﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmCerificadoOrigen
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmCerificadoOrigen))
        Me.botonExportar = New System.Windows.Forms.Button()
        Me.Panel2 = New System.Windows.Forms.Panel()
        Me.CeldaTitulo = New System.Windows.Forms.Label()
        Me.panelPrincipal = New System.Windows.Forms.Panel()
        Me.TabControl1 = New System.Windows.Forms.TabControl()
        Me.TabPage1 = New System.Windows.Forms.TabPage()
        Me.etiquetaHBI = New System.Windows.Forms.Label()
        Me.celdaHBI = New System.Windows.Forms.TextBox()
        Me.gbAnulación = New System.Windows.Forms.GroupBox()
        Me.celdaSaldoCajas = New System.Windows.Forms.TextBox()
        Me.Label27 = New System.Windows.Forms.Label()
        Me.celdaSaldoBruto = New System.Windows.Forms.TextBox()
        Me.celdaSaldoNeto = New System.Windows.Forms.TextBox()
        Me.Label25 = New System.Windows.Forms.Label()
        Me.Label26 = New System.Windows.Forms.Label()
        Me.celdaDestino = New System.Windows.Forms.TextBox()
        Me.Label23 = New System.Windows.Forms.Label()
        Me.DateTimePicker1 = New System.Windows.Forms.DateTimePicker()
        Me.celdaMedida = New System.Windows.Forms.TextBox()
        Me.celdaIDProducto = New System.Windows.Forms.Label()
        Me.celdaIDProveedor = New System.Windows.Forms.Label()
        Me.Label19 = New System.Windows.Forms.Label()
        Me.Label18 = New System.Windows.Forms.Label()
        Me.Label16 = New System.Windows.Forms.Label()
        Me.Label17 = New System.Windows.Forms.Label()
        Me.Label15 = New System.Windows.Forms.Label()
        Me.celdaTransporte = New System.Windows.Forms.TextBox()
        Me.celdaReferencia = New System.Windows.Forms.TextBox()
        Me.celdaPO = New System.Windows.Forms.TextBox()
        Me.celdaCajas = New System.Windows.Forms.TextBox()
        Me.CeldaContenedor = New System.Windows.Forms.TextBox()
        Me.celdaArancel = New System.Windows.Forms.TextBox()
        Me.Label14 = New System.Windows.Forms.Label()
        Me.celdaLote = New System.Windows.Forms.TextBox()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.celdaBruto = New System.Windows.Forms.TextBox()
        Me.celdaNeto = New System.Windows.Forms.TextBox()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.celdaProducto = New System.Windows.Forms.TextBox()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.celdaProveedorDic = New System.Windows.Forms.TextBox()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.celdaProveedor = New System.Windows.Forms.TextBox()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.celdaIDOrigen = New System.Windows.Forms.Label()
        Me.celdaOrigen = New System.Windows.Forms.TextBox()
        Me.botonSeleccionar = New System.Windows.Forms.Button()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.TabPage2 = New System.Windows.Forms.TabPage()
        Me.botonSelFirmante = New System.Windows.Forms.Button()
        Me.celdaIdFirmante = New System.Windows.Forms.Label()
        Me.celdaCorreo = New System.Windows.Forms.TextBox()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.CeldaPuesto = New System.Windows.Forms.TextBox()
        Me.Label20 = New System.Windows.Forms.Label()
        Me.celdaFirmante = New System.Windows.Forms.TextBox()
        Me.Label21 = New System.Windows.Forms.Label()
        Me.TabPage3 = New System.Windows.Forms.TabPage()
        Me.Panel4 = New System.Windows.Forms.Panel()
        Me.checkopc3 = New System.Windows.Forms.CheckBox()
        Me.checkopc2 = New System.Windows.Forms.CheckBox()
        Me.checkopc1 = New System.Windows.Forms.CheckBox()
        Me.Panel5 = New System.Windows.Forms.Panel()
        Me.dgDetalle = New System.Windows.Forms.DataGridView()
        Me.colidfibra = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colFibra = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colidorigen = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colOrigen = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colXtra = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colLinea1 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Panel6 = New System.Windows.Forms.Panel()
        Me.botonAdd = New System.Windows.Forms.Button()
        Me.botonDelete = New System.Windows.Forms.Button()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.celdaFact2 = New System.Windows.Forms.TextBox()
        Me.celdaCorrelativo = New System.Windows.Forms.TextBox()
        Me.Label24 = New System.Windows.Forms.Label()
        Me.celdaIDSerie = New System.Windows.Forms.TextBox()
        Me.celdaSerie = New System.Windows.Forms.TextBox()
        Me.botonSerie = New System.Windows.Forms.Button()
        Me.checkActivo = New System.Windows.Forms.CheckBox()
        Me.botonSeleccionarCliente = New System.Windows.Forms.Button()
        Me.celdaAño = New System.Windows.Forms.Label()
        Me.celdaIDCliente = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.celdaLinea = New System.Windows.Forms.TextBox()
        Me.celdaAñoFactrura = New System.Windows.Forms.TextBox()
        Me.celdaFactura = New System.Windows.Forms.TextBox()
        Me.celdaIdCertificado = New System.Windows.Forms.TextBox()
        Me.celdaCliente = New System.Windows.Forms.TextBox()
        Me.ListaCertificado = New System.Windows.Forms.DataGridView()
        Me.colNumero = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colCorrelativo = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colAnio = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colFecha = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colCliente = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colFactura = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colLinea = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colEstado = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.panelBusqueda = New System.Windows.Forms.Panel()
        Me.Panel3 = New System.Windows.Forms.Panel()
        Me.botonFiltrar = New System.Windows.Forms.Button()
        Me.celdaFacturaFiltro = New System.Windows.Forms.TextBox()
        Me.celdaClienteFlitro = New System.Windows.Forms.TextBox()
        Me.dtpFin = New System.Windows.Forms.DateTimePicker()
        Me.dtpInicio = New System.Windows.Forms.DateTimePicker()
        Me.CheckFactura = New System.Windows.Forms.CheckBox()
        Me.checkCliente = New System.Windows.Forms.CheckBox()
        Me.checkFechas = New System.Windows.Forms.CheckBox()
        Me.Label22 = New System.Windows.Forms.Label()
        Me.Encabezado1 = New KARIMs_SGI.encabezado()
        Me.Panel2.SuspendLayout()
        Me.panelPrincipal.SuspendLayout()
        Me.TabControl1.SuspendLayout()
        Me.TabPage1.SuspendLayout()
        Me.gbAnulación.SuspendLayout()
        Me.TabPage2.SuspendLayout()
        Me.TabPage3.SuspendLayout()
        Me.Panel4.SuspendLayout()
        Me.Panel5.SuspendLayout()
        CType(Me.dgDetalle, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Panel6.SuspendLayout()
        Me.Panel1.SuspendLayout()
        CType(Me.ListaCertificado, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.panelBusqueda.SuspendLayout()
        Me.Panel3.SuspendLayout()
        Me.SuspendLayout()
        '
        'botonExportar
        '
        Me.botonExportar.Image = Global.KARIMs_SGI.My.Resources.Resources.word1
        Me.botonExportar.Location = New System.Drawing.Point(204, 9)
        Me.botonExportar.Name = "botonExportar"
        Me.botonExportar.Size = New System.Drawing.Size(56, 45)
        Me.botonExportar.TabIndex = 13
        Me.botonExportar.Text = "&Exportar"
        Me.botonExportar.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.botonExportar.UseVisualStyleBackColor = True
        '
        'Panel2
        '
        Me.Panel2.BackColor = System.Drawing.Color.WhiteSmoke
        Me.Panel2.Controls.Add(Me.CeldaTitulo)
        Me.Panel2.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel2.Location = New System.Drawing.Point(0, 62)
        Me.Panel2.Name = "Panel2"
        Me.Panel2.Size = New System.Drawing.Size(1284, 26)
        Me.Panel2.TabIndex = 14
        '
        'CeldaTitulo
        '
        Me.CeldaTitulo.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.CeldaTitulo.AutoSize = True
        Me.CeldaTitulo.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.CeldaTitulo.Location = New System.Drawing.Point(18, 3)
        Me.CeldaTitulo.Name = "CeldaTitulo"
        Me.CeldaTitulo.Size = New System.Drawing.Size(50, 18)
        Me.CeldaTitulo.TabIndex = 0
        Me.CeldaTitulo.Text = "Titulo"
        '
        'panelPrincipal
        '
        Me.panelPrincipal.Controls.Add(Me.TabControl1)
        Me.panelPrincipal.Controls.Add(Me.Panel1)
        Me.panelPrincipal.Location = New System.Drawing.Point(21, 106)
        Me.panelPrincipal.Name = "panelPrincipal"
        Me.panelPrincipal.Size = New System.Drawing.Size(654, 565)
        Me.panelPrincipal.TabIndex = 15
        '
        'TabControl1
        '
        Me.TabControl1.Controls.Add(Me.TabPage1)
        Me.TabControl1.Controls.Add(Me.TabPage2)
        Me.TabControl1.Controls.Add(Me.TabPage3)
        Me.TabControl1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.TabControl1.Location = New System.Drawing.Point(0, 74)
        Me.TabControl1.Name = "TabControl1"
        Me.TabControl1.SelectedIndex = 0
        Me.TabControl1.Size = New System.Drawing.Size(654, 491)
        Me.TabControl1.TabIndex = 0
        '
        'TabPage1
        '
        Me.TabPage1.Controls.Add(Me.etiquetaHBI)
        Me.TabPage1.Controls.Add(Me.celdaHBI)
        Me.TabPage1.Controls.Add(Me.gbAnulación)
        Me.TabPage1.Controls.Add(Me.celdaDestino)
        Me.TabPage1.Controls.Add(Me.Label23)
        Me.TabPage1.Controls.Add(Me.DateTimePicker1)
        Me.TabPage1.Controls.Add(Me.celdaMedida)
        Me.TabPage1.Controls.Add(Me.celdaIDProducto)
        Me.TabPage1.Controls.Add(Me.celdaIDProveedor)
        Me.TabPage1.Controls.Add(Me.Label19)
        Me.TabPage1.Controls.Add(Me.Label18)
        Me.TabPage1.Controls.Add(Me.Label16)
        Me.TabPage1.Controls.Add(Me.Label17)
        Me.TabPage1.Controls.Add(Me.Label15)
        Me.TabPage1.Controls.Add(Me.celdaTransporte)
        Me.TabPage1.Controls.Add(Me.celdaReferencia)
        Me.TabPage1.Controls.Add(Me.celdaPO)
        Me.TabPage1.Controls.Add(Me.celdaCajas)
        Me.TabPage1.Controls.Add(Me.CeldaContenedor)
        Me.TabPage1.Controls.Add(Me.celdaArancel)
        Me.TabPage1.Controls.Add(Me.Label14)
        Me.TabPage1.Controls.Add(Me.celdaLote)
        Me.TabPage1.Controls.Add(Me.Label13)
        Me.TabPage1.Controls.Add(Me.celdaBruto)
        Me.TabPage1.Controls.Add(Me.celdaNeto)
        Me.TabPage1.Controls.Add(Me.Label12)
        Me.TabPage1.Controls.Add(Me.Label11)
        Me.TabPage1.Controls.Add(Me.celdaProducto)
        Me.TabPage1.Controls.Add(Me.Label10)
        Me.TabPage1.Controls.Add(Me.celdaProveedorDic)
        Me.TabPage1.Controls.Add(Me.Label9)
        Me.TabPage1.Controls.Add(Me.celdaProveedor)
        Me.TabPage1.Controls.Add(Me.Label8)
        Me.TabPage1.Controls.Add(Me.celdaIDOrigen)
        Me.TabPage1.Controls.Add(Me.celdaOrigen)
        Me.TabPage1.Controls.Add(Me.botonSeleccionar)
        Me.TabPage1.Controls.Add(Me.Label6)
        Me.TabPage1.Location = New System.Drawing.Point(4, 22)
        Me.TabPage1.Name = "TabPage1"
        Me.TabPage1.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage1.Size = New System.Drawing.Size(646, 465)
        Me.TabPage1.TabIndex = 0
        Me.TabPage1.Text = "Certificado"
        Me.TabPage1.UseVisualStyleBackColor = True
        '
        'etiquetaHBI
        '
        Me.etiquetaHBI.AutoSize = True
        Me.etiquetaHBI.Location = New System.Drawing.Point(28, 426)
        Me.etiquetaHBI.Name = "etiquetaHBI"
        Me.etiquetaHBI.Size = New System.Drawing.Size(57, 13)
        Me.etiquetaHBI.TabIndex = 28
        Me.etiquetaHBI.Text = "HBI PART"
        Me.etiquetaHBI.Visible = False
        '
        'celdaHBI
        '
        Me.celdaHBI.Location = New System.Drawing.Point(18, 442)
        Me.celdaHBI.Name = "celdaHBI"
        Me.celdaHBI.ReadOnly = True
        Me.celdaHBI.Size = New System.Drawing.Size(148, 20)
        Me.celdaHBI.TabIndex = 27
        Me.celdaHBI.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        Me.celdaHBI.Visible = False
        '
        'gbAnulación
        '
        Me.gbAnulación.BackColor = System.Drawing.SystemColors.ActiveCaption
        Me.gbAnulación.Controls.Add(Me.celdaSaldoCajas)
        Me.gbAnulación.Controls.Add(Me.Label27)
        Me.gbAnulación.Controls.Add(Me.celdaSaldoBruto)
        Me.gbAnulación.Controls.Add(Me.celdaSaldoNeto)
        Me.gbAnulación.Controls.Add(Me.Label25)
        Me.gbAnulación.Controls.Add(Me.Label26)
        Me.gbAnulación.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.gbAnulación.Location = New System.Drawing.Point(534, 38)
        Me.gbAnulación.Margin = New System.Windows.Forms.Padding(2)
        Me.gbAnulación.Name = "gbAnulación"
        Me.gbAnulación.Padding = New System.Windows.Forms.Padding(2)
        Me.gbAnulación.Size = New System.Drawing.Size(238, 179)
        Me.gbAnulación.TabIndex = 26
        Me.gbAnulación.TabStop = False
        Me.gbAnulación.Text = "Llenar Datos al Anular"
        '
        'celdaSaldoCajas
        '
        Me.celdaSaldoCajas.Location = New System.Drawing.Point(45, 144)
        Me.celdaSaldoCajas.Name = "celdaSaldoCajas"
        Me.celdaSaldoCajas.Size = New System.Drawing.Size(147, 19)
        Me.celdaSaldoCajas.TabIndex = 16
        Me.celdaSaldoCajas.Text = "0.00"
        '
        'Label27
        '
        Me.Label27.AutoSize = True
        Me.Label27.Location = New System.Drawing.Point(43, 127)
        Me.Label27.Name = "Label27"
        Me.Label27.Size = New System.Drawing.Size(62, 13)
        Me.Label27.TabIndex = 17
        Me.Label27.Text = "No. Cajas"
        '
        'celdaSaldoBruto
        '
        Me.celdaSaldoBruto.Location = New System.Drawing.Point(45, 90)
        Me.celdaSaldoBruto.Name = "celdaSaldoBruto"
        Me.celdaSaldoBruto.Size = New System.Drawing.Size(147, 19)
        Me.celdaSaldoBruto.TabIndex = 13
        Me.celdaSaldoBruto.Text = "0.00"
        '
        'celdaSaldoNeto
        '
        Me.celdaSaldoNeto.Location = New System.Drawing.Point(45, 37)
        Me.celdaSaldoNeto.Name = "celdaSaldoNeto"
        Me.celdaSaldoNeto.Size = New System.Drawing.Size(147, 19)
        Me.celdaSaldoNeto.TabIndex = 12
        Me.celdaSaldoNeto.Text = "0.00"
        '
        'Label25
        '
        Me.Label25.AutoSize = True
        Me.Label25.Location = New System.Drawing.Point(43, 73)
        Me.Label25.Name = "Label25"
        Me.Label25.Size = New System.Drawing.Size(73, 13)
        Me.Label25.TabIndex = 15
        Me.Label25.Text = "Saldo Bruto"
        '
        'Label26
        '
        Me.Label26.AutoSize = True
        Me.Label26.Location = New System.Drawing.Point(43, 20)
        Me.Label26.Name = "Label26"
        Me.Label26.Size = New System.Drawing.Size(70, 13)
        Me.Label26.TabIndex = 14
        Me.Label26.Text = "Saldo Neto"
        '
        'celdaDestino
        '
        Me.celdaDestino.Location = New System.Drawing.Point(20, 233)
        Me.celdaDestino.Name = "celdaDestino"
        Me.celdaDestino.Size = New System.Drawing.Size(336, 20)
        Me.celdaDestino.TabIndex = 25
        '
        'Label23
        '
        Me.Label23.AutoSize = True
        Me.Label23.Location = New System.Drawing.Point(29, 217)
        Me.Label23.Name = "Label23"
        Me.Label23.Size = New System.Drawing.Size(43, 13)
        Me.Label23.TabIndex = 24
        Me.Label23.Text = "Destino"
        '
        'DateTimePicker1
        '
        Me.DateTimePicker1.Location = New System.Drawing.Point(105, 10)
        Me.DateTimePicker1.Name = "DateTimePicker1"
        Me.DateTimePicker1.Size = New System.Drawing.Size(200, 20)
        Me.DateTimePicker1.TabIndex = 23
        Me.DateTimePicker1.Visible = False
        '
        'celdaMedida
        '
        Me.celdaMedida.Location = New System.Drawing.Point(326, 272)
        Me.celdaMedida.Name = "celdaMedida"
        Me.celdaMedida.ReadOnly = True
        Me.celdaMedida.Size = New System.Drawing.Size(29, 20)
        Me.celdaMedida.TabIndex = 22
        '
        'celdaIDProducto
        '
        Me.celdaIDProducto.AutoSize = True
        Me.celdaIDProducto.Location = New System.Drawing.Point(375, 158)
        Me.celdaIDProducto.Name = "celdaIDProducto"
        Me.celdaIDProducto.Size = New System.Drawing.Size(16, 13)
        Me.celdaIDProducto.TabIndex = 21
        Me.celdaIDProducto.Text = "-1"
        Me.celdaIDProducto.Visible = False
        '
        'celdaIDProveedor
        '
        Me.celdaIDProveedor.AutoSize = True
        Me.celdaIDProveedor.Location = New System.Drawing.Point(404, 80)
        Me.celdaIDProveedor.Name = "celdaIDProveedor"
        Me.celdaIDProveedor.Size = New System.Drawing.Size(16, 13)
        Me.celdaIDProveedor.TabIndex = 20
        Me.celdaIDProveedor.Text = "-1"
        Me.celdaIDProveedor.Visible = False
        '
        'Label19
        '
        Me.Label19.AutoSize = True
        Me.Label19.Location = New System.Drawing.Point(189, 386)
        Me.Label19.Name = "Label19"
        Me.Label19.Size = New System.Drawing.Size(29, 13)
        Me.Label19.TabIndex = 19
        Me.Label19.Text = "PO#"
        '
        'Label18
        '
        Me.Label18.AutoSize = True
        Me.Label18.Location = New System.Drawing.Point(29, 386)
        Me.Label18.Name = "Label18"
        Me.Label18.Size = New System.Drawing.Size(53, 13)
        Me.Label18.TabIndex = 19
        Me.Label18.Text = "No. Cajas"
        '
        'Label16
        '
        Me.Label16.AutoSize = True
        Me.Label16.Location = New System.Drawing.Point(29, 343)
        Me.Label16.Name = "Label16"
        Me.Label16.Size = New System.Drawing.Size(96, 13)
        Me.Label16.TabIndex = 19
        Me.Label16.Text = "Contenedor Origen"
        '
        'Label17
        '
        Me.Label17.AutoSize = True
        Me.Label17.Location = New System.Drawing.Point(204, 343)
        Me.Label17.Name = "Label17"
        Me.Label17.Size = New System.Drawing.Size(97, 13)
        Me.Label17.TabIndex = 18
        Me.Label17.Text = "Transporte Destino"
        '
        'Label15
        '
        Me.Label15.AutoSize = True
        Me.Label15.Location = New System.Drawing.Point(204, 304)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(59, 13)
        Me.Label15.TabIndex = 18
        Me.Label15.Text = "Referencia"
        '
        'celdaTransporte
        '
        Me.celdaTransporte.Location = New System.Drawing.Point(179, 359)
        Me.celdaTransporte.Name = "celdaTransporte"
        Me.celdaTransporte.Size = New System.Drawing.Size(148, 20)
        Me.celdaTransporte.TabIndex = 13
        '
        'celdaReferencia
        '
        Me.celdaReferencia.Location = New System.Drawing.Point(179, 320)
        Me.celdaReferencia.Name = "celdaReferencia"
        Me.celdaReferencia.Size = New System.Drawing.Size(148, 20)
        Me.celdaReferencia.TabIndex = 11
        '
        'celdaPO
        '
        Me.celdaPO.Location = New System.Drawing.Point(179, 402)
        Me.celdaPO.Name = "celdaPO"
        Me.celdaPO.Size = New System.Drawing.Size(148, 20)
        Me.celdaPO.TabIndex = 15
        '
        'celdaCajas
        '
        Me.celdaCajas.Location = New System.Drawing.Point(19, 402)
        Me.celdaCajas.Name = "celdaCajas"
        Me.celdaCajas.Size = New System.Drawing.Size(148, 20)
        Me.celdaCajas.TabIndex = 14
        Me.celdaCajas.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'CeldaContenedor
        '
        Me.CeldaContenedor.Location = New System.Drawing.Point(19, 359)
        Me.CeldaContenedor.Name = "CeldaContenedor"
        Me.CeldaContenedor.Size = New System.Drawing.Size(148, 20)
        Me.CeldaContenedor.TabIndex = 12
        '
        'celdaArancel
        '
        Me.celdaArancel.Location = New System.Drawing.Point(19, 320)
        Me.celdaArancel.Name = "celdaArancel"
        Me.celdaArancel.Size = New System.Drawing.Size(148, 20)
        Me.celdaArancel.TabIndex = 10
        '
        'Label14
        '
        Me.Label14.AutoSize = True
        Me.Label14.Location = New System.Drawing.Point(28, 304)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(96, 13)
        Me.Label14.TabIndex = 16
        Me.Label14.Text = "Partida Arancelaria"
        '
        'celdaLote
        '
        Me.celdaLote.Location = New System.Drawing.Point(20, 194)
        Me.celdaLote.Name = "celdaLote"
        Me.celdaLote.Size = New System.Drawing.Size(336, 20)
        Me.celdaLote.TabIndex = 7
        '
        'Label13
        '
        Me.Label13.AutoSize = True
        Me.Label13.Location = New System.Drawing.Point(29, 178)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(28, 13)
        Me.Label13.TabIndex = 14
        Me.Label13.Text = "Lote"
        '
        'celdaBruto
        '
        Me.celdaBruto.Location = New System.Drawing.Point(179, 272)
        Me.celdaBruto.Name = "celdaBruto"
        Me.celdaBruto.Size = New System.Drawing.Size(147, 20)
        Me.celdaBruto.TabIndex = 9
        '
        'celdaNeto
        '
        Me.celdaNeto.Location = New System.Drawing.Point(19, 272)
        Me.celdaNeto.Name = "celdaNeto"
        Me.celdaNeto.Size = New System.Drawing.Size(147, 20)
        Me.celdaNeto.TabIndex = 8
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.Location = New System.Drawing.Point(204, 256)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(59, 13)
        Me.Label12.TabIndex = 11
        Me.Label12.Text = "Peso Bruto"
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.Location = New System.Drawing.Point(29, 256)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(57, 13)
        Me.Label11.TabIndex = 10
        Me.Label11.Text = "Peso Neto"
        '
        'celdaProducto
        '
        Me.celdaProducto.Location = New System.Drawing.Point(20, 155)
        Me.celdaProducto.Name = "celdaProducto"
        Me.celdaProducto.Size = New System.Drawing.Size(336, 20)
        Me.celdaProducto.TabIndex = 6
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Location = New System.Drawing.Point(29, 139)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(50, 13)
        Me.Label10.TabIndex = 8
        Me.Label10.Text = "Producto"
        '
        'celdaProveedorDic
        '
        Me.celdaProveedorDic.Location = New System.Drawing.Point(20, 116)
        Me.celdaProveedorDic.Name = "celdaProveedorDic"
        Me.celdaProveedorDic.Size = New System.Drawing.Size(336, 20)
        Me.celdaProveedorDic.TabIndex = 5
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Location = New System.Drawing.Point(29, 100)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(103, 13)
        Me.Label9.TabIndex = 6
        Me.Label9.Text = "Dirección proveedor"
        '
        'celdaProveedor
        '
        Me.celdaProveedor.Location = New System.Drawing.Point(20, 77)
        Me.celdaProveedor.Name = "celdaProveedor"
        Me.celdaProveedor.Size = New System.Drawing.Size(336, 20)
        Me.celdaProveedor.TabIndex = 4
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Location = New System.Drawing.Point(29, 61)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(56, 13)
        Me.Label8.TabIndex = 4
        Me.Label8.Text = "Proveedor"
        '
        'celdaIDOrigen
        '
        Me.celdaIDOrigen.AutoSize = True
        Me.celdaIDOrigen.Location = New System.Drawing.Point(421, 41)
        Me.celdaIDOrigen.Name = "celdaIDOrigen"
        Me.celdaIDOrigen.Size = New System.Drawing.Size(16, 13)
        Me.celdaIDOrigen.TabIndex = 3
        Me.celdaIDOrigen.Text = "-1"
        Me.celdaIDOrigen.Visible = False
        '
        'celdaOrigen
        '
        Me.celdaOrigen.Location = New System.Drawing.Point(20, 38)
        Me.celdaOrigen.Name = "celdaOrigen"
        Me.celdaOrigen.Size = New System.Drawing.Size(336, 20)
        Me.celdaOrigen.TabIndex = 3
        '
        'botonSeleccionar
        '
        Me.botonSeleccionar.Location = New System.Drawing.Point(378, 34)
        Me.botonSeleccionar.Name = "botonSeleccionar"
        Me.botonSeleccionar.Size = New System.Drawing.Size(28, 23)
        Me.botonSeleccionar.TabIndex = 2
        Me.botonSeleccionar.Text = "..."
        Me.botonSeleccionar.UseVisualStyleBackColor = True
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(29, 22)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(67, 13)
        Me.Label6.TabIndex = 0
        Me.Label6.Text = "Procedencia"
        '
        'TabPage2
        '
        Me.TabPage2.Controls.Add(Me.botonSelFirmante)
        Me.TabPage2.Controls.Add(Me.celdaIdFirmante)
        Me.TabPage2.Controls.Add(Me.celdaCorreo)
        Me.TabPage2.Controls.Add(Me.Label7)
        Me.TabPage2.Controls.Add(Me.CeldaPuesto)
        Me.TabPage2.Controls.Add(Me.Label20)
        Me.TabPage2.Controls.Add(Me.celdaFirmante)
        Me.TabPage2.Controls.Add(Me.Label21)
        Me.TabPage2.Location = New System.Drawing.Point(4, 22)
        Me.TabPage2.Name = "TabPage2"
        Me.TabPage2.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage2.Size = New System.Drawing.Size(646, 465)
        Me.TabPage2.TabIndex = 1
        Me.TabPage2.Text = "Firmante"
        Me.TabPage2.UseVisualStyleBackColor = True
        '
        'botonSelFirmante
        '
        Me.botonSelFirmante.Location = New System.Drawing.Point(407, 35)
        Me.botonSelFirmante.Name = "botonSelFirmante"
        Me.botonSelFirmante.Size = New System.Drawing.Size(25, 23)
        Me.botonSelFirmante.TabIndex = 16
        Me.botonSelFirmante.Text = "..."
        Me.botonSelFirmante.UseVisualStyleBackColor = True
        '
        'celdaIdFirmante
        '
        Me.celdaIdFirmante.AutoSize = True
        Me.celdaIdFirmante.Location = New System.Drawing.Point(361, 45)
        Me.celdaIdFirmante.Name = "celdaIdFirmante"
        Me.celdaIdFirmante.Size = New System.Drawing.Size(16, 13)
        Me.celdaIdFirmante.TabIndex = 14
        Me.celdaIdFirmante.Text = "-1"
        Me.celdaIdFirmante.Visible = False
        '
        'celdaCorreo
        '
        Me.celdaCorreo.Location = New System.Drawing.Point(31, 120)
        Me.celdaCorreo.Name = "celdaCorreo"
        Me.celdaCorreo.Size = New System.Drawing.Size(306, 20)
        Me.celdaCorreo.TabIndex = 19
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(40, 104)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(38, 13)
        Me.Label7.TabIndex = 12
        Me.Label7.Text = "Correo"
        '
        'CeldaPuesto
        '
        Me.CeldaPuesto.Location = New System.Drawing.Point(31, 81)
        Me.CeldaPuesto.Name = "CeldaPuesto"
        Me.CeldaPuesto.ReadOnly = True
        Me.CeldaPuesto.Size = New System.Drawing.Size(306, 20)
        Me.CeldaPuesto.TabIndex = 18
        '
        'Label20
        '
        Me.Label20.AutoSize = True
        Me.Label20.Location = New System.Drawing.Point(40, 65)
        Me.Label20.Name = "Label20"
        Me.Label20.Size = New System.Drawing.Size(40, 13)
        Me.Label20.TabIndex = 10
        Me.Label20.Text = "Puesto"
        '
        'celdaFirmante
        '
        Me.celdaFirmante.Location = New System.Drawing.Point(31, 42)
        Me.celdaFirmante.Name = "celdaFirmante"
        Me.celdaFirmante.Size = New System.Drawing.Size(306, 20)
        Me.celdaFirmante.TabIndex = 17
        '
        'Label21
        '
        Me.Label21.AutoSize = True
        Me.Label21.Location = New System.Drawing.Point(40, 26)
        Me.Label21.Name = "Label21"
        Me.Label21.Size = New System.Drawing.Size(47, 13)
        Me.Label21.TabIndex = 8
        Me.Label21.Text = "Firmante"
        '
        'TabPage3
        '
        Me.TabPage3.Controls.Add(Me.Panel4)
        Me.TabPage3.Controls.Add(Me.Panel5)
        Me.TabPage3.Location = New System.Drawing.Point(4, 22)
        Me.TabPage3.Name = "TabPage3"
        Me.TabPage3.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage3.Size = New System.Drawing.Size(646, 465)
        Me.TabPage3.TabIndex = 2
        Me.TabPage3.Text = "Fibra"
        Me.TabPage3.UseVisualStyleBackColor = True
        '
        'Panel4
        '
        Me.Panel4.Controls.Add(Me.checkopc3)
        Me.Panel4.Controls.Add(Me.checkopc2)
        Me.Panel4.Controls.Add(Me.checkopc1)
        Me.Panel4.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel4.Location = New System.Drawing.Point(3, 3)
        Me.Panel4.Name = "Panel4"
        Me.Panel4.Size = New System.Drawing.Size(640, 110)
        Me.Panel4.TabIndex = 9
        '
        'checkopc3
        '
        Me.checkopc3.AutoSize = True
        Me.checkopc3.Location = New System.Drawing.Point(5, 70)
        Me.checkopc3.Name = "checkopc3"
        Me.checkopc3.Size = New System.Drawing.Size(414, 17)
        Me.checkopc3.TabIndex = 6
        Me.checkopc3.Text = "The yarn was wholly formed with fibers from countries other than CAFTA Countries." &
    ""
        Me.checkopc3.UseVisualStyleBackColor = True
        '
        'checkopc2
        '
        Me.checkopc2.AutoSize = True
        Me.checkopc2.Location = New System.Drawing.Point(5, 47)
        Me.checkopc2.Name = "checkopc2"
        Me.checkopc2.Size = New System.Drawing.Size(556, 17)
        Me.checkopc2.TabIndex = 5
        Me.checkopc2.Text = "The yarn was wholly or in part formed with fibers originating in the USA combined" &
    " with other fibers originating from"
        Me.checkopc2.UseVisualStyleBackColor = True
        '
        'checkopc1
        '
        Me.checkopc1.AutoSize = True
        Me.checkopc1.Location = New System.Drawing.Point(5, 24)
        Me.checkopc1.Name = "checkopc1"
        Me.checkopc1.Size = New System.Drawing.Size(527, 17)
        Me.checkopc1.TabIndex = 4
        Me.checkopc1.Text = "The yarn was wholly formed of Honduras in whole or in parts of fibers and/or mate" &
    "rials originating from USA"
        Me.checkopc1.UseVisualStyleBackColor = True
        '
        'Panel5
        '
        Me.Panel5.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Panel5.Controls.Add(Me.dgDetalle)
        Me.Panel5.Controls.Add(Me.Panel6)
        Me.Panel5.Location = New System.Drawing.Point(6, 119)
        Me.Panel5.Name = "Panel5"
        Me.Panel5.Size = New System.Drawing.Size(299, 303)
        Me.Panel5.TabIndex = 8
        '
        'dgDetalle
        '
        Me.dgDetalle.AllowUserToAddRows = False
        Me.dgDetalle.AllowUserToDeleteRows = False
        Me.dgDetalle.BackgroundColor = System.Drawing.SystemColors.ButtonHighlight
        Me.dgDetalle.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgDetalle.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.colidfibra, Me.colFibra, Me.colidorigen, Me.colOrigen, Me.colXtra, Me.colLinea1})
        Me.dgDetalle.Dock = System.Windows.Forms.DockStyle.Fill
        Me.dgDetalle.Location = New System.Drawing.Point(0, 0)
        Me.dgDetalle.Name = "dgDetalle"
        Me.dgDetalle.Size = New System.Drawing.Size(244, 303)
        Me.dgDetalle.TabIndex = 1
        '
        'colidfibra
        '
        Me.colidfibra.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill
        Me.colidfibra.HeaderText = "ID FIBRA"
        Me.colidfibra.Name = "colidfibra"
        Me.colidfibra.ReadOnly = True
        Me.colidfibra.Visible = False
        '
        'colFibra
        '
        Me.colFibra.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill
        Me.colFibra.HeaderText = "Fibra"
        Me.colFibra.Name = "colFibra"
        Me.colFibra.ReadOnly = True
        '
        'colidorigen
        '
        Me.colidorigen.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill
        Me.colidorigen.HeaderText = "ID Origen"
        Me.colidorigen.Name = "colidorigen"
        Me.colidorigen.ReadOnly = True
        Me.colidorigen.Visible = False
        '
        'colOrigen
        '
        Me.colOrigen.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill
        Me.colOrigen.HeaderText = "Origen"
        Me.colOrigen.Name = "colOrigen"
        Me.colOrigen.ReadOnly = True
        '
        'colXtra
        '
        Me.colXtra.HeaderText = "Xtra"
        Me.colXtra.Name = "colXtra"
        Me.colXtra.Visible = False
        '
        'colLinea1
        '
        Me.colLinea1.HeaderText = "Numero Linea"
        Me.colLinea1.Name = "colLinea1"
        Me.colLinea1.Visible = False
        '
        'Panel6
        '
        Me.Panel6.Controls.Add(Me.botonAdd)
        Me.Panel6.Controls.Add(Me.botonDelete)
        Me.Panel6.Dock = System.Windows.Forms.DockStyle.Right
        Me.Panel6.Location = New System.Drawing.Point(244, 0)
        Me.Panel6.Margin = New System.Windows.Forms.Padding(2)
        Me.Panel6.Name = "Panel6"
        Me.Panel6.Size = New System.Drawing.Size(55, 303)
        Me.Panel6.TabIndex = 4
        '
        'botonAdd
        '
        Me.botonAdd.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.botonAdd.Image = CType(resources.GetObject("botonAdd.Image"), System.Drawing.Image)
        Me.botonAdd.Location = New System.Drawing.Point(7, 10)
        Me.botonAdd.Name = "botonAdd"
        Me.botonAdd.Size = New System.Drawing.Size(39, 37)
        Me.botonAdd.TabIndex = 1
        Me.botonAdd.UseVisualStyleBackColor = True
        '
        'botonDelete
        '
        Me.botonDelete.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.botonDelete.Image = CType(resources.GetObject("botonDelete.Image"), System.Drawing.Image)
        Me.botonDelete.Location = New System.Drawing.Point(7, 59)
        Me.botonDelete.Name = "botonDelete"
        Me.botonDelete.Size = New System.Drawing.Size(39, 37)
        Me.botonDelete.TabIndex = 2
        Me.botonDelete.UseVisualStyleBackColor = True
        '
        'Panel1
        '
        Me.Panel1.Controls.Add(Me.celdaFact2)
        Me.Panel1.Controls.Add(Me.celdaCorrelativo)
        Me.Panel1.Controls.Add(Me.Label24)
        Me.Panel1.Controls.Add(Me.celdaIDSerie)
        Me.Panel1.Controls.Add(Me.celdaSerie)
        Me.Panel1.Controls.Add(Me.botonSerie)
        Me.Panel1.Controls.Add(Me.checkActivo)
        Me.Panel1.Controls.Add(Me.botonSeleccionarCliente)
        Me.Panel1.Controls.Add(Me.celdaAño)
        Me.Panel1.Controls.Add(Me.celdaIDCliente)
        Me.Panel1.Controls.Add(Me.Label4)
        Me.Panel1.Controls.Add(Me.Label5)
        Me.Panel1.Controls.Add(Me.Label3)
        Me.Panel1.Controls.Add(Me.Label2)
        Me.Panel1.Controls.Add(Me.Label1)
        Me.Panel1.Controls.Add(Me.celdaLinea)
        Me.Panel1.Controls.Add(Me.celdaAñoFactrura)
        Me.Panel1.Controls.Add(Me.celdaFactura)
        Me.Panel1.Controls.Add(Me.celdaIdCertificado)
        Me.Panel1.Controls.Add(Me.celdaCliente)
        Me.Panel1.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel1.Location = New System.Drawing.Point(0, 0)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(654, 74)
        Me.Panel1.TabIndex = 1
        '
        'celdaFact2
        '
        Me.celdaFact2.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.celdaFact2.BackColor = System.Drawing.SystemColors.Info
        Me.celdaFact2.Location = New System.Drawing.Point(401, 21)
        Me.celdaFact2.Name = "celdaFact2"
        Me.celdaFact2.ReadOnly = True
        Me.celdaFact2.Size = New System.Drawing.Size(53, 20)
        Me.celdaFact2.TabIndex = 11
        Me.celdaFact2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'celdaCorrelativo
        '
        Me.celdaCorrelativo.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.celdaCorrelativo.BackColor = System.Drawing.SystemColors.Info
        Me.celdaCorrelativo.Location = New System.Drawing.Point(348, 21)
        Me.celdaCorrelativo.Name = "celdaCorrelativo"
        Me.celdaCorrelativo.ReadOnly = True
        Me.celdaCorrelativo.Size = New System.Drawing.Size(53, 20)
        Me.celdaCorrelativo.TabIndex = 10
        Me.celdaCorrelativo.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Label24
        '
        Me.Label24.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label24.AutoSize = True
        Me.Label24.Location = New System.Drawing.Point(455, 52)
        Me.Label24.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label24.Name = "Label24"
        Me.Label24.Size = New System.Drawing.Size(96, 13)
        Me.Label24.TabIndex = 9
        Me.Label24.Text = "Tipo de Certificado"
        '
        'celdaIDSerie
        '
        Me.celdaIDSerie.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.celdaIDSerie.BackColor = System.Drawing.Color.White
        Me.celdaIDSerie.Location = New System.Drawing.Point(578, 5)
        Me.celdaIDSerie.Name = "celdaIDSerie"
        Me.celdaIDSerie.ReadOnly = True
        Me.celdaIDSerie.Size = New System.Drawing.Size(38, 20)
        Me.celdaIDSerie.TabIndex = 8
        Me.celdaIDSerie.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        Me.celdaIDSerie.Visible = False
        '
        'celdaSerie
        '
        Me.celdaSerie.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.celdaSerie.BackColor = System.Drawing.SystemColors.Info
        Me.celdaSerie.Location = New System.Drawing.Point(556, 50)
        Me.celdaSerie.Name = "celdaSerie"
        Me.celdaSerie.ReadOnly = True
        Me.celdaSerie.Size = New System.Drawing.Size(53, 20)
        Me.celdaSerie.TabIndex = 7
        Me.celdaSerie.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'botonSerie
        '
        Me.botonSerie.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.botonSerie.Location = New System.Drawing.Point(621, 46)
        Me.botonSerie.Name = "botonSerie"
        Me.botonSerie.Size = New System.Drawing.Size(25, 23)
        Me.botonSerie.TabIndex = 6
        Me.botonSerie.Text = "..."
        Me.botonSerie.UseVisualStyleBackColor = True
        '
        'checkActivo
        '
        Me.checkActivo.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.checkActivo.AutoSize = True
        Me.checkActivo.Checked = True
        Me.checkActivo.CheckState = System.Windows.Forms.CheckState.Checked
        Me.checkActivo.Location = New System.Drawing.Point(564, 23)
        Me.checkActivo.Name = "checkActivo"
        Me.checkActivo.Size = New System.Drawing.Size(56, 17)
        Me.checkActivo.TabIndex = 5
        Me.checkActivo.Text = "Activo"
        Me.checkActivo.UseVisualStyleBackColor = True
        '
        'botonSeleccionarCliente
        '
        Me.botonSeleccionarCliente.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.botonSeleccionarCliente.Location = New System.Drawing.Point(621, 19)
        Me.botonSeleccionarCliente.Name = "botonSeleccionarCliente"
        Me.botonSeleccionarCliente.Size = New System.Drawing.Size(25, 23)
        Me.botonSeleccionarCliente.TabIndex = 1
        Me.botonSeleccionarCliente.Text = "..."
        Me.botonSeleccionarCliente.UseVisualStyleBackColor = True
        '
        'celdaAño
        '
        Me.celdaAño.AutoSize = True
        Me.celdaAño.Location = New System.Drawing.Point(3, 24)
        Me.celdaAño.Name = "celdaAño"
        Me.celdaAño.Size = New System.Drawing.Size(16, 13)
        Me.celdaAño.TabIndex = 4
        Me.celdaAño.Text = "-1"
        Me.celdaAño.Visible = False
        '
        'celdaIDCliente
        '
        Me.celdaIDCliente.AutoSize = True
        Me.celdaIDCliente.Location = New System.Drawing.Point(3, 5)
        Me.celdaIDCliente.Name = "celdaIDCliente"
        Me.celdaIDCliente.Size = New System.Drawing.Size(16, 13)
        Me.celdaIDCliente.TabIndex = 4
        Me.celdaIDCliente.Text = "-1"
        Me.celdaIDCliente.Visible = False
        '
        'Label4
        '
        Me.Label4.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(403, 5)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(43, 13)
        Me.Label4.TabIndex = 3
        Me.Label4.Text = "Factura"
        '
        'Label5
        '
        Me.Label5.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(518, 5)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(35, 13)
        Me.Label5.TabIndex = 3
        Me.Label5.Text = "Línea"
        '
        'Label3
        '
        Me.Label3.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(467, 5)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(26, 13)
        Me.Label3.TabIndex = 3
        Me.Label3.Text = "Año"
        '
        'Label2
        '
        Me.Label2.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(364, 5)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(18, 13)
        Me.Label2.TabIndex = 3
        Me.Label2.Text = "ID"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(44, 5)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(39, 13)
        Me.Label1.TabIndex = 3
        Me.Label1.Text = "Cliente"
        '
        'celdaLinea
        '
        Me.celdaLinea.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.celdaLinea.BackColor = System.Drawing.SystemColors.Info
        Me.celdaLinea.Location = New System.Drawing.Point(508, 21)
        Me.celdaLinea.Name = "celdaLinea"
        Me.celdaLinea.ReadOnly = True
        Me.celdaLinea.Size = New System.Drawing.Size(53, 20)
        Me.celdaLinea.TabIndex = 2
        Me.celdaLinea.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'celdaAñoFactrura
        '
        Me.celdaAñoFactrura.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.celdaAñoFactrura.BackColor = System.Drawing.SystemColors.Info
        Me.celdaAñoFactrura.Location = New System.Drawing.Point(455, 21)
        Me.celdaAñoFactrura.Name = "celdaAñoFactrura"
        Me.celdaAñoFactrura.ReadOnly = True
        Me.celdaAñoFactrura.Size = New System.Drawing.Size(53, 20)
        Me.celdaAñoFactrura.TabIndex = 2
        Me.celdaAñoFactrura.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'celdaFactura
        '
        Me.celdaFactura.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.celdaFactura.BackColor = System.Drawing.SystemColors.Info
        Me.celdaFactura.Location = New System.Drawing.Point(405, 46)
        Me.celdaFactura.Name = "celdaFactura"
        Me.celdaFactura.ReadOnly = True
        Me.celdaFactura.Size = New System.Drawing.Size(53, 20)
        Me.celdaFactura.TabIndex = 2
        Me.celdaFactura.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        Me.celdaFactura.Visible = False
        '
        'celdaIdCertificado
        '
        Me.celdaIdCertificado.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.celdaIdCertificado.BackColor = System.Drawing.SystemColors.Info
        Me.celdaIdCertificado.Location = New System.Drawing.Point(348, 46)
        Me.celdaIdCertificado.Name = "celdaIdCertificado"
        Me.celdaIdCertificado.ReadOnly = True
        Me.celdaIdCertificado.Size = New System.Drawing.Size(53, 20)
        Me.celdaIdCertificado.TabIndex = 1
        Me.celdaIdCertificado.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        Me.celdaIdCertificado.Visible = False
        '
        'celdaCliente
        '
        Me.celdaCliente.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.celdaCliente.BackColor = System.Drawing.SystemColors.Info
        Me.celdaCliente.Location = New System.Drawing.Point(34, 21)
        Me.celdaCliente.Name = "celdaCliente"
        Me.celdaCliente.ReadOnly = True
        Me.celdaCliente.Size = New System.Drawing.Size(312, 20)
        Me.celdaCliente.TabIndex = 0
        '
        'ListaCertificado
        '
        Me.ListaCertificado.AllowUserToAddRows = False
        Me.ListaCertificado.AllowUserToDeleteRows = False
        Me.ListaCertificado.AllowUserToOrderColumns = True
        Me.ListaCertificado.BackgroundColor = System.Drawing.SystemColors.Control
        Me.ListaCertificado.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.ListaCertificado.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.colNumero, Me.colCorrelativo, Me.colAnio, Me.colFecha, Me.colCliente, Me.colFactura, Me.colLinea, Me.colEstado})
        Me.ListaCertificado.Dock = System.Windows.Forms.DockStyle.Fill
        Me.ListaCertificado.Location = New System.Drawing.Point(0, 100)
        Me.ListaCertificado.MultiSelect = False
        Me.ListaCertificado.Name = "ListaCertificado"
        Me.ListaCertificado.ReadOnly = True
        Me.ListaCertificado.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.ListaCertificado.Size = New System.Drawing.Size(457, 162)
        Me.ListaCertificado.TabIndex = 16
        '
        'colNumero
        '
        Me.colNumero.HeaderText = "Numero"
        Me.colNumero.Name = "colNumero"
        Me.colNumero.ReadOnly = True
        Me.colNumero.Visible = False
        '
        'colCorrelativo
        '
        Me.colCorrelativo.HeaderText = "Correlativo"
        Me.colCorrelativo.Name = "colCorrelativo"
        Me.colCorrelativo.ReadOnly = True
        '
        'colAnio
        '
        Me.colAnio.HeaderText = "Año"
        Me.colAnio.Name = "colAnio"
        Me.colAnio.ReadOnly = True
        '
        'colFecha
        '
        Me.colFecha.HeaderText = "Fecha"
        Me.colFecha.Name = "colFecha"
        Me.colFecha.ReadOnly = True
        '
        'colCliente
        '
        Me.colCliente.HeaderText = "Cliente"
        Me.colCliente.Name = "colCliente"
        Me.colCliente.ReadOnly = True
        '
        'colFactura
        '
        Me.colFactura.HeaderText = "Factura"
        Me.colFactura.Name = "colFactura"
        Me.colFactura.ReadOnly = True
        '
        'colLinea
        '
        Me.colLinea.HeaderText = "Linea"
        Me.colLinea.Name = "colLinea"
        Me.colLinea.ReadOnly = True
        '
        'colEstado
        '
        Me.colEstado.HeaderText = "Estado"
        Me.colEstado.Name = "colEstado"
        Me.colEstado.ReadOnly = True
        '
        'panelBusqueda
        '
        Me.panelBusqueda.Controls.Add(Me.ListaCertificado)
        Me.panelBusqueda.Controls.Add(Me.Panel3)
        Me.panelBusqueda.Location = New System.Drawing.Point(681, 111)
        Me.panelBusqueda.Name = "panelBusqueda"
        Me.panelBusqueda.Size = New System.Drawing.Size(457, 262)
        Me.panelBusqueda.TabIndex = 17
        '
        'Panel3
        '
        Me.Panel3.Controls.Add(Me.botonFiltrar)
        Me.Panel3.Controls.Add(Me.celdaFacturaFiltro)
        Me.Panel3.Controls.Add(Me.celdaClienteFlitro)
        Me.Panel3.Controls.Add(Me.dtpFin)
        Me.Panel3.Controls.Add(Me.dtpInicio)
        Me.Panel3.Controls.Add(Me.CheckFactura)
        Me.Panel3.Controls.Add(Me.checkCliente)
        Me.Panel3.Controls.Add(Me.checkFechas)
        Me.Panel3.Controls.Add(Me.Label22)
        Me.Panel3.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel3.Location = New System.Drawing.Point(0, 0)
        Me.Panel3.Name = "Panel3"
        Me.Panel3.Size = New System.Drawing.Size(457, 100)
        Me.Panel3.TabIndex = 0
        '
        'botonFiltrar
        '
        Me.botonFiltrar.Location = New System.Drawing.Point(347, 30)
        Me.botonFiltrar.Name = "botonFiltrar"
        Me.botonFiltrar.Size = New System.Drawing.Size(75, 23)
        Me.botonFiltrar.TabIndex = 6
        Me.botonFiltrar.Text = "Filtrar"
        Me.botonFiltrar.UseVisualStyleBackColor = True
        '
        'celdaFacturaFiltro
        '
        Me.celdaFacturaFiltro.Location = New System.Drawing.Point(134, 74)
        Me.celdaFacturaFiltro.Name = "celdaFacturaFiltro"
        Me.celdaFacturaFiltro.Size = New System.Drawing.Size(187, 20)
        Me.celdaFacturaFiltro.TabIndex = 5
        Me.celdaFacturaFiltro.Text = "0"
        '
        'celdaClienteFlitro
        '
        Me.celdaClienteFlitro.Location = New System.Drawing.Point(135, 51)
        Me.celdaClienteFlitro.Name = "celdaClienteFlitro"
        Me.celdaClienteFlitro.Size = New System.Drawing.Size(187, 20)
        Me.celdaClienteFlitro.TabIndex = 5
        '
        'dtpFin
        '
        Me.dtpFin.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.dtpFin.Location = New System.Drawing.Point(238, 26)
        Me.dtpFin.Name = "dtpFin"
        Me.dtpFin.Size = New System.Drawing.Size(84, 20)
        Me.dtpFin.TabIndex = 4
        '
        'dtpInicio
        '
        Me.dtpInicio.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.dtpInicio.Location = New System.Drawing.Point(135, 26)
        Me.dtpInicio.Name = "dtpInicio"
        Me.dtpInicio.Size = New System.Drawing.Size(84, 20)
        Me.dtpInicio.TabIndex = 4
        '
        'CheckFactura
        '
        Me.CheckFactura.AutoSize = True
        Me.CheckFactura.Location = New System.Drawing.Point(14, 76)
        Me.CheckFactura.Name = "CheckFactura"
        Me.CheckFactura.Size = New System.Drawing.Size(62, 17)
        Me.CheckFactura.TabIndex = 3
        Me.CheckFactura.Text = "Factura"
        Me.CheckFactura.UseVisualStyleBackColor = True
        '
        'checkCliente
        '
        Me.checkCliente.AutoSize = True
        Me.checkCliente.Location = New System.Drawing.Point(14, 53)
        Me.checkCliente.Name = "checkCliente"
        Me.checkCliente.Size = New System.Drawing.Size(58, 17)
        Me.checkCliente.TabIndex = 2
        Me.checkCliente.Text = "Cliente"
        Me.checkCliente.UseVisualStyleBackColor = True
        '
        'checkFechas
        '
        Me.checkFechas.AutoSize = True
        Me.checkFechas.Checked = True
        Me.checkFechas.CheckState = System.Windows.Forms.CheckState.Checked
        Me.checkFechas.Location = New System.Drawing.Point(14, 31)
        Me.checkFechas.Name = "checkFechas"
        Me.checkFechas.Size = New System.Drawing.Size(111, 17)
        Me.checkFechas.TabIndex = 1
        Me.checkFechas.Text = "Rango de Fechas"
        Me.checkFechas.UseVisualStyleBackColor = True
        '
        'Label22
        '
        Me.Label22.AutoSize = True
        Me.Label22.Location = New System.Drawing.Point(13, 12)
        Me.Label22.Name = "Label22"
        Me.Label22.Size = New System.Drawing.Size(53, 13)
        Me.Label22.TabIndex = 0
        Me.Label22.Text = "Filtrar por:"
        '
        'Encabezado1
        '
        Me.Encabezado1.Dock = System.Windows.Forms.DockStyle.Top
        Me.Encabezado1.Location = New System.Drawing.Point(0, 0)
        Me.Encabezado1.Margin = New System.Windows.Forms.Padding(4)
        Me.Encabezado1.Name = "Encabezado1"
        Me.Encabezado1.Size = New System.Drawing.Size(1284, 62)
        Me.Encabezado1.TabIndex = 0
        '
        'frmCerificadoOrigen
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.ClientSize = New System.Drawing.Size(1284, 683)
        Me.Controls.Add(Me.panelBusqueda)
        Me.Controls.Add(Me.panelPrincipal)
        Me.Controls.Add(Me.Panel2)
        Me.Controls.Add(Me.botonExportar)
        Me.Controls.Add(Me.Encabezado1)
        Me.Name = "frmCerificadoOrigen"
        Me.Text = "Certificados de Origen"
        Me.WindowState = System.Windows.Forms.FormWindowState.Maximized
        Me.Panel2.ResumeLayout(False)
        Me.Panel2.PerformLayout()
        Me.panelPrincipal.ResumeLayout(False)
        Me.TabControl1.ResumeLayout(False)
        Me.TabPage1.ResumeLayout(False)
        Me.TabPage1.PerformLayout()
        Me.gbAnulación.ResumeLayout(False)
        Me.gbAnulación.PerformLayout()
        Me.TabPage2.ResumeLayout(False)
        Me.TabPage2.PerformLayout()
        Me.TabPage3.ResumeLayout(False)
        Me.Panel4.ResumeLayout(False)
        Me.Panel4.PerformLayout()
        Me.Panel5.ResumeLayout(False)
        CType(Me.dgDetalle, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Panel6.ResumeLayout(False)
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        CType(Me.ListaCertificado, System.ComponentModel.ISupportInitialize).EndInit()
        Me.panelBusqueda.ResumeLayout(False)
        Me.Panel3.ResumeLayout(False)
        Me.Panel3.PerformLayout()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents Encabezado1 As KARIMs_SGI.encabezado
    Friend WithEvents botonExportar As System.Windows.Forms.Button
    Friend WithEvents Panel2 As System.Windows.Forms.Panel
    Friend WithEvents CeldaTitulo As System.Windows.Forms.Label
    Friend WithEvents panelPrincipal As System.Windows.Forms.Panel
    Friend WithEvents ListaCertificado As System.Windows.Forms.DataGridView
    Friend WithEvents TabControl1 As System.Windows.Forms.TabControl
    Friend WithEvents TabPage1 As System.Windows.Forms.TabPage
    Friend WithEvents TabPage2 As System.Windows.Forms.TabPage
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
    Friend WithEvents celdaAñoFactrura As System.Windows.Forms.TextBox
    Friend WithEvents celdaFactura As System.Windows.Forms.TextBox
    Friend WithEvents celdaIdCertificado As System.Windows.Forms.TextBox
    Friend WithEvents celdaCliente As System.Windows.Forms.TextBox
    Friend WithEvents celdaLinea As System.Windows.Forms.TextBox
    Friend WithEvents celdaAño As System.Windows.Forms.Label
    Friend WithEvents celdaIDCliente As System.Windows.Forms.Label
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents botonSeleccionarCliente As System.Windows.Forms.Button
    Friend WithEvents botonSeleccionar As System.Windows.Forms.Button
    Friend WithEvents celdaIDOrigen As System.Windows.Forms.Label
    Friend WithEvents celdaOrigen As System.Windows.Forms.TextBox
    Friend WithEvents celdaProducto As System.Windows.Forms.TextBox
    Friend WithEvents Label10 As System.Windows.Forms.Label
    Friend WithEvents celdaProveedorDic As System.Windows.Forms.TextBox
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents celdaProveedor As System.Windows.Forms.TextBox
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents celdaArancel As System.Windows.Forms.TextBox
    Friend WithEvents Label14 As System.Windows.Forms.Label
    Friend WithEvents celdaLote As System.Windows.Forms.TextBox
    Friend WithEvents Label13 As System.Windows.Forms.Label
    Friend WithEvents celdaBruto As System.Windows.Forms.TextBox
    Friend WithEvents celdaNeto As System.Windows.Forms.TextBox
    Friend WithEvents Label12 As System.Windows.Forms.Label
    Friend WithEvents Label11 As System.Windows.Forms.Label
    Friend WithEvents Label15 As System.Windows.Forms.Label
    Friend WithEvents celdaReferencia As System.Windows.Forms.TextBox
    Friend WithEvents Label16 As System.Windows.Forms.Label
    Friend WithEvents Label17 As System.Windows.Forms.Label
    Friend WithEvents celdaTransporte As System.Windows.Forms.TextBox
    Friend WithEvents CeldaContenedor As System.Windows.Forms.TextBox
    Friend WithEvents Label19 As System.Windows.Forms.Label
    Friend WithEvents Label18 As System.Windows.Forms.Label
    Friend WithEvents celdaPO As System.Windows.Forms.TextBox
    Friend WithEvents celdaCajas As System.Windows.Forms.TextBox
    Friend WithEvents celdaIDProducto As System.Windows.Forms.Label
    Friend WithEvents celdaIDProveedor As System.Windows.Forms.Label
    Friend WithEvents celdaCorreo As System.Windows.Forms.TextBox
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents Label20 As System.Windows.Forms.Label
    Friend WithEvents celdaFirmante As System.Windows.Forms.TextBox
    Friend WithEvents Label21 As System.Windows.Forms.Label
    Friend WithEvents celdaIdFirmante As System.Windows.Forms.Label
    Friend WithEvents botonSelFirmante As System.Windows.Forms.Button
    Friend WithEvents celdaMedida As System.Windows.Forms.TextBox
    Friend WithEvents DateTimePicker1 As System.Windows.Forms.DateTimePicker
    Friend WithEvents panelBusqueda As System.Windows.Forms.Panel
    Friend WithEvents Panel3 As System.Windows.Forms.Panel
    Friend WithEvents dtpFin As System.Windows.Forms.DateTimePicker
    Friend WithEvents dtpInicio As System.Windows.Forms.DateTimePicker
    Friend WithEvents CheckFactura As System.Windows.Forms.CheckBox
    Friend WithEvents checkCliente As System.Windows.Forms.CheckBox
    Friend WithEvents checkFechas As System.Windows.Forms.CheckBox
    Friend WithEvents Label22 As System.Windows.Forms.Label
    Friend WithEvents celdaFacturaFiltro As System.Windows.Forms.TextBox
    Friend WithEvents celdaClienteFlitro As System.Windows.Forms.TextBox
    Friend WithEvents botonFiltrar As System.Windows.Forms.Button
    Friend WithEvents checkActivo As System.Windows.Forms.CheckBox
    Friend WithEvents celdaDestino As System.Windows.Forms.TextBox
    Friend WithEvents Label23 As System.Windows.Forms.Label
    Friend WithEvents celdaIDSerie As TextBox
    Friend WithEvents celdaSerie As TextBox
    Friend WithEvents botonSerie As Button
    Friend WithEvents Label24 As Label
    Friend WithEvents celdaCorrelativo As TextBox
    Friend WithEvents colNumero As DataGridViewTextBoxColumn
    Friend WithEvents colCorrelativo As DataGridViewTextBoxColumn
    Friend WithEvents colAnio As DataGridViewTextBoxColumn
    Friend WithEvents colFecha As DataGridViewTextBoxColumn
    Friend WithEvents colCliente As DataGridViewTextBoxColumn
    Friend WithEvents colFactura As DataGridViewTextBoxColumn
    Friend WithEvents colLinea As DataGridViewTextBoxColumn
    Friend WithEvents colEstado As DataGridViewTextBoxColumn
    Friend WithEvents gbAnulación As GroupBox
    Friend WithEvents celdaSaldoBruto As TextBox
    Friend WithEvents celdaSaldoNeto As TextBox
    Friend WithEvents Label25 As Label
    Friend WithEvents Label26 As Label
    Friend WithEvents celdaFact2 As TextBox
    Friend WithEvents celdaSaldoCajas As TextBox
    Friend WithEvents Label27 As Label
    Friend WithEvents etiquetaHBI As Label
    Friend WithEvents celdaHBI As TextBox
    Friend WithEvents TabPage3 As TabPage
    Friend WithEvents Panel4 As Panel
    Friend WithEvents checkopc3 As System.Windows.Forms.CheckBox
    Friend WithEvents checkopc2 As System.Windows.Forms.CheckBox
    Friend WithEvents checkopc1 As System.Windows.Forms.CheckBox
    Friend WithEvents Panel5 As Panel
    Friend WithEvents Panel6 As Panel
    Friend WithEvents botonAdd As Button
    Friend WithEvents botonDelete As Button
    Friend WithEvents dgDetalle As DataGridView
    Friend WithEvents colidfibra As DataGridViewTextBoxColumn
    Friend WithEvents colFibra As DataGridViewTextBoxColumn
    Friend WithEvents colidorigen As DataGridViewTextBoxColumn
    Friend WithEvents colOrigen As DataGridViewTextBoxColumn
    Friend WithEvents colXtra As DataGridViewTextBoxColumn
    Friend WithEvents colLinea1 As DataGridViewTextBoxColumn
    Private WithEvents CeldaPuesto As TextBox
End Class
