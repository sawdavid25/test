﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmClientes
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmClientes))
        Me.panelLista = New System.Windows.Forms.Panel()
        Me.dgLista = New System.Windows.Forms.DataGridView()
        Me.Panel2 = New System.Windows.Forms.Panel()
        Me.botonBuscar = New System.Windows.Forms.Button()
        Me.botonImprimir = New System.Windows.Forms.Button()
        Me.panelDocumento = New System.Windows.Forms.Panel()
        Me.celdaGiro = New System.Windows.Forms.TextBox()
        Me.etiquetaGiro = New System.Windows.Forms.Label()
        Me.celdaRegistro = New System.Windows.Forms.TextBox()
        Me.etiquetaRegistro = New System.Windows.Forms.Label()
        Me.celdaIdCategoria = New System.Windows.Forms.TextBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.celdaCategoria = New System.Windows.Forms.TextBox()
        Me.botonCategoria = New System.Windows.Forms.Button()
        Me.panelDireccion = New System.Windows.Forms.Panel()
        Me.dgDireccionCliente = New System.Windows.Forms.DataGridView()
        Me.colCodigo = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colNom = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colDireccion = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colCodigo1 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colEstadoD = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.panelBoton = New System.Windows.Forms.Panel()
        Me.botonUp = New System.Windows.Forms.Button()
        Me.panelDetalle = New System.Windows.Forms.Panel()
        Me.panelDgDetalle = New System.Windows.Forms.Panel()
        Me.dgDetalle = New System.Windows.Forms.DataGridView()
        Me.colNombre = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colPuesto = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colCelular = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colCorreoElectronico = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colEstado = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colCode = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colEstatus = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colEliminar = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.panelBotones2 = New System.Windows.Forms.Panel()
        Me.botonAbajo = New System.Windows.Forms.Button()
        Me.botonArriba = New System.Windows.Forms.Button()
        Me.panelEncabezado = New System.Windows.Forms.Panel()
        Me.panelEncabezado2 = New System.Windows.Forms.Panel()
        Me.CeldaNombreCta = New System.Windows.Forms.TextBox()
        Me.gbPosicionCuenta = New System.Windows.Forms.GroupBox()
        Me.celdaDisponible = New System.Windows.Forms.TextBox()
        Me.celdaSaldo = New System.Windows.Forms.TextBox()
        Me.etiquetaDisponible = New System.Windows.Forms.Label()
        Me.etiquetaSaldo = New System.Windows.Forms.Label()
        Me.celdaCxC = New System.Windows.Forms.TextBox()
        Me.botonCuentaNomenclatura = New System.Windows.Forms.Button()
        Me.botonCuentasxCobrar = New System.Windows.Forms.Button()
        Me.celdaCuentasxCobrar = New System.Windows.Forms.TextBox()
        Me.celdaNumeroCta = New System.Windows.Forms.TextBox()
        Me.botonMetodoCosteo = New System.Windows.Forms.Button()
        Me.botonFormaPago = New System.Windows.Forms.Button()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.celdaLimiteCredito = New System.Windows.Forms.TextBox()
        Me.celdaMetodoCosteo = New System.Windows.Forms.TextBox()
        Me.celdaPlazoCreditos = New System.Windows.Forms.TextBox()
        Me.celdaDescuento = New System.Windows.Forms.TextBox()
        Me.celdaFormaPago = New System.Windows.Forms.TextBox()
        Me.etiquetaCuentasxCobrar = New System.Windows.Forms.Label()
        Me.etiquetaLimiteCredito = New System.Windows.Forms.Label()
        Me.etiquetaMetodoCosteo = New System.Windows.Forms.Label()
        Me.etiquetaPlazoCredito = New System.Windows.Forms.Label()
        Me.etiquetaDescuento = New System.Windows.Forms.Label()
        Me.etiquetaFormaPago = New System.Windows.Forms.Label()
        Me.panelEncabezado1 = New System.Windows.Forms.Panel()
        Me.rdCobro = New System.Windows.Forms.RadioButton()
        Me.rdDestino = New System.Windows.Forms.RadioButton()
        Me.rdHilo = New System.Windows.Forms.RadioButton()
        Me.btnClasificacion = New System.Windows.Forms.Button()
        Me.celdaClasificacion = New System.Windows.Forms.TextBox()
        Me.celdaIdClasificacion = New System.Windows.Forms.TextBox()
        Me.lblClasif = New System.Windows.Forms.Label()
        Me.celdaIdMoneda = New System.Windows.Forms.TextBox()
        Me.celdaIdPais = New System.Windows.Forms.TextBox()
        Me.botonManucfactura = New System.Windows.Forms.Button()
        Me.celdaManufactura = New System.Windows.Forms.TextBox()
        Me.celdaDescripcionCorta = New System.Windows.Forms.TextBox()
        Me.botonMoneda = New System.Windows.Forms.Button()
        Me.celdaPaymentInfo = New System.Windows.Forms.TextBox()
        Me.botonPais = New System.Windows.Forms.Button()
        Me.botonRegimen = New System.Windows.Forms.Button()
        Me.botonUsuario = New System.Windows.Forms.Button()
        Me.etiquetaPaymentInfo = New System.Windows.Forms.Label()
        Me.celdaMoneda = New System.Windows.Forms.TextBox()
        Me.celdaPais = New System.Windows.Forms.TextBox()
        Me.celdaRegimen = New System.Windows.Forms.TextBox()
        Me.celdaUsuario = New System.Windows.Forms.TextBox()
        Me.celdaTelefono = New System.Windows.Forms.TextBox()
        Me.celdaNIT = New System.Windows.Forms.TextBox()
        Me.celdaDireccion = New System.Windows.Forms.TextBox()
        Me.celdaRazonSocial = New System.Windows.Forms.TextBox()
        Me.celdaCodigo = New System.Windows.Forms.TextBox()
        Me.etiquetaMoneda = New System.Windows.Forms.Label()
        Me.etiquetaManufactura = New System.Windows.Forms.Label()
        Me.etiquetaPais = New System.Windows.Forms.Label()
        Me.etiquetaRegimen = New System.Windows.Forms.Label()
        Me.etiquetaUsuario = New System.Windows.Forms.Label()
        Me.etiquetaTelefono = New System.Windows.Forms.Label()
        Me.etiquetaNIT = New System.Windows.Forms.Label()
        Me.etiquetaDireccion = New System.Windows.Forms.Label()
        Me.etiquetaRazonSocial = New System.Windows.Forms.Label()
        Me.etiquetaCodigo = New System.Windows.Forms.Label()
        Me.etiquetaDescripcionCorta = New System.Windows.Forms.Label()
        Me.etiquetaEstado = New System.Windows.Forms.Label()
        Me.celdaEstado = New System.Windows.Forms.TextBox()
        Me.botonEstado = New System.Windows.Forms.Button()
        Me.BarraTitulo1 = New KARIMs_SGI.BarraTitulo()
        Me.Encabezado1 = New KARIMs_SGI.encabezado()
        Me.panelLista.SuspendLayout()
        CType(Me.dgLista, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.panelDocumento.SuspendLayout()
        Me.panelDireccion.SuspendLayout()
        CType(Me.dgDireccionCliente, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.panelBoton.SuspendLayout()
        Me.panelDetalle.SuspendLayout()
        Me.panelDgDetalle.SuspendLayout()
        CType(Me.dgDetalle, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.panelBotones2.SuspendLayout()
        Me.panelEncabezado.SuspendLayout()
        Me.panelEncabezado2.SuspendLayout()
        Me.gbPosicionCuenta.SuspendLayout()
        Me.panelEncabezado1.SuspendLayout()
        Me.SuspendLayout()
        '
        'panelLista
        '
        Me.panelLista.Controls.Add(Me.dgLista)
        Me.panelLista.Controls.Add(Me.Panel2)
        Me.panelLista.Location = New System.Drawing.Point(0, 108)
        Me.panelLista.Name = "panelLista"
        Me.panelLista.Size = New System.Drawing.Size(752, 52)
        Me.panelLista.TabIndex = 0
        '
        'dgLista
        '
        Me.dgLista.AllowUserToAddRows = False
        Me.dgLista.AllowUserToDeleteRows = False
        Me.dgLista.BackgroundColor = System.Drawing.SystemColors.Control
        Me.dgLista.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgLista.Dock = System.Windows.Forms.DockStyle.Fill
        Me.dgLista.Location = New System.Drawing.Point(0, 0)
        Me.dgLista.MultiSelect = False
        Me.dgLista.Name = "dgLista"
        Me.dgLista.ReadOnly = True
        Me.dgLista.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.dgLista.Size = New System.Drawing.Size(752, 52)
        Me.dgLista.TabIndex = 1
        '
        'Panel2
        '
        Me.Panel2.Location = New System.Drawing.Point(3, 236)
        Me.Panel2.Name = "Panel2"
        Me.Panel2.Size = New System.Drawing.Size(651, 191)
        Me.Panel2.TabIndex = 2
        '
        'botonBuscar
        '
        Me.botonBuscar.Image = CType(resources.GetObject("botonBuscar.Image"), System.Drawing.Image)
        Me.botonBuscar.Location = New System.Drawing.Point(268, 12)
        Me.botonBuscar.Name = "botonBuscar"
        Me.botonBuscar.Size = New System.Drawing.Size(59, 43)
        Me.botonBuscar.TabIndex = 22
        Me.botonBuscar.Text = "Look"
        Me.botonBuscar.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.botonBuscar.UseMnemonic = False
        Me.botonBuscar.UseVisualStyleBackColor = True
        '
        'botonImprimir
        '
        Me.botonImprimir.Image = Global.KARIMs_SGI.My.Resources.Resources.print
        Me.botonImprimir.Location = New System.Drawing.Point(204, 12)
        Me.botonImprimir.Name = "botonImprimir"
        Me.botonImprimir.Size = New System.Drawing.Size(59, 43)
        Me.botonImprimir.TabIndex = 21
        Me.botonImprimir.Text = "Print"
        Me.botonImprimir.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.botonImprimir.UseVisualStyleBackColor = True
        '
        'panelDocumento
        '
        Me.panelDocumento.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.panelDocumento.Controls.Add(Me.celdaGiro)
        Me.panelDocumento.Controls.Add(Me.etiquetaGiro)
        Me.panelDocumento.Controls.Add(Me.celdaRegistro)
        Me.panelDocumento.Controls.Add(Me.etiquetaRegistro)
        Me.panelDocumento.Controls.Add(Me.celdaIdCategoria)
        Me.panelDocumento.Controls.Add(Me.Label1)
        Me.panelDocumento.Controls.Add(Me.celdaCategoria)
        Me.panelDocumento.Controls.Add(Me.botonCategoria)
        Me.panelDocumento.Controls.Add(Me.panelDireccion)
        Me.panelDocumento.Controls.Add(Me.panelDetalle)
        Me.panelDocumento.Controls.Add(Me.panelEncabezado)
        Me.panelDocumento.Controls.Add(Me.etiquetaEstado)
        Me.panelDocumento.Controls.Add(Me.celdaEstado)
        Me.panelDocumento.Controls.Add(Me.botonEstado)
        Me.panelDocumento.Location = New System.Drawing.Point(3, 166)
        Me.panelDocumento.Name = "panelDocumento"
        Me.panelDocumento.Size = New System.Drawing.Size(880, 505)
        Me.panelDocumento.TabIndex = 23
        '
        'celdaGiro
        '
        Me.celdaGiro.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.celdaGiro.Location = New System.Drawing.Point(818, 422)
        Me.celdaGiro.Name = "celdaGiro"
        Me.celdaGiro.Size = New System.Drawing.Size(47, 20)
        Me.celdaGiro.TabIndex = 48
        '
        'etiquetaGiro
        '
        Me.etiquetaGiro.AutoSize = True
        Me.etiquetaGiro.Location = New System.Drawing.Point(815, 406)
        Me.etiquetaGiro.Name = "etiquetaGiro"
        Me.etiquetaGiro.Size = New System.Drawing.Size(70, 13)
        Me.etiquetaGiro.TabIndex = 47
        Me.etiquetaGiro.Text = "Business turn"
        '
        'celdaRegistro
        '
        Me.celdaRegistro.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.celdaRegistro.Location = New System.Drawing.Point(818, 379)
        Me.celdaRegistro.Name = "celdaRegistro"
        Me.celdaRegistro.Size = New System.Drawing.Size(47, 20)
        Me.celdaRegistro.TabIndex = 46
        '
        'etiquetaRegistro
        '
        Me.etiquetaRegistro.AutoSize = True
        Me.etiquetaRegistro.Location = New System.Drawing.Point(815, 362)
        Me.etiquetaRegistro.Name = "etiquetaRegistro"
        Me.etiquetaRegistro.Size = New System.Drawing.Size(66, 13)
        Me.etiquetaRegistro.TabIndex = 45
        Me.etiquetaRegistro.Text = "No. Register"
        '
        'celdaIdCategoria
        '
        Me.celdaIdCategoria.Location = New System.Drawing.Point(500, 292)
        Me.celdaIdCategoria.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.celdaIdCategoria.Name = "celdaIdCategoria"
        Me.celdaIdCategoria.Size = New System.Drawing.Size(24, 20)
        Me.celdaIdCategoria.TabIndex = 35
        Me.celdaIdCategoria.Text = "0"
        Me.celdaIdCategoria.Visible = False
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(289, 295)
        Me.Label1.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(49, 13)
        Me.Label1.TabIndex = 34
        Me.Label1.Text = "Category"
        '
        'celdaCategoria
        '
        Me.celdaCategoria.Location = New System.Drawing.Point(340, 291)
        Me.celdaCategoria.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.celdaCategoria.Name = "celdaCategoria"
        Me.celdaCategoria.ReadOnly = True
        Me.celdaCategoria.Size = New System.Drawing.Size(122, 20)
        Me.celdaCategoria.TabIndex = 33
        '
        'botonCategoria
        '
        Me.botonCategoria.Location = New System.Drawing.Point(466, 291)
        Me.botonCategoria.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.botonCategoria.Name = "botonCategoria"
        Me.botonCategoria.Size = New System.Drawing.Size(29, 19)
        Me.botonCategoria.TabIndex = 32
        Me.botonCategoria.Text = "..."
        Me.botonCategoria.UseVisualStyleBackColor = True
        '
        'panelDireccion
        '
        Me.panelDireccion.Controls.Add(Me.dgDireccionCliente)
        Me.panelDireccion.Controls.Add(Me.panelBoton)
        Me.panelDireccion.Location = New System.Drawing.Point(0, 405)
        Me.panelDireccion.Name = "panelDireccion"
        Me.panelDireccion.Size = New System.Drawing.Size(811, 100)
        Me.panelDireccion.TabIndex = 2
        '
        'dgDireccionCliente
        '
        Me.dgDireccionCliente.AllowUserToAddRows = False
        Me.dgDireccionCliente.AllowUserToDeleteRows = False
        Me.dgDireccionCliente.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells
        Me.dgDireccionCliente.BackgroundColor = System.Drawing.SystemColors.Control
        Me.dgDireccionCliente.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgDireccionCliente.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.colCodigo, Me.colNom, Me.colDireccion, Me.colCodigo1, Me.colEstadoD})
        Me.dgDireccionCliente.Location = New System.Drawing.Point(0, 0)
        Me.dgDireccionCliente.MultiSelect = False
        Me.dgDireccionCliente.Name = "dgDireccionCliente"
        Me.dgDireccionCliente.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.dgDireccionCliente.Size = New System.Drawing.Size(740, 100)
        Me.dgDireccionCliente.TabIndex = 1
        '
        'colCodigo
        '
        Me.colCodigo.HeaderText = ""
        Me.colCodigo.Name = "colCodigo"
        Me.colCodigo.Width = 19
        '
        'colNom
        '
        Me.colNom.HeaderText = "Name"
        Me.colNom.Name = "colNom"
        Me.colNom.Width = 60
        '
        'colDireccion
        '
        Me.colDireccion.HeaderText = "Direction"
        Me.colDireccion.Name = "colDireccion"
        Me.colDireccion.Width = 74
        '
        'colCodigo1
        '
        Me.colCodigo1.HeaderText = "Codigo"
        Me.colCodigo1.Name = "colCodigo1"
        Me.colCodigo1.Visible = False
        Me.colCodigo1.Width = 81
        '
        'colEstadoD
        '
        Me.colEstadoD.HeaderText = "Estado"
        Me.colEstadoD.Name = "colEstadoD"
        Me.colEstadoD.Visible = False
        Me.colEstadoD.Width = 81
        '
        'panelBoton
        '
        Me.panelBoton.Controls.Add(Me.botonUp)
        Me.panelBoton.Location = New System.Drawing.Point(739, 0)
        Me.panelBoton.Name = "panelBoton"
        Me.panelBoton.Size = New System.Drawing.Size(72, 100)
        Me.panelBoton.TabIndex = 4
        '
        'botonUp
        '
        Me.botonUp.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.botonUp.Image = Global.KARIMs_SGI.My.Resources.Resources.arrow_up_blue
        Me.botonUp.Location = New System.Drawing.Point(18, 24)
        Me.botonUp.Name = "botonUp"
        Me.botonUp.Size = New System.Drawing.Size(32, 23)
        Me.botonUp.TabIndex = 30
        Me.botonUp.UseVisualStyleBackColor = True
        '
        'panelDetalle
        '
        Me.panelDetalle.Controls.Add(Me.panelDgDetalle)
        Me.panelDetalle.Controls.Add(Me.panelBotones2)
        Me.panelDetalle.Location = New System.Drawing.Point(0, 329)
        Me.panelDetalle.Name = "panelDetalle"
        Me.panelDetalle.Size = New System.Drawing.Size(811, 68)
        Me.panelDetalle.TabIndex = 1
        '
        'panelDgDetalle
        '
        Me.panelDgDetalle.Controls.Add(Me.dgDetalle)
        Me.panelDgDetalle.Dock = System.Windows.Forms.DockStyle.Left
        Me.panelDgDetalle.Location = New System.Drawing.Point(0, 0)
        Me.panelDgDetalle.Name = "panelDgDetalle"
        Me.panelDgDetalle.Size = New System.Drawing.Size(740, 68)
        Me.panelDgDetalle.TabIndex = 6
        '
        'dgDetalle
        '
        Me.dgDetalle.AllowUserToAddRows = False
        Me.dgDetalle.AllowUserToDeleteRows = False
        Me.dgDetalle.BackgroundColor = System.Drawing.SystemColors.Control
        Me.dgDetalle.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgDetalle.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.colNombre, Me.colPuesto, Me.colCelular, Me.colCorreoElectronico, Me.colEstado, Me.colCode, Me.colEstatus, Me.colEliminar})
        Me.dgDetalle.Dock = System.Windows.Forms.DockStyle.Fill
        Me.dgDetalle.Location = New System.Drawing.Point(0, 0)
        Me.dgDetalle.MultiSelect = False
        Me.dgDetalle.Name = "dgDetalle"
        Me.dgDetalle.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.dgDetalle.Size = New System.Drawing.Size(740, 68)
        Me.dgDetalle.TabIndex = 0
        '
        'colNombre
        '
        Me.colNombre.HeaderText = "Name"
        Me.colNombre.Name = "colNombre"
        '
        'colPuesto
        '
        Me.colPuesto.HeaderText = "Post"
        Me.colPuesto.Name = "colPuesto"
        '
        'colCelular
        '
        Me.colCelular.HeaderText = "Cell"
        Me.colCelular.Name = "colCelular"
        '
        'colCorreoElectronico
        '
        Me.colCorreoElectronico.HeaderText = "Email"
        Me.colCorreoElectronico.Name = "colCorreoElectronico"
        '
        'colEstado
        '
        Me.colEstado.HeaderText = "State"
        Me.colEstado.Name = "colEstado"
        '
        'colCode
        '
        Me.colCode.HeaderText = "Codigo"
        Me.colCode.Name = "colCode"
        Me.colCode.Visible = False
        '
        'colEstatus
        '
        Me.colEstatus.HeaderText = "Estatus "
        Me.colEstatus.Name = "colEstatus"
        Me.colEstatus.Visible = False
        '
        'colEliminar
        '
        Me.colEliminar.HeaderText = "eliminar"
        Me.colEliminar.Name = "colEliminar"
        Me.colEliminar.Visible = False
        '
        'panelBotones2
        '
        Me.panelBotones2.Controls.Add(Me.botonAbajo)
        Me.panelBotones2.Controls.Add(Me.botonArriba)
        Me.panelBotones2.Location = New System.Drawing.Point(739, 0)
        Me.panelBotones2.Name = "panelBotones2"
        Me.panelBotones2.Size = New System.Drawing.Size(72, 106)
        Me.panelBotones2.TabIndex = 5
        '
        'botonAbajo
        '
        Me.botonAbajo.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.botonAbajo.Image = Global.KARIMs_SGI.My.Resources.Resources.delete31
        Me.botonAbajo.Location = New System.Drawing.Point(18, 40)
        Me.botonAbajo.Name = "botonAbajo"
        Me.botonAbajo.Size = New System.Drawing.Size(32, 25)
        Me.botonAbajo.TabIndex = 31
        Me.botonAbajo.UseVisualStyleBackColor = True
        '
        'botonArriba
        '
        Me.botonArriba.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.botonArriba.Image = Global.KARIMs_SGI.My.Resources.Resources.arrow_up_blue
        Me.botonArriba.Location = New System.Drawing.Point(18, 3)
        Me.botonArriba.Name = "botonArriba"
        Me.botonArriba.Size = New System.Drawing.Size(32, 23)
        Me.botonArriba.TabIndex = 30
        Me.botonArriba.UseVisualStyleBackColor = True
        '
        'panelEncabezado
        '
        Me.panelEncabezado.Controls.Add(Me.panelEncabezado2)
        Me.panelEncabezado.Controls.Add(Me.panelEncabezado1)
        Me.panelEncabezado.Dock = System.Windows.Forms.DockStyle.Top
        Me.panelEncabezado.Location = New System.Drawing.Point(0, 0)
        Me.panelEncabezado.Name = "panelEncabezado"
        Me.panelEncabezado.Size = New System.Drawing.Size(880, 355)
        Me.panelEncabezado.TabIndex = 0
        '
        'panelEncabezado2
        '
        Me.panelEncabezado2.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.panelEncabezado2.Controls.Add(Me.CeldaNombreCta)
        Me.panelEncabezado2.Controls.Add(Me.gbPosicionCuenta)
        Me.panelEncabezado2.Controls.Add(Me.celdaCxC)
        Me.panelEncabezado2.Controls.Add(Me.botonCuentaNomenclatura)
        Me.panelEncabezado2.Controls.Add(Me.botonCuentasxCobrar)
        Me.panelEncabezado2.Controls.Add(Me.celdaCuentasxCobrar)
        Me.panelEncabezado2.Controls.Add(Me.celdaNumeroCta)
        Me.panelEncabezado2.Controls.Add(Me.botonMetodoCosteo)
        Me.panelEncabezado2.Controls.Add(Me.botonFormaPago)
        Me.panelEncabezado2.Controls.Add(Me.Label2)
        Me.panelEncabezado2.Controls.Add(Me.celdaLimiteCredito)
        Me.panelEncabezado2.Controls.Add(Me.celdaMetodoCosteo)
        Me.panelEncabezado2.Controls.Add(Me.celdaPlazoCreditos)
        Me.panelEncabezado2.Controls.Add(Me.celdaDescuento)
        Me.panelEncabezado2.Controls.Add(Me.celdaFormaPago)
        Me.panelEncabezado2.Controls.Add(Me.etiquetaCuentasxCobrar)
        Me.panelEncabezado2.Controls.Add(Me.etiquetaLimiteCredito)
        Me.panelEncabezado2.Controls.Add(Me.etiquetaMetodoCosteo)
        Me.panelEncabezado2.Controls.Add(Me.etiquetaPlazoCredito)
        Me.panelEncabezado2.Controls.Add(Me.etiquetaDescuento)
        Me.panelEncabezado2.Controls.Add(Me.etiquetaFormaPago)
        Me.panelEncabezado2.Location = New System.Drawing.Point(613, 0)
        Me.panelEncabezado2.Name = "panelEncabezado2"
        Me.panelEncabezado2.Size = New System.Drawing.Size(248, 369)
        Me.panelEncabezado2.TabIndex = 3
        '
        'CeldaNombreCta
        '
        Me.CeldaNombreCta.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.CeldaNombreCta.BackColor = System.Drawing.SystemColors.Info
        Me.CeldaNombreCta.Location = New System.Drawing.Point(16, 327)
        Me.CeldaNombreCta.Name = "CeldaNombreCta"
        Me.CeldaNombreCta.Size = New System.Drawing.Size(230, 20)
        Me.CeldaNombreCta.TabIndex = 53
        '
        'gbPosicionCuenta
        '
        Me.gbPosicionCuenta.Controls.Add(Me.celdaDisponible)
        Me.gbPosicionCuenta.Controls.Add(Me.celdaSaldo)
        Me.gbPosicionCuenta.Controls.Add(Me.etiquetaDisponible)
        Me.gbPosicionCuenta.Controls.Add(Me.etiquetaSaldo)
        Me.gbPosicionCuenta.Location = New System.Drawing.Point(15, 204)
        Me.gbPosicionCuenta.Name = "gbPosicionCuenta"
        Me.gbPosicionCuenta.Size = New System.Drawing.Size(217, 78)
        Me.gbPosicionCuenta.TabIndex = 49
        Me.gbPosicionCuenta.TabStop = False
        Me.gbPosicionCuenta.Text = "Account Position"
        '
        'celdaDisponible
        '
        Me.celdaDisponible.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.celdaDisponible.Location = New System.Drawing.Point(65, 45)
        Me.celdaDisponible.Name = "celdaDisponible"
        Me.celdaDisponible.Size = New System.Drawing.Size(146, 20)
        Me.celdaDisponible.TabIndex = 43
        '
        'celdaSaldo
        '
        Me.celdaSaldo.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.celdaSaldo.Location = New System.Drawing.Point(65, 24)
        Me.celdaSaldo.Name = "celdaSaldo"
        Me.celdaSaldo.Size = New System.Drawing.Size(146, 20)
        Me.celdaSaldo.TabIndex = 42
        '
        'etiquetaDisponible
        '
        Me.etiquetaDisponible.AutoSize = True
        Me.etiquetaDisponible.Location = New System.Drawing.Point(6, 48)
        Me.etiquetaDisponible.Name = "etiquetaDisponible"
        Me.etiquetaDisponible.Size = New System.Drawing.Size(50, 13)
        Me.etiquetaDisponible.TabIndex = 39
        Me.etiquetaDisponible.Text = "Available"
        '
        'etiquetaSaldo
        '
        Me.etiquetaSaldo.AutoSize = True
        Me.etiquetaSaldo.Location = New System.Drawing.Point(6, 24)
        Me.etiquetaSaldo.Name = "etiquetaSaldo"
        Me.etiquetaSaldo.Size = New System.Drawing.Size(46, 13)
        Me.etiquetaSaldo.TabIndex = 38
        Me.etiquetaSaldo.Text = "Balance"
        '
        'celdaCxC
        '
        Me.celdaCxC.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.celdaCxC.BackColor = System.Drawing.SystemColors.Info
        Me.celdaCxC.Location = New System.Drawing.Point(6, 178)
        Me.celdaCxC.Name = "celdaCxC"
        Me.celdaCxC.Size = New System.Drawing.Size(230, 20)
        Me.celdaCxC.TabIndex = 48
        '
        'botonCuentaNomenclatura
        '
        Me.botonCuentaNomenclatura.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.botonCuentaNomenclatura.Location = New System.Drawing.Point(214, 301)
        Me.botonCuentaNomenclatura.Name = "botonCuentaNomenclatura"
        Me.botonCuentaNomenclatura.Size = New System.Drawing.Size(32, 23)
        Me.botonCuentaNomenclatura.TabIndex = 52
        Me.botonCuentaNomenclatura.Text = "..."
        Me.botonCuentaNomenclatura.UseVisualStyleBackColor = True
        '
        'botonCuentasxCobrar
        '
        Me.botonCuentasxCobrar.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.botonCuentasxCobrar.Location = New System.Drawing.Point(205, 152)
        Me.botonCuentasxCobrar.Name = "botonCuentasxCobrar"
        Me.botonCuentasxCobrar.Size = New System.Drawing.Size(32, 23)
        Me.botonCuentasxCobrar.TabIndex = 47
        Me.botonCuentasxCobrar.Text = "..."
        Me.botonCuentasxCobrar.UseVisualStyleBackColor = True
        '
        'celdaCuentasxCobrar
        '
        Me.celdaCuentasxCobrar.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.celdaCuentasxCobrar.Location = New System.Drawing.Point(6, 155)
        Me.celdaCuentasxCobrar.Name = "celdaCuentasxCobrar"
        Me.celdaCuentasxCobrar.Size = New System.Drawing.Size(192, 20)
        Me.celdaCuentasxCobrar.TabIndex = 46
        '
        'celdaNumeroCta
        '
        Me.celdaNumeroCta.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.celdaNumeroCta.Location = New System.Drawing.Point(16, 305)
        Me.celdaNumeroCta.Name = "celdaNumeroCta"
        Me.celdaNumeroCta.Size = New System.Drawing.Size(192, 20)
        Me.celdaNumeroCta.TabIndex = 51
        '
        'botonMetodoCosteo
        '
        Me.botonMetodoCosteo.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.botonMetodoCosteo.Location = New System.Drawing.Point(205, 82)
        Me.botonMetodoCosteo.Name = "botonMetodoCosteo"
        Me.botonMetodoCosteo.Size = New System.Drawing.Size(32, 23)
        Me.botonMetodoCosteo.TabIndex = 45
        Me.botonMetodoCosteo.Text = "..."
        Me.botonMetodoCosteo.UseVisualStyleBackColor = True
        '
        'botonFormaPago
        '
        Me.botonFormaPago.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.botonFormaPago.Location = New System.Drawing.Point(205, 10)
        Me.botonFormaPago.Name = "botonFormaPago"
        Me.botonFormaPago.Size = New System.Drawing.Size(32, 23)
        Me.botonFormaPago.TabIndex = 44
        Me.botonFormaPago.Text = "..."
        Me.botonFormaPago.UseVisualStyleBackColor = True
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(13, 288)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(89, 13)
        Me.Label2.TabIndex = 50
        Me.Label2.Text = "Account to affect"
        '
        'celdaLimiteCredito
        '
        Me.celdaLimiteCredito.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.celdaLimiteCredito.Location = New System.Drawing.Point(120, 109)
        Me.celdaLimiteCredito.Name = "celdaLimiteCredito"
        Me.celdaLimiteCredito.Size = New System.Drawing.Size(116, 20)
        Me.celdaLimiteCredito.TabIndex = 43
        '
        'celdaMetodoCosteo
        '
        Me.celdaMetodoCosteo.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.celdaMetodoCosteo.Location = New System.Drawing.Point(120, 85)
        Me.celdaMetodoCosteo.Name = "celdaMetodoCosteo"
        Me.celdaMetodoCosteo.Size = New System.Drawing.Size(78, 20)
        Me.celdaMetodoCosteo.TabIndex = 42
        Me.celdaMetodoCosteo.Text = "CIF"
        '
        'celdaPlazoCreditos
        '
        Me.celdaPlazoCreditos.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.celdaPlazoCreditos.Location = New System.Drawing.Point(120, 60)
        Me.celdaPlazoCreditos.Name = "celdaPlazoCreditos"
        Me.celdaPlazoCreditos.Size = New System.Drawing.Size(56, 20)
        Me.celdaPlazoCreditos.TabIndex = 41
        '
        'celdaDescuento
        '
        Me.celdaDescuento.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.celdaDescuento.Location = New System.Drawing.Point(120, 38)
        Me.celdaDescuento.Name = "celdaDescuento"
        Me.celdaDescuento.Size = New System.Drawing.Size(56, 20)
        Me.celdaDescuento.TabIndex = 40
        '
        'celdaFormaPago
        '
        Me.celdaFormaPago.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.celdaFormaPago.Location = New System.Drawing.Point(120, 12)
        Me.celdaFormaPago.Name = "celdaFormaPago"
        Me.celdaFormaPago.Size = New System.Drawing.Size(78, 20)
        Me.celdaFormaPago.TabIndex = 39
        '
        'etiquetaCuentasxCobrar
        '
        Me.etiquetaCuentasxCobrar.AutoSize = True
        Me.etiquetaCuentasxCobrar.Location = New System.Drawing.Point(3, 138)
        Me.etiquetaCuentasxCobrar.Name = "etiquetaCuentasxCobrar"
        Me.etiquetaCuentasxCobrar.Size = New System.Drawing.Size(114, 13)
        Me.etiquetaCuentasxCobrar.TabIndex = 38
        Me.etiquetaCuentasxCobrar.Text = "Accounts Receivables"
        '
        'etiquetaLimiteCredito
        '
        Me.etiquetaLimiteCredito.AutoSize = True
        Me.etiquetaLimiteCredito.Location = New System.Drawing.Point(3, 112)
        Me.etiquetaLimiteCredito.Name = "etiquetaLimiteCredito"
        Me.etiquetaLimiteCredito.Size = New System.Drawing.Size(103, 13)
        Me.etiquetaLimiteCredito.TabIndex = 37
        Me.etiquetaLimiteCredito.Text = "Credit Limit (Amount)"
        '
        'etiquetaMetodoCosteo
        '
        Me.etiquetaMetodoCosteo.AutoSize = True
        Me.etiquetaMetodoCosteo.Location = New System.Drawing.Point(3, 88)
        Me.etiquetaMetodoCosteo.Name = "etiquetaMetodoCosteo"
        Me.etiquetaMetodoCosteo.Size = New System.Drawing.Size(81, 13)
        Me.etiquetaMetodoCosteo.TabIndex = 36
        Me.etiquetaMetodoCosteo.Text = "Costing Method"
        '
        'etiquetaPlazoCredito
        '
        Me.etiquetaPlazoCredito.AutoSize = True
        Me.etiquetaPlazoCredito.Location = New System.Drawing.Point(3, 63)
        Me.etiquetaPlazoCredito.Name = "etiquetaPlazoCredito"
        Me.etiquetaPlazoCredito.Size = New System.Drawing.Size(94, 13)
        Me.etiquetaPlazoCredito.TabIndex = 35
        Me.etiquetaPlazoCredito.Text = "Credit Term (Days)"
        '
        'etiquetaDescuento
        '
        Me.etiquetaDescuento.AutoSize = True
        Me.etiquetaDescuento.Location = New System.Drawing.Point(3, 41)
        Me.etiquetaDescuento.Name = "etiquetaDescuento"
        Me.etiquetaDescuento.Size = New System.Drawing.Size(115, 13)
        Me.etiquetaDescuento.TabIndex = 34
        Me.etiquetaDescuento.Text = "Discount Approved (%)"
        '
        'etiquetaFormaPago
        '
        Me.etiquetaFormaPago.AutoSize = True
        Me.etiquetaFormaPago.Location = New System.Drawing.Point(3, 15)
        Me.etiquetaFormaPago.Name = "etiquetaFormaPago"
        Me.etiquetaFormaPago.Size = New System.Drawing.Size(62, 13)
        Me.etiquetaFormaPago.TabIndex = 33
        Me.etiquetaFormaPago.Text = "Way to Pay"
        '
        'panelEncabezado1
        '
        Me.panelEncabezado1.Controls.Add(Me.rdCobro)
        Me.panelEncabezado1.Controls.Add(Me.rdDestino)
        Me.panelEncabezado1.Controls.Add(Me.rdHilo)
        Me.panelEncabezado1.Controls.Add(Me.btnClasificacion)
        Me.panelEncabezado1.Controls.Add(Me.celdaClasificacion)
        Me.panelEncabezado1.Controls.Add(Me.celdaIdClasificacion)
        Me.panelEncabezado1.Controls.Add(Me.lblClasif)
        Me.panelEncabezado1.Controls.Add(Me.celdaIdMoneda)
        Me.panelEncabezado1.Controls.Add(Me.celdaIdPais)
        Me.panelEncabezado1.Controls.Add(Me.botonManucfactura)
        Me.panelEncabezado1.Controls.Add(Me.celdaManufactura)
        Me.panelEncabezado1.Controls.Add(Me.celdaDescripcionCorta)
        Me.panelEncabezado1.Controls.Add(Me.botonMoneda)
        Me.panelEncabezado1.Controls.Add(Me.celdaPaymentInfo)
        Me.panelEncabezado1.Controls.Add(Me.botonPais)
        Me.panelEncabezado1.Controls.Add(Me.botonRegimen)
        Me.panelEncabezado1.Controls.Add(Me.botonUsuario)
        Me.panelEncabezado1.Controls.Add(Me.etiquetaPaymentInfo)
        Me.panelEncabezado1.Controls.Add(Me.celdaMoneda)
        Me.panelEncabezado1.Controls.Add(Me.celdaPais)
        Me.panelEncabezado1.Controls.Add(Me.celdaRegimen)
        Me.panelEncabezado1.Controls.Add(Me.celdaUsuario)
        Me.panelEncabezado1.Controls.Add(Me.celdaTelefono)
        Me.panelEncabezado1.Controls.Add(Me.celdaNIT)
        Me.panelEncabezado1.Controls.Add(Me.celdaDireccion)
        Me.panelEncabezado1.Controls.Add(Me.celdaRazonSocial)
        Me.panelEncabezado1.Controls.Add(Me.celdaCodigo)
        Me.panelEncabezado1.Controls.Add(Me.etiquetaMoneda)
        Me.panelEncabezado1.Controls.Add(Me.etiquetaManufactura)
        Me.panelEncabezado1.Controls.Add(Me.etiquetaPais)
        Me.panelEncabezado1.Controls.Add(Me.etiquetaRegimen)
        Me.panelEncabezado1.Controls.Add(Me.etiquetaUsuario)
        Me.panelEncabezado1.Controls.Add(Me.etiquetaTelefono)
        Me.panelEncabezado1.Controls.Add(Me.etiquetaNIT)
        Me.panelEncabezado1.Controls.Add(Me.etiquetaDireccion)
        Me.panelEncabezado1.Controls.Add(Me.etiquetaRazonSocial)
        Me.panelEncabezado1.Controls.Add(Me.etiquetaCodigo)
        Me.panelEncabezado1.Controls.Add(Me.etiquetaDescripcionCorta)
        Me.panelEncabezado1.Dock = System.Windows.Forms.DockStyle.Top
        Me.panelEncabezado1.Location = New System.Drawing.Point(0, 0)
        Me.panelEncabezado1.Name = "panelEncabezado1"
        Me.panelEncabezado1.Size = New System.Drawing.Size(880, 362)
        Me.panelEncabezado1.TabIndex = 2
        '
        'rdCobro
        '
        Me.rdCobro.AutoSize = True
        Me.rdCobro.Location = New System.Drawing.Point(479, 210)
        Me.rdCobro.Name = "rdCobro"
        Me.rdCobro.Size = New System.Drawing.Size(40, 17)
        Me.rdCobro.TabIndex = 43
        Me.rdCobro.TabStop = True
        Me.rdCobro.Text = "AR"
        Me.rdCobro.UseVisualStyleBackColor = True
        '
        'rdDestino
        '
        Me.rdDestino.AutoSize = True
        Me.rdDestino.Location = New System.Drawing.Point(479, 187)
        Me.rdDestino.Name = "rdDestino"
        Me.rdDestino.Size = New System.Drawing.Size(78, 17)
        Me.rdDestino.TabIndex = 42
        Me.rdDestino.TabStop = True
        Me.rdDestino.Text = "Destination"
        Me.rdDestino.UseVisualStyleBackColor = True
        '
        'rdHilo
        '
        Me.rdHilo.AutoSize = True
        Me.rdHilo.Location = New System.Drawing.Point(479, 164)
        Me.rdHilo.Name = "rdHilo"
        Me.rdHilo.Size = New System.Drawing.Size(60, 17)
        Me.rdHilo.TabIndex = 41
        Me.rdHilo.TabStop = True
        Me.rdHilo.Text = "Invoice"
        Me.rdHilo.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.rdHilo.UseVisualStyleBackColor = True
        '
        'btnClasificacion
        '
        Me.btnClasificacion.Location = New System.Drawing.Point(253, 260)
        Me.btnClasificacion.Name = "btnClasificacion"
        Me.btnClasificacion.Size = New System.Drawing.Size(34, 23)
        Me.btnClasificacion.TabIndex = 40
        Me.btnClasificacion.Text = "..."
        Me.btnClasificacion.UseVisualStyleBackColor = True
        '
        'celdaClasificacion
        '
        Me.celdaClasificacion.Location = New System.Drawing.Point(101, 260)
        Me.celdaClasificacion.Name = "celdaClasificacion"
        Me.celdaClasificacion.ReadOnly = True
        Me.celdaClasificacion.Size = New System.Drawing.Size(146, 20)
        Me.celdaClasificacion.TabIndex = 39
        '
        'celdaIdClasificacion
        '
        Me.celdaIdClasificacion.Location = New System.Drawing.Point(293, 262)
        Me.celdaIdClasificacion.Name = "celdaIdClasificacion"
        Me.celdaIdClasificacion.Size = New System.Drawing.Size(24, 20)
        Me.celdaIdClasificacion.TabIndex = 38
        Me.celdaIdClasificacion.Visible = False
        '
        'lblClasif
        '
        Me.lblClasif.AutoSize = True
        Me.lblClasif.Location = New System.Drawing.Point(3, 265)
        Me.lblClasif.Name = "lblClasif"
        Me.lblClasif.Size = New System.Drawing.Size(81, 13)
        Me.lblClasif.TabIndex = 37
        Me.lblClasif.Text = "Invoice Country"
        '
        'celdaIdMoneda
        '
        Me.celdaIdMoneda.Location = New System.Drawing.Point(258, 235)
        Me.celdaIdMoneda.Name = "celdaIdMoneda"
        Me.celdaIdMoneda.Size = New System.Drawing.Size(24, 20)
        Me.celdaIdMoneda.TabIndex = 36
        Me.celdaIdMoneda.Text = "178"
        Me.celdaIdMoneda.Visible = False
        '
        'celdaIdPais
        '
        Me.celdaIdPais.Location = New System.Drawing.Point(430, 158)
        Me.celdaIdPais.Name = "celdaIdPais"
        Me.celdaIdPais.Size = New System.Drawing.Size(32, 20)
        Me.celdaIdPais.TabIndex = 35
        Me.celdaIdPais.Text = "0"
        Me.celdaIdPais.Visible = False
        '
        'botonManucfactura
        '
        Me.botonManucfactura.Location = New System.Drawing.Point(429, 177)
        Me.botonManucfactura.Name = "botonManucfactura"
        Me.botonManucfactura.Size = New System.Drawing.Size(32, 23)
        Me.botonManucfactura.TabIndex = 34
        Me.botonManucfactura.Text = "..."
        Me.botonManucfactura.UseVisualStyleBackColor = True
        '
        'celdaManufactura
        '
        Me.celdaManufactura.Location = New System.Drawing.Point(335, 181)
        Me.celdaManufactura.Name = "celdaManufactura"
        Me.celdaManufactura.Size = New System.Drawing.Size(80, 20)
        Me.celdaManufactura.TabIndex = 33
        '
        'celdaDescripcionCorta
        '
        Me.celdaDescripcionCorta.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.celdaDescripcionCorta.BackColor = System.Drawing.SystemColors.Info
        Me.celdaDescripcionCorta.Location = New System.Drawing.Point(354, 12)
        Me.celdaDescripcionCorta.Name = "celdaDescripcionCorta"
        Me.celdaDescripcionCorta.Size = New System.Drawing.Size(252, 20)
        Me.celdaDescripcionCorta.TabIndex = 32
        '
        'botonMoneda
        '
        Me.botonMoneda.Location = New System.Drawing.Point(220, 232)
        Me.botonMoneda.Name = "botonMoneda"
        Me.botonMoneda.Size = New System.Drawing.Size(32, 23)
        Me.botonMoneda.TabIndex = 30
        Me.botonMoneda.Text = "..."
        Me.botonMoneda.UseVisualStyleBackColor = True
        '
        'celdaPaymentInfo
        '
        Me.celdaPaymentInfo.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.celdaPaymentInfo.Location = New System.Drawing.Point(323, 262)
        Me.celdaPaymentInfo.Name = "celdaPaymentInfo"
        Me.celdaPaymentInfo.Size = New System.Drawing.Size(74, 20)
        Me.celdaPaymentInfo.TabIndex = 24
        '
        'botonPais
        '
        Me.botonPais.Location = New System.Drawing.Point(429, 202)
        Me.botonPais.Name = "botonPais"
        Me.botonPais.Size = New System.Drawing.Size(32, 23)
        Me.botonPais.TabIndex = 29
        Me.botonPais.Text = "..."
        Me.botonPais.UseVisualStyleBackColor = True
        '
        'botonRegimen
        '
        Me.botonRegimen.Location = New System.Drawing.Point(220, 178)
        Me.botonRegimen.Name = "botonRegimen"
        Me.botonRegimen.Size = New System.Drawing.Size(32, 23)
        Me.botonRegimen.TabIndex = 27
        Me.botonRegimen.Text = "..."
        Me.botonRegimen.UseVisualStyleBackColor = True
        '
        'botonUsuario
        '
        Me.botonUsuario.Location = New System.Drawing.Point(220, 155)
        Me.botonUsuario.Name = "botonUsuario"
        Me.botonUsuario.Size = New System.Drawing.Size(32, 23)
        Me.botonUsuario.TabIndex = 26
        Me.botonUsuario.Text = "..."
        Me.botonUsuario.UseVisualStyleBackColor = True
        '
        'etiquetaPaymentInfo
        '
        Me.etiquetaPaymentInfo.AutoSize = True
        Me.etiquetaPaymentInfo.Location = New System.Drawing.Point(323, 238)
        Me.etiquetaPaymentInfo.Name = "etiquetaPaymentInfo"
        Me.etiquetaPaymentInfo.Size = New System.Drawing.Size(73, 13)
        Me.etiquetaPaymentInfo.TabIndex = 25
        Me.etiquetaPaymentInfo.Text = "Payment Info*"
        '
        'celdaMoneda
        '
        Me.celdaMoneda.Location = New System.Drawing.Point(101, 234)
        Me.celdaMoneda.Name = "celdaMoneda"
        Me.celdaMoneda.Size = New System.Drawing.Size(113, 20)
        Me.celdaMoneda.TabIndex = 21
        '
        'celdaPais
        '
        Me.celdaPais.Location = New System.Drawing.Point(101, 204)
        Me.celdaPais.Name = "celdaPais"
        Me.celdaPais.Size = New System.Drawing.Size(314, 20)
        Me.celdaPais.TabIndex = 20
        '
        'celdaRegimen
        '
        Me.celdaRegimen.Location = New System.Drawing.Point(101, 180)
        Me.celdaRegimen.Name = "celdaRegimen"
        Me.celdaRegimen.Size = New System.Drawing.Size(113, 20)
        Me.celdaRegimen.TabIndex = 18
        '
        'celdaUsuario
        '
        Me.celdaUsuario.Location = New System.Drawing.Point(101, 157)
        Me.celdaUsuario.Name = "celdaUsuario"
        Me.celdaUsuario.Size = New System.Drawing.Size(113, 20)
        Me.celdaUsuario.TabIndex = 17
        '
        'celdaTelefono
        '
        Me.celdaTelefono.Location = New System.Drawing.Point(101, 131)
        Me.celdaTelefono.Name = "celdaTelefono"
        Me.celdaTelefono.Size = New System.Drawing.Size(151, 20)
        Me.celdaTelefono.TabIndex = 16
        '
        'celdaNIT
        '
        Me.celdaNIT.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.celdaNIT.Location = New System.Drawing.Point(354, 131)
        Me.celdaNIT.Name = "celdaNIT"
        Me.celdaNIT.Size = New System.Drawing.Size(44, 20)
        Me.celdaNIT.TabIndex = 15
        '
        'celdaDireccion
        '
        Me.celdaDireccion.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.celdaDireccion.Location = New System.Drawing.Point(101, 60)
        Me.celdaDireccion.Multiline = True
        Me.celdaDireccion.Name = "celdaDireccion"
        Me.celdaDireccion.Size = New System.Drawing.Size(506, 64)
        Me.celdaDireccion.TabIndex = 14
        '
        'celdaRazonSocial
        '
        Me.celdaRazonSocial.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.celdaRazonSocial.Location = New System.Drawing.Point(101, 38)
        Me.celdaRazonSocial.Name = "celdaRazonSocial"
        Me.celdaRazonSocial.Size = New System.Drawing.Size(506, 20)
        Me.celdaRazonSocial.TabIndex = 13
        '
        'celdaCodigo
        '
        Me.celdaCodigo.BackColor = System.Drawing.SystemColors.Info
        Me.celdaCodigo.Location = New System.Drawing.Point(101, 12)
        Me.celdaCodigo.Name = "celdaCodigo"
        Me.celdaCodigo.Size = New System.Drawing.Size(122, 20)
        Me.celdaCodigo.TabIndex = 12
        '
        'etiquetaMoneda
        '
        Me.etiquetaMoneda.AutoSize = True
        Me.etiquetaMoneda.Location = New System.Drawing.Point(3, 234)
        Me.etiquetaMoneda.Name = "etiquetaMoneda"
        Me.etiquetaMoneda.Size = New System.Drawing.Size(49, 13)
        Me.etiquetaMoneda.TabIndex = 11
        Me.etiquetaMoneda.Text = "Currency"
        '
        'etiquetaManufactura
        '
        Me.etiquetaManufactura.AutoSize = True
        Me.etiquetaManufactura.Location = New System.Drawing.Point(262, 187)
        Me.etiquetaManufactura.Name = "etiquetaManufactura"
        Me.etiquetaManufactura.Size = New System.Drawing.Size(67, 13)
        Me.etiquetaManufactura.TabIndex = 9
        Me.etiquetaManufactura.Text = "Manufacture"
        '
        'etiquetaPais
        '
        Me.etiquetaPais.AutoSize = True
        Me.etiquetaPais.Location = New System.Drawing.Point(3, 207)
        Me.etiquetaPais.Name = "etiquetaPais"
        Me.etiquetaPais.Size = New System.Drawing.Size(43, 13)
        Me.etiquetaPais.TabIndex = 8
        Me.etiquetaPais.Text = "Country"
        '
        'etiquetaRegimen
        '
        Me.etiquetaRegimen.AutoSize = True
        Me.etiquetaRegimen.Location = New System.Drawing.Point(3, 180)
        Me.etiquetaRegimen.Name = "etiquetaRegimen"
        Me.etiquetaRegimen.Size = New System.Drawing.Size(43, 13)
        Me.etiquetaRegimen.TabIndex = 7
        Me.etiquetaRegimen.Text = "Regime"
        '
        'etiquetaUsuario
        '
        Me.etiquetaUsuario.AutoSize = True
        Me.etiquetaUsuario.Location = New System.Drawing.Point(3, 157)
        Me.etiquetaUsuario.Name = "etiquetaUsuario"
        Me.etiquetaUsuario.Size = New System.Drawing.Size(29, 13)
        Me.etiquetaUsuario.TabIndex = 6
        Me.etiquetaUsuario.Text = "User"
        '
        'etiquetaTelefono
        '
        Me.etiquetaTelefono.AutoSize = True
        Me.etiquetaTelefono.Location = New System.Drawing.Point(3, 133)
        Me.etiquetaTelefono.Name = "etiquetaTelefono"
        Me.etiquetaTelefono.Size = New System.Drawing.Size(92, 13)
        Me.etiquetaTelefono.TabIndex = 5
        Me.etiquetaTelefono.Text = "Telephon Number"
        '
        'etiquetaNIT
        '
        Me.etiquetaNIT.AutoSize = True
        Me.etiquetaNIT.Location = New System.Drawing.Point(323, 133)
        Me.etiquetaNIT.Name = "etiquetaNIT"
        Me.etiquetaNIT.Size = New System.Drawing.Size(25, 13)
        Me.etiquetaNIT.TabIndex = 4
        Me.etiquetaNIT.Text = "NIT"
        '
        'etiquetaDireccion
        '
        Me.etiquetaDireccion.AutoSize = True
        Me.etiquetaDireccion.Location = New System.Drawing.Point(3, 63)
        Me.etiquetaDireccion.Name = "etiquetaDireccion"
        Me.etiquetaDireccion.Size = New System.Drawing.Size(49, 13)
        Me.etiquetaDireccion.TabIndex = 3
        Me.etiquetaDireccion.Text = "Direction"
        '
        'etiquetaRazonSocial
        '
        Me.etiquetaRazonSocial.AutoSize = True
        Me.etiquetaRazonSocial.Location = New System.Drawing.Point(3, 41)
        Me.etiquetaRazonSocial.Name = "etiquetaRazonSocial"
        Me.etiquetaRazonSocial.Size = New System.Drawing.Size(80, 13)
        Me.etiquetaRazonSocial.TabIndex = 2
        Me.etiquetaRazonSocial.Text = "Business Name"
        '
        'etiquetaCodigo
        '
        Me.etiquetaCodigo.AutoSize = True
        Me.etiquetaCodigo.Location = New System.Drawing.Point(3, 15)
        Me.etiquetaCodigo.Name = "etiquetaCodigo"
        Me.etiquetaCodigo.Size = New System.Drawing.Size(32, 13)
        Me.etiquetaCodigo.TabIndex = 0
        Me.etiquetaCodigo.Text = "Code"
        '
        'etiquetaDescripcionCorta
        '
        Me.etiquetaDescripcionCorta.AutoSize = True
        Me.etiquetaDescripcionCorta.Location = New System.Drawing.Point(260, 15)
        Me.etiquetaDescripcionCorta.Name = "etiquetaDescripcionCorta"
        Me.etiquetaDescripcionCorta.Size = New System.Drawing.Size(88, 13)
        Me.etiquetaDescripcionCorta.TabIndex = 1
        Me.etiquetaDescripcionCorta.Text = "Short Description"
        '
        'etiquetaEstado
        '
        Me.etiquetaEstado.AutoSize = True
        Me.etiquetaEstado.Location = New System.Drawing.Point(3, 295)
        Me.etiquetaEstado.Name = "etiquetaEstado"
        Me.etiquetaEstado.Size = New System.Drawing.Size(32, 13)
        Me.etiquetaEstado.TabIndex = 10
        Me.etiquetaEstado.Text = "State"
        '
        'celdaEstado
        '
        Me.celdaEstado.Location = New System.Drawing.Point(101, 293)
        Me.celdaEstado.Name = "celdaEstado"
        Me.celdaEstado.Size = New System.Drawing.Size(113, 20)
        Me.celdaEstado.TabIndex = 22
        '
        'botonEstado
        '
        Me.botonEstado.Location = New System.Drawing.Point(220, 290)
        Me.botonEstado.Name = "botonEstado"
        Me.botonEstado.Size = New System.Drawing.Size(32, 23)
        Me.botonEstado.TabIndex = 31
        Me.botonEstado.Text = "..."
        Me.botonEstado.UseVisualStyleBackColor = True
        '
        'BarraTitulo1
        '
        Me.BarraTitulo1.BackColor = System.Drawing.Color.WhiteSmoke
        Me.BarraTitulo1.Dock = System.Windows.Forms.DockStyle.Top
        Me.BarraTitulo1.Location = New System.Drawing.Point(0, 72)
        Me.BarraTitulo1.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.BarraTitulo1.Name = "BarraTitulo1"
        Me.BarraTitulo1.Size = New System.Drawing.Size(944, 30)
        Me.BarraTitulo1.TabIndex = 1
        '
        'Encabezado1
        '
        Me.Encabezado1.Dock = System.Windows.Forms.DockStyle.Top
        Me.Encabezado1.Location = New System.Drawing.Point(0, 0)
        Me.Encabezado1.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.Encabezado1.Name = "Encabezado1"
        Me.Encabezado1.Size = New System.Drawing.Size(944, 72)
        Me.Encabezado1.TabIndex = 0
        '
        'frmClientes
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(944, 648)
        Me.Controls.Add(Me.panelDocumento)
        Me.Controls.Add(Me.botonBuscar)
        Me.Controls.Add(Me.botonImprimir)
        Me.Controls.Add(Me.panelLista)
        Me.Controls.Add(Me.BarraTitulo1)
        Me.Controls.Add(Me.Encabezado1)
        Me.Name = "frmClientes"
        Me.Text = "frmClientes"
        Me.WindowState = System.Windows.Forms.FormWindowState.Maximized
        Me.panelLista.ResumeLayout(False)
        CType(Me.dgLista, System.ComponentModel.ISupportInitialize).EndInit()
        Me.panelDocumento.ResumeLayout(False)
        Me.panelDocumento.PerformLayout()
        Me.panelDireccion.ResumeLayout(False)
        CType(Me.dgDireccionCliente, System.ComponentModel.ISupportInitialize).EndInit()
        Me.panelBoton.ResumeLayout(False)
        Me.panelDetalle.ResumeLayout(False)
        Me.panelDgDetalle.ResumeLayout(False)
        CType(Me.dgDetalle, System.ComponentModel.ISupportInitialize).EndInit()
        Me.panelBotones2.ResumeLayout(False)
        Me.panelEncabezado.ResumeLayout(False)
        Me.panelEncabezado2.ResumeLayout(False)
        Me.panelEncabezado2.PerformLayout()
        Me.gbPosicionCuenta.ResumeLayout(False)
        Me.gbPosicionCuenta.PerformLayout()
        Me.panelEncabezado1.ResumeLayout(False)
        Me.panelEncabezado1.PerformLayout()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents Encabezado1 As KARIMs_SGI.encabezado
    Friend WithEvents BarraTitulo1 As KARIMs_SGI.BarraTitulo
    Friend WithEvents panelLista As System.Windows.Forms.Panel
    Friend WithEvents Panel2 As System.Windows.Forms.Panel
    Friend WithEvents dgLista As System.Windows.Forms.DataGridView
    Friend WithEvents botonImprimir As System.Windows.Forms.Button
    Friend WithEvents botonBuscar As System.Windows.Forms.Button
    Friend WithEvents panelDocumento As System.Windows.Forms.Panel
    Friend WithEvents panelEncabezado As System.Windows.Forms.Panel
    Friend WithEvents etiquetaDescripcionCorta As System.Windows.Forms.Label
    Friend WithEvents etiquetaCodigo As System.Windows.Forms.Label
    Friend WithEvents panelEncabezado2 As System.Windows.Forms.Panel
    Friend WithEvents panelEncabezado1 As System.Windows.Forms.Panel
    Friend WithEvents etiquetaRegimen As System.Windows.Forms.Label
    Friend WithEvents etiquetaUsuario As System.Windows.Forms.Label
    Friend WithEvents etiquetaTelefono As System.Windows.Forms.Label
    Friend WithEvents etiquetaNIT As System.Windows.Forms.Label
    Friend WithEvents etiquetaDireccion As System.Windows.Forms.Label
    Friend WithEvents etiquetaRazonSocial As System.Windows.Forms.Label
    Friend WithEvents celdaRazonSocial As System.Windows.Forms.TextBox
    Friend WithEvents celdaCodigo As System.Windows.Forms.TextBox
    Friend WithEvents etiquetaMoneda As System.Windows.Forms.Label
    Friend WithEvents etiquetaEstado As System.Windows.Forms.Label
    Friend WithEvents etiquetaManufactura As System.Windows.Forms.Label
    Friend WithEvents etiquetaPais As System.Windows.Forms.Label
    Friend WithEvents etiquetaPaymentInfo As System.Windows.Forms.Label
    Friend WithEvents celdaPaymentInfo As System.Windows.Forms.TextBox
    Friend WithEvents celdaEstado As System.Windows.Forms.TextBox
    Friend WithEvents celdaMoneda As System.Windows.Forms.TextBox
    Friend WithEvents celdaPais As System.Windows.Forms.TextBox
    Friend WithEvents celdaRegimen As System.Windows.Forms.TextBox
    Friend WithEvents celdaUsuario As System.Windows.Forms.TextBox
    Friend WithEvents celdaTelefono As System.Windows.Forms.TextBox
    Friend WithEvents celdaNIT As System.Windows.Forms.TextBox
    Friend WithEvents celdaDireccion As System.Windows.Forms.TextBox
    Friend WithEvents celdaDescripcionCorta As System.Windows.Forms.TextBox
    Friend WithEvents botonEstado As System.Windows.Forms.Button
    Friend WithEvents botonMoneda As System.Windows.Forms.Button
    Friend WithEvents botonPais As System.Windows.Forms.Button
    Friend WithEvents botonRegimen As System.Windows.Forms.Button
    Friend WithEvents botonUsuario As System.Windows.Forms.Button
    Friend WithEvents panelDetalle As System.Windows.Forms.Panel
    Friend WithEvents dgDetalle As System.Windows.Forms.DataGridView
    Friend WithEvents gbPosicionCuenta As System.Windows.Forms.GroupBox
    Friend WithEvents celdaDisponible As System.Windows.Forms.TextBox
    Friend WithEvents celdaSaldo As System.Windows.Forms.TextBox
    Friend WithEvents etiquetaDisponible As System.Windows.Forms.Label
    Friend WithEvents etiquetaSaldo As System.Windows.Forms.Label
    Friend WithEvents celdaCxC As System.Windows.Forms.TextBox
    Friend WithEvents botonCuentasxCobrar As System.Windows.Forms.Button
    Friend WithEvents celdaCuentasxCobrar As System.Windows.Forms.TextBox
    Friend WithEvents botonMetodoCosteo As System.Windows.Forms.Button
    Friend WithEvents botonFormaPago As System.Windows.Forms.Button
    Friend WithEvents celdaLimiteCredito As System.Windows.Forms.TextBox
    Friend WithEvents celdaMetodoCosteo As System.Windows.Forms.TextBox
    Friend WithEvents celdaPlazoCreditos As System.Windows.Forms.TextBox
    Friend WithEvents celdaDescuento As System.Windows.Forms.TextBox
    Friend WithEvents celdaFormaPago As System.Windows.Forms.TextBox
    Friend WithEvents etiquetaCuentasxCobrar As System.Windows.Forms.Label
    Friend WithEvents etiquetaLimiteCredito As System.Windows.Forms.Label
    Friend WithEvents etiquetaMetodoCosteo As System.Windows.Forms.Label
    Friend WithEvents etiquetaPlazoCredito As System.Windows.Forms.Label
    Friend WithEvents etiquetaDescuento As System.Windows.Forms.Label
    Friend WithEvents etiquetaFormaPago As System.Windows.Forms.Label
    Friend WithEvents panelBoton As System.Windows.Forms.Panel
    Friend WithEvents botonUp As System.Windows.Forms.Button
    Friend WithEvents dgDireccionCliente As System.Windows.Forms.DataGridView
    Friend WithEvents botonManucfactura As Button
    Friend WithEvents celdaManufactura As TextBox
    Friend WithEvents celdaIdPais As TextBox
    Friend WithEvents celdaIdMoneda As TextBox
    Friend WithEvents panelDireccion As Panel
    Friend WithEvents panelBotones2 As Panel
    Friend WithEvents botonAbajo As Button
    Friend WithEvents botonArriba As Button
    Friend WithEvents panelDgDetalle As Panel
    Friend WithEvents colCodigo As DataGridViewTextBoxColumn
    Friend WithEvents colNom As DataGridViewTextBoxColumn
    Friend WithEvents colDireccion As DataGridViewTextBoxColumn
    Friend WithEvents colCodigo1 As DataGridViewTextBoxColumn
    Friend WithEvents colEstadoD As DataGridViewTextBoxColumn
    Friend WithEvents colNombre As DataGridViewTextBoxColumn
    Friend WithEvents colPuesto As DataGridViewTextBoxColumn
    Friend WithEvents colCelular As DataGridViewTextBoxColumn
    Friend WithEvents colCorreoElectronico As DataGridViewTextBoxColumn
    Friend WithEvents colEstado As DataGridViewTextBoxColumn
    Friend WithEvents colCode As DataGridViewTextBoxColumn
    Friend WithEvents colEstatus As DataGridViewTextBoxColumn
    Friend WithEvents colEliminar As DataGridViewTextBoxColumn
    Friend WithEvents btnClasificacion As Button
    Friend WithEvents celdaClasificacion As TextBox
    Friend WithEvents celdaIdClasificacion As TextBox
    Friend WithEvents lblClasif As Label
    Friend WithEvents celdaIdCategoria As TextBox
    Friend WithEvents Label1 As Label
    Friend WithEvents celdaCategoria As TextBox
    Friend WithEvents botonCategoria As Button
    Friend WithEvents celdaGiro As TextBox
    Friend WithEvents etiquetaGiro As Label
    Friend WithEvents celdaRegistro As TextBox
    Friend WithEvents etiquetaRegistro As Label
    Friend WithEvents rdCobro As RadioButton
    Friend WithEvents rdDestino As RadioButton
    Friend WithEvents rdHilo As RadioButton
    Friend WithEvents CeldaNombreCta As TextBox
    Friend WithEvents botonCuentaNomenclatura As Button
    Friend WithEvents celdaNumeroCta As TextBox
    Friend WithEvents Label2 As Label
End Class
