﻿Public Class frmPresupuestoMes

#Region "Miembros"
    Dim strKey As String = STR_VACIO
    Dim logInsertar As Boolean = False
    Dim logConsultar As Boolean = False
    Dim logEditar As Boolean = False
    Dim LogBorrar As Boolean = False
    Dim intFilto As Integer = INT_CERO
    Const CAT_ORD As Integer = 777
    Dim cfun As New clsFunciones
    Dim Codigo As Integer = NO_FILA
    Dim costo As Integer = INT_CERO
#End Region

#Region "Propiedades"
    Public Property Key As String
        Get
            Return strKey
        End Get
        Set(value As String)
            strKey = value
        End Set
    End Property
#End Region

#Region "Procedimientos"

    Private Sub CalcularTotales()
        Dim i As Integer
        Dim enero As Double
        Dim febrero As Double
        Dim marzo As Double
        Dim abril As Double
        Dim mayo As Double
        Dim junio As Double
        Dim julio As Double
        Dim agosto As Double
        Dim septiembre As Double
        Dim octubre As Double
        Dim noviembre As Double
        Dim diciembre As Double
        Dim totales As Double

        Try

            For o As Integer = 0 To dgNomenclatura.Rows.Count - 1

                enero += dgNomenclatura.Rows(o).Cells("enero").Value
                febrero += dgNomenclatura.Rows(o).Cells("febrero").Value
                marzo += dgNomenclatura.Rows(o).Cells("marzo").Value
                abril += dgNomenclatura.Rows(o).Cells("abril").Value
                mayo += dgNomenclatura.Rows(o).Cells("mayo").Value
                junio += dgNomenclatura.Rows(o).Cells("junio").Value
                julio += dgNomenclatura.Rows(o).Cells("julio").Value
                agosto += dgNomenclatura.Rows(o).Cells("agosto").Value
                septiembre += dgNomenclatura.Rows(o).Cells("septiembre").Value
                octubre += dgNomenclatura.Rows(o).Cells("octubre").Value
                noviembre += dgNomenclatura.Rows(o).Cells("noviembre").Value
                diciembre += dgNomenclatura.Rows(o).Cells("diciembre").Value


            Next
            totales = enero + febrero + marzo + abril + mayo + junio + julio + agosto + septiembre + octubre + noviembre + diciembre
            celdaEnero.Text = FormatNumber(enero.ToString("###0.00"), 2)
            celdaFebrero.Text = FormatNumber(febrero.ToString("###0.00"), 2)
            celdaMarzo.Text = FormatNumber(marzo.ToString("###0.00"), 2)
            celdaAbril.Text = FormatNumber(abril.ToString("###0.00"), 2)
            celdaMayo.Text = FormatNumber(mayo.ToString("###0.00"), 2)
            celdaJunio.Text = FormatNumber(junio.ToString("###0.00"), 2)
            celdaJulio.Text = FormatNumber(julio.ToString("###0.00"), 2)
            celdaAgosto.Text = FormatNumber(agosto.ToString("###0.00"), 2)
            celdaSeptiembre.Text = FormatNumber(septiembre.ToString("###0.00"), 2)
            celdaOctubre.Text = FormatNumber(octubre.ToString("###0.00"), 2)
            celdaNoviembre.Text = FormatNumber(noviembre.ToString("###0.00"), 2)
            celdaDiciembre.Text = FormatNumber(diciembre.ToString("###0.00"), 2)
            txtTotal.Text = FormatNumber(totales.ToString("###0.00"), 2)

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Function calcularSuma()

        Dim a As Integer = cantNomenclatura()
        Dim enero(a) As Double
        Dim febrero(a) As Double
        Dim marzo(a) As Double
        Dim abril(a) As Double
        Dim mayo(a) As Double
        Dim junio(a) As Double
        Dim julio(a) As Double
        Dim agosto(a) As Double
        Dim septiembre(a) As Double
        Dim octubre(a) As Double
        Dim noviembre(a) As Double
        Dim diciembre(a) As Double
        Dim totales As Double = INT_CERO

        For i As Integer = 0 To dgNomenclatura.Rows.Count - 1

            enero(i) = dgNomenclatura.Rows(i).Cells("enero").Value
            febrero(i) = dgNomenclatura.Rows(i).Cells("febrero").Value
            marzo(i) = dgNomenclatura.Rows(i).Cells("marzo").Value
            abril(i) = dgNomenclatura.Rows(i).Cells("abril").Value
            mayo(i) = dgNomenclatura.Rows(i).Cells("mayo").Value
            junio(i) = dgNomenclatura.Rows(i).Cells("junio").Value
            julio(i) = dgNomenclatura.Rows(i).Cells("julio").Value
            agosto(i) = dgNomenclatura.Rows(i).Cells("agosto").Value
            septiembre(i) = dgNomenclatura.Rows(i).Cells("septiembre").Value
            octubre(i) = dgNomenclatura.Rows(i).Cells("octubre").Value
            noviembre(i) = dgNomenclatura.Rows(i).Cells("noviembre").Value
            diciembre(i) = dgNomenclatura.Rows(i).Cells("diciembre").Value

            totales = totales + enero(i) + febrero(i) + marzo(i) + abril(i) + mayo(i) + junio(i) + julio(i) + agosto(i) + septiembre(i) + octubre(i) + noviembre(i) + diciembre(i)

        Next

        Me.txtTotal.Text = totales

    End Function

    Private Function cantNomenclatura()
        Dim strsql As String = STR_VACIO
        Dim resultadoCount As Integer = INT_CERO
        Dim com As MySqlCommand
        Dim CON3 As MySqlConnection
        Try
            strsql = "SELECT COUNT(idCuenta) FROM {conta}.nomenclatura "

            strsql = Replace(strsql, "{conta}", cfun.ContaEmpresa())

            CON3 = New MySqlConnection(strConexion)
            CON3.Open()
            com = New MySqlCommand(strsql, CON3)
            resultadoCount = CDbl(com.ExecuteScalar)
            resultadoCount = resultadoCount
            CON3.Clone()
            CON3.Dispose()
            CON3 = Nothing
            System.GC.Collect()

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        Return resultadoCount

    End Function

    Private Function CargarFiltro(ByVal Opcion As Integer) As frmSeleccionar
        Dim frm As New frmSeleccionar
        Dim strTabla As String = STR_VACIO
        Try
            Select Case Opcion
                Case 1 'Filtrar por cliente'
                    strTabla = " (
                                    SELECT cli_codigo Code, cli_cliente Customer, IF(cli_tipo  = 0, 'Invoice',IF(cli_tipo=1,'Destination','AR')) type
                                    FROM Clientes
                                        WHERE cli_sisemp = " & Sesion.IdEmpresa & ") c"
                    frm.Campos = "c.Code,c.Customer,c.type "
                    frm.Tabla = strTabla
                    frm.Condicion = "c.Code>0"
                    frm.Limite = 20
                    frm.Titulo = "Select a customer"
                    frm.Filtro = "c.Customer"

                'Case 2 ' filtrar por centro de costos
                '    frm.Campos = "cost_num code ,cost_nombre Cost"
                '    frm.Tabla = cFunciones.ContaEmpresa & ".costos"
                '    frm.Condicion = "cost_num>0"
                '    frm.Titulo = "Select a cost center"
                '    frm.Filtro = "cost_nombre"
                Case 2 ' Filtrar Costos
                    frm.Campos = " cost_num code,cost_nombre Cost, pms_usuario,pms_id"
                    frm.Tabla = " " & cFunciones.ContaEmpresa & ".costos INNER JOIN Permisos p ON p.pms_id = cost_num AND p.pms_modulo = 505 AND p.pms_usuario = '" & Sesion.Usuario & "'"
                    frm.Condicion = " cost_num>0"
                    frm.Titulo = " Select By Department"
                    frm.Filtro = "cost_nombre"


                Case 3 ' filtrar por proveedor
                    frm.Campos = "pro_codigo Code ,pro_proveedor Mill"
                    frm.Tabla = " Proveedores "
                    frm.Condicion = "pro_sisemp = " & Sesion.IdEmpresa & " and pro_fabricante= 'Si'"
                    frm.Titulo = "Select a mill"
                    frm.Filtro = "pro_proveedor"
                    frm.Limite = 20
                Case 4 ' filtrar por programa
                    frm.Campos = "cat_num Code,cat_clave Program"
                    frm.Tabla = "Catalogos"
                    frm.Condicion = "cat_clase = 'Programa'"
                    frm.Titulo = "Select a program"
                    frm.Filtro = "cat_clave"
                Case 5 'fitrar por pais
                    frm.Campos = " cat_num Code ,cat_desc Source "
                    frm.Tabla = " Catalogos "
                    frm.Condicion = " cat_clase = 'Paises' "
                    frm.Titulo = "Select Source"
                    frm.Filtro = " cat_desc "

                Case 6 ' filtrar por articulo
                    frm.Campos = "art_Codigo Code ,art_DCorta Yarn"
                    frm.Tabla = " Articulos "
                    frm.Condicion = "art_sisemp = " & Sesion.IdEmpresa
                    frm.Titulo = "Select a Yarn"
                    frm.Filtro = "art_DCorta"
                    frm.Limite = 30
                Case 7 ' filtrar por codigo generico
                    frm.Campos = "art_Codigo Code ,art_DCorta Yarn"
                    frm.Tabla = " Articulos "
                    frm.Condicion = "art_sisemp = " & Sesion.IdEmpresa
                    frm.Titulo = "Select a Yarn"
                    frm.Filtro = "art_DCorta"
                    frm.Limite = 30
                Case 8

                    frm.Campos = " cb.BCta_Num Id,cb.BCta_Nom_Cue Bank_Account, cb.BCta_Num_Cue Account_Number "
                    frm.Tabla = "  Permisos p  LEFT JOIN CtasBcos cb ON cb.BCta_Sis_Emp = p.pms_empresa AND cb.BCta_Num = p.pms_id "
                    frm.Condicion = " p.pms_empresa = " & Sesion.IdEmpresa & " AND p.pms_usuario = '" & Sesion.Usuario & "' AND p.pms_modulo = 94  AND p.pms_codigo = 'ALL' "
                    frm.Titulo = " Select a account"
                    frm.Filtro = "cb.BCta_Nom_Cue"
                    frm.Limite = 30

                Case 9 'Filtrar por Empleado 
                    Dim strRemplazo As String = STR_VACIO
                    strRemplazo = "per_sisemp = {empresa} AND per_estado = 1"
                    strRemplazo = Replace(strRemplazo, "{empresa}", Sesion.IdEmpresa)
                    frm.Titulo = "Select a Responsible"
                    frm.Campos = " per_codigo Id, CONCAT(per_nombre1,' ',per_nombre2,' ',per_apellido1,' ',per_apellido2) Descripcion"
                    frm.Tabla = " Personal  "
                    frm.FiltroText = " Enter The Name Of The responsible To Filter "
                    frm.Filtro = "per_nombre1  "
                    frm.Ordenamiento = "per_nombre1, per_nombre2, per_apellido1"
                    frm.TipoOrdenamiento = ""
                    frm.Condicion = strRemplazo
                    frm.Limite = 30
                Case 10
                    frm.Campos = " i.id_Inventario ID , i.Codigo_Equipo Code, CONCAT( i.Marca ,' - ' , i.Serie  ) Descripcion  "
                    frm.Tabla = "  InventarioIT i "
                    frm.Condicion = " i.id_Empresa = " & Sesion.IdEmpresa
                    frm.Titulo = " Select a Computer "
                    frm.Filtro = "i.Codigo_Equipo"
                    frm.Limite = 30

            End Select
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try

        Return frm
    End Function

    Private Sub BloquearBotones(Optional ByVal logBloquear As Boolean = True)
        If logBloquear = True Then
            Encabezado1.botonBorrar.Enabled = False
            Encabezado1.botonGuardar.Enabled = False
            botonExportar.Enabled = False

        Else
            If LogBorrar = True Then
                Encabezado1.botonBorrar.Enabled = True
            Else
                Encabezado1.botonBorrar.Enabled = False
            End If
            Encabezado1.botonGuardar.Enabled = True
            botonExportar.Enabled = True

        End If
    End Sub
    Private Sub Accessos()
        Dim cAccesos As New clsAccesos
        Try
            If cAccesos.Accesos(strKey) = True Then
                logInsertar = cAccesos.Insertar
                logConsultar = cAccesos.Consultar
                logEditar = cAccesos.Editar
                LogBorrar = cAccesos.Borrar
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub
    Private Function SQLDetalle(codigo) As String
        Dim strsql As String = STR_VACIO
        strsql = "SELECT p.*, cn.NombreIngles Descripcion, c.cost_desc CCosto, c.cost_nombre NCosto FROM Presupuesto p 
                    LEFT JOIN {conta}.cuentas cta ON cta.id_cuenta = p.idDescripcion
                    LEFT JOIN {conta}.nomenclatura cn ON cn.idCuenta =cta.id_nomenclatura
                        LEFT JOIN {conta}.costos c ON c.cost_num = p.idCosto  WHERE idPresupuesto = " & codigo & " "

        strsql = Replace(strsql, "{conta}", cfun.ContaEmpresa())

        Return strsql
    End Function
    Private Function SQLLista(codigo, c) As String
        Dim strsql As String = STR_VACIO
        strsql = "SELECT p.*, CONCAT('Presupuesto de ',c.cost_nombre,' ',p.Anio) Descripcion, c.cost_desc CCosto, c.cost_nombre NCosto FROM Presupuesto p 
                    LEFT JOIN {conta}.nomenclatura cn ON cn.idCuenta = p.idDescripcion
                        LEFT JOIN {conta}.costos c ON c.cost_num = p.idCosto "

        strsql = Replace(strsql, "{conta}", cfun.ContaEmpresa())

        If Sesion.Usuario <> "dramirez" And Sesion.Usuario <> "edleon" And Sesion.Usuario <> "fmadriz" Then

            strsql &= " WHERE p.idCosto in(" & codigo & ") GROUP BY idPresupuesto "


        Else
            strsql &= " GROUP BY idPresupuesto"
        End If

        Return strsql
    End Function

    Private Function SQLLista2() As String
        Dim strsql As String = STR_VACIO
        strsql = "SELECT p.*, cn.NombreIngles Descripcion, c.cost_desc CCosto, c.cost_nombre NCosto FROM Presupuesto p 
                    LEFT JOIN {conta}.nomenclatura cn ON cn.idCuenta = p.idDescripcion
                        LEFT JOIN {conta}.costos c ON c.cost_num = p.idCosto "

        strsql = Replace(strsql, "{conta}", cfun.ContaEmpresa())

        If checkFecha.Checked = True Then

            strsql &= " WHERE (p.Fecha BETWEEN '{fechainicio}' AND '{fechafin}' AND p.idCosto = {id} ) GROUP BY idPresupuesto "

            strsql = Replace(strsql, "{fechainicio}", dtpInicio.Value.ToString(FORMATO_MYSQL))
            strsql = Replace(strsql, "{fechafin}", dtpFin.Value.ToString(FORMATO_MYSQL))
            strsql = Replace(strsql, "{id}", txtIdCCost2.Text)

        End If
        Return strsql
    End Function

    Private Function SQLLista3(idcosto, anio) As String
        Dim strsql As String = STR_VACIO
        Dim resultadoCount As Integer = INT_CERO
        Dim com As MySqlCommand
        Dim CON3 As MySqlConnection
        Try
            If anio > 2023 Then
                strsql = " SELECT COUNT(p.idPresupuesto)
                            FROM {conta}.nomenclatura cn
                            LEFT JOIN {conta}.cuentas c ON c.empresa = cn.idEmpresa AND c.id_nomenclatura = cn.idCuenta 
                            LEFT JOIN Presupuesto p ON p.idDescripcion = c.id_cuenta  AND p.idCosto = " & idcosto & " AND p.Anio = " & anio & "
                            WHERE cn.NivelCta = 3
                            ORDER BY cn.idCuenta;"
            Else
                strsql = "SELECT COUNT(p.idPresupuesto) "
                strsql &= "   FROM {conta}.nomenclatura cn LEFT JOIN Presupuesto p ON p.idDescripcion = cn.idCuenta AND p.idCosto = " & idcosto & " AND p.Anio = " & anio & " WHERE cn.NivelCta = 3 ORDER BY cn.idCuenta"
            End If

            strsql = Replace(strsql, "{conta}", cfun.ContaEmpresa())

            CON3 = New MySqlConnection(strConexion)
            CON3.Open()
            com = New MySqlCommand(strsql, CON3)
            resultadoCount = CDbl(com.ExecuteScalar)
            resultadoCount = resultadoCount
            CON3.Clone()
            CON3.Dispose()
            CON3 = Nothing
            System.GC.Collect()

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        Return resultadoCount
    End Function
    Private Function SQLNom(codigo, costo) As String
        Dim strsql As String = STR_VACIO
        strsql = "SELECT 
                    IFNULL(p.idPresupuesto,'') ID, IFNULL(p.Linea, '0') Linea, cn.idCuenta, IFNULL(p.idCosto,'') COSTO, 
                    cn.NombreIngles, IFNULL(c.id_cuenta,0) Cuenta , IFNULL(c.nombre,'') Nombre, 
                    IFNULL(p.Mes1, 0) Enero, IFNULL(p.Mes2, 0) Febrero, IFNULL(p.Mes3, 0) Marzo, 
                    IFNULL(p.Mes4, 0) Abril, IFNULL(p.Mes5, 0) Mayo, IFNULL(p.Mes6, 0) Junio, 
                    IFNULL(p.Mes7, 0) Julio, IFNULL(p.Mes8, 0) Agosto, IFNULL(p.Mes9, 0) Septiembre, 
                    IFNULL(p.Mes10, 0) Octubre, IFNULL(p.Mes11, 0) Noviembre, IFNULL(p.Mes12, 0) Diciembre "
        strsql &= " FROM {conta}.nomenclatura cn 
                    LEFT JOIN {conta}.cuentas c ON cn.idCuenta =c.id_nomenclatura 
                    LEFT JOIN Presupuesto p ON p.idDescripcion = c.id_cuenta AND p.idCosto = " & costo & " AND p.idPresupuesto = " & codigo & "  
                    WHERE cn.NivelCta = 3 AND LEFT(cn.idCuenta,1)>=4 
                    ORDER BY cn.idCuenta"

        strsql = Replace(strsql, "{conta}", cfun.ContaEmpresa())

        Return strsql

    End Function
    Private Function sqlId() As Integer
        Dim strsql As String = STR_VACIO
        Dim resultadoCount As Integer = INT_CERO
        Dim com As MySqlCommand
        Dim CON3 As MySqlConnection
        Try
            strsql = "SELECT IFNULL(MAX(idPresupuesto),0) + 1 idPresupuesto FROM Presupuesto"

            CON3 = New MySqlConnection(strConexion)
            CON3.Open()
            com = New MySqlCommand(strsql, CON3)
            resultadoCount = CDbl(com.ExecuteScalar)
            CON3.Clone()
            CON3.Dispose()
            CON3 = Nothing
            System.GC.Collect()

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        Return resultadoCount

    End Function

    Private Function sqlLinea() As String
        Dim strsql As String = STR_VACIO
        Dim resultadoCount As Integer = INT_CERO
        Dim com As MySqlCommand
        Dim CON3 As MySqlConnection
        Try
            strsql = "SELECT MAX(Linea) Linea FROM Presupuesto"

            CON3 = New MySqlConnection(strConexion)
            CON3.Open()
            com = New MySqlCommand(strsql, CON3)
            resultadoCount = CDbl(com.ExecuteScalar)
            resultadoCount = resultadoCount
            CON3.Clone()
            CON3.Dispose()
            CON3 = Nothing
            System.GC.Collect()

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        Return resultadoCount

    End Function

    Private Function FiltroId() As String
        Dim strsql As String = STR_VACIO

        strsql = "SELECT  cost_num code,cost_nombre Cost, pms_usuario,pms_id FROM  {conta}.costos INNER JOIN Permisos p ON p.pms_id = cost_num AND p.pms_modulo = 505 AND p.pms_usuario = '" & Sesion.Usuario & "' WHERE  cost_num>0 "


        strsql = Replace(strsql, "{conta}", cfun.ContaEmpresa())

        Return strsql
    End Function
    Private Function FiltroId2() As String
        Dim strsql As String = STR_VACIO
        Dim resultadoCount As Integer = INT_CERO
        Dim com As MySqlCommand
        Dim CON3 As MySqlConnection
        Try

            strsql = "SELECT  COUNT(pms_id) FROM  {conta}.costos INNER JOIN Permisos p ON p.pms_id = cost_num AND p.pms_modulo = 505 AND p.pms_usuario = '" & Sesion.Usuario & "' WHERE  cost_num>0 "


            strsql = Replace(strsql, "{conta}", cfun.ContaEmpresa())

            CON3 = New MySqlConnection(strConexion)
            CON3.Open()
            com = New MySqlCommand(strsql, CON3)
            resultadoCount = CDbl(com.ExecuteScalar)
            resultadoCount = resultadoCount
            CON3.Clone()
            CON3.Dispose()
            CON3 = Nothing
            System.GC.Collect()

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        Return resultadoCount
    End Function

    Private Function moneda() As String
        Dim strsql As String = STR_VACIO

        strsql = "SELECT * FROM Catalogos WHERE	cat_clase = 'Monedas' AND cat_num = 178 "

        Return strsql
    End Function

    Private Function ComprobarCampos()
        Dim bolComprobar As Boolean = True
        Try
            If Len(celdaIdMoneda.Text) < 0 Then
                bolComprobar = False
                Exit Function
            End If
            If Len(celdaTasa.Text) < 0 Then
                bolComprobar = False
                Exit Function
            End If
            If dgNomenclatura.Rows.Count < 1 Then
                bolComprobar = False
                Exit Function
            End If
            If txtCCosto.Text = "" Then
                bolComprobar = False
                Exit Function
            End If
            If dtpAnios.Text = "" Then
                bolComprobar = False
                Exit Function
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try

        Return bolComprobar
    End Function
    Private Sub reset()
        txtCCosto.Text = STR_VACIO
        txtidPresupuesto.Text = -1
        dgNomenclatura.Rows.Clear()

    End Sub

    Private Sub reset2(codigo)
        txtCCosto.Text = STR_VACIO
        txtidPresupuesto.Text = -1
        txtidPresupuesto.Enabled = False
        dgNomenclatura.Rows.Clear()

    End Sub

    Private Function Guardar() As Boolean
        Dim logResultado As Boolean = False
        Dim PRO As New Tablas.TPRESUPUESTO
        Dim cls As New clsContabilidad
        Dim intTipoNegocio As Integer = 0
        Dim strSQL2 As String = STR_VACIO
        Dim strSQL3 As String = STR_VACIO
        Dim COM3 As MySqlCommand
        Dim numero As Integer = INT_UNO

        strSQL3 = SQLLista3(txtidCCosto.Text, Int(txtAnio.Text))

        Try
            If ComprobarCampos() = True Then
                If Me.Tag = "Nuevo" Then
                    If strSQL3 = 0 Then
                        PRO.CONEXION = strConexion
                        PRO.IDEMPRESA = Sesion.IdEmpresa
                        PRO.TASA = celdaTasa.Text
                        PRO.IDMONEDA = celdaIdMoneda.Text
                        PRO.IDCOSTO = Int(txtidCCosto.Text)
                        PRO.ANIO = Int(dtpAnios.Text)
                        PRO.Fecha_NET = dtpFecha.Value
                        If Me.Tag = "Nuevo" Then
                            PRO.IDPRESUPUESTO = sqlId()
                        Else
                            PRO.IDPRESUPUESTO = txtidPresupuesto.Text
                        End If


                        For i As Integer = 0 To dgNomenclatura.Rows.Count - 1

                            PRO.MES1 = dgNomenclatura.Rows(i).Cells("enero").Value
                            PRO.MES2 = dgNomenclatura.Rows(i).Cells("febrero").Value
                            PRO.MES3 = dgNomenclatura.Rows(i).Cells("marzo").Value
                            PRO.MES4 = dgNomenclatura.Rows(i).Cells("abril").Value
                            PRO.MES5 = dgNomenclatura.Rows(i).Cells("mayo").Value
                            PRO.MES6 = dgNomenclatura.Rows(i).Cells("junio").Value
                            PRO.MES7 = dgNomenclatura.Rows(i).Cells("julio").Value
                            PRO.MES8 = dgNomenclatura.Rows(i).Cells("agosto").Value
                            PRO.MES9 = dgNomenclatura.Rows(i).Cells("septiembre").Value
                            PRO.MES10 = dgNomenclatura.Rows(i).Cells("octubre").Value
                            PRO.MES11 = dgNomenclatura.Rows(i).Cells("noviembre").Value
                            PRO.MES12 = dgNomenclatura.Rows(i).Cells("diciembre").Value
                            If Int(dtpAnios.Text) > 2023 Then
                                PRO.IDDESCRIPCION = dgNomenclatura.Rows(i).Cells("NumeroCuenta").Value
                            Else
                                PRO.IDDESCRIPCION = dgNomenclatura.Rows(i).Cells("nCuenta").Value
                            End If


                            PRO.LINEA = numero
                            numero = numero + 1
                            If PRO.PINSERT() = False Then
                                MsgBox(PRO.MERROR.ToString & "Could not save the document", MsgBoxStyle.Critical)
                            End If
                        Next
                        MsgBox("Data Saved Successfully", vbInformation)
                        reset()
                        MostrarLista()
                    ElseIf strSQL3 = -1 Then
                        MsgBox("No has elegido un centro de costos", vbAbort)
                    Else
                        MsgBox("This cost center already has a budget for " & dtpAnios.Text & ".", vbInformation)
                    End If
                Else
                    BorrarPresupuesto(txtidPresupuesto.Text)
                    PRO.CONEXION = strConexion
                    PRO.IDEMPRESA = Sesion.IdEmpresa
                    PRO.TASA = celdaTasa.Text
                    PRO.IDMONEDA = celdaIdMoneda.Text
                    PRO.IDCOSTO = Int(txtidCCosto.Text)
                    PRO.ANIO = Int(txtAnio.Text)
                    PRO.Fecha_NET = dtpFecha.Value
                    PRO.IDPRESUPUESTO = txtidPresupuesto.Text

                    For i As Integer = 0 To dgNomenclatura.Rows.Count - 1

                        PRO.MES1 = dgNomenclatura.Rows(i).Cells("enero").Value
                        PRO.MES2 = dgNomenclatura.Rows(i).Cells("febrero").Value
                        PRO.MES3 = dgNomenclatura.Rows(i).Cells("marzo").Value
                        PRO.MES4 = dgNomenclatura.Rows(i).Cells("abril").Value
                        PRO.MES5 = dgNomenclatura.Rows(i).Cells("mayo").Value
                        PRO.MES6 = dgNomenclatura.Rows(i).Cells("junio").Value
                        PRO.MES7 = dgNomenclatura.Rows(i).Cells("julio").Value
                        PRO.MES8 = dgNomenclatura.Rows(i).Cells("agosto").Value
                        PRO.MES9 = dgNomenclatura.Rows(i).Cells("septiembre").Value
                        PRO.MES10 = dgNomenclatura.Rows(i).Cells("octubre").Value
                        PRO.MES11 = dgNomenclatura.Rows(i).Cells("noviembre").Value
                        PRO.MES12 = dgNomenclatura.Rows(i).Cells("diciembre").Value
                        If Int(txtAnio.Text) > 2023 Then
                            PRO.IDDESCRIPCION = dgNomenclatura.Rows(i).Cells("NumeroCuenta").Value
                        Else
                            PRO.IDDESCRIPCION = dgNomenclatura.Rows(i).Cells("nCuenta").Value
                        End If
                        'PRO.LINEA = dgNomenclatura.Rows(i).Cells("Linea").Value
                        PRO.LINEA = numero
                        numero = numero + 1

                        'If PRO.PUPDATE() = False Then
                        If PRO.PINSERT() = False Then
                            MsgBox(PRO.MERROR.ToString & "Could not save the document", MsgBoxStyle.Critical)
                        End If
                    Next
                    MsgBox("Data Saved Successfully", vbInformation)
                    reset()
                    MostrarLista()
                End If
            Else
                MsgBox("You must fill all fields", vbCritical)
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        Return logResultado
    End Function

    Private Sub BorrarPresupuesto(ByVal num As Integer)

        Dim strSQL As String = STR_VACIO
        Dim COM As MySqlCommand
        Try
            MyCnn.CONECTAR = strConexion
            strSQL = "  DELETE FROM Presupuesto  WHERE idEmpresa = {empresa} AND idPresupuesto = {numero}  "
            strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
            strSQL = Replace(strSQL, "{numero}", num)
            COM = New MySqlCommand(strSQL, CON)
            COM.ExecuteNonQuery()
            COM = Nothing

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub
    Public Sub CargarLista()
        Dim strSQL As String = STR_VACIO
        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader
        Dim REA2 As MySqlDataReader
        Dim strFila As String
        Dim strSql2 As String = STR_VACIO
        Dim strSql3 As Integer = INT_CERO
        Dim c As Integer = INT_CERO
        c = (FiltroId2() - 1)
        Dim codigo(c) As Integer
        Dim numero1 As Integer = INT_CERO
        Dim numero2 As Integer = INT_CERO
        Dim costo(c) As Integer
        Dim caso As Integer = 2
        strSql2 = FiltroId()

        MyCnn.CONECTAR = strConexion
        COM = New MySqlCommand(strSql2, CON)
        REA2 = COM.ExecuteReader

        Do While REA2.Read
            codigo(numero1) = REA2.GetInt32("pms_id")
            costo(numero2) = REA2.GetInt32("code")
            numero1 = numero1 + 1
            numero2 = numero2 + 1
        Loop

        Dim codigolista As String = String.Join(",", codigo)

        Try
            strSQL = SQLLista(codigolista, c)
            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSQL, CON)
            REA = COM.ExecuteReader

            If REA.HasRows Then
                dgLista.Rows.Clear()

                Do While REA.Read
                    strFila = STR_VACIO
                    strFila = REA.GetInt32("idPresupuesto") & "|"
                    strFila &= REA.GetInt32("idCosto") & "|"
                    strFila &= REA.GetDateTime("Fecha") & "|"
                    strFila &= REA.GetString("NCosto") & "|"
                    strFila &= REA.GetString("Descripcion")

                    cFunciones.AgregarFila(dgLista, strFila)
                Loop
            End If

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub
    Public Sub CargarLista2(codigo, costo)
        Dim strSQL As String = STR_VACIO
        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader
        Dim strFila As String
        Dim total As Double = INT_CERO
        Try
            strSQL = SQLNom(codigo, costo)
            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSQL, CON)
            REA = COM.ExecuteReader

            If REA.HasRows Then
                dgNomenclatura.Rows.Clear()

                Do While REA.Read
                    strFila = STR_VACIO
                    strFila &= REA.GetString("idCuenta") & "|"
                    strFila &= REA.GetInt32("Linea") & "|"
                    strFila &= REA.GetString("NombreIngles") & "|"
                    strFila &= REA.GetString("Cuenta") & "|"
                    strFila &= REA.GetString("Nombre") & "|"
                    strFila &= REA.GetDouble("Enero").ToString(FORMATO_MONEDA) & "|"
                    strFila &= REA.GetDouble("Febrero").ToString(FORMATO_MONEDA) & "|"
                    strFila &= REA.GetDouble("Marzo").ToString(FORMATO_MONEDA) & "|"
                    strFila &= REA.GetDouble("Abril").ToString(FORMATO_MONEDA) & "|"
                    strFila &= REA.GetDouble("Mayo").ToString(FORMATO_MONEDA) & "|"
                    strFila &= REA.GetDouble("Junio").ToString(FORMATO_MONEDA) & "|"
                    strFila &= REA.GetDouble("Julio").ToString(FORMATO_MONEDA) & "|"
                    strFila &= REA.GetDouble("Agosto").ToString(FORMATO_MONEDA) & "|"
                    strFila &= REA.GetDouble("Septiembre").ToString(FORMATO_MONEDA) & "|"
                    strFila &= REA.GetDouble("Octubre").ToString(FORMATO_MONEDA) & "|"
                    strFila &= REA.GetDouble("Noviembre").ToString(FORMATO_MONEDA) & "|"
                    strFila &= REA.GetDouble("Diciembre").ToString(FORMATO_MONEDA)

                    total = total + (REA.GetDouble("Enero") + REA.GetDouble("Febrero") + REA.GetDouble("Marzo") + REA.GetDouble("Abril") + REA.GetDouble("Mayo") + REA.GetDouble("Junio") + REA.GetDouble("Julio") + REA.GetDouble("Agosto") + REA.GetDouble("Septiembre") + REA.GetDouble("Octubre") + REA.GetDouble("Noviembre") + REA.GetDouble("Diciembre"))

                    cFunciones.AgregarFila(dgNomenclatura, strFila)
                Loop
            End If

            txtTotal.Text = FormatNumber(total, 2)

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Public Sub CargarLista3()
        Dim strSQL As String = STR_VACIO
        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader
        Dim strFila As String
        Try
            strSQL = SQLLista2()
            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSQL, CON)
            REA = COM.ExecuteReader

            If REA.HasRows Then
                dgLista.Rows.Clear()

                Do While REA.Read
                    strFila = STR_VACIO
                    strFila = REA.GetInt32("idPresupuesto") & "|"
                    strFila &= REA.GetInt32("idCosto") & "|"
                    strFila &= REA.GetDateTime("Fecha") & "|"
                    strFila &= REA.GetString("NCosto") & "|"
                    strFila &= REA.GetString("Descripcion")

                    cFunciones.AgregarFila(dgLista, strFila)
                Loop
            Else
                dgLista.Rows.Clear()
            End If

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub
    Private Sub AgregarFila(ByRef Lista As DataGridView, ByVal strFila As String, ByVal IVA As Integer)

        Dim Celda As New DataGridViewTextBoxCell
        Dim Fila As New DataGridViewRow
        Dim strSQL As String = STR_VACIO
        Dim arrayFila() As String
        Dim i As Integer
        Try
            Lista.BackgroundColor = Color.White
            arrayFila = strFila.Split("|".ToCharArray)
            For i = 0 To arrayFila.Length - 1
                Celda = New DataGridViewTextBoxCell
                Celda.Value = arrayFila(i)

                If IVA = INT_UNO Then
                    If i = 1 Then
                        Celda.Style.BackColor = Color.Yellow
                    End If
                End If
                'Pendiente de Certificado de Origen
                Fila.Cells.Add(Celda)
            Next

            Lista.Rows.Add(Fila)
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try

    End Sub
    Private Sub MostrarLista(Optional ByVal logMostrar As Boolean = True, Optional logInsert As Boolean = False)
        Dim cfun As New clsFunciones
        If logMostrar = True Then
            'Ocultar Panel de Documento
            panelDocumento.Dock = DockStyle.None
            panelDocumento.Visible = False
            'Actualizar Titulo
            BarraTitulo1.CambiarTitulo("Budget")
            'Cargar Datos
            'cfun.CargarLista(dgLista, SQLLista, False)
            CargarLista()
            'Mostrar Panel Filtro
            panelLista.Visible = True
            panelLista.Dock = DockStyle.Fill
            dtpInicio.Value = DateSerial(Year(Date.Now), Month(Date.Now) - 1, 1)
            BloquearBotones()
            Me.Tag = ""
        Else
            'Ocultar Panel Filtro
            panelLista.Visible = False
            panelLista.Dock = DockStyle.None
            'Mostrar Panel de Documento
            panelDocumento.Dock = DockStyle.Fill
            panelDocumento.Visible = True
            'Verifica si se va a Crear un nuevo Documento o se va a modificar
            If logInsert = False Then
                BarraTitulo1.CambiarTitulo("Modify Record")
                Me.Tag = ""
                BloquearBotones(False)
                reset()
            Else
                BarraTitulo1.CambiarTitulo("New Record")
                Me.Tag = "Nuevo"
                BloquearBotones(False)

                reset()
            End If

            dgLista.DataSource = Nothing
        End If
    End Sub

    Public Sub Seleccionar(ByVal Codigo As Integer)
        Dim strSQL As String
        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader
        Try
            MyCnn.CONECTAR = strConexion
            strSQL = SQLDetalle(Codigo)
            COM = New MySqlCommand(strSQL, CON)
            REA = COM.ExecuteReader
            If REA.HasRows Then
                Do While REA.Read

                    txtidCCosto.Text = REA.GetInt32("idCosto")
                    txtidDescripcion.Text = REA.GetInt64("idDescripcion")
                    txtCCosto.Text = REA.GetString("NCosto")
                    txtidPresupuesto.Text = REA.GetInt32("idPresupuesto")
                    celdaTasa.Text = REA.GetDouble("Tasa")
                    If REA.GetInt32("idMoneda") = 178 Then
                        celdaMoneda.Text = "US$"
                        celdaIdMoneda.Text = REA.GetInt32("idMoneda")
                    ElseIf REA.GetInt32("idMoneda") = 177 Then
                        celdaMoneda.Text = "Q/"
                        celdaIdMoneda.Text = REA.GetInt32("idMoneda")
                    ElseIf REA.GetInt32("idMoneda") = 182 Then
                        If (Sesion.IdEmpresa = 18) Or (Sesion.IdEmpresa = 19) Then
                            celdaMoneda.Text = "C$"
                            celdaIdMoneda.Text = REA.GetInt32("idMoneda")
                        Else
                            celdaMoneda.Text = "LPS"
                            celdaIdMoneda.Text = REA.GetInt32("idMoneda")
                        End If
                    End If
                    txtAnio.Text = REA.GetString("Anio")

                Loop

            End If

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub



#End Region

#Region "Eventos"


    Private Sub frmPresupuestoMes_load(sender As Object, e As EventArgs) Handles MyBase.Load
        Accessos()
        MostrarLista()
    End Sub

    Private Sub dgLista_DoubleClick(sender As Object, e As EventArgs) Handles dgLista.DoubleClick


        If dgLista.Rows.Count = 0 Then Exit Sub
        Try
            Codigo = dgLista.SelectedCells(0).Value
            costo = dgLista.SelectedCells(1).Value
            MostrarLista(False)
            BloquearBotones(False)
            Me.Tag = "mod"
            Seleccionar(Codigo)
            CargarLista2(Codigo, costo)
            dtpAnios.Visible = False
            txtAnio.Visible = True
            txtAnio.Enabled = False
            CalcularTotales()

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try

    End Sub

    Private Sub dgLista_KeyDown(sender As Object, e As KeyEventArgs) Handles dgLista.KeyDown
        Try
            If e.KeyCode = Keys.F3 Then
                cfun.BuscarenLista(dgLista)
                e.Handled = True
                e.SuppressKeyPress = True
            ElseIf e.KeyCode = Keys.F7 Then
                Dim rpt As New clsReportes
                rpt.Historial(0, 0, 0, "Presupuesto", dgLista.SelectedCells(0).Value)

            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try

    End Sub

    Private Sub dgNomemclatura_KeyDown(sender As Object, e As KeyEventArgs) Handles dgNomenclatura.KeyDown
        Try
            If e.KeyCode = Keys.F3 Then
                cfun.BuscarenLista(dgNomenclatura)
                e.Handled = True
                e.SuppressKeyPress = True
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try

    End Sub

    Private Sub encabezado1_ClickNuevo(sender As Object, click As Boolean) Handles Encabezado1.ClickNuevo
        Dim cls As New clsContabilidad
        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader
        Dim strSQL As String = STR_VACIO
        MostrarLista(False, True)

        Dim codigo As String = INT_CERO
        Dim costo As Integer = INT_CERO


        reset2(codigo)
        costo = txtIdCCost2.Text
        Encabezado1.botonBorrar.Enabled = False
        dtpAnios.Visible = True
        dtpAnios.Format = DateTimePickerFormat.Custom
        dtpAnios.CustomFormat = "yyyy"
        dtpAnios.ShowUpDown = True
        txtAnio.Visible = False
        txtAnio.Text = Int(dtpAnios.Text)
        MyCnn.CONECTAR = strConexion
        strSQL = moneda()
        COM = New MySqlCommand(strSQL, CON)
        REA = COM.ExecuteReader
        Do While REA.Read
            celdaIdMoneda.Text = REA.GetInt32("cat_num")
            celdaMoneda.Text = REA.GetString("cat_clave")
            celdaTasa.Text = REA.GetString("cat_sist")
        Loop
        checkFecha.Checked = True
        CargarLista2(codigo, costo)
    End Sub

    Private Sub Encabezado1_ClickGuardar(sender As Object, click As Boolean) Handles Encabezado1.ClickGuardar
        If Guardar() = True Then
            MostrarLista(True)
        End If

    End Sub

    Private Sub Encabezado1_ClickBorrar(sender As Object, click As Boolean) Handles Encabezado1.ClickBorrar
        If LogBorrar = True Then
            Dim strSQL As String = STR_VACIO
            Dim COM As MySqlCommand
            If MsgBox("The document will be permanently deleted, do you want to continue?", vbQuestion + vbYesNo, "Question") = vbYes Then
                BorrarPresupuesto(txtidPresupuesto.Text)
                cfun.EscribirRegistro("Presupuesto", clsFunciones.AccEnum.acDelete, txtidPresupuesto.Text,  , dtpAnios.Text, , txtCCosto2.Text & " / " & "SE BORRÓ PRESUPUESTO...")
                MostrarLista()
            End If
        End If
    End Sub
    Private Sub Encabezado1_ClickCerrar(sender As Object, click As Boolean) Handles Encabezado1.ClickCerrar
        If panelDocumento.Visible = False Then
            Me.Close()
        Else
            MostrarLista()
        End If
    End Sub

    Private Sub btnCCosto_Click(sender As Object, e As EventArgs) Handles btnCCosto.Click
        Dim frm As New frmSeleccionar
        Dim caso As Integer = 2
        frm = CargarFiltro(caso)
        Try
            frm.Titulo = " Costs Center "
            frm.FiltroText = " Enter the flow to be filtered"
            frm.ShowDialog(Me)
            If frm.DialogResult = System.Windows.Forms.DialogResult.OK Then
                txtidCCosto.Text = frm.LLave
                txtCCosto.Text = frm.Dato

            End If

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub btnCCosto2_Click(sender As Object, e As EventArgs) Handles btnCCosto2.Click
        Dim frm As New frmSeleccionar
        Dim caso As Integer = 2
        frm = CargarFiltro(caso)
        Try
            frm.Titulo = " Costs Center "
            frm.FiltroText = " Enter the flow to be filtered"
            frm.ShowDialog(Me)
            If frm.DialogResult = System.Windows.Forms.DialogResult.OK Then
                txtIdCCost2.Text = frm.LLave
                txtCCosto2.Text = frm.Dato

            End If

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub botonMoneda_Click(sender As Object, e As EventArgs) Handles botonMoneda.Click
        Dim frm As New frmSeleccionar

        Try
            frm.Titulo = "Coin"
            frm.Campos = "c.cat_clave Moneda, c.cat_num ID, c.cat_sist"
            frm.Tabla = "Catalogos c"
            frm.FiltroText = " Enter the Coin To filter"
            frm.Filtro = " c.cat_clave "
            frm.Limite = 5
            frm.Ordenamiento = " c.cat_clave "
            frm.TipoOrdenamiento = ""
            frm.Condicion = "cat_clase='Monedas'"

            frm.ShowDialog(Me)

            If frm.DialogResult = System.Windows.Forms.DialogResult.OK Then
                celdaMoneda.Text = frm.LLave
                celdaIdMoneda.Text = frm.Dato
                celdaTasa.Text = frm.Dato2

            End If

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub dtpFecha_ValueChanged(sender As Object, e As EventArgs) Handles dtpFecha.ValueChanged
        If celdaTasa.Text > 1 Then
            celdaTasa.Text = cFunciones.TasaSegunFecha(dtpFecha.Value.ToString(FORMATO_MYSQL))
        End If
    End Sub

    Private Sub btnFilter_Click(sender As Object, e As EventArgs) Handles btnFilter.Click

        Dim logCancelar As Boolean

        If CDate(dtpInicio.Value) > CDate(dtpFin.Value) Then
            MsgBox("The start date may not exceed the final date", vbExclamation, "Notice")
            logCancelar = True
        End If
        If Not (logCancelar) Then
            'strOrigen = PrepararListado

            'Procedimiento para cargar panel dgLista
            CargarLista3()
        End If
    End Sub

    Private Sub dgNomenclatura_CellEndEdit(sender As Object, e As DataGridViewCellEventArgs) Handles dgNomenclatura.CellEndEdit
        CalcularTotales()

    End Sub

    Private Sub dtpAnios_TextChanged(sender As Object, e As EventArgs) Handles dtpAnios.TextChanged
        txtAnio.Text = Int(dtpAnios.Text)
    End Sub

    Private Sub botonExportar_Click(sender As Object, e As EventArgs) Handles botonExportar.Click
        Dim creporte As New clsReportes
        creporte.ExportarBudget(Codigo, costo, txtCCosto.Text, txtAnio.Text)
    End Sub


#End Region

End Class