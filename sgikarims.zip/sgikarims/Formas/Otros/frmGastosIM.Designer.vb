﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmGastosIM
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.paneldocumento = New System.Windows.Forms.Panel()
        Me.celdadescripcion = New System.Windows.Forms.TextBox()
        Me.lbldescripcion = New System.Windows.Forms.Label()
        Me.celdacodigo = New System.Windows.Forms.TextBox()
        Me.lblcatnum = New System.Windows.Forms.Label()
        Me.panelLista = New System.Windows.Forms.Panel()
        Me.dglista = New System.Windows.Forms.DataGridView()
        Me.Número = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Descripción = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.BarraTitulo1 = New KARIMs_SGI.BarraTitulo()
        Me.Encabezado1 = New KARIMs_SGI.encabezado()
        Me.paneldocumento.SuspendLayout()
        Me.panelLista.SuspendLayout()
        CType(Me.dglista, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'paneldocumento
        '
        Me.paneldocumento.Controls.Add(Me.celdadescripcion)
        Me.paneldocumento.Controls.Add(Me.lbldescripcion)
        Me.paneldocumento.Controls.Add(Me.celdacodigo)
        Me.paneldocumento.Controls.Add(Me.lblcatnum)
        Me.paneldocumento.Location = New System.Drawing.Point(45, 391)
        Me.paneldocumento.Margin = New System.Windows.Forms.Padding(4)
        Me.paneldocumento.Name = "paneldocumento"
        Me.paneldocumento.Size = New System.Drawing.Size(538, 180)
        Me.paneldocumento.TabIndex = 6
        '
        'celdadescripcion
        '
        Me.celdadescripcion.Location = New System.Drawing.Point(144, 89)
        Me.celdadescripcion.Margin = New System.Windows.Forms.Padding(4)
        Me.celdadescripcion.Name = "celdadescripcion"
        Me.celdadescripcion.Size = New System.Drawing.Size(209, 22)
        Me.celdadescripcion.TabIndex = 20
        '
        'lbldescripcion
        '
        Me.lbldescripcion.AutoSize = True
        Me.lbldescripcion.Location = New System.Drawing.Point(47, 94)
        Me.lbldescripcion.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.lbldescripcion.Name = "lbldescripcion"
        Me.lbldescripcion.Size = New System.Drawing.Size(82, 17)
        Me.lbldescripcion.TabIndex = 19
        Me.lbldescripcion.Text = "Descripción"
        '
        'celdacodigo
        '
        Me.celdacodigo.Enabled = False
        Me.celdacodigo.Location = New System.Drawing.Point(144, 36)
        Me.celdacodigo.Margin = New System.Windows.Forms.Padding(4)
        Me.celdacodigo.Name = "celdacodigo"
        Me.celdacodigo.ReadOnly = True
        Me.celdacodigo.Size = New System.Drawing.Size(67, 22)
        Me.celdacodigo.TabIndex = 6
        '
        'lblcatnum
        '
        Me.lblcatnum.AutoSize = True
        Me.lblcatnum.Location = New System.Drawing.Point(47, 36)
        Me.lblcatnum.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.lblcatnum.Name = "lblcatnum"
        Me.lblcatnum.Size = New System.Drawing.Size(52, 17)
        Me.lblcatnum.TabIndex = 1
        Me.lblcatnum.Text = "Código"
        '
        'panelLista
        '
        Me.panelLista.Controls.Add(Me.dglista)
        Me.panelLista.Location = New System.Drawing.Point(45, 174)
        Me.panelLista.Margin = New System.Windows.Forms.Padding(4)
        Me.panelLista.Name = "panelLista"
        Me.panelLista.Size = New System.Drawing.Size(264, 134)
        Me.panelLista.TabIndex = 7
        '
        'dglista
        '
        Me.dglista.AllowUserToAddRows = False
        Me.dglista.AllowUserToDeleteRows = False
        Me.dglista.BackgroundColor = System.Drawing.SystemColors.Control
        Me.dglista.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dglista.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.Número, Me.Descripción})
        Me.dglista.Dock = System.Windows.Forms.DockStyle.Fill
        Me.dglista.Location = New System.Drawing.Point(0, 0)
        Me.dglista.Margin = New System.Windows.Forms.Padding(4)
        Me.dglista.MultiSelect = False
        Me.dglista.Name = "dglista"
        Me.dglista.ReadOnly = True
        Me.dglista.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.dglista.Size = New System.Drawing.Size(264, 134)
        Me.dglista.TabIndex = 0
        '
        'Número
        '
        Me.Número.HeaderText = "No"
        Me.Número.Name = "Número"
        Me.Número.ReadOnly = True
        '
        'Descripción
        '
        Me.Descripción.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.Descripción.HeaderText = "Descripción"
        Me.Descripción.Name = "Descripción"
        Me.Descripción.ReadOnly = True
        Me.Descripción.Width = 111
        '
        'BarraTitulo1
        '
        Me.BarraTitulo1.BackColor = System.Drawing.Color.WhiteSmoke
        Me.BarraTitulo1.Dock = System.Windows.Forms.DockStyle.Top
        Me.BarraTitulo1.Location = New System.Drawing.Point(0, 89)
        Me.BarraTitulo1.Margin = New System.Windows.Forms.Padding(5)
        Me.BarraTitulo1.Name = "BarraTitulo1"
        Me.BarraTitulo1.Size = New System.Drawing.Size(651, 37)
        Me.BarraTitulo1.TabIndex = 9
        '
        'Encabezado1
        '
        Me.Encabezado1.Dock = System.Windows.Forms.DockStyle.Top
        Me.Encabezado1.Location = New System.Drawing.Point(0, 0)
        Me.Encabezado1.Margin = New System.Windows.Forms.Padding(5)
        Me.Encabezado1.Name = "Encabezado1"
        Me.Encabezado1.Size = New System.Drawing.Size(651, 89)
        Me.Encabezado1.TabIndex = 8
        '
        'frmGastosIM
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(651, 608)
        Me.Controls.Add(Me.paneldocumento)
        Me.Controls.Add(Me.panelLista)
        Me.Controls.Add(Me.BarraTitulo1)
        Me.Controls.Add(Me.Encabezado1)
        Me.Name = "frmGastosIM"
        Me.Text = "frmGastosFN"
        Me.paneldocumento.ResumeLayout(False)
        Me.paneldocumento.PerformLayout()
        Me.panelLista.ResumeLayout(False)
        CType(Me.dglista, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents paneldocumento As Panel
    Friend WithEvents celdadescripcion As TextBox
    Friend WithEvents lbldescripcion As Label
    Friend WithEvents celdacodigo As TextBox
    Friend WithEvents lblcatnum As Label
    Friend WithEvents panelLista As Panel
    Friend WithEvents dglista As DataGridView
    Friend WithEvents BarraTitulo1 As BarraTitulo
    Friend WithEvents Encabezado1 As encabezado
    Friend WithEvents Número As DataGridViewTextBoxColumn
    Friend WithEvents Descripción As DataGridViewTextBoxColumn
End Class
