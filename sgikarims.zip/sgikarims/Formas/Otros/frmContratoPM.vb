﻿Public Class frmContrato_PM_

#Region "Miembros"
    Dim strKey As String = STR_VACIO
    Dim logInsertar As Boolean = False
    Dim logConsultar As Boolean = False
    Dim logEditar As Boolean = False
    Dim LogBorrar As Boolean = False
    Const CAT_ORD As Integer = 777
    Dim cfun As New clsFunciones
    Private Const FLD_TASA As Byte = 12
#End Region

#Region "Propiedades"
    Public Property Key As String
        Get
            Return strKey
        End Get
        Set(value As String)
            strKey = value
        End Set
    End Property
#End Region

#Region "Procedimientos"

    Private Sub BloquearBotones(Optional ByVal logBloquear As Boolean = True)
        If logBloquear = True Then
            Encabezado1.botonBorrar.Enabled = False
            Encabezado1.botonGuardar.Enabled = False

        Else
            Encabezado1.botonBorrar.Enabled = True
            Encabezado1.botonGuardar.Enabled = True

        End If
    End Sub

    Private Sub Accessos()
        Dim cAccesos As New clsAccesos
        Try
            If cAccesos.Accesos(strKey) = True Then
                logInsertar = cAccesos.Insertar
                logConsultar = cAccesos.Consultar
                logEditar = cAccesos.Editar
                LogBorrar = cAccesos.Borrar
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub reset()

        celdaAño.Text = NO_FILA
        celdaNumero.Text = NO_FILA
        celdaNombre.Text = STR_VACIO
        celdaDescripcion.Text = STR_VACIO
        celdaNIT.Text = NO_FILA
        celdaMoneda.Text = "$/"
        celdaTasa.Text = NO_FILA
        celdaNContrato.Text = NO_FILA
        celdaLinea.Text = STR_VACIO
        celdaCanti.Text = NO_FILA
        celdaTot.Text = NO_FILA

    End Sub

    Private Sub MostrarLista(Optional ByVal logMostrar As Boolean = True, Optional logInsert As Boolean = False)
         Dim cfun As New clsFunciones
        If logMostrar = True Then
            'Ocultar Panel de Documento
            panelDocumento.Dock = DockStyle.None
            panelDocumento.Visible = False
            'Actualizar Titulo
            BarraTitulo1.CambiarTitulo("Ordenes de Compra")
            'Cargar Datos
            'cfun.CargarLista(dgLista, SQLLista, False)
            'Mostrar Panel Filtro
            panelLista.Visible = True
            panelLista.Dock = DockStyle.Fill
            BloquearBotones()
            Me.Tag = ""
        Else
            'Ocultar Panel Filtro
            panelLista.Visible = False
            panelLista.Dock = DockStyle.None
            'Mostrar Panel de Documento
            panelDocumento.Dock = DockStyle.Fill
            panelDocumento.Visible = True
            'Verifica si se va a Crear un nuevo Documento o se va a modificar
            If logInsert = False Then
                BarraTitulo1.CambiarTitulo("Modificar Registro")
                Me.Tag = ""
                BloquearBotones(False)

            Else
                BarraTitulo1.CambiarTitulo("Nuevo Registro")
                Me.Tag = "Nuevo"
                BloquearBotones(False)

                reset()
            End If

            dgLista.DataSource = Nothing
        End If
    End Sub

#End Region

#Region "Eventos VB.NET"

    Private Sub frmContratoPM_FormClosing(sender As Object, e As FormClosingEventArgs) Handles Me.FormClosing
        frmSPrincipal.BarraDeTareas1.QuitarFormulario(strKey)
    End Sub

    Private Sub frmContratoPM_load(sender As Object, e As EventArgs) Handles MyBase.Load
        dtpFinal.Value = Today
        dtpInicio.Value = dtpFinal.Value.AddMonths(NO_FILA)
        Accessos()
        MostrarLista()
    End Sub

    Private Sub Encabezado1_ClickCerrar(sender As Object, click As Boolean) Handles Encabezado1.ClickCerrar
        If panelDocumento.Visible = False Then
            Me.Close()
        Else
            MostrarLista()
        End If
    End Sub

    Private Sub encabezado1_ClickNuevo(sender As Object, click As Boolean) Handles Encabezado1.ClickNuevo
        MostrarLista(False, True)
    End Sub

    Private Sub botonNombre_Click(sender As Object, e As EventArgs) Handles botonNombre.Click

        Dim frm As New frmSeleccionar

        'Datospara mostrar en pantalla
        frm.Titulo = "Name Company"
        frm.FiltroText = "Enter the Name Company to Filter "

        'Datos de Base para Llenar Grid
        frm.Campos = "HDoc_Doc_Num Code, HDoc_Emp_Nom CompanyName, HDoc_Emp_Dir Direction, HDoc_Emp_NIT NIT"
        frm.Tabla = "Dcmtos_HDR"
        frm.Condicion = "HDoc_Sis_Emp=" & Sesion.IdEmpresa
        frm.Limite = 20
        frm.Ordenamiento = "HDoc_Doc_Num < 0"
        frm.Filtro = "HDoc_Emp_Nom"

        'Mostrar formulario
        frm.ShowDialog(Me)
        If frm.DialogResult = System.Windows.Forms.DialogResult.OK Then
            'Captura de datos seleccionados
            celdaIDNombre.Text = frm.LLave
            celdaNombre.Text = frm.Dato
            celdaDescripcion.Text = frm.Dato2
            celdaNIT.Text = frm.Dato3

        End If

    End Sub

    Private Sub botonMoneda_Click(sender As Object, e As EventArgs) Handles botonMoneda.Click

        Dim frm As New frmSeleccionar

        Try
            frm.Titulo = "Una Moneda"
            frm.Campos = " cat_clave Moneda"
            frm.Tabla = " Catalogos"
            frm.FiltroText = " Ingrese el nombre de la moneda para filtrar"
            frm.Filtro = " cat_clave "
            frm.Condicion = "cat_clase = 'monedas'"

            frm.ShowDialog(Me)
            If frm.DialogResult = System.Windows.Forms.DialogResult.OK Then
                celdaMoneda.Text = frm.LLave
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try

    End Sub
    #End Region

End Class