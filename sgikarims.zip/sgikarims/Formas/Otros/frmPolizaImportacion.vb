﻿Public Class frmPolizaImportacion
#Region "Miembros"
    Dim strKey As String = STR_VACIO
    Dim logInsertar As Boolean = False
    Dim logConsultar As Boolean = False
    Dim logEditar As Boolean = False
    Dim LogBorrar As Boolean = False
    Const CAT_ORD As Integer = 777
    Dim cfun As New clsFunciones
    Dim intTipoDoc As Integer
    Dim SDoc As New frmSubDocumentos
    Dim Tbl_Documentos As String = "Dcmtos_HDR"
    Dim dblTCambio As String

#End Region

#Region "Propiedades"
    Public Property Key As String
        Get
            Return strKey
        End Get
        Set(value As String)
            strKey = value
        End Set
    End Property

    Public Property TasaCambio As String
        Get
            Return dblTCambio
        End Get
        Set(value As String)
            dblTCambio = value
        End Set
    End Property
#End Region

#Region "Procedimientos"
    Private Sub BloquearBotones(Optional ByVal logBloquear As Boolean = True)
        If logBloquear = True Then
            Encabezado1.botonBorrar.Enabled = False
            Encabezado1.botonGuardar.Enabled = False
            botonCorregir.Enabled = False
            botonMas.Enabled = False
            botonMenos.Enabled = False
        Else
            Encabezado1.botonBorrar.Enabled = True
            Encabezado1.botonGuardar.Enabled = True
            botonCorregir.Enabled = True
            botonMas.Enabled = True
            botonMenos.Enabled = True
        End If

    End Sub

    Private Sub Accesos()
        Dim cAcesos As New clsAccesos

        Try
            If cAcesos.Accesos(strKey) = True Then
                logInsertar = cAcesos.Insertar
                logEditar = cAcesos.Editar
                LogBorrar = cAcesos.Borrar
                logConsultar = cAcesos.Consultar

            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub MostrarLista(Optional ByVal logMostrar As Boolean = True, Optional logInsert As Boolean = False)
        If logMostrar = True Then
            panelLista.Visible = True
            panelLista.Dock = DockStyle.Fill
            panelDocumento.Visible = False
            panelDocumento.Dock = DockStyle.None
            BarraTitulo1.CambiarTitulo("Import Policy")
            BloquearBotones()

            '   dtpInicial.Value = DateSerial(Year(Date.Now), Month(Date.Now) - 1, 30)
            '   dtpFinal.Value = DateSerial(Year(Date.Now), Month(Date.Now) + 1, vbEmpty)

            ListaPrincipal()

        Else
            panelLista.Visible = False
            panelLista.Dock = DockStyle.None
            panelDocumento.Visible = True
            panelDocumento.Dock = DockStyle.Fill
            BloquearBotones(False)
        End If

        If Sesion.idGiro = 1 Then
            lblCertificado.Visible = True
            celdaCertificado.Visible = True
            botonGuardarCetificado.Visible = True
        End If

    End Sub

    Private Function SqlListaPrincipal()
        Dim strSql As String = STR_VACIO

        strSql = "SELECT l1.Cod_, l1.Numero, l1.Fecha, l1.nombre , l1.Clase , l1.NO,l1.Anio , l1.Estado ,l1.Selectivo ,l1.Regimen ,(l1.Soporte - l1.Linea) Soporte "
        strSql &= " FROM ( "
        strSql &= "     SELECT HDoc_RF2_Cod Cod_, HDoc_Doc_Num Numero, HDoc_Doc_Fec Fecha, HDoc_Emp_Nom nombre, CONCAT(ELT(COALESCE(HDoc_DR1_Cat,0)+1,'Importación','Devolución','Transf.'), CAST(IF(HDoc_DR1_Cat=2, IFNULL(CONCAT(' / ',HDoc_RF2_Txt),''),'') AS CHAR),' / ', CAST(COALESCE(dd.ADoc_Dta_Chr,'') AS CHAR)) Clase, HDoc_DR1_Num NO, HDoc_Doc_Ano Anio, HDoc_Doc_Status Estado, IFNULL(ds.ADoc_Dta_Chr,'') Selectivo, IFNULL(dr.ADoc_Dta_Chr,'') Regimen, IFNULL(( "
        strSql &= "         SELECT COUNT(*) "
        strSql &= "             FROM Dcmtos_DTL_Pro "
        strSql &= "                 WHERE PDoc_Sis_Emp=HDoc_Sis_Emp AND PDoc_Par_Cat=HDoc_Doc_Cat AND PDoc_Par_Ano=HDoc_Doc_Ano AND PDoc_Par_Num=HDoc_Doc_Num AND PDoc_Chi_Cat=44 "
        strSql &= "                     LIMIT 1),0) Soporte, IFNULL(( "
        strSql &= "                         SELECT COUNT(*)"
        strSql &= "                             FROM Dcmtos_DTL d  "
        strSql &= "                          WHERE d.DDoc_Sis_Emp = HDoc_Sis_Emp AND d.DDoc_Doc_Cat = HDoc_Doc_Cat AND d.DDoc_Doc_Ano = HDoc_Doc_Ano AND d.DDoc_Doc_Num = HDoc_Doc_Num "
        strSql &= "                      LIMIT 1),0) Linea"
        strSql &= "                   FROM Dcmtos_HDR "
        strSql &= "               LEFT JOIN Dcmtos_ACC dd ON dd.ADoc_Sis_Emp = HDoc_Sis_Emp AND dd.ADoc_Doc_Cat = HDoc_Doc_Cat AND dd.ADoc_Doc_Ano = HDoc_Doc_Ano AND dd.ADoc_Doc_Num = HDoc_Doc_Num AND dd.ADoc_Doc_Sub = 'Doc_PolImp' AND dd.ADoc_Doc_Lin = '01' "
        strSql &= "            LEFT JOIN Dcmtos_ACC dr ON dr.ADoc_Sis_Emp = HDoc_Sis_Emp AND dr.ADoc_Doc_Cat = HDoc_Doc_Cat AND dr.ADoc_Doc_Ano = HDoc_Doc_Ano AND dr.ADoc_Doc_Num = HDoc_Doc_Num AND dr.ADoc_Doc_Sub = 'Doc_PolImp' AND dr.ADoc_Doc_Lin = '22' "
        strSql &= "        LEFT JOIN Dcmtos_ACC ds ON ds.ADoc_Sis_Emp = HDoc_Sis_Emp AND ds.ADoc_Doc_Cat = HDoc_Doc_Cat AND ds.ADoc_Doc_Ano = HDoc_Doc_Ano AND ds.ADoc_Doc_Num = HDoc_Doc_Num AND ds.ADoc_Doc_Sub = 'Doc_PolImp' AND ds.ADoc_Doc_Lin = '23' "
        strSql &= " WHERE HDoc_Sis_Emp={empresa} AND HDoc_Doc_Cat=180 "
        If checkFechas.Checked = True Then
            strSql &= " And (HDoc_Doc_Fec BETWEEN '{inicial}' AND '{final}') "

        End If

        If Not celdaProveedorE.Text = vbNullString Then
            strSql &= " And (HDoc_Emp_Nom  = '{buscar}')"
            strSql = Replace(strSql, "{buscar}", celdaProveedorE.Text)
        End If
        strSql &= " GROUP BY HDoc_Sis_Emp, HDoc_Doc_Cat, HDoc_Doc_Ano, HDoc_Doc_Num "
        strSql &= " ORDER BY HDoc_Doc_Ano DESC, HDoc_Doc_Num DESC)l1 "

        strSql = Replace(strSql, "{empresa}", Sesion.IdEmpresa)
        strSql = Replace(strSql, "{inicial}", dtpInicial.Value.ToString(FORMATO_MYSQL))
        strSql = Replace(strSql, "{final}", dtpFinal.Value.ToString(FORMATO_MYSQL))

        Return strSql

    End Function


    Private Function SqlDatosProveedor(ByVal numero As Integer, ByVal fecha As String)
        Dim strSql As String = STR_VACIO

        strSql = " SELECT HDoc_DR1_Dbl, HDoc_RF2_Cod Cod_, HDoc_Sis_Emp Empresa, HDOc_Doc_Cat Catalogo, HDoc_Doc_Ano Anio, HDoc_Doc_Num Numero, HDoc_Doc_Fec Fecha, HDoc_Emp_Cod Id_Provee, HDoc_Emp_Nom Proveedor, HDoc_Emp_Dir Direccion, HDoc_Emp_Nit NIT, HDoc_Doc_Mon Moneda, HDoc_Doc_TC Tasa, HDoc_RF1_Dbl Flete, HDoc_RF2_Dbl Seguro, HDoc_DR1_Num Factura, HDoc_DR2_Num Referencia_1, HDoc_RF2_Txt Referencia_2, HDoc_Usuario Usuario, HDoc_Doc_Status Estado, HDoc_RF1_Txt Costeo, HDoc_DR1_Cat tipo,  /*0 = Póliza, 1 = Devolución */ cat_clave "
        strSql &= "     FROM Dcmtos_HDR "
        strSql &= "         LEFT JOIN Proveedores ON pro_codigo = HDoc_Emp_Cod AND pro_sisemp = {empresa} "
        strSql &= "     INNER JOIN Catalogos ON HDoc_Doc_Mon = cat_num "
        strSql &= " WHERE HDoc_Doc_Cat = 180 AND HDoc_Sis_Emp = {empresa} AND HDoc_Doc_Num = {numero} AND HDoc_Doc_Fec = '{fecha}' "

        strSql = Replace(strSql, "{empresa}", Sesion.IdEmpresa)
        strSql = Replace(strSql, "{numero}", numero)
        strSql = Replace(strSql, "{fecha}", fecha)

        Return strSql

    End Function

    Private Function SqlDatosPoliza(ByVal numero As Integer, ByVal anio As Integer)
        Dim strSql As String = STR_VACIO

        strSql = " SELECT DISTINCT HDoc_Doc_Cat Cat, HDoc_Doc_Ano Anio, HDoc_Doc_Num Numero, HDoc_Doc_Fec Fecha, HDoc_Usuario Usuario, HDoc_DR1_Num Factura "
        strSql &= "     FROM Dcmtos_DTL_Pro a "
        strSql &= "         INNER JOIN Dcmtos_HDR b ON a.PDoc_Sis_Emp = b.HDoc_Sis_Emp AND a.PDoc_Par_Cat = b.HDoc_Doc_Cat AND a.PDoc_Par_Ano = b.HDoc_Doc_Ano AND a.PDoc_Par_Num = b.HDoc_Doc_Num "
        strSql &= "     WHERE a.PDoc_Sis_Emp = {empresa} AND a.PDoc_Chi_Cat = 180 AND a.PDoc_Chi_Ano = {anio} AND a.PDoc_Chi_Num = {numero} "

        strSql = Replace(strSql, "{empresa}", Sesion.IdEmpresa)
        strSql = Replace(strSql, "{numero}", numero)
        strSql = Replace(strSql, "{anio}", anio)

        Return strSql

    End Function

    Private Function SqlCargarDetalle(ByVal numero As Integer, ByVal anio As Integer)
        Dim strSql As String = STR_VACIO

        strSql = " SELECT DDoc_Sis_Emp Empresa, DDoc_Doc_Cat catalogo, DDoc_Doc_Ano Anio, DDoc_Doc_Num Numero, DDoc_Doc_Lin Linea, DDoc_Prd_Cod Codigo, DDoc_Prd_Des Descripcion, cat_clave Medida, DDoc_Prd_PUQ PrecioU, DDoc_Prd_DSP DescuentoPor, DDoc_Prd_DSQ DescuentoMon, DDoc_Prd_QTY Cantidad, DDoc_Prd_PNr PNR, DDoc_Prd_UM UnidadMed, IFNULL(EDoc_Lin_Frac,'') Inciso, IFNULL(EDoc_Lin_Desc,'') DescLinea,IFNULL(DDoc_RF3_Dbl,0) ValorAduanal ,IFNULL(EDoc_Lin_Otros,0) Otros , IFNULL(EDoc_Lin_Gross, 0) Brutos, IFNULL(EDoc_Lin_Net,0) Netos, IFNULL(EDoc_Lin_Fob,0) Fob, IFNULL(EDoc_Lin_Freight,0) Flete, IFNULL(EDoc_Lin_Insurance,0) Seguro, IFNULL(EDoc_Lin_Cargos,0) Cargos, IFNULL(EDoc_Lin_Cif,0) CIF, IFNULL(EDoc_Lin_DAI,0) DAI, IFNULL(EDoc_Lin_IVA,0) IVA, DDoc_RF1_Num Numero, ROUND(DDoc_Prd_NET * DDoc_Prd_Qty++0.0000000001,2) Lin_Subtotal, inv_costo Costo, ROUND(inv_costo * DDoc_Prd_Qty+0.0000000001,2) Total, IFNULL(EDoc_Lin_Cif,0) CIF, IFNULL(BDoc_Box_QTY,0) Bultos, p.PDoc_Par_Cat catDatos, p.PDoc_Par_Ano anoDatos, p.PDoc_Par_Num NumDatos, p.PDoc_Par_Lin LinDatos, inv_prodlote lote "
        strSql &= "     FROM Dcmtos_DTL "
        strSql &= "         LEFT JOIN Dcmtos_DEC ON EDoc_Sis_Emp = DDoc_Sis_Emp AND EDoc_Doc_Cat = DDoc_Doc_Cat AND EDoc_Doc_Ano = DDoc_Doc_Ano AND EDoc_Doc_Num = DDoc_Doc_Num AND EDoc_Doc_Lin = DDoc_Doc_Lin "
        strSql &= "             LEFT JOIN Catalogos ON cat_num = DDoc_Prd_UM AND cat_clase = 'Medidas' "
        strSql &= "                  LEFT JOIN Inventarios ON inv_numero = DDoc_Prd_Cod AND inv_sisemp = {empresa} "
        strSql &= "                     LEFT JOIN Dcmtos_DTL_Box ON BDoc_Sis_Emp = DDoc_Sis_Emp AND BDoc_Doc_Cat = DDoc_Doc_Cat AND BDoc_Doc_Ano = DDoc_Doc_Ano AND BDoc_Doc_Num = DDoc_Doc_Num AND BDoc_Doc_Lin = DDoc_Doc_Lin "
        strSql &= "                  LEFT JOIN Dcmtos_DTL_Pro p ON p.PDoc_Sis_Emp = DDoc_Sis_Emp AND p.PDoc_Chi_Cat = DDoc_Doc_Cat and  p.PDoc_Chi_Ano = DDoc_Doc_Ano and p.PDoc_Chi_Num= DDoc_Doc_Num and p.PDoc_Chi_Lin = DDoc_Doc_Lin"
        strSql &= "         WHERE DDoc_Doc_Cat = 180 AND DDoc_Sis_Emp = {empresa} AND DDoc_Doc_Ano = {anio} AND DDoc_Doc_Num = {numero} "
        strSql &= " ORDER BY DDoc_Doc_Lin "

        strSql = Replace(strSql, "{empresa}", Sesion.IdEmpresa)
        strSql = Replace(strSql, "{anio}", anio)
        strSql = Replace(strSql, "{numero}", numero)

        Return strSql

    End Function

    Private Function SqlDatos(ByVal numero As Integer, ByVal anio As Integer)
        Dim strSql As String = STR_VACIO

        strSql = " SELECT cat_clave, cat_desc, ( "
        strSql &= "     SELECT COUNT(*) "
        strSql &= "         FROM Dcmtos_ACC "
        strSql &= "             WHERE ADoc_Sis_Emp = {empresa} AND ADoc_Doc_Cat = 180 AND ADoc_Doc_Ano = {anio} AND ADoc_Doc_Num = {numero} AND ADoc_Doc_Sub = cat_clave) Cantidad "
        strSql &= "         FROM Catalogos "
        strSql &= "     WHERE cat_clase = 'SubDcmtos' AND cat_sist = 'Doc_ODesImp' "
        strSql &= " ORDER BY cat_clave "

        strSql = Replace(strSql, "{empresa}", Sesion.IdEmpresa)
        strSql = Replace(strSql, "{anio}", anio)
        strSql = Replace(strSql, "{numero}", numero)

        Return strSql

    End Function

    Private Function SqlNuevosDatosPoliza(ByVal codigo As Integer)
        Dim strSql As String = STR_VACIO

        strSql = " SELECT DISTINCT HDoc_Sis_Emp, HDoc_Doc_Cat Catalogo, HDoc_Doc_Ano Anio, HDoc_Doc_Num Numero, HDoc_Doc_Fec Fecha, COALESCE(HDoc_DR1_Num,'') Referencia, HDoc_Usuario Operador, HDoc_RF1_Dbl Total "
        strSql &= "     FROM Dcmtos_HDR a "
        strSql &= "         LEFT JOIN Dcmtos_DTL b ON a.HDoc_Sis_Emp = b.DDoc_Sis_Emp AND a.HDoc_Doc_Cat = b.DDoc_Doc_Cat AND a.HDoc_Doc_Ano = b.DDoc_Doc_Ano AND a.HDoc_Doc_Num = b.DDoc_Doc_Num "
        strSql &= "             WHERE HDoc_Sis_Emp = {empresa} AND (HDoc_Doc_Cat = 55) AND COALESCE(HDoc_DR1_Cat,0) = {tipoDoc} AND (HDoc_Emp_Cod = {codigo}) AND HDoc_Doc_Status = 1 AND (COALESCE(( "
        strSql &= "                 SELECT SUM(c.PDoc_QTY_Pro) "
        strSql &= "             FROM Dcmtos_DTL_Pro c "
        strSql &= "         WHERE c.PDoc_Sis_Emp = b.DDoc_Sis_Emp AND c.PDoc_Par_Cat = b.DDoc_Doc_Cat AND c.PDoc_Par_Ano = b.DDoc_Doc_Ano AND c.PDoc_Par_Num = b.DDoc_Doc_Num AND c.PDoc_Par_Lin = b.DDoc_Doc_Lin), 0) < b.DDoc_Prd_QTY) "
        strSql &= " ORDER BY HDoc_Doc_Ano DESC, HDoc_Doc_Num DESC "

        strSql = Replace(strSql, "{empresa}", Sesion.IdEmpresa)
        strSql = Replace(strSql, "{codigo}", codigo)
        strSql = Replace(strSql, "{tipoDoc}", intTipoDoc)

        Return strSql

    End Function

    Private Function SqlNuevoDetalle(ByVal codigo As Integer, ByVal strTemp As String)
        Dim strSql As String = STR_VACIO

        strSql = " SELECT HDoc_Sis_Emp,HDoc_Doc_Cat, HDoc_Doc_Num, HDoc_Doc_Ano, b.DDoc_Doc_Lin LinDPoliza, b.DDoc_Prd_Cod Codigo, b.DDoc_Prd_Des Descripcion, b.DDoc_Prd_PUQ PrecioU, art_DCorta DescCorta, cat_clave Medida, inv_costo PrecioUni, d.inv_partnum Parte, d.inv_UMcmpra UMedida, d.inv_UMfac, IFNULL(d.inv_prodlote,'') lote, SUM(b.DDoc_Prd_QTY) - COALESCE(( "
        strSql &= "     SELECT SUM(c.PDoc_QTY_Pro) "
        strSql &= "         FROM Dcmtos_DTL_Pro c "
        strSql &= "             WHERE b.DDoc_Sis_Emp = c.PDoc_Sis_Emp AND b.DDoc_Doc_Cat = c.PDoc_Par_Cat AND b.DDoc_Doc_Ano = c.PDoc_Par_Ano AND b.DDoc_Doc_Num = c.PDoc_Par_Num AND b.DDoc_Doc_Lin = c.PDoc_Par_Lin),0) Cantidad "
        strSql &= "                 FROM Dcmtos_HDR a "
        strSql &= "                     INNER JOIN Dcmtos_DTL b ON a.HDoc_Sis_Emp = b.DDoc_Sis_Emp AND a.HDoc_Doc_Cat = b.DDoc_Doc_Cat AND a.HDoc_Doc_Ano = b.DDoc_Doc_Ano AND a.HDoc_Doc_Num = b.DDoc_Doc_Num "
        strSql &= "                         INNER JOIN Inventarios d ON b.DDoc_Prd_Cod = d.inv_numero AND b.DDoc_Sis_Emp = d.inv_sisemp "
        strSql &= "                     INNER JOIN Articulos e ON d.inv_artcodigo = e.art_codigo AND d.inv_sisemp = e.art_sisemp "
        strSql &= "                 INNER JOIN Catalogos f ON d.inv_UMcmpra = f.cat_num "
        strSql &= "             WHERE HDoc_Doc_Cat = 55 AND HDoc_Sis_Emp = {empresa} AND HDoc_Emp_Cod = {codigo} {Condicion}) "
        strSql &= "         GROUP BY HDoc_Sis_Emp, HDoc_Doc_Cat, HDoc_Doc_Ano, HDoc_Doc_Num, DDoc_Doc_Lin "
        strSql &= " HAVING Cantidad > 0 "

        strSql = Replace(strSql, "{empresa}", Sesion.IdEmpresa)
        strSql = Replace(strSql, "{codigo}", codigo)
        strSql = Replace(strSql, "{Condicion}", strTemp)

        Return strSql

    End Function

    Private Function SqlCargarReferencia(ByVal numero As Integer, ByVal anio As Integer)
        Dim strSql As String = STR_VACIO

        strSql = " SELECT HDoc_DR1_Num Factura, HDoc_DR2_Num Ref_1, HDoc_RF2_Txt Ref_2, HDoc_RF1_Txt Costeo, HDoc_RF1_Dbl Flete, HDoc_RF2_Dbl Seguro "
        strSql &= "     FROM Dcmtos_HDR "
        strSql &= " WHERE HDoc_Sis_Emp = {empresa} AND HDoc_Doc_Cat = 55 AND HDoc_Doc_Ano = {anio} AND HDoc_Doc_Num = {numero} "

        strSql = Replace(strSql, "{empresa}", Sesion.IdEmpresa)
        strSql = Replace(strSql, "{anio}", anio)
        strSql = Replace(strSql, "{numero}", numero)

        Return strSql

    End Function

    Private Function SqlAgregaAlDetalle(ByVal numero As Integer)
        Dim strSql As String = STR_VACIO

        strSql = " SELECT a.art_frac Inciso, a.art_desc Descripcion "
        strSql &= "     FROM Inventarios i "
        strSql &= "         INNER JOIN Articulos a ON a.art_codigo = i.inv_artcodigo "
        strSql &= "     WHERE i.inv_activo = 0 AND i.inv_numero={numero} "

        strSql = Replace(strSql, "{numero}", numero)

        Return strSql

    End Function


    Public Sub ListaPrincipal()
        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader
        Dim strSQL As String = STR_VACIO
        Dim strFila As String

        strSQL = SqlListaPrincipal()

        Try

            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSQL, CON)
            REA = COM.ExecuteReader

            dgLista.Rows.Clear()

            If REA.HasRows Then
                Do While REA.Read
                    strFila = REA.GetInt32("Numero") & "|"
                    strFila &= REA.GetDateTime("Fecha") & "|"
                    strFila &= REA.GetString("nombre") & "|"
                    strFila &= REA.GetString("Clase") & "|"
                    strFila &= REA.GetString("NO") & "|"
                    strFila &= REA.GetInt32("Anio") & "|"
                    strFila &= REA.GetInt32("Estado") & "|"
                    strFila &= REA.GetString("Selectivo") & "|"
                    strFila &= REA.GetString("Regimen") & "|"
                    strFila &= REA.GetInt32("Soporte") & "|"
                    strFila &= REA.GetString("Cod_") & "|"
                    strFila &= 0

                    cFunciones.AgregarFila(dgLista, strFila)
                    dgLista.Columns(11).HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleCenter
                Loop
                ColorearListaPrincipal()
            End If
            If Sesion.IdEmpresa = 16 Then
                dgLista.Columns(10).Visible = True
            Else
                dgLista.Columns(10).Visible = False
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try

    End Sub

    Public Structure ArrayRegimen
        Public texto As String
        Public numero As Integer
    End Structure


    Public Sub ColorearListaPrincipal()

        Dim i As Integer
        Dim j As Integer = NO_FILA
        Dim k As Integer
        Dim verde As Integer
        Dim rojo As Integer
        Dim blanco As Integer
        Dim EtiquetaV As String
        Dim EtiquetaR As String
        Dim EtiquetaB As String
        Dim Regimen As String = STR_VACIO
        Dim ImprimirRegimen As String = STR_VACIO
        Dim intCuentaRegimen As Integer = 0
        Dim strDato As String
        Dim logVerificarR As Boolean = False

        Dim ARegimen() As ArrayRegimen


        verde = 0
        rojo = 0
        blanco = 0

        etiquetaVerde.Text = "Green"
        etiquetaRojo.Text = "Red"
        etiquetaBlanco.Text = "N/A"
        etiquetaTiposRegimen.Text = ""
        Try
            For i = 0 To dgLista.Rows.Count - 1

                ' Esta Parte Colorea el datagrid
                '*******************************************

                If dgLista.Rows(i).Cells("colEstado").Value = vbEmpty Then
                    dgLista.Item(0, i).Style.BackColor = Color.Red
                    dgLista.Item(0, i).Style.ForeColor = Color.White
                ElseIf dgLista.Rows(i).Cells("colSoporte").Value <> vbEmpty Then
                    dgLista.Item(0, i).Style.BackColor = Color.Orange
                End If

                If dgLista.Rows(i).Cells("colSelectivoLista").Value = "VERDE" Then
                    dgLista.Item(11, i).Style.BackColor = Color.YellowGreen
                    dgLista.Item(11, i).Style.ForeColor = Color.YellowGreen
                    dgLista.Rows(i).Cells("colSelectivo").Value = "V"
                    verde = verde + 1
                ElseIf dgLista.Rows(i).Cells("colSelectivoLista").Value = "ROJO" Then
                    dgLista.Item(11, i).Style.BackColor = Color.Red
                    dgLista.Item(11, i).Style.ForeColor = Color.White
                    dgLista.Rows(i).Cells("colSelectivo").Value = "R"
                    rojo = rojo + 1
                Else
                    dgLista.Rows(i).Cells("colSelectivo").Value = "X"
                    dgLista.Item(11, i).Style.BackColor = Color.White
                    blanco = blanco + 1
                End If
                '**********************************************
                'Esta parte cuenta los Regimenes
                strDato = Trim(dgLista.Rows(i).Cells("colRegimen").Value)
                If strDato.Length > 3 Then
                    strDato = "OTROS"
                ElseIf strDato = vbNullString Then
                    strDato = "N/A"
                End If

                'If Not dgLista.Rows(i).Cells("colRegimen").Value = Regimen Then
                If j = NO_FILA Then
                    j = 0
                    ReDim ARegimen(j)
                    ARegimen(j).texto = strDato
                    ARegimen(j).numero = 1

                    ImprimirRegimen = STR_VACIO

                Else
                    logVerificarR = False
                    For k = 0 To UBound(ARegimen)
                        If ARegimen(k).texto = strDato Then
                            ARegimen(k).texto = strDato
                            ARegimen(k).numero = ARegimen(k).numero + 1
                            logVerificarR = True
                            Exit For
                        End If
                    Next
                    If logVerificarR = False Then
                        j = j + 1
                        ReDim Preserve ARegimen(j)
                        ARegimen(j).texto = strDato
                        ARegimen(j).numero = 1

                    End If

                End If
                ' Else

            Next
            For k = 0 To UBound(ARegimen)
                ImprimirRegimen = ImprimirRegimen & IIf(ImprimirRegimen = STR_VACIO, STR_VACIO, vbCrLf) & ARegimen(k).texto & " - " & ARegimen(k).numero
            Next


            EtiquetaV = "Green" & " (" & verde & ")"
            EtiquetaR = "Red" & " (" & rojo & ")"
            EtiquetaB = "N/A" & " (" & blanco & ")"

            etiquetaVerde.Text = EtiquetaV
            etiquetaRojo.Text = EtiquetaR
            etiquetaBlanco.Text = EtiquetaB
            etiquetaTiposRegimen.Text = ImprimirRegimen


        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try

    End Sub

    Public Sub DatosProveedor(ByVal numero As Integer, ByVal fecha As String)
        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader
        Dim strSQL As String = STR_VACIO

        strSQL = SqlDatosProveedor(numero, fecha)

        Try
            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSQL, CON)
            REA = COM.ExecuteReader

            If REA.HasRows Then

                Do While REA.Read
                    'celdas ocultas
                    celdaCatalogo.Text = REA.GetInt32("Catalogo")
                    celdaEmpresa.Text = REA.GetInt32("Empresa")
                    celdaDate.Text = REA.GetDateTime("Fecha").ToString(FORMATO_MYSQL)
                    celdaIdProveedor.Text = REA.GetInt32("Id_Provee")
                    celdaNIT.Text = REA.GetString("NIT")
                    celdaIdMoneda.Text = REA.GetInt32("Moneda")
                    celdaUsuario.Text = REA.GetString("Usuario")

                    'celdas visibles
                    celdaAnio.Text = REA.GetInt32("Anio")
                    celdaNumero.Text = REA.GetInt32("Numero")
                    dtpFecha.Text = REA.GetDateTime("Fecha")
                    celdaProveedor.Text = REA.GetString("Proveedor")
                    celdaDireccion.Text = REA.GetString("Direccion")
                    celdaMoneda.Text = REA.GetString("cat_clave")
                    celdaTasa.Text = REA.GetDouble("Tasa")
                    celdaFactura.Text = REA.GetString("Factura")
                    celdaRef1.Text = REA.GetString("Referencia_1")
                    celdaRef2.Text = REA.GetString("Referencia_2")
                    celdaCosteo.Text = REA.GetString("Costeo")
                    celdaFlete.Text = REA.GetDouble("Flete")
                    celdaSeguro.Text = REA.GetDouble("Seguro")
                    If REA.GetDouble("HDoc_DR1_Dbl") = 1 Then
                        checkTendido.Checked = True
                    Else
                        checkTendido.Checked = False
                    End If
                    intTipoDoc = REA.GetInt32("tipo")
                    If REA.GetInt32("Estado") = 1 Then
                        checkActivo.Checked = True
                    ElseIf REA.GetInt32("Estado") = 0 Then
                        checkActivo.Checked = False
                    End If
                    If Sesion.IdEmpresa = 16 Then
                        celdaCodigoGeneracion.Text = REA.GetString("Cod_")
                    End If
                Loop
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try

    End Sub

    Public Sub DatosPoliza(ByVal numero As Integer, ByVal anio As Integer)
        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader
        Dim strSQL As String = STR_VACIO
        Dim strFila As String = STR_VACIO

        strSQL = SqlDatosPoliza(numero, anio)

        Try
            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSQL, CON)
            REA = COM.ExecuteReader

            If REA.HasRows Then
                Do While REA.Read
                    strFila = REA.GetString("Numero") & "|"
                    strFila &= REA.GetDateTime("Fecha") & "|"
                    strFila &= REA.GetString("Usuario") & "|"
                    strFila &= REA.GetString("Factura") & "|"
                    strFila &= REA.GetString("Anio") & "|"
                    strFila &= REA.GetString("Cat") & "|"
                    strFila &= INT_UNO


                    cFunciones.AgregarFila(dgPolizaImportacion, strFila)
                Loop
            End If

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub


    Public Sub CargarDetalle(ByVal numero As Integer, ByVal anio As Integer)
        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader
        Dim strSQL As String = STR_VACIO
        Dim strFila As String = STR_VACIO

        Dim i As Integer = 0

        strSQL = SqlCargarDetalle(numero, anio)

        Try
            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSQL, CON)
            REA = COM.ExecuteReader

            If REA.HasRows Then
                Do While REA.Read
                    strFila = REA.GetInt32("Codigo") & "|"
                    strFila &= REA.GetString("Descripcion") & "|"
                    strFila &= REA.GetString("Medida") & "|"
                    strFila &= REA.GetDouble("PrecioU") & "|"
                    strFila &= REA.GetDouble("DescuentoPor") & "|"
                    strFila &= REA.GetDouble("DescuentoMon") & "|"
                    strFila &= REA.GetInt32("Bultos") & "|"
                    strFila &= REA.GetDouble("Cantidad") & "|"
                    strFila &= REA.GetDouble("Lin_Subtotal") & "|"
                    strFila &= REA.GetString("PNR") & "|"
                    strFila &= REA.GetDouble("UnidadMed") & "|"
                    strFila &= REA.GetString("Inciso") & "|"
                    strFila &= REA.GetString("DescLinea") & "|"
                    strFila &= REA.GetDouble("Brutos") & "|"
                    strFila &= REA.GetDouble("Netos") & "|"
                    strFila &= REA.GetDouble("Fob") & "|"
                    strFila &= REA.GetDouble("Flete") & "|"
                    strFila &= REA.GetDouble("Seguro") & "|"
                    strFila &= REA.GetDouble("Cargos") & "|" ' Otros Gastos 
                    strFila &= REA.GetDouble("Otros") & "|" 'Otros 
                    strFila &= REA.GetDouble("CIF") & "|"
                    strFila &= REA.GetDouble("ValorAduanal") & "|" ' VAlor Aduanal
                    strFila &= REA.GetDouble("DAI") & "|"
                    strFila &= REA.GetDouble("IVA") & "|"
                    strFila &= REA.GetDouble("Costo") & "|"
                    strFila &= REA.GetDouble("Total") & "|"
                    strFila &= REA.GetInt32("catDatos") & "|"
                    strFila &= REA.GetInt32("anoDatos") & "|"
                    strFila &= REA.GetInt32("NumDatos") & "|"
                    strFila &= REA.GetInt32("LinDatos") & "|"
                    strFila &= REA.GetString("lote")

                    cFunciones.AgregarFila(dgDetalle, strFila)

                    'If Not REA.GetDouble("Total").ToString(FORMATO_MONEDA) = REA.GetDouble("CIF").ToString(FORMATO_MONEDA) Then
                    '    MsgBox("Difference between cost and CIF value" & vbCrLf & vbCrLf & dgDetalle.Rows(i).Cells("colDescripcionDet").Value & vbCrLf & vbCrLf & "Total: " & dgDetalle.Rows(i).Cells("colGranTotal").Value & vbCrLf & "CIF: " & dgDetalle.Rows(i).Cells("colCIF").Value & vbCrLf & vbCrLf & "Difference / TOTAL: " & Math.Round(dgDetalle.Rows(i).Cells("colGranTotal").Value - dgDetalle.Rows(i).Cells("colCIF").Value, 2), vbExclamation, "Online Discrepancy #" & i + 1)
                    'End If
                Loop

                For i = 0 To dgDetalle.Rows.Count - 1
                    If dgDetalle.Rows(i).Cells("colCosto").Value > 0 Then
                        If Not (dgDetalle.Rows(i).Cells("colTotalDet").Value = dgDetalle.Rows(i).Cells("colGranTotal").Value) Then
                            MsgBox("A change in product cost has been detected" & vbCrLf & vbCrLf & dgDetalle.Rows(i).Cells("colDescripcionDet").Value & vbCrLf & vbCrLf & "Previous cost: " & dgDetalle.Rows(i).Cells("colPrecioDet").Value & vbCrLf & "New: " & dgDetalle.Rows(i).Cells("colCosto").Value & vbCrLf & vbCrLf & "Difference / TOTAL: " & Math.Round(dgDetalle.Rows(i).Cells("colTotalDet").Value - dgDetalle.Rows(i).Cells("colGranTotal").Value, 2), vbExclamation, "Cost Modification")
                            dgDetalle.Rows(i).Cells("colPrecioDet").Value = dgDetalle.Rows(i).Cells("colCosto").Value
                            dgDetalle.Rows(i).Cells("colTotalDet").Value = dgDetalle.Rows(i).Cells("colGranTotal").Value
                        ElseIf Not (dgDetalle.Rows(i).Cells("colGranTotal").Value = dgDetalle.Rows(i).Cells("colCIF").Value) Then
                            MsgBox("Difference between cost and CIF value" & vbCrLf & vbCrLf & dgDetalle.Rows(i).Cells("colDescripcionDet").Value & vbCrLf & vbCrLf & "Total: " & dgDetalle.Rows(i).Cells("colGranTotal").Value & vbCrLf & "CIF: " & dgDetalle.Rows(i).Cells("colCIF").Value & vbCrLf & vbCrLf & "Difference / TOTAL: " & Math.Round(dgDetalle.Rows(i).Cells("colGranTotal").Value - dgDetalle.Rows(i).Cells("colCIF").Value, 2), vbExclamation, "Online Discrepancy #" & i + 1)
                        End If
                    End If


                Next

                CalcularTotales()

            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub


    Public Sub CargarDatos(ByVal numero As Integer, ByVal anio As Integer)
        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader
        Dim strSQL As String = STR_VACIO
        Dim strFila As String = STR_VACIO
        Dim cantidad As Integer

        strSQL = SqlDatos(numero, anio)

        Try

            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSQL, CON)
            REA = COM.ExecuteReader

            If REA.HasRows Then
                Do While REA.Read
                    strFila = REA.GetString("cat_clave") & "|"
                    strFila &= REA.GetString("cat_desc") & "|"
                    cantidad = REA.GetInt32("Cantidad")
                    If cantidad > 0 Then
                        strFila &= "SI"
                    Else
                        strFila &= "NO"
                    End If

                    cFunciones.AgregarFila(dgDocumentos, strFila)

                Loop
            End If


        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub


    Public Sub NuevosDatosPoliza(ByVal codigo As Integer)
        Dim COM1 As MySqlCommand
        Dim REA1 As MySqlDataReader
        Dim strSQL As String = STR_VACIO
        Dim strFila As String = STR_VACIO
        Dim conec As MySqlConnection

        strSQL = SqlNuevosDatosPoliza(codigo)

        Try

            conec = New MySqlConnection(strConexion)
            conec.Open()
            COM1 = New MySqlCommand(strSQL, conec)
            Using conec

                dgPolizaImportacion.Rows.Clear()
                REA1 = COM1.ExecuteReader

                If REA1.HasRows Then
                    Do While REA1.Read
                        strFila = REA1.GetInt32("Numero") & "|"
                        strFila &= REA1.GetDateTime("Fecha") & "|"
                        strFila &= REA1.GetString("Operador") & "|"
                        strFila &= REA1.GetString("Referencia") & "|"
                        strFila &= REA1.GetInt32("Anio") & "|"
                        strFila &= REA1.GetInt32("Catalogo") & "|"
                        strFila &= INT_CERO

                        cFunciones.AgregarFila(dgPolizaImportacion, strFila)
                    Loop
                End If
                COM1.Dispose()
                COM1 = Nothing
                conec.Close()
                conec.Dispose()
                conec = Nothing
                System.GC.Collect()
            End Using

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try

    End Sub


    Public Sub CargarReferencia(ByVal numero As Integer, ByVal anio As Integer)
        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader
        Dim strSQL As String = STR_VACIO

        Try
            If dgPolizaImportacion.CurrentRow Is Nothing Then
                Exit Sub
            Else

                strSQL = SqlCargarReferencia(numero, anio)



                MyCnn.CONECTAR = strConexion
                COM = New MySqlCommand(strSQL, CON)
                REA = COM.ExecuteReader

                If REA.HasRows Then
                    REA.Read()
                    celdaFactura.Text = REA.GetString("Factura")
                    celdaRef1.Text = REA.GetString("Ref_1")
                    celdaRef2.Text = REA.GetString("Ref_2")
                    celdaCosteo.Text = REA.GetString("Costeo")
                    celdaFlete.Text = REA.GetDouble("Flete")
                    celdaSeguro.Text = REA.GetDouble("seguro")

                End If

            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Public Sub NuevoDetalle(ByVal codigo As Integer)
        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader
        Dim strSQL As String = STR_VACIO
        Dim strFila As String = STR_VACIO
        Dim total As Double
        Dim strTemp As String = STR_VACIO
        Dim i As Integer


        For i = 0 To dgPolizaImportacion.Rows.Count - 1
            If i = 0 Then
                strTemp = " AND ("
            ElseIf i > 0 Then
                strTemp = strTemp & " OR "
            End If
            If dgPolizaImportacion.Rows.Count - 1 = 0 Then
                strTemp = strTemp & " ( HDoc_Doc_Ano = " & dgPolizaImportacion.Rows(i).Cells("colAnioP").Value & " AND HDoc_Doc_Num = " & dgPolizaImportacion.Rows(i).Cells("colNumeroP").Value & ")"
            Else
                strTemp = strTemp & " ( HDoc_Doc_Ano = " & dgPolizaImportacion.Rows(i).Cells("colAnioP").Value & " AND HDoc_Doc_Num = " & dgPolizaImportacion.Rows(i).Cells("colNumeroP").Value & ")"
            End If
        Next
        dgDetalle.Rows.Clear()
        If strTemp = vbNullString Then
            Exit Sub
        End If
        strSQL = SqlNuevoDetalle(codigo, strTemp)
        Try
            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSQL, CON)
            REA = COM.ExecuteReader
            If REA.HasRows Then
                Do While REA.Read
                    strFila = REA.GetInt32("Codigo") & "|" ' Codigo
                    strFila &= REA.GetString("Descripcion") & "|" ' Descripcion
                    strFila &= REA.GetString("Medida") & "|" ' Medida 
                    strFila &= REA.GetDouble("PrecioU") & "|" ' Precio 
                    strFila &= vbEmpty & "|" ' Discount %
                    strFila &= vbEmpty & "|" ' Discount $
                    strFila &= vbEmpty & "|" ' Packages 
                    strFila &= REA.GetDouble("Cantidad") & "|" ' Cantidad 

                    total = Math.Round((REA.GetDouble("PrecioU") * REA.GetDouble("Cantidad")) + 0.0000000001, 2)
                    strFila &= total.ToString(FORMATO_MONEDA) & "|" ' Total
                    strFila &= REA.GetString("Parte") & "|" 'Part
                    strFila &= REA.GetDouble("UMedida") & "|" ' Unit Code
                    strFila &= " " & "|" ' Item
                    strFila &= " " & "|" ' Descripcion 
                    strFila &= " " & "|" ' Gross
                    strFila &= " " & "|" ' Net 
                    strFila &= " " & "|" ' FOB($) 
                    strFila &= " " & "|" ' Freight ($)
                    strFila &= " " & "|" ' Insurance($)
                    strFila &= " " & "|" ' Others Expenses
                    strFila &= " " & "|" ' Others($)
                    strFila &= " " & "|" ' CIF 
                    strFila &= " " & "|" ' Valor Aduanal 
                    strFila &= " " & "|" ' DAI 
                    strFila &= " " & "|" ' IVA
                    strFila &= " " & "|" ' COSTO U
                    strFila &= " " & "|" ' Gran Total
                    strFila &= REA.GetInt32("HDoc_Doc_Cat") & "|" 'Catalogo
                    strFila &= REA.GetInt32("HDoc_Doc_Num") & "|" ' Numero
                    strFila &= REA.GetInt32("HDoc_Doc_Ano") & "|" ' Anio
                    strFila &= REA.GetInt32("LinDPoliza") & "|" ' Lin Poliza
                    strFila &= REA.GetString("lote") ' Lote
                    cFunciones.AgregarFila(dgDetalle, strFila)
                Loop
                CalcularTotales()
            End If

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub



    Public Sub AgregarAlDetalle()
        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader
        Dim strSQL As String = STR_VACIO
        Dim i As Integer
        Dim numero As Integer

        Try
            For i = 0 To dgDetalle.Rows.Count - 1

                If dgDetalle.Rows.Count - 1 >= 0 Then
                    numero = dgDetalle.Rows(i).Cells("colCodigoDet").Value

                    strSQL = SqlAgregaAlDetalle(numero)


                    MyCnn.CONECTAR = strConexion
                    COM = New MySqlCommand(strSQL, CON)
                    REA = COM.ExecuteReader

                    If REA.HasRows Then
                        REA.Read()
                        dgDetalle.Rows(i).Cells("colInciso").Value = REA.GetString("Inciso")
                        dgDetalle.Rows(i).Cells("colDescripDet").Value = REA.GetString("Descripcion")
                        dgDetalle.Rows(i).Cells("colKgBrutos").Value = CDbl(INT_CERO)
                        dgDetalle.Rows(i).Cells("colKgNetos").Value = CDbl(INT_CERO)
                        dgDetalle.Rows(i).Cells("colFOB").Value = CDbl(INT_CERO)
                        dgDetalle.Rows(i).Cells("colFlete").Value = CDbl(INT_CERO)
                        dgDetalle.Rows(i).Cells("colSeguro").Value = CDbl(INT_CERO)
                        dgDetalle.Rows(i).Cells("colOtros").Value = CDbl(INT_CERO)
                        dgDetalle.Rows(i).Cells("colOtrosG").Value = CDbl(INT_CERO)
                        dgDetalle.Rows(i).Cells("colCif").Value = CDbl(INT_CERO)
                        dgDetalle.Rows(i).Cells("colValorAduanal").Value = CDbl(INT_CERO)
                        dgDetalle.Rows(i).Cells("colDAI").Value = CDbl(INT_CERO)
                        dgDetalle.Rows(i).Cells("ColIVA").Value = CDbl(INT_CERO)
                        dgDetalle.Rows(i).Cells("colCosto").Value = CDbl(INT_CERO)
                        dgDetalle.Rows(i).Cells("colGranTotal").Value = Math.Round((dgDetalle.Rows(i).Cells("colCantidadDet").Value * dgDetalle.Rows(i).Cells("colCosto").Value) + 0.001, 2)
                    End If
                End If
            Next
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Function EsReferenciaValida() As Boolean
        Dim i As Integer
        Dim logCancelar As Boolean
        Dim Temp As String
        Dim Ref As String = vbNullString

        If intTipoDoc = 0 Then 'intTipoDoc = 0 --> Importación
            For i = 0 To dgPolizaImportacion.Rows.Count - 1
                Temp = dgPolizaImportacion.Rows(i).Cells("colReferenciaP").Value
                If Ref = vbNullString Then
                    Ref = Temp
                End If

                If Not (Temp = Ref) And Not (Ref = vbNullString) Then
                    MsgBox("Only multiple documents are allowed if they have the same reference", vbExclamation, "Notice")
                    logCancelar = True
                End If
            Next
        Else 'intTipoDoc = 1 -->Devolución
            If dgPolizaImportacion.Rows.Count - 1 > 0 Then
                MsgBox("Only one data document for policy is allowed", vbExclamation, "Notice")
                logCancelar = True
            End If
        End If
        EsReferenciaValida = Not (logCancelar)
    End Function

    Private Function EsPolizaValida() As Boolean
        Dim logCancelar As Boolean = True
        Dim i As Integer

        Dim dblCIF As Double
        Dim dblGasto As Double
        Dim dblTotal As Double
        Dim PrecioUnitario As Double

        Dim strLista As String
        Dim strDato As String = vbNullString
        Dim strCodigo As String

        Dim conec As New MySqlConnection
        Dim COM As New MySqlCommand
        Dim strSQL As String = STR_VACIO

        Dim intActivo As Integer = 0
        Try


            For i = 0 To dgDetalle.Rows.Count - 1
                dgDetalle.Rows(i).Cells("colTotalDet").Value = Math.Round(dgDetalle.Rows(i).Cells("colPrecioDet").Value * dgDetalle.Rows(i).Cells("colCantidadDet").Value, 2)
                dblTotal = dgDetalle.Rows(i).Cells("colTotalDet").Value

                If dgDetalle.Rows(i).Cells("colCIF").Value = vbNullString Or dgDetalle.Rows(i).Cells("colCIF").Value = 0.0 Then
                    dblCIF = 0
                Else
                    dblCIF = dgDetalle.Rows(i).Cells("colCIF").Value
                End If
                If dblTotal > 0 Then
                    If Not (dblTotal = dblCIF) Then
                        dgDetalle.Rows(i).Cells("colCIF").Value = CDbl(dgDetalle.Rows(i).Cells("colFOB").Value) + CDbl(dgDetalle.Rows(i).Cells("colFlete").Value) + CDbl(dgDetalle.Rows(i).Cells("colSeguro").Value) + CDbl(dgDetalle.Rows(i).Cells("colOtros").Value) + CDbl(dgDetalle.Rows(i).Cells("colOtrosG").Value)
                        dblTotal = dblCIF

                    End If

                    If dgDetalle.Rows(i).Cells("colCIF").Value = vbNullString Or dgDetalle.Rows(i).Cells("colCIF").Value = 0.0 Then
                        dblCIF = 0
                    Else
                        dblCIF = dgDetalle.Rows(i).Cells("colCIF").Value
                    End If

                    If Not (dblTotal = dblCIF) Then
                        strCodigo = dgDetalle.Rows(i).Cells("colCodigoDet").Value
                        strSQL = " SELECT inv_costo FROM Inventarios WHERE inv_activo = " & intActivo & " AND inv_sisemp= " & Sesion.IdEmpresa & " AND inv_numero= " & strCodigo
                        conec = New MySqlConnection(strConexion)
                        conec.Open()
                        COM = New MySqlCommand(strSQL, conec)
                        Using conec
                            PrecioUnitario = COM.ExecuteScalar
                            COM.Dispose()
                            COM = Nothing
                            conec.Close()
                            conec.Dispose()
                            conec = Nothing
                            System.GC.Collect()
                        End Using

                        If PrecioUnitario > 0 Then
                            dgDetalle.Rows(i).Cells("colPrecioDet").Value = PrecioUnitario
                            dgDetalle.Rows(i).Cells("coltotalDet").Value = Math.Round(dgDetalle.Rows(i).Cells("colCantidadDet").Value * PrecioUnitario, 2)
                        End If
                    End If
                    If dgDetalle.Rows(i).Cells("colCIF").Value = vbNullString Or dgDetalle.Rows(i).Cells("colCIF").Value = 0.0 Then
                        dblCIF = 0
                    Else
                        dblCIF = dgDetalle.Rows(i).Cells("colCIF").Value
                    End If

                    If Not (dblTotal = dblCIF) Then
                        strDato = strDato & IIf(strDato = vbNullString, vbNullString, "|") & "Linea #" & i + 1 & vbTab & Math.Round(dblTotal, 2) & vbTab & Math.Round(dblCIF, 2) & vbTab & Math.Round(dblTotal - dblCIF, 2) & IIf(dblCIF = 0, "I do not know", "")
                    End If
                End If
            Next

            If Not (strDato = vbNullString) Then
                MsgBox("The amount of the CIF does not match the other amounts, you must enter a correct CIF", vbInformation)
                'dgDetalle.CurrentRow.Cells("colCIF").Value = Focus()
                logCancelar = False
                Exit Function
            End If

            'Si la suma de FOB y Gastos es igual a CIF
            dblCIF = 0
            For j As Integer = 0 To dgDetalle.Rows.Count - 1
                dblCIF = dblCIF + dgDetalle.Rows(j).Cells("colCIF").Value
                dblGasto = dblGasto + dgDetalle.Rows(j).Cells("colFOB").Value + dgDetalle.Rows(j).Cells("colFlete").Value + dgDetalle.Rows(j).Cells("colSeguro").Value + dgDetalle.Rows(j).Cells("colOtros").Value + +dgDetalle.Rows(j).Cells("colOtrosG").Value
            Next
            If Not dblCIF.ToString(FORMATO_MONEDA) = dblGasto.ToString(FORMATO_MONEDA) Then
                If dblCIF.ToString(FORMATO_MONEDA) > vbEmpty Or dblGasto.ToString(FORMATO_MONEDA) > vbEmpty Then
                    strLista = strLista & IIf(strLista = vbNullString, vbNullString, vbCr) & vbTab & "- The sum of FOB and expenses differs from the sum of the CIF value"
                End If
            End If
            If Not (strLista = vbNullString) Then
                If MsgBox("The result of the check:" & vbCr & vbCr & strLista & vbCr & vbCr & "You want to save even with inconsistent data?", vbExclamation + vbYesNo + vbDefaultButton2, "Policy Data") = vbYes Then
                    logCancelar = True
                Else
                    logCancelar = False
                End If
            Else
                logCancelar = True
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try

        Return logCancelar
    End Function

    Private Function ComprobarIngreso() As Boolean
        Dim i As Integer
        Dim ValidarIngreso As Boolean = True

        If celdaAnio.Text = vbEmpty Or celdaNumero.Text = vbEmpty Or
        celdaIdProveedor.Text = vbEmpty Or celdaProveedor.Text = vbNullString Or
        celdaMoneda.Text = vbNullString Or celdaTasa.Text = vbEmpty Then

            MsgBox("You must enter all the minimum data", vbCritical)
            Exit Function
            ValidarIngreso = False
        End If

        For i = 0 To dgDetalle.Rows.Count - 1
            If Not ComprobarFila(i) Then
                ValidarIngreso = False
                Exit Function
            End If
        Next

        CalcularTotales()
        If (celdaTotalCantidad.Text = 0) Or (celdaTotal.Text = 0) Then
            MsgBox("An order with a zero amount is not supported", vbCritical)
            Exit Function
            ValidarIngreso = False
        End If
        Return ValidarIngreso
    End Function

    Private Function ComprobarFila(ByVal i As Integer) As Boolean
        If dgDetalle.Rows(i).Cells("colCodigoDet").Value = vbNullString Then
            MsgBox("Row " & i + 1 & ": Invalid Item Code")
            ComprobarFila = False
            Exit Function
        End If

        If dgDetalle.Rows(i).Cells("colDescripcionDet").Value = vbNullString Then
            MsgBox("Row " & i + 1 & ": Description of Item in white")
            ComprobarFila = False
            Exit Function
        End If

        If dgDetalle.Rows(i).Cells("colPrecioDet").Value = vbEmpty Then
            MsgBox("Row " & i + 1 & ": Item price at ZERO")
            ComprobarFila = False
            Exit Function
        End If

        If dgDetalle.Rows(i).Cells("colCantidadDet").Value = vbEmpty Then
            MsgBox("Row " & i + 1 & ": Amount of item in ZERO")
            ComprobarFila = False
            Exit Function
        End If
        If dgDetalle.Rows(i).Cells("colValorAduanal").Value = vbEmpty Then
            MsgBox("Row " & i + 1 & ": Value of item in ZERO")
            ComprobarFila = False
            Exit Function
        End If
        ComprobarFila = True
    End Function

    Private Sub CalcularTotales()
        Dim Cantidad As Double = 0
        Dim Total As Double = 0
        Dim i As Integer
        For i = 0 To dgDetalle.Rows.Count - 1
            Cantidad = Cantidad + dgDetalle.Rows(i).Cells("colCantidadDet").Value
            Total = Total + dgDetalle.Rows(i).Cells("colTotalDet").Value
        Next

        celdaTotalCantidad.Text = Cantidad.ToString(FORMATO_MONEDA)
        celdaTotal.Text = Total.ToString(FORMATO_MONEDA)

    End Sub


    Private Sub GuardarDocumento()
        Dim HDR As New clsDcmtos_HDR
        Dim verCheck As Integer

        If checkActivo.Checked = True Then
            verCheck = 1
        Else
            verCheck = 0
        End If

        HDR.CONEXION = strConexion

        Try
            HDR.HDOC_SIS_EMP = celdaEmpresa.Text
            HDR.HDOC_DOC_CAT = celdaCatalogo.Text
            HDR.HDOC_DOC_ANO = celdaAnio.Text
            HDR.HDOC_DOC_NUM = celdaNumero.Text
            HDR.HDoc_Doc_Fec_NET = celdaDate.Text
            HDR.HDOC_EMP_COD = celdaIdProveedor.Text
            HDR.HDOC_EMP_NOM = celdaProveedor.Text
            HDR.HDOC_EMP_DIR = celdaDireccion.Text
            HDR.HDOC_EMP_NIT = celdaNIT.Text
            HDR.HDOC_DR1_CAT = intTipoDoc
            HDR.HDOC_DR1_NUM = celdaFactura.Text
            'HDR.HDOC_DR1_EMP = vbEmpty
            HDR.HDOC_DR2_NUM = celdaRef1.Text
            HDR.HDOC_RF1_TXT = celdaCosteo.Text
            HDR.HDOC_RF2_TXT = celdaRef2.Text
            HDR.HDOC_USUARIO = celdaUsuario.Text
            HDR.HDOC_PRO_DCAT = vbEmpty
            HDR.HDOC_PRO_DANO = vbEmpty
            HDR.HDOC_PRO_DNUM = vbEmpty
            HDR.HDOC_DOC_TC = celdaTasa.Text
            HDR.HDOC_DOC_MON = celdaIdMoneda.Text
            HDR.HDOC_RF1_DBL = celdaFlete.Text
            HDR.HDOC_RF2_DBL = celdaSeguro.Text
            HDR.HDOC_DOC_STATUS = verCheck
            HDR.HDOC_RF2_COD = If(Len(celdaCodigoGeneracion.Text) > 1, celdaCodigoGeneracion.Text, "")
            HDR.HDOC_DR1_DBL = IIf(checkTendido.Checked = True, 1, 0)
            If Me.Tag = "Mod" Then
                If HDR.Actualizar() = False Then
                    MsgBox(HDR.MERROR.ToString & "Could not update the document", MsgBoxStyle.Critical)
                End If
            Else
                If HDR.Guardar() = False Then
                    MsgBox(HDR.MERROR.ToString & "Could not save the document", MsgBoxStyle.Critical)
                End If
            End If

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try


    End Sub


    Public Sub GuardarDetalle()
        Dim i As Integer
        For i = 0 To dgDetalle.Rows.Count - 1
            SqlGuardarDetalle(i)
            SqlGuardarDeclaracion(i)

        Next
    End Sub


    Private Sub SqlGuardarDetalle(ByVal i As Integer)
        Dim DTL As New clsDcmtos_DTL

        DTL.CONEXION = strConexion

        Try

            DTL.DDOC_SIS_EMP = Sesion.IdEmpresa
            DTL.DDOC_DOC_CAT = celdaCatalogo.Text
            DTL.DDOC_DOC_ANO = celdaAnio.Text
            DTL.DDOC_DOC_NUM = celdaNumero.Text
            DTL.DDOC_DOC_LIN = i + 1
            DTL.DDOC_PRD_COD = dgDetalle.Rows(i).Cells("colCodigoDet").Value
            DTL.DDOC_PRD_PNR = dgDetalle.Rows(i).Cells("colParteDet").Value
            DTL.DDOC_PRD_DES = dgDetalle.Rows(i).Cells("colDescripcionDet").Value
            DTL.DDOC_PRD_UM = dgDetalle.Rows(i).Cells("colCodigoUMDet").Value
            DTL.DDOC_PRD_PUQ = dgDetalle.Rows(i).Cells("colPrecioDet").Value
            DTL.DDOC_PRD_NET = dgDetalle.Rows(i).Cells("colPrecioDet").Value
            DTL.DDOC_PRD_QTY = dgDetalle.Rows(i).Cells("colCantidadDet").Value
            DTL.DDOC_RF1_NUM = vbEmpty
            DTL.DDOC_RF1_DBL = dgDetalle.Rows(i).Cells("colTotalDet").Value
            DTL.DDOC_PRD_FOB = dgDetalle.Rows(i).Cells("colFOB").Value / dgDetalle.Rows(i).Cells("colCantidadDet").Value
            DTL.DDOC_PRD_CIF = dgDetalle.Rows(i).Cells("colCIF").Value / dgDetalle.Rows(i).Cells("colCantidadDet").Value
            DTL.DDOC_RF3_DBL = dgDetalle.Rows(i).Cells("colValorAduanal").Value

            If Me.Tag = "Mod" Then
                If DTL.Actualizar() = False Then
                    MsgBox(DTL.MERROR.ToString & "Could not update the document", MsgBoxStyle.Critical)
                End If
            Else
                If DTL.Guardar() = False Then
                    MsgBox(DTL.MERROR.ToString & "Could not save the document", MsgBoxStyle.Critical)
                End If
            End If


        Catch ex As Exception

        End Try

    End Sub

    Private Sub SqlGuardarDeclaracion(ByVal i As Integer)
        Dim DEC As New Tablas.TDCMTOS_DEC

        DEC.CONEXION = strConexion

        DEC.EDOC_SIS_EMP = Sesion.IdEmpresa
        DEC.EDOC_DOC_CAT = celdaCatalogo.Text
        DEC.EDOC_DOC_ANO = celdaAnio.Text
        DEC.EDOC_DOC_NUM = celdaNumero.Text
        DEC.EDOC_DOC_LIN = i + 1
        DEC.EDOC_LIN_FRAC = dgDetalle.Rows(i).Cells("colInciso").Value
        DEC.EDOC_LIN_DESC = dgDetalle.Rows(i).Cells("colDescripDet").Value
        DEC.EDOC_LIN_GROSS = dgDetalle.Rows(i).Cells("colKgBrutos").Value
        DEC.EDOC_LIN_NET = dgDetalle.Rows(i).Cells("colKgNetos").Value
        DEC.EDOC_LIN_FOB = dgDetalle.Rows(i).Cells("colFOB").Value
        DEC.EDOC_LIN_FREIGHT = dgDetalle.Rows(i).Cells("colFlete").Value
        DEC.EDOC_LIN_INSURANCE = dgDetalle.Rows(i).Cells("colSeguro").Value
        DEC.EDOC_LIN_CARGOS = dgDetalle.Rows(i).Cells("colOtros").Value
        DEC.EDOC_LIN_OTROS = dgDetalle.Rows(i).Cells("colOtrosG").Value
        DEC.EDOC_LIN_CIF = dgDetalle.Rows(i).Cells("colCIF").Value
        DEC.EDOC_LIN_DAI = dgDetalle.Rows(i).Cells("colDAI").Value
        DEC.EDOC_LIN_IVA = dgDetalle.Rows(i).Cells("colIVA").Value

        If Me.Tag = "Mod" Then
            If DEC.PUPDATE() = False Then
                MsgBox(DEC.MERROR.ToString & "Could not update the document", MsgBoxStyle.Critical)
            End If
        Else
            If DEC.PINSERT() = False Then
                MsgBox(DEC.MERROR.ToString & "Could not save the document", MsgBoxStyle.Critical)
            End If
        End If

    End Sub

    Private Sub GuardarDescargos()
        Dim DTL_P As New clsDcmtos_DTL_Pro
        Dim i As Integer

        For i = 0 To dgDetalle.Rows.Count - 1
            DTL_P.CONEXION = strConexion

            DTL_P.PDOC_SIS_EMP = Sesion.IdEmpresa
            DTL_P.PDOC_PAR_CAT = dgDetalle.Rows(i).Cells("colCat").Value
            DTL_P.PDOC_PAR_ANO = dgDetalle.Rows(i).Cells("colAño").Value
            DTL_P.PDOC_PAR_NUM = dgDetalle.Rows(i).Cells("colNum").Value
            DTL_P.PDOC_PAR_LIN = dgDetalle.Rows(i).Cells("colLinDPoliza").Value
            DTL_P.PDOC_CHI_CAT = celdaCatalogo.Text
            DTL_P.PDOC_CHI_ANO = celdaAnio.Text
            DTL_P.PDOC_CHI_NUM = celdaNumero.Text
            DTL_P.PDOC_CHI_LIN = (i + 1)
            DTL_P.PDOC_PROV_COD = celdaIdProveedor.Text
            DTL_P.PDOC_PRD_COD = dgDetalle.Rows(i).Cells("colCodigoDet").Value
            DTL_P.PDOC_PRD_PNR = dgDetalle.Rows(i).Cells("colParteDet").Value
            DTL_P.PDOC_PRD_NET = dgDetalle.Rows(i).Cells("colPrecioDet").Value
            DTL_P.PDOC_QTY_ORD = dgDetalle.Rows(i).Cells("colCantidadDet").Value
            DTL_P.PDOC_QTY_PRO = dgDetalle.Rows(i).Cells("colCantidadDet").Value

            If Me.Tag = "Mod" Then
                If DTL_P.Actualizar() = False Then
                    MsgBox(DTL_P.MERROR.ToString & "Could not update the document", MsgBoxStyle.Critical)
                End If
            Else
                If DTL_P.Guardar() = False Then
                    MsgBox(DTL_P.MERROR.ToString & "Could not save the document", MsgBoxStyle.Critical)
                End If
            End If
        Next
    End Sub


    Public Sub GuardarBultos()
        Dim i As Integer

        For i = 0 To dgDetalle.Rows.Count - 1
            SqlGuardarBultos(i)
        Next

    End Sub


    Private Sub SqlGuardarBultos(ByVal i As Integer)
        Dim DTL_B As New Tablas.TDCMTOS_DTL_BOX

        DTL_B.CONEXION = strConexion

        DTL_B.BDOC_SIS_EMP = Sesion.IdEmpresa
        DTL_B.BDOC_DOC_CAT = celdaCatalogo.Text
        DTL_B.BDOC_DOC_ANO = celdaAnio.Text
        DTL_B.BDOC_DOC_NUM = celdaNumero.Text
        DTL_B.BDOC_DOC_LIN = i + 1
        DTL_B.BDOC_BOX_LIN = INT_UNO
        DTL_B.BDOC_BOX_COD = dgDetalle.Rows(i).Cells("colCodigoDet").Value
        DTL_B.BDOC_BOX_QTY = dgDetalle.Rows(i).Cells("colBultos").Value
        DTL_B.BDOC_BOX_LB = dgDetalle.Rows(i).Cells("colCantidadDet").Value

        If Me.Tag = "Mod" Then
            If DTL_B.PUPDATE() = False Then
                MsgBox(DTL_B.MERROR.ToString & "Could not update the document", MsgBoxStyle.Critical)
            End If
        Else
            If DTL_B.PINSERT() = False Then
                MsgBox(DTL_B.MERROR.ToString & "Could not save the document", MsgBoxStyle.Critical)
            End If
        End If
    End Sub



    Public Sub LimpiarCampos()
        celdaAnio.Text = NO_FILA
        celdaEmpresa.Text = NO_FILA
        celdaNumero.Text = NO_FILA
        celdaCatalogo.Text = 180
        celdaTasa.Text = INT_UNO
        dtpFecha.Text = cfun.HoyMySQL
        celdaDate.Text = dtpFecha.Value.ToString(FORMATO_MYSQL)
        celdaProveedor.Clear()
        celdaIdProveedor.Clear()
        celdaNIT.Clear()
        celdaDireccion.Clear()
        celdaMoneda.Clear()
        celdaIdMoneda.Text = INT_LOC
        celdaFactura.Clear()
        celdaRef1.Clear()
        celdaRef2.Clear()
        celdaCosteo.Clear()
        celdaFlete.Clear()
        celdaSeguro.Clear()
        celdaUsuario.Clear()
        celdaTotal.Clear()
        celdaTotalCantidad.Clear()

        dgPolizaImportacion.Rows.Clear()
        dgDetalle.Rows.Clear()
        dgDocumentos.Rows.Clear()
        dgDatosOcultos.Rows.Clear()

        celdaCodigoGeneracion.Clear()
        If Sesion.IdEmpresa = 16 Then
            etiquetacodigo.Visible = True
            celdaCodigoGeneracion.Visible = True
        Else
            etiquetacodigo.Visible = False
            celdaCodigoGeneracion.Visible = False
        End If
        If Sesion.idGiro = 2 Then
            checkTendido.Visible = True
            checkTendido.Checked = False
        Else
            checkTendido.Visible = False
            checkTendido.Checked = False
        End If

    End Sub
    Private Function DependeciasIngreso() As Integer
        Dim intValidacion As Integer
        Dim COM As MySqlCommand
        Dim conec As MySqlConnection
        Dim strSQL As String = STR_VACIO
        Try
            strSQL = "  SELECT COUNT(*) "
            strSQL &= "    	FROM Dcmtos_DTL_Pro p "
            strSQL &= "         WHERE p.PDoc_Sis_Emp = {empresa} AND p.PDoc_Par_Cat = 180 AND p.PDoc_Par_Ano = {anio} AND p.PDoc_Par_Num = {numero}  AND p.PDoc_Chi_Cat = 47 "
            strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
            strSQL = Replace(strSQL, "{anio}", celdaAnio.Text)
            strSQL = Replace(strSQL, "{numero}", celdaNumero.Text)
            conec = New MySqlConnection(strConexion)
            conec.Open()
            COM = New MySqlCommand(strSQL, conec)
            Using conec
                intValidacion = COM.ExecuteScalar
                COM.Dispose()
                COM = Nothing
                conec.Close()
                conec.Dispose()
                conec = Nothing
                System.GC.Collect()
            End Using
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        Return intValidacion
    End Function
    Private Function DependeciasFacturaCompra() As Integer
        Dim intValidacion As Integer
        Dim COM As MySqlCommand
        Dim conec As MySqlConnection
        Dim strSQL As String = STR_VACIO
        Try
            strSQL = "  SELECT COUNT(*) "
            strSQL &= "    	FROM Dcmtos_DTL_Pro p "
            strSQL &= "         WHERE p.PDoc_Sis_Emp = {empresa} AND p.PDoc_Par_Cat = 180 AND p.PDoc_Par_Ano = {anio} AND p.PDoc_Par_Num = {numero}  AND p.PDoc_Chi_Cat = 44 "
            strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
            strSQL = Replace(strSQL, "{anio}", celdaAnio.Text)
            strSQL = Replace(strSQL, "{numero}", celdaNumero.Text)
            conec = New MySqlConnection(strConexion)
            conec.Open()
            COM = New MySqlCommand(strSQL, conec)
            Using conec
                intValidacion = COM.ExecuteScalar
                COM.Dispose()
                COM = Nothing
                conec.Close()
                conec.Dispose()
                conec = Nothing
                System.GC.Collect()
            End Using
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        Return intValidacion
    End Function
    ' Borrar Encabezado
    Public Function BorrarEncabezadoPoliza() As Boolean
        Dim logGuardar As Boolean
        Try
            Dim hdr As New clsDcmtos_HDR
            hdr.CONEXION = strConexion
            hdr.HDOC_SIS_EMP = Sesion.IdEmpresa
            hdr.HDOC_DOC_CAT = 180
            hdr.HDOC_DOC_ANO = celdaAnio.Text
            hdr.HDOC_DOC_NUM = celdaNumero.Text
            hdr.Borrar()
            logGuardar = True
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        Return logGuardar
    End Function
    'Borrar Detalle Poliza
    Private Function BorrarDetallePoliza() As Boolean
        Dim logGuardar As Boolean
        Dim strSQL As String = STR_VACIO
        Try
            If LogBorrar = True Then
                For i = 0 To dgDetalle.Rows.Count - 1
                    strSQL = "DDoc_Sis_Emp = {empresa} AND DDoc_Doc_Cat = 180 AND DDoc_Doc_Ano  = {anio}   AND DDoc_Doc_Num  = {numero}  AND DDoc_Doc_Lin = {linea} ;"
                    strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
                    strSQL = Replace(strSQL, "{anio}", celdaAnio.Text)
                    strSQL = Replace(strSQL, "{numero}", celdaNumero.Text)
                    strSQL = Replace(strSQL, "{linea}", dgDetalle.Rows(i).Cells("colLinDPoliza").Value)
                    Dim dtl As New clsDcmtos_DTL
                    dtl.CONEXION = strConexion
                    dtl.Borrar(strSQL)
                Next
                logGuardar = True
            Else
                MsgBox("You don't have permission to this access")
                logGuardar = False
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        Return logGuardar
    End Function
    ' Borrar Acc
    Private Function BorrarAccPoliza() As Boolean
        Dim logGuardar As Boolean
        Dim strSQL As String = STR_VACIO

        Try
            If LogBorrar = True Then
                strSQL = "ADoc_Sis_Emp = {empresa} AND ADoc_Doc_Cat = 180 AND ADoc_Doc_Ano  = {anio}   AND ADoc_Doc_Num  = {numero}   "
                strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
                strSQL = Replace(strSQL, "{anio}", celdaAnio.Text)
                strSQL = Replace(strSQL, "{numero}", celdaNumero.Text)

                Dim acc As New Tablas.TDCMTOS_ACC
                acc.CONEXION = strConexion
                acc.PDELETE(strSQL)

                logGuardar = True
            Else
                MsgBox("You don't have permission to this access")
                logGuardar = False
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        Return logGuardar
    End Function
    'Borrar Descargo 
    Private Function BorrarDescargosPoliza() As Boolean
        Dim logGuardar As Boolean
        Dim strSQl As String = STR_VACIO
        Try
            If LogBorrar = True Then
                '    For i = 0 To dgDetalle.Rows.Count - 1

                strSQl = "PDoc_Sis_Emp = {empresa} AND PDoc_Chi_Cat = 180 AND PDoc_Chi_Ano  = {anio} AND PDoc_Chi_Num = {numero} ; "
                strSQl = Replace(strSQl, "{empresa}", Sesion.IdEmpresa)
                strSQl = Replace(strSQl, "{anio}", celdaAnio.Text)
                strSQl = Replace(strSQl, "{numero}", celdaNumero.Text)
                'Next
                Dim pro As New clsDcmtos_DTL_Pro
                pro.CONEXION = strConexion
                pro.Borrar(strSQl)
                logGuardar = True
            Else
                MsgBox("You don't have permission to this access")
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        Return logGuardar
    End Function
    Private Function BorrarDecPoliza() As Boolean
        Dim logGuardar As Boolean
        Dim strSQl As String = STR_VACIO
        Try
            If LogBorrar = True Then
                '    For i = 0 To dgDetalle.Rows.Count - 1

                strSQl = "EDoc_Sis_Emp = {empresa} AND EDoc_Doc_Cat = 180 AND EDoc_Doc_Ano = {anio} AND EDoc_Doc_Num = {numero} ; "
                strSQl = Replace(strSQl, "{empresa}", Sesion.IdEmpresa)
                strSQl = Replace(strSQl, "{anio}", celdaAnio.Text)
                strSQl = Replace(strSQl, "{numero}", celdaNumero.Text)
                'Next
                Dim dec As New Tablas.TDCMTOS_DEC
                dec.CONEXION = strConexion
                dec.PDELETE(strSQl)
                logGuardar = True
            Else
                MsgBox("You don't have permission to this access")
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        Return logGuardar
    End Function
    Private Function ValidarDescargoPO(ByVal Anio As Integer, ByVal Numero As Integer, ByVal Lin_ As Integer) As Integer
        Dim strSQL As String = STR_VACIO
        Dim conec As New MySqlConnection
        Dim COM As MySqlCommand
        Dim CodigoProyecto As Integer

        strSQL = " SELECT COUNT(*)"
        strSQL &= " FROM Dcmtos_DTL_Pro p "
        strSQL &= "     LEFT JOIN Dcmtos_DTL_Pro p38 ON p38.PDoc_Sis_Emp = p.PDoc_Sis_Emp AND p38.PDoc_Chi_Cat = p.PDoc_Par_Cat AND p38.PDoc_Chi_Ano = p.PDoc_Par_Ano AND p38.PDoc_Chi_Num = p.PDoc_Par_Num AND p38.PDoc_Chi_Lin = p.PDoc_Par_Lin AND p38.PDoc_Par_Cat = 38 "
        strSQL &= "     LEFT JOIN Inventarios i ON i.inv_sisemp = p.PDoc_Sis_Emp AND i.inv_numero = p.PDoc_Prd_Cod  "
        strSQL &= "     LEFT JOIN Articulos a ON a.art_sisemp = i.inv_sisemp AND a.art_codigo = i.inv_artcodigo  "
        strSQL &= " WHERE p.PDoc_Sis_Emp = {empresa} AND p.PDoc_Chi_Cat = {catalogo} AND p.PDoc_Chi_Ano = {anio} AND p.PDoc_Chi_Num = {numero} AND p.PDoc_Chi_Lin = {lin} AND a.art_clase NOT IN(330) AND p38.PDoc_Sis_Emp IS NULL "

        strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
        strSQL = Replace(strSQL, "{catalogo}", 55)
        strSQL = Replace(strSQL, "{anio}", Anio)
        strSQL = Replace(strSQL, "{numero}", Numero)
        strSQL = Replace(strSQL, "{lin}", Lin_)
        conec = New MySqlConnection(strConexion)
        conec.Open()
        COM = New MySqlCommand(strSQL, conec)
        CodigoProyecto = COM.ExecuteScalar
        conec.Close()
        conec.Dispose()
        conec = Nothing
        System.GC.Collect()
        Return CodigoProyecto
    End Function
    Private Function VerificarPoliza() As Integer
        Dim strSQL As String = STR_VACIO
        Dim conec As MySqlConnection
        Dim COM As MySqlCommand
        Dim intCodigo As Integer

        strSQL = " SELECT COUNT(*) "
        strSQL &= "     FROM Dcmtos_HDR h "
        strSQL &= "         WHERE h.HDoc_Sis_Emp = {empresa} AND h.HDoc_Doc_Cat = 180 AND h.HDoc_Doc_Ano = {anio} AND h.HDoc_Doc_Num = {codigo} "
        strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
        strSQL = Replace(strSQL, "{anio}", celdaAnio.Text)
        strSQL = Replace(strSQL, "{codigo}", celdaNumero.Text)
        conec = New MySqlConnection(strConexion)
        conec.Open()
        COM = New MySqlCommand(strSQL, conec)
        intCodigo = COM.ExecuteScalar
        conec.Close()
        conec.Dispose()
        conec = Nothing
        System.GC.Collect()
        Return intCodigo
    End Function
#End Region

#Region "Eventos"

    Private Sub frmPolizaImportacion_Load(sender As Object, e As EventArgs) Handles Me.Load


        dtpInicial.Value = Today.AddMonths(NO_FILA)
        dtpFinal.Value = Today

        MostrarLista()
        Accesos()

    End Sub


    Private Sub botonActualizar_Click(sender As Object, e As EventArgs) Handles botonActualizar.Click
        Dim logCancelar As Boolean

        If CDate(dtpInicial.Value) > CDate(dtpFinal.Value) Then
            MsgBox("The start date may not exceed the final date", vbExclamation, "Notice")
            logCancelar = True
        End If
        If Not (logCancelar) Then

            ListaPrincipal()

        End If
    End Sub

    Private Sub Encabezado1_ClickCerrar(sender As Object, click As Boolean) Handles Encabezado1.ClickCerrar

        If panelLista.Visible = True Then
            Me.Close()
            Fprincipal.BarraDeTareas1.QuitarFormulario(Key)
        ElseIf panelDocumento.Visible = True Then
            MostrarLista()
        End If

    End Sub

    Private Sub dgLista_DoubleClick(sender As Object, e As EventArgs) Handles dgLista.DoubleClick
        Me.Tag = "Mod"
        Dim numero As Integer
        Dim fecha As Date
        Dim fecha1 As String
        Dim anio As Integer
        Encabezado1.botonGuardar.Enabled = True

        dgDetalle.Columns(0).ReadOnly = True
        dgDetalle.Columns(3).ReadOnly = True
        dgDetalle.Columns(7).ReadOnly = True

        If dgLista.SelectedRows.Count = INT_CERO Then Exit Sub
        LimpiarCampos()


        numero = dgLista.SelectedCells(0).Value
        fecha = dgLista.SelectedCells(1).Value

        fecha1 = fecha.ToString(FORMATO_MYSQL)
        anio = dgLista.SelectedCells(5).Value
        BarraTitulo1.CambiarTitulo("Change Entry")
        If dgLista.SelectedCells(6).Value = 1 Then
            checkActivo.Checked = True
        Else
            checkActivo.Checked = False
        End If
        DatosProveedor(numero, fecha1)
        DatosPoliza(numero, anio)
        CargarDetalle(numero, anio)
        CargarDatos(numero, anio)

        MostrarLista(False)

        botonCorregir.Enabled = True

    End Sub

    Private Sub dgDocumentos_DoubleClick(sender As Object, e As EventArgs) Handles dgDocumentos.DoubleClick
        Try
            Dim i As Integer = INT_CERO
            Dim strSQL As String = STR_VACIO
            Dim NumDoc As Integer


            Select Case dgDocumentos.CurrentCell.ColumnIndex
                Case 2

                    'Carga los datos del detalle en el datagrid oculto
                    dgDatosOcultos.Rows.Clear()
                    For i = 0 To dgDetalle.Rows.Count - 1
                        strSQL = dgDetalle.Rows(i).Cells("colDescripcionDet").Value & "|"
                        strSQL &= dgDetalle.Rows(i).Cells("colKgBrutos").Value & "|"
                        strSQL &= dgDetalle.Rows(i).Cells("colKgNetos").Value & "|"
                        strSQL &= dgDetalle.Rows(i).Cells("colFOB").Value & "|"
                        strSQL &= dgDetalle.Rows(i).Cells("colFlete").Value & "|"
                        strSQL &= dgDetalle.Rows(i).Cells("colSeguro").Value & "|"
                        strSQL &= dgDetalle.Rows(i).Cells("colDAI").Value & "|"
                        strSQL &= dgDetalle.Rows(i).Cells("colIVA").Value & "|"
                        strSQL &= dgDetalle.Rows(i).Cells("colOtros").Value

                        cFunciones.AgregarFila(dgDatosOcultos, strSQL)
                    Next

                    If Me.Tag = "Nuevo" And logInsertar = True Then
                        If ComprobarIngreso() Then

                            If celdaNumero.Text = NO_FILA Then
                                NumDoc = cfun.NuevoId(180)
                                celdaNumero.Text = NumDoc
                                If Not (celdaNumero.Text = NO_FILA) Then
                                    If MsgBox("Year: " & vbTab & celdaAnio.Text & vbCrLf & "Number: " & vbTab & celdaNumero.Text & vbCrLf & vbCrLf & "¿Do you confirm the use of this document number?", vbExclamation + vbYesNo, "Confirm") = vbYes Then
                                        celdaNumero.Text = NumDoc
                                    Else
                                        celdaNumero.Focus()
                                        Exit Try
                                    End If
                                End If
                            End If

                            If celdaNumero.Text > 0 Then

                                GuardarDocumento()
                                GuardarDetalle()
                                GuardarDescargos()
                                GuardarBultos()

                                cFunciones.EscribirRegistro(Tbl_Documentos, clsFunciones.AccEnum.acAdd, , 180, celdaAnio.Text, celdaNumero.Text)

                            End If
                            'MostrarLista()
                            Me.Tag = "Mod"
                            CargarSubDoc()

                        Else
                            Exit Sub
                        End If
                    ElseIf Me.Tag = "Mod" And logEditar = True Then
                        If ComprobarIngreso() Then

                            GuardarDocumento()
                            GuardarDetalle()
                            GuardarDescargos()
                            GuardarBultos()

                            cFunciones.EscribirRegistro(Tbl_Documentos, clsFunciones.AccEnum.acUpdate, , 180, celdaAnio.Text, celdaNumero.Text)

                            'MostrarLista()
                            Me.Tag = "Mod"
                            CargarSubDoc 
                        Else
                            Exit Sub
                        End If

                    End If

                    'End If

            End Select
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Public Sub CargarSubDoc()
        Dim strDoc As String
        strDoc = dgDocumentos.SelectedCells(0).Value

        If dgDocumentos.SelectedCells(2).Value = "SI" Then
            SDoc.SubDocumento = dgDocumentos.SelectedCells(0).Value
            SDoc.Año = CInt(celdaAnio.Text)
            SDoc.Numero = CInt(celdaNumero.Text)
            SDoc.Catalogo = 180
            SDoc.Doc = strDoc
            SDoc.TasaC = celdaTasa.Text
            SDoc.datagrid = dgDatosOcultos
            SDoc.ShowDialog(Me)
        Else
            SDoc.SubDocumento = dgDocumentos.SelectedCells(0).Value
            SDoc.Año = celdaAnio.Text
            SDoc.Numero = celdaNumero.Text
            SDoc.Doc = strDoc
            SDoc.Catalogo = 180
            SDoc.TasaC = celdaTasa.Text
            SDoc.datagrid = dgDatosOcultos
            SDoc.ShowDialog(Me)
        End If

        'If frm.DialogResult = System.Windows.Forms.DialogResult.OK Then
        celdaTasa.Text = SDoc.TasaC
    End Sub
    Private Sub botonCorregir_Click(sender As Object, e As EventArgs) Handles botonCorregir.Click
        Dim mensaje As String
        Dim i As Integer = INT_CERO

        mensaje = MsgBox("Do you want to correct declaration data?", vbYesNo, "Correct data")

        If mensaje = vbYes Then

            dgDetalle.Columns(7).ReadOnly = False
            dgDetalle.Columns(3).ReadOnly = False

            For i = 0 To dgDetalle.Rows.Count - 1
                dgDetalle.Rows(i).Cells("colCantidadDet").Style.BackColor = Color.Aquamarine
                dgDetalle.Rows(i).Cells("colPrecioDet").Style.BackColor = Color.Aquamarine
            Next
        Else
        End If
    End Sub

    Private Sub Encabezado1_ClickNuevo(sender As Object, click As Boolean) Handles Encabezado1.ClickNuevo
        Me.Tag = "Nuevo"
        Dim frm As New frmOption

        If logInsertar = True Then
            LimpiarCampos()

            celdaEmpresa.Text = Sesion.IdEmpresa

            frm.Opciones = "Import Policy |" & "Return (Export) |" & "Transfer"
            frm.Titulo = "Type of statement"
            frm.ShowDialog(Me)
            If frm.DialogResult = System.Windows.Forms.DialogResult.OK Then
                Select Case frm.Seleccion
                    Case 0
                        BarraTitulo1.CambiarTitulo("Import Policy")
                        intTipoDoc = 0
                        CargarDatos(celdaNumero.Text, celdaAnio.Text)
                        MostrarLista(False)
                    Case 1
                        intTipoDoc = 1
                        BarraTitulo1.CambiarTitulo("Refund (re-export)")
                        CargarDatos(celdaNumero.Text, celdaAnio.Text)
                        MostrarLista(False)
                    Case 2
                        intTipoDoc = 2
                        BarraTitulo1.CambiarTitulo("Transfer")
                        MostrarLista(False)
                End Select

            End If

            botonCorregir.Enabled = False

            celdaAnio.Text = cFunciones.AñoMySQL
        Else
            MsgBox("You do not have access to create a new import policy", vbInformation)
        End If
    End Sub


    Private Sub botonProveedor_Click_1(sender As Object, e As EventArgs) Handles botonProveedor.Click
        Dim frm As New frmSeleccionar
        Dim condicion As String = STR_VACIO
        Dim numero As Integer
        Dim anio As Integer
        condicion = " pro_sisemp = {empresa}"
        condicion = Replace(condicion, "{empresa}", Sesion.IdEmpresa)
        Try

            frm.Titulo = "Provider"
            frm.Campos = " pro_codigo Codigo, pro_proveedor Nombre, pro_direccion Direccion, pro_nit NIT, cat_clave Moneda, cat_num IdMoneda, cat_sist TC"
            frm.Tabla = " Proveedores LEFT JOIN Catalogos ON cat_num = pro_moneda"
            frm.FiltroText = "Enter the Name Of the Provider To Filter"
            frm.Filtro = "pro_proveedor"
            frm.Condicion = condicion
            frm.Ordenamiento = "pro_proveedor"

            frm.ShowDialog(Me)

            If frm.DialogResult = System.Windows.Forms.DialogResult.OK Then
                celdaIdProveedor.Text = frm.ListaClientes.SelectedCells(0).Value
                celdaProveedor.Text = frm.ListaClientes.SelectedCells(1).Value
                celdaDireccion.Text = frm.ListaClientes.SelectedCells(2).Value
                celdaNIT.Text = frm.ListaClientes.SelectedCells(3).Value
                celdaMoneda.Text = frm.ListaClientes.SelectedCells(4).Value
                celdaIdMoneda.Text = frm.ListaClientes.SelectedCells(5).Value
                celdaTasa.Text = frm.ListaClientes.SelectedCells(6).Value

                NuevosDatosPoliza(celdaIdProveedor.Text)
                NuevoDetalle(celdaIdProveedor.Text)
                AgregarAlDetalle()
                celdaUsuario.Text = Sesion.Usuario
                If dgPolizaImportacion.Rows.Count = 0 Then Exit Sub
                numero = dgPolizaImportacion.Rows(0).Cells("colNumeroP").Value
                anio = dgPolizaImportacion.Rows(0).Cells("colAnioP").Value
                CargarReferencia(numero, anio)
            End If

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub dgPolizaImportacion_CellContentClick(sender As Object, e As DataGridViewCellEventArgs) Handles dgPolizaImportacion.CellContentClick
        Dim Numero As Integer
        Dim anio As Integer

        Numero = dgPolizaImportacion.Rows(e.RowIndex).Cells("colNumeroP").Value
        anio = dgPolizaImportacion.Rows(e.RowIndex).Cells("colAnioP").Value
        CargarReferencia(Numero, anio)
    End Sub
    Private Sub botonMenos_Click(sender As Object, e As EventArgs) Handles botonMenos.Click
        botonMenos.Enabled = False
        Dim Numero As Integer
        Dim anio As Integer
        Me.dgPolizaImportacion.Rows.Remove(dgPolizaImportacion.CurrentRow)
        dgDetalle.Rows.Clear()
        NuevoDetalle(celdaIdProveedor.Text)
        AgregarAlDetalle()

        ' Limpia campos
        celdaFactura.Clear()
        celdaRef1.Clear()
        celdaRef2.Clear()
        celdaCosteo.Clear()
        celdaFlete.Clear()
        celdaSeguro.Clear()

        Numero = dgPolizaImportacion.CurrentRow.Cells("colNumeroP").Value
        anio = dgPolizaImportacion.CurrentRow.Cells("colAnioP").Value
        CargarReferencia(Numero, anio)
        botonMenos.Enabled = True
    End Sub

    Private Sub dgDetalle_CellEndEdit(sender As Object, e As DataGridViewCellEventArgs) Handles dgDetalle.CellEndEdit
        Dim dblValAduanal As Double = 0
        Select Case dgDetalle.CurrentCell.ColumnIndex
            Case 8
                dgDetalle.SelectedCells(8).Value = (CDbl(dgDetalle.SelectedCells(3).Value) * CDbl(dgDetalle.SelectedCells(7).Value))
                CalcularTotales()
            Case 15
                dgDetalle.SelectedCells(20).Value = (CDbl(dgDetalle.SelectedCells(15).Value) + CDbl(dgDetalle.SelectedCells(16).Value) + CDbl(dgDetalle.SelectedCells(17).Value) + CDbl(dgDetalle.SelectedCells(18).Value) + CDbl(dgDetalle.SelectedCells(19).Value))
                If Sesion.idGiro = 2 Then
                    dblValAduanal = Math.Round(CDbl(dgDetalle.SelectedCells(20).Value) / CDbl(dgDetalle.SelectedCells(7).Value) + 0.0000000001, 5)
                Else
                    dblValAduanal = (CDbl(dgDetalle.SelectedCells(20).Value) / CDbl(dgDetalle.SelectedCells(7).Value)).ToString(FORMATO_MONEDA)
                End If

                If celdaCosteo.Text = "CIF" Then
                    dgDetalle.SelectedCells(21).Value = dblValAduanal
                Else
                    dgDetalle.SelectedCells(21).Value = dblValAduanal + 0.01
                End If
                CalcularTotales()
            Case 16
                dgDetalle.SelectedCells(20).Value = (CDbl(dgDetalle.SelectedCells(15).Value) + CDbl(dgDetalle.SelectedCells(16).Value) + CDbl(dgDetalle.SelectedCells(17).Value) + CDbl(dgDetalle.SelectedCells(18).Value) + CDbl(dgDetalle.SelectedCells(19).Value))
                If Sesion.idGiro = 2 Then
                    dblValAduanal = Math.Round(CDbl(dgDetalle.SelectedCells(20).Value) / CDbl(dgDetalle.SelectedCells(7).Value) + 0.0000000001, 5)
                Else
                    dblValAduanal = (CDbl(dgDetalle.SelectedCells(20).Value) / CDbl(dgDetalle.SelectedCells(7).Value)).ToString(FORMATO_MONEDA)
                End If
                If celdaCosteo.Text = "CIF" Then
                    dgDetalle.SelectedCells(21).Value = dblValAduanal
                Else
                    dgDetalle.SelectedCells(21).Value = dblValAduanal + 0.01
                End If
                CalcularTotales()
            Case 17
                dgDetalle.SelectedCells(20).Value = (CDbl(dgDetalle.SelectedCells(15).Value) + CDbl(dgDetalle.SelectedCells(16).Value) + CDbl(dgDetalle.SelectedCells(17).Value) + CDbl(dgDetalle.SelectedCells(18).Value) + CDbl(dgDetalle.SelectedCells(19).Value))
                If Sesion.idGiro = 2 Then
                    dblValAduanal = Math.Round(CDbl(dgDetalle.SelectedCells(20).Value) / CDbl(dgDetalle.SelectedCells(7).Value) + 0.0000000001, 5)
                Else
                    dblValAduanal = (CDbl(dgDetalle.SelectedCells(20).Value) / CDbl(dgDetalle.SelectedCells(7).Value)).ToString(FORMATO_MONEDA)
                End If
                If celdaCosteo.Text = "CIF" Then
                    dgDetalle.SelectedCells(21).Value = dblValAduanal
                Else
                    dgDetalle.SelectedCells(21).Value = dblValAduanal + 0.01
                End If
                CalcularTotales()
            Case 18
                dgDetalle.SelectedCells(20).Value = (CDbl(dgDetalle.SelectedCells(15).Value) + CDbl(dgDetalle.SelectedCells(16).Value) + CDbl(dgDetalle.SelectedCells(17).Value) + CDbl(dgDetalle.SelectedCells(18).Value) + CDbl(dgDetalle.SelectedCells(19).Value))
                If Sesion.idGiro = 2 Then
                    dblValAduanal = Math.Round(CDbl(dgDetalle.SelectedCells(20).Value) / CDbl(dgDetalle.SelectedCells(7).Value) + 0.0000000001, 5)
                Else
                    dblValAduanal = (CDbl(dgDetalle.SelectedCells(20).Value) / CDbl(dgDetalle.SelectedCells(7).Value)).ToString(FORMATO_MONEDA)
                End If
                If celdaCosteo.Text = "CIF" Then
                    dgDetalle.SelectedCells(21).Value = dblValAduanal
                Else
                    dgDetalle.SelectedCells(21).Value = dblValAduanal + 0.01
                End If
                CalcularTotales()
            Case 19
                dgDetalle.SelectedCells(20).Value = (CDbl(dgDetalle.SelectedCells(15).Value) + CDbl(dgDetalle.SelectedCells(16).Value) + CDbl(dgDetalle.SelectedCells(17).Value) + CDbl(dgDetalle.SelectedCells(18).Value) + CDbl(dgDetalle.SelectedCells(19).Value))
                If Sesion.idGiro = 2 Then
                    dblValAduanal = Math.Round(CDbl(dgDetalle.SelectedCells(20).Value) / CDbl(dgDetalle.SelectedCells(7).Value) + 0.0000000001, 5)
                Else
                    dblValAduanal = (CDbl(dgDetalle.SelectedCells(20).Value) / CDbl(dgDetalle.SelectedCells(7).Value)).ToString(FORMATO_MONEDA)
                End If
                If celdaCosteo.Text = "CIF" Then
                    dgDetalle.SelectedCells(21).Value = dblValAduanal
                Else
                    dgDetalle.SelectedCells(21).Value = dblValAduanal + 0.01
                End If
                CalcularTotales()
            Case 20
                dgDetalle.SelectedCells(20).Value = (CDbl(dgDetalle.SelectedCells(15).Value) + CDbl(dgDetalle.SelectedCells(16).Value) + CDbl(dgDetalle.SelectedCells(17).Value) + CDbl(dgDetalle.SelectedCells(18).Value) + CDbl(dgDetalle.SelectedCells(19).Value))
                If Sesion.idGiro = 2 Then
                    dblValAduanal = Math.Round(CDbl(dgDetalle.SelectedCells(20).Value) / CDbl(dgDetalle.SelectedCells(7).Value) + 0.0000000001, 5)
                Else
                    dblValAduanal = (CDbl(dgDetalle.SelectedCells(20).Value) / CDbl(dgDetalle.SelectedCells(7).Value)).ToString(FORMATO_MONEDA)
                End If
                If celdaCosteo.Text = "CIF" Then
                    dgDetalle.SelectedCells(21).Value = dblValAduanal
                Else
                    dgDetalle.SelectedCells(21).Value = dblValAduanal + 0.01
                End If
                CalcularTotales()
        End Select


    End Sub
    Private Function NuevaPolizaImp() As Integer
        Dim strSQL As String = STR_VACIO
        Dim conec As New MySqlConnection
        Dim COM As MySqlCommand
        Dim CodigoProyecto As Integer

        strSQL = " Select IFNULL(MAX(HDR.HDoc_Doc_Num),0)+1 NUMERO  "
        strSQL &= " FROM Dcmtos_HDR HDR"
        strSQL &= " WHERE HDR.HDoc_Sis_Emp = {empresa} And HDR.HDoc_Doc_Cat = {catalogo}  "

        strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
        strSQL = Replace(strSQL, "{catalogo}", 180)

        conec = New MySqlConnection(strConexion)
        conec.Open()
        COM = New MySqlCommand(strSQL, conec)
        CodigoProyecto = COM.ExecuteScalar
        conec.Close()
        conec.Dispose()
        conec = Nothing
        System.GC.Collect()
        Return CodigoProyecto
    End Function
    Private Sub Encabezado1_ClickGuardar(sender As Object, click As Boolean) Handles Encabezado1.ClickGuardar
        If Me.Tag = "Mod" Then
            If Sesion.idGiro = 1 And cfun.ValidaFacturaVenta(180, celdaAnio.Text, celdaNumero.Text) Then
                If AutorizarGuardar() = False Then
                    Exit Sub
                End If
            End If
        End If
        Dim NumDoc As Integer
        Try

            If EsReferenciaValida() Then
                If Not EsPolizaValida() Then
                    Exit Sub
                End If
            Else
                logConsultar = True
                Exit Sub
            End If

            If Me.Tag = "Nuevo" And logInsertar = True Then
                If ComprobarIngreso() Then

                    If celdaNumero.Text = NO_FILA Then
                        NumDoc = NuevaPolizaImp()
                        celdaNumero.Text = NumDoc
                        If Not (celdaNumero.Text = NO_FILA) Then
                            If MsgBox("Year: " & vbTab & celdaAnio.Text & vbCrLf & "Number: " & vbTab & celdaNumero.Text & vbCrLf & vbCrLf & "¿Do you confirm the use of this document number?", vbExclamation + vbYesNo, "Confirm") = vbYes Then
                                celdaNumero.Text = NumDoc
                            Else
                                celdaNumero.Focus()
                                Exit Try
                            End If
                        End If
                    Else
                        If VerificarPoliza() = INT_UNO Then
                            MsgBox("The Number Already Exist")
                            Exit Sub
                        End If
                    End If
                    If Sesion.idGiro = 2 Then
                    Else
                        If celdaNumero.Text > 0 Then
                            If intTipoDoc = INT_CERO Then
                                For i As Integer = 0 To dgDetalle.Rows.Count - 1
                                    If ValidarDescargoPO(dgDetalle.Rows(i).Cells("colAño").Value, dgDetalle.Rows(i).Cells("colNum").Value, dgDetalle.Rows(i).Cells("colLinDPoliza").Value) > INT_CERO Then
                                        MsgBox("Shipment confirmation is not related to any PO. (Review discharge line " & i + 1 & ")")
                                        Exit Sub
                                    End If
                                Next
                            End If
                        End If
                    End If
                    GuardarDocumento()
                    GuardarDetalle()
                    GuardarDescargos()
                    GuardarBultos()
                    ' cFunciones.EscribirRegistro(Tbl_Documentos, IIf(Me.Tag = "Nuevo", clsFunciones.AccEnum.acAdd, clsFunciones.AccEnum.acUpdate), , celdaCatalogo.Text, celdaAnio.Text, celdaNumero.Text)
                    cFunciones.EscribirRegistro(Tbl_Documentos, clsFunciones.AccEnum.acAdd, , 180, celdaAnio.Text, celdaNumero.Text)
                    MostrarLista()
                Else
                    Exit Sub
                End If

            ElseIf Me.Tag = "Mod" And logEditar = True Then
                If cfun.SQLVerificarCierre(180, celdaAnio.Text, celdaNumero.Text) = 0 Then
                    GuardarModificacion()
                Else
                    'Si hay cierre solicita autorización para modificar
                    MsgBox("You need authorization to modify this document", vbInformation, "Notice")
                    If cfun.AutorizarCambios = True Then
                        cfun.EscribirRegistro(Tbl_Documentos, clsFunciones.AccEnum.acConfirm,, 180, celdaAnio.Text, celdaNumero.Text, "Autorizó la Modificación")
                        GuardarModificacion()
                    End If
                End If

            Else
                MsgBox("You do not have access to carry out this action in the Import Policy", vbInformation)
            End If

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub GuardarModificacion()
        If ComprobarIngreso() Then

            GuardarDocumento()
            GuardarDetalle()
            GuardarDescargos()
            GuardarBultos()

            'cFunciones.EscribirRegistro(Tbl_Documentos, IIf(Me.Tag = "Nu", clsFunciones.AccEnum.acUpdate, clsFunciones.AccEnum.acUpdate), , celdaCatalogo.Text, celdaAnio.Text, celdaNumero.Text)
            cFunciones.EscribirRegistro(Tbl_Documentos, clsFunciones.AccEnum.acUpdate, , 180, celdaAnio.Text, celdaNumero.Text)

            Me.Tag = "Mod"

            MostrarLista()
        Else
            Exit Sub
        End If
    End Sub

    Private Sub botonProveedorE_Click(sender As Object, e As EventArgs) Handles botonProveedorE.Click
        Dim strRemplazo As String = STR_VACIO
        Dim frm As New frmSeleccionar
        Dim strFila As String = STR_VACIO

        strRemplazo = "p.pro_sisemp = {empresa}"
        strRemplazo = Replace(strRemplazo, "{empresa}", Sesion.IdEmpresa)

        Try

            frm.Titulo = "Providers"
            frm.Campos = "p.pro_codigo id, p.pro_proveedor Proveedor"
            frm.Tabla = "Proveedores p"
            frm.FiltroText = "Enter the provider to filter"
            frm.Filtro = "p.pro_proveedor"
            frm.Ordenamiento = "p.pro_proveedor"
            frm.TipoOrdenamiento = ""
            frm.Condicion = strRemplazo

            frm.ShowDialog(Me)

            If frm.DialogResult = System.Windows.Forms.DialogResult.OK Then
                celdaProveedorE.Text = frm.Dato
            End If

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub botonMoneda_Click(sender As Object, e As EventArgs) Handles botonMoneda.Click
        Dim frm As New frmSeleccionar

        Try
            frm.Titulo = "Coin"
            frm.Campos = "c.cat_clave Moneda, c.cat_num ID, c.cat_sist"
            frm.Tabla = "Catalogos c"
            frm.FiltroText = " Enter the Coin To filter"
            frm.Filtro = " c.cat_clave "
            frm.Limite = 5
            frm.Ordenamiento = " c.cat_clave "
            frm.TipoOrdenamiento = ""
            frm.Condicion = "cat_clase='Monedas'"

            frm.ShowDialog(Me)

            If frm.DialogResult = System.Windows.Forms.DialogResult.OK Then
                celdaMoneda.Text = frm.LLave
                celdaIdMoneda.Text = frm.Dato
                If frm.Dato2 > 1 Then
                    celdaTasa.Text = cFunciones.TasaSegunFecha(dtpFecha.Value.ToString(FORMATO_MYSQL))
                Else
                    celdaTasa.Text = frm.Dato2
                End If
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub



    Private Sub dtpFecha_ValueChanged(sender As Object, e As EventArgs) Handles dtpFecha.ValueChanged
        celdaDate.Text = dtpFecha.Value.ToString(FORMATO_MYSQL)
        If celdaTasa.Text > 1 Then
            celdaTasa.Text = cFunciones.TasaSegunFecha(dtpFecha.Value.ToString(FORMATO_MYSQL))
        End If
    End Sub


    Private Sub dgDetalle_DoubleClick(sender As Object, e As EventArgs) Handles dgDetalle.DoubleClick
        Try
            Select Case dgDetalle.CurrentCell.ColumnIndex
                Case 8
                    Dim strTitulo As String
                    Dim strMsg As String
                    Dim dblMonto As Double
                    Dim ValorDato As String
                    Dim valorTotal As Double

                    strTitulo = "Adjust Total"
                    strMsg = "This process will adjust the total line of the import policy." & vbCrLf & vbCrLf & "This change does not affect the unit value and will only be reflected in some reports."
                    dblMonto = dgDetalle.SelectedCells(8).Value

                    ValorDato = InputBox(strMsg, strTitulo, dblMonto)

                    If Not (ValorDato = vbNullString) Then
                        ValorDato = Trim(ValorDato)
                        If Not (ValorDato = vbNullString) Then
                            If IsNumeric(ValorDato) Then
                                valorTotal = Math.Round(Val(ValorDato), 2)
                                If MsgBox("Do you confirm the change of the total?" & vbCrLf & vbCrLf & "New Total: " & valorTotal, vbQuestion + vbYesNo, "Confirm") = vbYes Then
                                    dgDetalle.SelectedCells(8).Value = valorTotal
                                End If
                            End If
                        End If
                    End If
            End Select
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub
    Private Sub dgLista_CellContentClick(sender As Object, e As DataGridViewCellEventArgs) Handles dgLista.CellContentClick

    End Sub

    Private Sub dgLista_KeyDown(sender As Object, e As KeyEventArgs) Handles dgLista.KeyDown
        Try
            If e.KeyCode = Keys.F3 Then
                cfun.BuscarenLista(dgLista)
                e.Handled = True
                e.SuppressKeyPress = True
            ElseIf e.KeyCode = Keys.F6 Then
                cfun.MostrarDependencias(180, dgLista.SelectedCells(5).Value, dgLista.SelectedCells(0).Value)
            ElseIf e.KeyCode = Keys.F7 Then
                Dim rpt As New clsReportes
                rpt.Historial(dgLista.SelectedCells(0).Value, dgLista.SelectedCells(5).Value, 180)
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub dgPolizaImportacion_SelectionChanged(sender As Object, e As EventArgs) Handles dgPolizaImportacion.SelectionChanged
        Dim Numero As Integer
        Dim anio As Integer

        If dgPolizaImportacion.Rows.Count > 1 Then

            Numero = dgPolizaImportacion.CurrentRow.Cells("colNumeroP").Value
            anio = dgPolizaImportacion.CurrentRow.Cells("colAnioP").Value
            CargarReferencia(Numero, anio)
        End If

    End Sub

    Private Sub Encabezado1_Load(sender As Object, e As EventArgs)

    End Sub

    Private Sub dgDocumentos_CellContentClick(sender As Object, e As DataGridViewCellEventArgs) Handles dgDocumentos.CellContentClick

    End Sub

    Private Sub dgDocumentos_DataMemberChanged(sender As Object, e As EventArgs) Handles dgDocumentos.DataMemberChanged

    End Sub

    Private Sub Encabezado1_ClickBorrar(sender As Object, click As Boolean) Handles Encabezado1.ClickBorrar
        If LogBorrar = True Then
            If DependeciasIngreso() > INT_CERO Then
                MsgBox("This Document can not be canceled, is related to other agencies", MsgBoxStyle.Critical, "Warning")
                cfun.MostrarDependencias(180, celdaAnio.Text, celdaNumero.Text)

            ElseIf DependeciasFacturaCompra() > INT_CERO Then
                MsgBox("This Document can not be canceled, is related to other agencies", MsgBoxStyle.Critical, "Warning")
                cfun.MostrarDependencias(180, celdaAnio.Text, celdaNumero.Text)
            Else
                If MsgBox("Are You sure " & vbCr & vbCr & "¿do you want to delete this document? ", vbQuestion + vbYesNo, "Aviso") = vbYes Then
                    BorrarEncabezadoPoliza()
                    BorrarDetallePoliza()
                    BorrarAccPoliza()
                    BorrarDescargosPoliza()
                    BorrarDecPoliza()
                    cFunciones.EscribirRegistro(Tbl_Documentos, clsFunciones.AccEnum.acDelete, , 180, celdaAnio.Text, celdaNumero.Text)
                    MsgBox("Delete Complete")
                    MostrarLista()
                End If
            End If
        End If
    End Sub

    Private Sub dgPolizaImportacion_DoubleClick(sender As Object, e As EventArgs) Handles dgPolizaImportacion.DoubleClick
        If Me.Tag = "Mod" Then
            botonMenos.Enabled = False
        Else
            Dim strFila As String = STR_VACIO
            Dim numero As Integer = 0
            Dim anio As Integer = 0
            dgPolizaImportacion.CurrentRow.Cells("colExtra").Value = 2
            For i As Integer = 0 To dgPolizaImportacion.Rows.Count - 1
                If dgPolizaImportacion.Rows.Count = 1 Then
                ElseIf dgPolizaImportacion.Rows(i).Cells("colExtra").Value = 2 Then
                    dgPolizaImportacion.CurrentRow.Cells("colExtra").Value = 0
                    strFila = dgPolizaImportacion.Rows(i).Cells("colNumeroP").Value & "|" & dgPolizaImportacion.Rows(i).Cells("colFechaP").Value & "|" & dgPolizaImportacion.Rows(i).Cells("colOperadorP").Value & "|" & dgPolizaImportacion.Rows(i).Cells("colReferenciaP").Value & "|" & dgPolizaImportacion.Rows(i).Cells("colAnioP").Value & "|" & dgPolizaImportacion.Rows(i).Cells("colCatalogoP").Value & "|" & dgPolizaImportacion.Rows(i).Cells("colExtra").Value
                End If
            Next
            dgPolizaImportacion.Rows.Clear()
            cFunciones.AgregarFila(dgPolizaImportacion, strFila)

            dgDetalle.Rows.Clear()
            NuevoDetalle(celdaIdProveedor.Text)
            AgregarAlDetalle()
            celdaUsuario.Text = Sesion.Usuario
            numero = dgPolizaImportacion.Rows(0).Cells("colNumeroP").Value
            anio = dgPolizaImportacion.Rows(0).Cells("colAnioP").Value
            CargarReferencia(numero, anio)
        End If
    End Sub

    Private Sub botonImprimir_Click(sender As Object, e As EventArgs) Handles botonImprimir.Click
        Dim rpt As New clsReportes
        rpt.ReporteInspeccionDeEntradas(1, celdaAnio.Text, celdaNumero.Text)
    End Sub

    Private Sub botonGuardarCetificado_Click(sender As Object, e As EventArgs) Handles botonGuardarCetificado.Click
        If Me.Tag = "Mod" Then
            ActualizarCertificado()
        End If
    End Sub

    Private Function ActualizarCertificado() As Boolean
        Dim logGuardar As Boolean
        Dim strSQL As String = STR_VACIO
        Dim COM As MySqlCommand
        Try
            strSQL = " UPDATE  Dcmtos_HDR h SET h.HDOC_RF1_COD = '{certificado}'  WHERE h.HDoc_Sis_Emp = {empresa} AND h.HDoc_Doc_Cat = {catalogo} AND h.HDoc_Doc_Ano = {anio} AND h.HDoc_Doc_Num = {numero}"
            strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
            strSQL = Replace(strSQL, "{catalogo}", celdaCatalogo.Text)
            strSQL = Replace(strSQL, "{anio}", celdaAnio.Text)
            strSQL = Replace(strSQL, "{numero}", celdaNumero.Text)
            strSQL = Replace(strSQL, "{certificado}", celdaCertificado.Text)
            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSQL, CON)
            COM.ExecuteNonQuery()
            COM = Nothing
            logGuardar = True
            MsgBox("Update successful. Don't click on save button.")
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        Return logGuardar
    End Function

    ' Valida al momento de Editar
    Public Function AutorizarGuardar() As Boolean
        Const STR_MARGEN As String = "MOD_POLIZA_IMPORT"
        Dim frm As New frmAutorización
        AutorizarGuardar = False
        frm.Iniciar(180, STR_MARGEN, 0, "Authorize Edit")
        frm.ShowDialog(Me)
        If frm.Aceptado Then
            AutorizarGuardar = True
        End If
    End Function
#End Region

End Class