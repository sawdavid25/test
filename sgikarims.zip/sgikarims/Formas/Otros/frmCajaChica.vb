﻿Imports System.ComponentModel

Public Class frmCajaChica
#Region "Miembros"
    Dim strKey As String = STR_VACIO
    Dim logInsertar As Boolean = False
    Dim logConsultar As Boolean = False
    Dim logEditar As Boolean = False
    Dim LogBorrar As Boolean = False
    Dim cfun As New clsFunciones
    Dim Extemporaneo As Boolean = False
    Dim ModCelda As Boolean = False

#End Region

#Region "Propiedades"
    Public Property Key As String
        Get
            Return strKey
        End Get
        Set(value As String)
            strKey = value
        End Set
    End Property
#End Region

#Region "Procedimientos"
    Private Sub BloquearBotones(Optional ByVal logBloquear As Boolean = True)
        If logBloquear = True Then
            Encabezado1.botonBorrar.Enabled = False
            Encabezado1.botonGuardar.Enabled = False
            botonActualizar.Enabled = False
        Else
            Encabezado1.botonBorrar.Enabled = True
            Encabezado1.botonGuardar.Enabled = True
            botonActualizar.Enabled = True

        End If
    End Sub
    Private Sub Accesos()
        Dim cAccesos As New clsAccesos
        Try
            If cAccesos.Accesos(strKey) = True Then
                logInsertar = cAccesos.Insertar
                logConsultar = cAccesos.Consultar
                logEditar = cAccesos.Editar
                LogBorrar = cAccesos.Borrar
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub


    Private Function ObtenerLinea(ByVal intAnio As Integer, ByVal intNumero As Integer)
        Dim Linea As Integer = INT_CERO
        Dim COM As New MySqlCommand
        Dim conec As MySqlConnection
        Dim strSQL As String = STR_VACIO

        Try
            strSQL = "SELECT IFNULL(MAX(d.DDoc_Doc_Lin + 1),1) Linea"
            strSQL &= "      FROM Dcmtos_DTL d"
            strSQL &= "              WHERE d.DDoc_Sis_Emp = {empresa} and d.DDoc_Doc_Cat = {cat} and d.DDoc_Doc_Ano = {anio} and d.DDoc_Doc_Num = {numero}"

            strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
            strSQL = Replace(strSQL, "{cat}", celdadetalleIDDocumento.Text)
            strSQL = Replace(strSQL, "{anio}", intAnio)
            strSQL = Replace(strSQL, "{numero}", intNumero)

            conec = New MySqlConnection(strConexion)
            conec.Open()
            COM = New MySqlCommand(strSQL, conec)
            Linea = COM.ExecuteScalar
            conec.Close()
            conec.Dispose()
            conec = Nothing
            System.GC.Collect()

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try

        Return Linea
    End Function

    Private Function NuevoIdCaja()
        Dim strSQL As String = STR_VACIO
        Dim idCaja As Integer = INT_CERO
        Dim COM As New MySqlCommand
        Dim conec As MySqlConnection

        Try

            strSQL = " Select IFNULL(max(BCta_Num),0) + 1 as Nuevo FROM CtasBcos "

            conec = New MySqlConnection(strConexion)
            conec.Open()
            COM = New MySqlCommand(strSQL, conec)
            idCaja = COM.ExecuteScalar
            conec.Close()
            conec.Dispose()
            conec = Nothing
            System.GC.Collect()

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try

        Return idCaja
    End Function

    Private Sub BorrarEncabezadoDoc()
        Try
            Dim hdr As New clsDcmtos_HDR
            hdr.CONEXION = strConexion
            hdr.HDOC_SIS_EMP = Sesion.IdEmpresa
            hdr.HDOC_DOC_CAT = celdadetalleIDDocumento.Text
            hdr.HDOC_DOC_ANO = celdaDetalleAnio.Text
            hdr.HDOC_DOC_NUM = celdaNumeroHDR.Text
            hdr.Borrar()
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub BorrarDetalleDoc()
        Try
            If LogBorrar = True Then
                For i = 0 To dgDetalleDocumento.Rows.Count - 1
                    Dim dtl As New clsDcmtos_DTL
                    dtl.CONEXION = strConexion
                    dtl.DDOC_SIS_EMP = Sesion.IdEmpresa
                    dtl.DDOC_DOC_CAT = celdadetalleIDDocumento.Text
                    dtl.DDOC_DOC_ANO = celdaDetalleAnio.Text
                    dtl.DDOC_DOC_NUM = celdaNumeroHDR.Text
                    dtl.DDOC_DOC_LIN = dgDetalleDocumento.Rows(i).Cells("colLineaD").Value
                    dtl.Borrar()
                Next
            Else
                MsgBox("You don't have permission to this access")
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub BorrarImpuestosDoc()
        Dim strSQL As String = STR_VACIO
        Try
            Dim imp As New Tablas.TDCMTOS_IMP
            imp.CONEXION = strConexion
            strSQL = " MDoc_Sis_Emp = {empresa}  AND MDoc_Doc_Cat = {cat} AND MDoc_Doc_Ano = {anio} AND MDoc_Doc_Num = {numero} "
            strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
            strSQL = Replace(strSQL, "{anio}", celdaDetalleAnio.Text)
            strSQL = Replace(strSQL, "{numero}", celdaNumeroHDR.Text)
            strSQL = Replace(strSQL, "{cat}", celdadetalleIDDocumento.Text)
            imp.PDELETE(strSQL)

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub BorrarMovimientoBancario()
        Dim strSQL As String = STR_VACIO
        Try
            Dim bancos As New Tablas.TMVTOSBCOS
            bancos.CONEXION = strConexion
            strSQL = "BMov_Sis_Emp = {empresa}  AND BMov_Cat_Doc = {cat} AND BMov_Doc_Ano = {anio} AND BMov_Doc_Num = {numero} "
            strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
            strSQL = Replace(strSQL, "{anio}", celdaDetalleAnio.Text)
            strSQL = Replace(strSQL, "{numero}", celdaNumeroHDR.Text)
            strSQL = Replace(strSQL, "{cat}", celdadetalleIDDocumento.Text)
            bancos.PDELETE(strSQL)
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub GuardarCaja(ByVal intTipoCaja As Integer)
        Dim ban As New Tablas.TCTASBCOS

        Try
            ban.CONEXION = strConexion

            ban.BCTA_SIS_EMP = Sesion.IdEmpresa
            ban.BCTA_NUM = celdaCodigo.Text
            ' Tipo de Caja 1 = Caja Chica, 2 = Viaticos, 3 = Tarjeta de crédito
            ban.BCTA_TIPO = celdaTipoCaja.Text
            ban.BCTA_COD_BAN = INT_CERO
            ban.BCTA_CNT_BAN = STR_VACIO
            ban.BCTA_NUM_CUE = celdaCodigo.Text
            ban.BCTA_NOM_CUE = celdaResponsable.Text
            ban.BCTA_DES_CUE = celdaDescripcion.Text
            ban.BCTA_TIP_CUE = "Caja"
            ban.BCTA_SOB_AUT = INT_CERO
            ban.BCTA_SOB_PLZ = INT_CERO
            ban.BCTA_MON = celdaidMoneda.Text
            ban.BCTA_CUENTA = celdaCuenta.Text
            If checkInactivarCaja.Checked = True Then
                ban.BCTA_STATUS = INT_UNO
            Else
                ban.BCTA_STATUS = INT_CERO
            End If
            If Me.Tag = "Nuevo" Then
                If ban.PINSERT() = False Then
                    MsgBox(ban.MERROR.ToString & "Could not save the document", MsgBoxStyle.Critical)
                End If
            Else
                If ban.PUPDATE() = False Then
                    MsgBox(ban.MERROR.ToString & "Could not update the document", MsgBoxStyle.Critical)
                End If
            End If


        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try

    End Sub
    Public Sub ProcesoGuardarCajaChica()
        If panelDocumento.Visible = True Then 'ingreso de documentos
            Dim LogVerificar As Boolean = False
            Dim TotalImport As Double
            Dim conta As New clsContabilidad

            If logEditar = True Or Me.Tag = "Nuevo" Then

                If VerificaBloqueo() = 1 Then
                    If celdadetalleIDDocumento.Text = 44 Then ' Verifica que la factura no tenga marcado pequeño contribuyente junto con facura eliectrónica
                        ' Tambien verific que la factura no esté en el libro de compras (cuando ya es modificacion)
                        If checkFacElectrónica.Checked = True And checkContribuyent.Checked = True Then
                            MsgBox("The electronic invoice does not apply to small taxpayers", vbInformation, "Notice")
                        Else
                            LogVerificar = True
                        End If

                        If Me.Tag = "Mod" Then
                            If EnLibroCompras(celdaDetalleAnio.Text, celdaNumeroHDR.Text, True, "Nota: No se permiten modificaciones") = True Then
                            Else
                                LogVerificar = True
                            End If
                        End If

                    Else
                        LogVerificar = True
                    End If

                    If LogVerificar = True Then
                        If ComprobarIngreso() = True Then
                            GuardarHDR()
                            GuardarDTL()
                            GuardarMovimiento()

                            'If celdadetalleIDDocumento.Text = 44 Then
                            GuardarImpuestos()
                                If Me.Tag = "Nuevo" Then
                                    If cfun.SQLVerificarCierre(celdadetalleIDDocumento.Text, celdaDetalleAnio.Text, celdaNumeroHDR.Text) = 0 Then
                                        conta.GenerarPoliza(celdadetalleIDDocumento.Text, celdaDetalleAnio.Text, celdaNumeroHDR.Text, dtpFechaPolizaC.Value.ToString(FORMATO_MYSQL))
                                    Else
                                        If Year(dtpDetalleFecha.Value) <> Year(Now) Then
                                            conta.GenerarPoliza(celdadetalleIDDocumento.Text, celdaDetalleAnio.Text, celdaNumeroHDR.Text, dtpFechaPolizaC.Value.ToString(FORMATO_MYSQL))
                                        Else
                                            conta.GenerarPoliza(celdadetalleIDDocumento.Text, celdaDetalleAnio.Text, celdaNumeroHDR.Text, dtpFechaPolizaC.Value.ToString(FORMATO_MYSQL))
                                        End If
                                    End If
                                End If
                            'End If
                            cFunciones.EscribirRegistro("Dcmtos_HDR", IIf(Me.Tag = "Nuevo", clsFunciones.AccEnum.acAdd, clsFunciones.AccEnum.acUpdate), celdaNumeroCaja.Text, celdadetalleIDDocumento.Text, celdaDetalleAnio.Text, celdaNumeroHDR.Text)
                            MsgBox("Document successfully saved", vbInformation, "Notice")
                            CargarDocumentosCajaChica(celdaNumeroCaja.Text)
                            SaldoCaja(celdaNumeroCaja.Text)
                            MostrarLista(1)
                        End If
                    End If

                Else
                    MsgBox(" At this time you can not enter invoices, please contact the Financial Department", vbInformation, "Notice")
                End If
            Else
                MsgBox("You do not have access to edit this document", vbInformation)
            End If

        ElseIf panelDetalleCaja.Visible = True Then ' ingreso de nueva caja chica
            If ComprobarCuenta() = True Then

                If Me.Tag = "Nuevo" Then
                    celdaCodigo.Text = NuevoIdCaja()
                End If

                If celdaCodigo.Text > 0 Then
                    GuardarCaja(celdaTipoCaja.Text)
                    PermisoCaja(celdaCodigo.Text)
                    cFunciones.EscribirRegistro("Ctas_Bcos", IIf(Me.Tag = "Nuevo", clsFunciones.AccEnum.acAdd, clsFunciones.AccEnum.acUpdate), celdaCodigo.Text, 0, Year(Now), celdaCodigo.Text, celdaResponsable.Text)
                    MsgBox("The document has been saved successfully", vbInformation, "Notice")
                    MostrarLista()
                End If
            End If
        End If
    End Sub

    Private Sub PermisoCaja(ByVal Codigo As String)
        Dim strSQL As String = STR_VACIO
        Dim COM As MySqlCommand
        strSQL = " INSERT INTO Permisos (pms_registro,pms_empresa,pms_modulo,pms_usuario,pms_id,pms_codigo,pms_nivel) "
        strSQL &= " VALUES (0,{empresa},13,'{user}',{cod},'ALL',0) "

        strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
        strSQL = Replace(strSQL, "{user}", Sesion.Usuario)
        strSQL = Replace(strSQL, "{cod}", Codigo)
        If Me.Tag = "Nuevo" Then
            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSQL, CON)
            COM.ExecuteNonQuery()
        End If

    End Sub

    Private Sub GuardarHDR()
        Dim hdr As New clsDcmtos_HDR
        Dim intClase As Integer

        Try
            hdr.CONEXION = strConexion
            If celdaNumeroHDR.Text = -1 Then
                celdaNumeroHDR.Text = cFunciones.NuevoId(celdadetalleIDDocumento.Text, celdaDetalleAnio.Text)
            End If

            hdr.HDOC_SIS_EMP = Sesion.IdEmpresa
            hdr.HDOC_DOC_CAT = celdadetalleIDDocumento.Text
            hdr.HDOC_DOC_ANO = celdaDetalleAnio.Text
            hdr.HDOC_DOC_NUM = celdaNumeroHDR.Text
            hdr.HDOC_USUARIO = Sesion.Usuario
            hdr.HDoc_DR2_Fec_NET = dtpFechaPolizaC.Value.ToString(FORMATO_MYSQL)
            hdr.HDoc_Doc_Fec_NET = dtpDetalleFecha.Value.ToString(FORMATO_MYSQL)
            hdr.HDOC_EMP_COD = celdaidProveedor.Text
            hdr.HDOC_EMP_NOM = celdaProveedor.Text
            hdr.HDOC_EMP_PER = IIf(celdaEmisor.Text = vbNullString, " ", celdaEmisor.Text)
            hdr.HDOC_EMP_NIT = celdaDetalleNit.Text
            hdr.HDOC_DOC_TC = celdaDetalleTC.Text
            hdr.HDOC_DOC_MON = celdaDetalleIDMoneda.Text

            If checkFacElectrónica.Checked = True Then
                'Electrónca
                intClase = INT_UNO
            ElseIf checkContribuyent.Checked = True Then
                'Pequeño Contribuyente
                intClase = 2
            Else
                intClase = vbEmpty
            End If

            hdr.HDOC_DR1_CAT = celdaNumeroCaja.Text 'Guarda el numero de caja al que pertence el doc
            hdr.HDOC_DR1_NUM = celdaDetalleNumero.Text

            hdr.HDOC_DR1_DBL = INT_CERO
            hdr.HDoc_DR1_Fec_NET = dtpDetalleFecha.Value.ToString(FORMATO_MYSQL)
            hdr.HDOC_DR1_EMP = intClase

            hdr.HDOC_DR2_CAT = IIf(Extemporaneo, INT_UNO, INT_CERO)
            hdr.HDOC_DR2_NUM = celdaDetalleSerie.Text
            hdr.HDOC_DR2_EMP = IIf(checkContribuyent.Checked = True, INT_CERO, INT_UNO)

            hdr.HDOC_RF1_NUM = INT_CERO
            hdr.HDOC_RF1_DBL = celdaDetalleMonto.Text
            hdr.HDOC_RF1_TXT = celdaNota.Text
            hdr.HDOC_RF2_DBL = celdaDiferencia.Text
            hdr.HDOC_RF2_TXT = celdaLetra.Text

            hdr.HDOC_RF3_DBL = celdaDetalleMonto.Text
            hdr.HDOC_DOC_STATUS = INT_UNO
            hdr.HDOC_ANT_COM = INT_CERO
            hdr.HDOC_DR1_DBL = celdaMontoProd.Text ' total factura afectada con IVA NSM

            If Sesion.idGiro = 2 Or Sesion.IdEmpresa = 11 Then
                hdr.HDOC_RF2_COD = celdaCAI.Text
            End If

            If Me.Tag = "Mod" Then
                If hdr.Actualizar() = False Then
                    MsgBox(hdr.MERROR.ToString & "Could not update the document", MsgBoxStyle.Critical)
                End If
            Else
                If hdr.Guardar() = False Then
                    MsgBox(hdr.MERROR.ToString & "Could not save the document", MsgBoxStyle.Critical)
                End If
            End If

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try

    End Sub
    Private Sub GuardarDTL()
        Dim dtl As New clsDcmtos_DTL

        dtl.CONEXION = strConexion

        For i As Integer = 0 To dgDetalleDocumento.Rows.Count - 1
            'If dgDetalleDocumento.Rows(i).Cells("colExtra").Value = 2 Then
            'Else
            dtl.DDOC_SIS_EMP = Sesion.IdEmpresa
                dtl.DDOC_DOC_CAT = celdadetalleIDDocumento.Text
                dtl.DDOC_DOC_ANO = celdaDetalleAnio.Text
                dtl.DDOC_DOC_NUM = celdaNumeroHDR.Text
                If dgDetalleDocumento.Rows(i).Cells("colExtra").Value = 0 Then
                    dtl.DDOC_DOC_LIN = ObtenerLinea(celdaDetalleAnio.Text, celdaNumeroHDR.Text)
                Else
                    dtl.DDOC_DOC_LIN = dgDetalleDocumento.Rows(i).Cells("colLineaD").Value
                End If
                dtl.DDOC_PRD_COD = INT_CERO
                'dtl.DDOC_PRD_PNR = vbNullString
                dtl.DDOC_PRD_DES = dgDetalleDocumento.Rows(i).Cells("colDescripcionD").Value
                dtl.DDOC_PRD_UM = INT_CERO
                dtl.DDOC_PRD_PUQ = INT_CERO
                dtl.DDOC_PRD_DSP = INT_CERO
                dtl.DDOC_PRD_NET = dgDetalleDocumento.Rows(i).Cells("colPrecioD").Value
                dtl.DDOC_PRD_QTY = dgDetalleDocumento.Rows(i).Cells("colCantidadD").Value
                dtl.DDOC_RF1_NUM = IIf(dgDetalleDocumento.Rows(i).Cells("colClasificacionD").Value = "BIEN", INT_CERO, INT_UNO)
                dtl.DDOC_RF2_NUM = INT_CERO
                dtl.DDOC_RF3_NUM = dgDetalleDocumento.Rows(i).Cells("colidCcosto").Value
                If (Sesion.IdEmpresa = 15) Or (Sesion.IdEmpresa = 18) Or (Sesion.IdEmpresa = 19) Then
                    dtl.DDOC_RF1_TXT = dgDetalleDocumento.Rows(i).Cells("colidCuentaIVA").Value
                    dtl.DDOC_RF3_DBL = dgDetalleDocumento.Rows(i).Cells("colPrecioSinIVA").Value
                Else
                    dtl.DDOC_RF1_TXT = vbNullString
                End If
                dtl.DDOC_RF1_DBL = dgDetalleDocumento.Rows(i).Cells("colTotalD").Value
                'dtl.DDOC_RF2_COD = vbNullString
                dtl.DDOC_RF1_COD = dgDetalleDocumento.Rows(i).Cells("colidGastoD").Value
                If Sesion.idGiro = 1 Then
                    dtl.DDOC_RF2_TXT = dgDetalleDocumento.Rows(i).Cells("idrubro").Value
                    dtl.DDOC_RF3_TXT = dgDetalleDocumento.Rows(i).Cells("idcuenta").Value
                Else
                    dtl.DDOC_RF2_TXT = vbNullString
                End If
                dtl.DDOC_RF2_DBL = INT_CERO
                dtl.DDOC_PRD_CIF = INT_CERO
                dtl.DDOC_PRD_FOB = INT_CERO
            ' dtl.DDOC_PRD_REF = vbNullString


            If dgDetalleDocumento.Rows(i).Cells("colExtra").Value = 1 Then
                If dtl.Actualizar() = False Then
                    MsgBox(dtl.MERROR.ToString & "Could not update the document", MsgBoxStyle.Critical)
                End If
            ElseIf dgDetalleDocumento.Rows(i).Cells("colExtra").Value = 0 Then
                If dtl.Guardar() = False Then
                    MsgBox(dtl.MERROR.ToString & "Could not save the document", MsgBoxStyle.Critical)
                End If
            ElseIf dgDetalleDocumento.Rows(i).Cells("colExtra").Value = 2 Then
                If dtl.Borrar = False Then
                    MsgBox(dtl.MERROR.ToString & "Could not save the document", MsgBoxStyle.Critical)
                End If
            End If

            'End If


        Next

    End Sub
    Private Sub GuardarImpuestos()
        Dim i As Integer
        Dim Imp As New Tablas.TDCMTOS_IMP
        Dim factor As Double

        Imp.CONEXION = strConexion

        Try

            For i = 0 To dgImpuestos.Rows.Count - 1

                Imp.MDOC_SIS_EMP = Sesion.IdEmpresa
                Imp.MDOC_DOC_CAT = celdadetalleIDDocumento.Text
                Imp.MDOC_DOC_ANO = celdaDetalleAnio.Text
                Imp.MDOC_DOC_NUM = celdaNumeroHDR.Text

                Imp.MDOC_DOC_LIN = dgImpuestos.Rows(i).Cells("colLine").Value
                Imp.MDOC_LIN_ID = dgImpuestos.Rows(i).Cells("colID").Value
                Imp.MDOC_LIN_CODIGO = dgImpuestos.Rows(i).Cells("colCodigo1").Value
                Imp.MDOC_LIN_TIPO = Val(dgImpuestos.Rows(i).Cells("colTipo").Value)
                Imp.MDOC_LIN_DESC = dgImpuestos.Rows(i).Cells("colDescripcion1").Value
                Imp.MDOC_LIN_BASE = dgImpuestos.Rows(i).Cells("colBase").Value
                Imp.MDOC_LIN_CANTIDAD = dgImpuestos.Rows(i).Cells("colCantidad1").Value
                factor = Replace(dgImpuestos.Rows(i).Cells("colFactor").Value, "%", "")
                Imp.MDOC_LIN_FACTOR = factor
                Imp.MDOC_LIN_MONTO = dgImpuestos.Rows(i).Cells("colMonto").Value

                ' If Me.Tag = "Mod" Then
                If dgImpuestos.Rows(i).Cells("colOrigen").Value = INT_UNO Then
                    If Imp.PUPDATE = False Then
                        MsgBox(Imp.MERROR.ToString & "Could not update the document", MsgBoxStyle.Critical)
                    End If
                ElseIf dgImpuestos.Rows(i).Cells("colOrigen").Value = INT_CERO Then
                    If Imp.PINSERT = False Then
                        MsgBox(Imp.MERROR.ToString & "Could not update the document", MsgBoxStyle.Critical)
                    End If
                ElseIf dgImpuestos.Rows(i).Cells("colOrigen").Value = 2 Then
                    If Imp.PDELETE = False Then
                        MsgBox(Imp.MERROR.ToString & "Could not delete the document", MsgBoxStyle.Critical)
                    End If
                End If

            Next

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try

    End Sub

    Private Sub ActualizarMovimientosBanco()
        Dim strSQL As String = STR_VACIO
        Dim CargoLcl As Double = 0
        Dim COM As MySqlCommand

        strSQL = " UPDATE MvtosBcos SET BMov_Crgo_Loc = {cargoL}, BMov_Crgo_Ext = {cargoE}, BMov_Num_Doc = '{docNum}', BMov_moneda = {moneda}, BMov_TC= {TC}, BMov_Concepto= '{concepto}' "
        strSQL &= " Where BMov_Cat_Doc = {cat} and BMov_Doc_Ano = {anio} and BMov_Doc_Num = {num}"

        If Sesion.IdEmpresa = 18 Then
            strSQL &= "; UPDATE PDM.MvtosBcos SET BMov_Crgo_Loc = {cargoL}, BMov_Crgo_Ext = {cargoE}, BMov_Num_Doc = '{docNum}', BMov_moneda = {moneda}, BMov_TC= {TC}, BMov_Concepto= '{concepto}' "
            strSQL &= " Where BMov_Cat_Doc = {cat} and BMov_Doc_Ano = {anio} and BMov_Doc_Num = {num}"
        End If

        CargoLcl = Math.Round((celdaDetalleMonto.Text * celdaDetalleTC.Text), 5).ToString(FORMATO_MONEDA)
        strSQL = Replace(strSQL, "{cargoL}", CargoLcl)
        strSQL = Replace(strSQL, "{cargoE}", Math.Round((CargoLcl / celdaDetalleTC.Text), 5))
        strSQL = Replace(strSQL, "{docNum}", celdaDetalleNumero.Text)
        strSQL = Replace(strSQL, "{moneda}", celdaDetalleIDMoneda.Text)
        strSQL = Replace(strSQL, "{TC}", celdaDetalleTC.Text)
        strSQL = Replace(strSQL, "{concepto}", celdaNota.Text)
        strSQL = Replace(strSQL, "{cat}", celdadetalleIDDocumento.Text)
        strSQL = Replace(strSQL, "{anio}", celdaDetalleAnio.Text)
        strSQL = Replace(strSQL, "{num}", celdaNumeroHDR.Text)

        COM = New MySqlCommand(strSQL, CON)
        COM.ExecuteNonQuery()
        COM = Nothing

    End Sub


    Private Sub GuardarMovimiento()
        Dim mov As New Tablas.TMVTOSBCOS
        Dim CargoLcl As Double = 0

        Try

            mov.CONEXION = strConexion

            mov.BMOV_SIS_EMP = Sesion.IdEmpresa
            mov.BMOV_CTA = celdaNumeroCaja.Text 'numero de Caja
            mov.BMov_Fec_NET = dtpDetalleFecha.Value.ToString(FORMATO_MYSQL) 'fecha del doc
            mov.BMOV_DOC_CAT = 52 ' catalgo de Débito (Cargo)
            mov.BMOV_DOC_ANO = celdaDetalleAnio.Text 'Año del doc
            mov.BMOV_DOC_NUM = celdaNumeroHDR.Text ' Numero del doc
            'mov.BMOV_BENEFICIARIO = vbNullString
            mov.BMOV_SINI_LOC = INT_CERO
            CargoLcl = Math.Round((celdaDetalleMonto.Text * celdaDetalleTC.Text), 5).ToString(FORMATO_MONEDA)
            mov.BMOV_CRGO_LOC = CargoLcl
            mov.BMOV_ABNO_LOC = INT_CERO
            mov.BMOV_SINI_EXT = INT_CERO
            mov.BMOV_CRGO_EXT = Math.Round((CargoLcl / celdaDetalleTC.Text), 5).ToString(FORMATO_MONEDA)
            mov.BMOV_ABNO_EXT = INT_CERO
            mov.BMOV_CAT_DOC = celdadetalleIDDocumento.Text 'catalogo del doc
            mov.BMOV_NUM_DOC = CStr(celdaDetalleNumero.Text) ' el numero de la factura que el proveedor entrega
            mov.BMOV_TIPOEMP = "Proveedores"
            mov.BMOV_CODEMP = INT_CERO
            mov.BMOV_MONEDA = celdaDetalleIDMoneda.Text
            mov.BMOV_TC = celdaDetalleTC.Text
            mov.BMOV_CONCEPTO = celdaNota.Text
            mov.BMOV_SALDO = INT_CERO
            mov.BMOV_DIAS_VCTO = INT_CERO

            If Me.Tag = "Mod" Then
                ActualizarMovimientosBanco()
            Else
                If mov.PINSERT = False Then
                    MsgBox(mov.MERROR.ToString & "Could not update the document", MsgBoxStyle.Critical)
                End If
            End If

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try

    End Sub



    Private Sub MostrarLista(Optional ByVal VerPanel As Integer = INT_CERO)

        Select Case VerPanel
            Case 0  ' Muestra Lista Principal
                panelLista.Visible = True
                panelLista.Dock = DockStyle.Fill
                HabilitarBotonPermisos()
                'Encabezado1.botonNuevo.Enabled = True
                Encabezado1.botonBorrar.Enabled = False
                Encabezado1.botonGuardar.Enabled = False
                panelDetalleCaja.Visible = False
                panelDetalleCaja.Dock = DockStyle.None
                panelDocumento.Visible = False
                panelDocumento.Dock = DockStyle.None
                ListaPrincipal()
                BotonImpreso.Enabled = False
                botonActualizar.Enabled = True
            Case 1 ' muestra el detalle de la caja y su lista de documentos

                Encabezado1.botonNuevo.Enabled = False
                Encabezado1.botonBorrar.Enabled = False
                Encabezado1.botonGuardar.Enabled = True
                panelDetalleCaja.Visible = True
                panelDetalleCaja.Dock = DockStyle.Fill
                panelLista.Visible = False
                panelLista.Dock = DockStyle.None
                panelDocumento.Visible = False
                panelDocumento.Dock = DockStyle.None
                BotonImpreso.Enabled = True
                botonActualizar.Enabled = False
                If Sesion.idGiro = 1 Then
                    If PermisoLiquidar() Then
                        botonLiquidar.Enabled = True
                    Else
                        botonLiquidar.Enabled = False
                    End If
                Else
                    botonLiquidar.Enabled = True
                End If

                If Sesion.idGiro = 1 Then
                    colrubro.Visible = True
                    colcuenta.Visible = True
                Else
                    colrubro.Visible = False
                    colcuenta.Visible = False
                End If

            Case 2 ' muestra el detalle de los documentos de la caja
                Encabezado1.botonNuevo.Enabled = False
                Encabezado1.botonBorrar.Enabled = True
                Encabezado1.botonGuardar.Enabled = True
                panelDocumento.Visible = True
                panelDocumento.Dock = DockStyle.Fill
                panelDetalleCaja.Visible = False
                panelDetalleCaja.Dock = DockStyle.None
                panelLista.Visible = False
                panelLista.Dock = DockStyle.None
                BotonImpreso.Enabled = False
                botonActualizar.Enabled = False
                If cfun.PermisoAnular = True Then
                    dtpFechaPolizaC.Enabled = True
                Else
                    dtpFechaPolizaC.Enabled = False
                End If
                If Sesion.idGiro = 1 Then
                    rubro.Visible = True
                    cuenta.Visible = True
                    idrubro.Visible = False
                    idcuenta.Visible = False
                Else
                    idrubro.Visible = False
                    idcuenta.Visible = False
                    rubro.Visible = False
                    cuenta.Visible = False
                End If
        End Select

    End Sub

    Private Function PermisoLiquidar() As Boolean
        Dim strSQL As String = STR_VACIO
        Dim COM As MySqlCommand
        Dim bandera As Boolean = False
        Dim REA As MySqlDataReader

        strSQL = "SELECT pms_codigo Clase, pms_nivel Nivel"
        strSQL &= "  FROM Permisos"
        strSQL &= "      WHERE pms_empresa={empresa} AND pms_modulo= 13 AND pms_usuario='{Usuario}' AND pms_codigo ='LIQUIDAR' LIMIT 1"

        strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
        strSQL = Replace(strSQL, "{Usuario}", Sesion.Usuario)

        MyCnn.CONECTAR = strConexion


        COM = New MySqlCommand(strSQL, CON)
        REA = COM.ExecuteReader

        If REA.Read Then
            bandera = True
        Else
            bandera = False
        End If
        Return bandera
    End Function

    Private Function VerificaBloqueo()
        Dim strSQL As String = STR_VACIO
        Dim COM As MySqlCommand
        Dim Bloqueo As Integer = NO_FILA

        strSQL = " SELECT c.cat_pid Estado "
        strSQL &= "   From Catalogos c "
        strSQL &= "        WHERE  c.cat_clase = 'Bloqueo' AND c.cat_clave = 'Compras' AND cat_sisemp = {empresa}"

        strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)

        MyCnn.CONECTAR = strConexion
        COM = New MySqlCommand(strSQL, CON)
        Bloqueo = COM.ExecuteScalar

        Return Bloqueo
    End Function

    Private Function EnLibroCompras(ByVal Anio As Integer, ByVal Numero As Integer, Optional Mensaje As Boolean = False, Optional Texto As String = vbNullString) As Boolean
        Dim strsql As String = STR_VACIO
        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader
        Dim logCompra As Boolean = False

        strsql = " Select e.HDoc_Doc_Fec Fecha, e.HDoc_DR1_Num Mes "
        strsql &= " From Dcmtos_DTL d "
        strsql &= " Left JOIN Dcmtos_HDR e On e.HDoc_Sis_Emp=d.DDoc_Sis_Emp And e.HDoc_Doc_Cat=d.DDoc_Doc_Cat And e.HDoc_Doc_Ano=d.DDoc_Doc_Ano And e.HDoc_Doc_Num=d.DDoc_Doc_Num "
        strsql &= " WHERE d.DDoc_Sis_Emp={empresa} And d.DDoc_RF1_Num=44 And d.DDoc_RF2_Num={anio} And d.DDoc_RF3_Num={num} And e.HDoc_Doc_Status=1 "
        strsql &= " LIMIT 1 "

        strsql = Replace(strsql, "{empresa}", Sesion.IdEmpresa)
        strsql = Replace(strsql, "{anio}", Anio)
        strsql = Replace(strsql, "{num}", Numero)

        Try
            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strsql, CON)
            REA = COM.ExecuteReader

            If REA.HasRows Then
                REA.Read()

                If Mensaje = True Then
                    MsgBox("La Factura se encuentra en el Libro " & REA.GetString("Mes") & IIf(Texto = vbNullString, vbNullString, vbCrLf & vbCrLf & Texto), IIf(Texto = vbNullString, vbInformation, vbExclamation), "Shopping Book")
                End If
                logCompra = True
            End If

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try

        Return logCompra
    End Function
    Private Function SQLImpuestos()
        Dim strsql As String = STR_VACIO

        strsql = " SELECT MDoc_Doc_Lin Linea, MDoc_Lin_ID ID, MDoc_Lin_Codigo Codigo, MDoc_Lin_Tipo Tipo, MDoc_Lin_Desc Descripcion, MDoc_Lin_Base Base, MDoc_Lin_Cantidad Cantidad, MDoc_Lin_Factor Factor, MDoc_Lin_Monto Monto, -1 Tag, 0 Origen"
        strsql &= "     From Dcmtos_IMP"
        strsql &= "         Where MDoc_Sis_Emp = {empresa} And MDoc_Doc_Cat = {cat} And MDoc_Doc_Ano = {anio} And MDoc_Doc_Num = {num}"
        strsql &= "     Order By MDoc_Doc_Lin"

        strsql = Replace(strsql, "{empresa}", Sesion.IdEmpresa)
        strsql = Replace(strsql, "{anio}", Year(Now.ToString(FORMATO_MYSQL)))
        strsql = Replace(strsql, "{num}", celdaNumeroHDR.Text)
        strsql = Replace(strsql, "{cat}", celdadetalleIDDocumento.Text)

        Return strsql

    End Function
    Private Function SQLListaPrincipal()
        Dim strSQL As String = STR_VACIO

        strSQL = " SELECT c.BCta_Num Codigo, c.BCta_Num_Cue Numero, c.BCta_Nom_Cue Nombre, c.BCta_Des_Cue Descripcion, c.BCta_Status Estado, n.cat_ext Moneda, IFNULL(( "
        strSQL &= " SELECT COUNT(*) "
        strSQL &= " From MvtosBcos m "
        strSQL &= " Left JOIN Dcmtos_HDR e ON e.HDoc_Sis_Emp=m.BMov_Sis_Emp AND e.HDoc_Doc_Cat=m.BMov_Cat_Doc AND e.HDoc_Doc_Ano=m.BMov_Doc_Ano AND e.HDoc_Doc_Num=m.BMov_Doc_Num "
        strSQL &= " Left JOIN Dcmtos_DTL d ON d.DDoc_Sis_Emp=e.HDoc_Sis_Emp AND d.DDoc_Doc_Cat=246 AND d.DDoc_Prd_Cod=e.HDoc_Doc_Cat AND d.DDoc_RF1_Num=e.HDoc_Doc_Ano AND d.DDoc_Prd_UM=e.HDoc_Doc_Num "
        strSQL &= " WHERE m.BMov_Sis_Emp=c.BCta_Sis_Emp AND m.BMov_Cta=c.BCta_Num AND ISNULL(d.DDoc_Sis_Emp)),0) Documentos "
        strSQL &= "    From CtasBcos c "
        strSQL &= "        Left JOIN Catalogos n ON n.cat_clase = 'Monedas' AND n.cat_num = c.BCta_Mon "
        strSQL &= "            Left JOIN Permisos p ON p.pms_empresa = c.BCta_Sis_Emp AND p.pms_modulo = 13 AND p.pms_id = c.BCta_Num "
        strSQL &= "                 WHERE c.BCta_Sis_Emp = {empresa} AND c.BCta_Tipo IN (1,2,3) And p.pms_usuario = '{usuario}' "
        strSQL &= "                    ORDER BY c.BCta_Tipo, c.BCta_Num "

        strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
        strSQL = Replace(strSQL, "{usuario}", Sesion.Usuario)

        Return strSQL
    End Function

    Public Sub Reset()
        dtpIncial.Value = Today.AddMonths(-6).ToString(FORMATO_MYSQL)
        dtpFinal.Value = Today.ToString(FORMATO_MYSQL)
        celdaidDocumento.Text = vbEmpty
        checkTodo.Checked = True
        celdaDocumento.Text = "ALL"

    End Sub

    Private Sub ListaPrincipal()
        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader
        Dim strsql As String = STR_VACIO
        Dim strFila As String = STR_VACIO

        Try
            strsql = SQLListaPrincipal()
            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strsql, CON)
            REA = COM.ExecuteReader

            If REA.HasRows Then
                dgLista.Rows.Clear()
                Do While REA.Read
                    strFila = REA.GetInt32("Codigo") & "|"
                    strFila &= REA.GetString("Numero") & "|"
                    strFila &= REA.GetString("Nombre") & "|"
                    strFila &= REA.GetString("Moneda") & "|"
                    strFila &= REA.GetString("Descripcion") & "|"
                    strFila &= REA.GetInt32("Documentos") & "|"
                    strFila &= REA.GetInt32("Estado")

                    If REA.GetInt32("Estado") = 1 Then
                        cFunciones.AgregarFila(dgLista, strFila)
                    Else
                        cFunciones.AgregarFila(dgLista, strFila, Color.Coral)
                    End If
                Loop
                For Each fila As DataGridViewRow In dgLista.Rows
                    If fila.Cells("colDocumentos").Value > 0 Then
                        fila.Cells(1).Style.BackColor = Color.YellowGreen
                    End If
                Next

            End If
            BarraTitulo1.CambiarTitulo("Petty Cash")
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try

    End Sub

    Private Function SQLCuentaBancaria(ByVal codigo As Integer) As String
        Dim strSQL As String
        strSQL = " SELECT ct.BCta_Num codigo , ct.BCta_Nom_Cue Responsable , ct.BCta_Des_Cue Descripcion , ct.BCta_Mon idMoneda , ct.BCta_Cuenta Cuenta, ct.BCta_Status status, c.cat_desc Moneda ,ct.BCta_Tipo TipoCaja, c.cat_clave Simbolo , IFNULL(cc.nombre,'') nombre "
        strSQL &= "     FROM CtasBcos ct "
        strSQL &= "         LEFT JOIN Catalogos c ON c.cat_num = ct.BCta_Mon AND c.cat_clase ='Monedas' "
        strSQL &= "             LEFT JOIN {conta}.cuentas cc ON cc.id_cuenta = ct.BCta_Cuenta AND cc.empresa = ct.BCta_Sis_Emp  "
        strSQL &= "                 WHERE ct.BCta_Sis_Emp = {empresa} AND ct.BCta_Num = {codigo} "
        strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
        strSQL = Replace(strSQL, "{codigo}", codigo)
        strSQL = Replace(strSQL, "{conta}", cFunciones.ContaEmpresa)
        Return strSQL
    End Function
    Private Function SQLDocumentosCajaChica(ByVal codigo As Integer, ByVal intClase As Integer) As String
        Dim strSQL As String = STR_VACIO
        strSQL = "  SELECT h.HDoc_Doc_Cat Catalogo,HDoc_Doc_Ano Anio , h.HDoc_Doc_Num Numero,h.HDoc_Doc_Fec Fecha, c.cat_desc Documento, h.HDoc_DR1_Num Referencia, "
        strSQL &= "     h.HDoc_Doc_Mon moneda, m.cat_ext, h.HDoc_RF1_Dbl Debito, h.HDoc_RF1_Txt Concepto, IFNULL(cc.nombre,'') Gasto, IFNULL(dd.DDoc_RF2_Txt,'') idrubro, IFNULL(n2.NombreIngles,'') Rubro, IFNULL(dd.DDoc_RF3_Txt,'') idcuenta, IFNULL(n.NombreIngles,'') Cuenta_Afectar, "
        strSQL &= "     h.HDoc_DR2_Num Serie , IF(h.HDoc_Emp_Nom='', h.HDoc_Emp_Per, h.HDoc_Emp_Nom) Nombre, h.HDoc_Doc_TC Tasa, "
        strSQL &= "     IFNULL((SELECT if( h.HDoc_Doc_Mon = 178, (SUM(e.ECta_Abno_Loc) / h.HDoc_Doc_TC), SUM(e.ECta_Abno_Loc)) "
        strSQL &= "        FROM ECtaCte e "
        strSQL &= "        WHERE e.ECta_Sis_Emp = h.HDoc_Sis_Emp AND NOT e.ECta_Doc_Cat = 44 AND e.ECta_Ref_Cat = h.HDoc_Doc_Cat AND e.ECta_Ref_Ano = h.HDoc_Doc_Ano AND e.ECta_Ref_Num = h.HDoc_Doc_Num),0) Parcial "
        strSQL &= "             FROM Dcmtos_HDR h "
        strSQL &= "             LEFT JOIN Dcmtos_DTL d ON d.DDoc_Sis_Emp = h.HDoc_Sis_Emp AND d.DDoc_Doc_Cat = 246 AND d.DDoc_Prd_Cod = h.HDoc_Doc_Cat AND d.DDoc_Prd_UM = h.HDoc_Doc_Num AND d.DDoc_RF1_Num = h.HDoc_Doc_Ano  "
        strSQL &= "             LEFT JOIN Catalogos c ON c.cat_clase = 'Documentos' AND c.cat_num = h.HDoc_Doc_Cat  "
        strSQL &= "             LEFT JOIN Catalogos m ON m.cat_num = h.HDoc_Doc_Mon "
        strSQL &= "             LEFT JOIN Dcmtos_DTL dd ON dd.DDoc_Sis_Emp = h.HDoc_Sis_Emp AND dd.DDoc_Doc_Cat = h.HDoc_Doc_Cat AND dd.DDoc_Doc_Ano = h.HDoc_Doc_Ano AND dd.DDoc_Doc_Num = h.HDoc_Doc_Num "
        strSQL &= "             LEFT JOIN {conta}.cuentas cc ON cc.empresa = h.HDoc_Sis_Emp AND cc.id_cuenta = dd.DDoc_RF1_Cod "
        strSQL &= "             Left Join {conta}.nomenclatura n ON n.idEmpresa = cc.empresa And n.idCuenta = cc.id_nomenclatura"
        strSQL &= "             Left Join {conta}.nomenclatura n2 ON n2.idEmpresa = n.idEmpresa And n2.idCuenta = n.Pertenencia"
        strSQL &= "             WHERE h.HDoc_Sis_Emp = {empresa} And h.HDoc_Doc_Cat IN({tipo}) AND h.HDoc_Doc_Fec BETWEEN '{fechainicio}' AND '{fechafin}' AND h.HDoc_DR1_Cat = {codigo} AND d.DDoc_Sis_Emp IS NULL "
        strSQL &= "     GROUP By h.HDoc_Sis_Emp , h.HDoc_Doc_Cat,h.HDoc_Doc_Ano,h.HDoc_Doc_Num"
        strSQL &= "         ORDER BY h.HDoc_Doc_Fec, h.HDoc_Doc_Cat, h.HDoc_DR1_Num "
        strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
        strSQL = Replace(strSQL, "{conta}", cFunciones.ContaEmpresa)
        strSQL = Replace(strSQL, "{codigo}", codigo)
        strSQL = Replace(strSQL, "{fechainicio}", dtpIncial.Value.ToString(FORMATO_MYSQL))
        strSQL = Replace(strSQL, "{fechafin}", dtpFinal.Value.ToString(FORMATO_MYSQL))
        If checkTodo.Checked = True Then
            strSQL = Replace(strSQL, "{tipo}", "44,209")
        Else
            strSQL = Replace(strSQL, "{tipo}", celdaidDocumento.Text)
        End If
        Return strSQL
    End Function
    Private Function CargarClase(ByVal Codigo As Integer) As String
        Dim strSQL As String = STR_VACIO
        Dim COM As MySqlCommand
        Dim conec As MySqlConnection
        Dim strClase As String = STR_VACIO
        Try
            strSQL = "  Select If(b.BCta_Mon = CAST(a.cat_clave As SIGNED),'Loc','Ext') Clase "
            strSQL &= "     FROM Catalogos a "
            strSQL &= "         LEFT JOIN CtasBcos b ON b.BCta_Sis_Emp = {empresa} AND b.BCta_Num = {codigo} "
            strSQL &= "             WHERE a.cat_sist='CUR_LOC' "
            strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
            strSQL = Replace(strSQL, "{codigo}", Codigo)
            conec = New MySqlConnection(strConexion)
            conec.Open()
            COM = New MySqlCommand(strSQL, conec)
            strClase = COM.ExecuteScalar
            conec.Close()
            conec.Dispose()
            conec = Nothing
            System.GC.Collect()
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        Return strClase
    End Function
    Private Function SQLSaldo(ByVal Codigo As Integer, ByVal clase As String, Optional logFecha As Boolean = False) As String
        Dim strSQL As String = STR_VACIO
        strSQL = "  SELECT IFNULL(SUM(m.BMov_Abno_Ext)- SUM(m.BMov_Crgo_Ext),0) Saldo "
        strSQL &= "     FROM MvtosBcos m "
        strSQL &= "         LEFT JOIN Dcmtos_HDR h ON h.HDoc_Sis_Emp = m.BMov_Sis_Emp AND h.HDoc_Doc_Cat = m.BMov_Cat_Doc AND h.HDoc_Doc_Ano = m.BMov_Doc_Ano AND h.HDoc_Doc_Num = m.BMov_Doc_Num "
        strSQL &= "             WHERE m.BMov_Sis_Emp = {empresa} AND m.BMov_Cta = {codigo} {fecha} AND h.HDoc_Pro_DCat = 0  "
        If logFecha Then
            strSQL = Replace(strSQL, "{fecha}", vbNullString)
        Else
            strSQL = Replace(strSQL, "{fecha}", " AND (m.BMov_Fec < '{fecha}')")
        End If
        strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
        strSQL = Replace(strSQL, "{codigo}", Codigo)
        strSQL = Replace(strSQL, "{fecha}", dtpIncial.Value.ToString(FORMATO_MYSQL))
        strSQL = Replace(strSQL, "{clase}", clase)
        Return strSQL
    End Function
    Public Sub CargarCuentaBancaria(ByVal Codigo As Integer, ByVal strNombreCuenta As String)
        Dim strSQL As String = STR_VACIO
        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader
        Try
            strSQL = SQLCuentaBancaria(Codigo)
            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSQL, CON)
            REA = COM.ExecuteReader
            If REA.HasRows Then
                Do While REA.Read
                    If REA.GetInt32("status") = 1 Then
                        checkInactivarCaja.Checked = True
                        checkInactivarCaja.Enabled = True
                        panelFechas.Enabled = True
                    Else
                        checkInactivarCaja.Checked = False
                        checkInactivarCaja.Enabled = False
                        panelFechas.Enabled = False
                    End If
                    celdaCodigo.Text = REA.GetInt32("codigo")
                    celdaResponsable.Text = REA.GetString("Responsable")
                    celdaDescripcion.Text = REA.GetString("Descripcion")
                    celdaidMoneda.Text = REA.GetInt32("idMoneda")
                    celdaMoneda.Text = REA.GetString("Simbolo")
                    celdaDescMoneda.Text = REA.GetString("Moneda")
                    celdaCuenta.Text = REA.GetString("Cuenta")
                    celdaDescCuenta.Text = REA.GetString("nombre")
                    celdaTipoCaja.Text = REA.GetInt32("TipoCaja")
                    BarraTitulo1.CambiarTitulo(strNombreCuenta)
                Loop
            End If
            COM = Nothing
            REA.Close()
            REA = Nothing

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub
    Public Sub CargarDocumentosCajaChica(ByVal Codigo As Integer)
        Dim strSQL As String = STR_VACIO
        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader
        Dim strFila As String = STR_VACIO
        Try
            strSQL = SQLDocumentosCajaChica(Codigo, celdaidDocumento.Text)
            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSQL, CON)
            REA = COM.ExecuteReader
            If REA.HasRows Then
                dgDocumentos.Rows.Clear()

                Do While REA.Read
                    strFila = REA.GetInt32("Catalogo") & "|"
                    strFila &= REA.GetInt32("Anio") & "|"
                    strFila &= REA.GetInt32("Numero") & "|"
                    strFila &= REA.GetDateTime("Fecha").ToString(FORMATO_MYSQL) & "|"
                    strFila &= REA.GetString("Documento") & "|"
                    strFila &= REA.GetString("Referencia") & "|"
                    strFila &= REA.GetInt32("moneda") & "|" ' moneda
                    strFila &= REA.GetString("cat_ext") & "|"
                    strFila &= REA.GetDouble("Debito").ToString(FORMATO_MONEDA) & "|"
                    strFila &= REA.GetString("Nombre") & "|"
                    strFila &= REA.GetString("Serie") & "|" '  
                    strFila &= REA.GetDouble("Parcial").ToString(FORMATO_MONEDA) & "|" 'Muestra el monto de la retención
                    strFila &= REA.GetDouble("Tasa") & "|"
                    strFila &= REA.GetString("Concepto") & "|"
                    strFila &= REA.GetString("Gasto") & "|"
                    strFila &= REA.GetString("idrubro") & "|"
                    strFila &= REA.GetString("Rubro") & "|"
                    strFila &= REA.GetString("idcuenta") & "|"
                    strFila &= REA.GetString("Cuenta_Afectar") & "|"
                    strFila &= STR_VACIO
                    cFunciones.AgregarFila(dgDocumentos, strFila)
                Loop
            Else
                dgDocumentos.Rows.Clear()
            End If
            COM = Nothing
            REA.Close()
            REA = Nothing
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub
    Public Sub SaldoCaja(ByVal Codigo As Integer)
        Dim strSQL As String = STR_VACIO
        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader
        Try
            strSQL = SQLSaldo(Codigo, clase:=CargarClase(Codigo), logFecha:=True)
            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSQL, CON)
            REA = COM.ExecuteReader
            If REA.HasRows Then
                Do While REA.Read
                    celdaDisponible.Text = REA.GetDouble("Saldo").ToString(FORMATO_MONEDA)
                Loop
            End If
            COM = Nothing
            REA.Close()
            REA = Nothing
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub
    Public Sub CalcularTotales()
        Dim dblTotales As Double = INT_CERO
        Dim dblTotalRetencion As Double = 0
        Dim dblSubTotales As Double = 0
        Dim frm As New frmOption
        For i As Integer = 0 To dgDocumentos.Rows.Count - 1
            If dgDocumentos.Rows(i).Cells("colDocLiquidar").Value = "SI" Then
                dblSubTotales = dblSubTotales + dgDocumentos.Rows(i).Cells("colDocDebito").Value
                dblTotalRetencion = dblTotalRetencion + dgDocumentos.Rows(i).Cells("colDocParcial").Value
            End If
        Next
        celdaSubtotal.Text = dblSubTotales.ToString(FORMATO_MONEDA)
        celdaRetencion.Text = dblTotalRetencion.ToString(FORMATO_MONEDA)
        dblTotales = dblSubTotales - dblTotalRetencion
        celdaTotalLiquidar.Text = dblTotales.ToString(FORMATO_MONEDA)
    End Sub


    Private Sub ActualizarTotal()
        Dim i As Integer = INT_CERO
        Dim Total As Double = 0
        Dim TotalImp As Double = 0
        Dim Monto As Double
        If (Sesion.IdEmpresa = 15) Or (Sesion.IdEmpresa = 18) Or (Sesion.IdEmpresa = 19) Then
            For i = INT_CERO To dgDetalleDocumento.Rows.Count - 1
                If Not dgDetalleDocumento.Rows(i).Cells("colExtra").Value = 2 Then
                    If Not dgDetalleDocumento.Rows(i).Cells("colidCuentaIVA").Value = vbNullString Then
                        TotalImp = TotalImp + dgDetalleDocumento.Rows(i).Cells("colTotalD").Value
                    End If
                    Total = Total + dgDetalleDocumento.Rows(i).Cells("colTotalD").Value
                End If
            Next
            celdaMontoProd.Text = TotalImp
            celdaDetalleMonto.Text = Total.ToString(FORMATO_MONEDA)
            Monto = (celdaDetalleMonto.Text * celdaDetalleTC.Text).ToString(FORMATO_MONEDA)

            celdaDetalleMonto.Text = Total.ToString(FORMATO_MONEDA)
            etiquetaMontoTotal.Text = Monto.ToString(FORMATO_MONEDA)


        Else
            For i = INT_CERO To dgDetalleDocumento.Rows.Count - 1
                If dgDetalleDocumento.Rows(i).Cells("colExtra").Value <> 2 Then
                    Total = Total + dgDetalleDocumento.Rows(i).Cells("colTotalD").Value
                End If
            Next

            celdaDetalleMonto.Text = Total.ToString(FORMATO_MONEDA)
            Monto = (celdaDetalleMonto.Text * celdaDetalleTC.Text)

            etiquetaMontoTotal.Text = Monto.ToString(FORMATO_MONEDA)
        End If
    End Sub

    Public Sub MarcarLiquidacion(ByVal logMarcar As Boolean)
        Try
            For i As Integer = 0 To dgDocumentos.Rows.Count - 1
                If logMarcar = True Then
                    dgDocumentos.Rows(i).Cells("colDocLiquidar").Value = "SI"
                Else
                    dgDocumentos.Rows(i).Cells("colDocLiquidar").Value = STR_VACIO
                End If
            Next
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub
    Private Function EncabezadoDocumento(ByVal Catalogo As Integer, ByVal Anio As Integer, ByVal Numero As Integer) As String
        Dim strSQL As String = STR_VACIO
        Try
            strSQL = "  SELECT h.HDoc_DR2_Fec conta_, h.HDoc_Sis_Emp Empresa , h.HDoc_Doc_Cat Catalogo , h.HDoc_Doc_Num Numero , h.HDoc_Doc_Fec Fecha, h.HDoc_Emp_Cod Codigo , h.HDoc_Emp_Nom NombreP , h.HDoc_Emp_Per Emisor ,"
            strSQL &= "     h.HDoc_Emp_NIT NIT , HDoc_DR1_Cat , HDoc_DR1_Num  NumeroDoc, h.HDoc_DR2_Num Serie , h.HDoc_DR2_Emp , h.HDoc_RF1_Txt  Nota , h.HDoc_RF2_Num , h.HDoc_RF2_Txt Letra , "
            strSQL &= "            h.HDoc_Doc_Mon idMoneda, h.HDoc_Doc_TC Tasa , h.HDoc_RF1_Dbl Monto ,h.HDoc_Doc_Status Estado, h.HDoc_DR2_Cat  , h.HDoc_DR1_Emp ,c.cat_clave Simbolo, t.cat_desc Tipo, h.HDoc_RF2_Cod CAI "
            strSQL &= "     FROM Dcmtos_HDR h "
            strSQL &= "         LEFT JOIN Catalogos c ON c.cat_num = h.HDoc_Doc_Mon AND c.cat_clase = 'Monedas' "
            strSQL &= "             LEFT JOIN Catalogos t ON t.cat_num = h.HDoc_Doc_Cat"
            strSQL &= "                 WHERE h.HDoc_Sis_Emp = {empresa} AND h.HDoc_Doc_Cat = {catalogo} AND h.HDoc_Doc_Ano = {anio} AND h.HDoc_Doc_Num = {numero} "
            strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
            strSQL = Replace(strSQL, "{catalogo}", Catalogo)
            strSQL = Replace(strSQL, "{anio}", Anio)
            strSQL = Replace(strSQL, "{numero}", Numero)
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        Return strSQL
    End Function
    Public Sub CargarEncabezadoDocumento(ByVal Catalogo As Integer, ByVal Anio As Integer, ByVal Numero As Integer)
        Dim strSQL As String = STR_VACIO
        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader
        Dim logCompra As Boolean = False
        Dim logIva As Boolean = False
        Dim LogFecha As Boolean = False
        Try
            strSQL = EncabezadoDocumento(Catalogo, Anio, Numero)
            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSQL, CON)
            REA = COM.ExecuteReader
            If REA.HasRows Then
                Do While REA.Read
                    ModCelda = False
                    logCompra = (Catalogo = 44)

                    celdaNumeroCaja.Text = celdaCodigo.Text

                    celdaDetalleDocumento.Text = REA.GetString("Tipo")
                    dtpDetalleFecha.Value = REA.GetDateTime("Fecha")
                    celdaidProveedor.Text = REA.GetInt32("Codigo")
                    celdaProveedor.Text = REA.GetString("NombreP")
                    celdaDetalleNumero.Text = REA.GetString("NumeroDoc")
                    celdaDetalleSerie.Text = REA.GetString("Serie")
                    celdaDetalleNit.Text = REA.GetString("NIT")
                    celdaDetalleMoneda.Text = REA.GetString("Simbolo")
                    celdaDetalleTC.Text = REA.GetDouble("Tasa")
                    celdaDetalleMonto.Text = REA.GetDouble("Monto").ToString(FORMATO_MONEDA)
                    celdaReintegro.Text = INT_CERO.ToString(FORMATO_MONEDA)
                    celdaDiferencia.Text = INT_CERO.ToString(FORMATO_MONEDA)
                    celdaNota.Text = REA.GetString("Nota")
                    celdaEmisor.Text = REA.GetString("Emisor")
                    celdaLetra.Text = REA.GetString("Letra")
                    celdaDetalleIDMoneda.Text = REA.GetInt32("idMoneda")
                    dtpFechaPolizaC.Value = REA.GetDateTime("conta_")
                    celdaDetalleAnio.Text = Anio
                    celdadetalleIDDocumento.Text = Catalogo
                    celdaNumeroHDR.Text = Numero
                    celdaCAI.Text = REA.GetString("CAI")



                    IIf(REA.GetInt32("Estado") = 1, checActivo.Checked = True, checActivo.Checked = False)
                    LogFecha = CBool(Val(vbNullString & REA.GetInt32("HDoc_DR2_Cat")))
                    panelExtemporaneo.Visible = LogFecha

                    etiquetaMontoTotal.Visible = Not (REA.GetInt32("idMoneda") = 177)
                    etiquetaMontoTotal.Text = (REA.GetDouble("Monto") * REA.GetDouble("Tasa")).ToString(FORMATO_MONEDA)
                    If logCompra Then
                        logIva = Not (Val(REA.GetInt32("HDoc_DR2_Emp")) = vbEmpty)

                        If REA.GetInt32("HDoc_DR1_Emp") = INT_UNO Then
                            checkFacElectrónica.Checked = True
                        Else
                            checkFacElectrónica.Checked = False
                        End If

                        If REA.GetInt32("HDoc_DR2_Cat") = 1 Then
                            panelExtemporaneo.Visible = True
                        Else
                            panelExtemporaneo.Visible = False
                        End If


                    End If
                Loop
                COM.Dispose()
                COM = Nothing

                If logCompra = True Then
                    If logIva = True Then
                        checkContribuyent.Checked = False
                        checkContribuyent.Checked = False
                        celdaDetalleDoc.Text = "INVOICE DETAIL"
                        celdaDetalleDoc.BackColor = Color.RoyalBlue
                        celdaDetalleDoc.TextAlign = HorizontalAlignment.Left
                        celdaDetalleDoc.ForeColor = Color.White
                    Else
                        checkContribuyent.Checked = True
                        celdaDetalleDoc.Text = "DOES NOT GENERATE RIGHT TO TAX CREDIT"
                        celdaDetalleDoc.BackColor = Color.Red
                        celdaDetalleDoc.TextAlign = HorizontalAlignment.Center

                    End If
                End If
            End If
            ModCelda = True
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub
    Private Function sqlDetalleDocumento(ByVal Catalogo As Integer, ByVal Anio As Integer, ByVal Numero As Integer) As String
        Dim strSQL As String = STR_VACIO
        strSQL = " SELECT  d.DDoc_Doc_Cat Catalogo , d.DDoc_Doc_Ano Anio , d.DDoc_Doc_Num Numero , d.DDoc_Doc_Lin Linea ,  d.DDoc_Prd_Des Descripcion , "
        strSQL &= "     d.DDoc_Prd_NET Precio , d.DDoc_Prd_QTY Cantidad , d.DDoc_RF1_Num Servicio , "
        strSQL &= "         d.DDoc_RF1_Cod Gasto , cc.nombre NombreG, IFNULL(d.DDoc_RF2_Txt,'') rubro, IFNULL(n2.NombreIngles,'') Rubro, IFNULL(d.DDoc_RF3_Txt,'') cuenta, IFNULL(n.NombreIngles,'') Cuenta_Afectar, d.DDoc_RF3_Num CentroCosto , c.cost_nombre NombreC ,d.DDoc_RF3_Dbl PrecioIva,IFNULL(cu.nombre,'') NombreIVA, IFNULL(d.DDoc_RF1_Txt,'') CuentaIva"
        strSQL &= "             FROM Dcmtos_DTL d "
        strSQL &= "                 LEFT JOIN {conta}.cuentas cc ON cc.empresa = d.DDoc_Sis_Emp AND cc.id_cuenta = d.DDoc_RF1_Cod  "
        strSQL &= "                     LEFT JOIN {conta}.costos c ON c.cost_num = d.DDoc_RF3_Num  "
        strSQL &= "                         LEFT JOIN {conta}.cuentas cu ON cu.empresa = d.DDoc_Sis_Emp AND cu.id_cuenta = d.DDoc_RF1_Txt"
        strSQL &= "                            Left Join {conta}.nomenclatura n ON n.idEmpresa = cc.empresa And n.idCuenta = cc.id_nomenclatura"
        strSQL &= "                               Left Join {conta}.nomenclatura n2 ON n2.idEmpresa = n.idEmpresa And n2.idCuenta = n.Pertenencia"
        strSQL &= "                             WHERE d.DDoc_Sis_Emp = {empresa} AND d.DDoc_Doc_Cat = {catalogo} AND d.DDoc_Doc_Ano = {anio} AND d.DDoc_Doc_Num = {numero} "
        strSQL &= "                                 ORDER BY d.DDoc_Doc_Lin "
        strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
        strSQL = Replace(strSQL, "{catalogo}", Catalogo)
        strSQL = Replace(strSQL, "{anio}", Anio)
        strSQL = Replace(strSQL, "{numero}", Numero)
        strSQL = Replace(strSQL, "{conta}", cFunciones.ContaEmpresa)
        Return strSQL
    End Function
    Public Sub CargarDetalleDocumento(ByVal Catalogo As Integer, ByVal Anio As Integer, ByVal Numero As Integer)
        Dim strSQL As String
        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader
        Dim strFila As String = STR_VACIO
        Try
            strSQL = sqlDetalleDocumento(Catalogo, Anio, Numero)
            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSQL, CON)
            REA = COM.ExecuteReader
            If REA.HasRows Then
                dgDetalleDocumento.Rows.Clear()
                Do While REA.Read
                    strFila = REA.GetInt32("Cantidad") & "|"
                    strFila &= REA.GetInt32("Catalogo") & "|"
                    strFila &= REA.GetInt32("Anio") & "|"
                    strFila &= REA.GetInt32("Numero") & "|"
                    strFila &= REA.GetInt32("Linea") & "|"
                    strFila &= REA.GetString("Descripcion") & "|"
                    strFila &= REA.GetDouble("PrecioIva") & "|"
                    strFila &= REA.GetDouble("Precio").ToString(FORMATO_MONEDA) & "|"
                    strFila &= (REA.GetDouble("Cantidad") * REA.GetDouble("Precio")).ToString(FORMATO_MONEDA) & "|"
                    strFila &= REA.GetString("NombreG") & "|"
                    strFila &= REA.GetString("Gasto") & "|"
                    strFila &= REA.GetString("CuentaIva") & "|"
                    strFila &= REA.GetString("NombreC") & "|"
                    strFila &= REA.GetInt32("CentroCosto") & "|"
                    strFila &= REA.GetString("rubro") & "|"
                    strFila &= REA.GetString("Rubro") & "|"
                    strFila &= REA.GetString("cuenta") & "|"
                    strFila &= REA.GetString("Cuenta_Afectar") & "|"
                    If REA.GetInt32("Servicio") = 1 Then
                        strFila &= "SERVICIO" & "|"
                    Else
                        strFila &= "BIEN" & "|"
                    End If
                    strFila &= REA.GetInt32("Servicio") & "|"

                    strFila &= REA.GetString("NombreIva") & "|"
                    strFila &= INT_UNO
                    cFunciones.AgregarFila(dgDetalleDocumento, strFila)
                Loop
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Public Sub LimpiarDetalleDoc()
        celdaDetalleIDMoneda.Text = cFunciones.DivisaLocal
        celdaDetalleTC.Text = INT_UNO.ToString(FORMATO_MONEDA)
        dtpDetalleFecha.Value = cfun.HoyMySQL.ToString(FORMATO_MYSQL)
        celdaNumeroCaja.Text = -1
        celdaDetalleDocumento.Clear()
        celdadetalleIDDocumento.Text = NO_FILA
        celdaDetalleMoneda.Text = cFunciones.TraerMoneda(cFunciones.DivisaLocal)
        celdaDetalleMonto.Text = INT_CERO.ToString(FORMATO_MONEDA)
        celdaMontoProd.Text = INT_CERO.ToString(FORMATO_MONEDA)
        celdaDetalleNit.Clear()
        celdaDetalleNumero.Clear()
        celdaDetalleSerie.Clear()
        celdaProveedor.Clear()
        celdaidProveedor.Clear()
        celdaReintegro.Text = INT_CERO.ToString(FORMATO_MONEDA)
        celdaDiferencia.Text = INT_CERO.ToString(FORMATO_MONEDA)
        ModCelda = False
        celdaNota.Clear()
        celdaNumeroHDR.Text = -1
        celdaCAI.Clear()
        celdaDetalleAnio.Text = -1
        celdaEmisor.Clear()
        panelExtemporaneo.Visible = False
        dgDetalleDocumento.Rows.Clear()
        dgImpuestos.Rows.Clear()
        checkContribuyent.Checked = False
        checkFacElectrónica.Checked = False
        botonDocumentos.Enabled = True
        dtpFechaPolizaC.Value = cfun.HoyMySQL.ToString(FORMATO_MYSQL)
        If Sesion.idGiro = 2 Then
            dgDetalleDocumento.Columns(6).Visible = True
        Else
            dgDetalleDocumento.Columns(6).Visible = False
        End If
        If Sesion.idGiro = 2 Then
            dgDetalleDocumento.Columns(11).Visible = True
        Else
            dgDetalleDocumento.Columns(11).Visible = False
        End If

        'botonMas.Enabled = False
    End Sub
    Private Sub dgDocumentos_DoubleClick(sender As Object, e As EventArgs) Handles dgDocumentos.DoubleClick
        Me.Tag = "Mod"
        celdaCAI.BackColor = Color.White
        Dim frm As New frmOption
        If dgDocumentos.Rows.Count = 0 Then Exit Sub
        Try
            Select Case dgDocumentos.CurrentCell.ColumnIndex
                Case 19
                    If dgDocumentos.CurrentRow.Cells("colDocLiquidar").Value = "SI" Then
                        dgDocumentos.CurrentRow.Cells("colDocLiquidar").Value = STR_VACIO
                    Else
                        dgDocumentos.CurrentRow.Cells("colDocLiquidar").Value = "SI"
                    End If
                    CalcularTotales()
                Case Else
                    LimpiarDetalleDoc()
                    botonDocumentos.Enabled = False
                    CargarEncabezadoDocumento(dgDocumentos.CurrentRow.Cells("colDocTipo").Value, dgDocumentos.CurrentRow.Cells("colDocAnio").Value, dgDocumentos.CurrentRow.Cells("colDocNumero").Value)
                    CargarDetalleDocumento(dgDocumentos.CurrentRow.Cells("colDocTipo").Value, dgDocumentos.CurrentRow.Cells("colDocAnio").Value, dgDocumentos.CurrentRow.Cells("colDocNumero").Value)
                    CargarImpuesto(dgDocumentos.CurrentRow.Cells("colDocTipo").Value, dgDocumentos.CurrentRow.Cells("colDocAnio").Value, dgDocumentos.CurrentRow.Cells("colDocNumero").Value)
                    If dgDocumentos.CurrentRow.Cells("colDocTipo").Value = 44 Then
                        BloquearCuandoEsRecibo(False)
                    Else
                        BloquearCuandoEsRecibo(True)
                    End If
                    If Sesion.idGiro = 2 Or Sesion.IdEmpresa = 11 Then
                        celdaCAI.Visible = True
                        etiquetaCAI.Visible = True
                    Else
                        celdaCAI.Visible = False
                        etiquetaCAI.Visible = False
                    End If
                    MostrarLista(2)
            End Select
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub
    Private Function SQLImpuestosDocumento(ByVal Catalogo As Integer, ByVal Anio As Integer, ByVal Numero As Integer) As String
        Dim strSQL As String = STR_VACIO
        strSQL = "  SELECT MDoc_Doc_Lin Linea, MDoc_Lin_ID ID, MDoc_Lin_Codigo Codigo, MDoc_Lin_Tipo Tipo, "
        strSQL &= "     MDoc_Lin_Desc Descripcion, MDoc_Lin_Base Base, MDoc_Lin_Cantidad Cantidad, MDoc_Lin_Factor Factor, MDoc_Lin_Monto Monto, -1 Tag, 1 Origen "
        strSQL &= "         FROM Dcmtos_IMP "
        strSQL &= "             WHERE MDoc_Sis_Emp={empresa} AND MDoc_Doc_Cat={catalogo} AND MDoc_Doc_Ano={anio} AND MDoc_Doc_Num={numero} "
        strSQL &= "                 ORDER BY MDoc_Doc_Lin"
        strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
        strSQL = Replace(strSQL, "{catalogo}", Catalogo)
        strSQL = Replace(strSQL, "{anio}", Anio)
        strSQL = Replace(strSQL, "{numero}", Numero)

        Return strSQL
    End Function
    Public Sub CargarImpuesto(ByVal Catalogo As Integer, ByVal Anio As Integer, ByVal Numero As Integer)
        Dim strSQL As String = STR_VACIO
        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader
        Dim strFila As String = STR_VACIO
        Try
            strSQL = SQLImpuestosDocumento(Catalogo, Anio, Numero)
            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSQL, CON)
            REA = COM.ExecuteReader
            If REA.HasRows Then
                dgImpuestos.Rows.Clear()
                Do While REA.Read
                    strFila = REA.GetInt32("Linea") & "|"
                    strFila &= REA.GetInt32("ID") & "|"
                    strFila &= REA.GetString("Codigo") & "|"
                    strFila &= REA.GetInt32("Tipo") & "|"
                    strFila &= REA.GetString("Descripcion") & "|"
                    strFila &= REA.GetDouble("Cantidad") & "|"
                    strFila &= REA.GetDouble("Factor") & "|"
                    strFila &= REA.GetDouble("Base") & "|"
                    strFila &= REA.GetDouble("Monto") & "|"
                    strFila &= REA.GetInt32("Tag") & "|"
                    strFila &= INT_UNO
                    cFunciones.AgregarFila(dgImpuestos, strFila)
                Loop
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub
    Private Sub Encabezado1_ClickCerrar(sender As Object, click As Boolean) Handles Encabezado1.ClickCerrar
        If dgLista.Visible = True Then
            Me.Close()
            Fprincipal.BarraDeTareas1.QuitarFormulario(Key)
        ElseIf dgDocumentos.Visible = True Then
            MostrarLista()
        ElseIf dgDetalleDocumento.Visible = True Then
            MostrarLista(1)
            CargarDocumentosCajaChica(celdaNumeroCaja.Text)
            SaldoCaja(celdaNumeroCaja.Text)
        End If
    End Sub
    Public Sub EliminarReporte(ByVal Numero As Integer, ByVal Anio As Integer)
        Dim strSQL As String = STR_VACIO
        Dim COM As New MySqlCommand
        Dim COM2 As New MySqlCommand
        Dim conec As New MySqlConnection
        Dim REA As MySqlDataReader
        conec = New MySqlConnection(strConexion & ";Allow User Variables=True")
        strSQL = " SELECT DDoc_Prd_Cod, IFNULL(DDoc_RF1_Num,0) num, DDoc_Prd_UM "
        strSQL &= "     FROM Dcmtos_DTL "
        strSQL &= "         WHERE DDoc_Sis_Emp = {empresa} AND DDoc_Doc_Cat = 246 AND DDoc_Doc_Ano = {anio} AND DDoc_Doc_Num = {numero}  "
        strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
        strSQL = Replace(strSQL, "{anio}", Anio)
        strSQL = Replace(strSQL, "{numero}", Numero)
        MyCnn.CONECTAR = strConexion
        COM = New MySqlCommand(strSQL, CON)
        REA = COM.ExecuteReader
        If REA.HasRows Then
            Do While REA.Read
                strSQL = vbNullString
                strSQL = " UPDATE Dcmtos_HDR SET HDoc_Pro_DCat = 0, HDoc_Pro_DAno = 0, HDoc_Pro_DNum = 0 "
                strSQL &= "     WHERE HDoc_Sis_Emp = {empresa} AND HDoc_Doc_Cat = {cat} AND HDoc_Doc_Ano = {anio} AND HDoc_Doc_Num = {num}  "
                If Sesion.IdEmpresa = 18 Then
                    strSQL &= "; UPDATE PDM.Dcmtos_HDR SET HDoc_Pro_DCat = 0, HDoc_Pro_DAno = 0, HDoc_Pro_DNum = 0 "
                    strSQL &= "     WHERE HDoc_Sis_Emp = {empresa} AND HDoc_Doc_Cat = {cat} AND HDoc_Doc_Ano = {anio} AND HDoc_Doc_Num = {num}  "
                End If
                strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
                strSQL = Replace(strSQL, "{cat}", REA.GetInt32("DDoc_Prd_Cod"))
                strSQL = Replace(strSQL, "{anio}", REA.GetInt32("num"))
                strSQL = Replace(strSQL, "{num}", REA.GetInt32("DDoc_Prd_UM"))
                conec.Open()
                COM2 = New MySqlCommand(strSQL, conec)
                COM2.ExecuteNonQuery()
                COM2 = Nothing
                conec.Close()
            Loop
        End If
        COM = Nothing
        REA.Close()
        REA = Nothing
        'Elimina Encabezado de la Liquidacion
        Dim hdr As New clsDcmtos_HDR
        hdr.CONEXION = strConexion
        hdr.HDOC_SIS_EMP = Sesion.IdEmpresa
        hdr.HDOC_DOC_CAT = 246
        hdr.HDOC_DOC_ANO = Anio
        hdr.HDOC_DOC_NUM = Numero
        hdr.Borrar()
        'Elimina Detalle de la Liquidacion 
        strSQL = "DDoc_Sis_Emp = {empresa} AND DDoc_Doc_Cat = 246 AND DDoc_Doc_Ano = {anio} AND DDoc_Doc_Num = {numero}  "
        strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
        strSQL = Replace(strSQL, "{anio}", Anio)
        strSQL = Replace(strSQL, "{numero}", Numero)
        Dim dtl As New clsDcmtos_DTL
        dtl.CONEXION = strConexion
        dtl.Borrar(strSQL)

        SaldoCaja(celdaCodigo.Text)
        CargarDocumentosCajaChica(celdaCodigo.Text)
        MsgBox("Liquidacion eliminada correctamente", MsgBoxStyle.Information, "Aviso")
    End Sub
    Private Function NuevoCodigo() As Integer
        Dim strSQL As String
        Dim conec As New MySqlConnection
        Dim COM As MySqlCommand
        Dim intCodigo As Integer

        strSQL = " SELECT (IFNULL(MAX(HDoc_Doc_Num),0) + 1) Nuevo, IFNULL(HDoc_RF2_Cod,'N/A') CAI "
        strSQL &= "     FROM Dcmtos_HDR "
        strSQL &= "         WHERE HDOC_Sis_Emp = {empresa} AND HDOC_Doc_Cat = 246 AND HDOC_Doc_Ano = {anio} "
        strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
        strSQL = Replace(strSQL, "{anio}", cFunciones.AñoMySQL)
        strSQL = Replace(strSQL, "{numero}", celdaCodigo.Text)

        conec = New MySqlConnection(strConexion)
        conec.Open()
        COM = New MySqlCommand(strSQL, conec)
        intCodigo = COM.ExecuteScalar
        conec.Close()
        conec.Dispose()
        conec = Nothing
        System.GC.Collect()
        Return intCodigo
    End Function
    Private Function NuevaLiquidacion() As Integer
        Dim strSQL As String
        Dim conec As New MySqlConnection
        Dim COM As MySqlCommand
        Dim CodigoLiquidacion As Integer

        strSQL = " SELECT (IFNULL(MAX(HDoc_DR1_Num),0) + 1) Nuevo  "
        strSQL &= "     FROM Dcmtos_HDR "
        strSQL &= "         WHERE HDOC_Sis_Emp = {empresa} AND HDOC_Doc_Cat = 246 AND HDOC_Doc_Ano = {anio} AND HDoc_DR1_cat = '{numero}'"
        strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
        strSQL = Replace(strSQL, "{anio}", cFunciones.AñoMySQL)
        strSQL = Replace(strSQL, "{numero}", celdaCodigo.Text)

        conec = New MySqlConnection(strConexion)
        conec.Open()
        COM = New MySqlCommand(strSQL, conec)
        CodigoLiquidacion = COM.ExecuteScalar
        conec.Close()
        conec.Dispose()
        conec = Nothing
        System.GC.Collect()
        Return CodigoLiquidacion
    End Function
    Private Function SqlCajaChica(ByVal Fechainicio As Date, ByVal FechaFin As Date) As String
        Dim strSQL As String = STR_VACIO
        strSQL = "  SELECT h.HDoc_Doc_Num NO, m.BMov_Cta Cuenta, h.HDoc_Doc_Cat Cat, h.HDoc_RF2_Num Mov, h.HDoc_Doc_Ano Anio, c.cat_desc Tipo, h.HDoc_DR2_Num Serie, "
        strSQL &= "     h.HDoc_DR1_Num Numero, h.HDoc_Doc_Fec Fecha, IF(h.HDoc_Emp_Nom='', h.HDoc_Emp_Per, h.HDoc_Emp_Nom) Nombre, "
        strSQL &= "         h.HDoc_RF1_Txt Concepto, h.HDoc_Doc_Mon Mon, c1.cat_clave Moneda, h.HDoc_RF1_Dbl Valor, h.HDoc_RF2_Dbl Parcial, h.HDoc_Doc_TC Tasa "
        strSQL &= "             FROM MvtosBcos m "
        strSQL &= "                 LEFT JOIN Dcmtos_HDR h ON h.HDoc_Sis_Emp = m.BMov_Sis_Emp AND h.HDoc_Doc_Cat = m.BMov_Cat_Doc AND h.HDoc_Doc_Ano = m.BMov_Doc_Ano AND h.HDoc_Doc_Num = m.BMov_Doc_Num "
        strSQL &= "                     INNER JOIN Catalogos c ON c.cat_num = h.HDoc_Doc_Cat "
        strSQL &= "                         INNER JOIN Catalogos c1 ON c1.cat_num = h.HDoc_Doc_Mon "
        strSQL &= "                             WHERE m.BMov_Sis_Emp = {empresa} AND m.BMov_Cta = {caja} AND m.BMov_Doc_Cat = 52 AND m.BMov_Fec BETWEEN '{fechainicio}' AND '{fechafin}' AND h.HDoc_Doc_Status = 1 "
        strSQL &= "                                 ORDER BY Fecha  "
        strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
        strSQL = Replace(strSQL, "{caja}", celdaCodigo.Text)
        strSQL = Replace(strSQL, "{fechainicio}", Fechainicio.ToString(FORMATO_MYSQL))
        strSQL = Replace(strSQL, "{fechafin}", FechaFin.ToString(FORMATO_MYSQL))
        Return strSQL
    End Function
    Public Sub GenerarLiquidacion(ByVal idLiquidacion As Integer, ByVal liquidacion As Integer, ByVal logcheck As Boolean)
        Dim fechaInicio As Date
        Dim fechaFin As Date
        Dim intLineas As Integer = INT_CERO
        Dim strMoneda As String = STR_VACIO
        Dim logSeleccionTodo As Boolean = False
        Dim LogPrimerLinea As Boolean = False
        Dim intLiquidacion As String = STR_VACIO
        Try
            For i As Integer = 0 To dgDocumentos.Rows.Count - 1
                If dgDocumentos.Rows(i).Cells("colDocLiquidar").Value = "SI" Then
                    intLineas = intLineas + 1
                    If LogPrimerLinea = False Then
                        fechaInicio = dgDocumentos.Rows(i).Cells("colDocFecha").Value
                        LogPrimerLinea = True
                    End If
                    strMoneda = dgDocumentos.Rows(i).Cells("colDocMoneda").Value
                    fechaFin = dgDocumentos.Rows(i).Cells("colDocFecha").Value
                End If
            Next
            If ValidacionMoneda(strMoneda) = True Then
                MsgBox("Verify that all document are of the same currency ", MsgBoxStyle.Information)
                Exit Sub
            End If
            intLiquidacion = liquidacion
            intLiquidacion = intLiquidacion.PadLeft(3, "0")
            If logcheck = True Then
                If GenerarLiquidacionDTL(fechaInicio, fechaFin, idLiquidacion, intLiquidacion) = True Then

                Else
                    Exit Sub
                End If
            Else
                If MsgBox(" " & intLineas & "" & vbCr & vbCr & "¿Liquidate these documents ? ", vbQuestion + vbYesNo, "liquidation") = vbYes Then

                    If GenerarLiquidacionDTL(fechaInicio, fechaFin, idLiquidacion, intLiquidacion) = True Then

                    Else
                        Exit Sub
                    End If
                Else
                    Exit Sub
                End If
            End If
            GenerarLiquidacionCaja(fechaInicio, fechaFin, intLiquidacion)
            SaldoCaja(celdaCodigo.Text)
            CargarDocumentosCajaChica(celdaCodigo.Text)
            checkSeleccionar.Checked = False
            celdaTotalLiquidar.Text = INT_CERO
            MsgBox("Liquidation Generated", MsgBoxStyle.Information, "Liquidation")
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub
    Private Function ValidacionMoneda(ByVal strMoneda As String)
        Dim logValidacion As Boolean = False
        Try
            For i As Integer = 0 To dgDocumentos.Rows.Count - 1
                If dgDocumentos.Rows(i).Cells("colDocLiquidar").Value = "SI" Then
                    If strMoneda <> dgDocumentos.Rows(i).Cells("colDocMoneda").Value Then
                        logValidacion = True
                    End If
                End If
            Next
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        Return logValidacion
    End Function
    Public Function GenerarLiquidacionDTL(ByVal FechaInicio As Date, ByVal FechaFin As Date, ByVal idLiquidacion As Integer, ByVal liquidacion As String) As Boolean
        Dim clsDTL As New clsDcmtos_DTL
        Dim conta As New clsContabilidad
        Dim strSQL As String = STR_VACIO
        Dim COM As MySqlCommand
        Dim conec As MySqlConnection
        Dim REA As MySqlDataReader
        Dim dblTotal As Double = INT_CERO
        Dim dblParcial As Double = INT_CERO
        Dim dblPendiente As Double = INT_CERO
        Dim intCurrency As Integer = INT_CERO
        Dim intLinea As Integer = INT_CERO
        Dim logVerificar As Boolean = False
        Dim ContarRecibos As Integer = 0
        Try
            For i As Integer = 0 To dgDocumentos.Rows.Count - 1
                If dgDocumentos.Rows(i).Cells("colDocLiquidar").Value = "SI" Then
                    clsDTL.CONEXION = strConexion
                    intLinea = intLinea + 1
                    clsDTL.DDOC_SIS_EMP = Sesion.IdEmpresa
                    clsDTL.DDOC_DOC_CAT = 246
                    clsDTL.DDOC_DOC_ANO = cfun.AñoMySQL
                    clsDTL.DDOC_DOC_NUM = idLiquidacion
                    clsDTL.DDOC_DOC_LIN = intLinea
                    clsDTL.DDOC_PRD_COD = dgDocumentos.Rows(i).Cells("colDocTipo").Value
                    clsDTL.DDOC_PRD_PNR = dgDocumentos.Rows(i).Cells("colDocSerie").Value
                    clsDTL.DDOC_PRD_DES = dgDocumentos.Rows(i).Cells("colDocReferencia").Value
                    clsDTL.DDOC_PRD_UM = dgDocumentos.Rows(i).Cells("colDocNumero").Value
                    clsDTL.DDOC_RF1_NUM = dgDocumentos.Rows(i).Cells("colDocAnio").Value
                    clsDTL.DDoc_RF1_Fec_NET = CDate(dgDocumentos.Rows(i).Cells("colDocFecha").Value).ToString(FORMATO_MYSQL)
                    clsDTL.DDOC_RF1_TXT = dgDocumentos.Rows(i).Cells("colDocNombre").Value
                    clsDTL.DDOC_RF2_TXT = dgDocumentos.Rows(i).Cells("colDocConcepto").Value
                    clsDTL.DDOC_RF1_DBL = (dgDocumentos.Rows(i).Cells("colDocDebito").Value - dgDocumentos.Rows(i).Cells("colDocParcial").Value)
                    clsDTL.DDOC_RF3_DBL = dgDocumentos.Rows(i).Cells("colDocTasa").Value
                    If dgDocumentos.Rows(i).Cells("colDocParcial").Value = INT_CERO Then
                        clsDTL.DDOC_RF2_DBL = (dgDocumentos.Rows(i).Cells("colDocDebito").Value - dgDocumentos.Rows(i).Cells("colDocParcial").Value)
                        dblParcial = dblParcial + dgDocumentos.Rows(i).Cells("colDocDebito").Value
                    Else
                        clsDTL.DDOC_RF2_DBL = dgDocumentos.Rows(i).Cells("colDocParcial").Value ' colDocParcial son las retencioes
                        dblParcial = dblParcial + dgDocumentos.Rows(i).Cells("colDocParcial").Value
                        dblPendiente = dblPendiente + dgDocumentos.Rows(i).Cells("colDocParcial").Value
                    End If
                    clsDTL.DDOC_RF2_NUM = dgDocumentos.Rows(i).Cells("colDocTransaccion").Value
                    clsDTL.DDOC_RF3_NUM = celdaCodigo.Text
                    dblTotal = dblTotal + (dgDocumentos.Rows(i).Cells("colDocDebito").Value - dgDocumentos.Rows(i).Cells("colDocParcial").Value)
                    intCurrency = dgDocumentos.Rows(i).Cells("colDocTransaccion").Value

                    If clsDTL.Guardar = False Then
                        MsgBox(clsDTL.MERROR.ToString & " Could not save this document ", MsgBoxStyle.Critical)
                        Return False
                    Else
                        logVerificar = True
                    End If
                End If
            Next
            If logVerificar = True Then
                If GenerarLiquidacionHDR(FechaInicio, FechaFin, idLiquidacion, liquidacion, dblTotal, dblPendiente, intCurrency) = True Then
                    'conta.GenerarPoliza(246, Year(FechaFin), idLiquidacion, cfun.HoyMySQL.ToString(FORMATO_MYSQL))
                    SaldoCaja(celdaCodigo.Text)
                Else
                    logVerificar = False
                End If

            End If


        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        Return logVerificar
    End Function
    Private Function GenerarLiquidacionHDR(ByVal FechaInicio As Date, ByVal FechaFin As Date, ByVal idLiquidacion As Integer, ByVal liquidacion As String, ByVal dblTotal As Double, ByVal dblPendiente As Double, ByVal intCurrency As Integer) As Boolean
        Dim clsHDR As New clsDcmtos_HDR
        Dim logVerificar As Boolean = False
        Try
            clsHDR.CONEXION = strConexion
            clsHDR.HDOC_SIS_EMP = Sesion.IdEmpresa
            clsHDR.HDOC_DOC_CAT = 246
            clsHDR.HDOC_DOC_ANO = cfun.AñoMySQL
            clsHDR.HDOC_DOC_NUM = idLiquidacion
            clsHDR.HDoc_Doc_Fec_NET = Now().ToString(FORMATO_MYSQL)
            clsHDR.HDoc_DR1_Fec_NET = FechaInicio.ToString(FORMATO_MYSQL)
            clsHDR.HDOC_DR1_NUM = liquidacion
            clsHDR.HDoc_DR2_Fec_NET = FechaFin.ToString(FORMATO_MYSQL)
            clsHDR.HDOC_DR1_CAT = celdaCodigo.Text
            clsHDR.HDOC_RF1_DBL = dblTotal
            clsHDR.HDOC_RF2_DBL = dblTotal
            clsHDR.HDOC_RF3_DBL = vbEmpty
            clsHDR.HDOC_PRO_DCAT = vbEmpty 'cheCat 
            clsHDR.HDOC_PRO_DANO = vbEmpty 'cheCat 
            clsHDR.HDOC_PRO_DNUM = vbEmpty 'cheNum 
            clsHDR.HDOC_DOC_MON = intCurrency
            clsHDR.HDOC_DOC_TC = INT_UNO
            clsHDR.HDOC_USUARIO = Sesion.Usuario
            clsHDR.HDOC_DOC_STATUS = INT_UNO
            If clsHDR.Guardar = False Then
                MsgBox(clsHDR.MERROR.ToString & " Could not save this document ", MsgBoxStyle.Critical)
                Return False
            Else
                logVerificar = True
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        Return logVerificar
    End Function
    Public Sub GenerarLiquidacionCaja(ByVal FechaInicio As Date, ByVal FechaFin As Date, ByVal nLiquidacion As String)
        Dim strSQL As String = STR_VACIO
        Dim strQuery As String = STR_VACIO
        Dim COM As MySqlCommand
        Dim COM2 As MySqlCommand
        Dim REA As MySqlDataReader
        Dim conec As New MySqlConnection
        Try
            For i As Integer = 0 To dgDocumentos.Rows.Count - 1
                If dgDocumentos.Rows(i).Cells("colDocLiquidar").Value = "SI" Then
                    strQuery = " UPDATE Dcmtos_HDR SET HDoc_Pro_DCat = {liq_categoria}, HDoc_Pro_DAno = {liq_anio}, HDoc_Pro_DNum = {liq_numero} "
                    strQuery &= "     WHERE HDoc_Sis_Emp = {empresa} AND HDoc_Doc_Cat = {categoria} AND HDoc_Doc_Ano = {anio} AND HDoc_Doc_Num = {numero}  "
                    If Sesion.IdEmpresa = 18 Then
                        strQuery &= "; UPDATE PDM.Dcmtos_HDR SET HDoc_Pro_DCat = {liq_categoria}, HDoc_Pro_DAno = {liq_anio}, HDoc_Pro_DNum = {liq_numero} "
                        strQuery &= "     WHERE HDoc_Sis_Emp = {empresa} AND HDoc_Doc_Cat = {categoria} AND HDoc_Doc_Ano = {anio} AND HDoc_Doc_Num = {numero}  "
                    End If
                    'Liquidacion 
                    strQuery = Replace(strQuery, "{liq_categoria}", 246)
                    strQuery = Replace(strQuery, "{liq_anio}", Year(FechaInicio))
                    strQuery = Replace(strQuery, "{liq_numero}", nLiquidacion)
                    'Factura
                    strQuery = Replace(strQuery, "{empresa}", Sesion.IdEmpresa)
                    strQuery = Replace(strQuery, "{categoria}", dgDocumentos.Rows(i).Cells("colDocTipo").Value)
                    strQuery = Replace(strQuery, "{anio}", dgDocumentos.Rows(i).Cells("colDocAnio").Value)
                    strQuery = Replace(strQuery, "{numero}", dgDocumentos.Rows(i).Cells("colDocNumero").Value)
                    conec = New MySqlConnection(strConexion)
                    conec.Open()
                    COM2 = New MySqlCommand(strQuery, CON)
                    COM2.ExecuteNonQuery()
                    COM2.Dispose()
                    System.GC.Collect()
                    conec.Close()
                    conec.Dispose()
                    conec = Nothing
                End If
            Next
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub


    Public Sub DesgloseImpuestos()
        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader
        Dim strSQL As String = STR_VACIO
        Dim strfila As String = STR_VACIO

        strSQL = SQLImpuestos()

        Try
            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSQL, CON)
            REA = COM.ExecuteReader

            dgImpuestos.Rows.Clear()

            'If REA.HasRows Then

            Do While REA.Read
                strfila = REA.GetInt32("Linea") & "|"
                strfila &= REA.GetInt32("ID") & "|"
                strfila &= REA.GetString("Codigo") & "|"
                strfila &= REA.GetInt32("Tipo") & "|"
                strfila &= REA.GetString("Descripcion") & "|"
                strfila &= REA.GetInt32("Cantidad") & "|"
                strfila &= REA.GetDouble("factor") & "|"
                strfila &= REA.GetDouble("Base").ToString(FORMATO_MONEDA) & "|"
                strfila &= REA.GetDouble("Monto").ToString(FORMATO_MONEDA) & "|"
                strfila &= REA.GetInt32("Tag") & "|"
                If Me.Tag = "Nuevo" Then
                    strfila &= INT_CERO
                ElseIf Me.Tag = "Mod" Then
                    strfila &= INT_UNO
                End If


                cFunciones.AgregarFila(dgImpuestos, strfila)
            Loop

            'End If

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try

    End Sub

    Private Function PorcentajeIVA()
        Dim strsql As String = STR_VACIO
        Dim Impuesto As Double
        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader
        Dim conec As New MySqlConnection

        Try
            strsql = " SELECT cat_sist IVA "
            strsql &= " From Catalogos c "
            strsql &= " WHERE c.cat_clase = 'Impuestos' AND c.cat_clave ='IVA' AND c.cat_sisemp = {empresa} "

            strsql = Replace(strsql, "{empresa}", Sesion.IdEmpresa)

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try

        Return strsql

    End Function


    Private Sub CalcuarImpuesto()
        Dim base As Double
        Dim cantidad As Double
        Dim factor As Double
        Dim i As Integer
        Dim sumaFila As Integer = 0
        Dim suma As Double
        Dim strSQL As String = STR_VACIO
        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader
        Dim dblImp As Double = 0

        If dgDetalleDocumento.Rows.Count > 0 Then
            For i = 0 To dgDetalleDocumento.Rows.Count - 1
                If dgDetalleDocumento.Rows(i).Cells("colExtra").Value <> 2 Then
                    suma = suma + dgDetalleDocumento.Rows(i).Cells("colTotalD").Value
                End If
            Next
            If (Sesion.IdEmpresa = 15) Or (Sesion.IdEmpresa = 18) Or (Sesion.IdEmpresa = 19) Then
                base = celdaMontoProd.Text * celdaDetalleTC.Text
            Else
                base = suma * celdaDetalleTC.Text
            End If
        Else
            base = 0
        End If

        If checkContribuyent.Checked = True Or Extemporaneo = True Then
            factor = 1
        Else
            strSQL = PorcentajeIVA()
            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSQL, CON)
            REA = COM.ExecuteReader
            If REA.HasRows Then
                REA.Read()
                factor = REA.GetDouble("IVA")
                factor = (factor / 100) + 1
            End If
        End If


        For i = 0 To dgImpuestos.Rows.Count - 1
            sumaFila = sumaFila + 1
        Next

        If sumaFila >= 1 Then

            For i = 0 To dgImpuestos.Rows.Count - 1
                If dgImpuestos.Rows(i).Cells(4).Value = "IVA" Then
                    If checkContribuyent.Checked = True Or Extemporaneo = True Then
                        dgImpuestos.Rows(i).Cells(7).Value = (base)
                        dgImpuestos.Rows(i).Cells(8).Value = INT_CERO.ToString(FORMATO_MONEDA)
                    Else
                        base = base - dblImp
                        cantidad = Math.Round(base / factor, 2)
                        dgImpuestos.Rows(i).Cells(7).Value = cantidad
                        dgImpuestos.Rows(i).Cells(8).Value = (base) - (cantidad)
                    End If
                    Exit For
                Else
                    dblImp = dgImpuestos.Rows(i).Cells(8).Value
                End If
            Next

        End If


    End Sub

    Private Function ComprobarCuenta() As Boolean
        Dim CtaValida As Boolean = True

        Try
            If celdaResponsable.Text = vbNullString Or celdaDescripcion.Text = vbNullString Or celdaidMoneda.Text = vbNullString Then
                MsgBox("You must enter at least the minimum data of the document", vbInformation, "Notice")
                CtaValida = False
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try

        Return CtaValida
    End Function

    Private Function VerificarDetalle() As Boolean
        Dim i As Integer = 0
        Dim LogDetalleValido As Boolean = True

        If dgDetalleDocumento.Rows.Count >= 1 Then

            For i = 0 To dgDetalleDocumento.Rows.Count - 1
                If dgDetalleDocumento.Rows(i).Cells("colExtra").Value <> 2 Then
                    If (dgDetalleDocumento.Rows(i).Cells("colCantidadD").Value = vbEmpty) And
                        (dgDetalleDocumento.Rows(i).Cells("colPrecioD").Value = vbEmpty) And
                        (dgDetalleDocumento.Rows(i).Cells("colTotalD").Value = vbEmpty) And
                        (dgDetalleDocumento.Rows(i).Cells("colDescripcionD").Value = vbNullString) And
                        (dgDetalleDocumento.Rows(i).Cells("colClasificacionD").Value = vbNullString) Then
                        LogDetalleValido = False
                        Exit For
                    ElseIf dgDetalleDocumento.Rows(i).Cells("colDescripcionD").Value = vbNullString Then
                        MsgBox("Row" & i & ": No description", vbExclamation, "Notice")
                        LogDetalleValido = False
                        Exit For
                    ElseIf dgDetalleDocumento.Rows(i).Cells("colGastoD").Value = vbNullString Then
                        MsgBox("Row " & i & ": No Expense account defined", vbExclamation, "Notice")
                        LogDetalleValido = False
                        Exit For
                    ElseIf dgDetalleDocumento.Rows(i).Cells("colCcosto").Value = vbNullString Then
                        MsgBox("Row " & i & ": Cost Center has not been defined", vbExclamation, "Notice")
                        LogDetalleValido = False
                        Exit For
                    ElseIf (dgDetalleDocumento.Rows(i).Cells("colCantidadD").Value = vbEmpty) Or
                        (dgDetalleDocumento.Rows(i).Cells("colPrecioD").Value = vbEmpty) Or
                        (dgDetalleDocumento.Rows(i).Cells("colTotalD").Value = vbEmpty) Or
                        (dgDetalleDocumento.Rows(i).Cells("colDescripcionD").Value = vbNullString) Then
                        LogDetalleValido = False
                        Exit For

                    End If
                End If
            Next
        Else
            LogDetalleValido = False

        End If


        Return LogDetalleValido
    End Function

    Private Function ComprobarIngreso() As Boolean
        Dim strSQL As String = STR_VACIO
        Dim COM As MySqlCommand
        Dim NumFila As Integer
        Dim DateExtemporanea As Date
        Dim LogVerificarIng As Boolean = False
        Dim LogIngresoValido As Boolean = False
        Dim strTexto As String
        Dim strDateExtemporanea As String = STR_VACIO
        Dim strFec As String = STR_VACIO

        If VerificarDetalle() = True Then
            If celdaDetalleNumero.Text = vbNullString Then
                MsgBox("You have not entered the invoice number", vbExclamation, "Notice")
                celdaDetalleNumero.Focus()
                Exit Function
            ElseIf celdaDetalleNumero.Text.Length = INT_CERO Then
                MsgBox("Document number must be different from 0", vbExclamation, "Notice")
                celdaDetalleNumero.Focus()
                Exit Function
            ElseIf dtpDetalleFecha.Value.ToString(FORMATO_MYSQL) > Now Then
                MsgBox("Check the date of the document", vbExclamation, "Notice")
                dtpDetalleFecha.Focus()
                Exit Function
            ElseIf celdaDetalleMonto.Text = INT_CERO.ToString(FORMATO_MONEDA) Then
                MsgBox("Document amount must be greater than zero", vbExclamation, "Notice")
                Exit Function
            ElseIf celdaNumeroCaja.Text = -1 Then
                MsgBox("It was not possible to identify the box number", vbInformation, "Notice")
                Exit Function
            End If

            'Verifica que ingrese beneficiario o proveedor obligatorio
            If celdaProveedor.Text = vbNullString And celdaEmisor.Text = vbNullString Then
                MsgBox("You have not entered supplier or beneficiary name", vbInformation, "Notice")
                Exit Function
            End If

            If celdadetalleIDDocumento.Text = 44 Then
                If celdaidProveedor.Text = vbNullString Then
                    MsgBox("Select Supplier", vbExclamation, "Notice")
                    botonProveedor.Focus()
                    Exit Function
                End If

                strSQL = " SELECT COUNT(*) "
                strSQL &= " From Dcmtos_HDR "
                strSQL &= " WHERE HDoc_Sis_Emp = {empresa} AND HDoc_Doc_Cat = 44 AND HDoc_Emp_Cod = {prov} AND HDoc_DR1_Num = '{NFact}' AND HDoc_DR2_Num = '{serie}' AND NOT(HDoc_Doc_Ano = {anio} AND HDoc_Doc_Num = {num})"

                strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
                strSQL = Replace(strSQL, "{anio}", celdaDetalleAnio.Text)
                strSQL = Replace(strSQL, "{num}", celdaNumeroHDR.Text)
                strSQL = Replace(strSQL, "{prov}", celdaidProveedor.Text)
                strSQL = Replace(strSQL, "{NFact}", celdaDetalleNumero.Text)
                strSQL = Replace(strSQL, "{serie}", celdaDetalleSerie.Text)

                MyCnn.CONECTAR = strConexion
                COM = New MySqlCommand(strSQL, CON)
                NumFila = COM.ExecuteScalar

                If NumFila = 0 Then
                    If Me.Tag = "Nuevo" Then
                        DateExtemporanea = dtpDetalleFecha.Value.ToString(FORMATO_MYSQL)
                        If (Sesion.IdEmpresa = 18) Or (Sesion.IdEmpresa = 15) Or (Sesion.IdEmpresa = 19) Then
                            DateExtemporanea = DateSerial(Year(DateExtemporanea), Month(DateExtemporanea) + 11, 0)
                        Else
                            DateExtemporanea = DateSerial(Year(DateExtemporanea), Month(DateExtemporanea) + 3, 0)
                        End If

                        strDateExtemporanea = CStr(DateExtemporanea.ToString(FORMATO_MYSQL))
                        strFec = CStr(Now().ToString(FORMATO_MYSQL))
                        If strFec > strDateExtemporanea Then
                            If MsgBox("The Document is entering out of time" & vbCrLf & vbCrLf & "NOTE: You want to save anyway", vbExclamation + vbOKCancel, "Notice") = vbCancel Then
                                Exit Function
                            Else
                                Extemporaneo = True
                                CalcuarImpuesto()
                            End If
                        End If
                    End If
                Else
                    strTexto = "The Invoice " & celdaDetalleNumero.Text & " " & celdaDetalleSerie.Text & vbCrLf & vbCrLf & "From " & celdaProveedor.Text & vbCrLf & "Already been admitted before"
                    MsgBox(strTexto, vbExclamation, "Notice")
                    celdaDetalleNumero.Focus()
                    Exit Function
                End If
            End If

            LogIngresoValido = Not (LogVerificarIng)
        End If

        Return LogIngresoValido
    End Function
#End Region

#Region "Eventos"
    Private Sub frmCajaChica_Load(sender As Object, e As EventArgs) Handles Me.Load
        'Encabezado1.botonNuevo.Text = "New petty cash"
        'Encabezado1.botonNuevo.ImageAlign = ContentAlignment.TopCenter
        'Encabezado1.botonNuevo.Width = 70
        Reset()
        Accesos()
        MostrarLista()

    End Sub

    Public Sub HabilitarBotonPermisos()
        Dim strSQL As String = STR_VACIO
        Dim COM As MySqlCommand
        Dim intPermiso As Integer = 0

        strSQL = "  SELECT COUNT(p.pms_codigo) FROM Permisos p WHERE p.pms_empresa = {emp} AND p.pms_modulo = 13 AND p.pms_usuario = '{user}' AND p.pms_codigo = 'PERMISOS' AND p.pms_id = 0 AND p.pms_nivel = 1 "
        strSQL = Replace(strSQL, "{emp}", Sesion.IdEmpresa)
        strSQL = Replace(strSQL, "{user}", Sesion.Usuario)

        MyCnn.CONECTAR = strConexion
        COM = New MySqlCommand(strSQL, CON)
        intPermiso = COM.ExecuteScalar()

        If intPermiso = 1 Then
            botonPermisos.Enabled = True
            Encabezado1.botonNuevo.Enabled = True
        Else
            botonPermisos.Enabled = False
            Encabezado1.botonNuevo.Enabled = False
        End If

    End Sub

    Public Sub LimpiarDetalleCajaChica()
        celdaCodigo.Text = NO_FILA
        checkInactivarCaja.Checked = True
        celdaidMoneda.Clear()
        celdaMoneda.Clear()
        celdaDescMoneda.Clear()
        celdaResponsable.Clear()
        celdaDescripcion.Clear()
        celdaTipoCaja.Clear()
        celdaCuenta.Clear()
        celdaDescCuenta.Clear()
        celdaTotalLiquidar.Clear()
        celdaDisponible.Clear()
        dgDocumentos.Rows.Clear()
        dgOtrosDocumentos.Rows.Clear()
        botonMoneda.Enabled = True
        panelFechas.Enabled = True

    End Sub
    Private Sub dgLista_DoubleClick(sender As Object, e As EventArgs) Handles dgLista.DoubleClick
        Dim numero As Integer
        Dim strNombre As String = STR_VACIO
        Me.Tag = "Mod"
        celdaCAI.BackColor = Color.White
        If dgLista.SelectedRows.Count = INT_CERO Then Exit Sub
        Reset()
        LimpiarDetalleCajaChica()
        MostrarLista(1)
        botonMoneda.Enabled = False
        numero = dgLista.SelectedCells(0).Value
        strNombre &= dgLista.SelectedCells(4).Value & " / " & dgLista.SelectedCells(2).Value
        CargarCuentaBancaria(numero, strNombre)
        CargarDocumentosCajaChica(numero)
        SaldoCaja(numero)
    End Sub

    Private Sub botonNuevoDoc_Click(sender As Object, e As EventArgs) Handles botonNuevoDoc.Click
        Me.Tag = "Nuevo"
        LimpiarDetalleDoc()
        BloquearCuandoEsRecibo(False)
        celdaNumeroCaja.Text = celdaCodigo.Text
        If Sesion.idGiro = 2 Or Sesion.IdEmpresa = 11 Then
            celdaCAI.Visible = True
            etiquetaCAI.Visible = True
            'dgDetalleDocumento.Columns(7).ReadOnly = True ' columna de Precio
            checkContribuyent.Text = "Does not Generate VAT"
        Else
            celdaCAI.Visible = False
            etiquetaCAI.Visible = False
            checkContribuyent.Text = "Small Taxpayer / Import "
        End If
        MostrarLista(2)

    End Sub
    Private Sub botonMoneda_Click(sender As Object, e As EventArgs) Handles botonMoneda.Click
        Dim frm As New frmSeleccionar
        Try
            frm.Titulo = "Select a Currency"
            frm.Campos = " c.cat_clave Moneda, c.cat_num ID, cat_desc Simbolo "
            frm.Tabla = " Catalogos c "
            frm.FiltroText = " Enter The Name Of The Currency To Filter "
            frm.Filtro = "  c.cat_clave  "
            frm.Condicion = " cat_clase='Monedas' ORDER BY c.cat_clave LIMIT 5"

            frm.ShowDialog(Me)
            If frm.DialogResult = System.Windows.Forms.DialogResult.OK Then
                celdaMoneda.Text = frm.LLave
                celdaidMoneda.Text = frm.Dato
                celdaDescMoneda.Text = frm.Dato2
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub
    Private Sub botonDocumento_Click(sender As Object, e As EventArgs) Handles botonDocumento.Click
        Dim frm As New frmSeleccionar
        Dim strTabla As String = STR_VACIO

        Try
            strTabla = "( SELECT DISTINCT BMov_Cat_Doc ID From MvtosBcos "
            '   strTabla = Replace(strTabla, "{empresa}", Sesion.IdEmpresa)
            '  strTabla = Replace(strTabla, "{cod}", celdaCodigo.Text)
            frm.Titulo = "Document"
            frm.Campos = "a.ID, c.cat_desc Descripcion "
            frm.Tabla = strTabla
            frm.Condicion = "  BMov_Sis_Emp = " & Sesion.IdEmpresa & " AND BMov_Cta = " & celdaCodigo.Text & " AND BMov_Cat_Doc > 0) a LEFT JOIN Catalogos c ON c.cat_num = a.ID "
            frm.ShowDialog(Me)
            If frm.DialogResult = System.Windows.Forms.DialogResult.OK Then
                celdaidDocumento.Text = frm.LLave
                celdaDocumento.Text = frm.Dato
                checkTodo.Checked = False
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try

    End Sub
    Private Sub checkTodo_CheckedChanged(sender As Object, e As EventArgs) Handles checkTodo.CheckedChanged
        If checkTodo.Checked = True Then
            celdaDocumento.Text = "ALL"
            celdaidDocumento.Text = vbEmpty
            'Else
            '    celdaDocumento.Text = STR_VACIO
        End If
    End Sub
    Private Sub botonRecargar_Click(sender As Object, e As EventArgs) Handles botonRecargar.Click
        CargarDocumentosCajaChica(celdaCodigo.Text)
        SaldoCaja(celdaCodigo.Text)
    End Sub
    Private Sub checkSeleccionar_CheckedChanged(sender As Object, e As EventArgs) Handles checkSeleccionar.CheckedChanged
        If checkSeleccionar.Checked = True Then
            MarcarLiquidacion(True)
            CalcularTotales()
        Else
            MarcarLiquidacion(False)
            CalcularTotales()
        End If
    End Sub
    Private Sub botnEditar_Click(sender As Object, e As EventArgs) Handles botnEditar.Click
        If dgImpuestos.SelectedCells(0).Value <> 2 Then
            Dim totalBase As Double
            Dim i As Integer
            Dim frm As New frmDatosImpuestos
            frm.checkMonto.Checked = False
            frm.celdaTotalOpcional.Enabled = False

            If Me.Tag = "Mod" Then
                frm.Dato1 = dgImpuestos.CurrentRow.Cells("colDescripcion1").Value
                frm.Dato2 = dgImpuestos.CurrentRow.Cells("colFactor").Value
                frm.Dato3 = dgImpuestos.CurrentRow.Cells("colCantidad1").Value
                frm.Dato4 = dgImpuestos.CurrentRow.Cells("colMonto").Value
                frm.CargarDatos()
            End If

            frm.ShowDialog(Me)

            If frm.DialogResult = System.Windows.Forms.DialogResult.OK Then
                If dgImpuestos.SelectedCells(0).Value = 1 Then

                    dgImpuestos.SelectedCells(4).Value = frm.Dato1
                    dgImpuestos.SelectedCells(5).Value = frm.Dato3
                    dgImpuestos.SelectedCells(6).Value = frm.Dato2
                    dgImpuestos.SelectedCells(8).Value = frm.Dato4
                    totalBase = celdaDetalleMonto.Text - frm.Dato4
                    dgImpuestos.SelectedCells(7).Value = Math.Round(totalBase, 2)
                    'dgImpuestos.Rows(0).Cells(7).Value = Math.Round((totalBase / 1.12), 2)
                    'dgImpuestos.Rows(0).Cells(8).Value = Math.Round((totalBase) - (totalBase / 1.12), 2)

                Else
                End If

                If dgImpuestos.SelectedCells(5).Value > 0 Then

                    For i = 0 To dgImpuestos.Rows.Count - 1
                        If dgImpuestos.Rows(i).Cells(0).Value = 2 Then
                            dgImpuestos.Rows(i).Cells(7).Value = Math.Round((totalBase / 1.12), 2)
                            dgImpuestos.Rows(i).Cells(8).Value = Math.Round((totalBase) - (totalBase / 1.12), 2)
                            Exit For
                        End If
                    Next
                Else
                End If
            End If

        Else

        End If
    End Sub
    Private Sub botonOtrosImp_Click(sender As Object, e As EventArgs) Handles botonOtrosImp.Click
        Dim strRemplazo As String = STR_VACIO
        Dim strfila As String = STR_VACIO
        Dim dblImpuestoIVA As Double = 0

        Dim frm As New frmSeleccionar

        strRemplazo = "c.cat_sisemp = {empresa}"
        strRemplazo = Replace(strRemplazo, "{empresa}", Sesion.IdEmpresa)

        Try

            frm.Titulo = "Other Taxes"
            frm.Campos = "d.cat_pid Linea, If(i.cat_pid = 0, i.cat_clave, i.cat_desc) Descripcion, d.cat_num ID"
            frm.Tabla = " Catalogos c LEFT JOIN Catalogos i ON i.cat_sisemp=c.cat_sisemp And i.cat_clase='Impuestos' AND i.cat_clave=c.cat_sist LEFT JOIN Catalogos d ON d.cat_sisemp=i.cat_sisemp AND d.cat_clase='DocImpuesto' AND d.cat_clave='Doc_PFactura' AND d.cat_sist=i.cat_clave"
            frm.FiltroText = "Enter the other taxes to filter"
            frm.Filtro = "Descripcion"
            frm.Ordenamiento = "d.cat_pid"
            frm.Agrupar = "i.cat_num"
            frm.TipoOrdenamiento = ""
            frm.Condicion = strRemplazo & " AND c.cat_clase='Contabilidad' AND c.cat_clave='Cuenta' AND NOT(i.cat_clave IN ('IVA')) AND NOT(ISNULL(d.cat_num))"

            frm.ShowDialog(Me)
            'If frm.LLave = 1 Then

            If frm.DialogResult = System.Windows.Forms.DialogResult.OK Then

                For i As Integer = 0 To dgImpuestos.Rows.Count - 1
                    If dgImpuestos.Rows(i).Cells("colDescripcion1").Value = "IVA" Then
                        dblImpuestoIVA = dgImpuestos.Rows(i).Cells("colBase").Value
                    End If
                Next

                strfila = frm.LLave & "|"
                strfila &= frm.Dato2 & "|"
                strfila &= "IMP_DC" & "|"
                strfila &= INT_UNO & "|"
                strfila &= frm.Dato & "|"
                strfila &= 0 & "|"
                strfila &= 0 & "|"
                strfila &= dblImpuestoIVA & "|"
                strfila &= 0 & "|"
                strfila &= 0 & "|"
                strfila &= 0

                cFunciones.AgregarFila(dgImpuestos, strfila)


                'dgImpuestos.Sort(dgFacturas.Columns("colLine"), ListSortDirection.Ascending)

            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub
    Private Sub botonEliminar_Click(sender As Object, e As EventArgs) Handles botonEliminar.Click
        'If dgImpuestos.SelectedCells(0).Value <> 2 Then
        'Me.dgImpuestos.Rows.Remove(dgImpuestos.CurrentRow)
        'Else
        ' End If
        Try
            Dim Count As Integer
            If dgImpuestos.SelectedCells(0).Value <> 2 Then

                If dgImpuestos.SelectedRows Is Nothing Then Exit Sub
                If dgImpuestos.Rows.Count > 1 Then
                    Count = dgImpuestos.Rows.GetRowCount(DataGridViewElementStates.Selected)
                    For i As Integer = 0 To Count - 1
                        '  strTexto = "Remove " & CStr(dgCotizacion.SelectedCells(1).Value) & vbCrLf
                        If MsgBox("You sure you want to delete the row " & "OF THE ORDER " &
                    CInt(dgImpuestos.SelectedCells(0).Value) & ", " &
               CStr(dgImpuestos.SelectedCells(4).Value) & " ," &
                CStr(dgImpuestos.SelectedCells(5).Value) & " ," &
                   CStr(dgImpuestos.SelectedCells(7).Value) & "?", vbQuestion + vbYesNo + vbDefaultButton2) =
                    vbYes Then
                            If dgImpuestos.SelectedCells(10).Value = 0 Or dgImpuestos.SelectedCells(10).Value = 1 Then
                                dgImpuestos.SelectedCells(10).Value = 2
                                If dgImpuestos.SelectedCells(10).Value = 2 Then
                                    dgImpuestos.CurrentRow.Visible = False
                                    CalcuarImpuesto()
                                End If
                            ElseIf dgImpuestos.Rows(i).Selected = Nothing Then
                                '  dgDetalle.SelectedCells(6).Value = 3
                                ' dgDetalle.CurrentRow.Visible = False
                                dgImpuestos.Rows.RemoveAt(dgImpuestos.RowCount - 1)
                            End If
                        End If
                    Next
                Else
                    MsgBox("you can not delete the last row")
                    Exit Sub
                End If
            End If
            dgImpuestos.ReadOnly = False
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub botonReportes_Click(sender As Object, e As EventArgs) Handles botonReportes.Click
        Dim frm As New frmSeleccionar
        Dim strTabla As String = STR_VACIO
        Dim rst As New clsReportes

        Try
            strTabla = "      (  SELECT t.cat_clave Coin,h.HDoc_DR1_Num N,h.HDoc_DR1_Fec Since, h.HDoc_DR2_Fec UNTIL, h.HDoc_Doc_Num ID, h.HDoc_Doc_Ano Anio, h.HDoc_Doc_Fec Fecha, ( "
            strTabla &= "            SELECT h1.HDoc_DR1_Num "
            strTabla &= "               FROM Dcmtos_HDR h1 "
            strTabla &= "                   WHERE h1.HDoc_Sis_Emp = h.HDoc_Sis_Emp AND h1.HDoc_Doc_Cat = h.HDoc_Pro_DCat AND h1.HDoc_Doc_Ano = h.HDoc_Pro_DAno AND h1.HDoc_Doc_Num = h.HDoc_Pro_DNum) Cheque, ROUND(IF(h.HDoc_RF2_Dbl=0, h.HDoc_RF1_Dbl, h.HDoc_RF2_Dbl),2) Total, p.poliza Poliza "
            strTabla &= "                       FROM Dcmtos_HDR h "
            strTabla &= "                           LEFT JOIN CtasBcos c ON c.BCta_Sis_Emp = h.HDoc_Sis_Emp AND c.BCta_Num = h.HDoc_DR1_Cat AND c.BCta_Tipo = 1 "
            strTabla &= "                           LEFT JOIN Catalogos t ON t.cat_num = h.HDoc_Doc_Mon AND t.cat_clase = 'Monedas' "
            strTabla &= "               LEFT JOIN " & cFunciones.ContaEmpresa & ".polizas p ON p.empresa = h.HDoc_Sis_Emp AND p.ref_tipo = h.HDoc_Doc_Cat AND p.ref_ciclo = h.HDoc_Doc_Ano AND p.ref_numero = h.HDoc_Doc_Num "
            strTabla &= "                               WHERE h.HDoc_Sis_Emp = " & Sesion.IdEmpresa & "  AND h.HDoc_Doc_Cat = 246 AND h.HDoc_DR1_Cat = " & celdaCodigo.Text & "  ORDER BY h.HDoc_Doc_Ano DESC, h.HDoc_Doc_Num DESC ) c1 "
            '   strTabla = Replace(strTabla, "{empresa}", Sesion.IdEmpresa)
            '  strTabla = Replace(strTabla, "{cod}", celdaCodigo.Text)
            frm.Titulo = "Document"
            frm.Campos = "   c1.N , c1.Since , c1.UNTIL , c1.ID , c1.Anio , c1.Fecha,c1.Cheque,c1.Coin, c1.Total, c1.Poliza  "
            frm.Tabla = strTabla
            frm.Filtro = "  c1.cheque "
            frm.Condicion = "     c1.id >0 "
            frm.ShowDialog(Me)
            If frm.DialogResult = System.Windows.Forms.DialogResult.OK Then
                rst.ImprimirReporte(celdaCodigo.Text, frm.ListaClientes.SelectedCells(3).Value, frm.ListaClientes.SelectedCells(4).Value, celdaTipoCaja.Text)
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub botonBorrarLiquidacion_Click(sender As Object, e As EventArgs) Handles botonBorrarLiquidacion.Click
        Dim frm As New frmSeleccionar
        Dim strTabla As String = STR_VACIO
        Dim Anio As Integer
        Dim Numero As Integer
        Try
            strTabla = "        Dcmtos_HDR h "
            strTabla &= "           LEFT JOIN CtasBcos c ON c.BCta_Sis_Emp = h.HDoc_Sis_Emp AND c.BCta_Num = h.HDoc_DR1_Cat AND c.BCta_Tipo = 1 "
            '   strTabla = Replace(strTabla, "{empresa}", Sesion.IdEmpresa)
            '  strTabla = Replace(strTabla, "{cod}", celdaCodigo.Text)
            frm.Titulo = "Document"
            frm.Campos = " h.HDoc_Doc_Ano Anio, h.HDoc_DR1_Num Numero, h.HDoc_DR1_Fec Inicio, h.HDoc_DR2_Fec Fin, h.HDoc_Doc_Fec Fecha, h.HDoc_Usuario Usuario, IFNULL((  SELECT h1.HDoc_DR1_Num  FROM Dcmtos_HDR h1  WHERE h1.HDoc_Sis_Emp = h.HDoc_Sis_Emp AND h1.HDoc_Doc_Cat = h.HDoc_Pro_DCat AND h1.HDoc_Doc_Ano = h.HDoc_Pro_DAno AND h1.HDoc_Doc_Num = h.HDoc_Pro_DNum),'N/A') Cheque, IF(h.HDoc_RF2_Dbl=0, h.HDoc_RF1_Dbl, h.HDoc_RF2_Dbl) Total, c.BCta_Des_Cue Origen, h.HDoc_Doc_Num NoLQ "
            frm.Tabla = strTabla
            frm.Condicion = "   h.HDoc_Sis_Emp = " & Sesion.IdEmpresa & " AND h.HDoc_Doc_Cat = 246 AND h.HDoc_DR1_Cat = " & celdaCodigo.Text & " AND h.HDoc_Pro_DCat = 0 "
            MsgBox("You need authorization to delete Liquidations", vbInformation, "Notice")
            If cfun.AutorizarBorrarLiquidacion = True Then
                frm.ShowDialog(Me)
                If frm.DialogResult = System.Windows.Forms.DialogResult.OK Then


                    If MsgBox("Are You sure " & vbCr & vbCr & "¿do you want to delete this document? ", vbQuestion + vbYesNo, "Aviso") = vbYes Then
                        EliminarReporte(frm.ListaClientes.SelectedCells(9).Value, frm.ListaClientes.SelectedCells(0).Value)
                        cFunciones.BorrarEncabezadoPoliza(frm.ListaClientes.SelectedCells(9).Value, frm.ListaClientes.SelectedCells(0).Value, 246)
                        cFunciones.BorrarDetallePoliza(frm.ListaClientes.SelectedCells(9).Value, frm.ListaClientes.SelectedCells(0).Value, 246)
                    End If

                Else
                    Exit Sub
                End If
            Else
                Me.DialogResult = System.Windows.Forms.DialogResult.Cancel
                Exit Sub

            End If



        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub BotonImpreso_Click(sender As Object, e As EventArgs) Handles BotonImpreso.Click
        Dim fechaInicio As Date
        Dim FechaFin As Date
        Dim rst As New clsReportes
        Dim LogPrimerLinea As Boolean = False
        Dim logValidacion As Boolean = False
        Dim i As Integer
        Dim strCamposQuery As String = STR_VACIO
        Dim intCuentaSelect As Integer = 0


        For i = 0 To dgDocumentos.Rows.Count - 1
            If LogPrimerLinea = False Then
                fechaInicio = dgDocumentos.Rows(i).Cells("colDocFecha").Value
                LogPrimerLinea = True
            End If
            If dgDocumentos.Rows(i).Cells("colDocLiquidar").Value = "SI" Then
                If intCuentaSelect = 0 Then
                    intCuentaSelect = 1
                    strCamposQuery = "(h.HDoc_Doc_Num = {num} AND h.HDoc_Doc_Ano = {anio} AND h.HDoc_Doc_Cat = {cat})"
                    strCamposQuery = Replace(strCamposQuery, "{num}", dgDocumentos.Rows(i).Cells("colDocNumero").Value)
                    strCamposQuery = Replace(strCamposQuery, "{anio}", dgDocumentos.Rows(i).Cells("colDocAnio").Value)
                    strCamposQuery = Replace(strCamposQuery, "{cat}", dgDocumentos.Rows(i).Cells("colDocTipo").Value)
                Else
                    strCamposQuery = strCamposQuery & " OR (h.HDoc_Doc_Num = {num} AND h.HDoc_Doc_Ano = {anio} AND h.HDoc_Doc_Cat = {cat})"
                    strCamposQuery = Replace(strCamposQuery, "{num}", dgDocumentos.Rows(i).Cells("colDocNumero").Value)
                    strCamposQuery = Replace(strCamposQuery, "{anio}", dgDocumentos.Rows(i).Cells("colDocAnio").Value)
                    strCamposQuery = Replace(strCamposQuery, "{cat}", dgDocumentos.Rows(i).Cells("colDocTipo").Value)
                End If

                logValidacion = True
            End If
            FechaFin = dgDocumentos.Rows(i).Cells("colDocFecha").Value
        Next
        If logValidacion = True Then
            rst.ImprimirDocumento(NuevaLiquidacion(), strCamposQuery, fechaInicio, FechaFin, celdaTipoCaja.Text, celdaResponsable.Text, celdaDescripcion.Text, celdaCodigo.Text, Val(celdaDisponible.Text))
        End If

    End Sub

    Private Sub BotonLiquidar_Click(sender As Object, e As EventArgs) Handles botonLiquidar.Click
        Dim logCheque As Boolean = False
        Dim strSQL As String = STR_VACIO
        Dim COM As MySqlCommand
        Dim intExisteCierre As Integer
        If MsgBox("Are You sure " & vbCr & vbCr & "¿do you want to generate this liquidation? ", vbQuestion + vbYesNo, "liquidation") = vbYes Then
            logCheque = checkSeleccionar.Checked
            'Verifica si hay cierre
            strSQL = " Select Count(*) From Cierre_Encabezado e Where e.CE_Empresa = {emp} and e.CE_Anio = {anio} and e.CE_Fecha_Final >= '{fec}' "
            strSQL = Replace(strSQL, "{emp}", Sesion.IdEmpresa)
            strSQL = Replace(strSQL, "{anio}", cfun.AñoMySQL)
            strSQL = Replace(strSQL, "{fec}", cfun.HoyMySQL.ToString(FORMATO_MYSQL))

            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSQL, CON)
            intExisteCierre = COM.ExecuteScalar
            ' 0 --> no existe Cierre
            If intExisteCierre = 0 Then
                GenerarLiquidacion(NuevoCodigo, NuevaLiquidacion, logCheque)
            Else
                'Si hay cierre solicita autorización para modificar
                MsgBox("You need authorization to modify this document", vbInformation, "Notice")
                If cfun.AutorizarCambios = True Then
                    GenerarLiquidacion(NuevoCodigo, NuevaLiquidacion, logCheque)
                End If
            End If
        End If
    End Sub

    Private Sub BotonCuenta_Click(sender As Object, e As EventArgs) Handles botonCuenta.Click
        Dim Condicion As String = STR_VACIO
        Dim condicion1 As String = STR_VACIO
        Dim frm As New frmSeleccionar

        Condicion = "Empresa = {empresa}  "

        Condicion = Replace(Condicion, "{empresa}", Sesion.IdEmpresa)
        condicion1 = "{conta}"
        condicion1 = Replace(condicion1, "{conta}", cFunciones.ContaEmpresa)
        'Datospara mostrar en pantalla
        frm.Titulo = "Expenses"
        frm.FiltroText = "Enter the Name Expense To Filter "

        'Datos de Base para Llenar Grid
        frm.Campos = "id_cuenta, nombre"
        frm.Tabla = condicion1 & ".cuentas"
        frm.Condicion = Condicion
        frm.Limite =
        frm.Ordenamiento = "id_cuenta"
        frm.Filtro = " nombre"

        'Mostrar formulario
        frm.ShowDialog(Me)

        If frm.DialogResult = System.Windows.Forms.DialogResult.OK Then
            celdaCuenta.Text = frm.LLave
            celdaDescCuenta.Text = frm.Dato
        End If
    End Sub

    Private Sub botonProveedor_Click(sender As Object, e As EventArgs) Handles botonProveedor.Click
        Dim strRemplazo As String = STR_VACIO
        Dim frm As New frmSeleccionar
        Dim strFila As String = STR_VACIO

        strRemplazo = "p.pro_sisemp = {empresa}"
        strRemplazo = Replace(strRemplazo, "{empresa}", Sesion.IdEmpresa)


        Try
            frm.Titulo = "Providers"
            frm.Campos = "p.pro_codigo id, p.pro_proveedor Proveedor, p.pro_iva SIVA, p.pro_nit nit, p.pro_servicio Categoria"
            frm.Tabla = "Proveedores p"
            frm.FiltroText = "Enter the provider to filter"
            frm.Filtro = "p.pro_proveedor"
            frm.Ordenamiento = "p.pro_proveedor, p.pro_status"
            frm.TipoOrdenamiento = ""
            frm.Condicion = strRemplazo

            frm.ShowDialog(Me)

            If frm.DialogResult = System.Windows.Forms.DialogResult.OK Then
                celdaProveedor.Text = frm.Dato
                celdaidProveedor.Text = frm.LLave
                celdaDetalleNit.Text = frm.Dato3
                'botonMas.Enabled = True
                If frm.Dato2 = 0 Then
                    checkContribuyent.Checked = True
                    celdaDetalleDoc.Text = "DOES NOT GENERATE RIGHT TO TAX CREDIT"
                    celdaDetalleDoc.BackColor = Color.Red
                    celdaDetalleDoc.TextAlign = HorizontalAlignment.Center
                    If Sesion.IdEmpresa = 12 Or Sesion.IdEmpresa = 10 Or Sesion.IdEmpresa = 9 Or Sesion.IdEmpresa = 3 Then
                        checkFacElectrónica.Checked = False
                    End If

                ElseIf frm.Dato2 = 1 Then
                    checkContribuyent.Checked = False
                    celdaDetalleDoc.Text = "INVOICE DETAIL"
                    celdaDetalleDoc.BackColor = Color.RoyalBlue
                    celdaDetalleDoc.TextAlign = HorizontalAlignment.Left
                    celdaDetalleDoc.ForeColor = Color.White
                    If Sesion.IdEmpresa = 12 Or Sesion.IdEmpresa = 10 Or Sesion.IdEmpresa = 9 Or Sesion.IdEmpresa = 3 Then
                        checkFacElectrónica.Checked = True

                    End If

                End If
                If frm.Dato4 = 1 Then
                    frm.Dato4 = "SERVICIO"
                Else
                    frm.Dato4 = "BIEN"
                End If



            End If

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub botonMas_Click(sender As Object, e As EventArgs) Handles botonMas.Click
        Dim i As Integer = 0
        Dim StrSQL As String = STR_VACIO
        Dim COM As MySqlCommand
        Dim strClass As String = STR_VACIO
        dgDetalleDocumento.Rows.Add()

        If celdaidProveedor.Text = vbNullString Or celdaidProveedor.Text = "0" Then
            strClass = "BIEN"
        Else
            StrSQL = " SELECT IF(p.pro_servicio = 0,'BIEN','SERVICIO') Class FROM Proveedores p WHERE p.pro_sisemp = {emp} AND p.pro_codigo = {cod} "
            StrSQL = Replace(StrSQL, "{emp}", Sesion.IdEmpresa)
            StrSQL = Replace(StrSQL, "{cod}", celdaidProveedor.Text)
            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(StrSQL, CON)
            strClass = COM.ExecuteScalar
        End If

        For i = 0 To dgDetalleDocumento.Rows.Count - 1
            i = i + 1
        Next
        dgDetalleDocumento.Rows(dgDetalleDocumento.Rows.Count - 1).Selected = True
        dgDetalleDocumento.SelectedCells(0).Value = 0
        dgDetalleDocumento.SelectedCells(6).Value = INT_CERO.ToString(FORMATO_MONEDA)
        dgDetalleDocumento.SelectedCells(7).Value = INT_CERO.ToString(FORMATO_MONEDA)
        dgDetalleDocumento.SelectedCells(8).Value = INT_CERO.ToString(FORMATO_MONEDA)
        dgDetalleDocumento.SelectedCells(15).Value = STR_VACIO
        dgDetalleDocumento.SelectedCells(17).Value = STR_VACIO
        dgDetalleDocumento.SelectedCells(18).Value = strClass
        dgDetalleDocumento.SelectedCells(20).Value = 0
    End Sub

    Private Sub checkContribuyent_CheckedChanged(sender As Object, e As EventArgs) Handles checkContribuyent.CheckedChanged
        If checkContribuyent.Checked = True Then
            celdaDetalleDoc.Text = "DOES NOT GENERATE RIGHT TO TAX CREDIT"
            celdaDetalleDoc.TextAlign = HorizontalAlignment.Center
            celdaDetalleDoc.BackColor = Color.Red
            celdaDetalleDoc.ForeColor = Color.White
        Else
            celdaDetalleDoc.Text = "INVOICE DETAIL"
            celdaDetalleDoc.BackColor = Color.RoyalBlue
            celdaDetalleDoc.TextAlign = HorizontalAlignment.Left
            celdaDetalleDoc.ForeColor = Color.White
        End If


        DesgloseImpuestos()
        CalcuarImpuesto()

    End Sub

    Private Sub Encabezado1_ClickNuevo(sender As Object, click As Boolean) Handles Encabezado1.ClickNuevo
        Dim op As New frmOption
        Me.Tag = "Nuevo"
        LimpiarDetalleCajaChica()

        op.Opciones = "Petty Cash |" & "Travel expenses |" & " Credit card"
        op.Titulo = "Document type"
        op.ShowDialog(Me)
        If op.DialogResult = System.Windows.Forms.DialogResult.OK Then
            Select Case op.Seleccion
                Case 0
                    celdaTipoCaja.Text = 1
                    BarraTitulo1.CambiarTitulo("New Petty Cash")
                Case 1
                    celdaTipoCaja.Text = 2
                    BarraTitulo1.CambiarTitulo("New Travel Expenses")
                Case 2
                    celdaTipoCaja.Text = 3
                    BarraTitulo1.CambiarTitulo("New Credit Card")
            End Select
            panelFechas.Enabled = False
            MostrarLista(1)
        End If

    End Sub

    Private Sub Encabezado1_ClickGuardar(sender As Object, click As Boolean) Handles Encabezado1.ClickGuardar
        Dim strSQL As String = STR_VACIO
        Dim COM As MySqlCommand
        Dim intExisteCierre As Integer

        If panelDocumento.Visible = True Then
            celdaDetalleAnio.Text = Year(dtpDetalleFecha.Value)
            'If celdadetalleIDDocumento.Text = 44 Then
            'Verifica si hay cierre
            strSQL = " Select Count(*) From Cierre_Encabezado e Where e.CE_Empresa = {emp} and e.CE_Anio = {anio} and e.CE_Fecha_Final >= '{fec}' "
            strSQL = Replace(strSQL, "{emp}", Sesion.IdEmpresa)
            strSQL = Replace(strSQL, "{anio}", Year(dtpDetalleFecha.Value.ToString(FORMATO_MYSQL)))
            strSQL = Replace(strSQL, "{fec}", dtpDetalleFecha.Value.ToString(FORMATO_MYSQL))

            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSQL, CON)
            intExisteCierre = COM.ExecuteScalar
            'VALIDAR CAMPOS LLENOS...
            If Sesion.IdEmpresa = 11 And celdadetalleIDDocumento.Text = "44" And ComprobarDatos() = False Then
                MsgBox("You must enter all minimum data", vbCritical)
                celdaCAI.BackColor = Color.Orange
                Exit Sub
            End If


            If Year(dtpDetalleFecha.Value) <> Year(Now) Then
                If Month(dtpDetalleFecha.Value) = 12 Then
                    If intExisteCierre = 0 Then
                        ValidacionEInsercion()
                    Else
                        MsgBox("This document cannot be saved, please contact the financial department", vbCritical)
                    End If
                Else
                    'Verifica si hay cierre en diciembre cuando la factura no es de diciembre, y ya estamos en otro año
                    strSQL = " Select Count(*) From Cierre_Encabezado e Where e.CE_Empresa = {emp} and e.CE_Anio = {anio} and e.CE_Fecha_Final >= '{fec}' "
                    strSQL = Replace(strSQL, "{emp}", Sesion.IdEmpresa)
                    strSQL = Replace(strSQL, "{anio}", Year(dtpDetalleFecha.Value.ToString(FORMATO_MYSQL)))
                    strSQL = Replace(strSQL, "{fec}", (DateSerial(Year(dtpDetalleFecha.Value), 12, 1).ToString(FORMATO_MYSQL)))

                    MyCnn.CONECTAR = strConexion
                    COM = New MySqlCommand(strSQL, CON)
                    intExisteCierre = COM.ExecuteScalar

                    If intExisteCierre = 0 Then
                        ValidacionEInsercion()
                    Else
                        MsgBox("This document cannot be saved, please contact the financial department", vbCritical)
                    End If

                End If

            Else
                ValidacionEInsercion()
            End If
            'Else
            '    ValidacionEInsercion()
            'End If
        ElseIf panelDetalleCaja.Visible = True Then
            ProcesoGuardarCajaChica()
        End If

    End Sub

    Public Sub ValidacionEInsercion()
        Dim clsConta As New clsContabilidad
        Dim dtpFechaConta As Date

        If Me.Tag = "Nuevo" Then
            ProcesoGuardarCajaChica()
        ElseIf Me.Tag = "Mod" Then
            dtpFechaConta = cfun.SQLValidarFechaContable(celdadetalleIDDocumento.Text, celdaDetalleAnio.Text, celdaNumeroHDR.Text)
            'Verifica si hay cierre (0---> No hay cierre 
            If cfun.SQLVerificarCierre(celdadetalleIDDocumento.Text, celdaDetalleAnio.Text, celdaNumeroHDR.Text) = 0 Then
                ProcesoGuardarCajaChica()
                ' If celdadetalleIDDocumento.Text = 44 Then
                clsConta.GenerarPoliza(celdadetalleIDDocumento.Text, celdaDetalleAnio.Text, celdaNumeroHDR.Text, dtpFechaPolizaC.Value.ToString(FORMATO_MYSQL))
                ' End If
            Else
                'If celdadetalleIDDocumento.Text = 44  Then
                'Si hay Cierre solicita autorizacion para modificar 
                MsgBox("You need authorization to modify this document ", vbInformation, "Notice")
                If cfun.AutorizarCambios = True Then
                    'Registra quien autoriza la modificacion 
                    cfun.EscribirRegistro("Dcmtos_HDR", clsFunciones.AccEnum.acConfirm, celdaNumeroCaja.Text, celdadetalleIDDocumento.Text, celdaDetalleAnio.Text, celdaNumeroHDR.Text)
                    ProcesoGuardarCajaChica()
                    clsConta.GenerarPoliza(celdadetalleIDDocumento.Text, celdaDetalleAnio.Text, celdaNumeroHDR.Text, dtpFechaPolizaC.Value.ToString(FORMATO_MYSQL))
                Else
                    EnviarCorreoAlCancelar()
                End If
                'Else
                '    ProcesoGuardarCajaChica()
                'End If
            End If
        End If
    End Sub

    Public Sub EnviarCorreoAlCancelar()
        Dim ArrayServer() As String
        Dim ArrayAuxiliar() As String
        Dim strConexion2 As String = STR_VACIO
        Dim strInsert As String = STR_VACIO
        Dim COMM As MySqlCommand
        Dim LLave As String = STR_VACIO
        Dim conec2 As MySqlConnection

        ArrayServer = strConexion.Split(";".ToCharArray)

        strConexion2 = "server={server};port={puerto};uid={user};password={password};database={database} ;Allow User Variables=True"
        ArrayAuxiliar = ArrayServer(INT_CERO).Split("=".ToCharArray)

        If ArrayAuxiliar(INT_UNO) = "192.168.4.9" Then
            strConexion2 = Replace(strConexion2, "{server}", MAIL_HOST)
            strConexion2 = Replace(strConexion2, "port={puerto};", vbNullString)
        Else
            strConexion2 = Replace(strConexion2, "{server}", MAIL_HOST_REMOTO)
            strConexion2 = Replace(strConexion2, "{puerto}", "3308")
        End If

        strConexion2 = Replace(strConexion2, "{user}", MAIL_USER)
        strConexion2 = Replace(strConexion2, "{password}", MAIL_PASS)
        strConexion2 = Replace(strConexion2, "{database}", MAIL_BASE)

        LLave = celdadetalleIDDocumento.Text & "-" & celdaDetalleAnio.Text & "-" & celdaNumeroHDR.Text & " --> " & Sesion.Usuario
        strInsert &= ("INSERT INTO MailServer.Correo (idCorreo,Destinatario,Asunto,Contenido,Estado) Values(0,'" & "tisoportegt@grupokarims.com, delia.ramirez@grupokarims.com'" & "," & "'Alteración de Póliza'" & ",'" & LLave & "',0)")

        conec2 = New MySqlConnection(strConexion2)
        conec2.Open()
        Using conec2
            COMM = New MySqlCommand(strInsert, conec2)
            COMM.ExecuteNonQuery()
            COMM.Dispose()
            System.GC.Collect()

            COMM.Dispose()
            COMM = Nothing
            conec2.Close()
            conec2.Dispose()
            conec2 = Nothing
            System.GC.Collect()
        End Using
    End Sub

    Public Sub BloquearCuandoEsRecibo(ByVal bloqueo As Boolean)
        If bloqueo = False Then
            checkContribuyent.Enabled = True
            checkFacElectrónica.Enabled = True
        Else
            checkContribuyent.Enabled = False
            checkFacElectrónica.Enabled = False
        End If

    End Sub

    Private Sub botonDocumentos_Click(sender As Object, e As EventArgs) Handles botonDocumentos.Click
        Dim frm As New frmSeleccionar
        Dim strTabla As String = STR_VACIO

        Try
            If Sesion.idGiro = 2 Then
                strTabla = " Catalogos c "
                frm.Titulo = "Document"
                frm.Campos = "c.cat_num ID, c.cat_desc Descripcion "
                frm.Tabla = strTabla
                frm.Condicion = " c.cat_clase ='Documentos' AND c.cat_sisemp = " & Sesion.IdEmpresa
            Else
                strTabla = "( SELECT DISTINCT BMov_Cat_Doc ID From MvtosBcos "
                '   strTabla = Replace(strTabla, "{empresa}", Sesion.IdEmpresa)
                '  strTabla = Replace(strTabla, "{cod}", celdaCodigo.Text)
                frm.Titulo = "Document"
                frm.Campos = "a.ID, c.cat_desc Descripcion "
                frm.Tabla = strTabla
                frm.Condicion = "  BMov_Sis_Emp = " & Sesion.IdEmpresa & " AND BMov_Cat_Doc > 0) a LEFT JOIN Catalogos c ON c.cat_num = a.ID WHERE c.cat_num IN(44,209)"
            End If
            frm.ShowDialog(Me)
            If frm.DialogResult = System.Windows.Forms.DialogResult.OK Then
                dgImpuestos.Rows.Clear()
                celdadetalleIDDocumento.Text = frm.LLave
                celdaDetalleDocumento.Text = frm.Dato
                If celdadetalleIDDocumento.Text = 44 Then
                    BloquearCuandoEsRecibo(False)
                    DesgloseImpuestos()
                Else
                    celdaDetalleNumero.Text = 0 & cFunciones.NuevoId(celdadetalleIDDocumento.Text)
                    celdaidProveedor.Text = 0
                    BloquearCuandoEsRecibo(True)
                End If

            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try

    End Sub


    Private Sub dgDetalleDocumento_DoubleClick(sender As Object, e As EventArgs) Handles dgDetalleDocumento.DoubleClick
        Try
            Dim Frm As New frmSeleccionar
            Dim strCondicion As String = STR_VACIO
            Dim strFila As String = STR_VACIO

            Select Case dgDetalleDocumento.CurrentCell.ColumnIndex
                Case 9 ' Elige que cuenta y el numero del gasto 

                    ' If dgDetalleDocumento.SelectedCells(6).Value > 0  Then
                    'If Not dgDetalleDocumento.SelectedCells(12).Value = vbNullString Then

                    'Else
                    Dim Condicion As String = STR_VACIO
                    Dim condicion1 As String = STR_VACIO
                    'Condicion = "Empresa = {empresa}  "

                    'Condicion = Replace(Condicion, "{empresa}", Sesion.IdEmpresa)
                    condicion1 = " (
                                    SELECT c.id_cuenta, c.nombre, IFNULL(n2.idCuenta,'') idRubro, IFNULL(n2.NombreIngles,'') Rubro, IFNULL(n.idCuenta,'') ID, IFNULL(n.NombreIngles,'') Cuenta_Afectar, if ((
                                        SELECT COUNT(*)
                                        FROM {conta}.cuentas cc
                                        WHERE cc.empresa = c.empresa AND cc.pid =c.id_cuenta)= 0,'Hijo', 'Padre')Tipo
                                        FROM {conta}.cuentas c
                                        LEFT JOIN {conta}.nomenclatura n ON n.idEmpresa = c.empresa AND n.idCuenta = c.id_nomenclatura 
                                        LEFT JOIN {conta}.nomenclatura n2 ON n2.idEmpresa = n.idEmpresa AND n2.idCuenta = n.Pertenencia 
                                        WHERE Empresa = {empresa}) l1 "
                    'condicion1 = "{conta}"
                    condicion1 = Replace(condicion1, "{conta}", cFunciones.ContaEmpresa)
                    condicion1 = Replace(condicion1, "{empresa}", Sesion.IdEmpresa)
                    'Datospara mostrar en pantalla
                    Frm.Titulo = "Expenses"
                    Frm.FiltroText = "Enter the Name Expense To Filter "

                    'Datos de Base para Llenar Grid
                    Frm.Campos = " l1.Tipo Type_,  l1.id_cuenta Account_, l1.nombre Name_, idRubro idRubro, l1.Rubro Accounting_Item, ID idCuenta, l1.Cuenta_Afectar Account_To_Affect"
                    Frm.Tabla = condicion1
                    Frm.Condicion = "LENGTH(l1.id_cuenta)>1"
                    Frm.Limite = 50
                    Frm.Ordenamiento = "id_cuenta"
                    Frm.Filtro = " nombre"
                    'Frm.Multiple = True
                    'Mostrar formulario
                    Frm.ShowDialog(Me)

                    If Frm.DialogResult = System.Windows.Forms.DialogResult.OK Then
                        'Captura de datos seleccionados

                        If Frm.LLave = "Padre" Then
                            MsgBox("You can't use a father accounts")
                        Else
                            For j As Integer = 0 To Frm.DataGrid.Rows.Count - 1
                                dgDetalleDocumento.CurrentRow.Cells("colidGastoD").Value = Frm.ListaClientes.SelectedCells(1).Value
                                dgDetalleDocumento.CurrentRow.Cells("colGastoD").Value = Frm.ListaClientes.SelectedCells(2).Value
                                dgDetalleDocumento.CurrentRow.Cells("idrubro").Value = Frm.ListaClientes.SelectedCells(3).Value
                                dgDetalleDocumento.CurrentRow.Cells("rubro").Value = Frm.ListaClientes.SelectedCells(4).Value
                                dgDetalleDocumento.CurrentRow.Cells("idcuenta").Value = Frm.ListaClientes.SelectedCells(5).Value
                                dgDetalleDocumento.CurrentRow.Cells("cuenta").Value = Frm.ListaClientes.SelectedCells(6).Value
                            Next
                        End If

                    End If
                    'End If
                    ' End If

                Case 12 ' Selecciona el Centro de Costos
                    If dgDetalleDocumento.CurrentRow.Cells("colCantidadD").Value > 0 Then
                        Dim Condicion As String = STR_VACIO
                        Dim condicion1 As String = STR_VACIO
                        condicion1 = "{conta}"
                        condicion1 = Replace(condicion1, "{conta}", cFunciones.ContaEmpresa)

                        'Datospara mostrar en pantalla
                        Frm.Titulo = "Costes Center"
                        Frm.FiltroText = "Enter the Name Costes Center To Filter "

                        'Datos de Base para Llenar Grid
                        Frm.Campos = "cost_num, cost_nombre"
                        Frm.Tabla = condicion1 & ".costos"
                        Frm.Condicion = "cost_num > 0"
                        Frm.Limite = 25
                        Frm.Ordenamiento = "cost_num"
                        Frm.Filtro = "cost_nombre"

                        'Mostrar formulario
                        Frm.ShowDialog(Me)

                        If Frm.DialogResult = System.Windows.Forms.DialogResult.OK Then
                            'Captura de datos seleccionados
                            dgDetalleDocumento.CurrentRow.Cells("colidCcosto").Value = Frm.LLave
                            dgDetalleDocumento.CurrentRow.Cells("colCcosto").Value = Frm.Dato
                        End If
                    End If
                Case 11
                    If checkContribuyent.Checked = False Then
                        Dim strSQL1 As String = STR_VACIO
                        Dim conec As MySqlConnection
                        Dim COM1 As MySqlCommand
                        Dim REA1 As MySqlDataReader
                        Dim factor As Double = 0

                        strSQL1 = PorcentajeIVA()
                        conec = New MySqlConnection(strConexion)
                        conec.Open()
                        COM1 = New MySqlCommand(strSQL1, conec)
                        Using conec
                            REA1 = COM1.ExecuteReader
                            If REA1.HasRows Then
                                REA1.Read()
                                factor = REA1.GetDouble("IVA")
                                factor = (factor / 100) + 1
                                conec.Close()
                                conec.Dispose()
                                conec = Nothing
                                System.GC.Collect()
                            End If
                        End Using

                        strCondicion = "c.empresa = {emp} AND c.nombre LIKE 'IVA%'"
                        strCondicion = strCondicion.Replace("{emp}", Sesion.IdEmpresa)

                        Frm.Titulo = "VAT"
                        Frm.Campos = "c.nombre, c.id_cuenta"
                        Frm.Tabla = cFunciones.ContaEmpresa & ".cuentas c"
                        Frm.Condicion = strCondicion
                        Frm.Filtro = "c.id_cuenta"

                        Frm.ShowDialog(Me)

                        If Frm.DialogResult = System.Windows.Forms.DialogResult.OK Then
                            dgDetalleDocumento.CurrentRow.Cells("colCtaIVA").Value = Frm.LLave
                            dgDetalleDocumento.CurrentRow.Cells("colidCuentaIVA").Value = Frm.Dato
                            'Recalcula los totales por linea
                            dgDetalleDocumento.CurrentRow.Cells("colPrecioD").Value = dgDetalleDocumento.CurrentRow.Cells("colPrecioSinIVA").Value * factor
                            dgDetalleDocumento.CurrentRow.Cells("colTotalD").Value = dgDetalleDocumento.CurrentRow.Cells("colPrecioD").Value
                        End If
                        ActualizarTotal()
                        CalcuarImpuesto()
                    End If
                Case 18
                    If dgDetalleDocumento.CurrentRow.Cells("colClasificacionD").Value = "SERVICIO" Then
                        dgDetalleDocumento.CurrentRow.Cells("colClasificacionD").Value = "BIEN"
                    ElseIf dgDetalleDocumento.CurrentRow.Cells("colClasificacionD").Value = "BIEN" Then
                        dgDetalleDocumento.CurrentRow.Cells("colClasificacionD").Value = "SERVICIO"
                    End If

            End Select
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub dgDetalleDocumento_CellEndEdit(sender As Object, e As DataGridViewCellEventArgs) Handles dgDetalleDocumento.CellEndEdit
        Dim i As Integer = INT_CERO
        Dim Total As Double
        Dim strSQL1 As String = STR_VACIO
        Dim conec As MySqlConnection
        Dim COM1 As MySqlCommand
        Dim REA1 As MySqlDataReader
        Dim factor As Double = 0

        Select Case dgDetalleDocumento.CurrentCell.ColumnIndex
            Case 0
                If dgDetalleDocumento.CurrentRow.Cells("colCantidadD").Value > vbEmpty Then
                    Total = INT_CERO
                    Total = (dgDetalleDocumento.CurrentRow.Cells("colPrecioD").Value * dgDetalleDocumento.CurrentRow.Cells("colCantidadD").Value)
                    dgDetalleDocumento.CurrentRow.Cells("colTotalD").Value = Total.ToString(FORMATO_MONEDA)

                    ActualizarTotal()
                    CalcuarImpuesto()
                Else
                    MsgBox("The quantity must be greater than zero", vbInformation)
                    dgDetalleDocumento.CurrentRow.Cells("colCantidadD").Selected = True
                End If
            Case 5
                celdaNota.Text = dgDetalleDocumento.CurrentRow.Cells("colDescripcionD").Value
            Case 6
                If dgDetalleDocumento.CurrentRow.Cells("colPrecioSinIVA").Value = 0 Then
                    MsgBox("El precio debe ser mayor a cero", vbInformation)
                    dgDetalleDocumento.CurrentRow.Cells("colPrecioSinIVA").Selected = True
                ElseIf dgDetalleDocumento.CurrentRow.Cells("colCantidadD").Value <= 0 Then
                    MsgBox("Debe ingresar la cantidad antes que el cero", vbInformation)
                    dgDetalleDocumento.CurrentRow.Cells("colCantidadD").Selected = True
                Else
                    If dgDetalleDocumento.CurrentRow.Cells("colidCuentaIVA").Value = vbNullString Then
                        factor = 1
                    Else
                        strSQL1 = PorcentajeIVA()
                        conec = New MySqlConnection(strConexion)
                        conec.Open()
                        COM1 = New MySqlCommand(strSQL1, conec)
                        Using conec
                            REA1 = COM1.ExecuteReader
                            If REA1.HasRows Then
                                REA1.Read()
                                factor = REA1.GetDouble("IVA")
                                factor = (factor / 100) + 1
                                conec.Close()
                                conec.Dispose()
                                conec = Nothing
                                System.GC.Collect()
                            End If
                        End Using
                    End If
                    Total = (dgDetalleDocumento.CurrentRow.Cells("colPrecioSinIVA").Value * dgDetalleDocumento.CurrentRow.Cells("colCantidadD").Value)
                    'dgDetalleDocumento.CurrentRow.Cells("colPrecioSinIVA").Value = Total.ToString(FORMATO_MONEDA)
                    dgDetalleDocumento.CurrentRow.Cells("colPrecioD").Value = dgDetalleDocumento.CurrentRow.Cells("colPrecioSinIVA").Value * factor
                    dgDetalleDocumento.CurrentRow.Cells("colTotalD").Value = dgDetalleDocumento.CurrentRow.Cells("colPrecioD").Value * dgDetalleDocumento.CurrentRow.Cells("colCantidadD").Value 'dgDetalleDocumento.CurrentRow.Cells("colPrecioD").Value
                End If
                ActualizarTotal()
                CalcuarImpuesto()
            Case 7
                If dgDetalleDocumento.CurrentRow.Cells("colPrecioD").Value = 0 Then
                    MsgBox("The price must be greater than zero", vbInformation)
                    dgDetalleDocumento.CurrentRow.Cells("colPrecioD").Selected = True
                ElseIf dgDetalleDocumento.CurrentRow.Cells("colCantidadD").Value <= 0 Then
                    MsgBox("You must enter the amount First", vbInformation)
                    dgDetalleDocumento.CurrentRow.Cells("colCantidadD").Selected = True
                Else
                    Total = (dgDetalleDocumento.CurrentRow.Cells("colPrecioD").Value * dgDetalleDocumento.CurrentRow.Cells("colCantidadD").Value)
                    dgDetalleDocumento.CurrentRow.Cells("colTotalD").Value = Total.ToString(FORMATO_MONEDA)
                End If
                ActualizarTotal()
                CalcuarImpuesto()

        End Select
    End Sub

    Private Sub botonDetalleMoneda_Click(sender As Object, e As EventArgs) Handles botonDetalleMoneda.Click
        Dim frm As New frmSeleccionar

        Try
            frm.Titulo = "Coin"
            frm.Campos = "c.cat_clave Moneda, c.cat_num ID, c.cat_sist"
            frm.Tabla = "Catalogos c"
            frm.FiltroText = " Enter the Coin To filter"
            frm.Filtro = " c.cat_clave "
            frm.Limite = 5
            frm.Ordenamiento = " c.cat_clave "
            frm.TipoOrdenamiento = ""
            frm.Condicion = "cat_clase='Monedas'"

            frm.ShowDialog(Me)

            If frm.DialogResult = System.Windows.Forms.DialogResult.OK Then
                celdaDetalleMoneda.Text = frm.LLave
                celdaDetalleIDMoneda.Text = frm.Dato
                If frm.Dato2 > 1 Then
                    celdaDetalleTC.Text = cfun.TasaSegunFecha(dtpDetalleFecha.Value.ToString(FORMATO_MYSQL))
                Else
                    celdaDetalleTC.Text = frm.Dato2
                End If
                If celdaDetalleMonto.Text.ToString.Length > 0 Then
                    etiquetaMontoTotal.Text = (celdaDetalleMonto.Text * celdaDetalleTC.Text)
                    'logIVA = True
                    CalcuarImpuesto()
                End If
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub celdaNota_TextChanged(sender As Object, e As EventArgs) Handles celdaNota.TextChanged
        If ModCelda = True Then
            dgDetalleDocumento.CurrentRow.Cells("colDescripcionD").Value = celdaNota.Text
        End If
    End Sub

    Private Sub botonPermisos_Click(sender As Object, e As EventArgs) Handles botonPermisos.Click
        Dim per As New frmPermisosCajaChica
        per.ShowDialog(Me)
    End Sub

    Private Sub botonActualizar_Click(sender As Object, e As EventArgs) Handles botonActualizar.Click
        MostrarLista()
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Dim cls As New clsPolizaContable

        cls.Tipo = celdadetalleIDDocumento.Text
        cls.Ciclo = celdaDetalleAnio.Text
        cls.Numero = celdaNumeroHDR.Text
        cls.Modo = 8

        cls.MostrarPolizaContable()
    End Sub

    Private Sub Encabezado1_ClickBorrar(sender As Object, click As Boolean) Handles Encabezado1.ClickBorrar
        If LogBorrar = True Then
            If celdadetalleIDDocumento.Text = 44 Then
                If EnLibroCompras(celdaDetalleAnio.Text, celdaNumeroHDR.Text, True, "Nota: No se permiten modificaciones") = True Then
                Else
                    If cfun.SQLVerificarCierre(celdadetalleIDDocumento.Text, celdaDetalleAnio.Text, celdaNumeroHDR.Text) = 0 Then
                        If MsgBox("You want to delete the registry", vbYesNo, "Question") = vbYes Then
                            BorrarEncabezadoDoc()
                            BorrarDetalleDoc()
                            BorrarImpuestosDoc()
                            BorrarMovimientoBancario()
                            cFunciones.BorrarEncabezadoPoliza(celdaNumeroHDR.Text, celdaDetalleAnio.Text, celdadetalleIDDocumento.Text)
                            cFunciones.BorrarDetallePoliza(celdaNumeroHDR.Text, celdaDetalleAnio.Text, celdadetalleIDDocumento.Text)
                            MsgBox("Delete Complete", vbInformation, "Notice")
                            MostrarLista(1)
                            CargarDocumentosCajaChica(celdaNumeroCaja.Text)
                            SaldoCaja(celdaNumeroCaja.Text)
                        End If
                    Else
                        'Si hay Cierre solicita autorizacion para modificar 
                        MsgBox("You need authorization to modify this document ", vbInformation, "Notice")
                        If cfun.AutorizarCambios = True Then
                            If MsgBox("You want to delete the registry", vbYesNo, "Question") = vbYes Then
                                BorrarEncabezadoDoc()
                                BorrarDetalleDoc()
                                BorrarImpuestosDoc()
                                BorrarMovimientoBancario()
                                cFunciones.BorrarEncabezadoPoliza(celdaNumeroHDR.Text, celdaDetalleAnio.Text, celdadetalleIDDocumento.Text)
                                cFunciones.BorrarDetallePoliza(celdaNumeroHDR.Text, celdaDetalleAnio.Text, celdadetalleIDDocumento.Text)
                                MsgBox("Delete Complete", vbInformation, "Notice")
                                MostrarLista(1)
                                CargarDocumentosCajaChica(celdaNumeroCaja.Text)
                                SaldoCaja(celdaNumeroCaja.Text)
                                cfun.EscribirRegistro("Dcmtos_HDR", clsFunciones.AccEnum.acConfirm, celdaNumeroCaja.Text, celdadetalleIDDocumento.Text, celdaDetalleAnio.Text, celdaNumeroHDR.Text)
                            End If
                        End If
                    End If
                End If
            Else
                If cfun.SQLVerificarCierre(celdadetalleIDDocumento.Text, celdaDetalleAnio.Text, celdaNumeroHDR.Text) = 0 Then
                    If MsgBox("You want to delete the registry", vbYesNo, "Question") = vbYes Then
                        BorrarEncabezadoDoc()
                        BorrarDetalleDoc()
                        BorrarImpuestosDoc()
                        BorrarMovimientoBancario()
                        cFunciones.BorrarEncabezadoPoliza(celdaNumeroHDR.Text, celdaDetalleAnio.Text, celdadetalleIDDocumento.Text)
                        cFunciones.BorrarDetallePoliza(celdaNumeroHDR.Text, celdaDetalleAnio.Text, celdadetalleIDDocumento.Text)
                        MsgBox("Delete Complete", vbInformation, "Notice")
                        MostrarLista(1)
                        CargarDocumentosCajaChica(celdaNumeroCaja.Text)
                        SaldoCaja(celdaNumeroCaja.Text)
                    End If
                Else
                    'Si hay Cierre solicita autorizacion para modificar 
                    MsgBox("You need authorization to modify this document ", vbInformation, "Notice")
                    If cfun.AutorizarCambios = True Then
                        If MsgBox("You want to delete the registry", vbYesNo, "Question") = vbYes Then
                            BorrarEncabezadoDoc()
                            BorrarDetalleDoc()
                            BorrarImpuestosDoc()
                            BorrarMovimientoBancario()
                            cFunciones.BorrarEncabezadoPoliza(celdaNumeroHDR.Text, celdaDetalleAnio.Text, celdadetalleIDDocumento.Text)
                            cFunciones.BorrarDetallePoliza(celdaNumeroHDR.Text, celdaDetalleAnio.Text, celdadetalleIDDocumento.Text)
                            MsgBox("Delete Complete", vbInformation, "Notice")
                            MostrarLista(1)
                            CargarDocumentosCajaChica(celdaNumeroCaja.Text)
                            SaldoCaja(celdaNumeroCaja.Text)
                            cfun.EscribirRegistro("Dcmtos_HDR", clsFunciones.AccEnum.acConfirm, celdaNumeroCaja.Text, celdadetalleIDDocumento.Text, celdaDetalleAnio.Text, celdaNumeroHDR.Text)
                        End If
                    End If
                End If
            End If
        Else
            MsgBox("You do not have access to delete this document", vbInformation, "Notice")
        End If
    End Sub

    Private Sub dgDocumentos_KeyDown(sender As Object, e As KeyEventArgs) Handles dgDocumentos.KeyDown
        Try
            If e.KeyCode = Keys.F3 Then
                cFunciones.BuscarenLista(dgDocumentos)
                e.Handled = True
                e.SuppressKeyPress = True
            ElseIf e.KeyCode = Keys.F6 Then
                cFunciones.MostrarDependencias(dgDocumentos.SelectedCells(0).Value, dgDocumentos.SelectedCells(1).Value, dgDocumentos.SelectedCells(2).Value)
            ElseIf e.KeyCode = Keys.F7 Then
                Dim rpt As New clsReportes
                rpt.Historial(dgDocumentos.SelectedCells(2).Value, dgDocumentos.SelectedCells(1).Value, dgDocumentos.SelectedCells(0).Value)
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub dgLista_KeyDown(sender As Object, e As KeyEventArgs) Handles dgLista.KeyDown
        Try
            If e.KeyCode = Keys.F3 Then
                cFunciones.BuscarenLista(dgLista)
                e.Handled = True
                e.SuppressKeyPress = True
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub botonMenos_Click(sender As Object, e As EventArgs) Handles botonMenos.Click
        If dgDetalleDocumento.Rows.Count > 0 Then
            If MsgBox("you want to delete the line", vbYesNo, "Question") = vbYes Then
                dgDetalleDocumento.SelectedCells(21).Value = 2
                dgDetalleDocumento.CurrentRow.Visible = False
                ActualizarTotal()
                CalcuarImpuesto()

            End If
        End If

    End Sub

    Private Sub dgDetalleDocumento_SelectionChanged(sender As Object, e As EventArgs) Handles dgDetalleDocumento.SelectionChanged
        celdaNota.Text = dgDetalleDocumento.CurrentRow.Cells("colDescripcionD").Value
    End Sub

    Private Sub frmCajaChica_Closing(sender As Object, e As CancelEventArgs) Handles Me.Closing
        Fprincipal.BarraDeTareas1.QuitarFormulario(strKey)
    End Sub

    Private Sub dtpDetalleFecha_ValueChanged(sender As Object, e As EventArgs) Handles dtpDetalleFecha.ValueChanged
        If celdaDetalleTC.Text > 1 Then
            celdaDetalleTC.Text = cFunciones.TasaSegunFecha(dtpDetalleFecha.Value.ToString(FORMATO_MYSQL))
        End If
    End Sub

    Private Function ComprobarDatos() As Boolean
        Dim comprobar As Boolean = True
        'Revisar que los datos de la cabecera no estén en blanco.

        If Not celdaCAI.Text.Length = 37 Then
            comprobar = False
        End If

        Return comprobar

    End Function
#End Region

End Class