﻿Imports System.ComponentModel

Public Class frmActivosUnidades
#Region "Variables"
    Dim strKey As String = STR_VACIO
    Dim logInsertar As Boolean = False
    Dim logConsultar As Boolean = False
    Dim logEditar As Boolean = False
    Dim LogBorrar As Boolean = False
    Dim cfun As New clsFunciones
    Dim intControlador As Integer = NO_FILA
#End Region
#Region "Propiedades"
    Public Property Key As String
        Get
            Return strKey
        End Get
        Set(value As String)
            strKey = value
        End Set
    End Property
#End Region
#Region "Procedimientos"
    Private Sub BloquearBotones(Optional ByVal logBloquear As Boolean = True)
        If logBloquear = True Then
            Encabezado1.botonBorrar.Enabled = False
            Encabezado1.botonGuardar.Enabled = False
            ' botonInprimir.Enabled = False
            Encabezado1.botonNuevo.Enabled = True
        Else
            If LogBorrar = True Then
                Encabezado1.botonBorrar.Enabled = True
            Else
                Encabezado1.botonBorrar.Enabled = False
            End If
            Encabezado1.botonGuardar.Enabled = True
            'botonInprimir.Enabled = True
            Encabezado1.botonNuevo.Enabled = False
        End If
    End Sub
    Private Sub Accessos()
        Dim cAccesos As New clsAccesos
        Try
            If cAccesos.Accesos(strKey) = True Then
                logInsertar = cAccesos.Insertar
                logConsultar = cAccesos.Consultar
                logEditar = cAccesos.Editar
                LogBorrar = cAccesos.Borrar
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub
    Private Sub reset()
        celdaID.Text = NO_FILA
        dtpFecha.Value = Now().ToString(FORMATO_MYSQL)
        dtpFechaDepreciacion.Value = Now.ToString(FORMATO_MYSQL)
        celdaDescripcion.Text = STR_VACIO
        dgDetalle.Rows.Clear()
        checkActivar.Checked = True
    End Sub
    Private Sub MostrarLista(Optional ByVal logMostrar As Boolean = True, Optional logInsert As Boolean = False)
        Dim cfun As New clsFunciones
        If logMostrar = True Then
            'ocultar panel de documento
            panelDocumento.Dock = DockStyle.None
            panelDocumento.Visible = False
            'actualizar Titulo
            BarraTitulo1.CambiarTitulo("Fixed asset per hour or units")
            'Cargar Datos
            'cfun.CargarLista(dgLista, SQLLista, False)
            CargarLista()
            'Mostrar Panel Filtro
            panelListaPrincipal.Visible = True
            panelListaPrincipal.Dock = DockStyle.Fill
            BloquearBotones()
            Me.Tag = ""
        Else
            'Ocultar Panel Filtro
            panelListaPrincipal.Visible = False
            panelListaPrincipal.Dock = DockStyle.None
            'Mostrar panel de documento
            panelDocumento.Dock = DockStyle.Fill
            panelDocumento.Visible = True
            'Verifica si se va a crear un nuevo documento o se va modifica
            If logInsert = False Then
                BarraTitulo1.CambiarTitulo("Update")
                Me.Tag = "mod"
                BloquearBotones(False)
                ' botonInprimir.Enabled = True
            Else
                BarraTitulo1.CambiarTitulo("New")
                Me.Tag = "Nuevo"
                BloquearBotones(False)
                'botonInprimir.Enabled = False
                reset()
            End If
            dgLista.DataSource = Nothing
        End If
    End Sub
    Private Function SQLLista() As String
        Dim strSql As String = STR_VACIO
        Try
            strSql = " SELECT CAST(CONCAT(a.Anio,'-',a.Mes,'-',a.Dia) AS DATE) Fecha2,a.Codigo,a.Fecha, Case a.Mes    
                            when 1 then CONCAT('DEPRECIATION OF JANUARY ',a.Anio)  
                                When 2 then CONCAT('DEPRECIATION OF FEBRUARY ',a.Anio) 
                                    When 3 then CONCAT('DEPRECIATION OF MARCH ',a.Anio)
                                        WHEN 4 THEN CONCAT('DEPRECIATION OF APRIL ',a.Anio)
                                            WHEN 5 then CONCAT('DEPRECIATION OF MAY ',a.Anio) 
                                                WHEN 6 then CONCAT('DEPRECIATION OF JUNE ',a.Anio) 
                                                    WHEN 7 then CONCAT('DEPRECIATION OF JULY ',a.Anio) 
                                                WHEN 8 then CONCAT('DEPRECIATION OF AUGUST ',a.Anio) 
                                            WHen 9 then CONCAT('DEPRECIATION OF SEPTEMBER ',a.Anio) 
                                        when 10 then CONCAT('DEPRECIATION OF OCTOBER ',a.Anio) 
                                    when 11 then CONCAT('DEPRECIATION OF NOVEMBER ',a.Anio) 
                                WHEN 12 Then CONCAT('DEPRECIATION OF DECEMBER ',a.Anio) 
                            END FechaDepreciacion, a.Estado 
                        FROM ActivosHU a
                     WHERE a.Empresa = {empresa}
                 GROUP BY a.Codigo
              ORDER BY a.Codigo  "
            strSql = strSql.Replace("{empresa}", Sesion.IdEmpresa)
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        Return strSql
    End Function
    Public Sub CargarLista()
        Dim strSQL As String = STR_VACIO
        ' Conexiones
        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader
        Dim strLinea As String
        Try
            strSQL = SQLLista()
            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSQL, CON)
            REA = COM.ExecuteReader
            dgLista.Rows.Clear()
            If REA.HasRows Then
                Do While REA.Read

                    strLinea = REA.GetDateTime("Fecha2") & "|" 'Año
                    strLinea &= REA.GetInt32("Codigo") & "|" 'Numero
                    strLinea &= REA.GetDateTime("Fecha") & "|" 'Fecha 
                    strLinea &= REA.GetString("FechaDepreciacion")  'Fecha Depreciacion
                    If REA.GetInt32("Estado") = INT_UNO Then
                        cFunciones.AgregarFila(dgLista, strLinea)
                    Else
                        cFunciones.AgregarFila(dgLista, strLinea, Color.Coral)
                    End If
                Loop
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub
    Private Function SQLCargaActivosXMes()
        Dim strSQL As String = STR_VACIO
        strSQL = " SELECT a.Codigo idActivo, a.Descripcion DescripcionActivo, ta.Codigo idTipoActivo, ta.Descripcion DescripcionTipoActivo "
        strSQL &= "     FROM Activos a "
        strSQL &= "         LEFT JOIN Tipos_Activo ta ON ta.Empresa = a.Empresa AND ta.Codigo = a.Id_Tipo "
        strSQL &= "             LEFT JOIN Catalogos t ON t.cat_num = a.Id_Depreciacion AND t.cat_clase = 'Depreciacion' "
        strSQL &= "                 WHERE a.Empresa = {empresa} AND (t.cat_clave = 'Hours' OR t.cat_clave = 'Units')  "
        strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
        Return strSQL
    End Function
    Public Sub CargarActivoXMes()
        Dim strSQL As String = STR_VACIO
        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader
        Dim strFila As String = STR_VACIO
        Try
            strSQL = SQLCargaActivosXMes()
            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSQL, CON)
            REA = COM.ExecuteReader
            If REA.HasRows Then
                Do While REA.Read
                    strFila = REA.GetInt32("idActivo") & "|"
                    strFila &= REA.GetString("DescripcionTipoActivo") & "|"
                    strFila &= REA.GetInt32("idTipoActivo") & "|"
                    strFila &= REA.GetString("DescripcionActivo") & "|"
                    strFila &= INT_CERO & "|"
                    strFila &= INT_CERO & "|"
                    strFila &= INT_CERO
                    cfun.AgregarFila(dgDetalle, strFila)
                Loop
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub
    Public Sub FuncionTituloDepreciacion()
        Dim intMes As Integer = NO_FILA
        Dim intAnio As Integer = NO_FILA

        intMes = dtpFechaDepreciacion.Value.Month
        intAnio = dtpFechaDepreciacion.Value.Year
        celdaDescripcion.Text = "DEPRECIATION OF " & UCase(cfun.MesIngles(intMes)) & " " & intAnio
    End Sub
    Private Function NuevoCodigo() As Integer
        Dim strSQL As String = STR_VACIO
        Dim conec As New MySqlConnection
        Dim COM As MySqlCommand
        Dim CodigoProyecto As Integer

        strSQL = " Select IFNULL(MAX(a.Codigo),0) + 1  Codigo   "
        strSQL &= " FROM ActivosHU a  "
        strSQL &= "     WHERE a.Empresa = {empresa}  "

        strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)

        conec = New MySqlConnection(strConexion)
        conec.Open()
        COM = New MySqlCommand(strSQL, conec)
        CodigoProyecto = COM.ExecuteScalar
        conec.Close()
        conec.Dispose()
        conec = Nothing
        System.GC.Collect()
        Return CodigoProyecto
    End Function
    Private Function NuevaLinea(ByVal Codigo As Integer) As Integer
        Dim strSQL As String = STR_VACIO
        Dim conec As New MySqlConnection
        Dim COM As MySqlCommand
        Dim LineaNueva As Integer

        strSQL = " SELECT IFNULL(MAX(a.Linea),0) + 1  Codigo  "
        strSQL &= " FROM ActivosHU a  "
        strSQL &= " WHERE a.Empresa = {empresa} AND a.Codigo = {codigo} "

        strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
        strSQL = Replace(strSQL, "{codigo}", Codigo)
        conec = New MySqlConnection(strConexion)
        conec.Open()
        COM = New MySqlCommand(strSQL, conec)
        LineaNueva = COM.ExecuteScalar
        conec.Close()
        conec.Dispose()
        conec = Nothing
        System.GC.Collect()
        Return LineaNueva
    End Function
    Private Function ComprobarFila() As Boolean
        Dim LogVerdadero As Boolean = True
        If dgDetalle.Rows.Count = 0 Then
            MsgBox("Fill all fields", MsgBoxStyle.Critical)
            LogVerdadero = False
        Else
            LogVerdadero = True
        End If
        Return LogVerdadero
    End Function
    Private Function Guardar() As Boolean
        Dim logResultado As Boolean = True
        Dim IntId As Integer = NO_FILA
        Dim cActivosHU As New Tablas.TACTIVOSHU
        Try
            If Me.Tag = "Nuevo" Then
                If logInsertar = True Then
                    IntId = NuevoCodigo()
                    If ValidarActivosHU() > INT_CERO Then
                        MsgBox("Depreciation already exists please check your data", vbInformation)
                        Return False
                        Exit Function
                    Else
                        For i As Integer = 0 To dgDetalle.Rows.Count - 1
                            cActivosHU.EMPRESA = Sesion.IdEmpresa
                            cActivosHU.CODIGO = IntId
                            cActivosHU.Fecha_NET = dtpFecha.Value
                            cActivosHU.DIA = dtpFechaDepreciacion.Value.Day
                            cActivosHU.MES = dtpFechaDepreciacion.Value.Month
                            cActivosHU.ANIO = dtpFechaDepreciacion.Value.Year
                            cActivosHU.IDACTIVO = dgDetalle.Rows(i).Cells("colidActivos").Value
                            cActivosHU.IDTIPOACTIVO = dgDetalle.Rows(i).Cells("colidTipoActivo").Value
                            cActivosHU.DESCRIPCION = dgDetalle.Rows(i).Cells("colDescripcion").Value
                            cActivosHU.CANTIDADHU = dgDetalle.Rows(i).Cells("colHU").Value
                            cActivosHU.ESTADO = IIf(checkActivar.Checked = True, 1, vbEmpty)
                            If dgDetalle.Rows(i).Cells("colEstado").Value = INT_CERO Then
                                cActivosHU.CONEXION = strConexion
                                cActivosHU.LINEA = NuevaLinea(IntId)
                                If cActivosHU.PINSERT = False Then
                                    MsgBox(cActivosHU.MERROR.ToString)
                                    Return False
                                    Exit Function
                                Else
                                    logResultado = True
                                    celdaID.Text = IntId
                                    cFunciones.EscribirRegistro("ActivosUnidad", clsFunciones.AccEnum.acAdd, celdaID.Text, 0, 0, celdaID.Text, Notas:=celdaDescripcion.Text)
                                End If
                            End If
                        Next
                    End If
                Else
                    MsgBox("You don't have permission to save ")
                    Return False
                    Exit Function
                End If
            Else
                If logEditar = True Then
                    For i As Integer = 0 To dgDetalle.Rows.Count - 1
                        cActivosHU.EMPRESA = Sesion.IdEmpresa
                        cActivosHU.CODIGO = celdaID.Text
                        cActivosHU.LINEA = dgDetalle.Rows(i).Cells("colLinea").Value
                        cActivosHU.Fecha_NET = dtpFecha.Value
                        cActivosHU.DIA = dtpFechaDepreciacion.Value.Day
                        cActivosHU.MES = dtpFechaDepreciacion.Value.Month
                        cActivosHU.ANIO = dtpFechaDepreciacion.Value.Year
                        cActivosHU.IDACTIVO = dgDetalle.Rows(i).Cells("colidActivos").Value
                        cActivosHU.IDTIPOACTIVO = dgDetalle.Rows(i).Cells("colidTipoActivo").Value
                        cActivosHU.DESCRIPCION = dgDetalle.Rows(i).Cells("colDescripcion").Value
                        cActivosHU.CANTIDADHU = dgDetalle.Rows(i).Cells("colHU").Value
                        cActivosHU.ESTADO = IIf(checkActivar.Checked = True, 1, vbEmpty)
                        If dgDetalle.Rows(i).Cells("colEstado").Value = INT_UNO Then
                            cActivosHU.CONEXION = strConexion
                            If cActivosHU.PUPDATE = False Then
                                MsgBox(cActivosHU.MERROR.ToString)
                                Return False
                                Exit Function
                            Else
                                logResultado = True
                                cFunciones.EscribirRegistro("ActivosUnidad", clsFunciones.AccEnum.acUpdate, celdaID.Text, 0, 0, celdaID.Text, Notas:=celdaDescripcion.Text)
                            End If
                        End If
                    Next
                Else
                    MsgBox("You don't have permission to update ")
                    Return False
                    Exit Function
                End If
            End If


        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        Return logResultado
    End Function
    Private Function sqlCargarDocumento(ByVal Codigo As Integer, ByVal Anio As Integer, ByVal Mes As Integer) As String
        Dim strSQL = STR_VACIO
        strSQL = " SELECT a.Codigo, a.Linea, a.Fecha,CAST(CONCAT(a.Anio,'-',a.Mes,'-',a.Dia) AS DATE ) FechaDepreciacion, "
        strSQL &= "     a.idActivo, a.Descripcion DescripcionActivo, a.idTipoActivo, ta.Descripcion DescripcionTipoActivo,a.CantidadHU, a.Estado "
        strSQL &= "         FROM ActivosHU a "
        strSQL &= "             LEFT JOIN Activos ac ON ac.Empresa = a.Empresa AND ac.Codigo = a.idActivo  "
        strSQL &= "                 LEFT JOIN Tipos_Activo ta ON ta.Empresa = a.Empresa AND ta.Codigo = a.idTipoActivo  "
        strSQL &= "             WHERE a.Empresa = {empresa} AND a.Codigo = {codigo} AND a.Anio = {anio} AND a.Mes = {mes} "
        strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
        strSQL = Replace(strSQL, "{codigo}", Codigo)
        strSQL = Replace(strSQL, "{anio}", Anio)
        strSQL = Replace(strSQL, "{mes}", Mes)
        Return strSQL
    End Function
    Public Sub CargarDocumento(ByVal Codigo As Integer, ByVal Anio As Integer, ByVal Mes As Integer)
        Dim strSQL As String = STR_VACIO
        Dim strFila As String = STR_VACIO
        Dim logEncabezado As Boolean
        ' Conexiones
        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader
        Try
            strSQL = sqlCargarDocumento(Codigo, Anio, Mes)
            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSQL, CON)
            REA = COM.ExecuteReader
            If REA.HasRows Then
                Do While REA.Read
                    If logEncabezado = False Then
                        celdaID.Text = REA.GetInt32("Codigo")
                        dtpFecha.Value = REA.GetDateTime("Fecha")
                        dtpFechaDepreciacion.Value = REA.GetDateTime("FechaDepreciacion")
                        If REA.GetInt32("Estado") = INT_UNO Then
                            checkActivar.Checked = True
                        Else
                            checkActivar.Checked = False
                        End If
                        strFila = REA.GetInt32("idActivo") & "|"
                        strFila &= REA.GetString("DescripcionTipoActivo") & "|"
                        strFila &= REA.GetInt32("idTipoActivo") & "|"
                        strFila &= REA.GetString("DescripcionActivo") & "|"
                        strFila &= REA.GetDouble("CantidadHU") & "|"
                        strFila &= REA.GetInt32("Linea") & "|"
                        strFila &= INT_UNO
                        cfun.AgregarFila(dgDetalle, strFila)
                        logEncabezado = True
                    Else
                        strFila = REA.GetInt32("idActivo") & "|"
                        strFila &= REA.GetString("DescripcionTipoActivo") & "|"
                        strFila &= REA.GetInt32("idTipoActivo") & "|"
                        strFila &= REA.GetString("DescripcionActivo") & "|"
                        strFila &= REA.GetDouble("CantidadHU") & "|"
                        strFila &= REA.GetInt32("Linea") & "|"
                        strFila &= INT_UNO
                        cfun.AgregarFila(dgDetalle, strFila)
                    End If
                Loop
            End If
            ValidarDepreciacion()
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub
    Private Function ValidarActivosHU() As Integer
        Dim strSQL As String = STR_VACIO
        Dim intCodigo As Integer = NO_FILA
        Dim conec As New MySqlConnection
        Dim COM As MySqlCommand
        strSQL = " SELECT COUNT(*) "
        strSQL &= "     FROM ActivosHU a "
        strSQL &= "         WHERE a.Empresa = {empresa} AND a.Mes = {mes} AND a.Anio = {anio} AND a.Estado = 1 "
        strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
        strSQL = Replace(strSQL, "{mes}", dtpFechaDepreciacion.Value.Month)
        strSQL = Replace(strSQL, "{anio}", dtpFechaDepreciacion.Value.Year)
        conec = New MySqlConnection(strConexion)
        conec.Open()
        COM = New MySqlCommand(strSQL, conec)
        intCodigo = COM.ExecuteScalar
        conec.Close()
        conec.Dispose()
        conec = Nothing
        System.GC.Collect()
        Return intCodigo
    End Function
    Private Function ValidarDepreciacion() As Integer
        Dim strSQL As String = STR_VACIO
        Dim intCodigo As Integer = NO_FILA
        Dim conec As New MySqlConnection
        Dim COM As MySqlCommand
        strSQL = " SELECT COUNT(*) "
        strSQL &= "     FROM ActivosHU a "
        strSQL &= "         LEFT JOIN Depreciaciones d ON d.dep_empresa = a.Empresa AND d.dep_codigo = a.Codigo AND EXTRACT(MONTH FROM d.dep_fecha) = a.Mes AND  EXTRACT(YEAR FROM d.dep_fecha) = a.Anio   "
        strSQL &= "         WHERE a.Empresa = {empresa}  AND a.Anio = {anio} AND a.Mes = {mes}  AND d.dep_codigo IS not NULL  "
        strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
        strSQL = Replace(strSQL, "{mes}", dtpFechaDepreciacion.Value.Month)
        strSQL = Replace(strSQL, "{anio}", dtpFechaDepreciacion.Value.Year)
        conec = New MySqlConnection(strConexion)
        conec.Open()
        COM = New MySqlCommand(strSQL, conec)
        intCodigo = COM.ExecuteScalar
        conec.Close()
        conec.Dispose()
        conec = Nothing
        System.GC.Collect()

        If intCodigo > INT_CERO Then
            For i As Integer = 0 To Me.dgDetalle.Rows.Count - 1
                Me.dgDetalle.Rows(i).Cells("colHU").Style.BackColor = Color.YellowGreen
                Me.dgDetalle.Rows(i).Cells("colHU").ReadOnly = True
            Next
        End If
        Return intCodigo
    End Function
    Public Sub BorrarActivosUnidades(ByVal fecha As Date)
        Dim strSQL As String = STR_VACIO
        Dim conec As MySqlConnection
        Dim COM As MySqlCommand
        strSQL = " DELETE FROM ActivosHU   WHERE Empresa = {empresa}  AND Fecha  = '{fecha}'  "
        strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
        strSQL = Replace(strSQL, "{fecha}", fecha.ToString(FORMATO_MYSQL))
        conec = New MySqlConnection(strConexion)
        conec.Open()
        COM = New MySqlCommand(strSQL, conec)
        COM.ExecuteScalar()
        conec.Close()
        conec.Dispose()
        conec = Nothing
        System.GC.Collect()
    End Sub
#End Region
#Region "Eventos"
    Private Sub frmActivosUnidades_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Accessos()
        MostrarLista()
    End Sub

    Private Sub Encabezado1_ClickNuevo(sender As Object, click As Boolean) Handles Encabezado1.ClickNuevo
        If logInsertar = True Then
            MostrarLista(False, True)
            Me.Tag = "Nuevo"
            CargarActivoXMes()
            FuncionTituloDepreciacion()
            Encabezado1.botonBorrar.Enabled = False
        Else
            MsgBox("Do you not have access to create a new Fixed asset per hour or units", vbInformation)
        End If
    End Sub

    Private Sub Encabezado1_ClickCerrar(sender As Object, click As Boolean) Handles Encabezado1.ClickCerrar
        If panelListaPrincipal.Visible = True Then
            Me.Close()
        Else
            MostrarLista()
        End If
    End Sub

    Private Sub dtpFechaDepreciacion_ValueChanged(sender As Object, e As EventArgs) Handles dtpFechaDepreciacion.ValueChanged
        FuncionTituloDepreciacion()
    End Sub

    Private Sub dgLista_KeyDown(sender As Object, e As KeyEventArgs) Handles dgLista.KeyDown
        Try
            If e.KeyCode = Keys.F3 Then
                cfun.BuscarenLista(dgLista)
                e.Handled = True
                e.SuppressKeyPress = True
                'ElseIf e.KeyCode = Keys.F6 Then
                '   cfun.MostrarDependencias(36, dgLista.SelectedCells(0).Value, dgLista.SelectedCells(1).Value)
                ' ElseIf e.KeyCode = Keys.F7 Then
                '    Dim rpt As New clsReportes
                '    rpt.Historial(dgLista.SelectedCells(1).Value, dgLista.SelectedCells(0).Value, 36)
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub
    Private Sub Encabezado1_ClickGuardar(sender As Object, click As Boolean) Handles Encabezado1.ClickGuardar
        Try
            If ComprobarFila() Then
                If Guardar() = True Then
                    MsgBox("save successful")
                    MostrarLista(True)
                End If
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub dgDetalle_CellEndEdit(sender As Object, e As DataGridViewCellEventArgs) Handles dgDetalle.CellEndEdit

        Select Case dgDetalle.CurrentCell.ColumnIndex
            Case 4
                cfun.ValidarFilaGrid(dgDetalle, "colHU")
        End Select


    End Sub

    Private Sub dgLista_DoubleClick(sender As Object, e As EventArgs) Handles dgLista.DoubleClick
        Dim dtpFecha As Date
        Dim intMes As Integer
        Dim intAnio As Integer
        Try
            If dgLista.SelectedRows.Count = INT_CERO Then Exit Sub
            Me.Tag = "mod"
            BarraTitulo1.CambiarTitulo("Modificar Registro")
            reset()
            dtpFecha = dgLista.SelectedCells(0).Value
            intMes = dtpFecha.Month
            intAnio = dtpFecha.Year
            CargarDocumento(dgLista.SelectedCells(1).Value, intAnio, intMes)
            MostrarLista(False)
            Encabezado1.botonNuevo.Enabled = True
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub
    Private Sub frmActivosUnidades_FormClosing(sender As Object, e As FormClosingEventArgs) Handles Me.FormClosing
        Fprincipal.BarraDeTareas1.QuitarFormulario(strKey)
    End Sub

    Private Sub botonActualizar_Click(sender As Object, e As EventArgs) Handles botonActualizar.Click
        CargarLista()
    End Sub

    Private Sub Encabezado1_ClickBorrar(sender As Object, click As Boolean) Handles Encabezado1.ClickBorrar
        If LogBorrar = True Then
            If MsgBox("Are You sure " & vbCr & vbCr & "¿do you want to delete this document? ", vbQuestion + vbYesNo, "Aviso") = vbYes Then
                If ValidarDepreciacion() > INT_CERO Then
                    MsgBox("Can't delete this document has dependencies")
                    Exit Sub
                Else
                    BorrarActivosUnidades(dtpFechaDepreciacion.Value)
                    MsgBox("Delete Complete")
                    MostrarLista()
                End If
            End If
            Else
            MsgBox("You don't have permission to this access")
        End If
    End Sub

#End Region

End Class