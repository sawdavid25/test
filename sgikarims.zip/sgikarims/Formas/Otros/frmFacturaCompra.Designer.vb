﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class frmFacturaCompra
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Dim DataGridViewCellStyle1 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle2 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle3 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmFacturaCompra))
        Dim DataGridViewCellStyle4 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle5 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle6 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle7 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle8 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle9 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle10 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle11 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle12 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle13 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle14 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle15 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle16 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle17 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle18 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle19 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle20 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle21 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle22 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle24 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle25 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle23 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Me.panelLista = New System.Windows.Forms.Panel()
        Me.dgLista = New System.Windows.Forms.DataGridView()
        Me.colIdLista = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colTipoLista = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colAñoLista = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colNumeroLista = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colFecha = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colFactura = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.ColProveedor = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colMoneda = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colSaldo = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colGrupo = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colClase = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colProcesado = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colEstado = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colSIVA = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colISR = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colFechaVence = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colReten = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colSerieF = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colAutorizacionF = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.tipoDocumento = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.SinIngresos = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.TipoOC = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.PanelPiePagina = New System.Windows.Forms.Panel()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.TextBox2 = New System.Windows.Forms.TextBox()
        Me.TextBox1 = New System.Windows.Forms.TextBox()
        Me.etiquetaOrden = New System.Windows.Forms.Label()
        Me.etiquetaVerde = New System.Windows.Forms.Label()
        Me.etiquetaCeleste = New System.Windows.Forms.Label()
        Me.etiquetaAmarilla = New System.Windows.Forms.Label()
        Me.etiquetaNaranja = New System.Windows.Forms.Label()
        Me.etiquetaISR = New System.Windows.Forms.Label()
        Me.etiquetaRoja = New System.Windows.Forms.Label()
        Me.celdaVerde = New System.Windows.Forms.TextBox()
        Me.celdaCeleste = New System.Windows.Forms.TextBox()
        Me.celdaAmarila = New System.Windows.Forms.TextBox()
        Me.celdaNaranja = New System.Windows.Forms.TextBox()
        Me.celdaRosa = New System.Windows.Forms.TextBox()
        Me.celdaRoja = New System.Windows.Forms.TextBox()
        Me.panelEncabezado = New System.Windows.Forms.Panel()
        Me.celdaidProveedores = New System.Windows.Forms.TextBox()
        Me.panelCriterios = New System.Windows.Forms.Panel()
        Me.botonTodo = New System.Windows.Forms.Button()
        Me.botonImportaciones = New System.Windows.Forms.Button()
        Me.botonLocal = New System.Windows.Forms.Button()
        Me.checkDocSaldo = New System.Windows.Forms.CheckBox()
        Me.botonProveedores = New System.Windows.Forms.Button()
        Me.celdaProveedores = New System.Windows.Forms.TextBox()
        Me.etiquetaDocumentos = New System.Windows.Forms.Label()
        Me.botonActualizar = New System.Windows.Forms.Button()
        Me.dtpFinal = New System.Windows.Forms.DateTimePicker()
        Me.etiquetaFecha = New System.Windows.Forms.Label()
        Me.dtpInicial = New System.Windows.Forms.DateTimePicker()
        Me.checkFecha = New System.Windows.Forms.CheckBox()
        Me.panelDocumento = New System.Windows.Forms.Panel()
        Me.panelDatosFac = New System.Windows.Forms.Panel()
        Me.panelResolucion = New System.Windows.Forms.Panel()
        Me.celdaIdResolución = New System.Windows.Forms.TextBox()
        Me.botonResolción = New System.Windows.Forms.Button()
        Me.celdaResolucion = New System.Windows.Forms.TextBox()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.celdaTipoOrden = New System.Windows.Forms.TextBox()
        Me.botonDocumentos = New System.Windows.Forms.Button()
        Me.celdaDetalleDocumento = New System.Windows.Forms.TextBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.dtpFechaPolizaC = New System.Windows.Forms.DateTimePicker()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.celdaMontoProd = New System.Windows.Forms.TextBox()
        Me.etiquetaDiaCredito = New System.Windows.Forms.Label()
        Me.BotonNotas = New System.Windows.Forms.Button()
        Me.celdaSerieFel = New System.Windows.Forms.TextBox()
        Me.celdaFechaHoraCertificacion = New System.Windows.Forms.TextBox()
        Me.celdaUUID = New System.Windows.Forms.TextBox()
        Me.celdaFechaEmisionDocumento = New System.Windows.Forms.TextBox()
        Me.checkActive = New System.Windows.Forms.CheckBox()
        Me.CheckFactEspecial = New System.Windows.Forms.CheckBox()
        Me.etiquetaExtemporanea = New System.Windows.Forms.Label()
        Me.celdaCAI = New System.Windows.Forms.TextBox()
        Me.etiquetaCAI = New System.Windows.Forms.Label()
        Me.botonGenerarIngreso = New System.Windows.Forms.Button()
        Me.rbOrdenDeCompra = New System.Windows.Forms.RadioButton()
        Me.rbImportación = New System.Windows.Forms.RadioButton()
        Me.rbLocal = New System.Windows.Forms.RadioButton()
        Me.celdaRevisado = New System.Windows.Forms.TextBox()
        Me.celdaDetFact = New System.Windows.Forms.TextBox()
        Me.botonProrrateo = New System.Windows.Forms.Button()
        Me.checkProrrateo = New System.Windows.Forms.CheckBox()
        Me.botonMoneda = New System.Windows.Forms.Button()
        Me.celdaNumOc = New System.Windows.Forms.TextBox()
        Me.celdaAnioOc = New System.Windows.Forms.TextBox()
        Me.celdaCatOc = New System.Windows.Forms.TextBox()
        Me.etiquetaNumero = New System.Windows.Forms.Label()
        Me.celdaRetension = New System.Windows.Forms.TextBox()
        Me.celdaNumero = New System.Windows.Forms.TextBox()
        Me.etiquetaSerie = New System.Windows.Forms.Label()
        Me.etiquetaCompra = New System.Windows.Forms.Label()
        Me.celdaSerie = New System.Windows.Forms.TextBox()
        Me.celdaNotas = New System.Windows.Forms.TextBox()
        Me.etiquetaFecha1 = New System.Windows.Forms.Label()
        Me.etiquetaNotas = New System.Windows.Forms.Label()
        Me.dtpFecha1 = New System.Windows.Forms.DateTimePicker()
        Me.botonISR = New System.Windows.Forms.Button()
        Me.etiquetaVence = New System.Windows.Forms.Label()
        Me.botonPagos = New System.Windows.Forms.Button()
        Me.dtpFechaVence = New System.Windows.Forms.DateTimePicker()
        Me.checkActivoFijo = New System.Windows.Forms.CheckBox()
        Me.etiquetaProveedor = New System.Windows.Forms.Label()
        Me.checkRevisado = New System.Windows.Forms.CheckBox()
        Me.celdaProveedor = New System.Windows.Forms.TextBox()
        Me.etiquetaMontoTotal = New System.Windows.Forms.Label()
        Me.botonProveedor = New System.Windows.Forms.Button()
        Me.celdaTasa = New System.Windows.Forms.TextBox()
        Me.botonFecha = New System.Windows.Forms.Button()
        Me.etiquetaTasa = New System.Windows.Forms.Label()
        Me.celdaProveedor1 = New System.Windows.Forms.TextBox()
        Me.celdaMoneda1 = New System.Windows.Forms.TextBox()
        Me.celdaFechaVence = New System.Windows.Forms.TextBox()
        Me.botonMonedaConvert = New System.Windows.Forms.Button()
        Me.celdaFecha1 = New System.Windows.Forms.TextBox()
        Me.celdaMoneda = New System.Windows.Forms.TextBox()
        Me.checkContribuyent = New System.Windows.Forms.CheckBox()
        Me.etiquetaMoneda = New System.Windows.Forms.Label()
        Me.checkFacElectrónica = New System.Windows.Forms.CheckBox()
        Me.celdaMonto = New System.Windows.Forms.TextBox()
        Me.etiquetaNIT = New System.Windows.Forms.Label()
        Me.etiquetaMonto = New System.Windows.Forms.Label()
        Me.celdaNIT = New System.Windows.Forms.TextBox()
        Me.botonPolizaContable = New System.Windows.Forms.Button()
        Me.etiquetaInvoice = New System.Windows.Forms.Label()
        Me.dgFacturas = New System.Windows.Forms.DataGridView()
        Me.colCat = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colAnio = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colNumber = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colLineaFactura = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colLineaOrden = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colCantidad = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colDescripcion = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colPrecioSinIVA = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colPrecio = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colTotal = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colCodigo = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colCuentaActivo = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colActivo = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colidCuentaIVA = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colCuenta = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colGasto = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colCosto = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colCentro = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colClasificacion = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colAgregar = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colCtaIVA = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colCodigoP = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.col_idCuenta = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.col_NomCuentafectar = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.col_idRubro = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.col_Rubro = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.loteNum = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.panelBtnDetalle = New System.Windows.Forms.Panel()
        Me.botonMenos = New System.Windows.Forms.Button()
        Me.botonMas = New System.Windows.Forms.Button()
        Me.panelDesglose = New System.Windows.Forms.Panel()
        Me.gbPoliza = New System.Windows.Forms.GroupBox()
        Me.dgOrdenes = New System.Windows.Forms.DataGridView()
        Me.colCatalogo = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colAñio = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colNumero = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colDate = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colLineOrden = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colReference = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.botonDesligar = New System.Windows.Forms.Button()
        Me.dgPoliza = New System.Windows.Forms.DataGridView()
        Me.colTipo1 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colAño = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colNum = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colPoliza = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colLinea = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colCantida = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colPrice = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colMonto1 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colFechaIngreso = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.TC_Poliza = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.botonRelacionar = New System.Windows.Forms.Button()
        Me.gbImpuestos = New System.Windows.Forms.GroupBox()
        Me.panelBotones = New System.Windows.Forms.Panel()
        Me.botonEliminar = New System.Windows.Forms.Button()
        Me.botonOtrosImp = New System.Windows.Forms.Button()
        Me.botnEditar = New System.Windows.Forms.Button()
        Me.dgImpuestos = New System.Windows.Forms.DataGridView()
        Me.colLine = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colID = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colCodigo1 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colTipo = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colDescripcion1 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colCantidad1 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colFactor = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colBase = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colMonto = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colTag = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colOrigen = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.panelDetalle = New System.Windows.Forms.Panel()
        Me.DataGridView1 = New System.Windows.Forms.DataGridView()
        Me.dgPagos = New System.Windows.Forms.DataGridView()
        Me.colTipo2 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colAño2 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colNumero2 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colMoneda2 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colTasa = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colCargoEx = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colAbonoEx = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colFecha2 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colDocumento = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colReferencia = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colConcepto = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colCargo = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colAbono = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colSaldo2 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.panelProrrateo = New System.Windows.Forms.Panel()
        Me.paneBotones = New System.Windows.Forms.Panel()
        Me.botonSeleccionar = New System.Windows.Forms.Button()
        Me.dgProrrateo = New System.Windows.Forms.DataGridView()
        Me.colIDP = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colCCostosP = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colCheckP = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.botonImprimir = New System.Windows.Forms.Button()
        Me.botonPrevio = New System.Windows.Forms.Button()
        Me.etiquetaAutorizacion = New System.Windows.Forms.Label()
        Me.etiquetaSerieF = New System.Windows.Forms.Label()
        Me.BarraTitulo1 = New KARIMs_SGI.BarraTitulo()
        Me.Encabezado1 = New KARIMs_SGI.encabezado()
        Me.panelLista.SuspendLayout()
        CType(Me.dgLista, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.PanelPiePagina.SuspendLayout()
        Me.panelEncabezado.SuspendLayout()
        Me.panelCriterios.SuspendLayout()
        Me.panelDocumento.SuspendLayout()
        Me.panelDatosFac.SuspendLayout()
        Me.panelResolucion.SuspendLayout()
        CType(Me.dgFacturas, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.panelBtnDetalle.SuspendLayout()
        Me.panelDesglose.SuspendLayout()
        Me.gbPoliza.SuspendLayout()
        CType(Me.dgOrdenes, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.dgPoliza, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.gbImpuestos.SuspendLayout()
        Me.panelBotones.SuspendLayout()
        CType(Me.dgImpuestos, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.panelDetalle.SuspendLayout()
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.dgPagos, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.panelProrrateo.SuspendLayout()
        Me.paneBotones.SuspendLayout()
        CType(Me.dgProrrateo, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'panelLista
        '
        Me.panelLista.Controls.Add(Me.dgLista)
        Me.panelLista.Controls.Add(Me.PanelPiePagina)
        Me.panelLista.Controls.Add(Me.panelEncabezado)
        Me.panelLista.Location = New System.Drawing.Point(358, 9)
        Me.panelLista.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.panelLista.Name = "panelLista"
        Me.panelLista.Size = New System.Drawing.Size(164, 139)
        Me.panelLista.TabIndex = 2
        '
        'dgLista
        '
        Me.dgLista.AllowUserToAddRows = False
        Me.dgLista.AllowUserToDeleteRows = False
        Me.dgLista.AllowUserToOrderColumns = True
        Me.dgLista.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells
        Me.dgLista.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells
        Me.dgLista.BackgroundColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle1.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.dgLista.ColumnHeadersDefaultCellStyle = DataGridViewCellStyle1
        Me.dgLista.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgLista.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.colIdLista, Me.colTipoLista, Me.colAñoLista, Me.colNumeroLista, Me.colFecha, Me.colFactura, Me.ColProveedor, Me.colMoneda, Me.colSaldo, Me.colGrupo, Me.colClase, Me.colProcesado, Me.colEstado, Me.colSIVA, Me.colISR, Me.colFechaVence, Me.colReten, Me.colSerieF, Me.colAutorizacionF, Me.tipoDocumento, Me.SinIngresos, Me.TipoOC})
        DataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle2.BackColor = System.Drawing.SystemColors.Window
        DataGridViewCellStyle2.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.ControlText
        DataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.[False]
        Me.dgLista.DefaultCellStyle = DataGridViewCellStyle2
        Me.dgLista.Dock = System.Windows.Forms.DockStyle.Fill
        Me.dgLista.Location = New System.Drawing.Point(0, 80)
        Me.dgLista.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.dgLista.MultiSelect = False
        Me.dgLista.Name = "dgLista"
        Me.dgLista.ReadOnly = True
        DataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle3.BackColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle3.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle3.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle3.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle3.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.dgLista.RowHeadersDefaultCellStyle = DataGridViewCellStyle3
        Me.dgLista.RowTemplate.Height = 24
        Me.dgLista.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.dgLista.Size = New System.Drawing.Size(164, 0)
        Me.dgLista.TabIndex = 0
        '
        'colIdLista
        '
        Me.colIdLista.HeaderText = "ID"
        Me.colIdLista.Name = "colIdLista"
        Me.colIdLista.ReadOnly = True
        Me.colIdLista.Visible = False
        Me.colIdLista.Width = 43
        '
        'colTipoLista
        '
        Me.colTipoLista.HeaderText = "Type"
        Me.colTipoLista.Name = "colTipoLista"
        Me.colTipoLista.ReadOnly = True
        Me.colTipoLista.Visible = False
        Me.colTipoLista.Width = 56
        '
        'colAñoLista
        '
        Me.colAñoLista.HeaderText = "Year"
        Me.colAñoLista.Name = "colAñoLista"
        Me.colAñoLista.ReadOnly = True
        Me.colAñoLista.Visible = False
        Me.colAñoLista.Width = 54
        '
        'colNumeroLista
        '
        Me.colNumeroLista.HeaderText = "Number"
        Me.colNumeroLista.Name = "colNumeroLista"
        Me.colNumeroLista.ReadOnly = True
        Me.colNumeroLista.Visible = False
        Me.colNumeroLista.Width = 69
        '
        'colFecha
        '
        Me.colFecha.HeaderText = "Date"
        Me.colFecha.Name = "colFecha"
        Me.colFecha.ReadOnly = True
        Me.colFecha.Width = 55
        '
        'colFactura
        '
        Me.colFactura.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.colFactura.HeaderText = "Invoice No."
        Me.colFactura.Name = "colFactura"
        Me.colFactura.ReadOnly = True
        Me.colFactura.Width = 80
        '
        'ColProveedor
        '
        Me.ColProveedor.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill
        Me.ColProveedor.HeaderText = "Provider"
        Me.ColProveedor.Name = "ColProveedor"
        Me.ColProveedor.ReadOnly = True
        '
        'colMoneda
        '
        Me.colMoneda.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.colMoneda.HeaderText = "Coin"
        Me.colMoneda.Name = "colMoneda"
        Me.colMoneda.ReadOnly = True
        Me.colMoneda.Width = 53
        '
        'colSaldo
        '
        Me.colSaldo.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.colSaldo.HeaderText = "Balance"
        Me.colSaldo.Name = "colSaldo"
        Me.colSaldo.ReadOnly = True
        Me.colSaldo.Width = 71
        '
        'colGrupo
        '
        Me.colGrupo.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.colGrupo.HeaderText = "Grupo"
        Me.colGrupo.Name = "colGrupo"
        Me.colGrupo.ReadOnly = True
        Me.colGrupo.Width = 61
        '
        'colClase
        '
        Me.colClase.HeaderText = "Clase"
        Me.colClase.Name = "colClase"
        Me.colClase.ReadOnly = True
        Me.colClase.Visible = False
        Me.colClase.Width = 58
        '
        'colProcesado
        '
        Me.colProcesado.HeaderText = "Procesado"
        Me.colProcesado.Name = "colProcesado"
        Me.colProcesado.ReadOnly = True
        Me.colProcesado.Visible = False
        Me.colProcesado.Width = 83
        '
        'colEstado
        '
        Me.colEstado.HeaderText = "Estado"
        Me.colEstado.Name = "colEstado"
        Me.colEstado.ReadOnly = True
        Me.colEstado.Visible = False
        Me.colEstado.Width = 65
        '
        'colSIVA
        '
        Me.colSIVA.HeaderText = "SIVA"
        Me.colSIVA.Name = "colSIVA"
        Me.colSIVA.ReadOnly = True
        Me.colSIVA.Visible = False
        Me.colSIVA.Width = 56
        '
        'colISR
        '
        Me.colISR.HeaderText = "RISR"
        Me.colISR.Name = "colISR"
        Me.colISR.ReadOnly = True
        Me.colISR.Visible = False
        Me.colISR.Width = 58
        '
        'colFechaVence
        '
        Me.colFechaVence.HeaderText = "FechaVence"
        Me.colFechaVence.Name = "colFechaVence"
        Me.colFechaVence.ReadOnly = True
        Me.colFechaVence.Visible = False
        Me.colFechaVence.Width = 93
        '
        'colReten
        '
        Me.colReten.HeaderText = "Reten"
        Me.colReten.Name = "colReten"
        Me.colReten.ReadOnly = True
        Me.colReten.Visible = False
        Me.colReten.Width = 61
        '
        'colSerieF
        '
        Me.colSerieF.HeaderText = "Serie Fel"
        Me.colSerieF.Name = "colSerieF"
        Me.colSerieF.ReadOnly = True
        Me.colSerieF.Width = 68
        '
        'colAutorizacionF
        '
        Me.colAutorizacionF.HeaderText = "Autorizacion Fel"
        Me.colAutorizacionF.Name = "colAutorizacionF"
        Me.colAutorizacionF.ReadOnly = True
        Me.colAutorizacionF.Width = 98
        '
        'tipoDocumento
        '
        Me.tipoDocumento.HeaderText = "tipoDocumento"
        Me.tipoDocumento.Name = "tipoDocumento"
        Me.tipoDocumento.ReadOnly = True
        Me.tipoDocumento.Width = 104
        '
        'SinIngresos
        '
        Me.SinIngresos.HeaderText = "SinIngresos"
        Me.SinIngresos.Name = "SinIngresos"
        Me.SinIngresos.ReadOnly = True
        Me.SinIngresos.Visible = False
        Me.SinIngresos.Width = 87
        '
        'TipoOC
        '
        Me.TipoOC.HeaderText = "TipoOC"
        Me.TipoOC.Name = "TipoOC"
        Me.TipoOC.ReadOnly = True
        Me.TipoOC.Visible = False
        Me.TipoOC.Width = 68
        '
        'PanelPiePagina
        '
        Me.PanelPiePagina.Controls.Add(Me.Label3)
        Me.PanelPiePagina.Controls.Add(Me.TextBox2)
        Me.PanelPiePagina.Controls.Add(Me.TextBox1)
        Me.PanelPiePagina.Controls.Add(Me.etiquetaOrden)
        Me.PanelPiePagina.Controls.Add(Me.etiquetaVerde)
        Me.PanelPiePagina.Controls.Add(Me.etiquetaCeleste)
        Me.PanelPiePagina.Controls.Add(Me.etiquetaAmarilla)
        Me.PanelPiePagina.Controls.Add(Me.etiquetaNaranja)
        Me.PanelPiePagina.Controls.Add(Me.etiquetaISR)
        Me.PanelPiePagina.Controls.Add(Me.etiquetaRoja)
        Me.PanelPiePagina.Controls.Add(Me.celdaVerde)
        Me.PanelPiePagina.Controls.Add(Me.celdaCeleste)
        Me.PanelPiePagina.Controls.Add(Me.celdaAmarila)
        Me.PanelPiePagina.Controls.Add(Me.celdaNaranja)
        Me.PanelPiePagina.Controls.Add(Me.celdaRosa)
        Me.PanelPiePagina.Controls.Add(Me.celdaRoja)
        Me.PanelPiePagina.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.PanelPiePagina.Location = New System.Drawing.Point(0, 79)
        Me.PanelPiePagina.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.PanelPiePagina.Name = "PanelPiePagina"
        Me.PanelPiePagina.Size = New System.Drawing.Size(164, 60)
        Me.PanelPiePagina.TabIndex = 2
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(846, 37)
        Me.Label3.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(68, 13)
        Me.Label3.TabIndex = 17
        Me.Label3.Text = "NO INCOME"
        '
        'TextBox2
        '
        Me.TextBox2.BackColor = System.Drawing.Color.Yellow
        Me.TextBox2.Location = New System.Drawing.Point(821, 34)
        Me.TextBox2.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.TextBox2.Name = "TextBox2"
        Me.TextBox2.Size = New System.Drawing.Size(16, 20)
        Me.TextBox2.TabIndex = 16
        '
        'TextBox1
        '
        Me.TextBox1.BackColor = System.Drawing.Color.BlueViolet
        Me.TextBox1.ForeColor = System.Drawing.Color.Black
        Me.TextBox1.Location = New System.Drawing.Point(707, 33)
        Me.TextBox1.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.TextBox1.Name = "TextBox1"
        Me.TextBox1.Size = New System.Drawing.Size(16, 20)
        Me.TextBox1.TabIndex = 13
        '
        'etiquetaOrden
        '
        Me.etiquetaOrden.AutoSize = True
        Me.etiquetaOrden.Location = New System.Drawing.Point(727, 35)
        Me.etiquetaOrden.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.etiquetaOrden.Name = "etiquetaOrden"
        Me.etiquetaOrden.Size = New System.Drawing.Size(81, 13)
        Me.etiquetaOrden.TabIndex = 12
        Me.etiquetaOrden.Text = "Purchase Order"
        '
        'etiquetaVerde
        '
        Me.etiquetaVerde.AutoSize = True
        Me.etiquetaVerde.Location = New System.Drawing.Point(639, 35)
        Me.etiquetaVerde.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.etiquetaVerde.Name = "etiquetaVerde"
        Me.etiquetaVerde.Size = New System.Drawing.Size(36, 13)
        Me.etiquetaVerde.TabIndex = 11
        Me.etiquetaVerde.Text = "Import"
        '
        'etiquetaCeleste
        '
        Me.etiquetaCeleste.AutoSize = True
        Me.etiquetaCeleste.Location = New System.Drawing.Point(526, 36)
        Me.etiquetaCeleste.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.etiquetaCeleste.Name = "etiquetaCeleste"
        Me.etiquetaCeleste.Size = New System.Drawing.Size(69, 13)
        Me.etiquetaCeleste.TabIndex = 10
        Me.etiquetaCeleste.Text = "Electronic bill"
        '
        'etiquetaAmarilla
        '
        Me.etiquetaAmarilla.AutoSize = True
        Me.etiquetaAmarilla.Location = New System.Drawing.Point(406, 37)
        Me.etiquetaAmarilla.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.etiquetaAmarilla.Name = "etiquetaAmarilla"
        Me.etiquetaAmarilla.Size = New System.Drawing.Size(75, 13)
        Me.etiquetaAmarilla.TabIndex = 9
        Me.etiquetaAmarilla.Text = "Small taxpayer"
        '
        'etiquetaNaranja
        '
        Me.etiquetaNaranja.AutoSize = True
        Me.etiquetaNaranja.Location = New System.Drawing.Point(256, 37)
        Me.etiquetaNaranja.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.etiquetaNaranja.Name = "etiquetaNaranja"
        Me.etiquetaNaranja.Size = New System.Drawing.Size(107, 13)
        Me.etiquetaNaranja.TabIndex = 8
        Me.etiquetaNaranja.Text = "No accounting policy"
        '
        'etiquetaISR
        '
        Me.etiquetaISR.AutoSize = True
        Me.etiquetaISR.Location = New System.Drawing.Point(142, 37)
        Me.etiquetaISR.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.etiquetaISR.Name = "etiquetaISR"
        Me.etiquetaISR.Size = New System.Drawing.Size(71, 13)
        Me.etiquetaISR.TabIndex = 7
        Me.etiquetaISR.Text = "ISR Detained"
        '
        'etiquetaRoja
        '
        Me.etiquetaRoja.AutoSize = True
        Me.etiquetaRoja.Location = New System.Drawing.Point(28, 36)
        Me.etiquetaRoja.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.etiquetaRoja.Name = "etiquetaRoja"
        Me.etiquetaRoja.Size = New System.Drawing.Size(70, 13)
        Me.etiquetaRoja.TabIndex = 6
        Me.etiquetaRoja.Text = "-CANCELED-"
        '
        'celdaVerde
        '
        Me.celdaVerde.BackColor = System.Drawing.Color.YellowGreen
        Me.celdaVerde.Location = New System.Drawing.Point(620, 32)
        Me.celdaVerde.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.celdaVerde.Name = "celdaVerde"
        Me.celdaVerde.Size = New System.Drawing.Size(16, 20)
        Me.celdaVerde.TabIndex = 5
        '
        'celdaCeleste
        '
        Me.celdaCeleste.BackColor = System.Drawing.Color.Orange
        Me.celdaCeleste.Location = New System.Drawing.Point(507, 32)
        Me.celdaCeleste.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.celdaCeleste.Name = "celdaCeleste"
        Me.celdaCeleste.Size = New System.Drawing.Size(16, 20)
        Me.celdaCeleste.TabIndex = 4
        '
        'celdaAmarila
        '
        Me.celdaAmarila.BackColor = System.Drawing.Color.LightYellow
        Me.celdaAmarila.Location = New System.Drawing.Point(386, 32)
        Me.celdaAmarila.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.celdaAmarila.Name = "celdaAmarila"
        Me.celdaAmarila.Size = New System.Drawing.Size(16, 20)
        Me.celdaAmarila.TabIndex = 3
        '
        'celdaNaranja
        '
        Me.celdaNaranja.BackColor = System.Drawing.Color.SkyBlue
        Me.celdaNaranja.Location = New System.Drawing.Point(236, 32)
        Me.celdaNaranja.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.celdaNaranja.Name = "celdaNaranja"
        Me.celdaNaranja.Size = New System.Drawing.Size(16, 20)
        Me.celdaNaranja.TabIndex = 2
        '
        'celdaRosa
        '
        Me.celdaRosa.BackColor = System.Drawing.Color.RoyalBlue
        Me.celdaRosa.Location = New System.Drawing.Point(122, 32)
        Me.celdaRosa.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.celdaRosa.Name = "celdaRosa"
        Me.celdaRosa.Size = New System.Drawing.Size(16, 20)
        Me.celdaRosa.TabIndex = 1
        '
        'celdaRoja
        '
        Me.celdaRoja.BackColor = System.Drawing.Color.Red
        Me.celdaRoja.Location = New System.Drawing.Point(9, 32)
        Me.celdaRoja.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.celdaRoja.Name = "celdaRoja"
        Me.celdaRoja.Size = New System.Drawing.Size(16, 20)
        Me.celdaRoja.TabIndex = 0
        '
        'panelEncabezado
        '
        Me.panelEncabezado.Controls.Add(Me.celdaidProveedores)
        Me.panelEncabezado.Controls.Add(Me.panelCriterios)
        Me.panelEncabezado.Controls.Add(Me.checkDocSaldo)
        Me.panelEncabezado.Controls.Add(Me.botonProveedores)
        Me.panelEncabezado.Controls.Add(Me.celdaProveedores)
        Me.panelEncabezado.Controls.Add(Me.etiquetaDocumentos)
        Me.panelEncabezado.Controls.Add(Me.botonActualizar)
        Me.panelEncabezado.Controls.Add(Me.dtpFinal)
        Me.panelEncabezado.Controls.Add(Me.etiquetaFecha)
        Me.panelEncabezado.Controls.Add(Me.dtpInicial)
        Me.panelEncabezado.Controls.Add(Me.checkFecha)
        Me.panelEncabezado.Dock = System.Windows.Forms.DockStyle.Top
        Me.panelEncabezado.Location = New System.Drawing.Point(0, 0)
        Me.panelEncabezado.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.panelEncabezado.Name = "panelEncabezado"
        Me.panelEncabezado.Size = New System.Drawing.Size(164, 80)
        Me.panelEncabezado.TabIndex = 0
        '
        'celdaidProveedores
        '
        Me.celdaidProveedores.Location = New System.Drawing.Point(656, 44)
        Me.celdaidProveedores.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.celdaidProveedores.Name = "celdaidProveedores"
        Me.celdaidProveedores.Size = New System.Drawing.Size(24, 20)
        Me.celdaidProveedores.TabIndex = 14
        Me.celdaidProveedores.Visible = False
        '
        'panelCriterios
        '
        Me.panelCriterios.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.panelCriterios.Controls.Add(Me.botonTodo)
        Me.panelCriterios.Controls.Add(Me.botonImportaciones)
        Me.panelCriterios.Controls.Add(Me.botonLocal)
        Me.panelCriterios.Location = New System.Drawing.Point(-74, 37)
        Me.panelCriterios.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.panelCriterios.Name = "panelCriterios"
        Me.panelCriterios.Size = New System.Drawing.Size(229, 38)
        Me.panelCriterios.TabIndex = 13
        '
        'botonTodo
        '
        Me.botonTodo.Location = New System.Drawing.Point(20, 15)
        Me.botonTodo.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.botonTodo.Name = "botonTodo"
        Me.botonTodo.Size = New System.Drawing.Size(56, 21)
        Me.botonTodo.TabIndex = 10
        Me.botonTodo.Text = "All"
        Me.botonTodo.UseVisualStyleBackColor = True
        '
        'botonImportaciones
        '
        Me.botonImportaciones.Location = New System.Drawing.Point(151, 15)
        Me.botonImportaciones.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.botonImportaciones.Name = "botonImportaciones"
        Me.botonImportaciones.Size = New System.Drawing.Size(56, 21)
        Me.botonImportaciones.TabIndex = 12
        Me.botonImportaciones.Text = "Imports"
        Me.botonImportaciones.TextAlign = System.Drawing.ContentAlignment.TopCenter
        Me.botonImportaciones.UseVisualStyleBackColor = True
        '
        'botonLocal
        '
        Me.botonLocal.Location = New System.Drawing.Point(84, 15)
        Me.botonLocal.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.botonLocal.Name = "botonLocal"
        Me.botonLocal.Size = New System.Drawing.Size(56, 21)
        Me.botonLocal.TabIndex = 11
        Me.botonLocal.Text = "Local"
        Me.botonLocal.UseVisualStyleBackColor = True
        '
        'checkDocSaldo
        '
        Me.checkDocSaldo.AutoSize = True
        Me.checkDocSaldo.Checked = True
        Me.checkDocSaldo.CheckState = System.Windows.Forms.CheckState.Checked
        Me.checkDocSaldo.Location = New System.Drawing.Point(729, 8)
        Me.checkDocSaldo.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.checkDocSaldo.Name = "checkDocSaldo"
        Me.checkDocSaldo.Size = New System.Drawing.Size(165, 17)
        Me.checkDocSaldo.TabIndex = 9
        Me.checkDocSaldo.Text = "Only documents with balance"
        Me.checkDocSaldo.UseVisualStyleBackColor = True
        '
        'botonProveedores
        '
        Me.botonProveedores.Location = New System.Drawing.Point(417, 45)
        Me.botonProveedores.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.botonProveedores.Name = "botonProveedores"
        Me.botonProveedores.Size = New System.Drawing.Size(25, 19)
        Me.botonProveedores.TabIndex = 8
        Me.botonProveedores.Text = "..."
        Me.botonProveedores.UseVisualStyleBackColor = True
        '
        'celdaProveedores
        '
        Me.celdaProveedores.Location = New System.Drawing.Point(75, 46)
        Me.celdaProveedores.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.celdaProveedores.Name = "celdaProveedores"
        Me.celdaProveedores.Size = New System.Drawing.Size(338, 20)
        Me.celdaProveedores.TabIndex = 7
        '
        'etiquetaDocumentos
        '
        Me.etiquetaDocumentos.AutoSize = True
        Me.etiquetaDocumentos.Location = New System.Drawing.Point(10, 47)
        Me.etiquetaDocumentos.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.etiquetaDocumentos.Name = "etiquetaDocumentos"
        Me.etiquetaDocumentos.Size = New System.Drawing.Size(61, 13)
        Me.etiquetaDocumentos.TabIndex = 6
        Me.etiquetaDocumentos.Text = "Documents"
        '
        'botonActualizar
        '
        Me.botonActualizar.Location = New System.Drawing.Point(424, 3)
        Me.botonActualizar.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.botonActualizar.Name = "botonActualizar"
        Me.botonActualizar.Size = New System.Drawing.Size(56, 23)
        Me.botonActualizar.TabIndex = 5
        Me.botonActualizar.Text = "Refresh"
        Me.botonActualizar.TextAlign = System.Drawing.ContentAlignment.TopCenter
        Me.botonActualizar.UseVisualStyleBackColor = True
        '
        'dtpFinal
        '
        Me.dtpFinal.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.dtpFinal.Location = New System.Drawing.Point(331, 7)
        Me.dtpFinal.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.dtpFinal.Name = "dtpFinal"
        Me.dtpFinal.Size = New System.Drawing.Size(83, 20)
        Me.dtpFinal.TabIndex = 4
        '
        'etiquetaFecha
        '
        Me.etiquetaFecha.AutoSize = True
        Me.etiquetaFecha.Location = New System.Drawing.Point(277, 9)
        Me.etiquetaFecha.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.etiquetaFecha.Name = "etiquetaFecha"
        Me.etiquetaFecha.Size = New System.Drawing.Size(51, 13)
        Me.etiquetaFecha.TabIndex = 3
        Me.etiquetaFecha.Text = "and Date"
        '
        'dtpInicial
        '
        Me.dtpInicial.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.dtpInicial.Location = New System.Drawing.Point(184, 8)
        Me.dtpInicial.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.dtpInicial.Name = "dtpInicial"
        Me.dtpInicial.Size = New System.Drawing.Size(83, 20)
        Me.dtpInicial.TabIndex = 2
        '
        'checkFecha
        '
        Me.checkFecha.AutoSize = True
        Me.checkFecha.Checked = True
        Me.checkFecha.CheckState = System.Windows.Forms.CheckState.Checked
        Me.checkFecha.Location = New System.Drawing.Point(9, 8)
        Me.checkFecha.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.checkFecha.Name = "checkFecha"
        Me.checkFecha.Size = New System.Drawing.Size(176, 17)
        Me.checkFecha.TabIndex = 1
        Me.checkFecha.Text = "Show documents between date"
        Me.checkFecha.UseVisualStyleBackColor = True
        '
        'panelDocumento
        '
        Me.panelDocumento.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.panelDocumento.Controls.Add(Me.panelDatosFac)
        Me.panelDocumento.Controls.Add(Me.dgFacturas)
        Me.panelDocumento.Controls.Add(Me.panelBtnDetalle)
        Me.panelDocumento.Controls.Add(Me.panelDesglose)
        Me.panelDocumento.Location = New System.Drawing.Point(62, 170)
        Me.panelDocumento.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.panelDocumento.Name = "panelDocumento"
        Me.panelDocumento.Size = New System.Drawing.Size(904, 474)
        Me.panelDocumento.TabIndex = 3
        '
        'panelDatosFac
        '
        Me.panelDatosFac.Controls.Add(Me.panelResolucion)
        Me.panelDatosFac.Controls.Add(Me.celdaTipoOrden)
        Me.panelDatosFac.Controls.Add(Me.botonDocumentos)
        Me.panelDatosFac.Controls.Add(Me.celdaDetalleDocumento)
        Me.panelDatosFac.Controls.Add(Me.Label2)
        Me.panelDatosFac.Controls.Add(Me.dtpFechaPolizaC)
        Me.panelDatosFac.Controls.Add(Me.Label1)
        Me.panelDatosFac.Controls.Add(Me.celdaMontoProd)
        Me.panelDatosFac.Controls.Add(Me.etiquetaDiaCredito)
        Me.panelDatosFac.Controls.Add(Me.BotonNotas)
        Me.panelDatosFac.Controls.Add(Me.celdaSerieFel)
        Me.panelDatosFac.Controls.Add(Me.celdaFechaHoraCertificacion)
        Me.panelDatosFac.Controls.Add(Me.celdaUUID)
        Me.panelDatosFac.Controls.Add(Me.celdaFechaEmisionDocumento)
        Me.panelDatosFac.Controls.Add(Me.checkActive)
        Me.panelDatosFac.Controls.Add(Me.CheckFactEspecial)
        Me.panelDatosFac.Controls.Add(Me.etiquetaExtemporanea)
        Me.panelDatosFac.Controls.Add(Me.celdaCAI)
        Me.panelDatosFac.Controls.Add(Me.etiquetaCAI)
        Me.panelDatosFac.Controls.Add(Me.botonGenerarIngreso)
        Me.panelDatosFac.Controls.Add(Me.rbOrdenDeCompra)
        Me.panelDatosFac.Controls.Add(Me.rbImportación)
        Me.panelDatosFac.Controls.Add(Me.rbLocal)
        Me.panelDatosFac.Controls.Add(Me.celdaRevisado)
        Me.panelDatosFac.Controls.Add(Me.celdaDetFact)
        Me.panelDatosFac.Controls.Add(Me.botonProrrateo)
        Me.panelDatosFac.Controls.Add(Me.checkProrrateo)
        Me.panelDatosFac.Controls.Add(Me.botonMoneda)
        Me.panelDatosFac.Controls.Add(Me.celdaNumOc)
        Me.panelDatosFac.Controls.Add(Me.celdaAnioOc)
        Me.panelDatosFac.Controls.Add(Me.celdaCatOc)
        Me.panelDatosFac.Controls.Add(Me.etiquetaNumero)
        Me.panelDatosFac.Controls.Add(Me.celdaRetension)
        Me.panelDatosFac.Controls.Add(Me.celdaNumero)
        Me.panelDatosFac.Controls.Add(Me.etiquetaSerie)
        Me.panelDatosFac.Controls.Add(Me.etiquetaCompra)
        Me.panelDatosFac.Controls.Add(Me.celdaSerie)
        Me.panelDatosFac.Controls.Add(Me.celdaNotas)
        Me.panelDatosFac.Controls.Add(Me.etiquetaFecha1)
        Me.panelDatosFac.Controls.Add(Me.etiquetaNotas)
        Me.panelDatosFac.Controls.Add(Me.dtpFecha1)
        Me.panelDatosFac.Controls.Add(Me.botonISR)
        Me.panelDatosFac.Controls.Add(Me.etiquetaVence)
        Me.panelDatosFac.Controls.Add(Me.botonPagos)
        Me.panelDatosFac.Controls.Add(Me.dtpFechaVence)
        Me.panelDatosFac.Controls.Add(Me.checkActivoFijo)
        Me.panelDatosFac.Controls.Add(Me.etiquetaProveedor)
        Me.panelDatosFac.Controls.Add(Me.checkRevisado)
        Me.panelDatosFac.Controls.Add(Me.celdaProveedor)
        Me.panelDatosFac.Controls.Add(Me.etiquetaMontoTotal)
        Me.panelDatosFac.Controls.Add(Me.botonProveedor)
        Me.panelDatosFac.Controls.Add(Me.celdaTasa)
        Me.panelDatosFac.Controls.Add(Me.botonFecha)
        Me.panelDatosFac.Controls.Add(Me.etiquetaTasa)
        Me.panelDatosFac.Controls.Add(Me.celdaProveedor1)
        Me.panelDatosFac.Controls.Add(Me.celdaMoneda1)
        Me.panelDatosFac.Controls.Add(Me.celdaFechaVence)
        Me.panelDatosFac.Controls.Add(Me.botonMonedaConvert)
        Me.panelDatosFac.Controls.Add(Me.celdaFecha1)
        Me.panelDatosFac.Controls.Add(Me.celdaMoneda)
        Me.panelDatosFac.Controls.Add(Me.checkContribuyent)
        Me.panelDatosFac.Controls.Add(Me.etiquetaMoneda)
        Me.panelDatosFac.Controls.Add(Me.checkFacElectrónica)
        Me.panelDatosFac.Controls.Add(Me.celdaMonto)
        Me.panelDatosFac.Controls.Add(Me.etiquetaNIT)
        Me.panelDatosFac.Controls.Add(Me.etiquetaMonto)
        Me.panelDatosFac.Controls.Add(Me.celdaNIT)
        Me.panelDatosFac.Controls.Add(Me.botonPolizaContable)
        Me.panelDatosFac.Controls.Add(Me.etiquetaInvoice)
        Me.panelDatosFac.Dock = System.Windows.Forms.DockStyle.Top
        Me.panelDatosFac.Location = New System.Drawing.Point(0, 0)
        Me.panelDatosFac.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.panelDatosFac.Name = "panelDatosFac"
        Me.panelDatosFac.Size = New System.Drawing.Size(904, 291)
        Me.panelDatosFac.TabIndex = 41
        '
        'panelResolucion
        '
        Me.panelResolucion.Controls.Add(Me.celdaIdResolución)
        Me.panelResolucion.Controls.Add(Me.botonResolción)
        Me.panelResolucion.Controls.Add(Me.celdaResolucion)
        Me.panelResolucion.Controls.Add(Me.Label12)
        Me.panelResolucion.Location = New System.Drawing.Point(861, 71)
        Me.panelResolucion.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.panelResolucion.Name = "panelResolucion"
        Me.panelResolucion.Size = New System.Drawing.Size(256, 46)
        Me.panelResolucion.TabIndex = 47
        Me.panelResolucion.Visible = False
        '
        'celdaIdResolución
        '
        Me.celdaIdResolución.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.celdaIdResolución.BackColor = System.Drawing.SystemColors.Info
        Me.celdaIdResolución.Location = New System.Drawing.Point(98, 3)
        Me.celdaIdResolución.Name = "celdaIdResolución"
        Me.celdaIdResolución.ReadOnly = True
        Me.celdaIdResolución.Size = New System.Drawing.Size(54, 20)
        Me.celdaIdResolución.TabIndex = 48
        Me.celdaIdResolución.Visible = False
        '
        'botonResolción
        '
        Me.botonResolción.Location = New System.Drawing.Point(224, 23)
        Me.botonResolción.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.botonResolción.Name = "botonResolción"
        Me.botonResolción.Size = New System.Drawing.Size(28, 19)
        Me.botonResolción.TabIndex = 47
        Me.botonResolción.Text = "..."
        Me.botonResolción.UseVisualStyleBackColor = True
        '
        'celdaResolucion
        '
        Me.celdaResolucion.BackColor = System.Drawing.SystemColors.Info
        Me.celdaResolucion.Location = New System.Drawing.Point(3, 23)
        Me.celdaResolucion.Name = "celdaResolucion"
        Me.celdaResolucion.ReadOnly = True
        Me.celdaResolucion.Size = New System.Drawing.Size(220, 20)
        Me.celdaResolucion.TabIndex = 45
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.Location = New System.Drawing.Point(2, 6)
        Me.Label12.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(57, 13)
        Me.Label12.TabIndex = 43
        Me.Label12.Text = "Resolution"
        '
        'celdaTipoOrden
        '
        Me.celdaTipoOrden.Location = New System.Drawing.Point(781, 162)
        Me.celdaTipoOrden.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.celdaTipoOrden.Name = "celdaTipoOrden"
        Me.celdaTipoOrden.Size = New System.Drawing.Size(38, 20)
        Me.celdaTipoOrden.TabIndex = 78
        Me.celdaTipoOrden.Visible = False
        '
        'botonDocumentos
        '
        Me.botonDocumentos.Location = New System.Drawing.Point(286, 8)
        Me.botonDocumentos.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.botonDocumentos.Name = "botonDocumentos"
        Me.botonDocumentos.Size = New System.Drawing.Size(24, 19)
        Me.botonDocumentos.TabIndex = 77
        Me.botonDocumentos.Text = "..."
        Me.botonDocumentos.UseVisualStyleBackColor = True
        '
        'celdaDetalleDocumento
        '
        Me.celdaDetalleDocumento.Location = New System.Drawing.Point(88, 9)
        Me.celdaDetalleDocumento.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.celdaDetalleDocumento.Name = "celdaDetalleDocumento"
        Me.celdaDetalleDocumento.ReadOnly = True
        Me.celdaDetalleDocumento.Size = New System.Drawing.Size(194, 20)
        Me.celdaDetalleDocumento.TabIndex = 76
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(16, 13)
        Me.Label2.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(56, 13)
        Me.Label2.TabIndex = 75
        Me.Label2.Text = "Document"
        '
        'dtpFechaPolizaC
        '
        Me.dtpFechaPolizaC.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.dtpFechaPolizaC.Location = New System.Drawing.Point(115, 93)
        Me.dtpFechaPolizaC.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.dtpFechaPolizaC.Name = "dtpFechaPolizaC"
        Me.dtpFechaPolizaC.Size = New System.Drawing.Size(91, 20)
        Me.dtpFechaPolizaC.TabIndex = 74
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(11, 71)
        Me.Label1.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(30, 13)
        Me.Label1.TabIndex = 73
        Me.Label1.Text = "Date"
        '
        'celdaMontoProd
        '
        Me.celdaMontoProd.Location = New System.Drawing.Point(198, 218)
        Me.celdaMontoProd.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.celdaMontoProd.Name = "celdaMontoProd"
        Me.celdaMontoProd.ReadOnly = True
        Me.celdaMontoProd.Size = New System.Drawing.Size(104, 20)
        Me.celdaMontoProd.TabIndex = 72
        Me.celdaMontoProd.Text = "0"
        Me.celdaMontoProd.Visible = False
        '
        'etiquetaDiaCredito
        '
        Me.etiquetaDiaCredito.AutoSize = True
        Me.etiquetaDiaCredito.BackColor = System.Drawing.SystemColors.Info
        Me.etiquetaDiaCredito.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.etiquetaDiaCredito.Location = New System.Drawing.Point(205, 71)
        Me.etiquetaDiaCredito.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.etiquetaDiaCredito.Name = "etiquetaDiaCredito"
        Me.etiquetaDiaCredito.Size = New System.Drawing.Size(14, 13)
        Me.etiquetaDiaCredito.TabIndex = 71
        Me.etiquetaDiaCredito.Text = "0"
        Me.etiquetaDiaCredito.Visible = False
        '
        'BotonNotas
        '
        Me.BotonNotas.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.BotonNotas.BackColor = System.Drawing.SystemColors.Control
        Me.BotonNotas.Enabled = False
        Me.BotonNotas.Image = CType(resources.GetObject("BotonNotas.Image"), System.Drawing.Image)
        Me.BotonNotas.ImageAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.BotonNotas.Location = New System.Drawing.Point(674, 169)
        Me.BotonNotas.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.BotonNotas.Name = "BotonNotas"
        Me.BotonNotas.Size = New System.Drawing.Size(60, 25)
        Me.BotonNotas.TabIndex = 70
        Me.BotonNotas.Text = "Save"
        Me.BotonNotas.TextAlign = System.Drawing.ContentAlignment.TopLeft
        Me.BotonNotas.UseVisualStyleBackColor = True
        '
        'celdaSerieFel
        '
        Me.celdaSerieFel.Location = New System.Drawing.Point(629, 65)
        Me.celdaSerieFel.Name = "celdaSerieFel"
        Me.celdaSerieFel.Size = New System.Drawing.Size(11, 20)
        Me.celdaSerieFel.TabIndex = 68
        Me.celdaSerieFel.Visible = False
        '
        'celdaFechaHoraCertificacion
        '
        Me.celdaFechaHoraCertificacion.Location = New System.Drawing.Point(614, 65)
        Me.celdaFechaHoraCertificacion.Name = "celdaFechaHoraCertificacion"
        Me.celdaFechaHoraCertificacion.Size = New System.Drawing.Size(11, 20)
        Me.celdaFechaHoraCertificacion.TabIndex = 67
        Me.celdaFechaHoraCertificacion.Visible = False
        '
        'celdaUUID
        '
        Me.celdaUUID.Location = New System.Drawing.Point(645, 63)
        Me.celdaUUID.Name = "celdaUUID"
        Me.celdaUUID.Size = New System.Drawing.Size(143, 20)
        Me.celdaUUID.TabIndex = 66
        Me.celdaUUID.Visible = False
        '
        'celdaFechaEmisionDocumento
        '
        Me.celdaFechaEmisionDocumento.Location = New System.Drawing.Point(600, 65)
        Me.celdaFechaEmisionDocumento.Name = "celdaFechaEmisionDocumento"
        Me.celdaFechaEmisionDocumento.Size = New System.Drawing.Size(11, 20)
        Me.celdaFechaEmisionDocumento.TabIndex = 65
        Me.celdaFechaEmisionDocumento.Visible = False
        '
        'checkActive
        '
        Me.checkActive.AutoSize = True
        Me.checkActive.Checked = True
        Me.checkActive.CheckState = System.Windows.Forms.CheckState.Checked
        Me.checkActive.Location = New System.Drawing.Point(507, 46)
        Me.checkActive.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.checkActive.Name = "checkActive"
        Me.checkActive.Size = New System.Drawing.Size(56, 17)
        Me.checkActive.TabIndex = 64
        Me.checkActive.Text = "Active"
        Me.checkActive.UseVisualStyleBackColor = True
        Me.checkActive.Visible = False
        '
        'CheckFactEspecial
        '
        Me.CheckFactEspecial.AutoSize = True
        Me.CheckFactEspecial.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.CheckFactEspecial.ForeColor = System.Drawing.Color.Green
        Me.CheckFactEspecial.Location = New System.Drawing.Point(89, 180)
        Me.CheckFactEspecial.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.CheckFactEspecial.Name = "CheckFactEspecial"
        Me.CheckFactEspecial.Size = New System.Drawing.Size(114, 17)
        Me.CheckFactEspecial.TabIndex = 58
        Me.CheckFactEspecial.Text = "Special Invoice"
        Me.CheckFactEspecial.UseVisualStyleBackColor = True
        '
        'etiquetaExtemporanea
        '
        Me.etiquetaExtemporanea.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.etiquetaExtemporanea.AutoSize = True
        Me.etiquetaExtemporanea.BackColor = System.Drawing.Color.DarkOrange
        Me.etiquetaExtemporanea.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.etiquetaExtemporanea.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.etiquetaExtemporanea.Location = New System.Drawing.Point(742, 114)
        Me.etiquetaExtemporanea.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.etiquetaExtemporanea.Name = "etiquetaExtemporanea"
        Me.etiquetaExtemporanea.Size = New System.Drawing.Size(129, 19)
        Me.etiquetaExtemporanea.TabIndex = 57
        Me.etiquetaExtemporanea.Text = "extemporaneous"
        Me.etiquetaExtemporanea.TextAlign = System.Drawing.ContentAlignment.TopCenter
        Me.etiquetaExtemporanea.Visible = False
        '
        'celdaCAI
        '
        Me.celdaCAI.Location = New System.Drawing.Point(567, 93)
        Me.celdaCAI.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.celdaCAI.Name = "celdaCAI"
        Me.celdaCAI.ReadOnly = True
        Me.celdaCAI.Size = New System.Drawing.Size(268, 20)
        Me.celdaCAI.TabIndex = 56
        '
        'etiquetaCAI
        '
        Me.etiquetaCAI.AutoSize = True
        Me.etiquetaCAI.Location = New System.Drawing.Point(541, 95)
        Me.etiquetaCAI.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.etiquetaCAI.Name = "etiquetaCAI"
        Me.etiquetaCAI.Size = New System.Drawing.Size(24, 13)
        Me.etiquetaCAI.TabIndex = 55
        Me.etiquetaCAI.Text = "CAI"
        '
        'botonGenerarIngreso
        '
        Me.botonGenerarIngreso.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.botonGenerarIngreso.Image = CType(resources.GetObject("botonGenerarIngreso.Image"), System.Drawing.Image)
        Me.botonGenerarIngreso.ImageAlign = System.Drawing.ContentAlignment.TopCenter
        Me.botonGenerarIngreso.Location = New System.Drawing.Point(602, 95)
        Me.botonGenerarIngreso.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.botonGenerarIngreso.Name = "botonGenerarIngreso"
        Me.botonGenerarIngreso.Size = New System.Drawing.Size(114, 53)
        Me.botonGenerarIngreso.TabIndex = 54
        Me.botonGenerarIngreso.Text = "Generate  Income to Inventory"
        Me.botonGenerarIngreso.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.botonGenerarIngreso.UseVisualStyleBackColor = True
        Me.botonGenerarIngreso.Visible = False
        '
        'rbOrdenDeCompra
        '
        Me.rbOrdenDeCompra.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.rbOrdenDeCompra.AutoSize = True
        Me.rbOrdenDeCompra.Location = New System.Drawing.Point(655, 43)
        Me.rbOrdenDeCompra.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.rbOrdenDeCompra.Name = "rbOrdenDeCompra"
        Me.rbOrdenDeCompra.Size = New System.Drawing.Size(99, 17)
        Me.rbOrdenDeCompra.TabIndex = 53
        Me.rbOrdenDeCompra.TabStop = True
        Me.rbOrdenDeCompra.Text = "Purchase Order"
        Me.rbOrdenDeCompra.UseVisualStyleBackColor = True
        '
        'rbImportación
        '
        Me.rbImportación.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.rbImportación.AutoSize = True
        Me.rbImportación.Location = New System.Drawing.Point(596, 43)
        Me.rbImportación.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.rbImportación.Name = "rbImportación"
        Me.rbImportación.Size = New System.Drawing.Size(54, 17)
        Me.rbImportación.TabIndex = 52
        Me.rbImportación.TabStop = True
        Me.rbImportación.Text = "Import"
        Me.rbImportación.UseVisualStyleBackColor = True
        '
        'rbLocal
        '
        Me.rbLocal.AccessibleRole = System.Windows.Forms.AccessibleRole.None
        Me.rbLocal.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.rbLocal.AutoSize = True
        Me.rbLocal.Location = New System.Drawing.Point(543, 43)
        Me.rbLocal.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.rbLocal.Name = "rbLocal"
        Me.rbLocal.Size = New System.Drawing.Size(51, 17)
        Me.rbLocal.TabIndex = 51
        Me.rbLocal.TabStop = True
        Me.rbLocal.Text = "Local"
        Me.rbLocal.UseVisualStyleBackColor = True
        '
        'celdaRevisado
        '
        Me.celdaRevisado.Location = New System.Drawing.Point(463, 159)
        Me.celdaRevisado.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.celdaRevisado.Name = "celdaRevisado"
        Me.celdaRevisado.Size = New System.Drawing.Size(38, 20)
        Me.celdaRevisado.TabIndex = 50
        Me.celdaRevisado.Visible = False
        '
        'celdaDetFact
        '
        Me.celdaDetFact.BackColor = System.Drawing.SystemColors.Window
        Me.celdaDetFact.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.celdaDetFact.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.celdaDetFact.ForeColor = System.Drawing.Color.White
        Me.celdaDetFact.Location = New System.Drawing.Point(0, 268)
        Me.celdaDetFact.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.celdaDetFact.Name = "celdaDetFact"
        Me.celdaDetFact.Size = New System.Drawing.Size(904, 23)
        Me.celdaDetFact.TabIndex = 47
        '
        'botonProrrateo
        '
        Me.botonProrrateo.BackColor = System.Drawing.SystemColors.Control
        Me.botonProrrateo.Enabled = False
        Me.botonProrrateo.Location = New System.Drawing.Point(317, 165)
        Me.botonProrrateo.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.botonProrrateo.Name = "botonProrrateo"
        Me.botonProrrateo.Size = New System.Drawing.Size(81, 25)
        Me.botonProrrateo.TabIndex = 46
        Me.botonProrrateo.Text = "Apportion"
        Me.botonProrrateo.TextAlign = System.Drawing.ContentAlignment.TopCenter
        Me.botonProrrateo.UseVisualStyleBackColor = True
        '
        'checkProrrateo
        '
        Me.checkProrrateo.AutoSize = True
        Me.checkProrrateo.Location = New System.Drawing.Point(317, 144)
        Me.checkProrrateo.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.checkProrrateo.Name = "checkProrrateo"
        Me.checkProrrateo.Size = New System.Drawing.Size(71, 17)
        Me.checkProrrateo.TabIndex = 45
        Me.checkProrrateo.Text = "Apportion"
        Me.checkProrrateo.UseVisualStyleBackColor = True
        '
        'botonMoneda
        '
        Me.botonMoneda.Location = New System.Drawing.Point(169, 242)
        Me.botonMoneda.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.botonMoneda.Name = "botonMoneda"
        Me.botonMoneda.Size = New System.Drawing.Size(25, 19)
        Me.botonMoneda.TabIndex = 44
        Me.botonMoneda.Text = "..."
        Me.botonMoneda.UseVisualStyleBackColor = True
        '
        'celdaNumOc
        '
        Me.celdaNumOc.Location = New System.Drawing.Point(293, 32)
        Me.celdaNumOc.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.celdaNumOc.Name = "celdaNumOc"
        Me.celdaNumOc.Size = New System.Drawing.Size(19, 20)
        Me.celdaNumOc.TabIndex = 43
        Me.celdaNumOc.Visible = False
        '
        'celdaAnioOc
        '
        Me.celdaAnioOc.Location = New System.Drawing.Point(266, 32)
        Me.celdaAnioOc.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.celdaAnioOc.Name = "celdaAnioOc"
        Me.celdaAnioOc.Size = New System.Drawing.Size(24, 20)
        Me.celdaAnioOc.TabIndex = 42
        Me.celdaAnioOc.Visible = False
        '
        'celdaCatOc
        '
        Me.celdaCatOc.Location = New System.Drawing.Point(238, 32)
        Me.celdaCatOc.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.celdaCatOc.Name = "celdaCatOc"
        Me.celdaCatOc.Size = New System.Drawing.Size(24, 20)
        Me.celdaCatOc.TabIndex = 41
        Me.celdaCatOc.Visible = False
        '
        'etiquetaNumero
        '
        Me.etiquetaNumero.AutoSize = True
        Me.etiquetaNumero.Location = New System.Drawing.Point(11, 43)
        Me.etiquetaNumero.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.etiquetaNumero.Name = "etiquetaNumero"
        Me.etiquetaNumero.Size = New System.Drawing.Size(44, 13)
        Me.etiquetaNumero.TabIndex = 0
        Me.etiquetaNumero.Text = "Number"
        '
        'celdaRetension
        '
        Me.celdaRetension.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.celdaRetension.BackColor = System.Drawing.SystemColors.Info
        Me.celdaRetension.CausesValidation = False
        Me.celdaRetension.Location = New System.Drawing.Point(543, 236)
        Me.celdaRetension.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.celdaRetension.Name = "celdaRetension"
        Me.celdaRetension.ReadOnly = True
        Me.celdaRetension.Size = New System.Drawing.Size(126, 20)
        Me.celdaRetension.TabIndex = 40
        '
        'celdaNumero
        '
        Me.celdaNumero.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.celdaNumero.Location = New System.Drawing.Point(89, 43)
        Me.celdaNumero.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.celdaNumero.Name = "celdaNumero"
        Me.celdaNumero.Size = New System.Drawing.Size(221, 19)
        Me.celdaNumero.TabIndex = 1
        Me.celdaNumero.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'etiquetaSerie
        '
        Me.etiquetaSerie.AutoSize = True
        Me.etiquetaSerie.Location = New System.Drawing.Point(322, 44)
        Me.etiquetaSerie.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.etiquetaSerie.Name = "etiquetaSerie"
        Me.etiquetaSerie.Size = New System.Drawing.Size(36, 13)
        Me.etiquetaSerie.TabIndex = 2
        Me.etiquetaSerie.Text = "Series"
        '
        'etiquetaCompra
        '
        Me.etiquetaCompra.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.etiquetaCompra.AutoSize = True
        Me.etiquetaCompra.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.etiquetaCompra.Location = New System.Drawing.Point(583, 26)
        Me.etiquetaCompra.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.etiquetaCompra.Name = "etiquetaCompra"
        Me.etiquetaCompra.Size = New System.Drawing.Size(74, 15)
        Me.etiquetaCompra.TabIndex = 38
        Me.etiquetaCompra.Text = "Purchases"
        '
        'celdaSerie
        '
        Me.celdaSerie.Location = New System.Drawing.Point(371, 42)
        Me.celdaSerie.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.celdaSerie.Name = "celdaSerie"
        Me.celdaSerie.Size = New System.Drawing.Size(120, 20)
        Me.celdaSerie.TabIndex = 3
        '
        'celdaNotas
        '
        Me.celdaNotas.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.celdaNotas.Location = New System.Drawing.Point(543, 150)
        Me.celdaNotas.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.celdaNotas.Multiline = True
        Me.celdaNotas.Name = "celdaNotas"
        Me.celdaNotas.Size = New System.Drawing.Size(126, 76)
        Me.celdaNotas.TabIndex = 37
        '
        'etiquetaFecha1
        '
        Me.etiquetaFecha1.AutoSize = True
        Me.etiquetaFecha1.BackColor = System.Drawing.SystemColors.ActiveCaption
        Me.etiquetaFecha1.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.etiquetaFecha1.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.etiquetaFecha1.Location = New System.Drawing.Point(11, 97)
        Me.etiquetaFecha1.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.etiquetaFecha1.Name = "etiquetaFecha1"
        Me.etiquetaFecha1.Size = New System.Drawing.Size(100, 13)
        Me.etiquetaFecha1.TabIndex = 4
        Me.etiquetaFecha1.Text = "Accounting date"
        '
        'etiquetaNotas
        '
        Me.etiquetaNotas.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.etiquetaNotas.AutoSize = True
        Me.etiquetaNotas.Location = New System.Drawing.Point(541, 130)
        Me.etiquetaNotas.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.etiquetaNotas.Name = "etiquetaNotas"
        Me.etiquetaNotas.Size = New System.Drawing.Size(119, 13)
        Me.etiquetaNotas.TabIndex = 36
        Me.etiquetaNotas.Text = "Notes and observations"
        '
        'dtpFecha1
        '
        Me.dtpFecha1.CalendarFont = New System.Drawing.Font("Microsoft Sans Serif", 7.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.dtpFecha1.CalendarForeColor = System.Drawing.SystemColors.Info
        Me.dtpFecha1.CalendarTitleForeColor = System.Drawing.SystemColors.Control
        Me.dtpFecha1.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.dtpFecha1.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.dtpFecha1.Location = New System.Drawing.Point(89, 67)
        Me.dtpFecha1.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.dtpFecha1.Name = "dtpFecha1"
        Me.dtpFecha1.Size = New System.Drawing.Size(91, 19)
        Me.dtpFecha1.TabIndex = 5
        '
        'botonISR
        '
        Me.botonISR.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.botonISR.Image = CType(resources.GetObject("botonISR.Image"), System.Drawing.Image)
        Me.botonISR.ImageAlign = System.Drawing.ContentAlignment.TopCenter
        Me.botonISR.Location = New System.Drawing.Point(382, 26)
        Me.botonISR.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.botonISR.Name = "botonISR"
        Me.botonISR.Size = New System.Drawing.Size(69, 39)
        Me.botonISR.TabIndex = 35
        Me.botonISR.Text = "Reten ISR"
        Me.botonISR.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.botonISR.UseVisualStyleBackColor = True
        '
        'etiquetaVence
        '
        Me.etiquetaVence.AutoSize = True
        Me.etiquetaVence.Location = New System.Drawing.Point(317, 71)
        Me.etiquetaVence.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.etiquetaVence.Name = "etiquetaVence"
        Me.etiquetaVence.Size = New System.Drawing.Size(41, 13)
        Me.etiquetaVence.TabIndex = 6
        Me.etiquetaVence.Text = "Expires"
        '
        'botonPagos
        '
        Me.botonPagos.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.botonPagos.Image = CType(resources.GetObject("botonPagos.Image"), System.Drawing.Image)
        Me.botonPagos.ImageAlign = System.Drawing.ContentAlignment.TopCenter
        Me.botonPagos.Location = New System.Drawing.Point(460, 26)
        Me.botonPagos.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.botonPagos.Name = "botonPagos"
        Me.botonPagos.Size = New System.Drawing.Size(69, 39)
        Me.botonPagos.TabIndex = 34
        Me.botonPagos.Text = "Payments"
        Me.botonPagos.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.botonPagos.UseVisualStyleBackColor = True
        '
        'dtpFechaVence
        '
        Me.dtpFechaVence.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.dtpFechaVence.Location = New System.Drawing.Point(369, 68)
        Me.dtpFechaVence.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.dtpFechaVence.Name = "dtpFechaVence"
        Me.dtpFechaVence.Size = New System.Drawing.Size(90, 20)
        Me.dtpFechaVence.TabIndex = 7
        '
        'checkActivoFijo
        '
        Me.checkActivoFijo.AutoSize = True
        Me.checkActivoFijo.CheckAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.checkActivoFijo.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.checkActivoFijo.ForeColor = System.Drawing.Color.Green
        Me.checkActivoFijo.Location = New System.Drawing.Point(418, 223)
        Me.checkActivoFijo.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.checkActivoFijo.Name = "checkActivoFijo"
        Me.checkActivoFijo.Size = New System.Drawing.Size(91, 17)
        Me.checkActivoFijo.TabIndex = 33
        Me.checkActivoFijo.Text = "Fixed Asset"
        Me.checkActivoFijo.UseVisualStyleBackColor = True
        '
        'etiquetaProveedor
        '
        Me.etiquetaProveedor.AutoSize = True
        Me.etiquetaProveedor.Location = New System.Drawing.Point(11, 120)
        Me.etiquetaProveedor.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.etiquetaProveedor.Name = "etiquetaProveedor"
        Me.etiquetaProveedor.Size = New System.Drawing.Size(46, 13)
        Me.etiquetaProveedor.TabIndex = 8
        Me.etiquetaProveedor.Text = "Provider"
        '
        'checkRevisado
        '
        Me.checkRevisado.AutoSize = True
        Me.checkRevisado.CheckAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.checkRevisado.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.checkRevisado.ForeColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(128, Byte), Integer))
        Me.checkRevisado.Location = New System.Drawing.Point(425, 193)
        Me.checkRevisado.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.checkRevisado.Name = "checkRevisado"
        Me.checkRevisado.Size = New System.Drawing.Size(82, 17)
        Me.checkRevisado.TabIndex = 32
        Me.checkRevisado.Text = "Reviewed"
        Me.checkRevisado.UseVisualStyleBackColor = True
        '
        'celdaProveedor
        '
        Me.celdaProveedor.Location = New System.Drawing.Point(89, 118)
        Me.celdaProveedor.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.celdaProveedor.Name = "celdaProveedor"
        Me.celdaProveedor.Size = New System.Drawing.Size(274, 20)
        Me.celdaProveedor.TabIndex = 9
        '
        'etiquetaMontoTotal
        '
        Me.etiquetaMontoTotal.AutoSize = True
        Me.etiquetaMontoTotal.Location = New System.Drawing.Point(305, 211)
        Me.etiquetaMontoTotal.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.etiquetaMontoTotal.Name = "etiquetaMontoTotal"
        Me.etiquetaMontoTotal.Size = New System.Drawing.Size(13, 13)
        Me.etiquetaMontoTotal.TabIndex = 31
        Me.etiquetaMontoTotal.Text = "0"
        Me.etiquetaMontoTotal.Visible = False
        '
        'botonProveedor
        '
        Me.botonProveedor.Location = New System.Drawing.Point(367, 119)
        Me.botonProveedor.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.botonProveedor.Name = "botonProveedor"
        Me.botonProveedor.Size = New System.Drawing.Size(25, 19)
        Me.botonProveedor.TabIndex = 13
        Me.botonProveedor.Text = "..."
        Me.botonProveedor.UseVisualStyleBackColor = True
        '
        'celdaTasa
        '
        Me.celdaTasa.Location = New System.Drawing.Point(304, 239)
        Me.celdaTasa.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.celdaTasa.Name = "celdaTasa"
        Me.celdaTasa.Size = New System.Drawing.Size(76, 20)
        Me.celdaTasa.TabIndex = 30
        '
        'botonFecha
        '
        Me.botonFecha.Image = CType(resources.GetObject("botonFecha.Image"), System.Drawing.Image)
        Me.botonFecha.Location = New System.Drawing.Point(463, 45)
        Me.botonFecha.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.botonFecha.Name = "botonFecha"
        Me.botonFecha.Size = New System.Drawing.Size(25, 19)
        Me.botonFecha.TabIndex = 14
        Me.botonFecha.UseVisualStyleBackColor = True
        '
        'etiquetaTasa
        '
        Me.etiquetaTasa.AutoSize = True
        Me.etiquetaTasa.Location = New System.Drawing.Point(260, 240)
        Me.etiquetaTasa.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.etiquetaTasa.Name = "etiquetaTasa"
        Me.etiquetaTasa.Size = New System.Drawing.Size(30, 13)
        Me.etiquetaTasa.TabIndex = 29
        Me.etiquetaTasa.Text = "Rate"
        '
        'celdaProveedor1
        '
        Me.celdaProveedor1.Location = New System.Drawing.Point(394, 117)
        Me.celdaProveedor1.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.celdaProveedor1.Name = "celdaProveedor1"
        Me.celdaProveedor1.Size = New System.Drawing.Size(32, 20)
        Me.celdaProveedor1.TabIndex = 15
        Me.celdaProveedor1.Visible = False
        '
        'celdaMoneda1
        '
        Me.celdaMoneda1.Location = New System.Drawing.Point(226, 245)
        Me.celdaMoneda1.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.celdaMoneda1.Name = "celdaMoneda1"
        Me.celdaMoneda1.Size = New System.Drawing.Size(24, 20)
        Me.celdaMoneda1.TabIndex = 28
        Me.celdaMoneda1.Visible = False
        '
        'celdaFechaVence
        '
        Me.celdaFechaVence.Location = New System.Drawing.Point(369, 53)
        Me.celdaFechaVence.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.celdaFechaVence.Name = "celdaFechaVence"
        Me.celdaFechaVence.Size = New System.Drawing.Size(83, 20)
        Me.celdaFechaVence.TabIndex = 16
        Me.celdaFechaVence.Visible = False
        '
        'botonMonedaConvert
        '
        Me.botonMonedaConvert.Image = CType(resources.GetObject("botonMonedaConvert.Image"), System.Drawing.Image)
        Me.botonMonedaConvert.Location = New System.Drawing.Point(198, 239)
        Me.botonMonedaConvert.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.botonMonedaConvert.Name = "botonMonedaConvert"
        Me.botonMonedaConvert.Size = New System.Drawing.Size(24, 26)
        Me.botonMonedaConvert.TabIndex = 27
        Me.botonMonedaConvert.UseVisualStyleBackColor = True
        Me.botonMonedaConvert.Visible = False
        '
        'celdaFecha1
        '
        Me.celdaFecha1.Location = New System.Drawing.Point(216, 97)
        Me.celdaFecha1.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.celdaFecha1.Name = "celdaFecha1"
        Me.celdaFecha1.Size = New System.Drawing.Size(74, 20)
        Me.celdaFecha1.TabIndex = 17
        Me.celdaFecha1.Visible = False
        '
        'celdaMoneda
        '
        Me.celdaMoneda.Location = New System.Drawing.Point(89, 242)
        Me.celdaMoneda.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.celdaMoneda.Name = "celdaMoneda"
        Me.celdaMoneda.Size = New System.Drawing.Size(76, 20)
        Me.celdaMoneda.TabIndex = 26
        '
        'checkContribuyent
        '
        Me.checkContribuyent.AutoSize = True
        Me.checkContribuyent.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.checkContribuyent.ForeColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.checkContribuyent.Location = New System.Drawing.Point(89, 145)
        Me.checkContribuyent.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.checkContribuyent.Name = "checkContribuyent"
        Me.checkContribuyent.Size = New System.Drawing.Size(165, 17)
        Me.checkContribuyent.TabIndex = 18
        Me.checkContribuyent.Text = "Small Taxpayer / Import "
        Me.checkContribuyent.UseVisualStyleBackColor = True
        '
        'etiquetaMoneda
        '
        Me.etiquetaMoneda.AutoSize = True
        Me.etiquetaMoneda.Location = New System.Drawing.Point(11, 245)
        Me.etiquetaMoneda.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.etiquetaMoneda.Name = "etiquetaMoneda"
        Me.etiquetaMoneda.Size = New System.Drawing.Size(28, 13)
        Me.etiquetaMoneda.TabIndex = 25
        Me.etiquetaMoneda.Text = "Coin"
        '
        'checkFacElectrónica
        '
        Me.checkFacElectrónica.AutoSize = True
        Me.checkFacElectrónica.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.checkFacElectrónica.ForeColor = System.Drawing.Color.Navy
        Me.checkFacElectrónica.Location = New System.Drawing.Point(89, 163)
        Me.checkFacElectrónica.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.checkFacElectrónica.Name = "checkFacElectrónica"
        Me.checkFacElectrónica.Size = New System.Drawing.Size(104, 17)
        Me.checkFacElectrónica.TabIndex = 19
        Me.checkFacElectrónica.Text = "Electronic Bill"
        Me.checkFacElectrónica.UseVisualStyleBackColor = True
        '
        'celdaMonto
        '
        Me.celdaMonto.Location = New System.Drawing.Point(89, 218)
        Me.celdaMonto.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.celdaMonto.Name = "celdaMonto"
        Me.celdaMonto.ReadOnly = True
        Me.celdaMonto.Size = New System.Drawing.Size(104, 20)
        Me.celdaMonto.TabIndex = 24
        Me.celdaMonto.Text = "0"
        '
        'etiquetaNIT
        '
        Me.etiquetaNIT.AutoSize = True
        Me.etiquetaNIT.Location = New System.Drawing.Point(11, 198)
        Me.etiquetaNIT.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.etiquetaNIT.Name = "etiquetaNIT"
        Me.etiquetaNIT.Size = New System.Drawing.Size(25, 13)
        Me.etiquetaNIT.TabIndex = 20
        Me.etiquetaNIT.Text = "NIT"
        '
        'etiquetaMonto
        '
        Me.etiquetaMonto.AutoSize = True
        Me.etiquetaMonto.Location = New System.Drawing.Point(11, 220)
        Me.etiquetaMonto.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.etiquetaMonto.Name = "etiquetaMonto"
        Me.etiquetaMonto.Size = New System.Drawing.Size(43, 13)
        Me.etiquetaMonto.TabIndex = 23
        Me.etiquetaMonto.Text = "Amount"
        '
        'celdaNIT
        '
        Me.celdaNIT.Location = New System.Drawing.Point(89, 196)
        Me.celdaNIT.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.celdaNIT.Name = "celdaNIT"
        Me.celdaNIT.ReadOnly = True
        Me.celdaNIT.Size = New System.Drawing.Size(104, 20)
        Me.celdaNIT.TabIndex = 21
        '
        'botonPolizaContable
        '
        Me.botonPolizaContable.Image = CType(resources.GetObject("botonPolizaContable.Image"), System.Drawing.Image)
        Me.botonPolizaContable.Location = New System.Drawing.Point(198, 193)
        Me.botonPolizaContable.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.botonPolizaContable.Name = "botonPolizaContable"
        Me.botonPolizaContable.Size = New System.Drawing.Size(26, 25)
        Me.botonPolizaContable.TabIndex = 22
        Me.botonPolizaContable.UseVisualStyleBackColor = True
        '
        'etiquetaInvoice
        '
        Me.etiquetaInvoice.AutoSize = True
        Me.etiquetaInvoice.Location = New System.Drawing.Point(314, 44)
        Me.etiquetaInvoice.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.etiquetaInvoice.Name = "etiquetaInvoice"
        Me.etiquetaInvoice.Size = New System.Drawing.Size(57, 13)
        Me.etiquetaInvoice.TabIndex = 69
        Me.etiquetaInvoice.Text = "Reference"
        '
        'dgFacturas
        '
        Me.dgFacturas.AllowUserToAddRows = False
        Me.dgFacturas.AllowUserToDeleteRows = False
        Me.dgFacturas.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.dgFacturas.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells
        Me.dgFacturas.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells
        Me.dgFacturas.BackgroundColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle4.BackColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle4.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle4.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle4.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle4.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle4.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.dgFacturas.ColumnHeadersDefaultCellStyle = DataGridViewCellStyle4
        Me.dgFacturas.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgFacturas.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.colCat, Me.colAnio, Me.colNumber, Me.colLineaFactura, Me.colLineaOrden, Me.colCantidad, Me.colDescripcion, Me.colPrecioSinIVA, Me.colPrecio, Me.colTotal, Me.colCodigo, Me.colCuentaActivo, Me.colActivo, Me.colidCuentaIVA, Me.colCuenta, Me.colGasto, Me.colCosto, Me.colCentro, Me.colClasificacion, Me.colAgregar, Me.colCtaIVA, Me.colCodigoP, Me.col_idCuenta, Me.col_NomCuentafectar, Me.col_idRubro, Me.col_Rubro, Me.loteNum})
        DataGridViewCellStyle5.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle5.BackColor = System.Drawing.SystemColors.Window
        DataGridViewCellStyle5.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle5.ForeColor = System.Drawing.SystemColors.ControlText
        DataGridViewCellStyle5.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle5.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle5.WrapMode = System.Windows.Forms.DataGridViewTriState.[False]
        Me.dgFacturas.DefaultCellStyle = DataGridViewCellStyle5
        Me.dgFacturas.Location = New System.Drawing.Point(2, 291)
        Me.dgFacturas.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.dgFacturas.Name = "dgFacturas"
        DataGridViewCellStyle6.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle6.BackColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle6.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle6.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle6.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle6.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle6.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.dgFacturas.RowHeadersDefaultCellStyle = DataGridViewCellStyle6
        Me.dgFacturas.RowTemplate.Height = 24
        Me.dgFacturas.Size = New System.Drawing.Size(850, 42)
        Me.dgFacturas.TabIndex = 45
        '
        'colCat
        '
        Me.colCat.HeaderText = "Catalogo"
        Me.colCat.Name = "colCat"
        Me.colCat.ReadOnly = True
        Me.colCat.Visible = False
        Me.colCat.Width = 74
        '
        'colAnio
        '
        Me.colAnio.HeaderText = "Anio"
        Me.colAnio.Name = "colAnio"
        Me.colAnio.ReadOnly = True
        Me.colAnio.Visible = False
        Me.colAnio.Width = 53
        '
        'colNumber
        '
        Me.colNumber.HeaderText = "Numero"
        Me.colNumber.Name = "colNumber"
        Me.colNumber.ReadOnly = True
        Me.colNumber.Visible = False
        Me.colNumber.Width = 69
        '
        'colLineaFactura
        '
        Me.colLineaFactura.HeaderText = "LineaFactura"
        Me.colLineaFactura.Name = "colLineaFactura"
        Me.colLineaFactura.ReadOnly = True
        Me.colLineaFactura.Visible = False
        Me.colLineaFactura.Width = 94
        '
        'colLineaOrden
        '
        Me.colLineaOrden.HeaderText = "LineaOrden"
        Me.colLineaOrden.Name = "colLineaOrden"
        Me.colLineaOrden.ReadOnly = True
        Me.colLineaOrden.Visible = False
        Me.colLineaOrden.Width = 87
        '
        'colCantidad
        '
        Me.colCantidad.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.colCantidad.HeaderText = "Quantity"
        Me.colCantidad.Name = "colCantidad"
        Me.colCantidad.Width = 71
        '
        'colDescripcion
        '
        Me.colDescripcion.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill
        Me.colDescripcion.HeaderText = "Description"
        Me.colDescripcion.Name = "colDescripcion"
        '
        'colPrecioSinIVA
        '
        Me.colPrecioSinIVA.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.colPrecioSinIVA.HeaderText = "Price without VAT"
        Me.colPrecioSinIVA.Name = "colPrecioSinIVA"
        Me.colPrecioSinIVA.Width = 107
        '
        'colPrecio
        '
        Me.colPrecio.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.colPrecio.HeaderText = "Price"
        Me.colPrecio.Name = "colPrecio"
        Me.colPrecio.Width = 56
        '
        'colTotal
        '
        Me.colTotal.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.colTotal.HeaderText = "Total"
        Me.colTotal.Name = "colTotal"
        Me.colTotal.ReadOnly = True
        Me.colTotal.Width = 56
        '
        'colCodigo
        '
        Me.colCodigo.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.colCodigo.HeaderText = "Codigo"
        Me.colCodigo.Name = "colCodigo"
        Me.colCodigo.ReadOnly = True
        Me.colCodigo.Width = 65
        '
        'colCuentaActivo
        '
        Me.colCuentaActivo.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.colCuentaActivo.HeaderText = "Cuenta(Activo)"
        Me.colCuentaActivo.Name = "colCuentaActivo"
        Me.colCuentaActivo.ReadOnly = True
        Me.colCuentaActivo.Width = 102
        '
        'colActivo
        '
        Me.colActivo.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.colActivo.HeaderText = "Fixed Assets"
        Me.colActivo.Name = "colActivo"
        Me.colActivo.ReadOnly = True
        Me.colActivo.Visible = False
        '
        'colidCuentaIVA
        '
        Me.colidCuentaIVA.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.colidCuentaIVA.HeaderText = "Account VAT"
        Me.colidCuentaIVA.Name = "colidCuentaIVA"
        Me.colidCuentaIVA.ReadOnly = True
        Me.colidCuentaIVA.Width = 88
        '
        'colCuenta
        '
        Me.colCuenta.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.colCuenta.HeaderText = "Nomenclatura(Gst)"
        Me.colCuenta.Name = "colCuenta"
        Me.colCuenta.ReadOnly = True
        Me.colCuenta.Width = 120
        '
        'colGasto
        '
        Me.colGasto.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.colGasto.HeaderText = "Expense"
        Me.colGasto.Name = "colGasto"
        Me.colGasto.ReadOnly = True
        Me.colGasto.Width = 73
        '
        'colCosto
        '
        Me.colCosto.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.colCosto.HeaderText = "Cost"
        Me.colCosto.Name = "colCosto"
        Me.colCosto.ReadOnly = True
        Me.colCosto.Visible = False
        '
        'colCentro
        '
        Me.colCentro.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.colCentro.HeaderText = "Cost Center"
        Me.colCentro.Name = "colCentro"
        Me.colCentro.ReadOnly = True
        Me.colCentro.Width = 80
        '
        'colClasificacion
        '
        Me.colClasificacion.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.colClasificacion.HeaderText = "Clasification"
        Me.colClasificacion.Name = "colClasificacion"
        Me.colClasificacion.ReadOnly = True
        Me.colClasificacion.Width = 88
        '
        'colAgregar
        '
        Me.colAgregar.HeaderText = "Agregar"
        Me.colAgregar.Name = "colAgregar"
        Me.colAgregar.ReadOnly = True
        Me.colAgregar.Visible = False
        Me.colAgregar.Width = 69
        '
        'colCtaIVA
        '
        Me.colCtaIVA.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.colCtaIVA.HeaderText = "Nombre IVA"
        Me.colCtaIVA.Name = "colCtaIVA"
        Me.colCtaIVA.ReadOnly = True
        Me.colCtaIVA.Visible = False
        '
        'colCodigoP
        '
        Me.colCodigoP.HeaderText = "Codigo P"
        Me.colCodigoP.Name = "colCodigoP"
        Me.colCodigoP.Visible = False
        Me.colCodigoP.Width = 69
        '
        'col_idCuenta
        '
        Me.col_idCuenta.HeaderText = "idCuenta"
        Me.col_idCuenta.Name = "col_idCuenta"
        Me.col_idCuenta.Visible = False
        Me.col_idCuenta.Width = 74
        '
        'col_NomCuentafectar
        '
        Me.col_NomCuentafectar.HeaderText = "Account to Affect"
        Me.col_NomCuentafectar.Name = "col_NomCuentafectar"
        Me.col_NomCuentafectar.Width = 80
        '
        'col_idRubro
        '
        Me.col_idRubro.HeaderText = "idRubro"
        Me.col_idRubro.Name = "col_idRubro"
        Me.col_idRubro.Visible = False
        Me.col_idRubro.Width = 69
        '
        'col_Rubro
        '
        Me.col_Rubro.HeaderText = "Item"
        Me.col_Rubro.Name = "col_Rubro"
        Me.col_Rubro.Width = 52
        '
        'loteNum
        '
        Me.loteNum.HeaderText = "Lote"
        Me.loteNum.Name = "loteNum"
        Me.loteNum.Width = 53
        '
        'panelBtnDetalle
        '
        Me.panelBtnDetalle.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.panelBtnDetalle.Controls.Add(Me.botonMenos)
        Me.panelBtnDetalle.Controls.Add(Me.botonMas)
        Me.panelBtnDetalle.Location = New System.Drawing.Point(856, 291)
        Me.panelBtnDetalle.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.panelBtnDetalle.Name = "panelBtnDetalle"
        Me.panelBtnDetalle.Size = New System.Drawing.Size(45, 71)
        Me.panelBtnDetalle.TabIndex = 44
        '
        'botonMenos
        '
        Me.botonMenos.Image = CType(resources.GetObject("botonMenos.Image"), System.Drawing.Image)
        Me.botonMenos.Location = New System.Drawing.Point(8, 46)
        Me.botonMenos.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.botonMenos.Name = "botonMenos"
        Me.botonMenos.Size = New System.Drawing.Size(26, 25)
        Me.botonMenos.TabIndex = 44
        Me.botonMenos.UseVisualStyleBackColor = True
        '
        'botonMas
        '
        Me.botonMas.Image = CType(resources.GetObject("botonMas.Image"), System.Drawing.Image)
        Me.botonMas.Location = New System.Drawing.Point(8, 5)
        Me.botonMas.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.botonMas.Name = "botonMas"
        Me.botonMas.Size = New System.Drawing.Size(26, 25)
        Me.botonMas.TabIndex = 3
        Me.botonMas.UseVisualStyleBackColor = True
        '
        'panelDesglose
        '
        Me.panelDesglose.Controls.Add(Me.gbPoliza)
        Me.panelDesglose.Controls.Add(Me.gbImpuestos)
        Me.panelDesglose.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.panelDesglose.Location = New System.Drawing.Point(0, 337)
        Me.panelDesglose.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.panelDesglose.Name = "panelDesglose"
        Me.panelDesglose.Size = New System.Drawing.Size(904, 137)
        Me.panelDesglose.TabIndex = 43
        '
        'gbPoliza
        '
        Me.gbPoliza.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.gbPoliza.Controls.Add(Me.dgOrdenes)
        Me.gbPoliza.Controls.Add(Me.botonDesligar)
        Me.gbPoliza.Controls.Add(Me.dgPoliza)
        Me.gbPoliza.Controls.Add(Me.botonRelacionar)
        Me.gbPoliza.Location = New System.Drawing.Point(715, 2)
        Me.gbPoliza.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.gbPoliza.Name = "gbPoliza"
        Me.gbPoliza.Padding = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.gbPoliza.Size = New System.Drawing.Size(190, 129)
        Me.gbPoliza.TabIndex = 1
        Me.gbPoliza.TabStop = False
        Me.gbPoliza.Text = "Import Policy"
        '
        'dgOrdenes
        '
        Me.dgOrdenes.AllowUserToAddRows = False
        Me.dgOrdenes.AllowUserToDeleteRows = False
        Me.dgOrdenes.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.dgOrdenes.BackgroundColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle7.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle7.BackColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle7.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle7.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle7.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle7.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle7.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.dgOrdenes.ColumnHeadersDefaultCellStyle = DataGridViewCellStyle7
        Me.dgOrdenes.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgOrdenes.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.colCatalogo, Me.colAñio, Me.colNumero, Me.colDate, Me.colLineOrden, Me.colReference})
        DataGridViewCellStyle8.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle8.BackColor = System.Drawing.SystemColors.Window
        DataGridViewCellStyle8.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle8.ForeColor = System.Drawing.SystemColors.ControlText
        DataGridViewCellStyle8.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle8.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle8.WrapMode = System.Windows.Forms.DataGridViewTriState.[False]
        Me.dgOrdenes.DefaultCellStyle = DataGridViewCellStyle8
        Me.dgOrdenes.Location = New System.Drawing.Point(2, 42)
        Me.dgOrdenes.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.dgOrdenes.Name = "dgOrdenes"
        DataGridViewCellStyle9.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle9.BackColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle9.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle9.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle9.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle9.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle9.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.dgOrdenes.RowHeadersDefaultCellStyle = DataGridViewCellStyle9
        Me.dgOrdenes.RowTemplate.Height = 24
        Me.dgOrdenes.Size = New System.Drawing.Size(157, 82)
        Me.dgOrdenes.TabIndex = 5
        Me.dgOrdenes.Visible = False
        '
        'colCatalogo
        '
        Me.colCatalogo.HeaderText = "Catalogue"
        Me.colCatalogo.Name = "colCatalogo"
        Me.colCatalogo.Visible = False
        '
        'colAñio
        '
        Me.colAñio.HeaderText = "Year"
        Me.colAñio.Name = "colAñio"
        Me.colAñio.Visible = False
        '
        'colNumero
        '
        Me.colNumero.HeaderText = "Orden Number"
        Me.colNumero.Name = "colNumero"
        '
        'colDate
        '
        Me.colDate.HeaderText = "Date"
        Me.colDate.Name = "colDate"
        '
        'colLineOrden
        '
        Me.colLineOrden.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.colLineOrden.HeaderText = "Line"
        Me.colLineOrden.Name = "colLineOrden"
        Me.colLineOrden.Width = 52
        '
        'colReference
        '
        Me.colReference.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill
        Me.colReference.HeaderText = "Orden Name"
        Me.colReference.Name = "colReference"
        '
        'botonDesligar
        '
        Me.botonDesligar.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.botonDesligar.Image = CType(resources.GetObject("botonDesligar.Image"), System.Drawing.Image)
        Me.botonDesligar.Location = New System.Drawing.Point(146, 7)
        Me.botonDesligar.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.botonDesligar.Name = "botonDesligar"
        Me.botonDesligar.Size = New System.Drawing.Size(26, 25)
        Me.botonDesligar.TabIndex = 4
        Me.botonDesligar.UseVisualStyleBackColor = True
        '
        'dgPoliza
        '
        Me.dgPoliza.AllowUserToAddRows = False
        Me.dgPoliza.AllowUserToDeleteRows = False
        Me.dgPoliza.AllowUserToOrderColumns = True
        Me.dgPoliza.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.dgPoliza.BackgroundColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle10.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle10.BackColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle10.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle10.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle10.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle10.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle10.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.dgPoliza.ColumnHeadersDefaultCellStyle = DataGridViewCellStyle10
        Me.dgPoliza.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgPoliza.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.colTipo1, Me.colAño, Me.colNum, Me.colPoliza, Me.colLinea, Me.colCantida, Me.colPrice, Me.colMonto1, Me.colFechaIngreso, Me.TC_Poliza})
        DataGridViewCellStyle11.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle11.BackColor = System.Drawing.SystemColors.Window
        DataGridViewCellStyle11.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle11.ForeColor = System.Drawing.SystemColors.ControlText
        DataGridViewCellStyle11.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle11.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle11.WrapMode = System.Windows.Forms.DataGridViewTriState.[False]
        Me.dgPoliza.DefaultCellStyle = DataGridViewCellStyle11
        Me.dgPoliza.Location = New System.Drawing.Point(2, 32)
        Me.dgPoliza.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.dgPoliza.MultiSelect = False
        Me.dgPoliza.Name = "dgPoliza"
        Me.dgPoliza.ReadOnly = True
        DataGridViewCellStyle12.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle12.BackColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle12.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle12.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle12.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle12.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle12.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.dgPoliza.RowHeadersDefaultCellStyle = DataGridViewCellStyle12
        Me.dgPoliza.RowTemplate.Height = 24
        Me.dgPoliza.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.dgPoliza.Size = New System.Drawing.Size(170, 94)
        Me.dgPoliza.TabIndex = 0
        '
        'colTipo1
        '
        Me.colTipo1.HeaderText = "Tipo"
        Me.colTipo1.Name = "colTipo1"
        Me.colTipo1.ReadOnly = True
        Me.colTipo1.Visible = False
        '
        'colAño
        '
        Me.colAño.HeaderText = "Año"
        Me.colAño.Name = "colAño"
        Me.colAño.ReadOnly = True
        Me.colAño.Visible = False
        '
        'colNum
        '
        Me.colNum.HeaderText = "No."
        Me.colNum.Name = "colNum"
        Me.colNum.ReadOnly = True
        '
        'colPoliza
        '
        Me.colPoliza.HeaderText = "Policy"
        Me.colPoliza.Name = "colPoliza"
        Me.colPoliza.ReadOnly = True
        '
        'colLinea
        '
        Me.colLinea.HeaderText = "Line"
        Me.colLinea.Name = "colLinea"
        Me.colLinea.ReadOnly = True
        '
        'colCantida
        '
        Me.colCantida.HeaderText = "Quantity"
        Me.colCantida.Name = "colCantida"
        Me.colCantida.ReadOnly = True
        '
        'colPrice
        '
        Me.colPrice.HeaderText = "Price"
        Me.colPrice.Name = "colPrice"
        Me.colPrice.ReadOnly = True
        Me.colPrice.Visible = False
        '
        'colMonto1
        '
        Me.colMonto1.HeaderText = "Amount"
        Me.colMonto1.Name = "colMonto1"
        Me.colMonto1.ReadOnly = True
        '
        'colFechaIngreso
        '
        Me.colFechaIngreso.HeaderText = "FechaIngreso"
        Me.colFechaIngreso.Name = "colFechaIngreso"
        Me.colFechaIngreso.ReadOnly = True
        Me.colFechaIngreso.Visible = False
        '
        'TC_Poliza
        '
        Me.TC_Poliza.HeaderText = "TC_Poliza"
        Me.TC_Poliza.Name = "TC_Poliza"
        Me.TC_Poliza.ReadOnly = True
        Me.TC_Poliza.Visible = False
        '
        'botonRelacionar
        '
        Me.botonRelacionar.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.botonRelacionar.Image = CType(resources.GetObject("botonRelacionar.Image"), System.Drawing.Image)
        Me.botonRelacionar.Location = New System.Drawing.Point(112, 7)
        Me.botonRelacionar.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.botonRelacionar.Name = "botonRelacionar"
        Me.botonRelacionar.Size = New System.Drawing.Size(26, 25)
        Me.botonRelacionar.TabIndex = 3
        Me.botonRelacionar.UseVisualStyleBackColor = True
        '
        'gbImpuestos
        '
        Me.gbImpuestos.Controls.Add(Me.panelBotones)
        Me.gbImpuestos.Controls.Add(Me.dgImpuestos)
        Me.gbImpuestos.Location = New System.Drawing.Point(2, 2)
        Me.gbImpuestos.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.gbImpuestos.Name = "gbImpuestos"
        Me.gbImpuestos.Padding = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.gbImpuestos.Size = New System.Drawing.Size(708, 129)
        Me.gbImpuestos.TabIndex = 0
        Me.gbImpuestos.TabStop = False
        Me.gbImpuestos.Text = "Tax Breakdown"
        '
        'panelBotones
        '
        Me.panelBotones.Controls.Add(Me.botonEliminar)
        Me.panelBotones.Controls.Add(Me.botonOtrosImp)
        Me.panelBotones.Controls.Add(Me.botnEditar)
        Me.panelBotones.Dock = System.Windows.Forms.DockStyle.Right
        Me.panelBotones.Location = New System.Drawing.Point(666, 15)
        Me.panelBotones.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.panelBotones.Name = "panelBotones"
        Me.panelBotones.Size = New System.Drawing.Size(40, 112)
        Me.panelBotones.TabIndex = 1
        '
        'botonEliminar
        '
        Me.botonEliminar.Image = CType(resources.GetObject("botonEliminar.Image"), System.Drawing.Image)
        Me.botonEliminar.Location = New System.Drawing.Point(8, 80)
        Me.botonEliminar.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.botonEliminar.Name = "botonEliminar"
        Me.botonEliminar.Size = New System.Drawing.Size(26, 25)
        Me.botonEliminar.TabIndex = 2
        Me.botonEliminar.UseVisualStyleBackColor = True
        '
        'botonOtrosImp
        '
        Me.botonOtrosImp.Image = CType(resources.GetObject("botonOtrosImp.Image"), System.Drawing.Image)
        Me.botonOtrosImp.Location = New System.Drawing.Point(8, 45)
        Me.botonOtrosImp.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.botonOtrosImp.Name = "botonOtrosImp"
        Me.botonOtrosImp.Size = New System.Drawing.Size(26, 25)
        Me.botonOtrosImp.TabIndex = 1
        Me.botonOtrosImp.UseVisualStyleBackColor = True
        '
        'botnEditar
        '
        Me.botnEditar.Image = CType(resources.GetObject("botnEditar.Image"), System.Drawing.Image)
        Me.botnEditar.Location = New System.Drawing.Point(8, 9)
        Me.botnEditar.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.botnEditar.Name = "botnEditar"
        Me.botnEditar.Size = New System.Drawing.Size(26, 25)
        Me.botnEditar.TabIndex = 0
        Me.botnEditar.UseVisualStyleBackColor = True
        '
        'dgImpuestos
        '
        Me.dgImpuestos.AllowUserToAddRows = False
        Me.dgImpuestos.AllowUserToDeleteRows = False
        Me.dgImpuestos.AllowUserToOrderColumns = True
        Me.dgImpuestos.BackgroundColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle13.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle13.BackColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle13.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle13.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle13.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle13.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle13.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.dgImpuestos.ColumnHeadersDefaultCellStyle = DataGridViewCellStyle13
        Me.dgImpuestos.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgImpuestos.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.colLine, Me.colID, Me.colCodigo1, Me.colTipo, Me.colDescripcion1, Me.colCantidad1, Me.colFactor, Me.colBase, Me.colMonto, Me.colTag, Me.colOrigen})
        DataGridViewCellStyle14.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle14.BackColor = System.Drawing.SystemColors.Window
        DataGridViewCellStyle14.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle14.ForeColor = System.Drawing.SystemColors.ControlText
        DataGridViewCellStyle14.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle14.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle14.WrapMode = System.Windows.Forms.DataGridViewTriState.[False]
        Me.dgImpuestos.DefaultCellStyle = DataGridViewCellStyle14
        Me.dgImpuestos.Location = New System.Drawing.Point(2, 15)
        Me.dgImpuestos.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.dgImpuestos.MultiSelect = False
        Me.dgImpuestos.Name = "dgImpuestos"
        Me.dgImpuestos.ReadOnly = True
        DataGridViewCellStyle15.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle15.BackColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle15.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle15.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle15.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle15.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle15.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.dgImpuestos.RowHeadersDefaultCellStyle = DataGridViewCellStyle15
        Me.dgImpuestos.RowTemplate.Height = 24
        Me.dgImpuestos.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.dgImpuestos.Size = New System.Drawing.Size(659, 112)
        Me.dgImpuestos.TabIndex = 0
        '
        'colLine
        '
        Me.colLine.HeaderText = "Order"
        Me.colLine.Name = "colLine"
        Me.colLine.ReadOnly = True
        '
        'colID
        '
        Me.colID.HeaderText = "ID"
        Me.colID.Name = "colID"
        Me.colID.ReadOnly = True
        Me.colID.Visible = False
        '
        'colCodigo1
        '
        Me.colCodigo1.HeaderText = "Code"
        Me.colCodigo1.Name = "colCodigo1"
        Me.colCodigo1.ReadOnly = True
        Me.colCodigo1.Visible = False
        '
        'colTipo
        '
        Me.colTipo.HeaderText = "Kind"
        Me.colTipo.Name = "colTipo"
        Me.colTipo.ReadOnly = True
        Me.colTipo.Visible = False
        '
        'colDescripcion1
        '
        Me.colDescripcion1.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill
        Me.colDescripcion1.HeaderText = "Description"
        Me.colDescripcion1.Name = "colDescripcion1"
        Me.colDescripcion1.ReadOnly = True
        '
        'colCantidad1
        '
        Me.colCantidad1.HeaderText = "Quantity"
        Me.colCantidad1.Name = "colCantidad1"
        Me.colCantidad1.ReadOnly = True
        '
        'colFactor
        '
        Me.colFactor.HeaderText = "Factor"
        Me.colFactor.Name = "colFactor"
        Me.colFactor.ReadOnly = True
        '
        'colBase
        '
        Me.colBase.HeaderText = "Base"
        Me.colBase.Name = "colBase"
        Me.colBase.ReadOnly = True
        '
        'colMonto
        '
        Me.colMonto.HeaderText = "Tax"
        Me.colMonto.Name = "colMonto"
        Me.colMonto.ReadOnly = True
        '
        'colTag
        '
        Me.colTag.HeaderText = "Tag"
        Me.colTag.Name = "colTag"
        Me.colTag.ReadOnly = True
        Me.colTag.Visible = False
        '
        'colOrigen
        '
        Me.colOrigen.HeaderText = "Origin"
        Me.colOrigen.Name = "colOrigen"
        Me.colOrigen.ReadOnly = True
        Me.colOrigen.Visible = False
        '
        'panelDetalle
        '
        Me.panelDetalle.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.panelDetalle.Controls.Add(Me.DataGridView1)
        Me.panelDetalle.Controls.Add(Me.dgPagos)
        Me.panelDetalle.Location = New System.Drawing.Point(991, 540)
        Me.panelDetalle.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.panelDetalle.Name = "panelDetalle"
        Me.panelDetalle.Size = New System.Drawing.Size(377, 237)
        Me.panelDetalle.TabIndex = 4
        '
        'DataGridView1
        '
        DataGridViewCellStyle16.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle16.BackColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle16.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle16.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle16.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle16.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle16.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.DataGridView1.ColumnHeadersDefaultCellStyle = DataGridViewCellStyle16
        Me.DataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        DataGridViewCellStyle17.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle17.BackColor = System.Drawing.SystemColors.Window
        DataGridViewCellStyle17.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle17.ForeColor = System.Drawing.SystemColors.ControlText
        DataGridViewCellStyle17.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle17.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle17.WrapMode = System.Windows.Forms.DataGridViewTriState.[False]
        Me.DataGridView1.DefaultCellStyle = DataGridViewCellStyle17
        Me.DataGridView1.Location = New System.Drawing.Point(11, 417)
        Me.DataGridView1.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.DataGridView1.Name = "DataGridView1"
        DataGridViewCellStyle18.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle18.BackColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle18.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle18.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle18.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle18.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle18.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.DataGridView1.RowHeadersDefaultCellStyle = DataGridViewCellStyle18
        Me.DataGridView1.RowTemplate.Height = 24
        Me.DataGridView1.Size = New System.Drawing.Size(180, 122)
        Me.DataGridView1.TabIndex = 1
        '
        'dgPagos
        '
        Me.dgPagos.AllowUserToAddRows = False
        Me.dgPagos.AllowUserToDeleteRows = False
        Me.dgPagos.AllowUserToOrderColumns = True
        Me.dgPagos.BackgroundColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle19.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle19.BackColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle19.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle19.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle19.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle19.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle19.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.dgPagos.ColumnHeadersDefaultCellStyle = DataGridViewCellStyle19
        Me.dgPagos.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgPagos.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.colTipo2, Me.colAño2, Me.colNumero2, Me.colMoneda2, Me.colTasa, Me.colCargoEx, Me.colAbonoEx, Me.colFecha2, Me.colDocumento, Me.colReferencia, Me.colConcepto, Me.colCargo, Me.colAbono, Me.colSaldo2})
        DataGridViewCellStyle20.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle20.BackColor = System.Drawing.SystemColors.Window
        DataGridViewCellStyle20.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle20.ForeColor = System.Drawing.SystemColors.ControlText
        DataGridViewCellStyle20.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle20.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle20.WrapMode = System.Windows.Forms.DataGridViewTriState.[False]
        Me.dgPagos.DefaultCellStyle = DataGridViewCellStyle20
        Me.dgPagos.Dock = System.Windows.Forms.DockStyle.Top
        Me.dgPagos.Location = New System.Drawing.Point(0, 0)
        Me.dgPagos.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.dgPagos.MultiSelect = False
        Me.dgPagos.Name = "dgPagos"
        Me.dgPagos.ReadOnly = True
        DataGridViewCellStyle21.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle21.BackColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle21.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle21.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle21.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle21.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle21.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.dgPagos.RowHeadersDefaultCellStyle = DataGridViewCellStyle21
        Me.dgPagos.RowTemplate.Height = 24
        Me.dgPagos.Size = New System.Drawing.Size(377, 158)
        Me.dgPagos.TabIndex = 0
        '
        'colTipo2
        '
        Me.colTipo2.HeaderText = "Tipo"
        Me.colTipo2.Name = "colTipo2"
        Me.colTipo2.ReadOnly = True
        Me.colTipo2.Visible = False
        '
        'colAño2
        '
        Me.colAño2.HeaderText = "Año"
        Me.colAño2.Name = "colAño2"
        Me.colAño2.ReadOnly = True
        Me.colAño2.Visible = False
        '
        'colNumero2
        '
        Me.colNumero2.HeaderText = "Numero"
        Me.colNumero2.Name = "colNumero2"
        Me.colNumero2.ReadOnly = True
        Me.colNumero2.Visible = False
        '
        'colMoneda2
        '
        Me.colMoneda2.HeaderText = "Moneda"
        Me.colMoneda2.Name = "colMoneda2"
        Me.colMoneda2.ReadOnly = True
        Me.colMoneda2.Visible = False
        '
        'colTasa
        '
        Me.colTasa.HeaderText = "Tasa"
        Me.colTasa.Name = "colTasa"
        Me.colTasa.ReadOnly = True
        Me.colTasa.Visible = False
        '
        'colCargoEx
        '
        Me.colCargoEx.HeaderText = "Cargo Ex"
        Me.colCargoEx.Name = "colCargoEx"
        Me.colCargoEx.ReadOnly = True
        Me.colCargoEx.Visible = False
        '
        'colAbonoEx
        '
        Me.colAbonoEx.HeaderText = "Abono Ex"
        Me.colAbonoEx.Name = "colAbonoEx"
        Me.colAbonoEx.ReadOnly = True
        Me.colAbonoEx.Visible = False
        '
        'colFecha2
        '
        Me.colFecha2.HeaderText = "Date"
        Me.colFecha2.Name = "colFecha2"
        Me.colFecha2.ReadOnly = True
        '
        'colDocumento
        '
        Me.colDocumento.HeaderText = "Document"
        Me.colDocumento.Name = "colDocumento"
        Me.colDocumento.ReadOnly = True
        '
        'colReferencia
        '
        Me.colReferencia.HeaderText = "Reference"
        Me.colReferencia.Name = "colReferencia"
        Me.colReferencia.ReadOnly = True
        '
        'colConcepto
        '
        Me.colConcepto.HeaderText = "Concept"
        Me.colConcepto.Name = "colConcepto"
        Me.colConcepto.ReadOnly = True
        '
        'colCargo
        '
        Me.colCargo.HeaderText = "Charge"
        Me.colCargo.Name = "colCargo"
        Me.colCargo.ReadOnly = True
        '
        'colAbono
        '
        Me.colAbono.HeaderText = "Payment"
        Me.colAbono.Name = "colAbono"
        Me.colAbono.ReadOnly = True
        '
        'colSaldo2
        '
        Me.colSaldo2.HeaderText = "Balance"
        Me.colSaldo2.Name = "colSaldo2"
        Me.colSaldo2.ReadOnly = True
        '
        'panelProrrateo
        '
        Me.panelProrrateo.Controls.Add(Me.paneBotones)
        Me.panelProrrateo.Controls.Add(Me.dgProrrateo)
        Me.panelProrrateo.Location = New System.Drawing.Point(1011, 188)
        Me.panelProrrateo.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.panelProrrateo.Name = "panelProrrateo"
        Me.panelProrrateo.Size = New System.Drawing.Size(300, 344)
        Me.panelProrrateo.TabIndex = 5
        '
        'paneBotones
        '
        Me.paneBotones.Controls.Add(Me.botonSeleccionar)
        Me.paneBotones.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.paneBotones.Location = New System.Drawing.Point(0, 217)
        Me.paneBotones.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.paneBotones.Name = "paneBotones"
        Me.paneBotones.Size = New System.Drawing.Size(300, 127)
        Me.paneBotones.TabIndex = 1
        '
        'botonSeleccionar
        '
        Me.botonSeleccionar.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.botonSeleccionar.Image = CType(resources.GetObject("botonSeleccionar.Image"), System.Drawing.Image)
        Me.botonSeleccionar.ImageAlign = System.Drawing.ContentAlignment.TopCenter
        Me.botonSeleccionar.Location = New System.Drawing.Point(188, 0)
        Me.botonSeleccionar.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.botonSeleccionar.Name = "botonSeleccionar"
        Me.botonSeleccionar.Size = New System.Drawing.Size(68, 46)
        Me.botonSeleccionar.TabIndex = 0
        Me.botonSeleccionar.Text = "Select"
        Me.botonSeleccionar.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.botonSeleccionar.UseVisualStyleBackColor = True
        '
        'dgProrrateo
        '
        Me.dgProrrateo.AllowUserToAddRows = False
        Me.dgProrrateo.AllowUserToDeleteRows = False
        Me.dgProrrateo.AllowUserToOrderColumns = True
        Me.dgProrrateo.BackgroundColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle22.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle22.BackColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle22.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle22.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle22.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle22.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle22.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.dgProrrateo.ColumnHeadersDefaultCellStyle = DataGridViewCellStyle22
        Me.dgProrrateo.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgProrrateo.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.colIDP, Me.colCCostosP, Me.colCheckP})
        DataGridViewCellStyle24.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle24.BackColor = System.Drawing.SystemColors.Window
        DataGridViewCellStyle24.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle24.ForeColor = System.Drawing.SystemColors.ControlText
        DataGridViewCellStyle24.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle24.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle24.WrapMode = System.Windows.Forms.DataGridViewTriState.[False]
        Me.dgProrrateo.DefaultCellStyle = DataGridViewCellStyle24
        Me.dgProrrateo.Dock = System.Windows.Forms.DockStyle.Top
        Me.dgProrrateo.Location = New System.Drawing.Point(0, 0)
        Me.dgProrrateo.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.dgProrrateo.MultiSelect = False
        Me.dgProrrateo.Name = "dgProrrateo"
        Me.dgProrrateo.ReadOnly = True
        DataGridViewCellStyle25.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle25.BackColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle25.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle25.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle25.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle25.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle25.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.dgProrrateo.RowHeadersDefaultCellStyle = DataGridViewCellStyle25
        Me.dgProrrateo.RowTemplate.Height = 24
        Me.dgProrrateo.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.dgProrrateo.Size = New System.Drawing.Size(300, 412)
        Me.dgProrrateo.TabIndex = 0
        '
        'colIDP
        '
        Me.colIDP.HeaderText = "ID"
        Me.colIDP.Name = "colIDP"
        Me.colIDP.ReadOnly = True
        '
        'colCCostosP
        '
        Me.colCCostosP.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill
        Me.colCCostosP.HeaderText = "Description"
        Me.colCCostosP.Name = "colCCostosP"
        Me.colCCostosP.ReadOnly = True
        '
        'colCheckP
        '
        DataGridViewCellStyle23.Alignment = System.Windows.Forms.DataGridViewContentAlignment.TopCenter
        Me.colCheckP.DefaultCellStyle = DataGridViewCellStyle23
        Me.colCheckP.HeaderText = "Check"
        Me.colCheckP.Name = "colCheckP"
        Me.colCheckP.ReadOnly = True
        '
        'botonImprimir
        '
        Me.botonImprimir.Image = CType(resources.GetObject("botonImprimir.Image"), System.Drawing.Image)
        Me.botonImprimir.Location = New System.Drawing.Point(208, 11)
        Me.botonImprimir.Name = "botonImprimir"
        Me.botonImprimir.Size = New System.Drawing.Size(59, 43)
        Me.botonImprimir.TabIndex = 23
        Me.botonImprimir.Text = "Print"
        Me.botonImprimir.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.botonImprimir.UseVisualStyleBackColor = True
        '
        'botonPrevio
        '
        Me.botonPrevio.Image = CType(resources.GetObject("botonPrevio.Image"), System.Drawing.Image)
        Me.botonPrevio.Location = New System.Drawing.Point(279, 11)
        Me.botonPrevio.Name = "botonPrevio"
        Me.botonPrevio.Size = New System.Drawing.Size(65, 42)
        Me.botonPrevio.TabIndex = 29
        Me.botonPrevio.Text = "Preview"
        Me.botonPrevio.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.botonPrevio.UseVisualStyleBackColor = True
        '
        'etiquetaAutorizacion
        '
        Me.etiquetaAutorizacion.AutoSize = True
        Me.etiquetaAutorizacion.Location = New System.Drawing.Point(478, 63)
        Me.etiquetaAutorizacion.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.etiquetaAutorizacion.Name = "etiquetaAutorizacion"
        Me.etiquetaAutorizacion.Size = New System.Drawing.Size(39, 13)
        Me.etiquetaAutorizacion.TabIndex = 34
        Me.etiquetaAutorizacion.Text = "Label4"
        Me.etiquetaAutorizacion.Visible = False
        '
        'etiquetaSerieF
        '
        Me.etiquetaSerieF.AutoSize = True
        Me.etiquetaSerieF.Location = New System.Drawing.Point(415, 63)
        Me.etiquetaSerieF.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.etiquetaSerieF.Name = "etiquetaSerieF"
        Me.etiquetaSerieF.Size = New System.Drawing.Size(39, 13)
        Me.etiquetaSerieF.TabIndex = 35
        Me.etiquetaSerieF.Text = "Label4"
        Me.etiquetaSerieF.Visible = False
        '
        'BarraTitulo1
        '
        Me.BarraTitulo1.BackColor = System.Drawing.Color.WhiteSmoke
        Me.BarraTitulo1.Dock = System.Windows.Forms.DockStyle.Top
        Me.BarraTitulo1.Location = New System.Drawing.Point(0, 59)
        Me.BarraTitulo1.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.BarraTitulo1.Name = "BarraTitulo1"
        Me.BarraTitulo1.Size = New System.Drawing.Size(1320, 30)
        Me.BarraTitulo1.TabIndex = 1
        '
        'Encabezado1
        '
        Me.Encabezado1.Dock = System.Windows.Forms.DockStyle.Top
        Me.Encabezado1.Location = New System.Drawing.Point(0, 0)
        Me.Encabezado1.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.Encabezado1.Name = "Encabezado1"
        Me.Encabezado1.Size = New System.Drawing.Size(1320, 59)
        Me.Encabezado1.TabIndex = 0
        '
        'frmFacturaCompra
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1320, 716)
        Me.Controls.Add(Me.etiquetaSerieF)
        Me.Controls.Add(Me.etiquetaAutorizacion)
        Me.Controls.Add(Me.botonPrevio)
        Me.Controls.Add(Me.botonImprimir)
        Me.Controls.Add(Me.panelProrrateo)
        Me.Controls.Add(Me.panelDetalle)
        Me.Controls.Add(Me.panelDocumento)
        Me.Controls.Add(Me.panelLista)
        Me.Controls.Add(Me.BarraTitulo1)
        Me.Controls.Add(Me.Encabezado1)
        Me.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.Name = "frmFacturaCompra"
        Me.Text = "frmFacturaCompra"
        Me.WindowState = System.Windows.Forms.FormWindowState.Maximized
        Me.panelLista.ResumeLayout(False)
        CType(Me.dgLista, System.ComponentModel.ISupportInitialize).EndInit()
        Me.PanelPiePagina.ResumeLayout(False)
        Me.PanelPiePagina.PerformLayout()
        Me.panelEncabezado.ResumeLayout(False)
        Me.panelEncabezado.PerformLayout()
        Me.panelCriterios.ResumeLayout(False)
        Me.panelDocumento.ResumeLayout(False)
        Me.panelDatosFac.ResumeLayout(False)
        Me.panelDatosFac.PerformLayout()
        Me.panelResolucion.ResumeLayout(False)
        Me.panelResolucion.PerformLayout()
        CType(Me.dgFacturas, System.ComponentModel.ISupportInitialize).EndInit()
        Me.panelBtnDetalle.ResumeLayout(False)
        Me.panelDesglose.ResumeLayout(False)
        Me.gbPoliza.ResumeLayout(False)
        CType(Me.dgOrdenes, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.dgPoliza, System.ComponentModel.ISupportInitialize).EndInit()
        Me.gbImpuestos.ResumeLayout(False)
        Me.panelBotones.ResumeLayout(False)
        CType(Me.dgImpuestos, System.ComponentModel.ISupportInitialize).EndInit()
        Me.panelDetalle.ResumeLayout(False)
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.dgPagos, System.ComponentModel.ISupportInitialize).EndInit()
        Me.panelProrrateo.ResumeLayout(False)
        Me.paneBotones.ResumeLayout(False)
        CType(Me.dgProrrateo, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents Encabezado1 As encabezado
    Friend WithEvents BarraTitulo1 As BarraTitulo
    Friend WithEvents panelLista As Panel
    Friend WithEvents panelEncabezado As Panel
    Friend WithEvents botonImportaciones As Button
    Friend WithEvents botonLocal As Button
    Friend WithEvents botonTodo As Button
    Friend WithEvents checkDocSaldo As System.Windows.Forms.CheckBox
    Friend WithEvents botonProveedores As Button
    Friend WithEvents celdaProveedores As TextBox
    Friend WithEvents etiquetaDocumentos As Label
    Friend WithEvents botonActualizar As Button
    Friend WithEvents dtpFinal As DateTimePicker
    Friend WithEvents etiquetaFecha As Label
    Friend WithEvents dtpInicial As DateTimePicker
    Friend WithEvents checkFecha As System.Windows.Forms.CheckBox
    Friend WithEvents panelDocumento As Panel
    Friend WithEvents dtpFechaVence As DateTimePicker
    Friend WithEvents etiquetaVence As Label
    Friend WithEvents dtpFecha1 As DateTimePicker
    Friend WithEvents etiquetaFecha1 As Label
    Friend WithEvents celdaSerie As TextBox
    Friend WithEvents etiquetaSerie As Label
    Friend WithEvents celdaNumero As TextBox
    Friend WithEvents etiquetaNumero As Label
    Friend WithEvents botonFecha As Button
    Friend WithEvents botonProveedor As Button
    Friend WithEvents celdaProveedor As TextBox
    Friend WithEvents etiquetaProveedor As Label
    Friend WithEvents checkFacElectrónica As System.Windows.Forms.CheckBox
    Friend WithEvents checkContribuyent As System.Windows.Forms.CheckBox
    Friend WithEvents celdaFecha1 As TextBox
    Friend WithEvents celdaFechaVence As TextBox
    Friend WithEvents celdaProveedor1 As TextBox
    Friend WithEvents celdaNIT As TextBox
    Friend WithEvents etiquetaNIT As Label
    Friend WithEvents botonPolizaContable As Button
    Friend WithEvents botonMonedaConvert As Button
    Friend WithEvents celdaMoneda As TextBox
    Friend WithEvents etiquetaMoneda As Label
    Friend WithEvents celdaMonto As TextBox
    Friend WithEvents etiquetaMonto As Label
    Friend WithEvents checkActivoFijo As System.Windows.Forms.CheckBox
    Friend WithEvents checkRevisado As System.Windows.Forms.CheckBox
    Friend WithEvents etiquetaMontoTotal As Label
    Friend WithEvents celdaTasa As TextBox
    Friend WithEvents etiquetaTasa As Label
    Friend WithEvents celdaMoneda1 As TextBox
    Friend WithEvents panelDesglose As Panel
    Friend WithEvents gbImpuestos As GroupBox
    Friend WithEvents panelBotones As Panel
    Friend WithEvents botonEliminar As Button
    Friend WithEvents botonOtrosImp As Button
    Friend WithEvents botnEditar As Button
    Friend WithEvents dgImpuestos As DataGridView
    Friend WithEvents panelDatosFac As Panel
    Friend WithEvents panelDetalle As Panel
    Friend WithEvents dgPagos As DataGridView
    Friend WithEvents dgLista As DataGridView
    Friend WithEvents PanelPiePagina As Panel
    Friend WithEvents etiquetaVerde As Label
    Friend WithEvents etiquetaCeleste As Label
    Friend WithEvents etiquetaAmarilla As Label
    Friend WithEvents etiquetaNaranja As Label
    Friend WithEvents etiquetaISR As Label
    Friend WithEvents etiquetaRoja As Label
    Friend WithEvents celdaVerde As TextBox
    Friend WithEvents celdaCeleste As TextBox
    Friend WithEvents celdaAmarila As TextBox
    Friend WithEvents celdaNaranja As TextBox
    Friend WithEvents celdaRosa As TextBox
    Friend WithEvents celdaRoja As TextBox
    Friend WithEvents gbPoliza As GroupBox
    Friend WithEvents botonDesligar As Button
    Friend WithEvents dgPoliza As DataGridView
    Friend WithEvents botonRelacionar As Button
    Friend WithEvents panelCriterios As Panel
    Friend WithEvents celdaRetension As TextBox
    Friend WithEvents etiquetaCompra As Label
    Friend WithEvents celdaNotas As TextBox
    Friend WithEvents etiquetaNotas As Label
    Friend WithEvents botonISR As Button
    Friend WithEvents botonPagos As Button
    Friend WithEvents celdaNumOc As TextBox
    Friend WithEvents celdaAnioOc As TextBox
    Friend WithEvents celdaCatOc As TextBox
    Friend WithEvents botonMoneda As Button
    Friend WithEvents botonProrrateo As Button
    Friend WithEvents checkProrrateo As System.Windows.Forms.CheckBox
    Friend WithEvents celdaDetFact As TextBox
    Friend WithEvents colTipo2 As DataGridViewTextBoxColumn
    Friend WithEvents colAño2 As DataGridViewTextBoxColumn
    Friend WithEvents colNumero2 As DataGridViewTextBoxColumn
    Friend WithEvents colMoneda2 As DataGridViewTextBoxColumn
    Friend WithEvents colTasa As DataGridViewTextBoxColumn
    Friend WithEvents colCargoEx As DataGridViewTextBoxColumn
    Friend WithEvents colAbonoEx As DataGridViewTextBoxColumn
    Friend WithEvents colFecha2 As DataGridViewTextBoxColumn
    Friend WithEvents colDocumento As DataGridViewTextBoxColumn
    Friend WithEvents colReferencia As DataGridViewTextBoxColumn
    Friend WithEvents colConcepto As DataGridViewTextBoxColumn
    Friend WithEvents colCargo As DataGridViewTextBoxColumn
    Friend WithEvents colAbono As DataGridViewTextBoxColumn
    Friend WithEvents colSaldo2 As DataGridViewTextBoxColumn
    Friend WithEvents panelProrrateo As Panel
    Friend WithEvents dgProrrateo As DataGridView
    Friend WithEvents paneBotones As Panel
    Friend WithEvents botonSeleccionar As Button
    Friend WithEvents colIDP As DataGridViewTextBoxColumn
    Friend WithEvents colCCostosP As DataGridViewTextBoxColumn
    Friend WithEvents colCheckP As DataGridViewTextBoxColumn
    Friend WithEvents celdaRevisado As TextBox
    Friend WithEvents panelBtnDetalle As Panel
    Friend WithEvents botonMenos As Button
    Friend WithEvents botonMas As Button
    Friend WithEvents colLine As DataGridViewTextBoxColumn
    Friend WithEvents colID As DataGridViewTextBoxColumn
    Friend WithEvents colCodigo1 As DataGridViewTextBoxColumn
    Friend WithEvents colTipo As DataGridViewTextBoxColumn
    Friend WithEvents colDescripcion1 As DataGridViewTextBoxColumn
    Friend WithEvents colCantidad1 As DataGridViewTextBoxColumn
    Friend WithEvents colFactor As DataGridViewTextBoxColumn
    Friend WithEvents colBase As DataGridViewTextBoxColumn
    Friend WithEvents colMonto As DataGridViewTextBoxColumn
    Friend WithEvents colTag As DataGridViewTextBoxColumn
    Friend WithEvents colOrigen As DataGridViewTextBoxColumn
    Friend WithEvents rbOrdenDeCompra As System.Windows.Forms.RadioButton
    Friend WithEvents rbImportación As System.Windows.Forms.RadioButton
    Friend WithEvents rbLocal As System.Windows.Forms.RadioButton
    Friend WithEvents dgOrdenes As System.Windows.Forms.DataGridView
    Friend WithEvents DataGridView1 As System.Windows.Forms.DataGridView
    Friend WithEvents colCatalogo As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colAñio As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colNumero As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colDate As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colLineOrden As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colReference As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents dgFacturas As System.Windows.Forms.DataGridView
    Friend WithEvents TextBox1 As System.Windows.Forms.TextBox
    Friend WithEvents etiquetaOrden As System.Windows.Forms.Label
    Friend WithEvents botonGenerarIngreso As System.Windows.Forms.Button
    Friend WithEvents celdaCAI As System.Windows.Forms.TextBox
    Friend WithEvents etiquetaCAI As System.Windows.Forms.Label
    Friend WithEvents etiquetaExtemporanea As Label
    Friend WithEvents CheckFactEspecial As System.Windows.Forms.CheckBox
    Friend WithEvents botonImprimir As System.Windows.Forms.Button
    Friend WithEvents celdaSerieFel As TextBox
    Friend WithEvents celdaFechaHoraCertificacion As TextBox
    Friend WithEvents celdaUUID As TextBox
    Friend WithEvents celdaFechaEmisionDocumento As TextBox
    Friend WithEvents checkActive As System.Windows.Forms.CheckBox
    Friend WithEvents botonPrevio As Button
    Friend WithEvents etiquetaAutorizacion As Label
    Friend WithEvents etiquetaSerieF As Label
    Friend WithEvents celdaidProveedores As TextBox
    Friend WithEvents etiquetaInvoice As Label
    Friend WithEvents BotonNotas As Button
    Friend WithEvents etiquetaDiaCredito As Label
    Friend WithEvents celdaMontoProd As TextBox
    Friend WithEvents dtpFechaPolizaC As DateTimePicker
    Friend WithEvents Label1 As Label
    Friend WithEvents botonDocumentos As Button
    Friend WithEvents celdaDetalleDocumento As TextBox
    Friend WithEvents Label2 As Label
    Friend WithEvents celdaTipoOrden As TextBox
    Friend WithEvents colTipo1 As DataGridViewTextBoxColumn
    Friend WithEvents colAño As DataGridViewTextBoxColumn
    Friend WithEvents colNum As DataGridViewTextBoxColumn
    Friend WithEvents colPoliza As DataGridViewTextBoxColumn
    Friend WithEvents colLinea As DataGridViewTextBoxColumn
    Friend WithEvents colCantida As DataGridViewTextBoxColumn
    Friend WithEvents colPrice As DataGridViewTextBoxColumn
    Friend WithEvents colMonto1 As DataGridViewTextBoxColumn
    Friend WithEvents colFechaIngreso As DataGridViewTextBoxColumn
    Friend WithEvents TC_Poliza As DataGridViewTextBoxColumn
    Friend WithEvents panelResolucion As Panel
    Friend WithEvents celdaIdResolución As TextBox
    Friend WithEvents botonResolción As Button
    Friend WithEvents celdaResolucion As TextBox
    Friend WithEvents Label12 As Label
    Friend WithEvents colIdLista As DataGridViewTextBoxColumn
    Friend WithEvents colTipoLista As DataGridViewTextBoxColumn
    Friend WithEvents colAñoLista As DataGridViewTextBoxColumn
    Friend WithEvents colNumeroLista As DataGridViewTextBoxColumn
    Friend WithEvents colFecha As DataGridViewTextBoxColumn
    Friend WithEvents colFactura As DataGridViewTextBoxColumn
    Friend WithEvents ColProveedor As DataGridViewTextBoxColumn
    Friend WithEvents colMoneda As DataGridViewTextBoxColumn
    Friend WithEvents colSaldo As DataGridViewTextBoxColumn
    Friend WithEvents colGrupo As DataGridViewTextBoxColumn
    Friend WithEvents colClase As DataGridViewTextBoxColumn
    Friend WithEvents colProcesado As DataGridViewTextBoxColumn
    Friend WithEvents colEstado As DataGridViewTextBoxColumn
    Friend WithEvents colSIVA As DataGridViewTextBoxColumn
    Friend WithEvents colISR As DataGridViewTextBoxColumn
    Friend WithEvents colFechaVence As DataGridViewTextBoxColumn
    Friend WithEvents colReten As DataGridViewTextBoxColumn
    Friend WithEvents colSerieF As DataGridViewTextBoxColumn
    Friend WithEvents colAutorizacionF As DataGridViewTextBoxColumn
    Friend WithEvents tipoDocumento As DataGridViewTextBoxColumn
    Friend WithEvents SinIngresos As DataGridViewTextBoxColumn
    Friend WithEvents TipoOC As DataGridViewTextBoxColumn
    Friend WithEvents Label3 As Label
    Friend WithEvents TextBox2 As TextBox
    Friend WithEvents colCat As DataGridViewTextBoxColumn
    Friend WithEvents colAnio As DataGridViewTextBoxColumn
    Friend WithEvents colNumber As DataGridViewTextBoxColumn
    Friend WithEvents colLineaFactura As DataGridViewTextBoxColumn
    Friend WithEvents colLineaOrden As DataGridViewTextBoxColumn
    Friend WithEvents colCantidad As DataGridViewTextBoxColumn
    Friend WithEvents colDescripcion As DataGridViewTextBoxColumn
    Friend WithEvents colPrecioSinIVA As DataGridViewTextBoxColumn
    Friend WithEvents colPrecio As DataGridViewTextBoxColumn
    Friend WithEvents colTotal As DataGridViewTextBoxColumn
    Friend WithEvents colCodigo As DataGridViewTextBoxColumn
    Friend WithEvents colCuentaActivo As DataGridViewTextBoxColumn
    Friend WithEvents colActivo As DataGridViewTextBoxColumn
    Friend WithEvents colidCuentaIVA As DataGridViewTextBoxColumn
    Friend WithEvents colCuenta As DataGridViewTextBoxColumn
    Friend WithEvents colGasto As DataGridViewTextBoxColumn
    Friend WithEvents colCosto As DataGridViewTextBoxColumn
    Friend WithEvents colCentro As DataGridViewTextBoxColumn
    Friend WithEvents colClasificacion As DataGridViewTextBoxColumn
    Friend WithEvents colAgregar As DataGridViewTextBoxColumn
    Friend WithEvents colCtaIVA As DataGridViewTextBoxColumn
    Friend WithEvents colCodigoP As DataGridViewTextBoxColumn
    Friend WithEvents col_idCuenta As DataGridViewTextBoxColumn
    Friend WithEvents col_NomCuentafectar As DataGridViewTextBoxColumn
    Friend WithEvents col_idRubro As DataGridViewTextBoxColumn
    Friend WithEvents col_Rubro As DataGridViewTextBoxColumn
    Friend WithEvents loteNum As DataGridViewTextBoxColumn
End Class
