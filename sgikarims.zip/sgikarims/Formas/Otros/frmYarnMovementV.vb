﻿Public Class frmYarnMovementV

#Region "Miembros"
    Dim strkey As String = STR_VACIO
    Dim logInsertar As Boolean = False
    Dim logConsultar As Boolean = False
    Dim logEditar As Boolean = False
    Dim LogBorrar As Boolean = False
    Private b As New BindingSource

    Public Const MAX_DOCS As Byte = 1

    'Clave del documento
    Private Const STR_CLAVE As String = "YMR"
    'Validar que la referencia sea única
    Private Const LOG_UNIQUE As Boolean = True
    Private Const STR_NOMBRE As String = "cliente"

    Public Const TBL_DOCUMENTOS As String = "Dcmtos_HDR"

#End Region

#Region "Propiedades"
    Public Property key As String
        Get
            Return strkey
        End Get
        Set(value As String)
            strkey = value
        End Set
    End Property
#End Region

#Region "Procedimientos"

    Private Sub Accessos()
        Dim cAccesos As New clsAccesos
        Try
            If cAccesos.Accesos(strkey) = True Then
                logInsertar = cAccesos.Insertar
                logConsultar = cAccesos.Consultar
                logEditar = cAccesos.Editar
                LogBorrar = cAccesos.Borrar
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub BloquearBotones(Optional ByVal logBloquear As Boolean = True)
        If logBloquear = True Then
            Encabezado1.botonBorrar.Enabled = False
            Encabezado1.botonGuardar.Enabled = False
            'botonImprimir.Enabled = False
        Else
            Encabezado1.botonBorrar.Enabled = True
            Encabezado1.botonGuardar.Enabled = True
            'botonImprimir.Enabled = True
        End If
    End Sub

    'Query que carga el listdo principal
    Private Function SqlLista() As String
        Dim strSql As String = STR_VACIO
        strSql = "SELECT h.HDoc_Doc_Ano YEAR, h.HDoc_DR1_DBL ID, h.HDoc_Doc_Num numeroVerdadero,  h.HDoc_Doc_Fec DATE, h.HDoc_Emp_Nom Customer, COALESCE(h.HDoc_DR1_Num,'') Reference, h.HDoc_Doc_Status Estado, IFNULL(fe.Serie,'') Serie,IFNULL(fe.NumeroAutorizacion,'')  Autorizacion, " &
            "       IFNULL(( " &
            "           SELECT f.HDoc_DR1_Num FROM Dcmtos_DTL_Pro r " &
            "             INNER JOIN Dcmtos_HDR f ON f.HDoc_Sis_Emp=r.PDoc_Sis_Emp AND f.HDoc_Doc_Cat=r.PDoc_Par_Cat AND f.HDoc_Doc_Ano=r.PDoc_Par_Ano AND f.HDoc_Doc_Num=r.PDoc_Par_Num  " &
            "           WHERE r.PDoc_Sis_Emp=h.HDoc_Sis_Emp AND r.PDoc_Chi_Cat=h.HDoc_Doc_Cat AND r.PDoc_Chi_Ano=h.HDoc_Doc_Ano AND r.PDoc_Chi_Num=h.HDoc_Doc_Num AND r.PDoc_Chi_Lin=1 AND r.PDoc_Par_Cat=36),'') Document, IFNULL(cl.cat_desc,'N/A') Clase " &
            "     FROM Dcmtos_HDR h " &
            "       LEFT JOIN Dcmtos_DTL_Pro dp ON dp.PDoc_Sis_Emp = h.HDoc_Sis_Emp AND dp.PDoc_Chi_Cat = h.HDoc_Doc_Cat AND dp.PDoc_Chi_Ano = h.HDoc_Doc_Ano AND dp.PDoc_Chi_Num = h.HDoc_Doc_Num AND dp.PDoc_Par_Cat = 36 
                    LEFT JOIN Catalogos cl ON cl.cat_num = h.HDoc_DR2_Emp " &
            "           LEFT JOIN Fel fe ON fe.Empresa  = dp.PDoc_Sis_Emp AND fe.Catalogo  = dp.PDoc_Par_Cat AND fe.Anio  = dp.PDoc_Par_Ano AND fe.Numero  = dp.PDoc_Par_Num  " &
            "   WHERE h.HDoc_Sis_Emp={empresa} AND h.HDoc_Doc_Cat=395  "

        If checkFecha.Checked Then
            strSql &= "  AND (h.HDoc_Doc_Fec BETWEEN '{inicio}' AND '{fin}')"
            strSql = Replace(strSql, "{inicio}", dtpFechaInicio.Value.ToString(FORMATO_MYSQL))
            strSql = Replace(strSql, "{fin}", dtpFechaFin.Value.ToString(FORMATO_MYSQL))
        End If

        If checkCliente.Checked Then
            strSql &= "  AND h.HDoc_Emp_Nom like '%{cliente}%' "
            strSql = Replace(strSql, "{cliente}", celdaClienteFiltro.Text)
        End If
        strSql &= " GROUP By h.HDoc_Sis_Emp,h.HDoc_Doc_Cat,h.HDoc_Doc_Ano , h.HDoc_Doc_Num"
        strSql &= " ORDER BY h.HDoc_Doc_Ano DESC, h.HDoc_Doc_Fec DESC, h.HDoc_Doc_Num DESC"
        strSql = Replace(strSql, "{empresa}", Sesion.IdEmpresa)
        Return strSql
    End Function

    'Cargar query de llista principal
    Private Function CargarSQLlista() As String
        Dim strSQL As String = STR_VACIO
        Dim strFila As String = STR_VACIO
        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader
        Dim IntPais As Integer = INT_CERO
        Dim strCadena As String = STR_VACIO
        Dim arrayCadena() As String

        strSQL = SqlLista()

        Try
            MyCnn.CONECTAR = strConexion

            COM = New MySqlCommand(strSQL, CON)
            REA = COM.ExecuteReader

            If REA.HasRows Then

                If (Sesion.IdEmpresa = 12 And Pais() = 310) Or (Sesion.IdEmpresa = 14 And Pais() = 327) Or (Sesion.IdEmpresa = 16) Or (Sesion.IdEmpresa = 11) Or Sesion.idGiro = 2 Then
                    dgLista.Columns(7).Visible = False
                    dgLista.Columns(8).Visible = False
                Else
                    dgLista.Columns(7).Visible = True
                    dgLista.Columns(8).Visible = True
                End If

                dgLista.Rows.Clear()
                Do While REA.Read
                    strFila = REA.GetInt32("YEAR") & "|"
                    IntPais = Pais()
                    If IntPais = 327 And Sesion.IdEmpresa = 14 Then
                        strFila &= REA.GetInt32("ID") & "|"
                        strFila &= REA.GetInt32("numeroVerdadero") & "|"

                    ElseIf IntPais = 310 And Sesion.IdEmpresa = 12 Then
                        strFila &= REA.GetInt32("ID") & "|"
                        strFila &= REA.GetInt32("numeroVerdadero") & "|"
                    ElseIf IntPais = 310 And Sesion.IdEmpresa = 16 Then
                        strFila &= REA.GetInt32("ID") & "|"
                        strFila &= REA.GetInt32("numeroVerdadero") & "|"
                    ElseIf Sesion.IdEmpresa = 11 Or Sesion.idGiro = 2 Then
                        strFila &= REA.GetInt32("ID") & "|"
                        strFila &= REA.GetInt32("numeroVerdadero") & "|"
                    Else
                        strFila &= REA.GetInt32("numeroVerdadero") & "|"
                        strFila &= REA.GetInt32("ID") & "|"
                    End If

                    strFila &= REA.GetDateTime("DATE") & "|"
                    strFila &= REA.GetString("Customer") & "|"
                    strFila &= REA.GetString("Reference") & "|"
                    strFila &= REA.GetString("Document") & "|"
                    strCadena = REA.GetString("Serie")
                    arrayCadena = strCadena.Split("-".ToCharArray)
                    strFila &= arrayCadena(INT_CERO) & "|"
                    strFila &= REA.GetString("Autorizacion") & "|"
                    strFila &= REA.GetString("Clase")

                    If REA.GetInt32("Estado") = 0 Then
                        cFunciones.AgregarFila(dgLista, strFila, Color.Red)
                    Else
                        cFunciones.AgregarFila(dgLista, strFila)
                    End If

                Loop
            End If

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Function

    'Limpia todos los campos y datagrid's del panel de Fcaturacion
    Public Sub LimpiarPanelOrden()
        celdaAño.Text = -1
        celdaNumero.Text = -1
        celdaTasaCambio.Text = INT_UNO
        dtpFecha.Text = STR_VACIO
        celdaIDEmpresa.Text = NO_FILA
        celdaCatalogo.Text = NO_FILA
        celdaUsuario.Text = NO_FILA
        celdaDireccion.Text = STR_VACIO
        celdaNombre.Text = STR_VACIO
        celdaIDCliente.Text = NO_FILA

        celdaidClase.Text = NO_FILA
        celdaClase.Text = STR_VACIO

        celdaNIt.Text = STR_VACIO
        celdaMoneda.Text = STR_VACIO
        celdaIDMoneda.Text = NO_FILA
        celdaReferencia.Text = STR_VACIO
        celdaCliente2.Text = STR_VACIO
        celdaIDCliente2.Text = STR_VACIO

        celdaInfo.Text = STR_VACIO
        etiquetaInfo0.Text = STR_VACIO
        etiquetaInfo1.Text = STR_VACIO
        celdaCantidad.Text = NO_FILA
        celdaTotal.Text = NO_FILA
        celdaObservacion.Clear()

        dgDetalle.Rows.Clear()
        dgDocs.Rows.Clear()


    End Sub

    Private Sub MostrarLista(Optional ByVal logMostrar As Boolean = True, Optional logInsert As Boolean = False)
        Dim cfun As New clsFunciones
        If logMostrar = True Then
            'ocultar panel de documento
            panelDocumento.Dock = DockStyle.None
            panelDocumento.Visible = False
            'actualizar Titulo
            BarraTitulo1.CambiarTitulo("Yarn Movement Requisition")
            'Cargar Datos
            'cfun.CargarLista(dgLista, SQLlista, False)
            CargarSQLlista()
            'Mostrar Panel Filtro
            PanelLista.Visible = True
            PanelLista.Dock = DockStyle.Fill
            BloquearBotones()
            etiquetaSerie.Visible = False
            etiquetaAutorizacion.Visible = False
            'Me.Tag = ""
        Else
            'Ocultar Panel Filtro
            PanelLista.Visible = False
            PanelLista.Dock = DockStyle.None
            'Mostrar panel de documento
            panelDocumento.Dock = DockStyle.Fill
            panelDocumento.Visible = True
            'Verifica si se va a crear un nuevo documento o se va modifica
            If logInsert = False Then
                BarraTitulo1.CambiarTitulo("Modify Record")
                Me.Tag = "Mod"
                BloquearBotones(False)
                'botonImprimir.Enabled = True
            Else
                BarraTitulo1.CambiarTitulo("New Record")
                Me.Tag = "Nuevo"
                BloquearBotones(False)
                'botonImprimir.Enabled = False

                'LimpiarPanelOrden()
            End If

            dgLista.DataSource = Nothing
        End If

    End Sub

    'Devuelve las consultas de seleccion con los documentos por procesars
    Private Function SqlGetDocumentList(Optional Clase As Boolean = False, Optional Codigo As Boolean = False, Optional Estado As Boolean = True, Optional Actual As Boolean = False, Optional Aleas As Boolean = False, Optional Saldo As Boolean = True, Optional CurDoc As Integer = vbEmpty) As String
        'Parámetros: empresa, tipo, clase, codigo, estado
        Dim strSQL As String = STR_VACIO

        strSQL = "SELECT DISTINCT"

        If Aleas Then
            strSQL &= "      HDoc_Sis_Emp empresa, HDoc_Doc_Cat tipo, HDoc_Doc_Ano anio, HDoc_DR1_Dbl num, HDoc_Doc_Num numero, HDoc_Doc_Fec fecha, COALESCE(HDoc_DR1_Num,'') referencia, HDoc_Usuario usuario, HDoc_RF1_Dbl Total"
        Else
            strSQL &= "      HDoc_Sis_Emp, HDoc_Doc_Cat, HDoc_Doc_Ano, HDoc_DR1_Dbl, HDoc_Doc_Num, HDoc_Doc_Fec, COALESCE(HDoc_DR1_Num,'') HDoc_DR1_Num, HDoc_Usuario, HDoc_RF1_Dbl Total "
        End If

        strSQL &= "                  FROM Dcmtos_HDR a"
        strSQL &= "                      LEFT JOIN Dcmtos_DTL b  ON a.HDoc_Sis_Emp  = b.DDoc_Sis_Emp AND a.HDoc_Doc_Cat  = b.DDoc_Doc_Cat AND"
        strSQL &= "                          a.HDoc_Doc_Ano  = b.DDoc_Doc_Ano AND a.HDoc_Doc_Num  = b.DDoc_Doc_Num "
        strSQL &= "                   WHERE HDoc_Sis_Emp = {empresa} AND (HDoc_Doc_Cat = {tipo})"

        If Clase Then
            'Clase: importación, devolución, transferencia
            strSQL &= "   AND COALESCE(HDoc_DR1_Cat,0) = {clase}"
        End If

        If Codigo Then
            'Código de la empresa (cliente/proveedor)
            strSQL &= "      AND (HDoc_Emp_Cod = {codigo})"
        End If

        If Estado Then
            strSQL &= "          AND HDoc_Doc_Status = 1"
        End If

        If Saldo Then
            'Solo documentos con saldo
            strSQL &= "      AND (COALESCE((SELECT SUM(c.PDoc_QTY_Pro)"
            strSQL &= "          FROM Dcmtos_DTL_Pro c"
            strSQL &= "              WHERE c.PDoc_Sis_Emp = b.DDoc_Sis_Emp AND c.PDoc_Par_Cat = b.DDoc_Doc_Cat AND"
            strSQL &= "                   c.PDoc_Par_Ano = b.DDoc_Doc_Ano AND c.PDoc_Par_Num = b.DDoc_Doc_Num AND"
            strSQL &= "               c.PDoc_Par_Lin = b.DDoc_Doc_Lin"

            If Actual Then
                'Documento que descarga (actual)
                strSQL &= "     AND c.PDoc_Chi_Cat = {actual}"
            End If

            If CurDoc = 36 Then
                strSQL &= "          ), 0) < b.DDoc_RF3_Dbl)"
            Else
                strSQL &= "                  ), 0) < b.DDoc_Prd_QTY)"
            End If
        End If

        strSQL &= "      ORDER BY HDoc_Doc_Ano DESC, HDoc_Doc_Num DESC"

        'Devuelve el resultado
        SqlGetDocumentList = strSQL
    End Function

    Private Function SqlDocsPendientes() As String
        'Consulta de selección de los documentos pendientes de procesar
        Dim strSQL As String = STR_VACIO

        'Instrucción de selección
        'Parametros: clase, código (empresa), estado (activo), actual (child)
        strSQL = SqlGetDocumentList(False, True, True, True, True)

        'Reemplazar parametros
        strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
        strSQL = Replace(strSQL, "{tipo}", 36)
        strSQL = Replace(strSQL, "{actual}", 395)
        strSQL = Replace(strSQL, "{codigo}", celdaIDCliente.Text)

        'Devuelve el resultado
        SqlDocsPendientes = strSQL

    End Function

    Private Function sqlDocsProcesados() As String
        Dim strSQL As String = STR_VACIO
        Dim intPais As Integer = INT_CERO

        strSQL = "SELECT DISTINCT HDoc_Doc_Cat tipo, HDoc_Doc_Ano anio, HDoc_Doc_Num numero,HDoc_DR1_Dbl num, HDoc_Doc_Fec fecha, HDoc_Usuario usuario, HDoc_DR1_Num referencia"
        strSQL &= "     FROM Dcmtos_DTL_Pro a"
        strSQL &= "              INNER JOIN Dcmtos_HDR b ON a.PDoc_Sis_Emp = b.HDoc_Sis_Emp AND a.PDoc_Par_Cat = b.HDoc_Doc_Cat AND a.PDoc_Par_Ano = b.HDoc_Doc_Ano AND a.PDoc_Par_Num = b.HDoc_Doc_Num"
        strSQL &= "         WHERE a.PDoc_Sis_Emp = {empresa} AND a.PDoc_Chi_Cat = 395 AND a.PDoc_Chi_Ano = {anio} AND a.PDoc_Chi_Num = {num}"
        strSQL &= "  ORDER BY b.HDoc_Doc_Ano, b.HDoc_Doc_Num"

        strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
        strSQL = Replace(strSQL, "{anio}", celdaAño.Text)
        intPais = Pais()
        If (Sesion.IdEmpresa = 14 And intPais = 327) Or (Sesion.IdEmpresa = 12 And intPais = 310) Or (Sesion.IdEmpresa = 16 And intPais = 310) Or Sesion.IdEmpresa = 11 Or Sesion.idGiro = 2 Then
            strSQL = Replace(strSQL, "{num}", celdaNum.Text)
        Else
            strSQL = Replace(strSQL, "{num}", celdaNumero.Text)
        End If

        sqlDocsProcesados = strSQL
    End Function

    Private Sub CargarDetalle(Optional ByVal Procesar As Boolean = True, Optional ByVal dgCantidad As Integer = INT_CERO)
        'Si la cant. de docs. referenciados es menor que el máximo, procesa los referencias
        Dim intCiclo As Integer = INT_CERO
        Dim intNumero As Long
        Dim intNum As Integer = INT_CERO
        Dim intCliente As Integer = INT_CERO
        Dim logCancelar As Boolean
        Dim strSQL As String = STR_VACIO
        Dim COM As New MySqlCommand
        Dim REA As MySqlDataReader

        If dgCantidad = vbEmpty Or (dgCantidad = MAX_DOCS) Then
            'If dgDocs.CurrentRow.Visible = True And dgDocs.CurrentRow.Cells(6).Value = 1 Then
            intCiclo = dgDocs.CurrentRow.Cells(0).Value
            intNumero = dgDocs.CurrentRow.Cells(2).Value
            intNum = dgDocs.CurrentRow.Cells(1).Value
            celdaReferencia.Text = STR_CLAVE & "-" & intNum

            strSQL = "SELECT COALESCE(e.HDoc_DR1_Emp,0) id, c.cli_cliente Nombre, COALESCE(e.HDoc_RF1_Cod,'N/A') persona, f.HDoc_Doc_Fec fecha"
            strSQL &= "     FROM Dcmtos_DTL d"
            strSQL &= "          LEFT JOIN Dcmtos_DTL_Pro i ON i.PDoc_Sis_Emp=d.DDoc_Sis_Emp AND i.PDoc_Chi_Cat=d.DDoc_Doc_Cat AND i.PDoc_Chi_Ano=d.DDoc_Doc_Ano AND i.PDoc_Chi_Num=d.DDoc_Doc_Num AND i.PDoc_Chi_Lin=d.DDoc_Doc_Lin"
            strSQL &= "               LEFT JOIN Dcmtos_DTL_Pro p ON p.PDoc_Sis_Emp=i.PDoc_Sis_Emp AND p.PDoc_Chi_Cat=i.PDoc_Par_Cat AND p.PDoc_Par_Cat=75 AND p.PDoc_Chi_Ano=i.PDoc_Par_Ano AND p.PDoc_Chi_Num=i.PDoc_Par_Num AND p.PDoc_Chi_Lin=i.PDoc_Par_Lin"
            strSQL &= "                     LEFT JOIN Dcmtos_HDR e ON e.HDoc_Sis_Emp=p.PDoc_Sis_Emp AND e.HDoc_Doc_Cat=p.PDoc_Par_Cat AND e.HDoc_Doc_Ano=p.PDoc_Par_Ano AND e.HDoc_Doc_Num=p.PDoc_Par_Num"
            strSQL &= "               LEFT JOIN Dcmtos_HDR f ON f.HDoc_Sis_Emp=d.DDoc_Sis_Emp AND f.HDoc_Doc_Cat=d.DDoc_Doc_Cat AND f.HDoc_Doc_Ano=d.DDoc_Doc_Ano AND f.HDoc_Doc_Num=d.DDoc_Doc_Num"
            strSQL &= "                  LEFT JOIN Clientes c ON c.cli_sisemp = e.HDoc_Sis_Emp and c.cli_codigo = e.HDoc_DR1_Emp "
            strSQL &= "          WHERE d.DDoc_Sis_Emp={empresa} AND d.DDoc_Doc_Cat={cat} AND d.DDoc_Doc_Ano={anio} AND d.DDoc_Doc_Num={numero}"
            strSQL &= "      LIMIT 1"

            strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
            strSQL = Replace(strSQL, "{cat}", 36)
            strSQL = Replace(strSQL, "{anio}", intCiclo)
            strSQL = Replace(strSQL, "{numero}", intNumero)

            Try
                MyCnn.CONECTAR = strConexion
                COM = New MySqlCommand(strSQL, CON)
                REA = COM.ExecuteReader

                If REA.Read Then
                    REA.Read()

                    intCliente = REA.GetInt32("id")
                    If (intCliente > vbEmpty) Then
                        celdaIDCliente2.Text = intCliente
                        celdaCliente2.Text = REA.GetString("Nombre")

                        celdaAño.Text = intCiclo
                        'celdaNumero.Text = intNumero

                        ValidarDatos(celdaIDCliente2.Text)
                    End If
                End If

                If Procesar Then
                    ProcesarDocumentos()
                End If

                If Not (dgDetalle.Rows.Count = NO_FILA) Then
                    For i As Integer = 0 To dgDetalle.Rows.Count - 1
                        MostrarInfo(i)
                    Next
                End If
                dtpFecha.Value = dgDocs.CurrentRow.Cells(3).Value
            Catch ex As Exception
                MsgBox(ex.ToString)
            End Try
            'End If
        End If
    End Sub

    'Consulta de selección del detalle de los docs. por procesar
    Private Function SqlDatosPorProcesar() As String
        Dim strSql As String = STR_VACIO
        Dim strCriterio As String = STR_VACIO

        strSql = "SELECT e.HDoc_Sis_Emp empresa, e.HDoc_Doc_Cat tipo, e.HDoc_Doc_Ano anio, e.HDoc_Doc_Num numero, e.HDoc_DR1_Dbl num, d.DDoc_Doc_Lin linea, d.DDoc_Prd_Cod codigo, a.art_DCorta descripcion,"
        strSql &= "   COALESCE(c.cat_clave,'') medida, d.DDoc_Prd_UM unidad, d.DDoc_Prd_PUQ precio, 0 total, d.DDoc_Prd_UM conversion, 0 cantidad, d.DDoc_RF1_Txt referencia, '' pago, '' pedido, '' contenedor, '' credito, 0 contrato, 0 revision,(IF(d.DDoc_Prd_UM = 69, d.DDoc_Prd_QTY, d.DDoc_RF3_Dbl)- COALESCE(("
        strSql &= "      SELECT SUM(p.PDoc_QTY_Pro)"
        strSql &= "         FROM Dcmtos_DTL_Pro p"
        strSql &= "            WHERE p.PDoc_Sis_Emp = d.DDoc_Sis_Emp AND p.PDoc_Par_Cat = d.DDoc_Doc_Cat AND p.PDoc_Par_Ano = d.DDoc_Doc_Ano AND p.PDoc_Par_Num = d.DDoc_Doc_Num  AND p.PDoc_Par_Lin = d.DDoc_Doc_Lin AND p.PDoc_Chi_Cat = {actual}),0)) saldo,("
        strSql &= "                  SELECT IFNULL(dp.DDoc_RF2_Txt,' ')"
        strSql &= "                      FROM Dcmtos_DTL_Pro p"
        strSql &= "                         LEFT JOIN Dcmtos_DTL_Pro i ON i.PDoc_Sis_Emp = p.PDoc_Sis_Emp AND i.PDoc_Chi_Cat = p.PDoc_Par_Cat AND i.PDoc_Chi_Ano = p.PDoc_Par_Ano AND i.PDoc_Chi_Num = p.PDoc_Par_Num AND i.PDoc_Chi_Lin = p.PDoc_Par_Lin AND i.PDoc_Par_Cat = 75"
        strSql &= "                             LEFT JOIN Dcmtos_DTL dp ON dp.DDoc_Sis_Emp = i.PDoc_Sis_Emp AND dp.DDoc_Doc_Cat = i.PDoc_Par_Cat AND dp.DDoc_Doc_Ano = i.PDoc_Par_Ano AND dp.DDoc_Doc_Num = i.PDoc_Par_Num AND dp.DDoc_Doc_Lin = i.PDoc_Par_Lin"
        strSql &= "                                 WHERE p.PDoc_Sis_Emp = d.DDoc_Sis_Emp AND p.PDoc_Par_Cat = 48 AND p.PDoc_Chi_Cat = d.DDoc_Doc_Cat AND p.PDoc_Chi_Ano = d.DDoc_Doc_Ano AND p.PDoc_Chi_Num = d.DDoc_Doc_Num AND p.PDoc_Chi_Lin = d.DDoc_Doc_Lin"
        strSql &= "                              ) comentario"
        strSql &= "              FROM Dcmtos_DTL d"
        strSql &= "                  LEFT JOIN Dcmtos_HDR e ON e.HDoc_Sis_Emp = d.DDoc_Sis_Emp AND e.HDoc_Doc_Cat = d.DDoc_Doc_Cat AND e.HDoc_Doc_Ano = d.DDoc_Doc_Ano AND e.HDoc_Doc_Num = d.DDoc_Doc_Num"
        strSql &= "                      LEFT JOIN Inventarios i ON i.inv_sisemp = d.DDoc_Sis_Emp AND i.inv_numero = d.DDoc_Prd_Cod"
        strSql &= "                          LEFT JOIN Articulos a ON a.art_sisemp = d.DDoc_Sis_Emp AND a.art_codigo = i.inv_artcodigo"
        strSql &= "                      LEFT JOIN Catalogos c ON c.cat_clase = 'Medidas' AND c.cat_num = d.DDoc_Prd_UM"
        strSql &= "                  WHERE d.DDoc_Sis_Emp = {empresa} AND d.DDoc_Doc_Cat = {tipo} {criterio}"
        strSql &= "                GROUP BY d.DDoc_Sis_Emp, d.DDoc_Doc_Cat, d.DDoc_Doc_Ano, d.DDoc_Doc_Num, d.DDoc_Doc_Lin"
        strSql &= "              HAVING (saldo > 0)"
        strSql &= "            ORDER BY d.DDoc_Doc_Ano, d.DDoc_Doc_Num"

        strCriterio = vbNullString
        If Not (dgDocs.Rows.Count = vbEmpty) Then
            'Construye el Criterio
            strCriterio = CriterioPorProcesar()
        End If

        'Reemplaza los Parametros
        strSql = Replace(strSql, "{empresa}", Sesion.IdEmpresa)
        strSql = Replace(strSql, "{actual}", 395)
        strSql = Replace(strSql, "{tipo}", 36)
        strSql = Replace(strSql, "{criterio}", strCriterio)

        Return strSql
    End Function


    Private Function SqlDatosPorProcesar2() As String
        Dim strSql As String = STR_VACIO
        Dim strCriterio As String = STR_VACIO

        strSql = "SELECT e.HDoc_Sis_Emp empresa, e.HDoc_Doc_Cat tipo, e.HDoc_Doc_Ano anio, e.HDoc_Doc_Num numero, e.HDoc_DR1_Dbl num, d.DDoc_Doc_Lin linea, d.DDoc_Prd_Cod codigo, IFNULL(d.DDoc_Prd_Des,'') descripcion,"
        strSql &= " COALESCE(c.cat_clave,'') medida, d.DDoc_Prd_UM unidad, d.DDoc_Prd_PUQ precio, 0 total, d.DDoc_Prd_UM conversion, d.DDoc_Prd_QTY cantidad, d.DDoc_RF1_Txt referencia, '' pago, '' pedido, '' contenedor, '' credito, 0 contrato, 0 revision,(IF(d.DDoc_Prd_UM = 69, d.DDoc_Prd_QTY, d.DDoc_RF3_Dbl)- 0) saldo,'' Comentario "
        strSql &= "              FROM Dcmtos_DTL d"
        strSql &= "                  LEFT JOIN Dcmtos_HDR e ON e.HDoc_Sis_Emp = d.DDoc_Sis_Emp AND e.HDoc_Doc_Cat = d.DDoc_Doc_Cat AND e.HDoc_Doc_Ano = d.DDoc_Doc_Ano AND e.HDoc_Doc_Num = d.DDoc_Doc_Num"
        strSql &= "                      LEFT JOIN Inventarios i ON i.inv_sisemp = d.DDoc_Sis_Emp AND i.inv_numero = d.DDoc_Prd_Cod"
        strSql &= "                          LEFT JOIN Articulos a ON a.art_sisemp = d.DDoc_Sis_Emp AND a.art_codigo = i.inv_artcodigo"
        strSql &= "                      LEFT JOIN Catalogos c ON c.cat_clase = 'Medidas' AND c.cat_num = d.DDoc_Prd_UM"
        strSql &= "                  WHERE d.DDoc_Sis_Emp = {empresa} AND d.DDoc_Doc_Cat = {tipo} {criterio}"
        strSql &= "                GROUP BY d.DDoc_Sis_Emp, d.DDoc_Doc_Cat, d.DDoc_Doc_Ano, d.DDoc_Doc_Num, d.DDoc_Doc_Lin"
        strSql &= "            ORDER BY d.DDoc_Doc_Ano, d.DDoc_Doc_Num"

        strCriterio = vbNullString
        If Not (dgDocs.Rows.Count = vbEmpty) Then
            'Construye el Criterio
            strCriterio = CriterioPorProcesar()
        End If

        'Reemplaza los Parametros
        strSql = Replace(strSql, "{empresa}", Sesion.IdEmpresa)
        strSql = Replace(strSql, "{tipo}", 36)
        strSql = Replace(strSql, "{criterio}", strCriterio)

        Return strSql
    End Function

    Private Function SqlTipoFactura() As String
        Dim strSql As String = STR_VACIO
        Dim strCriterio As String = STR_VACIO

        strSql = "SELECT IFNULL(h.HDoc_RF3_Dbl,0) Tipo "
        strSql &= "   FROM Dcmtos_HDR h"
        strSql &= "      WHERE h.HDoc_Sis_Emp = {empresa} AND h.HDoc_Doc_Cat = {tipo}{criterio} "

        strCriterio = vbNullString
        If Not (dgDocs.Rows.Count = vbEmpty) Then
            'Construye el Criterio
            strCriterio = CriterioPorProcesar()
        End If

        'Reemplaza los Parametros
        strSql = Replace(strSql, "{empresa}", Sesion.IdEmpresa)
        strSql = Replace(strSql, "{tipo}", 36)
        strSql = Replace(strSql, "{criterio}", strCriterio)

        Return strSql
    End Function

    Private Function CriterioPorProcesar() As String
        'Contruye el criterio de seleccion de docs. por procesar
        Dim strSQL As String = STR_VACIO
        Dim i As Integer = INT_CERO

        For i = INT_CERO To dgDocs.Rows.Count - 1
            If dgDocs.Rows(i).Visible = True And dgDocs.Rows.Count > 0 And dgDocs.Rows.Count - 1 = 0 Then
                strSQL = strSQL & IIf(i = vbEmpty, "(", " OR (")
                strSQL = strSQL & "HDoc_Doc_Ano = " & dgDocs.Rows(i).Cells("colAño").Value & " AND "
                strSQL = strSQL & "HDoc_Doc_Num = " & dgDocs.Rows(i).Cells("colNumReal").Value & ")"
            ElseIf dgDocs.Rows.Count - 1 = 0 Or dgDocs.Rows(i).Visible = True Then
                strSQL = strSQL & "HDoc_Doc_Ano = " & dgDocs.Rows(i).Cells("colAño").Value & " AND "
                strSQL = strSQL & "HDoc_Doc_Num = " & dgDocs.Rows(i).Cells("colNumReal").Value
            End If
        Next

        If Not (strSQL = vbNullString) Then
            CriterioPorProcesar = " AND (" & strSQL & ") "
        End If
    End Function

    Private Sub DatosDePedido(ByVal intNum As Integer)
        'Carga los datos del pedido para cada línea de la factura
        Dim i As Integer = INT_CERO
        Dim intCiclo As Integer = INT_CERO
        Dim intNumero As Long
        Dim intLinea As Integer = INT_CERO
        Dim dblPrecio As Double
        Dim strSQL As String = STR_VACIO
        Dim strSQL2 As String = STR_VACIO
        Dim strSQL3 As String = STR_VACIO
        Dim strSQL4 As String = STR_VACIO
        Dim strSQL5 As String = STR_VACIO
        Dim strTemp As String = STR_VACIO
        Dim strDato As String = STR_VACIO
        Dim intContrato As Integer = INT_CERO
        Dim Contenedor As String = STR_VACIO
        Dim dblDiferencia As Double
        Dim dblcosto As Double
        Dim COM As MySqlCommand
        Dim COM2 As MySqlCommand
        Dim COM3 As MySqlCommand
        Dim conec As MySqlConnection
        Dim COM4 As MySqlCommand
        Dim conec4 As MySqlConnection
        Dim conec2 As MySqlConnection
        Dim conec3 As MySqlConnection
        Dim REA As MySqlDataReader
        Dim frmNote As New frmAviso


        For i = 0 To dgDetalle.Rows.Count - 1
            'Doc. descargado (factura)
            intCiclo = dgDetalle.Rows(i).Cells("colAnio").Value
            If Sesion.IdEmpresa = 12 And Pais() = 0 Then
                intNumero = dgDetalle.Rows(i).Cells("colNum").Value
            Else
                intNumero = intNum
            End If

            intLinea = dgDetalle.Rows(i).Cells("colLinea").Value

            strSQL = "SELECT d.DDoc_Doc_Cat CatFac, d.DDoc_Doc_Ano AnoFac, d.DDoc_Doc_Num NumFac, d.DDoc_Doc_Lin LinFac,r.HDoc_Doc_Cat tipo, r.HDoc_Doc_Ano anio,"
            strSQL &= "  r.HDoc_Doc_Num numero, e.DDoc_Doc_Lin linea, "

            strSQL &= " IF(d.DDoc_Prd_UM = 70, -- si la factura esta en kg 
	                         if(e.DDoc_Prd_Cif>0 , -- si se ingreso precio en kg
	 	                        e.DDoc_Prd_Cif, -- usar precio en kg
		                        ROUND(COALESCE(e.DDoc_Prd_Net,0) *2.2046,2) )   , -- si no se ingreso precio kg calcular 
	                        e.DDoc_Prd_Net) precio, -- si el precio no es kg, usar precio normal " & vbCrLf
            strSQL &= "      COALESCE(e.DDoc_Prd_UM,0) unidad, COALESCE(r.HDoc_DR1_Num,'') pedido"
            strSQL &= "          FROM Dcmtos_DTL d"
            strSQL &= "             LEFT JOIN Dcmtos_DTL_Pro i ON i.PDoc_Sis_Emp=d.DDoc_Sis_Emp AND i.PDoc_Chi_Cat=d.DDoc_Doc_Cat AND i.PDoc_Chi_Ano=d.DDoc_Doc_Ano AND i.PDoc_Chi_Num=d.DDoc_Doc_Num AND i.PDoc_Chi_Lin=d.DDoc_Doc_Lin"
            strSQL &= "                  LEFT JOIN Dcmtos_DTL_Pro p ON p.PDoc_Sis_Emp=i.PDoc_Sis_Emp AND p.PDoc_Chi_Cat=i.PDoc_Par_Cat AND p.PDoc_Par_Cat={pedido} AND p.PDoc_Chi_Ano=i.PDoc_Par_Ano AND p.PDoc_Chi_Num=i.PDoc_Par_Num AND p.PDoc_Chi_Lin=i.PDoc_Par_Lin"
            strSQL &= "              LEFT JOIN Dcmtos_DTL e ON e.DDoc_Sis_Emp=p.PDoc_Sis_Emp AND e.DDoc_Doc_Cat=p.PDoc_Par_Cat AND e.DDoc_Doc_Ano=p.PDoc_Par_Ano AND e.DDoc_Doc_Num=p.PDoc_Par_Num AND e.DDoc_Doc_Lin=p.PDoc_Par_Lin"
            strSQL &= "           LEFT JOIN Dcmtos_HDR r ON r.HDoc_Sis_Emp=e.DDoc_Sis_Emp AND r.HDoc_Doc_Cat=e.DDoc_Doc_Cat AND r.HDoc_Doc_Ano=e.DDoc_Doc_Ano AND r.HDoc_Doc_Num=e.DDoc_Doc_Num"
            strSQL &= "        WHERE d.DDoc_Sis_Emp={empresa} AND d.DDoc_Doc_Cat={tipo} AND d.DDoc_Doc_Ano={ciclo} AND d.DDoc_Doc_Num={numero} AND d.DDoc_Doc_Lin={linea} AND NOT ISNULL(r.HDoc_Sis_Emp)"
            strSQL &= "      LIMIT 1"

            strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
            strSQL = Replace(strSQL, "{tipo}", 36)
            strSQL = Replace(strSQL, "{pedido}", 75)
            strSQL = Replace(strSQL, "{ciclo}", intCiclo)
            strSQL = Replace(strSQL, "{numero}", intNumero)
            strSQL = Replace(strSQL, "{linea}", intLinea)

            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSQL, CON)
            REA = COM.ExecuteReader

            If REA.HasRows Then
                REA.Read()
                dgDetalle.Rows(i).Cells("colPedido").Value = REA.GetString("pedido")
                If (REA.GetDouble("precio") > vbEmpty) Then
                    'Recupera el costo
                    strSQL2 = "SELECT i.PDoc_Prd_NET costo"
                    strSQL2 &= "     FROM Dcmtos_DTL_Pro p"
                    strSQL2 &= "         LEFT JOIN Dcmtos_DTL_Pro i ON i.PDoc_Sis_Emp = p.PDoc_Sis_Emp AND i.PDoc_Chi_Cat = p.PDoc_Par_Cat AND i.PDoc_Chi_Ano = p.PDoc_Par_Ano AND i.PDoc_Chi_Num =p.PDoc_Par_Num AND i.PDoc_Chi_Lin = p.PDoc_Par_Lin AND i.PDoc_Par_Cat = 47"
                    strSQL2 &= "     WHERE p.PDoc_Sis_Emp ={empresa} AND p.PDoc_Chi_Cat = {catfact} AND p.PDoc_Chi_Ano = {anofact} AND p.PDoc_Chi_Num = {numfact} AND p.PDoc_Chi_Lin = {linfact}"

                    strSQL2 = Replace(strSQL2, "{empresa}", Sesion.IdEmpresa)
                    strSQL2 = Replace(strSQL2, "{catfact}", REA.GetInt32("CatFac"))
                    strSQL2 = Replace(strSQL2, "{anofact}", REA.GetInt32("AnoFac"))
                    strSQL2 = Replace(strSQL2, "{numfact}", REA.GetInt32("NumFac"))
                    strSQL2 = Replace(strSQL2, "{linfact}", REA.GetInt32("LinFac"))

                    conec = New MySqlConnection(strConexion)
                    conec.Open()
                    COM = New MySqlCommand(strSQL2, conec)
                    Using conec
                        dblcosto = COM.ExecuteScalar
                        COM.Dispose()
                        COM = Nothing
                        conec.Close()
                        conec.Dispose()
                        conec = Nothing
                    End Using

                    'Si el precio del pedido es > cero
                    dblPrecio = (dgDetalle.Rows(i).Cells("colPrecio").Value)
                    If Not dblPrecio = REA.GetDouble("precio") Then
                        'Si el precio es distinto
                        dgDetalle.Rows(i).Cells("colPrecio").Value = REA.GetDouble("precio")
                        dgDetalle.Rows(i).Cells("colTotal").Value = (REA.GetDouble("precio") * dgDetalle.Rows(i).Cells("colCantidad").Value)

                        'Agrega a la lista de mensajes
                        strTemp = strTemp & vbCrLf & vbCrLf & "LINE #" & (i + 1) & ": the price of the order differs from the invoiced" & vbCrLf & "Order: " & REA.GetDouble("precio").ToString(FORMATO_MONEDA) & vbCrLf & "Invoice: " & dblPrecio.ToString(FORMATO_MONEDA)
                    End If

                    strTemp = strTemp & "Order Price : " & REA.GetDouble("precio").ToString(FORMATO_MONEDA) & vbCrLf & "Invoice Price: " & dblPrecio.ToString(FORMATO_MONEDA) & vbCrLf & " Costo : " & dblcosto.ToString(FORMATO_MONEDA)
                    dblDiferencia = (dblPrecio - REA.GetDouble("precio"))
                    If (dblDiferencia > 0.05) Then
                        strTemp = strTemp & " The difference is great than 0.05" & vbCrLf & "**  Please contact w Customer Service before continuing**" & vbCrLf
                    End If


                    'Recupera el número de carta de crédito
                    strSQL3 = "SELECT COALESCE(ec.HDoc_DR1_Num) credito"
                    strSQL3 &= "     FROM Dcmtos_DTL e"
                    strSQL3 &= "         LEFT JOIN Dcmtos_DTL_Pro rc ON rc.PDoc_Sis_Emp = e.DDoc_Sis_Emp AND rc.PDoc_Chi_Cat = e.DDoc_Doc_Cat AND rc.PDoc_Chi_Ano = e.DDoc_Doc_Ano AND rc.PDoc_Chi_Num = e.DDoc_Doc_Num AND rc.PDoc_Chi_Lin = e.DDoc_Doc_Lin"
                    strSQL3 &= "            LEFT JOIN Dcmtos_DTL_Pro rl ON rl.PDoc_Sis_Emp = rc.PDoc_Sis_Emp AND rl.PDoc_Par_Cat = rc.PDoc_Par_Cat AND rl.PDoc_Par_Ano = rc.PDoc_Par_Ano AND rl.PDoc_Par_Num = rc.PDoc_Par_Num AND rl.PDoc_Par_Lin = rc.PDoc_Par_Lin AND rl.PDoc_Chi_Cat = {documento} "
                    strSQL3 &= "          LEFT JOIN Dcmtos_HDR ec ON ec.HDoc_Sis_Emp = rl.PDoc_Sis_Emp AND ec.HDoc_Doc_Cat = rl.PDoc_Chi_Cat AND ec.HDoc_Doc_Ano = rl.PDoc_Chi_Ano AND ec.HDoc_Doc_Num = rl.PDoc_Chi_Num"
                    strSQL3 &= "       WHERE e.DDoc_Doc_Cat = {tipo} AND e.DDoc_Doc_Ano = {anio} AND e.DDoc_Doc_Num = {numero} AND e.DDoc_Doc_Lin = {linea} AND NOT ISNULL(ec.HDoc_Sis_Emp)"

                    strSQL3 = Replace(strSQL3, "{documento}", 387)
                    strSQL3 = Replace(strSQL3, "{tipo}", REA.GetInt32("tipo"))
                    strSQL3 = Replace(strSQL3, "{anio}", REA.GetInt32("anio"))
                    strSQL3 = Replace(strSQL3, "{numero}", REA.GetInt32("numero"))
                    strSQL3 = Replace(strSQL3, "{linea}", REA.GetInt32("linea"))

                    conec2 = New MySqlConnection(strConexion)
                    conec2.Open()
                    COM2 = New MySqlCommand(strSQL3, conec2)
                    Using conec2
                        strDato = COM2.ExecuteScalar
                        COM2.Dispose()
                        COM2 = Nothing
                        conec2.Close()
                        conec2.Dispose()
                        conec2 = Nothing
                    End Using

                    dgDetalle.Rows(i).Cells("colCredito").Value = strDato

                    If Not (strDato = vbNullString) Then
                        'Si tiene carta de crédito coloca la forma de pago
                        dgDetalle.Rows(i).Cells("colPago").Value = "L/C"
                    End If

                    'Recupera el identificar del contrato
                    strSQL4 = "SELECT ec.HDoc_Doc_Num"
                    strSQL4 &= "     FROM Dcmtos_DTL e"
                    strSQL4 &= "         LEFT JOIN Dcmtos_DTL_Pro rc ON rc.PDoc_Sis_Emp = e.DDoc_Sis_Emp AND rc.PDoc_Chi_Cat = e.DDoc_Doc_Cat AND rc.PDoc_Chi_Ano = e.DDoc_Doc_Ano AND rc.PDoc_Chi_Num = e.DDoc_Doc_Num AND rc.PDoc_Chi_Lin = e.DDoc_Doc_Lin"
                    strSQL4 &= "             LEFT JOIN Dcmtos_HDR ec ON ec.HDoc_Sis_Emp = rc.PDoc_Sis_Emp AND ec.HDoc_Doc_Cat = rc.PDoc_Par_Cat AND ec.HDoc_Doc_Ano = rc.PDoc_Par_Ano AND ec.HDoc_Doc_Num = rc.PDoc_Par_Num"
                    strSQL4 &= "         WHERE e.DDoc_Doc_Cat = {tipo} AND e.DDoc_Doc_Ano = {año} AND e.DDoc_Doc_Num = {numero} AND e.DDoc_Doc_Lin = {linea} AND NOT ISNULL(ec.HDoc_Sis_Emp)"
                    strSQL4 &= "      LIMIT 1"

                    strSQL4 = Replace(strSQL4, "{tipo}", REA.GetInt32("tipo"))
                    strSQL4 = Replace(strSQL4, "{año}", REA.GetInt32("anio"))
                    strSQL4 = Replace(strSQL4, "{numero}", REA.GetInt32("numero"))
                    strSQL4 = Replace(strSQL4, "{linea}", REA.GetInt32("linea"))

                    conec3 = New MySqlConnection(strConexion)
                    conec3.Open()
                    COM3 = New MySqlCommand(strSQL4, conec3)
                    Using conec3
                        intContrato = COM3.ExecuteScalar
                        COM3.Dispose()
                        COM3 = Nothing
                        conec3.Close()
                        conec3.Dispose()
                        conec3 = Nothing
                    End Using

                    dgDetalle.Rows(i).Cells("colContrato").Value = intContrato

                    'Recupera el contenedor de datos para póliza
                    strSQL5 = "SELECT COALESCE(d.ADoc_Dta_Txt,'') contenedor"
                    strSQL5 &= "    FROM Dcmtos_DTL_Pro f"
                    strSQL5 &= "         LEFT JOIN Dcmtos_DTL_Pro i ON i.PDoc_Sis_Emp = f.PDoc_Sis_Emp AND i.PDoc_Chi_Cat = f.PDoc_Par_Cat AND i.PDoc_Chi_Ano = f.PDoc_Par_Ano AND i.PDoc_Chi_Num = f.PDoc_Par_Num AND i.PDoc_Chi_Lin = f.PDoc_Par_Lin"
                    strSQL5 &= "             LEFT JOIN Dcmtos_DTL_Pro b ON b.PDoc_Sis_Emp = i.PDoc_Sis_Emp AND b.PDoc_Chi_Cat = i.PDoc_Par_Cat AND b.PDoc_Chi_Ano = i.PDoc_Par_Ano AND b.PDoc_Chi_Num = i.PDoc_Par_Num AND b.PDoc_Chi_Lin = i.PDoc_Par_Lin"
                    strSQL5 &= "                 LEFT JOIN Dcmtos_DTL_Pro p ON p.PDoc_Sis_Emp = b.PDoc_Sis_Emp AND p.PDoc_Chi_Cat = b.PDoc_Par_Cat AND p.PDoc_Chi_Ano = b.PDoc_Par_Ano AND p.PDoc_Chi_Num = b.PDoc_Par_Num AND p.PDoc_Chi_Lin = b.PDoc_Par_Lin"
                    strSQL5 &= "             LEFT JOIN Dcmtos_ACC d ON d.ADoc_Sis_Emp = p.PDoc_Sis_Emp AND d.ADoc_Doc_Cat = p.PDoc_Par_Cat AND d.ADoc_Doc_Ano = p.PDoc_Par_Ano And d.ADoc_Doc_Num = p.PDoc_Par_Num And d.ADoc_Doc_Sub = 'Doc_PBLading' And d.ADoc_Doc_Lin = '04'"
                    strSQL5 &= "          WHERE f.PDoc_Sis_Emp = {empresa} AND f.PDoc_Chi_Cat = {tipo} AND f.PDoc_Chi_Ano = {anio} AND f.PDoc_Chi_Num ={numero} AND f.PDoc_Chi_Lin = {linea} AND d.ADoc_Doc_Cat = 55"

                    strSQL5 = Replace(strSQL5, "{empresa}", Sesion.IdEmpresa)
                    strSQL5 = Replace(strSQL5, "{tipo}", 36)
                    strSQL5 = Replace(strSQL5, "{anio}", REA.GetInt32("anio"))
                    strSQL5 = Replace(strSQL5, "{numero}", intNumero)
                    strSQL5 = Replace(strSQL5, "{linea}", REA.GetInt32("linea"))

                    conec4 = New MySqlConnection(strConexion)
                    conec4.Open()
                    COM4 = New MySqlCommand(strSQL5, conec4)
                    Using conec4
                        Contenedor = COM4.ExecuteScalar
                        COM4.Dispose()
                        COM4 = Nothing
                        conec4.Close()
                        conec4.Dispose()
                        conec4 = Nothing
                    End Using


                    dgDetalle.Rows(i).Cells("colContenedor").Value = Contenedor
                End If
            End If
        Next

        'Carga los datos al frmAviso
        frmNote.Texto = strTemp
        frmNote.ShowDialog(Me)

        'If Not (strTemp = vbNullString) Then
        '    'Dim frmTemp As New frmMensaje
        '    'frmTemp.Text = strTemp
        '    'frmTemp.ShowDialog(Me)
        '    MsgBox(strTemp, MsgBoxStyle.Information, "Notice")
        'End If
    End Sub

    Private Function ComprobarIDs() As Boolean
        Dim logComprobar As Boolean = True
        Dim i As Integer
        Dim strNombre As String = STR_VACIO
        Dim strNombre2 As String = STR_VACIO

        If celdaIDCliente.Text = vbEmpty Then
            MsgBox("The client has not entered", vbExclamation, "Notice")
            logComprobar = False
            Exit Function
        End If

        If logComprobar Then
            If celdaIDCliente2.Text = vbEmpty Then
                If MsgBox("You must complete the applicant's data" & vbCr & vbCr & "¿Return top correct the Data?" & vbCr & vbCr & "NOTE: If you answer No, it is assumed that the requestor is the same client", vbInformation, "Applicant") = vbNo Then
                    i = IIf(celdaIDCliente2.Text = vbEmpty, celdaIDCliente.Text, vbEmpty)
                    If Not (i = NO_FILA) Then
                        'Asignar mismos datos de cliente
                        i = celdaIDCliente.Text
                        celdaIDCliente2.Text = i
                        celdaCliente2.Text = celdaNombre.Text
                    Else
                        logComprobar = True
                    End If
                End If
            End If
        End If

        If logComprobar = False Then
            strNombre = celdaIDCliente.Text
            strNombre2 = celdaIDCliente2.Text

            If strNombre = strNombre2 Then
                logComprobar = True
            ElseIf MsgBox("Receivable" & vbCr & " - " & strNombre2 & vbCr & vbCr & "Billing" & vbCr & " - " & strNombre2, vbInformation + vbOKCancel + vbDefaultButton2, "Confirmar") = vbOK Then
                logComprobar = True
            End If
        End If

        Return logComprobar
    End Function

    Private Function ComprobarIngreso() As Boolean
        'Revisar que los datos de la cabecera sean válidas
        Dim i As Integer
        Dim dblRevision As Double
        Dim logContinuar As Boolean = True
        Dim intDocs As Integer = INT_CERO
        Dim strRef As String = STR_VACIO

        If celdaRevision.Text = vbNullString Then
            For i = 0 To dgDetalle.Rows.Count - 1
                dblRevision = dblRevision + dgDetalle.Rows(i).Cells("colRevision").Value
            Next
            If dblRevision > vbEmpty Then
                celdaRevision.Text = "REVISED"
            End If
        End If

        If Me.Tag = "Nuevo" Then
            If celdaIDEmpresa.Text = vbEmpty Or celdaCatalogo.Text = vbEmpty Or celdaUsuario.Text = vbNullString Then
                MsgBox("Incomplete Data", vbExclamation, "Note")
                logContinuar = False
            ElseIf celdaAño.Text = vbEmpty Or
                   celdaIDCliente.Text = vbEmpty Or
                   celdaNombre.Text = STR_VACIO Or
                celdaTasaCambio.Text = vbEmpty Then
                MsgBox("Must enter at least the minimum data of the document", vbExclamation, "Notice")
                logContinuar = False
            ElseIf LOG_UNIQUE And celdaReferencia.Text = vbNullString Then
                MsgBox("Enter the reference data", vbExclamation, "Notice")
                logContinuar = False
            ElseIf LOG_UNIQUE Then
                If ExisteReferencia() Then
                    MsgBox("The entered reference already exists", vbExclamation, "Notice")
                    logContinuar = False
                End If
            End If
        End If

        If logContinuar Then
            'Compruebe los documentos a descargar
            intDocs = vbEmpty
            strRef = vbNullString

            For i = INT_CERO To dgDocs.Rows.Count - 1
                If dgDocs.Rows(i).Cells("colAdicional").Value = 1 Then

                    strRef = dgDocs.Rows(i).Cells("colReferencia").Value
                    intDocs = 1
                    If Not dgDocs.Rows(i).Cells("colReferencia").Value = strRef Then
                        logContinuar = False
                        'Else
                        '    'Verifica que el total sea mayor que cero
                        '    CalcularTotales()
                        '    If Not ((celdaCantidad.Text = vbEmpty) > vbEmpty) Then
                        '        MsgBox("The Quantity must be greater than zero", vbCritical)
                        '        logContinuar = False
                        '    End If
                    End If
                End If
            Next

            'Comprueba los datos del detalle del Documento
            If ComprobarFila() = False Then
                Exit Function
            End If
        End If

        ComprobarIngreso = logContinuar
        Return ComprobarIngreso
    End Function

    Private Function ComprobarFila() As Boolean
        ComprobarFila = True
        Dim i As Integer
        Dim Comprobacion As Boolean = True

        For i = 0 To dgDetalle.Rows.Count - 1

            If dgDetalle.Rows(i).Cells("colCodigo").Value = vbNullString Then
                Comprobacion = False
                MsgBox("Article code invalid")
            End If

            If dgDetalle.Rows(i).Cells("colDescripcion").Value = vbNullString Then
                Comprobacion = False
                MsgBox("Blank item description")
            End If

            If dgDetalle.Rows(i).Cells("colPrecio").Value = vbNullString Then
                Comprobacion = False
                MsgBox("Item price ZERO")
            End If

            If dgDetalle.Rows(i).Cells("colCantidad").Value = vbNullString Then
                Comprobacion = False
                MsgBox("Item number ZERO")
            End If

            If dgDetalle.Rows(i).Cells("colPago").Value = vbNullString Then
                Comprobacion = False
                MsgBox("You Have not Specified the Payment Method")
            End If

        Next
        Return Comprobacion
    End Function

    Private Function ExisteReferencia() As Boolean
        'Comprueba si la referencia ingresada ya existe o no
        Dim strSQL As String = STR_VACIO
        Dim COM As MySqlCommand
        Dim conec As MySqlConnection
        Dim intRef As Integer
        Try
            strSQL = "SELECT COUNT(*)"
            strSQL &= " FROM Dcmtos_HDR"
            strSQL &= "     WHERE HDoc_Sis_Emp={empresa} AND HDoc_Doc_Cat={tipo} AND HDoc_DR1_Num='{referencia}' AND NOT(HDoc_Doc_Ano={año} AND HDoc_Doc_Num={numero})"

            strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
            strSQL = Replace(strSQL, "{tipo}", 395)
            strSQL = Replace(strSQL, "{referencia}", celdaReferencia.Text)
            strSQL = Replace(strSQL, "{año}", celdaAño.Text)
            strSQL = Replace(strSQL, "{numero}", celdaNumero.Text)

            'Devuelve el resultado
            conec = New MySqlConnection(strConexion)
            conec.Open()
            COM = New MySqlCommand(strSQL, conec)
            Using conec
                intRef = COM.ExecuteScalar
                COM.Dispose()
                COM = Nothing
                conec.Close()
                conec.Dispose()
                conec = Nothing
                System.GC.Collect()
            End Using
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try

        If intRef > 0 Then
            ExisteReferencia = True
        Else
            ExisteReferencia = False
        End If
        Return ExisteReferencia
    End Function

    Private Function IDEmpresa() As Integer
        Dim strSQL As String = STR_VACIO
        Dim COM As MySqlCommand
        Dim conec As MySqlConnection
        Dim intPais As Integer

        Try
            strSQL = "SELECT e.emp_pais pais"
            strSQL &= "      FROM Empresas e"
            strSQL &= "              WHERE e.emp_no = {empresa}"

            strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)

            conec = New MySqlConnection(strConexion)
            conec.Open()
            COM = New MySqlCommand(strSQL, conec)
            Using conec
                intPais = COM.ExecuteScalar
                COM.Dispose()
                COM = Nothing
                conec.Close()
                conec.Dispose()
                conec = Nothing
                System.GC.Collect()
            End Using
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try

        Return intPais
    End Function

    'Guardar Encabezado del modulo de Yarn Movement
    Private Function GuardarDocumento(ByVal tipoFactura_YRM) As Boolean

        Dim logResultado As Boolean = True
        Dim intPais As Integer

        Try
            Dim chdr As New clsDcmtos_HDR
            chdr.CONEXION = strConexion

            chdr.HDOC_SIS_EMP = celdaIDEmpresa.Text
            chdr.HDOC_DOC_CAT = celdaCatalogo.Text
            chdr.HDOC_DOC_ANO = celdaAño.Text

            intPais = Pais()
            If intPais = 327 And Sesion.IdEmpresa = 14 Or Sesion.IdEmpresa = 11 Or Sesion.idGiro = 2 Then
                chdr.HDOC_DOC_NUM = celdaNum.Text
                chdr.HDOC_DR1_DBL = celdaNumero.Text
            ElseIf Sesion.IdEmpresa = 12 And intPais = 310 Then
                chdr.HDOC_DOC_NUM = celdaNum.Text
                chdr.HDOC_DR1_DBL = celdaNumero.Text
            ElseIf Sesion.IdEmpresa = 16 And intPais = 310 Then
                chdr.HDOC_DOC_NUM = celdaNum.Text
                chdr.HDOC_DR1_DBL = celdaNumero.Text

            Else
                chdr.HDOC_DOC_NUM = celdaNumero.Text
                chdr.HDOC_DR1_DBL = celdaNum.Text
            End If

            chdr.HDOC_DR2_EMP = celdaidClase.Text
            chdr.HDoc_Doc_Fec_NET = dtpFecha.Value.ToString(FORMATO_MYSQL)
            chdr.HDOC_EMP_COD = celdaIDCliente.Text
            chdr.HDOC_EMP_NOM = celdaNombre.Text
            chdr.HDOC_EMP_DIR = celdaDireccion.Text
            chdr.HDOC_EMP_NIT = celdaNIt.Text

            chdr.HDOC_DOC_MON = celdaIDMoneda.Text
            chdr.HDOC_DOC_TC = celdaTasaCambio.Text

            'Referencia y Cliente
            chdr.HDOC_DR1_CAT = celdaCreidtDay.Text
            If tipoFactura_YRM = 1 Then
                chdr.HDOC_DR1_NUM = celdaNumero.Text
            Else
                chdr.HDOC_DR1_NUM = celdaReferencia.Text
            End If

            chdr.HDOC_DR1_EMP = IIf(celdaIDCliente2.Text = STR_VACIO, celdaIDCliente.Text, celdaIDCliente2.Text)
            chdr.HDOC_RF1_COD = IIf(celdaCliente2.Text = STR_VACIO, celdaNombre.Text, celdaCliente2.Text)
            chdr.HDOC_RF2_TXT = celdaObservacion.Text


            chdr.HDOC_DR2_NUM = celdaRevision.Text
            chdr.HDOC_DOC_STATUS = If(checkActivo.Checked = True, 1, 0)
            chdr.HDOC_USUARIO = celdaUsuario.Text


            If Me.Tag = "Mod" Then
                If chdr.Actualizar() = False Then
                    MsgBox(chdr.MERROR.ToString & "Could not update the document", MsgBoxStyle.Critical)
                End If
            Else
                If chdr.Guardar() = False Then
                    MsgBox(chdr.MERROR.ToString & "Could not save the document", MsgBoxStyle.Critical)
                End If
            End If

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        Return logResultado
    End Function
    ' Borrar Encabezado 
    Private Function BorrarEncabezado() As Boolean
        Dim logGuardar As Boolean
        Dim intPais As Integer
        Dim chdr As New clsDcmtos_HDR
        Try
            chdr.CONEXION = strConexion

            chdr.HDOC_SIS_EMP = celdaIDEmpresa.Text
            chdr.HDOC_DOC_CAT = celdaCatalogo.Text
            chdr.HDOC_DOC_ANO = celdaAño.Text

            intPais = Pais()
            If intPais = 327 And Sesion.IdEmpresa = 14 Then
                chdr.HDOC_DOC_NUM = celdaNum.Text
                '  chdr.HDOC_DR1_DBL = celdaNumero.Text
            ElseIf Sesion.IdEmpresa = 12 And intPais = 310 Then
                chdr.HDOC_DOC_NUM = celdaNum.Text
                '  chdr.HDOC_DR1_DBL = celdaNumero.Text
            ElseIf Sesion.IdEmpresa = 16 And intPais = 310 Then
                chdr.HDOC_DOC_NUM = celdaNum.Text
            ElseIf Sesion.IdEmpresa = 11 Or Sesion.idGiro = 2 Then
                chdr.HDOC_DOC_NUM = celdaNum.Text
            Else
                chdr.HDOC_DOC_NUM = celdaNumero.Text
                '  chdr.HDOC_DR1_DBL = celdaNum.Text
            End If
            If LogBorrar = True Then
                If chdr.Borrar = False Then
                    MsgBox(chdr.MERROR.ToString & "Could not delete the document", MsgBoxStyle.Critical)
                    Return False
                Else
                    logGuardar = True
                End If
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        Return logGuardar
    End Function
    'Guardar el Detalle del modulo de Yarn Movement
    Private Function GuardarDetalle() As Boolean
        Dim logResultado As Boolean = True
        Dim Dtl As New clsDcmtos_DTL
        Dtl.CONEXION = strConexion
        Dim j As Integer = INT_CERO
        Dim i As Integer = INT_CERO
        Dim intPais As Integer = INT_CERO

        Try
            For i = 0 To dgDetalle.Rows.Count - 1
                Dtl.DDOC_SIS_EMP = celdaIDEmpresa.Text
                Dtl.DDOC_DOC_CAT = celdaCatalogo.Text
                Dtl.DDOC_DOC_ANO = celdaAño.Text
                intPais = Pais()
                If intPais = 327 And Sesion.IdEmpresa = 14 Or Sesion.IdEmpresa = 11 Or Sesion.idGiro = 2 Then
                    Dtl.DDOC_DOC_NUM = celdaNum.Text
                    '  chdr.HDOC_DR1_DBL = celdaNumero.Text
                ElseIf Sesion.IdEmpresa = 12 And intPais = 310 Then
                    Dtl.DDOC_DOC_NUM = celdaNum.Text
                    '  chdr.HDOC_DR1_DBL = celdaNumero.Text
                ElseIf Sesion.IdEmpresa = 16 And intPais = 310 Then
                    Dtl.DDOC_DOC_NUM = celdaNum.Text
                Else
                    Dtl.DDOC_DOC_NUM = celdaNumero.Text
                    '  chdr.HDOC_DR1_DBL = celdaNum.Text
                End If


                If Me.Tag = "Nuevo" Then
                    If dgDetalle.Rows(i).Visible = True Then
                        j = j + 1
                    End If
                    Dtl.DDOC_DOC_LIN = j
                Else
                    Dtl.DDOC_DOC_LIN = dgDetalle.Rows(i).Cells("colLineaYarn").Value
                End If

                Dtl.DDOC_PRD_COD = dgDetalle.Rows(i).Cells("colCodigo").Value
                Dtl.DDOC_PRD_DES = dgDetalle.Rows(i).Cells("colDescripcion").Value
                Dtl.DDOC_PRD_UM = dgDetalle.Rows(i).Cells("colUnidad").Value

                Dtl.DDOC_PRD_PUQ = CDbl(dgDetalle.Rows(i).Cells("colPrecio").Value)
                'Dtl.DDOC_PRD_DSP = CDbl(dgDetalle.Rows(i).Cells("colDesc").Value)
                'Dtl.DDOC_PRD_DSQ = CDbl(dgDetalle.Rows(i).Cells("colDescDolar").Value)
                Dtl.DDOC_PRD_NET = CDbl(dgDetalle.Rows(i).Cells("colPrecio").Value)
                Dtl.DDOC_PRD_QTY = CDbl(dgDetalle.Rows(i).Cells("colCantidad").Value)

                'Id del contrato (PM), pedido y referencia
                Dtl.DDOC_RF1_NUM = dgDetalle.Rows(i).Cells("colContrato").Value
                Dtl.DDOC_RF1_COD = dgDetalle.Rows(i).Cells("colPedido").Value
                Dtl.DDOC_RF1_TXT = dgDetalle.Rows(i).Cells("colRef").Value
                Dtl.DDOC_RF1_DBL = dgDetalle.Rows(i).Cells("colTotal").Value

                'Contenedor, forma de pago y cant. a restar (devuelta)
                Dtl.DDOC_RF2_COD = If(dgDetalle.Rows(i).Cells("colContenedor").Value = vbNullString, "NULL", dgDetalle.Rows(i).Cells("colContenedor").Value)
                Dtl.DDOC_RF2_TXT = dgDetalle.Rows(i).Cells("colPago").Value
                Dtl.DDOC_RF2_DBL = If(dgDetalle.Rows(i).Cells("colDevolucion").Value = vbNullString, "NULL", dgDetalle.Rows(i).Cells("colDevolucion").Value)

                'Notas y comentarios
                Dtl.DDOC_RF3_TXT = If(dgDetalle.Rows(i).Cells("colNotas").Value = vbNullString, "NULL", dgDetalle.Rows(i).Cells("colNotas").Value)

                'Carta de crédito
                Dtl.DDOC_PRD_REF = If(dgDetalle.Rows(i).Cells("colCredito").Value = vbNullString, " ", dgDetalle.Rows(i).Cells("colCredito").Value)

                'CIF, 'FOB
                Dtl.DDOC_PRD_CIF = dgDetalle.Rows(i).Cells("colTotal").Value
                Dtl.DDOC_PRD_FOB = dgDetalle.Rows(i).Cells("colTotal").Value


                If Me.Tag = "Mod" Then
                    If Dtl.Actualizar() = False Then
                        MsgBox(Dtl.MERROR.ToString & "Could not update the document", MsgBoxStyle.Critical)
                    End If
                ElseIf Me.Tag = "Nuevo" Then
                    If Dtl.Guardar() = False Then
                        MsgBox(Dtl.MERROR.ToString & "Could not save the document", MsgBoxStyle.Critical)
                    End If
                End If
            Next

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        Return logResultado
    End Function
    'Borrar Detalle  
    Private Function BorrarDetalle() As Boolean
        Dim logGuardar As Boolean
        Dim Dtl As New clsDcmtos_DTL
        Dim intPais As Integer
        Try
            Dtl.CONEXION = strConexion
            For i = 0 To dgDetalle.Rows.Count - 1
                Dtl.DDOC_SIS_EMP = celdaIDEmpresa.Text
                Dtl.DDOC_DOC_CAT = celdaCatalogo.Text
                Dtl.DDOC_DOC_ANO = celdaAño.Text
                intPais = Pais()
                If intPais = 327 And Sesion.IdEmpresa = 14 Then
                    Dtl.DDOC_DOC_NUM = celdaNum.Text
                    '  chdr.HDOC_DR1_DBL = celdaNumero.Text
                ElseIf Sesion.IdEmpresa = 12 And intPais = 310 Then
                    Dtl.DDOC_DOC_NUM = celdaNum.Text
                    '  chdr.HDOC_DR1_DBL = celdaNumero.Text
                ElseIf Sesion.IdEmpresa = 16 And intPais = 310 Then
                    Dtl.DDOC_DOC_NUM = celdaNum.Text
                ElseIf Sesion.IdEmpresa = 11 Or Sesion.idGiro = 2 Then
                    Dtl.DDOC_DOC_NUM = celdaNum.Text
                Else
                    Dtl.DDOC_DOC_NUM = celdaNumero.Text
                    '  chdr.HDOC_DR1_DBL = celdaNum.Text
                End If
                Dtl.DDOC_DOC_LIN = dgDetalle.Rows(i).Cells("colLineaYarn").Value
                If LogBorrar = True Then
                    If Dtl.Borrar = False Then
                        MsgBox(Dtl.MERROR.ToString & "Could not delete the document", MsgBoxStyle.Critical)
                        Return False
                    Else
                        logGuardar = True
                    End If
                End If
            Next
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        Return logGuardar
    End Function
    'Guarda el descargo de Yarn Movement con Facturacion
    Private Sub GuargarDescargos()
        Dim clsDTLPro As New clsDcmtos_DTL_Pro
        Dim cfun As New clsFunciones
        Dim intPais As Integer
        Dim logResultado As Boolean = True
        Dim j As Integer = 0

        Try


            clsDTLPro.CONEXION = strConexion

            For i As Integer = 0 To dgDetalle.Rows.Count - 1

                'Documento a ser descargado
                clsDTLPro.PDOC_SIS_EMP = Sesion.IdEmpresa
                clsDTLPro.PDOC_PAR_CAT = 36
                clsDTLPro.PDOC_PAR_ANO = dgDetalle.Rows(i).Cells("colAnio").Value

                clsDTLPro.PDOC_PAR_LIN = dgDetalle.Rows(i).Cells("colLinea").Value

                'Referencia al documento actual
                clsDTLPro.PDOC_CHI_CAT = celdaCatalogo.Text
                clsDTLPro.PDOC_CHI_ANO = Val(celdaAño.Text)

                intPais = Pais()
                If intPais = 327 And Sesion.IdEmpresa = 14 Then
                    clsDTLPro.PDOC_CHI_NUM = celdaNum.Text
                    clsDTLPro.PDOC_PAR_NUM = celdaNum.Text
                ElseIf Sesion.IdEmpresa = 12 And intPais = 310 Then
                    clsDTLPro.PDOC_CHI_NUM = celdaNum.Text
                    clsDTLPro.PDOC_PAR_NUM = celdaNum.Text
                ElseIf Sesion.IdEmpresa = 16 And intPais = 310 Then
                    clsDTLPro.PDOC_CHI_NUM = celdaNum.Text
                    clsDTLPro.PDOC_PAR_NUM = celdaNum.Text
                ElseIf Sesion.IdEmpresa = 11 Or Sesion.idGiro = 2 Then
                    clsDTLPro.PDOC_CHI_NUM = celdaNum.Text
                    clsDTLPro.PDOC_PAR_NUM = celdaNum.Text
                Else
                    clsDTLPro.PDOC_CHI_NUM = celdaNumero.Text
                    clsDTLPro.PDOC_PAR_NUM = celdaNumero.Text
                End If

                'If Sesion.IdEmpresa = 12 And Pais() = 310 Then
                '    clsDTLPro.PDOC_CHI_NUM = Val(celdaNumero.Text)
                'Else
                '    clsDTLPro.PDOC_CHI_NUM = Val(celdaNum.Text)
                'End If

                clsDTLPro.PDOC_CHI_LIN = dgDetalle.Rows(i).Cells("colLineaYarn").Value

                'Empresa relacionada al doc. actual
                If STR_NOMBRE = "proveedor" Then
                    clsDTLPro.PDOC_PROV_COD = celdaIDCliente.Text
                Else
                    clsDTLPro.PDOC_CLTE_COD = celdaIDCliente.Text
                End If

                'Referencia al producto y despacho
                clsDTLPro.PDOC_PRD_COD = dgDetalle.Rows(i).Cells("colCodigo").Value
                clsDTLPro.PDOC_PRD_PNR = "N/A"
                clsDTLPro.PDOC_DR1_NUM = INT_CERO
                clsDTLPro.PDOC_DR2_NUM = INT_CERO
                clsDTLPro.PDOC_PRD_NET = dgDetalle.Rows(i).Cells("colPrecio").Value
                clsDTLPro.PDOC_QTY_ORD = dgDetalle.Rows(i).Cells("colCantidad").Value
                clsDTLPro.PDOC_QTY_PRO = dgDetalle.Rows(i).Cells("colCantidad").Value

                If Me.Tag = "Mod" Then
                    If clsDTLPro.Actualizar() = False Then
                        MsgBox(clsDTLPro.MERROR.ToString)
                    End If

                ElseIf Me.Tag = "Nuevo" Then
                    If clsDTLPro.Guardar() = False Then
                        MsgBox(clsDTLPro.MERROR.ToString)
                    End If
                End If
            Next
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub
    Private Function BorrarDescargo() As Boolean
        Dim logGuardar As Boolean
        Dim intPais As Integer
        Dim clsDTLPro As New clsDcmtos_DTL_Pro
        Try
            For i As Integer = 0 To dgDetalle.Rows.Count - 1
                clsDTLPro.PDOC_SIS_EMP = Sesion.IdEmpresa
                clsDTLPro.PDOC_PAR_CAT = 36
                clsDTLPro.PDOC_PAR_ANO = dgDetalle.Rows(i).Cells("colAnio").Value
                clsDTLPro.PDOC_PAR_LIN = dgDetalle.Rows(i).Cells("colLinea").Value

                clsDTLPro.PDOC_CHI_CAT = celdaCatalogo.Text
                clsDTLPro.PDOC_CHI_ANO = Val(celdaAño.Text)


                intPais = Pais()
                If intPais = 327 And Sesion.IdEmpresa = 14 Then
                    clsDTLPro.PDOC_CHI_NUM = celdaNum.Text
                    clsDTLPro.PDOC_PAR_NUM = celdaNum.Text
                ElseIf Sesion.IdEmpresa = 12 And intPais = 310 Then
                    clsDTLPro.PDOC_CHI_NUM = celdaNum.Text
                    clsDTLPro.PDOC_PAR_NUM = celdaNum.Text
                ElseIf Sesion.IdEmpresa = 16 And intPais = 310 Then
                    clsDTLPro.PDOC_CHI_NUM = celdaNum.Text
                    clsDTLPro.PDOC_PAR_NUM = celdaNum.Text
                ElseIf Sesion.IdEmpresa = 11 Or Sesion.idGiro = 2 Then
                    clsDTLPro.PDOC_CHI_NUM = celdaNum.Text
                    clsDTLPro.PDOC_PAR_NUM = celdaNum.Text
                Else
                    clsDTLPro.PDOC_CHI_NUM = celdaNumero.Text
                    clsDTLPro.PDOC_PAR_NUM = celdaNumero.Text
                End If

                'If Sesion.IdEmpresa = 12 And Pais() = 310 Then
                '    clsDTLPro.PDOC_CHI_NUM = Val(celdaNumero.Text)
                'Else
                '    clsDTLPro.PDOC_CHI_NUM = Val(celdaNum.Text)
                'End If


                clsDTLPro.PDOC_CHI_LIN = dgDetalle.Rows(i).Cells("colLineaYarn").Value
                If LogBorrar = True Then
                    If clsDTLPro.Borrar = False Then
                        MsgBox(clsDTLPro.MERROR.ToString & "Could not delete the document", MsgBoxStyle.Critical)
                        Return False
                    Else
                        logGuardar = True
                    End If
                End If
            Next
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        Return logGuardar
    End Function
    'Actualiza el cliente (para CxC) y días de plazo en la factura
    Private Sub ActualizarFactura(ByVal dblTipoFact As Integer)
        Dim i As Integer = INT_CERO
        Dim strSQL As String = STR_VACIO
        Dim COM As MySqlCommand

        For i = INT_CERO To dgDocs.Rows.Count - 1

            strSQL = "UPDATE Dcmtos_HDR "
            strSQL &= "     SET HDoc_DR1_Emp={idcliente}, HDoc_RF2_Num={diascredito}"
            strSQL &= "          WHERE HDoc_Sis_Emp={empresa} AND HDoc_Doc_Cat=36 AND HDoc_Doc_Ano={anio} AND HDoc_Doc_Num={numero}"

            strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
            strSQL = Replace(strSQL, "{anio}", dgDocs.Rows(i).Cells("colAño").Value)
            'If Sesion.IdEmpresa = 12 And IDEmpresa() = 310 Or Sesion.IdEmpresa = 14 And IDEmpresa() = 327 Then
            '    strSQL = Replace(strSQL, "{numero}", dgDocs.Rows(i).Cells("colNumero").Value)
            'Else
            strSQL = Replace(strSQL, "{numero}", dgDocs.Rows(i).Cells("colNumReal").Value)
            'End If
            If dblTipoFact = 0 Then
                strSQL = Replace(strSQL, "{idcliente}", celdaIDCliente2.Text)
                strSQL = Replace(strSQL, "{diascredito}", celdaCreidtDay.Text)
            Else
                strSQL = Replace(strSQL, "{idcliente}", celdaIDCliente.Text)
                strSQL = Replace(strSQL, "{diascredito}", celdaCreidtDay.Text)
            End If

            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSQL, CON)
            COM.ExecuteNonQuery()
        Next
    End Sub

    Private Sub CargarDocumento()
        Dim strSQL As String = STR_VACIO
        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader
        Dim intPais As Integer = INT_CERO
        Dim Referencia As String = STR_VACIO
        Dim arrayRef As Array
        Dim strCadena As String = STR_VACIO
        Dim arrayCadena() As String

        Try
            strSQL = "SELECT e.HDoc_Sis_Emp IDempresa, e.HDoc_Doc_Cat tipo, e.HDoc_Doc_Ano anio, e.HDoc_Doc_Num num, e.HDoc_DR1_Dbl NumReal, e.HDoc_Doc_Fec fecha, e.HDoc_Emp_Cod idcliente, e.HDoc_Emp_Nom empresa, e.HDoc_Emp_Dir direccion, e.HDoc_Emp_NIT nit, e.HDoc_DR1_Cat dias, e.HDoc_DR1_Num referencia, e.HDoc_DR1_Dbl numfalse, IFNULL(e.HDoc_DR1_Emp,e.HDoc_Emp_Cod) cliente, e.HDoc_Usuario usuario, e.HDoc_Doc_TC tasa, e.HDoc_Doc_Mon moneda, e.HDoc_Doc_Status estado,  e.HDoc_RF1_Cod codcliente, c.cat_clave mon, IFNULL(cli.cli_cliente,e.HDoc_Emp_Nom) cliente2, e.HDoc_RF2_Txt observaciones, ifnull(cl.cat_num,-1) idClase , ifnull(cl.cat_desc,'N/A') Clase,IFNULL(f.Serie,'') Serie, IFNULL(f.NumeroAutorizacion,'') Autorizacion  "
            strSQL &= " FROM Dcmtos_HDR e"
            strSQL &= "    LEFT JOIN Catalogos c On c.cat_num = e.HDoc_Doc_Mon"
            strSQL &= "    LEFT JOIN Clientes cli On cli.cli_codigo  = e.HDoc_DR1_Emp "
            strSQL &= "     left join Catalogos cl on cl.cat_num = e.HDoc_DR2_Emp "
            strSQL &= "         LEFT JOIN Dcmtos_DTL_Pro dp ON dp.PDoc_Sis_Emp = e.HDoc_Sis_Emp AND dp.PDoc_Chi_Cat = e.HDoc_Doc_Cat AND dp.PDoc_Chi_Ano = e.HDoc_Doc_Ano AND dp.PDoc_Chi_Num = e.HDoc_Doc_Num AND  dp.PDoc_Par_Cat = 36  "
            strSQL &= "             LEFT JOIN Fel f ON f.Empresa = dp.PDoc_Sis_Emp AND f.Catalogo = dp.PDoc_Par_Cat AND f.Anio = dp.PDoc_Par_Ano AND f.Numero = dp.PDoc_Par_Num  "
            strSQL &= " WHERE e.HDoc_Sis_Emp={empresa} AND e.HDoc_Doc_Cat=395 AND e.HDoc_Doc_Ano={anio} AND e.HDoc_Doc_Num ={num}"

            strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
            strSQL = Replace(strSQL, "{anio}", dgLista.CurrentRow.Cells("colYear").Value)
            intPais = Pais()
            If (Sesion.IdEmpresa = 14 And intPais = 327) Or (Sesion.IdEmpresa = 12 And intPais = 310) Or (Sesion.IdEmpresa = 16 And intPais = 310) Or Sesion.IdEmpresa = 11 Or Sesion.idGiro = 2 Then
                strSQL = Replace(strSQL, "{num}", dgLista.CurrentRow.Cells("colNumVerdadero").Value)
            Else
                strSQL = Replace(strSQL, "{num}", dgLista.CurrentRow.Cells("colID").Value)
            End If


            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSQL, CON)
            REA = COM.ExecuteReader

            If REA.HasRows Then
                REA.Read()

                celdaCatalogo.Text = REA.GetInt32("tipo")
                celdaAño.Text = REA.GetInt32("anio")
                If (Sesion.IdEmpresa = 14 And intPais = 327) Or (Sesion.IdEmpresa = 12 And intPais = 310) Or (Sesion.IdEmpresa = 16 And intPais = 310) Or Sesion.IdEmpresa = 11 Or Sesion.idGiro = 2 Then
                    celdaNumero.Text = REA.GetInt32("NumReal")
                    celdaNum.Text = REA.GetInt32("num")
                Else
                    celdaNumero.Text = REA.GetInt32("num")
                    celdaNum.Text = REA.GetInt32("NumReal")
                End If
              
                dtpFecha.Value = REA.GetDateTime("fecha")
                celdaIDEmpresa.Text = REA.GetInt32("idempresa")
                celdaNombre.Text = REA.GetString("empresa")
                celdaIDCliente.Text = REA.GetInt32("idcliente")
                celdaDireccion.Text = REA.GetString("direccion")
                celdaNIt.Text = REA.GetString("nit")
                celdaUsuario.Text = REA.GetString("usuario")
                celdaTasaCambio.Text = REA.GetDouble("tasa")
                celdaIDMoneda.Text = REA.GetInt32("moneda")

                celdaCreidtDay.Text = REA.GetInt32("dias")

                celdaIDCliente2.Text = REA.GetInt32("cliente")
                celdaCliente2.Text = REA.GetString("cliente2")

                celdaidClase.Text = REA.GetInt32("idClase")
                celdaClase.Text = REA.GetString("Clase")

                Referencia = REA.GetString("referencia")
                arrayRef = Referencia.Split("-".ToCharArray)
                If arrayRef(0) = "YRM" Then
                    celdaReferencia.Text = REA.GetString("referencia")
                Else
                    celdaReferencia.Text = "YRM" & "-" & REA.GetString("referencia")
                End If

                celdaTasaCambio.Text = REA.GetDouble("tasa")
                celdaMoneda.Text = REA.GetString("mon")
                celdaIDMoneda.Text = REA.GetInt32("moneda")
                celdaObservacion.Text = REA.GetString("observaciones")

                If REA.GetInt32("estado") = 1 Then
                    checkActivo.Checked = True
                Else
                    checkActivo.Checked = False
                End If
                If Sesion.IdEmpresa = 12 And Pais() = 0 Then
                    strCadena = REA.GetString("Serie")
                    arrayCadena = strCadena.Split("-".ToCharArray)
                    etiquetaSerie.Text = arrayCadena(INT_CERO)
                    etiquetaAutorizacion.Text = REA.GetString("Autorizacion")
                    etiquetaSerie.Visible = True
                    etiquetaAutorizacion.Visible = True
                End If

            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try

    End Sub

    Private Sub CargarDetalle()
        Dim strSQL As String = STR_VACIO
        Dim strFila As String = STR_VACIO
        Dim i As Integer = INT_CERO
        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader
        Dim intPais As Integer = INT_CERO

        Try
            strSQL = "SELECT d.DDoc_Sis_Emp empresa, d.DDoc_Doc_Cat tipo, d.DDoc_Prd_Cod codigo, ifnull(a.art_DCorta, d.DDoc_Prd_Des) descripcion, COALESCE(c.cat_clave,'') medida, d.DDoc_Prd_UM unidad, d.DDoc_Prd_Net precio, d.DDoc_Prd_Qty cantidad, (d.DDoc_Prd_NET * d.DDoc_Prd_Qty) total, COALESCE(d.DDoc_RF3_Num, d.DDoc_Prd_UM) conversion,"
            strSQL &= "  0 saldo, COALESCE(p.PDoc_Par_Ano,0) anio, COALESCE(p.PDoc_Par_Num,0) numero, COALESCE(p.PDoc_Par_Lin,0) lineafac, COALESCE(p.PDoc_Chi_Lin,0) lineayarn, COALESCE(d.DDoc_RF1_Txt,'') referencia, COALESCE(d.DDoc_RF1_Cod,'') pedido, COALESCE(d.DDoc_RF2_Cod,'') contenedor, COALESCE(d.DDoc_RF2_Txt,'') pago, COALESCE(d.DDoc_Prd_Ref,'') credito, COALESCE(d.DDoc_RF1_Num,0) contrato, d.DDoc_RF2_Dbl revision, IFNULL(d.DDoc_RF3_Txt,'') notas,"
            strSQL &= "          (   SELECT IFNULL(de.DDoc_RF2_Txt,' ')"
            strSQL &= "                  FROM Dcmtos_DTL_Pro p"
            strSQL &= "                          LEFT JOIN Dcmtos_DTL_Pro pro on pro.PDoc_Sis_Emp = p.PDoc_Sis_Emp and pro.PDoc_Chi_Cat = p.PDoc_Par_Cat and pro.PDoc_Chi_Ano = p.PDoc_Par_Ano and pro.PDoc_Chi_Num = p.PDoc_Par_Num and pro.PDoc_Chi_Lin = p.PDoc_Par_Lin"
            strSQL &= "                                 LEFT JOIN Dcmtos_DTL_Pro dt on dt.PDoc_Sis_Emp = pro.PDoc_Sis_Emp and dt.PDoc_Chi_Cat = pro.PDoc_Par_Cat and dt.PDoc_Chi_Ano = pro.PDoc_Par_Ano and dt.PDoc_Chi_Num = pro.PDoc_Par_Num and dt.PDoc_Chi_Lin = pro.PDoc_Par_Lin and dt.PDoc_Par_Cat = 75"
            strSQL &= "                                      LEFT JOIN Dcmtos_DTL de on de.DDoc_Sis_Emp = dt.PDoc_Sis_Emp and de.DDoc_Doc_Cat = dt.PDoc_Par_Cat and de.DDoc_Doc_Ano = dt.PDoc_Par_Ano and de.DDoc_Doc_Num = dt.PDoc_Par_Num and de.DDoc_Doc_Lin = dt.PDoc_Par_Lin"
            strSQL &= "                                             where p.PDoc_Sis_Emp = d.DDoc_Sis_Emp  and p.PDoc_Chi_Cat = d.DDoc_Doc_Cat and p.PDoc_Chi_Num = d.DDoc_Doc_Num and p.PDoc_Chi_Ano = d.DDoc_Doc_Ano and p.PDoc_Chi_Lin = 1) comentario"
            strSQL &= "                                      FROM Dcmtos_DTL d"
            strSQL &= "                                 LEFT JOIN Dcmtos_DTL_Pro p ON p.PDoc_Sis_Emp = d.DDoc_Sis_Emp AND p.PDoc_Par_Cat = 36 AND p.PDoc_Chi_Cat = 395 AND p.PDoc_Chi_Ano = d.DDoc_Doc_Ano AND p.PDoc_Chi_Num = d.DDoc_Doc_Num AND p.PDoc_Chi_Lin = d.DDoc_Doc_Lin"
            strSQL &= "                           LEFT JOIN Catalogos c ON c.cat_clase = 'Medidas' AND c.cat_num = d.DDoc_Prd_UM"
            strSQL &= "                 LEFT JOIN Inventarios i ON i.inv_sisemp = {empresa} AND i.inv_numero = d.DDoc_Prd_Cod"
            strSQL &= "               LEFT JOIN Articulos a ON a.art_sisemp = i.inv_sisemp AND a.art_codigo = i.inv_artcodigo"
            strSQL &= "            WHERE d.DDoc_Sis_Emp = {empresa} AND d.DDoc_Doc_Cat = 395 AND d.DDoc_Doc_Ano = {anio} AND d.DDoc_Doc_Num = {num}"
            strSQL &= "          GROUP BY d.DDoc_Doc_Cat, d.DDoc_Doc_Ano, d.DDoc_Doc_Num, d.DDoc_Doc_Lin"
            strSQL &= "      ORDER BY d.DDoc_Doc_Lin"

            strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
            strSQL = Replace(strSQL, "{anio}", dgLista.CurrentRow.Cells("colYear").Value)
            intPais = Pais()
            If (Sesion.IdEmpresa = 14 And intPais = 327) Or (Sesion.IdEmpresa = 12 And intPais = 310) Or (Sesion.IdEmpresa = 16 And intPais = 310) Or Sesion.IdEmpresa = 11 Or Sesion.idGiro = 2 Then
                strSQL = Replace(strSQL, "{num}", celdaNum.Text)
            Else
                strSQL = Replace(strSQL, "{num}", dgLista.CurrentRow.Cells("colID").Value)
            End If


            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSQL, CON)
            REA = COM.ExecuteReader

            If REA.HasRows Then
                Do While REA.Read()

                    strFila = REA.GetInt32("empresa") & "|"
                    strFila &= REA.GetInt32("tipo") & "|"
                    strFila &= REA.GetInt32("anio") & "|"
                    strFila &= REA.GetInt32("numero") & "|"
                    strFila &= REA.GetInt32("codigo") & "|"
                    strFila &= REA.GetString("descripcion") & "|"
                    strFila &= REA.GetString("medida") & "|"
                    strFila &= REA.GetInt32("unidad") & "|"
                    strFila &= REA.GetDouble("precio") & "|"
                    strFila &= REA.GetDouble("cantidad") & "|"
                    strFila &= REA.GetDouble("revision") & "|"
                    strFila &= REA.GetDouble("total").ToString("###0.00") & "|"
                    strFila &= REA.GetInt32("lineafac") & "|"
                    strFila &= REA.GetInt32("lineayarn") & "|"
                    strFila &= REA.GetString("referencia") & "|"
                    strFila &= REA.GetString("pago") & "|"
                    strFila &= IIf(REA.GetString("credito") = "NULL", vbNullString, REA.GetString("credito")) & "|"
                    strFila &= IIf(REA.GetString("pedido") = "NULL", vbNullString, REA.GetString("pedido")) & "|"
                    strFila &= IIf(REA.GetString("contenedor") = "NULL", vbNullString, REA.GetString("contenedor")) & "|"
                    strFila &= IIf(REA.GetString("notas") = "NULL", vbNullString, REA.GetString("notas")) & "|"
                    strFila &= IIf(REA.GetString("contrato") = "NULL", vbNullString, REA.GetString("contrato")) & "|"
                    strFila &= REA.GetInt32("revision") & "|"
                    strFila &= REA.GetString("comentario")

                    cFunciones.AgregarFila(dgDetalle, strFila)
                Loop
            End If

            If Not (dgDetalle.Rows.Count = NO_FILA) Then
                MostrarInfo((dgDetalle.CurrentRow.Cells(13).Value))
            End If

            'calcular totales
            CalcularTotales()

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub MarcarPedidos()
        'Recorre el detalle para listar los pedidos
        Dim i As Integer = INT_CERO
        Dim k As Integer = INT_CERO

        For i = 0 To dgDetalle.Rows.Count - 1

        Next
    End Sub

    Private Function Pais()
        Dim strSQL2 As String
        Dim COM2 As New MySqlCommand
        Dim conec2 As New MySqlConnection
        Dim intPais As Integer

        strSQL2 = "SELECT e.emp_pais "
        strSQL2 &= "     FROM Empresas e"
        strSQL2 &= "         WHERE e.emp_no = {empresa} "

        strSQL2 = Replace(strSQL2, "{empresa}", Sesion.IdEmpresa)
        conec2 = New MySqlConnection(strConexion)
        conec2.Open()
        COM2 = New MySqlCommand(strSQL2, conec2)
        Using conec2
            intPais = COM2.ExecuteScalar
            COM2.Dispose()
            COM2 = Nothing
            conec2.Close()
            conec2.Dispose()
            conec2 = Nothing
            System.GC.Collect()
        End Using

        Return intPais
    End Function
    Private Function Dependencias() As Integer
        Dim strSQL As String = STR_VACIO
        Dim COM As MySqlCommand
        Dim conec As MySqlConnection
        Dim intValidacion As Integer
        strSQL = "  SELECT COUNT(*) "
        strSQL &= "     FROM Dcmtos_DTL_Pro a "
        strSQL &= "         WHERE a.PDoc_Sis_Emp = {empresa} AND a.PDoc_Par_Cat = 395 AND a.PDoc_Par_Ano = {anio} AND a.PDoc_Par_Num = {numero} "
        strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
        strSQL = Replace(strSQL, "{anio}", celdaAño.Text)
        strSQL = Replace(strSQL, "{numero}", celdaNumero.Text)
        conec = New MySqlConnection(strConexion)
        conec.Open()
        COM = New MySqlCommand(strSQL, conec)
        Using conec
            intValidacion = COM.ExecuteScalar
            COM.Dispose()
            COM = Nothing
            conec.Close()
            conec.Dispose()
            conec = Nothing
            System.GC.Collect()
        End Using
        Return intValidacion
    End Function
#End Region

#Region "Eventos"

    Private Sub Buscar2(ByVal texto As String)
        'Por defecto, indico buscar en la primera columna
        Dim indiceColumna As Integer = 5
        'Recorro filas del DataGridView
        For Each row As DataGridViewRow In dgLista.Rows
            'Si el contenido de la columna coinside con el valor del TextBox
            If InStr(CStr(row.Cells(indiceColumna).Value).ToLower, texto.ToLower) > 0 Then
                'Selecciono fila y abandono bucle
                row.Selected = True
                dgLista.CurrentCell = dgLista.Rows(row.Index).Cells(0)
                Exit For
            End If
        Next
    End Sub

    Private Sub frmYarnMovementV_FormClosing(sender As Object, e As FormClosingEventArgs) Handles Me.FormClosing
        'frmSPrincipal.BarraDeTareas1.QuitarFormulario(strkey)
        Fprincipal.BarraDeTareas1.QuitarFormulario(strkey)
    End Sub

    Private Sub frmYarnMovementV_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        checkFecha.Checked = True
        dtpFechaFin.Value = Today
        dtpFechaInicio.Value = Today.AddDays(-10)

        'CargarSQLlista()
        Accessos()
        MostrarLista()
    End Sub

    Private Sub Encabezado1_ClickNuevo(sender As Object, click As Boolean) Handles Encabezado1.ClickNuevo
        If logInsertar = True Then
            MostrarLista(False)

            LimpiarPanelOrden()
            celdaAño.Text = cFunciones.AñoMySQL
            celdaIDEmpresa.Text = Sesion.IdEmpresa
            celdaCatalogo.Text = 395
            celdaUsuario.Text = Sesion.Usuario
            celdaTasaCambio.Text = cFunciones.QueryTasa("CURDATE()")
            checkActivo.Checked = True
        Else
            MsgBox("You do not have permission to create a new document", vbCritical, "Notice")
        End If

    End Sub

    Private Sub Encabezado1_ClickCerrar(sender As Object, click As Boolean) Handles Encabezado1.ClickCerrar

        If panelDocumento.Visible = True Then
            MostrarLista()
        Else
            Me.Close()
        End If
        'dgReferencia.Rows.Clear()
    End Sub

    Private Sub Imprimir()
        Dim intID As Integer = NO_FILA
        Dim intAño As Integer = NO_FILA
        Try
            If dgLista.SelectedRows.Count = INT_CERO Then Exit Sub
            Me.Tag = "mod"

            intID = dgLista.SelectedCells(0).Value
            intAño = dgLista.SelectedCells(1).Value
            Dim crep As New clsReportes
            crep.GenerarYarnMovement(395, intAño, intID)

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub botonInprimir_Click(sender As Object, e As EventArgs) Handles botonInprimir.Click

        Dim intResp As Integer = INT_CERO
        Dim intNum As Integer = INT_CERO
        Dim intNumLin As Integer = INT_CERO
        Dim intAño As Integer = INT_CERO
        Dim strCarta As String = STR_VACIO
        Dim strPago As String = STR_VACIO
        Dim strRef As String = STR_VACIO
        Dim strTemp As String = STR_VACIO
        Dim strLetra As String = STR_VACIO
        Dim arrayFila3() As String
        Dim op As New frmOption
        Dim intRespuesta2 As Integer = INT_CERO
        Dim intRespuesta4 As Integer = INT_CERO
        Dim Yrm As New clsReportes
        Dim letters() As String
        Dim j As Integer
        Dim Letra As String = STR_VACIO
        Dim strFormaPago As String = STR_VACIO
        Dim arrayFila4() As String
        Dim intCuenta As Integer = INT_CERO
        Dim strTipoPago As String = STR_VACIO


        If (Sesion.IdEmpresa = 12 And Pais() = 310) Or (Sesion.IdEmpresa = 16 Or Sesion.IdEmpresa = 14) Or Sesion.IdEmpresa = 11 Or Sesion.idGiro = 2 Then
            intNum = celdaNum.Text
            intAño = celdaAño.Text
        Else
            intNum = celdaNumero.Text
            intAño = celdaAño.Text
        End If
      


        Dim opt As New frmOption
        Dim intRespuesta As Integer = INT_CERO
        opt.Titulo = "Print Yarn Movement"
        opt.Mensaje = "Select an option"
        opt.Opciones = "Yarn Movement" & "|" & "For Invoice"
        If opt.ShowDialog = System.Windows.Forms.DialogResult.OK Then

            Select Case opt.Seleccion

                Case 0
                    intRespuesta = INT_CERO
                Case 1
                    intRespuesta = INT_UNO

            End Select
        Else
            Exit Sub
        End If

        letters = {"A", "B", "C", "D", "F", "G", "H", "I", "J", "K", "L", "M", "N", "Ñ", "O", "P", "Q", "R", "S", "T", "U", "V", "W", "X", "Y", "Z"}


        For i As Integer = INT_CERO To dgDetalle.Rows.Count - 1
            If strRef = STR_VACIO Then
                strRef = dgDetalle.Rows(i).Cells("colPago").Value
            ElseIf strRef = dgDetalle.Rows(i).Cells("colPago").Value Then
                strRef = dgDetalle.Rows(i).Cells("colPago").Value
            Else
                strRef = strRef & "-" & dgDetalle.Rows(i).Cells("colPago").Value
            End If
        Next


        arrayFila4 = strRef.Split("-".ToCharArray)

        If intRespuesta = INT_CERO Then
            If dgDetalle.Rows.Count = 1 Or arrayFila4.Length = 1 Then
                'Cuando hay una sola linea
                strRef = celdaNumero.Text
                strRef = strRef & "/"
                strPago = dgDetalle.CurrentRow.Cells("colPago").Value
                strTemp = dgDetalle.CurrentRow.Cells("colCredito").Value
            ElseIf dgDetalle.Rows.Count > 1 And arrayFila4.Length > 1 Then
                'Cuando hay varias lineas
                For i = 0 To dgDetalle.Rows.Count - 1
                    For j = i To dgDetalle.Rows.Count - 1
                        strLetra = letters(i)
                    Next
                    If Not (i = 0) And Not (strPago = dgDetalle.Rows(i).Cells("colPago").Value) Then
                        strPago = strPago & "," & dgDetalle.Rows(i).Cells("colNum").Value & "/" & strLetra & " - " & dgDetalle.Rows(i).Cells("colPago").Value & IIf(dgDetalle.Rows(i).Cells("colCredito").Value = vbNullString, vbNullString, " - " & dgDetalle.Rows(i).Cells("colCredito").Value)
                    ElseIf i = 0 Then
                        strPago = dgDetalle.Rows(i).Cells("colNum").Value & "/" & strLetra & " - " & dgDetalle.Rows(i).Cells("colPago").Value & IIf(dgDetalle.Rows(i).Cells("colCredito").Value = vbNullString, vbNullString, " - " & dgDetalle.Rows(i).Cells("colCredito").Value)
                    End If
                Next

                strTemp = strPago
                arrayFila3 = strPago.Split(",".ToCharArray)
                For i = 0 To arrayFila3.Length - 1
                    op.Titulo = "Pay"
                    op.Mensaje = "Select the line to print"
                    If i = 0 Then
                        strRef = arrayFila3(i)
                    Else
                        strRef = strRef & "|" & arrayFila3(i)
                    End If

                Next
                op.Opciones = strRef
                If op.ShowDialog = System.Windows.Forms.DialogResult.OK Then
                    Select Case op.Seleccion

                        Case 0
                            intRespuesta2 = 0
                        Case 1
                            intRespuesta2 = 1
                        Case 2
                            intRespuesta2 = 2

                    End Select
                Else
                    Exit Sub
                End If
                strPago = arrayFila3(intRespuesta2)
            End If

            Yrm.ReporteYarnMovementRequisition(intAño, intNum, strPago, strTemp, dgDetalle.Rows.Count, arrayFila4.Length)

        Else
            Dim opt2 As New frmOption
            Dim intRespuesta3 As Integer = INT_CERO
            opt2.Titulo = "Print Invoice"
            opt2.Mensaje = "Select an option to print"
            opt2.Opciones = "Invoice" & "|" & "Invoice 2"
            If opt2.ShowDialog = System.Windows.Forms.DialogResult.OK Then

                Select Case opt2.Seleccion

                    Case 0
                        intRespuesta3 = INT_CERO
                    Case 1
                        intRespuesta3 = INT_UNO

                End Select
            Else
                Exit Sub
            End If

            If MsgBox("Want to print Bank account information", vbYesNo, vbQuestion) = MsgBoxResult.Yes Then
                intCuenta = INT_UNO
                Dim opt3 As New frmOption
                If Sesion.IdEmpresa = 12 And Pais() = 0 Then
                    opt3.Titulo = "Print BANK"
                    opt3.Mensaje = "Select an option to print"
                    opt3.Opciones = "TD Bank" & "|" & "BI"
                    If opt3.ShowDialog = System.Windows.Forms.DialogResult.OK Then
                        Select Case opt3.Seleccion

                            Case 0
                                intRespuesta4 = INT_UNO
                            Case 1
                                intRespuesta4 = INT_CERO

                        End Select
                    Else
                        Exit Sub
                    End If
                ElseIf Sesion.IdEmpresa = 11 Then
                    opt3.Titulo = "Print BANK"
                    opt3.Mensaje = "Select an option to print"
                    opt3.Opciones = "TD Bank" & "|" & "Ficohsa" & "|" & "BANCO ATLANTIDA"
                    If opt3.ShowDialog = System.Windows.Forms.DialogResult.OK Then
                        Select Case opt3.Seleccion
                            Case 0
                                intRespuesta4 = INT_UNO
                            Case 1
                                intRespuesta4 = INT_CERO
                            Case 2
                                intRespuesta4 = 2
                        End Select
                    Else
                        Exit Sub
                    End If
                ElseIf Sesion.IdEmpresa = 16 Then
                    opt3.Titulo = "Print BANK"
                    opt3.Mensaje = "Select an option to print"
                    opt3.Opciones = "TD Bank" & "|" & "BANCO AGRÍCOLA"
                    If opt3.ShowDialog = System.Windows.Forms.DialogResult.OK Then
                        Select Case opt3.Seleccion
                            Case 0
                                intRespuesta4 = INT_UNO
                            Case 1
                                intRespuesta4 = INT_CERO

                        End Select
                    Else
                        Exit Sub
                    End If

                End If
            Else
                    intCuenta = INT_CERO
            End If

            If intRespuesta3 = INT_CERO Then
                Yrm.ReporteInvoice(intAño, intNum, intCuenta, intRespuesta4)
            ElseIf intRespuesta3 = INT_UNO Then
                Yrm.ReporteInvoice2(intAño, intNum, intCuenta, intRespuesta4)
            End If


        End If




    End Sub

    Private Sub dgLista_DoubleClick(sender As Object, e As EventArgs) Handles dgLista.DoubleClick
        LimpiarPanelOrden()
        Me.Tag = "Mod"
        MostrarLista(False)
        Try

            'Carga el encabezado
            CargarDocumento()

            'carga el detalle
            CargarDetalle()

            celdaAño.Enabled = False
            celdaNumero.Enabled = False

            CargarDocsPendientes()


        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try

    End Sub

    Private Sub dgLista_KeyDown(sender As Object, e As KeyEventArgs) Handles dgLista.KeyDown
        Dim strTexto As String = STR_VACIO
        Try
            If e.KeyCode = Keys.F3 Then
                strTexto = InputBox("Buscar")
                ' MsgBox(Buscar("Reference", strTexto, b))
                Buscar2(strTexto)
                e.Handled = True
                e.SuppressKeyPress = True
            ElseIf e.KeyCode = Keys.F6 Then
                cFunciones.MostrarDependencias(395, dgLista.SelectedCells(0).Value, dgLista.SelectedCells(1).Value)
            ElseIf e.KeyCode = Keys.F7 Then
                Dim rpt As New clsReportes
                rpt.Historial(dgLista.SelectedCells(1).Value, dgLista.SelectedCells(0).Value, 395)
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub botonCliente_Click(sender As Object, e As EventArgs) Handles botonCliente.Click
        Me.Tag = "Nuevo"
        Dim frm As New frmSeleccionar
        Dim strCondicion As String = STR_VACIO

        strCondicion = "c.cli_sisemp  = {empresa} AND c.cli_status  = 'Activo' "
        strCondicion = Replace(strCondicion, "{empresa}", Sesion.IdEmpresa)
        Try
            frm.Titulo = "Client"
            frm.Campos = " c.cli_codigo , c.cli_cliente , c.cli_direccion , c.cli_telefono , c.cli_nit "
            frm.Tabla = " Clientes c"
            frm.FiltroText = " Enter the client to filter"
            frm.Filtro = "  c.cli_cliente"
            frm.Limite = 30
            frm.Ordenamiento = " c.cli_codigo "
            frm.TipoOrdenamiento = ""
            frm.Condicion = strCondicion

            frm.ShowDialog(Me)
            If frm.DialogResult = System.Windows.Forms.DialogResult.OK Then
                celdaIDCliente.Text = frm.LLave
                celdaNombre.Text = frm.Dato
                celdaDireccion.Text = frm.Dato2
                celdaNIt.Text = frm.Dato4


                celdaMoneda.Text = "US$"
                celdaIDMoneda.Text = 178

                CargarDocsPendientes()
            End If



        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub CargarDocsPendientes()
        'Carga los documentos pendientes de procesar
        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader
        Dim strOrigen As String = STR_VACIO
        Dim strTemp As String = STR_VACIO

        If Me.Tag = "Mod" Then
            'Documentos Procesados
            strOrigen = sqlDocsProcesados()
        Else
            'Documentos por Procesar
            strOrigen = SqlDocsPendientes()
        End If

        'COM = New MySqlCommand(strOrigen, CON)
        'REA = COM.ExecuteReader

        MyCnn.CONECTAR = strConexion
        COM = New MySqlCommand(strOrigen, CON)
        REA = COM.ExecuteReader

        If REA.HasRows Then
            dgDocs.Rows.Clear()
            Do While REA.Read
                strTemp = REA.GetInt32("anio") & "|"
                If Sesion.IdEmpresa = 12 And Pais() = 0 Then
                    strTemp &= REA.GetInt32("numero") & "|"
                    strTemp &= REA.GetInt32("numero") & "|"
                Else
                    strTemp &= REA.GetInt32("num") & "|"
                    strTemp &= REA.GetInt32("numero") & "|"
                End If

                strTemp &= REA.GetDateTime("fecha") & "|"
                strTemp &= REA.GetString("usuario") & "|"
                strTemp &= REA.GetString("referencia") & "|"
                strTemp &= 0

                cFunciones.AgregarFila(dgDocs, strTemp)


            Loop
        End If

        If Me.Tag = "Nuevo" Then
            If dgDocs.Rows.Count > 1 Or dgDocs.Rows.Count = 1 Then

                'Si el detalle está vacío procesa los documentos
                CargarDetalle(True, dgDocs.Rows.Count)

            End If
        End If

    End Sub

    Private Sub ProcesarDocumentos()
        'Carga el detalle de los documentos seleccionados por procesar
        Dim i As Integer = INT_CERO
        Dim strSQL As String = STR_VACIO
        Dim strsQLTipo As String = STR_VACIO
        Dim strFila As String = STR_VACIO
        Dim COM As MySqlCommand
        Dim COMT As MySqlCommand
        Dim REA As MySqlDataReader
        Dim REAT As MySqlDataReader
        Dim intNum As Integer = INT_CERO
        Dim TipoFactura As Integer

        Try
            'Nos indica es una factura de Servicios HDoc_RF3_Dbl = 1 
            strsQLTipo = SqlTipoFactura()
            MyCnn.CONECTAR = strConexion
            COMT = New MySqlCommand(strsQLTipo, CON)
            REAT = COMT.ExecuteReader

            If REAT.HasRows Then
                Do While REAT.Read
                    TipoFactura = REAT.GetInt32("Tipo")
                Loop
            End If


            If TipoFactura = 0 Then
                strSQL = SqlDatosPorProcesar()
            Else
                strSQL = SqlDatosPorProcesar2()
            End If


            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSQL, CON)
            REA = COM.ExecuteReader

            If REA.HasRows Then
                Do While REA.Read
                    i = i + 1
                    strFila = REA.GetInt32("empresa") & "|"
                    strFila &= REA.GetInt32("tipo") & "|"
                    strFila &= REA.GetInt32("anio") & "|"
                    If IDEmpresa() = 310 And Sesion.IdEmpresa = 12 Or Sesion.IdEmpresa = 14 Then
                        strFila &= REA.GetInt32("num") & "|"
                    Else
                        strFila &= REA.GetInt32("numero") & "|"
                    End If

                    strFila &= REA.GetInt32("codigo") & "|"
                    strFila &= REA.GetString("descripcion") & "|"
                    strFila &= REA.GetString("medida") & "|"
                    strFila &= REA.GetInt32("unidad") & "|"
                    strFila &= REA.GetDouble("precio") & "|"
                    strFila &= REA.GetDouble("saldo") & "|"
                    strFila &= 0.0 & "|"
                    strFila &= (REA.GetDouble("precio") * REA.GetDouble("saldo")).ToString(FORMATO_MONEDA) & "|"
                    strFila &= REA.GetInt32("linea") & "|"
                    strFila &= i & "|"
                    strFila &= REA.GetString("referencia") & "|"
                    strFila &= vbNullString & "|"
                    strFila &= vbNullString & "|"
                    strFila &= REA.GetString("pedido") & "|"
                    strFila &= REA.GetString("contenedor") & "|"
                    strFila &= vbNullString & "|"
                    strFila &= REA.GetString("contrato") & "|"
                    strFila &= REA.GetDouble("revision") & "|"
                    strFila &= REA.GetString("comentario")

                    cFunciones.AgregarFila(dgDetalle, strFila)

                    'Jala el numero de la factura
                    intNum = REA.GetInt32("numero")

                Loop
            End If

            'Recuperar Datos del Pedido
            DatosDePedido(intNum)

            'Se posiciona en la primera celda


        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub


    Private Sub dgDocs_DoubleClick(sender As Object, e As EventArgs) Handles dgDocs.DoubleClick
        'Se selecciona sólo el doc. actual (se borra el resto)
        Dim i As Integer = INT_CERO
        Dim j As Integer = INT_CERO
        Dim k As Integer = INT_CERO
        Dim ConteoLineas As Integer = INT_CERO

        If dgDocs.Rows.Count > 1 Then
            dgDocs.CurrentRow.Cells(6).Value = 1
            j = dgDocs.Rows.Count - 1
            For i = 0 To j
                If dgDocs.Rows(i).Cells(6).Value = 0 Then
                    dgDocs.Rows(i).Visible = False
                    ConteoLineas = ConteoLineas + 1
                End If
            Next
        End If

        ConteoLineas = dgDocs.Rows.Count - ConteoLineas

        dgDetalle.Rows.Clear()
        'Si el detalle está vacío procesa los documentos
        CargarDetalle(True, ConteoLineas)

    End Sub
    Private Sub MostrarInfo(ByVal i As Integer)

        'Muestra la información de inventario para la línea actual
        Dim strSQL As String = STR_VACIO
            Dim strDato As String = STR_VACIO
            Dim strTemp As String = STR_VACIO
            Dim strCodigo As String = STR_VACIO
            Dim COM As MySqlCommand
            Dim REA As MySqlDataReader


        If (i = NO_FILA) Then
            etiquetaInfo0.Text = "Linea: 00"
            etiquetaInfo1.Text = "(There is not a line selected)"
        Else
            etiquetaInfo0.Text = Replace("Line {numero}:", "{numero}", Format(i, "00"))
            i = dgDetalle.Rows.Count - 1
            strCodigo = dgDetalle.Rows(i).Cells("colCodigo").Value

            If Trim(strCodigo = vbNullString) Then
                strTemp = "(Invalid Code)"
            Else
                strSQL = "SELECT a.art_DLarga descripcion, COALESCE(p.cat_clave,'') pais, COALESCE(v.pro_proveedor,'') proveedor"
                strSQL &= "      FROM Inventarios i"
                strSQL &= "              INNER JOIN Articulos a ON a.art_sisemp = i.inv_sisemp AND a.art_codigo = i.inv_artcodigo"
                strSQL &= "                      LEFT JOIN Catalogos p ON p.cat_clase = 'Paises' AND p.cat_num = i.inv_lugarfab"
                strSQL &= "              LEFT JOIN Proveedores v ON v.pro_sisemp = i.inv_sisemp AND v.pro_codigo = i.inv_provcod"
                strSQL &= "       WHERE i.inv_sisemp={empresa} AND i.inv_numero={codigo}"

                strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
                strSQL = Replace(strSQL, "{codigo}", strCodigo)

                Try
                    MyCnn.CONECTAR = strConexion
                    COM = New MySqlCommand(strSQL, CON)
                    REA = COM.ExecuteReader

                    If REA.HasRows Then
                        Do While REA.Read
                            If Not (REA.HasRows) Then
                                strTemp = "(Invalid Information)"
                            Else
                                strTemp = REA.GetString("descripcion")
                                strDato = REA.GetString("pais")
                                strDato = strDato & " / " & REA.GetString("proveedor") & "/" & vbNullString
                                strTemp = strTemp & vbCr & strDato & vbCr
                            End If
                        Loop
                    End If

                    etiquetaInfo1.Text = strTemp
                Catch ex As Exception
                    MsgBox(ex.ToString)
                End Try
                CalcularTotales()
            End If
        End If
    End Sub

    Private Sub CalcularTotales()
        Dim i As Integer
        Dim dblCantidad As Double
        Dim dblTotal As Double
        Dim dblGranTotal As Double

        For i = 0 To dgDetalle.Rows.Count - 1
            dblCantidad = dblCantidad + dgDetalle.Rows(i).Cells("colCantidad").Value
            dblTotal = dgDetalle.Rows(i).Cells("colTotal").Value
            dblGranTotal = dblGranTotal + dblTotal.ToString("###0.00")

        Next

        celdaCantidad.Text = dblCantidad.ToString(FORMATO_MONEDA)
        celdaTotal.Text = dblGranTotal.ToString(FORMATO_MONEDA)
    End Sub

    Private Sub Encabezado1_ClickGuardar(sender As Object, click As Boolean) Handles Encabezado1.ClickGuardar
        Dim intPais As Integer = INT_CERO
        Dim strSQL As String = STR_VACIO
        Dim intNumero As Integer = INT_CERO
        Dim intNum As Integer = INT_CERO
        Dim COM As New MySqlCommand
        Dim conec As New MySqlConnection
        Dim strsQLTipo As String = STR_VACIO
        Dim DblTipoFact As Double = INT_CERO

        If Me.Tag = "Nuevo" Or logEditar = True Then
            If ComprobarIngreso() Then
                If Me.Tag = "Nuevo" Then
                    'Comprueba la validez del año/número
                    intPais = IDEmpresa()
                    'If (Sesion.IdEmpresa = 12 And intPais = 310) Or intPais = 327 Then
                    '    strSQL = " SELECT ifnull(MAX(h.HDoc_DR1_Dbl),0)+1"
                    '    strSQL &= "     FROM Dcmtos_HDR h"
                    '    strSQL &= "          LEFT JOIN Empresas e On e.emp_no = h.HDoc_Sis_Emp "
                    '    strSQL &= "     WHERE h.HDoc_Sis_Emp ={empresa} and h.HDoc_Doc_Cat = 36"

                    '    strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)

                    '    conec = New MySqlConnection(strConexion)
                    '    conec.Open()
                    '    COM = New MySqlCommand(strSQL, conec)
                    '    Using conec
                    '        intNumero = COM.ExecuteScalar
                    '        COM.Dispose()
                    '        COM = Nothing
                    '        conec.Close()
                    '        conec.Dispose()
                    '        conec = Nothing
                    '        System.GC.Collect()
                    '    End Using

                    'ElseIf Sesion.IdEmpresa = 12 Then
                    If dgDocs.Rows.Count = 1 Or dgDocs.CurrentRow.Cells("colAdicional").Value = 1 Then
                        intNumero = dgDocs.CurrentRow.Cells("colNumero").Value
                        intNum = dgDocs.CurrentRow.Cells("colNumReal").Value
                    End If
                    'intNumero = cFunciones.Verificacion_Nuevo_Registro(celdaNumero.Text, "Dcmtos", 395, celdaAño.Text, celdaIDCliente.Text, True)
                    'End If

                    celdaNumero.Text = intNumero
                    celdaNum.Text = intNum

                    'Nos indica es una factura de Servicios HDoc_RF3_Dbl = 1 
                    strsQLTipo = SqlTipoFactura()
                    MyCnn.CONECTAR = strConexion
                    COM = New MySqlCommand(strsQLTipo, CON)
                    DblTipoFact = COM.ExecuteScalar
                    COM.Dispose()
                    COM = Nothing
                    CON.Close()
                    CON.Dispose()
                    CON = Nothing

                    GuardarDocumento(DblTipoFact)
                    GuardarDetalle()
                    GuargarDescargos()

                    ActualizarFactura(DblTipoFact)

                    'Registra la transacción
                    cFunciones.EscribirRegistro(TBL_DOCUMENTOS, clsFunciones.AccEnum.acAdd, celdaIDCliente.Text, 395, celdaAño.Text, celdaNumero.Text)

                    If MsgBox("The data has been saved" & vbCr & vbCr & "¿You want to close the document?", vbQuestion + vbYesNo + vbDefaultButton2, "Close Document") = vbYes Then
                        'Carga el listado principal
                        MostrarLista()
                        CargarSQLlista()
                    Else
                        Me.Tag = "Mod"
                    End If

                ElseIf Me.Tag = "Mod" Then
                    Dim frmMsg As New frmPedirComentarios
                    frmMsg.ShowDialog(Me)
                    If frmMsg.DialogResult = System.Windows.Forms.DialogResult.OK Then
                        GuardarDocumento(DblTipoFact)
                        GuardarDetalle()
                        GuargarDescargos()
                        If checkActivo.Checked = False Then
                            BorrarDescargo()
                            If Sesion.IdEmpresa = 16 And intPais = 310 Then
                                cFunciones.EscribirRegistro(TBL_DOCUMENTOS, clsFunciones.AccEnum.acDelete, celdaIDCliente.Text, 395, celdaAño.Text, celdaNum.Text)
                            End If
                        End If


                        'Nos indica es una factura de Servicios HDoc_RF3_Dbl = 1 
                        strsQLTipo = SqlTipoFactura()
                        MyCnn.CONECTAR = strConexion
                        COM = New MySqlCommand(strsQLTipo, CON)
                        DblTipoFact = COM.ExecuteScalar
                        COM.Dispose()
                        COM = Nothing
                        CON.Close()
                        CON.Dispose()
                        CON = Nothing
                        ActualizarFactura(DblTipoFact)



                        'Registra la transacción
                        cFunciones.EscribirRegistro(TBL_DOCUMENTOS, clsFunciones.AccEnum.acUpdate, celdaIDCliente.Text, 395, celdaAño.Text, celdaNumero.Text, frmMsg.celdaInfo.Text)

                        If MsgBox("The data has been saved" & vbCr & vbCr & "¿You want to close the document?", vbQuestion + vbYesNo + vbDefaultButton2, "Close Document") = vbYes Then
                            'Carga el listado principal
                            MostrarLista()
                            CargarSQLlista()

                        End If
                    End If


                End If
            End If
        Else
            MsgBox("You do not have permission to modify the document", vbCritical, "Notice")
        End If

    End Sub

    Private Sub ValidarDatos(ByVal PId As Integer)
        Dim intID As Integer = INT_CERO
        Dim strSQL As String = STR_VACIO
        Dim COM As New MySqlCommand
        Dim REA As MySqlDataReader

        'Empresa (cliente/proveedor)
        strSQL = "  SELECT cli_codigo, cli_cliente, cli_plazoCR"
        strSQL &= "     FROM Clientes"
        strSQL &= "         LEFT JOIN Catalogos ON cat_num=cli_moneda"
        strSQL &= "     WHERE cli_sisemp={empresa} AND cli_codigo={idNombre}"

        strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
        strSQL = Replace(strSQL, "{idNombre}", PId)

        MyCnn.CONECTAR = strConexion
        COM = New MySqlCommand(strSQL, CON)
        REA = COM.ExecuteReader

        If REA.HasRows Then
            REA.Read()

            'Datos de la empresa
            celdaIDCliente2.Text = REA.GetInt32("cli_codigo")
            celdaCliente2.Text = REA.GetString("cli_cliente")

            'Dias de Credito
            celdaCreidtDay.Text = REA.GetDouble("cli_plazoCR")
        End If
    End Sub

    Private Sub botonMoneda_Click(sender As Object, e As EventArgs) Handles botonMoneda.Click
        Dim frm As New frmSeleccionar
        Dim strSQL As String = STR_VACIO
        Dim COM As MySqlCommand
        Dim conec As MySqlConnection
        Dim Cambio As Double

        Try
            frm.Titulo = "Currency"
            frm.FiltroText = " Enter The Currency To Filter"
            frm.Campos = " cat_num Code, cat_clave Currency"
            frm.Tabla = " Catalogos"
            frm.Filtro = " cat_clave "
            frm.Condicion = "cat_clase = 'monedas'"

            frm.ShowDialog(Me)
            If frm.DialogResult = System.Windows.Forms.DialogResult.OK Then
                celdaIDMoneda.Text = frm.LLave
                celdaMoneda.Text = frm.Dato
            End If

            strSQL = " SELECT cat_sist"
            strSQL &= "      FROM Catalogos"
            strSQL &= "          WHERE cat_clase = 'Monedas' AND cat_num = {Numero}"

            strSQL = Replace(strSQL, "{Numero}", frm.LLave)

            conec = New MySqlConnection(strConexion)
            conec.Open()
            COM = New MySqlCommand(strSQL, conec)
            Using conec
                Cambio = COM.ExecuteScalar
                COM.Dispose()
                COM = Nothing
                conec.Close()
                conec.Dispose()
                conec = Nothing
                System.GC.Collect()
            End Using
            If Cambio > 1 Then
                celdaTasaCambio.Text = cFunciones.TasaSegunFecha(dtpFecha.Value.ToString(FORMATO_MYSQL))
            Else
                celdaTasaCambio.Text = Cambio
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub dgDetalle_SelectionChanged(ByVal sender As Object, ByVal e As EventArgs) Handles dgDetalle.SelectionChanged

        If dgDetalle.Rows.Count > 1 Then
            'Jala datos de las lineas de detalle
            MostrarInfo((dgDetalle.CurrentRow.Cells(13).Value - 1))
        End If
    End Sub

    Private Sub botonFiltar_Click(sender As Object, e As EventArgs) Handles botonFiltar.Click
        Dim logCancelar As Boolean

        If CDate(dtpFechaInicio.Value) > CDate(dtpFechaFin.Value) Then
            MsgBox("The start date may not exceed the final date", vbExclamation, "Notice")
            logCancelar = True
        End If
        If Not (logCancelar) Then

            'Procedimiento para cargar panel dgLista
            CargarSQLlista()

        End If
    End Sub

    Private Sub botonCliente2_Click(sender As Object, e As EventArgs) Handles botonCliente2.Click
        'Me.Tag = "Nuevo"
        Dim frm As New frmSeleccionar
        Dim strSQL As String
        Dim strCondicion As String = STR_VACIO
        Dim año As Integer
        Dim numero As Integer
        strCondicion = "c.cli_sisemp  = {empresa} AND c.cli_status  = 'Activo' "
        strCondicion = Replace(strCondicion, "{empresa}", Sesion.IdEmpresa)
        Try
            frm.Titulo = "Client"
            frm.Campos = " c.cli_codigo , c.cli_cliente , c.cli_direccion , c.cli_telefono , c.cli_nit "
            frm.Tabla = " Clientes c"
            frm.FiltroText = " Enter the client to filter"
            frm.Filtro = "  c.cli_cliente"
            frm.Limite = 30
            frm.Ordenamiento = " c.cli_codigo "
            frm.TipoOrdenamiento = ""
            frm.Condicion = strCondicion

            frm.ShowDialog(Me)
            If frm.DialogResult = System.Windows.Forms.DialogResult.OK Then
                celdaIDCliente2.Text = frm.LLave
                celdaCliente2.Text = frm.Dato
                'celdaDireccion.Text = frm.Dato2
                'celdaNIt.Text = frm.Dato4


                celdaMoneda.Text = "US$"
                celdaIDMoneda.Text = 178
            End If

            CargarDocsPendientes()

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

#End Region

    Private Sub botonBuscar_Click(sender As Object, e As EventArgs) Handles botonBuscar.Click
        Try
            cFunciones.BuscarenLista(dgLista)
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub Encabezado1_ClickBorrar(sender As Object, click As Boolean) Handles Encabezado1.ClickBorrar
        Dim intPais As Integer
        If LogBorrar = True Then
            If Dependencias() = INT_UNO Then
                MsgBox("This YRM can not be canceled, is related to other agencies", MsgBoxStyle.Critical, "Warning")
                If intPais = 327 And Sesion.IdEmpresa = 14 Then
                    cFunciones.MostrarDependencias(395, celdaAño.Text, celdaNum.Text)
                ElseIf (Sesion.IdEmpresa = 12 And intPais = 310) Or (Sesion.IdEmpresa = 11) Or Sesion.idGiro = 2 Then
                    cFunciones.MostrarDependencias(395, celdaAño.Text, celdaNum.Text)
                Else
                    cFunciones.MostrarDependencias(395, celdaAño.Text, celdaNumero.Text)
                End If
            Else
                If MsgBox("Are You sure " & vbCr & vbCr & "¿do you want to delete this document? ", vbQuestion + vbYesNo, "Aviso") = vbYes Then
                    BorrarEncabezado()
                    BorrarDetalle()
                    BorrarDescargo()
                    'Registra la transacción
                    intPais = Pais()
                    If intPais = 327 And Sesion.IdEmpresa = 14 Then
                        cFunciones.EscribirRegistro(TBL_DOCUMENTOS, clsFunciones.AccEnum.acDelete, celdaIDCliente.Text, 395, celdaAño.Text, celdaNum.Text)
                    ElseIf Sesion.IdEmpresa = 12 And intPais = 310 Then
                        cFunciones.EscribirRegistro(TBL_DOCUMENTOS, clsFunciones.AccEnum.acDelete, celdaIDCliente.Text, 395, celdaAño.Text, celdaNum.Text)
                    ElseIf Sesion.IdEmpresa = 16 And intPais = 310 Then
                        cFunciones.EscribirRegistro(TBL_DOCUMENTOS, clsFunciones.AccEnum.acDelete, celdaIDCliente.Text, 395, celdaAño.Text, celdaNum.Text)
                    ElseIf Sesion.IdEmpresa = 11 Or Sesion.idGiro = 2 Then
                        cFunciones.EscribirRegistro(TBL_DOCUMENTOS, clsFunciones.AccEnum.acDelete, celdaIDCliente.Text, 395, celdaAño.Text, celdaNum.Text)
                    Else
                        cFunciones.EscribirRegistro(TBL_DOCUMENTOS, clsFunciones.AccEnum.acDelete, celdaIDCliente.Text, 395, celdaAño.Text, celdaNumero.Text)
                    End If
                    MsgBox("Delete Complete")
                    MostrarLista()
                End If
            End If
        Else
            MsgBox("You do not have permission to delete this document", vbCritical, "Notice")
        End If
    End Sub

    Private Sub botonClase_Click(sender As Object, e As EventArgs) Handles botonClase.Click
        Dim frm As New frmSeleccionar
        Try
            frm.Titulo = "Select any Class "

            frm.Campos = " cat_num Id, cat_desc Class"
            frm.Tabla = "Catalogos"
            frm.Condicion = " cat_clase = 'ClassYRM' and cat_sisemp =  " & Sesion.IdEmpresa

            frm.ShowDialog(Me)
            If frm.DialogResult = DialogResult.OK Then
                celdaidClase.Text = frm.LLave
                celdaClase.Text = frm.Dato
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub dtpFecha_ValueChanged(sender As Object, e As EventArgs) Handles dtpFecha.ValueChanged
        If celdaTasaCambio.Text > 1 Then
            celdaTasaCambio.Text = cFunciones.TasaSegunFecha(dtpFecha.Value.ToString(FORMATO_MYSQL))
        End If
    End Sub

    Private Sub dgDetalle_ColumnHeaderMouseDoubleClick(sender As Object, e As DataGridViewCellMouseEventArgs) Handles dgDetalle.ColumnHeaderMouseDoubleClick
        If e.ColumnIndex = 15 Then
            Dim resultado As DialogResult = MessageBox.Show("Replicate the value 'Way to Pay' Row 1 in all rows?", "Confirmation", MessageBoxButtons.YesNo, MessageBoxIcon.Question)

            If resultado = DialogResult.Yes Then
                Dim valorPrimeraFila As Object = dgDetalle.Rows(0).Cells(15).Value

                ' Recorrer todas las filas del DataGridView y asignar el mismo valor a la columna 15
                For Each fila As DataGridViewRow In dgDetalle.Rows
                    fila.Cells(15).Value = valorPrimeraFila
                Next

                ' Mensaje opcional para confirmar que la acción se completó
                MessageBox.Show("Values replicated",
                            "Action performed",
                            MessageBoxButtons.OK,
                            MessageBoxIcon.Information)
            End If
        End If
    End Sub

    Private Sub dgDetalle_CellMouseDoubleClick(sender As Object, e As DataGridViewCellMouseEventArgs) Handles dgDetalle.CellMouseDoubleClick
        ' Verificar si se ha hecho doble clic en una celda válida
        If e.RowIndex < 0 OrElse e.ColumnIndex < 0 Then
            ' MessageBox.Show("CLICK fuera", "", MessageBoxButtons.OK, MessageBoxIcon.Information)
            ' doble clic ocurrió en el encabezado de columna o fuera de las celdas
            Exit Sub
        End If

        Dim intFila As Integer
        Dim intTmp As Integer
        Dim Pago As String = STR_VACIO
        Dim frm As New frmOption
        If dgDetalle.Rows.Count = 0 Then
            Exit Sub
        Else
            Select Case dgDetalle.CurrentCell.ColumnIndex

                Case 15
                    intFila = dgDetalle.Rows.Count

                    If intFila > NO_FILA Then
                        Try
                            frm.Titulo = "Select Payment Method"
                            frm.Opciones = "Efectivo|" & "Cheque|" & "Transferencia|" & "Carta de Credito|" & "Hana financial"
                            frm.ShowDialog(Me)
                            If frm.DialogResult = System.Windows.Forms.DialogResult.OK Then
                                Select Case frm.Seleccion
                                    Case 0
                                        intTmp = 0
                                    Case 1
                                        intTmp = 1
                                    Case 2
                                        intTmp = 2
                                    Case 3
                                        intTmp = 3
                                    Case 4
                                        intTmp = 4
                                End Select

                            End If

                            If intTmp = vbEmpty Or intTmp > vbEmpty Then
                                If intTmp = 0 Then
                                    Pago = "CASH"
                                ElseIf intTmp = 1 Then
                                    Pago = "CHECK"
                                ElseIf intTmp = 2 Then
                                    Pago = "WIRE"
                                ElseIf intTmp = 3 Then
                                    Pago = "L/C"
                                ElseIf intTmp = 4 Then
                                    Pago = "Hana financial"
                                End If

                                dgDetalle.CurrentRow.Cells("colPago").Value = Pago
                            End If
                        Catch ex As Exception
                            MsgBox(ex.ToString)
                        End Try
                    End If
            End Select
        End If
    End Sub
End Class