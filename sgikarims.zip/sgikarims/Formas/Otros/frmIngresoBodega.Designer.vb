﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmIngresoBodega
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim DataGridViewCellStyle1 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle2 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle3 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle4 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle5 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle6 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmIngresoBodega))
        Dim DataGridViewCellStyle7 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle8 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle9 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle10 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle11 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle12 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle13 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle14 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle15 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle16 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle17 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle18 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Me.panelIngresoABodega = New System.Windows.Forms.Panel()
        Me.panelLista = New System.Windows.Forms.Panel()
        Me.dgLista = New System.Windows.Forms.DataGridView()
        Me.colNumber = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colDate = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colNombre = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colClase = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colReferencia = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colBodega = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colAnio = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colDireccion = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colTasa = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colIDMoneda = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colSimMoneda = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colCorrelativo = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colRevisado = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.panelFecha = New System.Windows.Forms.Panel()
        Me.botonPendientes = New System.Windows.Forms.Button()
        Me.botonActualizar = New System.Windows.Forms.Button()
        Me.dtpFin = New System.Windows.Forms.DateTimePicker()
        Me.etiquetaFin = New System.Windows.Forms.Label()
        Me.dtpInicio = New System.Windows.Forms.DateTimePicker()
        Me.checkFecha = New System.Windows.Forms.CheckBox()
        Me.panelInferior = New System.Windows.Forms.Panel()
        Me.TextBox3 = New System.Windows.Forms.TextBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.TextBox1 = New System.Windows.Forms.TextBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.TextBox2 = New System.Windows.Forms.TextBox()
        Me.etiquetaModificado = New System.Windows.Forms.Label()
        Me.panelDocumento = New System.Windows.Forms.Panel()
        Me.panelDetalle = New System.Windows.Forms.Panel()
        Me.dgDetalle = New System.Windows.Forms.DataGridView()
        Me.colCodigo = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colArticulo = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colIDMedida = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colMedida = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colPrecio = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colDescuento = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colDesDolar = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colCantidad = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colBultos = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colSubtotal = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colBodegga = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colBoxNumber = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colReserva = New System.Windows.Forms.DataGridViewButtonColumn()
        Me.colProblema = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colComentario = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colCantidadOriginal = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colCodOriginal = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.coLRF2Num = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colRF2cOD = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colLinea = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colPrdPNr = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colNotas = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colRF1Num = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colReservado = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colAgregar = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colEmpresaPol = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colAnioPoliza = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colNumPoliza = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colLineaPoliza = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colMarcaHSM = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colIdEstado = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colEstado = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colGFMO = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colTipoCambio = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colRefMKT = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colReferenciaRamplas = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colGin = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colGBac = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colCrp = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.botonQuitDetalle = New System.Windows.Forms.Button()
        Me.botonAgreDetalle = New System.Windows.Forms.Button()
        Me.Panel3 = New System.Windows.Forms.Panel()
        Me.gbInstDespacho = New System.Windows.Forms.GroupBox()
        Me.checkTendido = New System.Windows.Forms.CheckBox()
        Me.CheckIngreso = New System.Windows.Forms.CheckBox()
        Me.celdaTipoIngreso = New System.Windows.Forms.TextBox()
        Me.etiquetaRevisado = New System.Windows.Forms.Label()
        Me.celdaRevisado = New System.Windows.Forms.TextBox()
        Me.botonDespachos = New System.Windows.Forms.Button()
        Me.botonParciales = New System.Windows.Forms.Button()
        Me.celdaTelefono = New System.Windows.Forms.TextBox()
        Me.celdaNit = New System.Windows.Forms.TextBox()
        Me.checkRevisado = New System.Windows.Forms.CheckBox()
        Me.botonPolizaC = New System.Windows.Forms.Button()
        Me.celdaEmpresa = New System.Windows.Forms.TextBox()
        Me.dtpFech = New System.Windows.Forms.DateTimePicker()
        Me.celdaUsuario = New System.Windows.Forms.TextBox()
        Me.celdaCatalogo = New System.Windows.Forms.TextBox()
        Me.celdaIDMoneda = New System.Windows.Forms.TextBox()
        Me.celdaIDCliente = New System.Windows.Forms.TextBox()
        Me.celdaTasa = New System.Windows.Forms.TextBox()
        Me.etiquetaTasa = New System.Windows.Forms.Label()
        Me.botonMoneda = New System.Windows.Forms.Button()
        Me.celdaMoneda = New System.Windows.Forms.TextBox()
        Me.etiquetaMoneda = New System.Windows.Forms.Label()
        Me.celdaDireccion = New System.Windows.Forms.TextBox()
        Me.etiquetaDireccion = New System.Windows.Forms.Label()
        Me.botonClientes = New System.Windows.Forms.Button()
        Me.celdaCliente = New System.Windows.Forms.TextBox()
        Me.etiquetaCliente = New System.Windows.Forms.Label()
        Me.etiquetaFecha = New System.Windows.Forms.Label()
        Me.celdaNumero = New System.Windows.Forms.TextBox()
        Me.etiquetaNumero = New System.Windows.Forms.Label()
        Me.celdaAnio = New System.Windows.Forms.TextBox()
        Me.etiquetaAño = New System.Windows.Forms.Label()
        Me.gbPedidoClientes = New System.Windows.Forms.GroupBox()
        Me.celdaTipoIng = New System.Windows.Forms.TextBox()
        Me.botonPacas = New System.Windows.Forms.Button()
        Me.botonProduccion = New System.Windows.Forms.Button()
        Me.dgPolizasImportacion = New System.Windows.Forms.DataGridView()
        Me.colNumero = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colFecha = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colUsuario = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colReference = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colAno = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colCatalogo = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colEliminar = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.gbInformación = New System.Windows.Forms.GroupBox()
        Me.checkMuestra = New System.Windows.Forms.CheckBox()
        Me.celdaAnioProduccion = New System.Windows.Forms.TextBox()
        Me.celdaNProduccion = New System.Windows.Forms.TextBox()
        Me.celdaBodega = New System.Windows.Forms.TextBox()
        Me.celdaRef2 = New System.Windows.Forms.TextBox()
        Me.etiquetaRef2 = New System.Windows.Forms.Label()
        Me.celdaRef1 = New System.Windows.Forms.TextBox()
        Me.EtiquetaRef1 = New System.Windows.Forms.Label()
        Me.celdaRefFactura = New System.Windows.Forms.TextBox()
        Me.etiquetaRefFactura = New System.Windows.Forms.Label()
        Me.panelTotales = New System.Windows.Forms.Panel()
        Me.celdaSubTotal = New System.Windows.Forms.TextBox()
        Me.etiquetaTotal = New System.Windows.Forms.Label()
        Me.celdaTotal = New System.Windows.Forms.TextBox()
        Me.panelPiePagina = New System.Windows.Forms.Panel()
        Me.panelOculto = New System.Windows.Forms.Panel()
        Me.dgOculto = New System.Windows.Forms.DataGridView()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.botonBanderaAzul = New System.Windows.Forms.Button()
        Me.checkFech = New System.Windows.Forms.CheckBox()
        Me.dtpFecha2 = New System.Windows.Forms.DateTimePicker()
        Me.CeldaNota = New System.Windows.Forms.TextBox()
        Me.panelDescargos = New System.Windows.Forms.Panel()
        Me.dgDescargos = New System.Windows.Forms.DataGridView()
        Me.colFila = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colYear = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colNum = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colDespacho = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colSaldo = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colPedido = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colLine = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colIEstado = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colFEStado = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.panelSub = New System.Windows.Forms.Panel()
        Me.dgSubdocumentos = New System.Windows.Forms.DataGridView()
        Me.colClave = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colDocumento = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colDisponible = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.botonImprimir = New System.Windows.Forms.Button()
        Me.BotonImprimirRotulo = New System.Windows.Forms.Button()
        Me.BarraTitulo1 = New KARIMs_SGI.BarraTitulo()
        Me.Encabezado1 = New KARIMs_SGI.encabezado()
        Me.botonPOWE = New System.Windows.Forms.Button()
        Me.colEmpresa = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colCat = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colAnio2 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colNumero2 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colLinea2 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colLineaDetalle = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colRef = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colTara = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colPaquetes = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colCantMedida = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colPesoNeto = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colNumCaja = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colTipoBulto = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colXtraBox = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.col_Gin = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.col_GBac = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.col_Crp = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.col_Ref = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.panelIngresoABodega.SuspendLayout()
        Me.panelLista.SuspendLayout()
        CType(Me.dgLista, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.panelFecha.SuspendLayout()
        Me.panelInferior.SuspendLayout()
        Me.panelDocumento.SuspendLayout()
        Me.panelDetalle.SuspendLayout()
        CType(Me.dgDetalle, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Panel1.SuspendLayout()
        Me.Panel3.SuspendLayout()
        Me.gbInstDespacho.SuspendLayout()
        Me.gbPedidoClientes.SuspendLayout()
        CType(Me.dgPolizasImportacion, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.gbInformación.SuspendLayout()
        Me.panelTotales.SuspendLayout()
        Me.panelPiePagina.SuspendLayout()
        Me.panelOculto.SuspendLayout()
        CType(Me.dgOculto, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox1.SuspendLayout()
        Me.panelDescargos.SuspendLayout()
        CType(Me.dgDescargos, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.panelSub.SuspendLayout()
        CType(Me.dgSubdocumentos, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'panelIngresoABodega
        '
        Me.panelIngresoABodega.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.panelIngresoABodega.Controls.Add(Me.panelLista)
        Me.panelIngresoABodega.Location = New System.Drawing.Point(13, 142)
        Me.panelIngresoABodega.Margin = New System.Windows.Forms.Padding(4)
        Me.panelIngresoABodega.Name = "panelIngresoABodega"
        Me.panelIngresoABodega.Size = New System.Drawing.Size(1256, 719)
        Me.panelIngresoABodega.TabIndex = 0
        '
        'panelLista
        '
        Me.panelLista.Controls.Add(Me.dgLista)
        Me.panelLista.Controls.Add(Me.panelFecha)
        Me.panelLista.Controls.Add(Me.panelInferior)
        Me.panelLista.Dock = System.Windows.Forms.DockStyle.Fill
        Me.panelLista.Location = New System.Drawing.Point(0, 0)
        Me.panelLista.Margin = New System.Windows.Forms.Padding(4)
        Me.panelLista.Name = "panelLista"
        Me.panelLista.Size = New System.Drawing.Size(1256, 719)
        Me.panelLista.TabIndex = 3
        '
        'dgLista
        '
        Me.dgLista.AllowUserToAddRows = False
        Me.dgLista.AllowUserToDeleteRows = False
        Me.dgLista.AllowUserToOrderColumns = True
        Me.dgLista.BackgroundColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle1.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.dgLista.ColumnHeadersDefaultCellStyle = DataGridViewCellStyle1
        Me.dgLista.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgLista.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.colNumber, Me.colDate, Me.colNombre, Me.colClase, Me.colReferencia, Me.colBodega, Me.colAnio, Me.colDireccion, Me.colTasa, Me.colIDMoneda, Me.colSimMoneda, Me.colCorrelativo, Me.colRevisado})
        DataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle2.BackColor = System.Drawing.SystemColors.Window
        DataGridViewCellStyle2.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.ControlText
        DataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.[False]
        Me.dgLista.DefaultCellStyle = DataGridViewCellStyle2
        Me.dgLista.Dock = System.Windows.Forms.DockStyle.Fill
        Me.dgLista.Location = New System.Drawing.Point(0, 65)
        Me.dgLista.Margin = New System.Windows.Forms.Padding(4)
        Me.dgLista.MultiSelect = False
        Me.dgLista.Name = "dgLista"
        Me.dgLista.ReadOnly = True
        DataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle3.BackColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle3.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle3.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle3.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle3.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.dgLista.RowHeadersDefaultCellStyle = DataGridViewCellStyle3
        Me.dgLista.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.dgLista.Size = New System.Drawing.Size(1256, 613)
        Me.dgLista.TabIndex = 0
        '
        'colNumber
        '
        Me.colNumber.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.colNumber.HeaderText = "Number"
        Me.colNumber.Name = "colNumber"
        Me.colNumber.ReadOnly = True
        Me.colNumber.Width = 87
        '
        'colDate
        '
        Me.colDate.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.colDate.HeaderText = "Date"
        Me.colDate.Name = "colDate"
        Me.colDate.ReadOnly = True
        Me.colDate.Width = 67
        '
        'colNombre
        '
        Me.colNombre.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill
        Me.colNombre.HeaderText = "Provider"
        Me.colNombre.Name = "colNombre"
        Me.colNombre.ReadOnly = True
        '
        'colClase
        '
        Me.colClase.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.colClase.HeaderText = "Class"
        Me.colClase.Name = "colClase"
        Me.colClase.ReadOnly = True
        Me.colClase.Width = 71
        '
        'colReferencia
        '
        Me.colReferencia.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.colReferencia.HeaderText = "Reference"
        Me.colReferencia.Name = "colReferencia"
        Me.colReferencia.ReadOnly = True
        Me.colReferencia.Width = 103
        '
        'colBodega
        '
        Me.colBodega.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.colBodega.HeaderText = "Warehouse"
        Me.colBodega.Name = "colBodega"
        Me.colBodega.ReadOnly = True
        Me.colBodega.Width = 110
        '
        'colAnio
        '
        Me.colAnio.HeaderText = "Year"
        Me.colAnio.Name = "colAnio"
        Me.colAnio.ReadOnly = True
        Me.colAnio.Visible = False
        '
        'colDireccion
        '
        Me.colDireccion.HeaderText = "Direction"
        Me.colDireccion.Name = "colDireccion"
        Me.colDireccion.ReadOnly = True
        Me.colDireccion.Visible = False
        '
        'colTasa
        '
        Me.colTasa.HeaderText = "Rate"
        Me.colTasa.Name = "colTasa"
        Me.colTasa.ReadOnly = True
        Me.colTasa.Visible = False
        '
        'colIDMoneda
        '
        Me.colIDMoneda.HeaderText = "IDMoneda"
        Me.colIDMoneda.Name = "colIDMoneda"
        Me.colIDMoneda.ReadOnly = True
        Me.colIDMoneda.Visible = False
        '
        'colSimMoneda
        '
        Me.colSimMoneda.HeaderText = "SimMoneda"
        Me.colSimMoneda.Name = "colSimMoneda"
        Me.colSimMoneda.ReadOnly = True
        Me.colSimMoneda.Visible = False
        '
        'colCorrelativo
        '
        Me.colCorrelativo.HeaderText = "Correlativo"
        Me.colCorrelativo.Name = "colCorrelativo"
        Me.colCorrelativo.ReadOnly = True
        Me.colCorrelativo.Visible = False
        '
        'colRevisado
        '
        Me.colRevisado.HeaderText = "Revisado"
        Me.colRevisado.Name = "colRevisado"
        Me.colRevisado.ReadOnly = True
        Me.colRevisado.Visible = False
        '
        'panelFecha
        '
        Me.panelFecha.Controls.Add(Me.botonPendientes)
        Me.panelFecha.Controls.Add(Me.botonActualizar)
        Me.panelFecha.Controls.Add(Me.dtpFin)
        Me.panelFecha.Controls.Add(Me.etiquetaFin)
        Me.panelFecha.Controls.Add(Me.dtpInicio)
        Me.panelFecha.Controls.Add(Me.checkFecha)
        Me.panelFecha.Dock = System.Windows.Forms.DockStyle.Top
        Me.panelFecha.Location = New System.Drawing.Point(0, 0)
        Me.panelFecha.Margin = New System.Windows.Forms.Padding(4)
        Me.panelFecha.Name = "panelFecha"
        Me.panelFecha.Size = New System.Drawing.Size(1256, 65)
        Me.panelFecha.TabIndex = 1
        '
        'botonPendientes
        '
        Me.botonPendientes.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.botonPendientes.Image = Global.KARIMs_SGI.My.Resources.Resources.document_warning
        Me.botonPendientes.Location = New System.Drawing.Point(1184, 14)
        Me.botonPendientes.Margin = New System.Windows.Forms.Padding(4)
        Me.botonPendientes.Name = "botonPendientes"
        Me.botonPendientes.Size = New System.Drawing.Size(36, 34)
        Me.botonPendientes.TabIndex = 7
        Me.botonPendientes.UseVisualStyleBackColor = True
        '
        'botonActualizar
        '
        Me.botonActualizar.Location = New System.Drawing.Point(576, 15)
        Me.botonActualizar.Margin = New System.Windows.Forms.Padding(4)
        Me.botonActualizar.Name = "botonActualizar"
        Me.botonActualizar.Size = New System.Drawing.Size(100, 28)
        Me.botonActualizar.TabIndex = 5
        Me.botonActualizar.Text = "To Update"
        Me.botonActualizar.UseVisualStyleBackColor = True
        '
        'dtpFin
        '
        Me.dtpFin.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.dtpFin.Location = New System.Drawing.Point(437, 17)
        Me.dtpFin.Margin = New System.Windows.Forms.Padding(4)
        Me.dtpFin.Name = "dtpFin"
        Me.dtpFin.Size = New System.Drawing.Size(113, 22)
        Me.dtpFin.TabIndex = 4
        '
        'etiquetaFin
        '
        Me.etiquetaFin.AutoSize = True
        Me.etiquetaFin.Location = New System.Drawing.Point(361, 21)
        Me.etiquetaFin.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.etiquetaFin.Name = "etiquetaFin"
        Me.etiquetaFin.Size = New System.Drawing.Size(66, 17)
        Me.etiquetaFin.TabIndex = 3
        Me.etiquetaFin.Text = "and Date"
        '
        'dtpInicio
        '
        Me.dtpInicio.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.dtpInicio.Location = New System.Drawing.Point(243, 16)
        Me.dtpInicio.Margin = New System.Windows.Forms.Padding(4)
        Me.dtpInicio.Name = "dtpInicio"
        Me.dtpInicio.Size = New System.Drawing.Size(112, 22)
        Me.dtpInicio.TabIndex = 1
        '
        'checkFecha
        '
        Me.checkFecha.AutoSize = True
        Me.checkFecha.Checked = True
        Me.checkFecha.CheckState = System.Windows.Forms.CheckState.Checked
        Me.checkFecha.Location = New System.Drawing.Point(9, 21)
        Me.checkFecha.Margin = New System.Windows.Forms.Padding(4)
        Me.checkFecha.Name = "checkFecha"
        Me.checkFecha.Size = New System.Drawing.Size(224, 21)
        Me.checkFecha.TabIndex = 0
        Me.checkFecha.Text = "show documents between date"
        Me.checkFecha.UseVisualStyleBackColor = True
        '
        'panelInferior
        '
        Me.panelInferior.Controls.Add(Me.TextBox3)
        Me.panelInferior.Controls.Add(Me.Label2)
        Me.panelInferior.Controls.Add(Me.TextBox1)
        Me.panelInferior.Controls.Add(Me.Label1)
        Me.panelInferior.Controls.Add(Me.TextBox2)
        Me.panelInferior.Controls.Add(Me.etiquetaModificado)
        Me.panelInferior.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.panelInferior.Location = New System.Drawing.Point(0, 678)
        Me.panelInferior.Margin = New System.Windows.Forms.Padding(4)
        Me.panelInferior.Name = "panelInferior"
        Me.panelInferior.Size = New System.Drawing.Size(1256, 41)
        Me.panelInferior.TabIndex = 2
        '
        'TextBox3
        '
        Me.TextBox3.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.TextBox3.BackColor = System.Drawing.Color.YellowGreen
        Me.TextBox3.Location = New System.Drawing.Point(423, 7)
        Me.TextBox3.Margin = New System.Windows.Forms.Padding(4)
        Me.TextBox3.Name = "TextBox3"
        Me.TextBox3.ReadOnly = True
        Me.TextBox3.Size = New System.Drawing.Size(24, 22)
        Me.TextBox3.TabIndex = 35
        '
        'Label2
        '
        Me.Label2.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(452, 10)
        Me.Label2.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(84, 17)
        Me.Label2.TabIndex = 34
        Me.Label2.Text = " REVIEWED"
        '
        'TextBox1
        '
        Me.TextBox1.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.TextBox1.BackColor = System.Drawing.Color.Orchid
        Me.TextBox1.Location = New System.Drawing.Point(240, 7)
        Me.TextBox1.Margin = New System.Windows.Forms.Padding(4)
        Me.TextBox1.Name = "TextBox1"
        Me.TextBox1.ReadOnly = True
        Me.TextBox1.Size = New System.Drawing.Size(24, 22)
        Me.TextBox1.TabIndex = 33
        '
        'Label1
        '
        Me.Label1.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(269, 10)
        Me.Label1.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(114, 17)
        Me.Label1.TabIndex = 32
        Me.Label1.Text = "NOT REVIEWED"
        '
        'TextBox2
        '
        Me.TextBox2.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.TextBox2.BackColor = System.Drawing.Color.Yellow
        Me.TextBox2.Location = New System.Drawing.Point(103, 7)
        Me.TextBox2.Margin = New System.Windows.Forms.Padding(4)
        Me.TextBox2.Name = "TextBox2"
        Me.TextBox2.ReadOnly = True
        Me.TextBox2.Size = New System.Drawing.Size(24, 22)
        Me.TextBox2.TabIndex = 31
        '
        'etiquetaModificado
        '
        Me.etiquetaModificado.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.etiquetaModificado.AutoSize = True
        Me.etiquetaModificado.Location = New System.Drawing.Point(132, 10)
        Me.etiquetaModificado.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.etiquetaModificado.Name = "etiquetaModificado"
        Me.etiquetaModificado.Size = New System.Drawing.Size(73, 17)
        Me.etiquetaModificado.TabIndex = 6
        Me.etiquetaModificado.Text = "MODIFIED"
        '
        'panelDocumento
        '
        Me.panelDocumento.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.panelDocumento.Controls.Add(Me.panelDetalle)
        Me.panelDocumento.Controls.Add(Me.Panel3)
        Me.panelDocumento.Controls.Add(Me.panelTotales)
        Me.panelDocumento.Controls.Add(Me.panelPiePagina)
        Me.panelDocumento.Location = New System.Drawing.Point(23, 138)
        Me.panelDocumento.Margin = New System.Windows.Forms.Padding(4)
        Me.panelDocumento.Name = "panelDocumento"
        Me.panelDocumento.Size = New System.Drawing.Size(1205, 553)
        Me.panelDocumento.TabIndex = 4
        '
        'panelDetalle
        '
        Me.panelDetalle.BackColor = System.Drawing.SystemColors.ActiveCaption
        Me.panelDetalle.Controls.Add(Me.dgDetalle)
        Me.panelDetalle.Controls.Add(Me.Panel1)
        Me.panelDetalle.Dock = System.Windows.Forms.DockStyle.Fill
        Me.panelDetalle.Location = New System.Drawing.Point(0, 298)
        Me.panelDetalle.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.panelDetalle.Name = "panelDetalle"
        Me.panelDetalle.Size = New System.Drawing.Size(1205, 103)
        Me.panelDetalle.TabIndex = 7
        '
        'dgDetalle
        '
        Me.dgDetalle.AllowUserToAddRows = False
        Me.dgDetalle.AllowUserToDeleteRows = False
        Me.dgDetalle.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells
        Me.dgDetalle.BackgroundColor = System.Drawing.SystemColors.Control
        Me.dgDetalle.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.Raised
        DataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle4.BackColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle4.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle4.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle4.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle4.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle4.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.dgDetalle.ColumnHeadersDefaultCellStyle = DataGridViewCellStyle4
        Me.dgDetalle.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgDetalle.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.colCodigo, Me.colArticulo, Me.colIDMedida, Me.colMedida, Me.colPrecio, Me.colDescuento, Me.colDesDolar, Me.colCantidad, Me.colBultos, Me.colSubtotal, Me.colBodegga, Me.colBoxNumber, Me.colReserva, Me.colProblema, Me.colComentario, Me.colCantidadOriginal, Me.colCodOriginal, Me.coLRF2Num, Me.colRF2cOD, Me.colLinea, Me.colPrdPNr, Me.colNotas, Me.colRF1Num, Me.colReservado, Me.colAgregar, Me.colEmpresaPol, Me.colAnioPoliza, Me.colNumPoliza, Me.colLineaPoliza, Me.colMarcaHSM, Me.colIdEstado, Me.colEstado, Me.colGFMO, Me.colTipoCambio, Me.colRefMKT, Me.colReferenciaRamplas, Me.colGin, Me.colGBac, Me.colCrp})
        DataGridViewCellStyle5.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle5.BackColor = System.Drawing.SystemColors.Window
        DataGridViewCellStyle5.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle5.ForeColor = System.Drawing.SystemColors.ControlText
        DataGridViewCellStyle5.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle5.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle5.WrapMode = System.Windows.Forms.DataGridViewTriState.[False]
        Me.dgDetalle.DefaultCellStyle = DataGridViewCellStyle5
        Me.dgDetalle.Dock = System.Windows.Forms.DockStyle.Fill
        Me.dgDetalle.Location = New System.Drawing.Point(0, 0)
        Me.dgDetalle.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.dgDetalle.Name = "dgDetalle"
        DataGridViewCellStyle6.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle6.BackColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle6.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle6.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle6.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle6.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle6.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.dgDetalle.RowHeadersDefaultCellStyle = DataGridViewCellStyle6
        Me.dgDetalle.RowTemplate.Height = 24
        Me.dgDetalle.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.dgDetalle.Size = New System.Drawing.Size(1140, 103)
        Me.dgDetalle.TabIndex = 0
        '
        'colCodigo
        '
        Me.colCodigo.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.colCodigo.HeaderText = "Code"
        Me.colCodigo.Name = "colCodigo"
        Me.colCodigo.ReadOnly = True
        Me.colCodigo.Resizable = System.Windows.Forms.DataGridViewTriState.[False]
        Me.colCodigo.Width = 70
        '
        'colArticulo
        '
        Me.colArticulo.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.colArticulo.HeaderText = "Article*"
        Me.colArticulo.Name = "colArticulo"
        Me.colArticulo.ReadOnly = True
        Me.colArticulo.Width = 81
        '
        'colIDMedida
        '
        Me.colIDMedida.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.colIDMedida.HeaderText = "IDMedida"
        Me.colIDMedida.Name = "colIDMedida"
        Me.colIDMedida.Visible = False
        '
        'colMedida
        '
        Me.colMedida.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.colMedida.HeaderText = "Measure"
        Me.colMedida.Name = "colMedida"
        Me.colMedida.ReadOnly = True
        Me.colMedida.Width = 92
        '
        'colPrecio
        '
        Me.colPrecio.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.colPrecio.HeaderText = "Price $"
        Me.colPrecio.Name = "colPrecio"
        Me.colPrecio.ReadOnly = True
        Me.colPrecio.Width = 81
        '
        'colDescuento
        '
        Me.colDescuento.HeaderText = "Dscto. %"
        Me.colDescuento.Name = "colDescuento"
        Me.colDescuento.ReadOnly = True
        Me.colDescuento.Width = 93
        '
        'colDesDolar
        '
        Me.colDesDolar.HeaderText = "Dscto.$"
        Me.colDesDolar.Name = "colDesDolar"
        Me.colDesDolar.ReadOnly = True
        Me.colDesDolar.Width = 85
        '
        'colCantidad
        '
        Me.colCantidad.HeaderText = "Quantity"
        Me.colCantidad.Name = "colCantidad"
        Me.colCantidad.ReadOnly = True
        Me.colCantidad.Width = 90
        '
        'colBultos
        '
        Me.colBultos.HeaderText = "Package"
        Me.colBultos.Name = "colBultos"
        Me.colBultos.Width = 92
        '
        'colSubtotal
        '
        Me.colSubtotal.HeaderText = "SubTotal $"
        Me.colSubtotal.Name = "colSubtotal"
        Me.colSubtotal.ReadOnly = True
        Me.colSubtotal.Width = 106
        '
        'colBodegga
        '
        Me.colBodegga.HeaderText = "Wharehouse*"
        Me.colBodegga.Name = "colBodegga"
        Me.colBodegga.ReadOnly = True
        Me.colBodegga.Width = 123
        '
        'colBoxNumber
        '
        Me.colBoxNumber.HeaderText = "Box Number"
        Me.colBoxNumber.Name = "colBoxNumber"
        Me.colBoxNumber.Width = 114
        '
        'colReserva
        '
        Me.colReserva.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.colReserva.HeaderText = "Reservation*"
        Me.colReserva.Name = "colReserva"
        Me.colReserva.ReadOnly = True
        Me.colReserva.Resizable = System.Windows.Forms.DataGridViewTriState.[True]
        Me.colReserva.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic
        Me.colReserva.Width = 118
        '
        'colProblema
        '
        Me.colProblema.HeaderText = "Problem"
        Me.colProblema.Name = "colProblema"
        Me.colProblema.Visible = False
        Me.colProblema.Width = 70
        '
        'colComentario
        '
        Me.colComentario.HeaderText = "Commentary"
        Me.colComentario.Name = "colComentario"
        Me.colComentario.Visible = False
        Me.colComentario.Width = 90
        '
        'colCantidadOriginal
        '
        Me.colCantidadOriginal.HeaderText = "CantidadOriginal"
        Me.colCantidadOriginal.Name = "colCantidadOriginal"
        Me.colCantidadOriginal.Visible = False
        Me.colCantidadOriginal.Width = 109
        '
        'colCodOriginal
        '
        Me.colCodOriginal.HeaderText = "CodigoOriginal"
        Me.colCodOriginal.Name = "colCodOriginal"
        Me.colCodOriginal.Visible = False
        '
        'coLRF2Num
        '
        Me.coLRF2Num.HeaderText = "DDoc_RF2_Cod"
        Me.coLRF2Num.Name = "coLRF2Num"
        Me.coLRF2Num.Visible = False
        Me.coLRF2Num.Width = 111
        '
        'colRF2cOD
        '
        Me.colRF2cOD.HeaderText = "DDoc_RF2_Cod"
        Me.colRF2cOD.Name = "colRF2cOD"
        Me.colRF2cOD.Visible = False
        Me.colRF2cOD.Width = 111
        '
        'colLinea
        '
        Me.colLinea.HeaderText = "Linea"
        Me.colLinea.Name = "colLinea"
        Me.colLinea.Visible = False
        Me.colLinea.Width = 58
        '
        'colPrdPNr
        '
        Me.colPrdPNr.HeaderText = "DDoc_Prd_PNr"
        Me.colPrdPNr.Name = "colPrdPNr"
        Me.colPrdPNr.Visible = False
        Me.colPrdPNr.Width = 106
        '
        'colNotas
        '
        Me.colNotas.HeaderText = "Notas"
        Me.colNotas.Name = "colNotas"
        Me.colNotas.Visible = False
        Me.colNotas.Width = 60
        '
        'colRF1Num
        '
        Me.colRF1Num.HeaderText = "DDoc_RF1_Num"
        Me.colRF1Num.Name = "colRF1Num"
        Me.colRF1Num.Visible = False
        Me.colRF1Num.Width = 114
        '
        'colReservado
        '
        Me.colReservado.HeaderText = "Reservado"
        Me.colReservado.Name = "colReservado"
        Me.colReservado.Visible = False
        Me.colReservado.Width = 84
        '
        'colAgregar
        '
        Me.colAgregar.HeaderText = "Agregar"
        Me.colAgregar.Name = "colAgregar"
        Me.colAgregar.Visible = False
        Me.colAgregar.Width = 69
        '
        'colEmpresaPol
        '
        Me.colEmpresaPol.HeaderText = "EmpresaPoliza"
        Me.colEmpresaPol.Name = "colEmpresaPol"
        Me.colEmpresaPol.Visible = False
        Me.colEmpresaPol.Width = 101
        '
        'colAnioPoliza
        '
        Me.colAnioPoliza.HeaderText = "AnioPoliza"
        Me.colAnioPoliza.Name = "colAnioPoliza"
        Me.colAnioPoliza.Visible = False
        Me.colAnioPoliza.Width = 81
        '
        'colNumPoliza
        '
        Me.colNumPoliza.HeaderText = "NumeroPoliza"
        Me.colNumPoliza.Name = "colNumPoliza"
        Me.colNumPoliza.Visible = False
        Me.colNumPoliza.Width = 97
        '
        'colLineaPoliza
        '
        Me.colLineaPoliza.HeaderText = "LineaPoliza"
        Me.colLineaPoliza.Name = "colLineaPoliza"
        Me.colLineaPoliza.Visible = False
        Me.colLineaPoliza.Width = 86
        '
        'colMarcaHSM
        '
        Me.colMarcaHSM.HeaderText = "Mark"
        Me.colMarcaHSM.Name = "colMarcaHSM"
        Me.colMarcaHSM.Visible = False
        Me.colMarcaHSM.Width = 56
        '
        'colIdEstado
        '
        Me.colIdEstado.HeaderText = "idEstado"
        Me.colIdEstado.Name = "colIdEstado"
        Me.colIdEstado.ReadOnly = True
        Me.colIdEstado.Visible = False
        Me.colIdEstado.Width = 73
        '
        'colEstado
        '
        Me.colEstado.HeaderText = "Status*"
        Me.colEstado.Name = "colEstado"
        Me.colEstado.ReadOnly = True
        Me.colEstado.Width = 82
        '
        'colGFMO
        '
        Me.colGFMO.HeaderText = "GF y MO"
        Me.colGFMO.Name = "colGFMO"
        Me.colGFMO.Visible = False
        Me.colGFMO.Width = 74
        '
        'colTipoCambio
        '
        Me.colTipoCambio.HeaderText = "Tipo Cambio"
        Me.colTipoCambio.Name = "colTipoCambio"
        Me.colTipoCambio.Visible = False
        Me.colTipoCambio.Width = 91
        '
        'colRefMKT
        '
        Me.colRefMKT.HeaderText = "Ref MKT"
        Me.colRefMKT.Name = "colRefMKT"
        Me.colRefMKT.Width = 92
        '
        'colReferenciaRamplas
        '
        Me.colReferenciaRamplas.HeaderText = "Ref Pallet"
        Me.colReferenciaRamplas.Name = "colReferenciaRamplas"
        Me.colReferenciaRamplas.Width = 98
        '
        'colGin
        '
        Me.colGin.HeaderText = "Gin"
        Me.colGin.Name = "colGin"
        Me.colGin.Visible = False
        Me.colGin.Width = 48
        '
        'colGBac
        '
        Me.colGBac.HeaderText = "GinBal"
        Me.colGBac.Name = "colGBac"
        Me.colGBac.Visible = False
        Me.colGBac.Width = 63
        '
        'colCrp
        '
        Me.colCrp.HeaderText = "CRP"
        Me.colCrp.Name = "colCrp"
        Me.colCrp.Visible = False
        Me.colCrp.Width = 54
        '
        'Panel1
        '
        Me.Panel1.Controls.Add(Me.botonQuitDetalle)
        Me.Panel1.Controls.Add(Me.botonAgreDetalle)
        Me.Panel1.Dock = System.Windows.Forms.DockStyle.Right
        Me.Panel1.Location = New System.Drawing.Point(1140, 0)
        Me.Panel1.Margin = New System.Windows.Forms.Padding(4)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(65, 103)
        Me.Panel1.TabIndex = 1
        '
        'botonQuitDetalle
        '
        Me.botonQuitDetalle.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.botonQuitDetalle.Image = Global.KARIMs_SGI.My.Resources.Resources.minus
        Me.botonQuitDetalle.Location = New System.Drawing.Point(20, 62)
        Me.botonQuitDetalle.Margin = New System.Windows.Forms.Padding(4)
        Me.botonQuitDetalle.Name = "botonQuitDetalle"
        Me.botonQuitDetalle.Size = New System.Drawing.Size(41, 36)
        Me.botonQuitDetalle.TabIndex = 9
        Me.botonQuitDetalle.UseVisualStyleBackColor = True
        '
        'botonAgreDetalle
        '
        Me.botonAgreDetalle.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.botonAgreDetalle.BackColor = System.Drawing.SystemColors.Control
        Me.botonAgreDetalle.Enabled = False
        Me.botonAgreDetalle.Image = Global.KARIMs_SGI.My.Resources.Resources.add
        Me.botonAgreDetalle.Location = New System.Drawing.Point(20, 20)
        Me.botonAgreDetalle.Margin = New System.Windows.Forms.Padding(4)
        Me.botonAgreDetalle.Name = "botonAgreDetalle"
        Me.botonAgreDetalle.Size = New System.Drawing.Size(41, 34)
        Me.botonAgreDetalle.TabIndex = 8
        Me.botonAgreDetalle.UseVisualStyleBackColor = False
        '
        'Panel3
        '
        Me.Panel3.Controls.Add(Me.gbInstDespacho)
        Me.Panel3.Controls.Add(Me.gbPedidoClientes)
        Me.Panel3.Controls.Add(Me.gbInformación)
        Me.Panel3.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel3.Location = New System.Drawing.Point(0, 0)
        Me.Panel3.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Panel3.Name = "Panel3"
        Me.Panel3.Size = New System.Drawing.Size(1205, 298)
        Me.Panel3.TabIndex = 12
        '
        'gbInstDespacho
        '
        Me.gbInstDespacho.Controls.Add(Me.checkTendido)
        Me.gbInstDespacho.Controls.Add(Me.CheckIngreso)
        Me.gbInstDespacho.Controls.Add(Me.celdaTipoIngreso)
        Me.gbInstDespacho.Controls.Add(Me.etiquetaRevisado)
        Me.gbInstDespacho.Controls.Add(Me.celdaRevisado)
        Me.gbInstDespacho.Controls.Add(Me.botonDespachos)
        Me.gbInstDespacho.Controls.Add(Me.botonParciales)
        Me.gbInstDespacho.Controls.Add(Me.celdaTelefono)
        Me.gbInstDespacho.Controls.Add(Me.celdaNit)
        Me.gbInstDespacho.Controls.Add(Me.checkRevisado)
        Me.gbInstDespacho.Controls.Add(Me.botonPolizaC)
        Me.gbInstDespacho.Controls.Add(Me.celdaEmpresa)
        Me.gbInstDespacho.Controls.Add(Me.dtpFech)
        Me.gbInstDespacho.Controls.Add(Me.celdaUsuario)
        Me.gbInstDespacho.Controls.Add(Me.celdaCatalogo)
        Me.gbInstDespacho.Controls.Add(Me.celdaIDMoneda)
        Me.gbInstDespacho.Controls.Add(Me.celdaIDCliente)
        Me.gbInstDespacho.Controls.Add(Me.celdaTasa)
        Me.gbInstDespacho.Controls.Add(Me.etiquetaTasa)
        Me.gbInstDespacho.Controls.Add(Me.botonMoneda)
        Me.gbInstDespacho.Controls.Add(Me.celdaMoneda)
        Me.gbInstDespacho.Controls.Add(Me.etiquetaMoneda)
        Me.gbInstDespacho.Controls.Add(Me.celdaDireccion)
        Me.gbInstDespacho.Controls.Add(Me.etiquetaDireccion)
        Me.gbInstDespacho.Controls.Add(Me.botonClientes)
        Me.gbInstDespacho.Controls.Add(Me.celdaCliente)
        Me.gbInstDespacho.Controls.Add(Me.etiquetaCliente)
        Me.gbInstDespacho.Controls.Add(Me.etiquetaFecha)
        Me.gbInstDespacho.Controls.Add(Me.celdaNumero)
        Me.gbInstDespacho.Controls.Add(Me.etiquetaNumero)
        Me.gbInstDespacho.Controls.Add(Me.celdaAnio)
        Me.gbInstDespacho.Controls.Add(Me.etiquetaAño)
        Me.gbInstDespacho.Location = New System.Drawing.Point(16, 7)
        Me.gbInstDespacho.Margin = New System.Windows.Forms.Padding(4)
        Me.gbInstDespacho.Name = "gbInstDespacho"
        Me.gbInstDespacho.Padding = New System.Windows.Forms.Padding(4)
        Me.gbInstDespacho.Size = New System.Drawing.Size(565, 309)
        Me.gbInstDespacho.TabIndex = 0
        Me.gbInstDespacho.TabStop = False
        Me.gbInstDespacho.Text = "Merchandise Revenue to Bodega"
        '
        'checkTendido
        '
        Me.checkTendido.AutoSize = True
        Me.checkTendido.Location = New System.Drawing.Point(245, 52)
        Me.checkTendido.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.checkTendido.Name = "checkTendido"
        Me.checkTendido.Size = New System.Drawing.Size(84, 21)
        Me.checkTendido.TabIndex = 44
        Me.checkTendido.Text = "Laid Out"
        Me.checkTendido.UseVisualStyleBackColor = True
        '
        'CheckIngreso
        '
        Me.CheckIngreso.AutoSize = True
        Me.CheckIngreso.Location = New System.Drawing.Point(245, 23)
        Me.CheckIngreso.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.CheckIngreso.Name = "CheckIngreso"
        Me.CheckIngreso.Size = New System.Drawing.Size(81, 21)
        Me.CheckIngreso.TabIndex = 43
        Me.CheckIngreso.Text = "Process"
        Me.CheckIngreso.UseVisualStyleBackColor = True
        '
        'celdaTipoIngreso
        '
        Me.celdaTipoIngreso.Location = New System.Drawing.Point(396, 94)
        Me.celdaTipoIngreso.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.celdaTipoIngreso.Name = "celdaTipoIngreso"
        Me.celdaTipoIngreso.Size = New System.Drawing.Size(25, 22)
        Me.celdaTipoIngreso.TabIndex = 42
        Me.celdaTipoIngreso.Text = "-1"
        Me.celdaTipoIngreso.Visible = False
        '
        'etiquetaRevisado
        '
        Me.etiquetaRevisado.AutoSize = True
        Me.etiquetaRevisado.Location = New System.Drawing.Point(509, 190)
        Me.etiquetaRevisado.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.etiquetaRevisado.Name = "etiquetaRevisado"
        Me.etiquetaRevisado.Size = New System.Drawing.Size(67, 17)
        Me.etiquetaRevisado.TabIndex = 41
        Me.etiquetaRevisado.Text = "Revisado"
        Me.etiquetaRevisado.Visible = False
        '
        'celdaRevisado
        '
        Me.celdaRevisado.Location = New System.Drawing.Point(515, 209)
        Me.celdaRevisado.Margin = New System.Windows.Forms.Padding(4)
        Me.celdaRevisado.Name = "celdaRevisado"
        Me.celdaRevisado.Size = New System.Drawing.Size(35, 22)
        Me.celdaRevisado.TabIndex = 40
        Me.celdaRevisado.Text = "0"
        Me.celdaRevisado.Visible = False
        '
        'botonDespachos
        '
        Me.botonDespachos.Image = CType(resources.GetObject("botonDespachos.Image"), System.Drawing.Image)
        Me.botonDespachos.Location = New System.Drawing.Point(457, 236)
        Me.botonDespachos.Margin = New System.Windows.Forms.Padding(4)
        Me.botonDespachos.Name = "botonDespachos"
        Me.botonDespachos.Size = New System.Drawing.Size(100, 46)
        Me.botonDespachos.TabIndex = 36
        Me.botonDespachos.Text = "Reviewed"
        Me.botonDespachos.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.botonDespachos.UseVisualStyleBackColor = True
        '
        'botonParciales
        '
        Me.botonParciales.Image = Global.KARIMs_SGI.My.Resources.Resources.cabinet2
        Me.botonParciales.Location = New System.Drawing.Point(427, 23)
        Me.botonParciales.Margin = New System.Windows.Forms.Padding(4)
        Me.botonParciales.Name = "botonParciales"
        Me.botonParciales.Size = New System.Drawing.Size(124, 54)
        Me.botonParciales.TabIndex = 35
        Me.botonParciales.Text = "Fragmentary"
        Me.botonParciales.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.botonParciales.UseVisualStyleBackColor = True
        Me.botonParciales.Visible = False
        '
        'celdaTelefono
        '
        Me.celdaTelefono.Location = New System.Drawing.Point(405, 199)
        Me.celdaTelefono.Margin = New System.Windows.Forms.Padding(4)
        Me.celdaTelefono.Name = "celdaTelefono"
        Me.celdaTelefono.Size = New System.Drawing.Size(97, 22)
        Me.celdaTelefono.TabIndex = 34
        Me.celdaTelefono.Visible = False
        '
        'celdaNit
        '
        Me.celdaNit.Location = New System.Drawing.Point(299, 199)
        Me.celdaNit.Margin = New System.Windows.Forms.Padding(4)
        Me.celdaNit.Name = "celdaNit"
        Me.celdaNit.Size = New System.Drawing.Size(97, 22)
        Me.celdaNit.TabIndex = 33
        Me.celdaNit.Visible = False
        '
        'checkRevisado
        '
        Me.checkRevisado.AutoSize = True
        Me.checkRevisado.Location = New System.Drawing.Point(339, 247)
        Me.checkRevisado.Margin = New System.Windows.Forms.Padding(4)
        Me.checkRevisado.Name = "checkRevisado"
        Me.checkRevisado.Size = New System.Drawing.Size(91, 21)
        Me.checkRevisado.TabIndex = 32
        Me.checkRevisado.Text = "Reviewed"
        Me.checkRevisado.UseVisualStyleBackColor = True
        Me.checkRevisado.Visible = False
        '
        'botonPolizaC
        '
        Me.botonPolizaC.Image = Global.KARIMs_SGI.My.Resources.Resources.book_open1
        Me.botonPolizaC.Location = New System.Drawing.Point(287, 236)
        Me.botonPolizaC.Margin = New System.Windows.Forms.Padding(4)
        Me.botonPolizaC.Name = "botonPolizaC"
        Me.botonPolizaC.Size = New System.Drawing.Size(39, 28)
        Me.botonPolizaC.TabIndex = 31
        Me.botonPolizaC.UseVisualStyleBackColor = True
        '
        'celdaEmpresa
        '
        Me.celdaEmpresa.Location = New System.Drawing.Point(363, 94)
        Me.celdaEmpresa.Margin = New System.Windows.Forms.Padding(4)
        Me.celdaEmpresa.Name = "celdaEmpresa"
        Me.celdaEmpresa.Size = New System.Drawing.Size(25, 22)
        Me.celdaEmpresa.TabIndex = 30
        Me.celdaEmpresa.Text = "-1"
        Me.celdaEmpresa.Visible = False
        '
        'dtpFech
        '
        Me.dtpFech.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.dtpFech.Location = New System.Drawing.Point(96, 81)
        Me.dtpFech.Margin = New System.Windows.Forms.Padding(4)
        Me.dtpFech.Name = "dtpFech"
        Me.dtpFech.Size = New System.Drawing.Size(112, 22)
        Me.dtpFech.TabIndex = 29
        '
        'celdaUsuario
        '
        Me.celdaUsuario.Location = New System.Drawing.Point(480, 82)
        Me.celdaUsuario.Margin = New System.Windows.Forms.Padding(4)
        Me.celdaUsuario.Name = "celdaUsuario"
        Me.celdaUsuario.Size = New System.Drawing.Size(25, 22)
        Me.celdaUsuario.TabIndex = 28
        Me.celdaUsuario.Text = "-1"
        Me.celdaUsuario.Visible = False
        '
        'celdaCatalogo
        '
        Me.celdaCatalogo.Location = New System.Drawing.Point(331, 94)
        Me.celdaCatalogo.Margin = New System.Windows.Forms.Padding(4)
        Me.celdaCatalogo.Name = "celdaCatalogo"
        Me.celdaCatalogo.Size = New System.Drawing.Size(25, 22)
        Me.celdaCatalogo.TabIndex = 27
        Me.celdaCatalogo.Text = "-1"
        Me.celdaCatalogo.Visible = False
        '
        'celdaIDMoneda
        '
        Me.celdaIDMoneda.Location = New System.Drawing.Point(241, 210)
        Me.celdaIDMoneda.Margin = New System.Windows.Forms.Padding(4)
        Me.celdaIDMoneda.Name = "celdaIDMoneda"
        Me.celdaIDMoneda.Size = New System.Drawing.Size(25, 22)
        Me.celdaIDMoneda.TabIndex = 25
        Me.celdaIDMoneda.Text = "-1"
        Me.celdaIDMoneda.Visible = False
        '
        'celdaIDCliente
        '
        Me.celdaIDCliente.Location = New System.Drawing.Point(525, 89)
        Me.celdaIDCliente.Margin = New System.Windows.Forms.Padding(4)
        Me.celdaIDCliente.Name = "celdaIDCliente"
        Me.celdaIDCliente.Size = New System.Drawing.Size(25, 22)
        Me.celdaIDCliente.TabIndex = 24
        Me.celdaIDCliente.Text = "-1"
        Me.celdaIDCliente.Visible = False
        '
        'celdaTasa
        '
        Me.celdaTasa.Location = New System.Drawing.Point(91, 247)
        Me.celdaTasa.Margin = New System.Windows.Forms.Padding(4)
        Me.celdaTasa.Name = "celdaTasa"
        Me.celdaTasa.Size = New System.Drawing.Size(133, 22)
        Me.celdaTasa.TabIndex = 23
        '
        'etiquetaTasa
        '
        Me.etiquetaTasa.AutoSize = True
        Me.etiquetaTasa.Location = New System.Drawing.Point(33, 251)
        Me.etiquetaTasa.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.etiquetaTasa.Name = "etiquetaTasa"
        Me.etiquetaTasa.Size = New System.Drawing.Size(38, 17)
        Me.etiquetaTasa.TabIndex = 22
        Me.etiquetaTasa.Text = "Rate"
        '
        'botonMoneda
        '
        Me.botonMoneda.Location = New System.Drawing.Point(197, 209)
        Me.botonMoneda.Margin = New System.Windows.Forms.Padding(4)
        Me.botonMoneda.Name = "botonMoneda"
        Me.botonMoneda.Size = New System.Drawing.Size(35, 25)
        Me.botonMoneda.TabIndex = 21
        Me.botonMoneda.Text = "..."
        Me.botonMoneda.UseVisualStyleBackColor = True
        '
        'celdaMoneda
        '
        Me.celdaMoneda.Location = New System.Drawing.Point(91, 209)
        Me.celdaMoneda.Margin = New System.Windows.Forms.Padding(4)
        Me.celdaMoneda.Name = "celdaMoneda"
        Me.celdaMoneda.Size = New System.Drawing.Size(97, 22)
        Me.celdaMoneda.TabIndex = 20
        '
        'etiquetaMoneda
        '
        Me.etiquetaMoneda.AutoSize = True
        Me.etiquetaMoneda.Location = New System.Drawing.Point(35, 213)
        Me.etiquetaMoneda.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.etiquetaMoneda.Name = "etiquetaMoneda"
        Me.etiquetaMoneda.Size = New System.Drawing.Size(36, 17)
        Me.etiquetaMoneda.TabIndex = 19
        Me.etiquetaMoneda.Text = "Coin"
        '
        'celdaDireccion
        '
        Me.celdaDireccion.Location = New System.Drawing.Point(91, 150)
        Me.celdaDireccion.Margin = New System.Windows.Forms.Padding(4)
        Me.celdaDireccion.Multiline = True
        Me.celdaDireccion.Name = "celdaDireccion"
        Me.celdaDireccion.Size = New System.Drawing.Size(412, 42)
        Me.celdaDireccion.TabIndex = 11
        '
        'etiquetaDireccion
        '
        Me.etiquetaDireccion.AutoSize = True
        Me.etiquetaDireccion.Location = New System.Drawing.Point(13, 153)
        Me.etiquetaDireccion.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.etiquetaDireccion.Name = "etiquetaDireccion"
        Me.etiquetaDireccion.Size = New System.Drawing.Size(60, 17)
        Me.etiquetaDireccion.TabIndex = 10
        Me.etiquetaDireccion.Text = "Address"
        '
        'botonClientes
        '
        Me.botonClientes.Location = New System.Drawing.Point(515, 118)
        Me.botonClientes.Margin = New System.Windows.Forms.Padding(4)
        Me.botonClientes.Name = "botonClientes"
        Me.botonClientes.Size = New System.Drawing.Size(35, 25)
        Me.botonClientes.TabIndex = 9
        Me.botonClientes.Text = "..."
        Me.botonClientes.UseVisualStyleBackColor = True
        '
        'celdaCliente
        '
        Me.celdaCliente.Location = New System.Drawing.Point(93, 121)
        Me.celdaCliente.Margin = New System.Windows.Forms.Padding(4)
        Me.celdaCliente.Name = "celdaCliente"
        Me.celdaCliente.ReadOnly = True
        Me.celdaCliente.Size = New System.Drawing.Size(412, 22)
        Me.celdaCliente.TabIndex = 8
        '
        'etiquetaCliente
        '
        Me.etiquetaCliente.AutoSize = True
        Me.etiquetaCliente.Location = New System.Drawing.Point(7, 123)
        Me.etiquetaCliente.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.etiquetaCliente.Name = "etiquetaCliente"
        Me.etiquetaCliente.Size = New System.Drawing.Size(61, 17)
        Me.etiquetaCliente.TabIndex = 7
        Me.etiquetaCliente.Text = "Provider"
        '
        'etiquetaFecha
        '
        Me.etiquetaFecha.AutoSize = True
        Me.etiquetaFecha.Location = New System.Drawing.Point(40, 89)
        Me.etiquetaFecha.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.etiquetaFecha.Name = "etiquetaFecha"
        Me.etiquetaFecha.Size = New System.Drawing.Size(38, 17)
        Me.etiquetaFecha.TabIndex = 5
        Me.etiquetaFecha.Text = "Date"
        '
        'celdaNumero
        '
        Me.celdaNumero.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.celdaNumero.ForeColor = System.Drawing.SystemColors.HotTrack
        Me.celdaNumero.Location = New System.Drawing.Point(91, 50)
        Me.celdaNumero.Margin = New System.Windows.Forms.Padding(4)
        Me.celdaNumero.Multiline = True
        Me.celdaNumero.Name = "celdaNumero"
        Me.celdaNumero.Size = New System.Drawing.Size(117, 22)
        Me.celdaNumero.TabIndex = 3
        Me.celdaNumero.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'etiquetaNumero
        '
        Me.etiquetaNumero.AutoSize = True
        Me.etiquetaNumero.Location = New System.Drawing.Point(25, 53)
        Me.etiquetaNumero.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.etiquetaNumero.Name = "etiquetaNumero"
        Me.etiquetaNumero.Size = New System.Drawing.Size(58, 17)
        Me.etiquetaNumero.TabIndex = 2
        Me.etiquetaNumero.Text = "Number"
        '
        'celdaAnio
        '
        Me.celdaAnio.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.celdaAnio.ForeColor = System.Drawing.SystemColors.HotTrack
        Me.celdaAnio.Location = New System.Drawing.Point(91, 22)
        Me.celdaAnio.Margin = New System.Windows.Forms.Padding(4)
        Me.celdaAnio.Name = "celdaAnio"
        Me.celdaAnio.Size = New System.Drawing.Size(119, 22)
        Me.celdaAnio.TabIndex = 1
        Me.celdaAnio.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'etiquetaAño
        '
        Me.etiquetaAño.AutoSize = True
        Me.etiquetaAño.Location = New System.Drawing.Point(35, 27)
        Me.etiquetaAño.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.etiquetaAño.Name = "etiquetaAño"
        Me.etiquetaAño.Size = New System.Drawing.Size(38, 17)
        Me.etiquetaAño.TabIndex = 0
        Me.etiquetaAño.Text = "Year"
        '
        'gbPedidoClientes
        '
        Me.gbPedidoClientes.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.gbPedidoClientes.Controls.Add(Me.celdaTipoIng)
        Me.gbPedidoClientes.Controls.Add(Me.botonPacas)
        Me.gbPedidoClientes.Controls.Add(Me.botonProduccion)
        Me.gbPedidoClientes.Controls.Add(Me.dgPolizasImportacion)
        Me.gbPedidoClientes.Location = New System.Drawing.Point(581, 7)
        Me.gbPedidoClientes.Margin = New System.Windows.Forms.Padding(4)
        Me.gbPedidoClientes.Name = "gbPedidoClientes"
        Me.gbPedidoClientes.Padding = New System.Windows.Forms.Padding(4)
        Me.gbPedidoClientes.Size = New System.Drawing.Size(624, 154)
        Me.gbPedidoClientes.TabIndex = 1
        Me.gbPedidoClientes.TabStop = False
        Me.gbPedidoClientes.Text = "Import Policy"
        '
        'celdaTipoIng
        '
        Me.celdaTipoIng.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.celdaTipoIng.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.celdaTipoIng.Location = New System.Drawing.Point(8, 127)
        Me.celdaTipoIng.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.celdaTipoIng.Name = "celdaTipoIng"
        Me.celdaTipoIng.ReadOnly = True
        Me.celdaTipoIng.Size = New System.Drawing.Size(487, 22)
        Me.celdaTipoIng.TabIndex = 39
        Me.celdaTipoIng.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'botonPacas
        '
        Me.botonPacas.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.botonPacas.Image = Global.KARIMs_SGI.My.Resources.Resources.arrow_up_blue
        Me.botonPacas.ImageAlign = System.Drawing.ContentAlignment.TopCenter
        Me.botonPacas.Location = New System.Drawing.Point(529, 16)
        Me.botonPacas.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.botonPacas.Name = "botonPacas"
        Me.botonPacas.Size = New System.Drawing.Size(84, 62)
        Me.botonPacas.TabIndex = 38
        Me.botonPacas.Text = "Load Bulks"
        Me.botonPacas.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.botonPacas.UseVisualStyleBackColor = True
        '
        'botonProduccion
        '
        Me.botonProduccion.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.botonProduccion.Image = Global.KARIMs_SGI.My.Resources.Resources.money
        Me.botonProduccion.ImageAlign = System.Drawing.ContentAlignment.TopCenter
        Me.botonProduccion.Location = New System.Drawing.Point(520, 80)
        Me.botonProduccion.Margin = New System.Windows.Forms.Padding(4)
        Me.botonProduccion.Name = "botonProduccion"
        Me.botonProduccion.Size = New System.Drawing.Size(104, 70)
        Me.botonProduccion.TabIndex = 37
        Me.botonProduccion.Text = "Get Production II"
        Me.botonProduccion.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.botonProduccion.UseVisualStyleBackColor = True
        Me.botonProduccion.Visible = False
        '
        'dgPolizasImportacion
        '
        Me.dgPolizasImportacion.AllowUserToAddRows = False
        Me.dgPolizasImportacion.AllowUserToDeleteRows = False
        Me.dgPolizasImportacion.AllowUserToOrderColumns = True
        Me.dgPolizasImportacion.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.dgPolizasImportacion.BackgroundColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle7.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle7.BackColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle7.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle7.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle7.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle7.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle7.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.dgPolizasImportacion.ColumnHeadersDefaultCellStyle = DataGridViewCellStyle7
        Me.dgPolizasImportacion.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgPolizasImportacion.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.colNumero, Me.colFecha, Me.colUsuario, Me.colReference, Me.colAno, Me.colCatalogo, Me.colEliminar})
        DataGridViewCellStyle8.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle8.BackColor = System.Drawing.SystemColors.Window
        DataGridViewCellStyle8.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle8.ForeColor = System.Drawing.SystemColors.ControlText
        DataGridViewCellStyle8.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle8.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle8.WrapMode = System.Windows.Forms.DataGridViewTriState.[False]
        Me.dgPolizasImportacion.DefaultCellStyle = DataGridViewCellStyle8
        Me.dgPolizasImportacion.Location = New System.Drawing.Point(8, 31)
        Me.dgPolizasImportacion.Margin = New System.Windows.Forms.Padding(4)
        Me.dgPolizasImportacion.MultiSelect = False
        Me.dgPolizasImportacion.Name = "dgPolizasImportacion"
        DataGridViewCellStyle9.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle9.BackColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle9.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle9.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle9.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle9.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle9.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.dgPolizasImportacion.RowHeadersDefaultCellStyle = DataGridViewCellStyle9
        Me.dgPolizasImportacion.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.dgPolizasImportacion.Size = New System.Drawing.Size(504, 87)
        Me.dgPolizasImportacion.TabIndex = 0
        '
        'colNumero
        '
        Me.colNumero.HeaderText = "Policy"
        Me.colNumero.Name = "colNumero"
        Me.colNumero.ReadOnly = True
        '
        'colFecha
        '
        Me.colFecha.HeaderText = "Date"
        Me.colFecha.Name = "colFecha"
        Me.colFecha.ReadOnly = True
        '
        'colUsuario
        '
        Me.colUsuario.HeaderText = "Operator"
        Me.colUsuario.Name = "colUsuario"
        Me.colUsuario.ReadOnly = True
        '
        'colReference
        '
        Me.colReference.HeaderText = "Reference"
        Me.colReference.Name = "colReference"
        Me.colReference.ReadOnly = True
        '
        'colAno
        '
        Me.colAno.HeaderText = "Year"
        Me.colAno.Name = "colAno"
        Me.colAno.ReadOnly = True
        Me.colAno.Visible = False
        '
        'colCatalogo
        '
        Me.colCatalogo.HeaderText = "Catalogo"
        Me.colCatalogo.Name = "colCatalogo"
        Me.colCatalogo.ReadOnly = True
        Me.colCatalogo.Visible = False
        '
        'colEliminar
        '
        Me.colEliminar.HeaderText = "Eliminar"
        Me.colEliminar.Name = "colEliminar"
        Me.colEliminar.Visible = False
        '
        'gbInformación
        '
        Me.gbInformación.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.gbInformación.Controls.Add(Me.checkMuestra)
        Me.gbInformación.Controls.Add(Me.celdaAnioProduccion)
        Me.gbInformación.Controls.Add(Me.celdaNProduccion)
        Me.gbInformación.Controls.Add(Me.celdaBodega)
        Me.gbInformación.Controls.Add(Me.celdaRef2)
        Me.gbInformación.Controls.Add(Me.etiquetaRef2)
        Me.gbInformación.Controls.Add(Me.celdaRef1)
        Me.gbInformación.Controls.Add(Me.EtiquetaRef1)
        Me.gbInformación.Controls.Add(Me.celdaRefFactura)
        Me.gbInformación.Controls.Add(Me.etiquetaRefFactura)
        Me.gbInformación.Location = New System.Drawing.Point(583, 171)
        Me.gbInformación.Margin = New System.Windows.Forms.Padding(4)
        Me.gbInformación.Name = "gbInformación"
        Me.gbInformación.Padding = New System.Windows.Forms.Padding(4)
        Me.gbInformación.Size = New System.Drawing.Size(627, 146)
        Me.gbInformación.TabIndex = 2
        Me.gbInformación.TabStop = False
        Me.gbInformación.Text = "Reference Document"
        '
        'checkMuestra
        '
        Me.checkMuestra.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.checkMuestra.AutoSize = True
        Me.checkMuestra.Location = New System.Drawing.Point(441, 30)
        Me.checkMuestra.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.checkMuestra.Name = "checkMuestra"
        Me.checkMuestra.Size = New System.Drawing.Size(109, 21)
        Me.checkMuestra.TabIndex = 31
        Me.checkMuestra.Text = "Sample fiber"
        Me.checkMuestra.UseVisualStyleBackColor = True
        Me.checkMuestra.Visible = False
        '
        'celdaAnioProduccion
        '
        Me.celdaAnioProduccion.Location = New System.Drawing.Point(369, 34)
        Me.celdaAnioProduccion.Margin = New System.Windows.Forms.Padding(4)
        Me.celdaAnioProduccion.Name = "celdaAnioProduccion"
        Me.celdaAnioProduccion.Size = New System.Drawing.Size(36, 22)
        Me.celdaAnioProduccion.TabIndex = 30
        Me.celdaAnioProduccion.Text = "-1"
        Me.celdaAnioProduccion.Visible = False
        '
        'celdaNProduccion
        '
        Me.celdaNProduccion.Location = New System.Drawing.Point(369, 55)
        Me.celdaNProduccion.Margin = New System.Windows.Forms.Padding(4)
        Me.celdaNProduccion.Name = "celdaNProduccion"
        Me.celdaNProduccion.Size = New System.Drawing.Size(36, 22)
        Me.celdaNProduccion.TabIndex = 29
        Me.celdaNProduccion.Text = "-1"
        Me.celdaNProduccion.Visible = False
        '
        'celdaBodega
        '
        Me.celdaBodega.Location = New System.Drawing.Point(369, 82)
        Me.celdaBodega.Margin = New System.Windows.Forms.Padding(4)
        Me.celdaBodega.Name = "celdaBodega"
        Me.celdaBodega.Size = New System.Drawing.Size(36, 22)
        Me.celdaBodega.TabIndex = 28
        Me.celdaBodega.Text = "-1"
        Me.celdaBodega.Visible = False
        '
        'celdaRef2
        '
        Me.celdaRef2.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.celdaRef2.BackColor = System.Drawing.SystemColors.Info
        Me.celdaRef2.Location = New System.Drawing.Point(161, 82)
        Me.celdaRef2.Margin = New System.Windows.Forms.Padding(4)
        Me.celdaRef2.Name = "celdaRef2"
        Me.celdaRef2.Size = New System.Drawing.Size(200, 22)
        Me.celdaRef2.TabIndex = 5
        Me.celdaRef2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'etiquetaRef2
        '
        Me.etiquetaRef2.AutoSize = True
        Me.etiquetaRef2.Location = New System.Drawing.Point(27, 86)
        Me.etiquetaRef2.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.etiquetaRef2.Name = "etiquetaRef2"
        Me.etiquetaRef2.Size = New System.Drawing.Size(72, 17)
        Me.etiquetaRef2.TabIndex = 4
        Me.etiquetaRef2.Text = "Ref. No. 2"
        '
        'celdaRef1
        '
        Me.celdaRef1.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.celdaRef1.BackColor = System.Drawing.SystemColors.Info
        Me.celdaRef1.Location = New System.Drawing.Point(161, 53)
        Me.celdaRef1.Margin = New System.Windows.Forms.Padding(4)
        Me.celdaRef1.Name = "celdaRef1"
        Me.celdaRef1.Size = New System.Drawing.Size(200, 22)
        Me.celdaRef1.TabIndex = 3
        Me.celdaRef1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'EtiquetaRef1
        '
        Me.EtiquetaRef1.AutoSize = True
        Me.EtiquetaRef1.Location = New System.Drawing.Point(27, 54)
        Me.EtiquetaRef1.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.EtiquetaRef1.Name = "EtiquetaRef1"
        Me.EtiquetaRef1.Size = New System.Drawing.Size(76, 17)
        Me.EtiquetaRef1.TabIndex = 2
        Me.EtiquetaRef1.Text = "Ref. No. 1 "
        '
        'celdaRefFactura
        '
        Me.celdaRefFactura.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.celdaRefFactura.BackColor = System.Drawing.SystemColors.Info
        Me.celdaRefFactura.Location = New System.Drawing.Point(161, 26)
        Me.celdaRefFactura.Margin = New System.Windows.Forms.Padding(4)
        Me.celdaRefFactura.Name = "celdaRefFactura"
        Me.celdaRefFactura.Size = New System.Drawing.Size(200, 22)
        Me.celdaRefFactura.TabIndex = 1
        Me.celdaRefFactura.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'etiquetaRefFactura
        '
        Me.etiquetaRefFactura.AutoSize = True
        Me.etiquetaRefFactura.Location = New System.Drawing.Point(27, 30)
        Me.etiquetaRefFactura.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.etiquetaRefFactura.Name = "etiquetaRefFactura"
        Me.etiquetaRefFactura.Size = New System.Drawing.Size(122, 17)
        Me.etiquetaRefFactura.TabIndex = 0
        Me.etiquetaRefFactura.Text = "Reference Invoice"
        '
        'panelTotales
        '
        Me.panelTotales.Controls.Add(Me.celdaSubTotal)
        Me.panelTotales.Controls.Add(Me.etiquetaTotal)
        Me.panelTotales.Controls.Add(Me.celdaTotal)
        Me.panelTotales.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.panelTotales.Location = New System.Drawing.Point(0, 401)
        Me.panelTotales.Margin = New System.Windows.Forms.Padding(4)
        Me.panelTotales.Name = "panelTotales"
        Me.panelTotales.Size = New System.Drawing.Size(1205, 47)
        Me.panelTotales.TabIndex = 11
        '
        'celdaSubTotal
        '
        Me.celdaSubTotal.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.celdaSubTotal.Location = New System.Drawing.Point(872, 16)
        Me.celdaSubTotal.Margin = New System.Windows.Forms.Padding(4)
        Me.celdaSubTotal.Name = "celdaSubTotal"
        Me.celdaSubTotal.Size = New System.Drawing.Size(132, 22)
        Me.celdaSubTotal.TabIndex = 5
        Me.celdaSubTotal.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'etiquetaTotal
        '
        Me.etiquetaTotal.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.etiquetaTotal.AutoSize = True
        Me.etiquetaTotal.Location = New System.Drawing.Point(823, 20)
        Me.etiquetaTotal.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.etiquetaTotal.Name = "etiquetaTotal"
        Me.etiquetaTotal.Size = New System.Drawing.Size(40, 17)
        Me.etiquetaTotal.TabIndex = 4
        Me.etiquetaTotal.Text = "Total"
        '
        'celdaTotal
        '
        Me.celdaTotal.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.celdaTotal.Location = New System.Drawing.Point(1025, 15)
        Me.celdaTotal.Margin = New System.Windows.Forms.Padding(4)
        Me.celdaTotal.Name = "celdaTotal"
        Me.celdaTotal.Size = New System.Drawing.Size(128, 22)
        Me.celdaTotal.TabIndex = 6
        Me.celdaTotal.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'panelPiePagina
        '
        Me.panelPiePagina.Controls.Add(Me.panelOculto)
        Me.panelPiePagina.Controls.Add(Me.GroupBox1)
        Me.panelPiePagina.Controls.Add(Me.CeldaNota)
        Me.panelPiePagina.Controls.Add(Me.panelDescargos)
        Me.panelPiePagina.Controls.Add(Me.panelSub)
        Me.panelPiePagina.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.panelPiePagina.Location = New System.Drawing.Point(0, 448)
        Me.panelPiePagina.Margin = New System.Windows.Forms.Padding(4)
        Me.panelPiePagina.Name = "panelPiePagina"
        Me.panelPiePagina.Size = New System.Drawing.Size(1205, 105)
        Me.panelPiePagina.TabIndex = 10
        '
        'panelOculto
        '
        Me.panelOculto.Controls.Add(Me.dgOculto)
        Me.panelOculto.Location = New System.Drawing.Point(571, 7)
        Me.panelOculto.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.panelOculto.Name = "panelOculto"
        Me.panelOculto.Size = New System.Drawing.Size(527, 162)
        Me.panelOculto.TabIndex = 1
        Me.panelOculto.Visible = False
        '
        'dgOculto
        '
        Me.dgOculto.AllowUserToAddRows = False
        Me.dgOculto.AllowUserToDeleteRows = False
        Me.dgOculto.BackgroundColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle10.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle10.BackColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle10.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle10.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle10.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle10.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle10.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.dgOculto.ColumnHeadersDefaultCellStyle = DataGridViewCellStyle10
        Me.dgOculto.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgOculto.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.colEmpresa, Me.colCat, Me.colAnio2, Me.colNumero2, Me.colLinea2, Me.colLineaDetalle, Me.colRef, Me.colTara, Me.colPaquetes, Me.colCantMedida, Me.colPesoNeto, Me.colNumCaja, Me.colTipoBulto, Me.colXtraBox, Me.col_Gin, Me.col_GBac, Me.col_Crp, Me.col_Ref})
        DataGridViewCellStyle11.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle11.BackColor = System.Drawing.SystemColors.Window
        DataGridViewCellStyle11.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle11.ForeColor = System.Drawing.SystemColors.ControlText
        DataGridViewCellStyle11.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle11.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle11.WrapMode = System.Windows.Forms.DataGridViewTriState.[False]
        Me.dgOculto.DefaultCellStyle = DataGridViewCellStyle11
        Me.dgOculto.Dock = System.Windows.Forms.DockStyle.Fill
        Me.dgOculto.Location = New System.Drawing.Point(0, 0)
        Me.dgOculto.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.dgOculto.Name = "dgOculto"
        DataGridViewCellStyle12.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle12.BackColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle12.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle12.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle12.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle12.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle12.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.dgOculto.RowHeadersDefaultCellStyle = DataGridViewCellStyle12
        Me.dgOculto.RowTemplate.Height = 24
        Me.dgOculto.Size = New System.Drawing.Size(527, 162)
        Me.dgOculto.TabIndex = 0
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.botonBanderaAzul)
        Me.GroupBox1.Controls.Add(Me.checkFech)
        Me.GroupBox1.Controls.Add(Me.dtpFecha2)
        Me.GroupBox1.Location = New System.Drawing.Point(427, 47)
        Me.GroupBox1.Margin = New System.Windows.Forms.Padding(4)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Padding = New System.Windows.Forms.Padding(4)
        Me.GroupBox1.Size = New System.Drawing.Size(257, 69)
        Me.GroupBox1.TabIndex = 13
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Date of  admission"
        '
        'botonBanderaAzul
        '
        Me.botonBanderaAzul.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.botonBanderaAzul.Image = Global.KARIMs_SGI.My.Resources.Resources.flag_blue
        Me.botonBanderaAzul.Location = New System.Drawing.Point(195, 22)
        Me.botonBanderaAzul.Margin = New System.Windows.Forms.Padding(4)
        Me.botonBanderaAzul.Name = "botonBanderaAzul"
        Me.botonBanderaAzul.Size = New System.Drawing.Size(35, 34)
        Me.botonBanderaAzul.TabIndex = 32
        Me.botonBanderaAzul.UseVisualStyleBackColor = True
        '
        'checkFech
        '
        Me.checkFech.AutoSize = True
        Me.checkFech.Location = New System.Drawing.Point(29, 34)
        Me.checkFech.Margin = New System.Windows.Forms.Padding(4)
        Me.checkFech.Name = "checkFech"
        Me.checkFech.Size = New System.Drawing.Size(18, 17)
        Me.checkFech.TabIndex = 31
        Me.checkFech.UseVisualStyleBackColor = True
        '
        'dtpFecha2
        '
        Me.dtpFecha2.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.dtpFecha2.Location = New System.Drawing.Point(57, 34)
        Me.dtpFecha2.Margin = New System.Windows.Forms.Padding(4)
        Me.dtpFecha2.Name = "dtpFecha2"
        Me.dtpFecha2.Size = New System.Drawing.Size(112, 22)
        Me.dtpFecha2.TabIndex = 30
        '
        'CeldaNota
        '
        Me.CeldaNota.BackColor = System.Drawing.SystemColors.Info
        Me.CeldaNota.Location = New System.Drawing.Point(412, 4)
        Me.CeldaNota.Margin = New System.Windows.Forms.Padding(4)
        Me.CeldaNota.Multiline = True
        Me.CeldaNota.Name = "CeldaNota"
        Me.CeldaNota.Size = New System.Drawing.Size(279, 42)
        Me.CeldaNota.TabIndex = 12
        '
        'panelDescargos
        '
        Me.panelDescargos.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.panelDescargos.Controls.Add(Me.dgDescargos)
        Me.panelDescargos.Location = New System.Drawing.Point(717, 0)
        Me.panelDescargos.Margin = New System.Windows.Forms.Padding(4)
        Me.panelDescargos.Name = "panelDescargos"
        Me.panelDescargos.Size = New System.Drawing.Size(467, 167)
        Me.panelDescargos.TabIndex = 1
        '
        'dgDescargos
        '
        Me.dgDescargos.AllowUserToAddRows = False
        Me.dgDescargos.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.dgDescargos.BackgroundColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle13.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle13.BackColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle13.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle13.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle13.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle13.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle13.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.dgDescargos.ColumnHeadersDefaultCellStyle = DataGridViewCellStyle13
        Me.dgDescargos.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgDescargos.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.colFila, Me.colYear, Me.colNum, Me.colDespacho, Me.colSaldo, Me.colPedido, Me.colLine, Me.colIEstado, Me.colFEStado})
        DataGridViewCellStyle14.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle14.BackColor = System.Drawing.SystemColors.Window
        DataGridViewCellStyle14.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle14.ForeColor = System.Drawing.SystemColors.ControlText
        DataGridViewCellStyle14.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle14.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle14.WrapMode = System.Windows.Forms.DataGridViewTriState.[False]
        Me.dgDescargos.DefaultCellStyle = DataGridViewCellStyle14
        Me.dgDescargos.Location = New System.Drawing.Point(0, 0)
        Me.dgDescargos.Margin = New System.Windows.Forms.Padding(4)
        Me.dgDescargos.MultiSelect = False
        Me.dgDescargos.Name = "dgDescargos"
        Me.dgDescargos.ReadOnly = True
        DataGridViewCellStyle15.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle15.BackColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle15.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle15.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle15.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle15.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle15.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.dgDescargos.RowHeadersDefaultCellStyle = DataGridViewCellStyle15
        Me.dgDescargos.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.dgDescargos.Size = New System.Drawing.Size(467, 116)
        Me.dgDescargos.TabIndex = 0
        '
        'colFila
        '
        Me.colFila.HeaderText = "Line"
        Me.colFila.Name = "colFila"
        Me.colFila.ReadOnly = True
        '
        'colYear
        '
        Me.colYear.HeaderText = "Year"
        Me.colYear.Name = "colYear"
        Me.colYear.ReadOnly = True
        Me.colYear.Visible = False
        '
        'colNum
        '
        Me.colNum.HeaderText = "Inst."
        Me.colNum.Name = "colNum"
        Me.colNum.ReadOnly = True
        '
        'colDespacho
        '
        Me.colDespacho.HeaderText = "Salida"
        Me.colDespacho.Name = "colDespacho"
        Me.colDespacho.ReadOnly = True
        '
        'colSaldo
        '
        Me.colSaldo.HeaderText = "Balance"
        Me.colSaldo.Name = "colSaldo"
        Me.colSaldo.ReadOnly = True
        '
        'colPedido
        '
        Me.colPedido.HeaderText = "Order Number"
        Me.colPedido.Name = "colPedido"
        Me.colPedido.ReadOnly = True
        '
        'colLine
        '
        Me.colLine.HeaderText = "Line"
        Me.colLine.Name = "colLine"
        Me.colLine.ReadOnly = True
        Me.colLine.Visible = False
        '
        'colIEstado
        '
        Me.colIEstado.HeaderText = "IEstado"
        Me.colIEstado.Name = "colIEstado"
        Me.colIEstado.ReadOnly = True
        Me.colIEstado.Visible = False
        '
        'colFEStado
        '
        Me.colFEStado.HeaderText = "FEstado"
        Me.colFEStado.Name = "colFEStado"
        Me.colFEStado.ReadOnly = True
        Me.colFEStado.Visible = False
        '
        'panelSub
        '
        Me.panelSub.Controls.Add(Me.dgSubdocumentos)
        Me.panelSub.Location = New System.Drawing.Point(0, 0)
        Me.panelSub.Margin = New System.Windows.Forms.Padding(4)
        Me.panelSub.Name = "panelSub"
        Me.panelSub.Size = New System.Drawing.Size(404, 167)
        Me.panelSub.TabIndex = 0
        '
        'dgSubdocumentos
        '
        Me.dgSubdocumentos.AllowUserToAddRows = False
        Me.dgSubdocumentos.BackgroundColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle16.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle16.BackColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle16.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle16.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle16.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle16.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle16.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.dgSubdocumentos.ColumnHeadersDefaultCellStyle = DataGridViewCellStyle16
        Me.dgSubdocumentos.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgSubdocumentos.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.colClave, Me.colDocumento, Me.colDisponible})
        DataGridViewCellStyle17.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle17.BackColor = System.Drawing.SystemColors.Window
        DataGridViewCellStyle17.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle17.ForeColor = System.Drawing.SystemColors.ControlText
        DataGridViewCellStyle17.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle17.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle17.WrapMode = System.Windows.Forms.DataGridViewTriState.[False]
        Me.dgSubdocumentos.DefaultCellStyle = DataGridViewCellStyle17
        Me.dgSubdocumentos.Location = New System.Drawing.Point(0, 0)
        Me.dgSubdocumentos.Margin = New System.Windows.Forms.Padding(4)
        Me.dgSubdocumentos.MultiSelect = False
        Me.dgSubdocumentos.Name = "dgSubdocumentos"
        Me.dgSubdocumentos.ReadOnly = True
        DataGridViewCellStyle18.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle18.BackColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle18.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle18.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle18.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle18.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle18.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.dgSubdocumentos.RowHeadersDefaultCellStyle = DataGridViewCellStyle18
        Me.dgSubdocumentos.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.dgSubdocumentos.Size = New System.Drawing.Size(404, 98)
        Me.dgSubdocumentos.TabIndex = 0
        '
        'colClave
        '
        Me.colClave.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.colClave.HeaderText = "Clave"
        Me.colClave.Name = "colClave"
        Me.colClave.ReadOnly = True
        Me.colClave.Visible = False
        '
        'colDocumento
        '
        Me.colDocumento.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.colDocumento.HeaderText = "Document"
        Me.colDocumento.Name = "colDocumento"
        Me.colDocumento.ReadOnly = True
        Me.colDocumento.Width = 101
        '
        'colDisponible
        '
        Me.colDisponible.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill
        Me.colDisponible.HeaderText = "Available"
        Me.colDisponible.Name = "colDisponible"
        Me.colDisponible.ReadOnly = True
        '
        'botonImprimir
        '
        Me.botonImprimir.Image = CType(resources.GetObject("botonImprimir.Image"), System.Drawing.Image)
        Me.botonImprimir.Location = New System.Drawing.Point(272, 14)
        Me.botonImprimir.Margin = New System.Windows.Forms.Padding(4)
        Me.botonImprimir.Name = "botonImprimir"
        Me.botonImprimir.Size = New System.Drawing.Size(79, 53)
        Me.botonImprimir.TabIndex = 42
        Me.botonImprimir.Text = "Print"
        Me.botonImprimir.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.botonImprimir.UseVisualStyleBackColor = True
        '
        'BotonImprimirRotulo
        '
        Me.BotonImprimirRotulo.Image = CType(resources.GetObject("BotonImprimirRotulo.Image"), System.Drawing.Image)
        Me.BotonImprimirRotulo.Location = New System.Drawing.Point(359, 14)
        Me.BotonImprimirRotulo.Margin = New System.Windows.Forms.Padding(4)
        Me.BotonImprimirRotulo.Name = "BotonImprimirRotulo"
        Me.BotonImprimirRotulo.Size = New System.Drawing.Size(103, 53)
        Me.BotonImprimirRotulo.TabIndex = 43
        Me.BotonImprimirRotulo.Text = "Label Print"
        Me.BotonImprimirRotulo.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.BotonImprimirRotulo.UseVisualStyleBackColor = True
        '
        'BarraTitulo1
        '
        Me.BarraTitulo1.BackColor = System.Drawing.Color.WhiteSmoke
        Me.BarraTitulo1.Dock = System.Windows.Forms.DockStyle.Top
        Me.BarraTitulo1.Location = New System.Drawing.Point(0, 92)
        Me.BarraTitulo1.Margin = New System.Windows.Forms.Padding(5)
        Me.BarraTitulo1.Name = "BarraTitulo1"
        Me.BarraTitulo1.Size = New System.Drawing.Size(1333, 41)
        Me.BarraTitulo1.TabIndex = 5
        '
        'Encabezado1
        '
        Me.Encabezado1.Dock = System.Windows.Forms.DockStyle.Top
        Me.Encabezado1.Location = New System.Drawing.Point(0, 0)
        Me.Encabezado1.Margin = New System.Windows.Forms.Padding(5)
        Me.Encabezado1.Name = "Encabezado1"
        Me.Encabezado1.Size = New System.Drawing.Size(1333, 92)
        Me.Encabezado1.TabIndex = 1
        '
        'botonPOWE
        '
        Me.botonPOWE.Image = Global.KARIMs_SGI.My.Resources.Resources.arrow_right_blue
        Me.botonPOWE.Location = New System.Drawing.Point(469, 15)
        Me.botonPOWE.Margin = New System.Windows.Forms.Padding(4)
        Me.botonPOWE.Name = "botonPOWE"
        Me.botonPOWE.Size = New System.Drawing.Size(151, 53)
        Me.botonPOWE.TabIndex = 44
        Me.botonPOWE.Text = "Make Entrance"
        Me.botonPOWE.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.botonPOWE.UseVisualStyleBackColor = True
        Me.botonPOWE.Visible = False
        '
        'colEmpresa
        '
        Me.colEmpresa.HeaderText = "Empresa"
        Me.colEmpresa.Name = "colEmpresa"
        '
        'colCat
        '
        Me.colCat.HeaderText = "Catalogo"
        Me.colCat.Name = "colCat"
        '
        'colAnio2
        '
        Me.colAnio2.HeaderText = "Anio"
        Me.colAnio2.Name = "colAnio2"
        '
        'colNumero2
        '
        Me.colNumero2.HeaderText = "Numero"
        Me.colNumero2.Name = "colNumero2"
        '
        'colLinea2
        '
        Me.colLinea2.HeaderText = "Linea"
        Me.colLinea2.Name = "colLinea2"
        '
        'colLineaDetalle
        '
        Me.colLineaDetalle.HeaderText = "LineaDetalle"
        Me.colLineaDetalle.Name = "colLineaDetalle"
        '
        'colRef
        '
        Me.colRef.HeaderText = "Color_Cono"
        Me.colRef.Name = "colRef"
        '
        'colTara
        '
        Me.colTara.HeaderText = "Conos"
        Me.colTara.Name = "colTara"
        '
        'colPaquetes
        '
        Me.colPaquetes.HeaderText = "Turno"
        Me.colPaquetes.Name = "colPaquetes"
        '
        'colCantMedida
        '
        Me.colCantMedida.HeaderText = "PesoBruto"
        Me.colCantMedida.Name = "colCantMedida"
        '
        'colPesoNeto
        '
        Me.colPesoNeto.HeaderText = "Peso Neto"
        Me.colPesoNeto.Name = "colPesoNeto"
        '
        'colNumCaja
        '
        Me.colNumCaja.HeaderText = "Caja No."
        Me.colNumCaja.Name = "colNumCaja"
        '
        'colTipoBulto
        '
        Me.colTipoBulto.HeaderText = "Tara"
        Me.colTipoBulto.Name = "colTipoBulto"
        '
        'colXtraBox
        '
        Me.colXtraBox.HeaderText = "XtraBox"
        Me.colXtraBox.Name = "colXtraBox"
        '
        'col_Gin
        '
        Me.col_Gin.HeaderText = "Gin"
        Me.col_Gin.Name = "col_Gin"
        '
        'col_GBac
        '
        Me.col_GBac.HeaderText = "Gin Bal"
        Me.col_GBac.Name = "col_GBac"
        '
        'col_Crp
        '
        Me.col_Crp.HeaderText = "Crp"
        Me.col_Crp.Name = "col_Crp"
        '
        'col_Ref
        '
        Me.col_Ref.HeaderText = "Ref"
        Me.col_Ref.Name = "col_Ref"
        '
        'frmIngresoBodega
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1333, 919)
        Me.Controls.Add(Me.botonPOWE)
        Me.Controls.Add(Me.BotonImprimirRotulo)
        Me.Controls.Add(Me.botonImprimir)
        Me.Controls.Add(Me.panelDocumento)
        Me.Controls.Add(Me.BarraTitulo1)
        Me.Controls.Add(Me.panelIngresoABodega)
        Me.Controls.Add(Me.Encabezado1)
        Me.Margin = New System.Windows.Forms.Padding(4)
        Me.Name = "frmIngresoBodega"
        Me.Text = "frmIngresoBodega"
        Me.WindowState = System.Windows.Forms.FormWindowState.Maximized
        Me.panelIngresoABodega.ResumeLayout(False)
        Me.panelLista.ResumeLayout(False)
        CType(Me.dgLista, System.ComponentModel.ISupportInitialize).EndInit()
        Me.panelFecha.ResumeLayout(False)
        Me.panelFecha.PerformLayout()
        Me.panelInferior.ResumeLayout(False)
        Me.panelInferior.PerformLayout()
        Me.panelDocumento.ResumeLayout(False)
        Me.panelDetalle.ResumeLayout(False)
        CType(Me.dgDetalle, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Panel1.ResumeLayout(False)
        Me.Panel3.ResumeLayout(False)
        Me.gbInstDespacho.ResumeLayout(False)
        Me.gbInstDespacho.PerformLayout()
        Me.gbPedidoClientes.ResumeLayout(False)
        Me.gbPedidoClientes.PerformLayout()
        CType(Me.dgPolizasImportacion, System.ComponentModel.ISupportInitialize).EndInit()
        Me.gbInformación.ResumeLayout(False)
        Me.gbInformación.PerformLayout()
        Me.panelTotales.ResumeLayout(False)
        Me.panelTotales.PerformLayout()
        Me.panelPiePagina.ResumeLayout(False)
        Me.panelPiePagina.PerformLayout()
        Me.panelOculto.ResumeLayout(False)
        CType(Me.dgOculto, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.panelDescargos.ResumeLayout(False)
        CType(Me.dgDescargos, System.ComponentModel.ISupportInitialize).EndInit()
        Me.panelSub.ResumeLayout(False)
        CType(Me.dgSubdocumentos, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents panelIngresoABodega As System.Windows.Forms.Panel
    Friend WithEvents Encabezado1 As KARIMs_SGI.encabezado
    Friend WithEvents panelLista As System.Windows.Forms.Panel
    Friend WithEvents dgLista As System.Windows.Forms.DataGridView
    Friend WithEvents panelFecha As System.Windows.Forms.Panel
    Friend WithEvents botonPendientes As System.Windows.Forms.Button
    Friend WithEvents botonActualizar As System.Windows.Forms.Button
    Friend WithEvents dtpFin As System.Windows.Forms.DateTimePicker
    Friend WithEvents etiquetaFin As System.Windows.Forms.Label
    Friend WithEvents dtpInicio As System.Windows.Forms.DateTimePicker
    Friend WithEvents checkFecha As System.Windows.Forms.CheckBox
    Friend WithEvents panelInferior As System.Windows.Forms.Panel
    Friend WithEvents TextBox2 As System.Windows.Forms.TextBox
    Friend WithEvents etiquetaModificado As System.Windows.Forms.Label
    Friend WithEvents panelDocumento As System.Windows.Forms.Panel
    Friend WithEvents panelPiePagina As System.Windows.Forms.Panel
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents checkFech As System.Windows.Forms.CheckBox
    Friend WithEvents dtpFecha2 As System.Windows.Forms.DateTimePicker
    Friend WithEvents CeldaNota As System.Windows.Forms.TextBox
    Friend WithEvents panelDescargos As System.Windows.Forms.Panel
    Friend WithEvents dgDescargos As System.Windows.Forms.DataGridView
    Friend WithEvents panelSub As System.Windows.Forms.Panel
    Friend WithEvents dgSubdocumentos As System.Windows.Forms.DataGridView
    Friend WithEvents botonQuitDetalle As System.Windows.Forms.Button
    Friend WithEvents botonAgreDetalle As System.Windows.Forms.Button
    Friend WithEvents panelDetalle As System.Windows.Forms.Panel
    Friend WithEvents dgDetalle As System.Windows.Forms.DataGridView
    Friend WithEvents gbInformación As System.Windows.Forms.GroupBox
    Friend WithEvents celdaRef2 As System.Windows.Forms.TextBox
    Friend WithEvents etiquetaRef2 As System.Windows.Forms.Label
    Friend WithEvents celdaRef1 As System.Windows.Forms.TextBox
    Friend WithEvents EtiquetaRef1 As System.Windows.Forms.Label
    Friend WithEvents celdaRefFactura As System.Windows.Forms.TextBox
    Friend WithEvents etiquetaRefFactura As System.Windows.Forms.Label
    Friend WithEvents gbPedidoClientes As System.Windows.Forms.GroupBox
    Friend WithEvents dgPolizasImportacion As System.Windows.Forms.DataGridView
    Friend WithEvents celdaTotal As System.Windows.Forms.TextBox
    Friend WithEvents gbInstDespacho As System.Windows.Forms.GroupBox
    Friend WithEvents dtpFech As System.Windows.Forms.DateTimePicker
    Friend WithEvents celdaUsuario As System.Windows.Forms.TextBox
    Friend WithEvents celdaCatalogo As System.Windows.Forms.TextBox
    Friend WithEvents celdaIDMoneda As System.Windows.Forms.TextBox
    Friend WithEvents celdaIDCliente As System.Windows.Forms.TextBox
    Friend WithEvents celdaTasa As System.Windows.Forms.TextBox
    Friend WithEvents etiquetaTasa As System.Windows.Forms.Label
    Friend WithEvents botonMoneda As System.Windows.Forms.Button
    Friend WithEvents celdaMoneda As System.Windows.Forms.TextBox
    Friend WithEvents etiquetaMoneda As System.Windows.Forms.Label
    Friend WithEvents celdaDireccion As System.Windows.Forms.TextBox
    Friend WithEvents etiquetaDireccion As System.Windows.Forms.Label
    Friend WithEvents botonClientes As System.Windows.Forms.Button
    Friend WithEvents celdaCliente As System.Windows.Forms.TextBox
    Friend WithEvents etiquetaCliente As System.Windows.Forms.Label
    Friend WithEvents etiquetaFecha As System.Windows.Forms.Label
    Friend WithEvents celdaNumero As System.Windows.Forms.TextBox
    Friend WithEvents etiquetaNumero As System.Windows.Forms.Label
    Friend WithEvents celdaAnio As System.Windows.Forms.TextBox
    Friend WithEvents etiquetaAño As System.Windows.Forms.Label
    Friend WithEvents celdaSubTotal As System.Windows.Forms.TextBox
    Friend WithEvents etiquetaTotal As System.Windows.Forms.Label
    Friend WithEvents botonBanderaAzul As System.Windows.Forms.Button
    Friend WithEvents BarraTitulo1 As KARIMs_SGI.BarraTitulo
    Friend WithEvents celdaEmpresa As System.Windows.Forms.TextBox
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
    Friend WithEvents colClave As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colDocumento As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colDisponible As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents panelTotales As System.Windows.Forms.Panel
    Friend WithEvents botonPolizaC As System.Windows.Forms.Button
    Friend WithEvents checkRevisado As System.Windows.Forms.CheckBox
    Friend WithEvents colCodigoOriginal As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents celdaTelefono As System.Windows.Forms.TextBox
    Friend WithEvents celdaNit As System.Windows.Forms.TextBox
    Friend WithEvents botonParciales As System.Windows.Forms.Button
    Friend WithEvents botonDespachos As System.Windows.Forms.Button
    Friend WithEvents etiquetaRevisado As System.Windows.Forms.Label
    Friend WithEvents celdaRevisado As System.Windows.Forms.TextBox
    Friend WithEvents TextBox1 As System.Windows.Forms.TextBox
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents TextBox3 As System.Windows.Forms.TextBox
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents colFila As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colYear As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colNum As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colDespacho As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colSaldo As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colPedido As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colLine As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colIEstado As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colFEStado As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colNumero As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colFecha As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colUsuario As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colReference As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colAno As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colCatalogo As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colEliminar As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents botonImprimir As Button
    Friend WithEvents celdaBodega As System.Windows.Forms.TextBox
    Friend WithEvents panelOculto As System.Windows.Forms.Panel
    Friend WithEvents dgOculto As System.Windows.Forms.DataGridView
    Friend WithEvents botonProduccion As System.Windows.Forms.Button
    Friend WithEvents celdaNProduccion As System.Windows.Forms.TextBox
    Friend WithEvents celdaAnioProduccion As System.Windows.Forms.TextBox
    Friend WithEvents colNumber As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colDate As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colNombre As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colClase As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colReferencia As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colBodega As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colAnio As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colDireccion As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colTasa As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colIDMoneda As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colSimMoneda As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colCorrelativo As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colRevisado As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents botonPacas As Button
    Friend WithEvents Panel3 As System.Windows.Forms.Panel
    Friend WithEvents celdaTipoIngreso As System.Windows.Forms.TextBox
    Friend WithEvents celdaTipoIng As System.Windows.Forms.TextBox
    Friend WithEvents checkMuestra As System.Windows.Forms.CheckBox
    Friend WithEvents CheckIngreso As System.Windows.Forms.CheckBox
    Friend WithEvents colCodigo As DataGridViewTextBoxColumn
    Friend WithEvents colArticulo As DataGridViewTextBoxColumn
    Friend WithEvents colIDMedida As DataGridViewTextBoxColumn
    Friend WithEvents colMedida As DataGridViewTextBoxColumn
    Friend WithEvents colPrecio As DataGridViewTextBoxColumn
    Friend WithEvents colDescuento As DataGridViewTextBoxColumn
    Friend WithEvents colDesDolar As DataGridViewTextBoxColumn
    Friend WithEvents colCantidad As DataGridViewTextBoxColumn
    Friend WithEvents colBultos As DataGridViewTextBoxColumn
    Friend WithEvents colSubtotal As DataGridViewTextBoxColumn
    Friend WithEvents colBodegga As DataGridViewTextBoxColumn
    Friend WithEvents colBoxNumber As DataGridViewTextBoxColumn
    Friend WithEvents colReserva As DataGridViewButtonColumn
    Friend WithEvents colProblema As DataGridViewTextBoxColumn
    Friend WithEvents colComentario As DataGridViewTextBoxColumn
    Friend WithEvents colCantidadOriginal As DataGridViewTextBoxColumn
    Friend WithEvents colCodOriginal As DataGridViewTextBoxColumn
    Friend WithEvents coLRF2Num As DataGridViewTextBoxColumn
    Friend WithEvents colRF2cOD As DataGridViewTextBoxColumn
    Friend WithEvents colLinea As DataGridViewTextBoxColumn
    Friend WithEvents colPrdPNr As DataGridViewTextBoxColumn
    Friend WithEvents colNotas As DataGridViewTextBoxColumn
    Friend WithEvents colRF1Num As DataGridViewTextBoxColumn
    Friend WithEvents colReservado As DataGridViewTextBoxColumn
    Friend WithEvents colAgregar As DataGridViewTextBoxColumn
    Friend WithEvents colEmpresaPol As DataGridViewTextBoxColumn
    Friend WithEvents colAnioPoliza As DataGridViewTextBoxColumn
    Friend WithEvents colNumPoliza As DataGridViewTextBoxColumn
    Friend WithEvents colLineaPoliza As DataGridViewTextBoxColumn
    Friend WithEvents colMarcaHSM As DataGridViewTextBoxColumn
    Friend WithEvents colIdEstado As DataGridViewTextBoxColumn
    Friend WithEvents colEstado As DataGridViewTextBoxColumn
    Friend WithEvents colGFMO As DataGridViewTextBoxColumn
    Friend WithEvents colTipoCambio As DataGridViewTextBoxColumn
    Friend WithEvents colRefMKT As DataGridViewTextBoxColumn
    Friend WithEvents colReferenciaRamplas As DataGridViewTextBoxColumn
    Friend WithEvents colGin As DataGridViewTextBoxColumn
    Friend WithEvents colGBac As DataGridViewTextBoxColumn
    Friend WithEvents colCrp As DataGridViewTextBoxColumn
    Friend WithEvents BotonImprimirRotulo As Button
    Friend WithEvents checkTendido As System.Windows.Forms.CheckBox
    Friend WithEvents botonPOWE As Button
    Friend WithEvents colEmpresa As DataGridViewTextBoxColumn
    Friend WithEvents colCat As DataGridViewTextBoxColumn
    Friend WithEvents colAnio2 As DataGridViewTextBoxColumn
    Friend WithEvents colNumero2 As DataGridViewTextBoxColumn
    Friend WithEvents colLinea2 As DataGridViewTextBoxColumn
    Friend WithEvents colLineaDetalle As DataGridViewTextBoxColumn
    Friend WithEvents colRef As DataGridViewTextBoxColumn
    Friend WithEvents colTara As DataGridViewTextBoxColumn
    Friend WithEvents colPaquetes As DataGridViewTextBoxColumn
    Friend WithEvents colCantMedida As DataGridViewTextBoxColumn
    Friend WithEvents colPesoNeto As DataGridViewTextBoxColumn
    Friend WithEvents colNumCaja As DataGridViewTextBoxColumn
    Friend WithEvents colTipoBulto As DataGridViewTextBoxColumn
    Friend WithEvents colXtraBox As DataGridViewTextBoxColumn
    Friend WithEvents col_Gin As DataGridViewTextBoxColumn
    Friend WithEvents col_GBac As DataGridViewTextBoxColumn
    Friend WithEvents col_Crp As DataGridViewTextBoxColumn
    Friend WithEvents col_Ref As DataGridViewTextBoxColumn
End Class
