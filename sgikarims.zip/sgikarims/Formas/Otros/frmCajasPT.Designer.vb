﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class frmCajasPT
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Dim DataGridViewCellStyle1 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle2 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle3 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle4 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle5 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle6 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Me.panelListaPrincipal = New System.Windows.Forms.Panel()
        Me.dgLista = New System.Windows.Forms.DataGridView()
        Me.colCatalogo = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colAnio = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colNumber = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colDate = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colReferencia = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colPO = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colLoteId = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.panelFecha = New System.Windows.Forms.Panel()
        Me.botonActualizar = New System.Windows.Forms.Button()
        Me.dtpFin = New System.Windows.Forms.DateTimePicker()
        Me.etiquetaFin = New System.Windows.Forms.Label()
        Me.dtpInicio = New System.Windows.Forms.DateTimePicker()
        Me.checkFecha = New System.Windows.Forms.CheckBox()
        Me.panelDocumento = New System.Windows.Forms.Panel()
        Me.Panel2 = New System.Windows.Forms.Panel()
        Me.dgOrdenado = New System.Windows.Forms.DataGridView()
        Me.col_catalogo_o = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.col_Ano_o = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.col_numero_o = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.col_linea_o = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.col_numLote_o = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.col_fecha_o = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.col_correlativo_o = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.col_tara_o = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.col_pesoNeto_o = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.col_pesoBruto_o = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.col_estado_o = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.col_numIngreso_o = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.col_anoIngreso_o = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.col_lineaIngreso_o = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.col_lineaLote_o = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.col_lineaBox_o = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.dgDetalle = New System.Windows.Forms.DataGridView()
        Me.col_catalogo = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.col_ano = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.col_numero = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.col_linea = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.col_numLote = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.col_fecha = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.col_correlativo = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.col_tara = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.col_PesoNeto = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.col_PesoBruto = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.col_estado = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.col_numIngreso = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.col_anoIngreso = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.col_lineaIngreso = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.col_lineaLote = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.col_lineabox = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.botonQuitDetalle = New System.Windows.Forms.Button()
        Me.panelEncabezado = New System.Windows.Forms.Panel()
        Me.btnSeleccionFecha = New System.Windows.Forms.Button()
        Me.botonImprimirConoEmpacador = New System.Windows.Forms.Button()
        Me.dtpPalletFin = New System.Windows.Forms.DateTimePicker()
        Me.botonFrame = New System.Windows.Forms.Button()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.botonColorCono = New System.Windows.Forms.Button()
        Me.dtpPalletInicio = New System.Windows.Forms.DateTimePicker()
        Me.botonEmpacador = New System.Windows.Forms.Button()
        Me.CheckBox1 = New System.Windows.Forms.CheckBox()
        Me.TextBox1 = New System.Windows.Forms.TextBox()
        Me.btnImprimirEtiquetas = New System.Windows.Forms.Button()
        Me.celdaIdTurno = New System.Windows.Forms.TextBox()
        Me.botonTurno = New System.Windows.Forms.Button()
        Me.celdaTurno = New System.Windows.Forms.TextBox()
        Me.lblTurno = New System.Windows.Forms.Label()
        Me.botonNoCapturaPeso = New System.Windows.Forms.PictureBox()
        Me.celdaVelocidad = New System.Windows.Forms.TextBox()
        Me.celdaCorrelativo = New System.Windows.Forms.TextBox()
        Me.etiquetaCorrelativo = New System.Windows.Forms.Label()
        Me.celdaAnoLote = New System.Windows.Forms.TextBox()
        Me.botonAgreDetalle = New System.Windows.Forms.Button()
        Me.celdaPuerto = New System.Windows.Forms.TextBox()
        Me.botonCapturaPeso = New System.Windows.Forms.PictureBox()
        Me.celdaPesoBoton = New System.Windows.Forms.TextBox()
        Me.lblPesoBoton = New System.Windows.Forms.Label()
        Me.celdaPesoManual = New System.Windows.Forms.TextBox()
        Me.lblPesoManual = New System.Windows.Forms.Label()
        Me.celdaIdLote = New System.Windows.Forms.TextBox()
        Me.botonNumeroLote = New System.Windows.Forms.Button()
        Me.celdaNumeroLote = New System.Windows.Forms.TextBox()
        Me.celdaidAnoPO = New System.Windows.Forms.TextBox()
        Me.celdaIdProducto = New System.Windows.Forms.TextBox()
        Me.celdaIdTipoLote = New System.Windows.Forms.TextBox()
        Me.celdaIdEmpacador = New System.Windows.Forms.TextBox()
        Me.celdaIdFrame = New System.Windows.Forms.TextBox()
        Me.celdaIdColorEtiqueta = New System.Windows.Forms.TextBox()
        Me.celdaIdColorCono = New System.Windows.Forms.TextBox()
        Me.celdaIdPO = New System.Windows.Forms.TextBox()
        Me.checkActivar = New System.Windows.Forms.CheckBox()
        Me.celdaProducto = New System.Windows.Forms.TextBox()
        Me.celdaEmpacador = New System.Windows.Forms.TextBox()
        Me.etiquetaEmpacador = New System.Windows.Forms.Label()
        Me.celdaTipoLote = New System.Windows.Forms.TextBox()
        Me.etiquetaTipoLote = New System.Windows.Forms.Label()
        Me.lblNumeroLote = New System.Windows.Forms.Label()
        Me.etiquetaProducto = New System.Windows.Forms.Label()
        Me.celdaColorCono = New System.Windows.Forms.TextBox()
        Me.etiquetaColorCono = New System.Windows.Forms.Label()
        Me.celdaPO = New System.Windows.Forms.TextBox()
        Me.etiquetaPO = New System.Windows.Forms.Label()
        Me.celdaTara = New System.Windows.Forms.TextBox()
        Me.etiquetaTara = New System.Windows.Forms.Label()
        Me.celdaRollosCaja = New System.Windows.Forms.TextBox()
        Me.etiquetaRollosCaja = New System.Windows.Forms.Label()
        Me.celdaFrame = New System.Windows.Forms.TextBox()
        Me.etiquetaFrame = New System.Windows.Forms.Label()
        Me.celdaEtiquetaColor = New System.Windows.Forms.TextBox()
        Me.etiquetaEtiquetaColor = New System.Windows.Forms.Label()
        Me.celdaNumero = New System.Windows.Forms.TextBox()
        Me.celdaAnio = New System.Windows.Forms.TextBox()
        Me.dtpFecha = New System.Windows.Forms.DateTimePicker()
        Me.etiquetaFecha = New System.Windows.Forms.Label()
        Me.botonEmbalaje = New System.Windows.Forms.Button()
        Me.celdaIdEmbalaje = New System.Windows.Forms.TextBox()
        Me.celdaEmbalaje = New System.Windows.Forms.TextBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.BarraTitulo1 = New KARIMs_SGI.BarraTitulo()
        Me.Encabezado1 = New KARIMs_SGI.encabezado()
        Me.panelListaPrincipal.SuspendLayout()
        CType(Me.dgLista, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.panelFecha.SuspendLayout()
        Me.panelDocumento.SuspendLayout()
        Me.Panel2.SuspendLayout()
        CType(Me.dgOrdenado, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.dgDetalle, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Panel1.SuspendLayout()
        Me.panelEncabezado.SuspendLayout()
        CType(Me.botonNoCapturaPeso, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.botonCapturaPeso, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'panelListaPrincipal
        '
        Me.panelListaPrincipal.Controls.Add(Me.dgLista)
        Me.panelListaPrincipal.Controls.Add(Me.panelFecha)
        Me.panelListaPrincipal.Dock = System.Windows.Forms.DockStyle.Top
        Me.panelListaPrincipal.Location = New System.Drawing.Point(0, 102)
        Me.panelListaPrincipal.Margin = New System.Windows.Forms.Padding(2)
        Me.panelListaPrincipal.Name = "panelListaPrincipal"
        Me.panelListaPrincipal.Size = New System.Drawing.Size(1208, 73)
        Me.panelListaPrincipal.TabIndex = 4
        '
        'dgLista
        '
        Me.dgLista.AllowUserToAddRows = False
        Me.dgLista.AllowUserToDeleteRows = False
        Me.dgLista.AllowUserToOrderColumns = True
        Me.dgLista.BackgroundColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle1.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.dgLista.ColumnHeadersDefaultCellStyle = DataGridViewCellStyle1
        Me.dgLista.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgLista.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.colCatalogo, Me.colAnio, Me.colNumber, Me.colDate, Me.colReferencia, Me.colPO, Me.colLoteId})
        DataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle2.BackColor = System.Drawing.SystemColors.Window
        DataGridViewCellStyle2.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.ControlText
        DataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.[False]
        Me.dgLista.DefaultCellStyle = DataGridViewCellStyle2
        Me.dgLista.Dock = System.Windows.Forms.DockStyle.Fill
        Me.dgLista.Location = New System.Drawing.Point(0, 44)
        Me.dgLista.MultiSelect = False
        Me.dgLista.Name = "dgLista"
        Me.dgLista.ReadOnly = True
        Me.dgLista.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.dgLista.Size = New System.Drawing.Size(1208, 29)
        Me.dgLista.TabIndex = 1
        '
        'colCatalogo
        '
        Me.colCatalogo.HeaderText = "Catalogo"
        Me.colCatalogo.Name = "colCatalogo"
        Me.colCatalogo.ReadOnly = True
        Me.colCatalogo.Visible = False
        '
        'colAnio
        '
        Me.colAnio.HeaderText = "Year"
        Me.colAnio.Name = "colAnio"
        Me.colAnio.ReadOnly = True
        Me.colAnio.Visible = False
        '
        'colNumber
        '
        Me.colNumber.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.colNumber.HeaderText = "Number"
        Me.colNumber.Name = "colNumber"
        Me.colNumber.ReadOnly = True
        Me.colNumber.Width = 69
        '
        'colDate
        '
        Me.colDate.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.colDate.HeaderText = "Date"
        Me.colDate.Name = "colDate"
        Me.colDate.ReadOnly = True
        Me.colDate.Width = 55
        '
        'colReferencia
        '
        Me.colReferencia.HeaderText = "Lot No."
        Me.colReferencia.Name = "colReferencia"
        Me.colReferencia.ReadOnly = True
        '
        'colPO
        '
        Me.colPO.FillWeight = 250.0!
        Me.colPO.HeaderText = "PO"
        Me.colPO.Name = "colPO"
        Me.colPO.ReadOnly = True
        Me.colPO.Width = 300
        '
        'colLoteId
        '
        Me.colLoteId.HeaderText = "LoteId"
        Me.colLoteId.Name = "colLoteId"
        Me.colLoteId.ReadOnly = True
        '
        'panelFecha
        '
        Me.panelFecha.Controls.Add(Me.botonActualizar)
        Me.panelFecha.Controls.Add(Me.dtpFin)
        Me.panelFecha.Controls.Add(Me.etiquetaFin)
        Me.panelFecha.Controls.Add(Me.dtpInicio)
        Me.panelFecha.Controls.Add(Me.checkFecha)
        Me.panelFecha.Dock = System.Windows.Forms.DockStyle.Top
        Me.panelFecha.Location = New System.Drawing.Point(0, 0)
        Me.panelFecha.Name = "panelFecha"
        Me.panelFecha.Size = New System.Drawing.Size(1208, 44)
        Me.panelFecha.TabIndex = 0
        '
        'botonActualizar
        '
        Me.botonActualizar.Location = New System.Drawing.Point(436, 12)
        Me.botonActualizar.Name = "botonActualizar"
        Me.botonActualizar.Size = New System.Drawing.Size(75, 23)
        Me.botonActualizar.TabIndex = 4
        Me.botonActualizar.Text = "To Update"
        Me.botonActualizar.UseVisualStyleBackColor = True
        '
        'dtpFin
        '
        Me.dtpFin.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.dtpFin.Location = New System.Drawing.Point(326, 14)
        Me.dtpFin.Name = "dtpFin"
        Me.dtpFin.Size = New System.Drawing.Size(86, 20)
        Me.dtpFin.TabIndex = 3
        '
        'etiquetaFin
        '
        Me.etiquetaFin.AutoSize = True
        Me.etiquetaFin.Location = New System.Drawing.Point(271, 17)
        Me.etiquetaFin.Name = "etiquetaFin"
        Me.etiquetaFin.Size = New System.Drawing.Size(51, 13)
        Me.etiquetaFin.TabIndex = 2
        Me.etiquetaFin.Text = "and Date"
        '
        'dtpInicio
        '
        Me.dtpInicio.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.dtpInicio.Location = New System.Drawing.Point(182, 13)
        Me.dtpInicio.Name = "dtpInicio"
        Me.dtpInicio.Size = New System.Drawing.Size(85, 20)
        Me.dtpInicio.TabIndex = 1
        '
        'checkFecha
        '
        Me.checkFecha.AutoSize = True
        Me.checkFecha.Checked = True
        Me.checkFecha.CheckState = System.Windows.Forms.CheckState.Checked
        Me.checkFecha.Location = New System.Drawing.Point(7, 17)
        Me.checkFecha.Name = "checkFecha"
        Me.checkFecha.Size = New System.Drawing.Size(174, 17)
        Me.checkFecha.TabIndex = 0
        Me.checkFecha.Text = "show documents between date"
        Me.checkFecha.UseVisualStyleBackColor = True
        '
        'panelDocumento
        '
        Me.panelDocumento.Controls.Add(Me.Panel2)
        Me.panelDocumento.Controls.Add(Me.Panel1)
        Me.panelDocumento.Controls.Add(Me.panelEncabezado)
        Me.panelDocumento.Location = New System.Drawing.Point(0, 181)
        Me.panelDocumento.Name = "panelDocumento"
        Me.panelDocumento.Size = New System.Drawing.Size(1041, 501)
        Me.panelDocumento.TabIndex = 10
        '
        'Panel2
        '
        Me.Panel2.Controls.Add(Me.dgOrdenado)
        Me.Panel2.Controls.Add(Me.dgDetalle)
        Me.Panel2.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Panel2.Location = New System.Drawing.Point(0, 292)
        Me.Panel2.Name = "Panel2"
        Me.Panel2.Size = New System.Drawing.Size(976, 209)
        Me.Panel2.TabIndex = 3
        '
        'dgOrdenado
        '
        Me.dgOrdenado.AllowUserToAddRows = False
        Me.dgOrdenado.AllowUserToDeleteRows = False
        Me.dgOrdenado.BackgroundColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle3.BackColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle3.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle3.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle3.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle3.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.dgOrdenado.ColumnHeadersDefaultCellStyle = DataGridViewCellStyle3
        Me.dgOrdenado.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgOrdenado.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.col_catalogo_o, Me.col_Ano_o, Me.col_numero_o, Me.col_linea_o, Me.col_numLote_o, Me.col_fecha_o, Me.col_correlativo_o, Me.col_tara_o, Me.col_pesoNeto_o, Me.col_pesoBruto_o, Me.col_estado_o, Me.col_numIngreso_o, Me.col_anoIngreso_o, Me.col_lineaIngreso_o, Me.col_lineaLote_o, Me.col_lineaBox_o})
        DataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle4.BackColor = System.Drawing.SystemColors.Window
        DataGridViewCellStyle4.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle4.ForeColor = System.Drawing.SystemColors.ControlText
        DataGridViewCellStyle4.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle4.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle4.WrapMode = System.Windows.Forms.DataGridViewTriState.[False]
        Me.dgOrdenado.DefaultCellStyle = DataGridViewCellStyle4
        Me.dgOrdenado.Dock = System.Windows.Forms.DockStyle.Fill
        Me.dgOrdenado.Location = New System.Drawing.Point(0, 109)
        Me.dgOrdenado.MultiSelect = False
        Me.dgOrdenado.Name = "dgOrdenado"
        Me.dgOrdenado.ReadOnly = True
        Me.dgOrdenado.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.dgOrdenado.Size = New System.Drawing.Size(976, 100)
        Me.dgOrdenado.TabIndex = 11
        '
        'col_catalogo_o
        '
        Me.col_catalogo_o.HeaderText = "Catalogo"
        Me.col_catalogo_o.Name = "col_catalogo_o"
        Me.col_catalogo_o.ReadOnly = True
        Me.col_catalogo_o.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        Me.col_catalogo_o.Visible = False
        '
        'col_Ano_o
        '
        Me.col_Ano_o.HeaderText = "Year"
        Me.col_Ano_o.Name = "col_Ano_o"
        Me.col_Ano_o.ReadOnly = True
        Me.col_Ano_o.Visible = False
        '
        'col_numero_o
        '
        Me.col_numero_o.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.col_numero_o.HeaderText = "Number"
        Me.col_numero_o.Name = "col_numero_o"
        Me.col_numero_o.ReadOnly = True
        Me.col_numero_o.Visible = False
        Me.col_numero_o.Width = 69
        '
        'col_linea_o
        '
        Me.col_linea_o.HeaderText = "Linea"
        Me.col_linea_o.Name = "col_linea_o"
        Me.col_linea_o.ReadOnly = True
        '
        'col_numLote_o
        '
        Me.col_numLote_o.HeaderText = "No. Lote"
        Me.col_numLote_o.Name = "col_numLote_o"
        Me.col_numLote_o.ReadOnly = True
        '
        'col_fecha_o
        '
        Me.col_fecha_o.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.col_fecha_o.HeaderText = "Date"
        Me.col_fecha_o.Name = "col_fecha_o"
        Me.col_fecha_o.ReadOnly = True
        Me.col_fecha_o.Width = 55
        '
        'col_correlativo_o
        '
        Me.col_correlativo_o.HeaderText = "Correlativo"
        Me.col_correlativo_o.Name = "col_correlativo_o"
        Me.col_correlativo_o.ReadOnly = True
        Me.col_correlativo_o.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        '
        'col_tara_o
        '
        Me.col_tara_o.HeaderText = "Tara"
        Me.col_tara_o.Name = "col_tara_o"
        Me.col_tara_o.ReadOnly = True
        '
        'col_pesoNeto_o
        '
        Me.col_pesoNeto_o.HeaderText = "Peso Neto"
        Me.col_pesoNeto_o.Name = "col_pesoNeto_o"
        Me.col_pesoNeto_o.ReadOnly = True
        '
        'col_pesoBruto_o
        '
        Me.col_pesoBruto_o.HeaderText = "Peso Bruto"
        Me.col_pesoBruto_o.Name = "col_pesoBruto_o"
        Me.col_pesoBruto_o.ReadOnly = True
        '
        'col_estado_o
        '
        Me.col_estado_o.HeaderText = "Estado"
        Me.col_estado_o.Name = "col_estado_o"
        Me.col_estado_o.ReadOnly = True
        '
        'col_numIngreso_o
        '
        Me.col_numIngreso_o.HeaderText = "numIngreso"
        Me.col_numIngreso_o.Name = "col_numIngreso_o"
        Me.col_numIngreso_o.ReadOnly = True
        '
        'col_anoIngreso_o
        '
        Me.col_anoIngreso_o.HeaderText = "Año Ingreso"
        Me.col_anoIngreso_o.Name = "col_anoIngreso_o"
        Me.col_anoIngreso_o.ReadOnly = True
        '
        'col_lineaIngreso_o
        '
        Me.col_lineaIngreso_o.HeaderText = "Linea Ingreso"
        Me.col_lineaIngreso_o.Name = "col_lineaIngreso_o"
        Me.col_lineaIngreso_o.ReadOnly = True
        '
        'col_lineaLote_o
        '
        Me.col_lineaLote_o.HeaderText = "Linea Lote"
        Me.col_lineaLote_o.Name = "col_lineaLote_o"
        Me.col_lineaLote_o.ReadOnly = True
        '
        'col_lineaBox_o
        '
        Me.col_lineaBox_o.HeaderText = "linea box"
        Me.col_lineaBox_o.Name = "col_lineaBox_o"
        Me.col_lineaBox_o.ReadOnly = True
        '
        'dgDetalle
        '
        Me.dgDetalle.AllowUserToAddRows = False
        Me.dgDetalle.AllowUserToDeleteRows = False
        Me.dgDetalle.BackgroundColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle5.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle5.BackColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle5.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle5.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle5.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle5.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle5.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.dgDetalle.ColumnHeadersDefaultCellStyle = DataGridViewCellStyle5
        Me.dgDetalle.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgDetalle.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.col_catalogo, Me.col_ano, Me.col_numero, Me.col_linea, Me.col_numLote, Me.col_fecha, Me.col_correlativo, Me.col_tara, Me.col_PesoNeto, Me.col_PesoBruto, Me.col_estado, Me.col_numIngreso, Me.col_anoIngreso, Me.col_lineaIngreso, Me.col_lineaLote, Me.col_lineabox})
        DataGridViewCellStyle6.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle6.BackColor = System.Drawing.SystemColors.Window
        DataGridViewCellStyle6.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle6.ForeColor = System.Drawing.SystemColors.ControlText
        DataGridViewCellStyle6.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle6.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle6.WrapMode = System.Windows.Forms.DataGridViewTriState.[False]
        Me.dgDetalle.DefaultCellStyle = DataGridViewCellStyle6
        Me.dgDetalle.Dock = System.Windows.Forms.DockStyle.Top
        Me.dgDetalle.Location = New System.Drawing.Point(0, 0)
        Me.dgDetalle.MultiSelect = False
        Me.dgDetalle.Name = "dgDetalle"
        Me.dgDetalle.ReadOnly = True
        Me.dgDetalle.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.dgDetalle.Size = New System.Drawing.Size(976, 109)
        Me.dgDetalle.TabIndex = 2
        Me.dgDetalle.Visible = False
        '
        'col_catalogo
        '
        Me.col_catalogo.HeaderText = "Catalogo"
        Me.col_catalogo.Name = "col_catalogo"
        Me.col_catalogo.ReadOnly = True
        Me.col_catalogo.Visible = False
        '
        'col_ano
        '
        Me.col_ano.HeaderText = "Year"
        Me.col_ano.Name = "col_ano"
        Me.col_ano.ReadOnly = True
        Me.col_ano.Visible = False
        '
        'col_numero
        '
        Me.col_numero.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.col_numero.HeaderText = "Number"
        Me.col_numero.Name = "col_numero"
        Me.col_numero.ReadOnly = True
        Me.col_numero.Visible = False
        Me.col_numero.Width = 69
        '
        'col_linea
        '
        Me.col_linea.HeaderText = "Linea"
        Me.col_linea.Name = "col_linea"
        Me.col_linea.ReadOnly = True
        '
        'col_numLote
        '
        Me.col_numLote.HeaderText = "No. Lote"
        Me.col_numLote.Name = "col_numLote"
        Me.col_numLote.ReadOnly = True
        '
        'col_fecha
        '
        Me.col_fecha.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.col_fecha.HeaderText = "Date"
        Me.col_fecha.Name = "col_fecha"
        Me.col_fecha.ReadOnly = True
        Me.col_fecha.Width = 55
        '
        'col_correlativo
        '
        Me.col_correlativo.HeaderText = "Correlativo"
        Me.col_correlativo.Name = "col_correlativo"
        Me.col_correlativo.ReadOnly = True
        '
        'col_tara
        '
        Me.col_tara.HeaderText = "Tara"
        Me.col_tara.Name = "col_tara"
        Me.col_tara.ReadOnly = True
        '
        'col_PesoNeto
        '
        Me.col_PesoNeto.HeaderText = "Peso Neto"
        Me.col_PesoNeto.Name = "col_PesoNeto"
        Me.col_PesoNeto.ReadOnly = True
        '
        'col_PesoBruto
        '
        Me.col_PesoBruto.HeaderText = "Peso Bruto"
        Me.col_PesoBruto.Name = "col_PesoBruto"
        Me.col_PesoBruto.ReadOnly = True
        '
        'col_estado
        '
        Me.col_estado.HeaderText = "Estado"
        Me.col_estado.Name = "col_estado"
        Me.col_estado.ReadOnly = True
        '
        'col_numIngreso
        '
        Me.col_numIngreso.HeaderText = "numIngreso"
        Me.col_numIngreso.Name = "col_numIngreso"
        Me.col_numIngreso.ReadOnly = True
        '
        'col_anoIngreso
        '
        Me.col_anoIngreso.HeaderText = "Año Ingreso"
        Me.col_anoIngreso.Name = "col_anoIngreso"
        Me.col_anoIngreso.ReadOnly = True
        '
        'col_lineaIngreso
        '
        Me.col_lineaIngreso.HeaderText = "Linea Ingreso"
        Me.col_lineaIngreso.Name = "col_lineaIngreso"
        Me.col_lineaIngreso.ReadOnly = True
        '
        'col_lineaLote
        '
        Me.col_lineaLote.HeaderText = "Linea Lote"
        Me.col_lineaLote.Name = "col_lineaLote"
        Me.col_lineaLote.ReadOnly = True
        '
        'col_lineabox
        '
        Me.col_lineabox.HeaderText = "linea box"
        Me.col_lineabox.Name = "col_lineabox"
        Me.col_lineabox.ReadOnly = True
        '
        'Panel1
        '
        Me.Panel1.Controls.Add(Me.botonQuitDetalle)
        Me.Panel1.Dock = System.Windows.Forms.DockStyle.Right
        Me.Panel1.Location = New System.Drawing.Point(976, 292)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(65, 209)
        Me.Panel1.TabIndex = 0
        '
        'botonQuitDetalle
        '
        Me.botonQuitDetalle.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.botonQuitDetalle.Image = Global.KARIMs_SGI.My.Resources.Resources.minus
        Me.botonQuitDetalle.Location = New System.Drawing.Point(31, 31)
        Me.botonQuitDetalle.Name = "botonQuitDetalle"
        Me.botonQuitDetalle.Size = New System.Drawing.Size(31, 29)
        Me.botonQuitDetalle.TabIndex = 0
        Me.botonQuitDetalle.UseVisualStyleBackColor = True
        '
        'panelEncabezado
        '
        Me.panelEncabezado.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.panelEncabezado.Controls.Add(Me.botonEmbalaje)
        Me.panelEncabezado.Controls.Add(Me.celdaIdEmbalaje)
        Me.panelEncabezado.Controls.Add(Me.celdaEmbalaje)
        Me.panelEncabezado.Controls.Add(Me.Label2)
        Me.panelEncabezado.Controls.Add(Me.btnSeleccionFecha)
        Me.panelEncabezado.Controls.Add(Me.botonImprimirConoEmpacador)
        Me.panelEncabezado.Controls.Add(Me.dtpPalletFin)
        Me.panelEncabezado.Controls.Add(Me.botonFrame)
        Me.panelEncabezado.Controls.Add(Me.Label1)
        Me.panelEncabezado.Controls.Add(Me.botonColorCono)
        Me.panelEncabezado.Controls.Add(Me.dtpPalletInicio)
        Me.panelEncabezado.Controls.Add(Me.botonEmpacador)
        Me.panelEncabezado.Controls.Add(Me.CheckBox1)
        Me.panelEncabezado.Controls.Add(Me.TextBox1)
        Me.panelEncabezado.Controls.Add(Me.btnImprimirEtiquetas)
        Me.panelEncabezado.Controls.Add(Me.celdaIdTurno)
        Me.panelEncabezado.Controls.Add(Me.botonTurno)
        Me.panelEncabezado.Controls.Add(Me.celdaTurno)
        Me.panelEncabezado.Controls.Add(Me.lblTurno)
        Me.panelEncabezado.Controls.Add(Me.botonNoCapturaPeso)
        Me.panelEncabezado.Controls.Add(Me.celdaVelocidad)
        Me.panelEncabezado.Controls.Add(Me.celdaCorrelativo)
        Me.panelEncabezado.Controls.Add(Me.etiquetaCorrelativo)
        Me.panelEncabezado.Controls.Add(Me.celdaAnoLote)
        Me.panelEncabezado.Controls.Add(Me.botonAgreDetalle)
        Me.panelEncabezado.Controls.Add(Me.celdaPuerto)
        Me.panelEncabezado.Controls.Add(Me.botonCapturaPeso)
        Me.panelEncabezado.Controls.Add(Me.celdaPesoBoton)
        Me.panelEncabezado.Controls.Add(Me.lblPesoBoton)
        Me.panelEncabezado.Controls.Add(Me.celdaPesoManual)
        Me.panelEncabezado.Controls.Add(Me.lblPesoManual)
        Me.panelEncabezado.Controls.Add(Me.celdaIdLote)
        Me.panelEncabezado.Controls.Add(Me.botonNumeroLote)
        Me.panelEncabezado.Controls.Add(Me.celdaNumeroLote)
        Me.panelEncabezado.Controls.Add(Me.celdaidAnoPO)
        Me.panelEncabezado.Controls.Add(Me.celdaIdProducto)
        Me.panelEncabezado.Controls.Add(Me.celdaIdTipoLote)
        Me.panelEncabezado.Controls.Add(Me.celdaIdEmpacador)
        Me.panelEncabezado.Controls.Add(Me.celdaIdFrame)
        Me.panelEncabezado.Controls.Add(Me.celdaIdColorEtiqueta)
        Me.panelEncabezado.Controls.Add(Me.celdaIdColorCono)
        Me.panelEncabezado.Controls.Add(Me.celdaIdPO)
        Me.panelEncabezado.Controls.Add(Me.checkActivar)
        Me.panelEncabezado.Controls.Add(Me.celdaProducto)
        Me.panelEncabezado.Controls.Add(Me.celdaEmpacador)
        Me.panelEncabezado.Controls.Add(Me.etiquetaEmpacador)
        Me.panelEncabezado.Controls.Add(Me.celdaTipoLote)
        Me.panelEncabezado.Controls.Add(Me.etiquetaTipoLote)
        Me.panelEncabezado.Controls.Add(Me.lblNumeroLote)
        Me.panelEncabezado.Controls.Add(Me.etiquetaProducto)
        Me.panelEncabezado.Controls.Add(Me.celdaColorCono)
        Me.panelEncabezado.Controls.Add(Me.etiquetaColorCono)
        Me.panelEncabezado.Controls.Add(Me.celdaPO)
        Me.panelEncabezado.Controls.Add(Me.etiquetaPO)
        Me.panelEncabezado.Controls.Add(Me.celdaTara)
        Me.panelEncabezado.Controls.Add(Me.etiquetaTara)
        Me.panelEncabezado.Controls.Add(Me.celdaRollosCaja)
        Me.panelEncabezado.Controls.Add(Me.etiquetaRollosCaja)
        Me.panelEncabezado.Controls.Add(Me.celdaFrame)
        Me.panelEncabezado.Controls.Add(Me.etiquetaFrame)
        Me.panelEncabezado.Controls.Add(Me.celdaEtiquetaColor)
        Me.panelEncabezado.Controls.Add(Me.etiquetaEtiquetaColor)
        Me.panelEncabezado.Controls.Add(Me.celdaNumero)
        Me.panelEncabezado.Controls.Add(Me.celdaAnio)
        Me.panelEncabezado.Controls.Add(Me.dtpFecha)
        Me.panelEncabezado.Controls.Add(Me.etiquetaFecha)
        Me.panelEncabezado.Dock = System.Windows.Forms.DockStyle.Top
        Me.panelEncabezado.Location = New System.Drawing.Point(0, 0)
        Me.panelEncabezado.Margin = New System.Windows.Forms.Padding(2)
        Me.panelEncabezado.Name = "panelEncabezado"
        Me.panelEncabezado.Size = New System.Drawing.Size(1041, 292)
        Me.panelEncabezado.TabIndex = 1
        '
        'btnSeleccionFecha
        '
        Me.btnSeleccionFecha.Location = New System.Drawing.Point(413, 260)
        Me.btnSeleccionFecha.Name = "btnSeleccionFecha"
        Me.btnSeleccionFecha.Size = New System.Drawing.Size(75, 23)
        Me.btnSeleccionFecha.TabIndex = 9
        Me.btnSeleccionFecha.Text = "To Update"
        Me.btnSeleccionFecha.UseVisualStyleBackColor = True
        '
        'botonImprimirConoEmpacador
        '
        Me.botonImprimirConoEmpacador.BackColor = System.Drawing.SystemColors.Control
        Me.botonImprimirConoEmpacador.Image = Global.KARIMs_SGI.My.Resources.Resources.printLabels
        Me.botonImprimirConoEmpacador.Location = New System.Drawing.Point(895, 181)
        Me.botonImprimirConoEmpacador.Name = "botonImprimirConoEmpacador"
        Me.botonImprimirConoEmpacador.Size = New System.Drawing.Size(100, 64)
        Me.botonImprimirConoEmpacador.TabIndex = 117
        Me.botonImprimirConoEmpacador.Text = "cono empacador"
        Me.botonImprimirConoEmpacador.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.botonImprimirConoEmpacador.UseVisualStyleBackColor = False
        '
        'dtpPalletFin
        '
        Me.dtpPalletFin.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.dtpPalletFin.Location = New System.Drawing.Point(310, 262)
        Me.dtpPalletFin.Name = "dtpPalletFin"
        Me.dtpPalletFin.Size = New System.Drawing.Size(86, 20)
        Me.dtpPalletFin.TabIndex = 8
        '
        'botonFrame
        '
        Me.botonFrame.Location = New System.Drawing.Point(630, 79)
        Me.botonFrame.Margin = New System.Windows.Forms.Padding(2)
        Me.botonFrame.Name = "botonFrame"
        Me.botonFrame.Size = New System.Drawing.Size(25, 19)
        Me.botonFrame.TabIndex = 35
        Me.botonFrame.Text = "..."
        Me.botonFrame.UseVisualStyleBackColor = True
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(255, 265)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(51, 13)
        Me.Label1.TabIndex = 7
        Me.Label1.Text = "and Date"
        '
        'botonColorCono
        '
        Me.botonColorCono.Location = New System.Drawing.Point(290, 83)
        Me.botonColorCono.Margin = New System.Windows.Forms.Padding(2)
        Me.botonColorCono.Name = "botonColorCono"
        Me.botonColorCono.Size = New System.Drawing.Size(25, 19)
        Me.botonColorCono.TabIndex = 119
        Me.botonColorCono.Text = "..."
        Me.botonColorCono.UseVisualStyleBackColor = True
        '
        'dtpPalletInicio
        '
        Me.dtpPalletInicio.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.dtpPalletInicio.Location = New System.Drawing.Point(166, 261)
        Me.dtpPalletInicio.Name = "dtpPalletInicio"
        Me.dtpPalletInicio.Size = New System.Drawing.Size(85, 20)
        Me.dtpPalletInicio.TabIndex = 6
        '
        'botonEmpacador
        '
        Me.botonEmpacador.Location = New System.Drawing.Point(630, 34)
        Me.botonEmpacador.Margin = New System.Windows.Forms.Padding(2)
        Me.botonEmpacador.Name = "botonEmpacador"
        Me.botonEmpacador.Size = New System.Drawing.Size(25, 19)
        Me.botonEmpacador.TabIndex = 118
        Me.botonEmpacador.Text = "..."
        Me.botonEmpacador.UseVisualStyleBackColor = True
        '
        'CheckBox1
        '
        Me.CheckBox1.AutoSize = True
        Me.CheckBox1.Checked = True
        Me.CheckBox1.CheckState = System.Windows.Forms.CheckState.Checked
        Me.CheckBox1.Location = New System.Drawing.Point(10, 265)
        Me.CheckBox1.Name = "CheckBox1"
        Me.CheckBox1.Size = New System.Drawing.Size(152, 17)
        Me.CheckBox1.TabIndex = 5
        Me.CheckBox1.Text = "show pallets between date"
        Me.CheckBox1.UseVisualStyleBackColor = True
        '
        'TextBox1
        '
        Me.TextBox1.Location = New System.Drawing.Point(19, 131)
        Me.TextBox1.Margin = New System.Windows.Forms.Padding(2)
        Me.TextBox1.Name = "TextBox1"
        Me.TextBox1.ReadOnly = True
        Me.TextBox1.Size = New System.Drawing.Size(319, 20)
        Me.TextBox1.TabIndex = 117
        Me.TextBox1.Visible = False
        '
        'btnImprimirEtiquetas
        '
        Me.btnImprimirEtiquetas.BackColor = System.Drawing.SystemColors.Control
        Me.btnImprimirEtiquetas.Image = Global.KARIMs_SGI.My.Resources.Resources.printLabels
        Me.btnImprimirEtiquetas.Location = New System.Drawing.Point(789, 181)
        Me.btnImprimirEtiquetas.Name = "btnImprimirEtiquetas"
        Me.btnImprimirEtiquetas.Size = New System.Drawing.Size(100, 64)
        Me.btnImprimirEtiquetas.TabIndex = 116
        Me.btnImprimirEtiquetas.Text = "Imprimir Etiquetas"
        Me.btnImprimirEtiquetas.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.btnImprimirEtiquetas.UseVisualStyleBackColor = False
        '
        'celdaIdTurno
        '
        Me.celdaIdTurno.Location = New System.Drawing.Point(415, 8)
        Me.celdaIdTurno.Margin = New System.Windows.Forms.Padding(2)
        Me.celdaIdTurno.Name = "celdaIdTurno"
        Me.celdaIdTurno.ReadOnly = True
        Me.celdaIdTurno.Size = New System.Drawing.Size(34, 20)
        Me.celdaIdTurno.TabIndex = 113
        Me.celdaIdTurno.Visible = False
        '
        'botonTurno
        '
        Me.botonTurno.Location = New System.Drawing.Point(630, 9)
        Me.botonTurno.Margin = New System.Windows.Forms.Padding(2)
        Me.botonTurno.Name = "botonTurno"
        Me.botonTurno.Size = New System.Drawing.Size(25, 19)
        Me.botonTurno.TabIndex = 115
        Me.botonTurno.Text = "..."
        Me.botonTurno.UseVisualStyleBackColor = True
        '
        'celdaTurno
        '
        Me.celdaTurno.Location = New System.Drawing.Point(453, 8)
        Me.celdaTurno.Margin = New System.Windows.Forms.Padding(2)
        Me.celdaTurno.Name = "celdaTurno"
        Me.celdaTurno.ReadOnly = True
        Me.celdaTurno.Size = New System.Drawing.Size(173, 20)
        Me.celdaTurno.TabIndex = 114
        '
        'lblTurno
        '
        Me.lblTurno.AutoSize = True
        Me.lblTurno.Location = New System.Drawing.Point(355, 12)
        Me.lblTurno.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lblTurno.Name = "lblTurno"
        Me.lblTurno.Size = New System.Drawing.Size(38, 13)
        Me.lblTurno.TabIndex = 112
        Me.lblTurno.Text = "Turno:"
        '
        'botonNoCapturaPeso
        '
        Me.botonNoCapturaPeso.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.botonNoCapturaPeso.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.botonNoCapturaPeso.Cursor = System.Windows.Forms.Cursors.Hand
        Me.botonNoCapturaPeso.Image = Global.KARIMs_SGI.My.Resources.Resources.balanza_no_existe
        Me.botonNoCapturaPeso.Location = New System.Drawing.Point(702, 34)
        Me.botonNoCapturaPeso.Name = "botonNoCapturaPeso"
        Me.botonNoCapturaPeso.Size = New System.Drawing.Size(158, 142)
        Me.botonNoCapturaPeso.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.botonNoCapturaPeso.TabIndex = 111
        Me.botonNoCapturaPeso.TabStop = False
        '
        'celdaVelocidad
        '
        Me.celdaVelocidad.Enabled = False
        Me.celdaVelocidad.Location = New System.Drawing.Point(789, 9)
        Me.celdaVelocidad.Margin = New System.Windows.Forms.Padding(2)
        Me.celdaVelocidad.Name = "celdaVelocidad"
        Me.celdaVelocidad.ReadOnly = True
        Me.celdaVelocidad.Size = New System.Drawing.Size(71, 20)
        Me.celdaVelocidad.TabIndex = 11
        '
        'celdaCorrelativo
        '
        Me.celdaCorrelativo.Location = New System.Drawing.Point(506, 189)
        Me.celdaCorrelativo.Margin = New System.Windows.Forms.Padding(2)
        Me.celdaCorrelativo.Name = "celdaCorrelativo"
        Me.celdaCorrelativo.Size = New System.Drawing.Size(148, 20)
        Me.celdaCorrelativo.TabIndex = 6
        '
        'etiquetaCorrelativo
        '
        Me.etiquetaCorrelativo.AutoSize = True
        Me.etiquetaCorrelativo.Location = New System.Drawing.Point(439, 196)
        Me.etiquetaCorrelativo.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.etiquetaCorrelativo.Name = "etiquetaCorrelativo"
        Me.etiquetaCorrelativo.Size = New System.Drawing.Size(63, 13)
        Me.etiquetaCorrelativo.TabIndex = 5
        Me.etiquetaCorrelativo.Text = "Correlativo: "
        '
        'celdaAnoLote
        '
        Me.celdaAnoLote.Location = New System.Drawing.Point(37, 34)
        Me.celdaAnoLote.Margin = New System.Windows.Forms.Padding(2)
        Me.celdaAnoLote.Name = "celdaAnoLote"
        Me.celdaAnoLote.ReadOnly = True
        Me.celdaAnoLote.Size = New System.Drawing.Size(34, 20)
        Me.celdaAnoLote.TabIndex = 6
        Me.celdaAnoLote.Visible = False
        '
        'botonAgreDetalle
        '
        Me.botonAgreDetalle.BackColor = System.Drawing.SystemColors.Control
        Me.botonAgreDetalle.Image = Global.KARIMs_SGI.My.Resources.Resources.cajas
        Me.botonAgreDetalle.Location = New System.Drawing.Point(688, 181)
        Me.botonAgreDetalle.Name = "botonAgreDetalle"
        Me.botonAgreDetalle.Size = New System.Drawing.Size(96, 64)
        Me.botonAgreDetalle.TabIndex = 9
        Me.botonAgreDetalle.Text = "Agregar Cajas"
        Me.botonAgreDetalle.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.botonAgreDetalle.UseVisualStyleBackColor = False
        '
        'celdaPuerto
        '
        Me.celdaPuerto.Location = New System.Drawing.Point(702, 9)
        Me.celdaPuerto.Margin = New System.Windows.Forms.Padding(2)
        Me.celdaPuerto.Name = "celdaPuerto"
        Me.celdaPuerto.ReadOnly = True
        Me.celdaPuerto.Size = New System.Drawing.Size(71, 20)
        Me.celdaPuerto.TabIndex = 10
        '
        'botonCapturaPeso
        '
        Me.botonCapturaPeso.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.botonCapturaPeso.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.botonCapturaPeso.Cursor = System.Windows.Forms.Cursors.Hand
        Me.botonCapturaPeso.Image = Global.KARIMs_SGI.My.Resources.Resources.balanza
        Me.botonCapturaPeso.Location = New System.Drawing.Point(702, 33)
        Me.botonCapturaPeso.Name = "botonCapturaPeso"
        Me.botonCapturaPeso.Size = New System.Drawing.Size(158, 142)
        Me.botonCapturaPeso.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.botonCapturaPeso.TabIndex = 104
        Me.botonCapturaPeso.TabStop = False
        '
        'celdaPesoBoton
        '
        Me.celdaPesoBoton.Enabled = False
        Me.celdaPesoBoton.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.celdaPesoBoton.Location = New System.Drawing.Point(506, 213)
        Me.celdaPesoBoton.Margin = New System.Windows.Forms.Padding(2)
        Me.celdaPesoBoton.Name = "celdaPesoBoton"
        Me.celdaPesoBoton.Size = New System.Drawing.Size(148, 29)
        Me.celdaPesoBoton.TabIndex = 8
        '
        'lblPesoBoton
        '
        Me.lblPesoBoton.AutoSize = True
        Me.lblPesoBoton.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblPesoBoton.Location = New System.Drawing.Point(355, 216)
        Me.lblPesoBoton.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lblPesoBoton.Name = "lblPesoBoton"
        Me.lblPesoBoton.Size = New System.Drawing.Size(147, 24)
        Me.lblPesoBoton.TabIndex = 7
        Me.lblPesoBoton.Text = "Peso capturado:"
        '
        'celdaPesoManual
        '
        Me.celdaPesoManual.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.celdaPesoManual.Location = New System.Drawing.Point(167, 213)
        Me.celdaPesoManual.Margin = New System.Windows.Forms.Padding(2)
        Me.celdaPesoManual.Name = "celdaPesoManual"
        Me.celdaPesoManual.Size = New System.Drawing.Size(148, 29)
        Me.celdaPesoManual.TabIndex = 4
        '
        'lblPesoManual
        '
        Me.lblPesoManual.AutoSize = True
        Me.lblPesoManual.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblPesoManual.Location = New System.Drawing.Point(16, 216)
        Me.lblPesoManual.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lblPesoManual.Name = "lblPesoManual"
        Me.lblPesoManual.Size = New System.Drawing.Size(125, 24)
        Me.lblPesoManual.TabIndex = 3
        Me.lblPesoManual.Text = "Peso Manual:"
        '
        'celdaIdLote
        '
        Me.celdaIdLote.Location = New System.Drawing.Point(75, 33)
        Me.celdaIdLote.Margin = New System.Windows.Forms.Padding(2)
        Me.celdaIdLote.Name = "celdaIdLote"
        Me.celdaIdLote.ReadOnly = True
        Me.celdaIdLote.Size = New System.Drawing.Size(34, 20)
        Me.celdaIdLote.TabIndex = 7
        '
        'botonNumeroLote
        '
        Me.botonNumeroLote.Location = New System.Drawing.Point(290, 34)
        Me.botonNumeroLote.Margin = New System.Windows.Forms.Padding(2)
        Me.botonNumeroLote.Name = "botonNumeroLote"
        Me.botonNumeroLote.Size = New System.Drawing.Size(25, 19)
        Me.botonNumeroLote.TabIndex = 9
        Me.botonNumeroLote.Text = "..."
        Me.botonNumeroLote.UseVisualStyleBackColor = True
        '
        'celdaNumeroLote
        '
        Me.celdaNumeroLote.Location = New System.Drawing.Point(113, 33)
        Me.celdaNumeroLote.Margin = New System.Windows.Forms.Padding(2)
        Me.celdaNumeroLote.Name = "celdaNumeroLote"
        Me.celdaNumeroLote.ReadOnly = True
        Me.celdaNumeroLote.Size = New System.Drawing.Size(173, 20)
        Me.celdaNumeroLote.TabIndex = 8
        '
        'celdaidAnoPO
        '
        Me.celdaidAnoPO.Location = New System.Drawing.Point(379, 102)
        Me.celdaidAnoPO.Margin = New System.Windows.Forms.Padding(2)
        Me.celdaidAnoPO.Name = "celdaidAnoPO"
        Me.celdaidAnoPO.ReadOnly = True
        Me.celdaidAnoPO.Size = New System.Drawing.Size(34, 20)
        Me.celdaidAnoPO.TabIndex = 41
        '
        'celdaIdProducto
        '
        Me.celdaIdProducto.Location = New System.Drawing.Point(57, 155)
        Me.celdaIdProducto.Margin = New System.Windows.Forms.Padding(2)
        Me.celdaIdProducto.Name = "celdaIdProducto"
        Me.celdaIdProducto.ReadOnly = True
        Me.celdaIdProducto.Size = New System.Drawing.Size(34, 20)
        Me.celdaIdProducto.TabIndex = 17
        Me.celdaIdProducto.Visible = False
        '
        'celdaIdTipoLote
        '
        Me.celdaIdTipoLote.Location = New System.Drawing.Point(75, 55)
        Me.celdaIdTipoLote.Margin = New System.Windows.Forms.Padding(2)
        Me.celdaIdTipoLote.Name = "celdaIdTipoLote"
        Me.celdaIdTipoLote.ReadOnly = True
        Me.celdaIdTipoLote.Size = New System.Drawing.Size(34, 20)
        Me.celdaIdTipoLote.TabIndex = 11
        Me.celdaIdTipoLote.Visible = False
        '
        'celdaIdEmpacador
        '
        Me.celdaIdEmpacador.Location = New System.Drawing.Point(414, 34)
        Me.celdaIdEmpacador.Margin = New System.Windows.Forms.Padding(2)
        Me.celdaIdEmpacador.Name = "celdaIdEmpacador"
        Me.celdaIdEmpacador.ReadOnly = True
        Me.celdaIdEmpacador.Size = New System.Drawing.Size(34, 20)
        Me.celdaIdEmpacador.TabIndex = 32
        Me.celdaIdEmpacador.Visible = False
        '
        'celdaIdFrame
        '
        Me.celdaIdFrame.Location = New System.Drawing.Point(417, 78)
        Me.celdaIdFrame.Margin = New System.Windows.Forms.Padding(2)
        Me.celdaIdFrame.Name = "celdaIdFrame"
        Me.celdaIdFrame.ReadOnly = True
        Me.celdaIdFrame.Size = New System.Drawing.Size(34, 20)
        Me.celdaIdFrame.TabIndex = 38
        Me.celdaIdFrame.Visible = False
        '
        'celdaIdColorEtiqueta
        '
        Me.celdaIdColorEtiqueta.Location = New System.Drawing.Point(417, 55)
        Me.celdaIdColorEtiqueta.Margin = New System.Windows.Forms.Padding(2)
        Me.celdaIdColorEtiqueta.Name = "celdaIdColorEtiqueta"
        Me.celdaIdColorEtiqueta.ReadOnly = True
        Me.celdaIdColorEtiqueta.Size = New System.Drawing.Size(34, 20)
        Me.celdaIdColorEtiqueta.TabIndex = 35
        Me.celdaIdColorEtiqueta.Visible = False
        '
        'celdaIdColorCono
        '
        Me.celdaIdColorCono.Location = New System.Drawing.Point(76, 83)
        Me.celdaIdColorCono.Margin = New System.Windows.Forms.Padding(2)
        Me.celdaIdColorCono.Name = "celdaIdColorCono"
        Me.celdaIdColorCono.ReadOnly = True
        Me.celdaIdColorCono.Size = New System.Drawing.Size(34, 20)
        Me.celdaIdColorCono.TabIndex = 14
        Me.celdaIdColorCono.Visible = False
        '
        'celdaIdPO
        '
        Me.celdaIdPO.Location = New System.Drawing.Point(414, 102)
        Me.celdaIdPO.Margin = New System.Windows.Forms.Padding(2)
        Me.celdaIdPO.Name = "celdaIdPO"
        Me.celdaIdPO.ReadOnly = True
        Me.celdaIdPO.Size = New System.Drawing.Size(34, 20)
        Me.celdaIdPO.TabIndex = 42
        '
        'checkActivar
        '
        Me.checkActivar.AutoSize = True
        Me.checkActivar.Checked = True
        Me.checkActivar.CheckState = System.Windows.Forms.CheckState.Checked
        Me.checkActivar.Location = New System.Drawing.Point(259, 11)
        Me.checkActivar.Name = "checkActivar"
        Me.checkActivar.Size = New System.Drawing.Size(56, 17)
        Me.checkActivar.TabIndex = 4
        Me.checkActivar.Text = "Active"
        Me.checkActivar.UseVisualStyleBackColor = True
        '
        'celdaProducto
        '
        Me.celdaProducto.Location = New System.Drawing.Point(95, 155)
        Me.celdaProducto.Margin = New System.Windows.Forms.Padding(2)
        Me.celdaProducto.Name = "celdaProducto"
        Me.celdaProducto.ReadOnly = True
        Me.celdaProducto.Size = New System.Drawing.Size(559, 20)
        Me.celdaProducto.TabIndex = 18
        '
        'celdaEmpacador
        '
        Me.celdaEmpacador.Location = New System.Drawing.Point(452, 33)
        Me.celdaEmpacador.Margin = New System.Windows.Forms.Padding(2)
        Me.celdaEmpacador.Name = "celdaEmpacador"
        Me.celdaEmpacador.ReadOnly = True
        Me.celdaEmpacador.Size = New System.Drawing.Size(174, 20)
        Me.celdaEmpacador.TabIndex = 33
        '
        'etiquetaEmpacador
        '
        Me.etiquetaEmpacador.AutoSize = True
        Me.etiquetaEmpacador.Location = New System.Drawing.Point(355, 37)
        Me.etiquetaEmpacador.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.etiquetaEmpacador.Name = "etiquetaEmpacador"
        Me.etiquetaEmpacador.Size = New System.Drawing.Size(64, 13)
        Me.etiquetaEmpacador.TabIndex = 31
        Me.etiquetaEmpacador.Text = "Empacador:"
        '
        'celdaTipoLote
        '
        Me.celdaTipoLote.Location = New System.Drawing.Point(113, 55)
        Me.celdaTipoLote.Margin = New System.Windows.Forms.Padding(2)
        Me.celdaTipoLote.Name = "celdaTipoLote"
        Me.celdaTipoLote.ReadOnly = True
        Me.celdaTipoLote.Size = New System.Drawing.Size(202, 20)
        Me.celdaTipoLote.TabIndex = 12
        '
        'etiquetaTipoLote
        '
        Me.etiquetaTipoLote.AutoSize = True
        Me.etiquetaTipoLote.Location = New System.Drawing.Point(16, 59)
        Me.etiquetaTipoLote.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.etiquetaTipoLote.Name = "etiquetaTipoLote"
        Me.etiquetaTipoLote.Size = New System.Drawing.Size(55, 13)
        Me.etiquetaTipoLote.TabIndex = 10
        Me.etiquetaTipoLote.Text = "Tipo Lote:"
        '
        'lblNumeroLote
        '
        Me.lblNumeroLote.AutoSize = True
        Me.lblNumeroLote.Location = New System.Drawing.Point(16, 36)
        Me.lblNumeroLote.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lblNumeroLote.Name = "lblNumeroLote"
        Me.lblNumeroLote.Size = New System.Drawing.Size(51, 13)
        Me.lblNumeroLote.TabIndex = 5
        Me.lblNumeroLote.Text = "No. Lote:"
        '
        'etiquetaProducto
        '
        Me.etiquetaProducto.AutoSize = True
        Me.etiquetaProducto.Location = New System.Drawing.Point(16, 158)
        Me.etiquetaProducto.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.etiquetaProducto.Name = "etiquetaProducto"
        Me.etiquetaProducto.Size = New System.Drawing.Size(53, 13)
        Me.etiquetaProducto.TabIndex = 16
        Me.etiquetaProducto.Text = "Producto:"
        '
        'celdaColorCono
        '
        Me.celdaColorCono.Location = New System.Drawing.Point(113, 81)
        Me.celdaColorCono.Margin = New System.Windows.Forms.Padding(2)
        Me.celdaColorCono.Name = "celdaColorCono"
        Me.celdaColorCono.ReadOnly = True
        Me.celdaColorCono.Size = New System.Drawing.Size(173, 20)
        Me.celdaColorCono.TabIndex = 15
        '
        'etiquetaColorCono
        '
        Me.etiquetaColorCono.AutoSize = True
        Me.etiquetaColorCono.Location = New System.Drawing.Point(16, 86)
        Me.etiquetaColorCono.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.etiquetaColorCono.Name = "etiquetaColorCono"
        Me.etiquetaColorCono.Size = New System.Drawing.Size(77, 13)
        Me.etiquetaColorCono.TabIndex = 13
        Me.etiquetaColorCono.Text = "Color de Cono:"
        '
        'celdaPO
        '
        Me.celdaPO.Enabled = False
        Me.celdaPO.Location = New System.Drawing.Point(452, 102)
        Me.celdaPO.Margin = New System.Windows.Forms.Padding(2)
        Me.celdaPO.Name = "celdaPO"
        Me.celdaPO.Size = New System.Drawing.Size(202, 20)
        Me.celdaPO.TabIndex = 43
        '
        'etiquetaPO
        '
        Me.etiquetaPO.AutoSize = True
        Me.etiquetaPO.Location = New System.Drawing.Point(355, 106)
        Me.etiquetaPO.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.etiquetaPO.Name = "etiquetaPO"
        Me.etiquetaPO.Size = New System.Drawing.Size(25, 13)
        Me.etiquetaPO.TabIndex = 40
        Me.etiquetaPO.Text = "PO:"
        '
        'celdaTara
        '
        Me.celdaTara.Location = New System.Drawing.Point(167, 189)
        Me.celdaTara.Margin = New System.Windows.Forms.Padding(2)
        Me.celdaTara.Name = "celdaTara"
        Me.celdaTara.Size = New System.Drawing.Size(148, 20)
        Me.celdaTara.TabIndex = 2
        '
        'etiquetaTara
        '
        Me.etiquetaTara.AutoSize = True
        Me.etiquetaTara.Location = New System.Drawing.Point(109, 196)
        Me.etiquetaTara.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.etiquetaTara.Name = "etiquetaTara"
        Me.etiquetaTara.Size = New System.Drawing.Size(32, 13)
        Me.etiquetaTara.TabIndex = 1
        Me.etiquetaTara.Text = "Tara:"
        '
        'celdaRollosCaja
        '
        Me.celdaRollosCaja.Location = New System.Drawing.Point(452, 128)
        Me.celdaRollosCaja.Margin = New System.Windows.Forms.Padding(2)
        Me.celdaRollosCaja.Name = "celdaRollosCaja"
        Me.celdaRollosCaja.Size = New System.Drawing.Size(202, 20)
        Me.celdaRollosCaja.TabIndex = 0
        '
        'etiquetaRollosCaja
        '
        Me.etiquetaRollosCaja.AutoSize = True
        Me.etiquetaRollosCaja.Location = New System.Drawing.Point(355, 131)
        Me.etiquetaRollosCaja.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.etiquetaRollosCaja.Name = "etiquetaRollosCaja"
        Me.etiquetaRollosCaja.Size = New System.Drawing.Size(84, 13)
        Me.etiquetaRollosCaja.TabIndex = 44
        Me.etiquetaRollosCaja.Text = "Rollos por Bulto:"
        '
        'celdaFrame
        '
        Me.celdaFrame.Location = New System.Drawing.Point(452, 78)
        Me.celdaFrame.Margin = New System.Windows.Forms.Padding(2)
        Me.celdaFrame.Name = "celdaFrame"
        Me.celdaFrame.ReadOnly = True
        Me.celdaFrame.Size = New System.Drawing.Size(174, 20)
        Me.celdaFrame.TabIndex = 39
        '
        'etiquetaFrame
        '
        Me.etiquetaFrame.AutoSize = True
        Me.etiquetaFrame.Location = New System.Drawing.Point(355, 82)
        Me.etiquetaFrame.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.etiquetaFrame.Name = "etiquetaFrame"
        Me.etiquetaFrame.Size = New System.Drawing.Size(39, 13)
        Me.etiquetaFrame.TabIndex = 37
        Me.etiquetaFrame.Text = "Frame:"
        '
        'celdaEtiquetaColor
        '
        Me.celdaEtiquetaColor.Location = New System.Drawing.Point(452, 54)
        Me.celdaEtiquetaColor.Margin = New System.Windows.Forms.Padding(2)
        Me.celdaEtiquetaColor.Name = "celdaEtiquetaColor"
        Me.celdaEtiquetaColor.ReadOnly = True
        Me.celdaEtiquetaColor.Size = New System.Drawing.Size(202, 20)
        Me.celdaEtiquetaColor.TabIndex = 36
        '
        'etiquetaEtiquetaColor
        '
        Me.etiquetaEtiquetaColor.AutoSize = True
        Me.etiquetaEtiquetaColor.Location = New System.Drawing.Point(355, 58)
        Me.etiquetaEtiquetaColor.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.etiquetaEtiquetaColor.Name = "etiquetaEtiquetaColor"
        Me.etiquetaEtiquetaColor.Size = New System.Drawing.Size(91, 13)
        Me.etiquetaEtiquetaColor.TabIndex = 34
        Me.etiquetaEtiquetaColor.Text = "Color de Etiqueta:"
        '
        'celdaNumero
        '
        Me.celdaNumero.Location = New System.Drawing.Point(211, 9)
        Me.celdaNumero.Margin = New System.Windows.Forms.Padding(2)
        Me.celdaNumero.Name = "celdaNumero"
        Me.celdaNumero.ReadOnly = True
        Me.celdaNumero.Size = New System.Drawing.Size(34, 20)
        Me.celdaNumero.TabIndex = 3
        '
        'celdaAnio
        '
        Me.celdaAnio.Location = New System.Drawing.Point(173, 9)
        Me.celdaAnio.Margin = New System.Windows.Forms.Padding(2)
        Me.celdaAnio.Name = "celdaAnio"
        Me.celdaAnio.ReadOnly = True
        Me.celdaAnio.Size = New System.Drawing.Size(34, 20)
        Me.celdaAnio.TabIndex = 2
        '
        'dtpFecha
        '
        Me.dtpFecha.Enabled = False
        Me.dtpFecha.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.dtpFecha.Location = New System.Drawing.Point(76, 10)
        Me.dtpFecha.Margin = New System.Windows.Forms.Padding(2)
        Me.dtpFecha.Name = "dtpFecha"
        Me.dtpFecha.Size = New System.Drawing.Size(94, 20)
        Me.dtpFecha.TabIndex = 1
        '
        'etiquetaFecha
        '
        Me.etiquetaFecha.AutoSize = True
        Me.etiquetaFecha.Location = New System.Drawing.Point(16, 12)
        Me.etiquetaFecha.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.etiquetaFecha.Name = "etiquetaFecha"
        Me.etiquetaFecha.Size = New System.Drawing.Size(40, 13)
        Me.etiquetaFecha.TabIndex = 0
        Me.etiquetaFecha.Text = "Fecha:"
        '
        'botonEmbalaje
        '
        Me.botonEmbalaje.Location = New System.Drawing.Point(291, 110)
        Me.botonEmbalaje.Margin = New System.Windows.Forms.Padding(2)
        Me.botonEmbalaje.Name = "botonEmbalaje"
        Me.botonEmbalaje.Size = New System.Drawing.Size(25, 19)
        Me.botonEmbalaje.TabIndex = 123
        Me.botonEmbalaje.Text = "..."
        Me.botonEmbalaje.UseVisualStyleBackColor = True
        '
        'celdaIdEmbalaje
        '
        Me.celdaIdEmbalaje.Location = New System.Drawing.Point(77, 107)
        Me.celdaIdEmbalaje.Margin = New System.Windows.Forms.Padding(2)
        Me.celdaIdEmbalaje.Name = "celdaIdEmbalaje"
        Me.celdaIdEmbalaje.ReadOnly = True
        Me.celdaIdEmbalaje.Size = New System.Drawing.Size(34, 20)
        Me.celdaIdEmbalaje.TabIndex = 121
        Me.celdaIdEmbalaje.Visible = False
        '
        'celdaEmbalaje
        '
        Me.celdaEmbalaje.Location = New System.Drawing.Point(114, 108)
        Me.celdaEmbalaje.Margin = New System.Windows.Forms.Padding(2)
        Me.celdaEmbalaje.Name = "celdaEmbalaje"
        Me.celdaEmbalaje.ReadOnly = True
        Me.celdaEmbalaje.Size = New System.Drawing.Size(173, 20)
        Me.celdaEmbalaje.TabIndex = 122
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(19, 111)
        Me.Label2.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(53, 13)
        Me.Label2.TabIndex = 120
        Me.Label2.Text = "Embalaje:"
        '
        'BarraTitulo1
        '
        Me.BarraTitulo1.BackColor = System.Drawing.Color.WhiteSmoke
        Me.BarraTitulo1.Dock = System.Windows.Forms.DockStyle.Top
        Me.BarraTitulo1.Location = New System.Drawing.Point(0, 72)
        Me.BarraTitulo1.Margin = New System.Windows.Forms.Padding(4)
        Me.BarraTitulo1.Name = "BarraTitulo1"
        Me.BarraTitulo1.Size = New System.Drawing.Size(1208, 30)
        Me.BarraTitulo1.TabIndex = 1
        '
        'Encabezado1
        '
        Me.Encabezado1.Dock = System.Windows.Forms.DockStyle.Top
        Me.Encabezado1.Location = New System.Drawing.Point(0, 0)
        Me.Encabezado1.Margin = New System.Windows.Forms.Padding(4)
        Me.Encabezado1.Name = "Encabezado1"
        Me.Encabezado1.Size = New System.Drawing.Size(1208, 72)
        Me.Encabezado1.TabIndex = 0
        '
        'frmCajasPT
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1208, 694)
        Me.Controls.Add(Me.panelDocumento)
        Me.Controls.Add(Me.panelListaPrincipal)
        Me.Controls.Add(Me.BarraTitulo1)
        Me.Controls.Add(Me.Encabezado1)
        Me.Name = "frmCajasPT"
        Me.Text = "frmCajasPT"
        Me.panelListaPrincipal.ResumeLayout(False)
        CType(Me.dgLista, System.ComponentModel.ISupportInitialize).EndInit()
        Me.panelFecha.ResumeLayout(False)
        Me.panelFecha.PerformLayout()
        Me.panelDocumento.ResumeLayout(False)
        Me.Panel2.ResumeLayout(False)
        CType(Me.dgOrdenado, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.dgDetalle, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Panel1.ResumeLayout(False)
        Me.panelEncabezado.ResumeLayout(False)
        Me.panelEncabezado.PerformLayout()
        CType(Me.botonNoCapturaPeso, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.botonCapturaPeso, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents Encabezado1 As encabezado
    Friend WithEvents BarraTitulo1 As BarraTitulo
    Friend WithEvents panelListaPrincipal As Panel
    Friend WithEvents dgLista As DataGridView
    Friend WithEvents panelFecha As Panel
    Friend WithEvents botonActualizar As Button
    Friend WithEvents dtpFin As DateTimePicker
    Friend WithEvents etiquetaFin As Label
    Friend WithEvents dtpInicio As DateTimePicker
    Friend WithEvents checkFecha As System.Windows.Forms.CheckBox
    Friend WithEvents panelDocumento As Panel
    Friend WithEvents dgDetalle As DataGridView
    Friend WithEvents panelEncabezado As Panel
    Friend WithEvents botonCapturaPeso As PictureBox
    Friend WithEvents celdaPesoBoton As TextBox
    Friend WithEvents lblPesoBoton As Label
    Friend WithEvents celdaPesoManual As TextBox
    Friend WithEvents lblPesoManual As Label
    Friend WithEvents celdaIdLote As TextBox
    Friend WithEvents botonNumeroLote As Button
    Friend WithEvents celdaNumeroLote As TextBox
    Friend WithEvents celdaidAnoPO As TextBox
    Friend WithEvents celdaIdProducto As TextBox
    Friend WithEvents celdaIdTipoLote As TextBox
    Friend WithEvents celdaIdEmpacador As TextBox
    Friend WithEvents celdaIdFrame As TextBox
    Friend WithEvents celdaIdColorEtiqueta As TextBox
    Friend WithEvents celdaIdColorCono As TextBox
    Friend WithEvents celdaIdPO As TextBox
    Friend WithEvents checkActivar As System.Windows.Forms.CheckBox
    Friend WithEvents celdaProducto As TextBox
    Friend WithEvents celdaEmpacador As TextBox
    Friend WithEvents etiquetaEmpacador As Label
    Friend WithEvents celdaTipoLote As TextBox
    Friend WithEvents etiquetaTipoLote As Label
    Friend WithEvents lblNumeroLote As Label
    Friend WithEvents etiquetaProducto As Label
    Friend WithEvents celdaColorCono As TextBox
    Friend WithEvents etiquetaColorCono As Label
    Friend WithEvents celdaPO As TextBox
    Friend WithEvents etiquetaPO As Label
    Friend WithEvents celdaTara As TextBox
    Friend WithEvents etiquetaTara As Label
    Friend WithEvents celdaRollosCaja As TextBox
    Friend WithEvents etiquetaRollosCaja As Label
    Friend WithEvents celdaFrame As TextBox
    Friend WithEvents etiquetaFrame As Label
    Friend WithEvents celdaEtiquetaColor As TextBox
    Friend WithEvents etiquetaEtiquetaColor As Label
    Friend WithEvents celdaNumero As TextBox
    Friend WithEvents celdaAnio As TextBox
    Friend WithEvents dtpFecha As DateTimePicker
    Friend WithEvents etiquetaFecha As Label
    Friend WithEvents celdaPuerto As TextBox
    Friend WithEvents botonAgreDetalle As Button
    Friend WithEvents celdaAnoLote As TextBox
    Friend WithEvents Panel1 As Panel
    Friend WithEvents botonQuitDetalle As Button
    Friend WithEvents celdaCorrelativo As TextBox
    Friend WithEvents etiquetaCorrelativo As Label
    Friend WithEvents celdaVelocidad As TextBox
    Friend WithEvents botonNoCapturaPeso As PictureBox
    Friend WithEvents col_catalogo As DataGridViewTextBoxColumn
    Friend WithEvents col_ano As DataGridViewTextBoxColumn
    Friend WithEvents col_numero As DataGridViewTextBoxColumn
    Friend WithEvents col_linea As DataGridViewTextBoxColumn
    Friend WithEvents col_numLote As DataGridViewTextBoxColumn
    Friend WithEvents col_fecha As DataGridViewTextBoxColumn
    Friend WithEvents col_correlativo As DataGridViewTextBoxColumn
    Friend WithEvents col_tara As DataGridViewTextBoxColumn
    Friend WithEvents col_PesoNeto As DataGridViewTextBoxColumn
    Friend WithEvents col_PesoBruto As DataGridViewTextBoxColumn
    Friend WithEvents col_estado As DataGridViewTextBoxColumn
    Friend WithEvents col_numIngreso As DataGridViewTextBoxColumn
    Friend WithEvents col_anoIngreso As DataGridViewTextBoxColumn
    Friend WithEvents col_lineaIngreso As DataGridViewTextBoxColumn
    Friend WithEvents col_lineaLote As DataGridViewTextBoxColumn
    Friend WithEvents col_lineabox As DataGridViewTextBoxColumn
    Friend WithEvents colCatalogo As DataGridViewTextBoxColumn
    Friend WithEvents colAnio As DataGridViewTextBoxColumn
    Friend WithEvents colNumber As DataGridViewTextBoxColumn
    Friend WithEvents colDate As DataGridViewTextBoxColumn
    Friend WithEvents colReferencia As DataGridViewTextBoxColumn
    Friend WithEvents colPO As DataGridViewTextBoxColumn
    Friend WithEvents colLoteId As DataGridViewTextBoxColumn
    Friend WithEvents celdaIdTurno As TextBox
    Friend WithEvents botonTurno As Button
    Friend WithEvents celdaTurno As TextBox
    Friend WithEvents lblTurno As Label
    Friend WithEvents btnImprimirEtiquetas As Button
    Friend WithEvents TextBox1 As TextBox
    Friend WithEvents botonEmpacador As Button
    Friend WithEvents Panel2 As Panel
    Friend WithEvents botonColorCono As Button
    Friend WithEvents dgOrdenado As DataGridView
    Friend WithEvents botonFrame As Button
    Friend WithEvents botonImprimirConoEmpacador As Button
    Friend WithEvents col_catalogo_o As DataGridViewTextBoxColumn
    Friend WithEvents col_Ano_o As DataGridViewTextBoxColumn
    Friend WithEvents col_numero_o As DataGridViewTextBoxColumn
    Friend WithEvents col_linea_o As DataGridViewTextBoxColumn
    Friend WithEvents col_numLote_o As DataGridViewTextBoxColumn
    Friend WithEvents col_fecha_o As DataGridViewTextBoxColumn
    Friend WithEvents col_correlativo_o As DataGridViewTextBoxColumn
    Friend WithEvents col_tara_o As DataGridViewTextBoxColumn
    Friend WithEvents col_pesoNeto_o As DataGridViewTextBoxColumn
    Friend WithEvents col_pesoBruto_o As DataGridViewTextBoxColumn
    Friend WithEvents col_estado_o As DataGridViewTextBoxColumn
    Friend WithEvents col_numIngreso_o As DataGridViewTextBoxColumn
    Friend WithEvents col_anoIngreso_o As DataGridViewTextBoxColumn
    Friend WithEvents col_lineaIngreso_o As DataGridViewTextBoxColumn
    Friend WithEvents col_lineaLote_o As DataGridViewTextBoxColumn
    Friend WithEvents col_lineaBox_o As DataGridViewTextBoxColumn
    Friend WithEvents btnSeleccionFecha As Button
    Friend WithEvents dtpPalletFin As DateTimePicker
    Friend WithEvents Label1 As Label
    Friend WithEvents dtpPalletInicio As DateTimePicker
    Friend WithEvents CheckBox1 As System.Windows.Forms.CheckBox
    Friend WithEvents botonEmbalaje As Button
    Friend WithEvents celdaIdEmbalaje As TextBox
    Friend WithEvents celdaEmbalaje As TextBox
    Friend WithEvents Label2 As Label
End Class
