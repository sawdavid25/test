﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmCajaChica
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim DataGridViewCellStyle1 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle2 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle3 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle4 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle5 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle6 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle7 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle8 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle9 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle10 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle11 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmCajaChica))
        Me.panelLista = New System.Windows.Forms.Panel()
        Me.dgLista = New System.Windows.Forms.DataGridView()
        Me.colCodigo = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colNumero = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colNombre = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colMoneda = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colDescripcion = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colDocumentos = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colEstado = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.panelPieLista = New System.Windows.Forms.Panel()
        Me.etiquetaConDoc = New System.Windows.Forms.Label()
        Me.etiquetaCerrada = New System.Windows.Forms.Label()
        Me.celdaConDoc = New System.Windows.Forms.TextBox()
        Me.celdaCerrada = New System.Windows.Forms.TextBox()
        Me.panelDetalleCaja = New System.Windows.Forms.Panel()
        Me.dgDocumentos = New System.Windows.Forms.DataGridView()
        Me.colDocTipo = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colDocAnio = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colDocNumero = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colDocFecha = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colDocDocumento = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colDocReferencia = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colDocTransaccion = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colDocMoneda = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colDocDebito = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colDocNombre = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colDocSerie = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colDocParcial = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colDocTasa = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colDocConcepto = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colDocGasto = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colidrubro = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colrubro = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colidcuenta = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colcuenta = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colDocLiquidar = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.panelPieDetalle = New System.Windows.Forms.Panel()
        Me.dgOtrosDocumentos = New System.Windows.Forms.DataGridView()
        Me.colOtroTipo = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colOtroAnio = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colOtroNumero = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colOtroDescripcion = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colOtroFecha = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colOtroReferencia = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colOtroSaldo = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colOtroConcepto = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.panelOpciones = New System.Windows.Forms.Panel()
        Me.celdaRetencion = New System.Windows.Forms.TextBox()
        Me.etiquetaRetencion = New System.Windows.Forms.Label()
        Me.celdaSubtotal = New System.Windows.Forms.TextBox()
        Me.etiquetaSubTotal = New System.Windows.Forms.Label()
        Me.celdaTotalLiquidar = New System.Windows.Forms.TextBox()
        Me.etiquetaTotalLiquidar = New System.Windows.Forms.Label()
        Me.gbBotones = New System.Windows.Forms.GroupBox()
        Me.botonBorrarLiquidacion = New System.Windows.Forms.Button()
        Me.botonLiquidar = New System.Windows.Forms.Button()
        Me.botonReportes = New System.Windows.Forms.Button()
        Me.botonArqueo = New System.Windows.Forms.Button()
        Me.panelFechas = New System.Windows.Forms.Panel()
        Me.checkTodo = New System.Windows.Forms.CheckBox()
        Me.celdaidDocumento = New System.Windows.Forms.TextBox()
        Me.checkSeleccionar = New System.Windows.Forms.CheckBox()
        Me.celdaDisponible = New System.Windows.Forms.TextBox()
        Me.etiquetaDisponible = New System.Windows.Forms.Label()
        Me.botonRecargar = New System.Windows.Forms.Button()
        Me.dtpFinal = New System.Windows.Forms.DateTimePicker()
        Me.dtpIncial = New System.Windows.Forms.DateTimePicker()
        Me.etiquetaFechas = New System.Windows.Forms.Label()
        Me.botonDocumento = New System.Windows.Forms.Button()
        Me.botonNuevoDoc = New System.Windows.Forms.Button()
        Me.celdaDocumento = New System.Windows.Forms.TextBox()
        Me.panelEncabezadoDetalle = New System.Windows.Forms.Panel()
        Me.gbEncabezadoDetalle1 = New System.Windows.Forms.GroupBox()
        Me.Label14 = New System.Windows.Forms.Label()
        Me.checkInactivarCaja = New System.Windows.Forms.CheckBox()
        Me.celdaCuenta = New System.Windows.Forms.TextBox()
        Me.celdaDescCuenta = New System.Windows.Forms.TextBox()
        Me.botonCuenta = New System.Windows.Forms.Button()
        Me.gbEncabezadoDetalle = New System.Windows.Forms.GroupBox()
        Me.celdaTipoCaja = New System.Windows.Forms.TextBox()
        Me.celdaidMoneda = New System.Windows.Forms.TextBox()
        Me.botonMoneda = New System.Windows.Forms.Button()
        Me.celdaDescMoneda = New System.Windows.Forms.TextBox()
        Me.celdaMoneda = New System.Windows.Forms.TextBox()
        Me.etiquetaMoneda = New System.Windows.Forms.Label()
        Me.celdaDescripcion = New System.Windows.Forms.TextBox()
        Me.etiquetaDescripcion = New System.Windows.Forms.Label()
        Me.celdaResponsable = New System.Windows.Forms.TextBox()
        Me.etiquetaResponsable = New System.Windows.Forms.Label()
        Me.celdaCodigo = New System.Windows.Forms.TextBox()
        Me.etiquetaCodigo = New System.Windows.Forms.Label()
        Me.celdaCAI = New System.Windows.Forms.TextBox()
        Me.etiquetaCAI = New System.Windows.Forms.Label()
        Me.panelDocumento = New System.Windows.Forms.Panel()
        Me.dgDetalleDocumento = New System.Windows.Forms.DataGridView()
        Me.colCantidadD = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colCodigoD = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colAnioD = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colNumD = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colLineaD = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colDescripcionD = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colPrecioSinIVA = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colPrecioD = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colTotalD = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colGastoD = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colidGastoD = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colidCuentaIVA = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colCcosto = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colidCcosto = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.idrubro = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.rubro = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.idcuenta = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.cuenta = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colClasificacionD = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colidClasificacionD = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colCtaIVA = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colExtra = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.panelBtnDetalle = New System.Windows.Forms.Panel()
        Me.botonMenos = New System.Windows.Forms.Button()
        Me.botonMas = New System.Windows.Forms.Button()
        Me.celdaDetalleDoc = New System.Windows.Forms.TextBox()
        Me.panelPieDocumento = New System.Windows.Forms.Panel()
        Me.gbImpuestos = New System.Windows.Forms.GroupBox()
        Me.dgImpuestos = New System.Windows.Forms.DataGridView()
        Me.colLine = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colID = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colCodigo1 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colTipo = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colDescripcion1 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colCantidad1 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colFactor = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colBase = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colMonto = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colTag = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colOrigen = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.panelBotones = New System.Windows.Forms.Panel()
        Me.botonEliminar = New System.Windows.Forms.Button()
        Me.botonOtrosImp = New System.Windows.Forms.Button()
        Me.botnEditar = New System.Windows.Forms.Button()
        Me.panelLetra = New System.Windows.Forms.Panel()
        Me.panelExtemporaneo = New System.Windows.Forms.Panel()
        Me.celdaExtemporaneo = New System.Windows.Forms.TextBox()
        Me.Label15 = New System.Windows.Forms.Label()
        Me.celdaLetra = New System.Windows.Forms.TextBox()
        Me.panelEncabezadoDocumento = New System.Windows.Forms.Panel()
        Me.gbDatosDocumento1 = New System.Windows.Forms.GroupBox()
        Me.etiquetaMontoTotal = New System.Windows.Forms.Label()
        Me.celdaEmisor = New System.Windows.Forms.TextBox()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.celdaNota = New System.Windows.Forms.TextBox()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.celdaDiferencia = New System.Windows.Forms.TextBox()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.botonReintegro = New System.Windows.Forms.Button()
        Me.celdaReintegro = New System.Windows.Forms.TextBox()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.celdaDetalleMonto = New System.Windows.Forms.TextBox()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.gbDatosDocumento = New System.Windows.Forms.GroupBox()
        Me.dtpFechaPolizaC = New System.Windows.Forms.DateTimePicker()
        Me.etiquetaFecha1 = New System.Windows.Forms.Label()
        Me.celdaMontoProd = New System.Windows.Forms.TextBox()
        Me.celdaNumeroCaja = New System.Windows.Forms.TextBox()
        Me.botonDetalleMoneda = New System.Windows.Forms.Button()
        Me.celdaDetalleAnio = New System.Windows.Forms.TextBox()
        Me.celdaNumeroHDR = New System.Windows.Forms.TextBox()
        Me.celdadetalleIDDocumento = New System.Windows.Forms.TextBox()
        Me.botonDocumentos = New System.Windows.Forms.Button()
        Me.celdaDetalleIDMoneda = New System.Windows.Forms.TextBox()
        Me.celdaidProveedor = New System.Windows.Forms.TextBox()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.checkActivoFijo = New System.Windows.Forms.CheckBox()
        Me.celdaDetalleTC = New System.Windows.Forms.TextBox()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.celdaDetalleMoneda = New System.Windows.Forms.TextBox()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.celdaDetalleNit = New System.Windows.Forms.TextBox()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.checkContribuyent = New System.Windows.Forms.CheckBox()
        Me.checkFacElectrónica = New System.Windows.Forms.CheckBox()
        Me.botonProveedor = New System.Windows.Forms.Button()
        Me.celdaProveedor = New System.Windows.Forms.TextBox()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.checActivo = New System.Windows.Forms.CheckBox()
        Me.celdaDetalleSerie = New System.Windows.Forms.TextBox()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.celdaDetalleNumero = New System.Windows.Forms.TextBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.dtpDetalleFecha = New System.Windows.Forms.DateTimePicker()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.celdaDetalleDocumento = New System.Windows.Forms.TextBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.ToolTip1 = New System.Windows.Forms.ToolTip(Me.components)
        Me.botonPermisos = New System.Windows.Forms.Button()
        Me.BotonImpreso = New System.Windows.Forms.Button()
        Me.botonActualizar = New System.Windows.Forms.Button()
        Me.BarraTitulo1 = New KARIMs_SGI.BarraTitulo()
        Me.Encabezado1 = New KARIMs_SGI.encabezado()
        Me.panelLista.SuspendLayout()
        CType(Me.dgLista, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.panelPieLista.SuspendLayout()
        Me.panelDetalleCaja.SuspendLayout()
        CType(Me.dgDocumentos, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.panelPieDetalle.SuspendLayout()
        CType(Me.dgOtrosDocumentos, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.panelOpciones.SuspendLayout()
        Me.gbBotones.SuspendLayout()
        Me.panelFechas.SuspendLayout()
        Me.panelEncabezadoDetalle.SuspendLayout()
        Me.gbEncabezadoDetalle1.SuspendLayout()
        Me.gbEncabezadoDetalle.SuspendLayout()
        Me.panelDocumento.SuspendLayout()
        CType(Me.dgDetalleDocumento, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.panelBtnDetalle.SuspendLayout()
        Me.panelPieDocumento.SuspendLayout()
        Me.gbImpuestos.SuspendLayout()
        CType(Me.dgImpuestos, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.panelBotones.SuspendLayout()
        Me.panelLetra.SuspendLayout()
        Me.panelExtemporaneo.SuspendLayout()
        Me.panelEncabezadoDocumento.SuspendLayout()
        Me.gbDatosDocumento1.SuspendLayout()
        Me.gbDatosDocumento.SuspendLayout()
        Me.SuspendLayout()
        '
        'panelLista
        '
        Me.panelLista.Controls.Add(Me.dgLista)
        Me.panelLista.Controls.Add(Me.panelPieLista)
        Me.panelLista.Dock = System.Windows.Forms.DockStyle.Top
        Me.panelLista.Location = New System.Drawing.Point(0, 88)
        Me.panelLista.Margin = New System.Windows.Forms.Padding(2)
        Me.panelLista.Name = "panelLista"
        Me.panelLista.Size = New System.Drawing.Size(836, 93)
        Me.panelLista.TabIndex = 2
        '
        'dgLista
        '
        Me.dgLista.AllowUserToAddRows = False
        Me.dgLista.AllowUserToDeleteRows = False
        Me.dgLista.AllowUserToOrderColumns = True
        Me.dgLista.BackgroundColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle1.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.dgLista.ColumnHeadersDefaultCellStyle = DataGridViewCellStyle1
        Me.dgLista.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgLista.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.colCodigo, Me.colNumero, Me.colNombre, Me.colMoneda, Me.colDescripcion, Me.colDocumentos, Me.colEstado})
        DataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle2.BackColor = System.Drawing.SystemColors.Window
        DataGridViewCellStyle2.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.ControlText
        DataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.[False]
        Me.dgLista.DefaultCellStyle = DataGridViewCellStyle2
        Me.dgLista.Dock = System.Windows.Forms.DockStyle.Fill
        Me.dgLista.Location = New System.Drawing.Point(0, 0)
        Me.dgLista.Margin = New System.Windows.Forms.Padding(2)
        Me.dgLista.MultiSelect = False
        Me.dgLista.Name = "dgLista"
        Me.dgLista.ReadOnly = True
        Me.dgLista.RowHeadersWidth = 51
        Me.dgLista.RowTemplate.Height = 24
        Me.dgLista.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.dgLista.Size = New System.Drawing.Size(836, 35)
        Me.dgLista.TabIndex = 1
        '
        'colCodigo
        '
        Me.colCodigo.HeaderText = "Code"
        Me.colCodigo.MinimumWidth = 6
        Me.colCodigo.Name = "colCodigo"
        Me.colCodigo.ReadOnly = True
        Me.colCodigo.Visible = False
        Me.colCodigo.Width = 125
        '
        'colNumero
        '
        Me.colNumero.HeaderText = "Number"
        Me.colNumero.MinimumWidth = 6
        Me.colNumero.Name = "colNumero"
        Me.colNumero.ReadOnly = True
        Me.colNumero.Width = 125
        '
        'colNombre
        '
        Me.colNombre.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.colNombre.HeaderText = "Name"
        Me.colNombre.MinimumWidth = 6
        Me.colNombre.Name = "colNombre"
        Me.colNombre.ReadOnly = True
        Me.colNombre.Width = 60
        '
        'colMoneda
        '
        Me.colMoneda.HeaderText = "Currency"
        Me.colMoneda.MinimumWidth = 6
        Me.colMoneda.Name = "colMoneda"
        Me.colMoneda.ReadOnly = True
        Me.colMoneda.Width = 125
        '
        'colDescripcion
        '
        Me.colDescripcion.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.colDescripcion.HeaderText = "Description"
        Me.colDescripcion.MinimumWidth = 6
        Me.colDescripcion.Name = "colDescripcion"
        Me.colDescripcion.ReadOnly = True
        Me.colDescripcion.Width = 85
        '
        'colDocumentos
        '
        Me.colDocumentos.HeaderText = "Documents"
        Me.colDocumentos.MinimumWidth = 6
        Me.colDocumentos.Name = "colDocumentos"
        Me.colDocumentos.ReadOnly = True
        Me.colDocumentos.Width = 125
        '
        'colEstado
        '
        Me.colEstado.HeaderText = "Status"
        Me.colEstado.MinimumWidth = 6
        Me.colEstado.Name = "colEstado"
        Me.colEstado.ReadOnly = True
        Me.colEstado.Visible = False
        Me.colEstado.Width = 125
        '
        'panelPieLista
        '
        Me.panelPieLista.Controls.Add(Me.etiquetaConDoc)
        Me.panelPieLista.Controls.Add(Me.etiquetaCerrada)
        Me.panelPieLista.Controls.Add(Me.celdaConDoc)
        Me.panelPieLista.Controls.Add(Me.celdaCerrada)
        Me.panelPieLista.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.panelPieLista.Location = New System.Drawing.Point(0, 35)
        Me.panelPieLista.Margin = New System.Windows.Forms.Padding(2)
        Me.panelPieLista.Name = "panelPieLista"
        Me.panelPieLista.Size = New System.Drawing.Size(836, 58)
        Me.panelPieLista.TabIndex = 0
        '
        'etiquetaConDoc
        '
        Me.etiquetaConDoc.AutoSize = True
        Me.etiquetaConDoc.Location = New System.Drawing.Point(35, 37)
        Me.etiquetaConDoc.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.etiquetaConDoc.Name = "etiquetaConDoc"
        Me.etiquetaConDoc.Size = New System.Drawing.Size(237, 13)
        Me.etiquetaConDoc.TabIndex = 3
        Me.etiquetaConDoc.Text = "Petty Cash with Documents Pending of Liquidate"
        '
        'etiquetaCerrada
        '
        Me.etiquetaCerrada.AutoSize = True
        Me.etiquetaCerrada.Location = New System.Drawing.Point(35, 11)
        Me.etiquetaCerrada.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.etiquetaCerrada.Name = "etiquetaCerrada"
        Me.etiquetaCerrada.Size = New System.Drawing.Size(93, 13)
        Me.etiquetaCerrada.TabIndex = 2
        Me.etiquetaCerrada.Text = "Petty Cash Closed"
        '
        'celdaConDoc
        '
        Me.celdaConDoc.BackColor = System.Drawing.Color.YellowGreen
        Me.celdaConDoc.Location = New System.Drawing.Point(9, 34)
        Me.celdaConDoc.Margin = New System.Windows.Forms.Padding(2)
        Me.celdaConDoc.Name = "celdaConDoc"
        Me.celdaConDoc.ReadOnly = True
        Me.celdaConDoc.Size = New System.Drawing.Size(24, 20)
        Me.celdaConDoc.TabIndex = 1
        '
        'celdaCerrada
        '
        Me.celdaCerrada.BackColor = System.Drawing.Color.Coral
        Me.celdaCerrada.Location = New System.Drawing.Point(9, 6)
        Me.celdaCerrada.Margin = New System.Windows.Forms.Padding(2)
        Me.celdaCerrada.Name = "celdaCerrada"
        Me.celdaCerrada.ReadOnly = True
        Me.celdaCerrada.Size = New System.Drawing.Size(24, 20)
        Me.celdaCerrada.TabIndex = 0
        '
        'panelDetalleCaja
        '
        Me.panelDetalleCaja.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.panelDetalleCaja.Controls.Add(Me.dgDocumentos)
        Me.panelDetalleCaja.Controls.Add(Me.panelPieDetalle)
        Me.panelDetalleCaja.Controls.Add(Me.panelFechas)
        Me.panelDetalleCaja.Controls.Add(Me.panelEncabezadoDetalle)
        Me.panelDetalleCaja.Location = New System.Drawing.Point(9, 184)
        Me.panelDetalleCaja.Margin = New System.Windows.Forms.Padding(2)
        Me.panelDetalleCaja.Name = "panelDetalleCaja"
        Me.panelDetalleCaja.Size = New System.Drawing.Size(789, 369)
        Me.panelDetalleCaja.TabIndex = 3
        '
        'dgDocumentos
        '
        Me.dgDocumentos.AllowUserToAddRows = False
        Me.dgDocumentos.AllowUserToDeleteRows = False
        Me.dgDocumentos.BackgroundColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle3.BackColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle3.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle3.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle3.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle3.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.dgDocumentos.ColumnHeadersDefaultCellStyle = DataGridViewCellStyle3
        Me.dgDocumentos.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgDocumentos.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.colDocTipo, Me.colDocAnio, Me.colDocNumero, Me.colDocFecha, Me.colDocDocumento, Me.colDocReferencia, Me.colDocTransaccion, Me.colDocMoneda, Me.colDocDebito, Me.colDocNombre, Me.colDocSerie, Me.colDocParcial, Me.colDocTasa, Me.colDocConcepto, Me.colDocGasto, Me.colidrubro, Me.colrubro, Me.colidcuenta, Me.colcuenta, Me.colDocLiquidar})
        DataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle4.BackColor = System.Drawing.SystemColors.Window
        DataGridViewCellStyle4.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle4.ForeColor = System.Drawing.SystemColors.ControlText
        DataGridViewCellStyle4.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle4.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle4.WrapMode = System.Windows.Forms.DataGridViewTriState.[False]
        Me.dgDocumentos.DefaultCellStyle = DataGridViewCellStyle4
        Me.dgDocumentos.Dock = System.Windows.Forms.DockStyle.Fill
        Me.dgDocumentos.Location = New System.Drawing.Point(0, 210)
        Me.dgDocumentos.Margin = New System.Windows.Forms.Padding(2)
        Me.dgDocumentos.MultiSelect = False
        Me.dgDocumentos.Name = "dgDocumentos"
        Me.dgDocumentos.ReadOnly = True
        Me.dgDocumentos.RowHeadersWidth = 51
        Me.dgDocumentos.RowTemplate.Height = 24
        Me.dgDocumentos.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.dgDocumentos.Size = New System.Drawing.Size(789, 30)
        Me.dgDocumentos.TabIndex = 3
        '
        'colDocTipo
        '
        Me.colDocTipo.HeaderText = "Type"
        Me.colDocTipo.MinimumWidth = 6
        Me.colDocTipo.Name = "colDocTipo"
        Me.colDocTipo.ReadOnly = True
        Me.colDocTipo.Visible = False
        Me.colDocTipo.Width = 6
        '
        'colDocAnio
        '
        Me.colDocAnio.HeaderText = "Year"
        Me.colDocAnio.MinimumWidth = 6
        Me.colDocAnio.Name = "colDocAnio"
        Me.colDocAnio.ReadOnly = True
        Me.colDocAnio.Visible = False
        Me.colDocAnio.Width = 6
        '
        'colDocNumero
        '
        Me.colDocNumero.HeaderText = "Number"
        Me.colDocNumero.MinimumWidth = 6
        Me.colDocNumero.Name = "colDocNumero"
        Me.colDocNumero.ReadOnly = True
        Me.colDocNumero.Visible = False
        Me.colDocNumero.Width = 6
        '
        'colDocFecha
        '
        Me.colDocFecha.HeaderText = "Date"
        Me.colDocFecha.MinimumWidth = 6
        Me.colDocFecha.Name = "colDocFecha"
        Me.colDocFecha.ReadOnly = True
        Me.colDocFecha.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        Me.colDocFecha.Width = 44
        '
        'colDocDocumento
        '
        Me.colDocDocumento.HeaderText = "Transaction"
        Me.colDocDocumento.MinimumWidth = 6
        Me.colDocDocumento.Name = "colDocDocumento"
        Me.colDocDocumento.ReadOnly = True
        Me.colDocDocumento.Width = 112
        '
        'colDocReferencia
        '
        Me.colDocReferencia.HeaderText = "Reference"
        Me.colDocReferencia.MinimumWidth = 6
        Me.colDocReferencia.Name = "colDocReferencia"
        Me.colDocReferencia.ReadOnly = True
        Me.colDocReferencia.Width = 103
        '
        'colDocTransaccion
        '
        Me.colDocTransaccion.HeaderText = "Categoria"
        Me.colDocTransaccion.MinimumWidth = 6
        Me.colDocTransaccion.Name = "colDocTransaccion"
        Me.colDocTransaccion.ReadOnly = True
        Me.colDocTransaccion.Visible = False
        Me.colDocTransaccion.Width = 6
        '
        'colDocMoneda
        '
        Me.colDocMoneda.HeaderText = "Currency"
        Me.colDocMoneda.MinimumWidth = 6
        Me.colDocMoneda.Name = "colDocMoneda"
        Me.colDocMoneda.ReadOnly = True
        Me.colDocMoneda.Width = 94
        '
        'colDocDebito
        '
        Me.colDocDebito.HeaderText = "Debit"
        Me.colDocDebito.MinimumWidth = 6
        Me.colDocDebito.Name = "colDocDebito"
        Me.colDocDebito.ReadOnly = True
        Me.colDocDebito.Width = 70
        '
        'colDocNombre
        '
        Me.colDocNombre.HeaderText = "Nombre"
        Me.colDocNombre.MinimumWidth = 6
        Me.colDocNombre.Name = "colDocNombre"
        Me.colDocNombre.ReadOnly = True
        Me.colDocNombre.Visible = False
        Me.colDocNombre.Width = 6
        '
        'colDocSerie
        '
        Me.colDocSerie.HeaderText = "Serie"
        Me.colDocSerie.MinimumWidth = 6
        Me.colDocSerie.Name = "colDocSerie"
        Me.colDocSerie.ReadOnly = True
        Me.colDocSerie.Visible = False
        Me.colDocSerie.Width = 6
        '
        'colDocParcial
        '
        Me.colDocParcial.HeaderText = "Discounts"
        Me.colDocParcial.MinimumWidth = 6
        Me.colDocParcial.Name = "colDocParcial"
        Me.colDocParcial.ReadOnly = True
        Me.colDocParcial.Width = 99
        '
        'colDocTasa
        '
        Me.colDocTasa.HeaderText = "Tasa"
        Me.colDocTasa.MinimumWidth = 6
        Me.colDocTasa.Name = "colDocTasa"
        Me.colDocTasa.ReadOnly = True
        Me.colDocTasa.Visible = False
        Me.colDocTasa.Width = 6
        '
        'colDocConcepto
        '
        Me.colDocConcepto.HeaderText = "Concept"
        Me.colDocConcepto.MinimumWidth = 6
        Me.colDocConcepto.Name = "colDocConcepto"
        Me.colDocConcepto.ReadOnly = True
        Me.colDocConcepto.Width = 200
        '
        'colDocGasto
        '
        Me.colDocGasto.HeaderText = "Expense"
        Me.colDocGasto.MinimumWidth = 6
        Me.colDocGasto.Name = "colDocGasto"
        Me.colDocGasto.ReadOnly = True
        Me.colDocGasto.Width = 91
        '
        'colidrubro
        '
        Me.colidrubro.HeaderText = "colidrubro"
        Me.colidrubro.MinimumWidth = 6
        Me.colidrubro.Name = "colidrubro"
        Me.colidrubro.ReadOnly = True
        Me.colidrubro.Visible = False
        Me.colidrubro.Width = 125
        '
        'colrubro
        '
        Me.colrubro.HeaderText = "Item"
        Me.colrubro.MinimumWidth = 6
        Me.colrubro.Name = "colrubro"
        Me.colrubro.ReadOnly = True
        Me.colrubro.Width = 125
        '
        'colidcuenta
        '
        Me.colidcuenta.HeaderText = "colidcuenta"
        Me.colidcuenta.MinimumWidth = 6
        Me.colidcuenta.Name = "colidcuenta"
        Me.colidcuenta.ReadOnly = True
        Me.colidcuenta.Visible = False
        Me.colidcuenta.Width = 125
        '
        'colcuenta
        '
        Me.colcuenta.HeaderText = "Account"
        Me.colcuenta.MinimumWidth = 6
        Me.colcuenta.Name = "colcuenta"
        Me.colcuenta.ReadOnly = True
        Me.colcuenta.Width = 125
        '
        'colDocLiquidar
        '
        Me.colDocLiquidar.HeaderText = "Liquidate"
        Me.colDocLiquidar.MinimumWidth = 6
        Me.colDocLiquidar.Name = "colDocLiquidar"
        Me.colDocLiquidar.ReadOnly = True
        Me.colDocLiquidar.Width = 95
        '
        'panelPieDetalle
        '
        Me.panelPieDetalle.Controls.Add(Me.dgOtrosDocumentos)
        Me.panelPieDetalle.Controls.Add(Me.panelOpciones)
        Me.panelPieDetalle.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.panelPieDetalle.Location = New System.Drawing.Point(0, 240)
        Me.panelPieDetalle.Margin = New System.Windows.Forms.Padding(2)
        Me.panelPieDetalle.Name = "panelPieDetalle"
        Me.panelPieDetalle.Size = New System.Drawing.Size(789, 129)
        Me.panelPieDetalle.TabIndex = 2
        '
        'dgOtrosDocumentos
        '
        Me.dgOtrosDocumentos.AllowUserToAddRows = False
        Me.dgOtrosDocumentos.AllowUserToDeleteRows = False
        Me.dgOtrosDocumentos.AllowUserToOrderColumns = True
        Me.dgOtrosDocumentos.BackgroundColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle5.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle5.BackColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle5.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle5.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle5.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle5.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle5.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.dgOtrosDocumentos.ColumnHeadersDefaultCellStyle = DataGridViewCellStyle5
        Me.dgOtrosDocumentos.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgOtrosDocumentos.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.colOtroTipo, Me.colOtroAnio, Me.colOtroNumero, Me.colOtroDescripcion, Me.colOtroFecha, Me.colOtroReferencia, Me.colOtroSaldo, Me.colOtroConcepto})
        DataGridViewCellStyle6.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle6.BackColor = System.Drawing.SystemColors.Window
        DataGridViewCellStyle6.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle6.ForeColor = System.Drawing.SystemColors.ControlText
        DataGridViewCellStyle6.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle6.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle6.WrapMode = System.Windows.Forms.DataGridViewTriState.[False]
        Me.dgOtrosDocumentos.DefaultCellStyle = DataGridViewCellStyle6
        Me.dgOtrosDocumentos.Dock = System.Windows.Forms.DockStyle.Fill
        Me.dgOtrosDocumentos.Location = New System.Drawing.Point(0, 0)
        Me.dgOtrosDocumentos.Margin = New System.Windows.Forms.Padding(2)
        Me.dgOtrosDocumentos.MultiSelect = False
        Me.dgOtrosDocumentos.Name = "dgOtrosDocumentos"
        Me.dgOtrosDocumentos.ReadOnly = True
        Me.dgOtrosDocumentos.RowHeadersWidth = 51
        Me.dgOtrosDocumentos.RowTemplate.Height = 24
        Me.dgOtrosDocumentos.Size = New System.Drawing.Size(297, 129)
        Me.dgOtrosDocumentos.TabIndex = 1
        '
        'colOtroTipo
        '
        Me.colOtroTipo.HeaderText = "Type"
        Me.colOtroTipo.MinimumWidth = 6
        Me.colOtroTipo.Name = "colOtroTipo"
        Me.colOtroTipo.ReadOnly = True
        Me.colOtroTipo.Width = 125
        '
        'colOtroAnio
        '
        Me.colOtroAnio.HeaderText = "Year"
        Me.colOtroAnio.MinimumWidth = 6
        Me.colOtroAnio.Name = "colOtroAnio"
        Me.colOtroAnio.ReadOnly = True
        Me.colOtroAnio.Width = 125
        '
        'colOtroNumero
        '
        Me.colOtroNumero.HeaderText = "Number"
        Me.colOtroNumero.MinimumWidth = 6
        Me.colOtroNumero.Name = "colOtroNumero"
        Me.colOtroNumero.ReadOnly = True
        Me.colOtroNumero.Width = 125
        '
        'colOtroDescripcion
        '
        Me.colOtroDescripcion.HeaderText = "Description"
        Me.colOtroDescripcion.MinimumWidth = 6
        Me.colOtroDescripcion.Name = "colOtroDescripcion"
        Me.colOtroDescripcion.ReadOnly = True
        Me.colOtroDescripcion.Width = 125
        '
        'colOtroFecha
        '
        Me.colOtroFecha.HeaderText = "Date"
        Me.colOtroFecha.MinimumWidth = 6
        Me.colOtroFecha.Name = "colOtroFecha"
        Me.colOtroFecha.ReadOnly = True
        Me.colOtroFecha.Width = 125
        '
        'colOtroReferencia
        '
        Me.colOtroReferencia.HeaderText = "Reference"
        Me.colOtroReferencia.MinimumWidth = 6
        Me.colOtroReferencia.Name = "colOtroReferencia"
        Me.colOtroReferencia.ReadOnly = True
        Me.colOtroReferencia.Width = 125
        '
        'colOtroSaldo
        '
        Me.colOtroSaldo.HeaderText = "Balance"
        Me.colOtroSaldo.MinimumWidth = 6
        Me.colOtroSaldo.Name = "colOtroSaldo"
        Me.colOtroSaldo.ReadOnly = True
        Me.colOtroSaldo.Width = 125
        '
        'colOtroConcepto
        '
        Me.colOtroConcepto.HeaderText = "Concept"
        Me.colOtroConcepto.MinimumWidth = 6
        Me.colOtroConcepto.Name = "colOtroConcepto"
        Me.colOtroConcepto.ReadOnly = True
        Me.colOtroConcepto.Width = 125
        '
        'panelOpciones
        '
        Me.panelOpciones.Controls.Add(Me.celdaRetencion)
        Me.panelOpciones.Controls.Add(Me.etiquetaRetencion)
        Me.panelOpciones.Controls.Add(Me.celdaSubtotal)
        Me.panelOpciones.Controls.Add(Me.etiquetaSubTotal)
        Me.panelOpciones.Controls.Add(Me.celdaTotalLiquidar)
        Me.panelOpciones.Controls.Add(Me.etiquetaTotalLiquidar)
        Me.panelOpciones.Controls.Add(Me.gbBotones)
        Me.panelOpciones.Dock = System.Windows.Forms.DockStyle.Right
        Me.panelOpciones.Location = New System.Drawing.Point(297, 0)
        Me.panelOpciones.Margin = New System.Windows.Forms.Padding(2)
        Me.panelOpciones.Name = "panelOpciones"
        Me.panelOpciones.Size = New System.Drawing.Size(492, 129)
        Me.panelOpciones.TabIndex = 0
        '
        'celdaRetencion
        '
        Me.celdaRetencion.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.celdaRetencion.Location = New System.Drawing.Point(136, 29)
        Me.celdaRetencion.Margin = New System.Windows.Forms.Padding(2)
        Me.celdaRetencion.Name = "celdaRetencion"
        Me.celdaRetencion.ReadOnly = True
        Me.celdaRetencion.Size = New System.Drawing.Size(104, 19)
        Me.celdaRetencion.TabIndex = 6
        '
        'etiquetaRetencion
        '
        Me.etiquetaRetencion.AutoSize = True
        Me.etiquetaRetencion.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.etiquetaRetencion.Location = New System.Drawing.Point(66, 32)
        Me.etiquetaRetencion.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.etiquetaRetencion.Name = "etiquetaRetencion"
        Me.etiquetaRetencion.Size = New System.Drawing.Size(63, 13)
        Me.etiquetaRetencion.TabIndex = 5
        Me.etiquetaRetencion.Text = "Discounts"
        '
        'celdaSubtotal
        '
        Me.celdaSubtotal.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.celdaSubtotal.Location = New System.Drawing.Point(136, 7)
        Me.celdaSubtotal.Margin = New System.Windows.Forms.Padding(2)
        Me.celdaSubtotal.Name = "celdaSubtotal"
        Me.celdaSubtotal.ReadOnly = True
        Me.celdaSubtotal.Size = New System.Drawing.Size(104, 19)
        Me.celdaSubtotal.TabIndex = 4
        '
        'etiquetaSubTotal
        '
        Me.etiquetaSubTotal.AutoSize = True
        Me.etiquetaSubTotal.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.etiquetaSubTotal.Location = New System.Drawing.Point(70, 11)
        Me.etiquetaSubTotal.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.etiquetaSubTotal.Name = "etiquetaSubTotal"
        Me.etiquetaSubTotal.Size = New System.Drawing.Size(58, 13)
        Me.etiquetaSubTotal.TabIndex = 3
        Me.etiquetaSubTotal.Text = "SubTotal"
        '
        'celdaTotalLiquidar
        '
        Me.celdaTotalLiquidar.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.celdaTotalLiquidar.Location = New System.Drawing.Point(378, 25)
        Me.celdaTotalLiquidar.Margin = New System.Windows.Forms.Padding(2)
        Me.celdaTotalLiquidar.Name = "celdaTotalLiquidar"
        Me.celdaTotalLiquidar.ReadOnly = True
        Me.celdaTotalLiquidar.Size = New System.Drawing.Size(104, 19)
        Me.celdaTotalLiquidar.TabIndex = 2
        '
        'etiquetaTotalLiquidar
        '
        Me.etiquetaTotalLiquidar.AutoSize = True
        Me.etiquetaTotalLiquidar.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.etiquetaTotalLiquidar.Location = New System.Drawing.Point(265, 28)
        Me.etiquetaTotalLiquidar.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.etiquetaTotalLiquidar.Name = "etiquetaTotalLiquidar"
        Me.etiquetaTotalLiquidar.Size = New System.Drawing.Size(107, 13)
        Me.etiquetaTotalLiquidar.TabIndex = 1
        Me.etiquetaTotalLiquidar.Text = "Total to Liquidate"
        '
        'gbBotones
        '
        Me.gbBotones.Controls.Add(Me.botonBorrarLiquidacion)
        Me.gbBotones.Controls.Add(Me.botonLiquidar)
        Me.gbBotones.Controls.Add(Me.botonReportes)
        Me.gbBotones.Controls.Add(Me.botonArqueo)
        Me.gbBotones.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.gbBotones.Location = New System.Drawing.Point(0, 46)
        Me.gbBotones.Margin = New System.Windows.Forms.Padding(2)
        Me.gbBotones.Name = "gbBotones"
        Me.gbBotones.Padding = New System.Windows.Forms.Padding(2)
        Me.gbBotones.Size = New System.Drawing.Size(492, 83)
        Me.gbBotones.TabIndex = 0
        Me.gbBotones.TabStop = False
        Me.gbBotones.Text = "Options"
        '
        'botonBorrarLiquidacion
        '
        Me.botonBorrarLiquidacion.Image = Global.KARIMs_SGI.My.Resources.Resources.delete3
        Me.botonBorrarLiquidacion.ImageAlign = System.Drawing.ContentAlignment.TopCenter
        Me.botonBorrarLiquidacion.Location = New System.Drawing.Point(298, 24)
        Me.botonBorrarLiquidacion.Margin = New System.Windows.Forms.Padding(2)
        Me.botonBorrarLiquidacion.Name = "botonBorrarLiquidacion"
        Me.botonBorrarLiquidacion.Size = New System.Drawing.Size(63, 43)
        Me.botonBorrarLiquidacion.TabIndex = 17
        Me.botonBorrarLiquidacion.Text = "Delete Liq."
        Me.botonBorrarLiquidacion.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.botonBorrarLiquidacion.UseVisualStyleBackColor = True
        '
        'botonLiquidar
        '
        Me.botonLiquidar.Image = Global.KARIMs_SGI.My.Resources.Resources.folder_document
        Me.botonLiquidar.ImageAlign = System.Drawing.ContentAlignment.TopCenter
        Me.botonLiquidar.Location = New System.Drawing.Point(222, 24)
        Me.botonLiquidar.Margin = New System.Windows.Forms.Padding(2)
        Me.botonLiquidar.Name = "botonLiquidar"
        Me.botonLiquidar.Size = New System.Drawing.Size(64, 43)
        Me.botonLiquidar.TabIndex = 16
        Me.botonLiquidar.Text = "Liquidate"
        Me.botonLiquidar.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.botonLiquidar.UseVisualStyleBackColor = True
        '
        'botonReportes
        '
        Me.botonReportes.Image = Global.KARIMs_SGI.My.Resources.Resources.Exportar
        Me.botonReportes.ImageAlign = System.Drawing.ContentAlignment.TopCenter
        Me.botonReportes.Location = New System.Drawing.Point(146, 24)
        Me.botonReportes.Margin = New System.Windows.Forms.Padding(2)
        Me.botonReportes.Name = "botonReportes"
        Me.botonReportes.Size = New System.Drawing.Size(64, 43)
        Me.botonReportes.TabIndex = 15
        Me.botonReportes.Text = "Reports"
        Me.botonReportes.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.botonReportes.UseVisualStyleBackColor = True
        '
        'botonArqueo
        '
        Me.botonArqueo.Image = Global.KARIMs_SGI.My.Resources.Resources.currency1
        Me.botonArqueo.ImageAlign = System.Drawing.ContentAlignment.TopCenter
        Me.botonArqueo.Location = New System.Drawing.Point(68, 24)
        Me.botonArqueo.Margin = New System.Windows.Forms.Padding(2)
        Me.botonArqueo.Name = "botonArqueo"
        Me.botonArqueo.Size = New System.Drawing.Size(63, 43)
        Me.botonArqueo.TabIndex = 14
        Me.botonArqueo.Text = "Cash register"
        Me.botonArqueo.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.botonArqueo.UseVisualStyleBackColor = True
        '
        'panelFechas
        '
        Me.panelFechas.Controls.Add(Me.checkTodo)
        Me.panelFechas.Controls.Add(Me.celdaidDocumento)
        Me.panelFechas.Controls.Add(Me.checkSeleccionar)
        Me.panelFechas.Controls.Add(Me.celdaDisponible)
        Me.panelFechas.Controls.Add(Me.etiquetaDisponible)
        Me.panelFechas.Controls.Add(Me.botonRecargar)
        Me.panelFechas.Controls.Add(Me.dtpFinal)
        Me.panelFechas.Controls.Add(Me.dtpIncial)
        Me.panelFechas.Controls.Add(Me.etiquetaFechas)
        Me.panelFechas.Controls.Add(Me.botonDocumento)
        Me.panelFechas.Controls.Add(Me.botonNuevoDoc)
        Me.panelFechas.Controls.Add(Me.celdaDocumento)
        Me.panelFechas.Dock = System.Windows.Forms.DockStyle.Top
        Me.panelFechas.Location = New System.Drawing.Point(0, 141)
        Me.panelFechas.Margin = New System.Windows.Forms.Padding(2)
        Me.panelFechas.Name = "panelFechas"
        Me.panelFechas.Size = New System.Drawing.Size(789, 69)
        Me.panelFechas.TabIndex = 1
        '
        'checkTodo
        '
        Me.checkTodo.AutoSize = True
        Me.checkTodo.Location = New System.Drawing.Point(89, 9)
        Me.checkTodo.Margin = New System.Windows.Forms.Padding(2)
        Me.checkTodo.Name = "checkTodo"
        Me.checkTodo.Size = New System.Drawing.Size(94, 17)
        Me.checkTodo.TabIndex = 23
        Me.checkTodo.Text = "All Documents"
        Me.checkTodo.UseVisualStyleBackColor = True
        '
        'celdaidDocumento
        '
        Me.celdaidDocumento.Location = New System.Drawing.Point(259, 3)
        Me.celdaidDocumento.Margin = New System.Windows.Forms.Padding(2)
        Me.celdaidDocumento.Name = "celdaidDocumento"
        Me.celdaidDocumento.Size = New System.Drawing.Size(13, 20)
        Me.celdaidDocumento.TabIndex = 22
        Me.celdaidDocumento.Visible = False
        '
        'checkSeleccionar
        '
        Me.checkSeleccionar.AutoSize = True
        Me.checkSeleccionar.CheckAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.checkSeleccionar.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.checkSeleccionar.ForeColor = System.Drawing.Color.Green
        Me.checkSeleccionar.Location = New System.Drawing.Point(688, 24)
        Me.checkSeleccionar.Margin = New System.Windows.Forms.Padding(2)
        Me.checkSeleccionar.Name = "checkSeleccionar"
        Me.checkSeleccionar.Size = New System.Drawing.Size(79, 17)
        Me.checkSeleccionar.TabIndex = 21
        Me.checkSeleccionar.Text = "Select all"
        Me.checkSeleccionar.UseVisualStyleBackColor = True
        '
        'celdaDisponible
        '
        Me.celdaDisponible.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.celdaDisponible.BackColor = System.Drawing.SystemColors.Info
        Me.celdaDisponible.Location = New System.Drawing.Point(699, 30)
        Me.celdaDisponible.Margin = New System.Windows.Forms.Padding(2)
        Me.celdaDisponible.Name = "celdaDisponible"
        Me.celdaDisponible.ReadOnly = True
        Me.celdaDisponible.Size = New System.Drawing.Size(73, 20)
        Me.celdaDisponible.TabIndex = 14
        '
        'etiquetaDisponible
        '
        Me.etiquetaDisponible.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.etiquetaDisponible.AutoSize = True
        Me.etiquetaDisponible.Location = New System.Drawing.Point(714, 9)
        Me.etiquetaDisponible.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.etiquetaDisponible.Name = "etiquetaDisponible"
        Me.etiquetaDisponible.Size = New System.Drawing.Size(50, 13)
        Me.etiquetaDisponible.TabIndex = 20
        Me.etiquetaDisponible.Text = "Available"
        '
        'botonRecargar
        '
        Me.botonRecargar.Location = New System.Drawing.Point(526, 20)
        Me.botonRecargar.Margin = New System.Windows.Forms.Padding(2)
        Me.botonRecargar.Name = "botonRecargar"
        Me.botonRecargar.Size = New System.Drawing.Size(62, 21)
        Me.botonRecargar.TabIndex = 18
        Me.botonRecargar.Text = "Recharge"
        Me.botonRecargar.UseVisualStyleBackColor = True
        '
        'dtpFinal
        '
        Me.dtpFinal.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.dtpFinal.Location = New System.Drawing.Point(424, 19)
        Me.dtpFinal.Margin = New System.Windows.Forms.Padding(2)
        Me.dtpFinal.Name = "dtpFinal"
        Me.dtpFinal.Size = New System.Drawing.Size(92, 20)
        Me.dtpFinal.TabIndex = 17
        '
        'dtpIncial
        '
        Me.dtpIncial.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.dtpIncial.Location = New System.Drawing.Point(318, 18)
        Me.dtpIncial.Margin = New System.Windows.Forms.Padding(2)
        Me.dtpIncial.Name = "dtpIncial"
        Me.dtpIncial.Size = New System.Drawing.Size(91, 20)
        Me.dtpIncial.TabIndex = 16
        '
        'etiquetaFechas
        '
        Me.etiquetaFechas.AutoSize = True
        Me.etiquetaFechas.Location = New System.Drawing.Point(268, 24)
        Me.etiquetaFechas.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.etiquetaFechas.Name = "etiquetaFechas"
        Me.etiquetaFechas.Size = New System.Drawing.Size(48, 13)
        Me.etiquetaFechas.TabIndex = 14
        Me.etiquetaFechas.Text = "between"
        '
        'botonDocumento
        '
        Me.botonDocumento.Location = New System.Drawing.Point(232, 28)
        Me.botonDocumento.Margin = New System.Windows.Forms.Padding(2)
        Me.botonDocumento.Name = "botonDocumento"
        Me.botonDocumento.Size = New System.Drawing.Size(22, 19)
        Me.botonDocumento.TabIndex = 15
        Me.botonDocumento.Text = "..."
        Me.botonDocumento.UseVisualStyleBackColor = True
        '
        'botonNuevoDoc
        '
        Me.botonNuevoDoc.Image = Global.KARIMs_SGI.My.Resources.Resources.document_add
        Me.botonNuevoDoc.Location = New System.Drawing.Point(9, 5)
        Me.botonNuevoDoc.Margin = New System.Windows.Forms.Padding(2)
        Me.botonNuevoDoc.Name = "botonNuevoDoc"
        Me.botonNuevoDoc.Size = New System.Drawing.Size(64, 43)
        Me.botonNuevoDoc.TabIndex = 0
        Me.botonNuevoDoc.Text = "Document"
        Me.botonNuevoDoc.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.botonNuevoDoc.UseVisualStyleBackColor = True
        '
        'celdaDocumento
        '
        Me.celdaDocumento.Location = New System.Drawing.Point(80, 29)
        Me.celdaDocumento.Margin = New System.Windows.Forms.Padding(2)
        Me.celdaDocumento.Name = "celdaDocumento"
        Me.celdaDocumento.ReadOnly = True
        Me.celdaDocumento.Size = New System.Drawing.Size(142, 20)
        Me.celdaDocumento.TabIndex = 14
        '
        'panelEncabezadoDetalle
        '
        Me.panelEncabezadoDetalle.Controls.Add(Me.gbEncabezadoDetalle1)
        Me.panelEncabezadoDetalle.Controls.Add(Me.gbEncabezadoDetalle)
        Me.panelEncabezadoDetalle.Dock = System.Windows.Forms.DockStyle.Top
        Me.panelEncabezadoDetalle.Location = New System.Drawing.Point(0, 0)
        Me.panelEncabezadoDetalle.Margin = New System.Windows.Forms.Padding(2)
        Me.panelEncabezadoDetalle.Name = "panelEncabezadoDetalle"
        Me.panelEncabezadoDetalle.Size = New System.Drawing.Size(789, 141)
        Me.panelEncabezadoDetalle.TabIndex = 0
        '
        'gbEncabezadoDetalle1
        '
        Me.gbEncabezadoDetalle1.Controls.Add(Me.Label14)
        Me.gbEncabezadoDetalle1.Controls.Add(Me.checkInactivarCaja)
        Me.gbEncabezadoDetalle1.Controls.Add(Me.celdaCuenta)
        Me.gbEncabezadoDetalle1.Controls.Add(Me.celdaDescCuenta)
        Me.gbEncabezadoDetalle1.Controls.Add(Me.botonCuenta)
        Me.gbEncabezadoDetalle1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.gbEncabezadoDetalle1.Location = New System.Drawing.Point(525, 0)
        Me.gbEncabezadoDetalle1.Margin = New System.Windows.Forms.Padding(2)
        Me.gbEncabezadoDetalle1.Name = "gbEncabezadoDetalle1"
        Me.gbEncabezadoDetalle1.Padding = New System.Windows.Forms.Padding(2)
        Me.gbEncabezadoDetalle1.Size = New System.Drawing.Size(264, 141)
        Me.gbEncabezadoDetalle1.TabIndex = 1
        Me.gbEncabezadoDetalle1.TabStop = False
        '
        'Label14
        '
        Me.Label14.AutoSize = True
        Me.Label14.Location = New System.Drawing.Point(8, 67)
        Me.Label14.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(104, 13)
        Me.Label14.TabIndex = 10
        Me.Label14.Text = "Accounting Account"
        '
        'checkInactivarCaja
        '
        Me.checkInactivarCaja.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.checkInactivarCaja.AutoSize = True
        Me.checkInactivarCaja.BackColor = System.Drawing.SystemColors.Control
        Me.checkInactivarCaja.CheckAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.checkInactivarCaja.Checked = True
        Me.checkInactivarCaja.CheckState = System.Windows.Forms.CheckState.Checked
        Me.checkInactivarCaja.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Underline), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.checkInactivarCaja.ForeColor = System.Drawing.Color.Brown
        Me.checkInactivarCaja.ImageAlign = System.Drawing.ContentAlignment.TopRight
        Me.checkInactivarCaja.Location = New System.Drawing.Point(56, 18)
        Me.checkInactivarCaja.Margin = New System.Windows.Forms.Padding(2)
        Me.checkInactivarCaja.Name = "checkInactivarCaja"
        Me.checkInactivarCaja.Size = New System.Drawing.Size(180, 21)
        Me.checkInactivarCaja.TabIndex = 13
        Me.checkInactivarCaja.Text = "Inactivate Petty Cash"
        Me.checkInactivarCaja.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.checkInactivarCaja.UseVisualStyleBackColor = False
        '
        'celdaCuenta
        '
        Me.celdaCuenta.Location = New System.Drawing.Point(118, 65)
        Me.celdaCuenta.Margin = New System.Windows.Forms.Padding(2)
        Me.celdaCuenta.Name = "celdaCuenta"
        Me.celdaCuenta.ReadOnly = True
        Me.celdaCuenta.Size = New System.Drawing.Size(265, 20)
        Me.celdaCuenta.TabIndex = 10
        '
        'celdaDescCuenta
        '
        Me.celdaDescCuenta.Location = New System.Drawing.Point(118, 86)
        Me.celdaDescCuenta.Margin = New System.Windows.Forms.Padding(2)
        Me.celdaDescCuenta.Name = "celdaDescCuenta"
        Me.celdaDescCuenta.ReadOnly = True
        Me.celdaDescCuenta.Size = New System.Drawing.Size(265, 20)
        Me.celdaDescCuenta.TabIndex = 12
        '
        'botonCuenta
        '
        Me.botonCuenta.Location = New System.Drawing.Point(413, 63)
        Me.botonCuenta.Margin = New System.Windows.Forms.Padding(2)
        Me.botonCuenta.Name = "botonCuenta"
        Me.botonCuenta.Size = New System.Drawing.Size(25, 19)
        Me.botonCuenta.TabIndex = 11
        Me.botonCuenta.Text = "..."
        Me.botonCuenta.UseVisualStyleBackColor = True
        '
        'gbEncabezadoDetalle
        '
        Me.gbEncabezadoDetalle.Controls.Add(Me.celdaTipoCaja)
        Me.gbEncabezadoDetalle.Controls.Add(Me.celdaidMoneda)
        Me.gbEncabezadoDetalle.Controls.Add(Me.botonMoneda)
        Me.gbEncabezadoDetalle.Controls.Add(Me.celdaDescMoneda)
        Me.gbEncabezadoDetalle.Controls.Add(Me.celdaMoneda)
        Me.gbEncabezadoDetalle.Controls.Add(Me.etiquetaMoneda)
        Me.gbEncabezadoDetalle.Controls.Add(Me.celdaDescripcion)
        Me.gbEncabezadoDetalle.Controls.Add(Me.etiquetaDescripcion)
        Me.gbEncabezadoDetalle.Controls.Add(Me.celdaResponsable)
        Me.gbEncabezadoDetalle.Controls.Add(Me.etiquetaResponsable)
        Me.gbEncabezadoDetalle.Controls.Add(Me.celdaCodigo)
        Me.gbEncabezadoDetalle.Controls.Add(Me.etiquetaCodigo)
        Me.gbEncabezadoDetalle.Dock = System.Windows.Forms.DockStyle.Left
        Me.gbEncabezadoDetalle.Location = New System.Drawing.Point(0, 0)
        Me.gbEncabezadoDetalle.Margin = New System.Windows.Forms.Padding(2)
        Me.gbEncabezadoDetalle.Name = "gbEncabezadoDetalle"
        Me.gbEncabezadoDetalle.Padding = New System.Windows.Forms.Padding(2)
        Me.gbEncabezadoDetalle.Size = New System.Drawing.Size(525, 141)
        Me.gbEncabezadoDetalle.TabIndex = 0
        Me.gbEncabezadoDetalle.TabStop = False
        Me.gbEncabezadoDetalle.Text = "data of petty cash"
        '
        'celdaTipoCaja
        '
        Me.celdaTipoCaja.Location = New System.Drawing.Point(172, 109)
        Me.celdaTipoCaja.Margin = New System.Windows.Forms.Padding(2)
        Me.celdaTipoCaja.Name = "celdaTipoCaja"
        Me.celdaTipoCaja.Size = New System.Drawing.Size(30, 20)
        Me.celdaTipoCaja.TabIndex = 23
        Me.celdaTipoCaja.Visible = False
        '
        'celdaidMoneda
        '
        Me.celdaidMoneda.Location = New System.Drawing.Point(172, 18)
        Me.celdaidMoneda.Margin = New System.Windows.Forms.Padding(2)
        Me.celdaidMoneda.Name = "celdaidMoneda"
        Me.celdaidMoneda.Size = New System.Drawing.Size(12, 20)
        Me.celdaidMoneda.TabIndex = 10
        Me.celdaidMoneda.Visible = False
        '
        'botonMoneda
        '
        Me.botonMoneda.Location = New System.Drawing.Point(326, 15)
        Me.botonMoneda.Margin = New System.Windows.Forms.Padding(2)
        Me.botonMoneda.Name = "botonMoneda"
        Me.botonMoneda.Size = New System.Drawing.Size(25, 19)
        Me.botonMoneda.TabIndex = 8
        Me.botonMoneda.Text = "..."
        Me.botonMoneda.UseVisualStyleBackColor = True
        '
        'celdaDescMoneda
        '
        Me.celdaDescMoneda.ForeColor = System.Drawing.Color.Green
        Me.celdaDescMoneda.Location = New System.Drawing.Point(370, 16)
        Me.celdaDescMoneda.Margin = New System.Windows.Forms.Padding(2)
        Me.celdaDescMoneda.Name = "celdaDescMoneda"
        Me.celdaDescMoneda.ReadOnly = True
        Me.celdaDescMoneda.Size = New System.Drawing.Size(128, 20)
        Me.celdaDescMoneda.TabIndex = 9
        '
        'celdaMoneda
        '
        Me.celdaMoneda.Location = New System.Drawing.Point(240, 17)
        Me.celdaMoneda.Margin = New System.Windows.Forms.Padding(2)
        Me.celdaMoneda.Name = "celdaMoneda"
        Me.celdaMoneda.ReadOnly = True
        Me.celdaMoneda.Size = New System.Drawing.Size(76, 20)
        Me.celdaMoneda.TabIndex = 7
        '
        'etiquetaMoneda
        '
        Me.etiquetaMoneda.AutoSize = True
        Me.etiquetaMoneda.Location = New System.Drawing.Point(187, 18)
        Me.etiquetaMoneda.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.etiquetaMoneda.Name = "etiquetaMoneda"
        Me.etiquetaMoneda.Size = New System.Drawing.Size(49, 13)
        Me.etiquetaMoneda.TabIndex = 6
        Me.etiquetaMoneda.Text = "Currency"
        '
        'celdaDescripcion
        '
        Me.celdaDescripcion.Location = New System.Drawing.Point(80, 86)
        Me.celdaDescripcion.Margin = New System.Windows.Forms.Padding(2)
        Me.celdaDescripcion.Name = "celdaDescripcion"
        Me.celdaDescripcion.Size = New System.Drawing.Size(421, 20)
        Me.celdaDescripcion.TabIndex = 5
        '
        'etiquetaDescripcion
        '
        Me.etiquetaDescripcion.AutoSize = True
        Me.etiquetaDescripcion.Location = New System.Drawing.Point(9, 89)
        Me.etiquetaDescripcion.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.etiquetaDescripcion.Name = "etiquetaDescripcion"
        Me.etiquetaDescripcion.Size = New System.Drawing.Size(60, 13)
        Me.etiquetaDescripcion.TabIndex = 4
        Me.etiquetaDescripcion.Text = "Description"
        '
        'celdaResponsable
        '
        Me.celdaResponsable.Location = New System.Drawing.Point(80, 50)
        Me.celdaResponsable.Margin = New System.Windows.Forms.Padding(2)
        Me.celdaResponsable.Name = "celdaResponsable"
        Me.celdaResponsable.Size = New System.Drawing.Size(417, 20)
        Me.celdaResponsable.TabIndex = 3
        '
        'etiquetaResponsable
        '
        Me.etiquetaResponsable.AutoSize = True
        Me.etiquetaResponsable.Location = New System.Drawing.Point(9, 53)
        Me.etiquetaResponsable.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.etiquetaResponsable.Name = "etiquetaResponsable"
        Me.etiquetaResponsable.Size = New System.Drawing.Size(35, 13)
        Me.etiquetaResponsable.TabIndex = 2
        Me.etiquetaResponsable.Text = "Liable"
        '
        'celdaCodigo
        '
        Me.celdaCodigo.Location = New System.Drawing.Point(80, 17)
        Me.celdaCodigo.Margin = New System.Windows.Forms.Padding(2)
        Me.celdaCodigo.Name = "celdaCodigo"
        Me.celdaCodigo.ReadOnly = True
        Me.celdaCodigo.Size = New System.Drawing.Size(76, 20)
        Me.celdaCodigo.TabIndex = 1
        '
        'etiquetaCodigo
        '
        Me.etiquetaCodigo.AutoSize = True
        Me.etiquetaCodigo.Location = New System.Drawing.Point(9, 20)
        Me.etiquetaCodigo.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.etiquetaCodigo.Name = "etiquetaCodigo"
        Me.etiquetaCodigo.Size = New System.Drawing.Size(32, 13)
        Me.etiquetaCodigo.TabIndex = 0
        Me.etiquetaCodigo.Text = "Code"
        '
        'celdaCAI
        '
        Me.celdaCAI.ForeColor = System.Drawing.SystemColors.HotTrack
        Me.celdaCAI.Location = New System.Drawing.Point(290, 145)
        Me.celdaCAI.Margin = New System.Windows.Forms.Padding(2)
        Me.celdaCAI.Name = "celdaCAI"
        Me.celdaCAI.Size = New System.Drawing.Size(234, 20)
        Me.celdaCAI.TabIndex = 25
        Me.celdaCAI.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        Me.celdaCAI.Visible = False
        '
        'etiquetaCAI
        '
        Me.etiquetaCAI.AutoSize = True
        Me.etiquetaCAI.Location = New System.Drawing.Point(263, 148)
        Me.etiquetaCAI.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.etiquetaCAI.Name = "etiquetaCAI"
        Me.etiquetaCAI.Size = New System.Drawing.Size(27, 13)
        Me.etiquetaCAI.TabIndex = 24
        Me.etiquetaCAI.Text = "CAI:"
        Me.etiquetaCAI.Visible = False
        '
        'panelDocumento
        '
        Me.panelDocumento.Controls.Add(Me.dgDetalleDocumento)
        Me.panelDocumento.Controls.Add(Me.panelBtnDetalle)
        Me.panelDocumento.Controls.Add(Me.celdaDetalleDoc)
        Me.panelDocumento.Controls.Add(Me.panelPieDocumento)
        Me.panelDocumento.Controls.Add(Me.panelEncabezadoDocumento)
        Me.panelDocumento.Location = New System.Drawing.Point(89, 72)
        Me.panelDocumento.Margin = New System.Windows.Forms.Padding(2)
        Me.panelDocumento.Name = "panelDocumento"
        Me.panelDocumento.Size = New System.Drawing.Size(477, 419)
        Me.panelDocumento.TabIndex = 4
        '
        'dgDetalleDocumento
        '
        Me.dgDetalleDocumento.AllowUserToAddRows = False
        Me.dgDetalleDocumento.AllowUserToDeleteRows = False
        Me.dgDetalleDocumento.AllowUserToOrderColumns = True
        Me.dgDetalleDocumento.BackgroundColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle7.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle7.BackColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle7.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle7.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle7.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle7.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle7.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.dgDetalleDocumento.ColumnHeadersDefaultCellStyle = DataGridViewCellStyle7
        Me.dgDetalleDocumento.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgDetalleDocumento.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.colCantidadD, Me.colCodigoD, Me.colAnioD, Me.colNumD, Me.colLineaD, Me.colDescripcionD, Me.colPrecioSinIVA, Me.colPrecioD, Me.colTotalD, Me.colGastoD, Me.colidGastoD, Me.colidCuentaIVA, Me.colCcosto, Me.colidCcosto, Me.idrubro, Me.rubro, Me.idcuenta, Me.cuenta, Me.colClasificacionD, Me.colidClasificacionD, Me.colCtaIVA, Me.colExtra})
        DataGridViewCellStyle8.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle8.BackColor = System.Drawing.SystemColors.Window
        DataGridViewCellStyle8.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle8.ForeColor = System.Drawing.SystemColors.ControlText
        DataGridViewCellStyle8.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle8.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle8.WrapMode = System.Windows.Forms.DataGridViewTriState.[False]
        Me.dgDetalleDocumento.DefaultCellStyle = DataGridViewCellStyle8
        Me.dgDetalleDocumento.Dock = System.Windows.Forms.DockStyle.Fill
        Me.dgDetalleDocumento.Location = New System.Drawing.Point(0, 226)
        Me.dgDetalleDocumento.Margin = New System.Windows.Forms.Padding(2)
        Me.dgDetalleDocumento.MultiSelect = False
        Me.dgDetalleDocumento.Name = "dgDetalleDocumento"
        Me.dgDetalleDocumento.RowHeadersWidth = 51
        Me.dgDetalleDocumento.RowTemplate.Height = 24
        Me.dgDetalleDocumento.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.dgDetalleDocumento.Size = New System.Drawing.Size(432, 27)
        Me.dgDetalleDocumento.TabIndex = 2
        '
        'colCantidadD
        '
        Me.colCantidadD.HeaderText = "Quantity"
        Me.colCantidadD.MinimumWidth = 6
        Me.colCantidadD.Name = "colCantidadD"
        Me.colCantidadD.Width = 90
        '
        'colCodigoD
        '
        Me.colCodigoD.HeaderText = "Code"
        Me.colCodigoD.MinimumWidth = 6
        Me.colCodigoD.Name = "colCodigoD"
        Me.colCodigoD.Visible = False
        Me.colCodigoD.Width = 70
        '
        'colAnioD
        '
        Me.colAnioD.HeaderText = "Anio"
        Me.colAnioD.MinimumWidth = 6
        Me.colAnioD.Name = "colAnioD"
        Me.colAnioD.Visible = False
        Me.colAnioD.Width = 65
        '
        'colNumD
        '
        Me.colNumD.HeaderText = "Numero"
        Me.colNumD.MinimumWidth = 6
        Me.colNumD.Name = "colNumD"
        Me.colNumD.Visible = False
        Me.colNumD.Width = 87
        '
        'colLineaD
        '
        Me.colLineaD.HeaderText = "Line"
        Me.colLineaD.MinimumWidth = 6
        Me.colLineaD.Name = "colLineaD"
        Me.colLineaD.Visible = False
        Me.colLineaD.Width = 64
        '
        'colDescripcionD
        '
        Me.colDescripcionD.FillWeight = 200.0!
        Me.colDescripcionD.HeaderText = "Description"
        Me.colDescripcionD.MinimumWidth = 6
        Me.colDescripcionD.Name = "colDescripcionD"
        Me.colDescripcionD.Width = 108
        '
        'colPrecioSinIVA
        '
        Me.colPrecioSinIVA.HeaderText = "Price without VAT"
        Me.colPrecioSinIVA.MinimumWidth = 6
        Me.colPrecioSinIVA.Name = "colPrecioSinIVA"
        Me.colPrecioSinIVA.Width = 125
        '
        'colPrecioD
        '
        Me.colPrecioD.HeaderText = "Price"
        Me.colPrecioD.MinimumWidth = 6
        Me.colPrecioD.Name = "colPrecioD"
        Me.colPrecioD.Width = 69
        '
        'colTotalD
        '
        Me.colTotalD.HeaderText = "Total"
        Me.colTotalD.MinimumWidth = 6
        Me.colTotalD.Name = "colTotalD"
        Me.colTotalD.ReadOnly = True
        Me.colTotalD.Width = 69
        '
        'colGastoD
        '
        Me.colGastoD.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.colGastoD.HeaderText = "Expense"
        Me.colGastoD.MinimumWidth = 6
        Me.colGastoD.Name = "colGastoD"
        Me.colGastoD.ReadOnly = True
        Me.colGastoD.Width = 73
        '
        'colidGastoD
        '
        Me.colidGastoD.HeaderText = "id Gasto"
        Me.colidGastoD.MinimumWidth = 6
        Me.colidGastoD.Name = "colidGastoD"
        Me.colidGastoD.Visible = False
        Me.colidGastoD.Width = 90
        '
        'colidCuentaIVA
        '
        Me.colidCuentaIVA.HeaderText = "Account VAT"
        Me.colidCuentaIVA.MinimumWidth = 6
        Me.colidCuentaIVA.Name = "colidCuentaIVA"
        Me.colidCuentaIVA.ReadOnly = True
        Me.colidCuentaIVA.Width = 125
        '
        'colCcosto
        '
        Me.colCcosto.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.colCcosto.HeaderText = "Cost Center"
        Me.colCcosto.MinimumWidth = 6
        Me.colCcosto.Name = "colCcosto"
        Me.colCcosto.ReadOnly = True
        Me.colCcosto.Width = 80
        '
        'colidCcosto
        '
        Me.colidCcosto.HeaderText = "id Centro"
        Me.colidCcosto.MinimumWidth = 6
        Me.colidCcosto.Name = "colidCcosto"
        Me.colidCcosto.Visible = False
        Me.colidCcosto.Width = 94
        '
        'idrubro
        '
        Me.idrubro.HeaderText = "idrubro"
        Me.idrubro.MinimumWidth = 6
        Me.idrubro.Name = "idrubro"
        Me.idrubro.Width = 125
        '
        'rubro
        '
        Me.rubro.HeaderText = "Item"
        Me.rubro.MinimumWidth = 6
        Me.rubro.Name = "rubro"
        Me.rubro.Width = 125
        '
        'idcuenta
        '
        Me.idcuenta.HeaderText = "idcuenta"
        Me.idcuenta.MinimumWidth = 6
        Me.idcuenta.Name = "idcuenta"
        Me.idcuenta.Width = 125
        '
        'cuenta
        '
        Me.cuenta.HeaderText = "Account"
        Me.cuenta.MinimumWidth = 6
        Me.cuenta.Name = "cuenta"
        Me.cuenta.Width = 125
        '
        'colClasificacionD
        '
        Me.colClasificacionD.HeaderText = "Classification"
        Me.colClasificacionD.MinimumWidth = 6
        Me.colClasificacionD.Name = "colClasificacionD"
        Me.colClasificacionD.ReadOnly = True
        Me.colClasificacionD.Width = 119
        '
        'colidClasificacionD
        '
        Me.colidClasificacionD.HeaderText = "id Clasificacion"
        Me.colidClasificacionD.MinimumWidth = 6
        Me.colidClasificacionD.Name = "colidClasificacionD"
        Me.colidClasificacionD.Visible = False
        Me.colidClasificacionD.Width = 130
        '
        'colCtaIVA
        '
        Me.colCtaIVA.HeaderText = "Nombre IVA"
        Me.colCtaIVA.MinimumWidth = 6
        Me.colCtaIVA.Name = "colCtaIVA"
        Me.colCtaIVA.Visible = False
        Me.colCtaIVA.Width = 125
        '
        'colExtra
        '
        Me.colExtra.HeaderText = "Extra"
        Me.colExtra.MinimumWidth = 6
        Me.colExtra.Name = "colExtra"
        Me.colExtra.Visible = False
        Me.colExtra.Width = 69
        '
        'panelBtnDetalle
        '
        Me.panelBtnDetalle.Controls.Add(Me.botonMenos)
        Me.panelBtnDetalle.Controls.Add(Me.botonMas)
        Me.panelBtnDetalle.Dock = System.Windows.Forms.DockStyle.Right
        Me.panelBtnDetalle.Location = New System.Drawing.Point(432, 226)
        Me.panelBtnDetalle.Margin = New System.Windows.Forms.Padding(2)
        Me.panelBtnDetalle.Name = "panelBtnDetalle"
        Me.panelBtnDetalle.Size = New System.Drawing.Size(45, 27)
        Me.panelBtnDetalle.TabIndex = 45
        '
        'botonMenos
        '
        Me.botonMenos.Image = Global.KARIMs_SGI.My.Resources.Resources.delete3
        Me.botonMenos.Location = New System.Drawing.Point(8, 50)
        Me.botonMenos.Margin = New System.Windows.Forms.Padding(2)
        Me.botonMenos.Name = "botonMenos"
        Me.botonMenos.Size = New System.Drawing.Size(26, 25)
        Me.botonMenos.TabIndex = 44
        Me.ToolTip1.SetToolTip(Me.botonMenos, "Remove Line")
        Me.botonMenos.UseVisualStyleBackColor = True
        '
        'botonMas
        '
        Me.botonMas.Image = Global.KARIMs_SGI.My.Resources.Resources.plus
        Me.botonMas.Location = New System.Drawing.Point(8, 9)
        Me.botonMas.Margin = New System.Windows.Forms.Padding(2)
        Me.botonMas.Name = "botonMas"
        Me.botonMas.Size = New System.Drawing.Size(26, 25)
        Me.botonMas.TabIndex = 3
        Me.ToolTip1.SetToolTip(Me.botonMas, "Add Line")
        Me.botonMas.UseVisualStyleBackColor = True
        '
        'celdaDetalleDoc
        '
        Me.celdaDetalleDoc.Dock = System.Windows.Forms.DockStyle.Top
        Me.celdaDetalleDoc.Location = New System.Drawing.Point(0, 206)
        Me.celdaDetalleDoc.Margin = New System.Windows.Forms.Padding(2)
        Me.celdaDetalleDoc.Name = "celdaDetalleDoc"
        Me.celdaDetalleDoc.Size = New System.Drawing.Size(477, 20)
        Me.celdaDetalleDoc.TabIndex = 3
        '
        'panelPieDocumento
        '
        Me.panelPieDocumento.Controls.Add(Me.gbImpuestos)
        Me.panelPieDocumento.Controls.Add(Me.panelLetra)
        Me.panelPieDocumento.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.panelPieDocumento.Location = New System.Drawing.Point(0, 253)
        Me.panelPieDocumento.Margin = New System.Windows.Forms.Padding(2)
        Me.panelPieDocumento.Name = "panelPieDocumento"
        Me.panelPieDocumento.Size = New System.Drawing.Size(477, 166)
        Me.panelPieDocumento.TabIndex = 1
        '
        'gbImpuestos
        '
        Me.gbImpuestos.Controls.Add(Me.dgImpuestos)
        Me.gbImpuestos.Controls.Add(Me.panelBotones)
        Me.gbImpuestos.Dock = System.Windows.Forms.DockStyle.Fill
        Me.gbImpuestos.Location = New System.Drawing.Point(0, 0)
        Me.gbImpuestos.Margin = New System.Windows.Forms.Padding(2)
        Me.gbImpuestos.Name = "gbImpuestos"
        Me.gbImpuestos.Padding = New System.Windows.Forms.Padding(2)
        Me.gbImpuestos.Size = New System.Drawing.Size(477, 123)
        Me.gbImpuestos.TabIndex = 1
        Me.gbImpuestos.TabStop = False
        Me.gbImpuestos.Text = "Tax Breakdown"
        '
        'dgImpuestos
        '
        Me.dgImpuestos.AllowUserToAddRows = False
        Me.dgImpuestos.AllowUserToDeleteRows = False
        Me.dgImpuestos.AllowUserToOrderColumns = True
        Me.dgImpuestos.BackgroundColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle9.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle9.BackColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle9.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle9.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle9.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle9.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle9.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.dgImpuestos.ColumnHeadersDefaultCellStyle = DataGridViewCellStyle9
        Me.dgImpuestos.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgImpuestos.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.colLine, Me.colID, Me.colCodigo1, Me.colTipo, Me.colDescripcion1, Me.colCantidad1, Me.colFactor, Me.colBase, Me.colMonto, Me.colTag, Me.colOrigen})
        DataGridViewCellStyle10.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle10.BackColor = System.Drawing.SystemColors.Window
        DataGridViewCellStyle10.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle10.ForeColor = System.Drawing.SystemColors.ControlText
        DataGridViewCellStyle10.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle10.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle10.WrapMode = System.Windows.Forms.DataGridViewTriState.[False]
        Me.dgImpuestos.DefaultCellStyle = DataGridViewCellStyle10
        Me.dgImpuestos.Dock = System.Windows.Forms.DockStyle.Fill
        Me.dgImpuestos.Location = New System.Drawing.Point(2, 15)
        Me.dgImpuestos.Margin = New System.Windows.Forms.Padding(2)
        Me.dgImpuestos.MultiSelect = False
        Me.dgImpuestos.Name = "dgImpuestos"
        Me.dgImpuestos.ReadOnly = True
        DataGridViewCellStyle11.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle11.BackColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle11.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle11.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle11.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle11.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle11.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.dgImpuestos.RowHeadersDefaultCellStyle = DataGridViewCellStyle11
        Me.dgImpuestos.RowHeadersWidth = 51
        Me.dgImpuestos.RowTemplate.Height = 24
        Me.dgImpuestos.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.dgImpuestos.Size = New System.Drawing.Size(433, 106)
        Me.dgImpuestos.TabIndex = 0
        '
        'colLine
        '
        Me.colLine.HeaderText = "Order"
        Me.colLine.MinimumWidth = 6
        Me.colLine.Name = "colLine"
        Me.colLine.ReadOnly = True
        Me.colLine.Width = 125
        '
        'colID
        '
        Me.colID.HeaderText = "ID"
        Me.colID.MinimumWidth = 6
        Me.colID.Name = "colID"
        Me.colID.ReadOnly = True
        Me.colID.Visible = False
        Me.colID.Width = 125
        '
        'colCodigo1
        '
        Me.colCodigo1.HeaderText = "Code"
        Me.colCodigo1.MinimumWidth = 6
        Me.colCodigo1.Name = "colCodigo1"
        Me.colCodigo1.ReadOnly = True
        Me.colCodigo1.Visible = False
        Me.colCodigo1.Width = 125
        '
        'colTipo
        '
        Me.colTipo.HeaderText = "Kind"
        Me.colTipo.MinimumWidth = 6
        Me.colTipo.Name = "colTipo"
        Me.colTipo.ReadOnly = True
        Me.colTipo.Visible = False
        Me.colTipo.Width = 125
        '
        'colDescripcion1
        '
        Me.colDescripcion1.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.colDescripcion1.HeaderText = "Description"
        Me.colDescripcion1.MinimumWidth = 6
        Me.colDescripcion1.Name = "colDescripcion1"
        Me.colDescripcion1.ReadOnly = True
        Me.colDescripcion1.Width = 85
        '
        'colCantidad1
        '
        Me.colCantidad1.HeaderText = "Quantity"
        Me.colCantidad1.MinimumWidth = 6
        Me.colCantidad1.Name = "colCantidad1"
        Me.colCantidad1.ReadOnly = True
        Me.colCantidad1.Width = 125
        '
        'colFactor
        '
        Me.colFactor.HeaderText = "Factor"
        Me.colFactor.MinimumWidth = 6
        Me.colFactor.Name = "colFactor"
        Me.colFactor.ReadOnly = True
        Me.colFactor.Width = 125
        '
        'colBase
        '
        Me.colBase.HeaderText = "Base"
        Me.colBase.MinimumWidth = 6
        Me.colBase.Name = "colBase"
        Me.colBase.ReadOnly = True
        Me.colBase.Width = 125
        '
        'colMonto
        '
        Me.colMonto.HeaderText = "Tax"
        Me.colMonto.MinimumWidth = 6
        Me.colMonto.Name = "colMonto"
        Me.colMonto.ReadOnly = True
        Me.colMonto.Width = 125
        '
        'colTag
        '
        Me.colTag.HeaderText = "Tag"
        Me.colTag.MinimumWidth = 6
        Me.colTag.Name = "colTag"
        Me.colTag.ReadOnly = True
        Me.colTag.Visible = False
        Me.colTag.Width = 125
        '
        'colOrigen
        '
        Me.colOrigen.HeaderText = "Origin"
        Me.colOrigen.MinimumWidth = 6
        Me.colOrigen.Name = "colOrigen"
        Me.colOrigen.ReadOnly = True
        Me.colOrigen.Visible = False
        Me.colOrigen.Width = 125
        '
        'panelBotones
        '
        Me.panelBotones.Controls.Add(Me.botonEliminar)
        Me.panelBotones.Controls.Add(Me.botonOtrosImp)
        Me.panelBotones.Controls.Add(Me.botnEditar)
        Me.panelBotones.Dock = System.Windows.Forms.DockStyle.Right
        Me.panelBotones.Location = New System.Drawing.Point(435, 15)
        Me.panelBotones.Margin = New System.Windows.Forms.Padding(2)
        Me.panelBotones.Name = "panelBotones"
        Me.panelBotones.Size = New System.Drawing.Size(40, 106)
        Me.panelBotones.TabIndex = 1
        '
        'botonEliminar
        '
        Me.botonEliminar.Image = Global.KARIMs_SGI.My.Resources.Resources.delete3
        Me.botonEliminar.Location = New System.Drawing.Point(8, 80)
        Me.botonEliminar.Margin = New System.Windows.Forms.Padding(2)
        Me.botonEliminar.Name = "botonEliminar"
        Me.botonEliminar.Size = New System.Drawing.Size(26, 25)
        Me.botonEliminar.TabIndex = 2
        Me.botonEliminar.UseVisualStyleBackColor = True
        '
        'botonOtrosImp
        '
        Me.botonOtrosImp.Image = CType(resources.GetObject("botonOtrosImp.Image"), System.Drawing.Image)
        Me.botonOtrosImp.Location = New System.Drawing.Point(8, 45)
        Me.botonOtrosImp.Margin = New System.Windows.Forms.Padding(2)
        Me.botonOtrosImp.Name = "botonOtrosImp"
        Me.botonOtrosImp.Size = New System.Drawing.Size(26, 25)
        Me.botonOtrosImp.TabIndex = 1
        Me.ToolTip1.SetToolTip(Me.botonOtrosImp, "Other taxes")
        Me.botonOtrosImp.UseVisualStyleBackColor = True
        '
        'botnEditar
        '
        Me.botnEditar.Image = CType(resources.GetObject("botnEditar.Image"), System.Drawing.Image)
        Me.botnEditar.Location = New System.Drawing.Point(8, 9)
        Me.botnEditar.Margin = New System.Windows.Forms.Padding(2)
        Me.botnEditar.Name = "botnEditar"
        Me.botnEditar.Size = New System.Drawing.Size(26, 25)
        Me.botnEditar.TabIndex = 0
        Me.ToolTip1.SetToolTip(Me.botnEditar, "Enter Tax Data")
        Me.botnEditar.UseVisualStyleBackColor = True
        '
        'panelLetra
        '
        Me.panelLetra.Controls.Add(Me.panelExtemporaneo)
        Me.panelLetra.Controls.Add(Me.Label15)
        Me.panelLetra.Controls.Add(Me.celdaLetra)
        Me.panelLetra.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.panelLetra.Location = New System.Drawing.Point(0, 123)
        Me.panelLetra.Margin = New System.Windows.Forms.Padding(2)
        Me.panelLetra.Name = "panelLetra"
        Me.panelLetra.Size = New System.Drawing.Size(477, 43)
        Me.panelLetra.TabIndex = 2
        '
        'panelExtemporaneo
        '
        Me.panelExtemporaneo.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.panelExtemporaneo.Controls.Add(Me.celdaExtemporaneo)
        Me.panelExtemporaneo.Location = New System.Drawing.Point(238, 15)
        Me.panelExtemporaneo.Margin = New System.Windows.Forms.Padding(2)
        Me.panelExtemporaneo.Name = "panelExtemporaneo"
        Me.panelExtemporaneo.Size = New System.Drawing.Size(206, 25)
        Me.panelExtemporaneo.TabIndex = 17
        '
        'celdaExtemporaneo
        '
        Me.celdaExtemporaneo.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.celdaExtemporaneo.BackColor = System.Drawing.Color.DarkOrange
        Me.celdaExtemporaneo.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.celdaExtemporaneo.Location = New System.Drawing.Point(28, 5)
        Me.celdaExtemporaneo.Margin = New System.Windows.Forms.Padding(2)
        Me.celdaExtemporaneo.Name = "celdaExtemporaneo"
        Me.celdaExtemporaneo.ReadOnly = True
        Me.celdaExtemporaneo.Size = New System.Drawing.Size(140, 21)
        Me.celdaExtemporaneo.TabIndex = 18
        Me.celdaExtemporaneo.Text = "extemporaneous"
        Me.celdaExtemporaneo.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Label15
        '
        Me.Label15.AutoSize = True
        Me.Label15.Location = New System.Drawing.Point(3, 20)
        Me.Label15.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(73, 13)
        Me.Label15.TabIndex = 16
        Me.Label15.Text = "Total In Letter"
        '
        'celdaLetra
        '
        Me.celdaLetra.BackColor = System.Drawing.SystemColors.Info
        Me.celdaLetra.Location = New System.Drawing.Point(76, 15)
        Me.celdaLetra.Margin = New System.Windows.Forms.Padding(2)
        Me.celdaLetra.Multiline = True
        Me.celdaLetra.Name = "celdaLetra"
        Me.celdaLetra.ReadOnly = True
        Me.celdaLetra.Size = New System.Drawing.Size(488, 28)
        Me.celdaLetra.TabIndex = 15
        '
        'panelEncabezadoDocumento
        '
        Me.panelEncabezadoDocumento.Controls.Add(Me.gbDatosDocumento1)
        Me.panelEncabezadoDocumento.Controls.Add(Me.gbDatosDocumento)
        Me.panelEncabezadoDocumento.Dock = System.Windows.Forms.DockStyle.Top
        Me.panelEncabezadoDocumento.Location = New System.Drawing.Point(0, 0)
        Me.panelEncabezadoDocumento.Margin = New System.Windows.Forms.Padding(2)
        Me.panelEncabezadoDocumento.Name = "panelEncabezadoDocumento"
        Me.panelEncabezadoDocumento.Size = New System.Drawing.Size(477, 206)
        Me.panelEncabezadoDocumento.TabIndex = 0
        '
        'gbDatosDocumento1
        '
        Me.gbDatosDocumento1.Controls.Add(Me.etiquetaMontoTotal)
        Me.gbDatosDocumento1.Controls.Add(Me.celdaEmisor)
        Me.gbDatosDocumento1.Controls.Add(Me.Label13)
        Me.gbDatosDocumento1.Controls.Add(Me.celdaNota)
        Me.gbDatosDocumento1.Controls.Add(Me.Label12)
        Me.gbDatosDocumento1.Controls.Add(Me.celdaDiferencia)
        Me.gbDatosDocumento1.Controls.Add(Me.Label11)
        Me.gbDatosDocumento1.Controls.Add(Me.botonReintegro)
        Me.gbDatosDocumento1.Controls.Add(Me.celdaReintegro)
        Me.gbDatosDocumento1.Controls.Add(Me.Label10)
        Me.gbDatosDocumento1.Controls.Add(Me.celdaDetalleMonto)
        Me.gbDatosDocumento1.Controls.Add(Me.Label9)
        Me.gbDatosDocumento1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.gbDatosDocumento1.Location = New System.Drawing.Point(538, 0)
        Me.gbDatosDocumento1.Margin = New System.Windows.Forms.Padding(2)
        Me.gbDatosDocumento1.Name = "gbDatosDocumento1"
        Me.gbDatosDocumento1.Padding = New System.Windows.Forms.Padding(2)
        Me.gbDatosDocumento1.Size = New System.Drawing.Size(0, 206)
        Me.gbDatosDocumento1.TabIndex = 1
        Me.gbDatosDocumento1.TabStop = False
        '
        'etiquetaMontoTotal
        '
        Me.etiquetaMontoTotal.AutoSize = True
        Me.etiquetaMontoTotal.Location = New System.Drawing.Point(288, 16)
        Me.etiquetaMontoTotal.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.etiquetaMontoTotal.Name = "etiquetaMontoTotal"
        Me.etiquetaMontoTotal.Size = New System.Drawing.Size(13, 13)
        Me.etiquetaMontoTotal.TabIndex = 32
        Me.etiquetaMontoTotal.Text = "0"
        Me.etiquetaMontoTotal.Visible = False
        '
        'celdaEmisor
        '
        Me.celdaEmisor.Location = New System.Drawing.Point(90, 179)
        Me.celdaEmisor.Margin = New System.Windows.Forms.Padding(2)
        Me.celdaEmisor.Name = "celdaEmisor"
        Me.celdaEmisor.Size = New System.Drawing.Size(402, 20)
        Me.celdaEmisor.TabIndex = 10
        '
        'Label13
        '
        Me.Label13.AutoSize = True
        Me.Label13.Location = New System.Drawing.Point(88, 162)
        Me.Label13.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(191, 13)
        Me.Label13.TabIndex = 9
        Me.Label13.Text = "Issuer / Beneficiary (Receipt / Deposit)"
        '
        'celdaNota
        '
        Me.celdaNota.Location = New System.Drawing.Point(90, 90)
        Me.celdaNota.Margin = New System.Windows.Forms.Padding(2)
        Me.celdaNota.Multiline = True
        Me.celdaNota.Name = "celdaNota"
        Me.celdaNota.Size = New System.Drawing.Size(402, 67)
        Me.celdaNota.TabIndex = 8
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.Location = New System.Drawing.Point(88, 71)
        Me.Label12.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(121, 13)
        Me.Label12.TabIndex = 7
        Me.Label12.Text = "Notes and Observations"
        '
        'celdaDiferencia
        '
        Me.celdaDiferencia.Location = New System.Drawing.Point(385, 43)
        Me.celdaDiferencia.Margin = New System.Windows.Forms.Padding(2)
        Me.celdaDiferencia.Name = "celdaDiferencia"
        Me.celdaDiferencia.Size = New System.Drawing.Size(108, 20)
        Me.celdaDiferencia.TabIndex = 6
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.Location = New System.Drawing.Point(322, 46)
        Me.Label11.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(56, 13)
        Me.Label11.TabIndex = 5
        Me.Label11.Text = "Difference"
        '
        'botonReintegro
        '
        Me.botonReintegro.Enabled = False
        Me.botonReintegro.Image = Global.KARIMs_SGI.My.Resources.Resources.money
        Me.botonReintegro.Location = New System.Drawing.Point(265, 43)
        Me.botonReintegro.Margin = New System.Windows.Forms.Padding(2)
        Me.botonReintegro.Name = "botonReintegro"
        Me.botonReintegro.Size = New System.Drawing.Size(35, 19)
        Me.botonReintegro.TabIndex = 4
        Me.ToolTip1.SetToolTip(Me.botonReintegro, "calculate Refund")
        Me.botonReintegro.UseVisualStyleBackColor = True
        '
        'celdaReintegro
        '
        Me.celdaReintegro.Location = New System.Drawing.Point(154, 43)
        Me.celdaReintegro.Margin = New System.Windows.Forms.Padding(2)
        Me.celdaReintegro.Name = "celdaReintegro"
        Me.celdaReintegro.Size = New System.Drawing.Size(108, 20)
        Me.celdaReintegro.TabIndex = 3
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Location = New System.Drawing.Point(88, 46)
        Me.Label10.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(42, 13)
        Me.Label10.TabIndex = 2
        Me.Label10.Text = "Refund"
        '
        'celdaDetalleMonto
        '
        Me.celdaDetalleMonto.Location = New System.Drawing.Point(154, 14)
        Me.celdaDetalleMonto.Margin = New System.Windows.Forms.Padding(2)
        Me.celdaDetalleMonto.Name = "celdaDetalleMonto"
        Me.celdaDetalleMonto.Size = New System.Drawing.Size(108, 20)
        Me.celdaDetalleMonto.TabIndex = 1
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Location = New System.Drawing.Point(88, 19)
        Me.Label9.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(43, 13)
        Me.Label9.TabIndex = 0
        Me.Label9.Text = "Amount"
        '
        'gbDatosDocumento
        '
        Me.gbDatosDocumento.Controls.Add(Me.etiquetaCAI)
        Me.gbDatosDocumento.Controls.Add(Me.celdaCAI)
        Me.gbDatosDocumento.Controls.Add(Me.dtpFechaPolizaC)
        Me.gbDatosDocumento.Controls.Add(Me.etiquetaFecha1)
        Me.gbDatosDocumento.Controls.Add(Me.celdaMontoProd)
        Me.gbDatosDocumento.Controls.Add(Me.celdaNumeroCaja)
        Me.gbDatosDocumento.Controls.Add(Me.botonDetalleMoneda)
        Me.gbDatosDocumento.Controls.Add(Me.celdaDetalleAnio)
        Me.gbDatosDocumento.Controls.Add(Me.celdaNumeroHDR)
        Me.gbDatosDocumento.Controls.Add(Me.celdadetalleIDDocumento)
        Me.gbDatosDocumento.Controls.Add(Me.botonDocumentos)
        Me.gbDatosDocumento.Controls.Add(Me.celdaDetalleIDMoneda)
        Me.gbDatosDocumento.Controls.Add(Me.celdaidProveedor)
        Me.gbDatosDocumento.Controls.Add(Me.Button1)
        Me.gbDatosDocumento.Controls.Add(Me.checkActivoFijo)
        Me.gbDatosDocumento.Controls.Add(Me.celdaDetalleTC)
        Me.gbDatosDocumento.Controls.Add(Me.Label8)
        Me.gbDatosDocumento.Controls.Add(Me.celdaDetalleMoneda)
        Me.gbDatosDocumento.Controls.Add(Me.Label7)
        Me.gbDatosDocumento.Controls.Add(Me.celdaDetalleNit)
        Me.gbDatosDocumento.Controls.Add(Me.Label6)
        Me.gbDatosDocumento.Controls.Add(Me.checkContribuyent)
        Me.gbDatosDocumento.Controls.Add(Me.checkFacElectrónica)
        Me.gbDatosDocumento.Controls.Add(Me.botonProveedor)
        Me.gbDatosDocumento.Controls.Add(Me.celdaProveedor)
        Me.gbDatosDocumento.Controls.Add(Me.Label5)
        Me.gbDatosDocumento.Controls.Add(Me.checActivo)
        Me.gbDatosDocumento.Controls.Add(Me.celdaDetalleSerie)
        Me.gbDatosDocumento.Controls.Add(Me.Label4)
        Me.gbDatosDocumento.Controls.Add(Me.celdaDetalleNumero)
        Me.gbDatosDocumento.Controls.Add(Me.Label3)
        Me.gbDatosDocumento.Controls.Add(Me.dtpDetalleFecha)
        Me.gbDatosDocumento.Controls.Add(Me.Label2)
        Me.gbDatosDocumento.Controls.Add(Me.celdaDetalleDocumento)
        Me.gbDatosDocumento.Controls.Add(Me.Label1)
        Me.gbDatosDocumento.Dock = System.Windows.Forms.DockStyle.Left
        Me.gbDatosDocumento.Location = New System.Drawing.Point(0, 0)
        Me.gbDatosDocumento.Margin = New System.Windows.Forms.Padding(2)
        Me.gbDatosDocumento.Name = "gbDatosDocumento"
        Me.gbDatosDocumento.Padding = New System.Windows.Forms.Padding(2)
        Me.gbDatosDocumento.Size = New System.Drawing.Size(538, 206)
        Me.gbDatosDocumento.TabIndex = 0
        Me.gbDatosDocumento.TabStop = False
        Me.gbDatosDocumento.Text = "Document Data"
        '
        'dtpFechaPolizaC
        '
        Me.dtpFechaPolizaC.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.dtpFechaPolizaC.Location = New System.Drawing.Point(317, 41)
        Me.dtpFechaPolizaC.Margin = New System.Windows.Forms.Padding(2)
        Me.dtpFechaPolizaC.Name = "dtpFechaPolizaC"
        Me.dtpFechaPolizaC.Size = New System.Drawing.Size(91, 20)
        Me.dtpFechaPolizaC.TabIndex = 76
        '
        'etiquetaFecha1
        '
        Me.etiquetaFecha1.AutoSize = True
        Me.etiquetaFecha1.BackColor = System.Drawing.SystemColors.ActiveCaption
        Me.etiquetaFecha1.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.etiquetaFecha1.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.etiquetaFecha1.Location = New System.Drawing.Point(214, 43)
        Me.etiquetaFecha1.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.etiquetaFecha1.Name = "etiquetaFecha1"
        Me.etiquetaFecha1.Size = New System.Drawing.Size(100, 13)
        Me.etiquetaFecha1.TabIndex = 75
        Me.etiquetaFecha1.Text = "Accounting date"
        '
        'celdaMontoProd
        '
        Me.celdaMontoProd.Location = New System.Drawing.Point(328, 148)
        Me.celdaMontoProd.Margin = New System.Windows.Forms.Padding(2)
        Me.celdaMontoProd.Name = "celdaMontoProd"
        Me.celdaMontoProd.ReadOnly = True
        Me.celdaMontoProd.Size = New System.Drawing.Size(104, 20)
        Me.celdaMontoProd.TabIndex = 73
        Me.celdaMontoProd.Text = "0"
        Me.celdaMontoProd.Visible = False
        '
        'celdaNumeroCaja
        '
        Me.celdaNumeroCaja.Location = New System.Drawing.Point(488, 88)
        Me.celdaNumeroCaja.Margin = New System.Windows.Forms.Padding(2)
        Me.celdaNumeroCaja.Name = "celdaNumeroCaja"
        Me.celdaNumeroCaja.Size = New System.Drawing.Size(46, 20)
        Me.celdaNumeroCaja.TabIndex = 37
        Me.celdaNumeroCaja.Visible = False
        '
        'botonDetalleMoneda
        '
        Me.botonDetalleMoneda.Location = New System.Drawing.Point(152, 173)
        Me.botonDetalleMoneda.Margin = New System.Windows.Forms.Padding(2)
        Me.botonDetalleMoneda.Name = "botonDetalleMoneda"
        Me.botonDetalleMoneda.Size = New System.Drawing.Size(22, 19)
        Me.botonDetalleMoneda.TabIndex = 36
        Me.botonDetalleMoneda.Text = "..."
        Me.botonDetalleMoneda.UseVisualStyleBackColor = True
        '
        'celdaDetalleAnio
        '
        Me.celdaDetalleAnio.Location = New System.Drawing.Point(488, 19)
        Me.celdaDetalleAnio.Margin = New System.Windows.Forms.Padding(2)
        Me.celdaDetalleAnio.Name = "celdaDetalleAnio"
        Me.celdaDetalleAnio.Size = New System.Drawing.Size(46, 20)
        Me.celdaDetalleAnio.TabIndex = 35
        Me.celdaDetalleAnio.Visible = False
        '
        'celdaNumeroHDR
        '
        Me.celdaNumeroHDR.Location = New System.Drawing.Point(488, 41)
        Me.celdaNumeroHDR.Margin = New System.Windows.Forms.Padding(2)
        Me.celdaNumeroHDR.Name = "celdaNumeroHDR"
        Me.celdaNumeroHDR.Size = New System.Drawing.Size(46, 20)
        Me.celdaNumeroHDR.TabIndex = 34
        Me.celdaNumeroHDR.Visible = False
        '
        'celdadetalleIDDocumento
        '
        Me.celdadetalleIDDocumento.Location = New System.Drawing.Point(488, 65)
        Me.celdadetalleIDDocumento.Margin = New System.Windows.Forms.Padding(2)
        Me.celdadetalleIDDocumento.Name = "celdadetalleIDDocumento"
        Me.celdadetalleIDDocumento.Size = New System.Drawing.Size(46, 20)
        Me.celdadetalleIDDocumento.TabIndex = 33
        Me.celdadetalleIDDocumento.Visible = False
        '
        'botonDocumentos
        '
        Me.botonDocumentos.Location = New System.Drawing.Point(284, 16)
        Me.botonDocumentos.Margin = New System.Windows.Forms.Padding(2)
        Me.botonDocumentos.Name = "botonDocumentos"
        Me.botonDocumentos.Size = New System.Drawing.Size(24, 19)
        Me.botonDocumentos.TabIndex = 32
        Me.botonDocumentos.Text = "..."
        Me.botonDocumentos.UseVisualStyleBackColor = True
        '
        'celdaDetalleIDMoneda
        '
        Me.celdaDetalleIDMoneda.Location = New System.Drawing.Point(348, 174)
        Me.celdaDetalleIDMoneda.Margin = New System.Windows.Forms.Padding(2)
        Me.celdaDetalleIDMoneda.Name = "celdaDetalleIDMoneda"
        Me.celdaDetalleIDMoneda.Size = New System.Drawing.Size(27, 20)
        Me.celdaDetalleIDMoneda.TabIndex = 31
        Me.celdaDetalleIDMoneda.Visible = False
        '
        'celdaidProveedor
        '
        Me.celdaidProveedor.Location = New System.Drawing.Point(429, 115)
        Me.celdaidProveedor.Margin = New System.Windows.Forms.Padding(2)
        Me.celdaidProveedor.Name = "celdaidProveedor"
        Me.celdaidProveedor.Size = New System.Drawing.Size(18, 20)
        Me.celdaidProveedor.TabIndex = 30
        Me.celdaidProveedor.Visible = False
        '
        'Button1
        '
        Me.Button1.Image = Global.KARIMs_SGI.My.Resources.Resources.book_open
        Me.Button1.Location = New System.Drawing.Point(217, 145)
        Me.Button1.Margin = New System.Windows.Forms.Padding(2)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(34, 19)
        Me.Button1.TabIndex = 29
        Me.Button1.UseVisualStyleBackColor = True
        '
        'checkActivoFijo
        '
        Me.checkActivoFijo.AutoSize = True
        Me.checkActivoFijo.CheckAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.checkActivoFijo.Checked = True
        Me.checkActivoFijo.CheckState = System.Windows.Forms.CheckState.Checked
        Me.checkActivoFijo.Location = New System.Drawing.Point(450, 176)
        Me.checkActivoFijo.Margin = New System.Windows.Forms.Padding(2)
        Me.checkActivoFijo.Name = "checkActivoFijo"
        Me.checkActivoFijo.Size = New System.Drawing.Size(79, 17)
        Me.checkActivoFijo.TabIndex = 28
        Me.checkActivoFijo.Text = "Fixed asset"
        Me.checkActivoFijo.UseVisualStyleBackColor = True
        Me.checkActivoFijo.Visible = False
        '
        'celdaDetalleTC
        '
        Me.celdaDetalleTC.Location = New System.Drawing.Point(286, 175)
        Me.celdaDetalleTC.Margin = New System.Windows.Forms.Padding(2)
        Me.celdaDetalleTC.Name = "celdaDetalleTC"
        Me.celdaDetalleTC.Size = New System.Drawing.Size(59, 20)
        Me.celdaDetalleTC.TabIndex = 27
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Location = New System.Drawing.Point(206, 176)
        Me.Label8.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(76, 13)
        Me.Label8.TabIndex = 26
        Me.Label8.Text = "Exchange rate"
        '
        'celdaDetalleMoneda
        '
        Me.celdaDetalleMoneda.Location = New System.Drawing.Point(86, 174)
        Me.celdaDetalleMoneda.Margin = New System.Windows.Forms.Padding(2)
        Me.celdaDetalleMoneda.Name = "celdaDetalleMoneda"
        Me.celdaDetalleMoneda.Size = New System.Drawing.Size(59, 20)
        Me.celdaDetalleMoneda.TabIndex = 25
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(14, 176)
        Me.Label7.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(49, 13)
        Me.Label7.TabIndex = 24
        Me.Label7.Text = "Currency"
        '
        'celdaDetalleNit
        '
        Me.celdaDetalleNit.Location = New System.Drawing.Point(86, 145)
        Me.celdaDetalleNit.Margin = New System.Windows.Forms.Padding(2)
        Me.celdaDetalleNit.Name = "celdaDetalleNit"
        Me.celdaDetalleNit.Size = New System.Drawing.Size(122, 20)
        Me.celdaDetalleNit.TabIndex = 23
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(14, 148)
        Me.Label6.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(25, 13)
        Me.Label6.TabIndex = 22
        Me.Label6.Text = "NIT"
        '
        'checkContribuyent
        '
        Me.checkContribuyent.AutoSize = True
        Me.checkContribuyent.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.checkContribuyent.ForeColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.checkContribuyent.Location = New System.Drawing.Point(86, 117)
        Me.checkContribuyent.Margin = New System.Windows.Forms.Padding(2)
        Me.checkContribuyent.Name = "checkContribuyent"
        Me.checkContribuyent.Size = New System.Drawing.Size(165, 17)
        Me.checkContribuyent.TabIndex = 20
        Me.checkContribuyent.Text = "Small Taxpayer / Import "
        Me.checkContribuyent.UseVisualStyleBackColor = True
        '
        'checkFacElectrónica
        '
        Me.checkFacElectrónica.AutoSize = True
        Me.checkFacElectrónica.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.checkFacElectrónica.ForeColor = System.Drawing.Color.Navy
        Me.checkFacElectrónica.Location = New System.Drawing.Point(265, 117)
        Me.checkFacElectrónica.Margin = New System.Windows.Forms.Padding(2)
        Me.checkFacElectrónica.Name = "checkFacElectrónica"
        Me.checkFacElectrónica.Size = New System.Drawing.Size(104, 17)
        Me.checkFacElectrónica.TabIndex = 21
        Me.checkFacElectrónica.Text = "Electronic Bill"
        Me.checkFacElectrónica.UseVisualStyleBackColor = True
        '
        'botonProveedor
        '
        Me.botonProveedor.Location = New System.Drawing.Point(424, 93)
        Me.botonProveedor.Margin = New System.Windows.Forms.Padding(2)
        Me.botonProveedor.Name = "botonProveedor"
        Me.botonProveedor.Size = New System.Drawing.Size(22, 19)
        Me.botonProveedor.TabIndex = 11
        Me.botonProveedor.Text = "..."
        Me.botonProveedor.UseVisualStyleBackColor = True
        '
        'celdaProveedor
        '
        Me.celdaProveedor.Location = New System.Drawing.Point(86, 93)
        Me.celdaProveedor.Margin = New System.Windows.Forms.Padding(2)
        Me.celdaProveedor.Name = "celdaProveedor"
        Me.celdaProveedor.ReadOnly = True
        Me.celdaProveedor.Size = New System.Drawing.Size(330, 20)
        Me.celdaProveedor.TabIndex = 10
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(14, 96)
        Me.Label5.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(46, 13)
        Me.Label5.TabIndex = 9
        Me.Label5.Text = "Provider"
        '
        'checActivo
        '
        Me.checActivo.AutoSize = True
        Me.checActivo.CheckAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.checActivo.Checked = True
        Me.checActivo.CheckState = System.Windows.Forms.CheckState.Checked
        Me.checActivo.Location = New System.Drawing.Point(407, 21)
        Me.checActivo.Margin = New System.Windows.Forms.Padding(2)
        Me.checActivo.Name = "checActivo"
        Me.checActivo.Size = New System.Drawing.Size(56, 17)
        Me.checActivo.TabIndex = 8
        Me.checActivo.Text = "Active"
        Me.checActivo.UseVisualStyleBackColor = True
        '
        'celdaDetalleSerie
        '
        Me.celdaDetalleSerie.ForeColor = System.Drawing.SystemColors.HotTrack
        Me.celdaDetalleSerie.Location = New System.Drawing.Point(337, 65)
        Me.celdaDetalleSerie.Margin = New System.Windows.Forms.Padding(2)
        Me.celdaDetalleSerie.Name = "celdaDetalleSerie"
        Me.celdaDetalleSerie.Size = New System.Drawing.Size(122, 20)
        Me.celdaDetalleSerie.TabIndex = 7
        Me.celdaDetalleSerie.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(295, 67)
        Me.Label4.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(31, 13)
        Me.Label4.TabIndex = 6
        Me.Label4.Text = "Serie"
        '
        'celdaDetalleNumero
        '
        Me.celdaDetalleNumero.ForeColor = System.Drawing.SystemColors.HotTrack
        Me.celdaDetalleNumero.Location = New System.Drawing.Point(86, 65)
        Me.celdaDetalleNumero.Margin = New System.Windows.Forms.Padding(2)
        Me.celdaDetalleNumero.Name = "celdaDetalleNumero"
        Me.celdaDetalleNumero.Size = New System.Drawing.Size(194, 20)
        Me.celdaDetalleNumero.TabIndex = 5
        Me.celdaDetalleNumero.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(14, 67)
        Me.Label3.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(44, 13)
        Me.Label3.TabIndex = 4
        Me.Label3.Text = "Numero"
        '
        'dtpDetalleFecha
        '
        Me.dtpDetalleFecha.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.dtpDetalleFecha.Location = New System.Drawing.Point(86, 41)
        Me.dtpDetalleFecha.Margin = New System.Windows.Forms.Padding(2)
        Me.dtpDetalleFecha.Name = "dtpDetalleFecha"
        Me.dtpDetalleFecha.Size = New System.Drawing.Size(119, 20)
        Me.dtpDetalleFecha.TabIndex = 3
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(14, 46)
        Me.Label2.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(37, 13)
        Me.Label2.TabIndex = 2
        Me.Label2.Text = "Fecha"
        '
        'celdaDetalleDocumento
        '
        Me.celdaDetalleDocumento.Location = New System.Drawing.Point(86, 17)
        Me.celdaDetalleDocumento.Margin = New System.Windows.Forms.Padding(2)
        Me.celdaDetalleDocumento.Name = "celdaDetalleDocumento"
        Me.celdaDetalleDocumento.ReadOnly = True
        Me.celdaDetalleDocumento.Size = New System.Drawing.Size(194, 20)
        Me.celdaDetalleDocumento.TabIndex = 1
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(14, 21)
        Me.Label1.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(56, 13)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "Document"
        '
        'botonPermisos
        '
        Me.botonPermisos.Image = Global.KARIMs_SGI.My.Resources.Resources.llave
        Me.botonPermisos.Location = New System.Drawing.Point(202, 11)
        Me.botonPermisos.Name = "botonPermisos"
        Me.botonPermisos.Size = New System.Drawing.Size(59, 43)
        Me.botonPermisos.TabIndex = 25
        Me.botonPermisos.Text = "Permits"
        Me.botonPermisos.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.botonPermisos.UseVisualStyleBackColor = True
        '
        'BotonImpreso
        '
        Me.BotonImpreso.Image = CType(resources.GetObject("BotonImpreso.Image"), System.Drawing.Image)
        Me.BotonImpreso.Location = New System.Drawing.Point(268, 11)
        Me.BotonImpreso.Name = "BotonImpreso"
        Me.BotonImpreso.Size = New System.Drawing.Size(59, 43)
        Me.BotonImpreso.TabIndex = 24
        Me.BotonImpreso.Text = "Print"
        Me.BotonImpreso.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.BotonImpreso.UseVisualStyleBackColor = True
        '
        'botonActualizar
        '
        Me.botonActualizar.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.botonActualizar.Image = Global.KARIMs_SGI.My.Resources.Resources.replace2
        Me.botonActualizar.Location = New System.Drawing.Point(608, 11)
        Me.botonActualizar.Name = "botonActualizar"
        Me.botonActualizar.Size = New System.Drawing.Size(59, 43)
        Me.botonActualizar.TabIndex = 26
        Me.botonActualizar.Text = "Refresh"
        Me.botonActualizar.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.botonActualizar.UseVisualStyleBackColor = True
        '
        'BarraTitulo1
        '
        Me.BarraTitulo1.BackColor = System.Drawing.Color.WhiteSmoke
        Me.BarraTitulo1.Dock = System.Windows.Forms.DockStyle.Top
        Me.BarraTitulo1.Location = New System.Drawing.Point(0, 61)
        Me.BarraTitulo1.Margin = New System.Windows.Forms.Padding(4)
        Me.BarraTitulo1.Name = "BarraTitulo1"
        Me.BarraTitulo1.Size = New System.Drawing.Size(836, 27)
        Me.BarraTitulo1.TabIndex = 1
        '
        'Encabezado1
        '
        Me.Encabezado1.Dock = System.Windows.Forms.DockStyle.Top
        Me.Encabezado1.Location = New System.Drawing.Point(0, 0)
        Me.Encabezado1.Margin = New System.Windows.Forms.Padding(4)
        Me.Encabezado1.Name = "Encabezado1"
        Me.Encabezado1.Size = New System.Drawing.Size(836, 61)
        Me.Encabezado1.TabIndex = 0
        '
        'frmCajaChica
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(836, 546)
        Me.Controls.Add(Me.botonActualizar)
        Me.Controls.Add(Me.botonPermisos)
        Me.Controls.Add(Me.BotonImpreso)
        Me.Controls.Add(Me.panelDocumento)
        Me.Controls.Add(Me.panelDetalleCaja)
        Me.Controls.Add(Me.panelLista)
        Me.Controls.Add(Me.BarraTitulo1)
        Me.Controls.Add(Me.Encabezado1)
        Me.Margin = New System.Windows.Forms.Padding(2)
        Me.Name = "frmCajaChica"
        Me.Text = "Caja Chica"
        Me.panelLista.ResumeLayout(False)
        CType(Me.dgLista, System.ComponentModel.ISupportInitialize).EndInit()
        Me.panelPieLista.ResumeLayout(False)
        Me.panelPieLista.PerformLayout()
        Me.panelDetalleCaja.ResumeLayout(False)
        CType(Me.dgDocumentos, System.ComponentModel.ISupportInitialize).EndInit()
        Me.panelPieDetalle.ResumeLayout(False)
        CType(Me.dgOtrosDocumentos, System.ComponentModel.ISupportInitialize).EndInit()
        Me.panelOpciones.ResumeLayout(False)
        Me.panelOpciones.PerformLayout()
        Me.gbBotones.ResumeLayout(False)
        Me.panelFechas.ResumeLayout(False)
        Me.panelFechas.PerformLayout()
        Me.panelEncabezadoDetalle.ResumeLayout(False)
        Me.gbEncabezadoDetalle1.ResumeLayout(False)
        Me.gbEncabezadoDetalle1.PerformLayout()
        Me.gbEncabezadoDetalle.ResumeLayout(False)
        Me.gbEncabezadoDetalle.PerformLayout()
        Me.panelDocumento.ResumeLayout(False)
        Me.panelDocumento.PerformLayout()
        CType(Me.dgDetalleDocumento, System.ComponentModel.ISupportInitialize).EndInit()
        Me.panelBtnDetalle.ResumeLayout(False)
        Me.panelPieDocumento.ResumeLayout(False)
        Me.gbImpuestos.ResumeLayout(False)
        CType(Me.dgImpuestos, System.ComponentModel.ISupportInitialize).EndInit()
        Me.panelBotones.ResumeLayout(False)
        Me.panelLetra.ResumeLayout(False)
        Me.panelLetra.PerformLayout()
        Me.panelExtemporaneo.ResumeLayout(False)
        Me.panelExtemporaneo.PerformLayout()
        Me.panelEncabezadoDocumento.ResumeLayout(False)
        Me.gbDatosDocumento1.ResumeLayout(False)
        Me.gbDatosDocumento1.PerformLayout()
        Me.gbDatosDocumento.ResumeLayout(False)
        Me.gbDatosDocumento.PerformLayout()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents Encabezado1 As encabezado
    Friend WithEvents BarraTitulo1 As BarraTitulo
    Friend WithEvents panelLista As Panel
    Friend WithEvents panelPieLista As Panel
    Friend WithEvents dgLista As DataGridView
    Friend WithEvents etiquetaConDoc As Label
    Friend WithEvents etiquetaCerrada As Label
    Friend WithEvents celdaConDoc As TextBox
    Friend WithEvents celdaCerrada As TextBox
    Friend WithEvents panelDetalleCaja As Panel
    Friend WithEvents dgDocumentos As DataGridView
    Friend WithEvents panelPieDetalle As Panel
    Friend WithEvents dgOtrosDocumentos As DataGridView
    Friend WithEvents colOtroTipo As DataGridViewTextBoxColumn
    Friend WithEvents colOtroAnio As DataGridViewTextBoxColumn
    Friend WithEvents colOtroNumero As DataGridViewTextBoxColumn
    Friend WithEvents colOtroDescripcion As DataGridViewTextBoxColumn
    Friend WithEvents colOtroFecha As DataGridViewTextBoxColumn
    Friend WithEvents colOtroReferencia As DataGridViewTextBoxColumn
    Friend WithEvents colOtroSaldo As DataGridViewTextBoxColumn
    Friend WithEvents colOtroConcepto As DataGridViewTextBoxColumn
    Friend WithEvents panelOpciones As Panel
    Friend WithEvents celdaTotalLiquidar As TextBox
    Friend WithEvents etiquetaTotalLiquidar As Label
    Friend WithEvents gbBotones As GroupBox
    Friend WithEvents botonBorrarLiquidacion As Button
    Friend WithEvents botonLiquidar As Button
    Friend WithEvents botonReportes As Button
    Friend WithEvents botonArqueo As Button
    Friend WithEvents panelFechas As Panel
    Friend WithEvents checkSeleccionar As System.Windows.Forms.CheckBox
    Friend WithEvents celdaDisponible As TextBox
    Friend WithEvents etiquetaDisponible As Label
    Friend WithEvents botonRecargar As Button
    Friend WithEvents dtpFinal As DateTimePicker
    Friend WithEvents dtpIncial As DateTimePicker
    Friend WithEvents etiquetaFechas As Label
    Friend WithEvents botonDocumento As Button
    Friend WithEvents botonNuevoDoc As Button
    Friend WithEvents celdaDocumento As TextBox
    Friend WithEvents panelEncabezadoDetalle As Panel
    Friend WithEvents gbEncabezadoDetalle1 As GroupBox
    Friend WithEvents celdaCuenta As TextBox
    Friend WithEvents celdaDescCuenta As TextBox
    Friend WithEvents botonCuenta As Button
    Friend WithEvents gbEncabezadoDetalle As GroupBox
    Friend WithEvents botonMoneda As Button
    Friend WithEvents celdaDescMoneda As TextBox
    Friend WithEvents celdaMoneda As TextBox
    Friend WithEvents etiquetaMoneda As Label
    Friend WithEvents celdaDescripcion As TextBox
    Friend WithEvents etiquetaDescripcion As Label
    Friend WithEvents celdaResponsable As TextBox
    Friend WithEvents etiquetaResponsable As Label
    Friend WithEvents celdaCodigo As TextBox
    Friend WithEvents etiquetaCodigo As Label
    Friend WithEvents panelDocumento As Panel
    Friend WithEvents panelEncabezadoDocumento As Panel
    Friend WithEvents gbDatosDocumento As GroupBox
    Friend WithEvents checActivo As System.Windows.Forms.CheckBox
    Friend WithEvents celdaDetalleSerie As TextBox
    Friend WithEvents Label4 As Label
    Friend WithEvents celdaDetalleNumero As TextBox
    Friend WithEvents Label3 As Label
    Friend WithEvents dtpDetalleFecha As DateTimePicker
    Friend WithEvents Label2 As Label
    Friend WithEvents celdaDetalleDocumento As TextBox
    Friend WithEvents Label1 As Label
    Friend WithEvents botonProveedor As Button
    Friend WithEvents celdaProveedor As TextBox
    Friend WithEvents Label5 As Label
    Friend WithEvents checkContribuyent As System.Windows.Forms.CheckBox
    Friend WithEvents checkFacElectrónica As System.Windows.Forms.CheckBox
    Friend WithEvents celdaDetalleTC As TextBox
    Friend WithEvents Label8 As Label
    Friend WithEvents celdaDetalleMoneda As TextBox
    Friend WithEvents Label7 As Label
    Friend WithEvents celdaDetalleNit As TextBox
    Friend WithEvents Label6 As Label
    Friend WithEvents gbDatosDocumento1 As GroupBox
    Friend WithEvents checkActivoFijo As System.Windows.Forms.CheckBox
    Friend WithEvents panelPieDocumento As Panel
    Friend WithEvents celdaEmisor As TextBox
    Friend WithEvents Label13 As Label
    Friend WithEvents celdaNota As TextBox
    Friend WithEvents Label12 As Label
    Friend WithEvents celdaDiferencia As TextBox
    Friend WithEvents Label11 As Label
    Friend WithEvents botonReintegro As Button
    Friend WithEvents celdaReintegro As TextBox
    Friend WithEvents Label10 As Label
    Friend WithEvents celdaDetalleMonto As TextBox
    Friend WithEvents Label9 As Label
    Friend WithEvents gbImpuestos As GroupBox
    Friend WithEvents dgImpuestos As DataGridView
    Friend WithEvents panelBotones As Panel
    Friend WithEvents botonEliminar As Button
    Friend WithEvents botonOtrosImp As Button
    Friend WithEvents botnEditar As Button
    Friend WithEvents dgDetalleDocumento As DataGridView
    Friend WithEvents Button1 As Button
    Friend WithEvents checkInactivarCaja As System.Windows.Forms.CheckBox
    Friend WithEvents Label14 As Label
    Friend WithEvents colCodigo As DataGridViewTextBoxColumn
    Friend WithEvents colNumero As DataGridViewTextBoxColumn
    Friend WithEvents colNombre As DataGridViewTextBoxColumn
    Friend WithEvents colMoneda As DataGridViewTextBoxColumn
    Friend WithEvents colDescripcion As DataGridViewTextBoxColumn
    Friend WithEvents colDocumentos As DataGridViewTextBoxColumn
    Friend WithEvents colEstado As DataGridViewTextBoxColumn
    Friend WithEvents celdaidMoneda As TextBox
    Friend WithEvents celdaidDocumento As TextBox
    Friend WithEvents checkTodo As System.Windows.Forms.CheckBox
    Friend WithEvents celdaidProveedor As TextBox
    Friend WithEvents panelLetra As Panel
    Friend WithEvents Label15 As Label
    Friend WithEvents celdaLetra As TextBox
    Friend WithEvents panelExtemporaneo As Panel
    Friend WithEvents celdaExtemporaneo As TextBox
    Friend WithEvents etiquetaMontoTotal As Label
    Friend WithEvents celdaTipoCaja As TextBox
    Friend WithEvents BotonImpreso As Button
    Friend WithEvents celdaDetalleDoc As TextBox
    Friend WithEvents panelBtnDetalle As Panel
    Friend WithEvents botonMenos As Button
    Friend WithEvents botonMas As Button
    Friend WithEvents celdaDetalleIDMoneda As TextBox
    Friend WithEvents botonDocumentos As Button
    Friend WithEvents celdadetalleIDDocumento As TextBox
    Friend WithEvents celdaNumeroHDR As TextBox
    Friend WithEvents celdaDetalleAnio As TextBox
    Friend WithEvents botonDetalleMoneda As Button
    Friend WithEvents ToolTip1 As ToolTip
    Friend WithEvents celdaNumeroCaja As TextBox
    Friend WithEvents botonPermisos As Button
    Friend WithEvents botonActualizar As Button
    Friend WithEvents colLine As DataGridViewTextBoxColumn
    Friend WithEvents colID As DataGridViewTextBoxColumn
    Friend WithEvents colCodigo1 As DataGridViewTextBoxColumn
    Friend WithEvents colTipo As DataGridViewTextBoxColumn
    Friend WithEvents colDescripcion1 As DataGridViewTextBoxColumn
    Friend WithEvents colCantidad1 As DataGridViewTextBoxColumn
    Friend WithEvents colFactor As DataGridViewTextBoxColumn
    Friend WithEvents colBase As DataGridViewTextBoxColumn
    Friend WithEvents colMonto As DataGridViewTextBoxColumn
    Friend WithEvents colTag As DataGridViewTextBoxColumn
    Friend WithEvents colOrigen As DataGridViewTextBoxColumn
    Friend WithEvents celdaRetencion As TextBox
    Friend WithEvents etiquetaRetencion As Label
    Friend WithEvents celdaSubtotal As TextBox
    Friend WithEvents etiquetaSubTotal As Label
    Friend WithEvents celdaMontoProd As TextBox
    Friend WithEvents dtpFechaPolizaC As DateTimePicker
    Friend WithEvents etiquetaFecha1 As Label
    Friend WithEvents celdaCAI As TextBox
    Friend WithEvents etiquetaCAI As Label
    Friend WithEvents colDocTipo As DataGridViewTextBoxColumn
    Friend WithEvents colDocAnio As DataGridViewTextBoxColumn
    Friend WithEvents colDocNumero As DataGridViewTextBoxColumn
    Friend WithEvents colDocFecha As DataGridViewTextBoxColumn
    Friend WithEvents colDocDocumento As DataGridViewTextBoxColumn
    Friend WithEvents colDocReferencia As DataGridViewTextBoxColumn
    Friend WithEvents colDocTransaccion As DataGridViewTextBoxColumn
    Friend WithEvents colDocMoneda As DataGridViewTextBoxColumn
    Friend WithEvents colDocDebito As DataGridViewTextBoxColumn
    Friend WithEvents colDocNombre As DataGridViewTextBoxColumn
    Friend WithEvents colDocSerie As DataGridViewTextBoxColumn
    Friend WithEvents colDocParcial As DataGridViewTextBoxColumn
    Friend WithEvents colDocTasa As DataGridViewTextBoxColumn
    Friend WithEvents colDocConcepto As DataGridViewTextBoxColumn
    Friend WithEvents colDocGasto As DataGridViewTextBoxColumn
    Friend WithEvents colidrubro As DataGridViewTextBoxColumn
    Friend WithEvents colrubro As DataGridViewTextBoxColumn
    Friend WithEvents colidcuenta As DataGridViewTextBoxColumn
    Friend WithEvents colcuenta As DataGridViewTextBoxColumn
    Friend WithEvents colDocLiquidar As DataGridViewTextBoxColumn
    Friend WithEvents colCantidadD As DataGridViewTextBoxColumn
    Friend WithEvents colCodigoD As DataGridViewTextBoxColumn
    Friend WithEvents colAnioD As DataGridViewTextBoxColumn
    Friend WithEvents colNumD As DataGridViewTextBoxColumn
    Friend WithEvents colLineaD As DataGridViewTextBoxColumn
    Friend WithEvents colDescripcionD As DataGridViewTextBoxColumn
    Friend WithEvents colPrecioSinIVA As DataGridViewTextBoxColumn
    Friend WithEvents colPrecioD As DataGridViewTextBoxColumn
    Friend WithEvents colTotalD As DataGridViewTextBoxColumn
    Friend WithEvents colGastoD As DataGridViewTextBoxColumn
    Friend WithEvents colidGastoD As DataGridViewTextBoxColumn
    Friend WithEvents colidCuentaIVA As DataGridViewTextBoxColumn
    Friend WithEvents colCcosto As DataGridViewTextBoxColumn
    Friend WithEvents colidCcosto As DataGridViewTextBoxColumn
    Friend WithEvents idrubro As DataGridViewTextBoxColumn
    Friend WithEvents rubro As DataGridViewTextBoxColumn
    Friend WithEvents idcuenta As DataGridViewTextBoxColumn
    Friend WithEvents cuenta As DataGridViewTextBoxColumn
    Friend WithEvents colClasificacionD As DataGridViewTextBoxColumn
    Friend WithEvents colidClasificacionD As DataGridViewTextBoxColumn
    Friend WithEvents colCtaIVA As DataGridViewTextBoxColumn
    Friend WithEvents colExtra As DataGridViewTextBoxColumn
End Class
