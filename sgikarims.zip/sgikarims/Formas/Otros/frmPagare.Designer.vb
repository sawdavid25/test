﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmPagare
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim DataGridViewCellStyle1 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle2 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Me.Panel2 = New System.Windows.Forms.Panel()
        Me.CeldaTitulo = New System.Windows.Forms.Label()
        Me.ListaPagare = New System.Windows.Forms.DataGridView()
        Me.colID = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colAno = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colFactura = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colDeudor = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colUsuario = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colActivo = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colRecibido = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Pestañas = New System.Windows.Forms.TabControl()
        Me.TabDeudor = New System.Windows.Forms.TabPage()
        Me.GroupBox2 = New System.Windows.Forms.GroupBox()
        Me.CheckNombramiento = New System.Windows.Forms.CheckBox()
        Me.dtpFNombramientoF = New System.Windows.Forms.DateTimePicker()
        Me.dtpFNombramiento = New System.Windows.Forms.DateTimePicker()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.celdaNotario = New System.Windows.Forms.TextBox()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.celdaLibro = New System.Windows.Forms.TextBox()
        Me.celdaDPIRepresentante = New System.Windows.Forms.TextBox()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.celdaFolio = New System.Windows.Forms.TextBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.celdaCliente = New System.Windows.Forms.TextBox()
        Me.celdaRegistro = New System.Windows.Forms.TextBox()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.celdaRepresentante = New System.Windows.Forms.TextBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.TabPage1 = New System.Windows.Forms.TabPage()
        Me.botonSelFacturas = New System.Windows.Forms.Button()
        Me.GroupBox4 = New System.Windows.Forms.GroupBox()
        Me.celdaDepartamentoNotificaciones = New System.Windows.Forms.TextBox()
        Me.celdaMunicipioNotificaciones = New System.Windows.Forms.TextBox()
        Me.Label17 = New System.Windows.Forms.Label()
        Me.Label16 = New System.Windows.Forms.Label()
        Me.celdaNotificaciones = New System.Windows.Forms.TextBox()
        Me.Label15 = New System.Windows.Forms.Label()
        Me.GroupBox3 = New System.Windows.Forms.GroupBox()
        Me.celdaPlazo = New System.Windows.Forms.TextBox()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.dtpVigencia = New System.Windows.Forms.DateTimePicker()
        Me.dtpVencimiento = New System.Windows.Forms.DateTimePicker()
        Me.Label14 = New System.Windows.Forms.Label()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.celdaInteres = New System.Windows.Forms.TextBox()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.celdaFactura = New System.Windows.Forms.TextBox()
        Me.celdaPedido = New System.Windows.Forms.TextBox()
        Me.ListaFacturas = New System.Windows.Forms.DataGridView()
        Me.clmAno = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.clmNumero = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.clmCliente = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.clmFecha = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.clmMoneda = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.clmMOnto = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.pedido = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.TabPage3 = New System.Windows.Forms.TabPage()
        Me.CeldaMunicipioFiador = New System.Windows.Forms.TextBox()
        Me.Label21 = New System.Windows.Forms.Label()
        Me.CeldaDepartamentoFiador = New System.Windows.Forms.TextBox()
        Me.Label20 = New System.Windows.Forms.Label()
        Me.celdaDPIFiador = New System.Windows.Forms.TextBox()
        Me.Label19 = New System.Windows.Forms.Label()
        Me.celdaFiador = New System.Windows.Forms.TextBox()
        Me.Label18 = New System.Windows.Forms.Label()
        Me.TabPage4 = New System.Windows.Forms.TabPage()
        Me.celdaDireccionAcreedor = New System.Windows.Forms.TextBox()
        Me.Label23 = New System.Windows.Forms.Label()
        Me.celdaAcreedor = New System.Windows.Forms.TextBox()
        Me.Label22 = New System.Windows.Forms.Label()
        Me.lblIdMoneda = New System.Windows.Forms.Label()
        Me.CeldaMonto = New System.Windows.Forms.TextBox()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.celdaMoneda = New System.Windows.Forms.TextBox()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.checkActivo = New System.Windows.Forms.CheckBox()
        Me.checkRecibido = New System.Windows.Forms.CheckBox()
        Me.celdaIdPagare = New System.Windows.Forms.TextBox()
        Me.celdaAño = New System.Windows.Forms.TextBox()
        Me.etiquetaIdCliente = New System.Windows.Forms.Label()
        Me.botonBuscarCliente = New System.Windows.Forms.Button()
        Me.etiquetaCliente = New System.Windows.Forms.Label()
        Me.panelPestañas = New System.Windows.Forms.Panel()
        Me.botonExportar = New System.Windows.Forms.Button()
        Me.PanelLista = New System.Windows.Forms.Panel()
        Me.panelFiltro = New System.Windows.Forms.Panel()
        Me.botonCliente = New System.Windows.Forms.Button()
        Me.Label24 = New System.Windows.Forms.Label()
        Me.checkCliente = New System.Windows.Forms.CheckBox()
        Me.checkFecha = New System.Windows.Forms.CheckBox()
        Me.botonFiltar = New System.Windows.Forms.Button()
        Me.celdaClienteFiltro = New System.Windows.Forms.TextBox()
        Me.dtpFechaFin = New System.Windows.Forms.DateTimePicker()
        Me.dtpFechaInicio = New System.Windows.Forms.DateTimePicker()
        Me.Botones1 = New KARIMs_SGI.encabezado()
        Me.Panel2.SuspendLayout()
        CType(Me.ListaPagare, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Pestañas.SuspendLayout()
        Me.TabDeudor.SuspendLayout()
        Me.GroupBox2.SuspendLayout()
        Me.GroupBox1.SuspendLayout()
        Me.TabPage1.SuspendLayout()
        Me.GroupBox4.SuspendLayout()
        Me.GroupBox3.SuspendLayout()
        CType(Me.ListaFacturas, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.TabPage3.SuspendLayout()
        Me.TabPage4.SuspendLayout()
        Me.Panel1.SuspendLayout()
        Me.panelPestañas.SuspendLayout()
        Me.PanelLista.SuspendLayout()
        Me.panelFiltro.SuspendLayout()
        Me.SuspendLayout()
        '
        'Panel2
        '
        Me.Panel2.BackColor = System.Drawing.Color.WhiteSmoke
        Me.Panel2.Controls.Add(Me.CeldaTitulo)
        Me.Panel2.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel2.Location = New System.Drawing.Point(0, 72)
        Me.Panel2.Name = "Panel2"
        Me.Panel2.Size = New System.Drawing.Size(1139, 26)
        Me.Panel2.TabIndex = 7
        '
        'CeldaTitulo
        '
        Me.CeldaTitulo.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.CeldaTitulo.AutoSize = True
        Me.CeldaTitulo.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.CeldaTitulo.Location = New System.Drawing.Point(18, 3)
        Me.CeldaTitulo.Name = "CeldaTitulo"
        Me.CeldaTitulo.Size = New System.Drawing.Size(50, 18)
        Me.CeldaTitulo.TabIndex = 0
        Me.CeldaTitulo.Text = "Titulo"
        '
        'ListaPagare
        '
        Me.ListaPagare.AllowUserToAddRows = False
        Me.ListaPagare.AllowUserToDeleteRows = False
        Me.ListaPagare.AllowUserToOrderColumns = True
        Me.ListaPagare.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells
        Me.ListaPagare.BackgroundColor = System.Drawing.SystemColors.Control
        Me.ListaPagare.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.ListaPagare.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.colID, Me.colAno, Me.colFactura, Me.colDeudor, Me.colUsuario, Me.colActivo, Me.colRecibido})
        Me.ListaPagare.Dock = System.Windows.Forms.DockStyle.Fill
        Me.ListaPagare.Location = New System.Drawing.Point(0, 81)
        Me.ListaPagare.MultiSelect = False
        Me.ListaPagare.Name = "ListaPagare"
        Me.ListaPagare.ReadOnly = True
        Me.ListaPagare.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.ListaPagare.Size = New System.Drawing.Size(408, 115)
        Me.ListaPagare.TabIndex = 8
        '
        'colID
        '
        Me.colID.HeaderText = "ID"
        Me.colID.Name = "colID"
        Me.colID.ReadOnly = True
        Me.colID.Width = 43
        '
        'colAno
        '
        Me.colAno.HeaderText = "Año"
        Me.colAno.Name = "colAno"
        Me.colAno.ReadOnly = True
        Me.colAno.Width = 51
        '
        'colFactura
        '
        Me.colFactura.HeaderText = "Factura"
        Me.colFactura.Name = "colFactura"
        Me.colFactura.ReadOnly = True
        Me.colFactura.Width = 68
        '
        'colDeudor
        '
        Me.colDeudor.HeaderText = "Deudor"
        Me.colDeudor.Name = "colDeudor"
        Me.colDeudor.ReadOnly = True
        Me.colDeudor.Width = 67
        '
        'colUsuario
        '
        Me.colUsuario.HeaderText = "Usuario"
        Me.colUsuario.Name = "colUsuario"
        Me.colUsuario.ReadOnly = True
        Me.colUsuario.Width = 68
        '
        'colActivo
        '
        Me.colActivo.HeaderText = "Activo"
        Me.colActivo.Name = "colActivo"
        Me.colActivo.ReadOnly = True
        Me.colActivo.Width = 62
        '
        'colRecibido
        '
        Me.colRecibido.HeaderText = "Recibido"
        Me.colRecibido.Name = "colRecibido"
        Me.colRecibido.ReadOnly = True
        Me.colRecibido.Width = 74
        '
        'Pestañas
        '
        Me.Pestañas.Controls.Add(Me.TabDeudor)
        Me.Pestañas.Controls.Add(Me.TabPage1)
        Me.Pestañas.Controls.Add(Me.TabPage3)
        Me.Pestañas.Controls.Add(Me.TabPage4)
        Me.Pestañas.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Pestañas.Location = New System.Drawing.Point(0, 75)
        Me.Pestañas.Name = "Pestañas"
        Me.Pestañas.SelectedIndex = 0
        Me.Pestañas.Size = New System.Drawing.Size(639, 379)
        Me.Pestañas.TabIndex = 9
        '
        'TabDeudor
        '
        Me.TabDeudor.AutoScroll = True
        Me.TabDeudor.Controls.Add(Me.GroupBox2)
        Me.TabDeudor.Controls.Add(Me.GroupBox1)
        Me.TabDeudor.Location = New System.Drawing.Point(4, 22)
        Me.TabDeudor.Name = "TabDeudor"
        Me.TabDeudor.Padding = New System.Windows.Forms.Padding(3)
        Me.TabDeudor.Size = New System.Drawing.Size(631, 353)
        Me.TabDeudor.TabIndex = 1
        Me.TabDeudor.Text = "Deudor"
        Me.TabDeudor.UseVisualStyleBackColor = True
        '
        'GroupBox2
        '
        Me.GroupBox2.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.GroupBox2.Controls.Add(Me.CheckNombramiento)
        Me.GroupBox2.Controls.Add(Me.dtpFNombramientoF)
        Me.GroupBox2.Controls.Add(Me.dtpFNombramiento)
        Me.GroupBox2.Controls.Add(Me.Label10)
        Me.GroupBox2.Controls.Add(Me.Label5)
        Me.GroupBox2.Controls.Add(Me.celdaNotario)
        Me.GroupBox2.Controls.Add(Me.Label4)
        Me.GroupBox2.Location = New System.Drawing.Point(17, 242)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Size = New System.Drawing.Size(57, 168)
        Me.GroupBox2.TabIndex = 7
        Me.GroupBox2.TabStop = False
        Me.GroupBox2.Text = "Datos del Nombramiento"
        '
        'CheckNombramiento
        '
        Me.CheckNombramiento.AutoSize = True
        Me.CheckNombramiento.Checked = True
        Me.CheckNombramiento.CheckState = System.Windows.Forms.CheckState.Checked
        Me.CheckNombramiento.Location = New System.Drawing.Point(19, 76)
        Me.CheckNombramiento.Name = "CheckNombramiento"
        Me.CheckNombramiento.Size = New System.Drawing.Size(72, 17)
        Me.CheckNombramiento.TabIndex = 10
        Me.CheckNombramiento.Text = "Indefinido"
        Me.CheckNombramiento.UseVisualStyleBackColor = True
        '
        'dtpFNombramientoF
        '
        Me.dtpFNombramientoF.Enabled = False
        Me.dtpFNombramientoF.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.dtpFNombramientoF.Location = New System.Drawing.Point(206, 121)
        Me.dtpFNombramientoF.Name = "dtpFNombramientoF"
        Me.dtpFNombramientoF.Size = New System.Drawing.Size(127, 20)
        Me.dtpFNombramientoF.TabIndex = 9
        '
        'dtpFNombramiento
        '
        Me.dtpFNombramiento.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.dtpFNombramiento.Location = New System.Drawing.Point(19, 121)
        Me.dtpFNombramiento.Name = "dtpFNombramiento"
        Me.dtpFNombramiento.Size = New System.Drawing.Size(126, 20)
        Me.dtpFNombramiento.TabIndex = 8
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Location = New System.Drawing.Point(203, 105)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(112, 13)
        Me.Label10.TabIndex = 8
        Me.Label10.Text = "Fecha de vencimiento"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(16, 105)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(121, 13)
        Me.Label5.TabIndex = 8
        Me.Label5.Text = "Fecha de nombramiento"
        '
        'celdaNotario
        '
        Me.celdaNotario.Location = New System.Drawing.Point(19, 37)
        Me.celdaNotario.MaxLength = 255
        Me.celdaNotario.Name = "celdaNotario"
        Me.celdaNotario.Size = New System.Drawing.Size(314, 20)
        Me.celdaNotario.TabIndex = 7
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(25, 21)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(41, 13)
        Me.Label4.TabIndex = 6
        Me.Label4.Text = "Notario"
        '
        'GroupBox1
        '
        Me.GroupBox1.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.GroupBox1.Controls.Add(Me.celdaLibro)
        Me.GroupBox1.Controls.Add(Me.celdaDPIRepresentante)
        Me.GroupBox1.Controls.Add(Me.Label8)
        Me.GroupBox1.Controls.Add(Me.Label1)
        Me.GroupBox1.Controls.Add(Me.celdaFolio)
        Me.GroupBox1.Controls.Add(Me.Label3)
        Me.GroupBox1.Controls.Add(Me.Label7)
        Me.GroupBox1.Controls.Add(Me.celdaCliente)
        Me.GroupBox1.Controls.Add(Me.celdaRegistro)
        Me.GroupBox1.Controls.Add(Me.Label6)
        Me.GroupBox1.Controls.Add(Me.celdaRepresentante)
        Me.GroupBox1.Controls.Add(Me.Label2)
        Me.GroupBox1.Location = New System.Drawing.Point(17, 19)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(57, 217)
        Me.GroupBox1.TabIndex = 6
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Datos del Cliente"
        '
        'celdaLibro
        '
        Me.celdaLibro.Location = New System.Drawing.Point(239, 175)
        Me.celdaLibro.MaxLength = 255
        Me.celdaLibro.Name = "celdaLibro"
        Me.celdaLibro.Size = New System.Drawing.Size(94, 20)
        Me.celdaLibro.TabIndex = 6
        '
        'celdaDPIRepresentante
        '
        Me.celdaDPIRepresentante.Location = New System.Drawing.Point(19, 127)
        Me.celdaDPIRepresentante.MaxLength = 255
        Me.celdaDPIRepresentante.Name = "celdaDPIRepresentante"
        Me.celdaDPIRepresentante.Size = New System.Drawing.Size(314, 20)
        Me.celdaDPIRepresentante.TabIndex = 3
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Location = New System.Drawing.Point(243, 159)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(30, 13)
        Me.Label8.TabIndex = 14
        Me.Label8.Text = "Libro"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(25, 26)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(39, 13)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "Cliente"
        '
        'celdaFolio
        '
        Me.celdaFolio.Location = New System.Drawing.Point(132, 175)
        Me.celdaFolio.MaxLength = 255
        Me.celdaFolio.Name = "celdaFolio"
        Me.celdaFolio.Size = New System.Drawing.Size(92, 20)
        Me.celdaFolio.TabIndex = 5
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(25, 111)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(25, 13)
        Me.Label3.TabIndex = 4
        Me.Label3.Text = "DPI"
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(136, 159)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(29, 13)
        Me.Label7.TabIndex = 12
        Me.Label7.Text = "Folio"
        '
        'celdaCliente
        '
        Me.celdaCliente.Location = New System.Drawing.Point(19, 42)
        Me.celdaCliente.MaxLength = 255
        Me.celdaCliente.Name = "celdaCliente"
        Me.celdaCliente.Size = New System.Drawing.Size(314, 20)
        Me.celdaCliente.TabIndex = 1
        '
        'celdaRegistro
        '
        Me.celdaRegistro.Location = New System.Drawing.Point(19, 175)
        Me.celdaRegistro.MaxLength = 255
        Me.celdaRegistro.Name = "celdaRegistro"
        Me.celdaRegistro.Size = New System.Drawing.Size(102, 20)
        Me.celdaRegistro.TabIndex = 4
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(25, 159)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(61, 13)
        Me.Label6.TabIndex = 10
        Me.Label6.Text = "No. registro"
        '
        'celdaRepresentante
        '
        Me.celdaRepresentante.Location = New System.Drawing.Point(19, 87)
        Me.celdaRepresentante.MaxLength = 255
        Me.celdaRepresentante.Name = "celdaRepresentante"
        Me.celdaRepresentante.Size = New System.Drawing.Size(314, 20)
        Me.celdaRepresentante.TabIndex = 2
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(25, 71)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(96, 13)
        Me.Label2.TabIndex = 2
        Me.Label2.Text = "Rpresentente legal"
        '
        'TabPage1
        '
        Me.TabPage1.AutoScroll = True
        Me.TabPage1.Controls.Add(Me.botonSelFacturas)
        Me.TabPage1.Controls.Add(Me.GroupBox4)
        Me.TabPage1.Controls.Add(Me.GroupBox3)
        Me.TabPage1.Controls.Add(Me.ListaFacturas)
        Me.TabPage1.Location = New System.Drawing.Point(4, 22)
        Me.TabPage1.Name = "TabPage1"
        Me.TabPage1.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage1.Size = New System.Drawing.Size(631, 353)
        Me.TabPage1.TabIndex = 0
        Me.TabPage1.Text = "Pagaré"
        Me.TabPage1.UseVisualStyleBackColor = True
        '
        'botonSelFacturas
        '
        Me.botonSelFacturas.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.botonSelFacturas.Location = New System.Drawing.Point(596, 38)
        Me.botonSelFacturas.Name = "botonSelFacturas"
        Me.botonSelFacturas.Size = New System.Drawing.Size(28, 23)
        Me.botonSelFacturas.TabIndex = 3
        Me.botonSelFacturas.Text = "..."
        Me.botonSelFacturas.UseVisualStyleBackColor = True
        '
        'GroupBox4
        '
        Me.GroupBox4.Controls.Add(Me.celdaDepartamentoNotificaciones)
        Me.GroupBox4.Controls.Add(Me.celdaMunicipioNotificaciones)
        Me.GroupBox4.Controls.Add(Me.Label17)
        Me.GroupBox4.Controls.Add(Me.Label16)
        Me.GroupBox4.Controls.Add(Me.celdaNotificaciones)
        Me.GroupBox4.Controls.Add(Me.Label15)
        Me.GroupBox4.Location = New System.Drawing.Point(17, 187)
        Me.GroupBox4.Name = "GroupBox4"
        Me.GroupBox4.Size = New System.Drawing.Size(333, 152)
        Me.GroupBox4.TabIndex = 2
        Me.GroupBox4.TabStop = False
        Me.GroupBox4.Text = "Dirección de notificaciones"
        '
        'celdaDepartamentoNotificaciones
        '
        Me.celdaDepartamentoNotificaciones.Location = New System.Drawing.Point(186, 112)
        Me.celdaDepartamentoNotificaciones.MaxLength = 255
        Me.celdaDepartamentoNotificaciones.Name = "celdaDepartamentoNotificaciones"
        Me.celdaDepartamentoNotificaciones.Size = New System.Drawing.Size(123, 20)
        Me.celdaDepartamentoNotificaciones.TabIndex = 18
        '
        'celdaMunicipioNotificaciones
        '
        Me.celdaMunicipioNotificaciones.Location = New System.Drawing.Point(26, 112)
        Me.celdaMunicipioNotificaciones.MaxLength = 255
        Me.celdaMunicipioNotificaciones.Name = "celdaMunicipioNotificaciones"
        Me.celdaMunicipioNotificaciones.Size = New System.Drawing.Size(123, 20)
        Me.celdaMunicipioNotificaciones.TabIndex = 17
        '
        'Label17
        '
        Me.Label17.AutoSize = True
        Me.Label17.Location = New System.Drawing.Point(192, 96)
        Me.Label17.Name = "Label17"
        Me.Label17.Size = New System.Drawing.Size(74, 13)
        Me.Label17.TabIndex = 2
        Me.Label17.Text = "Departamento"
        '
        'Label16
        '
        Me.Label16.AutoSize = True
        Me.Label16.Location = New System.Drawing.Point(32, 96)
        Me.Label16.Name = "Label16"
        Me.Label16.Size = New System.Drawing.Size(52, 13)
        Me.Label16.TabIndex = 2
        Me.Label16.Text = "Municipio"
        '
        'celdaNotificaciones
        '
        Me.celdaNotificaciones.Location = New System.Drawing.Point(26, 38)
        Me.celdaNotificaciones.MaxLength = 255
        Me.celdaNotificaciones.Multiline = True
        Me.celdaNotificaciones.Name = "celdaNotificaciones"
        Me.celdaNotificaciones.Size = New System.Drawing.Size(283, 51)
        Me.celdaNotificaciones.TabIndex = 16
        '
        'Label15
        '
        Me.Label15.AutoSize = True
        Me.Label15.Location = New System.Drawing.Point(32, 20)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(52, 13)
        Me.Label15.TabIndex = 0
        Me.Label15.Text = "Dirección"
        '
        'GroupBox3
        '
        Me.GroupBox3.Controls.Add(Me.celdaPlazo)
        Me.GroupBox3.Controls.Add(Me.Label9)
        Me.GroupBox3.Controls.Add(Me.dtpVigencia)
        Me.GroupBox3.Controls.Add(Me.dtpVencimiento)
        Me.GroupBox3.Controls.Add(Me.Label14)
        Me.GroupBox3.Controls.Add(Me.Label13)
        Me.GroupBox3.Controls.Add(Me.celdaInteres)
        Me.GroupBox3.Controls.Add(Me.Label12)
        Me.GroupBox3.Controls.Add(Me.celdaFactura)
        Me.GroupBox3.Controls.Add(Me.celdaPedido)
        Me.GroupBox3.Location = New System.Drawing.Point(17, 19)
        Me.GroupBox3.Name = "GroupBox3"
        Me.GroupBox3.Size = New System.Drawing.Size(333, 162)
        Me.GroupBox3.TabIndex = 1
        Me.GroupBox3.TabStop = False
        Me.GroupBox3.Text = "Datos del Pagaré"
        '
        'celdaPlazo
        '
        Me.celdaPlazo.Location = New System.Drawing.Point(195, 55)
        Me.celdaPlazo.Name = "celdaPlazo"
        Me.celdaPlazo.Size = New System.Drawing.Size(95, 20)
        Me.celdaPlazo.TabIndex = 17
        Me.celdaPlazo.Text = "0"
        Me.celdaPlazo.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Location = New System.Drawing.Point(192, 39)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(71, 13)
        Me.Label9.TabIndex = 16
        Me.Label9.Text = "Dias de plazo"
        '
        'dtpVigencia
        '
        Me.dtpVigencia.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.dtpVigencia.Location = New System.Drawing.Point(26, 108)
        Me.dtpVigencia.Name = "dtpVigencia"
        Me.dtpVigencia.Size = New System.Drawing.Size(95, 20)
        Me.dtpVigencia.TabIndex = 14
        Me.dtpVigencia.Value = New Date(2000, 1, 1, 8, 1, 0, 0)
        '
        'dtpVencimiento
        '
        Me.dtpVencimiento.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.dtpVencimiento.Location = New System.Drawing.Point(195, 108)
        Me.dtpVencimiento.Name = "dtpVencimiento"
        Me.dtpVencimiento.Size = New System.Drawing.Size(95, 20)
        Me.dtpVencimiento.TabIndex = 15
        '
        'Label14
        '
        Me.Label14.AutoSize = True
        Me.Label14.Location = New System.Drawing.Point(190, 92)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(113, 13)
        Me.Label14.TabIndex = 7
        Me.Label14.Text = "Fecha de Vencimiento"
        '
        'Label13
        '
        Me.Label13.AutoSize = True
        Me.Label13.Location = New System.Drawing.Point(23, 92)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(96, 13)
        Me.Label13.TabIndex = 7
        Me.Label13.Text = "Fecha de Vigencia"
        '
        'celdaInteres
        '
        Me.celdaInteres.Location = New System.Drawing.Point(26, 55)
        Me.celdaInteres.Name = "celdaInteres"
        Me.celdaInteres.Size = New System.Drawing.Size(95, 20)
        Me.celdaInteres.TabIndex = 13
        Me.celdaInteres.Text = "18"
        Me.celdaInteres.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.Location = New System.Drawing.Point(23, 39)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(124, 13)
        Me.Label12.TabIndex = 5
        Me.Label12.Text = "Porcentaje de interés (%)"
        '
        'celdaFactura
        '
        Me.celdaFactura.Location = New System.Drawing.Point(268, 19)
        Me.celdaFactura.MaxLength = 255
        Me.celdaFactura.Name = "celdaFactura"
        Me.celdaFactura.Size = New System.Drawing.Size(27, 20)
        Me.celdaFactura.TabIndex = 9
        Me.celdaFactura.Text = "0"
        Me.celdaFactura.Visible = False
        '
        'celdaPedido
        '
        Me.celdaPedido.Location = New System.Drawing.Point(297, 19)
        Me.celdaPedido.MaxLength = 255
        Me.celdaPedido.Name = "celdaPedido"
        Me.celdaPedido.Size = New System.Drawing.Size(27, 20)
        Me.celdaPedido.TabIndex = 10
        Me.celdaPedido.Text = "0"
        Me.celdaPedido.Visible = False
        '
        'ListaFacturas
        '
        Me.ListaFacturas.AllowUserToAddRows = False
        Me.ListaFacturas.AllowUserToOrderColumns = True
        Me.ListaFacturas.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.ListaFacturas.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells
        Me.ListaFacturas.BackgroundColor = System.Drawing.SystemColors.Control
        Me.ListaFacturas.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.ListaFacturas.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.clmAno, Me.clmNumero, Me.clmCliente, Me.clmFecha, Me.clmMoneda, Me.clmMOnto, Me.pedido})
        Me.ListaFacturas.Location = New System.Drawing.Point(356, 19)
        Me.ListaFacturas.MultiSelect = False
        Me.ListaFacturas.Name = "ListaFacturas"
        Me.ListaFacturas.ReadOnly = True
        Me.ListaFacturas.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.ListaFacturas.Size = New System.Drawing.Size(228, 320)
        Me.ListaFacturas.TabIndex = 0
        '
        'clmAno
        '
        Me.clmAno.HeaderText = "Año"
        Me.clmAno.Name = "clmAno"
        Me.clmAno.ReadOnly = True
        Me.clmAno.Width = 51
        '
        'clmNumero
        '
        Me.clmNumero.HeaderText = "Factura"
        Me.clmNumero.Name = "clmNumero"
        Me.clmNumero.ReadOnly = True
        Me.clmNumero.Width = 68
        '
        'clmCliente
        '
        Me.clmCliente.HeaderText = "Cliente"
        Me.clmCliente.Name = "clmCliente"
        Me.clmCliente.ReadOnly = True
        Me.clmCliente.Width = 64
        '
        'clmFecha
        '
        Me.clmFecha.HeaderText = "Fecha"
        Me.clmFecha.Name = "clmFecha"
        Me.clmFecha.ReadOnly = True
        Me.clmFecha.Width = 62
        '
        'clmMoneda
        '
        DataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight
        Me.clmMoneda.DefaultCellStyle = DataGridViewCellStyle1
        Me.clmMoneda.HeaderText = "Moneda"
        Me.clmMoneda.Name = "clmMoneda"
        Me.clmMoneda.ReadOnly = True
        Me.clmMoneda.Width = 71
        '
        'clmMOnto
        '
        DataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight
        Me.clmMOnto.DefaultCellStyle = DataGridViewCellStyle2
        Me.clmMOnto.HeaderText = "Monto"
        Me.clmMOnto.Name = "clmMOnto"
        Me.clmMOnto.ReadOnly = True
        Me.clmMOnto.Width = 62
        '
        'pedido
        '
        Me.pedido.HeaderText = "Pedido"
        Me.pedido.Name = "pedido"
        Me.pedido.ReadOnly = True
        Me.pedido.Width = 65
        '
        'TabPage3
        '
        Me.TabPage3.AutoScroll = True
        Me.TabPage3.Controls.Add(Me.CeldaMunicipioFiador)
        Me.TabPage3.Controls.Add(Me.Label21)
        Me.TabPage3.Controls.Add(Me.CeldaDepartamentoFiador)
        Me.TabPage3.Controls.Add(Me.Label20)
        Me.TabPage3.Controls.Add(Me.celdaDPIFiador)
        Me.TabPage3.Controls.Add(Me.Label19)
        Me.TabPage3.Controls.Add(Me.celdaFiador)
        Me.TabPage3.Controls.Add(Me.Label18)
        Me.TabPage3.Location = New System.Drawing.Point(4, 22)
        Me.TabPage3.Name = "TabPage3"
        Me.TabPage3.Size = New System.Drawing.Size(631, 353)
        Me.TabPage3.TabIndex = 2
        Me.TabPage3.Text = "Fiador"
        Me.TabPage3.UseVisualStyleBackColor = True
        '
        'CeldaMunicipioFiador
        '
        Me.CeldaMunicipioFiador.Location = New System.Drawing.Point(27, 133)
        Me.CeldaMunicipioFiador.MaxLength = 255
        Me.CeldaMunicipioFiador.Name = "CeldaMunicipioFiador"
        Me.CeldaMunicipioFiador.Size = New System.Drawing.Size(295, 20)
        Me.CeldaMunicipioFiador.TabIndex = 22
        '
        'Label21
        '
        Me.Label21.AutoSize = True
        Me.Label21.Location = New System.Drawing.Point(37, 117)
        Me.Label21.Name = "Label21"
        Me.Label21.Size = New System.Drawing.Size(122, 13)
        Me.Label21.TabIndex = 0
        Me.Label21.Text = "Extendida en (municipio)"
        '
        'CeldaDepartamentoFiador
        '
        Me.CeldaDepartamentoFiador.Location = New System.Drawing.Point(27, 181)
        Me.CeldaDepartamentoFiador.MaxLength = 255
        Me.CeldaDepartamentoFiador.Name = "CeldaDepartamentoFiador"
        Me.CeldaDepartamentoFiador.Size = New System.Drawing.Size(295, 20)
        Me.CeldaDepartamentoFiador.TabIndex = 23
        '
        'Label20
        '
        Me.Label20.AutoSize = True
        Me.Label20.Location = New System.Drawing.Point(37, 165)
        Me.Label20.Name = "Label20"
        Me.Label20.Size = New System.Drawing.Size(143, 13)
        Me.Label20.TabIndex = 0
        Me.Label20.Text = "Extendida en (departamento)"
        '
        'celdaDPIFiador
        '
        Me.celdaDPIFiador.Location = New System.Drawing.Point(27, 91)
        Me.celdaDPIFiador.MaxLength = 255
        Me.celdaDPIFiador.Name = "celdaDPIFiador"
        Me.celdaDPIFiador.Size = New System.Drawing.Size(295, 20)
        Me.celdaDPIFiador.TabIndex = 21
        '
        'Label19
        '
        Me.Label19.AutoSize = True
        Me.Label19.Location = New System.Drawing.Point(37, 75)
        Me.Label19.Name = "Label19"
        Me.Label19.Size = New System.Drawing.Size(25, 13)
        Me.Label19.TabIndex = 0
        Me.Label19.Text = "DPI"
        '
        'celdaFiador
        '
        Me.celdaFiador.Location = New System.Drawing.Point(27, 50)
        Me.celdaFiador.MaxLength = 255
        Me.celdaFiador.Name = "celdaFiador"
        Me.celdaFiador.Size = New System.Drawing.Size(295, 20)
        Me.celdaFiador.TabIndex = 20
        '
        'Label18
        '
        Me.Label18.AutoSize = True
        Me.Label18.Location = New System.Drawing.Point(37, 34)
        Me.Label18.Name = "Label18"
        Me.Label18.Size = New System.Drawing.Size(44, 13)
        Me.Label18.TabIndex = 0
        Me.Label18.Text = "Nombre"
        '
        'TabPage4
        '
        Me.TabPage4.AutoScroll = True
        Me.TabPage4.Controls.Add(Me.celdaDireccionAcreedor)
        Me.TabPage4.Controls.Add(Me.Label23)
        Me.TabPage4.Controls.Add(Me.celdaAcreedor)
        Me.TabPage4.Controls.Add(Me.Label22)
        Me.TabPage4.Location = New System.Drawing.Point(4, 22)
        Me.TabPage4.Name = "TabPage4"
        Me.TabPage4.Size = New System.Drawing.Size(631, 353)
        Me.TabPage4.TabIndex = 3
        Me.TabPage4.Text = "Acreedor"
        Me.TabPage4.UseVisualStyleBackColor = True
        '
        'celdaDireccionAcreedor
        '
        Me.celdaDireccionAcreedor.Location = New System.Drawing.Point(26, 103)
        Me.celdaDireccionAcreedor.MaxLength = 255
        Me.celdaDireccionAcreedor.Name = "celdaDireccionAcreedor"
        Me.celdaDireccionAcreedor.ReadOnly = True
        Me.celdaDireccionAcreedor.Size = New System.Drawing.Size(471, 20)
        Me.celdaDireccionAcreedor.TabIndex = 25
        '
        'Label23
        '
        Me.Label23.AutoSize = True
        Me.Label23.Location = New System.Drawing.Point(33, 87)
        Me.Label23.Name = "Label23"
        Me.Label23.Size = New System.Drawing.Size(152, 13)
        Me.Label23.TabIndex = 2
        Me.Label23.Text = "Dirección de oficinas centrales"
        '
        'celdaAcreedor
        '
        Me.celdaAcreedor.Location = New System.Drawing.Point(26, 52)
        Me.celdaAcreedor.MaxLength = 255
        Me.celdaAcreedor.Name = "celdaAcreedor"
        Me.celdaAcreedor.ReadOnly = True
        Me.celdaAcreedor.Size = New System.Drawing.Size(471, 20)
        Me.celdaAcreedor.TabIndex = 24
        '
        'Label22
        '
        Me.Label22.AutoSize = True
        Me.Label22.Location = New System.Drawing.Point(33, 36)
        Me.Label22.Name = "Label22"
        Me.Label22.Size = New System.Drawing.Size(44, 13)
        Me.Label22.TabIndex = 0
        Me.Label22.Text = "Nombre"
        '
        'lblIdMoneda
        '
        Me.lblIdMoneda.AutoSize = True
        Me.lblIdMoneda.Location = New System.Drawing.Point(395, 22)
        Me.lblIdMoneda.Name = "lblIdMoneda"
        Me.lblIdMoneda.Size = New System.Drawing.Size(13, 13)
        Me.lblIdMoneda.TabIndex = 16
        Me.lblIdMoneda.Text = "0"
        Me.lblIdMoneda.Visible = False
        '
        'CeldaMonto
        '
        Me.CeldaMonto.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.CeldaMonto.BackColor = System.Drawing.SystemColors.Info
        Me.CeldaMonto.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.CeldaMonto.Location = New System.Drawing.Point(387, 40)
        Me.CeldaMonto.Name = "CeldaMonto"
        Me.CeldaMonto.ReadOnly = True
        Me.CeldaMonto.Size = New System.Drawing.Size(112, 26)
        Me.CeldaMonto.TabIndex = 12
        '
        'Label11
        '
        Me.Label11.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label11.AutoSize = True
        Me.Label11.Location = New System.Drawing.Point(348, 23)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(37, 13)
        Me.Label11.TabIndex = 3
        Me.Label11.Text = "Monto"
        '
        'celdaMoneda
        '
        Me.celdaMoneda.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.celdaMoneda.BackColor = System.Drawing.SystemColors.Info
        Me.celdaMoneda.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.celdaMoneda.Location = New System.Drawing.Point(345, 40)
        Me.celdaMoneda.Name = "celdaMoneda"
        Me.celdaMoneda.ReadOnly = True
        Me.celdaMoneda.Size = New System.Drawing.Size(43, 26)
        Me.celdaMoneda.TabIndex = 11
        Me.celdaMoneda.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'Panel1
        '
        Me.Panel1.Controls.Add(Me.checkActivo)
        Me.Panel1.Controls.Add(Me.checkRecibido)
        Me.Panel1.Controls.Add(Me.lblIdMoneda)
        Me.Panel1.Controls.Add(Me.celdaIdPagare)
        Me.Panel1.Controls.Add(Me.celdaAño)
        Me.Panel1.Controls.Add(Me.etiquetaIdCliente)
        Me.Panel1.Controls.Add(Me.botonBuscarCliente)
        Me.Panel1.Controls.Add(Me.etiquetaCliente)
        Me.Panel1.Controls.Add(Me.celdaMoneda)
        Me.Panel1.Controls.Add(Me.Label11)
        Me.Panel1.Controls.Add(Me.CeldaMonto)
        Me.Panel1.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel1.Location = New System.Drawing.Point(0, 0)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(639, 75)
        Me.Panel1.TabIndex = 10
        '
        'checkActivo
        '
        Me.checkActivo.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.checkActivo.AutoSize = True
        Me.checkActivo.Location = New System.Drawing.Point(561, 18)
        Me.checkActivo.Name = "checkActivo"
        Me.checkActivo.Size = New System.Drawing.Size(56, 17)
        Me.checkActivo.TabIndex = 18
        Me.checkActivo.Text = "Activo"
        Me.checkActivo.UseVisualStyleBackColor = True
        '
        'checkRecibido
        '
        Me.checkRecibido.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.checkRecibido.AutoSize = True
        Me.checkRecibido.Location = New System.Drawing.Point(561, 41)
        Me.checkRecibido.Name = "checkRecibido"
        Me.checkRecibido.Size = New System.Drawing.Size(68, 17)
        Me.checkRecibido.TabIndex = 17
        Me.checkRecibido.Text = "Recibido"
        Me.checkRecibido.UseVisualStyleBackColor = True
        '
        'celdaIdPagare
        '
        Me.celdaIdPagare.BackColor = System.Drawing.SystemColors.InactiveBorder
        Me.celdaIdPagare.Location = New System.Drawing.Point(73, 27)
        Me.celdaIdPagare.Name = "celdaIdPagare"
        Me.celdaIdPagare.ReadOnly = True
        Me.celdaIdPagare.Size = New System.Drawing.Size(50, 20)
        Me.celdaIdPagare.TabIndex = 3
        Me.celdaIdPagare.Text = "-1"
        Me.celdaIdPagare.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'celdaAño
        '
        Me.celdaAño.BackColor = System.Drawing.SystemColors.InactiveBorder
        Me.celdaAño.Location = New System.Drawing.Point(19, 27)
        Me.celdaAño.Name = "celdaAño"
        Me.celdaAño.ReadOnly = True
        Me.celdaAño.Size = New System.Drawing.Size(52, 20)
        Me.celdaAño.TabIndex = 3
        Me.celdaAño.Text = "-1"
        Me.celdaAño.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'etiquetaIdCliente
        '
        Me.etiquetaIdCliente.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.etiquetaIdCliente.AutoSize = True
        Me.etiquetaIdCliente.Location = New System.Drawing.Point(414, 22)
        Me.etiquetaIdCliente.Name = "etiquetaIdCliente"
        Me.etiquetaIdCliente.Size = New System.Drawing.Size(13, 13)
        Me.etiquetaIdCliente.TabIndex = 2
        Me.etiquetaIdCliente.Text = "0"
        Me.etiquetaIdCliente.Visible = False
        '
        'botonBuscarCliente
        '
        Me.botonBuscarCliente.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.botonBuscarCliente.Location = New System.Drawing.Point(510, 40)
        Me.botonBuscarCliente.Name = "botonBuscarCliente"
        Me.botonBuscarCliente.Size = New System.Drawing.Size(27, 23)
        Me.botonBuscarCliente.TabIndex = 1
        Me.botonBuscarCliente.Text = "..."
        Me.botonBuscarCliente.UseVisualStyleBackColor = True
        '
        'etiquetaCliente
        '
        Me.etiquetaCliente.AutoSize = True
        Me.etiquetaCliente.Location = New System.Drawing.Point(16, 50)
        Me.etiquetaCliente.Name = "etiquetaCliente"
        Me.etiquetaCliente.Size = New System.Drawing.Size(126, 13)
        Me.etiquetaCliente.TabIndex = 0
        Me.etiquetaCliente.Text = "NOMBRE DEL CLIENTE"
        '
        'panelPestañas
        '
        Me.panelPestañas.AutoScroll = True
        Me.panelPestañas.Controls.Add(Me.Pestañas)
        Me.panelPestañas.Controls.Add(Me.Panel1)
        Me.panelPestañas.Location = New System.Drawing.Point(12, 122)
        Me.panelPestañas.Name = "panelPestañas"
        Me.panelPestañas.Size = New System.Drawing.Size(639, 454)
        Me.panelPestañas.TabIndex = 11
        '
        'botonExportar
        '
        Me.botonExportar.Image = Global.KARIMs_SGI.My.Resources.Resources.word1
        Me.botonExportar.Location = New System.Drawing.Point(201, 9)
        Me.botonExportar.Name = "botonExportar"
        Me.botonExportar.Size = New System.Drawing.Size(56, 45)
        Me.botonExportar.TabIndex = 12
        Me.botonExportar.Text = "&Export"
        Me.botonExportar.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.botonExportar.UseVisualStyleBackColor = True
        '
        'PanelLista
        '
        Me.PanelLista.Controls.Add(Me.ListaPagare)
        Me.PanelLista.Controls.Add(Me.panelFiltro)
        Me.PanelLista.Location = New System.Drawing.Point(676, 144)
        Me.PanelLista.Name = "PanelLista"
        Me.PanelLista.Size = New System.Drawing.Size(408, 196)
        Me.PanelLista.TabIndex = 13
        '
        'panelFiltro
        '
        Me.panelFiltro.Controls.Add(Me.botonCliente)
        Me.panelFiltro.Controls.Add(Me.Label24)
        Me.panelFiltro.Controls.Add(Me.checkCliente)
        Me.panelFiltro.Controls.Add(Me.checkFecha)
        Me.panelFiltro.Controls.Add(Me.botonFiltar)
        Me.panelFiltro.Controls.Add(Me.celdaClienteFiltro)
        Me.panelFiltro.Controls.Add(Me.dtpFechaFin)
        Me.panelFiltro.Controls.Add(Me.dtpFechaInicio)
        Me.panelFiltro.Dock = System.Windows.Forms.DockStyle.Top
        Me.panelFiltro.Location = New System.Drawing.Point(0, 0)
        Me.panelFiltro.Name = "panelFiltro"
        Me.panelFiltro.Size = New System.Drawing.Size(408, 81)
        Me.panelFiltro.TabIndex = 0
        '
        'botonCliente
        '
        Me.botonCliente.Enabled = False
        Me.botonCliente.Location = New System.Drawing.Point(368, 48)
        Me.botonCliente.Name = "botonCliente"
        Me.botonCliente.Size = New System.Drawing.Size(28, 23)
        Me.botonCliente.TabIndex = 7
        Me.botonCliente.Text = "..."
        Me.botonCliente.UseVisualStyleBackColor = True
        '
        'Label24
        '
        Me.Label24.AutoSize = True
        Me.Label24.Location = New System.Drawing.Point(17, 7)
        Me.Label24.Name = "Label24"
        Me.Label24.Size = New System.Drawing.Size(53, 13)
        Me.Label24.TabIndex = 6
        Me.Label24.Text = "Filtrar por:"
        '
        'checkCliente
        '
        Me.checkCliente.AutoSize = True
        Me.checkCliente.Location = New System.Drawing.Point(18, 51)
        Me.checkCliente.Name = "checkCliente"
        Me.checkCliente.Size = New System.Drawing.Size(58, 17)
        Me.checkCliente.TabIndex = 3
        Me.checkCliente.Text = "Cliente"
        Me.checkCliente.UseVisualStyleBackColor = True
        '
        'checkFecha
        '
        Me.checkFecha.AutoSize = True
        Me.checkFecha.Checked = True
        Me.checkFecha.CheckState = System.Windows.Forms.CheckState.Checked
        Me.checkFecha.Location = New System.Drawing.Point(18, 25)
        Me.checkFecha.Name = "checkFecha"
        Me.checkFecha.Size = New System.Drawing.Size(111, 17)
        Me.checkFecha.TabIndex = 0
        Me.checkFecha.Text = "Rango de Fechas"
        Me.checkFecha.UseVisualStyleBackColor = True
        '
        'botonFiltar
        '
        Me.botonFiltar.Location = New System.Drawing.Point(314, 25)
        Me.botonFiltar.Name = "botonFiltar"
        Me.botonFiltar.Size = New System.Drawing.Size(71, 20)
        Me.botonFiltar.TabIndex = 5
        Me.botonFiltar.Text = "&Filtar"
        Me.botonFiltar.UseVisualStyleBackColor = True
        '
        'celdaClienteFiltro
        '
        Me.celdaClienteFiltro.Location = New System.Drawing.Point(135, 48)
        Me.celdaClienteFiltro.Name = "celdaClienteFiltro"
        Me.celdaClienteFiltro.ReadOnly = True
        Me.celdaClienteFiltro.Size = New System.Drawing.Size(227, 20)
        Me.celdaClienteFiltro.TabIndex = 4
        '
        'dtpFechaFin
        '
        Me.dtpFechaFin.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.dtpFechaFin.Location = New System.Drawing.Point(221, 25)
        Me.dtpFechaFin.Name = "dtpFechaFin"
        Me.dtpFechaFin.Size = New System.Drawing.Size(87, 20)
        Me.dtpFechaFin.TabIndex = 2
        '
        'dtpFechaInicio
        '
        Me.dtpFechaInicio.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.dtpFechaInicio.Location = New System.Drawing.Point(135, 25)
        Me.dtpFechaInicio.Name = "dtpFechaInicio"
        Me.dtpFechaInicio.Size = New System.Drawing.Size(80, 20)
        Me.dtpFechaInicio.TabIndex = 1
        '
        'Botones1
        '
        Me.Botones1.Dock = System.Windows.Forms.DockStyle.Top
        Me.Botones1.Location = New System.Drawing.Point(0, 0)
        Me.Botones1.Name = "Botones1"
        Me.Botones1.Size = New System.Drawing.Size(1139, 72)
        Me.Botones1.TabIndex = 0
        '
        'frmPagare
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1139, 586)
        Me.Controls.Add(Me.PanelLista)
        Me.Controls.Add(Me.botonExportar)
        Me.Controls.Add(Me.panelPestañas)
        Me.Controls.Add(Me.Panel2)
        Me.Controls.Add(Me.Botones1)
        Me.Name = "frmPagare"
        Me.Text = "Pagaré"
        Me.WindowState = System.Windows.Forms.FormWindowState.Maximized
        Me.Panel2.ResumeLayout(False)
        Me.Panel2.PerformLayout()
        CType(Me.ListaPagare, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Pestañas.ResumeLayout(False)
        Me.TabDeudor.ResumeLayout(False)
        Me.GroupBox2.ResumeLayout(False)
        Me.GroupBox2.PerformLayout()
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.TabPage1.ResumeLayout(False)
        Me.GroupBox4.ResumeLayout(False)
        Me.GroupBox4.PerformLayout()
        Me.GroupBox3.ResumeLayout(False)
        Me.GroupBox3.PerformLayout()
        CType(Me.ListaFacturas, System.ComponentModel.ISupportInitialize).EndInit()
        Me.TabPage3.ResumeLayout(False)
        Me.TabPage3.PerformLayout()
        Me.TabPage4.ResumeLayout(False)
        Me.TabPage4.PerformLayout()
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        Me.panelPestañas.ResumeLayout(False)
        Me.PanelLista.ResumeLayout(False)
        Me.panelFiltro.ResumeLayout(False)
        Me.panelFiltro.PerformLayout()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents Botones1 As KARIMs_SGI.encabezado
    Friend WithEvents Panel2 As System.Windows.Forms.Panel
    Friend WithEvents CeldaTitulo As System.Windows.Forms.Label
    Friend WithEvents ListaPagare As System.Windows.Forms.DataGridView
    Friend WithEvents Pestañas As System.Windows.Forms.TabControl
    Friend WithEvents TabPage1 As System.Windows.Forms.TabPage
    Friend WithEvents TabDeudor As System.Windows.Forms.TabPage
    Friend WithEvents TabPage3 As System.Windows.Forms.TabPage
    Friend WithEvents TabPage4 As System.Windows.Forms.TabPage
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
    Friend WithEvents etiquetaIdCliente As System.Windows.Forms.Label
    Friend WithEvents botonBuscarCliente As System.Windows.Forms.Button
    Friend WithEvents etiquetaCliente As System.Windows.Forms.Label
    Friend WithEvents panelPestañas As System.Windows.Forms.Panel
    Friend WithEvents botonExportar As System.Windows.Forms.Button
    Friend WithEvents GroupBox2 As System.Windows.Forms.GroupBox
    Friend WithEvents celdaLibro As System.Windows.Forms.TextBox
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents celdaFolio As System.Windows.Forms.TextBox
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents celdaRegistro As System.Windows.Forms.TextBox
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents dtpFNombramiento As System.Windows.Forms.DateTimePicker
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents celdaNotario As System.Windows.Forms.TextBox
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents celdaDPIRepresentante As System.Windows.Forms.TextBox
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents celdaCliente As System.Windows.Forms.TextBox
    Friend WithEvents celdaRepresentante As System.Windows.Forms.TextBox
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents GroupBox4 As System.Windows.Forms.GroupBox
    Friend WithEvents GroupBox3 As System.Windows.Forms.GroupBox
    Friend WithEvents ListaFacturas As System.Windows.Forms.DataGridView
    Friend WithEvents celdaDepartamentoNotificaciones As System.Windows.Forms.TextBox
    Friend WithEvents celdaMunicipioNotificaciones As System.Windows.Forms.TextBox
    Friend WithEvents Label17 As System.Windows.Forms.Label
    Friend WithEvents Label16 As System.Windows.Forms.Label
    Friend WithEvents celdaNotificaciones As System.Windows.Forms.TextBox
    Friend WithEvents Label15 As System.Windows.Forms.Label
    Friend WithEvents dtpVigencia As System.Windows.Forms.DateTimePicker
    Friend WithEvents dtpVencimiento As System.Windows.Forms.DateTimePicker
    Friend WithEvents Label14 As System.Windows.Forms.Label
    Friend WithEvents Label13 As System.Windows.Forms.Label
    Friend WithEvents celdaInteres As System.Windows.Forms.TextBox
    Friend WithEvents Label12 As System.Windows.Forms.Label
    Friend WithEvents CeldaMonto As System.Windows.Forms.TextBox
    Friend WithEvents Label11 As System.Windows.Forms.Label
    Friend WithEvents celdaMoneda As System.Windows.Forms.TextBox
    Friend WithEvents celdaFactura As System.Windows.Forms.TextBox
    Friend WithEvents celdaPedido As System.Windows.Forms.TextBox
    Friend WithEvents CeldaMunicipioFiador As System.Windows.Forms.TextBox
    Friend WithEvents Label21 As System.Windows.Forms.Label
    Friend WithEvents CeldaDepartamentoFiador As System.Windows.Forms.TextBox
    Friend WithEvents Label20 As System.Windows.Forms.Label
    Friend WithEvents celdaDPIFiador As System.Windows.Forms.TextBox
    Friend WithEvents Label19 As System.Windows.Forms.Label
    Friend WithEvents celdaFiador As System.Windows.Forms.TextBox
    Friend WithEvents Label18 As System.Windows.Forms.Label
    Friend WithEvents celdaDireccionAcreedor As System.Windows.Forms.TextBox
    Friend WithEvents Label23 As System.Windows.Forms.Label
    Friend WithEvents celdaAcreedor As System.Windows.Forms.TextBox
    Friend WithEvents Label22 As System.Windows.Forms.Label
    Friend WithEvents lblIdMoneda As System.Windows.Forms.Label
    Friend WithEvents celdaAño As System.Windows.Forms.TextBox
    Friend WithEvents celdaIdPagare As System.Windows.Forms.TextBox
    Friend WithEvents botonSelFacturas As System.Windows.Forms.Button
    Friend WithEvents clmAno As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents clmNumero As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents clmCliente As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents clmFecha As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents clmMoneda As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents clmMOnto As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents pedido As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents celdaPlazo As System.Windows.Forms.TextBox
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents dtpFNombramientoF As System.Windows.Forms.DateTimePicker
    Friend WithEvents Label10 As System.Windows.Forms.Label
    Friend WithEvents CheckNombramiento As System.Windows.Forms.CheckBox
    Friend WithEvents checkRecibido As System.Windows.Forms.CheckBox
    Friend WithEvents checkActivo As System.Windows.Forms.CheckBox
    Friend WithEvents PanelLista As System.Windows.Forms.Panel
    Friend WithEvents panelFiltro As System.Windows.Forms.Panel
    Friend WithEvents Label24 As System.Windows.Forms.Label
    Friend WithEvents checkCliente As System.Windows.Forms.CheckBox
    Friend WithEvents checkFecha As System.Windows.Forms.CheckBox
    Friend WithEvents botonFiltar As System.Windows.Forms.Button
    Friend WithEvents celdaClienteFiltro As System.Windows.Forms.TextBox
    Friend WithEvents dtpFechaFin As System.Windows.Forms.DateTimePicker
    Friend WithEvents dtpFechaInicio As System.Windows.Forms.DateTimePicker
    Friend WithEvents colID As DataGridViewTextBoxColumn
    Friend WithEvents colAno As DataGridViewTextBoxColumn
    Friend WithEvents colFactura As DataGridViewTextBoxColumn
    Friend WithEvents colDeudor As DataGridViewTextBoxColumn
    Friend WithEvents colUsuario As DataGridViewTextBoxColumn
    Friend WithEvents colActivo As DataGridViewTextBoxColumn
    Friend WithEvents colRecibido As DataGridViewTextBoxColumn
    Friend WithEvents botonCliente As Button
End Class
