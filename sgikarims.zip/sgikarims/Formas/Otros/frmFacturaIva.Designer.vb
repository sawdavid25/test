﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class frmFacturaIva
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Dim DataGridViewCellStyle1 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle2 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle3 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle4 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle5 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle6 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle7 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle8 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle9 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle10 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle11 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle12 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle13 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle14 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle15 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle16 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle17 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle18 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Me.panelLista = New System.Windows.Forms.Panel()
        Me.dgLista = New System.Windows.Forms.DataGridView()
        Me.colCat = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colAno = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colNum = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colFecha = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colCliente = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colFact = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colTotal = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colSerieF = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colAutorizacionF = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.panelColores = New System.Windows.Forms.Panel()
        Me.celdaColorAmarillo = New System.Windows.Forms.TextBox()
        Me.celdaColorRojo = New System.Windows.Forms.TextBox()
        Me.etiquetaNoImpreso = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.panelEncabLista = New System.Windows.Forms.Panel()
        Me.botonEntrega = New System.Windows.Forms.Button()
        Me.botonActualizar = New System.Windows.Forms.Button()
        Me.etiquetaAnd = New System.Windows.Forms.Label()
        Me.dtpFin = New System.Windows.Forms.DateTimePicker()
        Me.dtpInicio = New System.Windows.Forms.DateTimePicker()
        Me.checkFecha = New System.Windows.Forms.CheckBox()
        Me.panelDocumento = New System.Windows.Forms.Panel()
        Me.Panel4 = New System.Windows.Forms.Panel()
        Me.PanelDtalle = New System.Windows.Forms.Panel()
        Me.dgDetalle = New System.Windows.Forms.DataGridView()
        Me.ColLinea = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.ColCodigo = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colDes = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colIdMedida = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colMedida = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colBulto = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colTipoBulto = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colPrecio = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colDescP = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.ColDesD = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colCantidad = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colReferencia = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colID = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.ColAnio = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.ColNumero = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colLineF = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.ColDestino = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.ColFlete = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colAgente = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.ColGestiones = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colOtros = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colImpuesto = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colExepcion = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colSubTotal = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colCtaAjena = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colCtaAjenaValor = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colTotal_ = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colExtra = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Panel3 = New System.Windows.Forms.Panel()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.Button2 = New System.Windows.Forms.Button()
        Me.PanelComplemento = New System.Windows.Forms.Panel()
        Me.dgComplemento = New System.Windows.Forms.DataGridView()
        Me.colLinComplemento = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colRelatedDocument = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colDate = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colComplemento = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colComplementoValor = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colExtraComplemento = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.PanelComplementoBotones = New System.Windows.Forms.Panel()
        Me.buttonDelComplemento = New System.Windows.Forms.Button()
        Me.buttonAddcomplemento = New System.Windows.Forms.Button()
        Me.panelEncabezado = New System.Windows.Forms.Panel()
        Me.panelInstrucciones = New System.Windows.Forms.Panel()
        Me.panelInfo = New System.Windows.Forms.Panel()
        Me.panelExtras = New System.Windows.Forms.Panel()
        Me.celdaGiro = New System.Windows.Forms.TextBox()
        Me.etiquetaGiro = New System.Windows.Forms.Label()
        Me.celdaRegistro = New System.Windows.Forms.TextBox()
        Me.etiquetaRegistro = New System.Windows.Forms.Label()
        Me.celdaNotas = New System.Windows.Forms.TextBox()
        Me.panelEncabezadoInstr = New System.Windows.Forms.Panel()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.dgFactrura = New System.Windows.Forms.DataGridView()
        Me.ColYearF = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.ColInvoiceF = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.ColDateF = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.ColRefF = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.ColWeightF = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Panel2 = New System.Windows.Forms.Panel()
        Me.botonQuitar = New System.Windows.Forms.Button()
        Me.botonAgregar = New System.Windows.Forms.Button()
        Me.gbInvoiceInfo = New System.Windows.Forms.GroupBox()
        Me.celdaFechaEmisionDocumento = New System.Windows.Forms.TextBox()
        Me.celdaFechaHoraCertificacion = New System.Windows.Forms.TextBox()
        Me.celdaSerieFel = New System.Windows.Forms.TextBox()
        Me.celdaUUID = New System.Windows.Forms.TextBox()
        Me.celdaOrden = New System.Windows.Forms.TextBox()
        Me.celdaCorrelativo = New System.Windows.Forms.TextBox()
        Me.botonRefacturar = New System.Windows.Forms.Button()
        Me.celdaIdMoneda = New System.Windows.Forms.TextBox()
        Me.dtpFecha = New System.Windows.Forms.DateTimePicker()
        Me.etiquetaAnulada = New System.Windows.Forms.Label()
        Me.botonPolizaC = New System.Windows.Forms.Button()
        Me.botonMoneda = New System.Windows.Forms.Button()
        Me.celdaIdCliente = New System.Windows.Forms.TextBox()
        Me.botonCliente = New System.Windows.Forms.Button()
        Me.checkActivar = New System.Windows.Forms.CheckBox()
        Me.celdaSerie = New System.Windows.Forms.TextBox()
        Me.celdaTasa = New System.Windows.Forms.TextBox()
        Me.etiquetaTasa = New System.Windows.Forms.Label()
        Me.celdaMoneda = New System.Windows.Forms.TextBox()
        Me.celdaNIT = New System.Windows.Forms.TextBox()
        Me.celdaTelefono = New System.Windows.Forms.TextBox()
        Me.celdaDireccion = New System.Windows.Forms.TextBox()
        Me.celdaCliente = New System.Windows.Forms.TextBox()
        Me.celdaNumero = New System.Windows.Forms.TextBox()
        Me.celdaAño = New System.Windows.Forms.TextBox()
        Me.etiquetaMoneda = New System.Windows.Forms.Label()
        Me.etiquetaNit = New System.Windows.Forms.Label()
        Me.etiquetaTelefono = New System.Windows.Forms.Label()
        Me.etiquetaCliente = New System.Windows.Forms.Label()
        Me.etiquetaDireccion = New System.Windows.Forms.Label()
        Me.etiquetaNumero = New System.Windows.Forms.Label()
        Me.etiquetaFecha = New System.Windows.Forms.Label()
        Me.etiquetaAño = New System.Windows.Forms.Label()
        Me.panelInfoFinal = New System.Windows.Forms.Panel()
        Me.panelDatos = New System.Windows.Forms.Panel()
        Me.dgDatos = New System.Windows.Forms.DataGridView()
        Me.colNombre = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colConcepto = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colMonto = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colTC = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colCargo = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colAbono = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colDias = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.panelSubDocumentos = New System.Windows.Forms.Panel()
        Me.dgSubdocumentos = New System.Windows.Forms.DataGridView()
        Me.colDescripcion = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colDocumento = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colDatos = New System.Windows.Forms.DataGridViewButtonColumn()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.panelComplementoTotales = New System.Windows.Forms.Panel()
        Me.celdaTotalDocumento = New System.Windows.Forms.TextBox()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.celdaTotalDetalle = New System.Windows.Forms.TextBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.celdaTotalComplemento = New System.Windows.Forms.TextBox()
        Me.etiquetaComplemento = New System.Windows.Forms.Label()
        Me.etiquetaSubTotal = New System.Windows.Forms.Label()
        Me.celdaSubTotal = New System.Windows.Forms.TextBox()
        Me.EtiquetaImpuesto = New System.Windows.Forms.Label()
        Me.celdaIva = New System.Windows.Forms.TextBox()
        Me.etiquetaExepto = New System.Windows.Forms.Label()
        Me.celdaExepcion = New System.Windows.Forms.TextBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.celdaObservaciones = New System.Windows.Forms.TextBox()
        Me.etiquetaTotales = New System.Windows.Forms.Label()
        Me.celdaTotal = New System.Windows.Forms.TextBox()
        Me.botonISR = New System.Windows.Forms.Button()
        Me.botonInprimir = New System.Windows.Forms.Button()
        Me.etiquetaAutorizacion = New System.Windows.Forms.Label()
        Me.etiquetaSerie = New System.Windows.Forms.Label()
        Me.botonPrevio = New System.Windows.Forms.Button()
        Me.BarraTitulo1 = New KARIMs_SGI.BarraTitulo()
        Me.Encabezado1 = New KARIMs_SGI.encabezado()
        Me.panelLista.SuspendLayout()
        CType(Me.dgLista, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.panelColores.SuspendLayout()
        Me.panelEncabLista.SuspendLayout()
        Me.panelDocumento.SuspendLayout()
        Me.Panel4.SuspendLayout()
        Me.PanelDtalle.SuspendLayout()
        CType(Me.dgDetalle, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Panel3.SuspendLayout()
        Me.PanelComplemento.SuspendLayout()
        CType(Me.dgComplemento, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.PanelComplementoBotones.SuspendLayout()
        Me.panelEncabezado.SuspendLayout()
        Me.panelInstrucciones.SuspendLayout()
        Me.panelInfo.SuspendLayout()
        Me.panelExtras.SuspendLayout()
        Me.panelEncabezadoInstr.SuspendLayout()
        Me.GroupBox1.SuspendLayout()
        CType(Me.dgFactrura, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Panel2.SuspendLayout()
        Me.gbInvoiceInfo.SuspendLayout()
        Me.panelInfoFinal.SuspendLayout()
        Me.panelDatos.SuspendLayout()
        CType(Me.dgDatos, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.panelSubDocumentos.SuspendLayout()
        CType(Me.dgSubdocumentos, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Panel1.SuspendLayout()
        Me.panelComplementoTotales.SuspendLayout()
        Me.SuspendLayout()
        '
        'panelLista
        '
        Me.panelLista.Controls.Add(Me.dgLista)
        Me.panelLista.Controls.Add(Me.panelColores)
        Me.panelLista.Controls.Add(Me.panelEncabLista)
        Me.panelLista.Location = New System.Drawing.Point(10, 110)
        Me.panelLista.Name = "panelLista"
        Me.panelLista.Size = New System.Drawing.Size(677, 125)
        Me.panelLista.TabIndex = 4
        '
        'dgLista
        '
        Me.dgLista.AllowUserToAddRows = False
        Me.dgLista.AllowUserToDeleteRows = False
        Me.dgLista.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells
        Me.dgLista.BackgroundColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle1.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.dgLista.ColumnHeadersDefaultCellStyle = DataGridViewCellStyle1
        Me.dgLista.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgLista.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.colCat, Me.colAno, Me.colNum, Me.colFecha, Me.colCliente, Me.colFact, Me.colTotal, Me.colSerieF, Me.colAutorizacionF})
        DataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle2.BackColor = System.Drawing.SystemColors.Window
        DataGridViewCellStyle2.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.ControlText
        DataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.[False]
        Me.dgLista.DefaultCellStyle = DataGridViewCellStyle2
        Me.dgLista.Dock = System.Windows.Forms.DockStyle.Fill
        Me.dgLista.Location = New System.Drawing.Point(0, 50)
        Me.dgLista.Margin = New System.Windows.Forms.Padding(2)
        Me.dgLista.MultiSelect = False
        Me.dgLista.Name = "dgLista"
        Me.dgLista.ReadOnly = True
        DataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle3.BackColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle3.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle3.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle3.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle3.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.dgLista.RowHeadersDefaultCellStyle = DataGridViewCellStyle3
        Me.dgLista.RowTemplate.Height = 24
        Me.dgLista.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.dgLista.Size = New System.Drawing.Size(677, 32)
        Me.dgLista.TabIndex = 3
        '
        'colCat
        '
        Me.colCat.HeaderText = "Cat"
        Me.colCat.Name = "colCat"
        Me.colCat.ReadOnly = True
        Me.colCat.Visible = False
        Me.colCat.Width = 48
        '
        'colAno
        '
        Me.colAno.HeaderText = "Year"
        Me.colAno.Name = "colAno"
        Me.colAno.ReadOnly = True
        Me.colAno.Visible = False
        Me.colAno.Width = 54
        '
        'colNum
        '
        Me.colNum.HeaderText = "ID"
        Me.colNum.Name = "colNum"
        Me.colNum.ReadOnly = True
        Me.colNum.Width = 43
        '
        'colFecha
        '
        Me.colFecha.HeaderText = "Date"
        Me.colFecha.Name = "colFecha"
        Me.colFecha.ReadOnly = True
        Me.colFecha.Width = 55
        '
        'colCliente
        '
        Me.colCliente.HeaderText = "Customer"
        Me.colCliente.Name = "colCliente"
        Me.colCliente.ReadOnly = True
        Me.colCliente.Width = 76
        '
        'colFact
        '
        Me.colFact.HeaderText = "# Fact"
        Me.colFact.Name = "colFact"
        Me.colFact.ReadOnly = True
        Me.colFact.Width = 63
        '
        'colTotal
        '
        Me.colTotal.HeaderText = "Amount"
        Me.colTotal.Name = "colTotal"
        Me.colTotal.ReadOnly = True
        Me.colTotal.Width = 68
        '
        'colSerieF
        '
        Me.colSerieF.HeaderText = "SerieF"
        Me.colSerieF.Name = "colSerieF"
        Me.colSerieF.ReadOnly = True
        Me.colSerieF.Visible = False
        Me.colSerieF.Width = 62
        '
        'colAutorizacionF
        '
        Me.colAutorizacionF.HeaderText = "Autorizacion Fel"
        Me.colAutorizacionF.Name = "colAutorizacionF"
        Me.colAutorizacionF.ReadOnly = True
        Me.colAutorizacionF.Visible = False
        Me.colAutorizacionF.Width = 107
        '
        'panelColores
        '
        Me.panelColores.BackColor = System.Drawing.SystemColors.Info
        Me.panelColores.Controls.Add(Me.celdaColorAmarillo)
        Me.panelColores.Controls.Add(Me.celdaColorRojo)
        Me.panelColores.Controls.Add(Me.etiquetaNoImpreso)
        Me.panelColores.Controls.Add(Me.Label1)
        Me.panelColores.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.panelColores.Location = New System.Drawing.Point(0, 82)
        Me.panelColores.Name = "panelColores"
        Me.panelColores.Size = New System.Drawing.Size(677, 43)
        Me.panelColores.TabIndex = 2
        '
        'celdaColorAmarillo
        '
        Me.celdaColorAmarillo.BackColor = System.Drawing.Color.Yellow
        Me.celdaColorAmarillo.Enabled = False
        Me.celdaColorAmarillo.Location = New System.Drawing.Point(122, 17)
        Me.celdaColorAmarillo.Name = "celdaColorAmarillo"
        Me.celdaColorAmarillo.ReadOnly = True
        Me.celdaColorAmarillo.Size = New System.Drawing.Size(19, 20)
        Me.celdaColorAmarillo.TabIndex = 30
        '
        'celdaColorRojo
        '
        Me.celdaColorRojo.BackColor = System.Drawing.Color.Red
        Me.celdaColorRojo.Enabled = False
        Me.celdaColorRojo.Location = New System.Drawing.Point(28, 17)
        Me.celdaColorRojo.Name = "celdaColorRojo"
        Me.celdaColorRojo.ReadOnly = True
        Me.celdaColorRojo.Size = New System.Drawing.Size(19, 20)
        Me.celdaColorRojo.TabIndex = 25
        '
        'etiquetaNoImpreso
        '
        Me.etiquetaNoImpreso.AutoSize = True
        Me.etiquetaNoImpreso.BackColor = System.Drawing.SystemColors.Info
        Me.etiquetaNoImpreso.Location = New System.Drawing.Point(145, 20)
        Me.etiquetaNoImpreso.Name = "etiquetaNoImpreso"
        Me.etiquetaNoImpreso.Size = New System.Drawing.Size(64, 13)
        Me.etiquetaNoImpreso.TabIndex = 32
        Me.etiquetaNoImpreso.Text = "Undelivered"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.BackColor = System.Drawing.SystemColors.Info
        Me.Label1.Location = New System.Drawing.Point(52, 20)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(46, 13)
        Me.Label1.TabIndex = 31
        Me.Label1.Text = "Annuled"
        '
        'panelEncabLista
        '
        Me.panelEncabLista.Controls.Add(Me.botonEntrega)
        Me.panelEncabLista.Controls.Add(Me.botonActualizar)
        Me.panelEncabLista.Controls.Add(Me.etiquetaAnd)
        Me.panelEncabLista.Controls.Add(Me.dtpFin)
        Me.panelEncabLista.Controls.Add(Me.dtpInicio)
        Me.panelEncabLista.Controls.Add(Me.checkFecha)
        Me.panelEncabLista.Dock = System.Windows.Forms.DockStyle.Top
        Me.panelEncabLista.Location = New System.Drawing.Point(0, 0)
        Me.panelEncabLista.Name = "panelEncabLista"
        Me.panelEncabLista.Size = New System.Drawing.Size(677, 50)
        Me.panelEncabLista.TabIndex = 0
        '
        'botonEntrega
        '
        Me.botonEntrega.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.botonEntrega.BackColor = System.Drawing.SystemColors.Control
        Me.botonEntrega.Enabled = False
        Me.botonEntrega.Image = Global.KARIMs_SGI.My.Resources.Resources.flag_red
        Me.botonEntrega.Location = New System.Drawing.Point(635, 16)
        Me.botonEntrega.Name = "botonEntrega"
        Me.botonEntrega.Size = New System.Drawing.Size(29, 23)
        Me.botonEntrega.TabIndex = 6
        Me.botonEntrega.UseVisualStyleBackColor = False
        '
        'botonActualizar
        '
        Me.botonActualizar.Location = New System.Drawing.Point(465, 15)
        Me.botonActualizar.Name = "botonActualizar"
        Me.botonActualizar.Size = New System.Drawing.Size(75, 23)
        Me.botonActualizar.TabIndex = 4
        Me.botonActualizar.Text = "Refresh"
        Me.botonActualizar.UseVisualStyleBackColor = True
        '
        'etiquetaAnd
        '
        Me.etiquetaAnd.AutoSize = True
        Me.etiquetaAnd.Location = New System.Drawing.Point(307, 20)
        Me.etiquetaAnd.Name = "etiquetaAnd"
        Me.etiquetaAnd.Size = New System.Drawing.Size(26, 13)
        Me.etiquetaAnd.TabIndex = 3
        Me.etiquetaAnd.Text = "And"
        '
        'dtpFin
        '
        Me.dtpFin.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.dtpFin.Location = New System.Drawing.Point(363, 16)
        Me.dtpFin.Name = "dtpFin"
        Me.dtpFin.Size = New System.Drawing.Size(97, 20)
        Me.dtpFin.TabIndex = 2
        '
        'dtpInicio
        '
        Me.dtpInicio.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.dtpInicio.Location = New System.Drawing.Point(205, 19)
        Me.dtpInicio.Name = "dtpInicio"
        Me.dtpInicio.Size = New System.Drawing.Size(97, 20)
        Me.dtpInicio.TabIndex = 1
        '
        'checkFecha
        '
        Me.checkFecha.AutoSize = True
        Me.checkFecha.Checked = True
        Me.checkFecha.CheckState = System.Windows.Forms.CheckState.Checked
        Me.checkFecha.Location = New System.Drawing.Point(18, 19)
        Me.checkFecha.Name = "checkFecha"
        Me.checkFecha.Size = New System.Drawing.Size(123, 17)
        Me.checkFecha.TabIndex = 0
        Me.checkFecha.Text = "Show Date between"
        Me.checkFecha.UseVisualStyleBackColor = True
        '
        'panelDocumento
        '
        Me.panelDocumento.Controls.Add(Me.Panel4)
        Me.panelDocumento.Controls.Add(Me.panelEncabezado)
        Me.panelDocumento.Controls.Add(Me.panelInfoFinal)
        Me.panelDocumento.Dock = System.Windows.Forms.DockStyle.Left
        Me.panelDocumento.Location = New System.Drawing.Point(0, 100)
        Me.panelDocumento.Name = "panelDocumento"
        Me.panelDocumento.Size = New System.Drawing.Size(1153, 563)
        Me.panelDocumento.TabIndex = 5
        '
        'Panel4
        '
        Me.Panel4.AutoScroll = True
        Me.Panel4.Controls.Add(Me.PanelDtalle)
        Me.Panel4.Controls.Add(Me.PanelComplemento)
        Me.Panel4.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Panel4.Location = New System.Drawing.Point(0, 271)
        Me.Panel4.Name = "Panel4"
        Me.Panel4.Size = New System.Drawing.Size(1153, 179)
        Me.Panel4.TabIndex = 10
        '
        'PanelDtalle
        '
        Me.PanelDtalle.AutoSize = True
        Me.PanelDtalle.Controls.Add(Me.dgDetalle)
        Me.PanelDtalle.Controls.Add(Me.Panel3)
        Me.PanelDtalle.Dock = System.Windows.Forms.DockStyle.Fill
        Me.PanelDtalle.Location = New System.Drawing.Point(0, 0)
        Me.PanelDtalle.Margin = New System.Windows.Forms.Padding(2)
        Me.PanelDtalle.Name = "PanelDtalle"
        Me.PanelDtalle.Size = New System.Drawing.Size(1153, 106)
        Me.PanelDtalle.TabIndex = 7
        '
        'dgDetalle
        '
        Me.dgDetalle.AllowUserToAddRows = False
        Me.dgDetalle.AllowUserToDeleteRows = False
        Me.dgDetalle.AllowUserToOrderColumns = True
        Me.dgDetalle.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells
        Me.dgDetalle.BackgroundColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle4.BackColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle4.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle4.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle4.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle4.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle4.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.dgDetalle.ColumnHeadersDefaultCellStyle = DataGridViewCellStyle4
        Me.dgDetalle.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgDetalle.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.ColLinea, Me.ColCodigo, Me.colDes, Me.colIdMedida, Me.colMedida, Me.colBulto, Me.colTipoBulto, Me.colPrecio, Me.colDescP, Me.ColDesD, Me.colCantidad, Me.colReferencia, Me.colID, Me.ColAnio, Me.ColNumero, Me.colLineF, Me.ColDestino, Me.ColFlete, Me.colAgente, Me.ColGestiones, Me.colOtros, Me.colImpuesto, Me.colExepcion, Me.colSubTotal, Me.colCtaAjena, Me.colCtaAjenaValor, Me.colTotal_, Me.colExtra})
        DataGridViewCellStyle5.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle5.BackColor = System.Drawing.SystemColors.Window
        DataGridViewCellStyle5.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle5.ForeColor = System.Drawing.SystemColors.ControlText
        DataGridViewCellStyle5.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle5.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle5.WrapMode = System.Windows.Forms.DataGridViewTriState.[False]
        Me.dgDetalle.DefaultCellStyle = DataGridViewCellStyle5
        Me.dgDetalle.Dock = System.Windows.Forms.DockStyle.Fill
        Me.dgDetalle.Location = New System.Drawing.Point(0, 0)
        Me.dgDetalle.Margin = New System.Windows.Forms.Padding(2)
        Me.dgDetalle.MultiSelect = False
        Me.dgDetalle.Name = "dgDetalle"
        DataGridViewCellStyle6.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle6.BackColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle6.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle6.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle6.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle6.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle6.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.dgDetalle.RowHeadersDefaultCellStyle = DataGridViewCellStyle6
        Me.dgDetalle.RowTemplate.Height = 24
        Me.dgDetalle.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.dgDetalle.Size = New System.Drawing.Size(1060, 106)
        Me.dgDetalle.TabIndex = 1
        '
        'ColLinea
        '
        Me.ColLinea.HeaderText = "Linea"
        Me.ColLinea.Name = "ColLinea"
        Me.ColLinea.Visible = False
        Me.ColLinea.Width = 58
        '
        'ColCodigo
        '
        Me.ColCodigo.HeaderText = "Code"
        Me.ColCodigo.Name = "ColCodigo"
        Me.ColCodigo.Width = 57
        '
        'colDes
        '
        Me.colDes.HeaderText = "Description"
        Me.colDes.Name = "colDes"
        Me.colDes.Width = 85
        '
        'colIdMedida
        '
        Me.colIdMedida.HeaderText = "IdMedida"
        Me.colIdMedida.Name = "colIdMedida"
        Me.colIdMedida.Visible = False
        Me.colIdMedida.Width = 76
        '
        'colMedida
        '
        Me.colMedida.HeaderText = "Medida"
        Me.colMedida.Name = "colMedida"
        Me.colMedida.Width = 67
        '
        'colBulto
        '
        Me.colBulto.HeaderText = "Package"
        Me.colBulto.Name = "colBulto"
        Me.colBulto.Width = 75
        '
        'colTipoBulto
        '
        Me.colTipoBulto.HeaderText = "Package Type"
        Me.colTipoBulto.Name = "colTipoBulto"
        Me.colTipoBulto.Width = 94
        '
        'colPrecio
        '
        Me.colPrecio.HeaderText = "Price"
        Me.colPrecio.Name = "colPrecio"
        Me.colPrecio.Width = 56
        '
        'colDescP
        '
        Me.colDescP.HeaderText = "Desc%"
        Me.colDescP.Name = "colDescP"
        Me.colDescP.Width = 65
        '
        'ColDesD
        '
        Me.ColDesD.HeaderText = "Desc"
        Me.ColDesD.Name = "ColDesD"
        Me.ColDesD.Width = 57
        '
        'colCantidad
        '
        Me.colCantidad.HeaderText = "Quantity"
        Me.colCantidad.Name = "colCantidad"
        Me.colCantidad.Width = 71
        '
        'colReferencia
        '
        Me.colReferencia.HeaderText = "Reference"
        Me.colReferencia.Name = "colReferencia"
        Me.colReferencia.Width = 82
        '
        'colID
        '
        Me.colID.HeaderText = "ID"
        Me.colID.Name = "colID"
        Me.colID.Visible = False
        Me.colID.Width = 43
        '
        'ColAnio
        '
        Me.ColAnio.HeaderText = "Ano"
        Me.ColAnio.Name = "ColAnio"
        Me.ColAnio.Visible = False
        Me.ColAnio.Width = 51
        '
        'ColNumero
        '
        Me.ColNumero.HeaderText = "Number"
        Me.ColNumero.Name = "ColNumero"
        Me.ColNumero.Width = 69
        '
        'colLineF
        '
        Me.colLineF.HeaderText = "LineR"
        Me.colLineF.Name = "colLineF"
        Me.colLineF.Visible = False
        Me.colLineF.Width = 60
        '
        'ColDestino
        '
        Me.ColDestino.HeaderText = "Destiny"
        Me.ColDestino.Name = "ColDestino"
        Me.ColDestino.Width = 67
        '
        'ColFlete
        '
        Me.ColFlete.HeaderText = "Freight Service"
        Me.ColFlete.Name = "ColFlete"
        Me.ColFlete.Width = 95
        '
        'colAgente
        '
        Me.colAgente.HeaderText = "Customs broker"
        Me.colAgente.Name = "colAgente"
        Me.colAgente.Width = 96
        '
        'ColGestiones
        '
        Me.ColGestiones.HeaderText = "Customs formalities"
        Me.ColGestiones.Name = "ColGestiones"
        Me.ColGestiones.Width = 111
        '
        'colOtros
        '
        Me.colOtros.HeaderText = "Descripcion"
        Me.colOtros.Name = "colOtros"
        Me.colOtros.Width = 88
        '
        'colImpuesto
        '
        Me.colImpuesto.HeaderText = "Taxes"
        Me.colImpuesto.Name = "colImpuesto"
        Me.colImpuesto.Width = 61
        '
        'colExepcion
        '
        Me.colExepcion.HeaderText = "Exempt Sales"
        Me.colExepcion.Name = "colExepcion"
        Me.colExepcion.Width = 88
        '
        'colSubTotal
        '
        Me.colSubTotal.HeaderText = "Sub-total"
        Me.colSubTotal.Name = "colSubTotal"
        Me.colSubTotal.Width = 74
        '
        'colCtaAjena
        '
        Me.colCtaAjena.HeaderText = "Another's Account"
        Me.colCtaAjena.Name = "colCtaAjena"
        Me.colCtaAjena.Visible = False
        Me.colCtaAjena.Width = 109
        '
        'colCtaAjenaValor
        '
        Me.colCtaAjenaValor.HeaderText = "Another's Account Value"
        Me.colCtaAjenaValor.Name = "colCtaAjenaValor"
        Me.colCtaAjenaValor.Visible = False
        Me.colCtaAjenaValor.Width = 112
        '
        'colTotal_
        '
        Me.colTotal_.HeaderText = "Total"
        Me.colTotal_.Name = "colTotal_"
        Me.colTotal_.Width = 56
        '
        'colExtra
        '
        Me.colExtra.HeaderText = "Extra"
        Me.colExtra.Name = "colExtra"
        Me.colExtra.Visible = False
        Me.colExtra.Width = 56
        '
        'Panel3
        '
        Me.Panel3.Controls.Add(Me.Button1)
        Me.Panel3.Controls.Add(Me.Button2)
        Me.Panel3.Dock = System.Windows.Forms.DockStyle.Right
        Me.Panel3.Location = New System.Drawing.Point(1060, 0)
        Me.Panel3.Margin = New System.Windows.Forms.Padding(2)
        Me.Panel3.Name = "Panel3"
        Me.Panel3.Size = New System.Drawing.Size(93, 106)
        Me.Panel3.TabIndex = 0
        '
        'Button1
        '
        Me.Button1.Image = Global.KARIMs_SGI.My.Resources.Resources.delete3
        Me.Button1.Location = New System.Drawing.Point(5, 33)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(26, 24)
        Me.Button1.TabIndex = 1
        Me.Button1.Text = "-"
        Me.Button1.UseVisualStyleBackColor = True
        '
        'Button2
        '
        Me.Button2.Image = Global.KARIMs_SGI.My.Resources.Resources.plus
        Me.Button2.Location = New System.Drawing.Point(5, 3)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(26, 24)
        Me.Button2.TabIndex = 2
        Me.Button2.UseVisualStyleBackColor = True
        '
        'PanelComplemento
        '
        Me.PanelComplemento.Controls.Add(Me.dgComplemento)
        Me.PanelComplemento.Controls.Add(Me.PanelComplementoBotones)
        Me.PanelComplemento.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.PanelComplemento.Location = New System.Drawing.Point(0, 106)
        Me.PanelComplemento.Margin = New System.Windows.Forms.Padding(2)
        Me.PanelComplemento.Name = "PanelComplemento"
        Me.PanelComplemento.Size = New System.Drawing.Size(1153, 73)
        Me.PanelComplemento.TabIndex = 9
        '
        'dgComplemento
        '
        Me.dgComplemento.AllowUserToAddRows = False
        Me.dgComplemento.AllowUserToDeleteRows = False
        Me.dgComplemento.AllowUserToOrderColumns = True
        Me.dgComplemento.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells
        Me.dgComplemento.BackgroundColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle7.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle7.BackColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle7.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle7.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle7.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle7.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle7.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.dgComplemento.ColumnHeadersDefaultCellStyle = DataGridViewCellStyle7
        Me.dgComplemento.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgComplemento.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.colLinComplemento, Me.colRelatedDocument, Me.colDate, Me.colComplemento, Me.colComplementoValor, Me.colExtraComplemento})
        DataGridViewCellStyle8.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle8.BackColor = System.Drawing.SystemColors.Window
        DataGridViewCellStyle8.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle8.ForeColor = System.Drawing.SystemColors.ControlText
        DataGridViewCellStyle8.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle8.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle8.WrapMode = System.Windows.Forms.DataGridViewTriState.[False]
        Me.dgComplemento.DefaultCellStyle = DataGridViewCellStyle8
        Me.dgComplemento.Dock = System.Windows.Forms.DockStyle.Fill
        Me.dgComplemento.Location = New System.Drawing.Point(0, 0)
        Me.dgComplemento.Margin = New System.Windows.Forms.Padding(2)
        Me.dgComplemento.MultiSelect = False
        Me.dgComplemento.Name = "dgComplemento"
        DataGridViewCellStyle9.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle9.BackColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle9.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle9.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle9.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle9.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle9.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.dgComplemento.RowHeadersDefaultCellStyle = DataGridViewCellStyle9
        Me.dgComplemento.RowTemplate.Height = 24
        Me.dgComplemento.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.dgComplemento.Size = New System.Drawing.Size(1060, 73)
        Me.dgComplemento.TabIndex = 1
        '
        'colLinComplemento
        '
        Me.colLinComplemento.HeaderText = "Linea"
        Me.colLinComplemento.Name = "colLinComplemento"
        Me.colLinComplemento.Visible = False
        Me.colLinComplemento.Width = 58
        '
        'colRelatedDocument
        '
        Me.colRelatedDocument.HeaderText = "Related Document"
        Me.colRelatedDocument.Name = "colRelatedDocument"
        Me.colRelatedDocument.Width = 111
        '
        'colDate
        '
        Me.colDate.HeaderText = "Date"
        Me.colDate.Name = "colDate"
        Me.colDate.Width = 55
        '
        'colComplemento
        '
        Me.colComplemento.HeaderText = "Another's Account"
        Me.colComplemento.Name = "colComplemento"
        Me.colComplemento.Width = 109
        '
        'colComplementoValor
        '
        Me.colComplementoValor.HeaderText = "Another's Account Value"
        Me.colComplementoValor.Name = "colComplementoValor"
        Me.colComplementoValor.Width = 112
        '
        'colExtraComplemento
        '
        Me.colExtraComplemento.HeaderText = "Extra"
        Me.colExtraComplemento.Name = "colExtraComplemento"
        Me.colExtraComplemento.Visible = False
        Me.colExtraComplemento.Width = 56
        '
        'PanelComplementoBotones
        '
        Me.PanelComplementoBotones.Controls.Add(Me.buttonDelComplemento)
        Me.PanelComplementoBotones.Controls.Add(Me.buttonAddcomplemento)
        Me.PanelComplementoBotones.Dock = System.Windows.Forms.DockStyle.Right
        Me.PanelComplementoBotones.Location = New System.Drawing.Point(1060, 0)
        Me.PanelComplementoBotones.Margin = New System.Windows.Forms.Padding(2)
        Me.PanelComplementoBotones.Name = "PanelComplementoBotones"
        Me.PanelComplementoBotones.Size = New System.Drawing.Size(93, 73)
        Me.PanelComplementoBotones.TabIndex = 0
        '
        'buttonDelComplemento
        '
        Me.buttonDelComplemento.Image = Global.KARIMs_SGI.My.Resources.Resources.delete3
        Me.buttonDelComplemento.Location = New System.Drawing.Point(5, 33)
        Me.buttonDelComplemento.Name = "buttonDelComplemento"
        Me.buttonDelComplemento.Size = New System.Drawing.Size(26, 24)
        Me.buttonDelComplemento.TabIndex = 1
        Me.buttonDelComplemento.Text = "-"
        Me.buttonDelComplemento.UseVisualStyleBackColor = True
        '
        'buttonAddcomplemento
        '
        Me.buttonAddcomplemento.Image = Global.KARIMs_SGI.My.Resources.Resources.plus
        Me.buttonAddcomplemento.Location = New System.Drawing.Point(5, 3)
        Me.buttonAddcomplemento.Name = "buttonAddcomplemento"
        Me.buttonAddcomplemento.Size = New System.Drawing.Size(26, 24)
        Me.buttonAddcomplemento.TabIndex = 2
        Me.buttonAddcomplemento.UseVisualStyleBackColor = True
        '
        'panelEncabezado
        '
        Me.panelEncabezado.Controls.Add(Me.panelInstrucciones)
        Me.panelEncabezado.Controls.Add(Me.gbInvoiceInfo)
        Me.panelEncabezado.Dock = System.Windows.Forms.DockStyle.Top
        Me.panelEncabezado.Location = New System.Drawing.Point(0, 0)
        Me.panelEncabezado.Margin = New System.Windows.Forms.Padding(2)
        Me.panelEncabezado.Name = "panelEncabezado"
        Me.panelEncabezado.Size = New System.Drawing.Size(1153, 271)
        Me.panelEncabezado.TabIndex = 5
        '
        'panelInstrucciones
        '
        Me.panelInstrucciones.Controls.Add(Me.panelInfo)
        Me.panelInstrucciones.Controls.Add(Me.panelEncabezadoInstr)
        Me.panelInstrucciones.Dock = System.Windows.Forms.DockStyle.Fill
        Me.panelInstrucciones.Location = New System.Drawing.Point(440, 0)
        Me.panelInstrucciones.Margin = New System.Windows.Forms.Padding(2)
        Me.panelInstrucciones.Name = "panelInstrucciones"
        Me.panelInstrucciones.Size = New System.Drawing.Size(713, 271)
        Me.panelInstrucciones.TabIndex = 1
        '
        'panelInfo
        '
        Me.panelInfo.Controls.Add(Me.panelExtras)
        Me.panelInfo.Controls.Add(Me.celdaNotas)
        Me.panelInfo.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.panelInfo.Location = New System.Drawing.Point(0, 126)
        Me.panelInfo.Margin = New System.Windows.Forms.Padding(2)
        Me.panelInfo.Name = "panelInfo"
        Me.panelInfo.Size = New System.Drawing.Size(713, 145)
        Me.panelInfo.TabIndex = 1
        '
        'panelExtras
        '
        Me.panelExtras.Controls.Add(Me.celdaGiro)
        Me.panelExtras.Controls.Add(Me.etiquetaGiro)
        Me.panelExtras.Controls.Add(Me.celdaRegistro)
        Me.panelExtras.Controls.Add(Me.etiquetaRegistro)
        Me.panelExtras.Dock = System.Windows.Forms.DockStyle.Fill
        Me.panelExtras.Location = New System.Drawing.Point(0, 0)
        Me.panelExtras.Margin = New System.Windows.Forms.Padding(2)
        Me.panelExtras.Name = "panelExtras"
        Me.panelExtras.Size = New System.Drawing.Size(713, 145)
        Me.panelExtras.TabIndex = 2
        '
        'celdaGiro
        '
        Me.celdaGiro.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.celdaGiro.Location = New System.Drawing.Point(101, 76)
        Me.celdaGiro.Margin = New System.Windows.Forms.Padding(2)
        Me.celdaGiro.Name = "celdaGiro"
        Me.celdaGiro.Size = New System.Drawing.Size(606, 20)
        Me.celdaGiro.TabIndex = 3
        '
        'etiquetaGiro
        '
        Me.etiquetaGiro.AutoSize = True
        Me.etiquetaGiro.Location = New System.Drawing.Point(14, 84)
        Me.etiquetaGiro.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.etiquetaGiro.Name = "etiquetaGiro"
        Me.etiquetaGiro.Size = New System.Drawing.Size(26, 13)
        Me.etiquetaGiro.TabIndex = 2
        Me.etiquetaGiro.Text = "Giro"
        '
        'celdaRegistro
        '
        Me.celdaRegistro.Location = New System.Drawing.Point(101, 33)
        Me.celdaRegistro.Margin = New System.Windows.Forms.Padding(2)
        Me.celdaRegistro.Name = "celdaRegistro"
        Me.celdaRegistro.Size = New System.Drawing.Size(104, 20)
        Me.celdaRegistro.TabIndex = 1
        '
        'etiquetaRegistro
        '
        Me.etiquetaRegistro.AutoSize = True
        Me.etiquetaRegistro.Location = New System.Drawing.Point(14, 37)
        Me.etiquetaRegistro.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.etiquetaRegistro.Name = "etiquetaRegistro"
        Me.etiquetaRegistro.Size = New System.Drawing.Size(66, 13)
        Me.etiquetaRegistro.TabIndex = 0
        Me.etiquetaRegistro.Text = "Registro No."
        '
        'celdaNotas
        '
        Me.celdaNotas.BackColor = System.Drawing.SystemColors.Info
        Me.celdaNotas.Dock = System.Windows.Forms.DockStyle.Fill
        Me.celdaNotas.Location = New System.Drawing.Point(0, 0)
        Me.celdaNotas.Multiline = True
        Me.celdaNotas.Name = "celdaNotas"
        Me.celdaNotas.ReadOnly = True
        Me.celdaNotas.Size = New System.Drawing.Size(713, 145)
        Me.celdaNotas.TabIndex = 1
        Me.celdaNotas.Text = "Info..."
        '
        'panelEncabezadoInstr
        '
        Me.panelEncabezadoInstr.Controls.Add(Me.GroupBox1)
        Me.panelEncabezadoInstr.Dock = System.Windows.Forms.DockStyle.Fill
        Me.panelEncabezadoInstr.Location = New System.Drawing.Point(0, 0)
        Me.panelEncabezadoInstr.Margin = New System.Windows.Forms.Padding(2)
        Me.panelEncabezadoInstr.Name = "panelEncabezadoInstr"
        Me.panelEncabezadoInstr.Size = New System.Drawing.Size(713, 271)
        Me.panelEncabezadoInstr.TabIndex = 0
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.dgFactrura)
        Me.GroupBox1.Controls.Add(Me.Panel2)
        Me.GroupBox1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.GroupBox1.Location = New System.Drawing.Point(0, 0)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(713, 271)
        Me.GroupBox1.TabIndex = 1
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Dispatching Instructions to Include"
        '
        'dgFactrura
        '
        Me.dgFactrura.AllowUserToAddRows = False
        Me.dgFactrura.AllowUserToDeleteRows = False
        Me.dgFactrura.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells
        Me.dgFactrura.BackgroundColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle10.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle10.BackColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle10.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle10.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle10.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle10.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle10.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.dgFactrura.ColumnHeadersDefaultCellStyle = DataGridViewCellStyle10
        Me.dgFactrura.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgFactrura.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.ColYearF, Me.ColInvoiceF, Me.ColDateF, Me.ColRefF, Me.ColWeightF})
        DataGridViewCellStyle11.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle11.BackColor = System.Drawing.SystemColors.Window
        DataGridViewCellStyle11.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle11.ForeColor = System.Drawing.SystemColors.ControlText
        DataGridViewCellStyle11.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle11.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle11.WrapMode = System.Windows.Forms.DataGridViewTriState.[False]
        Me.dgFactrura.DefaultCellStyle = DataGridViewCellStyle11
        Me.dgFactrura.Dock = System.Windows.Forms.DockStyle.Top
        Me.dgFactrura.Location = New System.Drawing.Point(3, 16)
        Me.dgFactrura.Margin = New System.Windows.Forms.Padding(2)
        Me.dgFactrura.Name = "dgFactrura"
        Me.dgFactrura.ReadOnly = True
        DataGridViewCellStyle12.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle12.BackColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle12.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle12.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle12.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle12.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle12.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.dgFactrura.RowHeadersDefaultCellStyle = DataGridViewCellStyle12
        Me.dgFactrura.RowTemplate.Height = 24
        Me.dgFactrura.Size = New System.Drawing.Size(671, 107)
        Me.dgFactrura.TabIndex = 2
        '
        'ColYearF
        '
        Me.ColYearF.HeaderText = "Ano"
        Me.ColYearF.Name = "ColYearF"
        Me.ColYearF.ReadOnly = True
        Me.ColYearF.Visible = False
        Me.ColYearF.Width = 51
        '
        'ColInvoiceF
        '
        Me.ColInvoiceF.HeaderText = "Invoice"
        Me.ColInvoiceF.Name = "ColInvoiceF"
        Me.ColInvoiceF.ReadOnly = True
        Me.ColInvoiceF.Width = 67
        '
        'ColDateF
        '
        Me.ColDateF.HeaderText = "Date"
        Me.ColDateF.Name = "ColDateF"
        Me.ColDateF.ReadOnly = True
        Me.ColDateF.Width = 55
        '
        'ColRefF
        '
        Me.ColRefF.HeaderText = "Reference"
        Me.ColRefF.Name = "ColRefF"
        Me.ColRefF.ReadOnly = True
        Me.ColRefF.Width = 82
        '
        'ColWeightF
        '
        Me.ColWeightF.HeaderText = "Weight"
        Me.ColWeightF.Name = "ColWeightF"
        Me.ColWeightF.ReadOnly = True
        Me.ColWeightF.Width = 66
        '
        'Panel2
        '
        Me.Panel2.Controls.Add(Me.botonQuitar)
        Me.Panel2.Controls.Add(Me.botonAgregar)
        Me.Panel2.Dock = System.Windows.Forms.DockStyle.Right
        Me.Panel2.Location = New System.Drawing.Point(674, 16)
        Me.Panel2.Margin = New System.Windows.Forms.Padding(2)
        Me.Panel2.Name = "Panel2"
        Me.Panel2.Size = New System.Drawing.Size(36, 252)
        Me.Panel2.TabIndex = 3
        '
        'botonQuitar
        '
        Me.botonQuitar.Image = Global.KARIMs_SGI.My.Resources.Resources.delete3
        Me.botonQuitar.Location = New System.Drawing.Point(3, 64)
        Me.botonQuitar.Name = "botonQuitar"
        Me.botonQuitar.Size = New System.Drawing.Size(26, 24)
        Me.botonQuitar.TabIndex = 1
        Me.botonQuitar.Text = "-"
        Me.botonQuitar.UseVisualStyleBackColor = True
        '
        'botonAgregar
        '
        Me.botonAgregar.Image = Global.KARIMs_SGI.My.Resources.Resources.plus
        Me.botonAgregar.Location = New System.Drawing.Point(3, 34)
        Me.botonAgregar.Name = "botonAgregar"
        Me.botonAgregar.Size = New System.Drawing.Size(26, 24)
        Me.botonAgregar.TabIndex = 2
        Me.botonAgregar.UseVisualStyleBackColor = True
        '
        'gbInvoiceInfo
        '
        Me.gbInvoiceInfo.Controls.Add(Me.celdaFechaEmisionDocumento)
        Me.gbInvoiceInfo.Controls.Add(Me.celdaFechaHoraCertificacion)
        Me.gbInvoiceInfo.Controls.Add(Me.celdaSerieFel)
        Me.gbInvoiceInfo.Controls.Add(Me.celdaUUID)
        Me.gbInvoiceInfo.Controls.Add(Me.celdaOrden)
        Me.gbInvoiceInfo.Controls.Add(Me.celdaCorrelativo)
        Me.gbInvoiceInfo.Controls.Add(Me.botonRefacturar)
        Me.gbInvoiceInfo.Controls.Add(Me.celdaIdMoneda)
        Me.gbInvoiceInfo.Controls.Add(Me.dtpFecha)
        Me.gbInvoiceInfo.Controls.Add(Me.etiquetaAnulada)
        Me.gbInvoiceInfo.Controls.Add(Me.botonPolizaC)
        Me.gbInvoiceInfo.Controls.Add(Me.botonMoneda)
        Me.gbInvoiceInfo.Controls.Add(Me.celdaIdCliente)
        Me.gbInvoiceInfo.Controls.Add(Me.botonCliente)
        Me.gbInvoiceInfo.Controls.Add(Me.checkActivar)
        Me.gbInvoiceInfo.Controls.Add(Me.celdaSerie)
        Me.gbInvoiceInfo.Controls.Add(Me.celdaTasa)
        Me.gbInvoiceInfo.Controls.Add(Me.etiquetaTasa)
        Me.gbInvoiceInfo.Controls.Add(Me.celdaMoneda)
        Me.gbInvoiceInfo.Controls.Add(Me.celdaNIT)
        Me.gbInvoiceInfo.Controls.Add(Me.celdaTelefono)
        Me.gbInvoiceInfo.Controls.Add(Me.celdaDireccion)
        Me.gbInvoiceInfo.Controls.Add(Me.celdaCliente)
        Me.gbInvoiceInfo.Controls.Add(Me.celdaNumero)
        Me.gbInvoiceInfo.Controls.Add(Me.celdaAño)
        Me.gbInvoiceInfo.Controls.Add(Me.etiquetaMoneda)
        Me.gbInvoiceInfo.Controls.Add(Me.etiquetaNit)
        Me.gbInvoiceInfo.Controls.Add(Me.etiquetaTelefono)
        Me.gbInvoiceInfo.Controls.Add(Me.etiquetaCliente)
        Me.gbInvoiceInfo.Controls.Add(Me.etiquetaDireccion)
        Me.gbInvoiceInfo.Controls.Add(Me.etiquetaNumero)
        Me.gbInvoiceInfo.Controls.Add(Me.etiquetaFecha)
        Me.gbInvoiceInfo.Controls.Add(Me.etiquetaAño)
        Me.gbInvoiceInfo.Dock = System.Windows.Forms.DockStyle.Left
        Me.gbInvoiceInfo.Location = New System.Drawing.Point(0, 0)
        Me.gbInvoiceInfo.Name = "gbInvoiceInfo"
        Me.gbInvoiceInfo.Size = New System.Drawing.Size(440, 271)
        Me.gbInvoiceInfo.TabIndex = 0
        Me.gbInvoiceInfo.TabStop = False
        Me.gbInvoiceInfo.Text = "Invoice Information"
        '
        'celdaFechaEmisionDocumento
        '
        Me.celdaFechaEmisionDocumento.Location = New System.Drawing.Point(341, 232)
        Me.celdaFechaEmisionDocumento.Name = "celdaFechaEmisionDocumento"
        Me.celdaFechaEmisionDocumento.Size = New System.Drawing.Size(11, 20)
        Me.celdaFechaEmisionDocumento.TabIndex = 53
        Me.celdaFechaEmisionDocumento.Visible = False
        '
        'celdaFechaHoraCertificacion
        '
        Me.celdaFechaHoraCertificacion.Location = New System.Drawing.Point(353, 232)
        Me.celdaFechaHoraCertificacion.Name = "celdaFechaHoraCertificacion"
        Me.celdaFechaHoraCertificacion.Size = New System.Drawing.Size(11, 20)
        Me.celdaFechaHoraCertificacion.TabIndex = 52
        Me.celdaFechaHoraCertificacion.Visible = False
        '
        'celdaSerieFel
        '
        Me.celdaSerieFel.Location = New System.Drawing.Point(364, 232)
        Me.celdaSerieFel.Name = "celdaSerieFel"
        Me.celdaSerieFel.Size = New System.Drawing.Size(11, 20)
        Me.celdaSerieFel.TabIndex = 51
        Me.celdaSerieFel.Visible = False
        '
        'celdaUUID
        '
        Me.celdaUUID.Location = New System.Drawing.Point(269, 210)
        Me.celdaUUID.Name = "celdaUUID"
        Me.celdaUUID.Size = New System.Drawing.Size(143, 20)
        Me.celdaUUID.TabIndex = 47
        Me.celdaUUID.Visible = False
        '
        'celdaOrden
        '
        Me.celdaOrden.BackColor = System.Drawing.SystemColors.Info
        Me.celdaOrden.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.celdaOrden.ForeColor = System.Drawing.SystemColors.HotTrack
        Me.celdaOrden.Location = New System.Drawing.Point(357, 53)
        Me.celdaOrden.Name = "celdaOrden"
        Me.celdaOrden.ReadOnly = True
        Me.celdaOrden.Size = New System.Drawing.Size(72, 19)
        Me.celdaOrden.TabIndex = 36
        Me.celdaOrden.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'celdaCorrelativo
        '
        Me.celdaCorrelativo.BackColor = System.Drawing.SystemColors.Info
        Me.celdaCorrelativo.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.celdaCorrelativo.ForeColor = System.Drawing.SystemColors.HotTrack
        Me.celdaCorrelativo.Location = New System.Drawing.Point(58, 53)
        Me.celdaCorrelativo.Name = "celdaCorrelativo"
        Me.celdaCorrelativo.Size = New System.Drawing.Size(72, 19)
        Me.celdaCorrelativo.TabIndex = 35
        Me.celdaCorrelativo.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'botonRefacturar
        '
        Me.botonRefacturar.Location = New System.Drawing.Point(347, 15)
        Me.botonRefacturar.Margin = New System.Windows.Forms.Padding(2)
        Me.botonRefacturar.Name = "botonRefacturar"
        Me.botonRefacturar.Size = New System.Drawing.Size(65, 32)
        Me.botonRefacturar.TabIndex = 6
        Me.botonRefacturar.Text = "Refacturar"
        Me.botonRefacturar.UseVisualStyleBackColor = True
        '
        'celdaIdMoneda
        '
        Me.celdaIdMoneda.Location = New System.Drawing.Point(170, 236)
        Me.celdaIdMoneda.Margin = New System.Windows.Forms.Padding(2)
        Me.celdaIdMoneda.Name = "celdaIdMoneda"
        Me.celdaIdMoneda.Size = New System.Drawing.Size(30, 20)
        Me.celdaIdMoneda.TabIndex = 34
        Me.celdaIdMoneda.Visible = False
        '
        'dtpFecha
        '
        Me.dtpFecha.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.dtpFecha.Location = New System.Drawing.Point(57, 78)
        Me.dtpFecha.Name = "dtpFecha"
        Me.dtpFecha.Size = New System.Drawing.Size(97, 20)
        Me.dtpFecha.TabIndex = 33
        '
        'etiquetaAnulada
        '
        Me.etiquetaAnulada.AutoSize = True
        Me.etiquetaAnulada.BackColor = System.Drawing.Color.Red
        Me.etiquetaAnulada.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.etiquetaAnulada.Location = New System.Drawing.Point(176, 34)
        Me.etiquetaAnulada.Name = "etiquetaAnulada"
        Me.etiquetaAnulada.Size = New System.Drawing.Size(69, 15)
        Me.etiquetaAnulada.TabIndex = 28
        Me.etiquetaAnulada.Text = "ANULADA"
        Me.etiquetaAnulada.Visible = False
        '
        'botonPolizaC
        '
        Me.botonPolizaC.Image = Global.KARIMs_SGI.My.Resources.Resources.book_open
        Me.botonPolizaC.Location = New System.Drawing.Point(403, 184)
        Me.botonPolizaC.Name = "botonPolizaC"
        Me.botonPolizaC.Size = New System.Drawing.Size(29, 23)
        Me.botonPolizaC.TabIndex = 27
        Me.botonPolizaC.UseVisualStyleBackColor = True
        '
        'botonMoneda
        '
        Me.botonMoneda.Location = New System.Drawing.Point(135, 234)
        Me.botonMoneda.Name = "botonMoneda"
        Me.botonMoneda.Size = New System.Drawing.Size(30, 23)
        Me.botonMoneda.TabIndex = 25
        Me.botonMoneda.Text = "..."
        Me.botonMoneda.UseVisualStyleBackColor = True
        '
        'celdaIdCliente
        '
        Me.celdaIdCliente.Location = New System.Drawing.Point(403, 98)
        Me.celdaIdCliente.Name = "celdaIdCliente"
        Me.celdaIdCliente.Size = New System.Drawing.Size(30, 20)
        Me.celdaIdCliente.TabIndex = 24
        Me.celdaIdCliente.Text = "-1"
        Me.celdaIdCliente.Visible = False
        '
        'botonCliente
        '
        Me.botonCliente.Location = New System.Drawing.Point(367, 96)
        Me.botonCliente.Name = "botonCliente"
        Me.botonCliente.Size = New System.Drawing.Size(30, 23)
        Me.botonCliente.TabIndex = 23
        Me.botonCliente.Text = "..."
        Me.botonCliente.UseVisualStyleBackColor = True
        '
        'checkActivar
        '
        Me.checkActivar.AutoSize = True
        Me.checkActivar.Checked = True
        Me.checkActivar.CheckState = System.Windows.Forms.CheckState.Checked
        Me.checkActivar.Location = New System.Drawing.Point(280, 19)
        Me.checkActivar.Name = "checkActivar"
        Me.checkActivar.Size = New System.Drawing.Size(56, 17)
        Me.checkActivar.TabIndex = 22
        Me.checkActivar.Text = "Active"
        Me.checkActivar.UseVisualStyleBackColor = True
        '
        'celdaSerie
        '
        Me.celdaSerie.Location = New System.Drawing.Point(136, 53)
        Me.celdaSerie.Name = "celdaSerie"
        Me.celdaSerie.ReadOnly = True
        Me.celdaSerie.Size = New System.Drawing.Size(139, 20)
        Me.celdaSerie.TabIndex = 21
        Me.celdaSerie.Text = """A"""
        Me.celdaSerie.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'celdaTasa
        '
        Me.celdaTasa.Location = New System.Drawing.Point(246, 236)
        Me.celdaTasa.Name = "celdaTasa"
        Me.celdaTasa.Size = New System.Drawing.Size(60, 20)
        Me.celdaTasa.TabIndex = 19
        Me.celdaTasa.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'etiquetaTasa
        '
        Me.etiquetaTasa.AutoSize = True
        Me.etiquetaTasa.Location = New System.Drawing.Point(210, 240)
        Me.etiquetaTasa.Name = "etiquetaTasa"
        Me.etiquetaTasa.Size = New System.Drawing.Size(30, 13)
        Me.etiquetaTasa.TabIndex = 18
        Me.etiquetaTasa.Text = "Rate"
        '
        'celdaMoneda
        '
        Me.celdaMoneda.Location = New System.Drawing.Point(56, 236)
        Me.celdaMoneda.Name = "celdaMoneda"
        Me.celdaMoneda.ReadOnly = True
        Me.celdaMoneda.Size = New System.Drawing.Size(76, 20)
        Me.celdaMoneda.TabIndex = 17
        '
        'celdaNIT
        '
        Me.celdaNIT.Location = New System.Drawing.Point(56, 210)
        Me.celdaNIT.Name = "celdaNIT"
        Me.celdaNIT.ReadOnly = True
        Me.celdaNIT.Size = New System.Drawing.Size(110, 20)
        Me.celdaNIT.TabIndex = 16
        '
        'celdaTelefono
        '
        Me.celdaTelefono.Location = New System.Drawing.Point(56, 184)
        Me.celdaTelefono.Name = "celdaTelefono"
        Me.celdaTelefono.ReadOnly = True
        Me.celdaTelefono.Size = New System.Drawing.Size(158, 20)
        Me.celdaTelefono.TabIndex = 15
        '
        'celdaDireccion
        '
        Me.celdaDireccion.Location = New System.Drawing.Point(56, 124)
        Me.celdaDireccion.Multiline = True
        Me.celdaDireccion.Name = "celdaDireccion"
        Me.celdaDireccion.ReadOnly = True
        Me.celdaDireccion.Size = New System.Drawing.Size(378, 54)
        Me.celdaDireccion.TabIndex = 13
        '
        'celdaCliente
        '
        Me.celdaCliente.Location = New System.Drawing.Point(57, 101)
        Me.celdaCliente.Name = "celdaCliente"
        Me.celdaCliente.ReadOnly = True
        Me.celdaCliente.Size = New System.Drawing.Size(305, 20)
        Me.celdaCliente.TabIndex = 12
        '
        'celdaNumero
        '
        Me.celdaNumero.BackColor = System.Drawing.SystemColors.Info
        Me.celdaNumero.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.celdaNumero.ForeColor = System.Drawing.SystemColors.HotTrack
        Me.celdaNumero.Location = New System.Drawing.Point(280, 53)
        Me.celdaNumero.Name = "celdaNumero"
        Me.celdaNumero.ReadOnly = True
        Me.celdaNumero.Size = New System.Drawing.Size(72, 19)
        Me.celdaNumero.TabIndex = 10
        Me.celdaNumero.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'celdaAño
        '
        Me.celdaAño.BackColor = System.Drawing.SystemColors.Info
        Me.celdaAño.Enabled = False
        Me.celdaAño.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.celdaAño.ForeColor = System.Drawing.SystemColors.HotTrack
        Me.celdaAño.Location = New System.Drawing.Point(57, 31)
        Me.celdaAño.Name = "celdaAño"
        Me.celdaAño.ReadOnly = True
        Me.celdaAño.Size = New System.Drawing.Size(72, 19)
        Me.celdaAño.TabIndex = 9
        Me.celdaAño.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'etiquetaMoneda
        '
        Me.etiquetaMoneda.AutoSize = True
        Me.etiquetaMoneda.Location = New System.Drawing.Point(6, 239)
        Me.etiquetaMoneda.Name = "etiquetaMoneda"
        Me.etiquetaMoneda.Size = New System.Drawing.Size(49, 13)
        Me.etiquetaMoneda.TabIndex = 8
        Me.etiquetaMoneda.Text = "Currency"
        '
        'etiquetaNit
        '
        Me.etiquetaNit.AutoSize = True
        Me.etiquetaNit.Location = New System.Drawing.Point(6, 213)
        Me.etiquetaNit.Name = "etiquetaNit"
        Me.etiquetaNit.Size = New System.Drawing.Size(20, 13)
        Me.etiquetaNit.TabIndex = 7
        Me.etiquetaNit.Text = "Nit"
        '
        'etiquetaTelefono
        '
        Me.etiquetaTelefono.AutoSize = True
        Me.etiquetaTelefono.Location = New System.Drawing.Point(6, 184)
        Me.etiquetaTelefono.Name = "etiquetaTelefono"
        Me.etiquetaTelefono.Size = New System.Drawing.Size(38, 13)
        Me.etiquetaTelefono.TabIndex = 6
        Me.etiquetaTelefono.Text = "Phone"
        '
        'etiquetaCliente
        '
        Me.etiquetaCliente.AutoSize = True
        Me.etiquetaCliente.Location = New System.Drawing.Point(6, 104)
        Me.etiquetaCliente.Name = "etiquetaCliente"
        Me.etiquetaCliente.Size = New System.Drawing.Size(33, 13)
        Me.etiquetaCliente.TabIndex = 4
        Me.etiquetaCliente.Text = "Client"
        '
        'etiquetaDireccion
        '
        Me.etiquetaDireccion.AutoSize = True
        Me.etiquetaDireccion.Location = New System.Drawing.Point(6, 127)
        Me.etiquetaDireccion.Name = "etiquetaDireccion"
        Me.etiquetaDireccion.Size = New System.Drawing.Size(49, 13)
        Me.etiquetaDireccion.TabIndex = 3
        Me.etiquetaDireccion.Text = "Direction"
        '
        'etiquetaNumero
        '
        Me.etiquetaNumero.AutoSize = True
        Me.etiquetaNumero.Location = New System.Drawing.Point(6, 60)
        Me.etiquetaNumero.Name = "etiquetaNumero"
        Me.etiquetaNumero.Size = New System.Drawing.Size(44, 13)
        Me.etiquetaNumero.TabIndex = 2
        Me.etiquetaNumero.Text = "Number"
        '
        'etiquetaFecha
        '
        Me.etiquetaFecha.AutoSize = True
        Me.etiquetaFecha.Location = New System.Drawing.Point(6, 82)
        Me.etiquetaFecha.Name = "etiquetaFecha"
        Me.etiquetaFecha.Size = New System.Drawing.Size(30, 13)
        Me.etiquetaFecha.TabIndex = 1
        Me.etiquetaFecha.Text = "Date"
        '
        'etiquetaAño
        '
        Me.etiquetaAño.AutoSize = True
        Me.etiquetaAño.Location = New System.Drawing.Point(6, 34)
        Me.etiquetaAño.Name = "etiquetaAño"
        Me.etiquetaAño.Size = New System.Drawing.Size(29, 13)
        Me.etiquetaAño.TabIndex = 0
        Me.etiquetaAño.Text = "Year"
        '
        'panelInfoFinal
        '
        Me.panelInfoFinal.Controls.Add(Me.panelDatos)
        Me.panelInfoFinal.Controls.Add(Me.panelSubDocumentos)
        Me.panelInfoFinal.Controls.Add(Me.Panel1)
        Me.panelInfoFinal.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.panelInfoFinal.Location = New System.Drawing.Point(0, 450)
        Me.panelInfoFinal.Name = "panelInfoFinal"
        Me.panelInfoFinal.Size = New System.Drawing.Size(1153, 113)
        Me.panelInfoFinal.TabIndex = 4
        '
        'panelDatos
        '
        Me.panelDatos.Controls.Add(Me.dgDatos)
        Me.panelDatos.Dock = System.Windows.Forms.DockStyle.Fill
        Me.panelDatos.Location = New System.Drawing.Point(243, 62)
        Me.panelDatos.Name = "panelDatos"
        Me.panelDatos.Size = New System.Drawing.Size(910, 51)
        Me.panelDatos.TabIndex = 1
        '
        'dgDatos
        '
        Me.dgDatos.AccessibleRole = System.Windows.Forms.AccessibleRole.None
        Me.dgDatos.AllowUserToAddRows = False
        Me.dgDatos.AllowUserToDeleteRows = False
        Me.dgDatos.AllowUserToOrderColumns = True
        Me.dgDatos.BackgroundColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle13.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle13.BackColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle13.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle13.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle13.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle13.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle13.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.dgDatos.ColumnHeadersDefaultCellStyle = DataGridViewCellStyle13
        Me.dgDatos.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgDatos.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.colNombre, Me.colConcepto, Me.colMonto, Me.colTC, Me.colCargo, Me.colAbono, Me.colDias})
        DataGridViewCellStyle14.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle14.BackColor = System.Drawing.SystemColors.Window
        DataGridViewCellStyle14.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle14.ForeColor = System.Drawing.SystemColors.ControlText
        DataGridViewCellStyle14.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle14.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle14.WrapMode = System.Windows.Forms.DataGridViewTriState.[False]
        Me.dgDatos.DefaultCellStyle = DataGridViewCellStyle14
        Me.dgDatos.Dock = System.Windows.Forms.DockStyle.Fill
        Me.dgDatos.Location = New System.Drawing.Point(0, 0)
        Me.dgDatos.Name = "dgDatos"
        DataGridViewCellStyle15.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle15.BackColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle15.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle15.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle15.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle15.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle15.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.dgDatos.RowHeadersDefaultCellStyle = DataGridViewCellStyle15
        Me.dgDatos.Size = New System.Drawing.Size(910, 51)
        Me.dgDatos.TabIndex = 0
        '
        'colNombre
        '
        Me.colNombre.HeaderText = "Name"
        Me.colNombre.Name = "colNombre"
        '
        'colConcepto
        '
        Me.colConcepto.HeaderText = "Concept"
        Me.colConcepto.Name = "colConcepto"
        '
        'colMonto
        '
        Me.colMonto.HeaderText = "Amount"
        Me.colMonto.Name = "colMonto"
        '
        'colTC
        '
        Me.colTC.HeaderText = "T/C"
        Me.colTC.Name = "colTC"
        '
        'colCargo
        '
        Me.colCargo.HeaderText = "Charge"
        Me.colCargo.Name = "colCargo"
        '
        'colAbono
        '
        Me.colAbono.HeaderText = "Payment"
        Me.colAbono.Name = "colAbono"
        '
        'colDias
        '
        Me.colDias.HeaderText = "Days"
        Me.colDias.Name = "colDias"
        '
        'panelSubDocumentos
        '
        Me.panelSubDocumentos.Controls.Add(Me.dgSubdocumentos)
        Me.panelSubDocumentos.Dock = System.Windows.Forms.DockStyle.Left
        Me.panelSubDocumentos.Location = New System.Drawing.Point(0, 62)
        Me.panelSubDocumentos.Name = "panelSubDocumentos"
        Me.panelSubDocumentos.Size = New System.Drawing.Size(243, 51)
        Me.panelSubDocumentos.TabIndex = 0
        '
        'dgSubdocumentos
        '
        Me.dgSubdocumentos.AllowUserToAddRows = False
        Me.dgSubdocumentos.AllowUserToDeleteRows = False
        Me.dgSubdocumentos.AllowUserToOrderColumns = True
        Me.dgSubdocumentos.BackgroundColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle16.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle16.BackColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle16.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle16.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle16.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle16.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle16.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.dgSubdocumentos.ColumnHeadersDefaultCellStyle = DataGridViewCellStyle16
        Me.dgSubdocumentos.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgSubdocumentos.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.colDescripcion, Me.colDocumento, Me.colDatos})
        DataGridViewCellStyle17.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle17.BackColor = System.Drawing.SystemColors.Window
        DataGridViewCellStyle17.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle17.ForeColor = System.Drawing.SystemColors.ControlText
        DataGridViewCellStyle17.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle17.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle17.WrapMode = System.Windows.Forms.DataGridViewTriState.[False]
        Me.dgSubdocumentos.DefaultCellStyle = DataGridViewCellStyle17
        Me.dgSubdocumentos.Dock = System.Windows.Forms.DockStyle.Fill
        Me.dgSubdocumentos.Location = New System.Drawing.Point(0, 0)
        Me.dgSubdocumentos.Name = "dgSubdocumentos"
        DataGridViewCellStyle18.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle18.BackColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle18.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle18.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle18.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle18.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle18.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.dgSubdocumentos.RowHeadersDefaultCellStyle = DataGridViewCellStyle18
        Me.dgSubdocumentos.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.dgSubdocumentos.Size = New System.Drawing.Size(243, 51)
        Me.dgSubdocumentos.TabIndex = 0
        '
        'colDescripcion
        '
        Me.colDescripcion.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.colDescripcion.HeaderText = "Description"
        Me.colDescripcion.Name = "colDescripcion"
        Me.colDescripcion.Visible = False
        '
        'colDocumento
        '
        Me.colDocumento.HeaderText = "Document"
        Me.colDocumento.Name = "colDocumento"
        '
        'colDatos
        '
        Me.colDatos.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill
        Me.colDatos.HeaderText = "Data"
        Me.colDatos.Name = "colDatos"
        Me.colDatos.ReadOnly = True
        Me.colDatos.Resizable = System.Windows.Forms.DataGridViewTriState.[True]
        Me.colDatos.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic
        '
        'Panel1
        '
        Me.Panel1.Controls.Add(Me.panelComplementoTotales)
        Me.Panel1.Controls.Add(Me.etiquetaSubTotal)
        Me.Panel1.Controls.Add(Me.celdaSubTotal)
        Me.Panel1.Controls.Add(Me.EtiquetaImpuesto)
        Me.Panel1.Controls.Add(Me.celdaIva)
        Me.Panel1.Controls.Add(Me.etiquetaExepto)
        Me.Panel1.Controls.Add(Me.celdaExepcion)
        Me.Panel1.Controls.Add(Me.Label2)
        Me.Panel1.Controls.Add(Me.celdaObservaciones)
        Me.Panel1.Controls.Add(Me.etiquetaTotales)
        Me.Panel1.Controls.Add(Me.celdaTotal)
        Me.Panel1.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel1.Location = New System.Drawing.Point(0, 0)
        Me.Panel1.Margin = New System.Windows.Forms.Padding(2)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(1153, 62)
        Me.Panel1.TabIndex = 23
        '
        'panelComplementoTotales
        '
        Me.panelComplementoTotales.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.panelComplementoTotales.Controls.Add(Me.etiquetaComplemento)
        Me.panelComplementoTotales.Controls.Add(Me.celdaTotalDocumento)
        Me.panelComplementoTotales.Controls.Add(Me.Label4)
        Me.panelComplementoTotales.Controls.Add(Me.celdaTotalDetalle)
        Me.panelComplementoTotales.Controls.Add(Me.Label3)
        Me.panelComplementoTotales.Controls.Add(Me.celdaTotalComplemento)
        Me.panelComplementoTotales.Location = New System.Drawing.Point(676, 0)
        Me.panelComplementoTotales.Name = "panelComplementoTotales"
        Me.panelComplementoTotales.Size = New System.Drawing.Size(477, 61)
        Me.panelComplementoTotales.TabIndex = 29
        Me.panelComplementoTotales.Visible = False
        '
        'celdaTotalDocumento
        '
        Me.celdaTotalDocumento.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.celdaTotalDocumento.BackColor = System.Drawing.SystemColors.Info
        Me.celdaTotalDocumento.Enabled = False
        Me.celdaTotalDocumento.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.celdaTotalDocumento.Location = New System.Drawing.Point(371, 33)
        Me.celdaTotalDocumento.Name = "celdaTotalDocumento"
        Me.celdaTotalDocumento.ReadOnly = True
        Me.celdaTotalDocumento.Size = New System.Drawing.Size(103, 24)
        Me.celdaTotalDocumento.TabIndex = 32
        Me.celdaTotalDocumento.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'Label4
        '
        Me.Label4.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label4.AutoSize = True
        Me.Label4.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.Location = New System.Drawing.Point(270, 36)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(97, 13)
        Me.Label4.TabIndex = 31
        Me.Label4.Text = "Total Document"
        Me.Label4.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'celdaTotalDetalle
        '
        Me.celdaTotalDetalle.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.celdaTotalDetalle.BackColor = System.Drawing.SystemColors.Info
        Me.celdaTotalDetalle.Enabled = False
        Me.celdaTotalDetalle.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.celdaTotalDetalle.Location = New System.Drawing.Point(371, 3)
        Me.celdaTotalDetalle.Name = "celdaTotalDetalle"
        Me.celdaTotalDetalle.ReadOnly = True
        Me.celdaTotalDetalle.Size = New System.Drawing.Size(103, 24)
        Me.celdaTotalDetalle.TabIndex = 30
        Me.celdaTotalDetalle.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'Label3
        '
        Me.Label3.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.Location = New System.Drawing.Point(292, 6)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(73, 13)
        Me.Label3.TabIndex = 29
        Me.Label3.Text = "Detail Total"
        Me.Label3.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'celdaTotalComplemento
        '
        Me.celdaTotalComplemento.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.celdaTotalComplemento.BackColor = System.Drawing.SystemColors.Info
        Me.celdaTotalComplemento.Enabled = False
        Me.celdaTotalComplemento.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.celdaTotalComplemento.Location = New System.Drawing.Point(158, 2)
        Me.celdaTotalComplemento.Name = "celdaTotalComplemento"
        Me.celdaTotalComplemento.ReadOnly = True
        Me.celdaTotalComplemento.Size = New System.Drawing.Size(103, 24)
        Me.celdaTotalComplemento.TabIndex = 28
        Me.celdaTotalComplemento.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'etiquetaComplemento
        '
        Me.etiquetaComplemento.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.etiquetaComplemento.AutoSize = True
        Me.etiquetaComplemento.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.etiquetaComplemento.Location = New System.Drawing.Point(8, 6)
        Me.etiquetaComplemento.Name = "etiquetaComplemento"
        Me.etiquetaComplemento.Size = New System.Drawing.Size(144, 13)
        Me.etiquetaComplemento.TabIndex = 27
        Me.etiquetaComplemento.Text = "Another's Account Total"
        Me.etiquetaComplemento.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'etiquetaSubTotal
        '
        Me.etiquetaSubTotal.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.etiquetaSubTotal.AutoSize = True
        Me.etiquetaSubTotal.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.etiquetaSubTotal.Location = New System.Drawing.Point(946, 7)
        Me.etiquetaSubTotal.Name = "etiquetaSubTotal"
        Me.etiquetaSubTotal.Size = New System.Drawing.Size(62, 13)
        Me.etiquetaSubTotal.TabIndex = 25
        Me.etiquetaSubTotal.Text = "Sub-Total"
        '
        'celdaSubTotal
        '
        Me.celdaSubTotal.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.celdaSubTotal.BackColor = System.Drawing.SystemColors.Info
        Me.celdaSubTotal.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.celdaSubTotal.Location = New System.Drawing.Point(1011, 6)
        Me.celdaSubTotal.Name = "celdaSubTotal"
        Me.celdaSubTotal.ReadOnly = True
        Me.celdaSubTotal.Size = New System.Drawing.Size(103, 24)
        Me.celdaSubTotal.TabIndex = 26
        Me.celdaSubTotal.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'EtiquetaImpuesto
        '
        Me.EtiquetaImpuesto.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.EtiquetaImpuesto.AutoSize = True
        Me.EtiquetaImpuesto.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.EtiquetaImpuesto.Location = New System.Drawing.Point(799, 7)
        Me.EtiquetaImpuesto.Name = "EtiquetaImpuesto"
        Me.EtiquetaImpuesto.Size = New System.Drawing.Size(53, 18)
        Me.EtiquetaImpuesto.TabIndex = 23
        Me.EtiquetaImpuesto.Text = "Taxes"
        '
        'celdaIva
        '
        Me.celdaIva.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.celdaIva.BackColor = System.Drawing.SystemColors.Info
        Me.celdaIva.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.celdaIva.Location = New System.Drawing.Point(855, 5)
        Me.celdaIva.Name = "celdaIva"
        Me.celdaIva.ReadOnly = True
        Me.celdaIva.Size = New System.Drawing.Size(85, 24)
        Me.celdaIva.TabIndex = 24
        Me.celdaIva.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'etiquetaExepto
        '
        Me.etiquetaExepto.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.etiquetaExepto.AutoSize = True
        Me.etiquetaExepto.Cursor = System.Windows.Forms.Cursors.Default
        Me.etiquetaExepto.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.etiquetaExepto.Location = New System.Drawing.Point(772, 37)
        Me.etiquetaExepto.Name = "etiquetaExepto"
        Me.etiquetaExepto.Size = New System.Drawing.Size(81, 13)
        Me.etiquetaExepto.TabIndex = 21
        Me.etiquetaExepto.Text = "Exempt sales"
        '
        'celdaExepcion
        '
        Me.celdaExepcion.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.celdaExepcion.BackColor = System.Drawing.SystemColors.Info
        Me.celdaExepcion.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.celdaExepcion.ForeColor = System.Drawing.Color.Red
        Me.celdaExepcion.Location = New System.Drawing.Point(855, 32)
        Me.celdaExepcion.Name = "celdaExepcion"
        Me.celdaExepcion.ReadOnly = True
        Me.celdaExepcion.Size = New System.Drawing.Size(85, 24)
        Me.celdaExepcion.TabIndex = 22
        Me.celdaExepcion.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(26, 2)
        Me.Label2.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(69, 13)
        Me.Label2.TabIndex = 20
        Me.Label2.Text = "Observations"
        '
        'celdaObservaciones
        '
        Me.celdaObservaciones.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.celdaObservaciones.Location = New System.Drawing.Point(3, 19)
        Me.celdaObservaciones.Margin = New System.Windows.Forms.Padding(2)
        Me.celdaObservaciones.Multiline = True
        Me.celdaObservaciones.Name = "celdaObservaciones"
        Me.celdaObservaciones.Size = New System.Drawing.Size(650, 41)
        Me.celdaObservaciones.TabIndex = 19
        '
        'etiquetaTotales
        '
        Me.etiquetaTotales.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.etiquetaTotales.AutoSize = True
        Me.etiquetaTotales.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.etiquetaTotales.Location = New System.Drawing.Point(954, 34)
        Me.etiquetaTotales.Name = "etiquetaTotales"
        Me.etiquetaTotales.Size = New System.Drawing.Size(46, 18)
        Me.etiquetaTotales.TabIndex = 3
        Me.etiquetaTotales.Text = "Total"
        '
        'celdaTotal
        '
        Me.celdaTotal.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.celdaTotal.BackColor = System.Drawing.SystemColors.Info
        Me.celdaTotal.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.celdaTotal.Location = New System.Drawing.Point(1011, 32)
        Me.celdaTotal.Name = "celdaTotal"
        Me.celdaTotal.ReadOnly = True
        Me.celdaTotal.Size = New System.Drawing.Size(103, 24)
        Me.celdaTotal.TabIndex = 18
        Me.celdaTotal.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'botonISR
        '
        Me.botonISR.Location = New System.Drawing.Point(406, 8)
        Me.botonISR.Margin = New System.Windows.Forms.Padding(2)
        Me.botonISR.Name = "botonISR"
        Me.botonISR.Size = New System.Drawing.Size(62, 46)
        Me.botonISR.TabIndex = 7
        Me.botonISR.Text = "ISR"
        Me.botonISR.UseVisualStyleBackColor = True
        '
        'botonInprimir
        '
        Me.botonInprimir.Image = Global.KARIMs_SGI.My.Resources.Resources.print
        Me.botonInprimir.Location = New System.Drawing.Point(202, 10)
        Me.botonInprimir.Name = "botonInprimir"
        Me.botonInprimir.Size = New System.Drawing.Size(59, 45)
        Me.botonInprimir.TabIndex = 21
        Me.botonInprimir.Text = "Print"
        Me.botonInprimir.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.botonInprimir.UseVisualStyleBackColor = True
        '
        'etiquetaAutorizacion
        '
        Me.etiquetaAutorizacion.AutoSize = True
        Me.etiquetaAutorizacion.Location = New System.Drawing.Point(358, 74)
        Me.etiquetaAutorizacion.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.etiquetaAutorizacion.Name = "etiquetaAutorizacion"
        Me.etiquetaAutorizacion.Size = New System.Drawing.Size(39, 13)
        Me.etiquetaAutorizacion.TabIndex = 32
        Me.etiquetaAutorizacion.Text = "Label4"
        Me.etiquetaAutorizacion.Visible = False
        '
        'etiquetaSerie
        '
        Me.etiquetaSerie.AutoSize = True
        Me.etiquetaSerie.Location = New System.Drawing.Point(296, 74)
        Me.etiquetaSerie.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.etiquetaSerie.Name = "etiquetaSerie"
        Me.etiquetaSerie.Size = New System.Drawing.Size(39, 13)
        Me.etiquetaSerie.TabIndex = 31
        Me.etiquetaSerie.Text = "Label4"
        Me.etiquetaSerie.Visible = False
        '
        'botonPrevio
        '
        Me.botonPrevio.Image = Global.KARIMs_SGI.My.Resources.Resources.search1
        Me.botonPrevio.Location = New System.Drawing.Point(270, 13)
        Me.botonPrevio.Name = "botonPrevio"
        Me.botonPrevio.Size = New System.Drawing.Size(65, 42)
        Me.botonPrevio.TabIndex = 34
        Me.botonPrevio.Text = "Preview"
        Me.botonPrevio.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.botonPrevio.UseVisualStyleBackColor = True
        '
        'BarraTitulo1
        '
        Me.BarraTitulo1.BackColor = System.Drawing.Color.WhiteSmoke
        Me.BarraTitulo1.Dock = System.Windows.Forms.DockStyle.Top
        Me.BarraTitulo1.Location = New System.Drawing.Point(0, 70)
        Me.BarraTitulo1.Margin = New System.Windows.Forms.Padding(4)
        Me.BarraTitulo1.Name = "BarraTitulo1"
        Me.BarraTitulo1.Size = New System.Drawing.Size(1158, 30)
        Me.BarraTitulo1.TabIndex = 3
        '
        'Encabezado1
        '
        Me.Encabezado1.Dock = System.Windows.Forms.DockStyle.Top
        Me.Encabezado1.Location = New System.Drawing.Point(0, 0)
        Me.Encabezado1.Margin = New System.Windows.Forms.Padding(4)
        Me.Encabezado1.Name = "Encabezado1"
        Me.Encabezado1.Size = New System.Drawing.Size(1158, 70)
        Me.Encabezado1.TabIndex = 2
        '
        'frmFacturaIva
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1158, 663)
        Me.Controls.Add(Me.botonPrevio)
        Me.Controls.Add(Me.etiquetaAutorizacion)
        Me.Controls.Add(Me.etiquetaSerie)
        Me.Controls.Add(Me.botonInprimir)
        Me.Controls.Add(Me.botonISR)
        Me.Controls.Add(Me.panelDocumento)
        Me.Controls.Add(Me.panelLista)
        Me.Controls.Add(Me.BarraTitulo1)
        Me.Controls.Add(Me.Encabezado1)
        Me.Margin = New System.Windows.Forms.Padding(2)
        Me.Name = "frmFacturaIva"
        Me.Text = "frmFacturaIva"
        Me.WindowState = System.Windows.Forms.FormWindowState.Maximized
        Me.panelLista.ResumeLayout(False)
        CType(Me.dgLista, System.ComponentModel.ISupportInitialize).EndInit()
        Me.panelColores.ResumeLayout(False)
        Me.panelColores.PerformLayout()
        Me.panelEncabLista.ResumeLayout(False)
        Me.panelEncabLista.PerformLayout()
        Me.panelDocumento.ResumeLayout(False)
        Me.Panel4.ResumeLayout(False)
        Me.Panel4.PerformLayout()
        Me.PanelDtalle.ResumeLayout(False)
        CType(Me.dgDetalle, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Panel3.ResumeLayout(False)
        Me.PanelComplemento.ResumeLayout(False)
        CType(Me.dgComplemento, System.ComponentModel.ISupportInitialize).EndInit()
        Me.PanelComplementoBotones.ResumeLayout(False)
        Me.panelEncabezado.ResumeLayout(False)
        Me.panelInstrucciones.ResumeLayout(False)
        Me.panelInfo.ResumeLayout(False)
        Me.panelInfo.PerformLayout()
        Me.panelExtras.ResumeLayout(False)
        Me.panelExtras.PerformLayout()
        Me.panelEncabezadoInstr.ResumeLayout(False)
        Me.GroupBox1.ResumeLayout(False)
        CType(Me.dgFactrura, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Panel2.ResumeLayout(False)
        Me.gbInvoiceInfo.ResumeLayout(False)
        Me.gbInvoiceInfo.PerformLayout()
        Me.panelInfoFinal.ResumeLayout(False)
        Me.panelDatos.ResumeLayout(False)
        CType(Me.dgDatos, System.ComponentModel.ISupportInitialize).EndInit()
        Me.panelSubDocumentos.ResumeLayout(False)
        CType(Me.dgSubdocumentos, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        Me.panelComplementoTotales.ResumeLayout(False)
        Me.panelComplementoTotales.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents BarraTitulo1 As KARIMs_SGI.BarraTitulo
    Friend WithEvents Encabezado1 As KARIMs_SGI.encabezado
    Friend WithEvents panelLista As System.Windows.Forms.Panel
    Friend WithEvents panelEncabLista As System.Windows.Forms.Panel
    Friend WithEvents botonEntrega As System.Windows.Forms.Button
    Friend WithEvents botonActualizar As System.Windows.Forms.Button
    Friend WithEvents etiquetaAnd As System.Windows.Forms.Label
    Friend WithEvents dtpFin As System.Windows.Forms.DateTimePicker
    Friend WithEvents dtpInicio As System.Windows.Forms.DateTimePicker
    Friend WithEvents checkFecha As System.Windows.Forms.CheckBox
    Friend WithEvents panelColores As System.Windows.Forms.Panel
    Friend WithEvents celdaColorAmarillo As System.Windows.Forms.TextBox
    Friend WithEvents celdaColorRojo As System.Windows.Forms.TextBox
    Friend WithEvents etiquetaNoImpreso As System.Windows.Forms.Label
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents dgLista As System.Windows.Forms.DataGridView
    Friend WithEvents panelDocumento As System.Windows.Forms.Panel
    Friend WithEvents panelInfoFinal As System.Windows.Forms.Panel
    Friend WithEvents celdaTotal As System.Windows.Forms.TextBox
    Friend WithEvents etiquetaTotales As System.Windows.Forms.Label
    Friend WithEvents panelSubDocumentos As System.Windows.Forms.Panel
    Friend WithEvents dgSubdocumentos As System.Windows.Forms.DataGridView
    Friend WithEvents colDescripcion As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colDocumento As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colDatos As System.Windows.Forms.DataGridViewButtonColumn
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents celdaNotas As System.Windows.Forms.TextBox
    Friend WithEvents gbInvoiceInfo As System.Windows.Forms.GroupBox
    Friend WithEvents dtpFecha As System.Windows.Forms.DateTimePicker
    Friend WithEvents etiquetaAnulada As System.Windows.Forms.Label
    Friend WithEvents botonPolizaC As System.Windows.Forms.Button
    Friend WithEvents botonMoneda As System.Windows.Forms.Button
    Friend WithEvents celdaIdCliente As System.Windows.Forms.TextBox
    Friend WithEvents botonCliente As System.Windows.Forms.Button
    Friend WithEvents checkActivar As System.Windows.Forms.CheckBox
    Friend WithEvents celdaSerie As System.Windows.Forms.TextBox
    Friend WithEvents celdaTasa As System.Windows.Forms.TextBox
    Friend WithEvents etiquetaTasa As System.Windows.Forms.Label
    Friend WithEvents celdaMoneda As System.Windows.Forms.TextBox
    Friend WithEvents celdaNIT As System.Windows.Forms.TextBox
    Friend WithEvents celdaTelefono As System.Windows.Forms.TextBox
    Friend WithEvents celdaDireccion As System.Windows.Forms.TextBox
    Friend WithEvents celdaCliente As System.Windows.Forms.TextBox
    Friend WithEvents celdaNumero As System.Windows.Forms.TextBox
    Friend WithEvents celdaAño As System.Windows.Forms.TextBox
    Friend WithEvents etiquetaMoneda As System.Windows.Forms.Label
    Friend WithEvents etiquetaNit As System.Windows.Forms.Label
    Friend WithEvents etiquetaTelefono As System.Windows.Forms.Label
    Friend WithEvents etiquetaCliente As System.Windows.Forms.Label
    Friend WithEvents etiquetaDireccion As System.Windows.Forms.Label
    Friend WithEvents etiquetaNumero As System.Windows.Forms.Label
    Friend WithEvents etiquetaFecha As System.Windows.Forms.Label
    Friend WithEvents etiquetaAño As System.Windows.Forms.Label
    Friend WithEvents dgDatos As System.Windows.Forms.DataGridView
    Friend WithEvents colNombre As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colConcepto As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colMonto As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colTC As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colCargo As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colAbono As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colDias As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
    Friend WithEvents dgFactrura As System.Windows.Forms.DataGridView
    Friend WithEvents panelEncabezado As System.Windows.Forms.Panel
    Friend WithEvents celdaObservaciones As System.Windows.Forms.TextBox
    Friend WithEvents dgDetalle As System.Windows.Forms.DataGridView
    Friend WithEvents Panel2 As System.Windows.Forms.Panel
    Friend WithEvents botonRefacturar As System.Windows.Forms.Button
    Friend WithEvents botonISR As System.Windows.Forms.Button
    Friend WithEvents botonInprimir As System.Windows.Forms.Button
    Friend WithEvents botonQuitar As System.Windows.Forms.Button
    Friend WithEvents botonAgregar As System.Windows.Forms.Button
    Friend WithEvents celdaIdMoneda As System.Windows.Forms.TextBox
    Friend WithEvents ColYearF As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents ColInvoiceF As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents ColDateF As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents ColRefF As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents ColWeightF As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents celdaCorrelativo As System.Windows.Forms.TextBox
    Friend WithEvents etiquetaExepto As System.Windows.Forms.Label
    Friend WithEvents celdaExepcion As System.Windows.Forms.TextBox
    Friend WithEvents EtiquetaImpuesto As System.Windows.Forms.Label
    Friend WithEvents celdaIva As System.Windows.Forms.TextBox
    Friend WithEvents etiquetaSubTotal As System.Windows.Forms.Label
    Friend WithEvents celdaSubTotal As System.Windows.Forms.TextBox
    Friend WithEvents celdaOrden As System.Windows.Forms.TextBox
    Friend WithEvents panelInstrucciones As Panel
    Friend WithEvents panelInfo As Panel
    Friend WithEvents panelEncabezadoInstr As Panel
    Friend WithEvents panelExtras As Panel
    Friend WithEvents celdaGiro As TextBox
    Friend WithEvents etiquetaGiro As Label
    Friend WithEvents celdaRegistro As TextBox
    Friend WithEvents etiquetaRegistro As Label
    Friend WithEvents celdaUUID As TextBox
    Friend WithEvents celdaFechaEmisionDocumento As TextBox
    Friend WithEvents celdaFechaHoraCertificacion As TextBox
    Friend WithEvents celdaSerieFel As TextBox
    Friend WithEvents etiquetaAutorizacion As Label
    Friend WithEvents etiquetaSerie As Label
    Friend WithEvents botonPrevio As Button
    Friend WithEvents colCat As DataGridViewTextBoxColumn
    Friend WithEvents colAno As DataGridViewTextBoxColumn
    Friend WithEvents colNum As DataGridViewTextBoxColumn
    Friend WithEvents colFecha As DataGridViewTextBoxColumn
    Friend WithEvents colCliente As DataGridViewTextBoxColumn
    Friend WithEvents colFact As DataGridViewTextBoxColumn
    Friend WithEvents colTotal As DataGridViewTextBoxColumn
    Friend WithEvents colSerieF As DataGridViewTextBoxColumn
    Friend WithEvents colAutorizacionF As DataGridViewTextBoxColumn
    Friend WithEvents ColLinea As DataGridViewTextBoxColumn
    Friend WithEvents ColCodigo As DataGridViewTextBoxColumn
    Friend WithEvents colDes As DataGridViewTextBoxColumn
    Friend WithEvents colIdMedida As DataGridViewTextBoxColumn
    Friend WithEvents colMedida As DataGridViewTextBoxColumn
    Friend WithEvents colBulto As DataGridViewTextBoxColumn
    Friend WithEvents colTipoBulto As DataGridViewTextBoxColumn
    Friend WithEvents colPrecio As DataGridViewTextBoxColumn
    Friend WithEvents colDescP As DataGridViewTextBoxColumn
    Friend WithEvents ColDesD As DataGridViewTextBoxColumn
    Friend WithEvents colCantidad As DataGridViewTextBoxColumn
    Friend WithEvents colReferencia As DataGridViewTextBoxColumn
    Friend WithEvents colID As DataGridViewTextBoxColumn
    Friend WithEvents ColAnio As DataGridViewTextBoxColumn
    Friend WithEvents ColNumero As DataGridViewTextBoxColumn
    Friend WithEvents colLineF As DataGridViewTextBoxColumn
    Friend WithEvents ColDestino As DataGridViewTextBoxColumn
    Friend WithEvents ColFlete As DataGridViewTextBoxColumn
    Friend WithEvents colAgente As DataGridViewTextBoxColumn
    Friend WithEvents ColGestiones As DataGridViewTextBoxColumn
    Friend WithEvents colOtros As DataGridViewTextBoxColumn
    Friend WithEvents colImpuesto As DataGridViewTextBoxColumn
    Friend WithEvents colExepcion As DataGridViewTextBoxColumn
    Friend WithEvents colSubTotal As DataGridViewTextBoxColumn
    Friend WithEvents colCtaAjena As DataGridViewTextBoxColumn
    Friend WithEvents colCtaAjenaValor As DataGridViewTextBoxColumn
    Friend WithEvents colTotal_ As DataGridViewTextBoxColumn
    Friend WithEvents colExtra As DataGridViewTextBoxColumn
    Friend WithEvents PanelComplemento As Panel
    Friend WithEvents dgComplemento As DataGridView
    Friend WithEvents colLinComplemento As DataGridViewTextBoxColumn
    Friend WithEvents colRelatedDocument As DataGridViewTextBoxColumn
    Friend WithEvents colDate As DataGridViewTextBoxColumn
    Friend WithEvents colComplemento As DataGridViewTextBoxColumn
    Friend WithEvents colComplementoValor As DataGridViewTextBoxColumn
    Friend WithEvents colExtraComplemento As DataGridViewTextBoxColumn
    Friend WithEvents PanelComplementoBotones As Panel
    Friend WithEvents buttonDelComplemento As Button
    Friend WithEvents buttonAddcomplemento As Button
    Friend WithEvents PanelDtalle As Panel
    Friend WithEvents Panel3 As Panel
    Friend WithEvents Button1 As Button
    Friend WithEvents Button2 As Button
    Public WithEvents panelDatos As Panel
    Friend WithEvents Panel4 As Panel
    Friend WithEvents panelComplementoTotales As Panel
    Friend WithEvents celdaTotalDetalle As TextBox
    Friend WithEvents Label3 As Label
    Friend WithEvents celdaTotalComplemento As TextBox
    Friend WithEvents etiquetaComplemento As Label
    Friend WithEvents celdaTotalDocumento As TextBox
    Friend WithEvents Label4 As Label
End Class
