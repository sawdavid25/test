﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmCentrosCostos
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.paneldocumento = New System.Windows.Forms.Panel()
        Me.celdadescripcion = New System.Windows.Forms.TextBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.celdanombre = New System.Windows.Forms.TextBox()
        Me.celdacodigo = New System.Windows.Forms.TextBox()
        Me.lblnombre = New System.Windows.Forms.Label()
        Me.lblccosto = New System.Windows.Forms.Label()
        Me.id_Ccosto = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Centro_costo = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Estado = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn1 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn2 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn3 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.panelLista = New System.Windows.Forms.Panel()
        Me.dglista = New System.Windows.Forms.DataGridView()
        Me.BarraTitulo1 = New KARIMs_SGI.BarraTitulo()
        Me.Encabezado1 = New KARIMs_SGI.encabezado()
        Me.Número = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Nombre = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Descripción = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.paneldocumento.SuspendLayout()
        Me.panelLista.SuspendLayout()
        CType(Me.dglista, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'paneldocumento
        '
        Me.paneldocumento.Controls.Add(Me.celdadescripcion)
        Me.paneldocumento.Controls.Add(Me.Label1)
        Me.paneldocumento.Controls.Add(Me.celdanombre)
        Me.paneldocumento.Controls.Add(Me.celdacodigo)
        Me.paneldocumento.Controls.Add(Me.lblnombre)
        Me.paneldocumento.Controls.Add(Me.lblccosto)
        Me.paneldocumento.Location = New System.Drawing.Point(35, 339)
        Me.paneldocumento.Name = "paneldocumento"
        Me.paneldocumento.Size = New System.Drawing.Size(395, 132)
        Me.paneldocumento.TabIndex = 4
        '
        'celdadescripcion
        '
        Me.celdadescripcion.Location = New System.Drawing.Point(108, 97)
        Me.celdadescripcion.Name = "celdadescripcion"
        Me.celdadescripcion.Size = New System.Drawing.Size(158, 20)
        Me.celdadescripcion.TabIndex = 20
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(35, 100)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(63, 13)
        Me.Label1.TabIndex = 19
        Me.Label1.Text = "Descripción"
        '
        'celdanombre
        '
        Me.celdanombre.Location = New System.Drawing.Point(108, 67)
        Me.celdanombre.Name = "celdanombre"
        Me.celdanombre.Size = New System.Drawing.Size(158, 20)
        Me.celdanombre.TabIndex = 8
        '
        'celdacodigo
        '
        Me.celdacodigo.Enabled = False
        Me.celdacodigo.Location = New System.Drawing.Point(108, 29)
        Me.celdacodigo.Name = "celdacodigo"
        Me.celdacodigo.ReadOnly = True
        Me.celdacodigo.Size = New System.Drawing.Size(51, 20)
        Me.celdacodigo.TabIndex = 6
        '
        'lblnombre
        '
        Me.lblnombre.AutoSize = True
        Me.lblnombre.Location = New System.Drawing.Point(35, 70)
        Me.lblnombre.Name = "lblnombre"
        Me.lblnombre.Size = New System.Drawing.Size(44, 13)
        Me.lblnombre.TabIndex = 2
        Me.lblnombre.Text = "Nombre"
        '
        'lblccosto
        '
        Me.lblccosto.AutoSize = True
        Me.lblccosto.Location = New System.Drawing.Point(35, 29)
        Me.lblccosto.Name = "lblccosto"
        Me.lblccosto.Size = New System.Drawing.Size(40, 13)
        Me.lblccosto.TabIndex = 1
        Me.lblccosto.Text = "Código"
        '
        'id_Ccosto
        '
        Me.id_Ccosto.HeaderText = "id_Ccosto"
        Me.id_Ccosto.Name = "id_Ccosto"
        Me.id_Ccosto.ReadOnly = True
        '
        'Centro_costo
        '
        Me.Centro_costo.HeaderText = "Centro de costo"
        Me.Centro_costo.Name = "Centro_costo"
        Me.Centro_costo.ReadOnly = True
        '
        'Estado
        '
        Me.Estado.HeaderText = "Estado"
        Me.Estado.Name = "Estado"
        '
        'DataGridViewTextBoxColumn1
        '
        Me.DataGridViewTextBoxColumn1.HeaderText = "id_Ccosto"
        Me.DataGridViewTextBoxColumn1.Name = "DataGridViewTextBoxColumn1"
        Me.DataGridViewTextBoxColumn1.ReadOnly = True
        '
        'DataGridViewTextBoxColumn2
        '
        Me.DataGridViewTextBoxColumn2.HeaderText = "Centro de costo"
        Me.DataGridViewTextBoxColumn2.Name = "DataGridViewTextBoxColumn2"
        Me.DataGridViewTextBoxColumn2.ReadOnly = True
        '
        'DataGridViewTextBoxColumn3
        '
        Me.DataGridViewTextBoxColumn3.HeaderText = "Estado"
        Me.DataGridViewTextBoxColumn3.Name = "DataGridViewTextBoxColumn3"
        '
        'panelLista
        '
        Me.panelLista.Controls.Add(Me.dglista)
        Me.panelLista.Location = New System.Drawing.Point(57, 132)
        Me.panelLista.Name = "panelLista"
        Me.panelLista.Size = New System.Drawing.Size(333, 125)
        Me.panelLista.TabIndex = 5
        '
        'dglista
        '
        Me.dglista.AllowUserToAddRows = False
        Me.dglista.AllowUserToDeleteRows = False
        Me.dglista.BackgroundColor = System.Drawing.SystemColors.Control
        Me.dglista.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dglista.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.Número, Me.Nombre, Me.Descripción})
        Me.dglista.Dock = System.Windows.Forms.DockStyle.Fill
        Me.dglista.Location = New System.Drawing.Point(0, 0)
        Me.dglista.MultiSelect = False
        Me.dglista.Name = "dglista"
        Me.dglista.ReadOnly = True
        Me.dglista.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.dglista.Size = New System.Drawing.Size(333, 125)
        Me.dglista.TabIndex = 0
        '
        'BarraTitulo1
        '
        Me.BarraTitulo1.BackColor = System.Drawing.Color.WhiteSmoke
        Me.BarraTitulo1.Dock = System.Windows.Forms.DockStyle.Top
        Me.BarraTitulo1.Location = New System.Drawing.Point(0, 72)
        Me.BarraTitulo1.Name = "BarraTitulo1"
        Me.BarraTitulo1.Size = New System.Drawing.Size(489, 30)
        Me.BarraTitulo1.TabIndex = 7
        '
        'Encabezado1
        '
        Me.Encabezado1.Dock = System.Windows.Forms.DockStyle.Top
        Me.Encabezado1.Location = New System.Drawing.Point(0, 0)
        Me.Encabezado1.Name = "Encabezado1"
        Me.Encabezado1.Size = New System.Drawing.Size(489, 72)
        Me.Encabezado1.TabIndex = 6
        '
        'Número
        '
        Me.Número.HeaderText = "No"
        Me.Número.Name = "Número"
        Me.Número.ReadOnly = True
        '
        'Nombre
        '
        Me.Nombre.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.Nombre.HeaderText = "Nombre"
        Me.Nombre.Name = "Nombre"
        Me.Nombre.ReadOnly = True
        Me.Nombre.Width = 69
        '
        'Descripción
        '
        Me.Descripción.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.Descripción.HeaderText = "Descripción"
        Me.Descripción.Name = "Descripción"
        Me.Descripción.ReadOnly = True
        Me.Descripción.Width = 88
        '
        'frmCentrosCostos
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(489, 502)
        Me.Controls.Add(Me.paneldocumento)
        Me.Controls.Add(Me.panelLista)
        Me.Controls.Add(Me.BarraTitulo1)
        Me.Controls.Add(Me.Encabezado1)
        Me.Name = "frmCentrosCostos"
        Me.Text = "frmCentrosCostos"
        Me.paneldocumento.ResumeLayout(False)
        Me.paneldocumento.PerformLayout()
        Me.panelLista.ResumeLayout(False)
        CType(Me.dglista, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents paneldocumento As Panel
    Friend WithEvents celdadescripcion As TextBox
    Friend WithEvents Label1 As Label
    Friend WithEvents celdanombre As TextBox
    Friend WithEvents celdacodigo As TextBox
    Friend WithEvents lblnombre As Label
    Friend WithEvents lblccosto As Label
    Friend WithEvents id_Ccosto As DataGridViewTextBoxColumn
    Friend WithEvents Centro_costo As DataGridViewTextBoxColumn
    Friend WithEvents Estado As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn1 As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn2 As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn3 As DataGridViewTextBoxColumn
    Friend WithEvents panelLista As Panel
    Friend WithEvents dglista As DataGridView
    Friend WithEvents Encabezado1 As encabezado
    Friend WithEvents BarraTitulo1 As BarraTitulo
    Friend WithEvents Número As DataGridViewTextBoxColumn
    Friend WithEvents Nombre As DataGridViewTextBoxColumn
    Friend WithEvents Descripción As DataGridViewTextBoxColumn
End Class
