﻿Public Class frmDebiteNote
#Region "Variables"
    Dim strKey As String = STR_VACIO
    Dim logInsertar As Boolean = False
    Dim logConsultar As Boolean = False
    Dim logEditar As Boolean = False
    Dim LogBorrar As Boolean = False
    Dim strMensaje As String = STR_VACIO
    Dim intPais As Integer = 0
    Dim cfun As New clsFunciones
    Public Const catalogoFactura = 36

    Public Const catalogos = 398
#End Region
#Region "Propiedades"
    Public Property Key As String
        Get
            Return strKey
        End Get
        Set(value As String)
            strKey = value
        End Set
    End Property
#End Region
#Region "Funciones"
    Private Sub Accessos()
        Dim cAccesos As New clsAccesos
        Try
            If cAccesos.Accesos(strKey) = True Then
                logInsertar = cAccesos.Insertar
                logConsultar = cAccesos.Consultar
                logEditar = cAccesos.Editar
                LogBorrar = cAccesos.Borrar
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try

    End Sub

    Private Function verificarPais()
        Dim strsql As String = STR_VACIO
        Dim com As MySqlCommand

        strsql = " Select e.emp_pais From Empresas e Where e.emp_no =  " & Sesion.IdEmpresa
        MyCnn.CONECTAR = strConexion
        com = New MySqlCommand(strsql, CON)

        Return com.ExecuteScalar()

    End Function
    Public Sub LimpiarPanelOrden()
        celdaAño.Text = cFunciones.AñoMySQL
        celdaNumero.Text = -1
        celdaTasa.Text = INT_UNO
        dtpFecha.Text = Now.ToString(FORMATO_MYSQL)
        celdaDireccion.Text = STR_VACIO
        celdaNombreCliente.Text = STR_VACIO
        celdaidCliente.Text = NO_FILA
        celdaTelefono.Text = STR_VACIO
        celdaNit.Text = STR_VACIO
        celdaMoneda.Text = STR_VACIO
        celdaIdMoneda.Text = NO_FILA
        celdaDocumento.Text = STR_VACIO
        celdaAplicante.Text = STR_VACIO
        celdaDireccion2.Text = STR_VACIO
        celdaTotal.Clear()
        celdaCantidad.Clear()

        dgDetalle.Rows.Clear()
        dgFactura.Rows.Clear()
    End Sub
    Private Sub BloquearBotones(Optional ByVal logBloquear As Boolean = True)
        If logBloquear = True Then
            Encabezado1.botonBorrar.Enabled = False
            Encabezado1.botonGuardar.Enabled = False
            Encabezado1.botonNuevo.Enabled = True
            botonImprimir.Enabled = False
        Else
            If LogBorrar = True Then
                Encabezado1.botonBorrar.Enabled = True
            Else
                Encabezado1.botonBorrar.Enabled = False
            End If
            Encabezado1.botonGuardar.Enabled = True
            botonImprimir.Enabled = True
        End If

    End Sub
    Private Sub MostrarLista(Optional ByVal logMostrar As Boolean = True, Optional logInsert As Boolean = False)
        Dim cfun As New clsFunciones
        If logMostrar = True Then
            'ocultar panel de documento
            panelDocumento.Dock = DockStyle.None
            panelDocumento.Visible = False
            'actualizar Titulo
            BarraTitulo1.CambiarTitulo("Debit Note")
            'Cargar Datos
            ' cfun.CargarLista(dgLista, SQLLista, False)
            CargarLista()
            'Mostrar Panel Filtro
            PanelLista.Visible = True
            PanelLista.Dock = DockStyle.Fill
            BloquearBotones()

        Else
            'Ocultar Panel Filtro
            PanelLista.Visible = False
            PanelLista.Dock = DockStyle.None
            'Mostrar panel de documento
            panelDocumento.Dock = DockStyle.Fill
            panelDocumento.Visible = True
            'Verifica si se va a crear un nuevo documento o se va modifica
            If logInsert = False Then
                BarraTitulo1.CambiarTitulo("Modify Register")
                Me.Tag = "Mod"
                BloquearBotones(False)
                '     botonInprimir.Enabled = True
            Else
                BarraTitulo1.CambiarTitulo("New Register")
                Me.Tag = "Nuevo"
                BloquearBotones(False)
                '  botonImprimir.Enabled = False

                Reset()
            End If

            dgLista.DataSource = Nothing
        End If

    End Sub
    Private Function sqlLista() As String
        Dim strSQL As String = STR_VACIO

        strSQL = " SELECT HDoc_Doc_Ano anio, HDoc_Doc_Num numero, HDoc_Doc_Fec fecha, HDoc_Emp_Nom nombre, HDoc_Emp_Per contacto, COALESCE(HDoc_DR1_Num,'') referencia,HDoc_Doc_Status Estado "
        strSQL &= "     FROM Dcmtos_HDR "
        strSQL &= "         WHERE HDoc_Sis_Emp={empresa} AND HDoc_Doc_Cat={catalogo} "
        If checkFiltroFecha.Checked = True Then
            strSQL &= "     AND (HDoc_Doc_Fec BETWEEN '{fechainicial}' AND '{fechafinal}')"
        End If
        strSQL &= "             ORDER BY HDoc_Doc_Ano DESC, HDoc_Doc_Num DESC; "
        strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
        strSQL = Replace(strSQL, "{catalogo}", catalogos)
        strSQL = Replace(strSQL, "{fechainicial}", dtpFechaInicial.Value.ToString(FORMATO_MYSQL))
        strSQL = Replace(strSQL, "{fechafinal}", dtpFechaFinal.Value.ToString(FORMATO_MYSQL))
        Return strSQL
    End Function
    Public Sub CargarLista()
        Dim strSQL As String = STR_VACIO
        Dim strFila As String = STR_VACIO
        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader



        strSQL = sqlLista()
        MyCnn.CONECTAR = strConexion
        COM = New MySqlCommand(strSQL, CON)
        REA = COM.ExecuteReader
        If REA.HasRows Then
            dgLista.Rows.Clear()
            Do While REA.Read
                strFila = REA.GetInt32("anio") & "|"
                strFila &= REA.GetInt32("numero") & "|"
                strFila &= REA.GetDateTime("fecha") & "|"
                strFila &= REA.GetString("nombre") & "|"
                strFila &= REA.GetString("contacto") & "|"
                strFila &= REA.GetString("referencia")
                If REA.GetInt32("Estado") = 0 Then
                    cfun.AgregarFila(dgLista, strFila, Color.Coral)
                Else
                    cfun.AgregarFila(dgLista, strFila)
                End If

            Loop
        End If

    End Sub
    Private Function SQLEncabezado(ByVal codigo As Integer, ByVal Anio As Integer) As String
        Dim strSQL As String = STR_VACIO
        strSQL = "  SELECT e.HDoc_Doc_Cat Catalogo, e.HDoc_Doc_Ano Anio , e.HDoc_Doc_Status Estado,e.HDoc_Doc_Num Numero,e.HDoc_Doc_Fec Fecha, e.HDoc_Emp_Cod Codigo, e.HDoc_Emp_Nom Nombre, e.HDoc_Emp_Dir Direccion , e.HDoc_Emp_Per Contacto , e.HDoc_Emp_Tel Telefono , e.HDoc_Emp_NIT Nit ,e.HDoc_Doc_Mon idMoneda,cc.cat_clave Moneda,e.HDoc_Doc_TC Tasa, e.HDoc_DR1_Num  Documento,e.HDoc_DR1_Emp Aplicante , c.cli_cliente Cliente,e.HDoc_RF1_Txt Direccion2 "
        strSQL &= "     FROM Dcmtos_HDR e "
        strSQL &= "         LEFT JOIN Clientes c ON c.cli_sisemp = e.HDoc_Sis_Emp AND c.cli_codigo = e.HDoc_DR1_Emp "
        strSQL &= "             LEFT JOIN Catalogos cc ON cc.cat_num = e.HDoc_Doc_Mon AND cc.cat_clase = 'Monedas' "
        strSQL &= "                 WHERE e.HDoc_Sis_Emp={empresa} AND e.HDoc_Doc_Cat={catalogo} AND e.HDoc_Doc_Ano={anio} AND e.HDoc_Doc_Num={numero} "
        strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
        strSQL = Replace(strSQL, "{catalogo}", catalogos)
        strSQL = Replace(strSQL, "{anio}", Anio)
        strSQL = Replace(strSQL, "{numero}", codigo)
        Return strSQL
    End Function
    Public Sub CargarEncabezado(ByVal Codigo As Integer, ByVal Anio As Integer)
        Dim strSQL As String
        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader
        Try
            strSQL = SQLEncabezado(Codigo, Anio)
            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSQL, CON)
            REA = COM.ExecuteReader
            If REA.HasRows Then
                Do While REA.Read
                    celdaAño.Text = REA.GetInt32("Anio")
                    celdaNumero.Text = REA.GetInt32("Numero")
                    If REA.GetInt32("Estado") = 1 Then
                        checkActive.Checked = True
                    Else
                        checkActive.Checked = False
                        checkActive.Enabled = False
                    End If
                    dtpFecha.Value = REA.GetDateTime("Fecha").ToString(FORMATO_MYSQL)
                    celdaidCliente.Text = REA.GetInt32("Codigo")
                    celdaNombreCliente.Text = REA.GetString("Nombre")
                    celdaDireccion.Text = REA.GetString("Direccion")
                    celdaContacto.Text = REA.GetString("Contacto")
                    celdaTelefono.Text = REA.GetString("Telefono")
                    celdaNit.Text = REA.GetString("Nit")
                    celdaIdMoneda.Text = REA.GetInt32("idMoneda")
                    celdaMoneda.Text = REA.GetString("Moneda")
                    celdaTasa.Text = REA.GetDouble("Tasa")
                    celdaDocumento.Text = REA.GetString("Documento")
                    celdaIdAplicante.Text = REA.GetInt32("Aplicante")
                    celdaAplicante.Text = REA.GetString("Cliente")
                    celdaDireccion2.Text = REA.GetString("Direccion2")
                Loop
                REA.Close()
                COM = Nothing
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub
    Private Function SQLDetalle(ByVal Codigo As Integer, ByVal Anio As Integer) As String
        Dim strSQL As String = STR_VACIO
        strSQL = "      SELECT d.DDoc_Prd_Cod codigo, d.DDoc_Prd_Des descripcion, COALESCE(c.cat_clave,'') medida, d.DDoc_Prd_UM unidad, d.DDoc_Prd_Net precio, "
        strSQL &= "         d.DDoc_Prd_Qty cantidad, ROUND((d.DDoc_Prd_NET * d.DDoc_Prd_Qty),3) total, COALESCE(d.DDoc_RF1_Num, d.DDoc_Prd_UM) conversion, 0 saldo, COALESCE(p.PDoc_Par_Ano,0) anio, "
        strSQL &= "             COALESCE(p.PDoc_Par_Num,0) numero, COALESCE(p.PDoc_Par_Lin,0) linea, d.DDoc_RF1_Fec fecha, d.DDoc_Prd_Ref estilo, COALESCE(d.DDoc_RF1_Cod,'') pedido, "
        strSQL &= "                COALESCE(l.cli_cliente,'') lugar, d.DDoc_RF1_Num destino, d.DDoc_RF2_Fec vencimiento, d.DDoc_RF2_Dbl revision "
        strSQL &= "                     FROM Dcmtos_DTL d "
        strSQL &= "                         LEFT JOIN Dcmtos_DTL_Pro p ON p.PDoc_Sis_Emp = d.DDoc_Sis_Emp AND p.PDoc_Par_Cat = 36 AND p.PDoc_Chi_Cat = 398 AND p.PDoc_Chi_Ano = d.DDoc_Doc_Ano AND p.PDoc_Chi_Num = d.DDoc_Doc_Num AND p.PDoc_Chi_Lin = d.DDoc_Doc_Lin "
        strSQL &= "                             LEFT JOIN Catalogos c ON c.cat_clase = 'Medidas' AND c.cat_num = d.DDoc_Prd_UM "
        strSQL &= "                                     LEFT JOIN Inventarios i ON i.inv_sisemp = 12 AND i.inv_numero = d.DDoc_Prd_Cod "
        strSQL &= "                                          LEFT JOIN Clientes l ON l.cli_sisemp = d.DDoc_Sis_Emp AND l.cli_codigo = d.DDoc_RF1_Num"
        strSQL &= "                                              WHERE d.DDoc_Sis_Emp = {empresa} AND d.DDoc_Doc_Cat = {catalogo} AND d.DDoc_Doc_Ano = {anio} AND d.DDoc_Doc_Num = {numero} "
        strSQL &= "                                                  GROUP BY d.DDoc_Doc_Cat, d.DDoc_Doc_Ano, d.DDoc_Doc_Num, d.DDoc_Doc_Lin "
        strSQL &= "                                                      ORDER BY d.DDoc_Doc_Lin "
        strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
        strSQL = Replace(strSQL, "{catalogo}", catalogos)
        strSQL = Replace(strSQL, "{anio}", Anio)
        strSQL = Replace(strSQL, "{numero}", Codigo)

        Return strSQL
    End Function
    Public Sub CargarDetalle(ByVal Codigo As Integer, ByVal Anio As Integer)
        Dim strSQL As String = STR_VACIO
        Dim strFila As String = STR_VACIO
        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader
        Dim dblcantidad As Double = 0
        Dim dblTotal As Double = 0
        Try
            strSQL = SQLDetalle(Codigo, Anio)
            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSQL, CON)
            REA = COM.ExecuteReader
            If REA.HasRows Then
                dgDetalle.Rows.Clear()
                Do While REA.Read

                    strFila = REA.GetInt32("codigo") & "|"  ' Codigo
                    strFila &= REA.GetString("descripcion") & "|"  ' Descripcion
                    strFila &= REA.GetInt32("unidad") & "|" ' id Medida
                    strFila &= REA.GetString("medida") & "|"  ' Medida
                    strFila &= REA.GetDouble("precio") & "|"  ' Precio
                    strFila &= REA.GetDouble("cantidad") & "|"   ' Cantidad
                    strFila &= REA.GetDouble("revision") & "|" ' Devolucion
                    strFila &= REA.GetDouble("total").ToString("###0.00") & "|"   ' Total
                    strFila &= REA.GetInt32("linea") & "|"  ' Linea
                    strFila &= REA.GetDateTime("fecha").ToString(FORMATO_MYSQL) & "|"  ' entrega
                    strFila &= REA.GetString("estilo") & "|"  ' estilo
                    strFila &= REA.GetString("pedido") & "|"  ' pedido    
                    strFila &= REA.GetString("Lugar") & "|" ' Lugar de Envio 
                    strFila &= REA.GetDateTime("vencimiento").ToString(FORMATO_MYSQL) & "|"  ' Fecha de Vencimiento
                    strFila &= REA.GetInt32("destino") & "|"
                    strFila &= "" & "|"
                    strFila &= "" & "|"
                    strFila &= "" & "|"
                    strFila &= REA.GetInt32("anio") & "|"
                    strFila &= REA.GetInt32("numero") & "|"
                    strFila &= REA.GetInt32("linea") & "|"
                    strFila &= INT_UNO
                    cFunciones.AgregarFila(dgDetalle, strFila)

                    dblCantidad = dblCantidad + REA.GetDouble("cantidad")
                    dblTotal = dblTotal + REA.GetDouble("total")

                Loop
                celdaCantidad.Text = dblcantidad.ToString(FORMATO_MONEDA)
                celdaTotal.Text = dblTotal.ToString(FORMATO_MONEDA)
            End If

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub
    Private Function SQLReferenciaDocumento(ByVal Anio As Integer, ByVal Numero As Integer) As String
        Dim strSQL As String = STR_VACIO

        strSQL = "  SELECT DISTINCT b.HDoc_Doc_Cat tipo, b.HDoc_Doc_Ano anio, b.HDoc_Doc_Num numero, b.HDoc_DR1_Dbl numero2, b.HDoc_Doc_Fec fecha, b.HDoc_Usuario usuario, b.HDoc_DR1_Num referencia "
        strSQL &= "     FROM Dcmtos_DTL_Pro a "
        strSQL &= "         INNER JOIN Dcmtos_HDR b ON a.PDoc_Sis_Emp = b.HDoc_Sis_Emp AND a.PDoc_Par_Cat = b.HDoc_Doc_Cat AND a.PDoc_Par_Ano = b.HDoc_Doc_Ano AND a.PDoc_Par_Num = b.HDoc_Doc_Num AND a.PDoc_Par_Cat = 36 "
        strSQL &= "             WHERE a.PDoc_Sis_Emp = {empresa} AND a.PDoc_Chi_Cat = {catalogo} AND a.PDoc_Chi_Ano = {anio} AND a.PDoc_Chi_Num = {numero} "
        strSQL &= "                 ORDER BY b.HDoc_Doc_Ano, b.HDoc_Doc_Num "

        strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
        strSQL = Replace(strSQL, "{catalogo}", catalogos)
        strSQL = Replace(strSQL, "{anio}", Anio)
        strSQL = Replace(strSQL, "{numero}", Numero)
        Return strSQL
    End Function
    Public Sub CargarReferencia(ByVal Anio As Integer, ByVal Numero As Integer)
        Dim strSQL As String = STR_VACIO
        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader
        Dim strFila As String
        Try


            strSQL = SQLReferenciaDocumento(Anio, Numero)
            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSQL, CON)
            REA = COM.ExecuteReader
            If REA.HasRows Then
                dgFactura.Rows.Clear()
                Do While REA.Read
                    strFila = REA.GetInt32("tipo") & "|"
                    strFila &= REA.GetInt32("anio") & "|"
                    If (Sesion.IdEmpresa = 12 And intPais = 310) Or Sesion.IdEmpresa = 16 Or Sesion.IdEmpresa = 14 Then
                        strFila &= REA.GetInt32("numero2") & "|"
                    Else
                        strFila &= REA.GetInt32("numero") & "|"
                    End If
                    strFila &= REA.GetDateTime("Fecha").ToString(FORMATO_MYSQL) & "|"
                    strFila &= REA.GetString("usuario") & "|"
                    strFila &= REA.GetString("referencia") & "|"
                    strFila &= INT_UNO
                    cFunciones.AgregarFila(dgFactura, strFila)
                Loop
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub
    Private Function SQLDetalleDocumentosProceso() As String
        Dim strSQL As String = STR_VACIO
        Try
            strSQL = "  SELECT e.HDoc_Sis_Emp empresa, e.HDoc_Doc_Cat tipo, e.HDoc_Doc_Ano anio, e.HDoc_Doc_Num numero, d.DDoc_Doc_Lin linea, d.DDoc_Prd_Cod codigo, a.art_DCorta descripcion, COALESCE(c.cat_clave,'') medida, "
            strSQL &= "     d.DDoc_Prd_UM unidad, d.DDoc_Prd_PUQ precio, 0 total, d.DDoc_Prd_UM conversion, 0 cantidad, e.HDoc_Doc_Fec fecha, '' estilo, '' pedido, COALESCE(l.cli_cliente,'') lugar, d.DDoc_RF1_Num destino, 0 revision, (d.DDoc_Prd_QTY - COALESCE(( "
            strSQL &= "         SELECT SUM(p.PDoc_QTY_Pro) "
            strSQL &= "             FROM Dcmtos_DTL_Pro p "
            strSQL &= "                 WHERE p.PDoc_Sis_Emp = d.DDoc_Sis_Emp AND p.PDoc_Par_Cat = d.DDoc_Doc_Cat AND p.PDoc_Par_Ano = d.DDoc_Doc_Ano AND p.PDoc_Par_Num = d.DDoc_Doc_Num AND p.PDoc_Par_Lin = d.DDoc_Doc_Lin AND p.PDoc_Chi_Cat = 398),0)) saldo "
            strSQL &= "                     FROM Dcmtos_DTL d "
            strSQL &= "                         LEFT JOIN Dcmtos_HDR e ON e.HDoc_Sis_Emp = d.DDoc_Sis_Emp AND e.HDoc_Doc_Cat = d.DDoc_Doc_Cat AND e.HDoc_Doc_Ano = d.DDoc_Doc_Ano AND e.HDoc_Doc_Num = d.DDoc_Doc_Num "
            strSQL &= "                             LEFT JOIN Inventarios i ON i.inv_sisemp = d.DDoc_Sis_Emp AND i.inv_numero = d.DDoc_Prd_Cod "
            strSQL &= "                                 LEFT JOIN Articulos a ON a.art_sisemp = d.DDoc_Sis_Emp AND a.art_codigo = i.inv_artcodigo "
            strSQL &= "                                     LEFT JOIN Catalogos c ON c.cat_clase = 'Medidas' AND c.cat_num = d.DDoc_Prd_UM "
            strSQL &= "                                         LEFT JOIN Clientes l ON l.cli_sisemp = d.DDoc_Sis_Emp AND l.cli_codigo = d.DDoc_RF1_Num"
            strSQL &= "                                             WHERE d.DDoc_Sis_Emp = {empresa} AND d.DDoc_Doc_Cat = {catalogofact} AND HDoc_Doc_Ano = {anio} AND HDoc_Doc_Num = {numero}  "
            strSQL &= "                                                 GROUP BY d.DDoc_Sis_Emp, d.DDoc_Doc_Cat, d.DDoc_Doc_Ano, d.DDoc_Doc_Num, d.DDoc_Doc_Lin "
            strSQL &= "                                                     HAVING (saldo > 0) "
            strSQL &= "                                                         ORDER BY d.DDoc_Doc_Ano, d.DDoc_Doc_Num "
            strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
            strSQL = Replace(strSQL, "{catalogo}", catalogos)
            strSQL = Replace(strSQL, "{catalogofact}", dgFactura.CurrentRow.Cells("col_Tipo").Value)
            strSQL = Replace(strSQL, "{anio}", dgFactura.CurrentRow.Cells("col_anio").Value)
            strSQL = Replace(strSQL, "{numero}", dgFactura.CurrentRow.Cells("col_Numero").Value)
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        Return strSQL
    End Function
    Private Function SQLDocumentosEnProceso() As String
        Dim strSQL As String = STR_VACIO
        Try
            strSQL = " SELECT DISTINCT a.HDoc_Sis_Emp empresa, a.HDoc_Doc_Cat tipo, a.HDoc_Doc_Ano anio, a.HDoc_Doc_Num numero, a.HDoc_DR1_Dbl Numero2, a.HDoc_Doc_Fec fecha, COALESCE(a.HDoc_DR1_Num,'') referencia, a.HDoc_Usuario usuario, a.HDoc_RF1_Dbl Total "
            strSQL &= "     FROM Dcmtos_HDR a "
            strSQL &= "         LEFT JOIN Dcmtos_DTL b ON b.DDoc_Sis_Emp= a.HDoc_Sis_Emp AND b.DDoc_Doc_Cat = a.HDoc_Doc_Cat AND b.DDoc_Doc_Ano = a.HDoc_Doc_Ano AND b.DDoc_Doc_Num = a.HDoc_Doc_Num "
            strSQL &= "             WHERE HDoc_Sis_Emp = {empresa} AND (HDoc_Doc_Cat = {catalogoFac}) AND (HDoc_Emp_Cod = {codigo}) AND HDoc_Doc_Status = 1 AND (COALESCE(( "
            strSQL &= "                 SELECT SUM(c.PDoc_QTY_Pro) "
            strSQL &= "                     FROM Dcmtos_DTL_Pro c "
            strSQL &= "                         WHERE c.PDoc_Sis_Emp = b.DDoc_Sis_Emp AND c.PDoc_Par_Cat = b.DDoc_Doc_Cat AND c.PDoc_Par_Ano = b.DDoc_Doc_Ano AND c.PDoc_Par_Num = b.DDoc_Doc_Num AND c.PDoc_Par_Lin = b.DDoc_Doc_Lin AND c.PDoc_Chi_Cat = {catalogo}), 0) < b.DDoc_Prd_QTY) "
            strSQL &= "                             ORDER BY HDoc_Doc_Ano DESC, HDoc_Doc_Num DESC "
            strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
            strSQL = Replace(strSQL, "{catalogoFac}", catalogoFactura)
            strSQL = Replace(strSQL, "{codigo}", celdaidCliente.Text)
            strSQL = Replace(strSQL, "{catalogo}", catalogos)

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        Return strSQL
    End Function
    Public Sub CargarDatosCliente(ByVal codigo As Integer)
        Dim strSQL As String = STR_VACIO
        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader
        Try
            strSQL = " SELECT cli_codigo codigo , cli_cliente Cliente , cli_direccion Direccion  "
            strSQL &= "     FROM Clientes "
            strSQL &= "        LEFT JOIN Catalogos ON cat_num=cli_moneda "
            strSQL &= "             WHERE cli_sisemp={empresa} AND cli_codigo={codigo} "
            strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
            strSQL = Replace(strSQL, "{codigo}", codigo)
            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSQL, CON)
            REA = COM.ExecuteReader
            If REA.HasRows Then
                Do While REA.Read
                    celdaIdAplicante.Text = REA.GetInt32("codigo")
                    celdaAplicante.Text = REA.GetString("Cliente")
                    celdaDireccion2.Text = REA.GetString("Direccion")
                    celdaDocumento.Text = dgFactura.CurrentRow.Cells("col_Numero").Value
                Loop
            End If

        Catch ex As Exception

        End Try
    End Sub
    Public Sub CargarPolizaExportacion()
        Dim strSQL As String
        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader
        Try

            strSQL = " SELECT DISTINCT ip.ADoc_Dta_Chr  Exportacion"
            strSQL &= "     FROM Dcmtos_DTL_Pro rp "
            strSQL &= "         INNER JOIN Dcmtos_HDR ep ON ep.HDoc_Sis_Emp = rp.PDoc_Sis_Emp AND ep.HDoc_Doc_Cat = rp.PDoc_Chi_Cat AND ep.HDoc_Doc_Ano = rp.PDoc_Chi_Ano AND ep.HDoc_Doc_Num = rp.PDoc_Chi_Num "
            strSQL &= "             LEFT JOIN Dcmtos_ACC ip ON ip.ADoc_Sis_Emp = ep.HDoc_Sis_Emp AND ip.ADoc_Doc_Cat = ep.HDoc_Doc_Cat AND ip.ADoc_Doc_Ano = ep.HDoc_Doc_Ano AND ip.ADoc_Doc_Num = ep.HDoc_Doc_Num AND ip.ADoc_Doc_Sub = 'Doc_PolExp' AND ip.Adoc_Doc_Lin = '01' "
            strSQL &= "                      WHERE rp.PDoc_Sis_Emp = {empresa} AND rp.PDoc_Par_Cat = {catalogo} AND rp.PDoc_Par_Ano = {anio} AND rp.PDoc_Par_Num = {numero} AND rp.PDoc_Chi_Cat = 56 AND NOT(COALESCE(ip.ADoc_Dta_Chr,'') = '') LIMIT 1"
            strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
            strSQL = Replace(strSQL, "{catalogo}", dgFactura.CurrentRow.Cells("col_Tipo").Value)
            strSQL = Replace(strSQL, "{anio}", dgFactura.CurrentRow.Cells("col_anio").Value)
            strSQL = Replace(strSQL, "{numero}", dgFactura.CurrentRow.Cells("col_Numero").Value)
            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSQL, CON)
            REA = COM.ExecuteReader
            If REA.HasRows Then
                Do While REA.Read
                Loop
            End If

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub
    Public Sub CargarDocumentosProcesados()
        Dim strSQL As String = STR_VACIO
        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader
        Dim strFila As String = STR_VACIO
        Try
            strSQL = SQLDocumentosEnProceso()
            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSQL, CON)
            dgFactura.Rows.Clear()
            REA = COM.ExecuteReader
            If REA.HasRows Then
                Do While REA.Read
                    strFila = REA.GetInt32("tipo") & "|"
                    strFila &= REA.GetInt32("anio") & "|"
                    If (Sesion.IdEmpresa = 12 And intPais = 310) Or Sesion.IdEmpresa = 14 And Sesion.IdEmpresa = 16 Then
                        strFila &= REA.GetInt32("Numero2") & "|"
                    Else
                        strFila &= REA.GetInt32("numero") & "|"
                    End If

                    strFila &= REA.GetDateTime("fecha").ToString(FORMATO_MYSQL) & "|"
                    strFila &= REA.GetString("usuario") & "|"
                    strFila &= REA.GetString("referencia") & "|"c
                    strFila &= "0"
                    cfun.AgregarFila(dgFactura, strFila)
                Loop
            End If
            celdaDocumento.Text = STR_VACIO
            celdaDireccion2.Text = STR_VACIO
            celdaAplicante.Text = STR_VACIO
            celdaIdAplicante.Text = STR_VACIO


        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub
    Public Sub CargarDocumentosDetalle()
        Dim strSQL As String = STR_VACIO
        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader
        Dim strFila As String = STR_VACIO
        Dim dblTotalLin As Double = 0

        Try
            strSQL = SQLDetalleDocumentosProceso()
            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSQL, CON)
            REA = COM.ExecuteReader
            If REA.HasRows Then
                Do While REA.Read
                    strFila = REA.GetInt32("codigo") & "|"
                    strFila &= REA.GetString("descripcion") & "|"
                    strFila &= REA.GetInt32("unidad") & "|"
                    strFila &= REA.GetString("medida") & "|"
                    strFila &= REA.GetDouble("precio") & "|"
                    strFila &= REA.GetDouble("saldo") & "|"
                    strFila &= REA.GetInt32("revision") & "|"
                    dblTotalLin = (REA.GetDouble("precio") * REA.GetDouble("saldo"))
                    strFila &= dblTotalLin.ToString("###0.00") & "|"
                    strFila &= REA.GetInt32("linea") & "|"
                    strFila &= REA.GetDateTime("fecha").ToString(FORMATO_MYSQL) & "|"
                    strFila &= REA.GetString("estilo") & "|"
                    strFila &= REA.GetString("pedido") & "|"
                    strFila &= REA.GetString("lugar") & "|"
                    strFila &= "" & "|"
                    strFila &= REA.GetInt32("destino") & "|"
                    strFila &= "" & "|"
                    strFila &= "" & "|"
                    strFila &= "" & "|"
                    strFila &= REA.GetInt32("anio") & "|"
                    strFila &= REA.GetInt32("numero") & "|"
                    strFila &= REA.GetInt32("linea") & "|"
                    strFila &= INT_CERO
                    cfun.AgregarFila(dgDetalle, strFila)

                Loop

            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub
    Public Sub Pedido()
        Dim strSQL As String
        Dim strSQL1 As String
        Dim strSQl2 As String
        Dim COM As MySqlCommand
        Dim COM2 As MySqlCommand
        Dim REA As MySqlDataReader
        Dim conec As MySqlConnection
        Dim frmNote As New frmAviso
        Dim dblTotal As Double
        Dim dblPrecio As Double
        Dim strUnidad As String
        Dim strBase As String
        Dim strPedido As String
        Dim intUnidad As Integer
        Dim intBase As Integer
        Dim dblCantidad As Double = 0
        Dim dblTotalDoc As Double = 0
        Try
            strMensaje = STR_VACIO
            For i As Integer = 0 To dgDetalle.Rows.Count - 1

                strSQL = "  SELECT r.HDoc_Doc_Cat tipo, r.HDoc_Doc_Ano año, r.HDoc_Doc_Num numero, e.DDoc_Doc_Lin linea, IF(d.DDoc_Prd_UM = 70, COALESCE(e.DDoc_Prd_Net,0) * 2.2046, COALESCE(e.DDoc_Prd_Net,0)) precio, COALESCE(e.DDoc_Prd_UM,0) unidad, f.HDoc_Doc_Fec fecha, e.DDoc_Prd_Ref estilo, COALESCE(r.HDoc_DR1_Num,'') pedido, DATE_ADD(f.HDoc_Doc_Fec, INTERVAL c.cli_plazoCR DAY) vencimiento "
                strSQL &= "     FROM Dcmtos_DTL d "
                strSQL &= "         LEFT JOIN Dcmtos_DTL_Pro i ON i.PDoc_Sis_Emp=d.DDoc_Sis_Emp AND i.PDoc_Chi_Cat=d.DDoc_Doc_Cat AND i.PDoc_Chi_Ano=d.DDoc_Doc_Ano AND i.PDoc_Chi_Num=d.DDoc_Doc_Num AND i.PDoc_Chi_Lin=d.DDoc_Doc_Lin "
                strSQL &= "             LEFT JOIN Dcmtos_DTL_Pro p ON p.PDoc_Sis_Emp=i.PDoc_Sis_Emp AND p.PDoc_Chi_Cat=i.PDoc_Par_Cat AND p.PDoc_Par_Cat=75 AND p.PDoc_Chi_Ano=i.PDoc_Par_Ano AND p.PDoc_Chi_Num=i.PDoc_Par_Num AND p.PDoc_Chi_Lin=i.PDoc_Par_Lin "
                strSQL &= "                 LEFT JOIN Dcmtos_DTL e ON e.DDoc_Sis_Emp=p.PDoc_Sis_Emp AND e.DDoc_Doc_Cat=p.PDoc_Par_Cat AND e.DDoc_Doc_Ano=p.PDoc_Par_Ano AND e.DDoc_Doc_Num=p.PDoc_Par_Num AND e.DDoc_Doc_Lin=p.PDoc_Par_Lin "
                strSQL &= "                     LEFT JOIN Dcmtos_HDR r ON r.HDoc_Sis_Emp=e.DDoc_Sis_Emp AND r.HDoc_Doc_Cat=e.DDoc_Doc_Cat AND r.HDoc_Doc_Ano=e.DDoc_Doc_Ano AND r.HDoc_Doc_Num=e.DDoc_Doc_Num "
                strSQL &= "                          LEFT JOIN Clientes c ON c.cli_sisemp=r.HDoc_Sis_Emp AND c.cli_codigo=r.HDoc_Emp_Cod "
                strSQL &= "                              LEFT JOIN Dcmtos_HDR f ON f.HDoc_Sis_Emp={empresa} AND f.HDoc_Doc_Cat={catalogo} AND f.HDoc_Doc_Ano={anio} AND f.HDoc_Doc_Num={numero}"
                strSQL &= "                                  WHERE d.DDoc_Sis_Emp={empresa} AND d.DDoc_Doc_Cat={catalogo} AND d.DDoc_Doc_Ano={anio} AND d.DDoc_Doc_Num={numero} AND d.DDoc_Doc_Lin={linea} AND NOT ISNULL(r.HDoc_Sis_Emp) LIMIT 1"
                strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
                strSQL = Replace(strSQL, "{catalogo}", dgFactura.CurrentRow.Cells("col_Tipo").Value)
                strSQL = Replace(strSQL, "{anio}", dgFactura.CurrentRow.Cells("col_anio").Value)
                strSQL = Replace(strSQL, "{numero}", dgFactura.CurrentRow.Cells("col_Numero").Value)
                strSQL = Replace(strSQL, "{linea}", dgDetalle.Rows(i).Cells("col_linea").Value)

                MyCnn.CONECTAR = strConexion
                COM = New MySqlCommand(strSQL, CON)
                REA = COM.ExecuteReader
                If REA.HasRows Then
                    Do While REA.Read
                        If Me.Tag = "Nuevo" Then
                            intUnidad = dgDetalle.Rows(i).Cells("colidMedida").Value
                            'intBase = dgDetalle.Rows(i).Cells("colBase").Value
                            strPedido = REA.GetString("pedido")
                            If REA.GetDouble("precio") > vbEmpty Then
                                dblPrecio = dgDetalle.Rows(i).Cells("colPrecio").Value

                                If Not (dblPrecio = REA.GetDouble("precio")) Then

                                    strSQL1 = " SELECT cat_clave FROM Catalogos WHERE cat_clase='Medidas' AND cat_num = " & intUnidad
                                    conec = New MySqlConnection(strConexion)
                                    conec.Open()
                                    COM2 = New MySqlCommand(strSQL1, conec)
                                    Using conec
                                        strUnidad = COM2.ExecuteScalar
                                        COM2.Dispose()
                                        COM2 = Nothing
                                        conec.Close()
                                        conec.Dispose()
                                        conec = Nothing
                                        System.GC.Collect()
                                    End Using
                                    strSQl2 = " SELECT cat_clave FROM Catalogos WHERE cat_clase='Medidas' AND cat_num = " & intBase
                                    conec = New MySqlConnection(strConexion)
                                    conec.Open()
                                    COM2 = New MySqlCommand(strSQL1, conec)
                                    Using conec
                                        strBase = COM2.ExecuteScalar
                                        COM2.Dispose()
                                        COM2 = Nothing
                                        conec.Close()
                                        conec.Dispose()
                                        conec = Nothing
                                        System.GC.Collect()
                                    End Using
                                    dgDetalle.Rows(i).Cells("colPrecio").Value = REA.GetDouble("precio")
                                    dblTotal = REA.GetDouble("precio") * CDbl(dgDetalle.Rows(i).Cells("colCantidad").Value)
                                    dgDetalle.Rows(i).Cells("colTotal").Value = dblTotal.ToString(FORMATO_MONEDA)

                                    strMensaje &= "Línea #" & (i + 1) & ": el precio del pedido difiere del facturado" & vbCrLf & vbCrLf & "Pedido: " & REA.GetDouble("precio").ToString(FORMATO_MONEDA) & " x " & strUnidad & vbCrLf & "Factura: " & dblPrecio.ToString(FORMATO_MONEDA) & " x " & strBase & vbCrLf & vbCrLf & vbNullString
                                Else
                                    dblTotal = REA.GetDouble("precio") * CDbl(dgDetalle.Rows(i).Cells("colCantidad").Value)
                                End If
                            End If
                            dgDetalle.Rows(i).Cells("col_presentado").Value = REA.GetDateTime("vencimiento").ToString(FORMATO_MYSQL)
                            dgDetalle.Rows(i).Cells("col_Contrato").Value = strPedido
                            dblCantidad = dblCantidad + dgDetalle.Rows(i).Cells("colCantidad").Value
                            dblTotalDoc = dblTotalDoc + dblTotal
                        Else

                        End If
                    Loop
                    celdaCantidad.Text = dblCantidad.ToString(FORMATO_MONEDA)
                    celdaTotal.Text = dblTotalDoc.ToString(FORMATO_MONEDA)
                    ' Contrato(dgFactura.CurrentRow.Cells("col_anio").Value, dgFactura.CurrentRow.Cells("col_Numero").Value, dgDetalle.Rows(i).Cells("col_linea").Value)
                    COM = Nothing
                    REA.Close()
                End If
            Next
            If Not (strMensaje = vbNullString) Then
                frmNote.Texto = strMensaje
                frmNote.ShowDialog(Me)
            End If

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub
    Public Sub Contrato(ByVal Anio As Integer, ByVal Numero As Integer, ByVal Linea As Integer)
        Dim strSQL As String = STR_VACIO
        Dim k As Integer
        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader
        Dim strContrato As String = STR_VACIO
        Dim strFecha As String = STR_VACIO

        strSQL = " SELECT g.Año Anio, g.Numero, g.Linea, g.Contrato, CONCAT(IF(g.Fecha1!='' AND g.Fecha2='','FSD ',''),g.Fecha1, IF(g.Fecha1='' OR g.Fecha2='','',' / '), IF(g.Fecha1='' AND g.Fecha2!='','LSD ',''),g.Fecha2) Fechas "
        strSQL &= "     FROM ( "
        strSQL &= "         SELECT rc.PDoc_Par_Ano Año, rc.PDoc_Par_Num Numero, rc.PDoc_Par_Lin Linea, IFNULL(ec.HDoc_DR1_Num,'') Contrato, CAST(IFNULL(dc.DDoc_RF1_Fec,'') AS CHAR) Fecha1, CAST(IFNULL(dc.DDoc_RF2_Fec,'') AS CHAR) Fecha2 "
        strSQL &= "             FROM Dcmtos_DTL_Pro rc "
        strSQL &= "                 LEFT JOIN Dcmtos_DTL dc ON dc.DDoc_Sis_Emp=rc.PDoc_Sis_Emp AND dc.DDoc_Doc_Cat=rc.PDoc_Par_Cat AND dc.DDoc_Doc_Ano=rc.PDoc_Par_Ano AND dc.DDoc_Doc_Num=rc.PDoc_Par_Num AND dc.DDoc_Doc_Lin=rc.PDoc_Par_Lin "
        strSQL &= "                     LEFT JOIN Dcmtos_HDR ec ON ec.HDoc_Sis_Emp = dc.DDoc_Sis_Emp AND ec.HDoc_Doc_Cat=dc.DDoc_Doc_Cat AND ec.HDoc_Doc_Ano=dc.DDoc_Doc_Ano AND ec.HDoc_Doc_Num=dc.DDoc_Doc_Num "
        strSQL &= "                         WHERE rc.PDoc_Sis_Emp = {empresa} AND rc.PDoc_Chi_Cat = 75 AND rc.PDoc_Chi_Ano = {anio} AND rc.PDoc_Chi_Num = {numero} AND rc.PDoc_Chi_Lin = {linea} AND rc.PDoc_Par_Cat = 389 "
        strSQL &= "                             GROUP BY rc.PDoc_Sis_Emp, rc.PDoc_Par_Cat, rc.PDoc_Par_Ano, rc.PDoc_Par_Num, rc.PDoc_Par_Lin) g "
        strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
        strSQL = Replace(strSQL, "{anio}", Anio)
        strSQL = Replace(strSQL, "{numero}", Numero)
        strSQL = Replace(strSQL, "{linea}", Linea)

        MyCnn.CONECTAR = strConexion
        COM = New MySqlCommand(strSQL, CON)
        REA = COM.ExecuteReader
        If REA.HasRows Then
            Do While REA.Read
                If Not (REA.GetString("contrato") = "") Then
                    If k = vbEmpty Then
                        dgDetalle.CurrentRow.Cells("colRefAnio").Value = REA.GetInt32("Anio")
                        dgDetalle.CurrentRow.Cells("colRefNum").Value = REA.GetInt32("Numero")
                        dgDetalle.CurrentRow.Cells("colRefLine").Value = REA.GetInt32("Linea")
                    End If
                    If InStr(1, strContrato, REA.GetString("contrato")) = vbEmpty Then
                        strContrato &= REA.GetString("contrato") & "/"
                    End If
                    If strFecha = vbNullString Then
                        If Not REA.GetString("Fechas") = "" Then
                            strFecha = REA.GetString("Fechas")
                        End If
                    End If

                End If
                k = k + 1
            Loop
        End If
        If k > 1 Then
            'Agrega a la lista de mensajes
            strMensaje &= "Línea #" & (dgDetalle.CurrentRow.Cells("col_linea").Value) & ": se encontró más de un contrato para dicho pedido" & vbCrLf & vbCrLf & vbNullString
        End If
        dgDetalle.CurrentRow.Cells("col_Contrato").Value = strContrato
        dgDetalle.CurrentRow.Cells("colFechaContrato").Value = strFecha

    End Sub
    Private Function GuardarDocumento(ByVal codigo As Integer, ByVal intAnio As Integer) As Boolean
        Dim clsHDR As New clsDcmtos_HDR
        Dim logGuardar As Boolean = True
        Try
            clsHDR.CONEXION = strConexion
            clsHDR.HDOC_SIS_EMP = Sesion.IdEmpresa
            clsHDR.HDOC_DOC_CAT = catalogos
            clsHDR.HDOC_DOC_ANO = intAnio
            clsHDR.HDOC_DOC_NUM = codigo
            clsHDR.HDoc_Doc_Fec_NET = dtpFecha.Value.ToString(FORMATO_MYSQL)
            clsHDR.HDOC_EMP_COD = celdaidCliente.Text
            clsHDR.HDOC_EMP_NOM = celdaNombreCliente.Text
            clsHDR.HDOC_EMP_DIR = celdaDireccion.Text
            clsHDR.HDOC_EMP_NIT = celdaNit.Text
            clsHDR.HDOC_EMP_PER = If(celdaContacto.Text = STR_VACIO, "N/A", celdaContacto.Text)
            clsHDR.HDOC_EMP_TEL = celdaTelefono.Text
            clsHDR.HDOC_DR1_EMP = celdaIdAplicante.Text
            clsHDR.HDOC_DR1_NUM = celdaDocumento.Text
            clsHDR.HDOC_RF1_COD = celdaAplicante.Text
            clsHDR.HDOC_RF1_TXT = celdaDireccion2.Text
            clsHDR.HDOC_RF2_TXT = celdaObservaciones.Text
            clsHDR.HDOC_USUARIO = Sesion.Usuario
            clsHDR.HDOC_DOC_TC = celdaTasa.Text
            clsHDR.HDOC_DOC_MON = celdaIdMoneda.Text
            clsHDR.HDOC_DOC_STATUS = IIf(checkActive.Checked = True, 1, vbEmpty)

            If Me.Tag = "Mod" Then
                If clsHDR.Actualizar() = False Then
                    logGuardar = False
                    MsgBox(clsHDR.MERROR.ToString & "Could not update the document", MsgBoxStyle.Critical)
                Else
                    logGuardar = True
                End If
            Else
                If clsHDR.Guardar() = False Then
                    logGuardar = False
                    MsgBox(clsHDR.MERROR.ToString & "Could not save the document", MsgBoxStyle.Critical)
                Else
                    logGuardar = True
                End If
            End If

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        Return logGuardar
    End Function
    Private Function GuardarDetalle(ByVal Codigo As Integer, ByVal IntAnio As Integer) As Boolean
        Dim clsDTL As New clsDcmtos_DTL
        Dim logGuardar As Boolean
        Try
            clsDTL.CONEXION = strConexion
            For i As Integer = 0 To dgDetalle.Rows.Count - 1
                clsDTL.DDOC_SIS_EMP = Sesion.IdEmpresa
                clsDTL.DDOC_DOC_CAT = catalogos
                clsDTL.DDOC_DOC_ANO = IntAnio
                clsDTL.DDOC_DOC_NUM = Codigo
                If dgDetalle.Rows(i).Cells("col_linea").Value = 0 Then
                    clsDTL.DDOC_DOC_LIN = i + 1
                Else
                    clsDTL.DDOC_DOC_LIN = dgDetalle.Rows(i).Cells("col_linea").Value
                End If

                clsDTL.DDOC_PRD_COD = dgDetalle.Rows(i).Cells("col_codigo").Value
                clsDTL.DDOC_PRD_DES = dgDetalle.Rows(i).Cells("col_descripcion").Value
                clsDTL.DDOC_PRD_UM = dgDetalle.Rows(i).Cells("colidMedida").Value
                clsDTL.DDOC_PRD_PUQ = dgDetalle.Rows(i).Cells("colPrecio").Value
                clsDTL.DDOC_PRD_DSP = INT_CERO
                clsDTL.DDOC_PRD_DSQ = INT_CERO
                clsDTL.DDOC_PRD_NET = dgDetalle.Rows(i).Cells("colPrecio").Value
                clsDTL.DDOC_PRD_QTY = dgDetalle.Rows(i).Cells("colCantidad").Value

                clsDTL.DDOC_RF1_NUM = dgDetalle.Rows(i).Cells("col_Referencia1").Value
                clsDTL.DDOC_RF1_COD = dgDetalle.Rows(i).Cells("col_Contrato").Value
                clsDTL.DDOC_RF1_TXT = "NULL"
                clsDTL.DDoc_RF1_Fec_NET = dgDetalle.Rows(i).Cells("col_envio").Value  ' Envio 
                clsDTL.DDOC_RF1_DBL = dgDetalle.Rows(i).Cells("colTotal").Value
                clsDTL.DDoc_RF2_Fec_NET = dgDetalle.Rows(i).Cells("col_presentado").Value  ' Presentado 

                clsDTL.DDOC_RF2_DBL = dgDetalle.Rows(i).Cells("colDevolucion").Value
                clsDTL.DDOC_PRD_FOB = dgDetalle.Rows(i).Cells("colTotal").Value
                clsDTL.DDOC_PRD_CIF = dgDetalle.Rows(i).Cells("colTotal").Value ' Total 
                clsDTL.DDOC_PRD_REF = dgDetalle.Rows(i).Cells("col_FSD").Value ' Carta de Credito 

                ' clsDTL.DDOC_RF2_TXT = dgDetalle.Rows(i).Cells("").Value ' Documento 
                'clsDTL.DDOC_RF3_FEC = dgDetalle.Rows(i).Cells("").Value  ' Pago 
                'clsDTL.DDOC_RF2_COD = Codigo

                If Me.Tag = "Mod" Then
                    If clsDTL.Actualizar() = False Then
                        logGuardar = False
                        MsgBox(clsDTL.MERROR.ToString & "Could not update the document", MsgBoxStyle.Critical)
                    Else
                        logGuardar = True
                    End If
                Else
                    If clsDTL.Guardar() = False Then
                        logGuardar = False
                        MsgBox(clsDTL.MERROR.ToString & "Could not save the document", MsgBoxStyle.Critical)
                    Else
                        logGuardar = True
                    End If
                End If

            Next
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        Return logGuardar
    End Function

    Private Sub GuardarRelacion(ByVal numero As Integer, ByVal IntAnio As Integer)
        Dim pro As New clsDcmtos_DTL_Pro

        Try
            pro.CONEXION = strConexion

            For i As Integer = 0 To dgDetalle.Rows.Count - 1
                pro.PDOC_SIS_EMP = Sesion.IdEmpresa
                pro.PDOC_PAR_CAT = 36
                pro.PDOC_PAR_ANO = dgDetalle.Rows(i).Cells("colRefAnio").Value
                pro.PDOC_PAR_NUM = dgDetalle.Rows(i).Cells("colRefNum").Value
                pro.PDOC_PAR_LIN = dgDetalle.Rows(i).Cells("colRefLine").Value
                pro.PDOC_CHI_CAT = catalogos
                pro.PDOC_CHI_ANO = celdaAño.Text
                pro.PDOC_CHI_NUM = celdaNumero.Text
                pro.PDOC_CHI_LIN = dgDetalle.Rows(i).Cells("col_linea").Value
                pro.PDOC_CLTE_COD = celdaidCliente.Text
                pro.PDOC_PROV_COD = INT_CERO
                pro.PDOC_PRD_COD = dgDetalle.Rows(i).Cells("col_codigo").Value
                pro.PDOC_PRD_PNR = INT_CERO
                pro.PDOC_DR1_NUM = INT_CERO
                pro.PDOC_DR2_NUM = INT_CERO
                pro.PDOC_PRD_NET = dgDetalle.Rows(i).Cells("colPrecio").Value
                pro.PDOC_QTY_ORD = dgDetalle.Rows(i).Cells("colCantidad").Value
                pro.PDOC_QTY_PRO = dgDetalle.Rows(i).Cells("colCantidad").Value

                If Me.Tag = "Mod" Then
                    If pro.Actualizar() = False Then
                        MsgBox(pro.MERROR.ToString & "Could not update the document", MsgBoxStyle.Critical)
                    End If
                Else
                    If pro.Guardar() = False Then
                        MsgBox(pro.MERROR.ToString & "Could not save the document", MsgBoxStyle.Critical)
                    End If
                End If

                If checkActive.Checked = False Then
                    checkActive.Enabled = False
                    If pro.Borrar = False Then
                        MsgBox(pro.MERROR.ToString() & " Could Not delete this document", MsgBoxStyle.Critical)
                    End If
                End If

            Next

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try

    End Sub
    Public Sub MostrarInfo(ByVal Codigo As Integer, ByVal Linea As Integer)
        Dim strSQL As String
        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader
        Try
            strSQL = "      SELECT a.art_DLarga descripcion, COALESCE(p.cat_clave,'') pais, COALESCE(v.pro_proveedor,'') proveedor "
            strSQL &= "         FROM Inventarios i "
            strSQL &= "             INNER JOIN Articulos a ON a.art_sisemp = i.inv_sisemp AND a.art_codigo = i.inv_artcodigo "
            strSQL &= "                 LEFT JOIN Catalogos p ON p.cat_clase = 'Paises' AND p.cat_num = i.inv_lugarfab "
            strSQL &= "                     LEFT JOIN Proveedores v ON v.pro_sisemp = i.inv_sisemp AND v.pro_codigo = i.inv_provcod "
            strSQL &= "                         WHERE i.inv_sisemp=12 AND i.inv_numero=10646 "
            strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
            strSQL = Replace(strSQL, "{codigo}", Codigo)

            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSQL, CON)
            REA = COM.ExecuteReader


        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub


    Public Sub CargarHilo(ByVal intHilo As Integer, ByVal Linea As Integer)
        Dim strSQL As String = STR_VACIO
        Dim COM2 As MySqlCommand
        Dim REA2 As MySqlDataReader
        Dim conec As New MySqlConnection

        conec.ConnectionString = strConexion
        conec.Open()
        Try

            strSQL = " SELECT a.art_DLarga descripcion, COALESCE(p.cat_clave,'') pais, COALESCE(v.pro_proveedor,'') proveedor, m.cat_clave Medida "
            strSQL &= " FROM Inventarios i "
            strSQL &= " INNER JOIN Articulos a ON a.art_sisemp = i.inv_sisemp AND a.art_codigo = i.inv_artcodigo "
            strSQL &= " LEFT JOIN Catalogos m ON m.cat_clase = 'Medidas' AND m.cat_num = inv_UMventa "
            strSQL &= " LEFT JOIN Catalogos p ON p.cat_clase = 'Paises' AND p.cat_num = i.inv_lugarfab "
            strSQL &= " LEFT JOIN Proveedores v ON v.pro_sisemp = i.inv_sisemp AND v.pro_codigo = i.inv_provcod "
            strSQL &= " WHERE i.inv_sisemp={empresa} AND i.inv_numero={codigo} "
            strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
            strSQL = Replace(strSQL, "{codigo}", intHilo)

            COM2 = New MySqlCommand(strSQL, conec)
            REA2 = COM2.ExecuteReader
            If REA2.HasRows Then
                Do While REA2.Read
                    For i As Integer = 0 To dgDetalle.Rows.Count - 1

                        If REA2.GetString("proveedor") = vbNullString Then
                            lblInformacion.Text = REA2.GetString("descripcion") & "  " & REA2.GetString("pais")
                        Else
                            lblInformacion.Text = REA2.GetString("descripcion") & "  " & REA2.GetString("pais") & " / " & REA2.GetString("proveedor")
                        End If
                        ' Contador = Contador + 1

                    Next
                    lblLinea.Text = Linea
                Loop
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        Finally
            conec.Close()
        End Try
        'REA.Close()
        'REA = Nothing
        'COM = Nothing
    End Sub

    Private Sub VerInformacionDeHilo()
        Dim intHilo As Integer
        Try

            If dgDetalle.Rows.Count > 0 Then
                intHilo = dgDetalle.CurrentRow.Cells("col_Codigo").Value
                If Me.Tag = "Mod" Then
                    CargarHilo(intHilo, dgDetalle.CurrentRow.Cells("col_Extra").Value)
                Else
                    CargarHilo(intHilo, dgDetalle.CurrentRow.Index + 1)
                End If
            End If
            'End If

        Catch ex As Exception
            ' MsgBox(ex.ToString)
        End Try
    End Sub

    Private Function VerificarDatos() As Boolean
        Dim verificacion As Boolean = False
        If dgFactura.Rows.Count = 1 Then
            If dgDetalle.Rows.Count >= 1 Then
                verificacion = True
            End If
        End If
        Return verificacion
    End Function
    'Metodos de Borrar 
    Private Sub BorrarEncabezado(ByVal num As Integer, ByVal anio As Integer)
        Try
            Dim hdr As New clsDcmtos_HDR
            hdr.CONEXION = strConexion
            hdr.HDOC_SIS_EMP = Sesion.IdEmpresa
            hdr.HDOC_DOC_CAT = catalogos
            hdr.HDOC_DOC_ANO = anio
            hdr.HDOC_DOC_NUM = num
            hdr.Borrar()

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub
    Private Sub BorrarDetalle(ByVal num As Integer, ByVal anio As Integer)
        Dim strSQL As String = STR_VACIO
        Try
            strSQL = "DDoc_Sis_Emp = {empresa}  AND DDoc_Doc_Cat = {catalogo} AND DDoc_Doc_Ano = {anio} AND DDoc_Doc_Num = {numero} "
            strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
            strSQL = Replace(strSQL, "{catalogo}", catalogos)
            strSQL = Replace(strSQL, "{anio}", anio)
            strSQL = Replace(strSQL, "{numero}", num)
            Dim dtl As New clsDcmtos_DTL
            dtl.CONEXION = strConexion
            dtl.Borrar(strSQL)
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub
    Private Sub BorrarDtl_Pro(ByVal num As Integer, ByVal anio As Integer)
        Dim strSQL As String = STR_VACIO
        Try
            strSQL = "PDoc_Sis_Emp = {empresa}  AND PDoc_Chi_Cat = {catalogo} AND PDoc_Chi_Ano = {anio} AND PDoc_Chi_Num = {numero} "
            strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
            strSQL = Replace(strSQL, "{catalogo}", catalogos)
            strSQL = Replace(strSQL, "{anio}", anio)
            strSQL = Replace(strSQL, "{numero}", num)
            Dim pro As New clsDcmtos_DTL_Pro
            pro.CONEXION = strConexion
            pro.Borrar(strSQL)

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub
#End Region

#Region "Eventos"
    Private Sub frmDebitNote_Load(sender As Object, e As EventArgs) Handles Me.Load
        intPais = verificarPais()
        dtpFechaFinal.Value = Today.ToString(FORMATO_MYSQL)
        dtpFechaInicial.Value = dtpFechaInicial.Value.AddMonths(NO_FILA).ToString(FORMATO_MYSQL)
        Accessos()
        MostrarLista()
    End Sub
    Private Sub Encabezado1_ClickNuevo(sender As Object, click As Boolean) Handles Encabezado1.ClickNuevo
        If logInsertar = True Then
            LimpiarPanelOrden()
            MostrarLista(False, True)
            Encabezado1.botonBorrar.Enabled = False
        Else
            MsgBox("No Posee permisos para esta acción", vbInformation)
        End If
    End Sub
    Private Sub botonCliente_Click(sender As Object, e As EventArgs) Handles botonCliente.Click
        Me.Tag = "Nuevo"
        Dim frm As New frmSeleccionar
        Dim strCondicion As String = STR_VACIO
        strCondicion = "c.cli_sisemp  = {empresa} AND c.cli_status  = 'Activo' "
        strCondicion = Replace(strCondicion, "{empresa}", Sesion.IdEmpresa)
        Try
            frm.Titulo = "Client"
            frm.Campos = " c.cli_codigo , c.cli_cliente , c.cli_direccion , c.cli_nit, c.cli_telefono "
            frm.Tabla = " Clientes c"
            frm.FiltroText = " Enter the client to filter"
            frm.Filtro = "  c.cli_cliente"
            frm.Limite = 30
            frm.Ordenamiento = " c.cli_codigo "
            frm.TipoOrdenamiento = ""
            frm.Condicion = strCondicion

            frm.ShowDialog(Me)
            If frm.DialogResult = System.Windows.Forms.DialogResult.OK Then
                celdaidCliente.Text = frm.LLave
                celdaNombreCliente.Text = frm.Dato
                celdaDireccion.Text = frm.Dato2
                celdaNit.Text = frm.Dato3
                celdaTelefono.Text = frm.Dato4
                celdaMoneda.Text = "US$"
                celdaIdMoneda.Text = 178
                celdaTasa.Text = cFunciones.QueryTasa("CURDATE()")
                CargarDocumentosProcesados()
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub
    Private Sub botonContacto_Click(sender As Object, e As EventArgs) Handles botonContacto.Click
        Me.Tag = "Nuevo"
        Dim frm As New frmSeleccionar
        Dim strCondicion As String = STR_VACIO
        strCondicion = "c.cnt_sisemp = {empresa} AND  c.cnt_codemp  = {cliente} AND c.cnt_status = 'Activo'  "
        strCondicion = Replace(strCondicion, "{empresa}", Sesion.IdEmpresa)
        strCondicion = Replace(strCondicion, "{cliente}", celdaidCliente.Text)
        Try
            frm.Titulo = "Contact"
            frm.Campos = " CONCAT(c.cnt_nombre ,' | ',c.cnt_celular) Contacto "
            frm.Tabla = " Contactos c"
            frm.FiltroText = " Enter the client to filter"
            frm.Filtro = "  c.cnt_nombre"
            frm.Limite = 30
            frm.Ordenamiento = " c.cnt_codemp "
            frm.TipoOrdenamiento = ""
            frm.Condicion = strCondicion

            frm.ShowDialog(Me)
            If frm.DialogResult = System.Windows.Forms.DialogResult.OK Then
                celdaContacto.Text = frm.LLave

            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub
    Private Sub dgFactura_DoubleClick(sender As Object, e As EventArgs) Handles dgFactura.DoubleClick
        Dim strFila As String = STR_VACIO
        If dgFactura.Rows.Count > 1 Then
            dgFactura.CurrentRow.Cells(6).Value = 3
            For i As Integer = 0 To dgFactura.Rows.Count - 1
                If dgFactura.Rows.Count = 1 Then
                ElseIf dgFactura.Rows(i).Cells("colStatus").Value = 3 Then
                    dgFactura.CurrentRow.Cells(6).Value = 0
                    strFila = dgFactura.Rows(i).Cells("col_Tipo").Value & "|" & dgFactura.Rows(i).Cells("col_anio").Value & "|" & dgFactura.Rows(i).Cells("col_Numero").Value & "|" & dgFactura.Rows(i).Cells("col_fecha").Value & "|" & dgFactura.Rows(i).Cells("colUsuario").Value & "|" & dgFactura.Rows(i).Cells("col_referencia").Value & "|" & dgFactura.Rows(i).Cells("colStatus").Value
                    dtpFecha.Value = dgFactura.Rows(i).Cells("col_fecha").Value
                End If

            Next
            dgFactura.Rows.Clear()
            cFunciones.AgregarFila(dgFactura, strFila)

            dgDetalle.Rows.Clear()
            CargarDatosCliente(celdaidCliente.Text)
            'CargarPolizaExportacion()
            CargarDocumentosDetalle()
            Pedido()
        End If
    End Sub
    Private Sub Encabezado1_ClickCerrar(sender As Object, click As Boolean) Handles Encabezado1.ClickCerrar
        If panelDocumento.Visible = True Then
            MostrarLista()
        Else
            Me.Close()
            Fprincipal.BarraDeTareas1.QuitarFormulario(strKey)
        End If
    End Sub

    Private Sub BotonMoneda_Click(sender As Object, e As EventArgs) Handles BotonMoneda.Click
        Dim frm As New frmSeleccionar
        Try
            frm.Titulo = "Select a Currency"
            frm.Campos = " c.cat_clave Moneda, c.cat_num ID, c.cat_sist "
            frm.Tabla = " Catalogos c "
            frm.FiltroText = " Enter The Name Of The Currency To Filter "
            frm.Filtro = "  c.cat_clave  "
            frm.Condicion = " cat_clase='Monedas' ORDER BY c.cat_clave LIMIT 5"

            frm.ShowDialog(Me)
            If frm.DialogResult = System.Windows.Forms.DialogResult.OK Then
                celdaIdMoneda.Text = frm.Dato
                celdaMoneda.Text = frm.LLave
                If frm.Dato2 > 1 Then
                    celdaTasa.Text = cFunciones.TasaSegunFecha(dtpFecha.Value.ToString(FORMATO_MYSQL))
                Else
                    celdaTasa.Text = frm.Dato2
                End If
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub dgDetalle_DoubleClick(sender As Object, e As EventArgs) Handles dgDetalle.DoubleClick
        If dgDetalle.Rows.Count = 0 Then Exit Sub
        Try
            Select Case dgDetalle.CurrentCell.ColumnIndex
                Case 9
                    Dim frmF As New frmDateTimePicker
                    frmF.ShowDialog(Me)
                    If frmF.DialogResult = System.Windows.Forms.DialogResult.OK Then
                        dgDetalle.CurrentRow.Cells("col_envio").Value = frmF.LLave
                    End If
                Case 13
                    Dim frmF As New frmDateTimePicker
                    frmF.ShowDialog(Me)
                    If frmF.DialogResult = System.Windows.Forms.DialogResult.OK Then
                        dgDetalle.CurrentRow.Cells("col_presentado").Value = frmF.LLave
                    End If
                Case 17
                    Dim frmF As New frmDateTimePicker
                    frmF.ShowDialog(Me)
                    If frmF.DialogResult = System.Windows.Forms.DialogResult.OK Then
                        dgDetalle.CurrentRow.Cells("col_pago").Value = frmF.LLave
                    End If
            End Select


        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub
    Private Sub dgLista_DoubleClick(sender As Object, e As EventArgs) Handles dgLista.DoubleClick
        Dim año As Integer
        Dim numero As Integer
        Me.Tag = "Mod"
        If dgLista.SelectedRows.Count = INT_CERO Then Exit Sub
        'captura el año,numero del panelprincipal dglista
        MostrarLista(0)
        año = dgLista.SelectedCells(0).Value
        numero = dgLista.SelectedCells(1).Value
        LimpiarPanelOrden()
        CargarEncabezado(numero, año)
        CargarReferencia(año, numero)
        CargarDetalle(numero, año)
    End Sub

    Private Sub botonActualizar_Click(sender As Object, e As EventArgs) Handles botonActualizar.Click
        CargarLista()
    End Sub

    Private Sub dgDetalle_SelectionChanged(sender As Object, e As EventArgs) Handles dgDetalle.SelectionChanged
        VerInformacionDeHilo()
    End Sub

    Private Sub Encabezado1_ClickGuardar(sender As Object, click As Boolean) Handles Encabezado1.ClickGuardar

        If logEditar = True Or Me.Tag = "Nuevo" Then
            Dim numDoc As Integer = 0

            If VerificarDatos() = True Then
                If celdaNumero.Text = NO_FILA Then
                    numDoc = cFunciones.NuevoId(catalogos)
                    celdaNumero.Text = numDoc
                End If
                If GuardarDocumento(celdaNumero.Text, celdaAño.Text) = True Then
                    GuardarDetalle(celdaNumero.Text, celdaAño.Text)
                    GuardarRelacion(celdaNumero.Text, celdaAño.Text)
                    If Me.Tag = "Nuevo" Then
                        cFunciones.EscribirRegistro("Dcmtos_HDR", clsFunciones.AccEnum.acAdd, 0, 398, celdaAño.Text, celdaNumero.Text)
                        MsgBox("Successfully Saved Document", vbInformation, "Notice")
                    Else
                        cFunciones.EscribirRegistro("Dcmtos_HDR", clsFunciones.AccEnum.acUpdate, 0, 398, celdaAño.Text, celdaNumero.Text)
                        MsgBox("Successfully Updated Document", vbInformation, "Notice")
                    End If

                    If MsgBox("Do you want to close the document?", vbQuestion + vbYesNo, "Notice") = vbYes Then
                        MostrarLista()
                    End If
                    Me.Tag = "Mod"
                End If
            Else
                MsgBox("Enter the minimum data to be able to Save", vbInformation)

            End If
        Else
            MsgBox("You do not have access to edit this document", vbInformation)
        End If
    End Sub


    Private Sub botonAgregarFactura_Click(sender As Object, e As EventArgs) Handles botonAgregarFactura.Click
        If celdaidCliente.Text > 0 Then
            Dim frm As New frmSeleccionar
            Dim strTabla As String = STR_VACIO
            Dim strCondicion As String = STR_VACIO
            Dim strFila As String = STR_VACIO
            Dim strCampos As String = STR_VACIO

            strTabla = " Dcmtos_HDR a LEFT JOIN Dcmtos_DTL b ON b.DDoc_Sis_Emp= a.HDoc_Sis_Emp AND b.DDoc_Doc_Cat = a.HDoc_Doc_Cat AND b.DDoc_Doc_Ano = a.HDoc_Doc_Ano AND b.DDoc_Doc_Num = a.HDoc_Doc_Num "
            strCondicion = " HDoc_Sis_Emp = {empresa} AND (HDoc_Doc_Cat = 36) AND (HDoc_Emp_Cod = {cod}) AND HDoc_Doc_Status = 1 AND (COALESCE(( "
            strCondicion &= " Select SUM(c.PDoc_QTY_Pro) "
            strCondicion &= " From Dcmtos_DTL_Pro c "
            strCondicion &= " WHERE c.PDoc_Sis_Emp = b.DDoc_Sis_Emp AND c.PDoc_Par_Cat = b.DDoc_Doc_Cat AND c.PDoc_Par_Ano = b.DDoc_Doc_Ano AND c.PDoc_Par_Num = b.DDoc_Doc_Num AND c.PDoc_Par_Lin = b.DDoc_Doc_Lin AND c.PDoc_Chi_Cat = 398), 0) < b.DDoc_Prd_QTY) "

            strCondicion = Replace(strCondicion, "{empresa}", Sesion.IdEmpresa)
            strCondicion = Replace(strCondicion, "{cod}", celdaidCliente.Text)

            If (Sesion.IdEmpresa = 12 And intPais = 310) Or Sesion.IdEmpresa = 14 Or Sesion.IdEmpresa = 16 Then
                strCampos = " a.HDoc_DR1_Dbl numero2, "
            Else
                strCampos = " a.HDoc_Doc_Num numero, "
            End If
            strCampos &= " a.HDoc_Doc_Fec fecha, COALESCE(a.HDoc_DR1_Num,'') referencia, a.HDoc_Usuario usuario, a.HDoc_Doc_Cat tipo, a.HDoc_Doc_Ano anio"

            Try
                frm.Titulo = "Facturas"
                frm.Campos = strCampos
                frm.Tabla = strTabla
                frm.Condicion = strCondicion
                frm.FiltroText = " Seleccione una Factura"
                frm.Filtro = " a.HDoc_Doc_Num numero "
                frm.Ordenamiento = " a.HDoc_Doc_Ano DESC,"
                frm.TipoOrdenamiento = " a.HDoc_Doc_Num DESC"
                frm.Limite = 20
                frm.ShowDialog(Me)

                If frm.DialogResult = System.Windows.Forms.DialogResult.OK Then
                    strFila = frm.ListaClientes.SelectedCells(4).Value & "|"
                    strFila &= frm.ListaClientes.SelectedCells(5).Value & "|"
                    strFila &= frm.ListaClientes.SelectedCells(0).Value & "|"
                    strFila &= frm.ListaClientes.SelectedCells(1).Value & "|"
                    strFila &= frm.ListaClientes.SelectedCells(3).Value & "|"
                    strFila &= frm.ListaClientes.SelectedCells(2).Value & "|"
                    strFila &= INT_CERO

                    cFunciones.AgregarFila(dgFactura, strFila)
                End If

            Catch ex As Exception
                MsgBox(ex.ToString)
            End Try
        End If
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        dgFactura.CurrentRow.Cells(6).Value = 2
        dgFactura.CurrentRow.Visible = False
    End Sub

    Private Sub dgLista_KeyDown(sender As Object, e As KeyEventArgs) Handles dgLista.KeyDown
        Try
            If e.KeyCode = Keys.F3 Then
                cFunciones.BuscarenLista(dgLista)
                e.Handled = True
                e.SuppressKeyPress = True
            ElseIf e.KeyCode = Keys.F7 Then
                Dim rpt As New clsReportes
                rpt.Historial(dgLista.SelectedCells(1).Value, dgLista.SelectedCells(0).Value, catalogos,)
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub botonImprimir_Click(sender As Object, e As EventArgs) Handles botonImprimir.Click
        Dim intPrint As Integer = 0
        Dim contarOpciones As Integer = 0
        Dim cls As New clsReportes
        If dgDetalle.Rows.Count > 1 Then
            Dim op As New frmOption
            Dim opciones As String = STR_VACIO

            For i As Integer = 0 To dgDetalle.Rows.Count - 1
                opciones = opciones & IIf(i = 0, vbNullString, "|") & "Line #" & i + 1 & " - " & dgDetalle.Rows(i).Cells("col_descripcion").Value & "(" & dgDetalle.Rows(i).Cells("col_Contrato").Value & ")"
                contarOpciones = contarOpciones + 1
            Next
            opciones = "Whole document" & "|" & opciones
            op.Titulo = "Printing"
            op.Mensaje = "Select that you want to print"
            op.Opciones = opciones

            If op.ShowDialog = System.Windows.Forms.DialogResult.OK Then
                If op.Seleccion = 0 Then
                    cls.DebiteNote(celdaNumero.Text, celdaAño.Text)
                Else
                    For j As Integer = 0 To dgDetalle.Rows.Count - 1
                        If op.Seleccion = (dgDetalle.Rows(j).Index + 1) Then  'dgDetalle.Rows(j).Cells("col_linea").Value Then
                            cls.DebiteNote(celdaNumero.Text, celdaAño.Text, dgDetalle.Rows(j).Cells("col_linea").Value)
                        End If
                    Next
                End If
            End If
        Else
            cls.DebiteNote(celdaNumero.Text, celdaAño.Text)
        End If

    End Sub
    Private Sub Encabezado1_ClickBorrar(sender As Object, click As Boolean) Handles Encabezado1.ClickBorrar
        If LogBorrar = True Then
            If MsgBox("The document will be permanently deleted, do you want to continue?", vbQuestion + vbYesNo, "Question") = vbYes Then
                BorrarEncabezado(celdaNumero.Text, celdaAño.Text)
                BorrarDetalle(celdaNumero.Text, celdaAño.Text)
                BorrarDtl_Pro(celdaNumero.Text, celdaAño.Text)
                cFunciones.EscribirRegistro("Dcmtos_HDR", clsFunciones.AccEnum.acDelete, 0, 398, celdaAño.Text, celdaNumero.Text)
                MostrarLista()
            End If
        End If
    End Sub

    Private Sub dtpFecha_ValueChanged(sender As Object, e As EventArgs) Handles dtpFecha.ValueChanged
        If celdaTasa.Text > 1 Then
            celdaTasa.Text = cFunciones.TasaSegunFecha(dtpFecha.Value.ToString(FORMATO_MYSQL))
        End If
    End Sub


#End Region

End Class