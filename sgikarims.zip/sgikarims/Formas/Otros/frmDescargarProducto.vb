﻿Public Class frmDescargarProducto

#Region "Variable"
    Dim intCod As Integer = INT_CERO
    Dim intNum As Integer = INT_CERO
    Dim intLin As Integer = INT_CERO
    Dim intAnio As Integer = INT_CERO
    Dim intProcess As Integer = INT_CERO
    Dim intUMedida As Integer

    Dim strDesc As String = STR_VACIO
    Dim strClas As String = STR_VACIO
    Dim strReferencia As String = STR_VACIO
    Dim strCodigoMat As String = STR_VACIO

    Dim dblCost As Double
    Dim dblCant As Double

    Dim logAceptar As Boolean

#End Region


#Region "Propiedades"
    Public Property Code As Integer
        Get
            Return intCod
        End Get
        Set(value As Integer)
            intCod = value
        End Set
    End Property

    Public Property Number As Integer
        Get
            Return intNum
        End Get
        Set(value As Integer)
            intNum = value
        End Set
    End Property

    Public Property Line As Integer
        Get
            Return intLin
        End Get
        Set(value As Integer)
            intLin = value
        End Set
    End Property

    Public Property Anio As Integer
        Get
            Return intAnio
        End Get
        Set(value As Integer)
            intAnio = value
        End Set
    End Property

    Public Property Description As String
        Get
            Return strDesc
        End Get
        Set(value As String)
            strDesc = value
        End Set
    End Property

    Public Property classification As String
        Get
            Return strClas
        End Get
        Set(value As String)
            strClas = value
        End Set
    End Property

    Public Property Cost As Double
        Get
            Return dblCost
        End Get
        Set(value As Double)
            dblCost = value
        End Set
    End Property

    Public Property Quantity As Double
        Get
            Return dblCant
        End Get
        Set(value As Double)
            dblCant = value
        End Set
    End Property


    Public Property Aceptar As Boolean
        Get
            Return logAceptar
        End Get
        Set(value As Boolean)
            logAceptar = value
        End Set
    End Property

    Public Property Proceso As Integer
        Get
            Return intProcess
        End Get
        Set(value As Integer)
            intProcess = value
        End Set
    End Property

    Public Property Medida As Integer
        Get
            Return intUMedida
        End Get
        Set(value As Integer)
            intUMedida = value
        End Set
    End Property

    Public Property Referencia As String
        Get
            Return strReferencia
        End Get
        Set(value As String)
            strReferencia = value
        End Set
    End Property

    Public Property CodigoMat As String
        Get
            Return strCodigoMat
        End Get
        Set(value As String)
            strCodigoMat = value
        End Set
    End Property

#End Region




#Region "Procedimientos"

    Private Function SQLMostrarDescargos(Optional ByVal Agrega As Boolean = True)
        Dim frm As New frmProduccion
        Dim strSQL As String = STR_VACIO
        strSQL = " Select l1.*, (l1.Ingreso-l1.Egreso) saldo "
        strSQL &= "    FROM( "
        strSQL &= "      Select ifnull(d.DDoc_Prd_Cod, 0) Codigo, m.det_num, h.HDoc_DR1_Num Referencia, d.DDoc_Doc_Num Numero, {faseA} Descripcion, Ifnull(d.DDoc_RF1_Txt, '') Clasificacion, d.DDoc_Prd_NET Costo, d.DDoc_Doc_Lin Linea, d.DDoc_RF1_Dbl Ingreso, d.DDoc_Prd_UM UMedida, ( "
        strSQL &= "          Select IFNULL(SUM(dt.DDoc_Prd_QTY),0) "
        strSQL &= "              From Dcmtos_DTL_Pro p "
        strSQL &= "                  Left Join Dcmtos_DTL dt ON dt.DDoc_Sis_Emp= p.PDoc_Sis_Emp And dt.DDoc_Doc_Cat = p.PDoc_Chi_Cat And dt.DDoc_Doc_Ano = p.PDoc_Chi_Ano And dt.DDoc_Doc_Num= p.PDoc_Chi_Num And dt.DDoc_Doc_Lin = p.PDoc_Chi_Lin "
        strSQL &= "                      WHERE p.PDoc_Sis_Emp = d.DDoc_Sis_Emp And p.PDoc_Par_Cat = d.DDoc_Doc_Cat And p.PDoc_Par_Ano = d.DDoc_Doc_Ano And p.PDoc_Par_Num = d.DDoc_Doc_Num And p.PDoc_Par_Lin = d.DDoc_Doc_Lin) Egreso "
        strSQL &= "                          From Dcmtos_DTL d "
        strSQL &= "                          LEFT JOIN Dcmtos_HDR h ON h.HDoc_Sis_Emp = d.DDoc_Sis_Emp AND h.HDoc_Doc_Cat = d.DDoc_Doc_Cat AND h.HDoc_Doc_Ano = d.DDoc_Doc_Ano AND h.HDoc_Doc_Num = d.DDoc_Doc_Num "
        strSQL &= "                      Left Join Inventarios i ON i.inv_sisemp = d.DDoc_Sis_Emp And i.inv_numero = d.DDoc_Prd_Cod "
        strSQL &= "                  Left Join Articulos a ON a.art_sisemp = i.inv_sisemp And a.art_codigo = i.inv_artcodigo "
        strSQL &= "              LEFT JOIN Materiales m ON m.det_sisemp = a.art_sisemp AND m.det_articulo = a.art_codigo "

        If Agrega = True Then ' Condicion que permite ver si es un ingreso nuevo (Agrega = True) de lo contrario es modificación
            strSQL &= "          WHERE d.DDoc_Sis_Emp = {empresa} And d.DDoc_Doc_Cat = {catalogo} AND {faseB} in({acumula}) "
            'If Proceso <= 4 Then ' Esta condición permite que elija Fibra solo hasta Drawing
            '    strSQL &= " And {opcion} 2209 "
            '    strSQL = Replace(strSQL, "{opcion}", "a.art_clase = ")
            'End If

            'If Proceso > 1 Then ' Esta condicion es para que Vaya haciendo descargos de los procesos anteriores solo Blowroom hace descargo directo (no tiene proceso previo)
            '    strSQL &= " AND h.HDoc_Doc_Status = 1 AND h.HDoc_Pro_DNum IN({process})  "
            '    If Proceso = 3 Then
            '        strSQL &= " AND a.art_codigo = 1 " ' Esta condicion es para cuando entre a Peinado solo Jale Algodón
            '    End If
            'End If
            strSQL &= " )l1"
        Else
            strSQL &= "          WHERE d.DDoc_Sis_Emp = {empresa} And d.DDoc_Doc_Cat = {catalogo} AND d.DDoc_Doc_Ano= {anio}  AND d.DDoc_Doc_Num = {num} )l1 "
            strSQL = Replace(strSQL, "{num}", intNum)
        End If

        strSQL &= " HAVING saldo>0 "
        strSQL &= " ORDER BY l1.Numero ASC "



        strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)

        If Proceso = 1 Then ' Cuando el Proceso es Blowroom descarga de Catalogo 47
            strSQL = Replace(strSQL, "{catalogo}", 47)
            strSQL = Replace(strSQL, "{faseA}", "d.DDoc_Prd_Des ")
            strSQL = Replace(strSQL, "{faseB}", "m.det_num ")
        Else ' Cuando el proceso es > a 1 descarga de catalogo 952 
            strSQL = Replace(strSQL, "{catalogo}", 952)
            strSQL = Replace(strSQL, "{faseA}", "h.HDoc_RF2_Txt ")
            strSQL = Replace(strSQL, "{faseB}", "d.DDoc_RF1_Num ")
        End If

        strSQL = Replace(strSQL, "{anio}", intAnio)
        strSQL = Replace(strSQL, "{acumula}", CodigoMat)

        If Proceso = 4 Then
            strSQL = Replace(strSQL, "{process}", Proceso - 1 & "," & Proceso - 2) ' hace descargo del Proceso Previo
        Else
            strSQL = Replace(strSQL, "{process}", Proceso - 1) ' hace descargo del Proceso Previo
        End If

        Return strSQL

    End Function

    Public Sub MostrarDescargos()
        Dim strFila As String = STR_VACIO
        Dim strSQL As String = STR_VACIO
        Dim frmPr As New frmProduccion

        Dim REA As MySqlDataReader
        Dim COM As MySqlCommand

        Try
            BarraTitulo1.CambiarTitulo("Download product")
            strSQL = SQLMostrarDescargos()

            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSQL, CON)
            REA = COM.ExecuteReader

            If REA.HasRows Then
                Do While REA.Read
                    strFila = REA.GetInt32("Codigo") & "|"
                    strFila &= REA.GetInt32("Numero") & "|"
                    strFila &= REA.GetString("Descripcion") & "|"
                    strFila &= REA.GetString("Clasificacion") & "|"
                    strFila &= REA.GetDouble("Costo") & "|"
                    strFila &= REA.GetInt32("Linea") & "|"
                    strFila &= REA.GetDouble("Ingreso") & "|"
                    strFila &= REA.GetDouble("Egreso") & "|"
                    strFila &= REA.GetDouble("Saldo") & "|"
                    strFila &= INT_CERO & "|"
                    strFila &= REA.GetInt32("UMedida") & "|"
                    If REA.GetInt32("UMedida") = 69 Then
                        strFila &= "LBS" & "|"
                    ElseIf REA.GetInt32("UMedida") = 70 Then
                        strFila &= "KGS" & "|"
                    End If
                    strFila &= REA.GetString("Referencia")

                    cFunciones.AgregarFila(dgDescargos, strFila)
                Loop
            End If

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try

    End Sub

    Public Sub ModificarDescargos()
        Dim strFila As String = STR_VACIO
        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader
        Dim strSQL As String = STR_VACIO

        Dim Saldo As Double
        Dim SaldoTemp As Double

        Try


            strSQL = SQLMostrarDescargos(False)

            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSQL, CON)
            REA = COM.ExecuteReader

            If REA.HasRows Then
                REA.Read()
                Saldo = REA.GetDouble("saldo")

                SaldoTemp = Saldo + dblCant 

                strFila = REA.GetInt32("Codigo") & "|"
                strFila &= REA.GetInt32("Numero") & "|"
                strFila &= REA.GetString("Descripcion") & "|"
                strFila &= REA.GetString("Clasificacion") & "|"
                strFila &= REA.GetDouble("Costo") & "|"
                strFila &= REA.GetInt32("Linea") & "|"
                strFila &= INT_CERO & "|"
                strFila &= INT_CERO & "|"
                strFila &= SaldoTemp & "|"
                strFila &= dblCant & "|"
                strFila &= REA.GetInt32("UMedida") & "|"
                If REA.GetInt32("UMedida") = 69 Then
                    strFila &= "LBS"
                ElseIf REA.GetInt32("UMedida") = 70 Then
                    strFila &= "KGS"
                End If

                cFunciones.AgregarFila(dgDescargos, strFila)
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub
#End Region


#Region "Eventos"

    Private Sub frmDescargarProducto_Load(sender As Object, e As EventArgs) Handles Me.Load

        If logAceptar = True Then
            ModificarDescargos()
        Else
            MostrarDescargos()
        End If

    End Sub

    Private Sub botonCancelar_Click(sender As Object, e As EventArgs) Handles botonCancelar.Click
        Aceptar = False
        Me.DialogResult = System.Windows.Forms.DialogResult.Cancel
    End Sub

    Private Sub botonAceptar_Click(sender As Object, e As EventArgs) Handles botonAceptar.Click

        If CDbl(dgDescargos.SelectedCells(9).Value) > CDbl(dgDescargos.SelectedCells(8).Value) Then
            MsgBox("You can not enter an amount greater than the Balance", vbCritical, "Notice")
            Exit Sub
        Else

            intCod = dgDescargos.SelectedCells(0).Value
            intNum = dgDescargos.SelectedCells(1).Value
            strDesc = dgDescargos.SelectedCells(2).Value
            strClas = dgDescargos.SelectedCells(3).Value
            dblCost = dgDescargos.SelectedCells(4).Value
            intLin = dgDescargos.SelectedCells(5).Value
            dblCant = dgDescargos.SelectedCells(9).Value
            intUMedida = dgDescargos.SelectedCells(10).Value
            strReferencia = dgDescargos.SelectedCells(12).Value

            Aceptar = True
            Me.DialogResult = System.Windows.Forms.DialogResult.OK
        End If

    End Sub
#End Region

End Class