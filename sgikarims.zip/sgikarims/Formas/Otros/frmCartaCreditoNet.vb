﻿Public Class frmCartaCreditoNet
#Region "Variables"
    Dim strKey As String = STR_VACIO
    Dim logInsertar As Boolean = False
    Dim logConsultar As Boolean = False
    Dim logEditar As Boolean = False
    Dim LogBorrar As Boolean = False

    Private Const CATALOGO = 894
#End Region
#Region "Propiedades"
    Public Property Key As String
        Get
            Return strKey
        End Get
        Set(value As String)
            strKey = value
        End Set
    End Property
#End Region
#Region "Procedimientos"
    Private Sub BloquearBotones(Optional ByVal logBloquear As Boolean = True)
        If logBloquear = True Then
            Encabezado1.botonBorrar.Enabled = False
            '  botonImprimir.Enabled = False
            Encabezado1.botonGuardar.Enabled = False

        Else
            Encabezado1.botonBorrar.Enabled = True
            Encabezado1.botonGuardar.Enabled = True
            '  botonImprimir.Enabled = True
        End If
    End Sub
    Private Sub Accesos()
        Dim cAcesos As New clsAccesos
        Try
            If cAcesos.Accesos(strKey) = True Then
                logInsertar = cAcesos.Insertar
                logEditar = cAcesos.Editar
                LogBorrar = cAcesos.Borrar
                logConsultar = cAcesos.Consultar

            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub
    Private Function SQLLista() As String
        Dim strSQL As String

        strSQL = " SELECT HDR.HDoc_Doc_Fec fecha, HDR.HDoc_Doc_Num Numero,HDR.HDoc_Doc_Ano Anio ,IFNULL(c.cli_nombre,c.cli_cliente) Cliente,HDR.HDoc_RF1_Cod LC ,HDoc_DR1_Num PO , IF(HDR.HDoc_Doc_Status=0,'FINALIZED','ACTIVE') Estado "
        strSQL &= " FROM Dcmtos_HDR HDR"
        strSQL &= " LEFT JOIN Clientes c ON c.cli_sisemp = HDR.HDoc_Sis_Emp AND c.cli_codigo = HDR.HDoc_Emp_Cod "
        strSQL &= " WHERE HDR.HDoc_Sis_Emp = {empresa} AND HDR.HDoc_Doc_Cat = {catalogo} "
        If checkFiltroFecha.Checked = True Then
            strSQL &= "     AND (HDoc_Doc_Fec BETWEEN '{fechainicial}' AND '{fechafinal}')"
        End If
        strSQL &= " ORDER by HDR.HDoc_Doc_Fec desc , HDR.HDoc_Doc_Num DESC "
        strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
        strSQL = Replace(strSQL, "{catalogo}", 894)
        strSQL = Replace(strSQL, "{fechainicial}", dtpFechaInicial.Value.ToString(FORMATO_MYSQL))
        strSQL = Replace(strSQL, "{fechafinal}", dtpFechaFinal.Value.ToString(FORMATO_MYSQL))
        Return strSQL
    End Function
    Public Sub CargarListaPrincipal()
        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader
        Dim strSQL As String = STR_VACIO
        Dim strLinea As String = STR_VACIO

        strSQL = SQLLista()
        MyCnn.CONECTAR = strConexion
        COM = New MySqlCommand(strSQL, CON)
        REA = COM.ExecuteReader
        dgLista.Rows.Clear()
        If REA.HasRows Then
            dgLista.Rows.Clear()
            Do While REA.Read
                strLinea = REA.GetInt32("Numero") & "|" ' CODIGO
                strLinea &= REA.GetInt32("Anio") & "|" ' Año
                strLinea &= REA.GetDateTime("Fecha").ToString(FORMATO_MYSQL) & "|" ' Fecha
                strLinea &= REA.GetString("Cliente") & "|" ' Cliente
                strLinea &= REA.GetString("LC") & "|" ' LC
                strLinea &= REA.GetString("PO") & "|" ' PO   
                strLinea &= REA.GetString("Estado") ' ESTADO 
                If REA.GetString("Estado") = "CANCELED" Then
                    cFunciones.AgregarFila(dgLista, strLinea, Color.Coral)
                Else
                    cFunciones.AgregarFila(dgLista, strLinea)
                End If
            Loop

        End If

    End Sub
    Private Sub MostrarLista(Optional ByVal logMostrar As Boolean = True, Optional logInsert As Boolean = False)
        Dim cfun As New clsFunciones
        If logMostrar = True Then
            'ocultar panel de documento
            panelDocumento.Dock = DockStyle.None
            panelDocumento.Visible = False
            'actualizar Titulo
            BarraTitulo1.CambiarTitulo("Letter of Credit")
            'Cargar Datos
            'cfun.CargarLista(dgLista, SQLlista, False)
            CargarListaPrincipal()
            'Mostrar Panel Filtro
            panelLista.Visible = True
            panelLista.Dock = DockStyle.Fill
            BloquearBotones()
            'Me.Tag = ""
        Else
            'Ocultar Panel Filtro
            panelLista.Visible = False
            panelLista.Dock = DockStyle.None
            'Mostrar panel de documento
            panelDocumento.Dock = DockStyle.Fill
            panelDocumento.Visible = True
            'Verifica si se va a crear un nuevo documento o se va modifica
            If logInsert = False Then
                BarraTitulo1.CambiarTitulo("Modify Record")
                Me.Tag = "Mod"
                BloquearBotones(False)
                'botonImprimir.Enabled = True
            Else
                BarraTitulo1.CambiarTitulo("New Record")
                Me.Tag = "Nuevo"
                BloquearBotones(False)
                Limpiar()
                'botonImprimir.Enabled = False

                'LimpiarPanelOrden()
            End If

            dgLista.DataSource = Nothing
        End If
    End Sub
    Public Sub Limpiar()
        celdaNumero.Text = NO_FILA
        celdaAño.Text = NO_FILA
        celdaCliente.Text = STR_VACIO
        celdaidCliente.Text = NO_FILA
        celdaDireccion.Text = STR_VACIO
        celdaNit.Text = STR_VACIO
        celdaMoneda.Text = STR_VACIO
        celdaidMoneda.Text = STR_VACIO
        celdaTasa.Text = INT_UNO
        dtpFecha.Value = Now()
        celdaTotal.Text = INT_CERO
        celdaAño.Text = cFunciones.AñoMySQL
        checkActive.Checked = True
        celdaPO.Text = STR_VACIO
        dtpFechaExpiracion.Value = Now()
        celdaDrawee.Text = STR_VACIO
        celdaComentario.Text = STR_VACIO
        dgDetalle.Rows.Clear()
        celdaPO.ReadOnly = False
        celdaLC.Text = STR_VACIO
        dgCargoReceipt.Rows.Clear()
        celdaTotalYRM.Clear()
    End Sub
    Public Function ValidarCampos()
        Dim logValidacion As Boolean = True
        Try
            If celdaidCliente.Text = NO_FILA Then
                MsgBox("Select Cliente ", vbExclamation, "NOTICE")
                celdaCliente.Focus()
                logValidacion = False
                Exit Function
            End If
            If celdaPO.Text = STR_VACIO Then
                MsgBox("Blank PO Name", vbExclamation, "NOTICE")
                celdaPO.Focus()
                logValidacion = False
                Exit Function
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        Return logValidacion
    End Function
    Private Function AgregarCamposDatagridDetalle(ByVal num As Integer, ByVal contador As Integer, ByVal Cantidad As Double, ByVal idMedida As Integer, ByVal medida As String, ByVal Total As Double, ByVal FechaPresentacion As String, ByVal anio As Integer, ByVal numero As Integer, ByVal linea As Integer) As Boolean
        Dim strFila As String = STR_VACIO
        Dim cfun As New clsFunciones
        Dim logVerificar As Boolean = True
        Dim intContador As Integer = INT_CERO
        If dgDetalle.Rows.Count = 0 Then
            strFila = num & "|"
            strFila &= contador & "|"
            strFila &= Cantidad & "|"
            strFila &= idMedida & "|"
            strFila &= medida & "|"
            strFila &= Total.ToString("###0.00") & "|"
            strFila &= "" & "|"
            strFila &= "" & "|"
            strFila &= 395 & "|"
            strFila &= anio & "|"
            strFila &= numero & "|"
            strFila &= linea & "|"
            strFila &= INT_CERO
            cfun.AgregarFila(dgDetalle, strFila)
        Else
            For i As Integer = 0 To dgDetalle.Rows.Count - 1
                If dgDetalle.Rows(i).Visible = True Then
                    intContador = intContador + 1
                    If dgDetalle.Rows(i).Cells("colNumero").Value = num Then
                        MsgBox("The line that select is already repeated")
                        logVerificar = False
                        Exit Function
                    End If
                End If
            Next
            'If Me.Tag = "Nuevo" Then
            '    strFila = num & "|"
            '    strFila &= contador & "|"
            '    strFila &= Cantidad & "|"
            '    strFila &= idMedida & "|"
            '    strFila &= medida & "|"
            '    strFila &= Total.ToString("###0.00") & "|"
            '    strFila &= "" & "|"
            '    strFila &= "" & "|"
            '    strFila &= 395 & "|"
            '    strFila &= anio & "|"
            '    strFila &= numero & "|"
            '    strFila &= linea & "|"
            '    strFila &= INT_CERO
            '    cfun.AgregarFila(dgDetalle, strFila)
            'Else
            If logVerificar = True Then
                    strFila = num & "|"
                    strFila &= intContador + 1 & "|"
                    strFila &= Cantidad & "|"
                    strFila &= idMedida & "|"
                    strFila &= medida & "|"
                    strFila &= Total.ToString("###0.00") & "|"
                    strFila &= "" & "|"
                    strFila &= "" & "|"
                    strFila &= 395 & "|"
                    strFila &= anio & "|"
                    strFila &= numero & "|"
                    strFila &= linea & "|"
                    strFila &= INT_CERO
                    cfun.AgregarFila(dgDetalle, strFila)
                End If
            ' End If
        End If
            Return logVerificar
    End Function
    Private Function SQLCargoReceipt(ByVal Anio As Integer, ByVal Num As Integer)
        Dim strSQL As String = STR_VACIO
        strSQL = " SELECT IFNULL(z.HDoc_Doc_Num,0) NumC, IFNULL(z.HDoc_DR1_Dbl,0) NumEC, IFNULL(SUM((d.DDoc_Prd_QTY * d.DDoc_Prd_NET)),0) Total, h.HDoc_Doc_Num Num,h.HDoc_DR1_Dbl NumE "
        strSQL &= "     FROM Dcmtos_HDR h "
        strSQL &= "         LEFT JOIN Dcmtos_DTL_Pro p36 ON p36.PDoc_Sis_Emp = h.HDoc_Sis_Emp AND p36.PDoc_Chi_Cat = h.HDoc_Doc_Cat AND p36.PDoc_Chi_Ano = h.HDoc_Doc_Ano AND  p36.PDoc_Chi_Num = h.HDoc_Doc_Num  "
        strSQL &= "                 LEFT JOIN Dcmtos_DTL_Pro p ON p.PDoc_Sis_Emp = p36.PDoc_Sis_Emp AND p.PDoc_Par_Cat = p36.PDoc_Par_Cat AND p.PDoc_Par_Ano = p36.PDoc_Par_Ano AND p.PDoc_Par_Num = p36.PDoc_Par_Num AND p.PDoc_Par_Lin = p36.PDoc_Par_Lin AND p.PDoc_Chi_Cat = 397 "
        strSQL &= "                     LEFT JOIN Dcmtos_DTL d ON d.DDoc_Sis_Emp = p.PDoc_Sis_Emp AND d.DDoc_Doc_Cat = p.PDoc_Chi_Cat AND d.DDoc_Doc_Ano = p.PDoc_Chi_Ano AND d.DDoc_Doc_Num = p.PDoc_Chi_Num  "
        strSQL &= "                         LEFT JOIN Dcmtos_HDR z ON z.HDoc_Sis_Emp = d.DDoc_Sis_Emp AND z.HDoc_Doc_Cat = d.DDoc_Doc_Cat AND z.HDoc_Doc_Ano = d.DDoc_Doc_Ano AND z.HDoc_Doc_Num = d.DDoc_Doc_Num "
        strSQL &= "                             WHERE h.HDoc_Sis_Emp = {empresa} AND h.HDoc_Doc_Cat = 395 AND  h.HDoc_Doc_Ano = {anio} AND h.HDoc_Doc_Num = {numero} "
        strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
        strSQL = Replace(strSQL, "{anio}", Anio)
        strSQL = Replace(strSQL, "{numero}", Num)
        Return strSQL
    End Function
    Public Sub CargarCargoReceipt(ByVal Anio As Integer, ByVal Num As Integer)
        Dim strSQL As String = STR_VACIO
        Dim strFila As String = STR_VACIO
        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader
        Try
            strSQL = SQLCargoReceipt(Anio, Num)
            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSQL, CON)
            REA = COM.ExecuteReader
            If REA.HasRows Then
                Do While REA.Read
                    If (REA.GetInt32("NumC") <> 0) Or (REA.GetInt32("NumEC")) <> INT_CERO Then
                        If (Sesion.IdEmpresa = 16) Or Sesion.IdEmpresa = 14 Then
                            strFila = REA.GetInt32("NumEC") & "|"
                        Else
                            strFila = REA.GetInt32("NumC") & "|"
                        End If
                        strFila &= REA.GetDouble("Total").ToString("###0.00") & "|"
                        If (Sesion.IdEmpresa = 16) Or Sesion.IdEmpresa = 14 Then
                            strFila &= REA.GetInt32("NumE")
                        Else
                            strFila &= REA.GetInt32("Num")
                        End If
                        cFunciones.AgregarFila(dgCargoReceipt, strFila)
                    End If
                Loop
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub
    Public Sub CalcularTotales()
        Dim dblTotal As Double = INT_CERO
        If dgDetalle.Rows.Count = 0 Then Exit Sub
        Try
            For i As Integer = 0 To dgDetalle.Rows.Count - 1
                dblTotal = dblTotal + dgDetalle.Rows(i).Cells("colTotal").Value
            Next
            celdaTotalYRM.Text = dblTotal.ToString("###0.00")
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub
    Public Sub DeshabilitarFormas()
        celdaCliente.Enabled = False
        celdaDireccion.Enabled = False
        celdaNit.Enabled = False
        dgDetalle.ReadOnly = True
        celdaDrawee.Enabled = False
        celdaComentario.Enabled = False
        dtpFechaExpiracion.Enabled = False
        ' Encabezado1.botonGuardar.Enabled = False
        '   Encabezado1.botonNuevo.Enabled = False
        botonAgregar.Enabled = False
        botonEliminar.Enabled = False
        dtpFecha.Enabled = False
        checkActive.Enabled = False
        botonMoneda.Enabled = False
        celdaPO.Enabled = False
        PanelControles.Enabled = False
    End Sub
    Public Sub HabilitarFormas()
        celdaCliente.Enabled = True
        celdaDireccion.Enabled = True
        celdaNit.Enabled = True
        dgDetalle.ReadOnly = False
        celdaDrawee.Enabled = True
        celdaComentario.Enabled = True
        dtpFechaExpiracion.Enabled = True
        ' Encabezado1.botonGuardar.Enabled = False
        '       Encabezado1.botonNuevo.Enabled = True
        botonAgregar.Enabled = True
        botonEliminar.Enabled = True
        dtpFecha.Enabled = True
        checkActive.Enabled = True
        botonMoneda.Enabled = True
        celdaPO.Enabled = True
        botonCliente.Enabled = True
        PanelControles.Enabled = True
    End Sub
    Private Function NuevaCartaCredito() As Integer
        Dim strSQL As String = STR_VACIO
        Dim conec As New MySqlConnection
        Dim COM As MySqlCommand
        Dim CodigoProyecto As Integer

        strSQL = " Select IFNULL(MAX(HDR.HDoc_Doc_Num),0)+1 NUMERO  "
        strSQL &= " FROM Dcmtos_HDR HDR"
        strSQL &= " WHERE HDR.HDoc_Sis_Emp = {empresa} And HDR.HDoc_Doc_Cat = {catalogo} And HDR.HDoc_Doc_Ano = {anio} "

        strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
        strSQL = Replace(strSQL, "{catalogo}", 894)
        strSQL = Replace(strSQL, "{anio}", cFunciones.AñoMySQL)

        conec = New MySqlConnection(strConexion)
        conec.Open()
        COM = New MySqlCommand(strSQL, conec)
        CodigoProyecto = COM.ExecuteScalar
        conec.Close()
        conec.Dispose()
        conec = Nothing
        System.GC.Collect()
        Return CodigoProyecto
    End Function
    Private Function NuevaLinea(ByVal Codigo As Integer) As Integer
        Dim strSQL As String = STR_VACIO
        Dim conec As New MySqlConnection
        Dim COM As MySqlCommand
        Dim LineaNueva As Integer

        strSQL = " Select IFNULL(MAX(DTL.DDoc_Doc_Lin),0) + 1  DTL "
        strSQL &= " FROM Dcmtos_DTL DTL "
        strSQL &= " WHERE DTL.DDoc_Sis_emp = {empresa} And DTL.DDoc_Doc_Cat = {catalogo} And DTL.DDoc_Doc_Ano = {anio} And DTL.DDoc_Doc_Num ={codigo} "

        strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
        strSQL = Replace(strSQL, "{catalogo}", 894)
        strSQL = Replace(strSQL, "{anio}", cFunciones.AñoMySQL)
        strSQL = Replace(strSQL, "{codigo}", Codigo)



        conec = New MySqlConnection(strConexion)
        conec.Open()
        COM = New MySqlCommand(strSQL, conec)
        LineaNueva = COM.ExecuteScalar
        conec.Close()
        conec.Dispose()
        conec = Nothing
        System.GC.Collect()
        Return LineaNueva


    End Function
    Private Function Guardar() As Boolean
        Dim LogVerdadero As Boolean = False
        Dim HDR As New clsDcmtos_HDR
        Try

            HDR.HDOC_SIS_EMP = Sesion.IdEmpresa
            HDR.HDOC_DOC_CAT = 894
            HDR.HDOC_DOC_ANO = celdaAño.Text
            HDR.HDOC_EMP_COD = celdaidCliente.Text
            HDR.HDOC_EMP_NOM = celdaCliente.Text
            HDR.HDOC_EMP_DIR = celdaDireccion.Text
            HDR.HDOC_EMP_NIT = celdaNit.Text
            HDR.HDOC_DOC_MON = celdaidMoneda.Text
            HDR.HDOC_DOC_TC = celdaTasa.Text
            HDR.HDOC_DR1_NUM = celdaPO.Text 'PO
            HDR.HDoc_DR1_Fec_NET = dtpFechaExpiracion.Value ' Fecha Expiracion
            HDR.HDOC_DR2_NUM = celdaDrawee.Text ' Drawee
            HDR.HDOC_RF1_TXT = celdaComentario.Text ' Comentario 
            HDR.HDOC_RF1_COD = celdaLC.Text
            HDR.HDOC_DR1_CAT = celdaTotal.Text ' Amount


            If checkActive.Checked = True Then
                HDR.HDOC_DOC_STATUS = 1 ' Check Activo
            Else
                HDR.HDOC_DOC_STATUS = 0 ' ANULADO

            End If
            If dtpFecha.Format = DateTimePickerFormat.Custom Then
            Else
                HDR.HDoc_Doc_Fec_NET = dtpFecha.Value
            End If

            HDR.CONEXION = strConexion
            If Me.Tag = "Nuevo" Then
                If logInsertar = True Then
                    HDR.HDOC_USUARIO = Sesion.Usuario
                    HDR.HDOC_DOC_NUM = NuevaCartaCredito()
                    cFunciones.EscribirRegistro("Dcmtos_HDR", clsFunciones.AccEnum.acAdd, celdaidCliente.Text, 894, celdaAño.Text, HDR.HDOC_DOC_NUM)
                    If HDR.Guardar = False Then
                        MsgBox(HDR.MERROR.ToString & " Could not save this document ", MsgBoxStyle.Critical)
                    Else
                        LogVerdadero = True

                        If GuardarDetalle(HDR.HDOC_DOC_NUM) = True Then
                            LogVerdadero = True
                        Else
                            LogVerdadero = True
                        End If
                        If GuardarDcmtosPro(HDR.HDOC_DOC_NUM, celdaAño.Text) Then
                            LogVerdadero = True
                        Else
                            LogVerdadero = True
                        End If
                    End If
                        Else
                    MsgBox("Does Not have Permissions")
                End If
            Else

                If logEditar = True Then
                    HDR.HDOC_DOC_NUM = celdaNumero.Text
                    cFunciones.EscribirRegistro("Dcmtos_HDR", clsFunciones.AccEnum.acUpdate, celdaidCliente.Text, 894, celdaAño.Text, celdaNumero.Text)
                    If HDR.Actualizar = False Then
                        MsgBox(HDR.MERROR.ToString & " Could not Modify this document ", MsgBoxStyle.Critical)
                    Else
                        LogVerdadero = True
                        If GuardarDetalle(HDR.HDOC_DOC_NUM) Then
                            LogVerdadero = True
                        Else
                            LogVerdadero = True
                        End If
                        If GuardarDcmtosPro(HDR.HDOC_DOC_NUM, celdaAño.Text) Then
                            LogVerdadero = True
                        Else
                            LogVerdadero = True
                        End If
                    End If
                        Else
                    MsgBox("Does Not Have Permissions")
                End If
            End If

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        Return LogVerdadero
    End Function
    Private Function GuardarDetalle(ByVal Codigo As Integer) As Boolean
        Dim logVerdadero As Boolean = False
        Dim DTL As New clsDcmtos_DTL

        DTL.CONEXION = strConexion
        Try
            For i As Integer = 0 To dgDetalle.RowCount - 1

                DTL.DDOC_SIS_EMP = Sesion.IdEmpresa
                DTL.DDOC_DOC_CAT = 894
                DTL.DDOC_DOC_ANO = celdaAño.Text
                DTL.DDOC_PRD_QTY = dgDetalle.Rows(i).Cells("colCantidad").Value
                DTL.DDOC_PRD_UM = dgDetalle.Rows(i).Cells("colidMedida").Value
                DTL.DDOC_PRD_NET = dgDetalle.Rows(i).Cells("colTotal").Value
                If dgDetalle.Rows(i).Cells("colPresentacion").Value = "" Then
                    DTL.DDOC_RF1_FEC = Nothing
                Else
                    DTL.DDoc_RF1_Fec_NET = dgDetalle.Rows(i).Cells("colPresentacion").Value  ' Presentado 
                End If
                DTL.DDOC_RF1_COD = dgDetalle.Rows(i).Cells("colPago").Value
                If dgDetalle.Rows(i).Cells("colEstado").Value = 0 Then
                    DTL.DDOC_DOC_LIN = NuevaLinea(Codigo)
                    DTL.DDOC_DOC_NUM = Codigo
                    If DTL.Guardar = False Then
                        MsgBox(DTL.MERROR.ToString() & " Could Not Save this document", MsgBoxStyle.Critical)
                        Return False
                        Exit Function
                    Else
                        logVerdadero = True
                    End If
                End If
                If dgDetalle.Rows(i).Cells("colEstado").Value = 1 Then
                    DTL.DDOC_DOC_LIN = dgDetalle.Rows(i).Cells("colLin").Value
                    DTL.DDOC_DOC_NUM = celdaNumero.Text
                    If DTL.Actualizar = False Then
                        MsgBox(DTL.MERROR.ToString & " Could Not Modify this document", MsgBoxStyle.Critical)
                        Return False
                        Exit Function
                    Else
                        logVerdadero = True
                    End If
                End If
                If dgDetalle.Rows(i).Cells("colEstado").Value = 2 Then
                    If Not Me.Tag = "Nuevo" Then
                        BorrarDetalle(Codigo)
                    End If
                End If
            Next
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        Return logVerdadero
    End Function
    Private Function GuardarDcmtosPro(ByVal Codigo As Integer, ByVal Anio As Integer) As Boolean
        Dim logGuardar As Boolean
        Dim clsDTLPro As New clsDcmtos_DTL_Pro
        Try
            For i As Integer = 0 To dgDetalle.Rows.Count - 1
                'Catalogo 395
                clsDTLPro.PDOC_SIS_EMP = Sesion.IdEmpresa
                clsDTLPro.PDOC_PAR_CAT = 395
                clsDTLPro.PDOC_PAR_ANO = dgDetalle.Rows(i).Cells("colAnio").Value
                clsDTLPro.PDOC_PAR_NUM = dgDetalle.Rows(i).Cells("colNum").Value
                clsDTLPro.PDOC_PAR_LIN = dgDetalle.Rows(i).Cells("colLinea").Value
                'Catalogo 894
                clsDTLPro.PDOC_CHI_CAT = 894
                clsDTLPro.PDOC_CHI_ANO = Anio
                clsDTLPro.PDOC_CHI_NUM = Codigo
                clsDTLPro.PDOC_CHI_LIN = dgDetalle.Rows(i).Cells("colLin").Value
                If logInsertar = True Then
                    If dgDetalle.Rows(i).Cells("colEstado").Value = 0 Then
                        If clsDTLPro.Guardar = False Then
                            MsgBox(clsDTLPro.MERROR.ToString() & " Could Not Save this document", MsgBoxStyle.Critical)
                            Return False
                            logGuardar = False
                            Exit Function
                        Else
                            logGuardar = True
                        End If
                    End If
                End If

                If logEditar = True Then
                    If dgDetalle.Rows(i).Cells("colEstado").Value = 1 Then
                        If clsDTLPro.Actualizar = False Then
                            MsgBox(clsDTLPro.MERROR.ToString() & " Could Not update this document", MsgBoxStyle.Critical)
                            Return False
                            logGuardar = False
                            Exit Function
                        Else
                            logGuardar = True
                        End If
                    End If
                End If
                If dgDetalle.Rows(i).Cells("colEstado").Value = 2 Then
                    If clsDTLPro.Borrar = False Then
                        MsgBox(clsDTLPro.MERROR.ToString() & " Could Not update this document", MsgBoxStyle.Critical)
                        Return False
                        logGuardar = False
                        Exit Function
                    Else
                        logGuardar = True
                    End If
                End If

                ' If checkActive.Checked = False Then
                'checkActive.Enabled = False
                'If clsDTLPro.Borrar = False Then
                'MsgBox(clsDTLPro.MERROR.ToString() & " Could Not delete this document", MsgBoxStyle.Critical)
                '     Return False
                '      logGuardar = False
                '       Exit Function
                '    End If
                ' End If
            Next
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        Return logGuardar
    End Function
    Public Function BorrarDetalle(ByVal Codigo As Integer) As Boolean
        Dim LogAceptado As Boolean = False
        Dim DTL As New clsDcmtos_DTL
        Try
            For i As Integer = 0 To dgDetalle.RowCount - 1
                If Me.Tag = "Nuevo" Then
                Else

                    DTL.CONEXION = strConexion
                    DTL.DDOC_SIS_EMP = Sesion.IdEmpresa
                    DTL.DDOC_DOC_CAT = 894
                    DTL.DDOC_DOC_ANO = celdaAño.Text
                    If dgDetalle.Rows(i).Cells("colEstado").Value = 2 Then
                        DTL.DDOC_DOC_LIN = dgDetalle.Rows(i).Cells("colLin").Value
                        DTL.DDOC_DOC_NUM = Codigo
                        If DTL.Borrar = False Then
                            MsgBox(DTL.MERROR.ToString & " Could Not Delete this document", MsgBoxStyle.Critical)
                            Return False
                            Exit Function
                        Else
                            LogAceptado = True
                        End If
                    End If
                End If
            Next
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        Return LogAceptado
    End Function
    Private Function ComprobarDatos() As Boolean
        Dim Comprobar As Boolean = True
        If celdaidCliente.Text = NO_FILA Then
            MsgBox("BLANK CLIENT ")
            Comprobar = False
            Exit Function

        End If
        If celdaPO.Text = vbNullString Then
            MsgBox("BLANK PO Name ")
            Comprobar = False
            Exit Function
        End If
        'If celdaIdSolicitado.Text = vbNullString Then
        '    MsgBox("BLANK REQUESTED")
        '    Comprobar = False
        '    Exit Function
        'End If
        'If strMsg = vbNullString Then
        '    Comprobar = True
        'End If
        Return Comprobar
    End Function
    Private Function ComprobarFila() As Boolean
        Dim LogVerdadero As Boolean = True
        If dgDetalle.Rows.Count = 0 Then
            MsgBox("Fill all fields", MsgBoxStyle.Critical)
            LogVerdadero = False
        Else
            LogVerdadero = True
        End If
        Return LogVerdadero
    End Function
    Private Function SQLEncabezado(ByVal Codigo As Integer, ByVal Año As Integer) As String
        Dim strSQL As String
        strSQL = " SELECT HDR.HDoc_Doc_Num Numero,HDR.HDoc_Doc_Ano Anio ,HDR.HDoc_Doc_Fec Fecha,HDR.HDoc_Emp_Cod idCliente,HDR.HDoc_Emp_Nom Cliente,HDR.HDoc_RF1_Cod LC,IFNULL(HDR.HDoc_DR1_Cat,0) total, HDR.HDoc_Emp_Dir Direccion,HDR.HDoc_Emp_NIT Nit,HDR.HDoc_Doc_Mon idMoneda,c.cat_clave Moneda,HDR.HDoc_Doc_TC Tasa ,HDoc_DR1_Num PO ,HDR.HDoc_DR1_Fec FechaExpiracion,HDR.HDoc_DR2_Num Drawee,HDR.HDoc_RF1_Txt Comentario, HDR.HDoc_Doc_Status Estado "
        strSQL &= " FROM Dcmtos_HDR HDR "
        strSQL &= " LEFT JOIN Catalogos c ON c.cat_num = HDR.HDoc_Doc_Mon AND c.cat_clase='Monedas' "
        strSQL &= " WHERE HDR.HDoc_Sis_Emp = {empresa} AND HDR.HDoc_Doc_Cat = {catalogo} AND HDR.HDoc_Doc_Ano = {anio} AND HDR.HDoc_Doc_Num = {codigo} "
        strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
        strSQL = Replace(strSQL, "{catalogo}", 894)
        strSQL = Replace(strSQL, "{anio}", Año)
        strSQL = Replace(strSQL, "{codigo}", Codigo)
        Return strSQL
    End Function
    Public Sub Seleccionar(ByVal Codigo As Integer, ByVal Año As Integer)
        Dim COM As New MySqlCommand
        Dim REA As MySqlDataReader
        Dim strSQL As String = STR_VACIO

        strSQL = SQLEncabezado(Codigo, Año)
        MyCnn.CONECTAR = strConexion
        COM = New MySqlCommand(strSQL, CON)
        REA = COM.ExecuteReader
        If REA.HasRows Then
            Do While REA.Read
                'celdaPO.ReadOnly = False

                celdaAño.Text = REA.GetInt32("Anio")
                celdaNumero.Text = REA.GetInt32("Numero")
                dtpFecha.Value = REA.GetDateTime("Fecha").ToString(FORMATO_MYSQL)
                celdaCliente.Text = REA.GetString("Cliente")
                celdaidCliente.Text = REA.GetString("idCliente")
                celdaDireccion.Text = REA.GetString("Direccion")
                celdaNit.Text = REA.GetString("Nit")
                celdaidMoneda.Text = REA.GetInt32("idMoneda")
                celdaMoneda.Text = REA.GetString("Moneda")
                celdaTasa.Text = REA.GetDouble("Tasa")
                celdaPO.Text = REA.GetString("PO")
                dtpFechaExpiracion.Value = REA.GetDateTime("FechaExpiracion").ToString(FORMATO_MYSQL)
                celdaDrawee.Text = REA.GetString("Drawee")
                celdaComentario.Text = REA.GetString("Comentario")
                celdaLC.Text = REA.GetString("LC")
                celdaTotal.Text = REA.GetDouble("total")
                If REA.GetInt32("Estado") = 0 Then
                    checkActive.Checked = False
                    DeshabilitarFormas()
                Else
                    checkActive.Checked = True
                    HabilitarFormas()
                End If
                'celdaPO.ReadOnly = True
                botonCliente.Enabled = False
            Loop
        End If
        CargarDetalle(Codigo, Año)
    End Sub
    Private Function SQLDetalle(ByVal Codigo As Integer, ByVal Año As Integer) As String
        Dim strSQL As String = STR_VACIO

        strSQL = "  SELECT d.DDoc_Doc_Lin Linea ,d.DDoc_Prd_QTY Cantidad ,d.DDoc_Prd_UM idMedida,c.cat_clave, d.DDoc_Prd_NET Total ,IFNULL(d.DDoc_RF1_Fec,'') FechaPresentacion,d.DDoc_RF1_Cod Pago,p.PDoc_Par_Cat Catalogo,p.PDoc_Par_Ano Anio , p.PDoc_Par_Num Numero ,p.PDoc_Par_Lin Line"
        strSQL &= "  FROM Dcmtos_DTL d"
        strSQL &= "  LEFT JOIN Catalogos c ON c.cat_num = d.DDoc_Prd_UM AND c.cat_clase = 'Medidas' "
        strSQL &= "  LEFT JOIN Dcmtos_DTL_Pro p ON p.PDoc_Sis_Emp = d.DDoc_Sis_Emp AND p.PDoc_Chi_Cat = d.DDoc_Doc_Cat AND p.PDoc_Chi_Ano = d.DDoc_Doc_Ano AND p.PDoc_Chi_Num = d.DDoc_Doc_Num AND p.PDoc_Chi_Lin = d.DDoc_Doc_Lin "
        strSQL &= "  WHERE d.DDoc_Sis_Emp = {empresa} AND d.DDoc_Doc_Cat = {catalogo} AND d.DDoc_Doc_Ano = {anio} AND d.DDoc_Doc_Num = {codigo}"
        strSQL &= "  ORDER BY d.DDoc_Doc_Cat , d.DDoc_Doc_Ano,d.DDoc_Doc_Num ,d.DDoc_Doc_Lin "
        strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
        strSQL = Replace(strSQL, "{catalogo}", 894)
        strSQL = Replace(strSQL, "{anio}", Año)
        strSQL = Replace(strSQL, "{codigo}", Codigo)
        Return strSQL
    End Function
    Private Sub CargarDetalle(ByVal Codigo As Integer, ByVal Año As Integer)
        Dim COM As New MySqlCommand
        Dim REA As MySqlDataReader
        Dim strSQL As String = STR_VACIO
        Dim strLinea As String = STR_VACIO
        strSQL = SQLDetalle(Codigo, Año)
        MyCnn.CONECTAR = strConexion
        COM = New MySqlCommand(strSQL, CON)
        REA = COM.ExecuteReader
        If REA.HasRows Then
            dgDetalle.Rows.Clear()
            Do While REA.Read

                strLinea = REA.GetInt32("Numero") & "|" 'Numero
                strLinea &= REA.GetInt32("Linea") & "|" 'ID CODIGO
                strLinea &= REA.GetDouble("Cantidad") & "|" 'Titulo de producto cotizado   
                strLinea &= REA.GetInt32("idMedida") & "|" ' Cantidad
                strLinea &= REA.GetString("cat_clave") & "|"  ' Medida
                strLinea &= REA.GetDouble("Total").ToString("###0.00") & "|" ' id
                strLinea &= REA.GetString("FechaPresentacion") & "|" ' Comentario 
                strLinea &= REA.GetString("Pago") & "|" '  LINE
                strLinea &= REA.GetInt32("Catalogo") & "|" '  LINE
                strLinea &= REA.GetInt32("Anio") & "|" ' Año
                strLinea &= REA.GetInt32("Numero") & "|" ' Año
                strLinea &= REA.GetInt32("Line") & "|" ' Año
                strLinea &= "1" ' Status
                cFunciones.AgregarFila(dgDetalle, strLinea)

            Loop
        End If
        CargarReceipt()
        CalcularTotales()
    End Sub
    Public Sub CargarReceipt()
        Try
            For i As Integer = 0 To dgDetalle.Rows.Count - 1
                CargarCargoReceipt(dgDetalle.Rows(i).Cells("colAnio").Value, dgDetalle.Rows(i).Cells("colNum").Value)
            Next
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub
    Private Sub BorrarCartaCredito(ByVal num As Integer, ByVal anio As Integer)
        Try
            Dim hdr As New clsDcmtos_HDR
            hdr.CONEXION = strConexion
            hdr.HDOC_SIS_EMP = Sesion.IdEmpresa
            hdr.HDOC_DOC_CAT = CATALOGO
            hdr.HDOC_DOC_ANO = anio
            hdr.HDOC_DOC_NUM = num
            hdr.Borrar()
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub
    Private Sub BorrarDetalleCartaCredito(ByVal num As Integer, ByVal anio As Integer)
        Dim strSQL As String = STR_VACIO
        Try
            strSQL = "DDoc_Sis_Emp = {empresa}  AND DDoc_Doc_Cat = {cata} AND DDoc_Doc_Ano = {anio} AND DDoc_Doc_Num = {numero} "
            strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
            strSQL = Replace(strSQL, "{cata}", CATALOGO)
            strSQL = Replace(strSQL, "{anio}", anio)
            strSQL = Replace(strSQL, "{numero}", num)
            Dim dtl As New clsDcmtos_DTL
            dtl.CONEXION = strConexion
            dtl.Borrar(strSQL)
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub
    Private Sub BorrarProCartaCredito(ByVal num As Integer, ByVal anio As Integer)
        Dim strSQL As String = STR_VACIO
        Try
            strSQL = "PDoc_Sis_Emp = {empresa}  AND PDoc_Chi_Cat = {cata} AND PDoc_Chi_Ano = {anio} AND PDoc_Chi_Num = {numero} "
            strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
            strSQL = Replace(strSQL, "{cata}", CATALOGO)
            strSQL = Replace(strSQL, "{anio}", anio)
            strSQL = Replace(strSQL, "{numero}", num)
            Dim pro As New clsDcmtos_DTL_Pro
            pro.CONEXION = strConexion
            pro.Borrar(strSQL)

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub
#End Region
#Region "Eventos"
    Private Sub frmCartaCreditoNet_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        dtpFechaInicial.Value = Today.AddMonths(NO_FILA)
        dtpFechaFinal.Value = Today
        Accesos()
        MostrarLista()
    End Sub
    Private Sub frmCartaCreditoNet_FormClosing(sender As Object, e As FormClosingEventArgs) Handles Me.FormClosing
        Fprincipal.BarraDeTareas1.QuitarFormulario(strKey)
    End Sub
    Private Sub Encabezado1_ClickNuevo(sender As Object, click As Boolean) Handles Encabezado1.ClickNuevo
        If logInsertar = True Then
            HabilitarFormas()
            MostrarLista(False, logInsertar)
        Else
            MsgBox("You do not have permission to create a new document", vbCritical, "Notice")
        End If
    End Sub
    Private Sub botonCliente_Click(sender As Object, e As EventArgs) Handles botonCliente.Click
        Me.Tag = "Nuevo"
        Dim frm As New frmSeleccionar
        Dim strCondicion As String = STR_VACIO

        strCondicion = "c.cli_sisemp  = {empresa} AND c.cli_status  = 'Activo' "
        strCondicion = Replace(strCondicion, "{empresa}", Sesion.IdEmpresa)
        Try
            frm.Titulo = "Client"
            frm.Campos = " c.cli_codigo , c.cli_cliente , c.cli_direccion , c.cli_telefono , c.cli_nit "
            frm.Tabla = " Clientes c"
            frm.FiltroText = " Enter the client to filter"
            frm.Filtro = "  c.cli_cliente"
            frm.Limite = 30
            frm.Ordenamiento = " c.cli_codigo "
            frm.TipoOrdenamiento = ""
            frm.Condicion = strCondicion

            frm.ShowDialog(Me)
            If frm.DialogResult = System.Windows.Forms.DialogResult.OK Then
                celdaIDCliente.Text = frm.LLave
                celdaCliente.Text = frm.Dato
                celdaDireccion.Text = frm.Dato2
                celdaNit.Text = frm.Dato4

                celdaMoneda.Text = "US$"
                celdaidMoneda.Text = 178
                celdaTasa.Text = cFunciones.QueryTasa
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub
    Private Sub botonMoneda_Click(sender As Object, e As EventArgs) Handles botonMoneda.Click
        Dim frm As New frmSeleccionar
        Dim strSQL As String = STR_VACIO
        Dim COM As MySqlCommand
        Dim conec As MySqlConnection
        Dim Cambio As Double

        Try
            frm.Titulo = "Currency"
            frm.FiltroText = " Enter The Currency To Filter"
            frm.Campos = " cat_num Code, cat_clave Currency"
            frm.Tabla = " Catalogos"
            frm.Filtro = " cat_clave "
            frm.Condicion = "cat_clase = 'monedas'"

            frm.ShowDialog(Me)
            If frm.DialogResult = System.Windows.Forms.DialogResult.OK Then
                celdaidMoneda.Text = frm.LLave
                celdaMoneda.Text = frm.Dato
            End If

            strSQL = " SELECT cat_sist"
            strSQL &= "      FROM Catalogos"
            strSQL &= "          WHERE cat_clase = 'Monedas' AND cat_num = {Numero}"

            strSQL = Replace(strSQL, "{Numero}", frm.LLave)

            conec = New MySqlConnection(strConexion)
            conec.Open()
            COM = New MySqlCommand(strSQL, conec)
            Using conec
                Cambio = COM.ExecuteScalar
                COM.Dispose()
                COM = Nothing
                conec.Close()
                conec.Dispose()
                conec = Nothing
                System.GC.Collect()
            End Using
            If Cambio > 1 Then
                celdaTasa.Text = cFunciones.TasaSegunFecha(dtpFecha.Value.ToString(FORMATO_MYSQL))
            Else
                celdaTasa.Text = Cambio
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub
    Private Sub Encabezado1_ClickCerrar(sender As Object, click As Boolean) Handles Encabezado1.ClickCerrar
        If panelDocumento.Visible = True Then
            MostrarLista()
        Else
            Me.Close()
        End If
        'dgReferencia.Rows.Clear()

    End Sub
    Private Sub botonAgregar_Click(sender As Object, e As EventArgs) Handles botonAgregar.Click
        Dim frmS As New frmSeleccionar
        Dim strfila As String = STR_VACIO
        Dim intNumero As Integer = NO_FILA
        Dim strCondicion As String = STR_VACIO
        Dim intContador = INT_CERO
        Dim dblTotal As Double
        Try
            If ValidarCampos() = True Then
                frmS.Titulo = "YRM"
                strCondicion = " {campo}, l1.Cantidad  Quantity, l1.Medida  Measure, l1.Total  Total, l1.Presentacion  Presented,l1.idMedida idMedida, l1.anio  anio, l1.numero  numero"
                If (Sesion.IdEmpresa = 16) Or (Sesion.IdEmpresa = 14) Then
                    strCondicion = Replace(strCondicion, "{campo}", "l1.NumE Number")
                Else
                    strCondicion = Replace(strCondicion, "{campo}", "l1.Num Number")
                End If
                frmS.Campos = strCondicion
                frmS.Tabla = "  ( SELECT h.HDoc_Doc_Num Num, h.HDoc_DR1_Dbl numE, d.DDoc_Prd_QTY Cantidad,c.cat_num idMedida ,c.cat_clave Medida, SUM((d.DDoc_Prd_QTY * d.DDoc_Prd_NET)) Total,IFNULL(d397.DDoc_RF2_Fec,'') Presentacion,p36.PDoc_Chi_Cat catalogo,p36.PDoc_Chi_Ano anio,p36.PDoc_Chi_Num numero,p36.PDoc_Chi_Lin linea FROM Dcmtos_DTL d  " &
                "   LEFT JOIN Dcmtos_HDR h ON h.HDoc_Sis_Emp = d.DDoc_Sis_Emp AND h.HDoc_Doc_Cat = d.DDoc_Doc_Cat AND d.DDoc_Doc_Ano = h.HDoc_Doc_Ano AND d.DDoc_Doc_Num = h.HDoc_Doc_Num  " &
                "       LEFT JOIN Dcmtos_DTL_Pro p36 ON p36.PDoc_Sis_Emp = d.DDoc_Sis_Emp AND p36.PDoc_Chi_Cat = d.DDoc_Doc_Cat AND p36.PDoc_Chi_Ano = d.DDoc_Doc_Ano AND p36.PDoc_Chi_Num = d.DDoc_Doc_Num AND p36.PDoc_Chi_Lin = d.DDoc_Doc_Lin " &
                "           LEFT JOIN Dcmtos_DTL_Pro p ON p.PDoc_Sis_Emp = p36.PDoc_Sis_Emp AND p.PDoc_Par_Cat = p36.PDoc_Par_Cat  AND p.PDoc_Par_Ano = p36.PDoc_Par_Ano AND p.PDoc_Par_Num = p36.PDoc_Par_Num AND p.PDoc_Par_Lin = p36.PDoc_Par_Lin AND p.PDoc_Chi_Cat = 397 " &
                "                   LEFT JOIN Catalogos c ON c.cat_num = d.DDoc_Prd_UM AND c.cat_clase = 'Medidas' " &
                "                       LEFT JOIN Dcmtos_DTL d397 ON d397.DDoc_Sis_Emp = p.PDoc_Sis_Emp AND d397.DDoc_Doc_Cat = p.PDoc_Chi_Cat AND d397.DDoc_Doc_Ano = p.PDoc_Chi_Ano AND d397.DDoc_Doc_Num = p.PDoc_Chi_Num AND d397.DDoc_Doc_Lin = p.PDoc_Chi_Lin "
                frmS.FiltroText = "Enter the YRM Number"
                frmS.Filtro = "h.HDoc_Doc_Num"
                frmS.Limite = 50
                frmS.Condicion = "d.DDoc_Sis_Emp = " & Sesion.IdEmpresa & " AND d.DDoc_Doc_Cat = 395 AND h.HDoc_Doc_Status = 1  AND h.HDoc_Emp_Cod = " & celdaidCliente.Text & " AND  d.DDoc_RF1_Cod LIKE '%" & celdaPO.Text & "%' GROUP BY d.DDoc_Sis_Emp, d.DDoc_Doc_Cat, d.DDoc_Doc_Num )l1 "
                frmS.Multiple = True
                If (Sesion.IdEmpresa = 16) Or (Sesion.IdEmpresa = 14) Then
                    strCondicion = Replace(strCondicion, "{campo}", "l1.NumE Number")
                Else
                    strCondicion = Replace(strCondicion, "{campo}", "l1.Num Number")
                End If
                frmS.ShowDialog(Me)
                If frmS.DialogResult = System.Windows.Forms.DialogResult.OK Then
                    For j As Integer = 0 To frmS.DataGrid.Rows.Count - 1
                        If frmS.ListaClientes.Rows(j).Cells("colCheck").Value = True Then
                            intContador = intContador + 1
                            If AgregarCamposDatagridDetalle(frmS.ListaClientes.Rows(j).Cells(1).Value, intContador, frmS.ListaClientes.Rows(j).Cells(2).Value, frmS.ListaClientes.Rows(j).Cells(6).Value, frmS.ListaClientes.Rows(j).Cells(3).Value, frmS.ListaClientes.Rows(j).Cells(4).Value, frmS.ListaClientes.Rows(j).Cells(5).Value, frmS.ListaClientes.Rows(j).Cells(7).Value, frmS.ListaClientes.Rows(j).Cells(8).Value, INT_UNO) = True Then
                                CargarCargoReceipt(frmS.ListaClientes.Rows(j).Cells(7).Value, frmS.ListaClientes.Rows(j).Cells(8).Value)
                            End If
                        End If
                    Next
                End If
                CalcularTotales()
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub dgDetalle_DoubleClick(sender As Object, e As EventArgs) Handles dgDetalle.DoubleClick
        If dgDetalle.Rows.Count = 0 Then Exit Sub
        Try
            Select Case dgDetalle.CurrentCell.ColumnIndex
                Case 6
                    Dim frmF As New frmDateTimePicker
                    frmF.ShowDialog(Me)
                    If frmF.DialogResult = System.Windows.Forms.DialogResult.OK Then
                        dgDetalle.CurrentRow.Cells("colPresentacion").Value = frmF.LLave
                    End If
                Case 7
                    Dim frmO As New frmOption
                    frmO.Titulo = "Select Payment Method"
                    frmO.Opciones = "YES|" & "NO"
                    frmO.ShowDialog(Me)
                    If frmO.DialogResult = System.Windows.Forms.DialogResult.OK Then
                        Select Case frmO.Seleccion
                            Case 0
                                dgDetalle.CurrentRow.Cells("colPago").Value = "YES"
                            Case 1
                                dgDetalle.CurrentRow.Cells("colPago").Value = "NO"
                        End Select
                    End If
            End Select
            CalcularTotales()
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub
    Private Sub botonEliminar_Click(sender As Object, e As EventArgs) Handles botonEliminar.Click
        Try
            Dim Count As Integer
            If dgDetalle.SelectedRows Is Nothing Then Exit Sub
            If dgDetalle.Rows.Count > 1 Then
                Count = dgDetalle.Rows.GetRowCount(DataGridViewElementStates.Selected)
                For i As Integer = 0 To Count - 1
                    If MsgBox("You sure you want to delete the row " & "OF THE ORDER " &
                    CInt(dgDetalle.SelectedCells(0).Value) & ", " &
               CStr(dgDetalle.SelectedCells(1).Value) & " " &
                CStr(dgDetalle.SelectedCells(2).Value) & " " &
                   CStr(dgDetalle.SelectedCells(3).Value) & "?", vbQuestion + vbYesNo + vbDefaultButton2) =
                    vbYes Then
                        If dgDetalle.SelectedCells(12).Value = 0 Or dgDetalle.SelectedCells(12).Value = 1 Then
                            dgDetalle.SelectedCells(12).Value = 2
                            If dgDetalle.SelectedCells(12).Value = 2 Then
                                dgDetalle.CurrentRow.Visible = False
                            End If
                        ElseIf dgDetalle.Rows(i).Selected = Nothing Then
                            '  dgDetalle.SelectedCells(6).Value = 3
                            ' dgDetalle.CurrentRow.Visible = False
                            dgDetalle.Rows.RemoveAt(dgDetalle.RowCount - 1)
                        End If
                    End If
                Next
            Else
                MsgBox("you can not delete the last row")
                Exit Sub
            End If
            dgDetalle.ReadOnly = False
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub
    Private Sub Encabezado1_ClickGuardar(sender As Object, click As Boolean) Handles Encabezado1.ClickGuardar
        Try
            If ComprobarDatos() Then
                If Guardar() = True Then
                    MsgBox("the document has been saved")
                    MostrarLista(True)
                End If

            End If

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub dgLista_DoubleClick(sender As Object, e As EventArgs) Handles dgLista.DoubleClick
        Dim Codigo As Integer = NO_FILA
        Dim Año As Integer = NO_FILA
        If dgLista.Rows.Count = 0 Then Exit Sub
        Try
            Codigo = dgLista.SelectedCells(0).Value
            Año = dgLista.SelectedCells(1).Value
            Limpiar()
            MostrarLista(False)
            BloquearBotones(False)
            Me.Tag = "mod"
            Seleccionar(Codigo, Año)

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub
    Private Sub dgLista_KeyDown(sender As Object, e As KeyEventArgs) Handles dgLista.KeyDown
        Try
            If e.KeyCode = Keys.F3 Then
                cFunciones.BuscarenLista(dgLista)
                e.Handled = True
                e.SuppressKeyPress = True
            ElseIf e.KeyCode = Keys.F6 Then
                cFunciones.MostrarDependencias(894, dgLista.SelectedCells(1).Value, dgLista.SelectedCells(0).Value)
            ElseIf e.KeyCode = Keys.F7 Then
                Dim rpt As New clsReportes
                rpt.Historial(dgLista.SelectedCells(0).Value, dgLista.SelectedCells(1).Value, 894, codigo:=celdaidCliente.Text)

            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub Encabezado1_ClickBorrar(sender As Object, click As Boolean) Handles Encabezado1.ClickBorrar
        If LogBorrar = True Then
            Dim strSQL As String = STR_VACIO
            Dim COM As MySqlCommand
            Dim NumFact As Integer = 0
            Dim AnioFact As Integer = 0


            If MsgBox("The document will be permanently deleted, do you want to continue?", vbQuestion + vbYesNo, "Question") = vbYes Then
                NumFact = celdaNumero.Text
                AnioFact = celdaAño.Text
                BorrarCartaCredito(NumFact, AnioFact)
                BorrarDetalleCartaCredito(NumFact, AnioFact)
                BorrarProCartaCredito(NumFact, AnioFact)
                cFunciones.EscribirRegistro("Dcmtos_HDR", clsFunciones.AccEnum.acDelete, celdaidCliente.Text, 894, celdaAño.Text, celdaNumero.Text)
                MostrarLista()
            End If
        Else
            MsgBox("You do not have permission for this action", vbInformation, "Notice")
        End If
    End Sub

    Private Sub botonActualizar_Click(sender As Object, e As EventArgs) Handles botonActualizar.Click
        CargarListaPrincipal()
    End Sub

    Private Sub dtpFecha_ValueChanged(sender As Object, e As EventArgs) Handles dtpFecha.ValueChanged
        If celdaTasa.Text > 1 Then
            celdaTasa.Text = cFunciones.TasaSegunFecha(dtpFecha.Value.ToString(FORMATO_MYSQL))
        End If
    End Sub

#End Region
End Class