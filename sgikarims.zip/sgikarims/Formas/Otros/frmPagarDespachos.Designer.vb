﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmPagarDespachos
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim DataGridViewCellStyle1 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle2 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Me.panelLista = New System.Windows.Forms.Panel()
        Me.dgLista = New System.Windows.Forms.DataGridView()
        Me.panelFechas = New System.Windows.Forms.Panel()
        Me.botonFiltrar = New System.Windows.Forms.Button()
        Me.etiquetaFechas = New System.Windows.Forms.Label()
        Me.dtpFinal = New System.Windows.Forms.DateTimePicker()
        Me.dtpInicio = New System.Windows.Forms.DateTimePicker()
        Me.checkFechas = New System.Windows.Forms.CheckBox()
        Me.panelDocumento = New System.Windows.Forms.Panel()
        Me.dgDetalle = New System.Windows.Forms.DataGridView()
        Me.panelBotones = New System.Windows.Forms.Panel()
        Me.botonQuitar = New System.Windows.Forms.Button()
        Me.botonAgregar = New System.Windows.Forms.Button()
        Me.panelEncabezado = New System.Windows.Forms.Panel()
        Me.celdaIdMoneda = New System.Windows.Forms.TextBox()
        Me.celdaTotal = New System.Windows.Forms.TextBox()
        Me.etiquetaTotal = New System.Windows.Forms.Label()
        Me.celdaidProveedor = New System.Windows.Forms.TextBox()
        Me.botonProveedor = New System.Windows.Forms.Button()
        Me.celdaProveedor = New System.Windows.Forms.TextBox()
        Me.etiquetaProveedor = New System.Windows.Forms.Label()
        Me.celdaDescripcion = New System.Windows.Forms.TextBox()
        Me.etiquetaDescripcion = New System.Windows.Forms.Label()
        Me.checkActivo = New System.Windows.Forms.CheckBox()
        Me.dtpFecha = New System.Windows.Forms.DateTimePicker()
        Me.botonMoneda = New System.Windows.Forms.Button()
        Me.celdaTC = New System.Windows.Forms.TextBox()
        Me.celdaMoneda = New System.Windows.Forms.TextBox()
        Me.celdaNumero = New System.Windows.Forms.TextBox()
        Me.celdaAnio = New System.Windows.Forms.TextBox()
        Me.etiquetaTC = New System.Windows.Forms.Label()
        Me.etiquetaMoneda = New System.Windows.Forms.Label()
        Me.etiquetaFecga = New System.Windows.Forms.Label()
        Me.etiquetaNumero = New System.Windows.Forms.Label()
        Me.etiquetaAnio = New System.Windows.Forms.Label()
        Me.colAnio = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colNumero = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colFecha = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colDescripcion = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.conMonto = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colStatus = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.col_Catalogo = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.col_Anio = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.col_Linea = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.col_Numero = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.col_Fecha = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.col_Cliente = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.col_Monto = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.col_Extra = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.BarraTitulo1 = New KARIMs_SGI.BarraTitulo()
        Me.Encabezado1 = New KARIMs_SGI.encabezado()
        Me.panelLista.SuspendLayout()
        CType(Me.dgLista, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.panelFechas.SuspendLayout()
        Me.panelDocumento.SuspendLayout()
        CType(Me.dgDetalle, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.panelBotones.SuspendLayout()
        Me.panelEncabezado.SuspendLayout()
        Me.SuspendLayout()
        '
        'panelLista
        '
        Me.panelLista.Controls.Add(Me.dgLista)
        Me.panelLista.Controls.Add(Me.panelFechas)
        Me.panelLista.Location = New System.Drawing.Point(12, 119)
        Me.panelLista.Name = "panelLista"
        Me.panelLista.Size = New System.Drawing.Size(577, 99)
        Me.panelLista.TabIndex = 2
        '
        'dgLista
        '
        Me.dgLista.AllowUserToAddRows = False
        Me.dgLista.AllowUserToDeleteRows = False
        Me.dgLista.BackgroundColor = System.Drawing.SystemColors.Control
        Me.dgLista.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgLista.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.colAnio, Me.colNumero, Me.colFecha, Me.colDescripcion, Me.conMonto, Me.colStatus})
        Me.dgLista.Dock = System.Windows.Forms.DockStyle.Fill
        Me.dgLista.Location = New System.Drawing.Point(0, 48)
        Me.dgLista.MultiSelect = False
        Me.dgLista.Name = "dgLista"
        Me.dgLista.ReadOnly = True
        Me.dgLista.RowTemplate.Height = 24
        Me.dgLista.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.dgLista.Size = New System.Drawing.Size(577, 51)
        Me.dgLista.TabIndex = 1
        '
        'panelFechas
        '
        Me.panelFechas.Controls.Add(Me.botonFiltrar)
        Me.panelFechas.Controls.Add(Me.etiquetaFechas)
        Me.panelFechas.Controls.Add(Me.dtpFinal)
        Me.panelFechas.Controls.Add(Me.dtpInicio)
        Me.panelFechas.Controls.Add(Me.checkFechas)
        Me.panelFechas.Dock = System.Windows.Forms.DockStyle.Top
        Me.panelFechas.Location = New System.Drawing.Point(0, 0)
        Me.panelFechas.Name = "panelFechas"
        Me.panelFechas.Size = New System.Drawing.Size(577, 48)
        Me.panelFechas.TabIndex = 0
        '
        'botonFiltrar
        '
        Me.botonFiltrar.Location = New System.Drawing.Point(433, 7)
        Me.botonFiltrar.Margin = New System.Windows.Forms.Padding(4)
        Me.botonFiltrar.Name = "botonFiltrar"
        Me.botonFiltrar.Size = New System.Drawing.Size(100, 28)
        Me.botonFiltrar.TabIndex = 5
        Me.botonFiltrar.Text = "Filtered"
        Me.botonFiltrar.UseVisualStyleBackColor = True
        '
        'etiquetaFechas
        '
        Me.etiquetaFechas.AutoSize = True
        Me.etiquetaFechas.Location = New System.Drawing.Point(245, 15)
        Me.etiquetaFechas.Name = "etiquetaFechas"
        Me.etiquetaFechas.Size = New System.Drawing.Size(25, 17)
        Me.etiquetaFechas.TabIndex = 4
        Me.etiquetaFechas.Text = "To"
        '
        'dtpFinal
        '
        Me.dtpFinal.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.dtpFinal.Location = New System.Drawing.Point(281, 10)
        Me.dtpFinal.Margin = New System.Windows.Forms.Padding(4)
        Me.dtpFinal.Name = "dtpFinal"
        Me.dtpFinal.Size = New System.Drawing.Size(128, 22)
        Me.dtpFinal.TabIndex = 3
        '
        'dtpInicio
        '
        Me.dtpInicio.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.dtpInicio.Location = New System.Drawing.Point(109, 10)
        Me.dtpInicio.Margin = New System.Windows.Forms.Padding(4)
        Me.dtpInicio.Name = "dtpInicio"
        Me.dtpInicio.Size = New System.Drawing.Size(128, 22)
        Me.dtpInicio.TabIndex = 2
        '
        'checkFechas
        '
        Me.checkFechas.AutoSize = True
        Me.checkFechas.Checked = True
        Me.checkFechas.CheckState = System.Windows.Forms.CheckState.Checked
        Me.checkFechas.Location = New System.Drawing.Point(4, 14)
        Me.checkFechas.Margin = New System.Windows.Forms.Padding(4)
        Me.checkFechas.Name = "checkFechas"
        Me.checkFechas.Size = New System.Drawing.Size(97, 21)
        Me.checkFechas.TabIndex = 1
        Me.checkFechas.Text = "Filter From"
        Me.checkFechas.UseVisualStyleBackColor = True
        '
        'panelDocumento
        '
        Me.panelDocumento.Controls.Add(Me.dgDetalle)
        Me.panelDocumento.Controls.Add(Me.panelBotones)
        Me.panelDocumento.Controls.Add(Me.panelEncabezado)
        Me.panelDocumento.Location = New System.Drawing.Point(12, 235)
        Me.panelDocumento.Name = "panelDocumento"
        Me.panelDocumento.Size = New System.Drawing.Size(875, 425)
        Me.panelDocumento.TabIndex = 3
        '
        'dgDetalle
        '
        Me.dgDetalle.AllowUserToAddRows = False
        Me.dgDetalle.AllowUserToDeleteRows = False
        Me.dgDetalle.BackgroundColor = System.Drawing.SystemColors.Control
        Me.dgDetalle.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgDetalle.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.col_Catalogo, Me.col_Anio, Me.col_Linea, Me.col_Numero, Me.col_Fecha, Me.col_Cliente, Me.col_Monto, Me.col_Extra})
        Me.dgDetalle.Dock = System.Windows.Forms.DockStyle.Fill
        Me.dgDetalle.Location = New System.Drawing.Point(0, 217)
        Me.dgDetalle.MultiSelect = False
        Me.dgDetalle.Name = "dgDetalle"
        Me.dgDetalle.ReadOnly = True
        Me.dgDetalle.RowTemplate.Height = 24
        Me.dgDetalle.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.dgDetalle.Size = New System.Drawing.Size(816, 208)
        Me.dgDetalle.TabIndex = 2
        '
        'panelBotones
        '
        Me.panelBotones.Controls.Add(Me.botonQuitar)
        Me.panelBotones.Controls.Add(Me.botonAgregar)
        Me.panelBotones.Dock = System.Windows.Forms.DockStyle.Right
        Me.panelBotones.Location = New System.Drawing.Point(816, 217)
        Me.panelBotones.Name = "panelBotones"
        Me.panelBotones.Size = New System.Drawing.Size(59, 208)
        Me.panelBotones.TabIndex = 1
        '
        'botonQuitar
        '
        Me.botonQuitar.Image = Global.KARIMs_SGI.My.Resources.Resources.delete3
        Me.botonQuitar.Location = New System.Drawing.Point(13, 64)
        Me.botonQuitar.Margin = New System.Windows.Forms.Padding(4)
        Me.botonQuitar.Name = "botonQuitar"
        Me.botonQuitar.Size = New System.Drawing.Size(35, 30)
        Me.botonQuitar.TabIndex = 5
        Me.botonQuitar.UseVisualStyleBackColor = True
        '
        'botonAgregar
        '
        Me.botonAgregar.Image = Global.KARIMs_SGI.My.Resources.Resources.add
        Me.botonAgregar.Location = New System.Drawing.Point(13, 22)
        Me.botonAgregar.Margin = New System.Windows.Forms.Padding(4)
        Me.botonAgregar.Name = "botonAgregar"
        Me.botonAgregar.Size = New System.Drawing.Size(35, 30)
        Me.botonAgregar.TabIndex = 6
        Me.botonAgregar.UseVisualStyleBackColor = True
        '
        'panelEncabezado
        '
        Me.panelEncabezado.Controls.Add(Me.celdaIdMoneda)
        Me.panelEncabezado.Controls.Add(Me.celdaTotal)
        Me.panelEncabezado.Controls.Add(Me.etiquetaTotal)
        Me.panelEncabezado.Controls.Add(Me.celdaidProveedor)
        Me.panelEncabezado.Controls.Add(Me.botonProveedor)
        Me.panelEncabezado.Controls.Add(Me.celdaProveedor)
        Me.panelEncabezado.Controls.Add(Me.etiquetaProveedor)
        Me.panelEncabezado.Controls.Add(Me.celdaDescripcion)
        Me.panelEncabezado.Controls.Add(Me.etiquetaDescripcion)
        Me.panelEncabezado.Controls.Add(Me.checkActivo)
        Me.panelEncabezado.Controls.Add(Me.dtpFecha)
        Me.panelEncabezado.Controls.Add(Me.botonMoneda)
        Me.panelEncabezado.Controls.Add(Me.celdaTC)
        Me.panelEncabezado.Controls.Add(Me.celdaMoneda)
        Me.panelEncabezado.Controls.Add(Me.celdaNumero)
        Me.panelEncabezado.Controls.Add(Me.celdaAnio)
        Me.panelEncabezado.Controls.Add(Me.etiquetaTC)
        Me.panelEncabezado.Controls.Add(Me.etiquetaMoneda)
        Me.panelEncabezado.Controls.Add(Me.etiquetaFecga)
        Me.panelEncabezado.Controls.Add(Me.etiquetaNumero)
        Me.panelEncabezado.Controls.Add(Me.etiquetaAnio)
        Me.panelEncabezado.Dock = System.Windows.Forms.DockStyle.Top
        Me.panelEncabezado.Location = New System.Drawing.Point(0, 0)
        Me.panelEncabezado.Name = "panelEncabezado"
        Me.panelEncabezado.Size = New System.Drawing.Size(875, 217)
        Me.panelEncabezado.TabIndex = 0
        '
        'celdaIdMoneda
        '
        Me.celdaIdMoneda.Location = New System.Drawing.Point(442, 11)
        Me.celdaIdMoneda.Name = "celdaIdMoneda"
        Me.celdaIdMoneda.Size = New System.Drawing.Size(26, 22)
        Me.celdaIdMoneda.TabIndex = 20
        Me.celdaIdMoneda.Visible = False
        '
        'celdaTotal
        '
        Me.celdaTotal.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.celdaTotal.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.celdaTotal.ForeColor = System.Drawing.SystemColors.HotTrack
        Me.celdaTotal.Location = New System.Drawing.Point(707, 180)
        Me.celdaTotal.Name = "celdaTotal"
        Me.celdaTotal.ReadOnly = True
        Me.celdaTotal.Size = New System.Drawing.Size(100, 22)
        Me.celdaTotal.TabIndex = 19
        '
        'etiquetaTotal
        '
        Me.etiquetaTotal.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.etiquetaTotal.AutoSize = True
        Me.etiquetaTotal.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.etiquetaTotal.ForeColor = System.Drawing.SystemColors.HotTrack
        Me.etiquetaTotal.Location = New System.Drawing.Point(656, 183)
        Me.etiquetaTotal.Name = "etiquetaTotal"
        Me.etiquetaTotal.Size = New System.Drawing.Size(45, 17)
        Me.etiquetaTotal.TabIndex = 18
        Me.etiquetaTotal.Text = "Total"
        '
        'celdaidProveedor
        '
        Me.celdaidProveedor.Location = New System.Drawing.Point(516, 116)
        Me.celdaidProveedor.Name = "celdaidProveedor"
        Me.celdaidProveedor.Size = New System.Drawing.Size(26, 22)
        Me.celdaidProveedor.TabIndex = 17
        Me.celdaidProveedor.Visible = False
        '
        'botonProveedor
        '
        Me.botonProveedor.Location = New System.Drawing.Point(476, 116)
        Me.botonProveedor.Name = "botonProveedor"
        Me.botonProveedor.Size = New System.Drawing.Size(34, 23)
        Me.botonProveedor.TabIndex = 16
        Me.botonProveedor.Text = "..."
        Me.botonProveedor.UseVisualStyleBackColor = True
        '
        'celdaProveedor
        '
        Me.celdaProveedor.Location = New System.Drawing.Point(97, 116)
        Me.celdaProveedor.Name = "celdaProveedor"
        Me.celdaProveedor.ReadOnly = True
        Me.celdaProveedor.Size = New System.Drawing.Size(371, 22)
        Me.celdaProveedor.TabIndex = 15
        '
        'etiquetaProveedor
        '
        Me.etiquetaProveedor.AutoSize = True
        Me.etiquetaProveedor.Location = New System.Drawing.Point(13, 116)
        Me.etiquetaProveedor.Name = "etiquetaProveedor"
        Me.etiquetaProveedor.Size = New System.Drawing.Size(61, 17)
        Me.etiquetaProveedor.TabIndex = 14
        Me.etiquetaProveedor.Text = "Provider"
        '
        'celdaDescripcion
        '
        Me.celdaDescripcion.Location = New System.Drawing.Point(97, 157)
        Me.celdaDescripcion.Multiline = True
        Me.celdaDescripcion.Name = "celdaDescripcion"
        Me.celdaDescripcion.Size = New System.Drawing.Size(413, 53)
        Me.celdaDescripcion.TabIndex = 13
        '
        'etiquetaDescripcion
        '
        Me.etiquetaDescripcion.AutoSize = True
        Me.etiquetaDescripcion.Location = New System.Drawing.Point(13, 157)
        Me.etiquetaDescripcion.Name = "etiquetaDescripcion"
        Me.etiquetaDescripcion.Size = New System.Drawing.Size(79, 17)
        Me.etiquetaDescripcion.TabIndex = 12
        Me.etiquetaDescripcion.Text = "Description"
        '
        'checkActivo
        '
        Me.checkActivo.AutoSize = True
        Me.checkActivo.Checked = True
        Me.checkActivo.CheckState = System.Windows.Forms.CheckState.Checked
        Me.checkActivo.Location = New System.Drawing.Point(261, 8)
        Me.checkActivo.Name = "checkActivo"
        Me.checkActivo.Size = New System.Drawing.Size(68, 21)
        Me.checkActivo.TabIndex = 11
        Me.checkActivo.Text = "Active"
        Me.checkActivo.UseVisualStyleBackColor = True
        '
        'dtpFecha
        '
        Me.dtpFecha.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.dtpFecha.Location = New System.Drawing.Point(97, 73)
        Me.dtpFecha.Name = "dtpFecha"
        Me.dtpFecha.Size = New System.Drawing.Size(112, 22)
        Me.dtpFecha.TabIndex = 10
        '
        'botonMoneda
        '
        Me.botonMoneda.Location = New System.Drawing.Point(476, 38)
        Me.botonMoneda.Name = "botonMoneda"
        Me.botonMoneda.Size = New System.Drawing.Size(34, 23)
        Me.botonMoneda.TabIndex = 9
        Me.botonMoneda.Text = "..."
        Me.botonMoneda.UseVisualStyleBackColor = True
        '
        'celdaTC
        '
        Me.celdaTC.Location = New System.Drawing.Point(368, 73)
        Me.celdaTC.Name = "celdaTC"
        Me.celdaTC.Size = New System.Drawing.Size(100, 22)
        Me.celdaTC.TabIndex = 8
        '
        'celdaMoneda
        '
        Me.celdaMoneda.Location = New System.Drawing.Point(368, 39)
        Me.celdaMoneda.Name = "celdaMoneda"
        Me.celdaMoneda.ReadOnly = True
        Me.celdaMoneda.Size = New System.Drawing.Size(100, 22)
        Me.celdaMoneda.TabIndex = 7
        '
        'celdaNumero
        '
        Me.celdaNumero.Location = New System.Drawing.Point(97, 39)
        Me.celdaNumero.Name = "celdaNumero"
        Me.celdaNumero.ReadOnly = True
        Me.celdaNumero.Size = New System.Drawing.Size(100, 22)
        Me.celdaNumero.TabIndex = 6
        '
        'celdaAnio
        '
        Me.celdaAnio.Location = New System.Drawing.Point(97, 6)
        Me.celdaAnio.Name = "celdaAnio"
        Me.celdaAnio.ReadOnly = True
        Me.celdaAnio.Size = New System.Drawing.Size(100, 22)
        Me.celdaAnio.TabIndex = 5
        '
        'etiquetaTC
        '
        Me.etiquetaTC.AutoSize = True
        Me.etiquetaTC.Location = New System.Drawing.Point(258, 78)
        Me.etiquetaTC.Name = "etiquetaTC"
        Me.etiquetaTC.Size = New System.Drawing.Size(104, 17)
        Me.etiquetaTC.TabIndex = 4
        Me.etiquetaTC.Text = "Exchange Rate"
        '
        'etiquetaMoneda
        '
        Me.etiquetaMoneda.AutoSize = True
        Me.etiquetaMoneda.Location = New System.Drawing.Point(258, 44)
        Me.etiquetaMoneda.Name = "etiquetaMoneda"
        Me.etiquetaMoneda.Size = New System.Drawing.Size(65, 17)
        Me.etiquetaMoneda.TabIndex = 3
        Me.etiquetaMoneda.Text = "Currency"
        '
        'etiquetaFecga
        '
        Me.etiquetaFecga.AutoSize = True
        Me.etiquetaFecga.Location = New System.Drawing.Point(13, 78)
        Me.etiquetaFecga.Name = "etiquetaFecga"
        Me.etiquetaFecga.Size = New System.Drawing.Size(38, 17)
        Me.etiquetaFecga.TabIndex = 2
        Me.etiquetaFecga.Text = "Date"
        '
        'etiquetaNumero
        '
        Me.etiquetaNumero.AutoSize = True
        Me.etiquetaNumero.Location = New System.Drawing.Point(13, 42)
        Me.etiquetaNumero.Name = "etiquetaNumero"
        Me.etiquetaNumero.Size = New System.Drawing.Size(58, 17)
        Me.etiquetaNumero.TabIndex = 1
        Me.etiquetaNumero.Text = "Number"
        '
        'etiquetaAnio
        '
        Me.etiquetaAnio.AutoSize = True
        Me.etiquetaAnio.Location = New System.Drawing.Point(13, 9)
        Me.etiquetaAnio.Name = "etiquetaAnio"
        Me.etiquetaAnio.Size = New System.Drawing.Size(38, 17)
        Me.etiquetaAnio.TabIndex = 0
        Me.etiquetaAnio.Text = "Year"
        '
        'colAnio
        '
        Me.colAnio.HeaderText = "Year"
        Me.colAnio.Name = "colAnio"
        Me.colAnio.ReadOnly = True
        Me.colAnio.Visible = False
        '
        'colNumero
        '
        Me.colNumero.HeaderText = "Number"
        Me.colNumero.Name = "colNumero"
        Me.colNumero.ReadOnly = True
        '
        'colFecha
        '
        Me.colFecha.HeaderText = "Date"
        Me.colFecha.Name = "colFecha"
        Me.colFecha.ReadOnly = True
        '
        'colDescripcion
        '
        Me.colDescripcion.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.colDescripcion.HeaderText = "Description"
        Me.colDescripcion.Name = "colDescripcion"
        Me.colDescripcion.ReadOnly = True
        Me.colDescripcion.Width = 108
        '
        'conMonto
        '
        DataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight
        DataGridViewCellStyle1.Format = "N2"
        DataGridViewCellStyle1.NullValue = Nothing
        Me.conMonto.DefaultCellStyle = DataGridViewCellStyle1
        Me.conMonto.HeaderText = "Amount"
        Me.conMonto.Name = "conMonto"
        Me.conMonto.ReadOnly = True
        '
        'colStatus
        '
        Me.colStatus.HeaderText = "Status"
        Me.colStatus.Name = "colStatus"
        Me.colStatus.ReadOnly = True
        Me.colStatus.Visible = False
        '
        'col_Catalogo
        '
        Me.col_Catalogo.HeaderText = "Catalogo"
        Me.col_Catalogo.Name = "col_Catalogo"
        Me.col_Catalogo.ReadOnly = True
        Me.col_Catalogo.Visible = False
        '
        'col_Anio
        '
        Me.col_Anio.HeaderText = "Anio"
        Me.col_Anio.Name = "col_Anio"
        Me.col_Anio.ReadOnly = True
        Me.col_Anio.Visible = False
        '
        'col_Linea
        '
        Me.col_Linea.HeaderText = "Line"
        Me.col_Linea.Name = "col_Linea"
        Me.col_Linea.ReadOnly = True
        Me.col_Linea.Visible = False
        '
        'col_Numero
        '
        Me.col_Numero.HeaderText = "Number"
        Me.col_Numero.Name = "col_Numero"
        Me.col_Numero.ReadOnly = True
        '
        'col_Fecha
        '
        Me.col_Fecha.HeaderText = "Date"
        Me.col_Fecha.Name = "col_Fecha"
        Me.col_Fecha.ReadOnly = True
        '
        'col_Cliente
        '
        Me.col_Cliente.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.col_Cliente.HeaderText = "Customer"
        Me.col_Cliente.Name = "col_Cliente"
        Me.col_Cliente.ReadOnly = True
        Me.col_Cliente.Width = 97
        '
        'col_Monto
        '
        DataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight
        DataGridViewCellStyle2.Format = "N2"
        DataGridViewCellStyle2.NullValue = Nothing
        Me.col_Monto.DefaultCellStyle = DataGridViewCellStyle2
        Me.col_Monto.HeaderText = "Amount"
        Me.col_Monto.Name = "col_Monto"
        Me.col_Monto.ReadOnly = True
        '
        'col_Extra
        '
        Me.col_Extra.HeaderText = "Extra"
        Me.col_Extra.Name = "col_Extra"
        Me.col_Extra.ReadOnly = True
        Me.col_Extra.Visible = False
        '
        'BarraTitulo1
        '
        Me.BarraTitulo1.BackColor = System.Drawing.Color.WhiteSmoke
        Me.BarraTitulo1.Dock = System.Windows.Forms.DockStyle.Top
        Me.BarraTitulo1.Location = New System.Drawing.Point(0, 75)
        Me.BarraTitulo1.Margin = New System.Windows.Forms.Padding(4)
        Me.BarraTitulo1.Name = "BarraTitulo1"
        Me.BarraTitulo1.Size = New System.Drawing.Size(913, 37)
        Me.BarraTitulo1.TabIndex = 1
        '
        'Encabezado1
        '
        Me.Encabezado1.Dock = System.Windows.Forms.DockStyle.Top
        Me.Encabezado1.Location = New System.Drawing.Point(0, 0)
        Me.Encabezado1.Margin = New System.Windows.Forms.Padding(4)
        Me.Encabezado1.Name = "Encabezado1"
        Me.Encabezado1.Size = New System.Drawing.Size(913, 75)
        Me.Encabezado1.TabIndex = 0
        '
        'frmPagarDespachos
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(913, 672)
        Me.Controls.Add(Me.panelDocumento)
        Me.Controls.Add(Me.panelLista)
        Me.Controls.Add(Me.BarraTitulo1)
        Me.Controls.Add(Me.Encabezado1)
        Me.Name = "frmPagarDespachos"
        Me.Text = "frmPagarDespachos"
        Me.panelLista.ResumeLayout(False)
        CType(Me.dgLista, System.ComponentModel.ISupportInitialize).EndInit()
        Me.panelFechas.ResumeLayout(False)
        Me.panelFechas.PerformLayout()
        Me.panelDocumento.ResumeLayout(False)
        CType(Me.dgDetalle, System.ComponentModel.ISupportInitialize).EndInit()
        Me.panelBotones.ResumeLayout(False)
        Me.panelEncabezado.ResumeLayout(False)
        Me.panelEncabezado.PerformLayout()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents Encabezado1 As encabezado
    Friend WithEvents BarraTitulo1 As BarraTitulo
    Friend WithEvents panelLista As Panel
    Friend WithEvents panelFechas As Panel
    Friend WithEvents checkFechas As System.Windows.Forms.CheckBox
    Friend WithEvents etiquetaFechas As Label
    Friend WithEvents dtpFinal As DateTimePicker
    Friend WithEvents dtpInicio As DateTimePicker
    Friend WithEvents dgLista As DataGridView
    Friend WithEvents botonFiltrar As Button
    Friend WithEvents panelDocumento As Panel
    Friend WithEvents panelEncabezado As Panel
    Friend WithEvents etiquetaMoneda As Label
    Friend WithEvents etiquetaFecga As Label
    Friend WithEvents etiquetaNumero As Label
    Friend WithEvents etiquetaAnio As Label
    Friend WithEvents etiquetaTC As Label
    Friend WithEvents celdaDescripcion As TextBox
    Friend WithEvents etiquetaDescripcion As Label
    Friend WithEvents checkActivo As System.Windows.Forms.CheckBox
    Friend WithEvents dtpFecha As DateTimePicker
    Friend WithEvents botonMoneda As Button
    Friend WithEvents celdaTC As TextBox
    Friend WithEvents celdaMoneda As TextBox
    Friend WithEvents celdaNumero As TextBox
    Friend WithEvents celdaAnio As TextBox
    Friend WithEvents celdaProveedor As TextBox
    Friend WithEvents etiquetaProveedor As Label
    Friend WithEvents panelBotones As Panel
    Friend WithEvents celdaidProveedor As TextBox
    Friend WithEvents botonProveedor As Button
    Friend WithEvents botonQuitar As Button
    Friend WithEvents botonAgregar As Button
    Friend WithEvents dgDetalle As DataGridView
    Friend WithEvents etiquetaTotal As Label
    Friend WithEvents celdaTotal As TextBox
    Friend WithEvents celdaIdMoneda As TextBox
    Friend WithEvents colAnio As DataGridViewTextBoxColumn
    Friend WithEvents colNumero As DataGridViewTextBoxColumn
    Friend WithEvents colFecha As DataGridViewTextBoxColumn
    Friend WithEvents colDescripcion As DataGridViewTextBoxColumn
    Friend WithEvents conMonto As DataGridViewTextBoxColumn
    Friend WithEvents colStatus As DataGridViewTextBoxColumn
    Friend WithEvents col_Catalogo As DataGridViewTextBoxColumn
    Friend WithEvents col_Anio As DataGridViewTextBoxColumn
    Friend WithEvents col_Linea As DataGridViewTextBoxColumn
    Friend WithEvents col_Numero As DataGridViewTextBoxColumn
    Friend WithEvents col_Fecha As DataGridViewTextBoxColumn
    Friend WithEvents col_Cliente As DataGridViewTextBoxColumn
    Friend WithEvents col_Monto As DataGridViewTextBoxColumn
    Friend WithEvents col_Extra As DataGridViewTextBoxColumn
End Class
