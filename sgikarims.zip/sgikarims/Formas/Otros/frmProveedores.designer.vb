﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class frmProveedores
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.panelLista = New System.Windows.Forms.Panel()
        Me.dgLista = New System.Windows.Forms.DataGridView()
        Me.colID = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.col_Nombre = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.col_Nit = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.col_Abreviacion = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colDireccion = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colTelefono = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.panelDocumento = New System.Windows.Forms.Panel()
        Me.panelDatosProvedor = New System.Windows.Forms.Panel()
        Me.checkRecibos = New System.Windows.Forms.CheckBox()
        Me.gbCuentaContable = New System.Windows.Forms.GroupBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.celdaCuentaPadre = New System.Windows.Forms.TextBox()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.celdaNombreCuentaPadre = New System.Windows.Forms.TextBox()
        Me.botonCuentaPadre = New System.Windows.Forms.Button()
        Me.GbCuentaMiami = New System.Windows.Forms.GroupBox()
        Me.celdaCtaNombre = New System.Windows.Forms.TextBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.botonCta = New System.Windows.Forms.Button()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.celdaCta = New System.Windows.Forms.TextBox()
        Me.etiquetaCodigo = New System.Windows.Forms.Label()
        Me.etiquetaDesCorta = New System.Windows.Forms.Label()
        Me.etiquetaRazonSocial = New System.Windows.Forms.Label()
        Me.celdaIDNIT = New System.Windows.Forms.TextBox()
        Me.etiquetaDireccion = New System.Windows.Forms.Label()
        Me.botonNit = New System.Windows.Forms.Button()
        Me.celdaRazonSocial = New System.Windows.Forms.TextBox()
        Me.rbotonNo = New System.Windows.Forms.RadioButton()
        Me.celdaDireccion = New System.Windows.Forms.TextBox()
        Me.rbotonSi = New System.Windows.Forms.RadioButton()
        Me.etiquetaNIT = New System.Windows.Forms.Label()
        Me.celdaIDEstado = New System.Windows.Forms.TextBox()
        Me.etiquetaTelefono = New System.Windows.Forms.Label()
        Me.celdaIDMoneda = New System.Windows.Forms.TextBox()
        Me.celdaTelefono = New System.Windows.Forms.TextBox()
        Me.celdaIDRegimen = New System.Windows.Forms.TextBox()
        Me.etiquetaRegimen = New System.Windows.Forms.Label()
        Me.celdaIDPais = New System.Windows.Forms.TextBox()
        Me.etiquetaPais = New System.Windows.Forms.Label()
        Me.celdaIDAreaNegocio = New System.Windows.Forms.TextBox()
        Me.celdaRegimen = New System.Windows.Forms.TextBox()
        Me.celdaIDMetodoCosteo = New System.Windows.Forms.TextBox()
        Me.celdaPais = New System.Windows.Forms.TextBox()
        Me.celdaDesCorta = New System.Windows.Forms.TextBox()
        Me.botonRegimen = New System.Windows.Forms.Button()
        Me.celdaCodigo = New System.Windows.Forms.TextBox()
        Me.botonPais = New System.Windows.Forms.Button()
        Me.celdaNT = New System.Windows.Forms.TextBox()
        Me.etiquetaMoneda = New System.Windows.Forms.Label()
        Me.botonEstado = New System.Windows.Forms.Button()
        Me.celdaMoneda = New System.Windows.Forms.TextBox()
        Me.celdaEstado = New System.Windows.Forms.TextBox()
        Me.botonMoneda = New System.Windows.Forms.Button()
        Me.etiquetaEstado = New System.Windows.Forms.Label()
        Me.etiquetaFabricante = New System.Windows.Forms.Label()
        Me.etiquetaPeqContribuyentes = New System.Windows.Forms.Label()
        Me.etiquetaAreaNegocios = New System.Windows.Forms.Label()
        Me.checkDerechoCreditoFiscal = New System.Windows.Forms.CheckBox()
        Me.celdaAreaNegocios = New System.Windows.Forms.TextBox()
        Me.botonMetodoCos = New System.Windows.Forms.Button()
        Me.botonCeldaNegocios = New System.Windows.Forms.Button()
        Me.celdaMetodoCosteo = New System.Windows.Forms.TextBox()
        Me.etiquetaMetodoCosteo = New System.Windows.Forms.Label()
        Me.panelEncabezado = New System.Windows.Forms.Panel()
        Me.gbPosiCuenta = New System.Windows.Forms.GroupBox()
        Me.etiquetaDisponible = New System.Windows.Forms.Label()
        Me.etiquetaSaldo = New System.Windows.Forms.Label()
        Me.celdaDisponible = New System.Windows.Forms.TextBox()
        Me.celdaSaldo = New System.Windows.Forms.TextBox()
        Me.gbContabilidad = New System.Windows.Forms.GroupBox()
        Me.celdaIDCxP = New System.Windows.Forms.TextBox()
        Me.celdaIDProdPredet = New System.Windows.Forms.TextBox()
        Me.botonProducPred = New System.Windows.Forms.Button()
        Me.botonCxP = New System.Windows.Forms.Button()
        Me.rbServicio = New System.Windows.Forms.RadioButton()
        Me.rbBien = New System.Windows.Forms.RadioButton()
        Me.celdaPreProduct = New System.Windows.Forms.TextBox()
        Me.celdaPredPro = New System.Windows.Forms.TextBox()
        Me.etiquetaProPred = New System.Windows.Forms.Label()
        Me.celdaCxPagar = New System.Windows.Forms.TextBox()
        Me.celdaCuentasxPagar = New System.Windows.Forms.TextBox()
        Me.etiquetaCuentasxPagar = New System.Windows.Forms.Label()
        Me.celdaLimiteCredito = New System.Windows.Forms.TextBox()
        Me.etiquetaLimiteCredito = New System.Windows.Forms.Label()
        Me.celdaPlazoCredito = New System.Windows.Forms.TextBox()
        Me.etiquetaPlazoCredito = New System.Windows.Forms.Label()
        Me.celdaDescuento = New System.Windows.Forms.TextBox()
        Me.etiquetaDescuento = New System.Windows.Forms.Label()
        Me.panelDetalle = New System.Windows.Forms.Panel()
        Me.dgDetalle = New System.Windows.Forms.DataGridView()
        Me.colNombre = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colPuesto = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colCelular = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colCorreo = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colEstado = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colCodigo = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colStatus = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.panelBotones = New System.Windows.Forms.Panel()
        Me.botonAbajo = New System.Windows.Forms.Button()
        Me.botonUp = New System.Windows.Forms.Button()
        Me.BarraTitulo1 = New KARIMs_SGI.BarraTitulo()
        Me.Encabezado1 = New KARIMs_SGI.encabezado()
        Me.panelLista.SuspendLayout()
        CType(Me.dgLista, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.panelDocumento.SuspendLayout()
        Me.panelDatosProvedor.SuspendLayout()
        Me.gbCuentaContable.SuspendLayout()
        Me.GbCuentaMiami.SuspendLayout()
        Me.panelEncabezado.SuspendLayout()
        Me.gbPosiCuenta.SuspendLayout()
        Me.gbContabilidad.SuspendLayout()
        Me.panelDetalle.SuspendLayout()
        CType(Me.dgDetalle, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.panelBotones.SuspendLayout()
        Me.SuspendLayout()
        '
        'panelLista
        '
        Me.panelLista.Controls.Add(Me.dgLista)
        Me.panelLista.Dock = System.Windows.Forms.DockStyle.Top
        Me.panelLista.Location = New System.Drawing.Point(0, 126)
        Me.panelLista.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.panelLista.Name = "panelLista"
        Me.panelLista.Size = New System.Drawing.Size(1355, 50)
        Me.panelLista.TabIndex = 2
        '
        'dgLista
        '
        Me.dgLista.AllowUserToAddRows = False
        Me.dgLista.AllowUserToDeleteRows = False
        Me.dgLista.AllowUserToOrderColumns = True
        Me.dgLista.BackgroundColor = System.Drawing.SystemColors.Control
        Me.dgLista.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgLista.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.colID, Me.col_Nombre, Me.col_Nit, Me.col_Abreviacion, Me.colDireccion, Me.colTelefono})
        Me.dgLista.Dock = System.Windows.Forms.DockStyle.Fill
        Me.dgLista.Location = New System.Drawing.Point(0, 0)
        Me.dgLista.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.dgLista.MultiSelect = False
        Me.dgLista.Name = "dgLista"
        Me.dgLista.ReadOnly = True
        Me.dgLista.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.dgLista.Size = New System.Drawing.Size(1355, 50)
        Me.dgLista.TabIndex = 1
        '
        'colID
        '
        Me.colID.HeaderText = "ID"
        Me.colID.Name = "colID"
        Me.colID.ReadOnly = True
        '
        'col_Nombre
        '
        Me.col_Nombre.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.col_Nombre.HeaderText = "Name"
        Me.col_Nombre.Name = "col_Nombre"
        Me.col_Nombre.ReadOnly = True
        Me.col_Nombre.Width = 74
        '
        'col_Nit
        '
        Me.col_Nit.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.col_Nit.HeaderText = "NIT"
        Me.col_Nit.Name = "col_Nit"
        Me.col_Nit.ReadOnly = True
        Me.col_Nit.Width = 59
        '
        'col_Abreviacion
        '
        Me.col_Abreviacion.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.col_Abreviacion.HeaderText = "Abbreviation"
        Me.col_Abreviacion.Name = "col_Abreviacion"
        Me.col_Abreviacion.ReadOnly = True
        Me.col_Abreviacion.Width = 116
        '
        'colDireccion
        '
        Me.colDireccion.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.colDireccion.HeaderText = "Adress"
        Me.colDireccion.Name = "colDireccion"
        Me.colDireccion.ReadOnly = True
        Me.colDireccion.Width = 81
        '
        'colTelefono
        '
        Me.colTelefono.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.colTelefono.HeaderText = "Telephone"
        Me.colTelefono.Name = "colTelefono"
        Me.colTelefono.ReadOnly = True
        Me.colTelefono.Width = 105
        '
        'panelDocumento
        '
        Me.panelDocumento.Controls.Add(Me.panelDatosProvedor)
        Me.panelDocumento.Controls.Add(Me.panelEncabezado)
        Me.panelDocumento.Controls.Add(Me.panelDetalle)
        Me.panelDocumento.Dock = System.Windows.Forms.DockStyle.Fill
        Me.panelDocumento.Location = New System.Drawing.Point(0, 176)
        Me.panelDocumento.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.panelDocumento.Name = "panelDocumento"
        Me.panelDocumento.Size = New System.Drawing.Size(1355, 681)
        Me.panelDocumento.TabIndex = 3
        '
        'panelDatosProvedor
        '
        Me.panelDatosProvedor.Controls.Add(Me.checkRecibos)
        Me.panelDatosProvedor.Controls.Add(Me.gbCuentaContable)
        Me.panelDatosProvedor.Controls.Add(Me.GbCuentaMiami)
        Me.panelDatosProvedor.Controls.Add(Me.etiquetaCodigo)
        Me.panelDatosProvedor.Controls.Add(Me.etiquetaDesCorta)
        Me.panelDatosProvedor.Controls.Add(Me.etiquetaRazonSocial)
        Me.panelDatosProvedor.Controls.Add(Me.celdaIDNIT)
        Me.panelDatosProvedor.Controls.Add(Me.etiquetaDireccion)
        Me.panelDatosProvedor.Controls.Add(Me.botonNit)
        Me.panelDatosProvedor.Controls.Add(Me.celdaRazonSocial)
        Me.panelDatosProvedor.Controls.Add(Me.rbotonNo)
        Me.panelDatosProvedor.Controls.Add(Me.celdaDireccion)
        Me.panelDatosProvedor.Controls.Add(Me.rbotonSi)
        Me.panelDatosProvedor.Controls.Add(Me.etiquetaNIT)
        Me.panelDatosProvedor.Controls.Add(Me.celdaIDEstado)
        Me.panelDatosProvedor.Controls.Add(Me.etiquetaTelefono)
        Me.panelDatosProvedor.Controls.Add(Me.celdaIDMoneda)
        Me.panelDatosProvedor.Controls.Add(Me.celdaTelefono)
        Me.panelDatosProvedor.Controls.Add(Me.celdaIDRegimen)
        Me.panelDatosProvedor.Controls.Add(Me.etiquetaRegimen)
        Me.panelDatosProvedor.Controls.Add(Me.celdaIDPais)
        Me.panelDatosProvedor.Controls.Add(Me.etiquetaPais)
        Me.panelDatosProvedor.Controls.Add(Me.celdaIDAreaNegocio)
        Me.panelDatosProvedor.Controls.Add(Me.celdaRegimen)
        Me.panelDatosProvedor.Controls.Add(Me.celdaIDMetodoCosteo)
        Me.panelDatosProvedor.Controls.Add(Me.celdaPais)
        Me.panelDatosProvedor.Controls.Add(Me.celdaDesCorta)
        Me.panelDatosProvedor.Controls.Add(Me.botonRegimen)
        Me.panelDatosProvedor.Controls.Add(Me.celdaCodigo)
        Me.panelDatosProvedor.Controls.Add(Me.botonPais)
        Me.panelDatosProvedor.Controls.Add(Me.celdaNT)
        Me.panelDatosProvedor.Controls.Add(Me.etiquetaMoneda)
        Me.panelDatosProvedor.Controls.Add(Me.botonEstado)
        Me.panelDatosProvedor.Controls.Add(Me.celdaMoneda)
        Me.panelDatosProvedor.Controls.Add(Me.celdaEstado)
        Me.panelDatosProvedor.Controls.Add(Me.botonMoneda)
        Me.panelDatosProvedor.Controls.Add(Me.etiquetaEstado)
        Me.panelDatosProvedor.Controls.Add(Me.etiquetaFabricante)
        Me.panelDatosProvedor.Controls.Add(Me.etiquetaPeqContribuyentes)
        Me.panelDatosProvedor.Controls.Add(Me.etiquetaAreaNegocios)
        Me.panelDatosProvedor.Controls.Add(Me.checkDerechoCreditoFiscal)
        Me.panelDatosProvedor.Controls.Add(Me.celdaAreaNegocios)
        Me.panelDatosProvedor.Controls.Add(Me.botonMetodoCos)
        Me.panelDatosProvedor.Controls.Add(Me.botonCeldaNegocios)
        Me.panelDatosProvedor.Controls.Add(Me.celdaMetodoCosteo)
        Me.panelDatosProvedor.Controls.Add(Me.etiquetaMetodoCosteo)
        Me.panelDatosProvedor.Dock = System.Windows.Forms.DockStyle.Fill
        Me.panelDatosProvedor.Location = New System.Drawing.Point(0, 0)
        Me.panelDatosProvedor.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.panelDatosProvedor.Name = "panelDatosProvedor"
        Me.panelDatosProvedor.Size = New System.Drawing.Size(958, 564)
        Me.panelDatosProvedor.TabIndex = 78
        '
        'checkRecibos
        '
        Me.checkRecibos.AutoSize = True
        Me.checkRecibos.Location = New System.Drawing.Point(725, 11)
        Me.checkRecibos.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.checkRecibos.Name = "checkRecibos"
        Me.checkRecibos.Size = New System.Drawing.Size(129, 21)
        Me.checkRecibos.TabIndex = 76
        Me.checkRecibos.Text = "Issues Receipts"
        Me.checkRecibos.TextAlign = System.Drawing.ContentAlignment.BottomRight
        Me.checkRecibos.UseVisualStyleBackColor = True
        Me.checkRecibos.Visible = False
        '
        'gbCuentaContable
        '
        Me.gbCuentaContable.BackColor = System.Drawing.SystemColors.ActiveCaption
        Me.gbCuentaContable.Controls.Add(Me.Label3)
        Me.gbCuentaContable.Controls.Add(Me.celdaCuentaPadre)
        Me.gbCuentaContable.Controls.Add(Me.Label4)
        Me.gbCuentaContable.Controls.Add(Me.celdaNombreCuentaPadre)
        Me.gbCuentaContable.Controls.Add(Me.botonCuentaPadre)
        Me.gbCuentaContable.Location = New System.Drawing.Point(465, 404)
        Me.gbCuentaContable.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.gbCuentaContable.Name = "gbCuentaContable"
        Me.gbCuentaContable.Padding = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.gbCuentaContable.Size = New System.Drawing.Size(484, 89)
        Me.gbCuentaContable.TabIndex = 0
        Me.gbCuentaContable.TabStop = False
        Me.gbCuentaContable.Text = "Nomenclature Category"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.Location = New System.Drawing.Point(8, 23)
        Me.Label3.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(127, 17)
        Me.Label3.TabIndex = 81
        Me.Label3.Text = "Account Number"
        '
        'celdaCuentaPadre
        '
        Me.celdaCuentaPadre.BackColor = System.Drawing.SystemColors.Info
        Me.celdaCuentaPadre.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.celdaCuentaPadre.Location = New System.Drawing.Point(144, 22)
        Me.celdaCuentaPadre.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.celdaCuentaPadre.Name = "celdaCuentaPadre"
        Me.celdaCuentaPadre.ReadOnly = True
        Me.celdaCuentaPadre.Size = New System.Drawing.Size(273, 22)
        Me.celdaCuentaPadre.TabIndex = 0
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.Location = New System.Drawing.Point(8, 49)
        Me.Label4.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(112, 17)
        Me.Label4.TabIndex = 83
        Me.Label4.Text = "Account Name"
        '
        'celdaNombreCuentaPadre
        '
        Me.celdaNombreCuentaPadre.BackColor = System.Drawing.SystemColors.Info
        Me.celdaNombreCuentaPadre.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.celdaNombreCuentaPadre.Location = New System.Drawing.Point(144, 50)
        Me.celdaNombreCuentaPadre.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.celdaNombreCuentaPadre.Name = "celdaNombreCuentaPadre"
        Me.celdaNombreCuentaPadre.ReadOnly = True
        Me.celdaNombreCuentaPadre.Size = New System.Drawing.Size(325, 22)
        Me.celdaNombreCuentaPadre.TabIndex = 0
        '
        'botonCuentaPadre
        '
        Me.botonCuentaPadre.Location = New System.Drawing.Point(427, 17)
        Me.botonCuentaPadre.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.botonCuentaPadre.Name = "botonCuentaPadre"
        Me.botonCuentaPadre.Size = New System.Drawing.Size(43, 28)
        Me.botonCuentaPadre.TabIndex = 17
        Me.botonCuentaPadre.Text = "..."
        Me.botonCuentaPadre.UseVisualStyleBackColor = True
        '
        'GbCuentaMiami
        '
        Me.GbCuentaMiami.BackColor = System.Drawing.SystemColors.ActiveCaption
        Me.GbCuentaMiami.Controls.Add(Me.celdaCtaNombre)
        Me.GbCuentaMiami.Controls.Add(Me.Label2)
        Me.GbCuentaMiami.Controls.Add(Me.botonCta)
        Me.GbCuentaMiami.Controls.Add(Me.Label1)
        Me.GbCuentaMiami.Controls.Add(Me.celdaCta)
        Me.GbCuentaMiami.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GbCuentaMiami.ForeColor = System.Drawing.SystemColors.ControlText
        Me.GbCuentaMiami.Location = New System.Drawing.Point(7, 404)
        Me.GbCuentaMiami.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.GbCuentaMiami.Name = "GbCuentaMiami"
        Me.GbCuentaMiami.Padding = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.GbCuentaMiami.Size = New System.Drawing.Size(451, 87)
        Me.GbCuentaMiami.TabIndex = 0
        Me.GbCuentaMiami.TabStop = False
        Me.GbCuentaMiami.Text = "Statements USA"
        '
        'celdaCtaNombre
        '
        Me.celdaCtaNombre.BackColor = System.Drawing.SystemColors.Info
        Me.celdaCtaNombre.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.celdaCtaNombre.Location = New System.Drawing.Point(139, 46)
        Me.celdaCtaNombre.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.celdaCtaNombre.Name = "celdaCtaNombre"
        Me.celdaCtaNombre.ReadOnly = True
        Me.celdaCtaNombre.Size = New System.Drawing.Size(295, 22)
        Me.celdaCtaNombre.TabIndex = 0
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.Location = New System.Drawing.Point(7, 49)
        Me.Label2.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(112, 17)
        Me.Label2.TabIndex = 79
        Me.Label2.Text = "Account Name"
        '
        'botonCta
        '
        Me.botonCta.Location = New System.Drawing.Point(392, 14)
        Me.botonCta.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.botonCta.Name = "botonCta"
        Me.botonCta.Size = New System.Drawing.Size(43, 28)
        Me.botonCta.TabIndex = 16
        Me.botonCta.Text = "..."
        Me.botonCta.UseVisualStyleBackColor = True
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(5, 20)
        Me.Label1.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(127, 17)
        Me.Label1.TabIndex = 76
        Me.Label1.Text = "Account Number"
        '
        'celdaCta
        '
        Me.celdaCta.BackColor = System.Drawing.SystemColors.Info
        Me.celdaCta.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.celdaCta.Location = New System.Drawing.Point(140, 16)
        Me.celdaCta.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.celdaCta.Name = "celdaCta"
        Me.celdaCta.ReadOnly = True
        Me.celdaCta.Size = New System.Drawing.Size(244, 22)
        Me.celdaCta.TabIndex = 0
        '
        'etiquetaCodigo
        '
        Me.etiquetaCodigo.AutoSize = True
        Me.etiquetaCodigo.Location = New System.Drawing.Point(24, 18)
        Me.etiquetaCodigo.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.etiquetaCodigo.Name = "etiquetaCodigo"
        Me.etiquetaCodigo.Size = New System.Drawing.Size(41, 17)
        Me.etiquetaCodigo.TabIndex = 0
        Me.etiquetaCodigo.Text = "Code"
        '
        'etiquetaDesCorta
        '
        Me.etiquetaDesCorta.AutoSize = True
        Me.etiquetaDesCorta.Location = New System.Drawing.Point(357, 18)
        Me.etiquetaDesCorta.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.etiquetaDesCorta.Name = "etiquetaDesCorta"
        Me.etiquetaDesCorta.Size = New System.Drawing.Size(117, 17)
        Me.etiquetaDesCorta.TabIndex = 4
        Me.etiquetaDesCorta.Text = "Short Description"
        '
        'etiquetaRazonSocial
        '
        Me.etiquetaRazonSocial.AutoSize = True
        Me.etiquetaRazonSocial.Location = New System.Drawing.Point(24, 47)
        Me.etiquetaRazonSocial.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.etiquetaRazonSocial.Name = "etiquetaRazonSocial"
        Me.etiquetaRazonSocial.Size = New System.Drawing.Size(106, 17)
        Me.etiquetaRazonSocial.TabIndex = 0
        Me.etiquetaRazonSocial.Text = "Business Name"
        '
        'celdaIDNIT
        '
        Me.celdaIDNIT.Location = New System.Drawing.Point(672, 204)
        Me.celdaIDNIT.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.celdaIDNIT.Name = "celdaIDNIT"
        Me.celdaIDNIT.Size = New System.Drawing.Size(20, 22)
        Me.celdaIDNIT.TabIndex = 75
        Me.celdaIDNIT.Text = "-1"
        Me.celdaIDNIT.Visible = False
        '
        'etiquetaDireccion
        '
        Me.etiquetaDireccion.AutoSize = True
        Me.etiquetaDireccion.Location = New System.Drawing.Point(24, 82)
        Me.etiquetaDireccion.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.etiquetaDireccion.Name = "etiquetaDireccion"
        Me.etiquetaDireccion.Size = New System.Drawing.Size(64, 17)
        Me.etiquetaDireccion.TabIndex = 0
        Me.etiquetaDireccion.Text = "Direction"
        '
        'botonNit
        '
        Me.botonNit.Image = Global.KARIMs_SGI.My.Resources.Resources.search
        Me.botonNit.ImageAlign = System.Drawing.ContentAlignment.TopCenter
        Me.botonNit.Location = New System.Drawing.Point(403, 172)
        Me.botonNit.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.botonNit.Name = "botonNit"
        Me.botonNit.Size = New System.Drawing.Size(92, 47)
        Me.botonNit.TabIndex = 0
        Me.botonNit.Text = "Look For"
        Me.botonNit.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.botonNit.UseVisualStyleBackColor = True
        Me.botonNit.Visible = False
        '
        'celdaRazonSocial
        '
        Me.celdaRazonSocial.Location = New System.Drawing.Point(165, 43)
        Me.celdaRazonSocial.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.celdaRazonSocial.Name = "celdaRazonSocial"
        Me.celdaRazonSocial.Size = New System.Drawing.Size(541, 22)
        Me.celdaRazonSocial.TabIndex = 3
        '
        'rbotonNo
        '
        Me.rbotonNo.AutoSize = True
        Me.rbotonNo.Checked = True
        Me.rbotonNo.Location = New System.Drawing.Point(221, 302)
        Me.rbotonNo.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.rbotonNo.Name = "rbotonNo"
        Me.rbotonNo.Size = New System.Drawing.Size(47, 21)
        Me.rbotonNo.TabIndex = 12
        Me.rbotonNo.TabStop = True
        Me.rbotonNo.Text = "No"
        Me.rbotonNo.UseVisualStyleBackColor = True
        '
        'celdaDireccion
        '
        Me.celdaDireccion.Location = New System.Drawing.Point(165, 78)
        Me.celdaDireccion.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.celdaDireccion.Multiline = True
        Me.celdaDireccion.Name = "celdaDireccion"
        Me.celdaDireccion.Size = New System.Drawing.Size(541, 78)
        Me.celdaDireccion.TabIndex = 4
        '
        'rbotonSi
        '
        Me.rbotonSi.AutoSize = True
        Me.rbotonSi.Location = New System.Drawing.Point(169, 299)
        Me.rbotonSi.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.rbotonSi.Name = "rbotonSi"
        Me.rbotonSi.Size = New System.Drawing.Size(41, 21)
        Me.rbotonSi.TabIndex = 11
        Me.rbotonSi.Text = "Si"
        Me.rbotonSi.UseVisualStyleBackColor = True
        '
        'etiquetaNIT
        '
        Me.etiquetaNIT.AutoSize = True
        Me.etiquetaNIT.Location = New System.Drawing.Point(24, 194)
        Me.etiquetaNIT.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.etiquetaNIT.Name = "etiquetaNIT"
        Me.etiquetaNIT.Size = New System.Drawing.Size(42, 17)
        Me.etiquetaNIT.TabIndex = 0
        Me.etiquetaNIT.Text = "N.I.T."
        '
        'celdaIDEstado
        '
        Me.celdaIDEstado.Location = New System.Drawing.Point(299, 378)
        Me.celdaIDEstado.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.celdaIDEstado.Name = "celdaIDEstado"
        Me.celdaIDEstado.Size = New System.Drawing.Size(20, 22)
        Me.celdaIDEstado.TabIndex = 71
        Me.celdaIDEstado.Text = "-1"
        Me.celdaIDEstado.Visible = False
        '
        'etiquetaTelefono
        '
        Me.etiquetaTelefono.AutoSize = True
        Me.etiquetaTelefono.Location = New System.Drawing.Point(24, 164)
        Me.etiquetaTelefono.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.etiquetaTelefono.Name = "etiquetaTelefono"
        Me.etiquetaTelefono.Size = New System.Drawing.Size(122, 17)
        Me.etiquetaTelefono.TabIndex = 0
        Me.etiquetaTelefono.Text = "Telephon Number"
        '
        'celdaIDMoneda
        '
        Me.celdaIDMoneda.Location = New System.Drawing.Point(327, 266)
        Me.celdaIDMoneda.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.celdaIDMoneda.Name = "celdaIDMoneda"
        Me.celdaIDMoneda.Size = New System.Drawing.Size(55, 22)
        Me.celdaIDMoneda.TabIndex = 70
        Me.celdaIDMoneda.Text = "-1"
        Me.celdaIDMoneda.Visible = False
        '
        'celdaTelefono
        '
        Me.celdaTelefono.Location = New System.Drawing.Point(165, 161)
        Me.celdaTelefono.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.celdaTelefono.Name = "celdaTelefono"
        Me.celdaTelefono.Size = New System.Drawing.Size(229, 22)
        Me.celdaTelefono.TabIndex = 5
        '
        'celdaIDRegimen
        '
        Me.celdaIDRegimen.Location = New System.Drawing.Point(251, 226)
        Me.celdaIDRegimen.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.celdaIDRegimen.Name = "celdaIDRegimen"
        Me.celdaIDRegimen.Size = New System.Drawing.Size(20, 22)
        Me.celdaIDRegimen.TabIndex = 69
        Me.celdaIDRegimen.Text = "-1"
        Me.celdaIDRegimen.Visible = False
        '
        'etiquetaRegimen
        '
        Me.etiquetaRegimen.AutoSize = True
        Me.etiquetaRegimen.Location = New System.Drawing.Point(24, 230)
        Me.etiquetaRegimen.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.etiquetaRegimen.Name = "etiquetaRegimen"
        Me.etiquetaRegimen.Size = New System.Drawing.Size(56, 17)
        Me.etiquetaRegimen.TabIndex = 0
        Me.etiquetaRegimen.Text = "Regime"
        '
        'celdaIDPais
        '
        Me.celdaIDPais.Location = New System.Drawing.Point(709, 204)
        Me.celdaIDPais.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.celdaIDPais.Name = "celdaIDPais"
        Me.celdaIDPais.Size = New System.Drawing.Size(20, 22)
        Me.celdaIDPais.TabIndex = 68
        Me.celdaIDPais.Text = "-1"
        Me.celdaIDPais.Visible = False
        '
        'etiquetaPais
        '
        Me.etiquetaPais.AutoSize = True
        Me.etiquetaPais.Location = New System.Drawing.Point(400, 233)
        Me.etiquetaPais.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.etiquetaPais.Name = "etiquetaPais"
        Me.etiquetaPais.Size = New System.Drawing.Size(57, 17)
        Me.etiquetaPais.TabIndex = 0
        Me.etiquetaPais.Text = "Country"
        '
        'celdaIDAreaNegocio
        '
        Me.celdaIDAreaNegocio.Location = New System.Drawing.Point(684, 258)
        Me.celdaIDAreaNegocio.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.celdaIDAreaNegocio.Name = "celdaIDAreaNegocio"
        Me.celdaIDAreaNegocio.Size = New System.Drawing.Size(47, 22)
        Me.celdaIDAreaNegocio.TabIndex = 67
        Me.celdaIDAreaNegocio.Text = "-1"
        Me.celdaIDAreaNegocio.Visible = False
        '
        'celdaRegimen
        '
        Me.celdaRegimen.Location = New System.Drawing.Point(169, 226)
        Me.celdaRegimen.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.celdaRegimen.Name = "celdaRegimen"
        Me.celdaRegimen.ReadOnly = True
        Me.celdaRegimen.Size = New System.Drawing.Size(72, 22)
        Me.celdaRegimen.TabIndex = 0
        '
        'celdaIDMetodoCosteo
        '
        Me.celdaIDMetodoCosteo.Location = New System.Drawing.Point(687, 299)
        Me.celdaIDMetodoCosteo.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.celdaIDMetodoCosteo.Name = "celdaIDMetodoCosteo"
        Me.celdaIDMetodoCosteo.Size = New System.Drawing.Size(20, 22)
        Me.celdaIDMetodoCosteo.TabIndex = 66
        Me.celdaIDMetodoCosteo.Text = "-1"
        Me.celdaIDMetodoCosteo.Visible = False
        '
        'celdaPais
        '
        Me.celdaPais.Location = New System.Drawing.Point(507, 230)
        Me.celdaPais.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.celdaPais.Name = "celdaPais"
        Me.celdaPais.ReadOnly = True
        Me.celdaPais.Size = New System.Drawing.Size(211, 22)
        Me.celdaPais.TabIndex = 0
        '
        'celdaDesCorta
        '
        Me.celdaDesCorta.BackColor = System.Drawing.SystemColors.Info
        Me.celdaDesCorta.Location = New System.Drawing.Point(476, 10)
        Me.celdaDesCorta.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.celdaDesCorta.Name = "celdaDesCorta"
        Me.celdaDesCorta.Size = New System.Drawing.Size(232, 22)
        Me.celdaDesCorta.TabIndex = 2
        '
        'botonRegimen
        '
        Me.botonRegimen.Location = New System.Drawing.Point(276, 224)
        Me.botonRegimen.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.botonRegimen.Name = "botonRegimen"
        Me.botonRegimen.Size = New System.Drawing.Size(43, 28)
        Me.botonRegimen.TabIndex = 7
        Me.botonRegimen.Text = "..."
        Me.botonRegimen.UseVisualStyleBackColor = True
        '
        'celdaCodigo
        '
        Me.celdaCodigo.BackColor = System.Drawing.SystemColors.Info
        Me.celdaCodigo.Location = New System.Drawing.Point(165, 10)
        Me.celdaCodigo.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.celdaCodigo.Name = "celdaCodigo"
        Me.celdaCodigo.ReadOnly = True
        Me.celdaCodigo.Size = New System.Drawing.Size(151, 22)
        Me.celdaCodigo.TabIndex = 1
        '
        'botonPais
        '
        Me.botonPais.Location = New System.Drawing.Point(725, 226)
        Me.botonPais.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.botonPais.Name = "botonPais"
        Me.botonPais.Size = New System.Drawing.Size(43, 28)
        Me.botonPais.TabIndex = 8
        Me.botonPais.Text = "..."
        Me.botonPais.UseVisualStyleBackColor = True
        '
        'celdaNT
        '
        Me.celdaNT.Location = New System.Drawing.Point(165, 190)
        Me.celdaNT.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.celdaNT.Name = "celdaNT"
        Me.celdaNT.Size = New System.Drawing.Size(229, 22)
        Me.celdaNT.TabIndex = 6
        '
        'etiquetaMoneda
        '
        Me.etiquetaMoneda.AutoSize = True
        Me.etiquetaMoneda.Location = New System.Drawing.Point(24, 266)
        Me.etiquetaMoneda.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.etiquetaMoneda.Name = "etiquetaMoneda"
        Me.etiquetaMoneda.Size = New System.Drawing.Size(65, 17)
        Me.etiquetaMoneda.TabIndex = 0
        Me.etiquetaMoneda.Text = "Currency"
        '
        'botonEstado
        '
        Me.botonEstado.Location = New System.Drawing.Point(667, 334)
        Me.botonEstado.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.botonEstado.Name = "botonEstado"
        Me.botonEstado.Size = New System.Drawing.Size(43, 28)
        Me.botonEstado.TabIndex = 15
        Me.botonEstado.Text = "..."
        Me.botonEstado.UseVisualStyleBackColor = True
        '
        'celdaMoneda
        '
        Me.celdaMoneda.Location = New System.Drawing.Point(169, 262)
        Me.celdaMoneda.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.celdaMoneda.Name = "celdaMoneda"
        Me.celdaMoneda.ReadOnly = True
        Me.celdaMoneda.Size = New System.Drawing.Size(72, 22)
        Me.celdaMoneda.TabIndex = 0
        '
        'celdaEstado
        '
        Me.celdaEstado.Location = New System.Drawing.Point(507, 337)
        Me.celdaEstado.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.celdaEstado.Name = "celdaEstado"
        Me.celdaEstado.Size = New System.Drawing.Size(149, 22)
        Me.celdaEstado.TabIndex = 0
        '
        'botonMoneda
        '
        Me.botonMoneda.Location = New System.Drawing.Point(276, 258)
        Me.botonMoneda.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.botonMoneda.Name = "botonMoneda"
        Me.botonMoneda.Size = New System.Drawing.Size(43, 28)
        Me.botonMoneda.TabIndex = 9
        Me.botonMoneda.Text = "..."
        Me.botonMoneda.UseVisualStyleBackColor = True
        '
        'etiquetaEstado
        '
        Me.etiquetaEstado.AutoSize = True
        Me.etiquetaEstado.Location = New System.Drawing.Point(459, 341)
        Me.etiquetaEstado.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.etiquetaEstado.Name = "etiquetaEstado"
        Me.etiquetaEstado.Size = New System.Drawing.Size(41, 17)
        Me.etiquetaEstado.TabIndex = 0
        Me.etiquetaEstado.Text = "State"
        '
        'etiquetaFabricante
        '
        Me.etiquetaFabricante.AutoSize = True
        Me.etiquetaFabricante.Location = New System.Drawing.Point(24, 302)
        Me.etiquetaFabricante.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.etiquetaFabricante.Name = "etiquetaFabricante"
        Me.etiquetaFabricante.Size = New System.Drawing.Size(87, 17)
        Me.etiquetaFabricante.TabIndex = 0
        Me.etiquetaFabricante.Text = "Manufacture"
        '
        'etiquetaPeqContribuyentes
        '
        Me.etiquetaPeqContribuyentes.AutoSize = True
        Me.etiquetaPeqContribuyentes.Location = New System.Drawing.Point(24, 367)
        Me.etiquetaPeqContribuyentes.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.etiquetaPeqContribuyentes.Name = "etiquetaPeqContribuyentes"
        Me.etiquetaPeqContribuyentes.Size = New System.Drawing.Size(237, 17)
        Me.etiquetaPeqContribuyentes.TabIndex = 49
        Me.etiquetaPeqContribuyentes.Text = "**SMALL TAXPAYERS / IMPORTS** "
        '
        'etiquetaAreaNegocios
        '
        Me.etiquetaAreaNegocios.AutoSize = True
        Me.etiquetaAreaNegocios.Location = New System.Drawing.Point(400, 268)
        Me.etiquetaAreaNegocios.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.etiquetaAreaNegocios.Name = "etiquetaAreaNegocios"
        Me.etiquetaAreaNegocios.Size = New System.Drawing.Size(99, 17)
        Me.etiquetaAreaNegocios.TabIndex = 0
        Me.etiquetaAreaNegocios.Text = "Business Area"
        '
        'checkDerechoCreditoFiscal
        '
        Me.checkDerechoCreditoFiscal.AutoSize = True
        Me.checkDerechoCreditoFiscal.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.checkDerechoCreditoFiscal.Location = New System.Drawing.Point(27, 337)
        Me.checkDerechoCreditoFiscal.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.checkDerechoCreditoFiscal.Name = "checkDerechoCreditoFiscal"
        Me.checkDerechoCreditoFiscal.Size = New System.Drawing.Size(369, 21)
        Me.checkDerechoCreditoFiscal.TabIndex = 14
        Me.checkDerechoCreditoFiscal.Text = "GENERATES NO RIGTH TO TAX CREDIT (IVA)"
        Me.checkDerechoCreditoFiscal.UseVisualStyleBackColor = True
        '
        'celdaAreaNegocios
        '
        Me.celdaAreaNegocios.Location = New System.Drawing.Point(507, 262)
        Me.celdaAreaNegocios.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.celdaAreaNegocios.Name = "celdaAreaNegocios"
        Me.celdaAreaNegocios.ReadOnly = True
        Me.celdaAreaNegocios.Size = New System.Drawing.Size(123, 22)
        Me.celdaAreaNegocios.TabIndex = 0
        '
        'botonMetodoCos
        '
        Me.botonMetodoCos.Location = New System.Drawing.Point(637, 295)
        Me.botonMetodoCos.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.botonMetodoCos.Name = "botonMetodoCos"
        Me.botonMetodoCos.Size = New System.Drawing.Size(43, 28)
        Me.botonMetodoCos.TabIndex = 13
        Me.botonMetodoCos.Text = "..."
        Me.botonMetodoCos.UseVisualStyleBackColor = True
        '
        'botonCeldaNegocios
        '
        Me.botonCeldaNegocios.Location = New System.Drawing.Point(637, 258)
        Me.botonCeldaNegocios.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.botonCeldaNegocios.Name = "botonCeldaNegocios"
        Me.botonCeldaNegocios.Size = New System.Drawing.Size(43, 28)
        Me.botonCeldaNegocios.TabIndex = 10
        Me.botonCeldaNegocios.Text = "..."
        Me.botonCeldaNegocios.UseVisualStyleBackColor = True
        '
        'celdaMetodoCosteo
        '
        Me.celdaMetodoCosteo.Location = New System.Drawing.Point(507, 295)
        Me.celdaMetodoCosteo.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.celdaMetodoCosteo.Name = "celdaMetodoCosteo"
        Me.celdaMetodoCosteo.ReadOnly = True
        Me.celdaMetodoCosteo.Size = New System.Drawing.Size(123, 22)
        Me.celdaMetodoCosteo.TabIndex = 0
        '
        'etiquetaMetodoCosteo
        '
        Me.etiquetaMetodoCosteo.AutoSize = True
        Me.etiquetaMetodoCosteo.Location = New System.Drawing.Point(400, 299)
        Me.etiquetaMetodoCosteo.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.etiquetaMetodoCosteo.Name = "etiquetaMetodoCosteo"
        Me.etiquetaMetodoCosteo.Size = New System.Drawing.Size(106, 17)
        Me.etiquetaMetodoCosteo.TabIndex = 0
        Me.etiquetaMetodoCosteo.Text = "Costing Method"
        '
        'panelEncabezado
        '
        Me.panelEncabezado.Controls.Add(Me.gbPosiCuenta)
        Me.panelEncabezado.Controls.Add(Me.gbContabilidad)
        Me.panelEncabezado.Controls.Add(Me.celdaLimiteCredito)
        Me.panelEncabezado.Controls.Add(Me.etiquetaLimiteCredito)
        Me.panelEncabezado.Controls.Add(Me.celdaPlazoCredito)
        Me.panelEncabezado.Controls.Add(Me.etiquetaPlazoCredito)
        Me.panelEncabezado.Controls.Add(Me.celdaDescuento)
        Me.panelEncabezado.Controls.Add(Me.etiquetaDescuento)
        Me.panelEncabezado.Dock = System.Windows.Forms.DockStyle.Right
        Me.panelEncabezado.Location = New System.Drawing.Point(958, 0)
        Me.panelEncabezado.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.panelEncabezado.Name = "panelEncabezado"
        Me.panelEncabezado.Size = New System.Drawing.Size(397, 564)
        Me.panelEncabezado.TabIndex = 0
        '
        'gbPosiCuenta
        '
        Me.gbPosiCuenta.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.gbPosiCuenta.Controls.Add(Me.etiquetaDisponible)
        Me.gbPosiCuenta.Controls.Add(Me.etiquetaSaldo)
        Me.gbPosiCuenta.Controls.Add(Me.celdaDisponible)
        Me.gbPosiCuenta.Controls.Add(Me.celdaSaldo)
        Me.gbPosiCuenta.Location = New System.Drawing.Point(4, 375)
        Me.gbPosiCuenta.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.gbPosiCuenta.Name = "gbPosiCuenta"
        Me.gbPosiCuenta.Padding = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.gbPosiCuenta.Size = New System.Drawing.Size(336, 123)
        Me.gbPosiCuenta.TabIndex = 0
        Me.gbPosiCuenta.TabStop = False
        Me.gbPosiCuenta.Text = "Account Position"
        '
        'etiquetaDisponible
        '
        Me.etiquetaDisponible.AutoSize = True
        Me.etiquetaDisponible.Location = New System.Drawing.Point(36, 80)
        Me.etiquetaDisponible.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.etiquetaDisponible.Name = "etiquetaDisponible"
        Me.etiquetaDisponible.Size = New System.Drawing.Size(65, 17)
        Me.etiquetaDisponible.TabIndex = 0
        Me.etiquetaDisponible.Text = "Available"
        '
        'etiquetaSaldo
        '
        Me.etiquetaSaldo.AutoSize = True
        Me.etiquetaSaldo.Location = New System.Drawing.Point(36, 38)
        Me.etiquetaSaldo.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.etiquetaSaldo.Name = "etiquetaSaldo"
        Me.etiquetaSaldo.Size = New System.Drawing.Size(59, 17)
        Me.etiquetaSaldo.TabIndex = 0
        Me.etiquetaSaldo.Text = "Balance"
        '
        'celdaDisponible
        '
        Me.celdaDisponible.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.celdaDisponible.Location = New System.Drawing.Point(111, 76)
        Me.celdaDisponible.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.celdaDisponible.Name = "celdaDisponible"
        Me.celdaDisponible.ReadOnly = True
        Me.celdaDisponible.Size = New System.Drawing.Size(224, 22)
        Me.celdaDisponible.TabIndex = 0
        '
        'celdaSaldo
        '
        Me.celdaSaldo.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.celdaSaldo.Location = New System.Drawing.Point(111, 34)
        Me.celdaSaldo.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.celdaSaldo.Name = "celdaSaldo"
        Me.celdaSaldo.ReadOnly = True
        Me.celdaSaldo.Size = New System.Drawing.Size(224, 22)
        Me.celdaSaldo.TabIndex = 0
        '
        'gbContabilidad
        '
        Me.gbContabilidad.Controls.Add(Me.celdaIDCxP)
        Me.gbContabilidad.Controls.Add(Me.celdaIDProdPredet)
        Me.gbContabilidad.Controls.Add(Me.botonProducPred)
        Me.gbContabilidad.Controls.Add(Me.botonCxP)
        Me.gbContabilidad.Controls.Add(Me.rbServicio)
        Me.gbContabilidad.Controls.Add(Me.rbBien)
        Me.gbContabilidad.Controls.Add(Me.celdaPreProduct)
        Me.gbContabilidad.Controls.Add(Me.celdaPredPro)
        Me.gbContabilidad.Controls.Add(Me.etiquetaProPred)
        Me.gbContabilidad.Controls.Add(Me.celdaCxPagar)
        Me.gbContabilidad.Controls.Add(Me.celdaCuentasxPagar)
        Me.gbContabilidad.Controls.Add(Me.etiquetaCuentasxPagar)
        Me.gbContabilidad.Location = New System.Drawing.Point(4, 129)
        Me.gbContabilidad.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.gbContabilidad.Name = "gbContabilidad"
        Me.gbContabilidad.Padding = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.gbContabilidad.Size = New System.Drawing.Size(385, 233)
        Me.gbContabilidad.TabIndex = 0
        Me.gbContabilidad.TabStop = False
        Me.gbContabilidad.Text = "Accounting"
        '
        'celdaIDCxP
        '
        Me.celdaIDCxP.Location = New System.Drawing.Point(237, 39)
        Me.celdaIDCxP.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.celdaIDCxP.Name = "celdaIDCxP"
        Me.celdaIDCxP.Size = New System.Drawing.Size(20, 22)
        Me.celdaIDCxP.TabIndex = 66
        Me.celdaIDCxP.Text = "-1"
        Me.celdaIDCxP.Visible = False
        '
        'celdaIDProdPredet
        '
        Me.celdaIDProdPredet.Location = New System.Drawing.Point(237, 130)
        Me.celdaIDProdPredet.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.celdaIDProdPredet.Name = "celdaIDProdPredet"
        Me.celdaIDProdPredet.Size = New System.Drawing.Size(20, 22)
        Me.celdaIDProdPredet.TabIndex = 65
        Me.celdaIDProdPredet.Text = "-1"
        Me.celdaIDProdPredet.Visible = False
        '
        'botonProducPred
        '
        Me.botonProducPred.Location = New System.Drawing.Point(325, 126)
        Me.botonProducPred.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.botonProducPred.Name = "botonProducPred"
        Me.botonProducPred.Size = New System.Drawing.Size(43, 28)
        Me.botonProducPred.TabIndex = 22
        Me.botonProducPred.Text = "..."
        Me.botonProducPred.UseVisualStyleBackColor = True
        '
        'botonCxP
        '
        Me.botonCxP.Location = New System.Drawing.Point(325, 36)
        Me.botonCxP.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.botonCxP.Name = "botonCxP"
        Me.botonCxP.Size = New System.Drawing.Size(43, 28)
        Me.botonCxP.TabIndex = 21
        Me.botonCxP.Text = "..."
        Me.botonCxP.UseVisualStyleBackColor = True
        '
        'rbServicio
        '
        Me.rbServicio.AutoSize = True
        Me.rbServicio.Location = New System.Drawing.Point(140, 202)
        Me.rbServicio.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.rbServicio.Name = "rbServicio"
        Me.rbServicio.Size = New System.Drawing.Size(76, 21)
        Me.rbServicio.TabIndex = 24
        Me.rbServicio.Text = "Service"
        Me.rbServicio.UseVisualStyleBackColor = True
        '
        'rbBien
        '
        Me.rbBien.AutoSize = True
        Me.rbBien.Checked = True
        Me.rbBien.Location = New System.Drawing.Point(12, 202)
        Me.rbBien.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.rbBien.Name = "rbBien"
        Me.rbBien.Size = New System.Drawing.Size(73, 21)
        Me.rbBien.TabIndex = 23
        Me.rbBien.TabStop = True
        Me.rbBien.Text = "Benefit"
        Me.rbBien.UseVisualStyleBackColor = True
        '
        'celdaPreProduct
        '
        Me.celdaPreProduct.BackColor = System.Drawing.SystemColors.Info
        Me.celdaPreProduct.Location = New System.Drawing.Point(11, 166)
        Me.celdaPreProduct.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.celdaPreProduct.Name = "celdaPreProduct"
        Me.celdaPreProduct.ReadOnly = True
        Me.celdaPreProduct.Size = New System.Drawing.Size(343, 22)
        Me.celdaPreProduct.TabIndex = 0
        '
        'celdaPredPro
        '
        Me.celdaPredPro.Location = New System.Drawing.Point(11, 130)
        Me.celdaPredPro.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.celdaPredPro.Name = "celdaPredPro"
        Me.celdaPredPro.ReadOnly = True
        Me.celdaPredPro.Size = New System.Drawing.Size(307, 22)
        Me.celdaPredPro.TabIndex = 0
        '
        'etiquetaProPred
        '
        Me.etiquetaProPred.AutoSize = True
        Me.etiquetaProPred.Location = New System.Drawing.Point(7, 113)
        Me.etiquetaProPred.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.etiquetaProPred.Name = "etiquetaProPred"
        Me.etiquetaProPred.Size = New System.Drawing.Size(154, 17)
        Me.etiquetaProPred.TabIndex = 57
        Me.etiquetaProPred.Text = "Predetermined Product"
        '
        'celdaCxPagar
        '
        Me.celdaCxPagar.BackColor = System.Drawing.SystemColors.Info
        Me.celdaCxPagar.Location = New System.Drawing.Point(12, 74)
        Me.celdaCxPagar.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.celdaCxPagar.Name = "celdaCxPagar"
        Me.celdaCxPagar.ReadOnly = True
        Me.celdaCxPagar.Size = New System.Drawing.Size(343, 22)
        Me.celdaCxPagar.TabIndex = 56
        '
        'celdaCuentasxPagar
        '
        Me.celdaCuentasxPagar.Location = New System.Drawing.Point(12, 39)
        Me.celdaCuentasxPagar.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.celdaCuentasxPagar.Name = "celdaCuentasxPagar"
        Me.celdaCuentasxPagar.ReadOnly = True
        Me.celdaCuentasxPagar.Size = New System.Drawing.Size(305, 22)
        Me.celdaCuentasxPagar.TabIndex = 0
        '
        'etiquetaCuentasxPagar
        '
        Me.etiquetaCuentasxPagar.AutoSize = True
        Me.etiquetaCuentasxPagar.Location = New System.Drawing.Point(8, 25)
        Me.etiquetaCuentasxPagar.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.etiquetaCuentasxPagar.Name = "etiquetaCuentasxPagar"
        Me.etiquetaCuentasxPagar.Size = New System.Drawing.Size(94, 17)
        Me.etiquetaCuentasxPagar.TabIndex = 49
        Me.etiquetaCuentasxPagar.Text = "Debts To Pay"
        '
        'celdaLimiteCredito
        '
        Me.celdaLimiteCredito.Location = New System.Drawing.Point(155, 90)
        Me.celdaLimiteCredito.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.celdaLimiteCredito.Name = "celdaLimiteCredito"
        Me.celdaLimiteCredito.Size = New System.Drawing.Size(215, 22)
        Me.celdaLimiteCredito.TabIndex = 20
        '
        'etiquetaLimiteCredito
        '
        Me.etiquetaLimiteCredito.AutoSize = True
        Me.etiquetaLimiteCredito.Location = New System.Drawing.Point(19, 94)
        Me.etiquetaLimiteCredito.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.etiquetaLimiteCredito.Name = "etiquetaLimiteCredito"
        Me.etiquetaLimiteCredito.Size = New System.Drawing.Size(140, 17)
        Me.etiquetaLimiteCredito.TabIndex = 52
        Me.etiquetaLimiteCredito.Text = "Credit Limit (Amount)"
        '
        'celdaPlazoCredito
        '
        Me.celdaPlazoCredito.Location = New System.Drawing.Point(155, 57)
        Me.celdaPlazoCredito.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.celdaPlazoCredito.Name = "celdaPlazoCredito"
        Me.celdaPlazoCredito.Size = New System.Drawing.Size(215, 22)
        Me.celdaPlazoCredito.TabIndex = 19
        '
        'etiquetaPlazoCredito
        '
        Me.etiquetaPlazoCredito.AutoSize = True
        Me.etiquetaPlazoCredito.Location = New System.Drawing.Point(19, 60)
        Me.etiquetaPlazoCredito.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.etiquetaPlazoCredito.Name = "etiquetaPlazoCredito"
        Me.etiquetaPlazoCredito.Size = New System.Drawing.Size(128, 17)
        Me.etiquetaPlazoCredito.TabIndex = 50
        Me.etiquetaPlazoCredito.Text = "Credit Term (Days)"
        '
        'celdaDescuento
        '
        Me.celdaDescuento.Location = New System.Drawing.Point(155, 21)
        Me.celdaDescuento.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.celdaDescuento.Name = "celdaDescuento"
        Me.celdaDescuento.Size = New System.Drawing.Size(215, 22)
        Me.celdaDescuento.TabIndex = 18
        '
        'etiquetaDescuento
        '
        Me.etiquetaDescuento.AutoSize = True
        Me.etiquetaDescuento.Location = New System.Drawing.Point(19, 25)
        Me.etiquetaDescuento.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.etiquetaDescuento.Name = "etiquetaDescuento"
        Me.etiquetaDescuento.Size = New System.Drawing.Size(89, 17)
        Me.etiquetaDescuento.TabIndex = 48
        Me.etiquetaDescuento.Text = "Discount (%)"
        '
        'panelDetalle
        '
        Me.panelDetalle.Controls.Add(Me.dgDetalle)
        Me.panelDetalle.Controls.Add(Me.panelBotones)
        Me.panelDetalle.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.panelDetalle.Location = New System.Drawing.Point(0, 564)
        Me.panelDetalle.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.panelDetalle.Name = "panelDetalle"
        Me.panelDetalle.Size = New System.Drawing.Size(1355, 117)
        Me.panelDetalle.TabIndex = 2
        '
        'dgDetalle
        '
        Me.dgDetalle.AllowUserToAddRows = False
        Me.dgDetalle.AllowUserToDeleteRows = False
        Me.dgDetalle.AllowUserToOrderColumns = True
        Me.dgDetalle.BackgroundColor = System.Drawing.SystemColors.Control
        Me.dgDetalle.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgDetalle.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.colNombre, Me.colPuesto, Me.colCelular, Me.colCorreo, Me.colEstado, Me.colCodigo, Me.colStatus})
        Me.dgDetalle.Dock = System.Windows.Forms.DockStyle.Fill
        Me.dgDetalle.Location = New System.Drawing.Point(0, 0)
        Me.dgDetalle.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.dgDetalle.MultiSelect = False
        Me.dgDetalle.Name = "dgDetalle"
        Me.dgDetalle.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.dgDetalle.Size = New System.Drawing.Size(1286, 117)
        Me.dgDetalle.TabIndex = 0
        '
        'colNombre
        '
        Me.colNombre.HeaderText = "Name"
        Me.colNombre.Name = "colNombre"
        '
        'colPuesto
        '
        Me.colPuesto.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.colPuesto.HeaderText = "Position"
        Me.colPuesto.Name = "colPuesto"
        Me.colPuesto.Width = 87
        '
        'colCelular
        '
        Me.colCelular.HeaderText = "Cell Phone"
        Me.colCelular.Name = "colCelular"
        '
        'colCorreo
        '
        Me.colCorreo.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.colCorreo.HeaderText = "Email"
        Me.colCorreo.Name = "colCorreo"
        Me.colCorreo.Width = 71
        '
        'colEstado
        '
        Me.colEstado.HeaderText = "Status"
        Me.colEstado.Name = "colEstado"
        Me.colEstado.ReadOnly = True
        '
        'colCodigo
        '
        Me.colCodigo.HeaderText = "Codigo"
        Me.colCodigo.Name = "colCodigo"
        Me.colCodigo.Visible = False
        '
        'colStatus
        '
        Me.colStatus.HeaderText = "Status"
        Me.colStatus.Name = "colStatus"
        Me.colStatus.Visible = False
        '
        'panelBotones
        '
        Me.panelBotones.Controls.Add(Me.botonAbajo)
        Me.panelBotones.Controls.Add(Me.botonUp)
        Me.panelBotones.Dock = System.Windows.Forms.DockStyle.Right
        Me.panelBotones.Location = New System.Drawing.Point(1286, 0)
        Me.panelBotones.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.panelBotones.Name = "panelBotones"
        Me.panelBotones.Size = New System.Drawing.Size(69, 117)
        Me.panelBotones.TabIndex = 1
        '
        'botonAbajo
        '
        Me.botonAbajo.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.botonAbajo.Image = Global.KARIMs_SGI.My.Resources.Resources.minus2
        Me.botonAbajo.Location = New System.Drawing.Point(13, 39)
        Me.botonAbajo.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.botonAbajo.Name = "botonAbajo"
        Me.botonAbajo.Size = New System.Drawing.Size(43, 31)
        Me.botonAbajo.TabIndex = 0
        Me.botonAbajo.UseVisualStyleBackColor = True
        '
        'botonUp
        '
        Me.botonUp.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.botonUp.Image = Global.KARIMs_SGI.My.Resources.Resources.plus
        Me.botonUp.Location = New System.Drawing.Point(13, 7)
        Me.botonUp.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.botonUp.Name = "botonUp"
        Me.botonUp.Size = New System.Drawing.Size(43, 28)
        Me.botonUp.TabIndex = 0
        Me.botonUp.UseVisualStyleBackColor = True
        '
        'BarraTitulo1
        '
        Me.BarraTitulo1.BackColor = System.Drawing.Color.WhiteSmoke
        Me.BarraTitulo1.Dock = System.Windows.Forms.DockStyle.Top
        Me.BarraTitulo1.Location = New System.Drawing.Point(0, 89)
        Me.BarraTitulo1.Margin = New System.Windows.Forms.Padding(5, 5, 5, 5)
        Me.BarraTitulo1.Name = "BarraTitulo1"
        Me.BarraTitulo1.Size = New System.Drawing.Size(1355, 37)
        Me.BarraTitulo1.TabIndex = 1
        '
        'Encabezado1
        '
        Me.Encabezado1.Dock = System.Windows.Forms.DockStyle.Top
        Me.Encabezado1.Location = New System.Drawing.Point(0, 0)
        Me.Encabezado1.Margin = New System.Windows.Forms.Padding(5, 5, 5, 5)
        Me.Encabezado1.Name = "Encabezado1"
        Me.Encabezado1.Size = New System.Drawing.Size(1355, 89)
        Me.Encabezado1.TabIndex = 0
        '
        'frmProveedores
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1355, 857)
        Me.Controls.Add(Me.panelDocumento)
        Me.Controls.Add(Me.panelLista)
        Me.Controls.Add(Me.BarraTitulo1)
        Me.Controls.Add(Me.Encabezado1)
        Me.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.Name = "frmProveedores"
        Me.Text = "frmProveedores"
        Me.WindowState = System.Windows.Forms.FormWindowState.Maximized
        Me.panelLista.ResumeLayout(False)
        CType(Me.dgLista, System.ComponentModel.ISupportInitialize).EndInit()
        Me.panelDocumento.ResumeLayout(False)
        Me.panelDatosProvedor.ResumeLayout(False)
        Me.panelDatosProvedor.PerformLayout()
        Me.gbCuentaContable.ResumeLayout(False)
        Me.gbCuentaContable.PerformLayout()
        Me.GbCuentaMiami.ResumeLayout(False)
        Me.GbCuentaMiami.PerformLayout()
        Me.panelEncabezado.ResumeLayout(False)
        Me.panelEncabezado.PerformLayout()
        Me.gbPosiCuenta.ResumeLayout(False)
        Me.gbPosiCuenta.PerformLayout()
        Me.gbContabilidad.ResumeLayout(False)
        Me.gbContabilidad.PerformLayout()
        Me.panelDetalle.ResumeLayout(False)
        CType(Me.dgDetalle, System.ComponentModel.ISupportInitialize).EndInit()
        Me.panelBotones.ResumeLayout(False)
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents Encabezado1 As KARIMs_SGI.encabezado
    Friend WithEvents BarraTitulo1 As KARIMs_SGI.BarraTitulo
    Friend WithEvents panelLista As System.Windows.Forms.Panel
    Friend WithEvents panelDocumento As System.Windows.Forms.Panel
    Friend WithEvents panelEncabezado As System.Windows.Forms.Panel
    Friend WithEvents etiquetaDesCorta As System.Windows.Forms.Label
    Friend WithEvents etiquetaCodigo As System.Windows.Forms.Label
    Friend WithEvents panelDetalle As System.Windows.Forms.Panel
    Friend WithEvents celdaDireccion As System.Windows.Forms.TextBox
    Friend WithEvents celdaRazonSocial As System.Windows.Forms.TextBox
    Friend WithEvents etiquetaDireccion As System.Windows.Forms.Label
    Friend WithEvents etiquetaRazonSocial As System.Windows.Forms.Label
    Friend WithEvents celdaTelefono As System.Windows.Forms.TextBox
    Friend WithEvents etiquetaTelefono As System.Windows.Forms.Label
    Friend WithEvents etiquetaNIT As System.Windows.Forms.Label
    Friend WithEvents botonPais As System.Windows.Forms.Button
    Friend WithEvents botonRegimen As System.Windows.Forms.Button
    Friend WithEvents celdaPais As System.Windows.Forms.TextBox
    Friend WithEvents celdaRegimen As System.Windows.Forms.TextBox
    Friend WithEvents etiquetaPais As System.Windows.Forms.Label
    Friend WithEvents etiquetaRegimen As System.Windows.Forms.Label
    Friend WithEvents botonMetodoCos As System.Windows.Forms.Button
    Friend WithEvents celdaMetodoCosteo As System.Windows.Forms.TextBox
    Friend WithEvents etiquetaMetodoCosteo As System.Windows.Forms.Label
    Friend WithEvents botonCeldaNegocios As System.Windows.Forms.Button
    Friend WithEvents celdaAreaNegocios As System.Windows.Forms.TextBox
    Friend WithEvents etiquetaAreaNegocios As System.Windows.Forms.Label
    Friend WithEvents etiquetaFabricante As System.Windows.Forms.Label
    Friend WithEvents botonMoneda As System.Windows.Forms.Button
    Friend WithEvents celdaMoneda As System.Windows.Forms.TextBox
    Friend WithEvents etiquetaMoneda As System.Windows.Forms.Label
    Friend WithEvents botonEstado As System.Windows.Forms.Button
    Friend WithEvents celdaEstado As System.Windows.Forms.TextBox
    Friend WithEvents etiquetaEstado As System.Windows.Forms.Label
    Friend WithEvents etiquetaPeqContribuyentes As System.Windows.Forms.Label
    Friend WithEvents checkDerechoCreditoFiscal As System.Windows.Forms.CheckBox
    Friend WithEvents celdaDescuento As System.Windows.Forms.TextBox
    Friend WithEvents etiquetaDescuento As System.Windows.Forms.Label
    Friend WithEvents celdaPlazoCredito As System.Windows.Forms.TextBox
    Friend WithEvents etiquetaPlazoCredito As System.Windows.Forms.Label
    Friend WithEvents dgDetalle As System.Windows.Forms.DataGridView
    Friend WithEvents gbPosiCuenta As System.Windows.Forms.GroupBox
    Friend WithEvents etiquetaDisponible As System.Windows.Forms.Label
    Friend WithEvents etiquetaSaldo As System.Windows.Forms.Label
    Friend WithEvents celdaDisponible As System.Windows.Forms.TextBox
    Friend WithEvents celdaSaldo As System.Windows.Forms.TextBox
    Friend WithEvents gbContabilidad As System.Windows.Forms.GroupBox
    Friend WithEvents botonProducPred As System.Windows.Forms.Button
    Friend WithEvents botonCxP As System.Windows.Forms.Button
    Friend WithEvents rbServicio As System.Windows.Forms.RadioButton
    Friend WithEvents rbBien As System.Windows.Forms.RadioButton
    Friend WithEvents celdaPreProduct As System.Windows.Forms.TextBox
    Friend WithEvents celdaPredPro As System.Windows.Forms.TextBox
    Friend WithEvents etiquetaProPred As System.Windows.Forms.Label
    Friend WithEvents celdaCxPagar As System.Windows.Forms.TextBox
    Friend WithEvents celdaCuentasxPagar As System.Windows.Forms.TextBox
    Friend WithEvents etiquetaCuentasxPagar As System.Windows.Forms.Label
    Friend WithEvents celdaLimiteCredito As System.Windows.Forms.TextBox
    Friend WithEvents etiquetaLimiteCredito As System.Windows.Forms.Label
    Friend WithEvents celdaDesCorta As System.Windows.Forms.TextBox
    Friend WithEvents celdaCodigo As System.Windows.Forms.TextBox
    Friend WithEvents celdaNT As System.Windows.Forms.TextBox
    Friend WithEvents celdaIDEstado As System.Windows.Forms.TextBox
    Friend WithEvents celdaIDMoneda As System.Windows.Forms.TextBox
    Friend WithEvents celdaIDRegimen As System.Windows.Forms.TextBox
    Friend WithEvents celdaIDPais As System.Windows.Forms.TextBox
    Friend WithEvents celdaIDAreaNegocio As System.Windows.Forms.TextBox
    Friend WithEvents celdaIDMetodoCosteo As System.Windows.Forms.TextBox
    Friend WithEvents celdaIDCxP As System.Windows.Forms.TextBox
    Friend WithEvents celdaIDProdPredet As System.Windows.Forms.TextBox
    Friend WithEvents rbotonNo As System.Windows.Forms.RadioButton
    Friend WithEvents rbotonSi As System.Windows.Forms.RadioButton
    Friend WithEvents botonNit As System.Windows.Forms.Button
    Friend WithEvents celdaIDNIT As System.Windows.Forms.TextBox
    Friend WithEvents panelBotones As Panel
    Friend WithEvents botonAbajo As Button
    Friend WithEvents botonUp As Button
    Friend WithEvents dgLista As DataGridView
    Friend WithEvents panelDatosProvedor As Panel
    Friend WithEvents colID As DataGridViewTextBoxColumn
    Friend WithEvents col_Nombre As DataGridViewTextBoxColumn
    Friend WithEvents col_Nit As DataGridViewTextBoxColumn
    Friend WithEvents col_Abreviacion As DataGridViewTextBoxColumn
    Friend WithEvents colDireccion As DataGridViewTextBoxColumn
    Friend WithEvents colTelefono As DataGridViewTextBoxColumn
    Friend WithEvents colNombre As DataGridViewTextBoxColumn
    Friend WithEvents colPuesto As DataGridViewTextBoxColumn
    Friend WithEvents colCelular As DataGridViewTextBoxColumn
    Friend WithEvents colCorreo As DataGridViewTextBoxColumn
    Friend WithEvents colEstado As DataGridViewTextBoxColumn
    Friend WithEvents colCodigo As DataGridViewTextBoxColumn
    Friend WithEvents colStatus As DataGridViewTextBoxColumn
    Friend WithEvents Label3 As Label
    Friend WithEvents celdaCuentaPadre As TextBox
    Friend WithEvents botonCuentaPadre As Button
    Friend WithEvents celdaNombreCuentaPadre As TextBox
    Friend WithEvents Label4 As Label
    Friend WithEvents gbCuentaContable As GroupBox
    Friend WithEvents GbCuentaMiami As GroupBox
    Friend WithEvents celdaCtaNombre As TextBox
    Friend WithEvents Label2 As Label
    Friend WithEvents botonCta As Button
    Friend WithEvents Label1 As Label
    Friend WithEvents celdaCta As TextBox
    Friend WithEvents checkRecibos As System.Windows.Forms.CheckBox
End Class
