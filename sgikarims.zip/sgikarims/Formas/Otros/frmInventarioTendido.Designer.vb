﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmInventarioTendido
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim DataGridViewCellStyle7 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle8 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.botonRefrescar = New System.Windows.Forms.Button()
        Me.celdaReferencia = New System.Windows.Forms.TextBox()
        Me.Panel2 = New System.Windows.Forms.Panel()
        Me.botonCancelar = New System.Windows.Forms.Button()
        Me.botonAceptar = New System.Windows.Forms.Button()
        Me.dgLista = New System.Windows.Forms.DataGridView()
        Me.colAnoI = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colNumeroI = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colLineaI = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colLineaDetalle = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colDescripcionI = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colReferenciaI = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colMedidaI = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colBultosI = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colSaldoI = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colPrecioI = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colDescargoI = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colBultosDI = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colLLaveI = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Panel1.SuspendLayout()
        Me.Panel2.SuspendLayout()
        CType(Me.dgLista, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'Panel1
        '
        Me.Panel1.Controls.Add(Me.botonRefrescar)
        Me.Panel1.Controls.Add(Me.celdaReferencia)
        Me.Panel1.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel1.Location = New System.Drawing.Point(0, 0)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(877, 65)
        Me.Panel1.TabIndex = 0
        '
        'botonRefrescar
        '
        Me.botonRefrescar.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.botonRefrescar.Location = New System.Drawing.Point(594, 33)
        Me.botonRefrescar.Name = "botonRefrescar"
        Me.botonRefrescar.Size = New System.Drawing.Size(75, 23)
        Me.botonRefrescar.TabIndex = 20
        Me.botonRefrescar.Text = "Refresh"
        Me.botonRefrescar.UseVisualStyleBackColor = True
        '
        'celdaReferencia
        '
        Me.celdaReferencia.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.celdaReferencia.Location = New System.Drawing.Point(38, 33)
        Me.celdaReferencia.Name = "celdaReferencia"
        Me.celdaReferencia.Size = New System.Drawing.Size(550, 22)
        Me.celdaReferencia.TabIndex = 19
        '
        'Panel2
        '
        Me.Panel2.Controls.Add(Me.botonCancelar)
        Me.Panel2.Controls.Add(Me.botonAceptar)
        Me.Panel2.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.Panel2.Location = New System.Drawing.Point(0, 264)
        Me.Panel2.Name = "Panel2"
        Me.Panel2.Size = New System.Drawing.Size(877, 65)
        Me.Panel2.TabIndex = 1
        '
        'botonCancelar
        '
        Me.botonCancelar.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.botonCancelar.Image = Global.KARIMs_SGI.My.Resources.Resources.db_cancel
        Me.botonCancelar.Location = New System.Drawing.Point(790, 8)
        Me.botonCancelar.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.botonCancelar.Name = "botonCancelar"
        Me.botonCancelar.Size = New System.Drawing.Size(75, 51)
        Me.botonCancelar.TabIndex = 13
        Me.botonCancelar.Text = "Close"
        Me.botonCancelar.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.botonCancelar.UseVisualStyleBackColor = True
        '
        'botonAceptar
        '
        Me.botonAceptar.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.botonAceptar.Image = Global.KARIMs_SGI.My.Resources.Resources.Aceptado
        Me.botonAceptar.Location = New System.Drawing.Point(708, 8)
        Me.botonAceptar.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.botonAceptar.Name = "botonAceptar"
        Me.botonAceptar.Size = New System.Drawing.Size(75, 51)
        Me.botonAceptar.TabIndex = 12
        Me.botonAceptar.Text = "Accept"
        Me.botonAceptar.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.botonAceptar.UseVisualStyleBackColor = True
        '
        'dgLista
        '
        Me.dgLista.AllowUserToAddRows = False
        Me.dgLista.AllowUserToDeleteRows = False
        Me.dgLista.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells
        Me.dgLista.BackgroundColor = System.Drawing.SystemColors.ActiveCaption
        Me.dgLista.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgLista.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.colAnoI, Me.colNumeroI, Me.colLineaI, Me.colLineaDetalle, Me.colDescripcionI, Me.colReferenciaI, Me.colMedidaI, Me.colBultosI, Me.colSaldoI, Me.colPrecioI, Me.colDescargoI, Me.colBultosDI, Me.colLLaveI})
        Me.dgLista.Dock = System.Windows.Forms.DockStyle.Fill
        Me.dgLista.Location = New System.Drawing.Point(0, 65)
        Me.dgLista.MultiSelect = False
        Me.dgLista.Name = "dgLista"
        Me.dgLista.RowTemplate.Height = 24
        Me.dgLista.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.CellSelect
        Me.dgLista.Size = New System.Drawing.Size(877, 199)
        Me.dgLista.TabIndex = 2
        '
        'colAnoI
        '
        Me.colAnoI.HeaderText = "Ano"
        Me.colAnoI.Name = "colAnoI"
        Me.colAnoI.Visible = False
        Me.colAnoI.Width = 58
        '
        'colNumeroI
        '
        Me.colNumeroI.HeaderText = "Numero"
        Me.colNumeroI.Name = "colNumeroI"
        Me.colNumeroI.Visible = False
        Me.colNumeroI.Width = 83
        '
        'colLineaI
        '
        Me.colLineaI.HeaderText = "Linea"
        Me.colLineaI.Name = "colLineaI"
        Me.colLineaI.Visible = False
        Me.colLineaI.Width = 68
        '
        'colLineaDetalle
        '
        Me.colLineaDetalle.HeaderText = "Line"
        Me.colLineaDetalle.Name = "colLineaDetalle"
        Me.colLineaDetalle.ReadOnly = True
        Me.colLineaDetalle.Width = 60
        '
        'colDescripcionI
        '
        Me.colDescripcionI.HeaderText = "Description"
        Me.colDescripcionI.Name = "colDescripcionI"
        Me.colDescripcionI.ReadOnly = True
        Me.colDescripcionI.Width = 104
        '
        'colReferenciaI
        '
        Me.colReferenciaI.HeaderText = "Reference"
        Me.colReferenciaI.Name = "colReferenciaI"
        Me.colReferenciaI.ReadOnly = True
        Me.colReferenciaI.Width = 99
        '
        'colMedidaI
        '
        Me.colMedidaI.HeaderText = "Measure"
        Me.colMedidaI.Name = "colMedidaI"
        Me.colMedidaI.ReadOnly = True
        Me.colMedidaI.Width = 88
        '
        'colBultosI
        '
        Me.colBultosI.HeaderText = "Package"
        Me.colBultosI.Name = "colBultosI"
        Me.colBultosI.ReadOnly = True
        Me.colBultosI.Width = 88
        '
        'colSaldoI
        '
        Me.colSaldoI.HeaderText = "Balance"
        Me.colSaldoI.Name = "colSaldoI"
        Me.colSaldoI.ReadOnly = True
        Me.colSaldoI.Width = 84
        '
        'colPrecioI
        '
        Me.colPrecioI.HeaderText = "Price"
        Me.colPrecioI.Name = "colPrecioI"
        Me.colPrecioI.ReadOnly = True
        Me.colPrecioI.Width = 65
        '
        'colDescargoI
        '
        DataGridViewCellStyle7.BackColor = System.Drawing.SystemColors.Info
        DataGridViewCellStyle7.SelectionBackColor = System.Drawing.SystemColors.GradientActiveCaption
        Me.colDescargoI.DefaultCellStyle = DataGridViewCellStyle7
        Me.colDescargoI.HeaderText = "Discharge"
        Me.colDescargoI.Name = "colDescargoI"
        Me.colDescargoI.Width = 97
        '
        'colBultosDI
        '
        DataGridViewCellStyle8.BackColor = System.Drawing.SystemColors.Info
        DataGridViewCellStyle8.SelectionBackColor = System.Drawing.SystemColors.GradientActiveCaption
        Me.colBultosDI.DefaultCellStyle = DataGridViewCellStyle8
        Me.colBultosDI.HeaderText = "Out Package"
        Me.colBultosDI.Name = "colBultosDI"
        Me.colBultosDI.Width = 115
        '
        'colLLaveI
        '
        Me.colLLaveI.HeaderText = "LLave"
        Me.colLLaveI.Name = "colLLaveI"
        Me.colLLaveI.ReadOnly = True
        Me.colLLaveI.Visible = False
        Me.colLLaveI.Width = 72
        '
        'frmInventarioTendido
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(877, 329)
        Me.Controls.Add(Me.dgLista)
        Me.Controls.Add(Me.Panel2)
        Me.Controls.Add(Me.Panel1)
        Me.Name = "frmInventarioTendido"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Fiber Inventory"
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        Me.Panel2.ResumeLayout(False)
        CType(Me.dgLista, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
    Friend WithEvents Panel2 As System.Windows.Forms.Panel
    Friend WithEvents dgLista As System.Windows.Forms.DataGridView
    Friend WithEvents botonCancelar As System.Windows.Forms.Button
    Friend WithEvents botonAceptar As System.Windows.Forms.Button
    Friend WithEvents botonRefrescar As System.Windows.Forms.Button
    Friend WithEvents celdaReferencia As System.Windows.Forms.TextBox
    Friend WithEvents colAnoI As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colNumeroI As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colLineaI As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colLineaDetalle As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colDescripcionI As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colReferenciaI As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colMedidaI As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colBultosI As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colSaldoI As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colPrecioI As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colDescargoI As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colBultosDI As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colLLaveI As System.Windows.Forms.DataGridViewTextBoxColumn
End Class
