﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmActivosUnidades
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.panelListaPrincipal = New System.Windows.Forms.Panel()
        Me.dgLista = New System.Windows.Forms.DataGridView()
        Me.panelFecha = New System.Windows.Forms.Panel()
        Me.botonActualizar = New System.Windows.Forms.Button()
        Me.dtpFin = New System.Windows.Forms.DateTimePicker()
        Me.etiquetaFin = New System.Windows.Forms.Label()
        Me.dtpInicio = New System.Windows.Forms.DateTimePicker()
        Me.checkFecha = New System.Windows.Forms.CheckBox()
        Me.panelDocumento = New System.Windows.Forms.Panel()
        Me.panelDetalle = New System.Windows.Forms.Panel()
        Me.dgDetalle = New System.Windows.Forms.DataGridView()
        Me.colidActivos = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colTipoActivo = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colidTipoActivo = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colDescripcion = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colHU = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colLinea = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colEstado = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.panelEncabezado = New System.Windows.Forms.Panel()
        Me.checkActivar = New System.Windows.Forms.CheckBox()
        Me.etiquetaFechaDepreciacion = New System.Windows.Forms.Label()
        Me.etiquetaNombre = New System.Windows.Forms.Label()
        Me.celdaID = New System.Windows.Forms.TextBox()
        Me.etiquetaID = New System.Windows.Forms.Label()
        Me.etiquetaFecha = New System.Windows.Forms.Label()
        Me.celdaDescripcion = New System.Windows.Forms.TextBox()
        Me.dtpFechaDepreciacion = New System.Windows.Forms.DateTimePicker()
        Me.dtpFecha = New System.Windows.Forms.DateTimePicker()
        Me.BarraTitulo1 = New KARIMs_SGI.BarraTitulo()
        Me.Encabezado1 = New KARIMs_SGI.encabezado()
        Me.colAnio = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colNumero = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colFecha = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colFechaD = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.panelListaPrincipal.SuspendLayout()
        CType(Me.dgLista, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.panelFecha.SuspendLayout()
        Me.panelDocumento.SuspendLayout()
        Me.panelDetalle.SuspendLayout()
        CType(Me.dgDetalle, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.panelEncabezado.SuspendLayout()
        Me.SuspendLayout()
        '
        'panelListaPrincipal
        '
        Me.panelListaPrincipal.Controls.Add(Me.dgLista)
        Me.panelListaPrincipal.Controls.Add(Me.panelFecha)
        Me.panelListaPrincipal.Dock = System.Windows.Forms.DockStyle.Top
        Me.panelListaPrincipal.Location = New System.Drawing.Point(0, 102)
        Me.panelListaPrincipal.Margin = New System.Windows.Forms.Padding(2)
        Me.panelListaPrincipal.Name = "panelListaPrincipal"
        Me.panelListaPrincipal.Size = New System.Drawing.Size(613, 73)
        Me.panelListaPrincipal.TabIndex = 5
        '
        'dgLista
        '
        Me.dgLista.AllowUserToAddRows = False
        Me.dgLista.AllowUserToDeleteRows = False
        Me.dgLista.AllowUserToOrderColumns = True
        Me.dgLista.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells
        Me.dgLista.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells
        Me.dgLista.BackgroundColor = System.Drawing.SystemColors.Control
        Me.dgLista.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgLista.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.colAnio, Me.colNumero, Me.colFecha, Me.colFechaD})
        Me.dgLista.Dock = System.Windows.Forms.DockStyle.Fill
        Me.dgLista.Location = New System.Drawing.Point(0, 44)
        Me.dgLista.MultiSelect = False
        Me.dgLista.Name = "dgLista"
        Me.dgLista.ReadOnly = True
        Me.dgLista.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.dgLista.Size = New System.Drawing.Size(613, 29)
        Me.dgLista.TabIndex = 3
        '
        'panelFecha
        '
        Me.panelFecha.Controls.Add(Me.botonActualizar)
        Me.panelFecha.Controls.Add(Me.dtpFin)
        Me.panelFecha.Controls.Add(Me.etiquetaFin)
        Me.panelFecha.Controls.Add(Me.dtpInicio)
        Me.panelFecha.Controls.Add(Me.checkFecha)
        Me.panelFecha.Dock = System.Windows.Forms.DockStyle.Top
        Me.panelFecha.Location = New System.Drawing.Point(0, 0)
        Me.panelFecha.Name = "panelFecha"
        Me.panelFecha.Size = New System.Drawing.Size(613, 44)
        Me.panelFecha.TabIndex = 2
        '
        'botonActualizar
        '
        Me.botonActualizar.Location = New System.Drawing.Point(436, 12)
        Me.botonActualizar.Name = "botonActualizar"
        Me.botonActualizar.Size = New System.Drawing.Size(75, 23)
        Me.botonActualizar.TabIndex = 5
        Me.botonActualizar.Text = "To Update"
        Me.botonActualizar.UseVisualStyleBackColor = True
        '
        'dtpFin
        '
        Me.dtpFin.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.dtpFin.Location = New System.Drawing.Point(326, 14)
        Me.dtpFin.Name = "dtpFin"
        Me.dtpFin.Size = New System.Drawing.Size(86, 20)
        Me.dtpFin.TabIndex = 4
        '
        'etiquetaFin
        '
        Me.etiquetaFin.AutoSize = True
        Me.etiquetaFin.Location = New System.Drawing.Point(271, 17)
        Me.etiquetaFin.Name = "etiquetaFin"
        Me.etiquetaFin.Size = New System.Drawing.Size(51, 13)
        Me.etiquetaFin.TabIndex = 3
        Me.etiquetaFin.Text = "and Date"
        '
        'dtpInicio
        '
        Me.dtpInicio.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.dtpInicio.Location = New System.Drawing.Point(182, 13)
        Me.dtpInicio.Name = "dtpInicio"
        Me.dtpInicio.Size = New System.Drawing.Size(85, 20)
        Me.dtpInicio.TabIndex = 1
        '
        'checkFecha
        '
        Me.checkFecha.AutoSize = True
        Me.checkFecha.Checked = True
        Me.checkFecha.CheckState = System.Windows.Forms.CheckState.Checked
        Me.checkFecha.Location = New System.Drawing.Point(7, 17)
        Me.checkFecha.Name = "checkFecha"
        Me.checkFecha.Size = New System.Drawing.Size(174, 17)
        Me.checkFecha.TabIndex = 0
        Me.checkFecha.Text = "show documents between date"
        Me.checkFecha.UseVisualStyleBackColor = True
        '
        'panelDocumento
        '
        Me.panelDocumento.Controls.Add(Me.panelDetalle)
        Me.panelDocumento.Controls.Add(Me.panelEncabezado)
        Me.panelDocumento.Location = New System.Drawing.Point(23, 181)
        Me.panelDocumento.Name = "panelDocumento"
        Me.panelDocumento.Size = New System.Drawing.Size(520, 180)
        Me.panelDocumento.TabIndex = 6
        '
        'panelDetalle
        '
        Me.panelDetalle.Controls.Add(Me.dgDetalle)
        Me.panelDetalle.Dock = System.Windows.Forms.DockStyle.Fill
        Me.panelDetalle.Location = New System.Drawing.Point(0, 88)
        Me.panelDetalle.Name = "panelDetalle"
        Me.panelDetalle.Size = New System.Drawing.Size(520, 92)
        Me.panelDetalle.TabIndex = 1
        '
        'dgDetalle
        '
        Me.dgDetalle.AllowUserToAddRows = False
        Me.dgDetalle.AllowUserToDeleteRows = False
        Me.dgDetalle.AllowUserToOrderColumns = True
        Me.dgDetalle.BackgroundColor = System.Drawing.SystemColors.Control
        Me.dgDetalle.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgDetalle.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.colidActivos, Me.colTipoActivo, Me.colidTipoActivo, Me.colDescripcion, Me.colHU, Me.colLinea, Me.colEstado})
        Me.dgDetalle.Dock = System.Windows.Forms.DockStyle.Fill
        Me.dgDetalle.Location = New System.Drawing.Point(0, 0)
        Me.dgDetalle.MultiSelect = False
        Me.dgDetalle.Name = "dgDetalle"
        Me.dgDetalle.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.dgDetalle.Size = New System.Drawing.Size(520, 92)
        Me.dgDetalle.TabIndex = 0
        '
        'colidActivos
        '
        Me.colidActivos.HeaderText = "ID"
        Me.colidActivos.Name = "colidActivos"
        Me.colidActivos.ReadOnly = True
        Me.colidActivos.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        '
        'colTipoActivo
        '
        Me.colTipoActivo.HeaderText = "Fixed Asset"
        Me.colTipoActivo.Name = "colTipoActivo"
        Me.colTipoActivo.ReadOnly = True
        Me.colTipoActivo.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        '
        'colidTipoActivo
        '
        Me.colidTipoActivo.HeaderText = "Tipo Activo"
        Me.colidTipoActivo.Name = "colidTipoActivo"
        Me.colidTipoActivo.ReadOnly = True
        Me.colidTipoActivo.Visible = False
        '
        'colDescripcion
        '
        Me.colDescripcion.HeaderText = "Description"
        Me.colDescripcion.Name = "colDescripcion"
        Me.colDescripcion.ReadOnly = True
        Me.colDescripcion.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        '
        'colHU
        '
        Me.colHU.HeaderText = "Hours u Unit"
        Me.colHU.Name = "colHU"
        Me.colHU.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        '
        'colLinea
        '
        Me.colLinea.HeaderText = "Line"
        Me.colLinea.Name = "colLinea"
        Me.colLinea.ReadOnly = True
        Me.colLinea.Visible = False
        '
        'colEstado
        '
        Me.colEstado.HeaderText = "Estado"
        Me.colEstado.Name = "colEstado"
        Me.colEstado.ReadOnly = True
        Me.colEstado.Visible = False
        '
        'panelEncabezado
        '
        Me.panelEncabezado.Controls.Add(Me.checkActivar)
        Me.panelEncabezado.Controls.Add(Me.etiquetaFechaDepreciacion)
        Me.panelEncabezado.Controls.Add(Me.etiquetaNombre)
        Me.panelEncabezado.Controls.Add(Me.celdaID)
        Me.panelEncabezado.Controls.Add(Me.etiquetaID)
        Me.panelEncabezado.Controls.Add(Me.etiquetaFecha)
        Me.panelEncabezado.Controls.Add(Me.celdaDescripcion)
        Me.panelEncabezado.Controls.Add(Me.dtpFechaDepreciacion)
        Me.panelEncabezado.Controls.Add(Me.dtpFecha)
        Me.panelEncabezado.Dock = System.Windows.Forms.DockStyle.Top
        Me.panelEncabezado.Location = New System.Drawing.Point(0, 0)
        Me.panelEncabezado.Name = "panelEncabezado"
        Me.panelEncabezado.Size = New System.Drawing.Size(520, 88)
        Me.panelEncabezado.TabIndex = 0
        '
        'checkActivar
        '
        Me.checkActivar.AutoSize = True
        Me.checkActivar.Checked = True
        Me.checkActivar.CheckState = System.Windows.Forms.CheckState.Checked
        Me.checkActivar.Location = New System.Drawing.Point(282, 16)
        Me.checkActivar.Name = "checkActivar"
        Me.checkActivar.Size = New System.Drawing.Size(56, 17)
        Me.checkActivar.TabIndex = 23
        Me.checkActivar.Text = "Active"
        Me.checkActivar.UseVisualStyleBackColor = True
        '
        'etiquetaFechaDepreciacion
        '
        Me.etiquetaFechaDepreciacion.AutoSize = True
        Me.etiquetaFechaDepreciacion.Location = New System.Drawing.Point(279, 36)
        Me.etiquetaFechaDepreciacion.Name = "etiquetaFechaDepreciacion"
        Me.etiquetaFechaDepreciacion.Size = New System.Drawing.Size(93, 13)
        Me.etiquetaFechaDepreciacion.TabIndex = 7
        Me.etiquetaFechaDepreciacion.Text = "Depreciation Date"
        '
        'etiquetaNombre
        '
        Me.etiquetaNombre.AutoSize = True
        Me.etiquetaNombre.Location = New System.Drawing.Point(39, 65)
        Me.etiquetaNombre.Name = "etiquetaNombre"
        Me.etiquetaNombre.Size = New System.Drawing.Size(35, 13)
        Me.etiquetaNombre.TabIndex = 6
        Me.etiquetaNombre.Text = "Name"
        '
        'celdaID
        '
        Me.celdaID.Location = New System.Drawing.Point(74, 9)
        Me.celdaID.Name = "celdaID"
        Me.celdaID.ReadOnly = True
        Me.celdaID.Size = New System.Drawing.Size(104, 20)
        Me.celdaID.TabIndex = 5
        '
        'etiquetaID
        '
        Me.etiquetaID.AutoSize = True
        Me.etiquetaID.Location = New System.Drawing.Point(39, 12)
        Me.etiquetaID.Name = "etiquetaID"
        Me.etiquetaID.Size = New System.Drawing.Size(18, 13)
        Me.etiquetaID.TabIndex = 4
        Me.etiquetaID.Text = "ID"
        '
        'etiquetaFecha
        '
        Me.etiquetaFecha.AutoSize = True
        Me.etiquetaFecha.Location = New System.Drawing.Point(39, 36)
        Me.etiquetaFecha.Name = "etiquetaFecha"
        Me.etiquetaFecha.Size = New System.Drawing.Size(30, 13)
        Me.etiquetaFecha.TabIndex = 3
        Me.etiquetaFecha.Text = "Date"
        '
        'celdaDescripcion
        '
        Me.celdaDescripcion.Location = New System.Drawing.Point(74, 62)
        Me.celdaDescripcion.Name = "celdaDescripcion"
        Me.celdaDescripcion.ReadOnly = True
        Me.celdaDescripcion.Size = New System.Drawing.Size(298, 20)
        Me.celdaDescripcion.TabIndex = 2
        '
        'dtpFechaDepreciacion
        '
        Me.dtpFechaDepreciacion.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.dtpFechaDepreciacion.Location = New System.Drawing.Point(384, 36)
        Me.dtpFechaDepreciacion.Name = "dtpFechaDepreciacion"
        Me.dtpFechaDepreciacion.Size = New System.Drawing.Size(104, 20)
        Me.dtpFechaDepreciacion.TabIndex = 1
        '
        'dtpFecha
        '
        Me.dtpFecha.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.dtpFecha.Location = New System.Drawing.Point(75, 36)
        Me.dtpFecha.Name = "dtpFecha"
        Me.dtpFecha.Size = New System.Drawing.Size(104, 20)
        Me.dtpFecha.TabIndex = 0
        '
        'BarraTitulo1
        '
        Me.BarraTitulo1.BackColor = System.Drawing.Color.WhiteSmoke
        Me.BarraTitulo1.Dock = System.Windows.Forms.DockStyle.Top
        Me.BarraTitulo1.Location = New System.Drawing.Point(0, 72)
        Me.BarraTitulo1.Name = "BarraTitulo1"
        Me.BarraTitulo1.Size = New System.Drawing.Size(613, 30)
        Me.BarraTitulo1.TabIndex = 1
        '
        'Encabezado1
        '
        Me.Encabezado1.Dock = System.Windows.Forms.DockStyle.Top
        Me.Encabezado1.Location = New System.Drawing.Point(0, 0)
        Me.Encabezado1.Name = "Encabezado1"
        Me.Encabezado1.Size = New System.Drawing.Size(613, 72)
        Me.Encabezado1.TabIndex = 0
        '
        'colAnio
        '
        Me.colAnio.HeaderText = "FechaD"
        Me.colAnio.Name = "colAnio"
        Me.colAnio.ReadOnly = True
        Me.colAnio.Visible = False
        Me.colAnio.Width = 70
        '
        'colNumero
        '
        Me.colNumero.HeaderText = "ID"
        Me.colNumero.Name = "colNumero"
        Me.colNumero.ReadOnly = True
        Me.colNumero.Width = 43
        '
        'colFecha
        '
        Me.colFecha.HeaderText = "Date"
        Me.colFecha.Name = "colFecha"
        Me.colFecha.ReadOnly = True
        Me.colFecha.Width = 55
        '
        'colFechaD
        '
        Me.colFechaD.HeaderText = "Depreciation Date"
        Me.colFechaD.Name = "colFechaD"
        Me.colFechaD.ReadOnly = True
        Me.colFechaD.Width = 108
        '
        'frmActivosUnidades
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(613, 386)
        Me.Controls.Add(Me.panelDocumento)
        Me.Controls.Add(Me.panelListaPrincipal)
        Me.Controls.Add(Me.BarraTitulo1)
        Me.Controls.Add(Me.Encabezado1)
        Me.Name = "frmActivosUnidades"
        Me.Text = "frmActivosUnidades"
        Me.panelListaPrincipal.ResumeLayout(False)
        CType(Me.dgLista, System.ComponentModel.ISupportInitialize).EndInit()
        Me.panelFecha.ResumeLayout(False)
        Me.panelFecha.PerformLayout()
        Me.panelDocumento.ResumeLayout(False)
        Me.panelDetalle.ResumeLayout(False)
        CType(Me.dgDetalle, System.ComponentModel.ISupportInitialize).EndInit()
        Me.panelEncabezado.ResumeLayout(False)
        Me.panelEncabezado.PerformLayout()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents Encabezado1 As encabezado
    Friend WithEvents BarraTitulo1 As BarraTitulo
    Friend WithEvents panelListaPrincipal As Panel
    Friend WithEvents dgLista As DataGridView
    Friend WithEvents panelFecha As Panel
    Friend WithEvents botonActualizar As Button
    Friend WithEvents dtpFin As DateTimePicker
    Friend WithEvents etiquetaFin As Label
    Friend WithEvents dtpInicio As DateTimePicker
    Friend WithEvents checkFecha As System.Windows.Forms.CheckBox
    Friend WithEvents panelDocumento As Panel
    Friend WithEvents panelDetalle As Panel
    Friend WithEvents dgDetalle As DataGridView
    Friend WithEvents panelEncabezado As Panel
    Friend WithEvents celdaID As TextBox
    Friend WithEvents etiquetaID As Label
    Friend WithEvents etiquetaFecha As Label
    Friend WithEvents celdaDescripcion As TextBox
    Friend WithEvents dtpFechaDepreciacion As DateTimePicker
    Friend WithEvents dtpFecha As DateTimePicker
    Friend WithEvents etiquetaNombre As Label
    Friend WithEvents etiquetaFechaDepreciacion As Label
    Friend WithEvents checkActivar As System.Windows.Forms.CheckBox
    Friend WithEvents colidActivos As DataGridViewTextBoxColumn
    Friend WithEvents colTipoActivo As DataGridViewTextBoxColumn
    Friend WithEvents colidTipoActivo As DataGridViewTextBoxColumn
    Friend WithEvents colDescripcion As DataGridViewTextBoxColumn
    Friend WithEvents colHU As DataGridViewTextBoxColumn
    Friend WithEvents colLinea As DataGridViewTextBoxColumn
    Friend WithEvents colEstado As DataGridViewTextBoxColumn
    Friend WithEvents colAnio As DataGridViewTextBoxColumn
    Friend WithEvents colNumero As DataGridViewTextBoxColumn
    Friend WithEvents colFecha As DataGridViewTextBoxColumn
    Friend WithEvents colFechaD As DataGridViewTextBoxColumn
End Class
