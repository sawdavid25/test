﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class FrmCompras
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.dgSeleccionCompras = New System.Windows.Forms.DataGridView()
        Me.colAnio = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colNumero = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colFecha = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colMes = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colEstado = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.celdaServicio = New System.Windows.Forms.TextBox()
        Me.celdaBienes = New System.Windows.Forms.TextBox()
        Me.TextBox1 = New System.Windows.Forms.TextBox()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.panelTotales = New System.Windows.Forms.Panel()
        Me.celdaTotal = New System.Windows.Forms.TextBox()
        Me.celdaOtros = New System.Windows.Forms.TextBox()
        Me.celdaIMP65892 = New System.Windows.Forms.TextBox()
        Me.celdaServicios2 = New System.Windows.Forms.TextBox()
        Me.celdaBienes2 = New System.Windows.Forms.TextBox()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.TextBox2 = New System.Windows.Forms.TextBox()
        Me.celdaIMP6589 = New System.Windows.Forms.TextBox()
        Me.PanelLista = New System.Windows.Forms.Panel()
        Me.PanelFiltro = New System.Windows.Forms.Panel()
        Me.celdaidNumero = New System.Windows.Forms.TextBox()
        Me.checkFiltro = New System.Windows.Forms.CheckBox()
        Me.celdaAnio = New System.Windows.Forms.TextBox()
        Me.botonTipo = New System.Windows.Forms.Button()
        Me.dtpFechaInicio = New System.Windows.Forms.DateTimePicker()
        Me.celdaidProveedor = New System.Windows.Forms.TextBox()
        Me.dtpFechaFinal = New System.Windows.Forms.DateTimePicker()
        Me.botonRefresh = New System.Windows.Forms.Button()
        Me.botonBuscar = New System.Windows.Forms.Button()
        Me.celdaTipo = New System.Windows.Forms.TextBox()
        Me.celdaNumero = New System.Windows.Forms.TextBox()
        Me.etiquetaTipo = New System.Windows.Forms.Label()
        Me.etiquetaNumero = New System.Windows.Forms.Label()
        Me.botonProveedor = New System.Windows.Forms.Button()
        Me.etiquetaProveedor = New System.Windows.Forms.Label()
        Me.celdaProveedor = New System.Windows.Forms.TextBox()
        Me.dgLibroCompras = New System.Windows.Forms.DataGridView()
        Me.colCheque = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colCorrelativo = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn1 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.col_numero2 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colTipo = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colNit = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colNombreProveedor = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colISC = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colExentas = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colBienes = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colServicios = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colIMP = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colImp65 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colBienes1 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colServicio1 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colIMP2 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colimp6589 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colDirecto = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colMonto = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colCuenta = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colReftipo = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colrefAnio = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colRefNumero = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colImporte = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colCatalogo = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.col_anio = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colDocumento = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colLinea = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.PanelBotones = New System.Windows.Forms.Panel()
        Me.botonAgregar = New System.Windows.Forms.Button()
        Me.BotonDeshabilitar = New System.Windows.Forms.Button()
        Me.PanelDocumento = New System.Windows.Forms.Panel()
        Me.BarraTitulo1 = New KARIMs_SGI.BarraTitulo()
        Me.Encabezado1 = New KARIMs_SGI.encabezado()
        CType(Me.dgSeleccionCompras, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.panelTotales.SuspendLayout()
        Me.PanelLista.SuspendLayout()
        Me.PanelFiltro.SuspendLayout()
        CType(Me.dgLibroCompras, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.PanelBotones.SuspendLayout()
        Me.PanelDocumento.SuspendLayout()
        Me.SuspendLayout()
        '
        'dgSeleccionCompras
        '
        Me.dgSeleccionCompras.AllowUserToAddRows = False
        Me.dgSeleccionCompras.AllowUserToDeleteRows = False
        Me.dgSeleccionCompras.AllowUserToOrderColumns = True
        Me.dgSeleccionCompras.BackgroundColor = System.Drawing.SystemColors.Control
        Me.dgSeleccionCompras.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgSeleccionCompras.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.colAnio, Me.colNumero, Me.colFecha, Me.colMes, Me.colEstado})
        Me.dgSeleccionCompras.Dock = System.Windows.Forms.DockStyle.Fill
        Me.dgSeleccionCompras.Location = New System.Drawing.Point(0, 0)
        Me.dgSeleccionCompras.MultiSelect = False
        Me.dgSeleccionCompras.Name = "dgSeleccionCompras"
        Me.dgSeleccionCompras.ReadOnly = True
        Me.dgSeleccionCompras.RowTemplate.Height = 24
        Me.dgSeleccionCompras.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.dgSeleccionCompras.Size = New System.Drawing.Size(544, 99)
        Me.dgSeleccionCompras.TabIndex = 0
        '
        'colAnio
        '
        Me.colAnio.HeaderText = "Año"
        Me.colAnio.Name = "colAnio"
        Me.colAnio.ReadOnly = True
        '
        'colNumero
        '
        Me.colNumero.HeaderText = "Numero"
        Me.colNumero.Name = "colNumero"
        Me.colNumero.ReadOnly = True
        '
        'colFecha
        '
        Me.colFecha.HeaderText = "Date"
        Me.colFecha.Name = "colFecha"
        Me.colFecha.ReadOnly = True
        '
        'colMes
        '
        Me.colMes.HeaderText = "Month"
        Me.colMes.Name = "colMes"
        Me.colMes.ReadOnly = True
        '
        'colEstado
        '
        Me.colEstado.HeaderText = "State"
        Me.colEstado.Name = "colEstado"
        Me.colEstado.ReadOnly = True
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.ForeColor = System.Drawing.Color.Red
        Me.Label6.Location = New System.Drawing.Point(328, 32)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(76, 17)
        Me.Label6.TabIndex = 2
        Me.Label6.Text = "IMP. 65-89"
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.ForeColor = System.Drawing.Color.Red
        Me.Label7.Location = New System.Drawing.Point(553, 35)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(51, 17)
        Me.Label7.TabIndex = 3
        Me.Label7.Text = "Bienes"
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.ForeColor = System.Drawing.Color.Red
        Me.Label8.Location = New System.Drawing.Point(690, 35)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(65, 17)
        Me.Label8.TabIndex = 4
        Me.Label8.Text = "Servicios"
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.ForeColor = System.Drawing.Color.Red
        Me.Label9.Location = New System.Drawing.Point(855, 35)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(80, 17)
        Me.Label9.TabIndex = 5
        Me.Label9.Text = "IMP. 65-89 "
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.ForeColor = System.Drawing.Color.Red
        Me.Label10.Location = New System.Drawing.Point(1260, 32)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(83, 17)
        Me.Label10.TabIndex = 6
        Me.Label10.Text = "Monto Total"
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.ForeColor = System.Drawing.Color.Red
        Me.Label11.Location = New System.Drawing.Point(1102, 32)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(74, 17)
        Me.Label11.TabIndex = 7
        Me.Label11.Text = "Otros IMP."
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.ForeColor = System.Drawing.Color.Red
        Me.Label2.Location = New System.Drawing.Point(53, 32)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(51, 17)
        Me.Label2.TabIndex = 0
        Me.Label2.Text = "Bienes"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.ForeColor = System.Drawing.Color.Red
        Me.Label5.Location = New System.Drawing.Point(177, 32)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(65, 17)
        Me.Label5.TabIndex = 1
        Me.Label5.Text = "Servicios"
        '
        'celdaServicio
        '
        Me.celdaServicio.Location = New System.Drawing.Point(161, 55)
        Me.celdaServicio.Name = "celdaServicio"
        Me.celdaServicio.ReadOnly = True
        Me.celdaServicio.Size = New System.Drawing.Size(121, 22)
        Me.celdaServicio.TabIndex = 17
        '
        'celdaBienes
        '
        Me.celdaBienes.Location = New System.Drawing.Point(28, 55)
        Me.celdaBienes.Name = "celdaBienes"
        Me.celdaBienes.ReadOnly = True
        Me.celdaBienes.Size = New System.Drawing.Size(119, 22)
        Me.celdaBienes.TabIndex = 18
        '
        'TextBox1
        '
        Me.TextBox1.BackColor = System.Drawing.SystemColors.Control
        Me.TextBox1.Enabled = False
        Me.TextBox1.Location = New System.Drawing.Point(15, 15)
        Me.TextBox1.Multiline = True
        Me.TextBox1.Name = "TextBox1"
        Me.TextBox1.Size = New System.Drawing.Size(452, 68)
        Me.TextBox1.TabIndex = 19
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.Location = New System.Drawing.Point(158, 18)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(127, 17)
        Me.Label12.TabIndex = 16
        Me.Label12.Text = "COMPRAS SIN IVA"
        '
        'panelTotales
        '
        Me.panelTotales.Controls.Add(Me.celdaTotal)
        Me.panelTotales.Controls.Add(Me.celdaOtros)
        Me.panelTotales.Controls.Add(Me.celdaIMP65892)
        Me.panelTotales.Controls.Add(Me.Label9)
        Me.panelTotales.Controls.Add(Me.celdaServicios2)
        Me.panelTotales.Controls.Add(Me.celdaBienes2)
        Me.panelTotales.Controls.Add(Me.Label8)
        Me.panelTotales.Controls.Add(Me.Label7)
        Me.panelTotales.Controls.Add(Me.Label13)
        Me.panelTotales.Controls.Add(Me.TextBox2)
        Me.panelTotales.Controls.Add(Me.celdaIMP6589)
        Me.panelTotales.Controls.Add(Me.Label6)
        Me.panelTotales.Controls.Add(Me.celdaBienes)
        Me.panelTotales.Controls.Add(Me.Label2)
        Me.panelTotales.Controls.Add(Me.celdaServicio)
        Me.panelTotales.Controls.Add(Me.Label5)
        Me.panelTotales.Controls.Add(Me.Label12)
        Me.panelTotales.Controls.Add(Me.TextBox1)
        Me.panelTotales.Controls.Add(Me.Label11)
        Me.panelTotales.Controls.Add(Me.Label10)
        Me.panelTotales.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.panelTotales.Location = New System.Drawing.Point(0, 378)
        Me.panelTotales.Name = "panelTotales"
        Me.panelTotales.Size = New System.Drawing.Size(1432, 95)
        Me.panelTotales.TabIndex = 20
        '
        'celdaTotal
        '
        Me.celdaTotal.Location = New System.Drawing.Point(1241, 52)
        Me.celdaTotal.Name = "celdaTotal"
        Me.celdaTotal.ReadOnly = True
        Me.celdaTotal.Size = New System.Drawing.Size(121, 22)
        Me.celdaTotal.TabIndex = 27
        '
        'celdaOtros
        '
        Me.celdaOtros.Location = New System.Drawing.Point(1078, 52)
        Me.celdaOtros.Name = "celdaOtros"
        Me.celdaOtros.ReadOnly = True
        Me.celdaOtros.Size = New System.Drawing.Size(121, 22)
        Me.celdaOtros.TabIndex = 26
        '
        'celdaIMP65892
        '
        Me.celdaIMP65892.Location = New System.Drawing.Point(834, 55)
        Me.celdaIMP65892.Name = "celdaIMP65892"
        Me.celdaIMP65892.ReadOnly = True
        Me.celdaIMP65892.Size = New System.Drawing.Size(121, 22)
        Me.celdaIMP65892.TabIndex = 25
        '
        'celdaServicios2
        '
        Me.celdaServicios2.Location = New System.Drawing.Point(677, 55)
        Me.celdaServicios2.Name = "celdaServicios2"
        Me.celdaServicios2.ReadOnly = True
        Me.celdaServicios2.Size = New System.Drawing.Size(121, 22)
        Me.celdaServicios2.TabIndex = 24
        '
        'celdaBienes2
        '
        Me.celdaBienes2.Location = New System.Drawing.Point(525, 55)
        Me.celdaBienes2.Name = "celdaBienes2"
        Me.celdaBienes2.ReadOnly = True
        Me.celdaBienes2.Size = New System.Drawing.Size(121, 22)
        Me.celdaBienes2.TabIndex = 23
        '
        'Label13
        '
        Me.Label13.AutoSize = True
        Me.Label13.Location = New System.Drawing.Point(674, 18)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(144, 17)
        Me.Label13.TabIndex = 22
        Me.Label13.Text = "IVA CREDITO FISCAL"
        '
        'TextBox2
        '
        Me.TextBox2.BackColor = System.Drawing.SystemColors.Control
        Me.TextBox2.Location = New System.Drawing.Point(514, 15)
        Me.TextBox2.Multiline = True
        Me.TextBox2.Name = "TextBox2"
        Me.TextBox2.Size = New System.Drawing.Size(469, 68)
        Me.TextBox2.TabIndex = 21
        '
        'celdaIMP6589
        '
        Me.celdaIMP6589.Location = New System.Drawing.Point(319, 55)
        Me.celdaIMP6589.Name = "celdaIMP6589"
        Me.celdaIMP6589.ReadOnly = True
        Me.celdaIMP6589.Size = New System.Drawing.Size(119, 22)
        Me.celdaIMP6589.TabIndex = 20
        '
        'PanelLista
        '
        Me.PanelLista.Controls.Add(Me.dgSeleccionCompras)
        Me.PanelLista.Location = New System.Drawing.Point(880, 224)
        Me.PanelLista.Name = "PanelLista"
        Me.PanelLista.Size = New System.Drawing.Size(544, 99)
        Me.PanelLista.TabIndex = 31
        '
        'PanelFiltro
        '
        Me.PanelFiltro.Controls.Add(Me.celdaidNumero)
        Me.PanelFiltro.Controls.Add(Me.checkFiltro)
        Me.PanelFiltro.Controls.Add(Me.celdaAnio)
        Me.PanelFiltro.Controls.Add(Me.botonTipo)
        Me.PanelFiltro.Controls.Add(Me.dtpFechaInicio)
        Me.PanelFiltro.Controls.Add(Me.celdaidProveedor)
        Me.PanelFiltro.Controls.Add(Me.dtpFechaFinal)
        Me.PanelFiltro.Controls.Add(Me.botonRefresh)
        Me.PanelFiltro.Controls.Add(Me.botonBuscar)
        Me.PanelFiltro.Controls.Add(Me.celdaTipo)
        Me.PanelFiltro.Controls.Add(Me.celdaNumero)
        Me.PanelFiltro.Controls.Add(Me.etiquetaTipo)
        Me.PanelFiltro.Controls.Add(Me.etiquetaNumero)
        Me.PanelFiltro.Controls.Add(Me.botonProveedor)
        Me.PanelFiltro.Controls.Add(Me.etiquetaProveedor)
        Me.PanelFiltro.Controls.Add(Me.celdaProveedor)
        Me.PanelFiltro.Dock = System.Windows.Forms.DockStyle.Top
        Me.PanelFiltro.Location = New System.Drawing.Point(0, 126)
        Me.PanelFiltro.Name = "PanelFiltro"
        Me.PanelFiltro.Size = New System.Drawing.Size(1432, 71)
        Me.PanelFiltro.TabIndex = 23
        '
        'celdaidNumero
        '
        Me.celdaidNumero.Location = New System.Drawing.Point(786, 37)
        Me.celdaidNumero.Name = "celdaidNumero"
        Me.celdaidNumero.Size = New System.Drawing.Size(42, 22)
        Me.celdaidNumero.TabIndex = 40
        Me.celdaidNumero.Text = "-1"
        Me.celdaidNumero.Visible = False
        '
        'checkFiltro
        '
        Me.checkFiltro.AutoSize = True
        Me.checkFiltro.Location = New System.Drawing.Point(12, 7)
        Me.checkFiltro.Name = "checkFiltro"
        Me.checkFiltro.Size = New System.Drawing.Size(106, 21)
        Me.checkFiltro.TabIndex = 26
        Me.checkFiltro.Text = "Date Range"
        Me.checkFiltro.UseVisualStyleBackColor = True
        '
        'celdaAnio
        '
        Me.celdaAnio.Location = New System.Drawing.Point(761, 36)
        Me.celdaAnio.Name = "celdaAnio"
        Me.celdaAnio.Size = New System.Drawing.Size(19, 22)
        Me.celdaAnio.TabIndex = 39
        Me.celdaAnio.Text = "-1"
        Me.celdaAnio.Visible = False
        '
        'botonTipo
        '
        Me.botonTipo.Location = New System.Drawing.Point(677, 37)
        Me.botonTipo.Name = "botonTipo"
        Me.botonTipo.Size = New System.Drawing.Size(39, 23)
        Me.botonTipo.TabIndex = 37
        Me.botonTipo.Text = "..."
        Me.botonTipo.UseVisualStyleBackColor = True
        '
        'dtpFechaInicio
        '
        Me.dtpFechaInicio.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.dtpFechaInicio.Location = New System.Drawing.Point(124, 7)
        Me.dtpFechaInicio.Name = "dtpFechaInicio"
        Me.dtpFechaInicio.Size = New System.Drawing.Size(192, 22)
        Me.dtpFechaInicio.TabIndex = 24
        '
        'celdaidProveedor
        '
        Me.celdaidProveedor.Location = New System.Drawing.Point(736, 36)
        Me.celdaidProveedor.Name = "celdaidProveedor"
        Me.celdaidProveedor.Size = New System.Drawing.Size(19, 22)
        Me.celdaidProveedor.TabIndex = 38
        Me.celdaidProveedor.Text = "-1"
        Me.celdaidProveedor.Visible = False
        '
        'dtpFechaFinal
        '
        Me.dtpFechaFinal.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.dtpFechaFinal.Location = New System.Drawing.Point(331, 7)
        Me.dtpFechaFinal.Name = "dtpFechaFinal"
        Me.dtpFechaFinal.Size = New System.Drawing.Size(184, 22)
        Me.dtpFechaFinal.TabIndex = 25
        '
        'botonRefresh
        '
        Me.botonRefresh.Image = Global.KARIMs_SGI.My.Resources.Resources.replace2
        Me.botonRefresh.ImageAlign = System.Drawing.ContentAlignment.TopCenter
        Me.botonRefresh.Location = New System.Drawing.Point(963, 16)
        Me.botonRefresh.Name = "botonRefresh"
        Me.botonRefresh.Size = New System.Drawing.Size(83, 46)
        Me.botonRefresh.TabIndex = 36
        Me.botonRefresh.Text = "Show All"
        Me.botonRefresh.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.botonRefresh.UseVisualStyleBackColor = True
        '
        'botonBuscar
        '
        Me.botonBuscar.Image = Global.KARIMs_SGI.My.Resources.Resources.search1
        Me.botonBuscar.ImageAlign = System.Drawing.ContentAlignment.TopCenter
        Me.botonBuscar.Location = New System.Drawing.Point(834, 24)
        Me.botonBuscar.Name = "botonBuscar"
        Me.botonBuscar.Size = New System.Drawing.Size(83, 38)
        Me.botonBuscar.TabIndex = 27
        Me.botonBuscar.Text = "Search"
        Me.botonBuscar.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.botonBuscar.UseVisualStyleBackColor = True
        '
        'celdaTipo
        '
        Me.celdaTipo.Location = New System.Drawing.Point(435, 37)
        Me.celdaTipo.Name = "celdaTipo"
        Me.celdaTipo.ReadOnly = True
        Me.celdaTipo.Size = New System.Drawing.Size(235, 22)
        Me.celdaTipo.TabIndex = 35
        '
        'celdaNumero
        '
        Me.celdaNumero.Location = New System.Drawing.Point(612, 6)
        Me.celdaNumero.Name = "celdaNumero"
        Me.celdaNumero.Size = New System.Drawing.Size(168, 22)
        Me.celdaNumero.TabIndex = 28
        '
        'etiquetaTipo
        '
        Me.etiquetaTipo.AutoSize = True
        Me.etiquetaTipo.Location = New System.Drawing.Point(389, 42)
        Me.etiquetaTipo.Name = "etiquetaTipo"
        Me.etiquetaTipo.Size = New System.Drawing.Size(40, 17)
        Me.etiquetaTipo.TabIndex = 34
        Me.etiquetaTipo.Text = "Type"
        '
        'etiquetaNumero
        '
        Me.etiquetaNumero.AutoSize = True
        Me.etiquetaNumero.Location = New System.Drawing.Point(537, 7)
        Me.etiquetaNumero.Name = "etiquetaNumero"
        Me.etiquetaNumero.Size = New System.Drawing.Size(58, 17)
        Me.etiquetaNumero.TabIndex = 29
        Me.etiquetaNumero.Text = "Number"
        '
        'botonProveedor
        '
        Me.botonProveedor.Location = New System.Drawing.Point(331, 36)
        Me.botonProveedor.Name = "botonProveedor"
        Me.botonProveedor.Size = New System.Drawing.Size(39, 23)
        Me.botonProveedor.TabIndex = 33
        Me.botonProveedor.Text = "..."
        Me.botonProveedor.UseVisualStyleBackColor = True
        '
        'etiquetaProveedor
        '
        Me.etiquetaProveedor.AutoSize = True
        Me.etiquetaProveedor.Location = New System.Drawing.Point(12, 36)
        Me.etiquetaProveedor.Name = "etiquetaProveedor"
        Me.etiquetaProveedor.Size = New System.Drawing.Size(61, 17)
        Me.etiquetaProveedor.TabIndex = 31
        Me.etiquetaProveedor.Text = "Provider"
        '
        'celdaProveedor
        '
        Me.celdaProveedor.Location = New System.Drawing.Point(81, 36)
        Me.celdaProveedor.Name = "celdaProveedor"
        Me.celdaProveedor.ReadOnly = True
        Me.celdaProveedor.Size = New System.Drawing.Size(235, 22)
        Me.celdaProveedor.TabIndex = 32
        '
        'dgLibroCompras
        '
        Me.dgLibroCompras.AllowUserToAddRows = False
        Me.dgLibroCompras.AllowUserToDeleteRows = False
        Me.dgLibroCompras.AllowUserToOrderColumns = True
        Me.dgLibroCompras.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells
        Me.dgLibroCompras.BackgroundColor = System.Drawing.SystemColors.Control
        Me.dgLibroCompras.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgLibroCompras.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.colCheque, Me.colCorrelativo, Me.DataGridViewTextBoxColumn1, Me.col_numero2, Me.colTipo, Me.colNit, Me.colNombreProveedor, Me.colISC, Me.colExentas, Me.colBienes, Me.colServicios, Me.colIMP, Me.colImp65, Me.colBienes1, Me.colServicio1, Me.colIMP2, Me.colimp6589, Me.colDirecto, Me.colMonto, Me.colCuenta, Me.colReftipo, Me.colrefAnio, Me.colRefNumero, Me.colImporte, Me.colCatalogo, Me.col_anio, Me.colDocumento, Me.colLinea})
        Me.dgLibroCompras.Dock = System.Windows.Forms.DockStyle.Fill
        Me.dgLibroCompras.Location = New System.Drawing.Point(0, 0)
        Me.dgLibroCompras.MultiSelect = False
        Me.dgLibroCompras.Name = "dgLibroCompras"
        Me.dgLibroCompras.RowTemplate.Height = 24
        Me.dgLibroCompras.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.dgLibroCompras.Size = New System.Drawing.Size(695, 115)
        Me.dgLibroCompras.TabIndex = 1
        '
        'colCheque
        '
        Me.colCheque.HeaderText = "Cheque"
        Me.colCheque.Name = "colCheque"
        Me.colCheque.Visible = False
        Me.colCheque.Width = 86
        '
        'colCorrelativo
        '
        Me.colCorrelativo.HeaderText = "Correlativo"
        Me.colCorrelativo.Name = "colCorrelativo"
        Me.colCorrelativo.Visible = False
        Me.colCorrelativo.Width = 105
        '
        'DataGridViewTextBoxColumn1
        '
        Me.DataGridViewTextBoxColumn1.HeaderText = "Fecha"
        Me.DataGridViewTextBoxColumn1.Name = "DataGridViewTextBoxColumn1"
        Me.DataGridViewTextBoxColumn1.ReadOnly = True
        Me.DataGridViewTextBoxColumn1.Width = 76
        '
        'col_numero2
        '
        Me.col_numero2.HeaderText = "Numero"
        Me.col_numero2.Name = "col_numero2"
        Me.col_numero2.ReadOnly = True
        Me.col_numero2.Width = 87
        '
        'colTipo
        '
        Me.colTipo.HeaderText = "Tipo"
        Me.colTipo.Name = "colTipo"
        Me.colTipo.ReadOnly = True
        Me.colTipo.Width = 65
        '
        'colNit
        '
        Me.colNit.HeaderText = "Nit"
        Me.colNit.Name = "colNit"
        Me.colNit.ReadOnly = True
        Me.colNit.Width = 54
        '
        'colNombreProveedor
        '
        Me.colNombreProveedor.HeaderText = "Nombre Proveedor"
        Me.colNombreProveedor.Name = "colNombreProveedor"
        Me.colNombreProveedor.ReadOnly = True
        Me.colNombreProveedor.Width = 144
        '
        'colISC
        '
        Me.colISC.HeaderText = "ISC"
        Me.colISC.Name = "colISC"
        Me.colISC.Width = 58
        '
        'colExentas
        '
        Me.colExentas.HeaderText = "Exentas_Base"
        Me.colExentas.Name = "colExentas"
        Me.colExentas.Width = 127
        '
        'colBienes
        '
        Me.colBienes.HeaderText = "Bienes_Base"
        Me.colBienes.Name = "colBienes"
        Me.colBienes.Width = 120
        '
        'colServicios
        '
        Me.colServicios.HeaderText = "Servicios_Base"
        Me.colServicios.Name = "colServicios"
        Me.colServicios.Width = 134
        '
        'colIMP
        '
        Me.colIMP.HeaderText = "IMP_Base"
        Me.colIMP.Name = "colIMP"
        Me.colIMP.ReadOnly = True
        '
        'colImp65
        '
        Me.colImp65.HeaderText = "IMP 65-89_Base"
        Me.colImp65.Name = "colImp65"
        Me.colImp65.Width = 129
        '
        'colBienes1
        '
        Me.colBienes1.HeaderText = "Bienes_Impuesto"
        Me.colBienes1.Name = "colBienes1"
        Me.colBienes1.Width = 145
        '
        'colServicio1
        '
        Me.colServicio1.HeaderText = "Servicios_Impuesto"
        Me.colServicio1.Name = "colServicio1"
        Me.colServicio1.Width = 159
        '
        'colIMP2
        '
        Me.colIMP2.HeaderText = "IMP._Impuesto"
        Me.colIMP2.Name = "colIMP2"
        Me.colIMP2.ReadOnly = True
        Me.colIMP2.Width = 129
        '
        'colimp6589
        '
        Me.colimp6589.HeaderText = "IMP. 65-89_Impuesto"
        Me.colimp6589.Name = "colimp6589"
        Me.colimp6589.Width = 155
        '
        'colDirecto
        '
        Me.colDirecto.HeaderText = "OTROS IMP."
        Me.colDirecto.Name = "colDirecto"
        Me.colDirecto.Width = 109
        '
        'colMonto
        '
        Me.colMonto.HeaderText = "Monto Total"
        Me.colMonto.Name = "colMonto"
        Me.colMonto.ReadOnly = True
        Me.colMonto.Width = 103
        '
        'colCuenta
        '
        Me.colCuenta.HeaderText = "Cuenta"
        Me.colCuenta.Name = "colCuenta"
        Me.colCuenta.Visible = False
        Me.colCuenta.Width = 82
        '
        'colReftipo
        '
        Me.colReftipo.HeaderText = "refTipo"
        Me.colReftipo.Name = "colReftipo"
        Me.colReftipo.ReadOnly = True
        Me.colReftipo.Visible = False
        Me.colReftipo.Width = 82
        '
        'colrefAnio
        '
        Me.colrefAnio.HeaderText = "RefAnio"
        Me.colrefAnio.Name = "colrefAnio"
        Me.colrefAnio.ReadOnly = True
        Me.colrefAnio.Visible = False
        Me.colrefAnio.Width = 87
        '
        'colRefNumero
        '
        Me.colRefNumero.HeaderText = "RefNumero"
        Me.colRefNumero.Name = "colRefNumero"
        Me.colRefNumero.ReadOnly = True
        Me.colRefNumero.Visible = False
        Me.colRefNumero.Width = 109
        '
        'colImporte
        '
        Me.colImporte.HeaderText = "Importe Q."
        Me.colImporte.Name = "colImporte"
        Me.colImporte.ReadOnly = True
        Me.colImporte.Width = 95
        '
        'colCatalogo
        '
        Me.colCatalogo.HeaderText = "Catalogo"
        Me.colCatalogo.Name = "colCatalogo"
        Me.colCatalogo.Visible = False
        Me.colCatalogo.Width = 93
        '
        'col_anio
        '
        Me.col_anio.HeaderText = "Año"
        Me.col_anio.Name = "col_anio"
        Me.col_anio.Visible = False
        Me.col_anio.Width = 62
        '
        'colDocumento
        '
        Me.colDocumento.HeaderText = "Numero"
        Me.colDocumento.Name = "colDocumento"
        Me.colDocumento.Visible = False
        Me.colDocumento.Width = 87
        '
        'colLinea
        '
        Me.colLinea.HeaderText = "Linea"
        Me.colLinea.Name = "colLinea"
        Me.colLinea.Visible = False
        Me.colLinea.Width = 72
        '
        'PanelBotones
        '
        Me.PanelBotones.Controls.Add(Me.botonAgregar)
        Me.PanelBotones.Controls.Add(Me.BotonDeshabilitar)
        Me.PanelBotones.Dock = System.Windows.Forms.DockStyle.Right
        Me.PanelBotones.Location = New System.Drawing.Point(695, 0)
        Me.PanelBotones.Name = "PanelBotones"
        Me.PanelBotones.Size = New System.Drawing.Size(76, 115)
        Me.PanelBotones.TabIndex = 0
        '
        'botonAgregar
        '
        Me.botonAgregar.Image = Global.KARIMs_SGI.My.Resources.Resources.edit
        Me.botonAgregar.Location = New System.Drawing.Point(20, 71)
        Me.botonAgregar.Name = "botonAgregar"
        Me.botonAgregar.Size = New System.Drawing.Size(53, 29)
        Me.botonAgregar.TabIndex = 1
        Me.botonAgregar.UseVisualStyleBackColor = True
        '
        'BotonDeshabilitar
        '
        Me.BotonDeshabilitar.Image = Global.KARIMs_SGI.My.Resources.Resources.delete3
        Me.BotonDeshabilitar.Location = New System.Drawing.Point(20, 26)
        Me.BotonDeshabilitar.Name = "BotonDeshabilitar"
        Me.BotonDeshabilitar.Size = New System.Drawing.Size(53, 29)
        Me.BotonDeshabilitar.TabIndex = 0
        Me.BotonDeshabilitar.UseVisualStyleBackColor = True
        '
        'PanelDocumento
        '
        Me.PanelDocumento.Controls.Add(Me.dgLibroCompras)
        Me.PanelDocumento.Controls.Add(Me.PanelBotones)
        Me.PanelDocumento.Location = New System.Drawing.Point(81, 236)
        Me.PanelDocumento.Name = "PanelDocumento"
        Me.PanelDocumento.Size = New System.Drawing.Size(771, 115)
        Me.PanelDocumento.TabIndex = 24
        '
        'BarraTitulo1
        '
        Me.BarraTitulo1.BackColor = System.Drawing.Color.WhiteSmoke
        Me.BarraTitulo1.Dock = System.Windows.Forms.DockStyle.Top
        Me.BarraTitulo1.Location = New System.Drawing.Point(0, 89)
        Me.BarraTitulo1.Margin = New System.Windows.Forms.Padding(4)
        Me.BarraTitulo1.Name = "BarraTitulo1"
        Me.BarraTitulo1.Size = New System.Drawing.Size(1432, 37)
        Me.BarraTitulo1.TabIndex = 22
        '
        'Encabezado1
        '
        Me.Encabezado1.Dock = System.Windows.Forms.DockStyle.Top
        Me.Encabezado1.Location = New System.Drawing.Point(0, 0)
        Me.Encabezado1.Margin = New System.Windows.Forms.Padding(4)
        Me.Encabezado1.Name = "Encabezado1"
        Me.Encabezado1.Size = New System.Drawing.Size(1432, 89)
        Me.Encabezado1.TabIndex = 21
        '
        'FrmCompras
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1432, 473)
        Me.Controls.Add(Me.PanelLista)
        Me.Controls.Add(Me.PanelDocumento)
        Me.Controls.Add(Me.PanelFiltro)
        Me.Controls.Add(Me.BarraTitulo1)
        Me.Controls.Add(Me.Encabezado1)
        Me.Controls.Add(Me.panelTotales)
        Me.Name = "FrmCompras"
        Me.Text = "FrmCompras"
        CType(Me.dgSeleccionCompras, System.ComponentModel.ISupportInitialize).EndInit()
        Me.panelTotales.ResumeLayout(False)
        Me.panelTotales.PerformLayout()
        Me.PanelLista.ResumeLayout(False)
        Me.PanelFiltro.ResumeLayout(False)
        Me.PanelFiltro.PerformLayout()
        CType(Me.dgLibroCompras, System.ComponentModel.ISupportInitialize).EndInit()
        Me.PanelBotones.ResumeLayout(False)
        Me.PanelDocumento.ResumeLayout(False)
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents dgSeleccionCompras As DataGridView
    Friend WithEvents colAnio As DataGridViewTextBoxColumn
    Friend WithEvents colNumero As DataGridViewTextBoxColumn
    Friend WithEvents colFecha As DataGridViewTextBoxColumn
    Friend WithEvents colMes As DataGridViewTextBoxColumn
    Friend WithEvents colEstado As DataGridViewTextBoxColumn
    Friend WithEvents Label6 As Label
    Friend WithEvents Label7 As Label
    Friend WithEvents Label8 As Label
    Friend WithEvents Label9 As Label
    Friend WithEvents Label10 As Label
    Friend WithEvents Label11 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents Label5 As Label
    Friend WithEvents celdaServicio As TextBox
    Friend WithEvents celdaBienes As TextBox
    Friend WithEvents TextBox1 As TextBox
    Friend WithEvents Label12 As Label
    Friend WithEvents panelTotales As Panel
    Friend WithEvents celdaTotal As TextBox
    Friend WithEvents celdaOtros As TextBox
    Friend WithEvents celdaIMP65892 As TextBox
    Friend WithEvents celdaServicios2 As TextBox
    Friend WithEvents celdaBienes2 As TextBox
    Friend WithEvents Label13 As Label
    Friend WithEvents TextBox2 As TextBox
    Friend WithEvents celdaIMP6589 As TextBox
    Friend WithEvents BarraTitulo1 As BarraTitulo
    Friend WithEvents Encabezado1 As encabezado
    Friend WithEvents PanelFiltro As Panel
    Friend WithEvents celdaidNumero As TextBox
    Friend WithEvents checkFiltro As System.Windows.Forms.CheckBox
    Friend WithEvents celdaAnio As TextBox
    Friend WithEvents botonTipo As Button
    Friend WithEvents dtpFechaInicio As DateTimePicker
    Friend WithEvents celdaidProveedor As TextBox
    Friend WithEvents dtpFechaFinal As DateTimePicker
    Friend WithEvents botonRefresh As Button
    Friend WithEvents botonBuscar As Button
    Friend WithEvents celdaTipo As TextBox
    Friend WithEvents celdaNumero As TextBox
    Friend WithEvents etiquetaTipo As Label
    Friend WithEvents etiquetaNumero As Label
    Friend WithEvents botonProveedor As Button
    Friend WithEvents etiquetaProveedor As Label
    Friend WithEvents celdaProveedor As TextBox
    Friend WithEvents dgLibroCompras As DataGridView
    Friend WithEvents PanelBotones As Panel
    Friend WithEvents BotonDeshabilitar As Button
    Friend WithEvents PanelLista As Panel
    Friend WithEvents PanelDocumento As Panel
    Friend WithEvents colCheque As DataGridViewTextBoxColumn
    Friend WithEvents colCorrelativo As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn1 As DataGridViewTextBoxColumn
    Friend WithEvents col_numero2 As DataGridViewTextBoxColumn
    Friend WithEvents colTipo As DataGridViewTextBoxColumn
    Friend WithEvents colNit As DataGridViewTextBoxColumn
    Friend WithEvents colNombreProveedor As DataGridViewTextBoxColumn
    Friend WithEvents colISC As DataGridViewTextBoxColumn
    Friend WithEvents colExentas As DataGridViewTextBoxColumn
    Friend WithEvents colBienes As DataGridViewTextBoxColumn
    Friend WithEvents colServicios As DataGridViewTextBoxColumn
    Friend WithEvents colIMP As DataGridViewTextBoxColumn
    Friend WithEvents colImp65 As DataGridViewTextBoxColumn
    Friend WithEvents colBienes1 As DataGridViewTextBoxColumn
    Friend WithEvents colServicio1 As DataGridViewTextBoxColumn
    Friend WithEvents colIMP2 As DataGridViewTextBoxColumn
    Friend WithEvents colimp6589 As DataGridViewTextBoxColumn
    Friend WithEvents colDirecto As DataGridViewTextBoxColumn
    Friend WithEvents colMonto As DataGridViewTextBoxColumn
    Friend WithEvents colCuenta As DataGridViewTextBoxColumn
    Friend WithEvents colReftipo As DataGridViewTextBoxColumn
    Friend WithEvents colrefAnio As DataGridViewTextBoxColumn
    Friend WithEvents colRefNumero As DataGridViewTextBoxColumn
    Friend WithEvents colImporte As DataGridViewTextBoxColumn
    Friend WithEvents colCatalogo As DataGridViewTextBoxColumn
    Friend WithEvents col_anio As DataGridViewTextBoxColumn
    Friend WithEvents colDocumento As DataGridViewTextBoxColumn
    Friend WithEvents colLinea As DataGridViewTextBoxColumn
    Friend WithEvents botonAgregar As Button
End Class
