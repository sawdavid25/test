﻿Public Class frmFacturacionCredFiscal

#Region "Miembros"
    Dim strKey As String = STR_VACIO
    Dim logInsertar As Boolean = False
    Dim logConsultar As Boolean = False
    Dim logEditar As Boolean = False
    Dim LogBorrar As Boolean = False
    Const CAT_ORD As Integer = 777
    Dim intCurDoc As Integer
    Dim cfun As New clsFunciones
    Dim Poliza As String = STR_VACIO

    Private strOrigen As String

    Private dblDocCantidad As Double
    Private dblDocTotal As Double

    Public Const INT_UNO As Integer = 1

    Private logImpuesto As Boolean
    Private logLibre As Boolean
    Private logAdded As Boolean
    Private logPrinted As Boolean
    Private logPrinting As Boolean


    Private intRefID As Integer
    Private intRefDias As Integer

    'Constantes
    Public Const TBL_DOCUMENTOS As String = "clsDcmtos_DTL"
    Private Const CXC_NAME As String = "Factura"
    Private Const STR_TABLA As String = "Clientes"

#End Region

#Region "Propiedades"
    Public Property Key As String
        Get
            Return strKey
        End Get
        Set(value As String)
            strKey = value
        End Set
    End Property
#End Region

#Region "Procedimientos"

    Private Sub Accessos()
        Dim cAccesos As New clsAccesos
        Try
            If cAccesos.Accesos(strKey) = True Then
                logInsertar = cAccesos.Insertar
                logConsultar = cAccesos.Consultar
                logEditar = cAccesos.Editar
                LogBorrar = cAccesos.Borrar
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub BloquearBotones(Optional ByVal logBloquear As Boolean = True)
        If logBloquear = True Then
            Encabezado1.botonBorrar.Enabled = False
            Encabezado1.botonGuardar.Enabled = False
            botonImprimir.Enabled = False
        Else
            Encabezado1.botonBorrar.Enabled = True
            Encabezado1.botonGuardar.Enabled = True
            botonImprimir.Enabled = True
        End If
    End Sub

    'Query que carga Lista Principal
    Private Function SQLlista() As String

        Dim strsql As String = STR_VACIO

        strsql = "SELECT HDoc_Doc_Ano Year, HDoc_Doc_Num Numero, HDoc_Doc_Fec Fecha, HDoc_Emp_Nom Cliente, HDoc_DR1_Num Referencia, IFNULL(HDoc_DR2_Cat,0) Impreso, HDoc_Doc_Status, HDoc_Doc_Ano, IF(ISNULL(HDoc_DR1_Fec),0,1) Salida, IFNULL(HDoc_DR2_Emp,0) Impuesto, IF(ISNULL(HDoc_DR2_Fec),1,0) bloqueado, IFNULL(HDoc_RF2_Cod,0) Cargado, IFNULL(HDoc_RF1_Cod,0) Poliza, HDoc_Emp_Cod Code, HDoc_Emp_Dir Direction, HDoc_Emp_NIT NIT, HDoc_Emp_Tel Phone,HDoc_Doc_Mon, HDoc_Doc_TC, cat_clave, HDoc_RF1_Dbl, HDoc_RF2_Dbl"
        strsql &= " FROM Dcmtos_HDR"
        strsql &= "   LEFT JOIN Catalogos c ON cat_num = HDoc_Doc_Mon"
        strsql &= "  WHERE HDoc_Sis_Emp={empresa} AND HDoc_Doc_Cat=36"

        If checkFecha.Checked = True Then

            strsql &= " AND (HDoc_Doc_Fec BETWEEN '{fechainicio}' AND '{fechafin}') "

            strsql = Replace(strsql, "{fechainicio}", dtpInicio.Value.ToString(FORMATO_MYSQL))
            strsql = Replace(strsql, "{fechafin}", dtpFinal.Value.ToString(FORMATO_MYSQL))

        End If
        strsql &= "ORDER BY HDoc_Doc_Ano DESC, HDoc_Doc_Num DESC "
        strsql = Replace(strsql, "{empresa}", Sesion.IdEmpresa)


        Return strsql

    End Function

    'Query que carga Subdocumentos
    Private Function SqlListaSudDocumentos(ByVal intaño As Integer, ByVal intnumero As Integer) As String

        Dim strsql As String = STR_VACIO

        strsql = "SELECT cat_clave, cat_desc, IF(("
        strsql &= "  SELECT COUNT(*) "
        strsql &= "    FROM Dcmtos_ACC"
        strsql &= "       WHERE ADoc_Sis_Emp = {empresa} AND ADoc_Doc_Cat = 36 AND ADoc_Doc_Ano = {año} AND ADoc_Doc_Num ={numero} AND ADoc_Doc_Sub = cat_clave) >0,'SI','NO') Cantidad"
        strsql &= "     FROM Catalogos"
        strsql &= "   WHERE cat_clase = 'SubDcmtos' AND cat_sist = 'Doc_CFactura' AND (cat_sisemp IN (0,12))"
        strsql &= " ORDER BY cat_clave"

        strsql = Replace(strsql, "{empresa}", Sesion.IdEmpresa)
        strsql = Replace(strsql, "{año}", intaño)
        strsql = Replace(strsql, "{numero}", intnumero)

        Return strsql
    End Function

    'Query que Carga las Instrucciones De Despacho
    Private Function SqlInstDespacho(ByVal intaño As Integer, ByVal intnumero As Integer) As String

        Dim strsql As String = STR_VACIO

        strsql = "SELECT DISTINCT HDoc_Doc_Cat, HDoc_Doc_Ano, HDoc_Doc_Num, HDoc_Doc_Fec,HDoc_Usuario, HDoc_DR1_Num"
        strsql &= " FROM Dcmtos_DTL_Pro a"
        strsql &= "    INNER JOIN Dcmtos_HDR b ON a.PDoc_Sis_Emp = b.HDoc_Sis_Emp AND a.PDoc_Par_Cat = b.HDoc_Doc_Cat AND a.PDoc_Par_Ano = b.HDoc_Doc_Ano AND a.PDoc_Par_Num = b.HDoc_Doc_Num"
        strsql &= " WHERE a.PDoc_Sis_Emp = {empresa} AND a.PDoc_Chi_Ano = {año} AND a.PDoc_Chi_Num = {numero} AND a.PDoc_Par_Cat = 48"

        strsql = Replace(strsql, "{empresa}", Sesion.IdEmpresa)
        strsql = Replace(strsql, "{año}", intaño)
        strsql = Replace(strsql, "{numero}", intnumero)

        Return strsql
    End Function

    Private Function sqlDetalle(ByVal intaño As Integer, ByVal intnumero As Integer) As String

        Dim strsql As String = STR_VACIO

        strsql = "SELECT p.PDoc_Par_Ano Ano, p.PDoc_Par_Num Numero, p.PDoc_Par_Lin Linea, p.PDoc_Chi_Lin Lin2, 0 Id, d.DDoc_Prd_Cod Codigo, d.DDoc_Prd_Des Descripcion, d.DDoc_RF1_Cod Original, d.DDoc_Prd_PNr Parte, d.DDoc_Prd_PUQ Unitario, d.DDoc_Prd_NET Precio,m.cat_num NuMedida, m.cat_clave Medida, IFNULL(d.DDoc_RF3_Num,d.DDoc_Prd_UM) Base, IF(d.DDoc_RF3_Dbl=0,d.DDoc_Prd_QTY,d.DDoc_RF3_Dbl) Despacho, (IF(d.DDoc_RF3_Dbl=0,d.DDoc_Prd_QTY,d.DDoc_RF3_Dbl) * d.DDoc_Prd_NET) Total, IFNULL(d.DDoc_RF2_Cod,0) Distribucion, COALESCE(l.cli_cliente) Lugar, d.DDoc_RF1_Num Destino, d.DDoc_RF1_Txt Referencia, d.DDoc_RF2_Txt Bulto, IFNULL(d.DDoc_RF2_Num,0) Bobinas, d.DDoc_RF1_Dbl Libras, d.DDoc_RF2_Dbl Kilos, d.DDoc_Prd_UM Unidad, d.DDoc_Prd_QTY Cantidad, b.BDoc_Box_QTY cantidadBulto"
        strsql &= "  FROM Dcmtos_DTL d"
        strsql &= "    LEFT JOIN Dcmtos_DTL_Pro p ON p.PDoc_Sis_Emp = d.DDoc_Sis_Emp AND p.PDoc_Chi_Cat = d.DDoc_Doc_Cat AND p.PDoc_Chi_Ano = d.DDoc_Doc_Ano AND p.PDoc_Chi_Num = d.DDoc_Doc_Num AND p.PDoc_Chi_Lin = d.DDoc_Doc_Lin"
        strsql &= "      LEFT JOIN Catalogos m ON m.cat_clase = 'Medidas' AND m.cat_num = COALESCE(d.DDoc_RF3_Num,d.DDoc_Prd_UM)"
        strsql &= "        LEFT JOIN Clientes l ON l.cli_sisemp = d.DDoc_Sis_Emp AND l.cli_codigo = d.DDoc_RF1_Num"
        strsql &= "              LEFT JOIN Dcmtos_DTL_Box b ON b.BDoc_Sis_Emp = d.DDoc_Sis_Emp AND b.BDoc_Doc_Cat = d.DDoc_Doc_Cat AND b.BDoc_Doc_Ano = d.DDoc_Doc_Ano AND b.BDoc_Doc_Num = d.DDoc_Doc_Num AND b.BDoc_Doc_Lin = d.DDoc_Doc_Lin"
        strsql &= "      WHERE d.DDoc_Sis_Emp = {empresa} AND d.DDoc_Doc_Cat = 36 AND d.DDoc_Doc_Ano = {año} AND d.DDoc_Doc_Num = {numero}"
        strsql &= "    GROUP BY d.DDoc_Doc_Ano, d.DDoc_Doc_Num, d.DDoc_Doc_Lin"
        strsql &= "  ORDER BY d.DDoc_Doc_Lin"

        strsql = Replace(strsql, "{empresa}", Sesion.IdEmpresa)
        strsql = Replace(strsql, "{año}", intaño)
        strsql = Replace(strsql, "{numero}", intnumero)

        Return strsql
    End Function

    Private Function sqlCC(ByVal intaño As Integer, ByVal intnumero As Integer) As String

        Dim strsql As String = STR_VACIO

        strsql = " SELECT cat_num, cat_clave, ECta_Concepto, ECta_Sini_Loc, ECta_Crgo_Loc, ECta_Abno_Loc, ECta_Sini_Ext, ECta_Crgo_Ext, ECta_Abno_Ext, ECta_Doc_Lin, ECta_FecDcmt, ECta_FecVenc, ECta_moneda, ECta_TC, Nombre, Codigo, Tipo, c.HDoc_RF2_Num"
        strsql &= "  FROM ECtaCte AS a, ("
        strsql &= "   SELECT _latin1 'Proveedores' COLLATE latin1_spanish_ci AS Tipo, pro_codigo AS Codigo, pro_proveedor AS Nombre"
        strsql &= "     FROM Proveedores"
        strsql &= "      WHERE pro_sisemp = {empresa} UNION"
        strsql &= "         SELECT _latin1 'Clientes' COLLATE latin1_spanish_ci, cli_codigo, cli_cliente"
        strsql &= "      FROM Clientes"
        strsql &= "    WHERE cli_sisemp = {empresa}) AS b, Dcmtos_HDR AS c, Catalogos AS d"
        strsql &= "  WHERE ECta_moneda = cat_num AND cat_clase = 'Monedas' AND ECta_tipoemp = Tipo AND ECta_codemp = Codigo AND ECta_Sis_Emp = HDoc_Sis_Emp AND ECta_Ref_Cat = HDoc_Doc_Cat AND ECta_Ref_Ano = HDoc_Doc_Ano AND ECta_Ref_Num = HDoc_Doc_Num AND HDoc_Sis_Emp = {empresa} AND HDoc_Doc_Cat = 36 AND HDoc_Doc_Ano = {año} AND HDoc_Doc_Num = {numero}"
        strsql &= " ORDER BY ECta_FecDcmt"

        strsql = Replace(strsql, "{empresa}", Sesion.IdEmpresa)
        strsql = Replace(strsql, "{año}", intaño)
        strsql = Replace(strsql, "{numero}", intnumero)

        Return strsql
    End Function

    Private Function SQLMostrarInfoLPrincipal(ByVal intaño As Integer, ByVal intnumero As Integer)

        Dim strsql As String = STR_VACIO

        strsql = " SELECT d.DDoc_Doc_Lin Linea, a.art_DCorta Descripcion, d.DDoc_RF3_Dbl Cantidad, IFNULL(c.cat_clave,'N/A') Medida"
        strsql &= "     FROM Dcmtos_DTL d"
        strsql &= "      LEFT JOIN Inventarios i ON i.inv_sisemp = d.DDoc_Sis_Emp AND i.inv_numero= d.DDoc_Prd_Cod"
        strsql &= "     LEFT JOIN Articulos a ON a.art_sisemp = i.inv_sisemp AND a.art_codigo = i.inv_artcodigo"
        strsql &= "    LEFT JOIN Catalogos c ON c.cat_clase = 'Medidas' AND c.cat_num = d.DDoc_RF3_Num"
        strsql &= "   WHERE d.DDoc_Sis_Emp = {empresa} AND d.DDoc_Doc_Cat = 36 AND d.DDoc_Doc_Ano = {año} AND d.DDoc_Doc_Num = {numero}"
        strsql &= "  ORDER BY d.DDoc_Doc_Lin"

        strsql = Replace(strsql, "{empresa}", Sesion.IdEmpresa)
        strsql = Replace(strsql, "{año}", intaño)
        strsql = Replace(strsql, "{numero}", intnumero)
        Return strsql

    End Function

    'Carga el listado de referencias afectadas por las líneas del detalle
    Private Sub sqlCargarRelacion()

        Dim strsql As String = STR_VACIO
        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader
        Dim strTemp As String = STR_VACIO

        strsql = "SELECT b.HDoc_Doc_Cat Tipo, b.HDoc_Doc_Ano Ano, b.HDoc_Doc_Num Numero, b.HDoc_Doc_Fec Fecha, b.HDoc_DR1_Num Referencia, COALESCE(m.cat_clave,'') Medida, COALESCE(m.cat_num,0) Unidad, a.PDoc_Par_Lin Linea, a.PDoc_Prd_Cod Codigo, IFNULL(a.PDoc_QTY_Ord,0) Disponible, a.PDoc_QTY_Pro Descargo, d.DDoc_Prd_QTY Cantidad, a.PDoc_Chi_Lin ID"
        strsql &= "     FROM Dcmtos_DTL_Pro a"
        strsql &= "      INNER JOIN Dcmtos_HDR b ON b.HDoc_Sis_Emp = a.PDoc_Sis_Emp AND b.HDoc_Doc_Cat = a.PDoc_Par_Cat AND b.HDoc_Doc_Ano = a.PDoc_Par_Ano AND b.HDoc_Doc_Num = a.PDoc_Par_Num"
        strsql &= "     INNER JOIN Dcmtos_DTL d ON d.DDoc_Sis_Emp = a.PDoc_Sis_Emp AND d.DDoc_Doc_Cat = a.PDoc_Chi_Cat AND d.DDoc_Doc_Ano = a.PDoc_Chi_Ano AND d.DDoc_Doc_Num = a.PDoc_Chi_Num AND d.DDoc_Doc_Lin = a.PDoc_Chi_Lin"
        strsql &= "    LEFT JOIN Catalogos m ON m.cat_clase='Medidas' AND m.cat_num = COALESCE(d.DDoc_RF3_Num,d.DDoc_Prd_UM)"
        strsql &= "   WHERE PDoc_Sis_Emp = {empresa} AND PDoc_Par_Cat = 36 AND PDoc_Chi_Cat = 296 AND PDoc_Chi_Ano = {año} AND PDoc_Chi_Num = {numero} AND PDoc_Chi_Lin = {linea}"
        strsql &= "  ORDER BY b.HDoc_Doc_Ano, b.HDoc_Doc_Num"
        'NOTAS: '296/Facturacion' es child, y '36/Ingreso' es parent

        strsql = Replace(strsql, "{empresa}", Sesion.IdEmpresa)

        'dgReferencia.Rows.Clear()
        For i As Integer = 0 To dgDetalle.Rows.Count - 1
            strTemp = Replace(strsql, "{año}", dgDetalle.Rows(i).Cells("colAño").Value)
            strTemp = Replace(strTemp, "{numero}", dgDetalle.Rows(i).Cells("colNum").Value)
            strTemp = Replace(strTemp, "{linea}", dgDetalle.Rows(i).Cells("colLinea").Value)

            Try

                MyCnn.CONECTAR = strConexion

                COM = New MySqlCommand(strTemp, CON)
                REA = COM.ExecuteReader

                If REA.HasRows Then

                    Do While REA.Read
                        Dim strFila As String = STR_VACIO
                        Dim Numero As Integer = Val(dgDetalle.Rows(i).Cells("colLinea").Value)

                        strFila = Numero & "|"
                        strFila &= REA.GetInt32("Tipo") & "|"
                        strFila &= REA.GetInt32("Ano") & "|"
                        strFila &= REA.GetInt32("Numero") & "|"
                        strFila &= REA.GetDateTime("Fecha") & "|"
                        strFila &= PolizaIngreso(REA.GetInt32("Ano"), REA.GetInt32("Numero")) & "|"
                        strFila &= REA.GetString("Referencia") & "|"
                        strFila &= REA.GetInt32("Linea") & "|"
                        strFila &= REA.GetInt32("Codigo") & "|"
                        strFila &= REA.GetDouble("Disponible") & "|"
                        strFila &= REA.GetDouble("Descargo") & "|"
                        strFila &= REA.GetDouble("Descargo") & "|"
                        strFila &= REA.GetDouble("Cantidad") & "|"
                        strFila &= "" & "|"
                        strFila &= "" & "|"
                        strFila &= REA.GetInt32("Unidad") & "|"
                        strFila &= REA.GetString("Medida") & "|"
                        strFila &= ""


                        cFunciones.AgregarFila(dgReferencia, strFila)

                    Loop

                End If

            Catch ex As Exception
                MsgBox(ex.ToString)
            End Try


        Next


    End Sub

    'Devuelve la póliza para un documento de ingreso
    Private Function PolizaIngreso(ByVal Ano As String, ByVal Numero As String)
        Dim strSQL As String = STR_VACIO
        Dim COM As MySqlCommand
        Dim conec As MySqlConnection

        strSQL = "SELECT a.ADoc_Dta_Chr Poliza"
        strSQL &= " FROM Dcmtos_DTL_Pro p"
        strSQL &= "     INNER JOIN Catalogos c ON c.cat_num = p.PDoc_Par_Cat AND c.cat_clase = 'Documentos'"
        strSQL &= "          INNER JOIN Dcmtos_ACC a ON a.ADoc_Sis_Emp = p.PDoc_Sis_Emp AND a.ADoc_Doc_Cat = p.PDoc_Par_Cat AND a.ADoc_Doc_Ano = p.PDoc_Par_Ano AND a.ADoc_Doc_Num = p.PDoc_Par_Num"
        strSQL &= "      WHERE p.PDoc_Sis_Emp ={Empresa} AND p.PDoc_Chi_Cat =47 AND p.PDoc_Chi_Ano ={año} AND p.PDoc_Chi_Num ={Numero} AND c.cat_sist = 'Doc_ODesImp' AND a.ADoc_Doc_Lin = '01'"

        strSQL = Replace(strSQL, "{Empresa}", Sesion.IdEmpresa)
        strSQL = Replace(strSQL, "{año}", Ano)
        strSQL = Replace(strSQL, "{Numero}", Numero)

        conec = New MySqlConnection(strConexion)
        conec.Open()
        COM = New MySqlCommand(strSQL, conec)
        Poliza = COM.ExecuteScalar
        conec.Close()

        Return Poliza
    End Function

    'Procedimiento para Cargar dgLista Panel Principal
    Public Sub queryListaPrincipal()
        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader
        Dim strSQL As String = STR_VACIO
        Dim Celda As New DataGridViewTextBoxCell
        Dim Fila As New DataGridViewRow
        Dim e As Integer
        Dim m As Integer
        Dim im As Integer
        Dim b As Integer
        Dim s As Integer
        Dim c As Integer
        Dim p As Integer
        'Dim Lista As DataGridView

        strSQL = SQLlista()

        Try
            MyCnn.CONECTAR = strConexion

            COM = New MySqlCommand(strSQL, CON)
            REA = COM.ExecuteReader

            If REA.HasRows Then

                dgLista.Rows.Clear()

                Do While REA.Read
                    Dim strFila As String = STR_VACIO

                    strFila = REA.GetInt32("Year") & "|"
                    strFila &= REA.GetInt32("Numero") & "|"
                    strFila &= REA.GetDateTime("Fecha") & "|"
                    strFila &= REA.GetString("Cliente") & "|"
                    strFila &= REA.GetString("Referencia") & "|"
                    strFila &= REA.GetInt32("impreso") & "|"
                    strFila &= REA.GetInt32("HDoc_Doc_Status") & "|"
                    strFila &= REA.GetInt32("Salida") & "|"
                    strFila &= REA.GetInt32("Impuesto") & "|"
                    strFila &= REA.GetInt32("bloqueado") & "|"
                    strFila &= REA.GetInt32("Cargado") & "|"
                    strFila &= REA.GetInt32("Poliza") & "|"
                    strFila &= REA.GetString("Direction") & "|"
                    strFila &= REA.GetString("NIT")
                    'strFila &= REA.GetString("Phone")


                    e = REA.GetInt32("HDoc_Doc_Status")
                    m = REA.GetInt32("impreso")
                    im = REA.GetInt32("Impuesto")
                    b = REA.GetInt32("bloqueado")
                    s = REA.GetInt32("Salida")
                    c = REA.GetInt32("Cargado")
                    p = REA.GetInt32("Poliza")
                    AgregarFila(dgLista, strFila, e, m, im, b, s, c, p)


                Loop
            End If

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try

    End Sub

    'Pocedimiento propio de facturacion para agregar listado principal y colores de acuerdo al esta de cada fila
    Private Sub AgregarFila(ByRef Lista As DataGridView, ByVal strFila As String, ByVal Estado As Integer, ByVal impreso As Integer, ByVal Impuesto As Integer, ByVal bloqueado As Integer, ByVal Salida As Integer, ByVal Cargado As Integer, ByVal Poliza As Integer)

        Dim Celda As New DataGridViewTextBoxCell
        Dim Fila As New DataGridViewRow
        Dim strSQL As String = STR_VACIO
        Dim arrayFila() As String
        Dim i As Integer
        Try
            Lista.BackgroundColor = Color.White
            arrayFila = strFila.Split("|".ToCharArray)
            For i = 0 To arrayFila.Length - 1
                Celda = New DataGridViewTextBoxCell
                Celda.Value = arrayFila(i)

                If Estado = vbEmpty Then
                    If i = 1 Then
                        Celda.Style.BackColor = Color.Red
                        'Else
                        '    Celda.Style.BackColor = Color.White
                    End If
                Else
                    If impreso = vbEmpty Then
                        If i = 1 Then
                            Celda.Style.BackColor = Color.Yellow
                            'Else
                            '    Celda.Style.BackColor = Color.White
                        End If
                    End If
                End If
                'Pendiente de Certificado de Origen
                If Impuesto = INT_UNO And bloqueado = INT_UNO Then
                    If i = 2 Then
                        Celda.Style.BackColor = Color.Magenta
                        'Else
                        '    Celda.Style.BackColor = Color.White
                    End If
                ElseIf Salida = vbEmpty Then
                    'Pendiente de Salida
                    If i = 2 Then
                        Celda.Style.BackColor = Color.Orange
                        'Else
                        '    Celda.Style.BackColor = Color.White
                    End If
                    If Cargado = vbEmpty Then
                        If i = 3 Then
                            Celda.Style.BackColor = Color.Cyan

                        End If
                    End If
                    If Poliza = INT_CERO Then
                        If i = 4 Then
                            Celda.Style.BackColor = Color.GreenYellow

                        End If
                    End If
                End If
                'End If


                Fila.Cells.Add(Celda)

            Next

            Lista.Rows.Add(Fila)
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try

    End Sub

    'Query que carga las Instrucciones de Despacho
    Public Sub queryInstDespacho(ByVal intaño As Integer, ByVal intnumero As Integer)
        Dim COM As New MySqlCommand
        Dim REA As MySqlDataReader
        Dim strSQL As String = STR_VACIO

        strSQL = SqlInstDespacho(intaño, intnumero)

        Try

            MyCnn.CONECTAR = strConexion

            COM = New MySqlCommand(strSQL, CON)
            REA = COM.ExecuteReader

            If REA.HasRows Then

                dgFacturacion.Rows.Clear()

                Do While REA.Read
                    Dim strFila As String = STR_VACIO


                    strFila = REA.GetInt32("HDoc_Doc_Cat") & "|" & REA.GetString("HDoc_Doc_Ano") & "|" & REA.GetInt32("HDoc_Doc_Num") & "|" & REA.GetDateTime("HDoc_Doc_Fec") & "|" & REA.GetString("HDoc_Usuario") & "|" & REA.GetString("HDoc_DR1_Num") & "|" & "0"


                    cFunciones.AgregarFila(dgFacturacion, strFila)

                Loop

            End If

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try

    End Sub

    'procedimiento que cargar SubDocumentos
    Public Sub SeleccionarSubdocumentos(ByVal intaño As Integer, ByVal intnumero As Integer)
        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader
        Dim strSQL As String = STR_VACIO

        strSQL = SqlListaSudDocumentos(intaño, intnumero)

        Try

            MyCnn.CONECTAR = strConexion

            COM = New MySqlCommand(strSQL, CON)
            REA = COM.ExecuteReader

            If REA.HasRows Then

                dgSubdocumentos.Rows.Clear()

                Do While REA.Read
                    Dim strFila As String = STR_VACIO

                    strFila = REA.GetString("cat_clave") & "|"
                    strFila &= REA.GetString("cat_desc") & "|"
                    strFila &= REA.GetString("Cantidad")

                    cFunciones.AgregarFila(dgSubdocumentos, strFila)

                Loop

            End If

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try

    End Sub

    'Procedimiento para Cargar dgDetalle 
    Public Sub queryDetalle(ByVal intaño As Integer, ByVal intnumero As Integer)
        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader
        Dim strSQL As String = STR_VACIO

        strSQL = sqlDetalle(intaño, intnumero)

        Try

            MyCnn.CONECTAR = strConexion

            COM = New MySqlCommand(strSQL, CON)
            REA = COM.ExecuteReader

            If REA.HasRows Then

                dgDetalle.Rows.Clear()

                Do While REA.Read
                    Dim strFila As String = STR_VACIO

                    strFila = REA.GetInt32("Numero") & "|"
                    strFila &= REA.GetInt32("Codigo") & "|"
                    strFila &= REA.GetInt32("Ano") & "|"
                    strFila &= REA.GetInt32("Linea") & "|"
                    strFila &= REA.GetInt32("Lin2") & "|"
                    strFila &= REA.GetString("Descripcion") & "|"
                    strFila &= REA.GetInt32("NuMedida") & "|"
                    strFila &= REA.GetString("Medida") & "|"
                    strFila &= REA.GetDouble("Despacho") & "|"
                    strFila &= REA.GetDouble("Precio") & "|"
                    strFila &= "0.00" & "|"
                    strFila &= "0.00 " & "|"
                    strFila &= REA.GetDouble("Cantidad") & "|"
                    strFila &= REA.GetDouble("Total") & "|"
                    strFila &= REA.GetInt32("cantidadBulto") & "|"
                    strFila &= REA.GetString("Bulto") & "|"
                    strFila &= REA.GetInt32("Bobinas") & "|"
                    strFila &= REA.GetString("Distribucion") & "|"
                    strFila &= REA.GetInt32("Destino") & "|"
                    strFila &= REA.GetString("Lugar") & "|"
                    strFila &= REA.GetDouble("Libras") & "|"
                    strFila &= REA.GetDouble("Kilos") & "|"
                    strFila &= REA.GetInt32("Original") & "|"
                    strFila &= REA.GetString("Referencia") & "|"
                    strFila &= REA.GetInt32("Base")

                    cFunciones.AgregarFila(dgDetalle, strFila)
                Loop

            End If

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try

    End Sub

    'Procedimiento para Cargar Cuentas por Cobrar
    Public Sub queryCC(ByVal intaño As Integer, ByVal intnumero As Integer)
        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader
        Dim strSQL As String = STR_VACIO

        strSQL = sqlCC(intaño, intnumero)

        Try

            MyCnn.CONECTAR = strConexion

            COM = New MySqlCommand(strSQL, CON)
            REA = COM.ExecuteReader

            If REA.HasRows Then

                dgDatos.Rows.Clear()

                Do While REA.Read
                    Dim strFila As String = STR_VACIO

                    strFila = REA.GetString("Nombre") & "|" & REA.GetString("ECta_Concepto") & "|" & REA.GetString("cat_clave") & "|" & REA.GetDouble("ECta_TC") & "|" & REA.GetDouble("ECta_Crgo_Loc") & "|" & REA.GetDouble("ECta_Abno_Loc") & "|" &
                     REA.GetInt32("HDoc_RF2_Num")

                    cFunciones.AgregarFila(dgDatos, strFila)


                    'dgDatos..BackColor = Color.AntiqueWhite

                Loop

            End If

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try

    End Sub

    'Procedimiento para Cargar Informacion de CheckMuestra Detalle en Lista Principal (Parte Inferior)
    Public Sub queryCheckMuestraDetalle(ByVal intaño As Integer, ByVal intnumero As Integer)
        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader
        Dim strSQL As String = STR_VACIO
        Dim strFila As String = STR_VACIO
        Dim cone As New MySqlConnection
        cone.ConnectionString = strConexion
        cone.Open()

        Try
            strSQL = SQLMostrarInfoLPrincipal(intaño, intnumero)

            'MyCnn.CONECTAR = strConexion

            COM = New MySqlCommand(strSQL, cone)
            REA = COM.ExecuteReader


            Do While REA.Read


                strFila &= vbNewLine & REA.GetInt32("Linea") & " )     " & REA.GetDouble("Cantidad") & "   " & REA.GetString("Medida") & " " & REA.GetString("Descripcion")

                'celdaInfoDetalle.Text = strFila
            Loop
            celdaInfoDetalle.Text = strFila
        Catch ex As Exception
            MsgBox(ex.ToString)
        Finally
            cone.Close()
        End Try

    End Sub

    Private Sub MostrarLista(Optional ByVal logMostrar As Boolean = True, Optional logInsert As Boolean = False)
        Dim cfun As New clsFunciones
        If logMostrar = True Then
            'ocultar panel de documento
            panelDocumento.Dock = DockStyle.None
            panelDocumento.Visible = False
            'actualizar Titulo
            BarraTitulo1.CambiarTitulo("Clientes")
            'Cargar Datos
            'cfun.CargarLista(dgLista, SQLlista, False)
            queryListaPrincipal()
            'Mostrar Panel Filtro
            panelLista.Visible = True
            panelLista.Dock = DockStyle.Fill
            BloquearBotones()
            'Me.Tag = ""
        Else
            'Ocultar Panel Filtro
            panelLista.Visible = False
            panelLista.Dock = DockStyle.None
            'Mostrar panel de documento
            panelDocumento.Dock = DockStyle.Fill
            panelDocumento.Visible = True
            'Verifica si se va a crear un nuevo documento o se va modifica
            If logInsert = False Then
                BarraTitulo1.CambiarTitulo("Modificar Registro")
                Me.Tag = "Mod"
                BloquearBotones(False)
                botonImprimir.Enabled = True
            Else
                BarraTitulo1.CambiarTitulo("Nuevo Registro")
                Me.Tag = "Nuevo"
                BloquearBotones(False)
                botonImprimir.Enabled = False

                LimpiarPanelOrden()
            End If

            dgLista.DataSource = Nothing
        End If

    End Sub

    Private Sub Seleccionar(ByVal intaño As Integer, ByVal intnumero As Integer)
        SeleccionarCliente(intaño, intnumero)

    End Sub

    'Limpia todos los campos y datagrid's del panel de Fcaturacion
    Public Sub LimpiarPanelOrden()
        celdaAño.Text = -1
        celdaNumero.Text = -1
        dtpFecha.Text = STR_VACIO
        celdaDireccion.Text = STR_VACIO
        celdaCliente.Text = STR_VACIO
        celdaTasa.Text = cfun.QueryTasa
        celdaTelefono.Text = STR_VACIO
        celdaNIT.Text = STR_VACIO
        celdaMoneda.Text = STR_VACIO
        celdaFlete.Text = INT_CERO
        celdaSeguro.Text = INT_CERO
        celdaTotal1.Text = 0
        celdaTotal2.Text = 0
        dgDetalle.Rows.Clear()
        dgDatos.Rows.Clear()
        dgFacturacion.Rows.Clear()
        dgSubdocumentos.Rows.Clear()
        dgReferencia.Rows.Clear()
        logImpuesto = False
        logLibre = True

    End Sub

    Private Sub SeleccionarCliente(ByVal intaño As Integer, ByVal intnumero As Integer)
        Dim HDR As New clsDcmtos_HDR
        Dim CA As New clsCatalogos
        Dim strCampos As String = STR_VACIO
        Dim strCondicion As String = STR_VACIO
        strCampos = " HDoc_Doc_Ano, HDoc_Doc_Num, HDoc_Doc_Fec, HDoc_Emp_Cod, HDoc_Emp_Nom, HDoc_Emp_Dir, HDoc_Emp_Tel, HDoc_Emp_NIT, HDoc_Doc_Tc, HDoc_Doc_Status, HDoc_Doc_Mon, HDoc_Doc_TC,HDoc_RF1_Dbl, HDoc_RF2_Dbl, HDoc_Usuario, HDoc_RF2_Cod"
        strCondicion = " HDoc_Sis_Emp = {empresa} AND HDoc_Doc_Cat = 36 AND HDoc_Doc_Ano = {año} AND HDoc_Doc_Num = {numero}"
        strCondicion = Replace(strCondicion, "{empresa}", Sesion.IdEmpresa)
        strCondicion = Replace(strCondicion, "{año}", intaño)
        strCondicion = Replace(strCondicion, "{numero}", intnumero)

        Try
            HDR.CONEXION = strConexion
            If HDR.Seleccionar(strCondicion, strCampos) Then
                celdaAño.Text = HDR.HDOC_DOC_ANO
                celdaNumero.Text = HDR.HDOC_DOC_NUM
                dtpFecha.Text = HDR.HDOC_DOC_FEC
                celdaIdCliente.Text = HDR.HDOC_EMP_COD
                celdaCliente.Text = HDR.HDOC_EMP_NOM
                celdaDireccion.Text = HDR.HDOC_EMP_DIR
                celdaTelefono.Text = HDR.HDOC_EMP_TEL
                celdaNIT.Text = HDR.HDOC_EMP_NIT
                'celdaMoneda.Text = HDR.HDOC_DOC_MON
                celdaTasa.Text = HDR.HDOC_DOC_TC
                celdaFlete.Text = HDR.HDOC_RF1_DBL
                celdaSeguro.Text = HDR.HDOC_RF2_DBL
                celdaUsuario.Text = HDR.HDOC_USUARIO
                celdaEmpresa.Text = Sesion.IdEmpresa
                celdaTipo.Text = 296
                celdaCargado.Text = HDR.HDOC_RF2_COD


                If CA.Seleccionar(" cat_num = " & HDR.HDOC_DOC_MON, "cat_clave") Then
                    celdaMoneda.Text = CA.CAT_CLAVE
                Else
                    MsgBox(CA.MERROR.ToString)
                End If

                If HDR.HDOC_DOC_STATUS = 1 Then
                    checkActivar.Checked = True
                Else
                    checkActivar.Checked = False
                End If

                If HDR.HDOC_DR2_CAT = 0 Then
                    rbNacionalizacion.Checked = True
                Else
                    rbExportacion.Checked = False
                End If

                If logImpuesto Then
                    logLibre = Not IsDBNull(HDR.HDOC_DR2_FEC)
                Else
                    logLibre = True
                End If

            End If

        Catch ex As Exception

        End Try
    End Sub

    'Suma la columna para la línea
    Private Function SumarLista(ByVal Columna As String, ByVal Ciclo As String, ByVal Numero As String, ByVal Linea As String) As Double
        Dim i As Integer
        Dim dblSuma As Double

        Try
            dblSuma = vbEmpty
            For i = 0 To dgReferencia.Rows.Count - 1
                If (dgReferencia.Rows(i).Cells("colAno").Value = Ciclo) And
                    (dgReferencia.Rows(i).Cells("colNumber").Value = Numero) And
                    (dgReferencia.Rows(i).Cells("colLine").Value = Linea) Then
                    dblSuma = dblSuma + Val(dgReferencia.Rows(i).Cells(Columna).Value)
                End If
            Next
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try

        SumarLista = dblSuma
    End Function

    'Comprueba el descargo desde varias líneas a una misma línea de referencia
    Private Function ComprobarDescargos() As Boolean
        Dim i As Integer
        Dim strTemp As String
        Dim dblDisponible As Double
        Dim dblActual As Double
        Dim dblSuma As Double
        Dim strLineas As String = STR_VACIO
        Dim intDif As Boolean

        If Me.Tag = "Mod" And checkActivar.Checked = False Then
            ComprobarDescargos = True
        Else
            If (dgReferencia.Rows.Count > vbEmpty) Then
                For i = 0 To dgReferencia.Rows.Count - 1
                    'Identifica la línea a descargar
                    strTemp = dgReferencia.Rows(i).Cells("colAno").Value & "|"
                    strTemp &= dgReferencia.Rows(i).Cells("colNumber").Value & "|"
                    strTemp &= dgReferencia.Rows(i).Cells("colLine").Value & "|"
                    dblDisponible = dgReferencia.Rows(i).Cells("colAmount").Value
                    dblActual = SumarLista("colCantDescargada", dgReferencia.Rows(i).Cells("colAno").Value, dgReferencia.Rows(i).Cells("colNumber").Value, dgReferencia.Rows(i).Cells("colLine").Value)
                    dblSuma = SumarLista("colDescargo", dgReferencia.Rows(i).Cells("colAno").Value, dgReferencia.Rows(i).Cells("colNumber").Value, dgReferencia.Rows(i).Cells("colLine").Value)
                    If (dblSuma) > (dblDisponible + dblActual) Then
                        'Comprueba si ya se verificó
                        If InStr(1, strLineas, strTemp) = vbEmpty Then
                            MsgBox("You are trying to download and amount greater than the available" & vbCr & vbCr & "Inventory code" & vbTab & dgReferencia.Rows(i).Cells("colReference").Value & vbCr & "Linea: " & vbTab & vbTab & vbTab & dgReferencia.Rows(i).Cells("colLine").Value & vbCr & "Inventory Code: " & vbTab & dgReferencia.Rows(i).Cells("colCod").Value & vbCr & vbCr & "Faltante:" & vbTab & vbTab & (dblSuma - (dblDisponible + dblActual)).ToString(FORMATO_MONEDA), vbExclamation, "Notice")
                            intDif = intDif + 1
                        End If
                        'Agrega la línea a comprobadas
                        strLineas = strLineas & vbNullChar & strTemp
                    Else
                        'Asigna la existencia actual
                        dgReferencia.Rows(i).Cells("colDisponible").Value = (dblDisponible + dblActual).ToString(FORMATO_MONEDA)
                    End If
                Next
            Else
                MsgBox("Exculpatory information we not found", vbExclamation, "Notice")
                intDif = NO_FILA
            End If
            ComprobarDescargos = (intDif = vbEmpty)
        End If
    End Function

    Private Function ComprobarFilaDetalle() As Boolean
        ComprobarFilaDetalle = True
        Dim i As Integer
        Dim Comprobacion As Boolean = True

        For i = 0 To dgDetalle.Rows.Count - 1
            If dgDetalle.Rows(i).Cells("colCode").Value = vbNullString Then
                Comprobacion = False
                MsgBox("Article code invalid")
            End If

            If dgDetalle.Rows(i).Cells("colDescrip").Value = vbNullString Then
                Comprobacion = False
                MsgBox("Blank item description")
            End If

            If dgDetalle.Rows(i).Cells("colDescrip").Value = vbNullString Then
                Comprobacion = False
                MsgBox("Blank item description")
            End If

            If dgDetalle.Rows(i).Cells("colPrecio").Value = vbNullString Then
                Comprobacion = False
                MsgBox("ZERO price items")
            End If

            If dgDetalle.Rows(i).Cells("colCantidad").Value = vbNullString Then
                Comprobacion = False
                MsgBox("Item number ZERO")
            End If

            If dgDetalle.Rows(i).Cells("colTipoBulto").Value = vbNullString Then
                Comprobacion = False
                MsgBox("Do You must enter the type of packages", MsgBoxStyle.Information)

            End If
        Next
        Return Comprobacion
    End Function

    'Comprueba que se haya ingresado flete y seguro
    Private Function ComprobarGastos() As Boolean

        If checkActivar.Checked = False Then
            ComprobarGastos = True
        ElseIf Val(celdaFlete.Text) = vbEmpty Or Val(celdaSeguro.Text) = vbEmpty Then
            If MsgBox("You have not  entered a values  for freight or insuracne" & vbCr & vbCr & "Want to leave blank some of these values?", vbExclamation + vbYes + vbYesNo + vbDefaultButton2, "Confirm") = vbYes Then
                ComprobarGastos = True
            Else
                celdaFlete.Focus()
            End If
        Else
            ComprobarGastos = True
        End If
        ComprobarGastos = True
    End Function

    Private Function ComprobarDatos() As Boolean
        Dim comprobar As Boolean = True
        'Revisar que los datos de la cabecera no estén en blanco.
        If celdaEmpresa.Text = vbNullString Or
           celdaTipo.Text = vbNullString Or
           celdaUsuario.Text = vbNullString Then
            MsgBox("Incomplete  data sytem.", vbCritical)
            comprobar = False
        End If

        If celdaAño.Text = vbEmpty Or
           celdaNumero.Text = vbEmpty Or
           celdaIdCliente.Text = vbEmpty Or
           celdaCliente.Text = "" Or
           celdaNIT.Text = "" Or
           celdaMoneda.Text = "" Or
           celdaTasa.Text = vbEmpty Then
            MsgBox("You must enter all minimum data", vbCritical)
            comprobar = False
        End If

        If Not IsDate(dtpFecha.Text) Then
            MsgBox("You have not entered a valid date", vbExclamation, "Notice")
            dtpFecha.Focus()
            comprobar = False
        ElseIf Not (Val(celdaAño.Text)) = (celdaAño.Text) Then
            MsgBox("The date entered does not match the year of the document", vbExclamation, "Notice")
            dtpFecha.Focus()
            comprobar = False
        End If

        If Not checkActivar.Checked = False Then
            'Verifica datos en el Detalle
            If ComprobarFilaDetalle() = False Then comprobar = False
        End If



        'Verifica que total > 0
        CalcularTotales()
        If Not checkActivar.Checked = False Then
            If Not dblDocCantidad > 0 Then
                MsgBox("It is not supported and order with zero amount", vbCritical)
                comprobar = False
            End If
        End If
        Return comprobar
    End Function

    'Comprueba que no se mezclen grupos de paises (p.e.: USA, ASIA)
    Private Function ComprobarOrigenes() As Boolean
        Const STR_GRUPOS As String = "'ASIA','USA'"

        Dim logEx As Boolean
        Dim strCod As String
        Dim strLista As String
        Dim strSQL As String
        Dim strTemp As String
        Dim COM As MySqlCommand
        Dim conec As MySqlConnection

        Dim i As Integer
        Dim c As Integer

        logEx = False
        c = vbEmpty
        strCod = vbNullString : strLista = vbNullString
        For i = vbEmpty To dgDetalle.Rows.Count - 1
            strCod = "|" & strCod & "|"
            If Not (strCod = vbNullString) Then
                strCod = "|" & strCod & "|"
                If InStr(1, strLista, strCod) = vbEmpty Then
                    strLista = strLista & strCod
                    c = c + 1
                End If
            End If
        Next

        'Sólo si hay más de un código involucrado   
        If c > INT_UNO Then
            strLista = Replace(strLista, "||", ",")
            strLista = Replace(strLista, "|", vbNullString)

            strSQL = vbNullString
            strSQL &= "SELECT GROUP_CONCAT(DISTINCT g.cat_clave ORDER BY g.cat_clave SEPARATOR ',') Grupos "
            strSQL &= "      FROM Inventarios i"
            strSQL &= "         INNER JOIN Catalogos c ON c.cat_clase='Paises' AND c.cat_num=i.inv_lugarfab "
            strSQL &= "              INNER JOIN Catalogos g ON g.cat_clase='Countries' AND g.cat_num=c.cat_pid "
            strSQL &= "          WHERE i.inv_sisemp={empresa} AND i.inv_numero IN ({lista}) AND g.cat_clave IN ({grupos}) "

            strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
            strSQL = Replace(strSQL, "{lista}", strLista)
            strSQL = Replace(strSQL, "{grupo}", STR_GRUPOS)


            conec = New MySqlConnection(strConexion)
            conec.Open()
            COM = New MySqlCommand(strSQL, conec)
            strTemp = COM.ExecuteScalar()
            conec.Close()

            If Not (strTemp = vbNullString) Then
                If InStr(1, strTemp, ",") > vbEmpty Then
                    MsgBox("You cant not mix products originating" & Replace(Replace(STR_GRUPOS, "'", ""), ",", " y "), vbExclamation, "Origin")
                    logEx = True
                End If
            End If
        End If

        ComprobarOrigenes = Not logEx
    End Function

    'Comprueba que se haya verificado todas las líneas
    Private Function ComprobarLineas() As Boolean
        Dim i As Integer
        Dim j As Integer
        Dim k As Integer
        Dim strTemp As String = STR_VACIO
        Dim strMensaje As String = STR_VACIO

        If Me.Tag = "Mod" And checkActivar.Checked = False Then
            ComprobarLineas = True
        Else
            'Verifica si se han revisado las referencias para todas las líneas
            For i = vbEmpty To dgDetalle.Rows.Count - 1
                If dgDetalle.Rows(i).Cells("colReferences").Value = vbNullString Then
                    j = j + 1
                    strTemp = strTemp & IIf(strTemp = vbNullString, vbNullString, " , ") & (i + 1)
                End If
            Next

            If (j > vbEmpty) Then
                strMensaje = "No ha comprobado los descargos para " & IIf(j = 1, "la linea", "las lineas") & ":" & strTemp
            End If

            'Verifica si hay alguna línea sin tipo de bulto
            j = vbEmpty
            strTemp = vbNullString
            For i = vbEmpty To dgDetalle.Rows.Count - 1
                If dgDetalle.Rows(i).Cells("colTipoBulto").Value = vbNullString Then
                    j = j + 1
                    strTemp = strTemp & IIf(strTemp = vbNullString, vbNullString, " , ") & (i + 1)
                End If
            Next

            If (j > vbEmpty) Then
                strMensaje = strMensaje & IIf(strMensaje = vbNullString, vbNullString, vbCr & vbCr) & "No ha ingresado el Tipo de Bulto para" & IIf(j = 1, "la linea", "las lineas") & ": " & strTemp
            End If

            'Verifica el formato de distribución de la mercancía
            Dim varPartes As Object
            Dim varDato As Object
            Dim dblSuma As Double
            Dim logErr As Boolean
            Dim strInfo As String = STR_VACIO
            j = vbEmpty
            strTemp = vbNullString

            For i = 0 To dgDetalle.Rows.Count - 1
                If Not dgDetalle.Rows(i).Cells("colDistribucion").Value = vbNullString Then
                    varPartes = Split(dgDetalle.Rows(i).Cells("colDistribucion").Value, " , ")
                    dblSuma = vbEmpty
                    logErr = False
                    For k = vbEmpty To UBound(varPartes)
                        If InStr(1, varPartes(k), "/") > vbEmpty Then
                            varDato = Split(varPartes(k), "/")
                            If (UBound(varDato) = 1) Then
                                If IsNumeric(varDato(vbEmpty)) And IsNumeric(varDato(1)) Then
                                    If (varDato(vbEmpty) = CInt(Val(varDato(vbEmpty)))) And Val(varDato(vbEmpty)) > vbEmpty Then
                                        dblSuma = dblSuma + Val(varDato(1))
                                    Else
                                        strInfo = strInfo & IIf(strInfo = vbNullString, vbNullString, vbCr) & "Linea " & (i + 1) & ": la secuencia debe ser un numero entero mayor que cero"
                                        logErr = True
                                    End If
                                Else
                                    strInfo = strInfo & IIf(strInfo = vbNullString, vbNullString, vbCr) & "Linea " & (i + 1) & ": secuencia y cantidad deben ser datos númericos"
                                    logErr = True
                                End If
                            Else
                                strInfo = strInfo & IIf(strInfo = vbNullString, vbNullString, vbCr) & "Linea " & (i + 1) & ": no se cumple con el formato n°/cantidad[...,n°/cantidad] "
                                logErr = True
                            End If
                        Else
                            strInfo = strInfo & IIf(strInfo = vbNullString, vbNullString, vbCr) & "Linea " & (i + 1) & ": no se cumple con el formato n°/cantidad[...,n°/cantidad] "
                            logErr = True
                        End If
                        If logErr = True Then
                            Exit For
                        End If
                    Next
                    If Not logErr Then
                        If Not (dblSuma).ToString(FORMATO_MONEDA) = (dgDetalle.Rows(i).Cells("colDespacho").Value).ToString(FORMATO_MONEDA) Then
                            strInfo = strInfo & IIf(strInfo = vbNullString, vbNullString, vbCr) & "Linea " & (i + 1) & ": la suma de cantidades(" & (dblSuma).ToString(FORMATO_MONEDA) & ") difiere del detalle"
                            logErr = True
                        End If
                    End If
                    If logErr Then
                        j = j +
                        strTemp = strTemp & IIf(strTemp = vbNullString, vbNullString, " , ") & (i + 1)
                    End If
                End If
            Next
            If (j > vbEmpty) Then
                strMensaje = strMensaje & IIf(strMensaje = vbNullString, vbNullString, vbCr & vbCr) & "Check the form of distribution for " & IIf(j = 1, "the line", "the lines") & ": " & strTemp & vbCr & vbCr & strInfo
            End If

            If (strMensaje = vbNullString) Then
                ComprobarLineas = True
            Else
                MsgBox(strMensaje, vbExclamation, "Do Not")
            End If
        End If
        ComprobarLineas = True
    End Function

    'Query para guardar Descargos
    Private Sub GuargarDescargos()
        Dim clsDTLPro As New clsDcmtos_DTL_Pro
        Dim cfun As New clsFunciones
        Dim logResultado As Boolean = True
        Dim intID As Integer

        Try
            For j As Integer = 0 To dgDetalle.Rows.Count - 1
                intID = Val(dgDetalle.Rows(j).Cells("colLinea").Value)
                For i As Integer = vbEmpty To dgReferencia.Rows.Count - 1
                    MyCnn.CONECTAR = strConexion

                    If (Val(dgReferencia.Rows(i).Cells("colID").Value)) = intID Then
                        clsDTLPro.PDOC_SIS_EMP = Sesion.IdEmpresa
                        clsDTLPro.PDOC_PAR_CAT = 48
                        clsDTLPro.PDOC_PAR_ANO = dgDetalle.Rows(j).Cells("colAño").Value
                        clsDTLPro.PDOC_PAR_NUM = dgDetalle.Rows(j).Cells("colNum").Value
                        clsDTLPro.PDOC_PAR_LIN = dgDetalle.Rows(j).Cells("colLinea").Value
                        clsDTLPro.PDOC_CHI_CAT = 36
                        clsDTLPro.PDOC_CHI_ANO = Val(celdaAño.Text)
                        clsDTLPro.PDOC_CHI_NUM = Val(celdaNumero.Text)
                        clsDTLPro.PDOC_CHI_LIN = i + 1
                        clsDTLPro.PDOC_PROV_COD = Val(celdaIdCliente.Text)
                        clsDTLPro.PDOC_PRD_COD = dgDetalle.Rows(j).Cells("colCode").Value
                        clsDTLPro.PDOC_PRD_NET = dgDetalle.Rows(j).Cells("colPrecio").Value
                        clsDTLPro.PDOC_QTY_ORD = dgDetalle.Rows(j).Cells("colCantidad").Value
                        clsDTLPro.PDOC_QTY_PRO = dgDetalle.Rows(j).Cells("colCantidad").Value

                        If Me.Tag = "Mod" Then
                            If clsDTLPro.Actualizar() = False Then
                                MsgBox(clsDTLPro.MERROR.ToString)
                            End If
                            'MostrarLista(INT_UNO)

                        Else
                            Me.Tag = "Nuevo"
                            If clsDTLPro.Guardar() = False Then
                                MsgBox(clsDTLPro.MERROR.ToString)
                            End If
                            'MostrarLista(INT_UNO)
                        End If

                    End If
                Next
            Next

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try

    End Sub

    'Query para guardar Datos Encabezado
    Private Function GuardarDocumento() As Boolean
        Dim strSQL As String
        Dim intNumero As Integer
        Dim logResultado As Boolean = True
        Dim COM As New MySqlCommand
        Dim conec As New MySqlConnection

        strSQL = " SELECT ifnull(MAX(HDoc_DR1_Dbl),0)+1"
        strSQL &= "     FROM Dcmtos_HDR"
        strSQL &= "         WHERE HDoc_Sis_Emp ={empresa} and HDoc_Doc_Cat = 296 and HDoc_DR2_Num = '{serie}'"

        If Sesion.IdEmpresa = 8 Then
            strSQL = Replace(strSQL, "{serie}", 3)
        Else
            strSQL = Replace(strSQL, "{serie}", celdaSerie.Text)
        End If
        strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)

        conec = New MySqlConnection(strConexion)
        conec.Open()
        COM = New MySqlCommand(strSQL, conec)
        intNumero = COM.ExecuteScalar
        conec.Close()
        Try
            Dim chdr As New clsDcmtos_HDR
            chdr.CONEXION = strConexion

            chdr.HDOC_SIS_EMP = celdaEmpresa.Text
            chdr.HDOC_DOC_CAT = celdaTipo.Text
            chdr.HDOC_DOC_ANO = celdaAño.Text
            chdr.HDOC_DOC_NUM = celdaNumero.Text
            chdr.HDoc_Doc_Fec_NET = dtpFecha.Value.ToString(FORMATO_MYSQL)

            chdr.HDOC_DR1_DBL = intNumero

            chdr.HDOC_EMP_COD = celdaIdCliente.Text
            chdr.HDOC_EMP_NOM = celdaCliente.Text
            chdr.HDOC_EMP_DIR = celdaDireccion.Text
            chdr.HDOC_EMP_TEL = celdaTelefono.Text
            chdr.HDOC_EMP_NIT = celdaNIT.Text

            chdr.HDOC_DOC_MON = celdaIdMoneda.Text
            chdr.HDOC_DOC_TC = celdaTasa.Text

            chdr.HDOC_RF1_DBL = celdaFlete.Text
            chdr.HDOC_RF1_NUM = IIf(checkDetGatos.Checked = True, 1, vbEmpty)
            chdr.HDOC_RF2_DBL = celdaSeguro.Text

            chdr.HDOC_DR1_CAT = IIf(rbNacionalizacion.Checked, vbEmpty, 1) 'Tipo: venta/exportación
            chdr.HDOC_DR1_NUM = GetReferencia()
            chdr.HDOC_RF1_COD = 0

            chdr.HDOC_DR2_CAT = vbEmpty
            If celdaEmpresa.Text = 8 Then
                chdr.HDOC_DR2_NUM = "003"
            Else
                chdr.HDOC_DR2_NUM = celdaSerie.Text
            End If

            chdr.HDOC_DR2_EMP = IIf(logImpuesto, INT_UNO, vbEmpty) 'Pago de impuestos

            'DR1_Emp y RF2_Num se utilizan en el Yarn Movement para Cliente y Días
            chdr.HDOC_DR1_EMP = intRefID
            chdr.HDOC_RF2_NUM = intRefDias
            chdr.HDOC_RF2_COD = celdaCargado.Text

            chdr.HDOC_USUARIO = celdaUsuario.Text
            chdr.HDOC_DOC_STATUS = IIf(checkActivar.Checked = True, 1, vbEmpty)

            'No permitir modificaciones si ya fue impreso
            logPrinted = (Val(vbNullString & chdr.HDOC_DR2_CAT) > vbEmpty)
            logImpuesto = Not (Val(vbNullString & chdr.HDOC_DR2_EMP) = vbEmpty)
            If logImpuesto Then
                logLibre = Not IsDBNull(chdr.HDOC_DR2_FEC)
            Else
                logLibre = True
            End If

            If logPrinted Then

                celdaFlete.Text = Enabled
                celdaSeguro.Text = Enabled
            End If

            If Me.Tag = "Mod" Then
                If chdr.Actualizar() = False Then
                    MsgBox(chdr.MERROR.ToString & "Could not update the document", MsgBoxStyle.Critical)
                End If
                'MostrarLista(INT_UNO)

            Else
                If chdr.Guardar() = False Then
                    MsgBox(chdr.MERROR.ToString & "Could not save the document", MsgBoxStyle.Critical)
                End If
                'MostrarLista(INT_UNO)

            End If

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        Return logResultado
    End Function

    'Query para guardar el Detalle
    Private Function GuardarDetalle() As Boolean
        Dim logResultado As Boolean = True
        Dim Dtl As New clsDcmtos_DTL
        Dtl.CONEXION = strConexion

        Try
            For i As Integer = 0 To dgDetalle.Rows.Count - 1
                Dtl.DDOC_SIS_EMP = celdaEmpresa.Text
                Dtl.DDOC_DOC_CAT = celdaTipo.Text
                Dtl.DDOC_DOC_ANO = celdaAño.Text
                Dtl.DDOC_DOC_NUM = celdaNumero.Text
                Dtl.DDOC_DOC_LIN = i + 1

                Dtl.DDOC_PRD_COD = dgDetalle.Rows(i).Cells("colCode").Value
                Dtl.DDOC_PRD_DES = dgDetalle.Rows(i).Cells("colDescrip").Value
                Dtl.DDOC_PRD_UM = dgDetalle.Rows(i).Cells("colBase").Value

                Dtl.DDOC_PRD_PUQ = dgDetalle.Rows(i).Cells("colPrecio").Value
                Dtl.DDOC_PRD_DSP = dgDetalle.Rows(i).Cells("colDesc").Value
                Dtl.DDOC_PRD_DSQ = dgDetalle.Rows(i).Cells("colDescDolar").Value
                Dtl.DDOC_PRD_NET = dgDetalle.Rows(i).Cells("colPrecio").Value
                Dtl.DDOC_PRD_QTY = dgDetalle.Rows(i).Cells("colCantidad").Value

                Dtl.DDOC_RF1_DBL = dgDetalle.Rows(i).Cells("colLBS").Value
                Dtl.DDOC_RF2_DBL = dgDetalle.Rows(i).Cells("colKGS").Value

                Dtl.DDOC_RF1_COD = dgDetalle.Rows(i).Cells("colOriginal").Value
                Dtl.DDOC_RF1_NUM = dgDetalle.Rows(i).Cells("colCodLugar").Value
                Dtl.DDOC_RF1_TXT = dgDetalle.Rows(i).Cells("colReferences").Value

                Dtl.DDOC_RF2_NUM = dgDetalle.Rows(i).Cells("colBobina").Value
                Dtl.DDOC_RF2_COD = dgDetalle.Rows(i).Cells("colDistribucion").Value
                Dtl.DDOC_RF2_TXT = dgDetalle.Rows(i).Cells("colTipoBulto").Value

                Dtl.DDOC_RF3_NUM = dgDetalle.Rows(i).Cells("colBase").Value
                Dtl.DDOC_RF3_DBL = dgDetalle.Rows(i).Cells("colDespacho").Value

                If Me.Tag = "Mod" Then
                    If Dtl.Actualizar() = False Then
                        MsgBox(Dtl.MERROR.ToString & "Could not update the document", MsgBoxStyle.Critical)
                    End If
                    'MostrarLista(INT_UNO)
                Else
                    If Dtl.Guardar() = False Then
                        MsgBox(Dtl.MERROR.ToString & "Could not save the document", MsgBoxStyle.Critical)
                    End If
                    'MostrarLista(INT_UNO)

                End If
            Next

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        Return logResultado
    End Function

    'Guarda los bultos/cajas de este documento
    Private Function GuardarBultos() As Boolean
        Dim logResultado As Boolean = True
        Dim DtlBox As New Tablas.TDCMTOS_DTL_BOX
        'Const I_CODIGO As Integer = 1
        'Const I_CAJA As Integer = 2
        'Const I_CANTIDAD As Integer = 3
        Dim varDato As String = STR_VACIO

        DtlBox.CONEXION = strConexion
        Try
            For i As Integer = 0 To dgDetalle.Rows.Count - 1
                DtlBox.BDOC_SIS_EMP = celdaEmpresa.Text
                DtlBox.BDOC_DOC_CAT = celdaTipo.Text
                DtlBox.BDOC_DOC_ANO = celdaAño.Text
                DtlBox.BDOC_DOC_NUM = celdaNumero.Text
                DtlBox.BDOC_DOC_LIN = dgDetalle.Rows(i).Cells("colLinea").Value
                DtlBox.BDOC_BOX_LIN = dgDetalle.Rows(i).Cells("colLinea2").Value
                DtlBox.BDOC_BOX_COD = dgDetalle.Rows(i).Cells("colCode").Value
                DtlBox.BDOC_BOX_QTY = dgDetalle.Rows(i).Cells("colBulto").Value
                DtlBox.BDOC_BOX_LB = dgDetalle.Rows(i).Cells("colCantidad").Value
            Next

            If Me.Tag = "Mod" Then
                If DtlBox.PUPDATE = False Then
                    MsgBox(DtlBox.MERROR.ToString & "Could not update the document", MsgBoxStyle.Critical)
                End If
                'MostrarLista(INT_UNO)

            Else
                If DtlBox.PINSERT = False Then
                    MsgBox(DtlBox.MERROR.ToString & "Could not save the document", MsgBoxStyle.Critical)
                End If
                'MostrarLista(INT_UNO)

            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        Return logResultado
    End Function

    Private Function GuardarOperacion() As Boolean
        'Guarda el débito del documento
        Dim logResultado As Boolean = True

        Dim datFecha As Date
        Dim datVence As Date

        Dim dblDebito As Double
        Dim dblCredito As Double
        Dim dblTasa As Double

        Dim intFila As Integer
        Dim intDias As Integer

        Dim strSQL As String = STR_VACIO
        Dim strDato As String = STR_VACIO

        Dim Ectacte As New Tablas.TECTACTE

        Try

            'Ejecuta la transacción (borrado)
            strSQL = "DELETE FROM ECtaCte "
            strSQL &= "WHERE ECta_Sis_Emp = {empresa} AND ECta_Doc_Cat = {catalogo} AND ECta_Doc_Ano = {año} AND ECta_Doc_Num = {numero}"

            strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
            strSQL = Replace(strSQL, "{catalogo}", celdaTipo.Text)
            strSQL = Replace(strSQL, "{año}", celdaAño.Text)
            strSQL = Replace(strSQL, "{numero}", celdaNumero.Text)


            'Escribe la operación (débito/crédito)
            intDias = PlazoDeCredito(Val(celdaIdCliente.Text))
            datFecha = dtpFecha.Value.ToString(FORMATO_MYSQL)
            datVence = DateAdd("d", intDias, datFecha)

            intFila = vbEmpty
            intFila = intFila + 1

            dblTasa = Val(celdaTasa.Text)
            dblCredito = vbEmpty
            dblDebito = vbEmpty

            If checkActivar.Checked = True Then
                'Sólo si no está anulada
                dblDebito = Val(celdaTotal1.Text)
            End If

            Ectacte.CONEXION = strConexion
            'Id. del documento
            Ectacte.ECTA_SIS_EMP = Val(celdaEmpresa.Text)
            Ectacte.ECTA_DOC_ANO = Val(celdaAño.Text)
            Ectacte.ECTA_DOC_CAT = Val(celdaTipo.Text)
            Ectacte.ECTA_DOC_NUM = Val(celdaNumero.Text)
            Ectacte.ECTA_DOC_LIN = intFila

            'Empresa
            Ectacte.ECTA_TIPOEMP = STR_TABLA
            Ectacte.ECTA_CODEMP = Val(celdaIdCliente.Text)

            'Cargo/Abono
            Ectacte.ECTA_SINI_LOC = vbEmpty
            Ectacte.ECTA_CRGO_LOC = (dblDebito * dblTasa).ToString(FORMATO_MONEDA)
            Ectacte.ECTA_ABNO_LOC = (dblCredito * dblTasa).ToString(FORMATO_MONEDA)
            Ectacte.ECTA_SINI_EXT = vbEmpty
            Ectacte.ECTA_CRGO_EXT = dblDebito.ToString(FORMATO_MONEDA)
            Ectacte.ECTA_ABNO_EXT = dblCredito.ToString(FORMATO_MONEDA)

            For i As Integer = 0 To dgReferencia.Rows.Count - 1
                strDato = CXC_NAME & "N° " & Val(celdaNumero.Text) & "/" & dgReferencia.Rows(i).Cells("colReference").Value
            Next

            'Concepto, vencimiento y moneda
            Ectacte.ECTA_CONCEPTO = strDato
            Ectacte.ECta_FecDcmt_NET = datFecha
            Ectacte.ECta_FecVenc_NET = datVence
            Ectacte.ECTA_MONEDA = Val(celdaIdMoneda.Text)
            Ectacte.ECTA_TC = Val(celdaTasa.Text)

            'Referencia
            Ectacte.ECTA_REF_CAT = celdaTipo.Text
            Ectacte.ECTA_REF_ANO = celdaAño.Text
            Ectacte.ECTA_REF_NUM = celdaNumero.Text

            If Me.Tag = "Mod" Then
                If Ectacte.PUPDATE = False Then
                    MsgBox(Ectacte.MERROR.ToString & "Could not update the document", MsgBoxStyle.Critical)
                End If
                'MostrarLista(INT_UNO)

            Else
                If Ectacte.PINSERT = False Then
                    MsgBox(Ectacte.MERROR.ToString & "Could not save the document", MsgBoxStyle.Critical)
                End If
                'MostrarLista(INT_UNO)

            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        Return logResultado
    End Function

    Private Function PlazoDeCredito(ByVal ID As Long) As Integer
        Dim strSQL As String
        Dim strTemp As String
        Dim COM As New MySqlCommand
        Dim conec As New MySqlConnection

        strSQL = "   SELECT cli_plazoCR"
        strSQL &= "     FROM Clientes"
        strSQL &= "          WHERE cli_codigo = {id} AND cli_sisemp = {empresa}"

        strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
        strSQL = Replace(strSQL, "{id}", ID)


        'COM = New MySqlCommand(strSQL, CON)
        'strTemp = COM.ExecuteScalar

        conec = New MySqlConnection(strConexion)
        conec.Open()
        COM = New MySqlCommand(strSQL, conec)
        strTemp = COM.ExecuteScalar
        conec.Close()

        Return strTemp
    End Function

    'Comprueba si alguna de las instrucciones de despacho tiene pago de impuestos
    Private Function PagoDeImpuestos() As Boolean
        Dim i As Integer, j As Integer
        Dim strTemp As String = STR_VACIO
        Dim strSQL As String, strDato As String = STR_VACIO
        Dim logEx As Boolean, logSi As Boolean
        Dim COM As MySqlCommand
        'Dim conec As MySqlConnection

        '0 - número / 4 - año
        j = vbEmpty
        For i = vbEmpty To dgFacturacion.Rows.Count - 1
            j = j + 1
            If Val(dgFacturacion.Rows(i).Cells("colAñ").Value) > vbEmpty Then
                strTemp = IIf(strTemp = vbNullString, vbNullString, " OR ")
                strTemp &= "(HDoc_Doc_Ano={año} AND HDoc_Doc_Num={numero})"

                strTemp = Replace(strTemp, "{año}", Val(dgFacturacion.Rows(i).Cells("colAñ").Value))
                strTemp = Replace(strTemp, "{numero}", Val(dgFacturacion.Rows(i).Cells("colFact").Value))
            End If
        Next

        If Not (strTemp = vbNullString) Then

            strSQL = "SELECT IFNULL(CAST(GROUP_CONCAT(CONCAT('#',HDoc_Doc_Num) SEPARATOR ', ') AS CHAR),0)"
            strSQL &= "FROM Dcmtos_HDR "
            strSQL &= "WHERE HDoc_DR1_Emp = 1 And HDoc_Sis_Emp={empresa} AND HDoc_Doc_Cat= 36 "

            strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)

            'conec = New MySqlConnection(strConexion)
            'conec.Open()
            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSQL, CON)
            strDato = COM.ExecuteScalar
            'conec.Close()
            logSi = Not (strDato = vbNullString)
        End If

        If logSi Then
            If Not rbNacionalizacion.Checked Then
                rbNacionalizacion.Checked = True
                MsgBox("It has changed the type of bill to nationalize", vbInformation, "Tax payment")
            End If
            logEx = True
        End If
        PagoDeImpuestos = logEx
    End Function

    Private Sub InstruccionDespachada()
        Dim strSQL As String = STR_VACIO
        Dim strInstrucciones As String = STR_VACIO
        Dim r As Integer
        Dim COM As MySqlCommand
        Dim conec As MySqlConnection

        Try
            r = 0
            strSQL = "Select ifnull(max(HDoc_RF2_Cod),0) carga "
            strSQL &= "from Dcmtos_HDR where HDoc_Sis_Emp = {empresa} and HDoc_Doc_Cat = {cat} and HDoc_Doc_Num in({inst})"

            If dgFacturacion.RowCount = 1 Then
                strInstrucciones = dgFacturacion.Rows(0).Cells("colFact").Value
            Else
                For r = 0 To dgFacturacion.Rows.Count - 1
                    If strInstrucciones = "0" Then
                        strInstrucciones = dgFacturacion.Rows(r).Cells("colFact").Value
                    Else
                        strInstrucciones = strInstrucciones & dgFacturacion.Rows(r).Cells("colFact").Value
                    End If
                Next
            End If
            strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
            strSQL = Replace(strSQL, "{cat}", 48)
            strSQL = Replace(strSQL, "{inst}", strInstrucciones)

            conec = New MySqlConnection(strConexion)
            conec.Open()
            COM = New MySqlCommand(strSQL, conec)
            celdaCargado.Text = COM.ExecuteScalar
            conec.Close()
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub DatosDeCliente()
        Dim strSQL As String = STR_VACIO
        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader
        intRefID = vbEmpty
        intRefDias = vbEmpty

        If dgFacturacion.Rows.Count > vbEmpty Then
            strSQL = vbNullString
            strSQL &= "SELECT COALESCE(e.HDoc_DR1_Emp,0) id, IFNULL(c.cli_plazoCR,0) dias "
            strSQL &= "     FROM Dcmtos_DTL d "
            strSQL &= "         LEFT JOIN Dcmtos_DTL_Pro p ON p.PDoc_Sis_Emp=d.DDoc_Sis_Emp AND p.PDoc_Chi_Cat=d.DDoc_Doc_Cat AND p.PDoc_Par_Cat= 75 AND p.PDoc_Chi_Ano=d.Ddoc_Doc_Ano AND p.PDoc_Chi_Num=d.DDoc_Doc_Num AND p.PDoc_Chi_Lin=d.DDoc_Doc_Lin "
            strSQL &= "             LEFT JOIN Dcmtos_HDR e ON e.HDoc_Sis_Emp=p.PDoc_Sis_Emp AND e.HDoc_Doc_Cat=p.PDoc_Par_Cat AND e.HDoc_Doc_Ano=p.PDoc_Par_Ano AND e.HDoc_Doc_Num=p.PDoc_Par_Num"
            strSQL &= "                  LEFT JOIN Clientes c ON c.cli_sisemp=d.DDoc_Sis_Emp AND c.cli_codigo=e.HDoc_DR1_Emp"
            strSQL &= "             WHERE d.DDoc_Sis_Emp={empresa} AND d.DDoc_Doc_Cat= 48 AND d.DDoc_Doc_Ano={año} AND d.DDoc_Doc_Num={numero} "
            strSQL &= "         LIMIT 1"

            strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
            strSQL = Replace(strSQL, "{año}", dgFacturacion.SelectedCells(1).Value)
            strSQL = Replace(strSQL, "{numero}", dgFacturacion.SelectedCells(2).Value)

            MyCnn.CONECTAR = strConexion

            COM = New MySqlCommand(strSQL, CON)
            REA = COM.ExecuteReader
            If REA.Read Then
                intRefID = REA.GetInt32("id")
                intRefDias = REA.GetInt32("dias")
            End If
        End If
    End Sub

    'Obtiene la existencia para la línea
    Private Function ObtenerExistencia(ByVal ID As Integer) As Double
        Dim i As Integer
        Dim COL_KGS As String = STR_VACIO
        Dim strLineas As String = STR_VACIO
        Dim dblSaldo As Double

        For i = 0 To dgReferencia.Rows.Count - 1
            'Si la referencia corresponde a la línea
            If Val(dgReferencia.Rows(i).Cells("colID").Value) = ID Then
                COL_KGS = dgReferencia.Rows(i).Cells("colAno").Value & ","
                COL_KGS &= dgReferencia.Rows(i).Cells("colNumber").Value & ","
                COL_KGS &= dgReferencia.Rows(i).Cells("colLine").Value

                'Si no se ha sumado
                If InStr(1, strLineas, COL_KGS) = vbEmpty Then
                    dblSaldo = dblSaldo + Val(dgReferencia.Rows(i).Cells("colDisponible").Value)
                    strLineas = strLineas & vbNullChar & COL_KGS
                End If
            End If
        Next
        ObtenerExistencia = dblSaldo
    End Function

    'Actualiza la línea del detalle de la instrucción
    Private Sub ActualizarDetalle(ByVal Filas As Integer)
        'Documento: 48/Instrucción de despacho
        'Datos:     DSP/Existencia, QTY/A despachar
        Dim strSQL As String
        Dim COM As New MySqlCommand
        For i As Integer = 0 To dgDetalle.Rows.Count - 1
            If Val(dgDetalle.Rows(i).Cells("colAño").Value) > vbEmpty And Val(dgDetalle.Rows(i).Cells("colNum").Value) > vbEmpty And Val(dgDetalle.Rows(i).Cells("colLinea").Value) Then
                'Plantilla de la consulta
                strSQL = "   UPDATE Dcmtos_DTL "
                strSQL &= "     SET DDoc_Prd_DSP={0},DDoc_Prd_QTY={1},DDoc_RF3_Dbl={2}"
                strSQL &= "          WHERE DDoc_Sis_Emp={3} AND DDoc_Doc_Cat={4} AND DDoc_Doc_Ano={5} AND DDoc_Doc_Num={6} AND DDoc_Doc_Lin={7}"
                If Sesion.IdEmpresa = 18 Then
                    strSQL &= ";   UPDATE PDM.Dcmtos_DTL "
                    strSQL &= "     SET DDoc_Prd_DSP={0},DDoc_Prd_QTY={1},DDoc_RF3_Dbl={2}"
                    strSQL &= "          WHERE DDoc_Sis_Emp={3} AND DDoc_Doc_Cat={4} AND DDoc_Doc_Ano={5} AND DDoc_Doc_Num={6} AND DDoc_Doc_Lin={7}"
                End If

                'Reemplaza los parámetros de la plantilla
                strSQL = Replace(strSQL, "{0}", ObtenerExistencia(dgDetalle.Rows(i).Cells("colNum").Value))
                strSQL = Replace(strSQL, "{1}", dgDetalle.Rows(i).Cells("colCantidad").Value)
                strSQL = Replace(strSQL, "{2}", dgDetalle.Rows(i).Cells("colDespacho").Value)
                strSQL = Replace(strSQL, "{3}", Sesion.IdEmpresa)
                strSQL = Replace(strSQL, "{4}", 48)
                strSQL = Replace(strSQL, "{5}", dgDetalle.Rows(i).Cells("colAño").Value)
                strSQL = Replace(strSQL, "{6}", dgDetalle.Rows(i).Cells("colNum").Value)
                strSQL = Replace(strSQL, "{7}", dgDetalle.Rows(i).Cells("colLinea").Value)

                'Ejecuta la instrucción
                MyCnn.CONECTAR = strConexion
                COM = New MySqlCommand(strSQL, CON)
                COM.ExecuteNonQuery()
            End If
        Next
    End Sub

    'Reescribe los registros que descargan del ingreso
    Private Sub ActualizarDescargos(ByVal Filas As Integer)
        'Parent: 47/Ingreso a bodega
        'Child:  48/Instrucción de despacho
        'Datos:  Ord/Existencia, Pro/Descargo
        Dim i As Integer
        Dim dblCantidad As Double
        Dim intID As Integer
        Dim strSQL As String
        Dim strOrden As String = STR_VACIO
        Dim strTemp As String = STR_VACIO
        Dim COM As New MySqlCommand

        'Pantilla de la consulta de act. del descargo a ingreso
        strSQL = "   UPDATE Dcmtos_DTL_Pro "
        strSQL &= "     SET PDoc_QTY_Ord={0},PDoc_QTY_Pro={1}"
        strSQL &= "          WHERE PDoc_Sis_Emp={2} AND PDoc_Par_Cat={3} AND PDoc_Par_Ano={4} AND PDoc_Par_Num={5} AND PDoc_Par_Lin={6} AND PDoc_Chi_Cat={7} AND PDoc_Chi_Ano={8} AND PDoc_Chi_Num={9} AND PDoc_Chi_Lin={10}"
        If Sesion.IdEmpresa = 18 Then
            strSQL &= ";   UPDATE PDM.Dcmtos_DTL_Pro "
            strSQL &= "     SET PDoc_QTY_Ord={0},PDoc_QTY_Pro={1}"
            strSQL &= "          WHERE PDoc_Sis_Emp={2} AND PDoc_Par_Cat={3} AND PDoc_Par_Ano={4} AND PDoc_Par_Num={5} AND PDoc_Par_Lin={6} AND PDoc_Chi_Cat={7} AND PDoc_Chi_Ano={8} AND PDoc_Chi_Num={9} AND PDoc_Chi_Lin={10}"
        End If
        'Plantilla de la consulta de act. del descargo a pedido
        strOrden = "   UPDATE Dcmtos_DTL_Pro "
        strOrden &= "     SET PDoc_QTY_Pro={cantidad}"
        strOrden &= "          WHERE PDoc_Sis_Emp={empresa} AND PDoc_Par_Cat={pedido} AND PDoc_Chi_Cat={tipo} AND PDoc_Chi_Ano={año} AND PDoc_Chi_Num={numero} AND PDoc_Chi_Lin={linea}"
        If Sesion.IdEmpresa = 18 Then
            strOrden &= ";   UPDATE PDM.Dcmtos_DTL_Pro "
            strOrden &= "     SET PDoc_QTY_Pro={cantidad}"
            strOrden &= "          WHERE PDoc_Sis_Emp={empresa} AND PDoc_Par_Cat={pedido} AND PDoc_Chi_Cat={tipo} AND PDoc_Chi_Ano={año} AND PDoc_Chi_Num={numero} AND PDoc_Chi_Lin={linea}"
        End If
        'Obtiene el identificador de la fila
        For j As Integer = 0 To dgDetalle.Rows.Count - 1
            intID = dgDetalle.Rows(j).Cells("colNum").Value
            'Busca las referencias le pertenecen
            For i = 0 To dgReferencia.Rows.Count - 1
                If Val(dgReferencia.Rows(i).Cells("colID").Value) = intID Then
                    'ANTERIOR: Existencia
                    dblCantidad = vbEmpty
                    If checkActivar.Checked = True Then
                        dblCantidad = dgReferencia.Rows(i).Cells("colDescargo").Value
                        If dblCantidad = vbEmpty Then
                            'Reversar anulación
                            dblCantidad = dgReferencia.Rows(i).Cells("coldisponible").Value
                        End If
                    End If

                    'Reemplaza los parámetros de la plantilla de act. de ingreso
                    strTemp = strSQL
                    strTemp = Replace(strTemp, "{0}", dgReferencia.Rows(i).Cells("colDescargo").Value)
                    strTemp = Replace(strTemp, "{1}", dblCantidad)
                    strTemp = Replace(strTemp, "{2}", Sesion.IdEmpresa)
                    strTemp = Replace(strTemp, "{3}", 47)
                    strTemp = Replace(strTemp, "{4}", dgReferencia.Rows(i).Cells("colAno").Value)
                    strTemp = Replace(strTemp, "{5}", dgReferencia.Rows(i).Cells("colNumber").Value)
                    strTemp = Replace(strTemp, "{6}", dgReferencia.Rows(i).Cells("colLine").Value)
                    strTemp = Replace(strTemp, "{7}", 48)
                    strTemp = Replace(strTemp, "{8}", dgDetalle.Rows(j).Cells("colAño").Value)
                    strTemp = Replace(strTemp, "{9}", dgDetalle.Rows(j).Cells("colNum").Value)
                    strTemp = Replace(strTemp, "{10}", dgDetalle.Rows(j).Cells("colLinea").Value)

                    'Ejecuta la instrucción
                    MyCnn.CONECTAR = strConexion
                    COM = New MySqlCommand(strTemp, CON)
                    COM.ExecuteNonQuery()

                    'Reemplaza los parámetros de la plantilla de pedido
                    strTemp = strOrden
                    strTemp = Replace(strTemp, "{cantidad}", IIf(checkActivar.Checked = True, dgReferencia.Rows(i).Cells("colAmount").Value, vbEmpty))
                    strTemp = Replace(strTemp, "{empresa}", Sesion.IdEmpresa)
                    strTemp = Replace(strTemp, "{pedido}", 75)
                    strTemp = Replace(strTemp, "{tipo}", 48)
                    strTemp = Replace(strTemp, "{año}", dgDetalle.Rows(j).Cells("colAño").Value)
                    strTemp = Replace(strTemp, "{numero}", dgDetalle.Rows(j).Cells("colNum").Value)
                    strTemp = Replace(strTemp, "{linea}", dgDetalle.Rows(j).Cells("colLinea").Value)

                    'Ejecuta la instrucción
                    MyCnn.CONECTAR = strConexion
                    COM = New MySqlCommand(strTemp, CON)
                    COM.ExecuteNonQuery()
                End If
            Next
        Next
    End Sub

    'Actualiza los bultos de la instrcción para esta línea
    Private Sub ActualizarBultos(ByVal Fila As Integer)
        Const I_CAJA As Integer = 2
        Const I_CANTIDAD As Integer = 3

        Dim strSQL As String
        Dim varFila As Object = STR_VACIO
        Dim varDato As Object = STR_VACIO
        Dim COM As New MySqlCommand

        For i As Integer = 0 To dgDetalle.Rows.Count - 1
            If Val(dgDetalle.Rows(i).Cells("colAño").Value) > vbEmpty And Val(dgDetalle.Rows(i).Cells("colNum").Value) > vbEmpty And Val(dgDetalle.Rows(i).Cells("colLinea").Value) > vbEmpty Then

                'Plantilla de la consulta
                strSQL = "   UPDATE Dcmtos_DTL_Box  "
                strSQL &= "     SET BDoc_Box_QTY={0}, BDoc_Box_LB={1}"
                strSQL &= "          WHERE BDoc_Sis_Emp={2} AND BDoc_Doc_Cat={3} AND BDoc_Doc_Ano={4} AND BDoc_Doc_Num={5} AND BDoc_Doc_Lin={6} AND BDoc_Box_Lin=1"
                If Sesion.IdEmpresa = 18 Then
                    strSQL &= ";   UPDATE PDM.Dcmtos_DTL_Box  "
                    strSQL &= "     SET BDoc_Box_QTY={0}, BDoc_Box_LB={1}"
                    strSQL &= "          WHERE BDoc_Sis_Emp={2} AND BDoc_Doc_Cat={3} AND BDoc_Doc_Ano={4} AND BDoc_Doc_Num={5} AND BDoc_Doc_Lin={6} AND BDoc_Box_Lin=1"
                End If
                'Reemplaza los parámetros de la plantilla
                strSQL = Replace(strSQL, "{0}", I_CAJA)
                strSQL = Replace(strSQL, "{1}", I_CANTIDAD)
                strSQL = Replace(strSQL, "{2}", Sesion.IdEmpresa)
                strSQL = Replace(strSQL, "{3}", 48)
                strSQL = Replace(strSQL, "{4}", dgDetalle.Rows(i).Cells("colAño").Value)
                strSQL = Replace(strSQL, "{5}", dgDetalle.Rows(i).Cells("colNum").Value)
                strSQL = Replace(strSQL, "{6}", dgDetalle.Rows(i).Cells("colLinea").Value)

                'Ejecuta la instrucción
                MyCnn.CONECTAR = strConexion
                COM = New MySqlCommand(strSQL, CON)
                COM.ExecuteNonQuery()
            End If
        Next

    End Sub

    'Actualiza el valor descargado en el Kardex para la línea de la instrucción
    Private Sub RegistrarExistencia(ByVal Fila As Integer)
        'Documento: 48/Instrucción de despacho
        Dim COM As New MySqlCommand
        Dim REA As MySqlDataReader
        Dim dblSalida As Double
        Dim dblBultos As Double
        Dim lngId As Long
        Dim strCodigo As String
        Dim strTemp As String

        Dim varFila As Object
        Dim varDato As Object
        Dim strSQL As String = STR_VACIO

        For i As Integer = 0 To dgDetalle.Rows.Count - 1
            'Determina la cantidad de bultos (para esta línea)
            dblBultos = vbEmpty

            'Sólo si el documento está activo
            'If checkActivar.Checked = True Then
            '    varFila = Split()
            'End If

            'Sólo si el documento está activo
            strSQL = "  SELECT * "
            strSQL &= "     FROM Existencia"
            strSQL &= "          WHERE Ex_Doc_Emp={empresa} AND Ex_Doc_Tipo={tipo} AND Ex_Doc_Ciclo={año} AND Ex_Doc_Num={numero} AND Ex_Doc_Lin={linea}"

            'Reemplaza los parámetros de la plantilla
            strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
            strSQL = Replace(strSQL, "{tipo}", 48) '/Instruccion de Despacho
            strSQL = Replace(strSQL, "{año}", dgDetalle.Rows(i).Cells("colAño").Value)
            strSQL = Replace(strSQL, "{numero}", dgDetalle.Rows(i).Cells("colNum").Value)
            strSQL = Replace(strSQL, "{linea}", dgDetalle.Rows(i).Cells("colLinea").Value)

            'Ejecuta la instrucción
            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSQL, CON)
            REA = COM.ExecuteReader

            'Verifica si la factura ha escrito en existencia
            strSQL = "  SELECT COUNT(*)  "
            strSQL &= "     FROM Existencia "
            strSQL &= "          WHERE Ex_Doc_Emp={empresa} AND Ex_Doc_Tipo={tipo} AND Ex_Doc_Ciclo={año} AND Ex_Doc_Num={numero} AND Ex_Doc_Lin={linea}"

            'Reemplaza los parámetros de la plantilla
            strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
            strSQL = Replace(strSQL, "{tipo}", 36) '/Facturación
            strSQL = Replace(strSQL, "{año}", dgDetalle.Rows(i).Cells("colAño").Value)
            strSQL = Replace(strSQL, "{numero}", dgDetalle.Rows(i).Cells("colNum").Value)
            strSQL = Replace(strSQL, "{linea}", i + 1)

            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSQL, CON)
            strSQL = COM.ExecuteScalar()

            'Si no hay registros en existencia, los escribe con los valores de la instrucción
            Try
                If REA.HasRows Then
                    strSQL = "SELECT (IFNULL(MAX(Ex_Id),0) + 1) ID FROM Existencia"
                    MyCnn.CONECTAR = strConexion
                    COM = New MySqlCommand(strSQL, CON)
                    lngId = COM.ExecuteScalar()
                Else
                    Dim Exis As New Tablas.TEXISTENCIA
                    Do While REA.Read
                        Exis.EX_DOC_EMP = Sesion.IdEmpresa
                        Exis.EX_DOC_TIPO = 36
                        Exis.EX_DOC_CICLO = Val(celdaAño.Text)
                        Exis.EX_DOC_NUM = Val(celdaNumero.Text)
                        Exis.Ex_Fec_NET = dtpFecha.Value.ToString(FORMATO_MYSQL)
                        Exis.EX_DOC_LIN = i + 1
                        Exis.Ex_Fec_NET = MYSQL_HOY
                        Exis.EX_ID = lngId
                        Exis.EX_ARTICULO = REA.GetString("Ex_Articulo")
                        Exis.EX_CODIGO = REA.GetInt32("Ex_Codigo")
                        Exis.EX_DESCRIPCION = REA.GetString("Ex_Descripcion")
                        Exis.EX_PAIS = REA.GetString("Ex_Pais")
                        Exis.EX_REFERENCIA = REA.GetString("Ex_Referencia")
                        Exis.EX_LOTE = REA.GetInt32("Ex_Lote")
                        Exis.EX_CICLO = REA.GetInt32("Ex_Ciclo")
                        Exis.EX_SEMANA = REA.GetInt32("Ex_Semana")
                        Exis.EX_UM = REA.GetInt32("Ex_UM")
                        Exis.EX_INGRESO = vbEmpty
                        Exis.EX_EGRESO = REA.GetDouble("Ex_Egreso")
                        Exis.EX_BULTOS = dblBultos
                        Exis.EX_MONEDA = Val(celdaIdMoneda.Text)
                        Exis.EX_TC = Val(celdaTasa.Text)
                        Exis.EX_COSTO = REA.GetDouble("Ex_Costo")
                        Exis.EX_TOTAL = REA.GetDouble("Ex_Total")

                        lngId = lngId + 1
                    Loop
                End If


            Catch ex As Exception

            End Try

        Next

    End Sub

    'Reescribe los registros de las instrucciones de despacho
    Private Sub ReescribirInstruccion()
        Dim i As Integer

        'Recorre el detalle de la factura
        For i = 0 To dgDetalle.Rows.Count - 1
            'Actualiza el detalle
            ActualizarDetalle(i)
            'Actualiza los registros en DTL Pro
            ActualizarDescargos(i)
            'Actualizar bultos
            ActualizarBultos(i)
            'Actualiza el valor descargado en el Kardex
            RegistrarExistencia(i)
        Next
        'Actualiza el estado de las instrucciones afectadas
        ActualizarEstado()
    End Sub

    'Actualiza el estado de las 48/instrucciónes de acuerdo al estado de la factura
    Private Sub ActualizarEstado()
        Dim strSQL As String = STR_VACIO
        Dim strTemp As String = STR_VACIO
        Dim COM As New MySqlCommand
        Dim REA As MySqlDataReader

        'Selecciona las instrucciones atendidas por esta factura
        strSQL = "SELECT p.PDoc_Par_Cat, p.PDoc_Par_Ano, p.PDoc_Par_Num"
        strSQL &= " FROM Dcmtos_DTL_Pro p WHERE p.PDoc_Sis_Emp={empresa} AND p.PDoc_Chi_Cat={tipo} AND p.PDoc_Chi_Ano={año} AND p.PDoc_Chi_Num={numero}"
        strSQL &= "     GROUP BY p.PDoc_Par_Cat, p.PDoc_Par_Ano, p.PDoc_Par_Num"

        strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
        strSQL = Replace(strSQL, "{tipo}", celdaTipo.Text)
        strSQL = Replace(strSQL, "{año}", celdaAño.Text)
        strSQL = Replace(strSQL, "{numero}", celdaNumero.Text)

        MyCnn.CONECTAR = strConexion
        COM = New MySqlCommand(strSQL, CON)
        REA = COM.ExecuteReader

        Try
            If REA.HasRows Then
                Do While REA.Read
                    'Acturaliza la instrucción
                    strTemp = " UPDATE Dcmtos_HDR h SET h.HDoc_Doc_Status={estado}"
                    strTemp &= "    WHERE h.HDoc_Sis_Emp={empresa} AND h.HDoc_Doc_Cat={tipo} AND h.HDoc_Doc_Ano={año} AND h.HDoc_Doc_Num={numero}"
                    If Sesion.IdEmpresa = 18 Then
                        strTemp &= "; UPDATE PDM.Dcmtos_HDR h SET h.HDoc_Doc_Status={estado}"
                        strTemp &= "    WHERE h.HDoc_Sis_Emp={empresa} AND h.HDoc_Doc_Cat={tipo} AND h.HDoc_Doc_Ano={año} AND h.HDoc_Doc_Num={numero}"
                    End If
                    strTemp = Replace(strTemp, "{estado}", IIf(checkActivar.Checked = True, 1, 0))
                    strTemp = Replace(strTemp, "{empresa}", Sesion.IdEmpresa)
                    strTemp = Replace(strTemp, "{tipo}", REA.GetInt32("PDoc_Par_Cat"))
                    strTemp = Replace(strTemp, "{año}", REA.GetInt32("PDoc_Par_Ano"))
                    strTemp = Replace(strTemp, "{numero}", REA.GetInt32("PDoc_Par_Num"))
                Loop
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    'Actualiza el listado de referencias
    Private Sub ActualizarLista()
        Dim i As Integer
        Dim dblSaldo As Double
        Dim strLineas As String = STR_VACIO
        Dim strSQL As String = STR_VACIO
        Dim strTemp As String
        Dim COM As MySqlCommand
        'Si hay referencias

        If (dgReferencia.ColumnCount > vbEmpty) Then
            For i = 0 To dgReferencia.Rows.Count - 1
                'Si no se tiene el saldo actual
                If dgReferencia.Rows(i).Cells("colAmount").Value = vbNullString Then
                    'Identificador de ingreso a bodega

                    strTemp = dgReferencia.Rows(i).Cells("colAno").Value & ","
                    strTemp &= dgReferencia.Rows(i).Cells("colNumber").Value & ","
                    strTemp &= dgReferencia.Rows(i).Cells("colLine").Value & "," & "{saldo}"

                    'Si no está en el listado
                    If InStr(1, strLineas, strTemp) = vbEmpty Then
                        strSQL = " SELECT d.DDoc_Prd_QTY "
                        strSQL &= "     COALESCE((SELECT SUM(p.PDoc_QTY_Pro)"
                        strSQL &= "         FROM Dcmtos_DTL_Pro p"
                        strSQL &= "              WHERE p.PDoc_Sis_Emp = d.DDoc_Sis_Emp AND p.PDoc_Par_Cat = d.DDoc_Doc_Cat AND p.PDoc_Par_Ano = d.DDoc_Doc_Ano AND p.PDoc_Par_Num = d.DDoc_Doc_Num AND"
                        strSQL &= "               p.PDoc_Par_Lin = d.DDoc_Doc_Lin AND p.PDoc_Prd_Cod = d.DDoc_Prd_Cod),0) Saldo"
                        strSQL &= "     FROM Dcmtos_DTL d"
                        strSQL &= "          WHERE d.DDoc_Sis_Emp = " & Sesion.IdEmpresa & " AND"
                        strSQL &= "              d.DDoc_Doc_Cat = 36 AND"
                        strSQL &= "              d.DDoc_Doc_Ano = " & dgReferencia.Rows(i).Cells("colAno").Value & " AND"
                        strSQL &= "              d.DDoc_Doc_Num = " & dgReferencia.Rows(i).Cells("colNumber").Value & " AND"
                        strSQL &= "               d.DDoc_Doc_Lin = " & dgReferencia.Rows(i).Cells("colLine").Value & ""
                    End If
                    'Obtiene el saldo para la línea del documento de referencia
                    MyCnn.CONECTAR = strConexion
                    COM = New MySqlCommand(strSQL, CON)
                    dblSaldo = COM.ExecuteScalar()

                    'Agrega la línea
                    If Not (strLineas = vbNullString) Then
                        strLineas = strLineas + vbNullChar
                    End If
                    strLineas = strLineas & Replace(strTemp, "{Saldo}", dblSaldo.ToString(FORMATO_MONEDA))
                End If
            Next
        End If
    End Sub

    'Devuelve la consulta de selección con los documentos por procesar
    Public Function SqlGetDocumentsList(Optional Clase As Boolean = False, Optional Codigo As Boolean = False, Optional Estado As Boolean = True, Optional Actual As Boolean = False, Optional Alia As Boolean = False, Optional Saldo As Boolean = True, Optional curDoc As Integer = vbEmpty) As String
        'Parámetros: empresa, tipo, clase, codigo, estado
        Dim strSQL As String

        strSQL = vbNullString
        strSQL = " SELECT DISTINCT"

        If Alia Then
            strSQL &= " HDoc_Sis_Emp empresa, HDoc_Doc_Cat tipo, HDoc_Doc_Ano año, HDoc_Doc_Num numero, HDoc_Doc_Fec fecha, COALESCE(HDoc_DR1_Num,'') referencia, HDoc_Usuario usuario, HDoc_RF1_Dbl Total "
        Else
            strSQL &= " HDoc_Sis_Emp, HDoc_Doc_Cat, HDoc_Doc_Ano, HDoc_Doc_Num, HDoc_Doc_Fec, COALESCE(HDoc_DR1_Num,'') HDoc_DR1_Num, HDoc_Usuario, HDoc_RF1_Dbl Total "
        End If

        strSQL &= "  FROM Dcmtos_HDR a"
        strSQL &= "     LEFT JOIN Dcmtos_DTL b  ON a.HDoc_Sis_Emp  = b.DDoc_Sis_Emp AND a.HDoc_Doc_Cat  = b.DDoc_Doc_Cat AND a.HDoc_Doc_Ano  = b.DDoc_Doc_Ano AND a.HDoc_Doc_Num  = b.DDoc_Doc_Num"
        strSQL &= "         WHERE HDoc_Sis_Emp = {empresa} AND (HDoc_Doc_Cat = {tipo})"

        If Clase Then
            'Clase: importación, devolución, transferencia
            strSQL &= " AND COALESCE(HDoc_DR1_Cat,0) = {clase}"
        End If

        If Codigo Then
            'Estado del documento
            strSQL &= "  AND (HDoc_Emp_Cod = {codigo})"
        End If

        If Estado Then
            'Estado del documento
            strSQL &= "  AND HDoc_Doc_Status = 1"
        End If


        If Saldo Then
            'Sólo documentos con saldo
            strSQL &= "  AND (COALESCE((SELECT SUM(c.PDoc_QTY_Pro)"
            strSQL &= "      FROM Dcmtos_DTL_Pro c"
            strSQL &= "          WHERE c.PDoc_Sis_Emp = b.DDoc_Sis_Emp AND c.PDoc_Par_Cat = b.DDoc_Doc_Cat AND c.PDoc_Par_Ano = b.DDoc_Doc_Ano AND c.PDoc_Par_Num = b.DDoc_Doc_Num AND c.PDoc_Par_Lin = b.DDoc_Doc_Lin"

            If Actual Then
                'Documento que descarga (actual)
                strSQL &= " AND c.PDoc_Chi_Cat = {actual}"
            End If

            If curDoc = 36 Then
                strSQL &= "), 0) < b.DDoc_RF3_Dbl)"
            Else
                strSQL &= "), 0) < b.DDoc_Prd_QTY)"
            End If
        End If

        strSQL &= "  ORDER BY HDoc_Doc_Ano DESC, HDoc_Doc_Num DESC"

        'Devuelve el resultado
        SqlGetDocumentsList = strSQL
    End Function

    Private Function SqlDocsPorProcesar() As String
        Dim strSQL As String

        strSQL = SqlGetDocumentsList(False, True, True, True, , , 296)

        'Reemplazar parámetros
        strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
        strSQL = Replace(strSQL, "{tipo}", 36)
        strSQL = Replace(strSQL, "{codigo}", celdaIdCliente.Text)
        strSQL = Replace(strSQL, "{actual}", 296)

        SqlDocsPorProcesar = strSQL

    End Function

    Private Function SqlDocumentosProcesados() As String
        Dim wSql As String

        wSql = "  SELECT DISTINCT"
        wSql &= "    HDoc_Doc_Cat,"
        wSql &= "    HDoc_Doc_Ano,"
        wSql &= "    HDoc_Doc_Num,"
        wSql &= "    HDoc_Doc_Fec,"
        wSql &= "    HDoc_DR1_Num,"
        wSql &= "    HDoc_Usuario,"
        wSql &= " WHERE"
        wSql &= "    Dcmtos_DTL_Pro a"
        wSql &= "    INNER JOIN"
        wSql &= "      Dcmtos_HDR b ON a.PDoc_Sis_Emp = b.HDoc_Sis_Emp AND"
        wSql &= "      a.PDoc_Par_Cat = b.HDoc_Doc_Cat AND"
        wSql &= "      a.PDoc_Par_Ano = b.HDoc_Doc_Ano AND"
        wSql &= "      a.PDoc_Par_Num = b.HDoc_Doc_Num"
        wSql &= " WHERE"
        wSql &= "      a.PDoc_Sis_Emp = {empresa} AND"
        wSql &= "       a.PDoc_Chi_Ano = {Año} AND"
        wSql &= "       a.PDoc_Par_Cat = 36 "

        wSql = Replace(wSql, "{Año}", celdaAño.Text)
        wSql = Replace(wSql, "{empresa}", Sesion.IdEmpresa)

        SqlDocumentosProcesados = wSql

    End Function

    Private Sub ListarDocumentos()
        Dim strSQL As String
        Dim strTemp As String
        Dim intAño As Integer
        Dim intNumero As Integer
        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader

        intAño = celdaAño.Text
        intNumero = celdaNumero.Text
        'dgInstrucDespacho.ColumnCount = vbEmpty
        If Me.Tag = "Mod" Then
            strSQL = SqlDocumentosProcesados()
        Else
            strSQL = SqlDocsPorProcesar()
        End If

        'Agrega todos los registros de la selección
        MyCnn.CONECTAR = strConexion
        Try

            COM = New MySqlCommand(strSQL, CON)
            REA = COM.ExecuteReader
            Do While REA.Read

                strTemp = vbNullString
                strTemp &= REA.GetInt32("HDoc_Doc_Cat") & "|"
                strTemp &= REA.GetInt32("HDoc_Doc_Ano") & "|"
                strTemp &= REA.GetString("HDoc_Doc_Num") & "|"
                strTemp &= REA.GetDateTime("HDoc_Doc_Fec") & "|"
                strTemp &= REA.GetString("HDoc_Usuario") & "|"
                strTemp &= REA.GetString("HDoc_DR1_Num") & "|"
                strTemp &= 1


                cFunciones.AgregarFila(dgFacturacion, strTemp)
            Loop
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    'Carga el detalle de los documentos del cliente que estén en el listado
    Private Sub ProcesarDocumentos()
        Me.Tag = "Nuevo"
        Dim i As Integer
        Dim strTemp As String
        Dim strSQL As String = STR_VACIO
        Dim REA As MySqlDataReader
        Dim COM As MySqlCommand

        dgDetalle.Rows.Clear()

        If dgFacturacion.RowCount > 5 Then
            If MsgBox("¿Show details of all documents in the list?", vbQuestion + vbYesNo + vbDefaultButton2, "Documents Detail") = vbNo Then
                Exit Sub
            End If
        End If

        For i = 0 To dgFacturacion.Rows.Count - 1
            If dgFacturacion.ColumnCount > vbEmpty Then
                If Not (dgFacturacion.Rows(0).Cells(0).Value) = vbNullString Then
                    strSQL = SqlDetallePorProcesar()
                End If
            End If
            MyCnn.CONECTAR = strConexion
            Try
                dgDetalle.Rows.Clear()
                COM = New MySqlCommand(strSQL, CON)
                REA = COM.ExecuteReader
                Do While REA.Read

                    strTemp = REA.GetInt32("Numero") & "|"
                    strTemp &= REA.GetInt32("Codigo") & "|"
                    strTemp &= REA.GetInt32("Ano") & "|"
                    strTemp &= REA.GetInt32("Linea") & "|"
                    strTemp &= REA.GetInt32("Linea") & "|"
                    strTemp &= REA.GetString("Descripcion") & "|"
                    strTemp &= REA.GetInt32("Original") & "|"
                    strTemp &= REA.GetString("Medida") & "|"
                    strTemp &= REA.GetDouble("Despacho") & "|"
                    strTemp &= REA.GetDouble("Precio") & "|"
                    strTemp &= "0.00" & "|"
                    strTemp &= "0.00" & "|"
                    strTemp &= REA.GetDouble("Cantidad") & "|"
                    strTemp &= REA.GetDouble("Total") & "|"
                    strTemp &= "0" & "|"
                    strTemp &= REA.GetString("Bulto") & "|"
                    strTemp &= REA.GetInt32("Bobinas") & "|"
                    strTemp &= REA.GetString("Distribucion") & "|"
                    strTemp &= REA.GetInt32("Destino") & "|"
                    strTemp &= REA.GetString("Lugar") & "|"
                    strTemp &= REA.GetDouble("Libras") & "|"
                    strTemp &= REA.GetDouble("Kilos") & "|"
                    strTemp &= REA.GetInt32("Original") & "|"
                    strTemp &= REA.GetString("Referencia") & "|"
                    strTemp &= REA.GetInt32("Base")


                    cFunciones.AgregarFila(dgDetalle, strTemp)
                Loop

            Catch ex As Exception
                MsgBox(ex.ToString)
            End Try
        Next

        'Limpia el listado de referencias
        dgReferencia.Rows.Clear()

        If dgDetalle.ColumnCount > vbEmpty Then
            'Cargar Info. del DTL Pro
            sqlCargarRelacion()
        End If

        'Actualiza el saldo del listado de referencias
        ActualizarLista()

        CalcularTotales()
    End Sub

    Private Function SqlDetallePorProcesar() As String
        Dim strSQL As String


        strSQL = vbNullString
        strSQL &= " SELECT d.DDoc_Doc_Ano Ano, d.DDoc_Doc_Num Numero, d.DDoc_Doc_Lin Linea, 0 Id, d.DDoc_Prd_Cod Codigo, IF(COALESCE(a.art_desc,'')='',d"
        strSQL &= " .DDoc_Prd_Des,a.art_desc) Descripcion, d.DDoc_RF1_Cod Original, d.DDoc_Prd_PNr Parte, d.DDoc_Prd_PUQ Unitario, d.DDoc_Prd_NET Precio, m"
        strSQL &= "      =0,d.DDoc_Prd_QTY,d.DDoc_RF3_Dbl) * d.DDoc_Prd_NET) Total, '' Bulto, 0 Bobinas, '' Distribucion, COALESCE(l.cli_cliente,'') Lugar, d"
        strSQL &= "      .DDoc_RF1_Num Destino, d.DDoc_RF1_Txt Referencia, 0 Libras, 0 Kilos, d.DDoc_Prd_QTY Magnitud, d.DDoc_Prd_UM Unidad, (d.DDoc_Prd_QTY - COALESCE(("
        strSQL &= "      SELECT SUM(h.hdoc_rf2_dbl)"
        strSQL &= "      0 Libras, 0 Kilos, d.DDoc_Prd_QTY Magnitud, d.DDoc_Prd_UM Unidad,"
        strSQL &= "      (d.DDoc_Prd_QTY - COALESCE((SELECT SUM(p.PDoc_QTY_Pro)"
        strSQL &= "         FROM Dcmtos_DTL_Pro p"
        strSQL &= "         FROM Dcmtos_HDR h"
        strSQL &= "         WHERE h.hdoc_sis_emp = d.DDoc_Sis_Emp AND h.hdoc_doc_cat = d.DDoc_Doc_Cat AND h.hdoc_doc_ano = d.DDoc_Doc_Ano AND h.hdoc_doc_num = d.DDoc_Doc_Num),0)) Cantidad"
        strSQL &= "         FROM Dcmtos_DTL d"
        strSQL &= "    FROM Dcmtos_DTL d"
        strSQL &= "         LEFT JOIN Catalogos m ON m.cat_clase = 'Medidas' AND m.cat_num = COALESCE(d.DDoc_RF3_Num,d.DDoc_Prd_UM)"
        strSQL &= "         LEFT JOIN Clientes l ON l.cli_sisemp = d.DDoc_Sis_Emp AND l.cli_codigo = d.DDoc_RF1_Num"
        strSQL &= "         LEFT JOIN Inventarios i ON i.inv_sisemp = d.DDoc_Sis_Emp AND i.inv_numero = d.DDoc_Prd_Cod"
        strSQL &= "         LEFT JOIN Articulos   a ON a.art_sisemp = i.inv_sisemp   AND a.art_codigo = i.inv_artcodigo"
        strSQL &= "    WHERE d.DDoc_Sis_Emp = {empresa} AND"
        strSQL &= "             d.DDoc_Doc_Cat = {documento} {lista}"
        strSQL &= "    HAVING (Cantidad > 0)"
        strSQL &= "     ORDER BY d.DDoc_Doc_Ano, d.DDoc_Doc_Num, d.DDoc_Doc_Lin"

        strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
        strSQL = Replace(strSQL, "{documento}", 36)
        strSQL = Replace(strSQL, "{lista}", SqlSeleccionados())

        SqlDetallePorProcesar = strSQL

    End Function

    Private Function SqlDetallePorProcesar2() As String
        Dim strSQL As String


        strSQL = vbNullString
        strSQL &= " SELECT d.DDoc_Doc_Ano Ano, d.DDoc_Doc_Num Numero, d.DDoc_Doc_Lin Linea, 0 Id,"
        strSQL &= "      d.DDoc_Prd_Cod Codigo, IF(COALESCE(a.art_desc,'')='',d.DDoc_Prd_Des,a.art_desc) Descripcion, d.DDoc_RF1_Cod Original, d.DDoc_Prd_PNr Parte,"
        strSQL &= "      d.DDoc_Prd_PUQ Unitario, d.DDoc_Prd_NET Precio, m.cat_clave Medida,"
        strSQL &= "      COALESCE(d.DDoc_RF3_Num,d.DDoc_Prd_UM) Base, IF(d.DDoc_RF3_Dbl=0,d.DDoc_Prd_QTY,d.DDoc_RF3_Dbl) Despacho, (IF(d.DDoc_RF3_Dbl=0,d.DDoc_Prd_QTY,d.DDoc_RF3_Dbl) * d.DDoc_Prd_NET) Total,"
        strSQL &= "      '' Bulto, 0 Bobinas, '' Distribucion, COALESCE(l.cli_cliente,'') Lugar, d.DDoc_RF1_Num Destino, d.DDoc_RF1_Txt Referencia, "
        strSQL &= "      0 Libras, 0 Kilos, d.DDoc_Prd_QTY Magnitud, d.DDoc_Prd_UM Unidad,"
        strSQL &= "      (d.DDoc_Prd_QTY - COALESCE((SELECT SUM(p.PDoc_QTY_Pro)"
        strSQL &= "         FROM Dcmtos_DTL_Pro p"
        strSQL &= "         WHERE p.PDoc_Sis_Emp = d.DDoc_Sis_Emp AND p.PDoc_Par_Cat = d.DDoc_Doc_Cat AND"
        strSQL &= "          p.PDoc_Par_Ano = d.DDoc_Doc_Ano AND p.PDoc_Par_Num = d.DDoc_Doc_Num AND"
        strSQL &= "          p.PDoc_Par_Lin = d.DDoc_Doc_Lin AND p.PDoc_Prd_Cod = d.DDoc_Prd_Cod),0)) Cantidad"
        strSQL &= "    FROM Dcmtos_DTL d"
        strSQL &= "         LEFT JOIN Catalogos   m ON m.cat_clase  = 'Medidas'      AND m.cat_num = COALESCE(d.DDoc_RF3_Num,d.DDoc_Prd_UM)"
        strSQL &= "         LEFT JOIN Clientes    l ON l.cli_sisemp = d.DDoc_Sis_Emp AND l.cli_codigo = d.DDoc_RF1_Num"
        strSQL &= "         LEFT JOIN Inventarios i ON i.inv_sisemp = d.DDoc_Sis_Emp AND i.inv_numero = d.DDoc_Prd_Cod"
        strSQL &= "         LEFT JOIN Articulos   a ON a.art_sisemp = i.inv_sisemp   AND a.art_codigo = i.inv_artcodigo"
        strSQL &= "   WHERE d.DDoc_Sis_Emp = {empresa} AND d.DDoc_Doc_Cat = {documento} AND d.DDoc_Doc_Ano = {año} AND d.DDoc_Doc_Num = {ints}"
        strSQL &= "     ORDER BY d.DDoc_Doc_Ano, d.DDoc_Doc_Num, d.DDoc_Doc_Lin"

        strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
        strSQL = Replace(strSQL, "{documento}", 48)
        strSQL = Replace(strSQL, "{año}", dgFacturacion.SelectedCells(1).Value)
        strSQL = Replace(strSQL, "{ints}", dgFacturacion.SelectedCells(2).Value)

        SqlDetallePorProcesar2 = strSQL

    End Function

    Private Function SqlSeleccionados() As String
        Dim wSql As String = STR_VACIO

        For i As Integer = 0 To dgFacturacion.Rows.Count - 1

            If Not dgFacturacion.Rows(i).Cells(0).Value = vbNullString Then
                wSql &= IIf(i = vbEmpty, "(", " OR(")
                wSql &= "d.DDoc_Doc_Ano = " & dgFacturacion.Rows(i).Cells("colAñ").Value & " AND "
                wSql &= "d.DDoc_Doc_Num = " & dgFacturacion.Rows(i).Cells("colFact").Value & ") "
            End If
        Next
        If wSql = vbNullString Then
            SqlSeleccionados = "AND 1 = 0 "
        Else
            SqlSeleccionados = "AND (" & wSql & ")"
        End If

    End Function

    'Descarga de la reserva de inventario (si existe)
    Private Sub DescargarReserva()
        Dim i As Integer, j As Integer
        Dim intLinea As Integer, intEstado As Integer
        Dim intCod As Integer
        Dim Año As Integer
        Dim Numero As Integer
        Dim Tipo As Integer
        Dim Empresa As Integer
        Dim Linea As Integer
        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader

        Dim dblTemp As Double
        Dim dblCambio As Double
        Dim logEx As Boolean

        Dim strSQL As String

        For i = vbEmpty To dgDetalle.Rows.Count - 1
            'Determinar si hay cambio
            dblCambio = ((dgDetalle.Rows(i).Cells("colDespacho").Value) - (dgDetalle.Rows(i).Cells("colCantidad").Value))

            Empresa = vbEmpty
            If Not (dblCambio = vbEmpty) Then
                intLinea = dgDetalle.Rows(i).Cells("colNum").Value
                For j = vbEmpty To dgReferencia.Rows.Count - 1
                    If dgReferencia.Rows(j).Cells("colID").Value = intLinea Then
                        Empresa = Sesion.IdEmpresa
                        Tipo = 47
                        Año = dgReferencia.Rows(j).Cells("colAno").Value
                        Numero = dgReferencia.Rows(j).Cells("colNumber").Value
                        Linea = dgReferencia.Rows(j).Cells("colLine").Value

                        intCod = celdaIdCliente.Text

                        logEx = True
                        Exit For
                    End If
                Next

                If logEx Then
                    'Reservas de esa línea de referencia para el cliente actual (activas)
                    strSQL = "   SELECT linea, cantidad"
                    strSQL &= "      FROM Reserva"
                    strSQL &= "          WHERE id_empresa=" & Empresa & " AND doc_tipo=" & Tipo & " AND doc_ciclo=" & Año & " AND doc_num=" & Numero & " AND doc_lin=" & Linea & " AND id_entidad=" & intCod & " AND NOT(estado=2)"

                    MyCnn.CONECTAR = strConexion
                    COM = New MySqlCommand(strSQL, CON)
                    REA = COM.ExecuteReader
                    REA.Read()

                    dblTemp = (REA.GetDouble("Cantidad") - dblCambio)
                    intEstado = IIf(dblTemp <= vbEmpty, 2, INT_UNO)
                    strSQL = "  UPDATE Reserva"
                    strSQL &= "      SET cantidad=" & dblTemp & ", estado=" & intEstado & ", referencia = CONCAT(referencia,'\r\n***** DESPACHO *****\r\nFecha: ',CAST(NOW() AS CHAR),'\r\nUsuario: " & Sesion.idUsuario & "\r\nFactura: " & celdaNumero.Text & "\r\nCantidad: " & dblCambio & "') WHERE id_empresa=" & Empresa & " AND doc_tipo=" & Tipo & " AND doc_ciclo=" & Año & " AND doc_num=" & Numero & " AND doc_lin=" & Linea & " AND linea=" & REA.GetInt32("Linea")
                    If Sesion.IdEmpresa = 18 Then
                        strSQL &= ";  UPDATE PDM.Reserva"
                        strSQL &= "      SET cantidad=" & dblTemp & ", estado=" & intEstado & ", referencia = CONCAT(referencia,'\r\n***** DESPACHO *****\r\nFecha: ',CAST(NOW() AS CHAR),'\r\nUsuario: " & Sesion.idUsuario & "\r\nFactura: " & celdaNumero.Text & "\r\nCantidad: " & dblCambio & "') WHERE id_empresa=" & Empresa & " AND doc_tipo=" & Tipo & " AND doc_ciclo=" & Año & " AND doc_num=" & Numero & " AND doc_lin=" & Linea & " AND linea=" & REA.GetInt32("Linea")
                    End If
                End If
            End If
            dgDetalle.Rows(i).Cells("colOriginal").Value = dgDetalle.Rows(i).Cells("colDespacho").Value
        Next
    End Sub

    'Calculo de KG
    Private Sub CalcularKGBrutos(ByVal Bultos As Integer, ByVal Libras As Double, ByVal Medida As String)

        Dim strSQL As String
        Dim strSQL2 As String
        Dim dblTara As Double
        Dim dblKgBrutas As Double
        Dim dblLBSBrutas As Double
        Dim dblFactorKgs As Double
        Dim kg As Double
        Dim conec As MySqlConnection
        Dim COM As MySqlCommand

        For i As Integer = 0 To dgDetalle.Rows.Count - 1
            strSQL = "   SELECT ((pe.EDoc_Lin_Gross-pe.EDoc_Lin_Net)/b.BDoc_Box_QTY)tara"
            strSQL &= "      FROM Dcmtos_DTL_Pro p"
            strSQL &= "          LEFT JOIN Dcmtos_DTL_Box b ON b.BDoc_Sis_Emp = p.PDoc_Sis_Emp AND b.BDoc_Doc_Cat = p.PDoc_Par_Cat AND b.BDoc_Doc_Ano = p.PDoc_Par_Ano AND b.BDoc_Doc_Num = p.PDoc_Par_Num AND b.BDoc_Doc_Lin = p.PDoc_Par_Lin"
            strSQL &= "              LEFT JOIN Dcmtos_DTL_Pro po ON po.PDoc_Sis_Emp = p.PDoc_Sis_Emp AND po.PDoc_Chi_Cat = p.PDoc_Par_Cat AND po.PDoc_Chi_Ano = p.PDoc_Par_Ano AND po.PDoc_Chi_Num = p.PDoc_Par_Num AND po.PDoc_Chi_Lin = p.PDoc_Par_Lin"
            strSQL &= "           LEFT JOIN Dcmtos_DEC pe ON pe.EDoc_Sis_Emp = po.PDoc_Sis_Emp AND pe.EDoc_Doc_Cat = po.PDoc_Par_Cat AND pe.EDoc_Doc_Ano = po.PDoc_Par_Ano AND pe.EDoc_Doc_Num = po.PDoc_Par_Num AND pe.EDoc_Doc_Lin = po.PDoc_Par_Lin"
            strSQL &= "          WHERE p.PDoc_Sis_Emp = 12 AND p.PDoc_Chi_Cat = 48 AND p.PDoc_Chi_Ano = 2016 AND p.PDoc_Chi_Num = 657 AND p.PDoc_Chi_Lin = 1 AND p.PDoc_Par_Cat = 47"

            strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
            strSQL = Replace(strSQL, "{instruccion}", 48)
            strSQL = Replace(strSQL, "{año}", dgDetalle.Rows(i).Cells("colAño").Value)
            strSQL = Replace(strSQL, "{numero}", dgDetalle.Rows(i).Cells("colNum").Value)
            strSQL = Replace(strSQL, "{linea}", dgDetalle.Rows(i).Cells("colLinea").Value)
            strSQL = Replace(strSQL, "{ingreso}", 47)

            conec = New MySqlConnection(strConexion)
            conec.Open()
            COM = New MySqlCommand(strSQL, conec)
            dblTara = COM.ExecuteScalar
            conec.Close()

            If Medida = "LBS" Then
                strSQL2 = " SELECT cat_sist"
                strSQL2 &= "     FROM Catalogos"
                strSQL2 &= " WHERE cat_clave= 'KGS'"

                conec = New MySqlConnection(strConexion)
                conec.Open()
                COM = New MySqlCommand(strSQL2, conec)
                dblFactorKgs = COM.ExecuteScalar
                conec.Close()
            Else
                dblFactorKgs = 1
            End If

            kg = Libras / dblFactorKgs
            dblKgBrutas = (Bultos * dblTara) + kg
            dblLBSBrutas = dblKgBrutas * dblFactorKgs

            dgDetalle.Rows(i).Cells("colLBS").Value = dblLBSBrutas.ToString(FORMATO_MONEDA)
            dgDetalle.Rows(i).Cells("colKGS").Value = dblKgBrutas.ToString(FORMATO_MONEDA)
        Next
    End Sub

    Private Sub MarcarImpresion()
        Dim strSQL As String
        Dim COM As MySqlCommand

        strSQL = "UPDATE Dcmtos_HDR SET HDoc_DR2_Cat = (COALESCE(HDoc_DR2_Cat,0)+1)"
        strSQL &= "  WHERE HDoc_Sis_Emp = {empresa} AND HDoc_Doc_Cat = 36 AND HDoc_Doc_Ano = {año} AND HDoc_Doc_Num = {numero}"

        If Sesion.IdEmpresa = 18 Then
            strSQL &= ";UPDATE PDM.Dcmtos_HDR SET HDoc_DR2_Cat = (COALESCE(HDoc_DR2_Cat,0)+1)"
            strSQL &= "  WHERE HDoc_Sis_Emp = {empresa} AND HDoc_Doc_Cat = 36 AND HDoc_Doc_Ano = {año} AND HDoc_Doc_Num = {numero}"
        End If

        strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
        strSQL = Replace(strSQL, "{año}", celdaAño.Text)
        strSQL = Replace(strSQL, "{numero}", celdaNumero.Text)

        MyCnn.CONECTAR = strConexion
        COM = New MySqlCommand(strSQL, CON)
        COM.ExecuteNonQuery()

        cFunciones.EscribirRegistro(TBL_DOCUMENTOS, clsFunciones.AccEnum.acPrint, celdaTipo.Text, celdaAño.Text, celdaNumero.Text)
    End Sub

    'Procedimiento Propio de Facturacion para generar Yard Movemnet
    Public Function GenerarDocumento(ByVal Ciclo As Integer, ByVal Factura As Long, Optional Sobrescribe As Boolean = True) As Boolean
        Dim strSql As String
        Dim strSql2 As String
        Dim dblPrecio As Double
        Dim dblTotal As Double
        Dim logEx As Boolean
        Dim logOk As Boolean
        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader
        Dim REA2 As MySqlDataReader
        Dim Anio As Integer
        Dim Numero As Integer

        logOk = False
        logEx = False


        strSql = "SELECT e.HDoc_Doc_Fec Fecha, e.HDoc_Doc_Cat Tipo, e.HDoc_Doc_Ano Ciclo, e.HDoc_Doc_Num Numero, e.HDoc_Emp_Cod Codigo, e.HDoc_Emp_Nom Nombre, e.HDoc_Emp_Dir Direccion, e.HDoc_Emp_Per Persona, e.HDoc_Emp_Tel Telefono, e.HDoc_Emp_NIT NIT, e.HDoc_RF2_Num Dias, e.HDoc_Doc_Status Estado, e.HDoc_Doc_Mon Moneda, e.HDoc_Doc_TC Tasa"
        strSql &= "  FROM Dcmtos_HDR e"
        strSql &= "          WHERE e.HDoc_Sis_Emp={empresa} AND e.HDoc_Doc_Cat=36 AND e.HDoc_Doc_Ano={año} AND e.HDoc_Doc_Num={numero}"

        strSql = Replace(strSql, "{empresa}", Sesion.IdEmpresa)
        strSql = Replace(strSql, "{año}", celdaAño.Text)
        strSql = Replace(strSql, "{numero}", celdaNumero.Text)

        MyCnn.CONECTAR = strConexion
        COM = New MySqlCommand(strSql, CON)
        REA = COM.ExecuteReader

        If Not REA.HasRows Then

            strSql2 = "SELECT PDoc_Chi_Ano Ciclo, PDoc_Chi_Num Numero"
            strSql2 = "      FROM Dcmtos_DTL_Pro"
            strSql2 = "          WHERE PDoc_Sis_Emp={empresa} AND PDoc_Par_Cat=36 AND PDoc_Par_Ano={año} AND PDoc_Par_Num=294 AND PDoc_Chi_Cat={numero}"
            strSql2 = "              LIMIT 1"

            strSql = Replace(strSql, "{empresa}", Sesion.IdEmpresa)
            strSql = Replace(strSql, "{año}", celdaAño.Text)
            strSql = Replace(strSql, "{numero}", celdaNumero.Text)
            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSql, CON)
            REA = COM.ExecuteReader
            If Not REA.HasRows Then
                'Ya Existe
                logEx = True

                Anio = REA.GetInt32("Ciclo")
                Numero = REA.GetInt32("Numero")
            Else
                Anio = Ciclo
                Numero = Factura
            End If
            If Not logEx Or (logEx And Sobrescribe) Then
                'Borrar datos existentes

                Dim hdrd As New clsDcmtos_HDR
                hdrd.CONEXION = strConexion
                hdrd.HDOC_SIS_EMP = Sesion.IdEmpresa
                hdrd.HDOC_DOC_CAT = 395
                hdrd.HDOC_DOC_ANO = Anio
                hdrd.HDOC_DOC_NUM = Numero
                hdrd.Borrar()

                strSql = "DDoc_Sis_Emp={empresa} And DDoc_Doc_Cat = 395 And DDoc_Doc_Ano = {anio}, DDoc_Doc_Num ={numero}"

                strSql = Replace(strSql, "{empresa}", Sesion.IdEmpresa)
                strSql = Replace(strSql, "{anio}", Anio)
                strSql = Replace(strSql, "{numero}", Numero)

                Dim dtld As New clsDcmtos_DTL
                dtld.CONEXION = strConexion
                dtld.Borrar(strSql)

                strSql = "PDoc_Sis_Emp={empresa} And PDoc_Chi_Cat = 395 And PDoc_Chi_Ano = {anio}, PDoc_Chi_Num ={numero} And PDoc_Chi_Num = 36"

                strSql = Replace(strSql, "{empresa}", Sesion.IdEmpresa)
                strSql = Replace(strSql, "{anio}", Anio)
                strSql = Replace(strSql, "{numero}", Numero)

                Dim pro As New clsDcmtos_DTL_Pro
                pro.CONEXION = strConexion
                pro.Borrar(strSql)

                '1) Datos del encabezado
                Try
                    Dim chdr As New clsDcmtos_HDR
                    chdr.CONEXION = strConexion

                    chdr.HDOC_SIS_EMP = Sesion.IdEmpresa
                    chdr.HDOC_DOC_CAT = 365
                    chdr.HDOC_DOC_ANO = Anio
                    chdr.HDOC_DOC_NUM = Numero
                    chdr.HDoc_Doc_Fec_NET = REA.GetDateTime("Fecha")

                    chdr.HDOC_EMP_COD = REA.GetInt32("Codigo")
                    chdr.HDOC_EMP_NOM = REA.GetString("Nombre")
                    chdr.HDOC_EMP_DIR = REA.GetString("Direccion")
                    chdr.HDOC_EMP_PER = REA.GetString("Persona")
                    chdr.HDOC_EMP_TEL = REA.GetString("Telefono")
                    chdr.HDOC_EMP_NIT = REA.GetString("NIT")

                    'Referencia y cliente
                    chdr.HDOC_DR1_CAT = REA.GetInt32("Dias")
                    chdr.HDOC_DR1_NUM = Numero
                    chdr.HDOC_DR1_EMP = REA.GetInt32("Codigo")
                    chdr.HDOC_RF1_COD = REA.GetString("Persona")

                    'Revisión y notas
                    chdr.HDOC_DR2_NUM = vbNullString
                    chdr.HDOC_RF2_TXT = vbNullString
                    chdr.HDOC_DOC_MON = REA.GetInt32("Moneda")
                    chdr.HDOC_DOC_TC = REA.GetDouble("Tasa")

                    chdr.HDOC_DOC_STATUS = REA.GetInt32("Estado")
                    chdr.HDOC_USUARIO = Sesion.Usuario

                    If chdr.Guardar() = False Then
                        MsgBox(chdr.MERROR.ToString & "Could not save the document", MsgBoxStyle.Critical)
                    End If

                    'Datos del detalle y relación
                    strSql = "SELECT d.DDoc_Doc_Lin Linea, d.DDoc_Prd_Cod Codigo, d.DDoc_Prd_Des Descripcion, d.DDoc_RF1_Txt Referencia, IFNULL(e.HDoc_DR1_Num,'') Pedido, d.DDoc_Prd_UM UM, d.DDoc_Prd_QTY Cantidad, IFNULL(p.DDoc_Prd_NET,0) Precio, IFNULL(t.ADoc_Dta_Txt,'') Contenedor"
                    strSql &= "  FROM Dcmtos_DTL d"
                    strSql &= "      LEFT JOIN Dcmtos_DTL_Pro r ON r.PDoc_Sis_Emp=d.DDoc_Sis_Emp AND r.PDoc_Chi_Cat=d.DDoc_Doc_Cat AND r.PDoc_Chi_Ano=d.DDoc_Doc_Ano AND r.PDoc_Chi_Num=d.DDoc_Doc_Num AND r.PDoc_Chi_Lin=d.DDoc_Doc_Lin AND r.PDoc_Par_Cat= 48"
                    strSql &= "          LEFT JOIN Dcmtos_DTL_Pro n ON n.PDoc_Sis_Emp=r.PDoc_Sis_Emp AND n.PDoc_Chi_Cat=r.PDoc_Par_Cat AND n.PDoc_Chi_Ano=r.PDoc_Par_Ano AND n.PDoc_Chi_Num=r.PDoc_Par_Num AND n.PDoc_Chi_Lin=r.PDoc_Par_Lin AND n.PDoc_Par_Cat= 47"
                    strSql &= "             LEFT JOIN Dcmtos_DTL_Pro m ON m.PDoc_Sis_Emp=n.PDoc_Sis_Emp AND m.PDoc_Chi_Cat=n.PDoc_Par_Cat AND m.PDoc_Chi_Ano=n.PDoc_Par_Ano AND m.PDoc_Chi_Num=n.PDoc_Par_Num AND m.PDoc_Chi_Lin=n.PDoc_Par_Lin AND m.PDoc_Par_Cat= 180"
                    strSql &= "                  LEFT JOIN Dcmtos_DTL_Pro a ON a.PDoc_Sis_Emp=m.PDoc_Sis_Emp AND a.PDoc_Chi_Cat=m.PDoc_Par_Cat AND a.PDoc_Chi_Ano=m.PDoc_Par_Ano AND a.PDoc_Chi_Num=m.PDoc_Par_Num AND a.PDoc_Chi_Lin=m.PDoc_Par_Lin AND a.PDoc_Par_Cat= 55"
                    strSql &= "                      LEFT JOIN Dcmtos_DTL_Pro c ON c.PDoc_Sis_Emp=a.PDoc_Sis_Emp AND c.PDoc_Chi_Cat=a.PDoc_Par_Cat AND c.PDoc_Chi_Ano=a.PDoc_Par_Ano AND c.PDoc_Chi_Num=a.PDoc_Par_Num AND c.PDoc_Chi_Lin=a.PDoc_Par_Lin AND c.PDoc_Par_Cat= 127"
                    strSql &= "                          LEFT JOIN Dcmtos_ACC t ON t.ADoc_Sis_Emp=c.PDoc_Sis_Emp AND t.ADoc_Doc_Cat=c.PDoc_Par_Cat AND t.ADoc_Doc_Ano=c.PDoc_Par_Ano AND t.ADoc_Doc_Num=c.PDoc_Par_Num AND t.ADoc_Doc_Sub='Doc_PFactura' AND t.ADoc_Doc_Lin='07'"
                    strSql &= "                       LEFT JOIN Dcmtos_DTL_Pro o ON o.PDoc_Sis_Emp=r.PDoc_Sis_Emp AND o.PDoc_Chi_Cat=r.PDoc_Par_Cat AND o.PDoc_Chi_Ano=r.PDoc_Par_Ano AND o.PDoc_Chi_Num=r.PDoc_Par_Num AND o.PDoc_Chi_Lin=r.PDoc_Par_Lin AND o.PDoc_Par_Cat= 75"
                    strSql &= "                   LEFT JOIN Dcmtos_DTL p ON p.DDoc_Sis_Emp=o.PDoc_Sis_Emp AND p.DDoc_Doc_Cat=o.PDoc_Par_Cat AND p.DDoc_Doc_Ano=o.PDoc_Par_Ano AND p.DDoc_Doc_Num=o.PDoc_Par_Num AND p.DDoc_Doc_Lin=o.PDoc_Par_Lin"
                    strSql &= "               LEFT JOIN Dcmtos_HDR e ON e.HDoc_Sis_Emp=p.DDoc_Sis_Emp AND e.HDoc_Doc_Cat=p.DDoc_Doc_Cat AND e.HDoc_Doc_Ano=p.DDoc_Doc_Ano AND e.HDoc_Doc_Num=p.DDoc_Doc_Num"
                    strSql &= "             WHERE d.DDoc_Sis_Emp=11 AND d.DDoc_Doc_Cat=36 AND d.DDoc_Doc_Ano=2016 AND d.DDoc_Doc_Num=294"
                    strSql &= "          GROUP BY d.DDoc_Sis_Emp, d.DDoc_Doc_Cat, d.DDoc_Doc_Ano, d.DDoc_Doc_Num, d.DDoc_Doc_Lin"
                    strSql &= "        ORDER BY d.DDoc_Doc_Lin"

                    MyCnn.CONECTAR = strConexion
                    COM = New MySqlCommand(strSql, CON)
                    REA2 = COM.ExecuteReader

                    '2) Detalle del documento
                    Dim dtl As New clsDcmtos_DTL
                    chdr.CONEXION = strConexion

                    dtl.DDOC_SIS_EMP = Sesion.IdEmpresa
                    dtl.DDOC_DOC_CAT = 395
                    dtl.DDOC_DOC_ANO = Anio
                    dtl.DDOC_DOC_NUM = Numero
                    dtl.DDOC_DOC_LIN = REA2.GetInt32("Linea")

                    dtl.DDOC_PRD_COD = REA2.GetInt32("Codigo")
                    dtl.DDOC_PRD_DES = REA2.GetString("Descripcion")

                    'Precio y unidad de medida de pedido
                    dblPrecio = REA.GetDouble("Precio")

                    dtl.DDOC_PRD_UM = REA2.GetString("UM")
                    dtl.DDOC_PRD_PUQ = dblPrecio
                    dtl.DDOC_PRD_DSP = vbEmpty
                    dtl.DDOC_PRD_DSQ = vbEmpty
                    dtl.DDOC_PRD_NET = dblPrecio
                    dtl.DDOC_PRD_QTY = REA2.GetDouble("Cantidad")

                    dblTotal = (dblPrecio * REA2.GetDouble("Cantidad"))
                    dtl.DDOC_RF1_DBL = dblTotal
                    dtl.DDOC_PRD_FOB = dblTotal
                    dtl.DDOC_PRD_CIF = dblTotal

                    'ID de contrato, pedido y referencia
                    dtl.DDOC_RF1_NUM = vbEmpty
                    dtl.DDOC_RF1_COD = REA2.GetString("Pedido")
                    dtl.DDOC_RF1_TXT = REA2.GetString("Referencia")

                    'Contenedor, forma de pago y cant. a restar (devolución)
                    dtl.DDOC_RF2_COD = REA2.GetString("Contenedor")
                    dtl.DDOC_RF2_TXT = "N/A"
                    dtl.DDOC_RF2_DBL = vbEmpty

                    'Notas y carta de crédito
                    dtl.DDOC_RF3_TXT = vbNullString
                    dtl.DDOC_PRD_REF = vbNullString

                    If dtl.Guardar() = False Then
                        MsgBox(dtl.MERROR.ToString & "Could not save the document", MsgBoxStyle.Critical)
                    End If

                    '3) Relación con factura
                    Dim dpro As New clsDcmtos_DTL_Pro
                    chdr.CONEXION = strConexion

                    'Padre (factura)
                    dpro.PDOC_SIS_EMP = Sesion.IdEmpresa
                    dpro.PDOC_PAR_CAT = REA.GetInt32("Tipo")
                    dpro.PDOC_PAR_ANO = REA.GetInt32("Ciclo")
                    dpro.PDOC_PAR_NUM = REA.GetInt32("Numero")
                    dpro.PDOC_PAR_LIN = REA2.GetInt32("Linea")

                    'Hijo (YM)
                    dpro.PDOC_CHI_CAT = 395
                    dpro.PDOC_CHI_ANO = Anio
                    dpro.PDOC_CHI_NUM = Numero
                    dpro.PDOC_CHI_LIN = REA2.GetInt32("Linea")

                    'Cliente
                    dpro.PDOC_CLTE_COD = REA.GetInt32("Codigo")
                    dpro.PDOC_PROV_COD = vbEmpty

                    'Producto
                    dpro.PDOC_PRD_COD = REA2.GetInt32("Codigo")
                    dpro.PDOC_PRD_PNR = vbNullString
                    dpro.PDOC_PRD_NET = dblPrecio

                    dpro.PDOC_DR1_NUM = vbEmpty
                    dpro.PDOC_DR2_NUM = vbEmpty

                    'Cantidades
                    dpro.PDOC_QTY_ORD = REA2.GetDouble("Cantidad")
                    dpro.PDOC_QTY_PRO = REA2.GetDouble("Cantidad")

                    If dpro.Guardar() = False Then
                        MsgBox(dpro.MERROR.ToString)
                    End If
                Catch ex As Exception
                    MsgBox(ex.ToString)
                End Try
                logOk = True
            End If
        Else
            MsgBox("The Bill not found", vbExclamation, "Generate Yard Movement")
        End If

        GenerarDocumento = logOk
    End Function

    Public Function GetReferencia() As String
        Dim i As Integer
        Dim strReferencia As String = STR_VACIO

        If dgReferencia.RowCount = 1 Then
            strReferencia = dgReferencia.Rows(0).Cells("colReference").Value
        Else
            For i = 0 To dgReferencia.Rows.Count - 1
                If strReferencia = "0" Then
                    strReferencia = dgReferencia.Rows(i).Cells("colReference").Value
                Else
                    strReferencia = strReferencia & "/" & dgReferencia.Rows(i).Cells("colReference").Value
                End If
            Next
        End If
        Return strReferencia
    End Function


#End Region

#Region "Eventos"

    Private Sub frmFacturacion_FormClosed(sender As Object, e As FormClosedEventArgs)

        Try
            frmSPrincipal.BarraDeTareas1.QuitarFormulario(strKey)
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try

    End Sub
    Private Sub frmFacturacion_Activated(sender As Object, e As EventArgs) Handles Me.Activated
        Dim COM As MySqlCommand
        Dim conec As MySqlConnection
        Dim Pais As String

        If logPrinting Then
            logPrinting = False
            If Not (etiquetaAnulada.Visible Or logPrinted) Then
                If MsgBox("¿The document is printed correctly?", vbQuestion + vbYesNo + vbDefaultButton2, "Print") = vbYes Then
                    'Codigo para generar Yarn Movement
                    Dim strSQL As String
                    strSQL = "SELECT c.cat_clave "
                    strSQL &= "  FROM Empresas e"
                    strSQL &= "      LEFT JOIN Catalogos c ON c.cat_num = e.emp_pais "

                    conec = New MySqlConnection(strConexion)
                    conec.Open()
                    COM = New MySqlCommand(strSQL, conec)
                    Pais = COM.ExecuteScalar
                    conec.Close()

                    GenerarDocumento(Val(celdaAño.Text), Val(celdaNumero.Text))
                End If

                MarcarImpresion()


                celdaFlete.Enabled = True
                celdaSeguro.Enabled = True
            End If
        End If

    End Sub

    Private Sub frmFacturacion_Load(sender As Object, e As EventArgs) Handles MyBase.Load

        dtpInicio.Value = DateSerial(Year(Date.Now), Month(Date.Now) - 1, 30)
        dtpFinal.Value = DateSerial(Year(Date.Now), Month(Date.Now) + 1, vbEmpty)

        Accessos()
        MostrarLista()

    End Sub

    Private Sub Encabezado1_ClickNuevo(sender As Object, click As Boolean) Handles Encabezado1.ClickNuevo
        Dim SDoc As New frmSubDocumentos
        Me.Tag = "nuevo"
        MostrarLista(False)
        LimpiarPanelOrden()
        celdaAño.Text = cFunciones.AñoMySQL
        Dim año As Integer
        Dim numero As Integer
        SeleccionarSubdocumentos(año, numero)
        dgSubdocumentos.Enabled = False

        celdaEmpresa.Text = Sesion.IdEmpresa
        celdaTipo.Text = 296
        celdaUsuario.Text = Sesion.Usuario
        celdaTasa.Text = cfun.QueryTasa
        checkRevisado.Enabled = False

        'celdaSerie.Text = "A"

        SDoc.Año = celdaAño.Text
        SDoc.Numero = celdaNumero.Text
        SDoc.Catalogo = 36
        dgFacturacion.Enabled = True
        celdaFlete.Enabled = True
        celdaSeguro.Enabled = True
        dtpFecha.Enabled = True
        botonCliente.Enabled = True
        celdaSerie.Enabled = False
        botonSeguro.Enabled = True

    End Sub

    Private Sub Encabezado1_ClickCerrar(sender As Object, click As Boolean) Handles Encabezado1.ClickCerrar

        If panelDocumento.Visible = True Then
            MostrarLista()
        Else
            Me.Close()
        End If

    End Sub

    Private Sub Encabezado1_ClickGuardar(sender As Object, click As Boolean) Handles Encabezado1.ClickGuardar
        Dim strSQL As String = STR_VACIO
        Dim ComParChil As String = STR_VACIO
        Dim COM As MySqlCommand
        Dim conec As MySqlConnection
        Dim logVacia As Boolean
        Dim strDato As String = STR_VACIO
        Dim cls As New clsFunciones

        ' Este codigo evita anulacion de Factura. Si hay dependencias a factura no se puede anular.
        If etiquetaAnulada.Visible Then

            strSQL = vbNullString
            strSQL &= " select sum(b)from("
            strSQL &= "      SELECT COUNT(*) b"
            strSQL &= "          FROM Dcmtos_DTL_Pro p"
            strSQL &= "              left join Dcmtos_HDR h on h.HDoc_Sis_Emp = p.PDoc_Sis_Emp And h.HDoc_Doc_Cat = p.PDoc_Chi_Cat And h.HDoc_Doc_Ano = p.PDoc_Chi_Ano And h.HDoc_Doc_Num = p.PDoc_Chi_Num"
            strSQL &= "                  Where p.PDoc_Sis_Emp = {empresa} And p.PDoc_Par_Cat = 36 And p.PDoc_Par_Ano = {año} And p.PDoc_Par_Num = {numero} And h.HDoc_Doc_Status = 1"
            strSQL &= "               UNION"
            strSQL &= "                  Select count(*)b"
            strSQL &= "                from ECtaCte c"
            strSQL &= "              left join Dcmtos_HDR hh on hh.HDoc_Sis_Emp = c.ECta_Sis_Emp and hh.HDoc_Doc_Cat =c.ECta_Doc_Cat and hh.HDoc_Doc_Ano = c.ECta_Doc_Ano and hh.HDoc_Doc_Num =c.ECta_Doc_Num"
            strSQL &= "          where c.ECta_Sis_Emp = {empresa} And c.ECta_Ref_Cat = 36 And c.ECta_Ref_Ano = {año} And c.ECta_Ref_Num = {numero} And c.ECta_Ref_Cat != c.ECta_Doc_Cat  And hh.HDoc_Doc_Status = 1 )d"

            strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
            strSQL = Replace(strSQL, "{año}", celdaAño.Text)
            strSQL = Replace(strSQL, "{numero}", celdaNumero.Text)

            conec = New MySqlConnection(strConexion)
            conec.Open()
            COM = New MySqlCommand(strSQL, conec)
            ComParChil = COM.ExecuteScalar
            conec.Close()

            If ComParChil = 0 Then
            ElseIf ComParChil > 0 Then
                MsgBox("This bill can not be canceled, is related to other agencies")
                cls.MostrarDependencias(36, celdaAño.Text, celdaNumero.Text)
                Exit Sub
            End If

        End If

        ' Si hay dependencias a Factura no se puede anular.

        If Not MyCnn.CONECTAR = strConexion Then Exit Sub
        If Not rbNacionalizacion.Checked Or rbExportacion.Checked Then
            MsgBox("You have not selected the Type" & vbCr & vbCr &
                    "Nationalization:" & vbCr & "-sales tax payments" & vbCr & vbCr &
                    "Export: " & vbCr & "- Central America or the rest of the world", vbExclamation, "Notice")
            Exit Sub
        End If

        logVacia = (Me.Tag = "Nuevo") And checkActivar.Checked = False

        'Comprueba las cantidades a descargar
        If ComprobarGastos() Then
            If ComprobarDescargos() Then
                If ComprobarLineas() Then

                End If
            End If
        End If


        If etiquetaAnulada.Visible Then
            If checkActivar.Enabled Then
                strDato = "Status Change: CANCELED"
            Else
                MsgBox("No changes allowed", vbExclamation, "Invoice -CANCELED-")
            End If
        End If

        If Me.Tag = "Nuevo" Then
            If ComprobarDatos() = True Then
                logImpuesto = PagoDeImpuestos()
                If logImpuesto Then
                    logLibre = False
                End If

                celdaNumero.Text = cls.Verificacion_Nuevo_Registro(celdaNumero.Text, "Dcmtos", 36, celdaAño.Text, celdaIdCliente.Text)
                If celdaNumero.Text > 0 Then
                    DatosDeCliente()

                    'Reescribe los datos de las instrucciones afectadas
                    If Not logVacia Then ReescribirInstruccion()

                    'InstruccionDespachada()

                    GuardarDocumento()

                    If Not logVacia Then
                        GuardarDetalle()
                        GuargarDescargos()
                        GuardarBultos()
                        DescargarReserva()
                    End If

                    'frmSubDocumentos.GuardarCaso()
                    GuardarOperacion()

                    Dim acAdd As clsFunciones.AccEnum
                    cFunciones.EscribirRegistro(TBL_DOCUMENTOS, acAdd, , Val(celdaTipo.Text), Val(celdaAño.Text), Val(celdaNumero.Text), dgReferencia.SelectedCells(6).Value)

                    'NOTA: no se escribe póliza contable porque debe estar impresa y no puede imprimirse si no está guardada
                    If Me.Tag = "Nuevo" Then
                        If MsgBox("The document has been saved" & vbCr & vbCr & "¿To save the document?", vbQuestion + vbYesNo + vbDefaultButton2, "Close document") = vbYes Then
                            If logImpuesto Then
                                MsgBox("This firm has Tax." & vbCr & vbCr & "You can not print until the certificate of origin", vbInformation, "Certificate of origin")
                            End If
                            MostrarLista()
                        Else
                            celdaAño.Enabled = False
                            celdaNumero.Enabled = False
                            botonCliente.Enabled = False
                            logAdded = True
                            With frmSubDocumentos
                                botonImprimir.Enabled = logLibre
                            End With
                        End If

                        If logVacia Then Encabezado1.botonGuardar.Enabled = False
                        If logVacia Then botonImprimir.Enabled = False
                    End If
                End If
            End If
        ElseIf Me.Tag = "Mod" Then      'Actualizando

            ComprobarDatos()

            'Reescribe los datos de las instrucciones afectadas
            ReescribirInstruccion()
            GuardarDocumento()

            GuardarDetalle()
            GuardarBultos()
            GuargarDescargos()
            GuardarOperacion()
            DescargarReserva()

            Dim acUpdate As clsFunciones.AccEnum
            cFunciones.EscribirRegistro(TBL_DOCUMENTOS, acUpdate, , Val(celdaTipo.Text), Val(celdaAño.Text), Val(celdaNumero.Text), dgReferencia.SelectedCells(6).Value)


            If MsgBox("The document has been update" & vbCr & vbCr & "To close the document?", vbQuestion + vbYesNo + vbDefaultButton2, "Close document") = vbYes Then
                If Not logPrinted Then
                    If logLibre Then
                        If MsgBox("The document has been update" & vbCr & vbCr & "¿To print?", vbQuestion + vbYesNo + vbDefaultButton2, "To Print") = vbYes Then
                        End If
                    End If
                End If

                MostrarLista()
            End If
        Else
            MsgBox("It was not possible  to classify the operation to save", vbExclamation, "Notice")
        End If


    End Sub

    Private Sub botonCliente_Click(sender As Object, e As EventArgs) Handles botonCliente.Click
        Me.Tag = "Nuevo"
        Dim frm As New frmSeleccionar
        Dim strSQL As String
        Dim strCondicion As String = STR_VACIO
        Dim año As Integer
        Dim numero As Integer
        strCondicion = "c.cli_sisemp  = {empresa} AND c.cli_status  = 'Activo' "
        strCondicion = Replace(strCondicion, "{empresa}", Sesion.IdEmpresa)
        Try
            frm.Titulo = "Client"
            frm.Campos = " c.cli_codigo , c.cli_cliente , c.cli_direccion , c.cli_telefono , c.cli_nit "
            frm.Tabla = " Clientes c"
            frm.FiltroText = " Enter the client to filter"
            frm.Filtro = "  c.cli_cliente"
            frm.Limite = 30
            frm.Ordenamiento = " c.cli_codigo "
            frm.TipoOrdenamiento = ""
            frm.Condicion = strCondicion

            frm.ShowDialog(Me)
            If frm.DialogResult = System.Windows.Forms.DialogResult.OK Then
                celdaIdCliente.Text = frm.LLave
                celdaCliente.Text = frm.Dato
                celdaDireccion.Text = frm.Dato2
                celdaTelefono.Text = frm.Dato3
                celdaNIT.Text = frm.Dato4

                dgFacturacion.Rows.Clear()
                ListarDocumentos()
                ProcesarDocumentos()
                celdaTasa.Text = cfun.QueryTasa
                celdaMoneda.Text = "US$"
                celdaIdMoneda.Text = 178

            End If

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try


    End Sub

    Private Sub botonMoneda_Click(sender As Object, e As EventArgs) Handles botonMoneda.Click

        Dim frm As New frmSeleccionar

        Try
            frm.Titulo = "Currency"
            frm.Campos = " cat_num Code, cat_clave Currency"
            frm.Tabla = " Catalogos"
            frm.FiltroText = " Enter the Name of the Currency to Filter"
            frm.Filtro = " cat_clave "
            frm.Condicion = "cat_clase = 'monedas'"

            frm.ShowDialog(Me)
            If frm.DialogResult = System.Windows.Forms.DialogResult.OK Then
                celdaIdMoneda.Text = frm.LLave
                celdaMoneda.Text = frm.Dato
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub dgLista_DoubleClick(sender As Object, e As EventArgs) Handles dgLista.DoubleClick

        Dim año As Integer = 0
        Dim numero As Integer = 0
        Dim Linea As Integer = 0
        Dim strSQL As String = STR_VACIO

        Try
            Me.Tag = "Mod"
            If dgLista.SelectedRows.Count = INT_CERO Then Exit Sub
            'captura el año,numero del panelprincipal dglista
            año = dgLista.SelectedCells(0).Value
            numero = dgLista.SelectedCells(1).Value
            Seleccionar(año, numero)
            MostrarLista(0)
            SeleccionarSubdocumentos(año, numero)
            queryCC(año, numero)
            queryDetalle(año, numero)
            queryInstDespacho(año, numero)
            CalcularTotales()
            sqlCargarRelacion()
            SqlDocsPorProcesar()
            celdaIdMoneda.Text = 178
            If dgLista.SelectedCells(6).Value = 0 Then
                etiquetaAnulada.Visible = True
                etiquetaAnulada.BackColor = Color.Red
                etiquetaAnulada.ForeColor = Color.White
                'checkActivar.Checked = False
                checkActivar.Enabled = False
            Else
                etiquetaAnulada.Visible = False
                checkActivar.Enabled = True
            End If

            dgSubdocumentos.Enabled = True
            dgFacturacion.Enabled = False
            celdaSeguro.Enabled = False
            celdaFlete.Enabled = False
            dtpFecha.Enabled = False
            botonCliente.Enabled = False
            checkRevisado.Enabled = False
            celdaSerie.Enabled = False
            botonSeguro.Enabled = False

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try

    End Sub

    Private Sub botonConcolidacion_Click(sender As Object, e As EventArgs) Handles botonConcolidacion.Click

        Dim frm As New frmManifiesto()

        frm.Show()

    End Sub

    Private Sub dgDetalle_CellEndEdit(sender As Object, e As DataGridViewCellEventArgs) Handles dgDetalle.CellEndEdit
        Dim intBultos As String
        Dim intCantidad As Double
        Dim intMedida As String

        Select Case dgDetalle.CurrentCell.ColumnIndex
            Case 14
                intBultos = dgDetalle.SelectedCells(14).Value
                intCantidad = dgDetalle.SelectedCells(12).Value
                intMedida = dgDetalle.SelectedCells(7).Value
                CalcularKGBrutos(intBultos, intCantidad, intMedida)
        End Select
    End Sub

    Private Sub dgDetalle_DoubleClick(sender As Object, e As EventArgs) Handles dgDetalle.DoubleClick

        Dim FRef As New frmFacturasRef_Aux_
        Dim NC As New frmNumCajas
        Dim CV As New frmCatVentas


        Select Case dgDetalle.CurrentCell.ColumnIndex

            Case 1
                'If dgDetalle.SelectedRows.Count = 0 Then Exit Sub

                FRef.intnumero = dgDetalle.SelectedCells(0).Value
                FRef.intaño = dgDetalle.SelectedCells(2).Value
                FRef.intlinea = dgDetalle.SelectedCells(4).Value
                FRef.ShowDialog(Me)

            Case 15
                Dim frm As New frmSeleccionar

                Try
                    frm.Titulo = "Package Type"
                    frm.Campos = " cat_num, cat_Desc"
                    frm.Tabla = " Catalogos"
                    frm.FiltroText = " Enter the Package Type to filter"
                    frm.Filtro = " cat_Desc "
                    frm.Condicion = "  cat_clase = 'TipoBulto'"

                    frm.ShowDialog(Me)
                    If frm.DialogResult = System.Windows.Forms.DialogResult.OK Then
                        dgDetalle.SelectedCells(15).Value = frm.Dato
                    End If

                Catch ex As Exception
                    MsgBox(ex.ToString)
                End Try

            Case 20

                Dim frm As New frmSeleccionar
                Dim strCondicion As String = STR_VACIO
                strCondicion = "cli_sisemp = {empresa}"
                strCondicion = Replace(strCondicion, "{empresa}", Sesion.IdEmpresa)
                Try
                    frm.Titulo = "Sales Catalog"
                    frm.Campos = " cli_codigo, cli_cliente, cli_status"
                    frm.Tabla = " Clientes"
                    frm.FiltroText = " Enter the Client Name to filter"
                    frm.Filtro = " cli_cliente "
                    frm.Condicion = strCondicion

                    frm.ShowDialog(Me)
                    If frm.DialogResult = System.Windows.Forms.DialogResult.OK Then

                        dgDetalle.SelectedCells(19).Value = frm.LLave
                        dgDetalle.SelectedCells(20).Value = frm.Dato

                    End If

                Catch ex As Exception
                    MsgBox(ex.ToString)
                End Try


        End Select


    End Sub

    Private Sub botonActualizar_Click(sender As Object, e As EventArgs) Handles botonActualizar.Click

        Dim logCancelar As Boolean

        If CDate(dtpInicio.Value) > CDate(dtpFinal.Value) Then
            MsgBox("The start date may not exceed the final date", vbExclamation, "Notice")
            logCancelar = True
        End If
        If Not (logCancelar) Then
            'strOrigen = PrepararListado

            'Procedimiento para cargar panel dgLista
            queryListaPrincipal()


        End If


    End Sub

    Private Sub botonPolizaC_Click(sender As Object, e As EventArgs) Handles botonPolizaC.Click

        Dim frm As New frmOption
        Dim NP As New clsPolizaContable
        Dim NPC As New frmNPolizasContables


        Try
            frm.Titulo = "Mostrar Poliza Contable"
            frm.Opciones = "Venta|" & "Costos"
            frm.ShowDialog(Me)
            If frm.DialogResult = System.Windows.Forms.DialogResult.OK Then
                Select Case frm.Seleccion
                    Case 0
                        NP.intModo = 9
                        NP.intTipo = 36
                        NP.intCiclo = celdaAño.Text
                        NP.intNumero = celdaNumero.Text
                        NP.MostrarPolizaContable()

                    Case 1
                        NP.intModo = 10
                        NP.intTipo = 36
                        NP.intCiclo = celdaAño.Text
                        NP.intNumero = celdaNumero.Text
                        NP.MostrarPolizaContable()
                End Select
            End If

        Catch ex As Exception
            MsgBox("It has no Accounting Policy")
        End Try

    End Sub

    Private Sub CalcularTotales()
        Dim i As Integer
        Dim dblPrecio As Double
        Dim dblCant As Double

        Try
            dblDocCantidad = 0
            dblDocTotal = 0
            For i = vbEmpty To dgDetalle.Rows.Count - 1
                dblPrecio = dgDetalle.Rows(i).Cells("colPrecio").Value
                dblCant = dgDetalle.Rows(i).Cells("colCantidad").Value
                dblDocCantidad = dblDocCantidad + dblCant
                dblDocTotal = dblDocTotal + (dblCant * dblPrecio)
            Next
            celdaTotal1.Text = dblDocCantidad
            celdaTotal2.Text = dblDocTotal

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try

    End Sub

    Private Sub dgSubdocumentos_DoubleClick(sender As Object, e As EventArgs) Handles dgSubdocumentos.DoubleClick

        Dim SDoc As New frmSubDocumentos
        Dim strDoc As String

        strDoc = dgSubdocumentos.SelectedCells(0).Value

        Select Case dgSubdocumentos.CurrentCell.ColumnIndex

            Case 2
                If dgSubdocumentos.SelectedCells(2).Value = "SI" Then
                    SDoc.SubDocumento = dgSubdocumentos.SelectedCells(0).Value
                    SDoc.Año = CInt(celdaAño.Text)
                    SDoc.Numero = CInt(celdaNumero.Text)
                    SDoc.Catalogo = 36
                    SDoc.Doc = strDoc

                    SDoc.ShowDialog(Me)
                Else
                    SDoc.SubDocumento = dgSubdocumentos.SelectedCells(0).Value
                    SDoc.Año = celdaAño.Text
                    SDoc.Numero = celdaNumero.Text
                    SDoc.Doc = strDoc
                    SDoc.Catalogo = 36
                    SDoc.ShowDialog(Me)
                End If
        End Select
    End Sub

    Private Sub dgLista_SelectionChanged(sender As Object, e As EventArgs) Handles dgLista.SelectionChanged
        Dim año As Integer
        Dim numero As Integer

        If CheckMuestraDetalle.Checked = True Then
            año = dgLista.SelectedCells(0).Value
            numero = dgLista.SelectedCells(1).Value
            queryCheckMuestraDetalle(año, numero)
        Else
            celdaInfoDetalle.Text = " "
        End If
    End Sub

    Private Sub checkActivar_Click(sender As Object, e As EventArgs) Handles checkActivar.Click

        If checkActivar.Checked = False Then
            etiquetaAnulada.Visible = True
            etiquetaAnulada.ForeColor = Color.Red
            etiquetaAnulada.BackColor = Color.Orange
        Else
            etiquetaAnulada.Visible = False
        End If

    End Sub

    Private Sub botonCarga_Click(sender As Object, e As EventArgs) Handles botonCarga.Click

        Dim COM As MySqlCommand
        Dim COM2 As MySqlCommand
        Dim REA As MySqlDataReader
        Dim strSQL As String
        Dim año As Integer
        Dim tipo As Integer
        Dim numero As Integer


        If dgLista.SelectedRows.Count = 0 Then

        Else

            tipo = 36
            año = dgLista.SelectedCells(0).Value
            numero = dgLista.SelectedCells(1).Value

            strSQL = "      SELECT IFNULL(h.HDoc_RF2_Cod,0) cargado,h.HDoc_Doc_Status estado"
            strSQL &= "   FROM Dcmtos_HDR h"
            strSQL &= "  WHERE h.HDoc_Sis_Emp={empresa} AND h.HDoc_Doc_Cat=36 AND h.HDoc_Doc_Ano={año} AND h.HDoc_Doc_Num={numero}"
            strSQL &= " LIMIT 1"

            strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
            strSQL = Replace(strSQL, "{año}", año)
            strSQL = Replace(strSQL, "{numero}", numero)
            Try
                MyCnn.CONECTAR = strConexion
                COM = New MySqlCommand(strSQL, CON)
                REA = COM.ExecuteReader
                REA.Read()
                'No Anulados
                If REA.GetInt32("Estado") = INT_UNO Then
                    If REA.GetInt32("Cargado") = vbEmpty Then
                        If MsgBox("Indicate that the invoice: " & numero & " it was loaded. " & vbNewLine & vbNewLine & "NOTA: These changes are not reversibles. Do you wish to continue?", vbQuestion + vbYesNo + vbDefaultButton2, "Print release") = vbYes Then
                            strSQL = ""
                            strSQL &= "    UPDATE Dcmtos_HDR h set h.HDoc_RF2_Cod = 1 "
                            strSQL &= "WHERE h.HDoc_Sis_Emp={empresa} AND h.HDoc_Doc_Cat=36 AND h.HDoc_Doc_Ano={año} AND h.HDoc_Doc_Num={numero}"
                            If Sesion.IdEmpresa = 18 Then
                                strSQL &= ";    UPDATE PDM.Dcmtos_HDR h set h.HDoc_RF2_Cod = 1 "
                                strSQL &= "WHERE h.HDoc_Sis_Emp={empresa} AND h.HDoc_Doc_Cat=36 AND h.HDoc_Doc_Ano={año} AND h.HDoc_Doc_Num={numero}"
                            End If
                            strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
                            strSQL = Replace(strSQL, "{año}", año)
                            strSQL = Replace(strSQL, "{numero}", numero)

                            dgLista.SelectedCells(3).Style.BackColor = Color.White
                        End If
                    Else
                        MsgBox("The document was already loaded")
                    End If
                End If

                MyCnn.CONECTAR = strConexion
                COM2 = New MySqlCommand(strSQL, CON)
                COM2.ExecuteNonQuery()

                'Registrar evento
                cFunciones.EscribirRegistro("Dcmntos_HDR", clsFunciones.AccEnum.acCargar, numero, tipo, año)

            Catch ex As Exception
                MsgBox(ex.ToString)
            End Try
        End If

    End Sub

    Private Sub botonPoliza_Click(sender As Object, e As EventArgs) Handles botonPoliza.Click

        Dim COM As MySqlCommand
        Dim COM2 As MySqlCommand
        Dim COM3 As MySqlCommand
        Dim REA As MySqlDataReader
        Dim strSQL As String
        Dim año As Integer
        Dim tipo As Integer
        Dim numero As Integer


        If dgLista.SelectedRows.Count = 0 Then

        Else

            tipo = 36
            año = dgLista.SelectedCells(0).Value
            numero = dgLista.SelectedCells(1).Value

            strSQL = "       SELECT IFNULL(h.HDoc_RF1_Cod,0) cargado,h.HDoc_Doc_Status estado"
            strSQL &= "     From Dcmtos_HDR h"
            strSQL &= "   WHERE h.HDoc_Sis_Emp={empresa} AND h.HDoc_Doc_Cat=36 AND h.HDoc_Doc_Ano={año} AND h.HDoc_Doc_Num={numero}"
            strSQL &= "  LIMIT 1"

            strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
            strSQL = Replace(strSQL, "{año}", año)
            strSQL = Replace(strSQL, "{numero}", numero)

            Try
                MyCnn.CONECTAR = strConexion
                COM = New MySqlCommand(strSQL, CON)
                REA = COM.ExecuteReader
                REA.Read()
                'No Anulados
                'No Anulados
                If REA.GetInt32("Estado") = INT_UNO Then
                    If REA.GetInt32("Cargado") = vbEmpty Then
                        If MsgBox("indicate that the invoice: " & numero & " it was loaded. " & vbNewLine & vbNewLine & "NOTA: These changes will not be reversible. Do you wish to continue?", vbQuestion + vbYesNo + vbDefaultButton2, "Print release") = vbYes Then
                            strSQL = ""
                            strSQL &= "    UPDATE Dcmtos_HDR h set h.HDoc_RF1_Cod = 1 "
                            strSQL &= "WHERE h.HDoc_Sis_Emp={empresa} AND h.HDoc_Doc_Cat=36 AND h.HDoc_Doc_Ano={año} AND h.HDoc_Doc_Num={numero}"
                            If Sesion.IdEmpresa = 18 Then
                                strSQL &= ";    UPDATE PDM.Dcmtos_HDR h set h.HDoc_RF1_Cod = 1 "
                                strSQL &= "WHERE h.HDoc_Sis_Emp={empresa} AND h.HDoc_Doc_Cat=36 AND h.HDoc_Doc_Ano={año} AND h.HDoc_Doc_Num={numero}"
                            End If
                            strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
                            strSQL = Replace(strSQL, "{año}", año)
                            strSQL = Replace(strSQL, "{numero}", numero)

                            dgLista.SelectedCells(4).Style.BackColor = Color.White
                        End If
                    Else
                        MsgBox("The document was already loaded")
                    End If
                End If

                MyCnn.CONECTAR = strConexion
                COM2 = New MySqlCommand(strSQL, CON)
                COM2.ExecuteNonQuery()

                'Registrar evento
                cFunciones.EscribirRegistro("Dcmntos_HDR", clsFunciones.AccEnum.acCargar, numero, tipo, año)

            Catch ex As Exception
                MsgBox(ex.ToString)
            End Try
        End If
    End Sub

    Private Sub botonSalida_Click(sender As Object, e As EventArgs) Handles botonSalida.Click
        Dim COM As MySqlCommand
        Dim COM2 As MySqlCommand
        Dim COM3 As MySqlCommand
        Dim REA As MySqlDataReader
        Dim strSQL As String
        Dim año As Integer
        Dim tipo As Integer
        Dim numero As Integer
        Dim logFecha As Boolean


        If dgLista.SelectedRows.Count = 0 Then

        Else

            tipo = 36
            año = dgLista.SelectedCells(0).Value
            numero = dgLista.SelectedCells(1).Value

            strSQL = "       SELECT IF(ISNULL(HDoc_DR1_Fec),0,1) Salida, IFNULL(HDoc_DR2_Cat,0) Impreso, HDoc_Doc_Status Estado"
            strSQL &= "     FROM Dcmtos_HDR"
            strSQL &= "  WHERE HDoc_Sis_Emp={empresa} AND HDoc_Doc_Cat=36 AND HDoc_Doc_Ano={año} AND HDoc_Doc_Num={numero}"
            strSQL &= " LIMIT 1"

            strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
            strSQL = Replace(strSQL, "{año}", año)
            strSQL = Replace(strSQL, "{numero}", numero)

            Try
                MyCnn.CONECTAR = strConexion
                COM = New MySqlCommand(strSQL, CON)
                REA = COM.ExecuteReader
                REA.Read()

                'No Anulados
                If REA.GetInt32("Estado") = INT_UNO Then
                    If REA.GetInt32("Impreso") = vbEmpty Then
                        MsgBox("To print the document before confirming his departure", vbExclamation, "Notice")
                    Else
                        logFecha = (REA.GetInt32("Salida") = INT_UNO)
                        If logFecha Then
                            'dgLista.SelectedCells(1).Style.BackColor = Color.White
                        ElseIf MsgBox("Confirms the outputs of invoice number" & numero & "?", vbQuestion + vbYesNo + vbDefaultButton2, "Exit confirmation") = vbYes Then
                            strSQL = "    UPDATE Dcmtos_HDR SET HDoc_DR1_Fec={dato}"
                            strSQL &= " WHERE HDoc_Sis_Emp={empresa} AND HDoc_Doc_Cat=36 AND HDoc_Doc_Ano={año} AND HDoc_Doc_Num={numero}"
                            If Sesion.IdEmpresa = 18 Then
                                strSQL &= ";    UPDATE DPM.Dcmtos_HDR SET HDoc_DR1_Fec={dato}"
                                strSQL &= " WHERE HDoc_Sis_Emp={empresa} AND HDoc_Doc_Cat=36 AND HDoc_Doc_Ano={año} AND HDoc_Doc_Num={numero}"
                            End If
                            strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
                            strSQL = Replace(strSQL, "{año}", año)
                            strSQL = Replace(strSQL, "{numero}", numero)
                            strSQL = Replace(strSQL, "{dato}", "CURDATE()")
                        End If
                    End If

                    MyCnn.CONECTAR = strConexion
                    COM2 = New MySqlCommand(strSQL, CON)
                    COM2.ExecuteNonQuery()
                    'Actualizar fecha de autorización
                    strSQL = " REPLACE INTO Dcmtos_ACC (ADoc_Sis_Emp,ADoc_Doc_Cat,ADoc_Doc_Ano,ADoc_Doc_Num,ADoc_Doc_Sub,ADoc_Doc_Lin,ADoc_Dta_Des,ADoc_Dta_Chr) VALUES ({empresa},36,{año},{numero},'{grupo}','{linea}','{nombre}',{dato})"
                    strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
                    strSQL = Replace(strSQL, "{año}", año)
                    strSQL = Replace(strSQL, "{numero}", numero)
                    strSQL = Replace(strSQL, "{grupo}", ("Doc_CFNotas"))
                    strSQL = Replace(strSQL, "{linea}", ("01"))
                    strSQL = Replace(strSQL, "{nombre}", ("Fecha de Autorizacion"))
                    strSQL = Replace(strSQL, "{dato}", "CURDATE()")


                    dgLista.SelectedCells(2).Style.BackColor = Color.White
                End If

                MyCnn.CONECTAR = strConexion
                COM3 = New MySqlCommand(strSQL, CON)
                'COM3.ExecuteScalar()

                'Registrar evento
                cFunciones.EscribirRegistro("Dcmntos_HDR", clsFunciones.AccEnum.acCargar, numero, tipo, año)
                MsgBox("The date of authorization has been update notes", vbInformation, "Exit confirmation")
            Catch ex As Exception
                MsgBox(ex.ToString)
            End Try
        End If

    End Sub

    Private Sub botonLiberar_Click(sender As Object, e As EventArgs) Handles botonLiberar.Click
        Dim COM As MySqlCommand
        Dim COM2 As MySqlCommand
        Dim REA As MySqlDataReader
        Dim conec As MySqlConnection
        Dim strSQL As String
        Dim año As Integer
        Dim tipo As Integer
        Dim numero As Integer
        Dim logFecha As Boolean

        If dgLista.SelectedRows.Count = 0 Then

        Else

            tipo = 36
            año = dgLista.SelectedCells(0).Value
            numero = dgLista.SelectedCells(1).Value

            strSQL = "       SELECT IFNULL(HDoc_DR2_Emp,0) Pago, IF(ISNULL(HDoc_DR2_Fec),0,1) Liberado, IFNULL(HDoc_DR2_Cat,0) Impreso, HDoc_Doc_Status Estado"
            strSQL &= "     FROM Dcmtos_HDR"
            strSQL &= "  WHERE HDoc_Sis_Emp={empresa} AND HDoc_Doc_Cat=36 AND HDoc_Doc_Ano={año} AND HDoc_Doc_Num={numero}"
            strSQL &= " LIMIT 1"

            strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
            strSQL = Replace(strSQL, "{año}", año)
            strSQL = Replace(strSQL, "{numero}", numero)

            Try
                MyCnn.CONECTAR = strConexion
                COM = New MySqlCommand(strSQL, CON)
                REA = COM.ExecuteReader
                REA.Read()



                'No Anulados
                If REA.GetInt32("Estado") = INT_UNO Then
                    If REA.GetInt32("Pago") = vbEmpty Then
                        MsgBox("This office has no tax" & vbNewLine & vbNewLine & "It is not necesary to block printing", vbExclamation, "Notice")
                    Else
                        logFecha = (REA.GetInt32("Liberado") = INT_UNO)
                        If logFecha Then
                            MsgBox("This bill has no restrictions printed", vbInformation, "Notice")
                        ElseIf MsgBox("Release the invoice number " & numero & "?" & vbNewLine & vbNewLine & "NOTA: and you must have a certificate of origin", vbQuestion + vbYesNo + vbDefaultButton2, "Liberar Impresión") = vbYes Then
                            strSQL = "    UPDATE Dcmtos_HDR SET HDoc_DR2_Emp=1 AND HDoc_DR2_Fec={dato}"
                            strSQL &= " WHERE HDoc_Sis_Emp={empresa} AND HDoc_Doc_Cat=36 AND HDoc_Doc_Ano={año} AND HDoc_Doc_Num={numero}"
                            If Sesion.IdEmpresa = 18 Then
                                strSQL &= ";    UPDATE PDM.Dcmtos_HDR SET HDoc_DR2_Emp=1 AND HDoc_DR2_Fec={dato}"
                                strSQL &= " WHERE HDoc_Sis_Emp={empresa} AND HDoc_Doc_Cat=36 AND HDoc_Doc_Ano={año} AND HDoc_Doc_Num={numero}"
                            End If
                            strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
                            strSQL = Replace(strSQL, "{año}", año)
                            strSQL = Replace(strSQL, "{numero}", numero)
                            strSQL = Replace(strSQL, "{dato}", "CURDATE()")

                            dgLista.SelectedCells(2).Style.BackColor = Color.Orange
                        End If
                        MyCnn.CONECTAR = strConexion
                        COM2 = New MySqlCommand(strSQL, CON)
                        COM2.ExecuteNonQuery()


                        'Registrar evento
                        cFunciones.EscribirRegistro("Dcmntos_HDR", clsFunciones.AccEnum.acCargar, numero, tipo, año)
                        MsgBox("It is released the printing of this document", vbInformation, "Notice")
                    End If
                End If

            Catch ex As Exception
                MsgBox(ex.ToString)
            End Try
        End If
    End Sub

    'Calcula el seguro con 1.38% como base (1.375) y la suma como FOB
    Private Sub botonSeguro_Click(sender As Object, e As EventArgs) Handles botonSeguro.Click
        Dim dblFactor As Double
        Dim i As Integer
        Dim dblSuma As Double
        Dim dblSeguro As Double
        Dim strSQL As String = STR_VACIO
        Dim COM As MySqlCommand

        strSQL = "SELECT COALESCE(cat_sist,0) dato"
        strSQL &= " FROM Catalogos"
        strSQL &= "      WHERE cat_clase='Constantes' AND cat_clave='Seguro'"


        MyCnn.CONECTAR = strConexion
        COM = New MySqlCommand(strSQL, CON)
        dblFactor = COM.ExecuteScalar()

        If dblFactor = vbEmpty Then
            dblFactor = 0.01375
        End If

        For i = vbEmpty To dgDetalle.Rows.Count - 1
            dblSuma = dblSuma + Val(dgDetalle.Rows(i).Cells("colTotal").Value)
        Next

        dblSeguro = (dblSuma * dblFactor)
        celdaSeguro.Text = dblSeguro.ToString(FORMATO_MONEDA)

    End Sub

    Private Sub botonImprimir_Click(sender As Object, e As EventArgs) Handles botonImprimir.Click
        Const MAX_LINEAS As Byte = 4
        Dim COM As MySqlCommand
        Dim conec As MySqlConnection
        Dim intNumero As Integer
        Dim intAño As Integer
        Dim Inv As New clsReportes
        Dim strSQL As String
        Dim intForma As Integer
        Dim logErr As Boolean


        If Not logLibre Then
            MsgBox("This document is locked print" & vbCr & vbCr & "Present the certificate  of origin  to the appropriate to proceed to release", vbExclamation, "Notice")
            Exit Sub
        End If

        logPrinting = True

        strSQL = "SELECT cat_sist"
        strSQL &= " FROM Catalogos "
        strSQL &= "      WHERE cat_clase='Factura' AND cat_clave='Formato' AND cat_sisemp= {empresa}"

        strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)

        conec = New MySqlConnection(strConexion)
        conec.Open()
        COM = New MySqlCommand(strSQL, conec)
        intForma = COM.ExecuteScalar
        conec.Close()


        Select Case intForma

            Case 0
            Case 1
            Case 2
                If dgDetalle.Rows.Count > MAX_LINEAS Then


                    If MsgBox("NOTA: Some lines can not print." & vbCr & vbCr & "*** There are more lines in detail in the format ***", vbExclamation + vbCancel + vbDefaultButton2, "Print format") = vbCancel Then
                        logErr = True
                    End If
                End If

                If Not logErr Then
                    intAño = Val(celdaAño.Text)
                    intNumero = Val(celdaNumero.Text)

                    Inv.ReporteInvoicing(intAño, intNumero)

                End If

            Case 3
            Case 4
                intAño = Val(celdaAño.Text)
                intNumero = Val(celdaNumero.Text)
                Inv.ReporteInvoicing_PrideYarn(intAño, intNumero)
            Case 5
                intAño = Val(celdaAño.Text)
                intNumero = Val(celdaNumero.Text)
                Inv.ReporteInvoicing_Amtex(intAño, intNumero)
        End Select
    End Sub

    Private Sub dgLista_KeyDown(sender As Object, e As KeyEventArgs) Handles dgLista.KeyDown
        Try
            If e.KeyCode = Keys.F3 Then
                cfun.BuscarenLista(dgLista)
                e.Handled = True
                e.SuppressKeyPress = True
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub dgFacturacion_DoubleClick(sender As Object, e As EventArgs) Handles dgFacturacion.DoubleClick
        Dim i As Integer
        Dim strTemp As String
        Dim strSQL As String = STR_VACIO
        Dim REA As MySqlDataReader
        Dim COM As MySqlCommand

        For i = 0 To dgFacturacion.Rows.Count - 1
            If dgFacturacion.ColumnCount > vbEmpty Then
                If Not (dgFacturacion.Rows(0).Cells(0).Value) = vbNullString Then
                    strSQL = SqlDetallePorProcesar2()
                End If
            End If

        Next

        Try
            dgFacturacion.SelectedCells(6).Value = 2
            For j As Integer = 0 To dgFacturacion.Rows.Count - 1
                If dgFacturacion.RowCount = 1 Then
                Else
                    If dgFacturacion.Rows(j).Cells("colMarca").Value = 1 Then
                        dgFacturacion.Rows.RemoveAt(j)
                    End If
                End If
            Next

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        MyCnn.CONECTAR = strConexion
        Try
            dgDetalle.Rows.Clear()
            COM = New MySqlCommand(strSQL, CON)
            REA = COM.ExecuteReader
            Do While REA.Read

                strTemp = REA.GetInt32("Numero") & "|"
                strTemp &= REA.GetInt32("Codigo") & "|"
                strTemp &= REA.GetInt32("Ano") & "|"
                strTemp &= REA.GetInt32("Linea") & "|"
                strTemp &= REA.GetInt32("Linea") & "|"
                strTemp &= REA.GetString("Descripcion") & "|"
                strTemp &= REA.GetInt32("Original") & "|"
                strTemp &= REA.GetString("Medida") & "|"
                strTemp &= REA.GetDouble("Despacho") & "|"
                strTemp &= REA.GetDouble("Precio") & "|"
                strTemp &= "0.00" & "|"
                strTemp &= "0.00" & "|"
                strTemp &= REA.GetDouble("Cantidad") & "|"
                strTemp &= REA.GetDouble("Total") & "|"
                strTemp &= "0.0" & "|"
                strTemp &= REA.GetString("Bulto") & "|"
                strTemp &= REA.GetInt32("Bobinas") & "|"
                strTemp &= REA.GetString("Distribucion") & "|"
                strTemp &= REA.GetInt32("Destino") & "|"
                strTemp &= REA.GetString("Lugar") & "|"
                strTemp &= REA.GetDouble("Libras") & "|"
                strTemp &= REA.GetDouble("Kilos") & "|"
                strTemp &= REA.GetInt32("Original") & "|"
                strTemp &= REA.GetString("Referencia") & "|"
                strTemp &= REA.GetInt32("Base")


                cFunciones.AgregarFila(dgDetalle, strTemp)
            Loop

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub
#End Region

End Class