﻿Public Class frmOrdenCompra
#Region "Miembros"
    Dim strKey As String = STR_VACIO
    Dim logInsertar As Boolean = False
    Dim logConsultar As Boolean = False
    Dim logEditar As Boolean = False
    Dim LogBorrar As Boolean = False
    Const CAT_ORD As Integer = 777
    Const catalogos As Integer = 949
    Dim intTipo As Integer
    Dim cfun As New clsFunciones
    Dim tipoResolucion As String = STR_VACIO
#End Region

#Region "Propiedades"

    Public Property Key As String
        Get
            Return strKey
        End Get
        Set(value As String)
            strKey = value
        End Set
    End Property


#End Region

#Region "Procedimientos"

    Private Sub BloquearBotones(Optional ByVal logBloquear As Boolean = True)
        If logBloquear = True Then
            Encabezado1.botonBorrar.Enabled = False
            Encabezado1.botonGuardar.Enabled = False
            botonInprimir.Enabled = False
            Encabezado1.botonNuevo.Enabled = True
        Else
            Encabezado1.botonBorrar.Enabled = True
            Encabezado1.botonGuardar.Enabled = True
            botonInprimir.Enabled = True
            Encabezado1.botonNuevo.Enabled = False
        End If

    End Sub
    Private Sub CalcularTotal()
        Dim dblGranTotal As Double = INT_CERO
        Dim dblTotal As Double = INT_CERO
        Dim dblPrecio As Double = INT_CERO
        Dim dblCantidad As Double = INT_CERO
        Try
            For i As Integer = 0 To dtDetalle.Rows.Count - 1
                If dtDetalle.Rows(i).Cells("colEstado1").Value <> 2 Then
                    dblCantidad = 0
                    dblPrecio = 0
                    dblTotal = 0

                    dblCantidad = (dtDetalle.Rows(i).Cells("colCantidad").Value)
                    dblPrecio = (dtDetalle.Rows(i).Cells("colPrecio").Value)
                    dblTotal = dblCantidad * dblPrecio
                    dblGranTotal = dblGranTotal + dblTotal
                    dtDetalle.Rows(i).Cells("colTotal").Value = dblTotal.ToString(FORMATO_MONEDA)

                End If

            Next
            celdaTotal.Text = dblGranTotal.ToString(FORMATO_MONEDA) - celdaTexto4.Text
            celdaTexto3.Text = (dblGranTotal + celdaTexto1.Text + celdaTexto2.Text).ToString(FORMATO_MONEDA)
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub CalcularDescuento()
        Dim dblDescuentoTotal As Double = INT_CERO
        Dim dblPorcentaje As Double = INT_CERO
        Dim dblDescuento As Double = INT_CERO
        Dim dblTotal As Double = INT_CERO
        Dim dblCien As Double = INT_CERO
        Try
            For i As Integer = 0 To dtDetalle.Rows.Count - 1
                If dtDetalle.Rows(i).Cells("colEstado1").Value <> 2 Then
                    dblCien = 100
                    dblPorcentaje = 0
                    dblDescuento = 0
                    dblTotal = 0

                    dblPorcentaje = (dtDetalle.Rows(i).Cells("colPercentage").Value)
                    dblTotal = (dtDetalle.Rows(i).Cells("colTotal").Value)
                    dblDescuento = (dblPorcentaje * dblTotal) / dblCien
                    dblDescuentoTotal = dblDescuentoTotal + dblDescuento
                    dtDetalle.Rows(i).Cells("colDiscounts").Value = dblDescuento.ToString(FORMATO_MONEDA)

                End If

            Next
            celdaTexto4.Text = dblDescuentoTotal.ToString(FORMATO_MONEDA)
            'celdaTexto3.Text = (dblGranTotal + celdaTexto1.Text + celdaTexto2.Text).ToString(FORMATO_MONEDA)
            CalcularTotal()
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub
    Private Function ComprobarDatos() As Boolean
        Dim logCoprobar As Boolean = True
        Dim c As Integer = 0

        If cfun.ValidarCampoTexto(celdaProveedor) = False Then
            logCoprobar = False
        End If
        ' If cfun.ValidarCampoTexto(celdaDireccion) = False Then
        'logCoprobar = False
        ' End If
        'If cfun.ValidarCampoTexto(celdaCostos) = False Then
        '    logCoprobar = False
        'End If
        For i As Integer = 0 To dtDetalle.Rows.Count - 1
            If dtDetalle.Rows(i).Visible = False Then
                c = c + 1
            End If
        Next

        If dtDetalle.Rows.Count <= 0 Or dtDetalle.Rows.Count = c Then
            MsgBox("Detail is empty")
            logCoprobar = False
        End If

        Return logCoprobar
    End Function
    Private Sub Seleccionar(ByVal intNumero As Integer, ByVal intAÑo As Integer)
        SeleccionarEncabezado(intNumero, intAÑo)
        SeleccionarDetalle(intNumero, intAÑo)
    End Sub
    Private Function SQLLista() As String
        Dim strsql As String = STR_VACIO
        'strsql = "select h.HDoc_Doc_Num Correlativo, h.HDoc_Doc_Ano Ciclo, h.HDoc_Doc_Fec Fecha,h.HDoc_Emp_Nom,HDoc_DR1_Num Serie,LPAD(h.HDoc_DR1_Dbl,5,'0') Numero,IF(h.HDoc_Doc_Status=0,'CANCELED','ACTIVE')Estado, "
        'strsql &= "   ifnull((  "
        'strsql &= "     Select sum(d.DDoc_Prd_QTY * d.DDoc_Prd_NET)"
        'strsql &= "         from Dcmtos_DTL d"
        'strsql &= "     where d.DDoc_Sis_Emp = h.HDoc_Sis_Emp and d.DDoc_Doc_Cat = h.HDoc_Doc_Cat AND d.DDoc_Doc_Ano = h.HDoc_Doc_Ano and d.DDoc_Doc_Num = h.HDoc_Doc_Num ),0) Total"
        'strsql &= "  from Dcmtos_HDR h "
        'strsql &= "where  h.HDoc_Sis_Emp = {empresa} and h.HDoc_Doc_Cat= {CAT_ORD} "
        'strsql &= " and h.HDoc_Doc_Fec between '{inicio}' and '{fin}' "
        'strsql &= " ORDER by h.HDoc_Doc_Fec desc , h.HDoc_Doc_Num DESC "


        strsql = "SELECT h.HDoc_Doc_Num Correlativo, h.HDoc_Doc_Ano Ciclo, h.HDoc_Doc_Fec Fecha,h.HDoc_Emp_Nom,HDoc_DR1_Num Serie, LPAD(h.HDoc_DR1_Dbl,5,'0') Numero,
                IF(h.HDoc_Doc_Status=0,'CANCELED','ACTIVE')Estado, 

                IFNULL((
                SELECT SUM(d.DDoc_Prd_QTY * d.DDoc_Prd_NET)
                FROM Dcmtos_DTL d
                WHERE d.DDoc_Sis_Emp = h.HDoc_Sis_Emp AND d.DDoc_Doc_Cat = h.HDoc_Doc_Cat 
                AND d.DDoc_Doc_Ano = h.HDoc_Doc_Ano AND d.DDoc_Doc_Num = h.HDoc_Doc_Num),0) Total

                ,IFNULL(SUM(dd.DDoc_Prd_QTY * dd.DDoc_Prd_NET),0) TOTAL2
                ,IFNULL((SELECT NombreIngles FROM {conta}.nomenclatura n WHERE n.idEmpresa=h.HDoc_Sis_Emp AND n.idcuenta= dd.DDoc_RF2_Txt AND nivelCta=2),0) colIdCosto
                ,IFNULL((SELECT NombreIngles FROM {conta}.nomenclatura n WHERE n.idEmpresa=h.HDoc_Sis_Emp AND n.idcuenta= dd.DDoc_RF3_Txt AND nivelCta=3),0) colIdCentroCosto
                FROM Dcmtos_HDR h
                LEFT JOIN Dcmtos_DTL dd ON  h.HDoc_Sis_Emp=dd.DDoc_Sis_Emp AND h.HDoc_Doc_Cat=dd.DDoc_Doc_Cat AND h.HDoc_Doc_Ano=dd.DDoc_Doc_Ano AND h.HDoc_Doc_Num=dd.DDoc_Doc_Num
                WHERE h.HDoc_Sis_Emp = {empresa} AND h.HDoc_Doc_Cat= {CAT_ORD}"

        If checkFechas.Checked = True Then
            strsql &= " and h.HDoc_Doc_Fec between '{inicio}' and '{fin}' "
            strsql = Replace(strsql, "{inicio}", dtpInicio.Value.ToString(FORMATO_MYSQL))
            strsql = Replace(strsql, "{fin}", dtpFin.Value.ToString(FORMATO_MYSQL))
        End If
        strsql &= "GROUP BY h.HDoc_Sis_Emp,h.HDoc_Doc_Cat,h.HDoc_Doc_Ano,h.HDoc_Doc_Num "
        strsql &= " ORDER by h.HDoc_Doc_Fec desc , h.HDoc_Doc_Num DESC "
        strsql = Replace(strsql, "{conta}", Sesion.BaseConta)
        strsql = Replace(strsql, "{empresa}", Sesion.IdEmpresa)
        strsql = Replace(strsql, "{CAT_ORD}", CAT_ORD)

        Return strsql
    End Function
    Private Sub Accessos()
        Dim cAccesos As New clsAccesos
        Try
            If cAccesos.Accesos(strKey) = True Then
                logInsertar = cAccesos.Insertar
                logConsultar = cAccesos.Consultar
                logEditar = cAccesos.Editar
                LogBorrar = cAccesos.Borrar
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub
    Private Function CargarSerie() As String
        Dim strSQL As String = STR_VACIO
        Dim conec As New MySqlConnection
        Dim COM As New MySqlCommand
        Dim intSerie As Integer
        strSQL = " SELECT cat_pid "
        strSQL &= " FROM Catalogos"
        strSQL &= " WHERE cat_clase='Serie' AND cat_clave= 'Doc_COrdenC' AND cat_sisemp = {empresa}"

        strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
        conec = New MySqlConnection(strConexion)
        conec.Open()
        COM = New MySqlCommand(strSQL, CON)
        intSerie = COM.ExecuteScalar
        conec.Close()
        conec.Dispose()
        conec = Nothing
        System.GC.Collect()
        If intSerie = 1 Then
            celdaSerie.Text = "OCN"
        End If
        Return celdaSerie.Text
    End Function
    Private Sub reset()
        Dim strSQL As String = STR_VACIO
        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader
        Dim ValorMoneda As String = STR_VACIO
        Dim IdMoneda As Integer = INT_CERO

        If Sesion.IdEmpresa = 2 Then
            IdMoneda = 182

            strSQL = sqlDatosMoneda(IdMoneda)
            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSQL, CON)
            REA = COM.ExecuteReader

            If REA.HasRows Then
                REA.Read()
                ValorMoneda = REA.GetString("valormoneda")
            End If
        Else
            ValorMoneda = cFunciones.QueryTasa("CURDATE()")
        End If

        tipoResolucion = STR_VACIO
        celdaOCE.Clear()
        celdaAño.Text = cfun.AñoMySQL
        celdaID.Text = STR_VACIO
        celdaNumeroSerie.Text = STR_VACIO
        celdaSerie.Text = CargarSerie()
        celdaTasa.Text = ValorMoneda
        celdaidMoneda.Text = cfun.SimboloMoneda(cfun.DivisaLocal)
        celdaMoneda.Text = cfun.DivisaLocal
        celdaIdProveedor.Text = NO_FILA
        celdaProveedor.Text = STR_VACIO
        celdaCostos.Text = STR_VACIO
        dtDetalle.Rows.Clear()
        celdaObservaciones.Text = STR_VACIO
        celdaDireccion.Text = STR_VACIO
        checkActivo.Checked = True
        celdaDiasCredito.Clear()
        rbContado.Checked = False
        rbCredito.Checked = False
        celdaTotal.Text = INT_CERO.ToString(FORMATO_MONEDA)
        dtpFecha.Value = cfun.HoyMySQL
        celdaSerie.Text = STR_VACIO
        celdaNumeroSerie.Text = STR_VACIO
        celdaIdResolución.Text = 0
        celdaResolucion.Clear()
        celdaRequisicion.Clear()
        celdaRequerido.Clear()
        dtpFechaAprobacion.Value = cfun.HoyMySQL
        dtpDeliveryDate.Value = cfun.HoyMySQL
        celdaTotal.Text = INT_CERO
        celdaTexto1.Text = INT_CERO
        celdaTexto2.Text = INT_CERO
        celdaTexto3.Text = INT_CERO
        celdaTexto4.Text = INT_CERO
        txtTEXT1.Text = STR_VACIO
        txtTEXT2.Text = STR_VACIO
        txtTEXT3.Text = STR_VACIO
        If Sesion.IdEmpresa = 15 Or Sesion.IdEmpresa = 20 Or Sesion.IdEmpresa = 22 Then
            dtDetalle.Columns("colUM").Visible = True
            dtDetalle.Columns("colExoneracion").Visible = True
            dtDetalle.Columns("colRubro").Visible = True
            dtDetalle.Columns("colCantidadRecibida").Visible = True
        Else
            dtDetalle.Columns("colUM").Visible = False
            dtDetalle.Columns("colExoneracion").Visible = False
            dtDetalle.Columns("colRubro").Visible = False
            dtDetalle.Columns("colCantidadRecibida").Visible = False
        End If
    End Sub

    Public Function sqlDatosMoneda(ByVal idMon As Integer)
        Dim strsql As String = STR_VACIO

        strsql = " Select cat_clave simbolo, cat_desc nombre, cat_sist valormoneda
                    From Catalogos
                    Where cat_num = {id} and cat_clase = 'Monedas'"

        strsql = Replace(strsql, "{id}", idMon)

        Return strsql
    End Function
    Private Sub SeleccionarEncabezado(ByVal intNumero As Integer, ByVal intAÑo As Integer)
        Dim cHDR As New clsDcmtos_HDR
        Dim CA As New clsCatalogos
        Dim strCampos As String = STR_VACIO
        Dim strCondicion As String = STR_VACIO
        Dim strSQL As String = STR_VACIO
        Dim COM As MySqlCommand
        Dim conec As New MySqlConnection
        Dim REA2 As MySqlDataReader
        Try
            strSQL = " SELECT HDoc_DR2_Num OCE, HDoc_Ant_Com tipoOrden, IFNULL(s.cat_num,-1) idResolucion, IFNULL(s.cat_desc,'') tipoResolucion, IFNULL(s.cat_sist,'') Resolucion, HDoc_RF2_Txt, HDoc_Doc_Num, HDoc_Doc_Ano, HDoc_Doc_Fec,
                        HDoc_DR1_Dbl Numero,HDoc_DR1_Num Serie,HDoc_Emp_Cod,HDoc_Emp_Nom,HDoc_Emp_Dir,HDoc_Doc_TC,HDoc_Doc_Mon,HDoc_DR1_Cat Tipo,HDoc_DR1_Num,HDoc_RF1_Txt, IFNULL(c.cat_clave,'') Moneda, 
                        IFNULL(c.cat_num,0) id, IFNULL(c.cat_sist,'') tasa
                        , HDoc_Doc_Status Estado, HDoc_RF2_Cod Requisicion, HDoc_RF1_Cod Requerido, IFNULL(HDoc_DR1_Fec,now()) FechaAprobacion, IFNULL(HDoc_RF2_Num,0) checkfecha, 
                        IFNULL(HDoc_DR2_Fec,NOW()) FechaEntrega, IFNULL(HDoc_RF1_Num,0) ValFecEntrega, IFNULL(HDoc_RF1_Dbl,0) ValTexto1, IFNULL(HDoc_RF2_Dbl,0) ValTexto2, IFNULL(HDoc_RF3_Dbl,0) ValTexto3, IFNULL(HDoc_Ant_Com,0) ValTexto4, 
                        IFNULL(HDoc_RF1_Cod,'') Texto1, iFNULL(HDoc_RF2_Cod,'') Texto2, IFNULL(HDoc_Emp_Per,'') Texto3"
            strSQL &= " FROM Dcmtos_HDR "
            strSQL &= " LEFT JOIN Catalogos c ON c.cat_num = HDoc_Doc_Mon"
            strSQL &= " LEFT JOIN Catalogos s ON s.cat_num = HDoc_DR2_Cat"
            strSQL &= " WHERE HDoc_Doc_Num = {codigo} AND HDoc_Doc_Ano = {añio} AND HDoc_Doc_Cat = {Catalogo} AND HDoc_Sis_Emp = {empresa} "

            strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
            strSQL = Replace(strSQL, "{añio}", intAÑo)
            strSQL = Replace(strSQL, "{Catalogo}", CAT_ORD)
            strSQL = Replace(strSQL, "{codigo}", intNumero)

            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSQL, CON)
            REA2 = COM.ExecuteReader
            'conec = New MySqlConnection(strConexion)
            'conec.Open()
            'COM = New MySqlCommand(strSQL, conec)
            If REA2.HasRows Then
                Do While REA2.Read
                    celdaOCE.Text = REA2.GetString("OCE")
                    celdaID.Text = REA2.GetInt32("HDoc_Doc_Num")
                    celdaAño.Text = REA2.GetInt32("HDoc_Doc_Ano")
                    celdaSerie.Text = REA2.GetString("Serie")
                    celdaNumeroSerie.Text = REA2.GetInt32("Numero")
                    dtpFecha.Value = REA2.GetDateTime("HDoc_Doc_Fec").ToString(FORMATO_MYSQL)
                    celdaIdProveedor.Text = REA2.GetInt32("HDoc_Emp_Cod")
                    celdaProveedor.Text = REA2.GetString("HDoc_Emp_Nom")
                    celdaDireccion.Text = REA2.GetString("HDoc_Emp_Dir")
                    celdaTasa.Text = REA2.GetDouble("HDoc_Doc_TC")
                    celdaMoneda.Text = REA2.GetInt32("HDoc_Doc_Mon")
                    celdaidMoneda.Text = REA2.GetString("Moneda")
                    celdaObservaciones.Text = REA2.GetString("HDoc_RF1_Txt")
                    celdaDiasCredito.Text = REA2.GetString("HDoc_RF2_Txt")
                    celdaIdResolución.Text = REA2.GetInt32("idResolucion")
                    celdaResolucion.Text = REA2.GetString("Resolucion")
                    tipoResolucion = REA2.GetString("tipoResolucion")
                    intTipo = REA2.GetInt32("tipoOrden")
                    celdaRequisicion.Text = REA2.GetString("Requisicion")
                    'Carga los campos adicionales para facturacion
                    celdaTexto1.Text = REA2.GetDouble("ValTexto1")
                    celdaTexto2.Text = REA2.GetDouble("ValTexto2")
                    celdaTexto3.Text = REA2.GetDouble("ValTexto3")
                    'celdaTexto4.Text = REA2.GetDouble("ValTexto4")
                    txtTEXT1.Text = REA2.GetString("Texto1")
                    txtTEXT2.Text = REA2.GetString("Texto2")
                    If REA2.GetString("Texto3") = "" Then
                        txtTEXT3.Text = "Total"
                    Else
                        txtTEXT3.Text = REA2.GetString("Texto3")
                    End If

                    If REA2.GetInt32("Estado") = INT_UNO Then
                        checkActivo.Checked = True
                    Else
                        checkActivo.Checked = False
                    End If
                    If REA2.GetInt32("Tipo") = INT_CERO Then
                        rbContado.Checked = True
                    ElseIf REA2.GetInt32("Tipo") = INT_UNO Then
                        rbCredito.Checked = True
                    End If
                    'carga el valor de fecha propuesta si ya tiene valor guardado, inhabilita tanto el check como dtp para que ya no puedan cambiar la fecha agregada
                    If REA2.GetInt32("checkfecha") = INT_UNO Then
                        checkFechaAprobacion.Checked = True
                        dtpFechaAprobacion.Value = REA2.GetDateTime("FechaAprobacion").ToString(FORMATO_MYSQL)
                        checkFechaAprobacion.Enabled = False
                        dtpFechaAprobacion.Enabled = False
                    Else
                        checkFechaAprobacion.Checked = False
                        dtpFechaAprobacion.Value = cfun.HoyMySQL
                        checkFechaAprobacion.Enabled = True
                        dtpFechaAprobacion.Enabled = True
                    End If
                    'Carga el valor de DeliveryDate
                    If REA2.GetInt32("ValFecEntrega") = INT_CERO Then
                        dtpDeliveryDate.Value = cfun.HoyMySQL
                    Else
                        dtpDeliveryDate.Value = REA2.GetDateTime("FechaEntrega").ToString(FORMATO_MYSQL)
                    End If
                Loop
            End If
            If celdaSerie.Text = "OCE" Or celdaSerie.Text = "OEA" Then
                dtDetalle.Columns("colUM").Visible = True
                dtDetalle.Columns("colCantidadRecibida").Visible = True
            Else
                dtDetalle.Columns("colUM").Visible = False
                dtDetalle.Columns("colCantidadRecibida").Visible = False
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub
    Private Sub SeleccionarDetalle(ByVal intNumero As Integer, ByVal intAÑo As Integer)
        Dim cDTL As New clsDcmtos_DTL
        Dim strSQL As String = STR_VACIO
        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader
        Dim strFIla As String = STR_VACIO


        If Sesion.IdEmpresa = 15 Or Sesion.IdEmpresa = 20 Or Sesion.IdEmpresa = 22 Then
            dtDetalle.Columns("col_IdRequeride").Visible = False
            dtDetalle.Columns("col_Requeride").Visible = True
        Else
            dtDetalle.Columns("col_IdRequeride").Visible = False
            dtDetalle.Columns("col_Requeride").Visible = False
        End If

        Try
            strSQL = SQLCargarDetalle(intNumero, intAÑo)
            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSQL, CON)
            REA = COM.ExecuteReader
            If REA.HasRows Then
                dtDetalle.Rows.Clear()
                Do While REA.Read
                    strFIla = STR_VACIO
                    strFIla = REA.GetInt32("Codigo") & "|" 'ID CODIGO
                    strFIla &= REA.GetString("Producto") & "|" 'Producto  
                    strFIla &= REA.GetString("UM_OCE") & "|" 'Unidad de medida OCE  
                    strFIla &= REA.GetDouble("Cantidad") & "|" ' Cantidad
                    strFIla &= REA.GetDouble("Precio") & "|" ' Precio
                    strFIla &= REA.GetString("Medida") & "|" 'Medida
                    strFIla &= REA.GetInt32("id") & "|" ' id 
                    strFIla &= REA.GetDouble("Precio") * REA.GetDouble("Cantidad") & "|"   ' Total
                    strFIla &= REA.GetString("Nombre") & "|"  ' Centro Costo
                    strFIla &= REA.GetInt32("Centro") & "|"  ' ID
                    If Sesion.IdEmpresa = 15 Or Sesion.IdEmpresa = 20 Or Sesion.IdEmpresa = 22 Then
                        strFIla &= REA.GetString("NomRequerido") & "|" 'RequeridoPor
                        strFIla &= REA.GetInt32("Requerido") & "|" 'IDRequerido
                    Else
                        strFIla &= vbNullString & "|"
                        strFIla &= 0 & "|"
                    End If
                    strFIla &= REA.GetString("catalogo") & "|"  ' Catalogo 949
                    strFIla &= REA.GetInt32("anio") & "|" ' Año
                    strFIla &= REA.GetInt32("numero") & "|" '  Numero
                    strFIla &= REA.GetInt32("linea") & "|" ' Linea 
                    strFIla &= REA.GetString("Catalogo") & "|"   'Catalogo 777
                    strFIla &= REA.GetInt32("Anio") & "|"  ' Anio
                    strFIla &= REA.GetInt32("Numero") & "|"  ' Numero 
                    strFIla &= REA.GetInt32("Linea") & "|"   'Linea 
                    strFIla &= REA.GetString("Comentario") & "|" 'Comentario
                    strFIla &= REA.GetString("DescripcionExoneracion") & "|" ' Descricion Exoneracion HSM
                    strFIla &= REA.GetInt32("idExoneracion") & "|"
                    strFIla &= REA.GetInt32("idRubro") & "|"
                    strFIla &= REA.GetString("DescRubro") & "|"
                    strFIla &= "1" & "|"

                    strFIla &= REA.GetDouble("recibido") & "|"
                    strFIla &= REA.GetString("idCosto") & "|"
                    strFIla &= REA.GetString("ctaNom") & "|"
                    strFIla &= REA.GetString("idCentroCosto") & "|"
                    strFIla &= REA.GetString("Rubro") & "|"
                    strFIla &= REA.GetString("porcentaje") & "|"
                    strFIla &= REA.GetString("descuento") & "|"

                    'txtPacking.Text = 
                    If REA.GetInt32("Cancelado") = 0 Then
                        strFIla &= vbNullString      'Estado
                    Else
                        strFIla &= "SI"   'Estado
                    End If


                    cFunciones.AgregarFila(dtDetalle, strFIla)
                Loop
                CalcularTotal()
                CalcularDescuento()
            End If
            If checkFechaAprobacion.Checked = True Then
                dtDetalle.Enabled = False
            Else
                dtDetalle.Enabled = True
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub
    Private Function GuardarEncabezado(Optional logUpdate As Boolean = False, Optional N_OCE As Integer = 0) As Boolean
        Dim cHDR As New clsDcmtos_HDR
        Dim intNuevoID As Integer = NO_FILA
        Dim intAño As Integer = NO_FILA
        Dim dblVal1 As Double
        Dim dblVal2 As Double
        Dim dblTotal As Double

        Dim logGuardar As Boolean = False
        Try
            cHDR.CONEXION = strConexion
            cHDR.HDOC_SIS_EMP = Sesion.IdEmpresa
            cHDR.HDOC_DOC_CAT = CAT_ORD
            cHDR.HDOC_EMP_COD = celdaIdProveedor.Text
            cHDR.HDOC_EMP_NOM = celdaProveedor.Text
            cHDR.HDOC_EMP_DIR = celdaDireccion.Text
            cHDR.HDOC_USUARIO = Sesion.Usuario
            cHDR.HDOC_DOC_TC = CDbl(celdaTasa.Text)
            cHDR.HDOC_DOC_MON = CInt(celdaMoneda.Text)
            cHDR.HDOC_RF1_TXT = celdaObservaciones.Text
            cHDR.HDOC_RF2_TXT = celdaDiasCredito.Text
            cHDR.HDOC_DR1_NUM = celdaSerie.Text
            cHDR.HDOC_DR2_CAT = IIf(celdaIdResolución.Text = INT_CERO, NO_FILA, celdaIdResolución.Text)
            cHDR.HDOC_ANT_COM = intTipo
            cHDR.HDOC_RF2_COD = celdaRequisicion.Text
            cHDR.HDOC_RF1_COD = celdaRequerido.Text

            'Se almacena el nuevo campo de fecha Delivery Date
            If panelDeliveryDate.Visible = True Then
                If dtpDeliveryDate.Value.Date <> cfun.HoyMySQL Then
                    cHDR.HDoc_DR2_Fec_NET = dtpDeliveryDate.Value.Date
                    cHDR.HDOC_RF1_NUM = 1
                Else
                    cHDR.HDOC_RF1_NUM = 0
                End If

            End If

            'Almacenar campos adicionales para facturación
            dblVal1 = celdaTexto1.Text
            If dblVal1 > 0 And txtTEXT1.Text <> STR_VACIO Then
                cHDR.HDOC_RF1_DBL = dblVal1.ToString(FORMATO_MONEDA)
                cHDR.HDOC_RF1_COD = txtTEXT1.Text
            ElseIf dblVal1 = 0 And txtTEXT1.Text = STR_VACIO Then
                cHDR.HDOC_RF1_DBL = INT_CERO
                cHDR.HDOC_RF1_COD = STR_VACIO
            ElseIf dblVal1 = 0 And txtTEXT1.Text <> STR_VACIO Then
                cHDR.HDOC_RF1_DBL = dblVal1.ToString(FORMATO_MONEDA)
                cHDR.HDOC_RF1_COD = txtTEXT1.Text
            ElseIf txtTEXT1.Text = STR_VACIO And dblVal1 > 0 Then
                MsgBox("You must add a Text in the additional fields of purchase order to be able to save", vbOK)
                txtTEXT1.Focus()
                Encabezado1.botonGuardar.Enabled = True
                Return logGuardar
            End If

            dblVal2 = celdaTexto2.Text
            If dblVal2 > 0 And txtTEXT2.Text <> STR_VACIO Then
                cHDR.HDOC_RF2_DBL = dblVal2.ToString(FORMATO_MONEDA)
                cHDR.HDOC_RF2_COD = txtTEXT2.Text
            ElseIf dblVal2 = 0 And txtTEXT2.Text = STR_VACIO Then
                cHDR.HDOC_RF2_DBL = INT_CERO
                cHDR.HDOC_RF2_COD = STR_VACIO
            ElseIf dblVal2 = 0 And txtTEXT2.Text <> STR_VACIO Then
                cHDR.HDOC_RF2_DBL = dblVal2.ToString(FORMATO_MONEDA)
                cHDR.HDOC_RF2_COD = txtTEXT2.Text
            ElseIf txtTEXT2.Text = STR_VACIO And dblVal2 > 0 Then
                MsgBox("You must add a Text in the additional fields of purchase order to be able to save", vbOKOnly)
                txtTEXT2.Focus()
                Encabezado1.botonGuardar.Enabled = True
                Return logGuardar
            End If

            dblTotal = celdaTexto3.Text
            cHDR.HDOC_RF3_DBL = dblTotal.ToString(FORMATO_MONEDA)
            cHDR.HDOC_EMP_PER = txtTEXT3.Text

            'dblDescuento = celdaTexto4.Text ' Almacena valor total de descuento
            'cHDR.HDOC_ANT_COM = dblDescuento.ToString(FORMATO_MONEDA)

            If rbContado.Checked = True Then
                cHDR.HDOC_DR1_CAT = INT_CERO
            ElseIf rbCredito.Checked = True Then
                cHDR.HDOC_DR1_CAT = INT_UNO
            End If
            If checkActivo.Checked = True Then
                cHDR.HDOC_DOC_STATUS = INT_UNO
            Else
                cHDR.HDOC_DOC_STATUS = INT_CERO
            End If
            If logUpdate = False Or N_OCE = 1 Then
                cHDR.HDOC_DR2_NUM = STR_VACIO  'celdaOCE.Text
                cHDR.HDOC_DOC_NUM = NuevaOrdeDeCompra(N_OCE)
                cHDR.HDOC_DOC_ANO = celdaAño.Text
                If logUpdate = False Then
                    cHDR.HDoc_Doc_Fec_NET = dtpFecha.Value
                Else
                    cHDR.HDoc_Doc_Fec_NET = cfun.HoyMySQL.ToString(FORMATO_MYSQL)
                End If

                If celdaNumeroSerie.Text = vbNullString Or celdaNumeroSerie.Text = "0" Or celdaNumeroSerie.Text = " " Then
                    cHDR.HDOC_DR1_DBL = NuevaSerie()
                Else
                    cHDR.HDOC_DR1_DBL = celdaNumeroSerie.Text
                End If
                If cHDR.Guardar = False Then
                    MsgBox(cHDR.MERROR.ToString)
                Else
                    GuardarACC(cHDR.HDOC_DOC_NUM)   ''''proceso para guardar los datos de envío.
                    If GuardarDetalle(cHDR.HDOC_DOC_NUM, cHDR.HDOC_DOC_ANO, N_OCE) = True Then
                        logGuardar = True
                        'N_OCE = INT_CERO
                    End If

                End If
            End If
            If logUpdate = True Then
                cHDR.HDOC_DR2_NUM = celdaOCE.Text

                'Se almacena el nuevo campo de fecha segun check de cambio de fecha de aprovación
                If checkFechaAprobacion.Checked = True Then
                    cHDR.HDoc_DR1_Fec_NET = dtpFechaAprobacion.Value.Date
                    'Almacena el valor 1 si el check esta activo
                    cHDR.HDOC_RF2_NUM = 1
                End If
                cHDR.HDOC_DOC_NUM = CInt(celdaID.Text)
                cHDR.HDoc_Doc_Fec_NET = dtpFecha.Value
                cHDR.HDOC_DOC_ANO = celdaAño.Text
                'cHDR.HDOC_DR1_DBL = celdaNumeroSerie.Text
                If celdaNumeroSerie.Text = vbNullString Or celdaNumeroSerie.Text = "0" Or celdaNumeroSerie.Text = "" Then
                    cHDR.HDOC_DR1_DBL = NuevaSerie()
                Else
                    cHDR.HDOC_DR1_DBL = celdaNumeroSerie.Text
                End If
                If checkActivo.Checked = False Then
                    If ComprobarFacturaCompra() > INT_CERO Then
                        MsgBox("This document cannot be voided")
                        Return False
                    End If
                End If

                If cHDR.Actualizar = False Then
                    MsgBox(cHDR.MERROR.ToString)
                Else
                    If N_OCE = INT_CERO Then
                        GuardarACC(cHDR.HDOC_DOC_NUM, N_OCE) ''''proceso para guardar los datos de envío.
                        If GuardarDetalle(cHDR.HDOC_DOC_NUM, cHDR.HDOC_DOC_ANO, N_OCE) = True Then
                            logGuardar = True
                        End If
                    End If
                End If



                'If BorrarDetalle() = True Then
                '    If BorrarEncabezado() = True Then
                '        If cHDR.Guardar = False Then
                '            MsgBox(cHDR.MERROR.ToString)
                '        Else
                '            If GuardarDetalle(celdaID.Text) = True Then
                '                logGuardar = True
                '            End If
                '        End If

                '    End If
                'End If
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        Return logGuardar
    End Function
    Private Function GuardarDetalle(ByVal intNumero As Integer, ByVal Año As Integer, Optional N_OCE As Integer = 0) As Boolean
        Dim cDTL As New clsDcmtos_DTL
        Dim logDetalle As Boolean = False
        Try
            For i As Integer = 0 To dtDetalle.Rows.Count - 1
                cDTL.DDOC_SIS_EMP = Sesion.IdEmpresa
                cDTL.DDOC_DOC_CAT = CAT_ORD
                cDTL.DDOC_PRD_COD = CInt(dtDetalle.Rows(i).Cells("colCodigo").Value)
                cDTL.DDOC_PRD_DES = CStr(dtDetalle.Rows(i).Cells("colDescripcion").Value)
                cDTL.DDOC_PRD_NET = CDbl(dtDetalle.Rows(i).Cells("colPrecio").Value)
                cDTL.DDOC_PRD_UM = dtDetalle.Rows(i).Cells("col_id").Value
                cDTL.DDOC_RF1_NUM = dtDetalle.Rows(i).Cells("col_id3").Value
                cDTL.DDOC_PRD_PNR = dtDetalle.Rows(i).Cells("colUM").Value

                cDTL.DDOC_RF2_NUM = dtDetalle.Rows(i).Cells("colidExoneracion").Value
                cDTL.DDOC_RF3_DBL = dtDetalle.Rows(i).Cells("colIdRubro").Value
                cDTL.DDOC_RF1_TXT = dtDetalle.Rows(i).Cells("colComentario").Value
                'almacena el valor de Requerido por pero solo es para empresa de Giro 2
                cDTL.DDOC_RF1_DBL = dtDetalle.Rows(i).Cells("col_IdRequeride").Value

                cDTL.DDOC_RF2_TXT = dtDetalle.Rows(i).Cells("colIdCosto").Value     'rubro
                cDTL.DDOC_RF3_TXT = dtDetalle.Rows(i).Cells("colIdCenterCost").Value 'cuenta
                cDTL.DDOC_PRD_FOB = dtDetalle.Rows(i).Cells("colPercentage").Value  'Porcentaje
                cDTL.DDOC_RF4_DBL = dtDetalle.Rows(i).Cells("colDiscounts").Value  'Descuento

                If dtDetalle.Rows(i).Cells("colEstado1").Value = 0 Or dtDetalle.Rows(i).Cells("colEstado1").Value = vbNullString Or N_OCE = INT_UNO Then
                    cDTL.DDOC_RF2_DBL = INT_CERO
                    'cDTL.DDOC_PRD_QTY = CDbl(dtDetalle.Rows(i).Cells("colCantidad").Value)
                    If N_OCE = 1 Then
                        cDTL.DDOC_PRD_QTY = CDbl(dtDetalle.Rows(i).Cells("colCantidad").Value - dtDetalle.Rows(i).Cells("colCantidadRecibida").Value)
                    Else
                        cDTL.DDOC_PRD_QTY = CDbl(dtDetalle.Rows(i).Cells("colCantidad").Value)
                    End If

                    cDTL.DDOC_DOC_NUM = intNumero
                    cDTL.DDOC_DOC_LIN = NuevaLinea(intNumero)
                    dtDetalle.Rows(i).Cells("col_linea").Value = cDTL.DDOC_DOC_LIN
                    dtDetalle.Rows(i).Cells("colEstado1").Value = INT_UNO
                    cDTL.DDOC_DOC_ANO = Año
                    If cDTL.DDOC_PRD_QTY > 0 Then
                        If cDTL.Guardar = False Then
                            MsgBox(cDTL.MERROR.ToString)
                        Else
                            logDetalle = True
                        End If
                    End If

                End If
                If dtDetalle.Rows(i).Cells("colCancelado").Value = vbNullString Then
                    cDTL.DDOC_RF3_NUM = 0
                Else
                    cDTL.DDOC_RF3_NUM = 1
                End If

                If dtDetalle.Rows(i).Cells("colEstado1").Value = 1 Then
                    cDTL.DDOC_RF2_DBL = dtDetalle.Rows(i).Cells("colCantidadRecibida").Value
                    If N_OCE = 1 Then
                        cDTL.DDOC_PRD_QTY = CDbl(dtDetalle.Rows(i).Cells("colCantidadRecibida").Value)
                    Else
                        cDTL.DDOC_PRD_QTY = CDbl(dtDetalle.Rows(i).Cells("colCantidad").Value)
                    End If
                    'cDTL.DDOC_PRD_QTY = CDbl(dtDetalle.Rows(i).Cells("colCantidadRecibida").Value)
                    cDTL.DDOC_DOC_NUM = celdaID.Text
                    cDTL.DDOC_DOC_LIN = dtDetalle.Rows(i).Cells("col_linea").Value
                    cDTL.DDOC_DOC_ANO = celdaAño.Text
                    If cDTL.Actualizar = False Then
                        MsgBox(cDTL.MERROR.ToString)
                    Else
                        logDetalle = True
                    End If
                End If

                If dtDetalle.Rows(i).Cells("colEstado1").Value = 2 Then
                    If dtDetalle.Rows(i).Visible = False Then
                        BorrarDetalle(intNumero)
                    End If
                End If
            Next
            ' GuardarDetallePro(intNumero, cDTL.DDOC_DOC_LIN, Año)
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        Return logDetalle
    End Function
    Private Function GuardarDetallePro(ByVal intNumero As Integer, ByVal Linea As Integer, ByVal Año As Integer) As Boolean
        Dim CDTLPRO As New clsDcmtos_DTL_Pro
        Dim logDetalle As Boolean = False
        Try
            For i As Integer = 0 To dtDetalle.RowCount - 1
                CDTLPRO.PDOC_SIS_EMP = Sesion.IdEmpresa
                CDTLPRO.PDOC_PAR_CAT = dtDetalle.Rows(i).Cells("colCatalogo").Value
                CDTLPRO.PDOC_PAR_ANO = dtDetalle.Rows(i).Cells("colAño").Value
                CDTLPRO.PDOC_PAR_LIN = dtDetalle.Rows(i).Cells("colLinea").Value
                CDTLPRO.PDOC_CHI_CAT = CAT_ORD
                CDTLPRO.PDOC_PAR_NUM = dtDetalle.Rows(i).Cells("colNumero").Value
                If dtDetalle.Rows(i).Cells("colEstado1").Value = 0 Then
                    CDTLPRO.PDOC_CHI_ANO = Año
                    CDTLPRO.PDOC_CHI_NUM = intNumero
                    CDTLPRO.PDOC_CHI_LIN = dtDetalle.Rows(i).Cells("col_linea").Value
                    If CDTLPRO.Guardar = False Then
                        MsgBox(CDTLPRO.MERROR.ToString)
                    Else
                        logDetalle = True
                    End If
                End If
                If dtDetalle.Rows(i).Cells("colEstado1").Value = 1 Then
                    CDTLPRO.PDOC_CHI_ANO = celdaAño.Text
                    CDTLPRO.PDOC_CHI_NUM = dtDetalle.Rows(i).Cells("col_numero").Value
                    CDTLPRO.PDOC_CHI_LIN = dtDetalle.Rows(i).Cells("col_linea").Value
                    If CDTLPRO.Actualizar = False Then
                        MsgBox(CDTLPRO.MERROR.ToString)
                    Else
                        logDetalle = True
                    End If
                End If
                If dtDetalle.Rows(i).Cells("colEstado1").Value = 2 Then
                    BorrarDetalle_PRO(celdaID.Text)
                End If



            Next
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        Return logDetalle
    End Function
    Private Function GuardarACC(ByVal intNumero As Integer, Optional N_OCE As Integer = 0) As Boolean
        Dim ACC As New Tablas.TDCMTOS_ACC
        Try
            ACC = New Tablas.TDCMTOS_ACC
            ACC.ADOC_SIS_EMP = Sesion.IdEmpresa
            ACC.ADOC_DOC_CAT = CAT_ORD
            ACC.ADOC_DOC_ANO = celdaAño.Text
            ACC.ADOC_DOC_NUM = intNumero
            ACC.ADOC_DOC_SUB = "Doc_AccDesc"
            ACC.ADOC_DOC_LIN = 1
            ACC.ADOC_DTA_TXT = ""
            ACC.ADOC_DTA_DES = celdaDelivery.Text

            ACC.CONEXION = strConexion
            If logEditar = True Then
                If ACC.PUPDATE = False Then
                    MsgBox(ACC.MERROR.ToString)
                End If
            End If
            If logEditar = False Or N_OCE = 1 Then

                If ACC.PINSERT = False Then
                    MsgBox(ACC.MERROR.ToString)
                End If

            End If
            ACC.Dispose()
            ACC = Nothing

        Catch ex As Exception
            MsgBox(ex.ToString)
            Return False
        End Try
        Return True
    End Function
    Private Sub MostrarLista(Optional ByVal logMostrar As Boolean = True, Optional logInsert As Boolean = False)
        Dim cfun As New clsFunciones

        'If Sesion.IdEmpresa = 18 Then       'NSM
        'panelResolucion.Visible = False
        'PanelRequisicion.Visible = True
        'ElseIf Sesion.IdEmpresa = 15 Then   'HSM
        'panelResolucion.Visible = True
        'PanelRequisicion.Visible = False
        'End If

        If Sesion.idGiro = 2 Then       'NSM
            'panelResolucion.Visible = False
            PanelRequisicion.Visible = True
            panelRequerido.Visible = True
            PanelRequisicion.Location = New System.Drawing.Point(775, 137)
            panelRequerido.Location = New System.Drawing.Point(950, 137)
        End If
        If Sesion.IdEmpresa = 15 Or Sesion.IdEmpresa = 20 Or Sesion.IdEmpresa = 22 Then   'HSM
            panelResolucion.Visible = True
            'PanelRequisicion.Visible = False
            'panelRequerido.Visible = True
        End If

        If Sesion.IdEmpresa = 15 Or Sesion.IdEmpresa = 20 Or Sesion.IdEmpresa = 22 Then
            panelDeliveryDate.Visible = True
            gbCamposAdicionales.Visible = True
        Else
            panelDeliveryDate.Visible = False
        End If

        If Sesion.IdEmpresa = 18 Then

            gbCamposAdicionales.Visible = True
            txtTEXT4.Visible = True
            celdaTexto4.Visible = True
            dtDetalle.Columns("colPercentage").Visible = True
            dtDetalle.Columns("colDiscounts").Visible = True
        Else
            txtTEXT4.Visible = False
            celdaTexto4.Visible = False
            dtDetalle.Columns("colPercentage").Visible = False
            dtDetalle.Columns("colDiscounts").Visible = False
        End If

        If Sesion.idGiro = 2 Then
            celdaTotal.Enabled = False
        Else
            celdaTotal.Enabled = True
        End If

        If logMostrar = True Then
            'ocultar panel de documento
            panelDocumento.Dock = DockStyle.None
            panelDocumento.Visible = False
            'actualizar Titulo
            BarraTitulo1.CambiarTitulo("Órdenes de Compra")
            'Cargar Datos
            'cfun.CargarLista(dgLista, SQLLista, False)
            CargarLista()
            'Mostrar Panel Filtro
            panelLIsta.Visible = True
            panelLIsta.Dock = DockStyle.Fill
            BloquearBotones()
            Me.Tag = ""
        Else
            'Ocultar Panel Filtro
            panelLIsta.Visible = False
            panelLIsta.Dock = DockStyle.None
            'Mostrar panel de documento
            panelDocumento.Dock = DockStyle.Fill
            panelDocumento.Visible = True
            'Verifica si se va a crear un nuevo documento o se va modifica
            If logInsert = False Then
                BarraTitulo1.CambiarTitulo("Modificar Registro")
                Me.Tag = "Mod"
                BloquearBotones(False)
                botonInprimir.Enabled = True
            Else
                BarraTitulo1.CambiarTitulo("Nuevo Registro")
                Me.Tag = "Nuevo"
                BloquearBotones(False)
                botonInprimir.Enabled = False
                reset()
            End If

            dgLista.DataSource = Nothing
        End If
    End Sub
    Public Sub CargarLista()
        Dim strSQL As String = STR_VACIO
        ' Conexiones
        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader
        Dim strLinea As String
        Try
            strSQL = SQLLista()
            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSQL, CON)
            REA = COM.ExecuteReader

            If REA.HasRows Then
                dgLista.Rows.Clear()
                Do While REA.Read

                    strLinea = REA.GetInt32("Correlativo") & "|" 'Codigo
                    strLinea &= REA.GetInt32("Ciclo") & "|" 'Año 
                    strLinea &= REA.GetDateTime("Fecha").ToString(FORMATO_MYSQL) & "|" 'Fecha
                    strLinea &= REA.GetString("HDoc_Emp_Nom") & "|"  ' Nombre  
                    strLinea &= REA.GetString("Serie") & "_" & REA.GetString("Numero") & "|" ' Serie
                    strLinea &= REA.GetDouble("Total").ToString(FORMATO_MONEDA) & "|"  ' Total
                    strLinea &= REA.GetString("Estado") ' Estado
                    If REA.GetString("Estado") = "CANCELED" Then
                        cFunciones.AgregarFila(dgLista, strLinea, Color.Coral)
                    Else
                        cFunciones.AgregarFila(dgLista, strLinea)
                    End If
                Loop


            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub
    Private Function BorrarDetalle() As Boolean
        Dim logResulta As Boolean = False
        Dim cDTL As New clsDcmtos_DTL
        Dim strCondicion As String = STR_VACIO

        strCondicion = " DDoc_Doc_Num = {numero} And DDoc_Doc_Ano = {año} And DDoc_Doc_Cat =  {catalogo} And DDoc_Sis_Emp = {empresa}"
        strCondicion = Replace(strCondicion, "{numero}", celdaID.Text)
        strCondicion = Replace(strCondicion, "{año}", celdaAño.Text)
        strCondicion = Replace(strCondicion, "{catalogo}", CAT_ORD)
        strCondicion = Replace(strCondicion, "{empresa}", Sesion.IdEmpresa)
        Try
            cDTL.CONEXION = strConexion
            If cDTL.Borrar(strCondicion) = True Then
                logResulta = True
            Else
                MsgBox(cDTL.MERROR.ToString)
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        Return logResulta
    End Function
    Private Function BorrarEncabezado() As Boolean
        Dim logResult As Boolean = False
        Dim strCondicion As String = STR_VACIO
        Dim CHDR As New clsDcmtos_HDR
        strCondicion = " HDoc_Doc_Num = {numero} And HDoc_Doc_Ano = {año} And HDoc_Doc_Cat =  {catalogo} And HDoc_Sis_Emp = {empresa} "
        strCondicion = Replace(strCondicion, "{numero}", celdaID.Text)
        strCondicion = Replace(strCondicion, "{año}", celdaAño.Text)
        strCondicion = Replace(strCondicion, "{catalogo}", CAT_ORD)
        strCondicion = Replace(strCondicion, "{empresa}", Sesion.IdEmpresa)
        Try
            CHDR.CONEXION = strConexion
            If CHDR.Borrar(strCondicion) = True Then
                logResult = True
            Else
                MsgBox(CHDR.MERROR.ToString)
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        Return logResult
    End Function
    Private Function Borrar() As Boolean
        Dim logResult As Boolean = False
        If BorrarDetalle() = True Then
            If BorrarEncabezado() = True Then
                logResult = True
            End If
        End If
        Return logResult
    End Function
    Private Function NuevaLinea(ByVal Codigo As Integer) As Integer
        Dim strSQL As String = STR_VACIO
        Dim conec As New MySqlConnection
        Dim COM As MySqlCommand
        Dim LineaNueva As Integer

        strSQL = "Select IFNULL(MAX(DTL.DDoc_Doc_Lin),0) + 1 DTL "
        strSQL &= "FROM Dcmtos_DTL DTL "
        strSQL &= "WHERE DTL.DDoc_Sis_emp = {empresa} And DTL.DDoc_Doc_Cat = {catalogo} And DTL.DDoc_Doc_Ano = {anio} And DTL.DDoc_Doc_Num = {codigo} "

        strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
        strSQL = Replace(strSQL, "{catalogo}", CAT_ORD)
        strSQL = Replace(strSQL, "{anio}", cfun.AñoMySQL)
        strSQL = Replace(strSQL, "{codigo}", Codigo)

        conec = New MySqlConnection(strConexion)
        conec.Open()
        COM = New MySqlCommand(strSQL, conec)
        LineaNueva = COM.ExecuteScalar
        conec.Close()
        conec.Dispose()
        conec = Nothing
        System.GC.Collect()
        Return LineaNueva
    End Function
    Private Function SQLDetalle(ByVal Codigo As Integer, Optional codProd As String = STR_VACIO) As String
        Dim strSQL As String = STR_VACIO
        Dim strCodProductos As String
        If codProd = STR_VACIO Then
            strCodProductos = STR_VACIO
        Else
            strCodProductos = "AND NOT(d.DDoc_Prd_Cod IN(" & codProd & "))"
        End If


        strSQL = "  Select d.DDoc_Prd_Cod Codigo , d.DDoc_Prd_Des Descripcion,d.DDoc_Prd_QTY Cantidad ,d.DDoc_Prd_NET Precio,c.cat_clave medida,d.DDoc_Prd_UM id,d.DDoc_Doc_Cat catalogo,d.DDoc_Doc_Ano anio,d.DDoc_Doc_Num numero,d.DDoc_Doc_Lin linea ,h.HDoc_Doc_TC Tasa ,h.HDoc_Doc_Mon clave , cc.cat_clave Moneda, d.DDoc_RF1_Txt Comentario  "
        strSQL &= " FROM Dcmtos_HDR h LEFT JOIN Dcmtos_DTL d On d.DDoc_Sis_Emp = h.HDoc_Sis_Emp And d.DDoc_Doc_Cat = h.HDoc_Doc_Cat And d.DDoc_Doc_Ano = h.HDoc_Doc_Ano And d.DDoc_Doc_Num = h.HDoc_Doc_Num "
        strSQL &= " LEFT JOIN Inventarios i On i.inv_sisemp = d.DDoc_Sis_Emp And i.inv_numero = d.DDoc_Prd_Cod And i.inv_UMcmpra = d.DDoc_Prd_UM "
        strSQL &= " LEFT JOIN Articulos a On a.art_sisemp =i.inv_sisemp And a.art_codigo = i.inv_artcodigo "
        strSQL &= " LEFT JOIN Catalogos c On c.cat_num = d.DDoc_Prd_UM And c.cat_clase = 'Medidas' "
        strSQL &= " LEFT JOIN Catalogos cc ON cc.cat_num = h.HDoc_Doc_Mon "
        strSQL &= " WHERE h.HDoc_Sis_Emp ={empresa} AND h.HDoc_Doc_Cat = {catalogo} AND h.HDoc_Doc_Status = 1 AND d.DDoc_RF3_Num = 1 AND d.DDoc_RF1_Num = {proveedor} AND d.DDoc_Doc_Num = {codigo} {codProd} "


        strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
        strSQL = Replace(strSQL, "{catalogo}", catalogos)
        strSQL = Replace(strSQL, "{codigo}", Codigo)
        strSQL = Replace(strSQL, "{proveedor}", celdaIdProveedor.Text)
        strSQL = Replace(strSQL, "{codProd}", strCodProductos)


        Return strSQL
    End Function
    Private Function NuevaOrdeDeCompra(Optional intOCE_ As Integer = 0) As Integer
        Dim strSQL As String = STR_VACIO
        Dim conec As New MySqlConnection
        Dim COM As MySqlCommand
        Dim CodigoProyecto As Integer

        strSQL = " Select IFNULL(MAX(HDR.HDoc_Doc_Num),0)+1 NUMERO  "
        strSQL &= " FROM Dcmtos_HDR HDR"
        strSQL &= " WHERE HDR.HDoc_Sis_Emp = {empresa} And HDR.HDoc_Doc_Cat = {catalogo} And HDR.HDoc_Doc_Ano = {anio} "

        strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
        strSQL = Replace(strSQL, "{catalogo}", CAT_ORD)
        strSQL = Replace(strSQL, "{anio}", cfun.AñoMySQL)

        conec = New MySqlConnection(strConexion)
        conec.Open()
        COM = New MySqlCommand(strSQL, conec)
        CodigoProyecto = COM.ExecuteScalar
        conec.Close()
        conec.Dispose()
        conec = Nothing
        System.GC.Collect()
        If intOCE_ = INT_CERO Then
            celdaID.Text = CodigoProyecto
        End If
        Return CodigoProyecto
    End Function
    Private Function NuevaSerie() As Integer
        Dim strSQL As String = STR_VACIO
        Dim conec As New MySqlConnection
        Dim COM As MySqlCommand
        Dim Codigo As Integer

        strSQL = "  SELECT IFNULL(MAX(HDoc_DR1_Dbl),0)+1 Serie "
        strSQL &= " FROM Dcmtos_HDR "
        strSQL &= " WHERE HDoc_Sis_Emp ={empresa} AND HDoc_Doc_Cat ={catalogo} AND HDoc_Doc_Ano ={anio} AND HDoc_DR1_Num = '{serie}'"

        strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
        strSQL = Replace(strSQL, "{catalogo}", CAT_ORD)
        strSQL = Replace(strSQL, "{anio}", cfun.AñoMySQL)
        strSQL = Replace(strSQL, "{serie}", celdaSerie.Text)

        conec = New MySqlConnection(strConexion)
        conec.Open()
        COM = New MySqlCommand(strSQL, CON)
        Codigo = COM.ExecuteScalar
        conec.Close()
        conec.Dispose()
        conec = Nothing
        System.GC.Collect()
        'celdaID.Text = Codigo
        Return Codigo
    End Function
    Public Function BorrarDetalle(ByVal Codigo As Integer) As Boolean
        Dim LogAceptado As Boolean = False
        Dim DTL As New clsDcmtos_DTL
        Try

            For i As Integer = 0 To dtDetalle.RowCount - 1
                If Me.Tag = "Nuevo" Then
                Else

                    DTL.CONEXION = strConexion
                    DTL.DDOC_SIS_EMP = Sesion.IdEmpresa
                    DTL.DDOC_DOC_CAT = CAT_ORD
                    If dtDetalle.Rows(i).Cells("colEstado1").Value = 2 Then
                        If dtDetalle.Rows(i).Cells("col_año").Value = vbNullString Then
                        Else
                            DTL.DDOC_DOC_ANO = dtDetalle.Rows(i).Cells("col_año").Value
                        End If
                        DTL.DDOC_DOC_LIN = dtDetalle.Rows(i).Cells("col_linea").Value
                        DTL.DDOC_DOC_NUM = dtDetalle.Rows(i).Cells("col_numero").Value
                        If ComprobarLineaFacturaCompra(dtDetalle.Rows(i).Cells("col_linea").Value) > INT_CERO Then
                            MsgBox("can't delete the line has dependencies")
                            Return False
                            Exit Function
                        Else
                            If DTL.Borrar = False Then
                                MsgBox(DTL.MERROR.ToString & " Could Not Delete this document", MsgBoxStyle.Critical)
                                Return False
                                Exit Function
                            Else
                                LogAceptado = True
                            End If
                        End If
                    End If
                End If
            Next
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        Return LogAceptado
    End Function
    Public Function BorrarDetalle_PRO(ByVal Codigo As Integer) As Boolean
        Dim LogAceptado As Boolean = False
        Dim DTL_PRO As New clsDcmtos_DTL_Pro
        Try

            For i As Integer = 0 To dtDetalle.RowCount - 1
                DTL_PRO.CONEXION = strConexion
                DTL_PRO.PDOC_SIS_EMP = Sesion.IdEmpresa
                DTL_PRO.PDOC_PAR_CAT = dtDetalle.Rows(i).Cells("colCatalogo").Value
                DTL_PRO.PDOC_PAR_ANO = dtDetalle.Rows(i).Cells("colAño").Value
                DTL_PRO.PDOC_PAR_NUM = dtDetalle.Rows(i).Cells("colNumero").Value
                DTL_PRO.PDOC_PAR_LIN = dtDetalle.Rows(i).Cells("colLinea").Value
                If dtDetalle.Rows(i).Cells("colEstado1").Value = 2 Then


                    DTL_PRO.PDOC_CHI_CAT = CAT_ORD
                    If dtDetalle.Rows(i).Cells("col_año").Value = vbNullString Then
                    Else
                        DTL_PRO.PDOC_CHI_ANO = dtDetalle.Rows(i).Cells("col_año").Value
                    End If
                    If dtDetalle.Rows(i).Cells("col_numero").Value = vbNullString Then
                    Else
                        DTL_PRO.PDOC_CHI_NUM = dtDetalle.Rows(i).Cells("col_numero").Value
                    End If
                    If dtDetalle.Rows(i).Cells("col_linea").Value = vbNullString Then
                    Else
                        DTL_PRO.PDOC_CHI_LIN = dtDetalle.Rows(i).Cells("col_linea").Value
                    End If
                    If DTL_PRO.Borrar = False Then
                        MsgBox(DTL_PRO.MERROR.ToString & " Could Not Delete this document", MsgBoxStyle.Critical)
                        Return False
                        Exit Function
                    Else
                        LogAceptado = True
                    End If
                End If
            Next
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        Return LogAceptado
    End Function
    Public Function SQLCargarDetalle(ByVal Codigo As Integer, ByVal Año As Integer) As String
        Dim strSQL As String
        'strSQL = " SELECT d.DDoc_RF3_Dbl idRubro, IFNULL(r.Descripcion,'') DescRubro, IFNULL(d.DDoc_Prd_Cod,0) Codigo, IFNULL(d.DDoc_Prd_Des,'') Producto, IFNULL(d.DDoc_Prd_QTY,0) Cantidad,
        '           IFNULL(d.DDoc_Prd_NET,0) Precio,IFNULL(c.cat_clave,0) Medida,d.DDoc_Prd_UM id,d.DDoc_Doc_Cat Catalogo,
        '           d.DDoc_Doc_Ano Anio,d.DDoc_Doc_Num Numero,d.DDoc_Doc_Lin Linea,IFNULL(dt.PDoc_Par_Cat,0) catalogo, IFNULL(dt.PDoc_Par_Ano,0) anio,
        '           IFNULL(dt.PDoc_Par_Num,0) numero, IFNULL(dt.PDoc_Par_Lin,0) linea,IFNULL(d.DDoc_RF1_Num,0) Centro,IFNULL(cc.cost_nombre,'') Nombre,
        '           ifnull(d.DDoc_RF1_Txt,'') Comentario, IFNULL(e.Descripcion,'') DescripcionExoneracion, d.DDoc_RF2_Num idExoneracion, d.DDoc_RF3_Num Cancelado "

        'strSQL &= " FROM Dcmtos_DTL d LEFT JOIN Inventarios i ON i.inv_sisemp = d.DDoc_Sis_Emp AND i.inv_numero = d.DDoc_Prd_Cod AND i.inv_UMcmpra = d.DDoc_Prd_UM "
        'strSQL &= " LEFT JOIN Articulos a ON a.art_sisemp =i.inv_sisemp AND a.art_codigo = i.inv_artcodigo "
        'strSQL &= " LEFT JOIN Catalogos c ON c.cat_num = d.DDoc_Prd_UM AND c.cat_clase = 'Medidas' "
        'strSQL &= " LEFT JOIN Dcmtos_DTL_Pro dt ON dt.PDoc_Sis_Emp = d.DDoc_Sis_Emp  AND dt.PDoc_Chi_Cat = d.DDoc_Doc_Cat  AND dt.PDoc_Chi_Ano = d.DDoc_Doc_Ano AND dt.PDoc_Chi_Num = d.DDoc_Doc_Num AND  dt.PDoc_Chi_Lin = d.DDoc_Doc_Lin "
        'strSQL &= " LEFT JOIN " & cfun.ContaEmpresa & ".costos cc On cc.cost_num = d.DDoc_RF1_Num "
        'strSQL &= " LEFT JOIN Exoneracion  e ON e.idEmpresa = d.DDoc_Sis_Emp AND e.ID = d.DDoc_RF2_Num
        '            LEFT JOIN Exoneracion_Rubro r ON r.idEmpresa = d.DDoc_Sis_Emp AND r.ID = d.DDoc_RF3_Dbl "
        'strSQL &= " WHERE d.DDoc_Sis_Emp = {empresa} AND d.DDoc_Doc_Ano = {año} And d.DDoc_Doc_Cat= {catalogo} And d.DDoc_Doc_Num = {Codigo} "


        strSQL = "  SELECT d.DDoc_Prd_PNr UM_OCE, d.DDoc_RF3_Dbl idRubro, IFNULL(r.Descripcion,'') DescRubro, IFNULL(d.DDoc_Prd_Cod,0) Codigo, IFNULL(d.DDoc_Prd_Des,'') Producto, 
                    IFNULL(d.DDoc_Prd_QTY,0) Cantidad, IFNULL(d.DDoc_Prd_NET,0) Precio, IFNULL(c.cat_clave,0) Medida,d.DDoc_Prd_UM id,d.DDoc_Doc_Cat Catalogo, 
                    d.DDoc_Doc_Ano Anio,d.DDoc_Doc_Num Numero,d.DDoc_Doc_Lin Linea, IFNULL(dt.PDoc_Par_Cat,0) catalogo, IFNULL(dt.PDoc_Par_Ano,0) anio,
                    IFNULL(dt.PDoc_Par_Num,0) numero, IFNULL(dt.PDoc_Par_Lin,0) linea, IFNULL(d.DDoc_RF1_Num,0) Centro, IFNULL(cc.cost_nombre,'') Nombre {requerido1}
                    ,IFNULL(d.DDoc_RF1_Txt,'') Comentario, IFNULL(e.Descripcion,'') DescripcionExoneracion, d.DDoc_RF2_Num idExoneracion, d.DDoc_RF3_Num Cancelado

                    ,IFNULL(d.DDoc_RF2_Txt,'') idCosto, IFNULL((SELECT NombreIngles FROM {conta}.nomenclatura n WHERE n.idEmpresa=d.DDoc_Sis_Emp AND n.idcuenta= d.DDoc_RF2_Txt AND nivelCta=2),0) ctaNom
                    ,IFNULL(d.DDoc_RF3_Txt,'') idCentroCosto, IFNULL((SELECT NombreIngles FROM {conta}.nomenclatura n WHERE n.idEmpresa=d.DDoc_Sis_Emp AND n.idcuenta= d.DDoc_RF3_Txt AND nivelCta=3),0) Rubro, d.DDoc_RF2_Dbl recibido, d.DDoc_Prd_Fob porcentaje, d.DDoc_RF4_Dbl descuento
                    FROM Dcmtos_DTL d
                    LEFT JOIN Inventarios i ON i.inv_sisemp = d.DDoc_Sis_Emp AND i.inv_numero = d.DDoc_Prd_Cod AND i.inv_UMcmpra = d.DDoc_Prd_UM
                    LEFT JOIN Articulos a ON a.art_sisemp =i.inv_sisemp AND a.art_codigo = i.inv_artcodigo
                    LEFT JOIN Catalogos c ON c.cat_num = d.DDoc_Prd_UM AND c.cat_clase = 'Medidas'
                    LEFT JOIN Dcmtos_DTL_Pro dt ON dt.PDoc_Sis_Emp = d.DDoc_Sis_Emp 
	                    AND dt.PDoc_Chi_Cat = d.DDoc_Doc_Cat 
	                    AND dt.PDoc_Chi_Ano = d.DDoc_Doc_Ano 
	                    AND dt.PDoc_Chi_Num = d.DDoc_Doc_Num 
	                    AND dt.PDoc_Chi_Lin = d.DDoc_Doc_Lin
                    LEFT JOIN {conta}.costos cc ON cc.cost_num = d.DDoc_RF1_Num {requerido2}
                    LEFT JOIN Exoneracion e ON e.idEmpresa = d.DDoc_Sis_Emp AND e.ID = d.DDoc_RF2_Num
                    LEFT JOIN Exoneracion_Rubro r ON r.idEmpresa = d.DDoc_Sis_Emp AND r.ID = d.DDoc_RF3_Dbl
                    WHERE d.DDoc_Sis_Emp = {empresa} AND d.DDoc_Doc_Ano = {año} AND d.DDoc_Doc_Cat= {catalogo} AND d.DDoc_Doc_Num = {Codigo} "

        If Sesion.idGiro = 2 Then
            strSQL = Replace(strSQL, "{requerido1}", ",IFNULL(d.DDOC_RF1_DBL,0) Requerido, IFNULL(rp.req_nombre,'') NomRequerido ")
            strSQL = Replace(strSQL, "{requerido2}", " LEFT JOIN {conta}.requeridopor rp ON rp.req_num = d.DDOC_RF1_DBL ")
        Else
            strSQL = Replace(strSQL, "{requerido1}", "")
            strSQL = Replace(strSQL, "{requerido2}", "")

        End If
        strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
        strSQL = Replace(strSQL, "{catalogo}", CAT_ORD)
        strSQL = Replace(strSQL, "{Codigo}", Codigo)
        strSQL = Replace(strSQL, "{año}", Año)
        strSQL = Replace(strSQL, "{conta}", Sesion.BaseConta)
        Return strSQL
    End Function

    Private Function ComprobarIngresoDeOCE() As Integer
        Dim intIngresoOCE As Integer = 0
        Dim dblCantidadProductos As Double = 0
        For i As Integer = 0 To dtDetalle.Rows.Count - 1
            If dtDetalle.Rows(i).Cells("colCantidadRecibida").Value = 0 Then
                dblCantidadProductos = 0
            Else
                If dtDetalle.Rows(i).Cells("colCantidadRecibida").Value <= dtDetalle.Rows(i).Cells("colCantidad").Value Then
                    dblCantidadProductos = dblCantidadProductos + (dtDetalle.Rows(i).Cells("colCantidad").Value - dtDetalle.Rows(i).Cells("colCantidadRecibida").Value)
                Else
                    MsgBox("You cannot receive more than requested", vbInformation)
                    dblCantidadProductos = 0
                    Exit For
                End If
            End If
        Next
        If dblCantidadProductos > 0 Then
            intIngresoOCE = 1
        End If

        Return intIngresoOCE
    End Function

    Private Function ComprobarFila() As Boolean
        Dim LogVerdadero As Boolean = True

        If dtDetalle.Rows.Count = 0 Then
            MsgBox("Fill all fields", MsgBoxStyle.Critical)
            LogVerdadero = False
        Else
            LogVerdadero = True
        End If
        For i As Integer = 0 To dtDetalle.RowCount - 1
            'If dtDetalle.Rows(i).Cells("colEstado1").Value <> 2 Then
            If dtDetalle.Rows(i).Visible = True Then
                If CDbl(dtDetalle.Rows(i).Cells("colCantidad").Value) <= INT_CERO Then
                    MsgBox("Quantity is not valid")
                    LogVerdadero = False
                End If
                If Sesion.idGiro = 2 Then
                    If celdaSerie.Text = "OCE" Then
                        If checkFechaAprobacion.Checked = True Then

                            If celdaIdResolución.Text <> "" Then
                                If (dtDetalle.Rows(i).Cells("colidExoneracion").Value) = INT_CERO And (dtDetalle.Rows(i).Cells("colIdRubro").Value) = INT_CERO Then

                                    MsgBox("Select Chapter to exonerate")
                                    LogVerdadero = False


                                End If
                                If (dtDetalle.Rows(i).Cells("colidExoneracion").Value) <> INT_CERO And (dtDetalle.Rows(i).Cells("colIdRubro").Value) = INT_CERO Then

                                    MsgBox("Select Item to exonerate")
                                    LogVerdadero = False


                                End If
                            ElseIf (dtDetalle.Rows(i).Cells("colidExoneracion").Value) <> INT_CERO And (dtDetalle.Rows(i).Cells("colIdRubro").Value) <> INT_CERO Then

                                If Sesion.idGiro = 2 Then
                                Else
                                    If CInt(dtDetalle.Rows(i).Cells("col_id3").Value) = INT_CERO Then
                                        MsgBox("Select A Cost Center")
                                        LogVerdadero = False
                                    End If
                                    If CInt(dtDetalle.Rows(i).Cells("colIdCosto").Value) = vbNullString Then
                                        MsgBox("Select Account")
                                        LogVerdadero = False
                                    End If
                                    If CInt(dtDetalle.Rows(i).Cells("colIdCenterCost").Value) = vbNullString Then
                                        MsgBox("Select Category")
                                        LogVerdadero = False
                                    End If


                                End If
                            End If
                            If celdaIdResolución.Text = "" Then
                                MsgBox("Select a resolution")
                                LogVerdadero = False
                            End If
                            '------------------------------------ checkFechaAprobacion.Checked = FALSE ---------------------------------------------------------

                        Else
                            If celdaIdResolución.Text <> "" Then

                                If (dtDetalle.Rows(i).Cells("colidExoneracion").Value) = INT_CERO And (dtDetalle.Rows(i).Cells("colIdRubro").Value) = INT_CERO Then

                                    MsgBox("Select Chapter to exonerate")
                                    LogVerdadero = False


                                End If
                                If (dtDetalle.Rows(i).Cells("colidExoneracion").Value) <> INT_CERO And (dtDetalle.Rows(i).Cells("colIdRubro").Value) = INT_CERO Then

                                    MsgBox("Select Item to exonerate")
                                    LogVerdadero = False


                                End If
                                If (dtDetalle.Rows(i).Cells("colidExoneracion").Value) <> INT_CERO And (dtDetalle.Rows(i).Cells("colIdRubro").Value) <> INT_CERO Then

                                    If Sesion.idGiro = 2 Then
                                    Else
                                        If CInt(dtDetalle.Rows(i).Cells("col_id3").Value) = INT_CERO Then
                                            MsgBox("Select A Cost Center")
                                            LogVerdadero = False
                                        End If
                                        If CInt(dtDetalle.Rows(i).Cells("colIdCosto").Value) = vbNullString Then
                                            MsgBox("Select Account")
                                            LogVerdadero = False
                                        End If
                                        If CInt(dtDetalle.Rows(i).Cells("colIdCenterCost").Value) = vbNullString Then
                                            MsgBox("Select Category")
                                            LogVerdadero = False
                                        End If


                                    End If
                                End If
                            End If
                            If celdaIdResolución.Text = "" Then
                                If (dtDetalle.Rows(i).Cells("colidExoneracion").Value) <> INT_CERO And (dtDetalle.Rows(i).Cells("colIdRubro").Value) <> INT_CERO Then

                                    If Sesion.idGiro = 2 Then
                                    Else
                                        If CInt(dtDetalle.Rows(i).Cells("col_id3").Value) = INT_CERO Then
                                            MsgBox("Select A Cost Center")
                                            LogVerdadero = False
                                        End If
                                        If CInt(dtDetalle.Rows(i).Cells("colIdCosto").Value) = vbNullString Then
                                            MsgBox("Select Account")
                                            LogVerdadero = False
                                        End If
                                        If CInt(dtDetalle.Rows(i).Cells("colIdCenterCost").Value) = vbNullString Then
                                            MsgBox("Select Category")
                                            LogVerdadero = False
                                        End If


                                    End If
                                End If
                                If (dtDetalle.Rows(i).Cells("colidExoneracion").Value) = INT_CERO And (dtDetalle.Rows(i).Cells("colIdRubro").Value) = INT_CERO Then

                                    If Sesion.idGiro = 2 Then
                                    Else
                                        If CInt(dtDetalle.Rows(i).Cells("col_id3").Value) = INT_CERO Then
                                            MsgBox("Select A Cost Center")
                                            LogVerdadero = False
                                        End If
                                        If CInt(dtDetalle.Rows(i).Cells("colIdCosto").Value) = vbNullString Then
                                            MsgBox("Select Account")
                                            LogVerdadero = False
                                        End If
                                        If CInt(dtDetalle.Rows(i).Cells("colIdCenterCost").Value) = vbNullString Then
                                            MsgBox("Select Category")
                                            LogVerdadero = False
                                        End If


                                    End If
                                End If
                                If (dtDetalle.Rows(i).Cells("colidExoneracion").Value) <> INT_CERO And (dtDetalle.Rows(i).Cells("colIdRubro").Value) = INT_CERO Then

                                    MsgBox("Select Item to exonerate")
                                    LogVerdadero = False


                                End If
                            End If
                        End If
                    End If

                    '------------------------------------ DIFERENTE DE OCE ---------------------------------------------------------
                Else
                    If Sesion.idGiro = 2 Then
                    Else
                        If CInt(dtDetalle.Rows(i).Cells("col_id3").Value) = INT_CERO Then
                            MsgBox("Select A Cost Center")
                            LogVerdadero = False
                        End If
                        If CInt(dtDetalle.Rows(i).Cells("colIdCosto").Value) = vbNullString Then
                            MsgBox("Select Account")
                            LogVerdadero = False
                        End If
                        If CInt(dtDetalle.Rows(i).Cells("colIdCenterCost").Value) = vbNullString Then
                            MsgBox("Select Category")
                            LogVerdadero = False
                        End If
                    End If
                End If

                '------------------------------------ idGiro = 1 ---------------------------------------------------------
            Else



                'If (Sesion.IdEmpresa = 15) Or (Sesion.IdEmpresa >= 18 And Sesion.IdEmpresa <= 21) Then
                'Else
                '    If CInt(dtDetalle.Rows(i).Cells("col_id3").Value) = INT_CERO Then
                '        MsgBox("Select A Cost Center")
                '        LogVerdadero = False
                '    End If
                '    If CInt(dtDetalle.Rows(i).Cells("colIdCosto").Value) = vbNullString Then
                '        MsgBox("Select Account")
                '        LogVerdadero = False
                '    End If
                '    If CInt(dtDetalle.Rows(i).Cells("colIdCenterCost").Value) = vbNullString Then
                '        MsgBox("Select Category")
                '        LogVerdadero = False
                '    End If
                'End If

            End If

        Next
        Return LogVerdadero
    End Function
    Private Function ComprobarFacturaCompra()
        Dim strSQL As String = STR_VACIO
        Dim conec As New MySqlConnection
        Dim COM As MySqlCommand
        Dim Codigo As Integer

        strSQL = "  SELECT COUNT(*) "
        strSQL &= " FROM Dcmtos_DTL_Pro p "
        strSQL &= " WHERE p.PDoc_Sis_Emp = {empresa} AND p.PDoc_Par_Cat = {catalogo} AND p.PDoc_Par_Ano = {anio} AND p.PDoc_Par_Num = {num} AND p.PDoc_Chi_Cat = 44 "

        strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
        strSQL = Replace(strSQL, "{catalogo}", CAT_ORD)
        strSQL = Replace(strSQL, "{anio}", cfun.AñoMySQL)
        strSQL = Replace(strSQL, "{num}", celdaID.Text)

        conec = New MySqlConnection(strConexion)
        conec.Open()
        COM = New MySqlCommand(strSQL, CON)
        Codigo = COM.ExecuteScalar
        conec.Close()
        conec.Dispose()
        conec = Nothing
        System.GC.Collect()
        'celdaID.Text = Codigo
        Return Codigo
    End Function
    Private Function ComprobarLineaFacturaCompra(ByVal linea As Integer)
        Dim strSQL As String = STR_VACIO
        Dim conec As New MySqlConnection
        Dim COM As MySqlCommand
        Dim Codigo As Integer

        strSQL = "  SELECT COUNT(*) "
        strSQL &= " FROM Dcmtos_DTL_Pro p "
        strSQL &= " WHERE p.PDoc_Sis_Emp = {empresa} AND p.PDoc_Par_Cat = {catalogo} AND p.PDoc_Par_Ano = {anio} AND p.PDoc_Par_Num = {num} AND p.PDoc_Par_Lin = {linea}  AND p.PDoc_Chi_Cat = 44 "

        strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
        strSQL = Replace(strSQL, "{catalogo}", CAT_ORD)
        strSQL = Replace(strSQL, "{anio}", cfun.AñoMySQL)
        strSQL = Replace(strSQL, "{num}", celdaID.Text)
        strSQL = Replace(strSQL, "{linea}", linea)

        conec = New MySqlConnection(strConexion)
        conec.Open()
        COM = New MySqlCommand(strSQL, CON)
        Codigo = COM.ExecuteScalar
        conec.Close()
        conec.Dispose()
        conec = Nothing
        System.GC.Collect()
        'celdaID.Text = Codigo
        Return Codigo
    End Function
    Private Function ValidarDependencias() As Integer
        Dim strSQL As String = STR_VACIO
        Dim conec As New MySqlConnection
        Dim COM As MySqlCommand
        Dim Codigo As Integer

        strSQL = "  SELECT COUNT(p.PDoc_Chi_Num)  "
        strSQL &= " FROM Dcmtos_HDR h  "
        strSQL &= "     Left Join Dcmtos_DTL_Pro p ON p.PDoc_Sis_Emp = h.HDoc_Sis_Emp And p.PDoc_Par_Cat = h.HDoc_Doc_Cat And p.PDoc_Par_Ano = h.HDoc_Doc_Ano And p.PDoc_Par_Num = h.HDoc_Doc_Num "
        strSQL &= "  WHERE h.HDoc_Sis_Emp = {empresa} And h.HDoc_Doc_Cat = {catalogo} And h.HDoc_Doc_Ano = {anio} And h.HDoc_Doc_Num = {num} And h.HDoc_Doc_Status = 1 "

        strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
        strSQL = Replace(strSQL, "{catalogo}", CAT_ORD)
        strSQL = Replace(strSQL, "{anio}", cfun.AñoMySQL)
        strSQL = Replace(strSQL, "{num}", celdaID.Text)

        conec = New MySqlConnection(strConexion)
        conec.Open()
        COM = New MySqlCommand(strSQL, CON)
        Codigo = COM.ExecuteScalar
        conec.Close()
        conec.Dispose()
        conec = Nothing
        System.GC.Collect()
        'celdaID.Text = Codigo
        Return Codigo
    End Function
#End Region
    Private Sub frmOrdenCompra_FormClosing(sender As Object, e As FormClosingEventArgs) Handles Me.FormClosing
        Fprincipal.BarraDeTareas1.QuitarFormulario(strKey)
    End Sub
    Private Sub frmOrdenCompra_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        dtpFin.Value = Today
        dtpInicio.Value = dtpFin.Value.AddMonths(NO_FILA)
        'Dim col1 As New DataGridViewCheckBoxColumn()
        'dtDetalle.Columns.Add(col1)
        tipoResolucion = STR_VACIO
        Accessos()
        If Sesion.IdEmpresa = 15 Or Sesion.IdEmpresa = 20 Or Sesion.IdEmpresa = 22 Then
            panelApprovalDate.Visible = False
            checkFechaAprobacion.Visible = True
            celdaOCE.Visible = True
            Label14.Visible = True
        Else
            panelApprovalDate.Visible = False
            checkFechaAprobacion.Visible = False
            celdaOCE.Visible = False
            Label14.Visible = False
        End If
        MostrarLista()
    End Sub
    Private Sub botonAgregar_Click(sender As Object, e As EventArgs) Handles botonAgregar.Click
        Dim frm As New frmSeleccionar
        Dim strFila As String = STR_VACIO
        Dim strSQL As String = STR_VACIO
        Dim Codigo As Integer = NO_FILA
        Dim Validar As Boolean = True
        Dim i As Integer = 0
        Dim condicion As String
        Try
            If Sesion.idGiro = 2 Then
                If intTipo = 0 Then
                    frm.ParametroCrear = "Consumables"
                    frm.Titulo = " Please select the product"
                    frm.Campos = " i.inv_numero ,a.art_desc Descripcion , i.inv_costo Precio, ca.cat_clave UM "
                    frm.Tabla = "  Inventarios i LEFT JOIN Articulos a ON a.art_sisemp = i.inv_sisemp AND a.art_codigo = i.inv_artcodigo  LEFT JOIN Catalogos c ON c.cat_num = a.art_clase   LEFT JOIN Catalogos ca ON ca.cat_num = inV_UMVenta "
                    If Sesion.IdEmpresa = 22 Then
                        condicion = "   i.inv_sisemp  = " & Sesion.IdEmpresa & " AND i.inv_generico = 1 AND i.inv_status = 'Activo' AND  (c.cat_sisemp IN (1,2) {otros})    "
                    Else
                        condicion = "   i.inv_sisemp  = " & Sesion.IdEmpresa & " AND i.inv_generico = 1 AND i.inv_status = 'Activo' AND  (c.cat_ext = 'Consumibles' OR   c.cat_ext = 'Material de empaque' OR  c.cat_ext = 'Repuestos' OR c.cat_ext= 'Inventario en Custodia' OR c.cat_ext= 'Combustible' OR c.cat_ext= 'Maquinaria'{otros})    "
                    End If
                    If Sesion.IdEmpresa = 20 Then
                        condicion = Replace(condicion, "{otros}", " OR c.cat_ext = 'Otros'")
                    Else
                        condicion = Replace(condicion, "{otros}", "")
                    End If
                    frm.Condicion = condicion
                    frm.Limite = 25
                        frm.Filtro = " a.art_desc"
                        frm.FiltroText = " enter the product number to search "

                        frm.ShowDialog(Me)
                    If frm.DialogResult = DialogResult.OK Then
                        strFila = frm.LLave & "|" & frm.Dato & "|" & frm.Dato2
                        cfun.AgregarFila(dtDetalle, strFila)
                    End If

                    If celdaIdProveedor.Text = NO_FILA Then
                            MsgBox("Please Select a Provider")
                            Exit Sub
                        End If

                    Else
                        'frm.LCrear = True
                        frm.ParametroCrear = "Insumos"
                    frm.Titulo = "Seleccione un Producto"
                    frm.Campos = " cat_num Codigo, cat_desc  Descripcion , cat_dato  Precio "
                    frm.Tabla = " Catalogos "
                    frm.Condicion = " cat_clase = 'Insumos' "
                    frm.Limite = 10
                    frm.Filtro = " cat_desc "
                    frm.FiltroText = " Ingrese la descripicion del articulo para buscar"
                    frm.ShowDialog(Me)
                    If frm.DialogResult = DialogResult.OK Then
                        strFila = frm.LLave & "|" & frm.Dato & "|" & frm.Dato2
                        cfun.AgregarFila(dtDetalle, strFila)
                    End If

                    If celdaIdProveedor.Text = NO_FILA Then
                        MsgBox("Please Select a Provider")
                        Exit Sub
                    End If
                End If
            Else
                'frm.LCrear = True
                frm.ParametroCrear = "Insumos"
                frm.Titulo = "Seleccione un Producto"
                frm.Campos = " cat_num Codigo, cat_desc  Descripcion , cat_dato  Precio "
                frm.Tabla = " Catalogos "
                frm.Condicion = " cat_clase = 'Insumos' "
                frm.Limite = 10
                frm.Filtro = " cat_desc "
                frm.FiltroText = " Ingrese la descripicion del articulo para buscar"
                frm.ShowDialog(Me)
                If frm.DialogResult = DialogResult.OK Then
                    strFila = frm.LLave & "|" & frm.Dato & "|" & frm.Dato2
                    cfun.AgregarFila(dtDetalle, strFila)
                End If

                If celdaIdProveedor.Text = NO_FILA Then
                    MsgBox("Please Select a Provider")
                    Exit Sub
                End If
            End If
            'frm.Titulo = " Quotation "
            'frm.Campos = " d.DDoc_Doc_Num Codigo , d.DDoc_Prd_Des Descripcion,d.DDoc_Prd_QTY Cantidad ,d.DDoc_Prd_NET Precio,c.cat_clave medida,d.DDoc_Prd_UM id, d.DDoc_Prd_Cod CodProd "
            'frm.Tabla = " Dcmtos_HDR h  LEFT JOIN Dcmtos_DTL d ON d.DDoc_Sis_Emp = h.HDoc_Sis_Emp AND d.DDoc_Doc_Cat = h.HDoc_Doc_Cat AND d.DDoc_Doc_Ano = h.HDoc_Doc_Ano AND d.DDoc_Doc_Num = h.HDoc_Doc_Num  LEFT JOIN Inventarios i ON i.inv_sisemp = d.DDoc_Sis_Emp AND i.inv_numero = d.DDoc_Prd_Cod AND i.inv_UMcmpra = d.DDoc_Prd_UM LEFT JOIN Articulos a ON a.art_sisemp =i.inv_sisemp AND a.art_codigo = i.inv_artcodigo  LEFT JOIN Catalogos c ON c.cat_num = d.DDoc_Prd_UM AND c.cat_clase = 'Medidas' "
            'frm.FiltroText = " Enter the quotation Name "
            'frm.Filtro = " h.HDoc_Emp_Nom"
            'frm.Condicion = " h.HDoc_Sis_Emp =" & Sesion.IdEmpresa & " AND h.HDoc_Doc_Cat = " & catalogos & " AND h.HDoc_Doc_Status = 1 AND d.DDoc_RF3_Num = 1 AND d.DDoc_RF1_Num = " & celdaIdProveedor.Text & " AND ( SELECT COUNT(*) FROM Dcmtos_DTL_Pro p LEFT JOIN Dcmtos_HDR hh ON hh.HDoc_Sis_Emp = p.PDoc_Sis_Emp AND hh.HDoc_Doc_Cat = p.PDoc_Chi_Cat AND hh.HDoc_Doc_Ano = p.PDoc_Chi_Ano AND hh.HDoc_Doc_Num = p.PDoc_Chi_Num AND hh.HDoc_Doc_Status = 1 WHERE p.PDoc_Sis_Emp = d.DDoc_Sis_Emp AND p.PDoc_Par_Cat = d.DDoc_Doc_Cat AND p.PDoc_Par_Ano = d.DDoc_Doc_Ano AND p.PDoc_Par_Num = d.DDoc_Doc_Num AND p.PDoc_Par_Lin = d.DDoc_Doc_Lin)=0 GROUP BY h.HDoc_Sis_Emp, h.HDoc_Doc_Cat, h.HDoc_Doc_Ano, h.HDoc_Doc_Num "
            'frm.ShowDialog(Me)
            'If frm.DialogResult = DialogResult.OK Then
            '    If dtDetalle.RowCount > 0 Then
            '        For i = 0 To dtDetalle.Rows.Count - 1
            '            If i = 0 Then
            '                strCapturaCodigoProd = dtDetalle.Rows(i).Cells("colCodigo").Value
            '            Else
            '                strCapturaCodigoProd = dtDetalle.Rows(i).Cells("colCodigo").Value & "," & strCapturaCodigoProd
            '            End If

            '        Next
            '    End If
            'strSQL = SQLDetalle(frm.LLave, strCapturaCodigoProd)
            '    ' Codigo = frm.ListaClientes.CurrentRow.Cells(6).Value
            '    Dim intCuentaLinea As Integer = 0
            '    MyCnn.CONECTAR = strConexion
            '    COM = New MySqlCommand(strSQL, CON)
            '    REA = COM.ExecuteReader
            '    If REA.HasRows Then
            '        Do While REA.Read
            '            intCuentaLinea = intCuentaLinea + 1
            '            If dtDetalle.RowCount > 0 Then
            '                '     Validar = True
            '                '    Codigo = REA.GetInt32("codigo")

            '                ' RECORRE EL DG PARA VER SI YA ESTÁ AGREGADO EL PRODUCTO
            '                ' For i = 0 To dtDetalle.RowCount - 1
            '                'If dtDetalle.Rows(i).Cells("colCodigo").Value = Codigo Then
            '                'Validar = False
            '                'End If
            '                '   Next

            '                If Validar = True Then
            '                    strFila = STR_VACIO
            '                    Codigo = REA.GetInt32("codigo")
            '                    strFila = REA.GetInt32("codigo") & "|" 'ID CODIGO
            '                    strFila &= REA.GetString("Descripcion") & "|" 'Producto   
            '                    strFila &= REA.GetInt32("Cantidad") & "|" ' Cantidad
            '                    strFila &= REA.GetDouble("Precio") & "|" ' Precio
            '                    strFila &= REA.GetString("medida") & "|" 'Medida
            '                    strFila &= REA.GetInt32("id") & "|" ' id 
            '                    strFila &= REA.GetDouble("Precio") * REA.GetInt32("Cantidad") & "|"   ' Total
            '                    strFila &= "|"  ' Centro Costo
            '                    strFila &= "0|" ' ID
            '                    strFila &= REA.GetString("catalogo") & "|"  ' Catalogo
            '                    strFila &= REA.GetInt32("anio") & "|" ' Año
            '                    strFila &= REA.GetInt32("numero") & "|" ' Numero 
            '                    strFila &= REA.GetInt32("linea") & "|" ' Linea
            '                    strFila &= CAT_ORD & "|"   'Catalogo 777
            '                    strFila &= "|"  ' Anio
            '                    strFila &= "|"  ' Numero 
            '                    strFila &= "0|"   'Linea 
            '                    strFila &= REA.GetString("Comentario") & "|"   'Comentario
            '                    strFila &= "0|"   'Estado 
            '                    cFunciones.AgregarFila(dtDetalle, strFila)
            '                    celdaidMoneda.Text = REA.GetString("Moneda")
            '                    celdaMoneda.Text = REA.GetInt32("clave")
            '                    celdaTasa.Text = REA.GetDouble("Tasa")

            '                Else

            '                End If

            '            Else
            '                strFila = STR_VACIO
            '                Codigo = REA.GetInt32("codigo")
            '                strFila = REA.GetInt32("codigo") & "|" 'ID CODIGO
            '                strFila &= REA.GetString("Descripcion") & "|" 'Producto   
            '                strFila &= REA.GetInt32("Cantidad") & "|" ' Cantidad
            '                strFila &= REA.GetDouble("Precio") & "|" ' Precio
            '                strFila &= REA.GetString("medida") & "|" 'Medida
            '                strFila &= REA.GetInt32("id") & "|" ' id 
            '                strFila &= REA.GetDouble("Precio") * REA.GetInt32("Cantidad") & "|"   ' Total
            '                strFila &= "|"  ' Centro Costo
            '                strFila &= "0|" ' ID
            '                strFila &= REA.GetString("catalogo") & "|"  ' catalogo
            '                strFila &= REA.GetInt32("anio") & "|" ' año
            '                strFila &= REA.GetInt32("numero") & "|" '  numero
            '                strFila &= REA.GetInt32("linea") & "|" ' linea 
            '                strFila &= CAT_ORD & "|"   'Catalogo 777
            '                strFila &= "|"  ' Anio
            '                strFila &= "|"  ' Numero 
            '                strFila &= "0|"   'Linea 
            '                strFila &= REA.GetString("Comentario") & "|"   'Comentario
            '                strFila &= "0|"   'Estado 
            '                cFunciones.AgregarFila(dtDetalle, strFila)
            '                celdaidMoneda.Text = REA.GetString("Moneda")
            '                celdaMoneda.Text = REA.GetInt32("clave")
            '                celdaTasa.Text = REA.GetDouble("Tasa")

            '            End If
            '        Loop

            '        CalcularTotal()
            '    End If
            'End If


        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub
    Private Sub Encabezado1_ClickBorrar(sender As Object, click As Boolean) Handles Encabezado1.ClickBorrar
        If LogBorrar = True Then
            If ValidarDependencias() > INT_CERO Then
                MsgBox("You can not delete a document in the process", vbInformation, "Notice")
            Else
                If MsgBox("Are you sure you want to delete the document?", vbQuestion + vbYesNo, "Notice") = vbYes Then
                    If Borrar() = True Then
                        MsgBox("Document deleted")
                        cfun.EscribirRegistro("Dcmtos_HDR", clsFunciones.AccEnum.acDelete, 0, CAT_ORD, celdaAño.Text, celdaID.Text)
                        MostrarLista()
                    Else
                        MsgBox("ERROR: Document could not be deleted")
                    End If
                End If
            End If
        Else
            MsgBox("You do not have sufficient permissions to execute this action")
        End If
    End Sub
    Private Sub Encabezado1_ClickCerrar(sender As Object, click As Boolean) Handles Encabezado1.ClickCerrar

        If panelLIsta.Visible = True Then
            Me.Close()
        Else
            MostrarLista()
        End If
    End Sub
    Private Sub Encabezado1_ClickGuardar(sender As Object, click As Boolean) Handles Encabezado1.ClickGuardar
        Dim intIngresoOCE As Integer = INT_CERO
        If Sesion.idGiro = 1 Then
            If celdaObservaciones.Text = Nothing Then
                MsgBox("Enter a Description")
            Else
                If ComprobarDatos() = True Then
                    If Me.Tag = "Mod" Then
                        If logEditar Then
                            If ComprobarFila() Then
                                intIngresoOCE = ComprobarIngresoDeOCE()
                                Encabezado1.botonGuardar.Enabled = False
                                If GuardarEncabezado(True, intIngresoOCE) = True Then
                                    MsgBox("Document Updated correctly")
                                End If
                                cfun.EscribirRegistro("Dcmtos_HDR", clsFunciones.AccEnum.acUpdate, 0, CAT_ORD, celdaAño.Text, celdaID.Text)
                                If MsgBox("Want to Print the Document", vbOKCancel, "To Print?") = vbOK Then
                                    Impresiones()
                                    Encabezado1.botonGuardar.Enabled = True
                                Else
                                    MostrarLista()
                                End If
                            Else
                                MsgBox("Error, document not saved")
                            End If
                            'Encabezado1.botonGuardar.Enabled = True
                        Else
                        End If
                        'Else
                        '    MsgBox("You do not have enough Privileges to execute this action.", MsgBoxStyle.Critical)
                        'End If
                    Else
                        If logInsertar Then
                            If ComprobarFila() Then
                                Encabezado1.botonGuardar.Enabled = False
                                If GuardarEncabezado() = True Then
                                    Me.Tag = "Mod"
                                    MsgBox("Document saved correctly")
                                    cfun.EscribirRegistro("Dcmtos_HDR", clsFunciones.AccEnum.acAdd, 0, CAT_ORD, celdaAño.Text, celdaID.Text)

                                    If MsgBox("Want to Print the Document", vbOKCancel, "To Print?") = vbOK Then
                                        Impresiones()
                                    Else
                                        MostrarLista()
                                    End If
                                Else
                                    MsgBox("Error, document not saved")
                                End If
                                'Encabezado1.botonGuardar.Enabled = True
                            End If
                            ' MsgBox("No posee suficientes Privilegios para ejecutar esta acción.", MsgBoxStyle.Critical)
                        End If
                    End If
                End If
            End If
        Else
            If ComprobarDatos() = True Then
                If Me.Tag = "Mod" Then
                    If logEditar Then
                        If ComprobarFila() Then
                            intIngresoOCE = ComprobarIngresoDeOCE()
                            Encabezado1.botonGuardar.Enabled = False
                            If GuardarEncabezado(True, intIngresoOCE) = True Then
                                MsgBox("Document Updated correctly")
                            End If
                            cfun.EscribirRegistro("Dcmtos_HDR", clsFunciones.AccEnum.acUpdate, 0, CAT_ORD, celdaAño.Text, celdaID.Text)
                            If MsgBox("Want to Print the Document", vbOKCancel, "To Print?") = vbOK Then
                                Impresiones()
                                Encabezado1.botonGuardar.Enabled = True
                            Else
                                MostrarLista()
                            End If
                        Else
                            MsgBox("Error, document not saved")
                        End If
                        'Encabezado1.botonGuardar.Enabled = True
                    Else
                    End If
                    'Else
                    '    MsgBox("You do not have enough Privileges to execute this action.", MsgBoxStyle.Critical)
                    'End If
                Else
                    If logInsertar Then
                        If ComprobarFila() Then
                            Encabezado1.botonGuardar.Enabled = False
                            If GuardarEncabezado() = True Then
                                Me.Tag = "Mod"
                                MsgBox("Document saved correctly")
                                cfun.EscribirRegistro("Dcmtos_HDR", clsFunciones.AccEnum.acAdd, 0, CAT_ORD, celdaAño.Text, celdaID.Text)

                                If MsgBox("Want to Print the Document", vbOKCancel, "To Print?") = vbOK Then
                                    Impresiones()
                                Else
                                    MostrarLista()
                                End If
                            Else
                                MsgBox("Error, document not saved")
                            End If
                            'Encabezado1.botonGuardar.Enabled = True
                        End If
                        ' MsgBox("No posee suficientes Privilegios para ejecutar esta acción.", MsgBoxStyle.Critical)
                    End If
                End If
            End If
        End If
    End Sub
    Private Sub Encabezado1_ClickNuevo(sender As Object, click As Boolean) Handles Encabezado1.ClickNuevo
        Dim opt As New frmOption
        If Sesion.idGiro = 2 Then
            dtDetalle.Enabled = True
            opt.Titulo = "Option"
            opt.Mensaje = "Select an option"
            If Sesion.IdEmpresa = 22 Then
                opt.Opciones = "Consumables" & "|" & "Others - Trading "
            Else
                opt.Opciones = "Consumables - Spinning Mills" & "|" & "Others - Trading "
            End If

            If opt.ShowDialog = DialogResult.OK Then
                dtDetalle.Columns("colPrecio").HeaderText = "Price without VAT"
                'dtDetalle.Columns(18).Visible = True
                'dtDetalle.Columns(21).Visible = True
                panelDiasCredito.Visible = True

                rbContado.Visible = False
                rbCredito.Visible = False
                Select Case opt.Seleccion
                    Case 0
                        intTipo = 0
                    Case 1
                        intTipo = 1

                End Select
            Else
                Exit Sub
            End If
        End If
        If Sesion.idGiro = 1 Then
            dtDetalle.Columns("colCosto").Visible = True
            dtDetalle.Columns("colCentroCosto").Visible = True
            PanelDelivery.Visible = False
        Else
            dtDetalle.Columns("colCosto").Visible = False
            dtDetalle.Columns("colCentroCosto").Visible = False
            PanelDelivery.Visible = True
        End If
        MostrarLista(False, True)
        checkFechaAprobacion.Checked = False

    End Sub
    Private Sub dtDetalle_CellContentClick(sender As Object, e As DataGridViewCellEventArgs) Handles dtDetalle.CellContentClick
        cfun.ValidarFilaGrid(dtDetalle, "colPrecio")
        cfun.ValidarFilaGrid(dtDetalle, "colCantidad")
        CalcularTotal()
        CalcularDescuento()
    End Sub
    Private Sub botonQuitar_Click(sender As Object, e As EventArgs) Handles botonQuitar.Click
        'If dtDetalle.SelectedRows.Count = INT_CERO Then Exit Sub
        'dtDetalle.Rows.Remove(dtDetalle.CurrentRow)

        Try
            Dim Count As Integer
            If dtDetalle.SelectedRows Is Nothing Then Exit Sub
            If dtDetalle.Rows.Count > 1 Then
                Count = dtDetalle.Rows.GetRowCount(DataGridViewElementStates.Selected)
                For i As Integer = 0 To Count - 1
                    ' strTexto = "Remove " & CStr(dtDetalle.SelectedCells(1).Value) & vbCrLf
                    If MsgBox(" Are you sure you want to delete the row " & "OF THE ORDER " &
                CInt(dtDetalle.SelectedCells(0).Value) & ", " &
           CStr(dtDetalle.SelectedCells(1).Value) & " " &
            CInt(dtDetalle.SelectedCells(3).Value) & " " &
            CDbl(dtDetalle.SelectedCells(4).Value) & " " &
            CStr(dtDetalle.SelectedCells(5).Value) & " " &
            CInt(dtDetalle.SelectedCells(6).Value) & " " &
            CDbl(dtDetalle.SelectedCells(7).Value) & " " &
               CStr(dtDetalle.SelectedCells(8).Value) & "?", vbQuestion + vbYesNo + vbDefaultButton2) =
                vbYes Then
                        If dtDetalle.SelectedCells(25).Value = 0 Or dtDetalle.SelectedCells(25).Value = 1 Then
                            dtDetalle.SelectedCells(25).Value = 2
                            'dtDetalle.Rows.Remove(dtDetalle.CurrentRow)
                            'celdaTotal.Text = celdaTexto3.Text
                            'CalcularTotal()
                            If dtDetalle.SelectedCells(25).Value = 2 Then
                                dtDetalle.CurrentRow.Visible = False
                                CalcularTotal()
                                CalcularDescuento()
                            End If
                        ElseIf dtDetalle.Rows(i).Selected = Nothing Then
                            '  dgDetalle.SelectedCells(6).Value = 3
                            ' dgDetalle.CurrentRow.Visible = False
                            dtDetalle.Rows.RemoveAt(dtDetalle.RowCount - 1)
                        End If
                    End If
                Next
            Else
                MsgBox("you can´t delete the last row")
                Exit Sub
            End If
            dtDetalle.ReadOnly = False
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub
    Private Sub dtDetalle_CellEndEdit(sender As Object, e As DataGridViewCellEventArgs) Handles dtDetalle.CellEndEdit
        cfun.ValidarFilaGrid(dtDetalle, "colPrecio")
        cfun.ValidarFilaGrid(dtDetalle, "colCantidad")
        CalcularTotal()
        CalcularDescuento()
    End Sub
    Private Sub botonProveedor_Click(sender As Object, e As EventArgs) Handles botonProveedor.Click
        Dim frm As New frmSeleccionar
        Dim strCondicion As String = STR_VACIO

        Try
            frm.Titulo = "Provider"
            frm.Campos = " pro_codigo Code , pro_proveedor Provider,pro_direccion "
            frm.Tabla = " Proveedores "
            frm.FiltroText = " Enter the Provider Name"
            frm.Filtro = " pro_proveedor "
            frm.Condicion = " pro_sisemp = " & Sesion.IdEmpresa & ""
            frm.Limite = 10
            frm.ShowDialog(Me)
            If frm.DialogResult = DialogResult.OK Then
                celdaIdProveedor.Text = frm.LLave
                celdaProveedor.Text = frm.Dato
                celdaDireccion.Text = frm.Dato2
                dtDetalle.Rows.Clear()
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub
    Private Sub botonCCostos_Click(sender As Object, e As EventArgs) Handles botonCCostos.Click
        Dim frm As New frmSeleccionar
        Try
            frm.Titulo = "Seleccione un centro de costos"
            frm.Campos = " cost_num Codigo, cost_nombre Nombre "
            frm.Tabla = cfun.ContaEmpresa & ".costos "
            frm.FiltroText = " Ingrese el nombre del centro de costo para filtrar"
            frm.Filtro = " cost_nombre "
            frm.Condicion = "cost_num >=0"

            frm.ShowDialog(Me)
            If frm.DialogResult = DialogResult.OK Then
                celdaIDCosto.Text = frm.LLave
                celdaCostos.Text = frm.Dato
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub
    Private Sub dgLista_DoubleClick(sender As Object, e As EventArgs) Handles dgLista.DoubleClick
        Dim intID As Integer = NO_FILA
        Dim intAño As Integer = NO_FILA
        Try
            If dgLista.SelectedRows.Count = INT_CERO Then Exit Sub
            Me.Tag = "mod"

            BarraTitulo1.CambiarTitulo("Modificar Registro")
            intID = dgLista.SelectedCells(0).Value
            intAño = dgLista.SelectedCells(1).Value
            reset()
            Seleccionar(intID, intAño)
            If Sesion.idGiro = 2 Then
                dtDetalle.Columns("colPrecio").HeaderText = "Price without VAT"
                dtDetalle.Columns(20).Visible = True
                'dtDetalle.Columns(23).Visible = True
                panelDiasCredito.Visible = True
                rbContado.Visible = False
                rbCredito.Visible = False
            End If
            MostrarLista(False)
            Encabezado1.botonNuevo.Enabled = True
            If Sesion.idGiro = 1 Then
                dtDetalle.Columns("colCosto").Visible = True
                dtDetalle.Columns("colCentroCosto").Visible = True
                PanelDelivery.Visible = False
            Else
                dtDetalle.Columns("colCosto").Visible = False
                dtDetalle.Columns("colCentroCosto").Visible = False
                PanelDelivery.Visible = True
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try

    End Sub
    Private Sub botonInprimir_Click(sender As Object, e As EventArgs) Handles botonInprimir.Click
        Impresiones()
    End Sub

    Private Sub Impresiones()
        If logConsultar = True Then
            Dim cRep As New clsReportes
            Dim frm As New frmOption
            Try
                If Sesion.idGiro = 2 Then
                    frm.Opciones = "Orden de Compra Local |" & "Orden de Compra Exenta |" & "Orden de Compra Internacional"
                    frm.Titulo = "Printing Formats "
                    frm.Mensaje = "Select type of printing "
                    If frm.ShowDialog = DialogResult.OK Then
                        Select Case frm.Seleccion
                            Case 0
                                cRep.CompraLocalHSM(celdaID.Text, celdaAño.Text, celdaMoneda.Text)
                            Case 1
                                cRep.CompraExentaLocalHSM(celdaID.Text, celdaAño.Text, celdaMoneda.Text)
                            Case 2
                                cRep.CompraInternacionalHSM(celdaID.Text, celdaAño.Text, celdaMoneda.Text)
                        End Select
                    Else
                        Exit Sub

                    End If
                ElseIf Sesion.IdEmpresa = 20 Then
                    frm.Opciones = "Orden de Compra Local |" & "Orden de Compra Exenta |" & "Orden de Compra Internacional"
                    frm.Titulo = "Printing Formats "
                    frm.Mensaje = "Select type of printing "

                    If frm.ShowDialog = DialogResult.OK Then
                        Select Case frm.Seleccion
                            Case 0
                                cRep.CompraLocalHSM(celdaID.Text, celdaAño.Text, celdaMoneda.Text)
                            Case 1
                                cRep.CompraExentaLocalHSM(celdaID.Text, celdaAño.Text, celdaMoneda.Text)
                            Case 2
                                cRep.CompraInternacionalNS(celdaID.Text, celdaAño.Text, celdaMoneda.Text)
                        End Select
                    Else
                        Exit Sub
                    End If


                Else
                    cRep.GenerarOrdenCompra(CAT_ORD, CInt(celdaAño.Text), CInt(celdaID.Text))
                    cRep.Parent = Fprincipal

                End If

            Catch ex As Exception
                MsgBox(ex.ToString)

            End Try
        Else
            MsgBox("You do not have enough Privileges to execute this action", MsgBoxStyle.Critical)
        End If
    End Sub

    Private Function LimitePosicionArancelaria(ByVal idCapitulo As Integer, ByVal idRubro As Integer) As Boolean
        Dim strsql As String = STR_VACIO
        Dim bandera As Boolean = False
        Dim compararCantidad As Boolean = False
        Dim compararMonto As Boolean = False

        strsql = "SELECT IFNULL(SUM(d.DDoc_Prd_QTY),0) Cantidad, ex.Cantidad CantidadExoneracion, IFNULL(SUM(d.DDoc_Prd_NET * d.DDoc_Prd_QTY),0) Total, ex.Monto_Total
                 FROM Dcmtos_DTL d
                 LEFT JOIN Exoneracion_Rubro ex ON ex.ID = d.DDoc_RF3_Dbl AND ex.Id_Capitulo = d.DDoc_RF2_Num
                 WHERE ex.idEmpresa = {empresa} AND ex.ID = {rubro} AND ex.Id_Capitulo = {capitulo} AND d.DDoc_RF3_Num = 0"


        strsql = Replace(strsql, "{empresa}", Sesion.IdEmpresa)
        strsql = Replace(strsql, "{rubro}", idRubro)
        strsql = Replace(strsql, "{capitulo}", idCapitulo)

        Dim conec As New MySqlConnection
        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader
        Dim Cantidad As Integer = 0
        Dim CantidadDetalle As Integer = 0
        Dim CantidadTotal As Integer = 0
        Dim CantidadExoneracion As Integer = 0
        Dim Total As Double = 0
        Dim Monto_Total As Double = 0
        Dim TotalDetalle As Double = 0
        Dim SumaTotal As Double = 0

        Dim strsql1 As String = STR_VACIO
        Dim conec1 As New MySqlConnection
        Dim COM1 As MySqlCommand
        Dim REA1 As MySqlDataReader
        Dim TotalFactura As Double = 0
        Dim CantidadFactura As Integer = 0
        Dim Precio As Double = 0
        Try

            conec = New MySqlConnection(strConexion)
            conec.Open()
            COM = New MySqlCommand(strsql, CON)
            REA = COM.ExecuteReader

            If REA.HasRows Then
                dgLista.Rows.Clear()
                Do While REA.Read

                    Cantidad = REA.GetInt32("Cantidad")
                    CantidadExoneracion = REA.GetInt32("CantidadExoneracion")
                    Total = REA.GetDouble("Total")
                    Monto_Total = REA.GetDouble("Monto_Total")

                Loop
            End If
            REA.Close()
            conec.Close()
            conec.Dispose()
            conec = Nothing
            System.GC.Collect()
            For i As Integer = 0 To dtDetalle.Rows.Count - 1
                If (dtDetalle.Rows(i).Cells("colidExoneracion").Value = idCapitulo) And (dtDetalle.Rows(i).Cells("colIdRubro").Value = idRubro) Then
                    If dtDetalle.Rows(i).Cells("colCancelado").Value = "SI" Then

                        strsql = "SELECT d.DDoc_Prd_NET Precio, d.DDoc_Prd_QTY Cantidad
                                    FROM Dcmtos_DTL d
                                    LEFT JOIN Dcmtos_DTL_Pro p ON p.PDoc_Sis_Emp = d.DDoc_Sis_Emp AND p.PDoc_Chi_Cat = d.DDoc_Doc_Cat AND p.PDoc_Chi_Ano = d.DDoc_Doc_Ano AND p.PDoc_Chi_Num  = d.DDoc_Doc_Num
                                    AND p.PDoc_Chi_Lin = d.DDoc_Doc_Lin
                                    WHERE p.PDoc_Par_Cat = {catalogo} AND p.PDoc_Par_Ano = {anio} AND p.PDoc_Par_Num  = {numero} AND p.PDoc_Par_Lin = {linea}"


                        strsql = Replace(strsql, "{catalogo}", dtDetalle.Rows(i).Cells("col_catalogo").Value)
                        strsql = Replace(strsql, "{anio}", dtDetalle.Rows(i).Cells("col_año").Value)
                        strsql = Replace(strsql, "{numero}", dtDetalle.Rows(i).Cells("col_numero").Value)
                        strsql = Replace(strsql, "{linea}", dtDetalle.Rows(i).Cells("col_linea").Value)

                        conec1 = New MySqlConnection(strConexion)
                        conec1.Open()
                        COM1 = New MySqlCommand(strsql, CON)
                        REA1 = COM1.ExecuteReader

                        If REA1.HasRows Then
                            Do While REA1.Read
                                Precio = REA1.GetInt32("Precio")
                                CantidadFactura = REA1.GetInt32("Cantidad")
                                TotalFactura = Precio * CantidadFactura
                            Loop

                        Else
                            TotalFactura = 0
                            CantidadFactura = 0
                        End If
                        REA1.Close()
                        conec1.Close()
                        conec1.Dispose()
                        conec1 = Nothing
                        System.GC.Collect()
                        TotalDetalle = TotalDetalle + TotalFactura
                        CantidadDetalle = CantidadDetalle + CantidadFactura
                    Else
                        TotalDetalle = TotalDetalle + (CDbl(dtDetalle.Rows(i).Cells("colPrecio").Value) * dtDetalle.Rows(i).Cells("colCantidad").Value)
                        CantidadDetalle = CantidadDetalle + dtDetalle.Rows(i).Cells("colCantidad").Value

                    End If

                End If


            Next

            SumaTotal = Total + TotalDetalle
            CantidadTotal = Cantidad + CantidadDetalle

            If CantidadTotal > 0 And CantidadExoneracion > 0 Then

                If CantidadTotal >= CantidadExoneracion Then
                    compararCantidad = True
                End If
            End If

            If SumaTotal > 0 And Monto_Total > 0 Then

                If SumaTotal >= Monto_Total Then
                    compararMonto = True
                End If
            End If


            If compararMonto Or compararCantidad Then
                bandera = True
            Else
                bandera = False
            End If


        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try


        Return bandera
    End Function

    Private Sub dtDetalle_DoubleClick(sender As Object, e As EventArgs) Handles dtDetalle.DoubleClick
        If dtDetalle.Rows.Count = 0 Then Exit Sub
        If dtDetalle.CurrentCell Is Nothing Then Exit Sub

        Try
            Select Case dtDetalle.CurrentCell.ColumnIndex
                Case 2
                    Dim frm As New frmSeleccionar
                    Try
                        frm.Titulo = "Select a Unit Measure"
                        frm.Campos = " c.cat_desc "
                        frm.Tabla = "Catalogos c"
                        frm.FiltroText = "Enter the name of the unit measure to filter"
                        frm.Filtro = " c.cat_desc "
                        frm.Condicion = "c.cat_clase = 'Medidas' AND c.cat_dato ='OCE'"

                        frm.ShowDialog(Me)
                        If frm.DialogResult = DialogResult.OK Then
                            dtDetalle.CurrentRow.Cells("colUM").Value = frm.LLave
                        End If
                    Catch ex As Exception
                        MsgBox(ex.ToString)
                    End Try
                Case 8
                    Dim frm As New frmSeleccionar
                    Try
                        frm.Titulo = "Select a cost center"
                        frm.Campos = " cost_num Codigo, cost_nombre Nombre "
                        frm.Tabla = cfun.ContaEmpresa & ".costos "
                        frm.FiltroText = "Enter the name of the cost center to filter"
                        frm.Filtro = " cost_nombre "
                        frm.Condicion = "cost_num >=0"

                        frm.ShowDialog(Me)
                        If frm.DialogResult = DialogResult.OK Then
                            dtDetalle.CurrentRow.Cells("col_id3").Value = frm.LLave
                            dtDetalle.CurrentRow.Cells("col_centro").Value = frm.Dato
                        End If
                    Catch ex As Exception
                        MsgBox(ex.ToString)
                    End Try
                Case 10
                    Dim frm As New frmSeleccionar
                    Try
                        frm.Titulo = "Select a Requeride By"
                        frm.Campos = " req_num Codigo, req_nombre Nombre "
                        frm.Tabla = cfun.ContaEmpresa & ".requeridopor "
                        frm.FiltroText = "Enter the name of the cost center to filter"
                        frm.Filtro = " req_nombre "
                        frm.Condicion = "req_num >=0"

                        frm.ShowDialog(Me)
                        If frm.DialogResult = DialogResult.OK Then
                            dtDetalle.CurrentRow.Cells("col_IdRequeride").Value = frm.LLave
                            dtDetalle.CurrentRow.Cells("col_Requeride").Value = frm.Dato
                        End If
                    Catch ex As Exception
                        MsgBox(ex.ToString)
                    End Try

                Case 21
                    If celdaSerie.Text = "OCE" Then
                        If celdaResolucion.Text.Length > 4 Then
                            Dim frm As New frmSeleccionar
                            Try
                                frm.Titulo = "Select the Description"
                                frm.Campos = " e.ID code, e.Capítulo, e.Descripcion Description "
                                frm.Tabla = " Exoneracion e  "
                                frm.FiltroText = " Enter the name of the exonerated items to filter"
                                frm.Filtro = " e.Descripcion "
                                If tipoResolucion.Length > 2 Then
                                    frm.Condicion = "e.idEmpresa = " & Sesion.IdEmpresa & " AND Tipo = '" & tipoResolucion & "'"
                                Else
                                    frm.Condicion = "e.idEmpresa = " & Sesion.IdEmpresa
                                End If

                                frm.ShowDialog(Me)

                                If frm.DialogResult = DialogResult.OK Then
                                    dtDetalle.CurrentRow.Cells("colidExoneracion").Value = 0
                                    dtDetalle.CurrentRow.Cells("colExoneracion").Value = ""
                                    dtDetalle.CurrentRow.Cells("colIdRubro").Value = 0
                                    dtDetalle.CurrentRow.Cells("colRubro").Value = ""
                                    dtDetalle.CurrentRow.Cells("colidExoneracion").Value = frm.LLave
                                    dtDetalle.CurrentRow.Cells("colExoneracion").Value = frm.Dato2
                                End If
                            Catch ex As Exception
                                MsgBox(ex.ToString)
                            End Try
                        Else
                            MsgBox("Select resolution", vbInformation)
                            celdaResolucion.Focus()
                        End If
                    End If
                Case 24
                    If celdaSerie.Text = "OCE" Then
                        If dtDetalle.CurrentRow.Cells("colidExoneracion").Value > 0 Then ' Or dtDetalle.CurrentRow.Cells("colidExoneracion").Value <> STR_VACIO Then
                            Dim frm As New frmSeleccionar
                            Try
                                frm.Titulo = "Select the Description"
                                frm.Campos = " e.ID code_, e.Rubro, e.Descripcion Description_,e.Id_Capitulo Chapter_Id, x.Capítulo Chapter,x.Descripcion Name_Chapter, e.Unidad "
                                frm.Tabla = " Exoneracion_Rubro e
                                            RIGHT JOIN Exoneracion x ON x.idEmpresa =e.idEmpresa AND x.ID = e.Id_Capitulo  "
                                frm.FiltroText = " Enter the name of the exonerated items to filter"
                                frm.Filtro = " e.Descripcion "
                                If tipoResolucion.Length > 2 Then
                                    frm.Condicion = "e.idEmpresa = " & Sesion.IdEmpresa & " AND e.Tipo = '" & tipoResolucion & "' AND x.ID = " & dtDetalle.CurrentRow.Cells("colidExoneracion").Value
                                Else
                                    frm.Condicion = "e.idEmpresa = " & Sesion.IdEmpresa & " AND x.ID = " & dtDetalle.CurrentRow.Cells("colidExoneracion").Value
                                End If

                                frm.ShowDialog(Me)
                                If frm.DialogResult = DialogResult.OK Then

                                    dtDetalle.CurrentRow.Cells("colIdRubro").Value = frm.LLave
                                    dtDetalle.CurrentRow.Cells("colRubro").Value = frm.Dato2

                                    If Sesion.IdEmpresa = 15 Or Sesion.IdEmpresa = 20 Or Sesion.IdEmpresa = 22 Then
                                        If LimitePosicionArancelaria(frm.Dato3, frm.LLave) Then
                                            If intTipo = 0 Then
                                                MsgBox("The article has reached the exoneration limit", vbInformation, "Information")
                                            Else
                                                MsgBox("The Service has reached the exoneration limit", vbInformation, "Information")
                                            End If

                                        End If
                                    End If

                                End If
                            Catch ex As Exception
                                MsgBox(ex.ToString)
                            End Try
                        Else
                            MsgBox("Select a chapter", vbInformation)

                        End If

                    End If

                Case 28 ''nomenclatura padre
                    Dim frm As New frmSeleccionar
                    Try
                        frm.Titulo = "Select a account"
                        frm.Campos = " idCuenta Codigo, NombreIngles Nombre "
                        frm.Tabla = cfun.ContaEmpresa & ".nomenclatura "
                        frm.FiltroText = "Enter the name of the cost center to filter"
                        frm.Filtro = " nombreIngles "
                        frm.Condicion = "nivelCta=2"

                        frm.ShowDialog(Me)
                        If frm.DialogResult = DialogResult.OK Then
                            dtDetalle.CurrentRow.Cells("colIdCosto").Value = frm.LLave
                            dtDetalle.CurrentRow.Cells("colCosto").Value = frm.Dato
                            dtDetalle.CurrentRow.Cells("colIdCenterCost").Value = ""
                            dtDetalle.CurrentRow.Cells("colCentroCosto").Value = ""
                        End If
                    Catch ex As Exception
                        MsgBox(ex.ToString)
                    End Try
                Case 30 ''nomenclatura hijo
                    If dtDetalle.CurrentRow.Cells("colIdCosto").Value <> "" Then
                        Dim frm As New frmSeleccionar
                        Try
                            frm.Titulo = "Select a account"
                            frm.Campos = " idCuenta Codigo, NombreIngles Nombre "
                            frm.Tabla = cfun.ContaEmpresa & ".nomenclatura "
                            frm.FiltroText = "Enter the name of the cost center to filter"
                            frm.Filtro = " nombreIngles "
                            frm.Condicion = "pertenencia=" & dtDetalle.CurrentRow.Cells("colIdCosto").Value & " and nivelCta=3"

                            frm.ShowDialog(Me)
                            If frm.DialogResult = DialogResult.OK Then
                                dtDetalle.CurrentRow.Cells("colIdCenterCost").Value = frm.LLave
                                dtDetalle.CurrentRow.Cells("colCentroCosto").Value = frm.Dato
                            End If
                        Catch ex As Exception
                            MsgBox(ex.ToString)
                        End Try
                    End If

                Case 33 ' Cancelar Pedido

                    Try
                        If dtDetalle.SelectedCells(0).Value > 0 Then
                            Dim Opt As New frmOption
                            Dim cancel As String
                            Opt.Titulo = "State"
                            Opt.Mensaje = "Select an Option"
                            Opt.Opciones = "Activo" & "|" & "Canceled (Dispatched)"
                            'Opt.ShowDialog(Me)


                            If Opt.ShowDialog = DialogResult.OK Then
                                Select Case Opt.Seleccion

                                    Case 0
                                        If Opt.Seleccion = 0 Then
                                            cancel = ""
                                            dtDetalle.SelectedCells(33).Value = cancel
                                        End If

                                    Case 1
                                        If Opt.Seleccion = 1 Then
                                            cancel = "SI"
                                            dtDetalle.SelectedCells(33).Value = cancel
                                        End If
                                End Select
                            End If
                        End If
                    Catch ex As Exception
                        MessageBox.Show(ex.ToString)
                    End Try
            End Select
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub
    Private Sub botonMoneda_Click(sender As Object, e As EventArgs) Handles botonMoneda.Click
        Dim frm As New frmSeleccionar
        Try
            frm.Titulo = "Select a Currency"
            frm.Campos = " c.cat_clave Moneda, c.cat_num ID, c.cat_sist "
            frm.Tabla = " Catalogos c "
            frm.FiltroText = " Enter The Name Of The Currency To Filter "
            frm.Filtro = "  c.cat_clave  "
            frm.Condicion = " cat_clase='Monedas' ORDER BY c.cat_clave LIMIT 5"

            frm.ShowDialog(Me)
            If frm.DialogResult = DialogResult.OK Then
                celdaidMoneda.Text = frm.LLave
                celdaMoneda.Text = frm.Dato
                If frm.Dato2 > 1 Then
                    celdaTasa.Text = cFunciones.TasaSegunFecha(dtpFecha.Value.ToString(FORMATO_MYSQL))
                Else
                    celdaTasa.Text = frm.Dato2
                End If
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub
    Private Sub botonSerie_Click(sender As Object, e As EventArgs) Handles botonSerie.Click
        Dim frm As New frmSeleccionar
        Try
            frm.Campos = " cat_sist SEQUENCE "
            frm.Tabla = " Catalogos "
            frm.Condicion = "   cat_clase='Serie' AND cat_clave= 'Doc_COrdenC'  and cat_sisemp = " & Sesion.IdEmpresa
            frm.Filtro = " cat_sist"
            frm.FiltroText = " Enter the serial number to filter. "
            frm.Titulo = " Series "
            frm.ShowDialog(Fprincipal)
            If frm.DialogResult = DialogResult.OK Then
                celdaSerie.Text = frm.LLave
                If celdaSerie.Text = "OCE" Or celdaSerie.Text = "OEA" Then
                    dtDetalle.Columns("colUM").Visible = True
                    dtDetalle.Columns("colCantidadRecibida").Visible = False
                Else
                    dtDetalle.Columns("colUM").Visible = False
                    dtDetalle.Columns("colCantidadRecibida").Visible = False
                End If

                If Sesion.idGiro = 2 Then
                    celdaNumeroSerie.ReadOnly = False
                    If celdaSerie.Text = "OCE" Then
                        Label12.Visible = True
                        celdaResolucion.Visible = True
                        botonResolción.Visible = True
                        dtDetalle.Columns("colExoneracion").Visible = True
                        dtDetalle.Columns("colRubro").Visible = True

                    Else
                        Label12.Visible = False
                        celdaResolucion.Visible = False
                        botonResolción.Visible = False
                        dtDetalle.Columns("colExoneracion").Visible = False
                        dtDetalle.Columns("colRubro").Visible = False
                    End If
                End If
            End If

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub
    Private Sub dgLista_KeyDown(sender As Object, e As KeyEventArgs) Handles dgLista.KeyDown
        Try
            If e.KeyCode = Keys.F3 Then
                cfun.BuscarenLista(dgLista)
                e.Handled = True
                e.SuppressKeyPress = True
            ElseIf e.KeyCode = Keys.F6 Then
                cfun.MostrarDependencias(777, dgLista.SelectedCells(1).Value, dgLista.SelectedCells(0).Value)
            ElseIf e.KeyCode = Keys.F7 Then
                Dim rpt As New clsReportes
                rpt.Historial(dgLista.SelectedCells(0).Value, dgLista.SelectedCells(1).Value, 777)

            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub botonFiltrar_Click(sender As Object, e As EventArgs) Handles botonFiltrar.Click
        CargarLista()
    End Sub

    Private Sub dtpFecha_ValueChanged(sender As Object, e As EventArgs) Handles dtpFecha.ValueChanged
        If celdaTasa.Text > 1 Then
            celdaTasa.Text = cFunciones.TasaSegunFecha(dtpFecha.Value.ToString(FORMATO_MYSQL))
        End If
    End Sub

    Private Sub botonResolción_Click(sender As Object, e As EventArgs) Handles botonResolción.Click
        Dim frm As New frmSeleccionar
        Dim strCondicion As String = STR_VACIO

        Try
            frm.Titulo = "Regsiter"
            frm.Campos = " c.cat_num id, c.cat_desc tipo, c.cat_sist Numero "
            frm.Tabla = " Catalogos c "
            frm.FiltroText = " Enter the Resolution Name"
            'frm.Filtro = " pro_proveedor "
            frm.Condicion = " c.cat_clase = 'Serie' AND c.cat_clave = 'Doc_Resolucion' AND c.cat_pid = 0"
            'frm.Limite = 10
            frm.ShowDialog(Me)
            If frm.DialogResult = DialogResult.OK Then
                celdaIdResolución.Text = frm.LLave
                celdaResolucion.Text = frm.Dato2
                tipoResolucion = frm.Dato
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub checkFechaAprobacion_CheckedChanged(sender As Object, e As EventArgs) Handles checkFechaAprobacion.CheckedChanged

        If checkFechaAprobacion.Checked = True Then
            panelApprovalDate.Visible = True
        Else
            panelApprovalDate.Visible = False
        End If

    End Sub

    Private Sub celdaTexto1_TextChanged(sender As Object, e As EventArgs) Handles celdaTexto1.TextChanged
        Dim valor1 As Double = INT_CERO
        Dim valor2 As Double = INT_CERO
        Dim total As Double = INT_CERO

        If celdaTexto1.Text <> STR_VACIO Then

            If dtDetalle.RowCount > 0 Then
                CalcularTotal()
                CalcularDescuento()
                celdaTotal.Text = celdaTexto3.Text
            End If

        End If
    End Sub

    Private Sub celdaTexto2_TextChanged(sender As Object, e As EventArgs) Handles celdaTexto2.TextChanged
        Dim valor1 As Double = INT_CERO
        Dim valor2 As Double = INT_CERO
        Dim total As Double = INT_CERO

        If celdaTexto2.Text <> STR_VACIO Then

            If dtDetalle.RowCount > 0 Then
                CalcularTotal()
                CalcularDescuento()
                celdaTotal.Text = celdaTexto3.Text
            End If

        End If
    End Sub

    Private Sub botonQuitar_ChangeUICues(sender As Object, e As UICuesEventArgs) Handles botonQuitar.ChangeUICues

    End Sub

    Private Sub panelProveedor_Paint(sender As Object, e As PaintEventArgs) Handles panelProveedor.Paint
        If Sesion.idGiro = 1 Then
            Label10.Text = "Description"
        Else
            Label10.Text = "Observaciones"
        End If
    End Sub

    Private Sub txtTEXT4_TextChanged(sender As Object, e As EventArgs) Handles txtTEXT4.TextChanged

    End Sub
End Class
