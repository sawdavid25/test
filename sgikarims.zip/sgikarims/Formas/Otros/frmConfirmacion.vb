﻿Public Class frmConfirmacion
#Region "Miembros"
    Dim strKey As String = STR_VACIO
    Dim logInsertar As Boolean = False
    Dim logConsultar As Boolean = False
    Dim logEditar As Boolean = False
    Dim LogBorrar As Boolean = False
    Dim intTipoIngreso As Integer = NO_FILA


    Const CAT_ORD As Integer = 127
    Dim cfun As New clsFunciones
    Dim intCurDoc As Integer

    Dim strFabricante As String
    Dim intclase As Integer
    Dim strRef As String, strMedida As String
    Private Const DOC_NAME As String = "Doc_CPedido"
    Dim Re As New frmRequisiciones
    Dim insert As Boolean = True

    Private dblDocCantidad As Double
    Private dblDocTotal As Double
    Public logAceptado As Boolean

    Dim intControl As Integer = 0
    Dim intTipoDoc As Integer = 0

    'Cantidad de decimales
    Private Const PRO_NAME As String = "Doc_POrd/Com"      'Orden de importación
#End Region
#Region "Propiedades"

    Public Property Key As String
        Get
            Return strKey
        End Get
        Set(value As String)
            strKey = value
        End Set
    End Property

    Public Property Aceptado As Boolean
        Get
            Return logAceptado
        End Get
        Set(value As Boolean)
            logAceptado = value
        End Set
    End Property


#End Region
#Region "Funciones y Procedimientos Locales"

    Private Sub PintarTipoIngreso()

        Select Case celdaTipoIngreso.Text
            Case 0
                celdaTipoIng.Text = "IMPORT"
                celdaTipoIng.BackColor = Color.LightYellow
                celdaTipoIng.ForeColor = Color.Black
            Case 1
                celdaTipoIng.Text = "PACKING"
                celdaTipoIng.BackColor = Color.DarkBlue
                celdaTipoIng.ForeColor = Color.White
            Case 2
                celdaTipoIng.Text = "WASTE"
                celdaTipoIng.BackColor = Color.Purple
                celdaTipoIng.ForeColor = Color.White
        End Select

    End Sub

    Private Sub BloquearBotones(Optional ByVal logBloquear As Boolean = True)
        If logBloquear = True Then
            Encabezado1.botonBorrar.Enabled = False
            Encabezado1.botonGuardar.Enabled = False
            botonInprimir.Enabled = False
            botonAgrega.Enabled = True
        Else
            Encabezado1.botonBorrar.Enabled = True
            Encabezado1.botonGuardar.Enabled = True
            botonInprimir.Enabled = True
            botonQuitar.Enabled = True
        End If

    End Sub

    'Private Function ComprobarDatos() As Boolean
    '    Dim logCoprobar As Boolean = True
    '    Dim i As Integer = 0
    '    If cfun.ValidarCampoTexto(CeldaCliente) = False Then
    '        logCoprobar = False
    '    End If
    '    If cfun.ValidarCampoTexto(CeldaDireccion) = False Then
    '        logCoprobar = False
    '    End If
    '    If cfun.ValidarCampoTexto(CeldaCosteo) = False Then
    '        logCoprobar = False
    '    End If
    '    If dgDetalle.Rows.Count <= 0 Then
    '        logCoprobar = False
    '    End If
    '    For i = 0 To dgDetalle.Rows.Count - 1
    '        If dgDetalle.Rows(i).Cells("colEstado").Value = "Sold" Then
    '            If (dgDetalle.Rows(i).Cells("colIdVendido").Value = INT_CERO) Then
    '                MsgBox("Blank sold to")
    '                logCoprobar = False
    '            End If

    '        End If
    '    Next
    '    Return logCoprobar
    'End Function

    Private Sub Accessos()
        Dim cAccesos As New clsAccesos
        Dim strSQl As String
        Dim COM As MySqlCommand
        Try
            If cAccesos.Accesos(strKey) = True Then
                logInsertar = cAccesos.Insertar
                logConsultar = cAccesos.Consultar
                logEditar = cAccesos.Editar
                LogBorrar = cAccesos.Borrar

                strSQl = "select ifnull(pms_nivel, -1) permiso "
                strSQl &= " from Permisos p  "
                strSQl &= " where p.pms_empresa = {empresa} and p.pms_modulo = 15 and p.pms_usuario = '{usuario}' "

                strSQl = Replace(strSQl, "{empresa}", Sesion.IdEmpresa)
                strSQl = Replace(strSQl, "{usuario}", Sesion.Usuario)
                MyCnn.CONECTAR = strConexion
                COM = New MySqlCommand(strSQl, CON)
                intTipoIngreso = COM.ExecuteScalar

            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub Reset()


        CeldaAño.Text = NO_FILA
        CeldaNumero.Text = NO_FILA
        CeldaCliente.Text = STR_VACIO
        CeldaDireccion.Text = STR_VACIO
        celdaIDProveedores.Text = NO_FILA
        lblIDMoneda.Text = 178
        CeldaMoneda.Text = "USD$"
        CeldaTasa.Text = cfun.QueryTasa
        CeldaCantidad.Text = INT_CERO.ToString(FORMATO_MONEDA)
        CeldaTotal.Text = INT_CERO.ToString(FORMATO_MONEDA)
        celdaReferencia.Text = STR_VACIO
        CeldaReferencia1.Text = STR_VACIO
        CeldaReferencia2.Text = STR_VACIO
        celdaFlete.Text = INT_CERO.ToString(FORMATO_MONEDA)
        celdaSeguro.Text = INT_CERO.ToString(FORMATO_MONEDA)
        CeldaCosteo.Text = STR_VACIO
        celdaEmpresa.Text = NO_FILA
        celdaCatalogo.Text = NO_FILA
        celdaUsuario.Text = NO_FILA
        dtpEncabezado.Value = Now()
        botonQuitar.Enabled = True
        botonAgrega.Enabled = True
        dgDetalle.Rows.Clear()
        dgDocumentos.Rows.Clear()
        dgInfoDescargo.Rows.Clear()
    End Sub


    Public Sub VerificarDcmtosIngreso(ByVal intAnio As Integer, ByVal intNum As Integer)
        Dim strSQL As String = STR_VACIO
        Dim COM As MySqlCommand
        Dim intcuentaDTL_Pro As Integer = 0

        strSQL = " SELECT COUNT(d.PDoc_Chi_Num) "
        strSQL &= "    From Dcmtos_DTL_Pro p "
        strSQL &= "       LEFT JOIN Dcmtos_DTL_Pro d ON d.PDoc_Sis_Emp = p.PDoc_Sis_Emp AND d.PDoc_Par_Cat = p.PDoc_Chi_Cat AND d.PDoc_Par_Ano = p.PDoc_Chi_Ano AND d.PDoc_Par_Num = p.PDoc_Chi_Num AND d.PDoc_Par_Lin = p.PDoc_Chi_Lin "
        strSQL &= "            WHERE p.PDoc_Sis_Emp = {empresa} AND p.PDoc_Par_Cat = 127 AND p.PDoc_Par_Ano = {anio} AND p.PDoc_Par_Num = {numero} AND p.PDoc_Chi_Cat = 55 "

        strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
        strSQL = Replace(strSQL, "{anio}", intAnio)
        strSQL = Replace(strSQL, "{numero}", intNum)

        MyCnn.CONECTAR = strConexion
        COM = New MySqlCommand(strSQL, CON)
        intcuentaDTL_Pro = COM.ExecuteScalar

        If intcuentaDTL_Pro > 0 Then
            botonGenerarIngreso.Enabled = False
        Else
            botonGenerarIngreso.Enabled = True
        End If

    End Sub

    Private Function SQListaDocumentos(ByVal intaño As Integer, ByVal intID As Integer, ByVal cat As Integer) As String
        Dim strsql As String = STR_VACIO
        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader
        Dim CON As MySqlConnection
        Dim j As Integer = 0
        Dim intNumPol As Integer = VerificarChiNumDeConfirmacion()
        Dim intAnioPol As Integer = VerificarChiAnioDeConfirmacion()
        dgDocumentos.Rows.Clear()

        For j = 0 To 1
            strsql = "SELECT cat_clave, cat_desc, IF(("
            strsql &= "  SELECT COUNT(*) "
            strsql &= "    FROM Dcmtos_ACC"
            strsql &= "       WHERE ADoc_Sis_Emp = {empresa} AND ADoc_Doc_Cat = {cat}  AND ADoc_Doc_Ano = {año} AND ADoc_Doc_Num ={numero} AND ADoc_Doc_Sub = cat_clave) >0,'SI','NO') Cantidad"
            strsql &= "     FROM Catalogos"
            strsql &= "   WHERE cat_clase = 'SubDcmtos' AND cat_sist = '{doc}' AND (cat_sisemp IN (0,12))"
            strsql &= " ORDER BY cat_clave"


            strsql = Replace(strsql, "{empresa}", Sesion.IdEmpresa)
            If j = 0 Then
                strsql = Replace(strsql, "{año}", intaño)
                strsql = Replace(strsql, "{numero}", intID)
                strsql = Replace(strsql, "{cat}", 127)
                strsql = Replace(strsql, "{doc}", "Doc_SPolImp")
            ElseIf j = 1 Then
                strsql = Replace(strsql, "{año}", intAnioPol)
                strsql = Replace(strsql, "{numero}", intNumPol)
                strsql = Replace(strsql, "{cat}", 55)
                strsql = Replace(strsql, "{doc}", "Doc_PolImp")
            End If

            CON = New MySqlConnection(strConexion)

            CON.Open()

            Try
                COM = New MySqlCommand(strsql, CON)
                REA = COM.ExecuteReader

                If REA.HasRows Then

                    While REA.Read
                        Dim strFila As String = STR_VACIO

                        strFila = REA.GetString("cat_clave") & "|" & REA.GetString("cat_desc") & "|" & REA.GetString("Cantidad")

                        cfun.AgregarFila(dgDocumentos, strFila)

                    End While

                End If

            Catch ex As Exception
                MsgBox(ex.ToString)
            End Try
        Next

        CON.Close()

        Return strsql
    End Function

    Private Function SQLlista() As String
        Dim strSQL As String = STR_VACIO
        Dim strTemp As String = STR_VACIO
        strSQL = " SELECT HDoc_Doc_Num Number, HDoc_Doc_Fec Date, HDoc_Emp_Nom Name, HDoc_Emp_Per Contact, COALESCE(HDoc_DR1_Num,'') Reference, HDoc_Doc_Ano Year"

        If rbtTransito.Checked = True Then

            strSQL &= " ,IFNULL( ( "
            strSQL &= " SELECT  if( pp.PDoc_Sis_Emp IS NULL , 'Transito', 'Bodega'   ) estado FROM Dcmtos_DTL_Pro pd "
            strSQL &= " LEFT JOIN Dcmtos_DTL_Pro pp ON pp.PDoc_Sis_Emp =pd.PDoc_Sis_Emp AND pp.PDoc_Par_Cat = pd.PDoc_Chi_Cat AND pp.PDoc_Par_Ano = pd.PDoc_Chi_Ano  "
            strSQL &= " AND pp.PDoc_Par_Num = pd.PDoc_Chi_Num AND pp.PDoc_Par_Lin = pd.PDoc_Chi_Lin "
            strSQL &= " WHERE pd.PDoc_Sis_Emp = e.HDoc_Sis_Emp AND pd.PDoc_Par_Cat = e.HDoc_Doc_Cat AND pd.PDoc_Par_Ano = e.HDoc_Doc_Ano AND pd.PDoc_Par_Num = e.HDoc_Doc_Num "
            strSQL &= " GROUP BY pd.PDoc_Sis_Emp , pd.PDoc_Par_Cat ,pd.PDoc_Par_Ano , pd.PDoc_Par_Num  "
            strSQL &= " ) , 'Transito') Estado "

        End If

        strSQL &= " FROM Dcmtos_HDR e"
        strSQL &= " WHERE e.HDoc_Sis_Emp={empresa} AND e.HDoc_Doc_Cat={tipo} {criterio}  {hsm}"

        If rbtTransito.Checked = True Then

            strSQL &= " HAVING Estado = 'Transito' "

        End If
        strSQL &= " ORDER BY e.HDoc_Doc_Ano DESC, e.HDoc_Doc_Num DESC; "

        strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
        strSQL = Replace(strSQL, "{tipo}", CAT_ORD)
        If (Sesion.IdEmpresa = 15) Or (Sesion.IdEmpresa = 18) Or (Sesion.IdEmpresa = 19) Then 'hsm
            'If intTipoIngreso > NO_FILA Then
            'strSQL = Replace(strSQL, "{hsm}", " and HDoc_Ant_Com = " & intTipoIngreso)
            'Else
            strSQL = Replace(strSQL, "{hsm}", STR_VACIO)
                'End If
                Else
            strSQL = Replace(strSQL, "{hsm}", STR_VACIO)
        End If

        If (chkFecha.Checked = False) Then
            strSQL = Replace(strSQL, "{criterio}", vbNullString)
        Else
            strTemp = "AND (HDoc_Doc_Fec BETWEEN '{inicio}' AND '{fin}')"
            strTemp = Replace(strTemp, "{inicio}", dtpInicio.Value.ToString(FORMATO_MYSQL))
            strTemp = Replace(strTemp, "{fin}", dtpFin.Value.ToString(FORMATO_MYSQL))
            strSQL = Replace(strSQL, "{criterio}", strTemp)
        End If

        Return strSQL
    End Function

    Private Sub MostrarLista(Optional logMostrar As Boolean = True, Optional ByVal logInsert As Boolean = False)
        Dim cfun As New clsFunciones
        If logMostrar = True Then
            'ocultar panel de documento
            panelDocumento.Dock = DockStyle.None
            panelDocumento.Visible = False
            'actualizar Titulo
            BarraTitulo1.CambiarTitulo("Document List")
            'Cargar Datos
            cfun.CargarLista(dgLista, SQLlista, False)
            'Mostrar Panel Filtro
            panelLista.Visible = True
            panelLista.Dock = DockStyle.Fill
            BloquearBotones()
            'Me.Tag = ""
        Else
            'Ocultar Panel Filtro
            panelLista.Visible = False
            panelLista.Dock = DockStyle.None
            'Mostrar panel de documento
            panelDocumento.Dock = DockStyle.Fill
            panelDocumento.Visible = True
            'Verifica si se va a crear un nuevo documento o se va modifica
            If logInsert = False Then
                BarraTitulo1.CambiarTitulo("Update Document")
                Me.Tag = "Mod"
                botonGastos.Enabled = True
                BloquearBotones(False)
                botonInprimir.Enabled = True
                botonQuitar.Enabled = True
                botonAgrega.Enabled = True
                'botonCliente.Enabled = False
                botonMoneda.Enabled = True
                botonCosteo.Enabled = True
            Else
                BarraTitulo1.CambiarTitulo("New Document")
                Me.Tag = "nuevo"
                BloquearBotones(False)
                botonInprimir.Enabled = False
                'botonCliente.Enabled = True
                botonMoneda.Enabled = True
                botonCosteo.Enabled = True
                Reset()
            End If

            dgLista.DataSource = Nothing
        End If
    End Sub

    Private Function sqlEncabezado(ByVal intNum As Integer, ByVal intAño As String) As String
        Dim strSQL As String = STR_VACIO
        Dim chdr As New clsDcmtos_HDR
        Dim REA As MySqlDataReader
        Dim COM As MySqlCommand

        strSQL = "  SELECT *"
        strSQL &= "     FROM Dcmtos_HDR"
        strSQL &= "         LEFT JOIN Proveedores ON pro_codigo = HDoc_Emp_Cod AND pro_sisemp = {empresa}"
        strSQL &= "     INNER JOIN Catalogos ON pro_moneda = cat_num"
        strSQL &= " WHERE HDoc_Doc_Cat = {catalogo} AND HDoc_Sis_Emp = {empresa} AND HDoc_Doc_Num = {numero} AND HDoc_Doc_Ano = {año}"

        strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
        strSQL = Replace(strSQL, "{catalogo}", 127)
        strSQL = Replace(strSQL, "{año}", intAño)
        strSQL = Replace(strSQL, "{numero}", intNum)

        Try
            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSQL, CON)
            REA = COM.ExecuteReader
            If REA.HasRows Then
                Do While REA.Read
                    CeldaAño.Text = REA.GetInt32("HDOC_DOC_ANO")
                    CeldaNumero.Text = REA.GetInt32("HDOC_DOC_NUM")
                    CeldaCliente.Text = REA.GetString("HDOC_EMP_NOM")
                    celdaIDProveedores.Text = REA.GetInt32("HDOC_EMP_COD")
                    dtpEncabezado.Value = REA.GetDateTime("HDOC_DOC_FEC").ToString(FORMATO_MYSQL)
                    celdaReferencia.Text = REA.GetString("HDOC_DR1_Num")
                    CeldaReferencia1.Text = REA.GetString("HDOC_DR2_NUM")
                    CeldaReferencia2.Text = REA.GetString("HDOC_RF2_TXT")
                    CeldaCosteo.Text = REA.GetString("HDOC_RF1_TXT")
                    CeldaTasa.Text = REA.GetDouble("HDOC_DOC_TC")
                    lblIDMoneda.Text = REA.GetInt32("HDOC_DOC_MON")
                    CeldaMoneda.Text = REA.GetString("cat_clave")
                    CeldaDireccion.Text = REA.GetString("HDOC_EMP_DIR")
                    celdaFlete.Text = REA.GetDouble("HDOC_RF1_DBL").ToString(FORMATO_MONEDA)
                    celdaSeguro.Text = REA.GetDouble("HDOC_RF2_DBL").ToString(FORMATO_MONEDA)
                    checkActivo.Checked = REA.GetInt32("HDOC_DOC_STATUS")
                    celdaTipoIngreso.Text = REA.GetInt32("HDoc_Ant_Com").ToString
                    intTipoDoc = REA.GetInt16("HDoc_DR1_Cat")
                Loop
                PintarTipoIngreso()
            End If
        Catch ex As Exception

        End Try
        Return strSQL
    End Function

    Private Sub SelecionarEncabezado(ByVal intAño As Integer, ByVal intNum As Integer)
        Dim chdr As New clsDcmtos_HDR
        Dim ca As New clsCatalogos
        'Dim pro As New clsProveedores
        Dim strCampos As String = STR_VACIO
        Dim strCondicion As String = STR_VACIO

        strCampos = " HDoc_Doc_Ano, HDoc_Doc_Num, HDoc_Emp_Cod, HDoc_Emp_Nom, HDoc_Emp_Dir, HDoc_DR1_Num, HDoc_RF1_Txt, HDoc_Doc_TC, HDoc_Doc_Mon, HDoc_Doc_Status"
        strCampos &= ", HDoc_RF1_Dbl, HDoc_RF2_Dbl, HDoc_DR2_Num, HDoc_RF2_Txt, HDoc_Doc_Fec"
        strCondicion = " HDoc_Sis_Emp = {empresa} and  HDoc_Doc_Cat = {catalogo} and HDoc_Doc_Ano  = {ano} and HDoc_Doc_Num = {numero}"
        strCondicion = Replace(strCondicion, "{empresa}", Sesion.IdEmpresa)
        strCondicion = Replace(strCondicion, "{catalogo}", CAT_ORD)
        strCondicion = Replace(strCondicion, "{ano}", intAño)
        strCondicion = Replace(strCondicion, "{numero}", intNum)

        Try
            chdr.CONEXION = strConexion
            If chdr.Seleccionar(strCondicion, strCampos) Then
                CeldaAño.Text = chdr.HDOC_DOC_ANO
                CeldaNumero.Text = chdr.HDOC_DOC_NUM
                CeldaCliente.Text = chdr.HDOC_EMP_NOM
                celdaIDProveedores.Text = chdr.HDOC_EMP_COD
                celdaReferencia.Text = chdr.HDOC_DR1_NUM
                CeldaReferencia1.Text = chdr.HDOC_DR2_NUM
                CeldaReferencia2.Text = chdr.HDOC_RF2_TXT
                CeldaCosteo.Text = chdr.HDOC_RF1_TXT
                CeldaTasa.Text = chdr.HDOC_DOC_TC
                lblIDMoneda.Text = chdr.HDOC_DOC_MON
                CeldaDireccion.Text = chdr.HDOC_EMP_DIR
                celdaFlete.Text = chdr.HDOC_RF1_DBL.ToString(FORMATO_MONEDA)
                celdaSeguro.Text = chdr.HDOC_RF2_DBL.ToString(FORMATO_MONEDA)
                checkActivo.Checked = chdr.HDOC_DOC_STATUS
                dtpEncabezado.Value = chdr.HDOC_DOC_FEC


            Else
                MsgBox(chdr.MERROR.ToString)
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        Finally
            chdr.Dispose()
            chdr = Nothing
        End Try
    End Sub

    Private Sub SeleccionarDetalle(ByVal intAño As Integer, ByVal intNum As Integer)
        Dim strSQl As String = STR_VACIO
        Dim REA As MySqlDataReader
        Dim COM As MySqlCommand
        Dim strFIla As String = STR_VACIO
        strSQl &= " select d.DDoc_Prd_Cod  cod, d.DDoc_Prd_Des descripcion , d.DDoc_Prd_UM idmedida , c.cat_clave  medida, d.DDoc_Prd_NET precio , d.DDoc_Prd_QTY  cantidad, (d.DDoc_Prd_NET * d.DDoc_Prd_QTY) total,  d.DDoc_RF1_Cod job"
        strSQl &= " from Dcmtos_DTL d "
        strSQl &= " left join Catalogos c on c.cat_num = d.DDoc_Prd_UM  "
        strSQl &= " where d.DDoc_Sis_Emp = {empresa} and d.DDoc_Doc_Cat = {catalogo} and d.DDoc_Doc_Ano = {ano} and d.DDoc_Doc_Num = {numero} "

        strSQl = Replace(strSQl, "{empresa}", Sesion.IdEmpresa)
        strSQl = Replace(strSQl, "{catalogo}", CAT_ORD)
        strSQl = Replace(strSQl, "{ano}", intAño)
        strSQl = Replace(strSQl, "{numero}", intNum)
        Try
            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSQl, CON)
            REA = COM.ExecuteReader
            If REA.HasRows Then
                Do While REA.Read
                    strFIla = STR_VACIO
                    strFIla &= REA.GetInt32("cod") & "|"
                    strFIla &= REA.GetString("descripcion") & "| "
                    strFIla &= REA.GetInt32("idmedida") & "|"
                    strFIla &= REA.GetString("medida") & "|"
                    strFIla &= REA.GetDouble("precio") & "|"
                    strFIla &= REA.GetDouble("cantidad") & "|"
                    strFIla &= REA.GetDouble("total") & "|"
                    strFIla &= REA.GetString("job") & "|"
                    strFIla &= "0"

                    cfun.AgregarFila(dgDetalle, strFIla)

                Loop
            End If

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Function sqlListaDescargos(ByVal ano As Integer, ByVal numero As Integer) As String
        Dim strSQL As String = STR_VACIO

        strSQL = "SELECT p.PDoc_Par_Cat, p.PDoc_Par_Ano, p.PDoc_Par_Num, p.PDoc_Par_Lin, p.PDoc_Chi_Lin, p.PDoc_QTY_Pro, d.DDoc_Prd_Cod, d.DDoc_Prd_UM"
        strSQL &= " FROM Dcmtos_DTL_Pro p"
        strSQL &= "    INNER JOIN Dcmtos_DTL d ON d.DDoc_Sis_Emp = p.PDoc_Sis_Emp AND d.DDoc_Doc_Cat = p.PDoc_Par_Cat AND d.DDoc_Doc_Ano = p.PDoc_Par_Ano AND d.DDoc_Doc_Num = p.PDoc_Par_Num AND d.DDoc_Doc_Lin = p.PDoc_Par_Lin"
        strSQL &= "        WHERE p.PDoc_Sis_Emp = {empresa} AND p.PDoc_Chi_Cat = 127 AND p.PDoc_Chi_Ano = {ano} AND p.PDoc_Chi_Num = {numero} AND p.PDoc_Par_Cat = 38"
        strSQL &= "    ORDER BY p.PDoc_Chi_Lin, PDoc_Par_Lin"

        strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
        strSQL = Replace(strSQL, "{ano}", ano)
        strSQL = Replace(strSQL, "{numero}", numero)

        Return strSQL
    End Function

    Public Sub CargarListaDescargo(ByVal año As Integer, ByVal numero As Integer)

        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader
        Dim strSQL As String = STR_VACIO

        strSQL = sqlListaDescargos(año, numero)

        Try

            MyCnn.CONECTAR = strConexion

            COM = New MySqlCommand(strSQL, CON)
            REA = COM.ExecuteReader
            dgInfoDescargo.Rows.Clear()
            If REA.HasRows Then


                Do While REA.Read
                    Dim strTemp As String = STR_VACIO

                    strTemp &= REA.GetInt32("PDoc_Chi_Lin") & "|"
                    strTemp &= REA.GetInt32("PDoc_Par_Cat") & "|"
                    strTemp &= REA.GetInt32("PDoc_Par_Ano") & "|"
                    strTemp &= REA.GetInt32("PDoc_Par_Num") & "|"
                    strTemp &= REA.GetInt32("PDoc_Par_Lin") & "|"
                    strTemp &= REA.GetInt32("DDoc_Prd_Cod") & "|"
                    strTemp &= REA.GetDouble("DDoc_Prd_UM") & "|"
                    strTemp &= vbEmpty & "|"
                    strTemp &= REA.GetDouble("PDoc_QTY_Pro").ToString(FORMATO_MONEDA) & "|"
                    strTemp &= REA.GetDouble("PDoc_QTY_Pro").ToString(FORMATO_MONEDA) & "|"
                    strTemp &= INT_UNO

                    cfun.AgregarFila(dgInfoDescargo, strTemp)

                Loop

            End If

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try

    End Sub

    Public Function InfoProducto(ByVal año As Integer, ByVal numero As Integer)
        Dim strSQL As String
        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader
        Dim CON As MySqlConnection
        Dim i As Integer = 0
        'If dgLista.Rows.Count = 0 Then
        '    Return strSQL
        '    Exit Function
        'End If

        strSQL = "SELECT ifnull(DDoc_RF3_Num,0)DDoc_RF3_Num, DDoc_Doc_Ano, DDOc_Prd_Cod, DDoc_Doc_Lin, DDOc_Prd_Cod, DDoc_Prd_Des, DDoc_Prd_UM, c.cat_clave, DDoc_Prd_PUQ, DDoc_Prd_QTY, ROUND(DDoc_RF1_Dbl,2) total, DDoc_RF1_Cod, inv_numero, IF(DDoc_RF1_Num = 0 OR DDoc_RF1_Num IS NULL, 'Unsold', 'Sold') DDoc_RF1_Num, IFNULL(DDoc_RF2_Cod,'') DDoc_RF2_Cod, (DDoc_Prd_NET * DDoc_Prd_Qty) Lin_Subtotal,IFNULL(cc.cat_num,0) CodigoNaviera,IFNULL(cc.cat_desc,'') Naviera, IFNULL(d.DDoc_RF1_Fec,'') Fecha"
        strSQL &= "  FROM Dcmtos_DTL d"
        strSQL &= "      LEFT JOIN Catalogos c ON c.cat_num = DDoc_Prd_UM AND c.cat_clase = 'Medidas'"
        strSQL &= "          LEFT JOIN Inventarios ON inv_numero = DDoc_Prd_Cod AND inv_sisemp = {empresa}"
        strSQL &= "             LEFT JOIN Catalogos cc ON cc.cat_num = d.DDoc_Rf2_Dbl AND cc.cat_clase='Naviera' "
        strSQL &= "      WHERE DDoc_Doc_Cat = 127 AND DDoc_Sis_Emp = {empresa} AND DDoc_Doc_Ano = {año} AND DDoc_Doc_Num = {numero}"
        strSQL &= "  ORDER BY DDoc_Doc_Lin"


        strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
        strSQL = Replace(strSQL, "{año}", año)
        strSQL = Replace(strSQL, "{numero}", numero)

        CON = New MySqlConnection(strConexion)

        CON.Open()

        Try
            COM = New MySqlCommand(strSQL, CON)
            REA = COM.ExecuteReader

            If REA.HasRows Then

                dgDetalle.Rows.Clear()

                While REA.Read
                    Dim strFila As String = STR_VACIO
                    i = i + 1
                    strFila = STR_VACIO
                    strFila = REA.GetInt32("DDoc_Doc_Ano") & "|"
                    strFila &= REA.GetInt32("DDOc_Prd_Cod") & "|"
                    strFila &= REA.GetInt32("DDoc_Doc_Lin") & "|"
                    strFila &= REA.GetInt32("DDOc_Prd_Cod") & "|"
                    strFila &= REA.GetString("DDoc_Prd_Des") & "| "
                    strFila &= REA.GetInt32("DDoc_Prd_UM") & "|"
                    strFila &= REA.GetString("cat_clave") & "|"
                    strFila &= REA.GetDouble("DDoc_Prd_PUQ").ToString & "|"
                    strFila &= REA.GetDouble("DDoc_Prd_QTY").ToString & "|"
                    strFila &= REA.GetDouble("total").ToString & "|"
                    strFila &= REA.GetString("DDoc_RF1_Cod") & "|"
                    strFila &= REA.GetInt32("inv_numero") & "|"
                    strFila &= "" & "|"
                    strFila &= REA.GetInt32("DDoc_Doc_Lin") & "|"
                    strFila &= REA.GetString("DDoc_RF1_Num") & "|"
                    strFila &= REA.GetString("DDoc_RF2_Cod") & "|"
                    strFila &= REA.GetString("Naviera") & "|"
                    strFila &= REA.GetInt32("CodigoNaviera") & "|"
                    strFila &= REA.GetString("Fecha") & "|"
                    strFila &= "0" & "|"
                    strFila &= REA.GetInt32("DDoc_RF3_Num")


                    cfun.AgregarFila(dgDetalle, strFila)

                End While

            End If
            For j As Integer = 0 To dgDetalle.Rows.Count - 1
                dgDetalle.Rows(j).Cells("colDescripcion").Style.BackColor = Color.Beige
                dgDetalle.Rows(j).Cells("colMedida").Style.BackColor = Color.Beige
                dgDetalle.Rows(j).Cells("colTotal").Style.BackColor = Color.Beige
            Next

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try

        CON.Close()

        Return strSQL
    End Function

    'procedimiento que cargar SubDocumentos
    Public Sub SeleccionarSubdocumentos(ByVal intAño As Integer, ByVal intID As Integer, ByVal cat As Integer)
        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader
        Dim strSQL As String = STR_VACIO

        strSQL = SQListaDocumentos(intAño, intID, cat)

        Try

            MyCnn.CONECTAR = strConexion

            COM = New MySqlCommand(strSQL, CON)
            REA = COM.ExecuteReader

            If REA.HasRows Then

                dgDocumentos.Rows.Clear()

                Do While REA.Read
                    Dim strFila As String = STR_VACIO

                    strFila = REA.GetString("cat_clave") & "|" & REA.GetString("cat_desc") & "|" & REA.GetString("Cantidad")

                    cFunciones.AgregarFila(dgDocumentos, strFila)
                Loop

            End If

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try

    End Sub

    Private Sub CalcularTotales()

        dblDocCantidad = vbEmpty
        dblDocTotal = vbEmpty

        For i As Integer = 0 To dgDetalle.Rows.Count - 1
            If Not dgDetalle.Rows(i).Cells("colOperacion").Value = 2 Then
                dblDocTotal = dblDocTotal + dgDetalle.Rows(i).Cells("colTotal").Value
                dblDocCantidad = dblDocCantidad + dgDetalle.Rows(i).Cells("colCantidad").Value
            End If
        Next
        CeldaCantidad.Text = dblDocCantidad.ToString(FORMATO_MONEDA)
        CeldaTotal.Text = dblDocTotal.ToString(FORMATO_MONEDA)
    End Sub

    Private Function ComprobarFilas(Index As Integer)
        ComprobarFilas = True
        Try
            For i As Integer = 0 To dgDetalle.Rows.Count - 1
                If CStr(dgDetalle.Rows(i).Cells("colAño").Value) = STR_VACIO Then
                    ComprobarFilas = False
                End If
                If CStr(dgDetalle.Rows(i).Cells("colCodProducto").Value) = STR_VACIO Then
                    MsgBox("Fila " & i + 1 & ": Invalid Item Code")
                    ComprobarFilas = False
                End If
                If CStr(dgDetalle.Rows(i).Cells("colDescripcion").Value) = STR_VACIO Then
                    MsgBox("Fila " & i + 1 & ": White Item Descripcion")
                    ComprobarFilas = False
                End If
                If CStr(dgDetalle.Rows(i).Cells("colPrecio").Value) = STR_VACIO Then
                    MsgBox("Fila " & i + 1 & ": Zero Article Price")
                    ComprobarFilas = False
                End If
                If CStr(dgDetalle.Rows(i).Cells("colCantidad").Value) = STR_VACIO Then
                    MsgBox("Fila " & i + 1 & ": Article Quantity in Zero." & vbCr & vbCr & "¿Leave row with amount zero?", vbExclamation + vbYesNo + vbDefaultButton2, "Notice")
                    ComprobarFilas = False
                End If
                If CStr(dgDetalle.Rows(i).Cells("colPrecio").Value) = STR_VACIO Then
                    MsgBox("Fila " & i + 1 & ": Article Quantity in zero.", vbExclamation, "Notice")
                    ComprobarFilas = False
                End If
            Next
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Function

    '********************** VALIDACION EN EL FORMULARIO PRINCIPAL ***************************

    'Valida que los gastos sean válidos para costeo CIF
    Private Function ComprobarGastos(ByVal Flete As Double, ByVal Seguro As Double, Optional Bloquear As Boolean = False) As Boolean
        Dim i As Integer
        Dim dblSuma As Double
        Dim logValido As Boolean
        Dim intOpc As Integer
        Dim intresp As Integer

        'Sólo CIF, ya que al FOB se le suman los gastos
        If CeldaCosteo.Text = "CIF" Or CeldaCosteo.Text = "CIP" Then
            For i = 0 To dgDetalle.Rows.Count - 1
                'Suma los Subtotales
                If dgDetalle.Rows(i).Cells("colOperacion").Value <> 2 Then
                    dblSuma = dblSuma + (dgDetalle.Rows(i).Cells("colTotal").Value)
                End If
            Next
            If (dblSuma < (Flete + Seguro)) Then
                intOpc = vbExclamation
                If Not (Bloquear) Then
                    intOpc = intOpc + vbYesNo
                End If
                intresp = MsgBox("CIF Cost:" & vbCr & vbCr & "The sum of expenses cant not be greater than the sum of detail: " & vbTab & dblSuma & IIf(Bloquear, vbNullString, vbCr & vbCr & "You want to continue anyway?"), intOpc, "Notice")
                logValido = (intresp = vbYes)
            Else
                logValido = True
            End If
        ElseIf celdaFlete.Text = vbNullString Then
            MsgBox("You have not selected a costing method", vbExclamation, "Notice")
        Else
            logValido = True
        End If

        ComprobarGastos = logValido
    End Function

    Private Function ComprobarPrecios() As Boolean
        Dim frm As New frmSeleccionar
        Dim strSQL As String = STR_VACIO
        Dim strOrden As String = STR_VACIO
        Dim strCodigo As String = STR_VACIO
        Dim strNotas As String = STR_VACIO
        Dim strTemp As String = STR_VACIO
        Dim COM As New MySqlCommand
        Dim CONEC As MySqlConnection
        Dim intCodigo As Integer = 0

        Dim contLine As Integer = 0
        Dim intDif As Integer = 0
        Dim intID As Integer = 0
        Dim intTipo As Integer = 0
        Dim intAño As Integer = 0
        Dim intNumero As Integer = 0
        Dim intLinea As Integer = 0


        Dim dblActual As Double = 0
        Dim dblPrecio As Double = 0

        Dim logEx As Boolean
        Dim logErr As Boolean


        intDif = vbEmpty
        strTemp = vbNullString
        strNotas = vbNullString

        intCodigo = dgDetalle.SelectedCells(3).Value

        For i As Integer = 0 To dgDetalle.Rows.Count - 1
            'Datos de la Fila
            intID = Val(dgDetalle.Rows(i).Cells("colLinea").Value)
            strOrden = dgDetalle.Rows(i).Cells("colOrden").Value
            strCodigo = dgDetalle.Rows(i).Cells("colCodigo").Value
            dblActual = dgDetalle.Rows(i).Cells("colPrecio").Value
            contLine = i + 1
        Next

        If intID > vbEmpty Then
            logEx = False
            intTipo = vbEmpty : intAño = vbEmpty : intNumero = vbEmpty : intLinea = vbEmpty
            For j As Integer = vbEmpty To dgInfoDescargo.Rows.Count - 1
                If dgInfoDescargo.Rows(j).Cells("colID").Value = intID Then
                    intTipo = Val(dgInfoDescargo.Rows(j).Cells("colTipo").Value)
                    intAño = Val(dgInfoDescargo.Rows(j).Cells("colAno").Value)
                    intNumero = Val(dgInfoDescargo.Rows(j).Cells("colNumero").Value)
                    intLinea = Val(dgInfoDescargo.Rows(j).Cells("colLine").Value)
                    logEx = True
                    Exit For
                End If
            Next
            'Tiene Orden Relacionada
            If logEx Then
                'El precio a comparar es el CIF
                If CeldaCosteo.Text = "CIF" Or CeldaCosteo.Text = "CIP" Then
                    strSQL = "SELECT DDoc_RF3_Dbl FROM Dcmtos_DTL "
                Else
                    strSQL = "SELECT DDoc_RF2_Dbl FROM Dcmtos_DTL "
                End If

                strSQL &= "     WHERE DDoc_Sis_Emp={empresa} AND DDoc_Doc_Cat='{tipo}' AND DDoc_Doc_Ano={año} AND DDoc_Doc_Num={numero} AND DDoc_Doc_Lin={linea}"
                strSQL &= "   LIMIT 1"

                strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
                strSQL = Replace(strSQL, "{tipo}", intTipo)
                strSQL = Replace(strSQL, "{año}", intAño)
                strSQL = Replace(strSQL, "{numero}", intNumero)
                strSQL = Replace(strSQL, "{linea}", intLinea)

                CONEC = New MySqlConnection(strConexion)
                CONEC.Open()
                COM = New MySqlCommand(strSQL, CONEC)
                Using CONEC
                    dblPrecio = COM.ExecuteScalar
                End Using
                COM.Dispose()
                COM = Nothing
                CONEC.Close()
                CONEC.Dispose()
                CONEC = Nothing
                System.GC.Collect()
                If Not (dblActual) = dblPrecio Then
                    intDif = intDif + 1
                    strTemp = strTemp & IIf(strTemp = vbNullString, vbNullString, vbCrLf) &
                              "Line: " & Format(contLine, "00") & "/ Order " & strOrden & vbTab & "Price: " & dblPrecio & vbTab & "Actual: " & (dblActual)
                    strNotas = strNotas & IIf(strNotas = vbNullString, vbNullString, vbCrLf) &
                              "LIN#" & Format(contLine, "00") & " ORDER: " & strOrden & " PRICE: " & CStr(dblPrecio) & " ACTUAL: " & CStr(dblActual)
                End If
            End If
        End If

        If intDif > vbEmpty Then
            If MsgBox("Difference has been found between the requisition price and this document" & vbCr & vbCr & Replace(strTemp, vbTab, IIf(intDif = 1, vbCrLf, vbTab)) & vbCr & vbCr & "You want to continue despite the differences?", vbYesNo + vbQuestion + vbDefaultButton2, "Price difference") = vbYes Then
                If PedirAutorizacion(frm.Titulo, "Lines with different price:" & intDif) Then
                    strNotas = "PRICE DIFFERENCE" & vbCrLf & strNotas
                    cfun.EscribirRegistro("TBL_DOCUMENTOS", clsFunciones.AccEnum.acCarga, 0, 127, CeldaAño.Text, CeldaNumero.Text, strNotas)
                Else : logErr = True
                End If
            Else : logErr = True
            End If
        End If

        ComprobarPrecios = Not (logErr)
    End Function

    Private Function ComprobarReferencia() As Boolean
        Dim COM As New MySqlCommand
        Dim CONEC As MySqlConnection
        Dim Texto As String
        Dim strSQL As String
        Dim Respuesta As Boolean = False
        Try
            'Verifica la factura de referencia
            'Ésta sólo se puede duplicar al hacer una reexportación (devolución) ya que ingresa con la misma referencia
            Respuesta = False
            strSQL = " SELECT CAST(CONCAT(h.HDoc_Doc_Ano,'-',h.HDoc_Doc_Num) AS CHAR) numero"
            strSQL &= "    FROM Dcmtos_HDR h"
            strSQL &= "  WHERE h.HDoc_DR1_Num = '{Factura}' AND h.HDoc_Sis_Emp = {empresa} AND h.HDoc_Doc_Cat = 127 AND NOT(h.HDoc_Doc_Ano = '{Año}' AND h.HDoc_Doc_Num = '{Numero}')"

            strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
            strSQL = Replace(strSQL, "{Factura}", celdaReferencia.Text)
            strSQL = Replace(strSQL, "{Año}", CeldaAño.Text)
            strSQL = Replace(strSQL, "{Numero}", CeldaNumero.Text)
            CONEC = New MySqlConnection(strConexion)
            CONEC.Open()
            COM = New MySqlCommand(strSQL, CONEC)
            Using CONEC
                Texto = COM.ExecuteScalar
                COM.Dispose()
                CONEC.Dispose()
                CONEC = Nothing
                System.GC.Collect()
            End Using
            If (Texto = vbNullString) Then
                Respuesta = True
            ElseIf MsgBox("The reference Invoice" & celdaReferencia.Text & "Is being used in the document" & Texto & "." & vbCr & vbCr & "Confirm that you want to continue?", vbExclamation + vbYesNo + vbDefaultButton2, "Confirm") = vbYes Then
                Respuesta = True
            End If

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try

        ComprobarReferencia = Respuesta
    End Function

    Private Function PedirAutorizacion(ByVal Titulo As String, Optional Info As String = vbNullString) As Boolean

        Const STR_PRECIO As String = "PRECIO"
        Dim frm As New frmAutorización


        frm.Iniciar(15, STR_PRECIO, 0, "Authorize Price Difference")
        frm.ShowDialog(Me)
        If frm.Aceptado Then
            If frm.Nivel = INT_UNO Then
                PedirAutorizacion = True
            Else
                MsgBox("You do not have the required Authorization level", vbExclamation, "Notice")
                PedirAutorizacion = False
            End If
        End If
        Return PedirAutorizacion
    End Function

    Private Function ComprobarDatos()
        'Revisar que los datos de la cabecera no estén en blanco.
        Dim i As Integer
        Dim logCoprobar As Boolean = True
        Try

            If Not ComprobarGastos(Val(celdaFlete.Text & vbEmpty), Val(celdaSeguro.Text), True) Then
                celdaFlete.Focus()
                logCoprobar = False
                Exit Function
            End If


            If cfun.ValidarCampoTexto(celdaEmpresa) = False Then
                MsgBox("Incomplete System Data", vbExclamation, "Notice")
                logCoprobar = False
                Exit Function
            End If
            If cfun.ValidarCampoTexto(celdaCatalogo) = False Then
                MsgBox("Incomplete System Data", vbExclamation, "Notice")
                logCoprobar = False
                Exit Function
            End If
            If cfun.ValidarCampoTexto(celdaUsuario) = False Then
                MsgBox("Incomplete System Data", vbExclamation, "Notice")
                logCoprobar = False
                Exit Function
            End If


            If cfun.ValidarCampoTexto(CeldaCliente) = False Then
                logCoprobar = False
            End If
            If cfun.ValidarCampoTexto(CeldaDireccion) = False Then
                logCoprobar = False
            End If
            If cfun.ValidarCampoTexto(CeldaCosteo) = False Then
                logCoprobar = False
            End If
            If dgDetalle.Rows.Count <= 0 Then
                logCoprobar = False
            End If
            For i = 0 To dgDetalle.Rows.Count - 1
                If Not dgDetalle.Rows(i).Cells("colOperacion").Value = 2 Then
                    If dgDetalle.Rows(i).Cells("colEstado").Value = "Sold" Then
                        If (dgDetalle.Rows(i).Cells("colIdVendido").Value = INT_CERO) Then
                            MsgBox("Blank sold to")
                            logCoprobar = False
                        End If

                    End If
                End If

            Next

            If cfun.ValidarCampoTexto(CeldaAño) = False Or
                cfun.ValidarCampoTexto(CeldaNumero) = False Or
                cfun.ValidarCampoTexto(celdaIDProveedores) = False Or
                cfun.ValidarCampoTexto(celdaReferencia) = False Or
                cfun.ValidarCampoTexto(CeldaMoneda) = False Or
                cfun.ValidarCampoTexto(CeldaTasa) = False Then
                MsgBox("You must enter  all the minimum data", vbExclamation, "Notice")
                logCoprobar = False
                Exit Function
            End If

            'Comprueba que la factura de referencia no exista aun en el sistema
            If Not ComprobarReferencia() Then
                logCoprobar = False
                Exit Function
            End If

            'Verifica Datos en el DETALLE
            For i = 0 To dgDetalle.Rows.Count - 1
                If Not ComprobarFilas(i) Then
                    logCoprobar = False
                    Exit Function
                End If

            Next

            'Verifica que total > 0
            CalcularTotales()
            If Not dblDocCantidad > 0 Then
                MsgBox("The total must be greater than zero", vbExclamation, "Notice")
                dgDetalle.ColumnCount = vbEmpty
                dgDetalle.Focus()
                logCoprobar = False
                Exit Function
            End If

            If Not ComprobarPrecios() Then
                logCoprobar = False
            End If

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try

        Return logCoprobar
    End Function

    Private Function GuardarEncabezado() As Boolean
        Dim cfun As New clsFunciones
        Dim logResultado As Boolean = True
        Dim chdr As New clsDcmtos_HDR


        Try
            chdr.CONEXION = strConexion
            If Me.Tag = "Mod" Then
                chdr.HDOC_SIS_EMP = Sesion.IdEmpresa
                chdr.HDOC_DOC_CAT = 127
                chdr.HDOC_DOC_ANO = CeldaAño.Text
                chdr.HDOC_DOC_NUM = CeldaNumero.Text
                chdr.HDoc_Doc_Fec_NET = dtpEncabezado.Value
            Else
                chdr.HDOC_SIS_EMP = Sesion.IdEmpresa
                chdr.HDOC_DOC_CAT = 127
                chdr.HDOC_DOC_ANO = cfun.AñoMySQL
                chdr.HDOC_DOC_NUM = CeldaNumero.Text
                chdr.HDoc_Doc_Fec_NET = dtpEncabezado.Value
            End If

            If checkActivo.Checked = True Then
                chdr.HDOC_DOC_STATUS = 1
            Else
                chdr.HDOC_DOC_STATUS = 0
            End If
            chdr.HDOC_ANT_COM = celdaTipoIngreso.Text
            chdr.HDOC_EMP_COD = celdaIDProveedores.Text
            chdr.HDOC_EMP_NOM = CeldaCliente.Text
            chdr.HDOC_EMP_DIR = CeldaDireccion.Text
            chdr.HDOC_EMP_PER = "N/A"
            chdr.HDOC_EMP_TEL = "N/A"
            chdr.HDOC_EMP_NIT = celdaNit.Text
            chdr.HDOC_DOC_TC = CeldaTasa.Text
            chdr.HDOC_DOC_MON = lblIDMoneda.Text

            chdr.HDOC_DR1_CAT = intTipoDoc ' guarda si es devolucion o importacion
            chdr.HDOC_DR1_NUM = celdaReferencia.Text    'Factura de Referencia
            chdr.HDOC_DR2_NUM = CeldaReferencia1.Text   'Ref.1
            chdr.HDOC_RF2_TXT = CeldaReferencia2.Text   'Ref.2

            chdr.HDOC_RF1_TXT = CeldaCosteo.Text
            chdr.HDOC_RF1_DBL = celdaFlete.Text
            chdr.HDOC_RF2_DBL = celdaSeguro.Text
            chdr.HDOC_USUARIO = celdaUsuario.Text


            If Me.Tag = "Mod" Then
                If chdr.Actualizar() = False Then
                    MsgBox(chdr.MERROR.ToString & "Document could not be update", MsgBoxStyle.Critical)
                End If
                'MostrarLista()
            ElseIf Me.Tag = "nuevo" Then
                If MsgBox("You want to use the correlative " & CeldaNumero.Text, vbYesNo, "Question") = vbYes Then
                    If chdr.Guardar() = False Then
                        MsgBox(chdr.MERROR.ToString & "Document could not be saved", MsgBoxStyle.Critical)
                    End If
                Else
                    logResultado = False
                    CeldaNumero.Focus()
                End If

                ' MostrarLista()
            End If

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        Return logResultado
    End Function

    Private Function GuardarEncabezadoDatosPolizaImportacion(ByVal idDatos As Integer) As Boolean
        Dim cfun As New clsFunciones
        Dim logResultado As Boolean = True
        Dim chdr As New clsDcmtos_HDR


        Try
            chdr.CONEXION = strConexion
            If Me.Tag = "Mod" Then
                chdr.HDOC_SIS_EMP = Sesion.IdEmpresa
                chdr.HDOC_DOC_CAT = 55
                chdr.HDOC_DOC_ANO = CeldaAño.Text
                chdr.HDOC_DOC_NUM = idDatos
                chdr.HDoc_Doc_Fec_NET = dtpEncabezado.Value
            Else
                chdr.HDOC_SIS_EMP = Sesion.IdEmpresa
                chdr.HDOC_DOC_CAT = 55
                chdr.HDOC_DOC_ANO = cfun.AñoMySQL
                chdr.HDOC_DOC_NUM = idDatos
                chdr.HDoc_Doc_Fec_NET = dtpEncabezado.Value
            End If

            If checkActivo.Checked = True Then
                chdr.HDOC_DOC_STATUS = 1
            Else
                chdr.HDOC_DOC_STATUS = 0
            End If

            chdr.HDOC_EMP_COD = celdaIDProveedores.Text
            chdr.HDOC_EMP_NOM = CeldaCliente.Text
            chdr.HDOC_ANT_COM = celdaTipoIngreso.Text

            chdr.HDOC_EMP_DIR = CeldaDireccion.Text
            chdr.HDOC_EMP_PER = "N/A"
            chdr.HDOC_EMP_TEL = "N/A"
            chdr.HDOC_EMP_NIT = celdaNit.Text
            chdr.HDOC_DOC_TC = CeldaTasa.Text
            chdr.HDOC_DOC_MON = lblIDMoneda.Text

            chdr.HDOC_DR1_CAT = intTipoDoc ' Importación o Devolución
            chdr.HDOC_DR1_NUM = celdaReferencia.Text    'Factura de Referencia
            chdr.HDOC_DR2_NUM = CeldaReferencia1.Text   'Ref.1
            chdr.HDOC_RF2_TXT = CeldaReferencia2.Text   'Ref.2

            chdr.HDOC_RF1_TXT = CeldaCosteo.Text
            chdr.HDOC_RF1_DBL = celdaFlete.Text
            chdr.HDOC_RF2_DBL = celdaSeguro.Text
            chdr.HDOC_USUARIO = celdaUsuario.Text

            If Me.Tag = "Mod" Then
                If chdr.Actualizar() = False Then
                    MsgBox(chdr.MERROR.ToString & "Document could not be updated", MsgBoxStyle.Critical)
                End If
                'MostrarLista()
            ElseIf Me.Tag = "nuevo" Then
                If chdr.Guardar() = False Then
                    MsgBox(chdr.MERROR.ToString & "Document could not be saved", MsgBoxStyle.Critical)
                End If
                'MostrarLista()
            End If

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        Return logResultado
    End Function

    Private Function GuardarDocumentoDetalle() As Boolean
        Dim clsDTL As New clsDcmtos_DTL
        Dim logResultado As Boolean = True
        clsDTL.CONEXION = strConexion
        Try
            For i As Integer = 0 To dgDetalle.Rows.Count - 1
                clsDTL.DDOC_SIS_EMP = celdaEmpresa.Text
                clsDTL.DDOC_DOC_CAT = celdaCatalogo.Text
                clsDTL.DDOC_DOC_ANO = CeldaAño.Text
                clsDTL.DDOC_DOC_NUM = CeldaNumero.Text
                clsDTL.DDOC_DOC_LIN = dgDetalle.Rows(i).Cells("colLinea").Value
                clsDTL.DDOC_RF1_NUM = IIf(dgDetalle.Rows(i).Cells("colEstado").Value = "Unsold", 0, 1) '0 No Vendido, 1 Vendido
                clsDTL.DDOC_RF2_COD = If(dgDetalle.Rows(i).Cells("colVendido").Value Is Nothing, "NULL", dgDetalle.Rows(i).Cells("colVendido").Value) ' Vendido a 

                clsDTL.DDOC_PRD_COD = dgDetalle.Rows(i).Cells("colCodProducto").Value
                clsDTL.DDOC_PRD_DES = dgDetalle.Rows(i).Cells("colDescripcion").Value
                clsDTL.DDOC_PRD_UM = dgDetalle.Rows(i).Cells("colIdMedida").Value

                clsDTL.DDOC_PRD_PUQ = dgDetalle.Rows(i).Cells("colPrecio").Value    'Precio/u
                clsDTL.DDOC_PRD_DSP = 0                                             'Descuento
                clsDTL.DDOC_PRD_DSQ = 0                                             'Monto(Desc)
                clsDTL.DDOC_PRD_NET = dgDetalle.Rows(i).Cells("colPrecio").Value    'Precio Neto
                clsDTL.DDOC_PRD_QTY = dgDetalle.Rows(i).Cells("colCantidad").Value  'Cantidad

                clsDTL.DDOC_PRD_FOB = dgDetalle.Rows(i).Cells("colPrecio").Value    'Valor FOB
                clsDTL.DDOC_PRD_CIF = dgDetalle.Rows(i).Cells("colPrecio").Value    'Valor CIF
                clsDTL.DDOC_RF1_DBL = dgDetalle.Rows(i).Cells("colTotal").Value     'Total
                clsDTL.DDOC_RF2_DBL = dgDetalle.Rows(i).Cells("colidNaviera").Value  'Naviera 
                clsDTL.DDOC_RF3_NUM = dgDetalle.Rows(i).Cells("colIdVendido").Value

                If dgDetalle.Rows(i).Cells("colFechaDetalle").Value = STR_VACIO Then
                    clsDTL.DDOC_RF1_FEC = Nothing  ' Fecha ETD 
                Else
                    clsDTL.DDoc_RF1_Fec_NET = dgDetalle.Rows(i).Cells("colFechaDetalle").Value  ' Fecha ETD 
                End If
                clsDTL.DDOC_RF1_COD = dgDetalle.Rows(i).Cells("colOrden").Value  'Referencia

                If dgDetalle.Rows(i).Cells("colOperacion").Value = 0 Then
                    If clsDTL.Actualizar() = False Then
                        MsgBox(clsDTL.MERROR.ToString)
                    End If
                    'MostrarLista()
                    'cfun.CargarLista(dgLista, SQLlista, False)
                ElseIf dgDetalle.Rows(i).Cells("colOperacion").Value = 1 Then
                    If clsDTL.Guardar() = False Then
                        MsgBox(clsDTL.MERROR.ToString)
                    End If
                    'MostrarLista()
                    'cfun.CargarLista(dgLista, SQLlista, False)
                ElseIf dgDetalle.Rows(i).Cells("colOperacion").Value = 2 Then
                    If clsDTL.Borrar() = False Then
                        MsgBox(clsDTL.MERROR.ToString)
                    End If
                    'MostrarLista()
                    'cfun.CargarLista(dgLista, SQLlista, False)
                End If
            Next


        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        Return logResultado
    End Function

    Private Function GuardarDocumentoDetalleDatosPolizaImporatcion(ByVal idDatos As Integer) As Boolean
        Dim clsDTL As New clsDcmtos_DTL
        Dim logResultado As Boolean = True
        clsDTL.CONEXION = strConexion
        Try
            For i As Integer = 0 To dgDetalle.Rows.Count - 1
                clsDTL.DDOC_SIS_EMP = celdaEmpresa.Text
                clsDTL.DDOC_DOC_CAT = 55
                clsDTL.DDOC_DOC_ANO = CeldaAño.Text
                clsDTL.DDOC_DOC_NUM = idDatos
                clsDTL.DDOC_DOC_LIN = dgDetalle.Rows(i).Cells("colLinea").Value


                clsDTL.DDOC_PRD_COD = dgDetalle.Rows(i).Cells("colCodProducto").Value
                clsDTL.DDOC_PRD_DES = dgDetalle.Rows(i).Cells("colDescripcion").Value
                clsDTL.DDOC_PRD_UM = dgDetalle.Rows(i).Cells("colIdMedida").Value

                clsDTL.DDOC_PRD_PUQ = dgDetalle.Rows(i).Cells("colPrecio").Value    'Precio/u
                clsDTL.DDOC_PRD_DSP = 0                                             'Descuento
                clsDTL.DDOC_PRD_DSQ = 0                                             'Monto(Desc)
                clsDTL.DDOC_PRD_NET = dgDetalle.Rows(i).Cells("colPrecio").Value    'Precio Neto
                clsDTL.DDOC_PRD_QTY = dgDetalle.Rows(i).Cells("colCantidad").Value  'Cantidad

                clsDTL.DDOC_PRD_FOB = dgDetalle.Rows(i).Cells("colPrecio").Value    'Valor FOB
                clsDTL.DDOC_PRD_CIF = dgDetalle.Rows(i).Cells("colPrecio").Value    'Valor CIF
                clsDTL.DDOC_RF1_DBL = dgDetalle.Rows(i).Cells("colTotal").Value     'Total

                clsDTL.DDOC_RF1_COD = dgDetalle.Rows(i).Cells("colOrden").Value  'Referencia

                If dgDetalle.Rows(i).Cells("colOperacion").Value = 0 Then
                    If clsDTL.Actualizar() = False Then
                        MsgBox(clsDTL.MERROR.ToString)
                    End If
                    'MostrarLista()
                    'cfun.CargarLista(dgLista, SQLlista, False)
                ElseIf dgDetalle.Rows(i).Cells("colOperacion").Value = 1 Then
                    If clsDTL.Guardar() = False Then
                        MsgBox(clsDTL.MERROR.ToString)
                    End If
                    'MostrarLista()
                    'cfun.CargarLista(dgLista, SQLlista, False)
                ElseIf dgDetalle.Rows(i).Cells("colOperacion").Value = 2 Then
                    If clsDTL.Borrar() = False Then
                        MsgBox(clsDTL.MERROR.ToString)
                    End If
                    'MostrarLista()
                    'cfun.CargarLista(dgLista, SQLlista, False)
                End If
            Next


        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        Return logResultado
    End Function

    Private Function GuardarDescargos() As String

        'Guarda el descargo para la línea de detalle actual
        Dim DTPRO As New clsDcmtos_DTL_Pro
        Dim logResultado As Boolean = True
        DTPRO.CONEXION = strConexion
        Try
            'If dgInfoDescargo.Rows.Count > 0 Then
            For i As Integer = 0 To dgInfoDescargo.Rows.Count - 1
                DTPRO.PDOC_SIS_EMP = celdaEmpresa.Text

                'Documento a ser descargado
                DTPRO.PDOC_PAR_CAT = 38
                DTPRO.PDOC_PAR_ANO = dgInfoDescargo.Rows(i).Cells("colAno").Value
                DTPRO.PDOC_PAR_NUM = dgInfoDescargo.Rows(i).Cells("colNumero").Value
                DTPRO.PDOC_PAR_LIN = dgInfoDescargo.Rows(i).Cells("colLine").Value

                'Referencia al documento actual
                DTPRO.PDOC_CHI_CAT = 127
                DTPRO.PDOC_CHI_ANO = Val(CeldaAño.Text)
                DTPRO.PDOC_CHI_NUM = Val(CeldaNumero.Text)
                DTPRO.PDOC_CHI_LIN = dgInfoDescargo.Rows(i).Cells("colID").Value

                DTPRO.PDOC_PROV_COD = Val(celdaIDProveedores.Text)

                'Referencia al producto y despacho
                DTPRO.PDOC_PRD_COD = dgInfoDescargo.Rows(i).Cells("colCode").Value
                DTPRO.PDOC_PRD_PNR = "N/A"
                DTPRO.PDOC_DR1_NUM = "0"
                DTPRO.PDOC_DR2_NUM = "0"

                For j As Integer = 0 To dgDetalle.Rows.Count - 1
                    If dgInfoDescargo.Rows(i).Cells("colID").Value = dgDetalle.Rows(j).Cells("colLinea").Value Then
                        DTPRO.PDOC_PRD_NET = dgDetalle.Rows(j).Cells("colprecio").Value
                        DTPRO.PDOC_QTY_ORD = dgDetalle.Rows(j).Cells("colCantidad").Value
                        Exit For
                    End If
                Next
                DTPRO.PDOC_QTY_PRO = dgInfoDescargo.Rows(i).Cells("colDescargar").Value

                If dgInfoDescargo.Rows(i).Cells("colSaldo").Value = 1 Then
                    If dgInfoDescargo.Rows(i).Cells("colDescargar").Value = 0 Then
                        If DTPRO.Borrar() = False Then
                            MsgBox(DTPRO.MERROR.ToString & "Document could not be updated", MsgBoxStyle.Critical)
                        End If
                    Else
                        If DTPRO.Actualizar() = False Then
                            MsgBox(DTPRO.MERROR.ToString & "Document could not be updated", MsgBoxStyle.Critical)
                        End If
                    End If

                    'MostrarLista()
                ElseIf dgInfoDescargo.Rows(i).Cells("colSaldo").Value = 0 Then
                    If DTPRO.Guardar() = False Then
                        MsgBox(DTPRO.MERROR.ToString & "Document could not be saved", MsgBoxStyle.Critical)
                    End If
                    'MostrarLista()
                End If
            Next
            'End If


        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try

        Return logResultado
    End Function

    Private Function GuardarDescargosDatosPolizaImportacion(ByVal idDatos) As String

        'Guarda el descargo para la línea de detalle actual
        Dim DTPRO As New clsDcmtos_DTL_Pro
        Dim logResultado As Boolean = True
        DTPRO.CONEXION = strConexion
        Try
            For i As Integer = 0 To dgDetalle.Rows.Count - 1
                DTPRO.PDOC_SIS_EMP = celdaEmpresa.Text

                'Documento a ser descargado
                DTPRO.PDOC_PAR_CAT = 127
                DTPRO.PDOC_PAR_ANO = Val(CeldaAño.Text)
                DTPRO.PDOC_PAR_NUM = Val(CeldaNumero.Text)
                DTPRO.PDOC_PAR_LIN = dgDetalle.Rows(i).Cells("colLinea").Value

                'Referencia al documento actual
                DTPRO.PDOC_CHI_CAT = 55
                DTPRO.PDOC_CHI_ANO = Val(CeldaAño.Text)
                DTPRO.PDOC_CHI_NUM = idDatos
                If Me.Tag = "nuevo" Then
                    DTPRO.PDOC_CHI_LIN = i + 1
                Else
                    DTPRO.PDOC_CHI_LIN = dgDetalle.Rows(i).Cells("colLinea").Value
                End If

                DTPRO.PDOC_PROV_COD = Val(celdaIDProveedores.Text)

                'Referencia al producto y despacho
                DTPRO.PDOC_PRD_COD = dgDetalle.Rows(i).Cells("colCodigo").Value
                DTPRO.PDOC_PRD_PNR = "N/A"
                DTPRO.PDOC_DR1_NUM = "0"
                DTPRO.PDOC_DR2_NUM = "0"


                DTPRO.PDOC_PRD_NET = dgDetalle.Rows(i).Cells("colprecio").Value
                DTPRO.PDOC_QTY_ORD = dgDetalle.Rows(i).Cells("colCantidad").Value

                DTPRO.PDOC_QTY_PRO = dgDetalle.Rows(i).Cells("colCantidad").Value


                If dgDetalle.Rows(i).Cells("colOperacion").Value = 0 Then
                    If DTPRO.Actualizar() = False Then
                        MsgBox(DTPRO.MERROR.ToString & "Document could not be updated", MsgBoxStyle.Critical)
                    End If
                    'MostrarLista()
                ElseIf dgDetalle.Rows(i).Cells("colOperacion").Value = 1 Then
                    If DTPRO.Guardar() = False Then
                        MsgBox(DTPRO.MERROR.ToString & "Document could not be saved", MsgBoxStyle.Critical)
                    End If
                    'MostrarLista()
                ElseIf dgDetalle.Rows(i).Cells("colOperacion").Value = 2 Then

                    If DTPRO.Borrar() = False Then
                        MsgBox(DTPRO.MERROR.ToString)
                    End If
                    'MostrarLista()
                    'cfun.CargarLista(dgLista, SQLlista, False)
                End If
            Next


        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try

        Return logResultado
    End Function

    Private Function ActualizarDescargos() As Double
        'Actualiza el detalle de descargos de esta línea a las ordenes (con las cant. ya descargadas)
        'Devuelve la suma
        Dim i As Integer
        Dim k As Integer
        Dim intID As Integer
        Dim dblTemp As Double
        Dim dblTotal As Double
        Dim dblBalance As Double = 0
        Dim dblCantidad As Double = 0
        Dim strCantidad As String
        Dim strSimbolo As String
        Dim PosicionSimbolo As Integer

        intID = Val(dgDetalle.SelectedCells(2).Value)

        For i = 0 To Re.dgLista.Rows.Count - 1
            dblTemp = vbEmpty
            For k = 0 To dgInfoDescargo.Rows.Count - 1
                If dgInfoDescargo.Rows(k).Cells("colID").Value = intID Then
                    'Es el Id del detalle y corresponde a la línea de la orden
                    If dgInfoDescargo.Rows(k).Cells("colAno").Value = Re.dgLista.Rows(i).Cells("colAno").Value And
                       dgInfoDescargo.Rows(k).Cells("colNumero").Value = Re.dgLista.Rows(i).Cells("colNumero").Value And
                       dgInfoDescargo.Rows(k).Cells("colLine").Value = Re.dgLista.Rows(i).Cells("colLinea").Value Then
                        dblTemp = dblTemp + (dgInfoDescargo.Rows(k).Cells("colDescargar").Value)
                        dblTotal = dblTotal + (dgInfoDescargo.Rows(k).Cells("colDescargar").Value)

                    End If
                End If
            Next
            strCantidad = (Re.dgLista.Rows(i).Cells("colCantidad").Value)
            strSimbolo = "- "
            PosicionSimbolo = strCantidad.IndexOf(strSimbolo)
            If PosicionSimbolo = -1 Then
                dblCantidad = CDbl(strCantidad)
            Else
                strCantidad = Replace(strCantidad, "- ", 0)
                dblCantidad = (CDbl(strCantidad) * (-1))
            End If

            Re.dgLista.Rows(i).Cells("colDescargo").Value = dblTemp.ToString(FORMATO_MONEDA)
            dblBalance = (dblCantidad + CDbl(dblTemp))
            Re.dgLista.Rows(i).Cells("colCantidad").Value = dblBalance
        Next
        Return dblTotal
    End Function

    Private Sub MostrarOrdenes()
        'Muestra las líneas disponibles de los documentos del listado
        'Dim frmTemp As New frmRequisiciones
        Dim COM As New MySqlCommand
        Dim COM2 As New MySqlCommand
        Dim COM3 As New MySqlCommand
        Dim i As Integer
        Dim intCod As Long
        Dim intID As Integer
        Dim intClase As Integer
        Dim UMProd As Integer

        Dim strFabricante As String = STR_VACIO
        Dim strMedida As String = STR_VACIO
        Dim strSQL As String = STR_VACIO
        Dim strSQL2 As String = STR_VACIO
        Dim strSQL3 As String = STR_VACIO
        Dim strRef As String = STR_VACIO
        Dim dblTemp As Double
        Dim dblCant As Double
        Dim dblDesc As Double


        i = dgDetalle.Rows.Count

        If Not (i = NO_FILA) Then
            strFabricante = vbNullString
            intCod = Val(dgDetalle.CurrentRow.Cells("colCodProducto").Value)
            strMedida = dgDetalle.CurrentRow.Cells("colMedida").Value
            If intCod > vbEmpty Then
                strSQL = "SELECT inv_lugarfab"
                strSQL &= "   FROM Inventarios"
                strSQL &= "      WHERE inv_sisemp={empresa} AND inv_numero={codigo} AND inv_activo = 0 " ' 0= activo, 1= Inactivo

                strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
                strSQL = Replace(strSQL, "{codigo}", intCod)

                MyCnn.CONECTAR = strConexion
                COM = New MySqlCommand(strSQL, CON)
                intID = COM.ExecuteScalar

                strSQL2 = "SELECT inv_artcodigo"
                strSQL2 &= "     FROM Inventarios"
                strSQL2 &= "          WHERE inv_sisemp={empresa} AND inv_numero={codigo} AND inv_activo = 0 "

                strSQL2 = Replace(strSQL2, "{empresa}", Sesion.IdEmpresa)
                strSQL2 = Replace(strSQL2, "{codigo}", intCod)


                MyCnn.CONECTAR = strConexion
                COM2 = New MySqlCommand(strSQL2, CON)
                intClase = COM2.ExecuteScalar

                If Not intID >= vbEmpty Then intID = NO_FILA
            End If
            If Not (intID = NO_FILA) Then
                strSQL3 = " SELECT pro_proveedor"
                strSQL3 &= "      FROM Proveedores"
                strSQL3 &= "             WHERE pro_sisemp= {empresa} AND pro_codigo={codigo}"

                strSQL3 = Replace(strSQL3, "{empresa}", Sesion.IdEmpresa)
                strSQL3 = Replace(strSQL3, "{codigo}", intID)

                MyCnn.CONECTAR = strConexion
                COM3 = New MySqlCommand(strSQL3, CON)
                strFabricante = COM.ExecuteScalar
            End If

            strRef = dgDetalle.CurrentRow.Cells("colOrden").Value
            UMProd = dgDetalle.CurrentRow.Cells("colIdMedida").Value
            DatosParaDescargar(Re, intClase, intID, strRef, UMProd)

            'If Not (Re.dgLista.Rows.Count > vbEmpty) Then
            '    MsgBox("Check the Country of origin", vbExclamation, "Notice")
            'Else
            dblTemp = ActualizarDescargos()
            dblCant = dgDetalle.CurrentRow.Cells("colCantidad").Value
            'Si no hay descargos, intenta hacerlos automóticamente

            If dblTemp < dblCant Then
                For i = vbEmpty To Re.dgLista.Rows.Count - 1
                    If Re.dgLista.Rows(i).Cells("colReferencia").Value = strRef And
                       Re.dgLista.Rows(i).Cells("colClase").Value = intClase Then

                        dblTemp = Re.dgLista.Rows(i).Cells("colCantidad").Value
                        ' Decimal.TryParse(Re.dgLista.Rows(i).Cells("colCantidad").Value, dblTemp)
                        If dblTemp < 0 Then
                            dblTemp = dblTemp * -1
                        End If
                        dblDesc = Re.dgLista.Rows(i).Cells("colDescargo").Value
                        If dblDesc > vbEmpty Then
                            '  dblCant = (dblCant - dblDesc)
                        End If
                        If dblCant > vbEmpty Then
                            If dblTemp >= dblCant Then
                                Re.dgLista.Rows(i).Cells("colDescargo").Value = dblCant.ToString(FORMATO_MONEDA)
                                dblCant = vbEmpty
                                Re.dgLista.Rows(i).Cells("colDescargo").Style.ForeColor = Color.Blue
                            ElseIf dblTemp > vbEmpty And dblCant > vbEmpty Then
                                Re.dgLista.Rows(i).Cells("colDescargo").Value = dblCant.ToString(FORMATO_MONEDA)
                                dblCant = (dblCant - dblTemp)
                                Re.dgLista.Rows(i).Cells("coldescargo").Style.ForeColor = Color.Coral
                            End If
                        End If
                    End If
                    If dblCant <= vbEmpty Then Exit For
                Next
            Else
                dblCant = (dblCant - dblTemp)
            End If

            If dblCant > vbEmpty Then
                MsgBox(dblCant.ToString(FORMATO_MONEDA) & Space(2) & strMedida & "Pending assignment", vbExclamation, "Order #" & strRef)
            End If
            Re.Medida = dgDetalle.CurrentRow.Cells("colMedida").Value
            Re.Cantidad = dgDetalle.CurrentRow.Cells("colCantidad").Value
            Re.Precio = dgDetalle.CurrentRow.Cells("colPrecio").Value
            Re.codInventario = dgDetalle.CurrentRow.Cells("colCodProducto").Value
            Re.Linea = dgDetalle.CurrentRow.Cells("colLinea").Value
            Re.ShowDialog(Me)
            Re.Hide()

            If Re.Aceptado Then

                ActualizarDetalle()
            End If
            'End If
        End If


    End Sub

    Private Sub ActualizarDetalle()
        'Actualiza la realcion entre la linea actual del detalle y los descargos
        Dim i As Integer
        Dim dblTemp As Double
        Dim strStatus As String = STR_VACIO
        Dim strVendido As String = STR_VACIO
        Dim dblSuma As Double
        Dim intID As Integer
        Dim strFila As String = STR_VACIO
        Dim blNuevo As Boolean = False
        Dim COM As MySqlCommand
        Dim strSQL As String = STR_VACIO
        Dim j As Integer = 0


        intID = dgDetalle.CurrentRow.Cells("colIDD").Value
        blNuevo = QuitarReferencias(intID)

        If blNuevo = True Then

            For i = 0 To Re.dgLista.Rows.Count - 1
                dblTemp = Re.dgLista.Rows(i).Cells("colDescargo").Value
                strStatus = Re.dgLista.Rows(i).Cells("colEstado").Value
                strVendido = Re.dgLista.Rows(i).Cells("colVendido").Value

                If (dblTemp > vbEmpty) Then
                    dblSuma = dblSuma + dblTemp

                    strFila = intID & "|"
                    strFila &= 38 & "|"
                    strFila &= Re.dgLista.Rows(i).Cells("colAno").Value & "|"
                    strFila &= Re.dgLista.Rows(i).Cells("colNumero").Value & "|"
                    strFila &= Re.dgLista.Rows(i).Cells("colLinea").Value & "|"
                    strFila &= Re.dgLista.Rows(i).Cells("colCodigo").Value & "|"
                    strFila &= Re.dgLista.Rows(i).Cells("colUnit").Value & "|"
                    strFila &= "0" & "|"
                    strFila &= dblTemp.ToString(FORMATO_MONEDA) & "|"
                    strFila &= "0" & "|"
                    strFila &= "0"

                    cfun.AgregarFila(dgInfoDescargo, strFila)

                    dgDetalle.CurrentRow.Cells("colCantidad").Value = dblTemp
                    dgDetalle.CurrentRow.Cells("colEstado").Value = strStatus
                    dgDetalle.CurrentRow.Cells("colIdVendido").Value = strVendido

                    strSQL = " SELECT c.cli_cliente FROM Clientes c WHERE c.cli_sisemp = {emp} AND c.cli_codigo = {cod} "
                    strSQL = Replace(strSQL, "{emp}", Sesion.IdEmpresa)
                    strSQL = Replace(strSQL, "{cod}", strVendido)
                    MyCnn.CONECTAR = strConexion
                    COM = New MySqlCommand(strSQL, CON)
                    dgDetalle.CurrentRow.Cells("colVendido").Value = COM.ExecuteScalar
                    'dgDetalle.CurrentRow.Cells("colCantidad").Value = dblTemp
                    'dgDetalle.CurrentRow.Cells("colTotal").Value = (Re.dgLista.Rows(i).Cells("colUnit").Value * dblTemp)
                End If
            Next
        Else

            For i = 0 To Re.dgLista.Rows.Count - 1

                If Re.dgLista.Rows(i).Cells("colLinea").Value = intID Then
                    dblTemp = Re.dgLista.Rows(i).Cells("colDescargo").Value
                    strStatus = Re.dgLista.Rows(i).Cells("colEstado").Value
                    strVendido = Re.dgLista.Rows(i).Cells("colVendido").Value

                    If (dblTemp > vbEmpty) Then
                        dblSuma = dblSuma + dblTemp

                        For j = 0 To dgInfoDescargo.Rows.Count - 1
                            If dgInfoDescargo.Rows(j).Cells("colID").Value = intID Then
                                dgInfoDescargo.Rows(j).Cells("colDescargar").Value = dblTemp.ToString(FORMATO_MONEDA)
                            End If
                        Next

                        dgDetalle.CurrentRow.Cells("colCantidad").Value = dblTemp
                        dgDetalle.CurrentRow.Cells("colEstado").Value = strStatus
                        dgDetalle.CurrentRow.Cells("colIdVendido").Value = strVendido
                        strSQL = " SELECT c.cli_cliente FROM Clientes c WHERE c.cli_sisemp = {emp} AND c.cli_codigo = {cod} "
                        strSQL = Replace(strSQL, "{emp}", Sesion.IdEmpresa)
                        strSQL = Replace(strSQL, "{cod}", strVendido)
                        MyCnn.CONECTAR = strConexion
                        COM = New MySqlCommand(strSQL, CON)
                        dgDetalle.CurrentRow.Cells("colVendido").Value = COM.ExecuteScalar

                        'dgDetalle.CurrentRow.Cells("colCantidad").Value = dblTemp
                        'dgDetalle.CurrentRow.Cells("colTotal").Value = (Re.dgLista.Rows(i).Cells("colUnit").Value * dblTemp)
                    End If
                Else
                    dblTemp = Re.dgLista.Rows(i).Cells("colDescargo").Value
                    strStatus = Re.dgLista.Rows(i).Cells("colEstado").Value
                    strVendido = Re.dgLista.Rows(i).Cells("colVendido").Value


                    If (dblTemp > vbEmpty) Then
                        dblSuma = dblSuma + dblTemp
                        For j = 0 To dgInfoDescargo.Rows.Count - 1
                            If dgInfoDescargo.Rows(j).Cells("colID").Value = intID Then
                                dgInfoDescargo.Rows(j).Cells("colDescargar").Value = INT_CERO.ToString(FORMATO_MONEDA)
                            End If
                        Next

                        strFila = intID & "|"
                        strFila &= 38 & "|"
                        strFila &= Re.dgLista.Rows(i).Cells("colAno").Value & "|"
                        strFila &= Re.dgLista.Rows(i).Cells("colNumero").Value & "|"
                        strFila &= Re.dgLista.Rows(i).Cells("colLinea").Value & "|"
                        strFila &= Re.dgLista.Rows(i).Cells("colCodigo").Value & "|"
                        strFila &= Re.dgLista.Rows(i).Cells("colUnit").Value & "|"
                        strFila &= "0" & "|"
                        strFila &= dblTemp.ToString(FORMATO_MONEDA) & "|"
                        strFila &= "0" & "|"
                        strFila &= "0"

                        cfun.AgregarFila(dgInfoDescargo, strFila)


                        dgDetalle.CurrentRow.Cells("colCantidad").Value = dblTemp
                        dgDetalle.CurrentRow.Cells("colEstado").Value = strStatus
                        dgDetalle.CurrentRow.Cells("colIdVendido").Value = strVendido
                        strSQL = " SELECT c.cli_cliente FROM Clientes c WHERE c.cli_sisemp = {emp} AND c.cli_codigo = {cod} "
                        strSQL = Replace(strSQL, "{emp}", Sesion.IdEmpresa)
                        strSQL = Replace(strSQL, "{cod}", strVendido)
                        MyCnn.CONECTAR = strConexion
                        COM = New MySqlCommand(strSQL, CON)
                        dgDetalle.CurrentRow.Cells("colVendido").Value = COM.ExecuteScalar

                        'dgDetalle.CurrentRow.Cells("colCantidad").Value = dblTemp
                        'dgDetalle.CurrentRow.Cells("colTotal").Value = (Re.dgLista.Rows(i).Cells("colUnit").Value * dblTemp)
                    End If
                End If

            Next
        End If

        CalcularTotalesDGyCeldas()
        ActualizarReferencias(dgDetalle.Rows.Count, dblTemp)
    End Sub

    Private Sub ActualizarReferencias(Optional ByVal Index As Integer = NO_FILA, Optional ByVal cantidad As Double = INT_CERO)
        'Actualiza la colomna de referencias del detalle de acuerdo a las lineas referenciadas
        Dim intInicio As Integer
        Dim intLimite As Integer
        Dim i As Integer
        Dim intID As Integer
        Dim strTemp As String = STR_VACIO
        Dim dblTemp As Double
        Dim k As Integer

        If Index = NO_FILA Then
            intInicio = vbEmpty
            intLimite = dgDetalle.Rows.Count - 1
        Else
            intInicio = Index
            intLimite = Index
        End If

        For i = 0 To dgDetalle.Rows.Count - 1
            'Identificador del detalle
            intID = dgDetalle.Rows(i).Cells("colIDD").Value

            'Busca las referencias en el listado
            strTemp = vbNullString
            For k = 0 To dgInfoDescargo.Rows.Count - 1
                If dgInfoDescargo.Rows(k).Cells("colID").Value = intID Then
                    strTemp = strTemp & dgInfoDescargo.Rows(k).Cells("colNumero").Value & "/" & dgInfoDescargo.Rows(k).Cells("colLine").Value
                End If
            Next

            'Asigna el texto de referencia
            If dgDetalle.Rows(i).Cells("colOrden").Value = "0" Then
                dgDetalle.Rows(i).Cells("colReferencia").Value = strTemp
                dgDetalle.Rows(i).Cells("colOrden").Value = strTemp

            End If
        Next
    End Sub

    Private Function QuitarReferencias(ByVal ID As Integer)
        'Quita las referencias del listado para una fila del detalle
        Dim i As Integer
        Dim TipoSave As Boolean = True

        For i = dgInfoDescargo.Rows.Count - 1 To vbEmpty Step (-1)
            If dgInfoDescargo.Rows(i).Cells("colID").Value = ID Then
                ''dgInfoDescargo.Rows.Remove(dgInfoDescargo.Rows(i))
                'dgInfoDescargo.Rows(i).Cells("colDescargar").Value = Re.dgLista.Rows(i).Cells("colDescargo").Value
                'dgInfoDescargo.Rows(i).Cells("colDescargado").Value = Re.dgLista.Rows(i).Cells("colDescargo").Value
                TipoSave = False
            End If
        Next
        Return TipoSave
    End Function

    Private Function SqlDatosParaDescargar(ByVal Fabricante As Integer, ByVal Clase As Integer, ByVal Orden As String, ByVal UMProd As Integer) As String
        Dim strSQL As String = STR_VACIO

        strSQL = "  SELECT l1.*, (l1.transito - l1.bodega) confirmado, ROUND((l1.cantidad - (l1.transito+l1.manual)),2) saldo, 0 semana, '' lote"
        strSQL &= "    FROM ("
        strSQL &= "      SELECT IF(d.DDoc_Prd_Fob = 0,'Unsold','Sold') Estado, IFNULL(d.DDoc_Prd_PUQ,0) Vendido_A, d.DDoc_Doc_Cat tipo, d.DDoc_Doc_Ano anio, d.DDoc_Doc_Num numero, d.DDoc_Doc_Lin linea, e.HDoc_Doc_Fec fecha, IFNULL(cp.cat_clave,'') pais, IFNULL(lf.pro_proveedor,'') fabricante,"
        strSQL &= "         e.HDoc_DR1_Num referencia, d.DDoc_RF1_Cod orden, a.art_codigo clase, d.DDoc_Prd_Cod codigo, d.DDoc_Prd_Des descripcion, d.{precio} precio, d.DDoc_Prd_QTY cantidad, d.DDoc_Prd_UM unidad, IFNULL(cm.cat_clave,'') medida, IFNULL(("
        strSQL &= "             SELECT SUM(r1.PDoc_QTY_Pro)"
        strSQL &= "                FROM Dcmtos_DTL_Pro r1"
        strSQL &= "                   LEFT JOIN Dcmtos_HDR e1 ON e1.HDoc_Sis_Emp = r1.PDoc_Sis_Emp AND e1.HDoc_Doc_Cat = r1.PDoc_Chi_Cat AND e1.HDoc_Doc_Ano = r1.PDoc_Chi_Ano AND e1.HDoc_Doc_Num = r1.PDoc_Chi_Num"
        strSQL &= "                       WHERE r1.PDoc_Sis_Emp = d.DDoc_Sis_Emp AND r1.PDoc_Par_Cat = d.DDoc_Doc_Cat AND r1.PDoc_Par_Ano = d.DDoc_Doc_Ano AND r1.PDoc_Par_Num = d.DDoc_Doc_Num AND r1.PDoc_Par_Lin = d.DDoc_Doc_Lin AND r1.PDoc_Chi_Cat = {catalogo} AND e1.HDoc_Doc_Status = 1),0) transito, IFNULL(("
        strSQL &= "                          SELECT SUM(IFNULL(r4.PDoc_QTY_Pro,0))"
        strSQL &= "                             FROM Dcmtos_DTL_Pro r1"
        strSQL &= "                                LEFT JOIN Dcmtos_DTL_Pro r2 ON r2.PDoc_Sis_Emp = r1.PDoc_Sis_Emp AND r2.PDoc_Par_Cat = r1.PDoc_Chi_Cat AND r2.PDoc_Par_Ano = r1.PDoc_Chi_Ano AND r2.PDoc_Par_Num = r1.PDoc_Chi_Num AND r2.PDoc_Par_Lin = r1.PDoc_Chi_Lin AND r2.PDoc_Chi_Cat = {datos}"
        strSQL &= "                                    LEFT JOIN Dcmtos_DTL_Pro r3 ON r3.PDoc_Sis_Emp = r2.PDoc_Sis_Emp AND r3.PDoc_Par_Cat = r2.PDoc_Chi_Cat AND r3.PDoc_Par_Ano = r2.PDoc_Chi_Ano AND r3.PDoc_Par_Num = r2.PDoc_Chi_Num AND r3.PDoc_Par_Lin = r2.PDoc_Chi_Lin AND r3.PDoc_Chi_Cat = {importacion}"
        strSQL &= "                                        LEFT JOIN Dcmtos_DTL_Pro r4 ON r4.PDoc_Sis_Emp = r3.PDoc_Sis_Emp AND r4.PDoc_Par_Cat = r3.PDoc_Chi_Cat AND r4.PDoc_Par_Ano = r3.PDoc_Chi_Ano AND r4.PDoc_Par_Num = r3.PDoc_Chi_Num AND r4.PDoc_Par_Lin = r3.PDoc_Chi_Lin AND r4.PDoc_Chi_Cat = {ingreso}"
        strSQL &= "                                            WHERE r1.PDoc_Sis_Emp = d.DDoc_Sis_Emp AND r1.PDoc_Par_Cat = d.DDoc_Doc_Cat AND r1.PDoc_Par_Ano = d.DDoc_Doc_Ano AND r1.PDoc_Par_Num = d.DDoc_Doc_Num AND r1.PDoc_Par_Lin = d.DDoc_Doc_Lin AND r1.PDoc_Chi_Cat = 127),0) bodega, IFNULL(("
        strSQL &= "                                               SELECT SUM(m.IDoc_Itm_QTY)"
        strSQL &= "                                                  FROM Dcmtos_DTL_Itm m"
        strSQL &= "                                                    WHERE m.IDoc_Sis_Emp=d.DDoc_Sis_Emp AND m.IDoc_Doc_Cat=d.DDoc_Doc_Cat AND m.IDoc_Doc_Ano=d.DDoc_Doc_Ano AND m.IDoc_Doc_Num=d.DDoc_Doc_Num AND m.IDoc_Doc_Lin=d.DDoc_Doc_Lin AND m.IDoc_RF1_Txt='DESPACHO'),0) manual, IF(e.HDoc_Doc_Status = 1 AND d.DDoc_RF2_Num = 0,1,0) activo"
        strSQL &= "                                               FROM Inventarios ii"
        strSQL &= "                                            INNER JOIN Dcmtos_DTL d ON d.DDoc_Sis_Emp = ii.inv_sisemp AND d.DDoc_Doc_Cat = {orden} AND d.DDoc_Prd_Cod = ii.inv_numero"
        strSQL &= "                                         INNER JOIN Dcmtos_HDR e ON e.HDoc_Sis_Emp = d.DDoc_Sis_Emp AND e.HDoc_Doc_Cat = d.DDoc_Doc_Cat AND e.HDoc_Doc_Ano = d.DDoc_Doc_Ano AND e.HDoc_Doc_Num = d.DDoc_Doc_Num"
        strSQL &= "                                      LEFT JOIN Catalogos cm ON cm.cat_clase = 'Medidas' AND cm.cat_num = d.DDoc_Prd_UM"
        strSQL &= "                                   LEFT JOIN Inventarios i ON i.inv_sisemp=d.DDoc_Sis_Emp AND i.inv_numero=d.DDoc_Prd_Cod"
        strSQL &= "                                 LEFT JOIN Articulos a ON a.art_sisemp=i.inv_sisemp AND a.art_codigo=i.inv_artcodigo"
        strSQL &= "                               LEFT JOIN Catalogos cp ON cp.cat_clase='Paises' AND cp.cat_num=i.inv_lugarfab"
        strSQL &= "                            LEFT JOIN Proveedores lf ON lf.pro_sisemp=d.DDoc_Sis_Emp AND lf.pro_codigo=d.DDoc_RF1_Num"
        strSQL &= "                          WHERE i.inv_sisemp = {empresa} AND i.inv_artcodigo = {clase} AND i.inv_UMcmpra = {UM} /*AND i.inv_lugarfab = {fabricante}*/) l1"

        strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
        If CeldaCosteo.Text = "CIF" Or CeldaCosteo.Text = "CIP" Then
            strSQL = Replace(strSQL, "{precio}", "DDoc_RF3_Dbl")
        Else
            strSQL = Replace(strSQL, "{precio}", "DDoc_RF2_Dbl")
        End If
        strSQL = Replace(strSQL, "{UM}", UMProd)
        strSQL = Replace(strSQL, "{orden}", 38)
        strSQL = Replace(strSQL, "{catalogo}", 127)
        strSQL = Replace(strSQL, "{datos}", 55)
        strSQL = Replace(strSQL, "{importacion}", 180)
        strSQL = Replace(strSQL, "{ingreso}", 47)

        strSQL = Replace(strSQL, "{fabricante}", "") 'Fabricante)
        strSQL = Replace(strSQL, "{clase}", Clase)

        SqlDatosParaDescargar = strSQL
    End Function

    Private Sub DatosParaDescargar(ByRef Re As frmRequisiciones, ByVal Clase As Integer, ByVal Fabricantes As Integer, ByVal Orden As String, ByVal UMProd As Integer)
        'Carga el detalle de los docs. para descargar a la ventana
        Dim strSQL As String = STR_VACIO
        Dim dblSaldo As Double
        Dim dblSaldoTotal As Double = 0
        Dim intID As Integer
        Dim strFila As String = STR_VACIO
        Dim logClase As Boolean
        Dim logOrden As Boolean
        Dim a As Integer
        Dim f As String


        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader

        Try

            'Instruccion de seleccion
            strSQL = SqlDatosParaDescargar(Fabricantes, Clase, Orden, UMProd)
            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSQL, CON)
            REA = COM.ExecuteReader

            Re.dgLista.Rows.Clear()

            intID = dgDetalle.SelectedCells(13).Value
            If REA.HasRows Then
                Re.celdaPrecio.Text = dgDetalle.SelectedCells(7).Value
                Re.celdaIcotern.Text = CeldaCosteo.Text
                Do While REA.Read()
                    dblSaldo = DescargosDeLinea(REA.GetInt32("anio"), REA.GetInt32("Numero"), REA.GetInt32("Linea"), intID)
                    'MsgBox(REA.GetString("orden") & " " & Orden)
                    If (dblSaldo > 0 Or ((REA.GetString("orden") = Orden And REA.GetInt32("Clase") = Clase) And Not (Orden = vbNullString))) Then

                        'If (((REA.GetString("numero") = Orden And REA.GetInt32("Clase") = Clase) And Not (Orden = vbNullString))) Then
                        'Agrega una fila al listado
                        dblSaldoTotal = (REA.GetDouble("saldo")) '- dblSaldo)
                        strFila = REA.GetDateTime("fecha") & "|"
                        strFila &= REA.GetInt32("numero") & "|"

                        'Numero de Orden en vez de la referencia
                        strFila &= REA.GetString("orden") & "|"

                        strFila &= REA.GetInt32("linea") & "|"
                        strFila &= REA.GetInt32("anio") & "|"

                        strFila &= REA.GetInt32("codigo") & "|"
                        strFila &= REA.GetString("descripcion") & "|"
                        strFila &= REA.GetDouble("precio") & "|"
                        'strFila &= dblSaldo.ToString(FORMATO_MONEDA) & "|"
                        strFila &= dblSaldoTotal & "|"
                        strFila &= REA.GetString("medida") & "|"
                        strFila &= INT_CERO & "|"

                        strFila &= REA.GetString("Pais") & "|"
                        strFila &= REA.GetString("fabricante") & "|"
                        strFila &= REA.GetInt32("semana") & "|"
                        strFila &= REA.GetString("lote") & "|"
                        strFila &= REA.GetInt32("clase") & "|"
                        strFila &= REA.GetInt32("unidad") & "|"
                        strFila &= REA.GetString("Estado") & "|"
                        strFila &= REA.GetInt32("Vendido_A")

                        If REA.GetInt32("clase") = Clase Then
                            logClase = True
                        Else
                            logClase = False
                        End If

                        If (REA.GetString("orden") = Orden) And Not (Trim(Orden) = vbNullString) Then
                            logOrden = True
                        Else
                            logOrden = False
                        End If
                        Re.OrdenDeImportacion = logOrden

                        a = REA.GetInt32("activo")
                        f = REA.GetString("fabricante")

                        AgregarFila(Re.dgLista, strFila, logClase, logOrden, a, f)

                    End If
                Loop
            End If

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub AgregarFila(ByRef Lista As DataGridView, ByVal strFila As String, ByVal logClase As Boolean, ByVal logOrden As Boolean, ByVal Activo As Integer, ByVal Fabricantes As String)

        Dim Celda As New DataGridViewTextBoxCell
        Dim Fila As New DataGridViewRow
        Dim strSQL As String = STR_VACIO
        Dim arrayFila() As String
        Dim i As Integer
        Try
            Lista.BackgroundColor = Color.White
            arrayFila = strFila.Split("|".ToCharArray)
            For i = 0 To arrayFila.Length - 1
                Celda = New DataGridViewTextBoxCell
                Celda.Value = arrayFila(i)

                If Activo = vbEmpty Then
                    If i = 1 Then
                        Celda.Style.BackColor = Color.Red
                        Celda.Style.ForeColor = Color.White
                    End If
                Else
                    If i = 1 Then
                        Celda.Style.BackColor = Color.SkyBlue
                        Celda.Style.ForeColor = Color.White
                    End If
                End If

                If logOrden Or logClase Then
                    If logOrden And logClase Then
                        If i = 2 Then
                            Celda.Style.BackColor = Color.Blue
                            Celda.Style.ForeColor = Color.White
                        End If
                    ElseIf logOrden Then
                        If i = 2 Then
                            Celda.Style.BackColor = Color.Yellow
                            'Celda.Style.ForeColor = Color.White

                        End If
                    Else
                        If i = 2 Then
                            Celda.Style.BackColor = Color.Orange
                            'Celda.Style.ForeColor = Color.White
                        End If
                    End If
                End If

                If Fabricantes = vbNullString Then
                    If i = 2 Then
                        Celda.Style.BackColor = Color.LightGray
                    End If
                End If

                Fila.Cells.Add(Celda)

            Next

            Lista.Rows.Add(Fila)
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try

    End Sub

    Private Function DescargosDeLinea(ByVal Ciclo As Integer, ByVal Numero As Integer, ByVal Linea As Integer, Optional ByVal Excluir As Integer = NO_FILA) As Double
        'Devuelve la suma de las cantidades descargadas para una línea de orden
        Dim i As Integer = INT_CERO
        Dim dblTemp As Double
        Dim dblDes As Double
        Try
            dblTemp = vbEmpty
            For i = vbEmpty To dgInfoDescargo.Rows.Count - 1
                If dgInfoDescargo.Rows(i).Cells("colAno").Value = Ciclo And
                   dgInfoDescargo.Rows(i).Cells("colNumero").Value = Numero And
                   dgInfoDescargo.Rows(i).Cells("colLine").Value = Linea Then
                    dblDes = dgInfoDescargo.Rows(i).Cells("colDescargado").Value

                    'If dgInfoDescargo.Rows(i).Cells("colID").Value = Excluir Then ' exluir = 1
                    '    'Misma línea, lo resta para incrementar el saldo
                    '    dblTemp = dblDes - dblTemp
                    'Else
                    'Otras líneas, sumar para disminuir el saldo
                    dblTemp = dblDes + dblTemp
                    'End If
                End If
            Next
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try


        'Devuelve el resultado
        Return dblTemp
    End Function

    '***************************************************************
    '***************************************************************

    ' PROCEDIMIENTOS PARA GUARDAR DOCUMENTOS DE INGRESO

    Private Sub GuardarEncabezadoPolizaImportacion(ByVal intNumPoliza As Integer)
        Dim cfun As New clsFunciones
        Dim logResultado As Boolean = True
        Dim chdr As New clsDcmtos_HDR

        Try
            chdr.CONEXION = strConexion

            chdr.HDOC_SIS_EMP = Sesion.IdEmpresa
            chdr.HDOC_DOC_CAT = 180
            chdr.HDOC_DOC_ANO = cfun.AñoMySQL
            chdr.HDOC_DOC_NUM = intNumPoliza
            chdr.HDoc_Doc_Fec_NET = dtpEncabezado.Text

            chdr.HDOC_DOC_STATUS = 1
            chdr.HDOC_EMP_COD = celdaIDProveedores.Text
            chdr.HDOC_EMP_NOM = CeldaCliente.Text

            chdr.HDOC_EMP_DIR = "N/A"
            chdr.HDOC_EMP_PER = "N/A"
            chdr.HDOC_EMP_TEL = "N/A"
            chdr.HDOC_EMP_NIT = celdaNit.Text
            chdr.HDOC_DOC_TC = CeldaTasa.Text
            chdr.HDOC_DOC_MON = lblIDMoneda.Text

            chdr.HDOC_DR1_NUM = celdaReferencia.Text
            chdr.HDOC_DR2_NUM = "N/A"   'Ref.1
            chdr.HDOC_RF2_TXT = "N/A"   'Ref.2
            chdr.HDOC_ANT_COM = celdaTipoIngreso.Text

            chdr.HDOC_USUARIO = Sesion.idUsuario

            'If Me.Tag = "Mod" Then
            '    If chdr.Actualizar() = False Then
            '        MsgBox(chdr.MERROR.ToString & "Document could Not be updated", MsgBoxStyle.Critical)
            '    End If
            'ElseIf Me.Tag = "Nuevo" Then
            If chdr.Guardar() = False Then
                MsgBox(chdr.MERROR.ToString & "Document could Not be saved", MsgBoxStyle.Critical)
            End If
            'End If

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Function GuardarDetallePolizaImportacion(ByVal intNumPoliza As Integer)
        Dim clsDTL As New clsDcmtos_DTL
        Dim logResultado As Boolean = True
        Dim i As Integer = INT_CERO

        clsDTL.CONEXION = strConexion

        Try
            For i = 0 To dgDetalle.Rows.Count - 1
                clsDTL.DDOC_SIS_EMP = Sesion.IdEmpresa
                clsDTL.DDOC_DOC_CAT = 180
                clsDTL.DDOC_DOC_ANO = CeldaAño.Text
                clsDTL.DDOC_DOC_NUM = intNumPoliza
                clsDTL.DDOC_DOC_LIN = dgDetalle.Rows(i).Cells("colLinea").Value

                clsDTL.DDOC_PRD_COD = dgDetalle.Rows(i).Cells("colCodigo").Value
                clsDTL.DDOC_PRD_PNR = "N/A"
                clsDTL.DDOC_PRD_DES = dgDetalle.Rows(i).Cells("colDescripcion").Value
                clsDTL.DDOC_PRD_UM = dgDetalle.Rows(i).Cells("colIdMedida").Value

                clsDTL.DDOC_PRD_PUQ = dgDetalle.Rows(i).Cells("colPrecio").Value    'Precio/u
                clsDTL.DDOC_PRD_DSP = 0                                             'Descuento
                clsDTL.DDOC_PRD_DSQ = 0                                             'Monto(Desc)
                clsDTL.DDOC_PRD_NET = dgDetalle.Rows(i).Cells("colPrecio").Value    'Precio Neto
                clsDTL.DDOC_PRD_QTY = dgDetalle.Rows(i).Cells("colCantidad").Value  'Cantidad

                clsDTL.DDOC_PRD_FOB = dgDetalle.Rows(i).Cells("colPrecio").Value    'Valor FOB
                clsDTL.DDOC_PRD_CIF = dgDetalle.Rows(i).Cells("colPrecio").Value    'Valor CIF
                clsDTL.DDOC_RF1_DBL = dgDetalle.Rows(i).Cells("colTotal").Value     'Total

                clsDTL.DDOC_RF2_NUM = 0
                clsDTL.DDOC_RF2_DBL = 0
                clsDTL.DDOC_RF3_NUM = 0
                clsDTL.DDOC_RF3_DBL = dgDetalle.Rows(i).Cells("colPrecio").Value ' Valor Aduanal

                'If dgFacturas.Rows(i).Cells("colAgregar").Value = 1 Then
                '    If clsDTL.Actualizar() = False Then
                '        MsgBox(clsDTL.MERROR.ToString & "Could Not update the document", MsgBoxStyle.Critical)
                '    End If
                'ElseIf dgFacturas.Rows(i).Cells("colAgregar").Value = 0 Then
                If clsDTL.Guardar() = False Then
                    MsgBox(clsDTL.MERROR.ToString & "Could Not save the document", MsgBoxStyle.Critical)
                End If
                'ElseIf dgFacturas.Rows(i).Cells("colAgregar").Value = 2 Then
                '    If clsDTL.Borrar = False Then
                '        MsgBox(clsDTL.MERROR.ToString & "Could Not save the document", MsgBoxStyle.Critical)
                '    End If
                'End If
            Next

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        Return logResultado
    End Function


    Private Function GuardarDescargosPolizaImportacion(ByVal intNumPoliza As Integer, ByVal intDatosPoliza As Integer)
        'Guarda el descargo para la línea de detalle actual
        Dim DTPRO As New clsDcmtos_DTL_Pro
        Dim logResultado As Boolean = True
        Dim i As Integer = INT_CERO
        DTPRO.CONEXION = strConexion
        Try
            For i = 0 To dgDetalle.Rows.Count - 1
                DTPRO.PDOC_SIS_EMP = Sesion.IdEmpresa

                'Documento a ser descargado
                DTPRO.PDOC_PAR_CAT = 55
                DTPRO.PDOC_PAR_ANO = Val(CeldaAño.Text)
                DTPRO.PDOC_PAR_NUM = intDatosPoliza
                DTPRO.PDOC_PAR_LIN = dgDetalle.Rows(i).Cells("colLinea").Value

                'Referencia al documento actual
                DTPRO.PDOC_CHI_CAT = 180
                DTPRO.PDOC_CHI_ANO = Val(CeldaAño.Text)
                DTPRO.PDOC_CHI_NUM = intNumPoliza
                If Me.Tag = "nuevo" Then
                    DTPRO.PDOC_CHI_LIN = i + 1
                Else
                    DTPRO.PDOC_CHI_LIN = dgDetalle.Rows(i).Cells("colLinea").Value
                End If
                DTPRO.PDOC_PROV_COD = Val(celdaIDProveedores.Text)

                'Referencia al producto y despacho
                DTPRO.PDOC_PRD_COD = dgDetalle.Rows(i).Cells("colCodigo").Value
                DTPRO.PDOC_PRD_PNR = "N/A"
                DTPRO.PDOC_DR1_NUM = "0"
                DTPRO.PDOC_DR2_NUM = "0"

                DTPRO.PDOC_PRD_NET = dgDetalle.Rows(i).Cells("colprecio").Value
                DTPRO.PDOC_QTY_ORD = dgDetalle.Rows(i).Cells("colCantidad").Value

                DTPRO.PDOC_QTY_PRO = dgDetalle.Rows(i).Cells("colCantidad").Value

                'If dgFacturas.Rows(i).Cells("colAgregar").Value = 1 Then
                '    If DTPRO.Actualizar() = False Then
                '        MsgBox(DTPRO.MERROR.ToString & "Could Not update the document", MsgBoxStyle.Critical)
                '    End If
                'ElseIf dgFacturas.Rows(i).Cells("colAgregar").Value = 0 Then
                If DTPRO.Guardar() = False Then
                    MsgBox(DTPRO.MERROR.ToString & "Could Not save the document", MsgBoxStyle.Critical)
                End If
                'ElseIf dgFacturas.Rows(i).Cells("colAgregar").Value = 2 Then
                '    If DTPRO.Borrar = False Then
                '        MsgBox(DTPRO.MERROR.ToString & "Could Not save the document", MsgBoxStyle.Critical)
                '    End If
                'End If
            Next
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Function

    Private Sub GuardarDECPolizaImportacion(ByVal intNumPoliza As Integer)
        Dim dec As New Tablas.TDCMTOS_DEC
        Dim i As Integer = INT_CERO

        dec.CONEXION = strConexion

        For i = 0 To dgDetalle.Rows.Count - 1
            dec.EDOC_SIS_EMP = Sesion.IdEmpresa
            dec.EDOC_DOC_CAT = 180
            dec.EDOC_DOC_ANO = CeldaAño.Text
            dec.EDOC_DOC_NUM = intNumPoliza
            dec.EDOC_DOC_LIN = dgDetalle.Rows(i).Cells("colLinea").Value

            If dec.PINSERT = False Then
                MsgBox(dec.MERROR.ToString & "Could Not save the document", MsgBoxStyle.Critical)
            End If
        Next

    End Sub

    'INGRESO A BODEGA
    Private Sub GuardarEncabezadoIngresoBodega(ByVal intNumIngreso As Integer)
        Dim chdr As New clsDcmtos_HDR
        Try
            chdr.CONEXION = strConexion

            chdr.HDOC_SIS_EMP = Sesion.IdEmpresa
            chdr.HDOC_DOC_CAT = 47
            chdr.HDOC_DOC_ANO = CeldaAño.Text
            chdr.HDOC_DOC_NUM = intNumIngreso
            chdr.HDoc_Doc_Fec_NET = Now().ToString(FORMATO_MYSQL)
            chdr.HDOC_EMP_COD = celdaIDProveedores.Text
            chdr.HDOC_EMP_NOM = CeldaCliente.Text
            chdr.HDOC_EMP_DIR = CeldaDireccion.Text
            chdr.HDOC_EMP_NIT = celdaNit.Text
            chdr.HDOC_EMP_TEL = "N/A"
            chdr.HDOC_DR1_NUM = celdaReferencia.Text

            chdr.HDOC_DOC_MON = lblIDMoneda.Text
            chdr.HDOC_DOC_TC = CeldaTasa.Text

            chdr.HDOC_DR1_CAT = 0

            chdr.HDOC_USUARIO = Sesion.Usuario
            chdr.HDOC_ANT_COM = celdaTipoIngreso.Text

            'If Me.Tag = "Mod" Then
            '    If chdr.Actualizar() = False Then
            '        MsgBox(chdr.MERROR.ToString & "Could Not update the document", MsgBoxStyle.Critical)
            '    End If
            'Else
            If chdr.Guardar() = False Then
                MsgBox(chdr.MERROR.ToString & "Could Not save the document", MsgBoxStyle.Critical)
            End If
            'End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub


    Private Sub GuardarDescargosIngresoBodega(ByVal intNumIngreso As Integer, ByVal intNumPolizaImportacion As Integer)
        'Guarda el descargo para la línea de detalle actual
        Dim DTPRO As New clsDcmtos_DTL_Pro
        Dim logResultado As Boolean = True
        DTPRO.CONEXION = strConexion
        Dim i As Integer = INT_CERO

        Try
            For i = INT_CERO To dgDetalle.Rows.Count - 1
                DTPRO.PDOC_SIS_EMP = Sesion.IdEmpresa

                'Documento a ser descargado
                DTPRO.PDOC_PAR_CAT = 180
                DTPRO.PDOC_PAR_ANO = Val(CeldaAño.Text)
                DTPRO.PDOC_PAR_NUM = intNumPolizaImportacion
                DTPRO.PDOC_PAR_LIN = dgDetalle.Rows(i).Cells("colLinea").Value

                'Referencia al documento actual
                DTPRO.PDOC_CHI_CAT = 47
                DTPRO.PDOC_CHI_ANO = CeldaAño.Text
                DTPRO.PDOC_CHI_NUM = intNumIngreso
                DTPRO.PDOC_CHI_LIN = dgDetalle.Rows(i).Cells("colLinea").Value

                DTPRO.PDOC_PROV_COD = celdaIDProveedores.Text

                'Referencia al producto y despacho
                DTPRO.PDOC_PRD_COD = dgDetalle.Rows(i).Cells("colCodigo").Value
                DTPRO.PDOC_PRD_PNR = "N/A"
                DTPRO.PDOC_DR1_NUM = "0"
                DTPRO.PDOC_DR2_NUM = "0"

                DTPRO.PDOC_PRD_NET = dgDetalle.Rows(i).Cells("colPrecio").Value
                DTPRO.PDOC_QTY_ORD = dgDetalle.Rows(i).Cells("colCantidad").Value
                DTPRO.PDOC_QTY_PRO = dgDetalle.Rows(i).Cells("colCantidad").Value

                'If dgFacturas.Rows(i).Cells("colAgregar").Value = 1 Then
                '    If DTPRO.Actualizar() = False Then
                '        MsgBox(DTPRO.MERROR.ToString & "Could not update the document", MsgBoxStyle.Critical)
                '    End If
                'ElseIf dgFacturas.Rows(i).Cells("colAgregar").Value = 0 Then
                If DTPRO.Guardar() = False Then
                    MsgBox(DTPRO.MERROR.ToString & "Could not save the document", MsgBoxStyle.Critical)
                End If
                'ElseIf dgFacturas.Rows(i).Cells("colAgregar").Value = 2 Then
                '    If DTPRO.Borrar = False Then
                '        MsgBox(DTPRO.MERROR.ToString & "Could not save the document", MsgBoxStyle.Critical)
                '    End If
                'End If

            Next
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub GuardarDetalleIngresoBodega(ByVal intNumIngreso As Integer)
        Dim logResultado As Boolean = True
        Dim Dtl As New clsDcmtos_DTL
        Dtl.CONEXION = strConexion
        Dim j As Integer = 0

        Try
            For i As Integer = 0 To dgDetalle.Rows.Count - 1
                Dtl.DDOC_SIS_EMP = Sesion.IdEmpresa
                Dtl.DDOC_DOC_CAT = 47
                Dtl.DDOC_DOC_ANO = CeldaAño.Text
                Dtl.DDOC_DOC_NUM = intNumIngreso

                Dtl.DDOC_DOC_LIN = i + 1

                Dtl.DDOC_PRD_COD = dgDetalle.Rows(i).Cells("colCodigo").Value
                Dtl.DDOC_PRD_PNR = "N/A"
                Dtl.DDOC_PRD_UM = dgDetalle.Rows(i).Cells("colIdMedida").Value
                Dtl.DDOC_PRD_DES = dgDetalle.Rows(i).Cells("colDescripcion").Value

                Dtl.DDOC_PRD_PUQ = CDbl(dgDetalle.Rows(i).Cells("colPrecio").Value)
                Dtl.DDOC_PRD_NET = CDbl(dgDetalle.Rows(i).Cells("colPrecio").Value)
                Dtl.DDOC_PRD_QTY = CDbl(dgDetalle.Rows(i).Cells("colCantidad").Value)

                Dtl.DDOC_RF1_TXT = STR_VACIO
                Dtl.DDOC_RF1_COD = CDbl(dgDetalle.Rows(i).Cells("colCodigo").Value)
                Dtl.DDOC_RF1_DBL = CDbl(dgDetalle.Rows(i).Cells("colTotal").Value)

                Dtl.DDOC_RF2_COD = "N/A"
                Dtl.DDOC_RF2_TXT = "N/A"
                Dtl.DDOC_RF3_TXT = "N/A"

                'If dgFacturas.Rows(i).Cells("colAgregar").Value = 1 Then
                '    If Dtl.Actualizar() = False Then
                '        MsgBox(Dtl.MERROR.ToString & "Could not update the document", MsgBoxStyle.Critical)
                '    End If
                'ElseIf dgFacturas.Rows(i).Cells("colAgregar").Value = 0 Then
                If Dtl.Guardar() = False Then
                    MsgBox(Dtl.MERROR.ToString & "Could not save the document", MsgBoxStyle.Critical)
                End If
                'ElseIf dgFacturas.Rows(i).Cells("colAgregar").Value = 2 Then
                '    If Dtl.Borrar = False Then
                '        MsgBox(Dtl.MERROR.ToString & "Could not save the document", MsgBoxStyle.Critical)
                '    End If
                'End If
            Next

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub GuardarBultoDeIngreso(ByVal intNumIngreso As Integer)
        Dim logResultado As Boolean = True
        'Dim box As New Tablas.TDCMTOS_DTL_BOX
        'box.CONEXION = strConexion
        Dim strsql As String = STR_VACIO
        Dim COM As MySqlCommand


        Try
            For i As Integer = 0 To dgDetalle.Rows.Count - 1

                strsql = " Insert Into Dcmtos_DTL_Box (BDoc_Sis_Emp,BDoc_Doc_Cat,BDoc_Doc_Ano,BDoc_Doc_Num,BDoc_Doc_Lin,BDoc_Box_Lin,BDoc_Box_Cod,BDoc_Box_QTY) "
                strsql &= "      VALUES (" & Sesion.IdEmpresa & ", 47, " & CeldaAño.Text & "," & intNumIngreso & "," & dgDetalle.Rows(i).Cells("colLinea").Value & ",1,1,1) "

                MyCnn.CONECTAR = strConexion
                COM = New MySqlCommand(strsql, CON)
                COM.ExecuteNonQuery()

                'box.BDOC_SIS_EMP = Sesion.IdEmpresa
                'box.BDOC_DOC_CAT = 47
                'box.BDOC_DOC_ANO = CeldaAño.Text
                'box.BDOC_DOC_NUM = intNumIngreso

                'box.BDOC_DOC_LIN = i + 1
                'box.BDOC_BOX_LIN = 1

                'If box.PINSERT() = False Then
                '    MsgBox(box.MERROR.ToString & "Could not save the document", MsgBoxStyle.Critical)
                'End If

            Next

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub
    Private Function Dependecias() As Integer
        Dim intValidacion As Integer
        Dim COM As MySqlCommand
        Dim conec As MySqlConnection
        Dim strSQL As String = STR_VACIO
        Try
            strSQL = "  SELECT COUNT(d.PDoc_Chi_Num) from Dcmtos_DTL_Pro p "
            strSQL &= "    	left join Dcmtos_DTL_Pro d on d.PDoc_Sis_Emp= p.PDoc_Sis_Emp and d.PDoc_Par_Cat = p.PDoc_Chi_Cat and d.PDoc_Par_Ano = p.PDoc_Chi_Ano and d.PDoc_Par_Num = p.PDoc_Chi_Num and d.PDoc_Par_Lin = p.PDoc_Chi_Lin "
            strSQL &= "         where p.PDoc_Sis_Emp = {empresa} and p.PDoc_Par_Cat = 127 and p.PDoc_Par_Ano = {anio} and p.PDoc_Par_Num= {numero}  "
            strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
            strSQL = Replace(strSQL, "{anio}", CeldaAño.Text)
            strSQL = Replace(strSQL, "{numero}", CeldaNumero.Text)
            conec = New MySqlConnection(strConexion)
            conec.Open()
            COM = New MySqlCommand(strSQL, conec)
            Using conec
                intValidacion = COM.ExecuteScalar
                COM.Dispose()
                COM = Nothing
                conec.Close()
                conec.Dispose()
                conec = Nothing
                System.GC.Collect()
            End Using
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        Return intValidacion
    End Function

    Private Function DependenciasDeLineas(ByVal Lin As Integer)
        Dim intValidacion As Integer
        Dim COM As MySqlCommand
        Dim conec As MySqlConnection
        Dim strSQL As String = STR_VACIO
        Try
            strSQL = "  SELECT count(d.PDoc_Chi_Lin) from Dcmtos_DTL_Pro p "
            strSQL &= "    	left join Dcmtos_DTL_Pro d on d.PDoc_Sis_Emp= p.PDoc_Sis_Emp and d.PDoc_Par_Cat = p.PDoc_Chi_Cat and d.PDoc_Par_Ano = p.PDoc_Chi_Ano and d.PDoc_Par_Num = p.PDoc_Chi_Num and d.PDoc_Par_Lin = p.PDoc_Chi_Lin "
            strSQL &= "         where p.PDoc_Sis_Emp = {empresa} and p.PDoc_Par_Cat = 127 and p.PDoc_Par_Ano = {anio} and p.PDoc_Par_Num= {numero}  AND p.PDoc_Par_Lin= {linea} "
            strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
            strSQL = Replace(strSQL, "{anio}", CeldaAño.Text)
            strSQL = Replace(strSQL, "{numero}", CeldaNumero.Text)
            strSQL = Replace(strSQL, "{linea}", Lin)
            conec = New MySqlConnection(strConexion)
            conec.Open()
            COM = New MySqlCommand(strSQL, conec)
            Using conec
                intValidacion = COM.ExecuteScalar
                COM.Dispose()
                COM = Nothing
                conec.Close()
                conec.Dispose()
                conec = Nothing
                System.GC.Collect()
            End Using
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        Return intValidacion
    End Function
    'Borrar Confirmacion
    Public Function BorrarEncabezadoConfirmacion() As Boolean
        Dim logGuardar As Boolean
        Dim clsHDR As New clsDcmtos_HDR
        Try
            clsHDR.CONEXION = strConexion
            clsHDR.HDOC_SIS_EMP = Sesion.IdEmpresa
            clsHDR.HDOC_DOC_NUM = CeldaNumero.Text
            clsHDR.HDOC_DOC_CAT = 127
            clsHDR.HDOC_DOC_ANO = CeldaAño.Text
            If LogBorrar = True Then
                If clsHDR.Borrar = False Then
                    MsgBox(clsHDR.MERROR.ToString & "Could not delete the document", MsgBoxStyle.Critical)
                    Return False
                Else
                    logGuardar = True
                End If
            End If



        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        Return logGuardar
    End Function
    'Borrar Datos 
    Public Function BorrarEncabezadoDatosPoliza(ByVal anio As Integer, ByVal numero As Integer) As Boolean
        Dim logGuardar As Boolean
        Try
            Dim hdr As New clsDcmtos_HDR
            hdr.CONEXION = strConexion
            hdr.HDOC_SIS_EMP = Sesion.IdEmpresa
            hdr.HDOC_DOC_CAT = 55
            hdr.HDOC_DOC_ANO = anio
            hdr.HDOC_DOC_NUM = numero
            hdr.Borrar()
            logGuardar = True
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        Return logGuardar
    End Function
    'Borrar Detalle Confirmacion  
    Private Function BorrarDetalleConfirmacion() As Boolean
        Dim logGuardar As Boolean
        Dim Dtl As New clsDcmtos_DTL
        Try
            Dtl.CONEXION = strConexion
            For i = 0 To dgDetalle.Rows.Count - 1
                Dtl.DDOC_SIS_EMP = Sesion.IdEmpresa
                Dtl.DDOC_DOC_CAT = 127
                Dtl.DDOC_DOC_ANO = CeldaAño.Text
                Dtl.DDOC_DOC_NUM = CeldaNumero.Text
                Dtl.DDOC_DOC_LIN = dgDetalle.Rows(i).Cells("colLinea").Value
                If LogBorrar = True Then
                    If Dtl.Borrar = False Then
                        MsgBox(Dtl.MERROR.ToString & "Could not delete the document", MsgBoxStyle.Critical)
                        Return False
                    Else
                        logGuardar = True
                    End If
                End If
            Next
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        Return logGuardar
    End Function
    'Borrar Detalle Datos Poliza
    Private Function BorrarDetalleDatosPoliza(ByVal anio As Integer, ByVal numero As Integer) As Boolean
        Dim logGuardar As Boolean
        Dim strSQL As String = STR_VACIO
        Try
            strSQL = "DDoc_Sis_Emp = {emp} AND DDoc_Doc_Cat = {cat} AND DDoc_Doc_Ano = {anio} AND DDoc_Doc_Num = {num} "
            strSQL = Replace(strSQL, "{emp}", Sesion.IdEmpresa)
            strSQL = Replace(strSQL, "{cat}", 55)
            strSQL = Replace(strSQL, "{anio}", anio)
            strSQL = Replace(strSQL, "{num}", numero)

            Dim dtl As New clsDcmtos_DTL
            dtl.CONEXION = strConexion
            dtl.Borrar(strSQL)

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        Return logGuardar
    End Function
    ' Borrar ACC Confirmacion
    Private Function BorrarAccConfirmacion() As Boolean
        Dim logGuardar As Boolean
        Dim strSQL As String = STR_VACIO
        Try
            strSQL = "ADoc_Sis_Emp = {emp} AND ADoc_Doc_Cat = {cat} AND ADoc_Doc_Ano = {anio} AND ADoc_Doc_Num = {num} "
            strSQL = Replace(strSQL, "{emp}", Sesion.IdEmpresa)
            strSQL = Replace(strSQL, "{cat}", 127)
            strSQL = Replace(strSQL, "{anio}", CeldaAño.Text)
            strSQL = Replace(strSQL, "{num}", CeldaNumero.Text)

            Dim acc As New Tablas.TDCMTOS_ACC
            acc.CONEXION = strConexion
            acc.PDELETE(strSQL)

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        Return logGuardar
    End Function
    'Borrar Acc Datos Poliza
    Private Function BorrarAccDatosPoliza(ByVal anio As Integer, ByVal numero As Integer) As Boolean
        Dim logGuardar As Boolean
        Dim strSQL As String = STR_VACIO
        Try
            strSQL = "ADoc_Sis_Emp = {emp} AND ADoc_Doc_Cat = {cat} AND ADoc_Doc_Ano = {anio} AND ADoc_Doc_Num = {num} "
            strSQL = Replace(strSQL, "{emp}", Sesion.IdEmpresa)
            strSQL = Replace(strSQL, "{cat}", 55)
            strSQL = Replace(strSQL, "{anio}", anio)
            strSQL = Replace(strSQL, "{num}", numero)

            Dim acc As New Tablas.TDCMTOS_ACC
            acc.CONEXION = strConexion
            acc.PDELETE(strSQL)

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        Return logGuardar
    End Function

    'Borrar Descargos 

    Private Function BorrarDescargoPO()
        Dim logGuardar As Boolean
        Dim strSQL As String = STR_VACIO
        Try
            strSQL = "PDoc_Sis_Emp = {emp} AND PDoc_Chi_Cat = {cat} AND PDoc_Chi_Ano = {anio} AND PDoc_Chi_Num = {num} "
            strSQL = Replace(strSQL, "{emp}", Sesion.IdEmpresa)
            strSQL = Replace(strSQL, "{cat}", 127)
            strSQL = Replace(strSQL, "{anio}", CeldaAño.Text)
            strSQL = Replace(strSQL, "{num}", CeldaNumero.Text)

            Dim pro As New clsDcmtos_DTL_Pro
            pro.CONEXION = strConexion
            pro.Borrar(strSQL)

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        Return logGuardar
    End Function
    Private Function BorrarDescargo() As Boolean
        Dim logGuardar As Boolean
        Dim strSQL As String = STR_VACIO
        Try
            strSQL = "PDoc_Sis_Emp = {emp} AND PDoc_Par_Cat = {cat} AND PDoc_Par_Ano = {anio} AND PDoc_Par_Num = {num} "
            strSQL = Replace(strSQL, "{emp}", Sesion.IdEmpresa)
            strSQL = Replace(strSQL, "{cat}", 127)
            strSQL = Replace(strSQL, "{anio}", CeldaAño.Text)
            strSQL = Replace(strSQL, "{num}", CeldaNumero.Text)

            Dim pro As New clsDcmtos_DTL_Pro
            pro.CONEXION = strConexion
            pro.Borrar(strSQL)

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        Return logGuardar
    End Function

    'Mostrar Detalle desde lista principal

    Private Sub MostrarDetalle(ByVal intaño As Integer, ByVal intnumero As Integer)
        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader
        Dim strSQL As String = STR_VACIO
        Dim strFila As String = STR_VACIO
        Dim cone As New MySqlConnection
        cone.ConnectionString = strConexion
        cone.Open()
        Try
            strSQL = SQLMostrarInfoLPrincipal(intaño, intnumero)
            COM = New MySqlCommand(strSQL, cone)
            REA = COM.ExecuteReader
            Do While REA.Read
                strFila &= vbNewLine & REA.GetInt32("Linea") & " )     " & REA.GetDouble("Cantidad").ToString(FORMATO_MONEDA) & vbTab & REA.GetString("Medida") & vbTab & REA.GetString("Descripcion")
            Loop
            celdaLineas.Text = strFila
        Catch ex As Exception
            MsgBox(ex.ToString)
        Finally
            cone.Close()
            cone.Dispose()
            cone = Nothing
        End Try
    End Sub

    Private Function SQLMostrarInfoLPrincipal(ByVal intaño As Integer, ByVal intnumero As Integer)

        Dim strsql As String = STR_VACIO

        strsql = " SELECT d.DDoc_Doc_Lin Linea, a.art_DCorta Descripcion, d.DDoc_Prd_QTY Cantidad, IFNULL(c.cat_clave,'N/A') Medida"
        strsql &= "     FROM Dcmtos_DTL d"
        strsql &= "      LEFT JOIN Inventarios i ON i.inv_sisemp = d.DDoc_Sis_Emp AND i.inv_numero= d.DDoc_Prd_Cod"
        strsql &= "     LEFT JOIN Articulos a ON a.art_sisemp = i.inv_sisemp AND a.art_codigo = i.inv_artcodigo"
        strsql &= "    LEFT JOIN Catalogos c ON c.cat_clase = 'Medidas' AND c.cat_num = d.DDoc_Prd_UM "
        strsql &= "   WHERE d.DDoc_Sis_Emp = {empresa} AND d.DDoc_Doc_Cat = 127 AND d.DDoc_Doc_Ano = {año} AND d.DDoc_Doc_Num = {numero}"
        strsql &= "  ORDER BY d.DDoc_Doc_Lin"

        strsql = Replace(strsql, "{empresa}", Sesion.IdEmpresa)
        strsql = Replace(strsql, "{año}", intaño)
        strsql = Replace(strsql, "{numero}", intnumero)
        Return strsql

    End Function

#End Region
#Region "Eventos"

    Private Sub frmConfirmacion_FormClosing(sender As Object, e As FormClosingEventArgs) Handles Me.FormClosing
        Try
            frmSPrincipal.BarraDeTareas1.QuitarFormulario(strKey)
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try

    End Sub

    Private Sub frmConfirmacion_Load(sender As Object, e As EventArgs) Handles Me.Load
        If (Sesion.IdEmpresa = 15) Or (Sesion.IdEmpresa = 18) Or (Sesion.IdEmpresa = 19) Then
            celdaTipoIng.Visible = True
        Else
            celdaTipoIng.Visible = True
        End If

        dtpInicio.Value = Today.AddMonths(NO_FILA)
        dtpFin.Value = Today
        Accessos()
        MostrarLista()

    End Sub

    Private Sub Encabezado1_ClickCerrar(sender As Object, click As Boolean) Handles Encabezado1.ClickCerrar
        If panelLista.Visible = True Then
            Me.Close()
            Fprincipal.BarraDeTareas1.QuitarFormulario(Key)
        Else
            MostrarLista()
        End If

    End Sub
    Private Function NuevaConfirmacion() As Integer
        Dim strSQL As String = STR_VACIO
        Dim conec As New MySqlConnection
        Dim COM As MySqlCommand
        Dim CodigoProyecto As Integer

        strSQL = " Select IFNULL(MAX(HDR.HDoc_Doc_Num),0)+1 NUMERO  "
        strSQL &= " FROM Dcmtos_HDR HDR"
        strSQL &= " WHERE HDR.HDoc_Sis_Emp = {empresa} And HDR.HDoc_Doc_Cat = {catalogo}  "

        strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
        strSQL = Replace(strSQL, "{catalogo}", 127)

        conec = New MySqlConnection(strConexion)
        conec.Open()
        COM = New MySqlCommand(strSQL, conec)
        CodigoProyecto = COM.ExecuteScalar
        conec.Close()
        conec.Dispose()
        conec = Nothing
        System.GC.Collect()
        Return CodigoProyecto
    End Function
    Private Function NuevaDatosPoliza() As Integer
        Dim strSQL As String = STR_VACIO
        Dim conec As New MySqlConnection
        Dim COM As MySqlCommand
        Dim CodigoProyecto As Integer

        strSQL = " Select IFNULL(MAX(HDR.HDoc_Doc_Num),0)+1 NUMERO  "
        strSQL &= " FROM Dcmtos_HDR HDR"
        strSQL &= " WHERE HDR.HDoc_Sis_Emp = {empresa} And HDR.HDoc_Doc_Cat = {catalogo}  "

        strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
        strSQL = Replace(strSQL, "{catalogo}", 55)

        conec = New MySqlConnection(strConexion)
        conec.Open()
        COM = New MySqlCommand(strSQL, conec)
        CodigoProyecto = COM.ExecuteScalar
        conec.Close()
        conec.Dispose()
        conec = Nothing
        System.GC.Collect()
        Return CodigoProyecto
    End Function
    Private Sub Encabezado1_ClickGuardar(sender As Object, click As Boolean) Handles Encabezado1.ClickGuardar

        Try
            If Me.Tag = "nuevo" And logInsertar = True Then
                If ComprobarDatos() Then
                    If CeldaNumero.Text = NO_FILA Then
                        CeldaNumero.Text = NuevaConfirmacion()
                    End If
                    If (CeldaNumero.Text > 0) Then
                        If GuardarEncabezado() = True Then
                            GuardarDocumentoDetalle()
                            GuardarDescargos()
                            Dim idDatosParaPoliza As Integer = 0

                            idDatosParaPoliza = NuevaDatosPoliza()

                            'Almacenar Datos para Poliza de Importacion
                            GuardarEncabezadoDatosPolizaImportacion(idDatosParaPoliza)
                            GuardarDocumentoDetalleDatosPolizaImporatcion(idDatosParaPoliza)
                            GuardarDescargosDatosPolizaImportacion(idDatosParaPoliza)

                            cfun.EscribirRegistro("TBL_DOCUMENTOS", clsFunciones.AccEnum.acAdd, Sesion.idUsuario, 127, CeldaAño.Text, CeldaNumero.Text)

                            MsgBox("The documnet has been saved", vbInformation)
                            If MsgBox("Do you want to close the Document?", vbYesNo, "Question") = vbYes Then
                                cfun.CargarLista(dgLista, SQLlista, False)
                                MostrarLista()
                            Else
                                Me.Tag = "Mod"
                                botonGastos.Enabled = True
                                InfoProducto(CeldaAño.Text, CeldaNumero.Text)
                                CargarListaDescargo(CeldaAño.Text, CeldaNumero.Text)
                                CalcularTotales()
                                botonGenerarIngreso.Enabled = True
                            End If
                        End If

                    End If
                Else
                    Exit Sub
                End If
            ElseIf Me.Tag = "Mod" And logEditar = True Then
                Dim verResultadoChi As Integer
                If ComprobarDatos() Then
                    GuardarEncabezado()
                    GuardarDocumentoDetalle()
                    GuardarDescargos()

                    verResultadoChi = VerificarChiNumDeConfirmacion()
                    If verResultadoChi > 0 Then
                        'Almacenar Datos para Poliza de Importacion
                        GuardarEncabezadoDatosPolizaImportacion(verResultadoChi)
                        GuardarDocumentoDetalleDatosPolizaImporatcion(verResultadoChi)
                        GuardarDescargosDatosPolizaImportacion(verResultadoChi)
                    End If

                    cfun.EscribirRegistro("TBL_DOCUMENTOS", clsFunciones.AccEnum.acUpdate, Sesion.idUsuario, 127, CeldaAño.Text, CeldaNumero.Text)

                    MsgBox("The documnet has been Updated", vbInformation)
                    If MsgBox("Do you want to close the Document?", vbYesNo, "Question") = vbYes Then
                        cfun.CargarLista(dgLista, SQLlista, False)
                        MostrarLista()
                    Else
                        Me.Tag = "Mod"
                        InfoProducto(CeldaAño.Text, CeldaNumero.Text)
                        CargarListaDescargo(CeldaAño.Text, CeldaNumero.Text)
                        CalcularTotales()
                    End If
                Else
                    Exit Sub
                End If

            Else
                MsgBox("You Don´t have access To update ", vbExclamation, "Notice")
                Exit Sub
            End If

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try

    End Sub

    Private Function VerificarChiNumDeConfirmacion() As Integer
        Dim resultado As Integer
        Dim strSQL As String
        Dim COM As MySqlCommand

        strSQL = " Select p.PDoc_Chi_Num "
        strSQL &= "   FROM Dcmtos_DTL_Pro p "
        strSQL &= "        WHERE p.PDoc_Sis_Emp = {empresa} And p.PDoc_Par_Cat = 127 And p.PDoc_Par_Ano = {anio} And p.PDoc_Par_Num = {numero} And p.PDoc_Chi_Cat = 55 "
        strSQL &= "            LIMIT 1 "

        strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
        strSQL = Replace(strSQL, "{anio}", CeldaAño.Text)
        strSQL = Replace(strSQL, "{numero}", CeldaNumero.Text)

        MyCnn.CONECTAR = strConexion
        COM = New MySqlCommand(strSQL, CON)
        resultado = COM.ExecuteScalar

        Return resultado
    End Function


    Private Function VerificarChiAnioDeConfirmacion() As Integer
        Dim resultado As Integer
        Dim strSQL As String
        Dim COM As MySqlCommand

        strSQL = " Select p.PDoc_Chi_Ano "
        strSQL &= "   FROM Dcmtos_DTL_Pro p "
        strSQL &= "        WHERE p.PDoc_Sis_Emp = {empresa} And p.PDoc_Par_Cat = 127 And p.PDoc_Par_Ano = {anio} And p.PDoc_Par_Num = {numero} And p.PDoc_Chi_Cat = 55 "
        strSQL &= "            LIMIT 1 "

        strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
        strSQL = Replace(strSQL, "{anio}", CeldaAño.Text)
        strSQL = Replace(strSQL, "{numero}", CeldaNumero.Text)

        MyCnn.CONECTAR = strConexion
        COM = New MySqlCommand(strSQL, CON)
        resultado = COM.ExecuteScalar

        Return resultado
    End Function
    Private Sub botonQuitar_Click(sender As Object, e As EventArgs) Handles botonQuitar.Click
        Dim Linea As Integer = 0
        If dgDetalle.SelectedRows.Count = 0 Then Exit Sub
        Try
            If DependenciasDeLineas(dgDetalle.CurrentRow.Cells("colLinea").Value) > 0 Then
                MsgBox("This line already has downloads, it cannot be deleted")
                Exit Sub
            End If
            'Dim strFila As String
            dgDetalle.CurrentRow.Cells(19).Value = 2
            Linea = dgDetalle.CurrentRow.Cells(2).Value
            dgDetalle.CurrentRow.Visible = False

            For i As Integer = 0 To dgInfoDescargo.Rows.Count - 1
                If dgInfoDescargo.Rows(i).Cells("colID").Value = Linea Then
                    dgInfoDescargo.Rows(i).Cells("colDescargar").Value = 0
                End If
            Next

        Catch ex As Exception
            '    MsgBox(ex.ToString)
        End Try
    End Sub


    Private Sub Encabezado1_ClickNuevo(sender As Object, click As Boolean) Handles Encabezado1.ClickNuevo

        Dim frm As New frmOption

        If logInsertar = True Then

            Reset()
            MostrarLista(False, True)

            Me.Tag = "nuevo"

            If (Sesion.IdEmpresa = 15) Or (Sesion.IdEmpresa = 18) Or (Sesion.IdEmpresa = 19) Then
                '0 Importacion
                '1 Produccion
                '2 Desperdicios
                '3 Materiales y Suministros
                frm.Titulo = " Kind of Document"
                frm.Mensaje = " Select a kind of Document "
                frm.Opciones = "Import|Packing|Waste"
                frm.ShowDialog(frmSPrincipal)
                If frm.DialogResult = System.Windows.Forms.DialogResult.OK Then
                    celdaTipoIngreso.Text = frm.Seleccion
                    PintarTipoIngreso()
                End If

            Else

                frm.Opciones = "Import Policy |" & "Return (Export)"
                frm.Titulo = "Type of statement"
                frm.ShowDialog(Me)
                If frm.DialogResult = System.Windows.Forms.DialogResult.OK Then
                    Select Case frm.Seleccion
                        Case 0
                            BarraTitulo1.CambiarTitulo("Import Policy")
                            intTipoDoc = 0

                        Case 1
                            intTipoDoc = 1
                            BarraTitulo1.CambiarTitulo("Refund (re-export)")
                    End Select

                End If
            End If
            CeldaAño.Text = cFunciones.AñoMySQL
            celdaEmpresa.Text = Sesion.IdEmpresa
            celdaCatalogo.Text = 127
            celdaUsuario.Text = Sesion.Usuario
            SQListaDocumentos(CeldaAño.Text, CeldaNumero.Text, 127)
            If (Sesion.IdEmpresa = 15) Or (Sesion.IdEmpresa = 9) Or (Sesion.IdEmpresa = 18) Or (Sesion.IdEmpresa = 19) Then
                botonGenerarIngreso.Visible = True
                botonGenerarIngreso.Enabled = False
            End If

            botonGastos.Enabled = False
        Else
            MsgBox("You Don't have access to create a New shipment confirmation", vbInformation)
        End If

    End Sub

    Private Sub dgLista_DoubleClick(sender As Object, e As EventArgs) Handles dgLista.DoubleClick
        Dim intID As Integer = NO_FILA
        Dim intAño As Integer = NO_FILA
        Dim cat As Integer = NO_FILA

        Try
            If dgLista.SelectedRows.Count = INT_CERO Then Exit Sub
            Me.Tag = "Mod"

            intID = dgLista.SelectedCells(0).Value
            intAño = dgLista.SelectedCells(5).Value
            CeldaAño.Text = intAño
            cat = 127
            Reset()
            intControl = 1
            'Seleccionar(intAño, intID)
            sqlEncabezado(dgLista.SelectedCells(0).Value, intAño)
            'Seleccionar(intAño, intID)
            MostrarLista(False)
            'Dim año As Integer
            'Dim numero As Integer
            SQListaDocumentos(intAño, intID, cat)
            InfoProducto(CeldaAño.Text, CeldaNumero.Text)
            CargarListaDescargo(CeldaAño.Text, CeldaNumero.Text)
            CalcularTotales()
            celdaEmpresa.Text = Sesion.IdEmpresa
            celdaCatalogo.Text = 127
            celdaUsuario.Text = Sesion.Usuario

            If Sesion.IdEmpresa = 9 Then
                botonGenerarIngreso.Visible = True
                VerificarDcmtosIngreso(intAño, intID)
                celdaTipoIng.Visible = True
            End If
            If (Sesion.IdEmpresa = 15) Or (Sesion.IdEmpresa = 18) Or (Sesion.IdEmpresa = 19) Then
                botonGastos.Enabled = False
            Else
                botonGastos.Enabled = True
            End If
            intControl = 0
            'insert = True
            'Re.Tag = "nuevo"
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub dgDocumentos_DoubleClick(sender As Object, e As EventArgs) Handles dgDocumentos.DoubleClick

        If Me.Tag = "Mod" Then
            Dim frm As New frmSubDocumentos
            Select Case dgDocumentos.CurrentCell.ColumnIndex
                Case 2
                    ' If dgDocumentos.SelectedCells(2).Value = "SI" Then
                    frm.SubDocumento = dgDocumentos.SelectedCells(0).Value

                    If dgDocumentos.SelectedCells(0).Value = "Doc_PFactura" Then
                        frm.Catalogo = 127
                        frm.Año = CInt(CeldaAño.Text)
                        frm.Numero = CInt(CeldaNumero.Text)
                        frm.Doc = "Doc_PFactura"
                    Else
                        frm.Catalogo = 55
                        frm.Año = VerificarChiAnioDeConfirmacion()
                        frm.Numero = VerificarChiNumDeConfirmacion()
                    End If

                    frm.PolizaImportacionActiva = checkPolizImportacion.Checked
                    frm.ShowDialog(Me)
                    'Else
                    '    frm.SubDocumento = dgDocumentos.SelectedCells(0).Value
                    '    frm.Año = CeldaAño.Text
                    '    frm.Numero = CeldaNumero.Text
                    '    frm.Catalogo = 127
                    '    frm.PolizaImportacionActiva = checkPolizImportacion.Checked
                    '    frm.Show()
                    'End If
            End Select
        Else
            MsgBox("Save the document first", vbInformation, "Notice")
        End If
    End Sub

    Private Sub botonMoneda_Click(sender As Object, e As EventArgs) Handles botonMoneda.Click

        Dim frm As New frmSeleccionar
        Dim strSQL As String = STR_VACIO
        Dim COM As MySqlCommand
        Dim conec As MySqlConnection
        Dim Cambio As Double

        Try
            frm.Titulo = "Currency"
            frm.FiltroText = " Enter The Currency To Filter"
            frm.Campos = " cat_num Code, cat_clave Currency"
            frm.Tabla = " Catalogos"
            frm.Filtro = " cat_clave "
            frm.Condicion = "cat_clase = 'monedas'"

            frm.ShowDialog(Me)
            If frm.DialogResult = System.Windows.Forms.DialogResult.OK Then
                lblIDMoneda.Text = frm.LLave
                CeldaMoneda.Text = frm.Dato
            End If

            strSQL = " SELECT cat_sist"
            strSQL &= "      FROM Catalogos"
            strSQL &= "          WHERE cat_clase = 'Monedas' AND cat_num = {Numero}"

            strSQL = Replace(strSQL, "{Numero}", frm.LLave)


            conec = New MySqlConnection(strConexion)
            conec.Open()
            COM = New MySqlCommand(strSQL, conec)
            Using conec
                Cambio = COM.ExecuteScalar
                COM.Dispose()
                COM = Nothing
                conec.Close()
                conec.Dispose()
                conec = Nothing
                System.GC.Collect()
            End Using

            CeldaTasa.Text = Cambio


        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try


    End Sub

    Private Sub botonAgrega_Click(sender As Object, e As EventArgs) Handles botonAgrega.Click
        Dim frm As New frmSeleccionar
        Dim strCondicion As String = STR_VACIO
        Dim strTabla As String = STR_VACIO
        strCondicion = "inv_sisemp = {empresa} AND inv_status = 'activo' AND inv_generico=0"
        strCondicion = Replace(strCondicion, "{empresa}", Sesion.IdEmpresa)
        strTabla = " Inventarios INNER JOIN Articulos ON art_sisemp = inv_sisemp AND art_codigo = inv_artcodigo LEFT JOIN Catalogos m ON m.cat_clase = 'Medidas' AND m.cat_num = inv_UMcmpra LEFT JOIN Catalogos p ON p.cat_clase = 'Paises' AND p.cat_num = inv_lugarfab LEFT JOIN Proveedores pro ON pro_sisemp = inv_sisemp AND pro_codigo = inv_provcod"

        Try
            frm.Titulo = "List of Products"
            frm.FiltroText = "Enter the Product Name to filter"
            frm.Campos = "inv_numero Inventory, TRIM(CONCAT(art_DLarga, ' ', IFNULL(p.cat_clave,''))) Description, m.cat_num CodeUnit, m.cat_clave Unit,inv_costo Cost, inv_prodlote Lot,  inv_artcodigo Product, IFNULL(pro.pro_proveedor,'')Manufacturer, IFNULL(p.cat_clave,'')Origin, inv_partnum Part, inv_prodano Year, inv_prodsem Week"
            frm.Tabla = strTabla
            frm.Condicion = strCondicion
            If (Sesion.IdEmpresa = 15) Or (Sesion.IdEmpresa = 18) Or (Sesion.IdEmpresa = 19) Then
                frm.Filtro = " inv_prodlote "
            Else
                frm.Filtro = " inv_numero "
            End If
            frm.Ordenamiento = " inv_numero"
            frm.TipoOrdenamiento = ""
            frm.Limite = 150

            frm.ShowDialog(Me)
            If frm.DialogResult = System.Windows.Forms.DialogResult.OK Then

                Dim strFila As String = STR_VACIO
                Dim linea As Integer = 0
                For i As Integer = 0 To dgDetalle.Rows.Count - 1
                    linea = dgDetalle.Rows(i).Cells("colLinea").Value
                Next
                strFila = CeldaAño.Text & "|" & frm.LLave & "|" & linea + 1 & "|" & frm.LLave & "|" & frm.Dato & "|" & frm.Dato2 & "|" & frm.Dato3 & "|" & frm.Dato4 & "|" & 1 & "|" & frm.Dato4 * 1 & "|" & 0 & "|" & frm.LLave & "|" & "" & "|" & linea + 1 & "|" & "|" & "|" & "|" & INT_CERO & "|" & "|" & 1 & "|" & 0


                cFunciones.AgregarFila(dgDetalle, strFila)

            End If

            For j As Integer = 0 To dgDetalle.Rows.Count - 1
                dgDetalle.Rows(j).Cells("colDescripcion").Style.BackColor = Color.Beige
                dgDetalle.Rows(j).Cells("colMedida").Style.BackColor = Color.Beige
                dgDetalle.Rows(j).Cells("colTotal").Style.BackColor = Color.Beige
            Next

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try


    End Sub

    Private Sub botonInfo_Click(sender As Object, e As EventArgs) Handles botonInfo.Click
        MostrarOrdenesPorLinea()

    End Sub

    Private Sub btnFiltro_Click(sender As Object, e As EventArgs) Handles btnFiltro.Click
        Dim logCancelar As Boolean

        If CDate(dtpInicio.Value) > CDate(dtpFin.Value) Then
            MsgBox("The start date may not exceed the final date", vbExclamation, "Notice")
            logCancelar = True
        End If
        If Not (logCancelar) Then

            'Procedimiento para cargar panel dgLista
            cfun.CargarLista(dgLista, SQLlista, False)
        End If
    End Sub

    Private Sub dgDetalle_CellEndEdit(sender As Object, e As DataGridViewCellEventArgs) Handles dgDetalle.CellEndEdit
        CalcularTotalesDGyCeldas()
    End Sub
    Public Sub CalcularTotalesDGyCeldas()
        Dim dblPrecio As Double
        Dim intCantidad As Double
        Dim dblTotalLine As Double = 0

        For i As Integer = 0 To dgDetalle.Rows.Count - 1
            dblPrecio = dgDetalle.Rows(i).Cells("colPrecio").Value
            intCantidad = dgDetalle.Rows(i).Cells("colCantidad").Value
            dblTotalLine = dblPrecio * intCantidad

            dgDetalle.Rows(i).Cells("colTotal").Value = dblTotalLine.ToString(FORMATO_MONEDA)
        Next

        CalcularTotales()
    End Sub

    Private Sub botonCosteo_Click(sender As Object, e As EventArgs) Handles botonCosteo.Click
        Dim strCondicion As String = STR_VACIO
        Dim frm As New frmSeleccionar

        frm.Tabla = "Catalogos"
        frm.Campos = "  cat_num, cat_desc"
        frm.Condicion = "  cat_clase = 'Costeo'"
        frm.Filtro = "cli_desc"
        frm.Titulo = "Costing"
        frm.FiltroText = "Enter the costing to filter out"
        If frm.ShowDialog = System.Windows.Forms.DialogResult.OK Then
            celdaIdCosto.Text = frm.LLave
            CeldaCosteo.Text = frm.Dato
        End If


    End Sub

    Private Sub celdaProveedor_Click(sender As Object, e As EventArgs) Handles celdaProveedor.Click
        Dim frm As New frmSeleccionar
        Dim strCondicion As String = STR_VACIO
        strCondicion = " pro_sisemp = {empresa} AND pro_ramo = 'Textil' AND (pro_status = 'Activo' OR pro_codigo={id})"
        strCondicion = Replace(strCondicion, "{empresa}", Sesion.IdEmpresa)
        strCondicion = Replace(strCondicion, "{id}", 1937)
        Try
            frm.Titulo = "Providers"
            frm.FiltroText = "Enter the Provider to filter"
            frm.Campos = " pro_codigo Codigo,pro_proveedor Proveedor, pro_direccion Dirección, pro_cmethod Costeo, pro_nit NIT"
            frm.Tabla = "Proveedores"
            frm.Condicion = strCondicion
            frm.Filtro = " pro_proveedor"
            frm.Ordenamiento = " pro_proveedor"
            frm.TipoOrdenamiento = ""

            frm.ShowDialog(Me)
            If frm.DialogResult = System.Windows.Forms.DialogResult.OK Then
                celdaIDProveedores.Text = frm.LLave
                CeldaCliente.Text = frm.Dato
                CeldaDireccion.Text = frm.Dato2
                CeldaCosteo.Text = frm.Dato3
                celdaNit.Text = frm.Dato4
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try


    End Sub



    Private Sub dgDetalle_DoubleClick(sender As Object, e As EventArgs) Handles dgDetalle.DoubleClick
        MostrarOrdenesPorLinea()
    End Sub

    Public Sub MostrarOrdenesPorLinea()
        Dim i As Integer

        If dgDetalle.Rows.Count = 0 Then
            Exit Sub
        Else
            Select Case dgDetalle.CurrentCell.ColumnIndex

                Case 4

                    For i = 0 To dgDetalle.Rows.Count - 1

                        If Me.Tag = "Nuevo" Then
                            dgDetalle.Rows(i).Cells("colIDD").Value = i + 1

                        End If
                    Next

                    dgDetalle.CurrentRow.Cells("colOrden").Style.BackColor = Color.Yellow
                    MostrarOrdenes()

                Case 14
                    Dim frm As New frmOption
                    frm.Opciones = "Unsold |" & " Sold "
                    frm.Titulo = " Status "
                    frm.ShowDialog(Me)
                    Me.DialogResult = DialogResult.OK
                    Select Case frm.Seleccion
                        Case 0  ' Notas de Ingreso 
                            dgDetalle.CurrentRow.Cells("colEstado").Value = "Unsold"
                            dgDetalle.CurrentRow.Cells("colVendido").Value = STR_VACIO
                            dgDetalle.CurrentRow.Cells("colidVendido").Value = INT_CERO
                        Case 1 ' Sin Notas 
                            dgDetalle.CurrentRow.Cells("colEstado").Value = "Sold"
                    End Select
                Case 15
                    Dim frm As New frmSeleccionar
                    If dgDetalle.CurrentRow.Cells("colEstado").Value = "Sold" Then

                        'Propiedades de la consulta 
                        frm.Campos = " cli_codigo Code, cli_cliente Client"
                        frm.Tabla = " Clientes"
                        frm.Condicion = " cli_sisemp = " & Sesion.IdEmpresa & ""
                        frm.Ordenamiento = " cli_cliente"
                        frm.Filtro = " cli_cliente"
                        frm.Limite = " 20 "
                        ' Propiedades del Formulario 
                        frm.Titulo = "Customers"
                        frm.FiltroText = "Enter the name of the client to filter"
                        frm.ShowDialog(Me)
                        If frm.DialogResult = System.Windows.Forms.DialogResult.OK Then
                            dgDetalle.CurrentRow.Cells("colVendido").Value = frm.Dato
                            dgDetalle.CurrentRow.Cells("colIdVendido").Value = frm.LLave
                        End If
                    End If
                Case 16
                    Dim frm As New frmSeleccionar
                    'Propiedades de la consulta 
                    frm.Campos = " c.cat_num Codigo , c.cat_desc NombreNaviera"
                    frm.Tabla = " Catalogos c"
                    frm.Condicion = " c.cat_clase ='Naviera' "
                    frm.Ordenamiento = " c.cat_num"
                    frm.Filtro = " c.cat_desc"
                    frm.Limite = " 20 "
                    ' Propiedades del Formulario 
                    frm.Titulo = "Naviera"
                    frm.FiltroText = "Enter the name of the Naviera to filter"
                    frm.ShowDialog(Me)
                    If frm.DialogResult = System.Windows.Forms.DialogResult.OK Then
                        dgDetalle.CurrentRow.Cells("colNaviera").Value = frm.Dato
                        dgDetalle.CurrentRow.Cells("colidNaviera").Value = frm.LLave
                    End If
                Case 18
                    Dim frm As New frmDateTimePicker
                    frm.ShowDialog(Me)
                    If frm.DialogResult = System.Windows.Forms.DialogResult.OK Then
                        dgDetalle.CurrentRow.Cells("colFechaDetalle").Value = frm.LLave
                    End If
            End Select
        End If
    End Sub

    Private Sub botonGenerarIngreso_Click(sender As Object, e As EventArgs) Handles botonGenerarIngreso.Click

        Me.Enabled = False

        Dim numConfirmacion As Integer = INT_CERO
        Dim numPolizaImportacion As Integer = INT_CERO
        Dim numIngresoBodega As Integer = INT_CERO
        Dim numDatosPoliza As Integer
        Dim numParCat As Integer
        Dim clsconta As New clsContabilidad

        If Sesion.IdEmpresa = 9 Then
            If CeldaAño.Text = NO_FILA Then
                CeldaAño.Text = cFunciones.AñoMySQL
                CeldaNumero.Text = cFunciones.NuevoId(127)
            End If

            numDatosPoliza = VerificarChiNumDeConfirmacion()
            If numDatosPoliza > 0 Then
                numParCat = numDatosPoliza
            Else
                numParCat = cFunciones.NuevoId(55)
            End If


            'Genera Poliza de Importación 
            'Catalogo 180
            numPolizaImportacion = cfun.NuevoId(180)
            GuardarEncabezadoPolizaImportacion(numPolizaImportacion)
            GuardarDetallePolizaImportacion(numPolizaImportacion)
            GuardarDescargosPolizaImportacion(numPolizaImportacion, numParCat)
            GuardarDECPolizaImportacion(numPolizaImportacion)

            'Genera Ingreso a Bodega
            'Catalogo 47
            numIngresoBodega = cFunciones.NuevoId(47)
            GuardarEncabezadoIngresoBodega(numIngresoBodega)
            GuardarDetalleIngresoBodega(numIngresoBodega)
            GuardarDescargosIngresoBodega(numIngresoBodega, numPolizaImportacion)
            clsconta.GenerarPoliza(47, CeldaAño.Text, numIngresoBodega, Now().ToString(FORMATO_MYSQL))
            'Genera un bulto para el ingreso a Bodea (dtl_box)
            GuardarBultoDeIngreso(numIngresoBodega)

            Me.Enabled = True

            MsgBox("successfully saved data", vbInformation, vbOK)

        End If

    End Sub

    Private Sub CeldaReferencia1_TextChanged(sender As Object, e As EventArgs) Handles CeldaReferencia1.TextChanged
        If intControl = 0 Then
            celdaReferencia.Text = CeldaReferencia1.Text & IIf(CeldaReferencia2.TextLength > 0, " / " & CeldaReferencia2.Text, STR_VACIO)
        End If
    End Sub

    Private Sub CeldaReferencia2_TextChanged(sender As Object, e As EventArgs) Handles CeldaReferencia2.TextChanged
        If intControl = 0 Then
            celdaReferencia.Text = CeldaReferencia1.Text & IIf(CeldaReferencia2.TextLength > 0, " / " & CeldaReferencia2.Text, STR_VACIO)
        End If
    End Sub


    Private Sub dgLista_KeyDown(sender As Object, e As KeyEventArgs) Handles dgLista.KeyDown
        Try
            If e.KeyCode = Keys.F3 Then
                cfun.BuscarenLista(dgLista)
                e.Handled = True
                e.SuppressKeyPress = True
            ElseIf e.KeyCode = Keys.F6 Then
                cfun.MostrarDependencias(127, dgLista.SelectedCells(5).Value, dgLista.SelectedCells(0).Value)
            ElseIf e.KeyCode = Keys.F7 Then
                Dim rpt As New clsReportes
                rpt.Historial(dgLista.SelectedCells(0).Value, dgLista.SelectedCells(5).Value, 127)
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub botonGastos_Click(sender As Object, e As EventArgs) Handles botonGastos.Click
        Dim frm As New frmGastosLogistica
        frm.Catalogo = 127
        frm.Ano = CeldaAño.Text
        frm.Numero = CeldaNumero.Text
        frm.linea = INT_UNO

        frm.Ref_Ano = CeldaAño.Text
        frm.Ref_Catalogo = 127
        frm.Ref_Numero = CeldaNumero.Text
        frm.Ref_linea = INT_UNO

        frm.celdaReferencia.Text = celdaReferencia.Text

        frm.ShowDialog(Me)
    End Sub

    Private Sub Encabezado1_ClickBorrar(sender As Object, click As Boolean) Handles Encabezado1.ClickBorrar
        If LogBorrar = True Then
            Dim AnioDP As Integer = 0
            Dim NumeroDP As Integer = 0
            Dim strSQL As String = STR_VACIO
            Dim COM As MySqlCommand
            Dim REA As MySqlDataReader
            If Dependecias() > INT_CERO Then
                MsgBox("This Document can not be canceled, is related to other agencies", MsgBoxStyle.Critical, "Warning")
                cfun.MostrarDependencias(127, CeldaAño.Text, CeldaNumero.Text)

            Else
                If MsgBox("Are You sure " & vbCr & vbCr & "¿do you want to delete this document? ", vbQuestion + vbYesNo, "Aviso") = vbYes Then

                    strSQL = " SELECT d.PDoc_Chi_Ano anio, d.PDoc_Chi_Num num "
                    strSQL &= "    From Dcmtos_DTL_Pro d "
                    strSQL &= "        Where d.PDoc_Sis_Emp = {emp} And d.PDoc_Par_Cat = 127 And d.PDoc_Par_Ano = {anio} And d.PDoc_Par_Num = {num} "
                    strSQL &= "        Group By d.PDoc_Par_Num "

                    strSQL = Replace(strSQL, "{emp}", Sesion.IdEmpresa)
                    strSQL = Replace(strSQL, "{anio}", CeldaAño.Text)
                    strSQL = Replace(strSQL, "{num}", CeldaNumero.Text)

                    MyCnn.CONECTAR = strConexion
                    COM = New MySqlCommand(strSQL, CON)
                    REA = COM.ExecuteReader
                    If REA.HasRows Then
                        Do While REA.Read
                            AnioDP = REA.GetInt32("anio")
                            NumeroDP = REA.GetInt32("num")
                        Loop
                    End If

                    BorrarEncabezadoDatosPoliza(AnioDP, NumeroDP)
                    BorrarDetalleDatosPoliza(AnioDP, NumeroDP)
                    BorrarAccDatosPoliza(AnioDP, NumeroDP)
                    BorrarDescargo()
                    BorrarDescargoPO()
                    BorrarEncabezadoConfirmacion()
                    BorrarDetalleConfirmacion()
                    cfun.EscribirRegistro("TBL_DOCUMENTOS", clsFunciones.AccEnum.acDelete, Sesion.idUsuario, 127, CeldaAño.Text, CeldaNumero.Text)
                    BorrarAccConfirmacion()
                    cFunciones.BorrarEncabezadoPoliza(CeldaNumero.Text, CeldaAño.Text, 127)
                    cFunciones.BorrarDetallePoliza(CeldaNumero.Text, CeldaAño.Text, 127)
                    cFunciones.BorrarEncabezadoPoliza(CeldaNumero.Text, CeldaAño.Text, 55)
                    cFunciones.BorrarDetallePoliza(CeldaNumero.Text, CeldaAño.Text, 55)
                    MsgBox("Delete Complete")
                    MostrarLista()
                End If
            End If
        End If
    End Sub

    Private Sub checkMostrarDetalle_CheckedChanged(sender As Object, e As EventArgs) Handles checkMostrarDetalle.CheckedChanged

    End Sub

    Private Sub dtpEncabezado_ValueChanged(sender As Object, e As EventArgs) Handles dtpEncabezado.ValueChanged
        If CeldaTasa.Text > 1 Then
            CeldaTasa.Text = cfun.TasaSegunFecha(dtpEncabezado.Value.ToString(FORMATO_MYSQL))
        End If
    End Sub

    Private Sub dgLista_SelectionChanged(sender As Object, e As EventArgs) Handles dgLista.SelectionChanged
        Dim año As Integer
        Dim numero As Integer

        If checkMostrarDetalle.Checked = True Then
            numero = dgLista.SelectedCells(0).Value
            año = dgLista.SelectedCells(5).Value

            MostrarDetalle(año, numero)
        Else
            celdaLineas.Text = " "
        End If
    End Sub




#End Region
End Class