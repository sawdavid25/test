﻿Public Class frmPagarDespachos

#Region "Miembros"
    Dim strKey As String = STR_VACIO
    Dim logInsertar As Boolean = False
    Dim logConsultar As Boolean = False
    Dim logEditar As Boolean = False
    Dim LogBorrar As Boolean = False
#End Region

#Region "Propiedades"
    Public Property Key As String
        Get
            Return strKey
        End Get
        Set(value As String)
            strKey = value
        End Set
    End Property
#End Region

#Region "Procedimientos"
    Private Sub BloquearBotones(Optional ByVal logBloquear As Boolean = True)
        If logBloquear = True Then
            Encabezado1.botonBorrar.Enabled = False
            Encabezado1.botonGuardar.Enabled = False
        Else
            Encabezado1.botonBorrar.Enabled = True
            Encabezado1.botonGuardar.Enabled = True

        End If
    End Sub

    Private Sub Accessos()
        Dim cAccesos As New clsAccesos
        Try
            If cAccesos.Accesos(strKey) = True Then
                logInsertar = cAccesos.Insertar
                logConsultar = cAccesos.Consultar
                logEditar = cAccesos.Editar
                LogBorrar = cAccesos.Borrar
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub LimpiarCampos()
        celdaAnio.Text = cFunciones.AñoMySQL
        celdaTotal.Clear()
        celdaNumero.Text = NO_FILA
        dtpFecha.Value = Today
        celdaIdMoneda.Text = cFunciones.DivisaExtranjera
        celdaMoneda.Text = cFunciones.TraerMoneda(celdaIdMoneda.Text)
        celdaTC.Text = cFunciones.QueryTasa
        cFunciones.QueryTasa()
        celdaidProveedor.Text = INT_CERO
        celdaProveedor.Clear()
        celdaDescripcion.Clear()
        checkActivo.Checked = True
        checkActivo.Enabled = True
        dgDetalle.Rows.Clear()

    End Sub

    Private Sub MostrarLista(Optional ByVal logMostrar As Boolean = True, Optional logInsert As Boolean = False)
        Dim cfun As New clsFunciones
        If logMostrar = True Then
            panelDocumento.Dock = DockStyle.None
            panelDocumento.Visible = False
            BarraTitulo1.CambiarTitulo("Direct Dispatch Charges")
            ListaPrincipal()
            panelLista.Visible = True
            panelLista.Dock = DockStyle.Fill
            BloquearBotones()
        Else
            panelLista.Visible = False
            panelLista.Dock = DockStyle.None
            panelDocumento.Dock = DockStyle.Fill
            panelDocumento.Visible = True

            If logInsert = False Then
                BarraTitulo1.CambiarTitulo("Modify Registration")
                BloquearBotones(False)
            Else
                BarraTitulo1.CambiarTitulo("New Register")
                BloquearBotones(False)
            End If
        End If
    End Sub

    Private Function SQLListaPrincipal()
        Dim strSQL As String = STR_VACIO

        strSQL = " SELECT h.HDoc_Doc_Ano anio, h.HDoc_Doc_Num num, h.HDoc_Doc_Fec fecha, h.HDoc_RF1_Txt descripcion, h.HDoc_RF1_Dbl monto, h.HDoc_Doc_Status estado
                        FROM Dcmtos_HDR h
                        WHERE h.HDoc_Sis_Emp = 12 AND h.HDoc_Doc_Cat = 439 {fechas}"

        strSQL = strSQL.Replace("{emp}", Sesion.IdEmpresa)
        If checkFechas.Checked = True Then
            strSQL = strSQL.Replace("{fechas}", " AND h.HDoc_Doc_Fec BETWEEN '{inicio}' AND '{fin}' ")
            strSQL = strSQL.Replace("{inicio}", dtpInicio.Value.ToString(FORMATO_MYSQL))
            strSQL = strSQL.Replace("{fin}", dtpFinal.Value.ToString(FORMATO_MYSQL))
        Else
            strSQL = strSQL.Replace("{fechas}", "")
        End If

        Return strSQL
    End Function

    Private Function SQLCargarEncabezado(ByVal intAnio As Integer, ByVal intNum As Integer)
        Dim strSQL As String = STR_VACIO

        strSQL = " SELECT h.HDoc_Doc_Ano anio, h.HDoc_Doc_Num num, h.HDoc_Doc_Fec fecha,h.HDoc_Emp_Cod codProveedor, h.HDoc_Emp_Nom proveedor, h.HDoc_RF1_Txt descripcion, h.HDoc_RF1_Dbl monto, h.HDoc_Doc_Mon idMoneda,h.HDoc_Doc_TC TC, c.cat_clave, h.HDoc_Doc_Status estado
                        FROM Dcmtos_HDR h
                        LEFT JOIN Catalogos c ON c.cat_num = h.HDoc_Doc_Mon
                        WHERE h.HDoc_Sis_Emp = {emp} AND h.HDoc_Doc_Cat = 439 AND h.HDoc_Doc_Ano = {anio} AND h.HDoc_Doc_Num = {num} "

        strSQL = strSQL.Replace("{emp}", Sesion.IdEmpresa)
        strSQL = strSQL.Replace("{anio}", intAnio)
        strSQL = strSQL.Replace("{num}", intNum)

        Return strSQL
    End Function

    Public Sub ListaPrincipal()
        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader
        Dim strSQL As String = STR_VACIO
        Dim strFila As String = STR_VACIO

        Try
            strSQL = SQLListaPrincipal()
            MyCnn.CONECTAR = strConexion

            COM = New MySqlCommand(strSQL, CON)
            REA = COM.ExecuteReader
            dgLista.Rows.Clear()
            If REA.HasRows Then

                Do While REA.Read
                    strFila = REA.GetInt32("anio") & "|"
                    strFila &= REA.GetInt32("num") & "|"
                    strFila &= REA.GetDateTime("fecha").ToString(FORMATO_MYSQL) & "|"
                    strFila &= REA.GetString("descripcion") & "|"
                    strFila &= REA.GetDouble("monto").ToString(FORMATO_MONEDA) & "|"
                    strFila &= REA.GetInt32("estado") 

                    If REA.GetInt32("estado") = 0 Then
                        cFunciones.AgregarFila(dgLista, strFila, Color.Coral)
                    Else
                        cFunciones.AgregarFila(dgLista, strFila)
                    End If
                Loop
            End If

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try

    End Sub

    Private Function ComprobarCampos()
        Dim comprobar As Boolean = True

        If celdaidProveedor.Text = 0 Then
            If MsgBox("You must Select a provider", vbInformation, "Notice") = vbOK Then
                botonProveedor.Focus()
                comprobar = False
            End If
        ElseIf Not dgDetalle.Rows.Count >= 1 Then
            If MsgBox("Select an document please", vbInformation, "Notice") = vbOK Then
                botonAgregar.Focus()
                comprobar = False
            End If
        ElseIf celdaDescripcion.Text = vbNullString Then
            If MsgBox("Enter the payment description", vbInformation, "Notice") = vbOK Then
                celdaDescripcion.Focus()
                comprobar = False
            End If

        End If

        Return comprobar
    End Function


    Private Function NuevaLinea(ByVal Codigo As Integer, ByVal anio As Integer) As Integer
        Dim strSQL As String = STR_VACIO
        Dim conec As New MySqlConnection
        Dim COM As MySqlCommand
        Dim LineaNueva As Integer

        strSQL = " Select IFNULL(MAX(DTL.DDoc_Doc_Lin),0) + 1  DTL "
        strSQL &= " FROM Dcmtos_DTL DTL "
        strSQL &= " WHERE DTL.DDoc_Sis_emp = {empresa} And DTL.DDoc_Doc_Cat = {catalogo} And DTL.DDoc_Doc_Ano = {anio} And DTL.DDoc_Doc_Num ={codigo} "

        strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
        strSQL = Replace(strSQL, "{catalogo}", 439)
        strSQL = Replace(strSQL, "{anio}", anio)
        strSQL = Replace(strSQL, "{codigo}", Codigo)



        conec = New MySqlConnection(strConexion)
        conec.Open()
        COM = New MySqlCommand(strSQL, conec)
        LineaNueva = COM.ExecuteScalar
        conec.Close()
        conec.Dispose()
        conec = Nothing
        System.GC.Collect()
        Return LineaNueva

    End Function

    Private Sub GuardarEncabezado()
        Dim hdr As New clsDcmtos_HDR

        hdr.HDOC_SIS_EMP = Sesion.IdEmpresa
        hdr.HDOC_DOC_CAT = 439
        hdr.HDOC_DOC_ANO = celdaAnio.Text
        hdr.HDOC_DOC_NUM = celdaNumero.Text
        hdr.HDoc_Doc_Fec_NET = dtpFecha.Value.ToString(FORMATO_MYSQL)
        hdr.HDOC_EMP_COD = celdaidProveedor.Text
        hdr.HDOC_EMP_NOM = celdaProveedor.Text
        If checkActivo.Checked = True Then
            hdr.HDOC_RF1_DBL = celdaTotal.Text
        Else
            hdr.HDOC_RF1_DBL = INT_CERO
        End If

        hdr.HDOC_RF1_TXT = celdaDescripcion.Text
        hdr.HDOC_DOC_MON = celdaIdMoneda.Text
        hdr.HDOC_DOC_TC = celdaTC.Text
        hdr.HDOC_USUARIO = Sesion.Usuario
        hdr.HDOC_DOC_STATUS = IIf(checkActivo.Checked, INT_UNO, INT_CERO)
        hdr.HDOC_ANT_COM = INT_CERO

        hdr.CONEXION = strConexion

        If Me.Tag = "Nuevo" Then

            If hdr.Guardar() = False Then
                MsgBox(hdr.MERROR.ToString & "Could Not save the document", MsgBoxStyle.Critical)
            End If
        Else
            If hdr.Actualizar() = False Then
                MsgBox(hdr.MERROR.ToString & "Could Not save the document", MsgBoxStyle.Critical)
            End If
        End If
    End Sub

    Private Sub GuardarDetalle()
        Dim cdtl As New clsDcmtos_DTL
        Try
            For i As Integer = 0 To dgDetalle.Rows.Count - 1
                cdtl.DDOC_SIS_EMP = Sesion.IdEmpresa
                cdtl.DDOC_DOC_CAT = 439
                cdtl.DDOC_DOC_ANO = celdaAnio.Text
                cdtl.DDOC_DOC_NUM = celdaNumero.Text

                cdtl.DDOC_RF1_NUM = dgDetalle.Rows(i).Cells("col_Catalogo").Value
                cdtl.DDOC_RF2_NUM = dgDetalle.Rows(i).Cells("col_Anio").Value
                cdtl.DDOC_RF3_NUM = dgDetalle.Rows(i).Cells("col_Numero").Value
                If checkActivo.Checked = True Then
                    cdtl.DDOC_PRD_NET = dgDetalle.Rows(i).Cells("col_Monto").Value
                Else
                    cdtl.DDOC_PRD_NET = INT_CERO
                End If
                cdtl.DDoc_RF1_Fec_NET = dgDetalle.Rows(i).Cells("col_Fecha").Value

                Select Case dgDetalle.Rows(i).Cells("col_Extra").Value
                    Case 0 'Guardar nueva Linea
                        dgDetalle.Rows(i).Cells("col_Linea").Value = NuevaLinea(celdaNumero.Text, cdtl.DDOC_DOC_ANO)
                        cdtl.DDOC_DOC_LIN = dgDetalle.Rows(i).Cells("col_Linea").Value
                        cdtl.CONEXION = strConexion
                        If cdtl.Guardar = False Then
                            MsgBox(cdtl.MERROR.ToString)
                        End If
                    Case 1 'Actualizar Linea
                        cdtl.DDOC_DOC_LIN = dgDetalle.Rows(i).Cells("col_Linea").Value
                        cdtl.CONEXION = strConexion
                        If cdtl.Actualizar = False Then
                            MsgBox(cdtl.MERROR.ToString)
                        End If
                    Case 2 ' Borrar Linea
                        cdtl.DDOC_DOC_LIN = dgDetalle.Rows(i).Cells("col_Linea").Value
                        cdtl.CONEXION = strConexion
                        If cdtl.Borrar = False Then
                            MsgBox(cdtl.MERROR.ToString)
                        End If
                End Select

            Next

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub GuardarEctaCte()
        Dim ctate As New Tablas.TECTACTE
        Try
            For i As Integer = 0 To dgDetalle.Rows.Count - 1
                ctate.ECTA_SIS_EMP = Sesion.IdEmpresa
                ctate.ECTA_DOC_CAT = 439
                ctate.ECTA_DOC_ANO = celdaAnio.Text
                ctate.ECTA_DOC_NUM = celdaNumero.Text
                ctate.ECTA_DOC_LIN = dgDetalle.Rows(i).Cells("col_Linea").Value

                ctate.ECTA_REF_CAT = 446
                ctate.ECTA_REF_ANO = dgDetalle.Rows(i).Cells("col_Anio").Value
                ctate.ECTA_REF_NUM = dgDetalle.Rows(i).Cells("col_Numero").Value
                ctate.ECta_FecVenc_NET = dtpFecha.Value
                ctate.ECta_FecDcmt_NET = dtpFecha.Value
                ctate.ECTA_MONEDA = celdaIdMoneda.Text
                ctate.ECTA_TC = celdaTC.Text
                ctate.ECTA_TRANSID = INT_CERO

                If checkActivo.Checked = True Then
                    ctate.ECTA_ABNO_EXT = dgDetalle.Rows(i).Cells("col_Monto").Value
                    ctate.ECTA_ABNO_LOC = (dgDetalle.Rows(i).Cells("col_Monto").Value * celdaTC.Text)
                Else
                    ctate.ECTA_ABNO_EXT = INT_CERO
                    ctate.ECTA_ABNO_LOC = INT_CERO
                End If


                ctate.CONEXION = strConexion
                Select Case dgDetalle.Rows(i).Cells("col_Extra").Value
                    Case 0 'Guardar nueva Linea
                        If ctate.PINSERT = False Then
                            MsgBox(ctate.MERROR.ToString)
                        Else
                            dgDetalle.Rows(i).Cells("col_Extra").Value = 1
                        End If
                    Case 1 'Actualizar Linea
                        ctate.CONEXION = strConexion
                        If ctate.PUPDATE = False Then
                            MsgBox(ctate.MERROR.ToString)
                        End If
                    Case 2 ' Borrar Linea
                        ctate.CONEXION = strConexion
                        EliminarEctate(celdaAnio.Text, celdaNumero.Text, dgDetalle.Rows(i).Cells("col_Linea").Value)
                        If ctate.PDELETE = False Then
                            MsgBox(ctate.MERROR.ToString)
                        End If
                End Select
            Next
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub EliminarEctate(ByVal Anio As Integer, ByVal Numero As Integer, ByVal Linea As Integer)
        Dim strSQL As String = STR_VACIO
        Dim COM As MySqlCommand
        Try
            strSQL = " DELETE FROM  ECtaCte  "
            strSQL &= "     WHERE ECta_Sis_Emp = {empresa} And ECta_Doc_Cat = 439  And ECta_Doc_Ano = {anio} And ECta_Doc_Num = {numero} And ECta_Doc_Lin = {linea} "
            strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
            strSQL = Replace(strSQL, "{anio}", Anio)
            strSQL = Replace(strSQL, "{numero}", Numero)
            strSQL = Replace(strSQL, "{linea}", Linea)
            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSQL, CON)
            COM.ExecuteNonQuery()
            COM.Dispose()
            System.GC.Collect()
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub CalcularTotal()
        Dim dblGranTotal As Double = INT_CERO
        Dim dblTotal As Double = INT_CERO
        Dim dblPrecio As Double = INT_CERO
        Dim dblCantidad As Double = INT_CERO
        Try
            For i As Integer = 0 To dgDetalle.Rows.Count - 1
                If Not dgDetalle.Rows(i).Cells("col_Extra").Value = 2 Then
                    dblTotal = CDbl(dgDetalle.Rows(i).Cells("col_Monto").Value)
                    dblGranTotal = dblGranTotal + dblTotal
                End If
            Next
            celdaTotal.Text = dblGranTotal.ToString(FORMATO_MONEDA)
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub Borrar()
        Dim strSql As String = STR_VACIO
        Try
            checkActivo.Checked = False
            'BORRAR ENCABEZADO
            Dim hdr As New clsDcmtos_HDR
            hdr.CONEXION = strConexion
            hdr.HDOC_SIS_EMP = Sesion.IdEmpresa
            hdr.HDOC_DOC_CAT = 439
            hdr.HDOC_DOC_ANO = celdaAnio.Text
            hdr.HDOC_DOC_NUM = celdaNumero.Text
            hdr.Borrar()

            ' BORRAR DETALLE
            strSql = STR_VACIO
            strSql = "DDoc_Sis_Emp = {empresa} And  DDoc_Doc_Cat =439 And  DDoc_Doc_Ano = {ano}  And DDoc_Doc_Num = {numero} "
            strSql = strSql.Replace("{empresa}", Sesion.IdEmpresa)
            strSql = strSql.Replace("{ano}", celdaAnio.Text)
            strSql = strSql.Replace("{numero}", celdaNumero.Text)

            Dim dtl As New clsDcmtos_DTL
            dtl.CONEXION = strConexion
            dtl.Borrar(strSql)

            'BORRAR ECTATE

            strSql = STR_VACIO
            strSql = "ECta_Sis_Emp = {empresa} And  ECta_Doc_Cat =439 And  ECta_Doc_Ano = {ano}  And ECta_Doc_Num = {numero} "
            strSql = strSql.Replace("{empresa}", Sesion.IdEmpresa)
            strSql = strSql.Replace("{ano}", celdaAnio.Text)
            strSql = strSql.Replace("{numero}", celdaNumero.Text)

            Dim ectacte As New Tablas.TECTACTE
            ectacte.CONEXION = strConexion
            ectacte.PDELETE(strSql)

            cFunciones.EscribirRegistro("HDR", clsFunciones.AccEnum.acDelete, 0, 439, celdaAnio.Text, celdaNumero.Text)

            MostrarLista(True)
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub CargarEncabezado(ByVal intAnio As Integer, ByVal intNum As Integer)
        Dim strSQL As String = STR_VACIO
        Dim strFila As String = STR_VACIO
        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader

        Try
            strSQL = SQLCargarEncabezado(intAnio, intNum)
            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSQL, CON)
            REA = COM.ExecuteReader
            If REA.HasRows Then
                REA.Read()
                celdaAnio.Text = REA.GetInt32("anio")
                celdaNumero.Text = REA.GetInt32("num")
                celdaidProveedor.Text = REA.GetInt32("codProveedor")
                celdaProveedor.Text = REA.GetString("proveedor")
                celdaDescripcion.Text = REA.GetString("descripcion")
                celdaIdMoneda.Text = REA.GetInt32("idMoneda")
                celdaTC.Text = REA.GetDouble("TC")
                celdaMoneda.Text = REA.GetString("cat_clave")
                If REA.GetInt32("estado") = 1 Then
                    checkActivo.Checked = True
                    checkActivo.Enabled = True
                Else
                    checkActivo.Checked = False
                    checkActivo.Enabled = False
                End If

            End If

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub CargarDetalle(ByVal intAnio As Integer, ByVal intNum As Integer)
        Dim strSQL As String = STR_VACIO
        Dim strFila As String = STR_VACIO
        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader

        Try
            strSQL = " SELECT d.DDoc_RF1_Num cat,d.DDoc_RF2_Num anio,d.DDoc_RF3_Num num, d.DDoc_Doc_Lin linea, d.DDoc_RF1_Fec fecha, d.DDoc_Prd_NET monto, c.cli_cliente cliente 
                            FROM Dcmtos_HDR h
                            LEFT JOIN Dcmtos_DTL d ON d.DDoc_Sis_Emp = h.HDoc_Sis_Emp AND d.DDoc_Doc_Cat = h.HDoc_Doc_Cat AND d.DDoc_Doc_Ano = h.HDoc_Doc_Ano AND d.DDoc_Doc_Num = h.HDoc_Doc_Num
                            LEFT JOIN Dcmtos_HDR r ON r.HDoc_Sis_Emp = d.DDoc_Sis_Emp AND r.HDoc_Doc_Cat = d.DDoc_RF1_Num AND r.HDoc_Doc_Ano = d.DDoc_RF2_Num AND r.HDoc_Doc_Num = d.DDoc_RF3_Num
                            LEFT JOIN Clientes c ON c.cli_sisemp = r.HDoc_Sis_Emp AND c.cli_codigo = r.HDoc_DR1_Emp
                            WHERE h.HDoc_Sis_Emp = {empresa} AND h.HDoc_Doc_Cat = 439 AND h.HDoc_Doc_Ano = {ano} AND h.HDoc_Doc_Num = {numero}  "

            strSQL = strSQL.Replace("{empresa}", Sesion.IdEmpresa)
            strSQL = strSQL.Replace("{ano}", intAnio)
            strSQL = strSQL.Replace("{numero}", intNum)

            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSQL, CON)
            REA = COM.ExecuteReader
            dgDetalle.Rows.Clear()
            If REA.HasRows Then
                Do While REA.Read
                    strFila = REA.GetInt32("cat") & "|"
                    strFila &= REA.GetInt32("anio") & "|"
                    strFila &= REA.GetInt32("linea") & "|"
                    strFila &= REA.GetInt32("num") & "|"
                    strFila &= REA.GetDateTime("Fecha").ToString(FORMATO_MYSQL) & "|"
                    strFila &= REA.GetString("cliente") & "|"
                    strFila &= REA.GetDouble("monto").ToString(FORMATO_MONEDA) & "|"
                    strFila &= INT_UNO

                    cFunciones.AgregarFila(dgDetalle, strFila)
                Loop
                CalcularTotal()
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub


#End Region

#Region "Eventos"

    Private Sub frmPagarDespachos_Load(sender As Object, e As EventArgs) Handles Me.Load
        dtpInicio.Value = DateSerial(Year(Date.Now), Month(Date.Now) - 1, 1)
        dtpFinal.Value = Today

        MostrarLista()
        Accessos()
    End Sub

    Private Sub botonProveedor_Click(sender As Object, e As EventArgs) Handles botonProveedor.Click
        Dim frm As New frmSeleccionar
        Try
            frm.Titulo = "Suppliers"
            frm.Campos = " p.pro_codigo codigo, p.pro_proveedor proveedor "
            frm.Tabla = " Proveedores p "
            frm.FiltroText = " Enter the Supplier To filter "
            frm.Filtro = " p.pro_proveedor "
            frm.Ordenamiento = " p.pro_proveedor "
            frm.TipoOrdenamiento = " ASC "
            frm.Condicion = " p.pro_sisemp = " & Sesion.IdEmpresa
            frm.Limite = 15

            frm.ShowDialog(Me)
            If frm.DialogResult = System.Windows.Forms.DialogResult.OK Then
                celdaidProveedor.Text = frm.LLave
                celdaProveedor.Text = frm.Dato

            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub botonMoneda_Click(sender As Object, e As EventArgs) Handles botonMoneda.Click
        Dim frm As New frmSeleccionar

        Try
            frm.Titulo = "Coin"
            frm.Campos = "c.cat_clave Moneda, c.cat_num ID, c.cat_sist"
            frm.Tabla = "Catalogos c"
            frm.FiltroText = " Enter the Coin To filter"
            frm.Filtro = " c.cat_clave "
            frm.Limite = 5
            frm.Ordenamiento = " c.cat_clave "
            frm.TipoOrdenamiento = ""
            frm.Condicion = "cat_clase='Monedas'"

            frm.ShowDialog(Me)

            If frm.DialogResult = System.Windows.Forms.DialogResult.OK Then
                celdaMoneda.Text = frm.LLave
                celdaIDMoneda.Text = frm.Dato
                celdaTC.Text = frm.Dato2

            End If

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub Encabezado1_ClickNuevo(sender As Object, click As Boolean) Handles Encabezado1.ClickNuevo
        If logInsertar = True Then
            LimpiarCampos()
            Me.Tag = "Nuevo"
            MostrarLista(False, True)
        Else
            MsgBox("You do not have access to create a new document.", vbInformation)
        End If
    End Sub

    Private Sub Encabezado1_ClickCerrar(sender As Object, click As Boolean) Handles Encabezado1.ClickCerrar
        If panelDocumento.Visible = False Then
            Me.Close()
            Fprincipal.BarraDeTareas1.QuitarFormulario(strKey)
        Else
            MostrarLista()
        End If
    End Sub

    Private Sub botonAgregar_Click(sender As Object, e As EventArgs) Handles botonAgregar.Click
        If celdaidProveedor.Text = 0 Then
            MsgBox("Choose a Provider", vbInformation, "Notice")
            botonProveedor.Focus()
            Exit Sub
        End If
        Dim frm As New frmSeleccionar
        Dim strTabla As String = STR_VACIO
        Dim strCondicion As String = STR_VACIO
        Dim strFila As String = STR_VACIO
        Dim fecha As Date

        strTabla = " (SELECT h.HDoc_Doc_Num _number, h.HDoc_Doc_Fec _date, (e.ECta_Crgo_Ext - (SUM(e.ECta_Abno_Ext))) _balance,h.HDoc_Doc_Cat _code, h.HDoc_Doc_Ano _Year, c.cli_cliente cliente
                        FROM Dcmtos_HDR h
                        LEFT JOIN ECtaCte e ON e.ECta_Sis_Emp = h.HDoc_Sis_Emp AND e.ECta_Ref_Cat = h.HDoc_Doc_Cat AND e.ECta_Ref_Ano = h.HDoc_Doc_Ano AND e.ECta_Ref_Num = h.HDoc_Doc_Num
                        LEFT JOIN Clientes c ON c.cli_sisemp = h.HDoc_Sis_Emp AND c.cli_codigo = h.HDoc_DR1_Emp
                        WHERE h.HDoc_Sis_Emp = {emp} AND h.HDoc_Doc_Cat = 446 AND h.HDoc_Emp_Cod = {cod} AND h.HDoc_Doc_Status = 1
                        HAVING _balance>0
                        LIMIT 40)a "
        strTabla = strTabla.Replace("{emp}", Sesion.IdEmpresa)
        strTabla = strTabla.Replace("{cod}", celdaidProveedor.Text)

        strCondicion = " a._number >0 "


        frm.Titulo = "Documentos"
        frm.Multiple = True
        frm.Campos = " a._number _number,a.cliente _cliente,a._date _date,a._balance _balance,a._code _code,a._Year _Year "
        frm.Tabla = strTabla
        frm.Condicion = strCondicion
        frm.FiltroText = " Enter the document number"
        frm.Filtro = "a._number"
        frm.Limite = 40

        frm.ShowDialog(Me)
        If frm.DialogResult = System.Windows.Forms.DialogResult.OK Then
            For i As Integer = 0 To frm.DataGrid.Rows.Count - 1
                If frm.DataGrid.Rows(i).Cells("colCheck").Value = True Then
                    strFila = frm.ListaClientes.Rows(i).Cells(5).Value & "|"
                    strFila &= frm.ListaClientes.Rows(i).Cells(6).Value & "|"
                    strFila &= INT_CERO & "|"
                    strFila &= frm.ListaClientes.Rows(i).Cells(1).Value & "|"
                    fecha = frm.ListaClientes.Rows(i).Cells(3).Value

                    strFila &= CDate(fecha).ToString(FORMATO_MYSQL) & "|"
                    strFila &= frm.ListaClientes.Rows(i).Cells(2).Value & "|"
                    strFila &= frm.ListaClientes.Rows(i).Cells(4).Value & "|"
                    strFila &= INT_CERO

                    cFunciones.AgregarFila(dgDetalle, strFila)
                End If
            Next
            CalcularTotal()
        End If
    End Sub

    Private Sub Encabezado1_ClickGuardar(sender As Object, click As Boolean) Handles Encabezado1.ClickGuardar
        If logEditar = True Or Me.Tag = "Nuevo" Then

            If ComprobarCampos() = True Then
                If celdaNumero.Text = NO_FILA Then
                    celdaNumero.Text = cFunciones.NuevoId(439)
                End If
                GuardarEncabezado()
                GuardarDetalle()
                GuardarEctaCte()

                If Me.Tag = "Nuevo" Then
                    cFunciones.EscribirRegistro("Dcmtos_HDR", clsFunciones.AccEnum.acAdd, 0, 439, celdaAnio.Text, celdaNumero.Text)
                    MsgBox("The Document has been successfully saved", vbInformation, "Notice")
                Else
                    cFunciones.EscribirRegistro("Dcmtos_HDR", clsFunciones.AccEnum.acUpdate, 0, 439, celdaAnio.Text, celdaNumero.Text)
                    MsgBox("The document has been successfully updated", vbInformation, "Notice")
                End If

                MostrarLista(True)
            End If
        Else
            MsgBox("You do not have access to edit this document", vbInformation)
        End If
    End Sub

    Private Sub botonQuitar_Click(sender As Object, e As EventArgs) Handles botonQuitar.Click
        Try
            If MsgBox("Are you sure you want to delete this row? ", MsgBoxStyle.YesNo) = MsgBoxResult.Yes Then
                dgDetalle.CurrentRow.Cells("col_Extra").Value = 2
                dgDetalle.CurrentRow.Visible = False
                CalcularTotal()
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub dgDetalle_CellEndEdit(sender As Object, e As DataGridViewCellEventArgs) Handles dgDetalle.CellEndEdit
        CalcularTotal()
    End Sub

    Private Sub Encabezado1_ClickBorrar(sender As Object, click As Boolean) Handles Encabezado1.ClickBorrar
        If LogBorrar = True Then
            If MsgBox("Do you want to delete this document? ", MsgBoxStyle.YesNo) = MsgBoxResult.Yes Then
                Borrar()
            End If
        Else
            MsgBox("You don't have permission to delete")
        End If
    End Sub

    Private Sub dgLista_DoubleClick(sender As Object, e As EventArgs) Handles dgLista.DoubleClick
        Dim intAnio As Integer = 0
        Dim intNum As Integer = 0
        Try
            Me.Tag = "Mod"
            LimpiarCampos()
            intAnio = dgLista.SelectedCells(0).Value
            intNum = dgLista.SelectedCells(1).Value
            MostrarLista(False)
            CargarEncabezado(intAnio, intNum)
            CargarDetalle(intAnio, intNum)
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub dgLista_KeyDown(sender As Object, e As KeyEventArgs) Handles dgLista.KeyDown
        Try
            If e.KeyCode = Keys.F3 Then
                cFunciones.BuscarenLista(dgLista)
                e.Handled = True
                e.SuppressKeyPress = True
            ElseIf e.KeyCode = Keys.F6 Then
                cFunciones.MostrarDependencias(439, dgLista.SelectedCells(0).Value, dgLista.SelectedCells(1).Value)
            ElseIf e.KeyCode = Keys.F7 Then
                Dim rpt As New clsReportes
                rpt.Historial(dgLista.SelectedCells(1).Value, dgLista.SelectedCells(0).Value, 439)

            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub botonFiltrar_Click(sender As Object, e As EventArgs) Handles botonFiltrar.Click
        ListaPrincipal()
    End Sub

#End Region

End Class