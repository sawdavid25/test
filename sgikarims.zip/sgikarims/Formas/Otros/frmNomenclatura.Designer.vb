﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmNomenclatura
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmNomenclatura))
        Me.panelLista = New System.Windows.Forms.Panel()
        Me.tvLista = New System.Windows.Forms.TreeView()
        Me.panelEdicion = New System.Windows.Forms.Panel()
        Me.gbCuentas = New System.Windows.Forms.GroupBox()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.celdaNombreCta = New System.Windows.Forms.TextBox()
        Me.celdaNumeroCta = New System.Windows.Forms.TextBox()
        Me.celdaPid = New System.Windows.Forms.TextBox()
        Me.etiquetaOrigen = New System.Windows.Forms.Label()
        Me.celdaOrigen = New System.Windows.Forms.TextBox()
        Me.gbTipoCuenta = New System.Windows.Forms.GroupBox()
        Me.rbGastos = New System.Windows.Forms.RadioButton()
        Me.rbIngresos = New System.Windows.Forms.RadioButton()
        Me.rbPasivo = New System.Windows.Forms.RadioButton()
        Me.rbPatrimonio = New System.Windows.Forms.RadioButton()
        Me.rbActivo = New System.Windows.Forms.RadioButton()
        Me.gbSaldo = New System.Windows.Forms.GroupBox()
        Me.rbAcreedor = New System.Windows.Forms.RadioButton()
        Me.rbDeudor = New System.Windows.Forms.RadioButton()
        Me.celdaDescripcion = New System.Windows.Forms.TextBox()
        Me.celdaNombre = New System.Windows.Forms.TextBox()
        Me.celdaCompania = New System.Windows.Forms.TextBox()
        Me.celdaCuenta = New System.Windows.Forms.TextBox()
        Me.etiquetaDescripcion = New System.Windows.Forms.Label()
        Me.etiquetaNombre = New System.Windows.Forms.Label()
        Me.etiquetaEmpresa = New System.Windows.Forms.Label()
        Me.etiquetaCuenta = New System.Windows.Forms.Label()
        Me.imgLista = New System.Windows.Forms.ImageList(Me.components)
        Me.BarraTitulo1 = New KARIMs_SGI.BarraTitulo()
        Me.Encabezado1 = New KARIMs_SGI.encabezado()
        Me.panelLista.SuspendLayout()
        Me.panelEdicion.SuspendLayout()
        Me.gbCuentas.SuspendLayout()
        Me.gbTipoCuenta.SuspendLayout()
        Me.gbSaldo.SuspendLayout()
        Me.SuspendLayout()
        '
        'panelLista
        '
        Me.panelLista.Controls.Add(Me.tvLista)
        Me.panelLista.Location = New System.Drawing.Point(31, 133)
        Me.panelLista.Name = "panelLista"
        Me.panelLista.Size = New System.Drawing.Size(422, 533)
        Me.panelLista.TabIndex = 2
        '
        'tvLista
        '
        Me.tvLista.Dock = System.Windows.Forms.DockStyle.Fill
        Me.tvLista.HotTracking = True
        Me.tvLista.Location = New System.Drawing.Point(0, 0)
        Me.tvLista.Name = "tvLista"
        Me.tvLista.Size = New System.Drawing.Size(422, 533)
        Me.tvLista.TabIndex = 2
        '
        'panelEdicion
        '
        Me.panelEdicion.Controls.Add(Me.gbCuentas)
        Me.panelEdicion.Location = New System.Drawing.Point(495, 133)
        Me.panelEdicion.Name = "panelEdicion"
        Me.panelEdicion.Size = New System.Drawing.Size(550, 533)
        Me.panelEdicion.TabIndex = 3
        '
        'gbCuentas
        '
        Me.gbCuentas.Controls.Add(Me.Button1)
        Me.gbCuentas.Controls.Add(Me.Label2)
        Me.gbCuentas.Controls.Add(Me.Label1)
        Me.gbCuentas.Controls.Add(Me.celdaNombreCta)
        Me.gbCuentas.Controls.Add(Me.celdaNumeroCta)
        Me.gbCuentas.Controls.Add(Me.celdaPid)
        Me.gbCuentas.Controls.Add(Me.etiquetaOrigen)
        Me.gbCuentas.Controls.Add(Me.celdaOrigen)
        Me.gbCuentas.Controls.Add(Me.gbTipoCuenta)
        Me.gbCuentas.Controls.Add(Me.gbSaldo)
        Me.gbCuentas.Controls.Add(Me.celdaDescripcion)
        Me.gbCuentas.Controls.Add(Me.celdaNombre)
        Me.gbCuentas.Controls.Add(Me.celdaCompania)
        Me.gbCuentas.Controls.Add(Me.celdaCuenta)
        Me.gbCuentas.Controls.Add(Me.etiquetaDescripcion)
        Me.gbCuentas.Controls.Add(Me.etiquetaNombre)
        Me.gbCuentas.Controls.Add(Me.etiquetaEmpresa)
        Me.gbCuentas.Controls.Add(Me.etiquetaCuenta)
        Me.gbCuentas.Dock = System.Windows.Forms.DockStyle.Fill
        Me.gbCuentas.Location = New System.Drawing.Point(0, 0)
        Me.gbCuentas.Name = "gbCuentas"
        Me.gbCuentas.Size = New System.Drawing.Size(550, 533)
        Me.gbCuentas.TabIndex = 0
        Me.gbCuentas.TabStop = False
        Me.gbCuentas.Text = "Account Registration"
        '
        'Button1
        '
        Me.Button1.Location = New System.Drawing.Point(419, 352)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(39, 23)
        Me.Button1.TabIndex = 17
        Me.Button1.Text = "..."
        Me.Button1.UseVisualStyleBackColor = True
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(24, 394)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(59, 17)
        Me.Label2.TabIndex = 16
        Me.Label2.Text = "Account"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(24, 357)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(113, 17)
        Me.Label1.TabIndex = 15
        Me.Label1.Text = "Account Number"
        '
        'celdaNombreCta
        '
        Me.celdaNombreCta.BackColor = System.Drawing.Color.LightGoldenrodYellow
        Me.celdaNombreCta.Location = New System.Drawing.Point(154, 389)
        Me.celdaNombreCta.Name = "celdaNombreCta"
        Me.celdaNombreCta.ReadOnly = True
        Me.celdaNombreCta.Size = New System.Drawing.Size(304, 22)
        Me.celdaNombreCta.TabIndex = 14
        Me.celdaNombreCta.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'celdaNumeroCta
        '
        Me.celdaNumeroCta.BackColor = System.Drawing.Color.LightGoldenrodYellow
        Me.celdaNumeroCta.Location = New System.Drawing.Point(154, 352)
        Me.celdaNumeroCta.Name = "celdaNumeroCta"
        Me.celdaNumeroCta.ReadOnly = True
        Me.celdaNumeroCta.Size = New System.Drawing.Size(259, 22)
        Me.celdaNumeroCta.TabIndex = 13
        Me.celdaNumeroCta.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'celdaPid
        '
        Me.celdaPid.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.celdaPid.Location = New System.Drawing.Point(360, 73)
        Me.celdaPid.Name = "celdaPid"
        Me.celdaPid.ReadOnly = True
        Me.celdaPid.Size = New System.Drawing.Size(177, 22)
        Me.celdaPid.TabIndex = 12
        Me.celdaPid.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'etiquetaOrigen
        '
        Me.etiquetaOrigen.AutoSize = True
        Me.etiquetaOrigen.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.etiquetaOrigen.Location = New System.Drawing.Point(208, 25)
        Me.etiquetaOrigen.Name = "etiquetaOrigen"
        Me.etiquetaOrigen.Size = New System.Drawing.Size(134, 17)
        Me.etiquetaOrigen.TabIndex = 11
        Me.etiquetaOrigen.Text = "Account of Origin"
        '
        'celdaOrigen
        '
        Me.celdaOrigen.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.celdaOrigen.Location = New System.Drawing.Point(211, 45)
        Me.celdaOrigen.Name = "celdaOrigen"
        Me.celdaOrigen.ReadOnly = True
        Me.celdaOrigen.Size = New System.Drawing.Size(326, 22)
        Me.celdaOrigen.TabIndex = 10
        Me.celdaOrigen.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'gbTipoCuenta
        '
        Me.gbTipoCuenta.Controls.Add(Me.rbGastos)
        Me.gbTipoCuenta.Controls.Add(Me.rbIngresos)
        Me.gbTipoCuenta.Controls.Add(Me.rbPasivo)
        Me.gbTipoCuenta.Controls.Add(Me.rbPatrimonio)
        Me.gbTipoCuenta.Controls.Add(Me.rbActivo)
        Me.gbTipoCuenta.Location = New System.Drawing.Point(27, 520)
        Me.gbTipoCuenta.Name = "gbTipoCuenta"
        Me.gbTipoCuenta.Size = New System.Drawing.Size(485, 69)
        Me.gbTipoCuenta.TabIndex = 9
        Me.gbTipoCuenta.TabStop = False
        Me.gbTipoCuenta.Text = "Account type"
        '
        'rbGastos
        '
        Me.rbGastos.AutoSize = True
        Me.rbGastos.Location = New System.Drawing.Point(359, 33)
        Me.rbGastos.Name = "rbGastos"
        Me.rbGastos.Size = New System.Drawing.Size(90, 21)
        Me.rbGastos.TabIndex = 6
        Me.rbGastos.TabStop = True
        Me.rbGastos.Text = "Expenses"
        Me.rbGastos.UseVisualStyleBackColor = True
        '
        'rbIngresos
        '
        Me.rbIngresos.AutoSize = True
        Me.rbIngresos.Location = New System.Drawing.Point(272, 33)
        Me.rbIngresos.Name = "rbIngresos"
        Me.rbIngresos.Size = New System.Drawing.Size(74, 21)
        Me.rbIngresos.TabIndex = 5
        Me.rbIngresos.TabStop = True
        Me.rbIngresos.Text = "Income"
        Me.rbIngresos.UseVisualStyleBackColor = True
        '
        'rbPasivo
        '
        Me.rbPasivo.AutoSize = True
        Me.rbPasivo.Location = New System.Drawing.Point(184, 33)
        Me.rbPasivo.Name = "rbPasivo"
        Me.rbPasivo.Size = New System.Drawing.Size(71, 21)
        Me.rbPasivo.TabIndex = 4
        Me.rbPasivo.TabStop = True
        Me.rbPasivo.Text = "Pasive"
        Me.rbPasivo.UseVisualStyleBackColor = True
        '
        'rbPatrimonio
        '
        Me.rbPatrimonio.AutoSize = True
        Me.rbPatrimonio.Location = New System.Drawing.Point(81, 33)
        Me.rbPatrimonio.Name = "rbPatrimonio"
        Me.rbPatrimonio.Size = New System.Drawing.Size(83, 21)
        Me.rbPatrimonio.TabIndex = 3
        Me.rbPatrimonio.TabStop = True
        Me.rbPatrimonio.Text = "Heritage"
        Me.rbPatrimonio.UseVisualStyleBackColor = True
        '
        'rbActivo
        '
        Me.rbActivo.AutoSize = True
        Me.rbActivo.Location = New System.Drawing.Point(6, 33)
        Me.rbActivo.Name = "rbActivo"
        Me.rbActivo.Size = New System.Drawing.Size(67, 21)
        Me.rbActivo.TabIndex = 2
        Me.rbActivo.TabStop = True
        Me.rbActivo.Text = "Active"
        Me.rbActivo.UseVisualStyleBackColor = True
        '
        'gbSaldo
        '
        Me.gbSaldo.Controls.Add(Me.rbAcreedor)
        Me.gbSaldo.Controls.Add(Me.rbDeudor)
        Me.gbSaldo.Location = New System.Drawing.Point(27, 436)
        Me.gbSaldo.Name = "gbSaldo"
        Me.gbSaldo.Size = New System.Drawing.Size(431, 65)
        Me.gbSaldo.TabIndex = 8
        Me.gbSaldo.TabStop = False
        Me.gbSaldo.Text = "Type Of Balance"
        '
        'rbAcreedor
        '
        Me.rbAcreedor.AutoSize = True
        Me.rbAcreedor.Location = New System.Drawing.Point(130, 35)
        Me.rbAcreedor.Name = "rbAcreedor"
        Me.rbAcreedor.Size = New System.Drawing.Size(79, 21)
        Me.rbAcreedor.TabIndex = 1
        Me.rbAcreedor.TabStop = True
        Me.rbAcreedor.Text = "Creditor"
        Me.rbAcreedor.UseVisualStyleBackColor = True
        '
        'rbDeudor
        '
        Me.rbDeudor.AutoSize = True
        Me.rbDeudor.Location = New System.Drawing.Point(7, 35)
        Me.rbDeudor.Name = "rbDeudor"
        Me.rbDeudor.Size = New System.Drawing.Size(72, 21)
        Me.rbDeudor.TabIndex = 0
        Me.rbDeudor.TabStop = True
        Me.rbDeudor.Text = "Debtor"
        Me.rbDeudor.UseVisualStyleBackColor = True
        '
        'celdaDescripcion
        '
        Me.celdaDescripcion.Location = New System.Drawing.Point(154, 251)
        Me.celdaDescripcion.Multiline = True
        Me.celdaDescripcion.Name = "celdaDescripcion"
        Me.celdaDescripcion.Size = New System.Drawing.Size(304, 72)
        Me.celdaDescripcion.TabIndex = 7
        '
        'celdaNombre
        '
        Me.celdaNombre.Location = New System.Drawing.Point(154, 204)
        Me.celdaNombre.Name = "celdaNombre"
        Me.celdaNombre.Size = New System.Drawing.Size(304, 22)
        Me.celdaNombre.TabIndex = 6
        '
        'celdaCompania
        '
        Me.celdaCompania.Location = New System.Drawing.Point(154, 161)
        Me.celdaCompania.Name = "celdaCompania"
        Me.celdaCompania.ReadOnly = True
        Me.celdaCompania.Size = New System.Drawing.Size(304, 22)
        Me.celdaCompania.TabIndex = 5
        Me.celdaCompania.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'celdaCuenta
        '
        Me.celdaCuenta.Location = New System.Drawing.Point(186, 114)
        Me.celdaCuenta.Name = "celdaCuenta"
        Me.celdaCuenta.ReadOnly = True
        Me.celdaCuenta.Size = New System.Drawing.Size(272, 22)
        Me.celdaCuenta.TabIndex = 4
        Me.celdaCuenta.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'etiquetaDescripcion
        '
        Me.etiquetaDescripcion.AutoSize = True
        Me.etiquetaDescripcion.Location = New System.Drawing.Point(24, 256)
        Me.etiquetaDescripcion.Name = "etiquetaDescripcion"
        Me.etiquetaDescripcion.Size = New System.Drawing.Size(79, 17)
        Me.etiquetaDescripcion.TabIndex = 3
        Me.etiquetaDescripcion.Text = "Description"
        '
        'etiquetaNombre
        '
        Me.etiquetaNombre.AutoSize = True
        Me.etiquetaNombre.Location = New System.Drawing.Point(24, 207)
        Me.etiquetaNombre.Name = "etiquetaNombre"
        Me.etiquetaNombre.Size = New System.Drawing.Size(100, 17)
        Me.etiquetaNombre.TabIndex = 2
        Me.etiquetaNombre.Text = "Account Name"
        '
        'etiquetaEmpresa
        '
        Me.etiquetaEmpresa.AutoSize = True
        Me.etiquetaEmpresa.Location = New System.Drawing.Point(24, 161)
        Me.etiquetaEmpresa.Name = "etiquetaEmpresa"
        Me.etiquetaEmpresa.Size = New System.Drawing.Size(67, 17)
        Me.etiquetaEmpresa.TabIndex = 1
        Me.etiquetaEmpresa.Text = "Company"
        '
        'etiquetaCuenta
        '
        Me.etiquetaCuenta.AutoSize = True
        Me.etiquetaCuenta.Location = New System.Drawing.Point(24, 119)
        Me.etiquetaCuenta.Name = "etiquetaCuenta"
        Me.etiquetaCuenta.Size = New System.Drawing.Size(143, 17)
        Me.etiquetaCuenta.TabIndex = 0
        Me.etiquetaCuenta.Text = "Sub-Account Number"
        '
        'imgLista
        '
        Me.imgLista.ImageStream = CType(resources.GetObject("imgLista.ImageStream"), System.Windows.Forms.ImageListStreamer)
        Me.imgLista.TransparentColor = System.Drawing.Color.Transparent
        Me.imgLista.Images.SetKeyName(0, "Activo.ico")
        Me.imgLista.Images.SetKeyName(1, "Pasivo.ico")
        Me.imgLista.Images.SetKeyName(2, "Patrimonio.ico")
        Me.imgLista.Images.SetKeyName(3, "Ingresos.ico")
        Me.imgLista.Images.SetKeyName(4, "Egresos.ico")
        Me.imgLista.Images.SetKeyName(5, "nodos.ico")
        '
        'BarraTitulo1
        '
        Me.BarraTitulo1.BackColor = System.Drawing.Color.WhiteSmoke
        Me.BarraTitulo1.Dock = System.Windows.Forms.DockStyle.Top
        Me.BarraTitulo1.Location = New System.Drawing.Point(0, 71)
        Me.BarraTitulo1.Margin = New System.Windows.Forms.Padding(4)
        Me.BarraTitulo1.Name = "BarraTitulo1"
        Me.BarraTitulo1.Size = New System.Drawing.Size(1225, 31)
        Me.BarraTitulo1.TabIndex = 1
        '
        'Encabezado1
        '
        Me.Encabezado1.Dock = System.Windows.Forms.DockStyle.Top
        Me.Encabezado1.Location = New System.Drawing.Point(0, 0)
        Me.Encabezado1.Margin = New System.Windows.Forms.Padding(4)
        Me.Encabezado1.Name = "Encabezado1"
        Me.Encabezado1.Size = New System.Drawing.Size(1225, 71)
        Me.Encabezado1.TabIndex = 0
        '
        'frmNomenclatura
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1225, 707)
        Me.Controls.Add(Me.panelEdicion)
        Me.Controls.Add(Me.panelLista)
        Me.Controls.Add(Me.BarraTitulo1)
        Me.Controls.Add(Me.Encabezado1)
        Me.Name = "frmNomenclatura"
        Me.Text = "frmNomenclatura"
        Me.panelLista.ResumeLayout(False)
        Me.panelEdicion.ResumeLayout(False)
        Me.gbCuentas.ResumeLayout(False)
        Me.gbCuentas.PerformLayout()
        Me.gbTipoCuenta.ResumeLayout(False)
        Me.gbTipoCuenta.PerformLayout()
        Me.gbSaldo.ResumeLayout(False)
        Me.gbSaldo.PerformLayout()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents Encabezado1 As encabezado
    Friend WithEvents BarraTitulo1 As BarraTitulo
    Friend WithEvents panelLista As Panel
    Friend WithEvents panelEdicion As Panel
    Friend WithEvents gbCuentas As GroupBox
    Friend WithEvents etiquetaOrigen As Label
    Friend WithEvents celdaOrigen As TextBox
    Friend WithEvents gbTipoCuenta As GroupBox
    Friend WithEvents rbGastos As RadioButton
    Friend WithEvents rbIngresos As RadioButton
    Friend WithEvents rbPasivo As RadioButton
    Friend WithEvents rbPatrimonio As RadioButton
    Friend WithEvents rbActivo As RadioButton
    Friend WithEvents gbSaldo As GroupBox
    Friend WithEvents rbAcreedor As RadioButton
    Friend WithEvents rbDeudor As RadioButton
    Friend WithEvents celdaDescripcion As TextBox
    Friend WithEvents celdaNombre As TextBox
    Friend WithEvents celdaCompania As TextBox
    Friend WithEvents celdaCuenta As TextBox
    Friend WithEvents etiquetaDescripcion As Label
    Friend WithEvents etiquetaNombre As Label
    Friend WithEvents etiquetaEmpresa As Label
    Friend WithEvents etiquetaCuenta As Label
    Friend WithEvents tvLista As TreeView
    Friend WithEvents celdaPid As TextBox
    Friend WithEvents imgLista As ImageList
    Friend WithEvents Button1 As Button
    Friend WithEvents Label2 As Label
    Friend WithEvents Label1 As Label
    Friend WithEvents celdaNombreCta As TextBox
    Friend WithEvents celdaNumeroCta As TextBox
End Class
