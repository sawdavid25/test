﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmDespachoDirecto
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.panelLista = New System.Windows.Forms.Panel()
        Me.dgLista = New System.Windows.Forms.DataGridView()
        Me.colAnio = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colNumero = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colProveedor = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colCliente = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colEstado = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.PanelDocumento = New System.Windows.Forms.Panel()
        Me.panelDetalle = New System.Windows.Forms.Panel()
        Me.dgDetalle = New System.Windows.Forms.DataGridView()
        Me.colLinea = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colCodigo = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colDescripcion = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colidMedida = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colMedida = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colPrecio = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colCantidad = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colTotal = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colComision = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colPorcentajeC = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colExtra = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.PaneBotones = New System.Windows.Forms.Panel()
        Me.botonAbajo = New System.Windows.Forms.Button()
        Me.botonUp = New System.Windows.Forms.Button()
        Me.panelEncabezado = New System.Windows.Forms.Panel()
        Me.gbCliente = New System.Windows.Forms.GroupBox()
        Me.etiquetaDireccionCliente = New System.Windows.Forms.Label()
        Me.celdaDireccionCliente = New System.Windows.Forms.TextBox()
        Me.celdaidCliente = New System.Windows.Forms.TextBox()
        Me.botonCliente = New System.Windows.Forms.Button()
        Me.celdaCliente = New System.Windows.Forms.TextBox()
        Me.etiquetaCliente = New System.Windows.Forms.Label()
        Me.gbProveedor = New System.Windows.Forms.GroupBox()
        Me.celdaIDMoneda = New System.Windows.Forms.TextBox()
        Me.celdaTC = New System.Windows.Forms.TextBox()
        Me.etiquetaTasa = New System.Windows.Forms.Label()
        Me.botonMoneda = New System.Windows.Forms.Button()
        Me.celdaMoneda = New System.Windows.Forms.TextBox()
        Me.etiquetaMoneda = New System.Windows.Forms.Label()
        Me.checkActive = New System.Windows.Forms.CheckBox()
        Me.celdaidProveedor = New System.Windows.Forms.TextBox()
        Me.botonProveedor = New System.Windows.Forms.Button()
        Me.etiquetaDireccion = New System.Windows.Forms.Label()
        Me.celdaDireccionProveedor = New System.Windows.Forms.TextBox()
        Me.celdaProveedor = New System.Windows.Forms.TextBox()
        Me.etiquetaProveedor = New System.Windows.Forms.Label()
        Me.dtpFecha = New System.Windows.Forms.DateTimePicker()
        Me.etiquetaFecha = New System.Windows.Forms.Label()
        Me.celdaNumero = New System.Windows.Forms.TextBox()
        Me.etiquetaNumero = New System.Windows.Forms.Label()
        Me.celdaAño = New System.Windows.Forms.TextBox()
        Me.etiquetaAño = New System.Windows.Forms.Label()
        Me.panelTotales = New System.Windows.Forms.Panel()
        Me.celdaComisionPorcentaje = New System.Windows.Forms.TextBox()
        Me.etiquetaComisionPorcentaje = New System.Windows.Forms.Label()
        Me.celdaComision = New System.Windows.Forms.TextBox()
        Me.etiquetaComision = New System.Windows.Forms.Label()
        Me.celdaCantidad = New System.Windows.Forms.TextBox()
        Me.etiquetaCantidad = New System.Windows.Forms.Label()
        Me.etiquetaTotal = New System.Windows.Forms.Label()
        Me.celdaTotal = New System.Windows.Forms.TextBox()
        Me.BarraTitulo1 = New KARIMs_SGI.BarraTitulo()
        Me.Encabezado1 = New KARIMs_SGI.encabezado()
        Me.panelLista.SuspendLayout()
        CType(Me.dgLista, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.PanelDocumento.SuspendLayout()
        Me.panelDetalle.SuspendLayout()
        CType(Me.dgDetalle, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.PaneBotones.SuspendLayout()
        Me.panelEncabezado.SuspendLayout()
        Me.gbCliente.SuspendLayout()
        Me.gbProveedor.SuspendLayout()
        Me.panelTotales.SuspendLayout()
        Me.SuspendLayout()
        '
        'panelLista
        '
        Me.panelLista.AllowDrop = True
        Me.panelLista.Controls.Add(Me.dgLista)
        Me.panelLista.Location = New System.Drawing.Point(38, 106)
        Me.panelLista.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.panelLista.Name = "panelLista"
        Me.panelLista.Size = New System.Drawing.Size(130, 29)
        Me.panelLista.TabIndex = 2
        '
        'dgLista
        '
        Me.dgLista.AllowUserToAddRows = False
        Me.dgLista.AllowUserToDeleteRows = False
        Me.dgLista.AllowUserToOrderColumns = True
        Me.dgLista.BackgroundColor = System.Drawing.SystemColors.Control
        Me.dgLista.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgLista.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.colAnio, Me.colNumero, Me.colProveedor, Me.colCliente, Me.colEstado})
        Me.dgLista.Dock = System.Windows.Forms.DockStyle.Fill
        Me.dgLista.Location = New System.Drawing.Point(0, 0)
        Me.dgLista.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.dgLista.Name = "dgLista"
        Me.dgLista.ReadOnly = True
        Me.dgLista.RowTemplate.Height = 24
        Me.dgLista.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.dgLista.Size = New System.Drawing.Size(130, 29)
        Me.dgLista.TabIndex = 0
        '
        'colAnio
        '
        Me.colAnio.HeaderText = "Anio"
        Me.colAnio.Name = "colAnio"
        Me.colAnio.ReadOnly = True
        '
        'colNumero
        '
        Me.colNumero.HeaderText = "Numero"
        Me.colNumero.Name = "colNumero"
        Me.colNumero.ReadOnly = True
        '
        'colProveedor
        '
        Me.colProveedor.HeaderText = "Provider"
        Me.colProveedor.Name = "colProveedor"
        Me.colProveedor.ReadOnly = True
        '
        'colCliente
        '
        Me.colCliente.HeaderText = "Client"
        Me.colCliente.Name = "colCliente"
        Me.colCliente.ReadOnly = True
        '
        'colEstado
        '
        Me.colEstado.HeaderText = "Status"
        Me.colEstado.Name = "colEstado"
        Me.colEstado.ReadOnly = True
        '
        'PanelDocumento
        '
        Me.PanelDocumento.Controls.Add(Me.panelDetalle)
        Me.PanelDocumento.Controls.Add(Me.panelEncabezado)
        Me.PanelDocumento.Controls.Add(Me.panelTotales)
        Me.PanelDocumento.Location = New System.Drawing.Point(9, 140)
        Me.PanelDocumento.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.PanelDocumento.Name = "PanelDocumento"
        Me.PanelDocumento.Size = New System.Drawing.Size(698, 309)
        Me.PanelDocumento.TabIndex = 3
        '
        'panelDetalle
        '
        Me.panelDetalle.Controls.Add(Me.dgDetalle)
        Me.panelDetalle.Controls.Add(Me.PaneBotones)
        Me.panelDetalle.Dock = System.Windows.Forms.DockStyle.Fill
        Me.panelDetalle.Location = New System.Drawing.Point(0, 180)
        Me.panelDetalle.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.panelDetalle.Name = "panelDetalle"
        Me.panelDetalle.Size = New System.Drawing.Size(698, 75)
        Me.panelDetalle.TabIndex = 1
        '
        'dgDetalle
        '
        Me.dgDetalle.AllowUserToAddRows = False
        Me.dgDetalle.AllowUserToDeleteRows = False
        Me.dgDetalle.AllowUserToOrderColumns = True
        Me.dgDetalle.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells
        Me.dgDetalle.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells
        Me.dgDetalle.BackgroundColor = System.Drawing.SystemColors.Control
        Me.dgDetalle.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgDetalle.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.colLinea, Me.colCodigo, Me.colDescripcion, Me.colidMedida, Me.colMedida, Me.colPrecio, Me.colCantidad, Me.colTotal, Me.colComision, Me.colPorcentajeC, Me.colExtra})
        Me.dgDetalle.Dock = System.Windows.Forms.DockStyle.Fill
        Me.dgDetalle.Location = New System.Drawing.Point(0, 0)
        Me.dgDetalle.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.dgDetalle.Name = "dgDetalle"
        Me.dgDetalle.RowTemplate.Height = 24
        Me.dgDetalle.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.dgDetalle.Size = New System.Drawing.Size(660, 75)
        Me.dgDetalle.TabIndex = 0
        '
        'colLinea
        '
        Me.colLinea.HeaderText = "Linea"
        Me.colLinea.Name = "colLinea"
        Me.colLinea.Width = 58
        '
        'colCodigo
        '
        Me.colCodigo.HeaderText = "Code"
        Me.colCodigo.Name = "colCodigo"
        Me.colCodigo.ReadOnly = True
        Me.colCodigo.Width = 57
        '
        'colDescripcion
        '
        Me.colDescripcion.HeaderText = "Description"
        Me.colDescripcion.Name = "colDescripcion"
        Me.colDescripcion.ReadOnly = True
        Me.colDescripcion.Width = 85
        '
        'colidMedida
        '
        Me.colidMedida.HeaderText = "Medida"
        Me.colidMedida.Name = "colidMedida"
        Me.colidMedida.ReadOnly = True
        Me.colidMedida.Width = 67
        '
        'colMedida
        '
        Me.colMedida.HeaderText = "Measure"
        Me.colMedida.Name = "colMedida"
        Me.colMedida.ReadOnly = True
        Me.colMedida.Width = 73
        '
        'colPrecio
        '
        Me.colPrecio.HeaderText = "Price"
        Me.colPrecio.Name = "colPrecio"
        Me.colPrecio.Width = 56
        '
        'colCantidad
        '
        Me.colCantidad.HeaderText = "Quantity"
        Me.colCantidad.Name = "colCantidad"
        Me.colCantidad.Width = 71
        '
        'colTotal
        '
        Me.colTotal.HeaderText = "Total"
        Me.colTotal.Name = "colTotal"
        Me.colTotal.ReadOnly = True
        Me.colTotal.Width = 56
        '
        'colComision
        '
        Me.colComision.HeaderText = "Commission"
        Me.colComision.Name = "colComision"
        Me.colComision.Width = 87
        '
        'colPorcentajeC
        '
        Me.colPorcentajeC.HeaderText = "Commission %"
        Me.colPorcentajeC.Name = "colPorcentajeC"
        Me.colPorcentajeC.Width = 98
        '
        'colExtra
        '
        Me.colExtra.HeaderText = "Extra"
        Me.colExtra.Name = "colExtra"
        Me.colExtra.Visible = False
        Me.colExtra.Width = 69
        '
        'PaneBotones
        '
        Me.PaneBotones.Controls.Add(Me.botonAbajo)
        Me.PaneBotones.Controls.Add(Me.botonUp)
        Me.PaneBotones.Dock = System.Windows.Forms.DockStyle.Right
        Me.PaneBotones.Location = New System.Drawing.Point(660, 0)
        Me.PaneBotones.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.PaneBotones.Name = "PaneBotones"
        Me.PaneBotones.Size = New System.Drawing.Size(38, 75)
        Me.PaneBotones.TabIndex = 14
        '
        'botonAbajo
        '
        Me.botonAbajo.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.botonAbajo.Image = Global.KARIMs_SGI.My.Resources.Resources.delete31
        Me.botonAbajo.Location = New System.Drawing.Point(3, 39)
        Me.botonAbajo.Name = "botonAbajo"
        Me.botonAbajo.Size = New System.Drawing.Size(32, 25)
        Me.botonAbajo.TabIndex = 32
        Me.botonAbajo.UseVisualStyleBackColor = True
        '
        'botonUp
        '
        Me.botonUp.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.botonUp.Image = Global.KARIMs_SGI.My.Resources.Resources.arrow_up_blue
        Me.botonUp.Location = New System.Drawing.Point(3, 13)
        Me.botonUp.Name = "botonUp"
        Me.botonUp.Size = New System.Drawing.Size(32, 23)
        Me.botonUp.TabIndex = 31
        Me.botonUp.UseVisualStyleBackColor = True
        '
        'panelEncabezado
        '
        Me.panelEncabezado.Controls.Add(Me.gbCliente)
        Me.panelEncabezado.Controls.Add(Me.gbProveedor)
        Me.panelEncabezado.Dock = System.Windows.Forms.DockStyle.Top
        Me.panelEncabezado.Location = New System.Drawing.Point(0, 0)
        Me.panelEncabezado.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.panelEncabezado.Name = "panelEncabezado"
        Me.panelEncabezado.Size = New System.Drawing.Size(698, 180)
        Me.panelEncabezado.TabIndex = 0
        '
        'gbCliente
        '
        Me.gbCliente.Controls.Add(Me.etiquetaDireccionCliente)
        Me.gbCliente.Controls.Add(Me.celdaDireccionCliente)
        Me.gbCliente.Controls.Add(Me.celdaidCliente)
        Me.gbCliente.Controls.Add(Me.botonCliente)
        Me.gbCliente.Controls.Add(Me.celdaCliente)
        Me.gbCliente.Controls.Add(Me.etiquetaCliente)
        Me.gbCliente.Dock = System.Windows.Forms.DockStyle.Fill
        Me.gbCliente.Location = New System.Drawing.Point(392, 0)
        Me.gbCliente.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.gbCliente.Name = "gbCliente"
        Me.gbCliente.Padding = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.gbCliente.Size = New System.Drawing.Size(306, 180)
        Me.gbCliente.TabIndex = 1
        Me.gbCliente.TabStop = False
        Me.gbCliente.Text = "Client"
        '
        'etiquetaDireccionCliente
        '
        Me.etiquetaDireccionCliente.AutoSize = True
        Me.etiquetaDireccionCliente.Location = New System.Drawing.Point(10, 50)
        Me.etiquetaDireccionCliente.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.etiquetaDireccionCliente.Name = "etiquetaDireccionCliente"
        Me.etiquetaDireccionCliente.Size = New System.Drawing.Size(45, 13)
        Me.etiquetaDireccionCliente.TabIndex = 16
        Me.etiquetaDireccionCliente.Text = "Address"
        '
        'celdaDireccionCliente
        '
        Me.celdaDireccionCliente.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.celdaDireccionCliente.Location = New System.Drawing.Point(60, 46)
        Me.celdaDireccionCliente.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.celdaDireccionCliente.Multiline = True
        Me.celdaDireccionCliente.Name = "celdaDireccionCliente"
        Me.celdaDireccionCliente.ReadOnly = True
        Me.celdaDireccionCliente.Size = New System.Drawing.Size(218, 39)
        Me.celdaDireccionCliente.TabIndex = 15
        '
        'celdaidCliente
        '
        Me.celdaidCliente.Location = New System.Drawing.Point(60, 90)
        Me.celdaidCliente.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.celdaidCliente.Name = "celdaidCliente"
        Me.celdaidCliente.Size = New System.Drawing.Size(20, 20)
        Me.celdaidCliente.TabIndex = 14
        Me.celdaidCliente.Visible = False
        '
        'botonCliente
        '
        Me.botonCliente.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.botonCliente.Location = New System.Drawing.Point(250, 18)
        Me.botonCliente.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.botonCliente.Name = "botonCliente"
        Me.botonCliente.Size = New System.Drawing.Size(27, 19)
        Me.botonCliente.TabIndex = 13
        Me.botonCliente.Text = "..."
        Me.botonCliente.UseVisualStyleBackColor = True
        '
        'celdaCliente
        '
        Me.celdaCliente.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.celdaCliente.ForeColor = System.Drawing.SystemColors.WindowText
        Me.celdaCliente.Location = New System.Drawing.Point(60, 19)
        Me.celdaCliente.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.celdaCliente.Name = "celdaCliente"
        Me.celdaCliente.ReadOnly = True
        Me.celdaCliente.Size = New System.Drawing.Size(186, 20)
        Me.celdaCliente.TabIndex = 12
        '
        'etiquetaCliente
        '
        Me.etiquetaCliente.AutoSize = True
        Me.etiquetaCliente.Location = New System.Drawing.Point(4, 19)
        Me.etiquetaCliente.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.etiquetaCliente.Name = "etiquetaCliente"
        Me.etiquetaCliente.Size = New System.Drawing.Size(51, 13)
        Me.etiquetaCliente.TabIndex = 11
        Me.etiquetaCliente.Text = "Customer"
        '
        'gbProveedor
        '
        Me.gbProveedor.Controls.Add(Me.celdaIDMoneda)
        Me.gbProveedor.Controls.Add(Me.celdaTC)
        Me.gbProveedor.Controls.Add(Me.etiquetaTasa)
        Me.gbProveedor.Controls.Add(Me.botonMoneda)
        Me.gbProveedor.Controls.Add(Me.celdaMoneda)
        Me.gbProveedor.Controls.Add(Me.etiquetaMoneda)
        Me.gbProveedor.Controls.Add(Me.checkActive)
        Me.gbProveedor.Controls.Add(Me.celdaidProveedor)
        Me.gbProveedor.Controls.Add(Me.botonProveedor)
        Me.gbProveedor.Controls.Add(Me.etiquetaDireccion)
        Me.gbProveedor.Controls.Add(Me.celdaDireccionProveedor)
        Me.gbProveedor.Controls.Add(Me.celdaProveedor)
        Me.gbProveedor.Controls.Add(Me.etiquetaProveedor)
        Me.gbProveedor.Controls.Add(Me.dtpFecha)
        Me.gbProveedor.Controls.Add(Me.etiquetaFecha)
        Me.gbProveedor.Controls.Add(Me.celdaNumero)
        Me.gbProveedor.Controls.Add(Me.etiquetaNumero)
        Me.gbProveedor.Controls.Add(Me.celdaAño)
        Me.gbProveedor.Controls.Add(Me.etiquetaAño)
        Me.gbProveedor.Dock = System.Windows.Forms.DockStyle.Left
        Me.gbProveedor.Location = New System.Drawing.Point(0, 0)
        Me.gbProveedor.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.gbProveedor.Name = "gbProveedor"
        Me.gbProveedor.Padding = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.gbProveedor.Size = New System.Drawing.Size(392, 180)
        Me.gbProveedor.TabIndex = 0
        Me.gbProveedor.TabStop = False
        Me.gbProveedor.Text = "Provider"
        '
        'celdaIDMoneda
        '
        Me.celdaIDMoneda.Location = New System.Drawing.Point(178, 155)
        Me.celdaIDMoneda.Name = "celdaIDMoneda"
        Me.celdaIDMoneda.Size = New System.Drawing.Size(27, 20)
        Me.celdaIDMoneda.TabIndex = 30
        Me.celdaIDMoneda.Text = "-1"
        Me.celdaIDMoneda.Visible = False
        '
        'celdaTC
        '
        Me.celdaTC.Location = New System.Drawing.Point(256, 154)
        Me.celdaTC.Name = "celdaTC"
        Me.celdaTC.Size = New System.Drawing.Size(71, 20)
        Me.celdaTC.TabIndex = 29
        '
        'etiquetaTasa
        '
        Me.etiquetaTasa.AutoSize = True
        Me.etiquetaTasa.Location = New System.Drawing.Point(222, 158)
        Me.etiquetaTasa.Name = "etiquetaTasa"
        Me.etiquetaTasa.Size = New System.Drawing.Size(30, 13)
        Me.etiquetaTasa.TabIndex = 28
        Me.etiquetaTasa.Text = "Rate"
        '
        'botonMoneda
        '
        Me.botonMoneda.Location = New System.Drawing.Point(135, 154)
        Me.botonMoneda.Name = "botonMoneda"
        Me.botonMoneda.Size = New System.Drawing.Size(30, 23)
        Me.botonMoneda.TabIndex = 27
        Me.botonMoneda.Text = "..."
        Me.botonMoneda.UseVisualStyleBackColor = True
        '
        'celdaMoneda
        '
        Me.celdaMoneda.Location = New System.Drawing.Point(55, 156)
        Me.celdaMoneda.Name = "celdaMoneda"
        Me.celdaMoneda.ReadOnly = True
        Me.celdaMoneda.Size = New System.Drawing.Size(71, 20)
        Me.celdaMoneda.TabIndex = 26
        '
        'etiquetaMoneda
        '
        Me.etiquetaMoneda.AutoSize = True
        Me.etiquetaMoneda.Location = New System.Drawing.Point(3, 155)
        Me.etiquetaMoneda.Name = "etiquetaMoneda"
        Me.etiquetaMoneda.Size = New System.Drawing.Size(49, 13)
        Me.etiquetaMoneda.TabIndex = 25
        Me.etiquetaMoneda.Text = "Currency"
        '
        'checkActive
        '
        Me.checkActive.AutoSize = True
        Me.checkActive.Checked = True
        Me.checkActive.CheckState = System.Windows.Forms.CheckState.Checked
        Me.checkActive.Location = New System.Drawing.Point(217, 20)
        Me.checkActive.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.checkActive.Name = "checkActive"
        Me.checkActive.Size = New System.Drawing.Size(56, 17)
        Me.checkActive.TabIndex = 12
        Me.checkActive.Text = "Active"
        Me.checkActive.UseVisualStyleBackColor = True
        '
        'celdaidProveedor
        '
        Me.celdaidProveedor.Location = New System.Drawing.Point(285, 62)
        Me.celdaidProveedor.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.celdaidProveedor.Name = "celdaidProveedor"
        Me.celdaidProveedor.Size = New System.Drawing.Size(20, 20)
        Me.celdaidProveedor.TabIndex = 11
        Me.celdaidProveedor.Visible = False
        '
        'botonProveedor
        '
        Me.botonProveedor.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.botonProveedor.Location = New System.Drawing.Point(358, 89)
        Me.botonProveedor.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.botonProveedor.Name = "botonProveedor"
        Me.botonProveedor.Size = New System.Drawing.Size(28, 19)
        Me.botonProveedor.TabIndex = 10
        Me.botonProveedor.Text = "..."
        Me.botonProveedor.UseVisualStyleBackColor = True
        '
        'etiquetaDireccion
        '
        Me.etiquetaDireccion.AutoSize = True
        Me.etiquetaDireccion.Location = New System.Drawing.Point(4, 115)
        Me.etiquetaDireccion.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.etiquetaDireccion.Name = "etiquetaDireccion"
        Me.etiquetaDireccion.Size = New System.Drawing.Size(45, 13)
        Me.etiquetaDireccion.TabIndex = 9
        Me.etiquetaDireccion.Text = "Address"
        '
        'celdaDireccionProveedor
        '
        Me.celdaDireccionProveedor.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.celdaDireccionProveedor.Location = New System.Drawing.Point(55, 111)
        Me.celdaDireccionProveedor.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.celdaDireccionProveedor.Multiline = True
        Me.celdaDireccionProveedor.Name = "celdaDireccionProveedor"
        Me.celdaDireccionProveedor.ReadOnly = True
        Me.celdaDireccionProveedor.Size = New System.Drawing.Size(333, 37)
        Me.celdaDireccionProveedor.TabIndex = 8
        '
        'celdaProveedor
        '
        Me.celdaProveedor.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.celdaProveedor.ForeColor = System.Drawing.SystemColors.WindowText
        Me.celdaProveedor.Location = New System.Drawing.Point(55, 89)
        Me.celdaProveedor.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.celdaProveedor.Name = "celdaProveedor"
        Me.celdaProveedor.ReadOnly = True
        Me.celdaProveedor.Size = New System.Drawing.Size(300, 20)
        Me.celdaProveedor.TabIndex = 7
        '
        'etiquetaProveedor
        '
        Me.etiquetaProveedor.AutoSize = True
        Me.etiquetaProveedor.Location = New System.Drawing.Point(4, 90)
        Me.etiquetaProveedor.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.etiquetaProveedor.Name = "etiquetaProveedor"
        Me.etiquetaProveedor.Size = New System.Drawing.Size(46, 13)
        Me.etiquetaProveedor.TabIndex = 6
        Me.etiquetaProveedor.Text = "Provider"
        '
        'dtpFecha
        '
        Me.dtpFecha.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.dtpFecha.Location = New System.Drawing.Point(52, 62)
        Me.dtpFecha.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.dtpFecha.Name = "dtpFecha"
        Me.dtpFecha.Size = New System.Drawing.Size(108, 20)
        Me.dtpFecha.TabIndex = 5
        '
        'etiquetaFecha
        '
        Me.etiquetaFecha.AutoSize = True
        Me.etiquetaFecha.Location = New System.Drawing.Point(4, 66)
        Me.etiquetaFecha.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.etiquetaFecha.Name = "etiquetaFecha"
        Me.etiquetaFecha.Size = New System.Drawing.Size(30, 13)
        Me.etiquetaFecha.TabIndex = 4
        Me.etiquetaFecha.Text = "Date"
        '
        'celdaNumero
        '
        Me.celdaNumero.BackColor = System.Drawing.SystemColors.Info
        Me.celdaNumero.ForeColor = System.Drawing.SystemColors.MenuHighlight
        Me.celdaNumero.Location = New System.Drawing.Point(52, 39)
        Me.celdaNumero.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.celdaNumero.Name = "celdaNumero"
        Me.celdaNumero.ReadOnly = True
        Me.celdaNumero.Size = New System.Drawing.Size(108, 20)
        Me.celdaNumero.TabIndex = 3
        '
        'etiquetaNumero
        '
        Me.etiquetaNumero.AutoSize = True
        Me.etiquetaNumero.Location = New System.Drawing.Point(4, 39)
        Me.etiquetaNumero.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.etiquetaNumero.Name = "etiquetaNumero"
        Me.etiquetaNumero.Size = New System.Drawing.Size(44, 13)
        Me.etiquetaNumero.TabIndex = 2
        Me.etiquetaNumero.Text = "Number"
        '
        'celdaAño
        '
        Me.celdaAño.BackColor = System.Drawing.SystemColors.Info
        Me.celdaAño.ForeColor = System.Drawing.SystemColors.MenuHighlight
        Me.celdaAño.Location = New System.Drawing.Point(52, 16)
        Me.celdaAño.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.celdaAño.Name = "celdaAño"
        Me.celdaAño.ReadOnly = True
        Me.celdaAño.Size = New System.Drawing.Size(108, 20)
        Me.celdaAño.TabIndex = 1
        '
        'etiquetaAño
        '
        Me.etiquetaAño.AutoSize = True
        Me.etiquetaAño.Location = New System.Drawing.Point(4, 19)
        Me.etiquetaAño.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.etiquetaAño.Name = "etiquetaAño"
        Me.etiquetaAño.Size = New System.Drawing.Size(29, 13)
        Me.etiquetaAño.TabIndex = 0
        Me.etiquetaAño.Text = "Year"
        '
        'panelTotales
        '
        Me.panelTotales.Controls.Add(Me.celdaComisionPorcentaje)
        Me.panelTotales.Controls.Add(Me.etiquetaComisionPorcentaje)
        Me.panelTotales.Controls.Add(Me.celdaComision)
        Me.panelTotales.Controls.Add(Me.etiquetaComision)
        Me.panelTotales.Controls.Add(Me.celdaCantidad)
        Me.panelTotales.Controls.Add(Me.etiquetaCantidad)
        Me.panelTotales.Controls.Add(Me.etiquetaTotal)
        Me.panelTotales.Controls.Add(Me.celdaTotal)
        Me.panelTotales.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.panelTotales.Location = New System.Drawing.Point(0, 255)
        Me.panelTotales.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.panelTotales.Name = "panelTotales"
        Me.panelTotales.Size = New System.Drawing.Size(698, 54)
        Me.panelTotales.TabIndex = 2
        '
        'celdaComisionPorcentaje
        '
        Me.celdaComisionPorcentaje.Location = New System.Drawing.Point(590, 24)
        Me.celdaComisionPorcentaje.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.celdaComisionPorcentaje.Name = "celdaComisionPorcentaje"
        Me.celdaComisionPorcentaje.Size = New System.Drawing.Size(96, 20)
        Me.celdaComisionPorcentaje.TabIndex = 7
        '
        'etiquetaComisionPorcentaje
        '
        Me.etiquetaComisionPorcentaje.AutoSize = True
        Me.etiquetaComisionPorcentaje.Location = New System.Drawing.Point(511, 26)
        Me.etiquetaComisionPorcentaje.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.etiquetaComisionPorcentaje.Name = "etiquetaComisionPorcentaje"
        Me.etiquetaComisionPorcentaje.Size = New System.Drawing.Size(73, 13)
        Me.etiquetaComisionPorcentaje.TabIndex = 6
        Me.etiquetaComisionPorcentaje.Text = "Commission %"
        '
        'celdaComision
        '
        Me.celdaComision.Location = New System.Drawing.Point(404, 24)
        Me.celdaComision.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.celdaComision.Name = "celdaComision"
        Me.celdaComision.Size = New System.Drawing.Size(96, 20)
        Me.celdaComision.TabIndex = 5
        '
        'etiquetaComision
        '
        Me.etiquetaComision.AutoSize = True
        Me.etiquetaComision.Location = New System.Drawing.Point(329, 26)
        Me.etiquetaComision.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.etiquetaComision.Name = "etiquetaComision"
        Me.etiquetaComision.Size = New System.Drawing.Size(62, 13)
        Me.etiquetaComision.TabIndex = 4
        Me.etiquetaComision.Text = "Commission"
        '
        'celdaCantidad
        '
        Me.celdaCantidad.Location = New System.Drawing.Point(224, 24)
        Me.celdaCantidad.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.celdaCantidad.Name = "celdaCantidad"
        Me.celdaCantidad.Size = New System.Drawing.Size(97, 20)
        Me.celdaCantidad.TabIndex = 3
        '
        'etiquetaCantidad
        '
        Me.etiquetaCantidad.AutoSize = True
        Me.etiquetaCantidad.Location = New System.Drawing.Point(164, 24)
        Me.etiquetaCantidad.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.etiquetaCantidad.Name = "etiquetaCantidad"
        Me.etiquetaCantidad.Size = New System.Drawing.Size(46, 13)
        Me.etiquetaCantidad.TabIndex = 2
        Me.etiquetaCantidad.Text = "Quantity"
        '
        'etiquetaTotal
        '
        Me.etiquetaTotal.AutoSize = True
        Me.etiquetaTotal.Location = New System.Drawing.Point(18, 24)
        Me.etiquetaTotal.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.etiquetaTotal.Name = "etiquetaTotal"
        Me.etiquetaTotal.Size = New System.Drawing.Size(31, 13)
        Me.etiquetaTotal.TabIndex = 1
        Me.etiquetaTotal.Text = "Total"
        '
        'celdaTotal
        '
        Me.celdaTotal.Location = New System.Drawing.Point(55, 24)
        Me.celdaTotal.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.celdaTotal.Name = "celdaTotal"
        Me.celdaTotal.Size = New System.Drawing.Size(97, 20)
        Me.celdaTotal.TabIndex = 0
        '
        'BarraTitulo1
        '
        Me.BarraTitulo1.BackColor = System.Drawing.Color.WhiteSmoke
        Me.BarraTitulo1.Dock = System.Windows.Forms.DockStyle.Top
        Me.BarraTitulo1.Location = New System.Drawing.Point(0, 70)
        Me.BarraTitulo1.Name = "BarraTitulo1"
        Me.BarraTitulo1.Size = New System.Drawing.Size(732, 30)
        Me.BarraTitulo1.TabIndex = 1
        '
        'Encabezado1
        '
        Me.Encabezado1.Dock = System.Windows.Forms.DockStyle.Top
        Me.Encabezado1.Location = New System.Drawing.Point(0, 0)
        Me.Encabezado1.Name = "Encabezado1"
        Me.Encabezado1.Size = New System.Drawing.Size(732, 70)
        Me.Encabezado1.TabIndex = 0
        '
        'frmDespachoDirecto
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(732, 458)
        Me.Controls.Add(Me.PanelDocumento)
        Me.Controls.Add(Me.panelLista)
        Me.Controls.Add(Me.BarraTitulo1)
        Me.Controls.Add(Me.Encabezado1)
        Me.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.Name = "frmDespachoDirecto"
        Me.Text = "frmDespachoDirecto"
        Me.panelLista.ResumeLayout(False)
        CType(Me.dgLista, System.ComponentModel.ISupportInitialize).EndInit()
        Me.PanelDocumento.ResumeLayout(False)
        Me.panelDetalle.ResumeLayout(False)
        CType(Me.dgDetalle, System.ComponentModel.ISupportInitialize).EndInit()
        Me.PaneBotones.ResumeLayout(False)
        Me.panelEncabezado.ResumeLayout(False)
        Me.gbCliente.ResumeLayout(False)
        Me.gbCliente.PerformLayout()
        Me.gbProveedor.ResumeLayout(False)
        Me.gbProveedor.PerformLayout()
        Me.panelTotales.ResumeLayout(False)
        Me.panelTotales.PerformLayout()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents Encabezado1 As encabezado
    Friend WithEvents BarraTitulo1 As BarraTitulo
    Friend WithEvents panelLista As Panel
    Friend WithEvents dgLista As DataGridView
    Friend WithEvents PanelDocumento As Panel
    Friend WithEvents panelDetalle As Panel
    Friend WithEvents dgDetalle As DataGridView
    Friend WithEvents panelEncabezado As Panel
    Friend WithEvents gbCliente As GroupBox
    Friend WithEvents etiquetaDireccionCliente As Label
    Friend WithEvents celdaDireccionCliente As TextBox
    Friend WithEvents celdaidCliente As TextBox
    Friend WithEvents botonCliente As Button
    Friend WithEvents celdaCliente As TextBox
    Friend WithEvents etiquetaCliente As Label
    Friend WithEvents gbProveedor As GroupBox
    Friend WithEvents celdaidProveedor As TextBox
    Friend WithEvents botonProveedor As Button
    Friend WithEvents etiquetaDireccion As Label
    Friend WithEvents celdaDireccionProveedor As TextBox
    Friend WithEvents celdaProveedor As TextBox
    Friend WithEvents etiquetaProveedor As Label
    Friend WithEvents dtpFecha As DateTimePicker
    Friend WithEvents etiquetaFecha As Label
    Friend WithEvents celdaNumero As TextBox
    Friend WithEvents etiquetaNumero As Label
    Friend WithEvents celdaAño As TextBox
    Friend WithEvents etiquetaAño As Label
    Friend WithEvents PaneBotones As Panel
    Friend WithEvents botonAbajo As Button
    Friend WithEvents botonUp As Button
    Friend WithEvents panelTotales As Panel
    Friend WithEvents etiquetaTotal As Label
    Friend WithEvents celdaTotal As TextBox
    Friend WithEvents celdaComision As TextBox
    Friend WithEvents etiquetaComision As Label
    Friend WithEvents celdaCantidad As TextBox
    Friend WithEvents etiquetaCantidad As Label
    Friend WithEvents checkActive As System.Windows.Forms.CheckBox
    Friend WithEvents celdaComisionPorcentaje As TextBox
    Friend WithEvents etiquetaComisionPorcentaje As Label
    Friend WithEvents botonMoneda As Button
    Friend WithEvents celdaMoneda As TextBox
    Friend WithEvents etiquetaMoneda As Label
    Friend WithEvents celdaIDMoneda As TextBox
    Friend WithEvents celdaTC As TextBox
    Friend WithEvents etiquetaTasa As Label
    Friend WithEvents colAnio As DataGridViewTextBoxColumn
    Friend WithEvents colNumero As DataGridViewTextBoxColumn
    Friend WithEvents colProveedor As DataGridViewTextBoxColumn
    Friend WithEvents colCliente As DataGridViewTextBoxColumn
    Friend WithEvents colEstado As DataGridViewTextBoxColumn
    Friend WithEvents colLinea As DataGridViewTextBoxColumn
    Friend WithEvents colCodigo As DataGridViewTextBoxColumn
    Friend WithEvents colDescripcion As DataGridViewTextBoxColumn
    Friend WithEvents colidMedida As DataGridViewTextBoxColumn
    Friend WithEvents colMedida As DataGridViewTextBoxColumn
    Friend WithEvents colPrecio As DataGridViewTextBoxColumn
    Friend WithEvents colCantidad As DataGridViewTextBoxColumn
    Friend WithEvents colTotal As DataGridViewTextBoxColumn
    Friend WithEvents colComision As DataGridViewTextBoxColumn
    Friend WithEvents colPorcentajeC As DataGridViewTextBoxColumn
    Friend WithEvents colExtra As DataGridViewTextBoxColumn
End Class
