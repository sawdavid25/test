﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmDevoluciones
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmDevoluciones))
        Me.panelLista = New System.Windows.Forms.Panel()
        Me.dgLista = New System.Windows.Forms.DataGridView()
        Me.colNumero = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colFecha = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colCodEmpresa = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colCliente = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colReferencia = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colAnio = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colEstado = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colDireccion = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colMoneda = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colTasa = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colIDAprovado = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colAprovadoPor = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.coLIDCCosto = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colCCosto = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colDevolucion = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colComentario = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colEmp = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.panelEncabezadoLista = New System.Windows.Forms.Panel()
        Me.botonClienteE = New System.Windows.Forms.Button()
        Me.celdaClienteE = New System.Windows.Forms.TextBox()
        Me.etiquetaClienteE = New System.Windows.Forms.Label()
        Me.botonActualizar = New System.Windows.Forms.Button()
        Me.etiquetaFechas = New System.Windows.Forms.Label()
        Me.dtpFinal = New System.Windows.Forms.DateTimePicker()
        Me.dtpInicial = New System.Windows.Forms.DateTimePicker()
        Me.checkFechas = New System.Windows.Forms.CheckBox()
        Me.panelDetalle = New System.Windows.Forms.Panel()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.botonQuitar = New System.Windows.Forms.Button()
        Me.botonAgregar = New System.Windows.Forms.Button()
        Me.DgDetalle = New System.Windows.Forms.DataGridView()
        Me.colEmpresa = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colCatalogo = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colAnioFactura = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colCodigoDet = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colProductoDet = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colFacturaDet = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colLinea = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colLineaDevolucion = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colIDMedida = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colUMedida = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colLoteDet = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colLoteDetDev = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colCantidadDet = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colPrecioDet = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colPrecioKg = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colCantidadKG = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colBultosDet = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colReferenciaDet = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colTejedoraDet = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colXtra = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.panelTotales = New System.Windows.Forms.Panel()
        Me.panelOculto = New System.Windows.Forms.Panel()
        Me.dgOculto = New System.Windows.Forms.DataGridView()
        Me.colEmpBultos = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colCatBox = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colAnioBox = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colNumBox = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colLineaDetalle = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colLineaBox = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colReferenciaBox = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colTara = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colPaquetes = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colCantidadMedida = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colXtraBox = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.etiquetaComentarios = New System.Windows.Forms.Label()
        Me.celdaComentarios = New System.Windows.Forms.TextBox()
        Me.celdaTotal = New System.Windows.Forms.TextBox()
        Me.celdaTotalCantidad = New System.Windows.Forms.TextBox()
        Me.etiquetaTotales = New System.Windows.Forms.Label()
        Me.panelDgTotales = New System.Windows.Forms.Panel()
        Me.dgDocumentos = New System.Windows.Forms.DataGridView()
        Me.colClave = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colDocumento = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colDatos = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.panelDatos = New System.Windows.Forms.Panel()
        Me.celdaRSCliente = New System.Windows.Forms.TextBox()
        Me.etiquetaCustomer = New System.Windows.Forms.Label()
        Me.celdaIDAprobado = New System.Windows.Forms.TextBox()
        Me.celdaIDCCosto = New System.Windows.Forms.TextBox()
        Me.botonCCosto = New System.Windows.Forms.Button()
        Me.celdaCCosto = New System.Windows.Forms.TextBox()
        Me.etiquetaCCosto = New System.Windows.Forms.Label()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.rbCliente = New System.Windows.Forms.RadioButton()
        Me.rbHilos = New System.Windows.Forms.RadioButton()
        Me.botonAutorizado = New System.Windows.Forms.Button()
        Me.celdaAutorizado = New System.Windows.Forms.TextBox()
        Me.etiquetaAutorizado = New System.Windows.Forms.Label()
        Me.celdaSolicitante = New System.Windows.Forms.TextBox()
        Me.etiquetaSolicitante = New System.Windows.Forms.Label()
        Me.gbRelacion = New System.Windows.Forms.GroupBox()
        Me.panelBotones = New System.Windows.Forms.Panel()
        Me.botonMenos = New System.Windows.Forms.Button()
        Me.botonMas = New System.Windows.Forms.Button()
        Me.dgFactura = New System.Windows.Forms.DataGridView()
        Me.colNumeroF = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colFechaF = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colReferenciaF = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colAnioF = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colCatalogoF = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colAgregar = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.gbCliente = New System.Windows.Forms.GroupBox()
        Me.celdaDesactivar = New System.Windows.Forms.Label()
        Me.celdaEmpresa = New System.Windows.Forms.TextBox()
        Me.celdaUsuario = New System.Windows.Forms.TextBox()
        Me.botonMoneda = New System.Windows.Forms.Button()
        Me.dtpFecha = New System.Windows.Forms.DateTimePicker()
        Me.celdaNIT = New System.Windows.Forms.TextBox()
        Me.celdaIdMoneda = New System.Windows.Forms.TextBox()
        Me.celdaIdCliente = New System.Windows.Forms.TextBox()
        Me.celdaDate = New System.Windows.Forms.TextBox()
        Me.checkActivo = New System.Windows.Forms.CheckBox()
        Me.celdaTasa = New System.Windows.Forms.TextBox()
        Me.celdaMoneda = New System.Windows.Forms.TextBox()
        Me.celdaDireccion = New System.Windows.Forms.TextBox()
        Me.botonCliente = New System.Windows.Forms.Button()
        Me.celdaCliente = New System.Windows.Forms.TextBox()
        Me.celdaNumero = New System.Windows.Forms.TextBox()
        Me.celdaCatalogo = New System.Windows.Forms.TextBox()
        Me.celdaAnio = New System.Windows.Forms.TextBox()
        Me.etiquetaTasa = New System.Windows.Forms.Label()
        Me.etiquetaMoneda = New System.Windows.Forms.Label()
        Me.etiquetaDireccion = New System.Windows.Forms.Label()
        Me.etiquetaCliente = New System.Windows.Forms.Label()
        Me.etiquetaFecha = New System.Windows.Forms.Label()
        Me.etiquetaNumero = New System.Windows.Forms.Label()
        Me.etiquetaAnio = New System.Windows.Forms.Label()
        Me.botonImprimir = New System.Windows.Forms.Button()
        Me.botonImprimirPackingList = New System.Windows.Forms.Button()
        Me.BarraTitulo1 = New KARIMs_SGI.BarraTitulo()
        Me.Encabezado1 = New KARIMs_SGI.encabezado()
        Me.panelLista.SuspendLayout()
        CType(Me.dgLista, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.panelEncabezadoLista.SuspendLayout()
        Me.panelDetalle.SuspendLayout()
        Me.Panel1.SuspendLayout()
        CType(Me.DgDetalle, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.panelTotales.SuspendLayout()
        Me.panelOculto.SuspendLayout()
        CType(Me.dgOculto, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.panelDgTotales.SuspendLayout()
        CType(Me.dgDocumentos, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.panelDatos.SuspendLayout()
        Me.GroupBox1.SuspendLayout()
        Me.gbRelacion.SuspendLayout()
        Me.panelBotones.SuspendLayout()
        CType(Me.dgFactura, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.gbCliente.SuspendLayout()
        Me.SuspendLayout()
        '
        'panelLista
        '
        Me.panelLista.Controls.Add(Me.dgLista)
        Me.panelLista.Controls.Add(Me.panelEncabezadoLista)
        Me.panelLista.Dock = System.Windows.Forms.DockStyle.Top
        Me.panelLista.Location = New System.Drawing.Point(0, 102)
        Me.panelLista.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.panelLista.Name = "panelLista"
        Me.panelLista.Size = New System.Drawing.Size(1028, 115)
        Me.panelLista.TabIndex = 8
        '
        'dgLista
        '
        Me.dgLista.AllowUserToAddRows = False
        Me.dgLista.AllowUserToDeleteRows = False
        Me.dgLista.AllowUserToOrderColumns = True
        Me.dgLista.BackgroundColor = System.Drawing.SystemColors.Control
        Me.dgLista.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgLista.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.colNumero, Me.colFecha, Me.colCodEmpresa, Me.colCliente, Me.colReferencia, Me.colAnio, Me.colEstado, Me.colDireccion, Me.colMoneda, Me.colTasa, Me.colIDAprovado, Me.colAprovadoPor, Me.coLIDCCosto, Me.colCCosto, Me.colDevolucion, Me.colComentario, Me.colEmp})
        Me.dgLista.Dock = System.Windows.Forms.DockStyle.Fill
        Me.dgLista.Location = New System.Drawing.Point(0, 69)
        Me.dgLista.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.dgLista.MultiSelect = False
        Me.dgLista.Name = "dgLista"
        Me.dgLista.ReadOnly = True
        Me.dgLista.RowTemplate.Height = 24
        Me.dgLista.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.dgLista.Size = New System.Drawing.Size(1028, 46)
        Me.dgLista.TabIndex = 0
        '
        'colNumero
        '
        Me.colNumero.HeaderText = "Number"
        Me.colNumero.Name = "colNumero"
        Me.colNumero.ReadOnly = True
        '
        'colFecha
        '
        Me.colFecha.HeaderText = "Date"
        Me.colFecha.Name = "colFecha"
        Me.colFecha.ReadOnly = True
        '
        'colCodEmpresa
        '
        Me.colCodEmpresa.HeaderText = "CodCliente"
        Me.colCodEmpresa.Name = "colCodEmpresa"
        Me.colCodEmpresa.ReadOnly = True
        Me.colCodEmpresa.Visible = False
        '
        'colCliente
        '
        Me.colCliente.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.colCliente.HeaderText = "Client"
        Me.colCliente.Name = "colCliente"
        Me.colCliente.ReadOnly = True
        Me.colCliente.Width = 58
        '
        'colReferencia
        '
        Me.colReferencia.HeaderText = "Reference"
        Me.colReferencia.Name = "colReferencia"
        Me.colReferencia.ReadOnly = True
        '
        'colAnio
        '
        Me.colAnio.HeaderText = "Año"
        Me.colAnio.Name = "colAnio"
        Me.colAnio.ReadOnly = True
        '
        'colEstado
        '
        Me.colEstado.HeaderText = "Status"
        Me.colEstado.Name = "colEstado"
        Me.colEstado.ReadOnly = True
        Me.colEstado.Visible = False
        '
        'colDireccion
        '
        Me.colDireccion.HeaderText = "Direccion"
        Me.colDireccion.Name = "colDireccion"
        Me.colDireccion.ReadOnly = True
        Me.colDireccion.Visible = False
        '
        'colMoneda
        '
        Me.colMoneda.HeaderText = "Moneda"
        Me.colMoneda.Name = "colMoneda"
        Me.colMoneda.ReadOnly = True
        Me.colMoneda.Visible = False
        '
        'colTasa
        '
        Me.colTasa.HeaderText = "Tasa"
        Me.colTasa.Name = "colTasa"
        Me.colTasa.ReadOnly = True
        Me.colTasa.Visible = False
        '
        'colIDAprovado
        '
        Me.colIDAprovado.HeaderText = "IDAprovado"
        Me.colIDAprovado.Name = "colIDAprovado"
        Me.colIDAprovado.ReadOnly = True
        Me.colIDAprovado.Visible = False
        '
        'colAprovadoPor
        '
        Me.colAprovadoPor.HeaderText = "AprobadoPor"
        Me.colAprovadoPor.Name = "colAprovadoPor"
        Me.colAprovadoPor.ReadOnly = True
        Me.colAprovadoPor.Visible = False
        '
        'coLIDCCosto
        '
        Me.coLIDCCosto.HeaderText = "IDCCosto"
        Me.coLIDCCosto.Name = "coLIDCCosto"
        Me.coLIDCCosto.ReadOnly = True
        Me.coLIDCCosto.Visible = False
        '
        'colCCosto
        '
        Me.colCCosto.HeaderText = "CCosto"
        Me.colCCosto.Name = "colCCosto"
        Me.colCCosto.ReadOnly = True
        Me.colCCosto.Visible = False
        '
        'colDevolucion
        '
        Me.colDevolucion.HeaderText = "Devolucion"
        Me.colDevolucion.Name = "colDevolucion"
        Me.colDevolucion.ReadOnly = True
        Me.colDevolucion.Visible = False
        '
        'colComentario
        '
        Me.colComentario.HeaderText = "Comentario"
        Me.colComentario.Name = "colComentario"
        Me.colComentario.ReadOnly = True
        Me.colComentario.Visible = False
        '
        'colEmp
        '
        Me.colEmp.HeaderText = "Empresa"
        Me.colEmp.Name = "colEmp"
        Me.colEmp.ReadOnly = True
        Me.colEmp.Visible = False
        '
        'panelEncabezadoLista
        '
        Me.panelEncabezadoLista.Controls.Add(Me.botonClienteE)
        Me.panelEncabezadoLista.Controls.Add(Me.celdaClienteE)
        Me.panelEncabezadoLista.Controls.Add(Me.etiquetaClienteE)
        Me.panelEncabezadoLista.Controls.Add(Me.botonActualizar)
        Me.panelEncabezadoLista.Controls.Add(Me.etiquetaFechas)
        Me.panelEncabezadoLista.Controls.Add(Me.dtpFinal)
        Me.panelEncabezadoLista.Controls.Add(Me.dtpInicial)
        Me.panelEncabezadoLista.Controls.Add(Me.checkFechas)
        Me.panelEncabezadoLista.Dock = System.Windows.Forms.DockStyle.Top
        Me.panelEncabezadoLista.Location = New System.Drawing.Point(0, 0)
        Me.panelEncabezadoLista.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.panelEncabezadoLista.Name = "panelEncabezadoLista"
        Me.panelEncabezadoLista.Size = New System.Drawing.Size(1028, 69)
        Me.panelEncabezadoLista.TabIndex = 0
        '
        'botonClienteE
        '
        Me.botonClienteE.Location = New System.Drawing.Point(426, 44)
        Me.botonClienteE.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.botonClienteE.Name = "botonClienteE"
        Me.botonClienteE.Size = New System.Drawing.Size(32, 23)
        Me.botonClienteE.TabIndex = 7
        Me.botonClienteE.Text = "..."
        Me.botonClienteE.TextAlign = System.Drawing.ContentAlignment.TopCenter
        Me.botonClienteE.UseVisualStyleBackColor = True
        '
        'celdaClienteE
        '
        Me.celdaClienteE.Location = New System.Drawing.Point(98, 46)
        Me.celdaClienteE.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.celdaClienteE.Name = "celdaClienteE"
        Me.celdaClienteE.Size = New System.Drawing.Size(325, 20)
        Me.celdaClienteE.TabIndex = 6
        '
        'etiquetaClienteE
        '
        Me.etiquetaClienteE.AutoSize = True
        Me.etiquetaClienteE.Location = New System.Drawing.Point(34, 48)
        Me.etiquetaClienteE.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.etiquetaClienteE.Name = "etiquetaClienteE"
        Me.etiquetaClienteE.Size = New System.Drawing.Size(39, 13)
        Me.etiquetaClienteE.TabIndex = 5
        Me.etiquetaClienteE.Text = "Cliente"
        '
        'botonActualizar
        '
        Me.botonActualizar.Location = New System.Drawing.Point(556, 8)
        Me.botonActualizar.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.botonActualizar.Name = "botonActualizar"
        Me.botonActualizar.Size = New System.Drawing.Size(56, 21)
        Me.botonActualizar.TabIndex = 4
        Me.botonActualizar.Text = "Refresh"
        Me.botonActualizar.TextAlign = System.Drawing.ContentAlignment.TopCenter
        Me.botonActualizar.UseVisualStyleBackColor = True
        '
        'etiquetaFechas
        '
        Me.etiquetaFechas.AutoSize = True
        Me.etiquetaFechas.Location = New System.Drawing.Point(364, 11)
        Me.etiquetaFechas.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.etiquetaFechas.Name = "etiquetaFechas"
        Me.etiquetaFechas.Size = New System.Drawing.Size(52, 13)
        Me.etiquetaFechas.TabIndex = 3
        Me.etiquetaFechas.Text = "And Date"
        '
        'dtpFinal
        '
        Me.dtpFinal.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.dtpFinal.Location = New System.Drawing.Point(426, 9)
        Me.dtpFinal.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.dtpFinal.Name = "dtpFinal"
        Me.dtpFinal.Size = New System.Drawing.Size(92, 20)
        Me.dtpFinal.TabIndex = 2
        '
        'dtpInicial
        '
        Me.dtpInicial.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.dtpInicial.Location = New System.Drawing.Point(262, 9)
        Me.dtpInicial.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.dtpInicial.Name = "dtpInicial"
        Me.dtpInicial.Size = New System.Drawing.Size(92, 20)
        Me.dtpInicial.TabIndex = 1
        '
        'checkFechas
        '
        Me.checkFechas.AutoSize = True
        Me.checkFechas.Checked = True
        Me.checkFechas.CheckState = System.Windows.Forms.CheckState.Checked
        Me.checkFechas.Location = New System.Drawing.Point(37, 12)
        Me.checkFechas.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.checkFechas.Name = "checkFechas"
        Me.checkFechas.Size = New System.Drawing.Size(181, 17)
        Me.checkFechas.TabIndex = 0
        Me.checkFechas.Text = "Show Documents Between Date"
        Me.checkFechas.UseVisualStyleBackColor = True
        '
        'panelDetalle
        '
        Me.panelDetalle.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.panelDetalle.Controls.Add(Me.Panel1)
        Me.panelDetalle.Controls.Add(Me.DgDetalle)
        Me.panelDetalle.Controls.Add(Me.panelTotales)
        Me.panelDetalle.Controls.Add(Me.panelDatos)
        Me.panelDetalle.Location = New System.Drawing.Point(0, 223)
        Me.panelDetalle.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.panelDetalle.Name = "panelDetalle"
        Me.panelDetalle.Size = New System.Drawing.Size(1018, 476)
        Me.panelDetalle.TabIndex = 9
        '
        'Panel1
        '
        Me.Panel1.Controls.Add(Me.botonQuitar)
        Me.Panel1.Controls.Add(Me.botonAgregar)
        Me.Panel1.Dock = System.Windows.Forms.DockStyle.Right
        Me.Panel1.Location = New System.Drawing.Point(972, 258)
        Me.Panel1.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(46, 98)
        Me.Panel1.TabIndex = 5
        '
        'botonQuitar
        '
        Me.botonQuitar.Image = CType(resources.GetObject("botonQuitar.Image"), System.Drawing.Image)
        Me.botonQuitar.Location = New System.Drawing.Point(11, 46)
        Me.botonQuitar.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.botonQuitar.Name = "botonQuitar"
        Me.botonQuitar.Size = New System.Drawing.Size(26, 25)
        Me.botonQuitar.TabIndex = 45
        Me.botonQuitar.UseVisualStyleBackColor = True
        '
        'botonAgregar
        '
        Me.botonAgregar.Enabled = False
        Me.botonAgregar.Image = Global.KARIMs_SGI.My.Resources.Resources.plus
        Me.botonAgregar.Location = New System.Drawing.Point(11, 10)
        Me.botonAgregar.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.botonAgregar.Name = "botonAgregar"
        Me.botonAgregar.Size = New System.Drawing.Size(26, 25)
        Me.botonAgregar.TabIndex = 4
        Me.botonAgregar.UseVisualStyleBackColor = True
        '
        'DgDetalle
        '
        Me.DgDetalle.AllowUserToAddRows = False
        Me.DgDetalle.AllowUserToDeleteRows = False
        Me.DgDetalle.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.DgDetalle.BackgroundColor = System.Drawing.SystemColors.Control
        Me.DgDetalle.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DgDetalle.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.colEmpresa, Me.colCatalogo, Me.colAnioFactura, Me.colCodigoDet, Me.colProductoDet, Me.colFacturaDet, Me.colLinea, Me.colLineaDevolucion, Me.colIDMedida, Me.colUMedida, Me.colLoteDet, Me.colLoteDetDev, Me.colCantidadDet, Me.colPrecioDet, Me.colPrecioKg, Me.colCantidadKG, Me.colBultosDet, Me.colReferenciaDet, Me.colTejedoraDet, Me.colXtra})
        Me.DgDetalle.Location = New System.Drawing.Point(0, 258)
        Me.DgDetalle.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.DgDetalle.Name = "DgDetalle"
        Me.DgDetalle.RowTemplate.Height = 24
        Me.DgDetalle.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.DgDetalle.Size = New System.Drawing.Size(972, 98)
        Me.DgDetalle.TabIndex = 4
        '
        'colEmpresa
        '
        Me.colEmpresa.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.colEmpresa.HeaderText = "Empresa"
        Me.colEmpresa.Name = "colEmpresa"
        Me.colEmpresa.Visible = False
        '
        'colCatalogo
        '
        Me.colCatalogo.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.colCatalogo.HeaderText = "Catalogo"
        Me.colCatalogo.Name = "colCatalogo"
        Me.colCatalogo.Visible = False
        '
        'colAnioFactura
        '
        Me.colAnioFactura.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.colAnioFactura.HeaderText = "AnioFactura"
        Me.colAnioFactura.Name = "colAnioFactura"
        Me.colAnioFactura.Visible = False
        '
        'colCodigoDet
        '
        Me.colCodigoDet.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.colCodigoDet.HeaderText = "Code"
        Me.colCodigoDet.Name = "colCodigoDet"
        Me.colCodigoDet.ReadOnly = True
        Me.colCodigoDet.Width = 57
        '
        'colProductoDet
        '
        Me.colProductoDet.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.DisplayedCells
        Me.colProductoDet.HeaderText = "Product"
        Me.colProductoDet.Name = "colProductoDet"
        Me.colProductoDet.ReadOnly = True
        Me.colProductoDet.Width = 69
        '
        'colFacturaDet
        '
        Me.colFacturaDet.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.colFacturaDet.HeaderText = "Bill No."
        Me.colFacturaDet.Name = "colFacturaDet"
        Me.colFacturaDet.ReadOnly = True
        Me.colFacturaDet.Width = 65
        '
        'colLinea
        '
        Me.colLinea.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill
        Me.colLinea.HeaderText = "LineaFactura"
        Me.colLinea.Name = "colLinea"
        Me.colLinea.Visible = False
        '
        'colLineaDevolucion
        '
        Me.colLineaDevolucion.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill
        Me.colLineaDevolucion.HeaderText = "LineaDevolucion"
        Me.colLineaDevolucion.Name = "colLineaDevolucion"
        Me.colLineaDevolucion.Visible = False
        '
        'colIDMedida
        '
        Me.colIDMedida.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill
        Me.colIDMedida.HeaderText = "IDMedida"
        Me.colIDMedida.Name = "colIDMedida"
        Me.colIDMedida.Visible = False
        '
        'colUMedida
        '
        Me.colUMedida.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill
        Me.colUMedida.HeaderText = "Measure"
        Me.colUMedida.Name = "colUMedida"
        Me.colUMedida.ReadOnly = True
        '
        'colLoteDet
        '
        Me.colLoteDet.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill
        Me.colLoteDet.HeaderText = "Invoice lot"
        Me.colLoteDet.Name = "colLoteDet"
        Me.colLoteDet.ReadOnly = True
        '
        'colLoteDetDev
        '
        Me.colLoteDetDev.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill
        Me.colLoteDetDev.HeaderText = "Return Lot "
        Me.colLoteDetDev.Name = "colLoteDetDev"
        '
        'colCantidadDet
        '
        Me.colCantidadDet.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill
        Me.colCantidadDet.HeaderText = "Quantity Pound"
        Me.colCantidadDet.Name = "colCantidadDet"
        Me.colCantidadDet.ReadOnly = True
        '
        'colPrecioDet
        '
        Me.colPrecioDet.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill
        Me.colPrecioDet.HeaderText = "Price Pounds"
        Me.colPrecioDet.Name = "colPrecioDet"
        Me.colPrecioDet.ReadOnly = True
        '
        'colPrecioKg
        '
        Me.colPrecioKg.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill
        Me.colPrecioKg.HeaderText = "Price Kg"
        Me.colPrecioKg.Name = "colPrecioKg"
        Me.colPrecioKg.ReadOnly = True
        '
        'colCantidadKG
        '
        Me.colCantidadKG.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill
        Me.colCantidadKG.HeaderText = "Quantity Kg"
        Me.colCantidadKG.Name = "colCantidadKG"
        Me.colCantidadKG.ReadOnly = True
        '
        'colBultosDet
        '
        Me.colBultosDet.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill
        Me.colBultosDet.HeaderText = "Packages"
        Me.colBultosDet.Name = "colBultosDet"
        Me.colBultosDet.ReadOnly = True
        '
        'colReferenciaDet
        '
        Me.colReferenciaDet.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.colReferenciaDet.HeaderText = "Reference"
        Me.colReferenciaDet.Name = "colReferenciaDet"
        Me.colReferenciaDet.ReadOnly = True
        Me.colReferenciaDet.Width = 82
        '
        'colTejedoraDet
        '
        Me.colTejedoraDet.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill
        Me.colTejedoraDet.HeaderText = "Weaver"
        Me.colTejedoraDet.Name = "colTejedoraDet"
        '
        'colXtra
        '
        Me.colXtra.HeaderText = "Xtra"
        Me.colXtra.Name = "colXtra"
        Me.colXtra.Visible = False
        '
        'panelTotales
        '
        Me.panelTotales.Controls.Add(Me.panelOculto)
        Me.panelTotales.Controls.Add(Me.etiquetaComentarios)
        Me.panelTotales.Controls.Add(Me.celdaComentarios)
        Me.panelTotales.Controls.Add(Me.celdaTotal)
        Me.panelTotales.Controls.Add(Me.celdaTotalCantidad)
        Me.panelTotales.Controls.Add(Me.etiquetaTotales)
        Me.panelTotales.Controls.Add(Me.panelDgTotales)
        Me.panelTotales.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.panelTotales.Location = New System.Drawing.Point(0, 356)
        Me.panelTotales.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.panelTotales.Name = "panelTotales"
        Me.panelTotales.Size = New System.Drawing.Size(1018, 120)
        Me.panelTotales.TabIndex = 3
        '
        'panelOculto
        '
        Me.panelOculto.Controls.Add(Me.dgOculto)
        Me.panelOculto.Location = New System.Drawing.Point(511, 11)
        Me.panelOculto.Name = "panelOculto"
        Me.panelOculto.Size = New System.Drawing.Size(438, 100)
        Me.panelOculto.TabIndex = 23
        Me.panelOculto.Visible = False
        '
        'dgOculto
        '
        Me.dgOculto.AllowUserToAddRows = False
        Me.dgOculto.AllowUserToDeleteRows = False
        Me.dgOculto.BackgroundColor = System.Drawing.SystemColors.Control
        Me.dgOculto.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgOculto.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.colEmpBultos, Me.colCatBox, Me.colAnioBox, Me.colNumBox, Me.colLineaDetalle, Me.colLineaBox, Me.colReferenciaBox, Me.colTara, Me.colPaquetes, Me.colCantidadMedida, Me.colXtraBox})
        Me.dgOculto.Dock = System.Windows.Forms.DockStyle.Fill
        Me.dgOculto.Location = New System.Drawing.Point(0, 0)
        Me.dgOculto.Name = "dgOculto"
        Me.dgOculto.Size = New System.Drawing.Size(438, 100)
        Me.dgOculto.TabIndex = 0
        '
        'colEmpBultos
        '
        Me.colEmpBultos.HeaderText = "Empresa"
        Me.colEmpBultos.Name = "colEmpBultos"
        '
        'colCatBox
        '
        Me.colCatBox.HeaderText = "Catalogo"
        Me.colCatBox.Name = "colCatBox"
        '
        'colAnioBox
        '
        Me.colAnioBox.HeaderText = "Anio"
        Me.colAnioBox.Name = "colAnioBox"
        '
        'colNumBox
        '
        Me.colNumBox.HeaderText = "Numero"
        Me.colNumBox.Name = "colNumBox"
        '
        'colLineaDetalle
        '
        Me.colLineaDetalle.HeaderText = "Linea"
        Me.colLineaDetalle.Name = "colLineaDetalle"
        '
        'colLineaBox
        '
        Me.colLineaBox.HeaderText = "LineaDetalle"
        Me.colLineaBox.Name = "colLineaBox"
        '
        'colReferenciaBox
        '
        Me.colReferenciaBox.HeaderText = "Referencia"
        Me.colReferenciaBox.Name = "colReferenciaBox"
        '
        'colTara
        '
        Me.colTara.HeaderText = "Tara"
        Me.colTara.Name = "colTara"
        '
        'colPaquetes
        '
        Me.colPaquetes.HeaderText = "Paquetes"
        Me.colPaquetes.Name = "colPaquetes"
        '
        'colCantidadMedida
        '
        Me.colCantidadMedida.HeaderText = "CantidadMedida"
        Me.colCantidadMedida.Name = "colCantidadMedida"
        '
        'colXtraBox
        '
        Me.colXtraBox.HeaderText = "XtraBox"
        Me.colXtraBox.Name = "colXtraBox"
        '
        'etiquetaComentarios
        '
        Me.etiquetaComentarios.AutoSize = True
        Me.etiquetaComentarios.Location = New System.Drawing.Point(358, 11)
        Me.etiquetaComentarios.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.etiquetaComentarios.Name = "etiquetaComentarios"
        Me.etiquetaComentarios.Size = New System.Drawing.Size(56, 13)
        Me.etiquetaComentarios.TabIndex = 22
        Me.etiquetaComentarios.Text = "Comments"
        '
        'celdaComentarios
        '
        Me.celdaComentarios.Location = New System.Drawing.Point(361, 31)
        Me.celdaComentarios.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.celdaComentarios.Multiline = True
        Me.celdaComentarios.Name = "celdaComentarios"
        Me.celdaComentarios.Size = New System.Drawing.Size(208, 88)
        Me.celdaComentarios.TabIndex = 21
        '
        'celdaTotal
        '
        Me.celdaTotal.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.celdaTotal.Location = New System.Drawing.Point(898, 40)
        Me.celdaTotal.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.celdaTotal.Name = "celdaTotal"
        Me.celdaTotal.ReadOnly = True
        Me.celdaTotal.Size = New System.Drawing.Size(86, 20)
        Me.celdaTotal.TabIndex = 20
        '
        'celdaTotalCantidad
        '
        Me.celdaTotalCantidad.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.celdaTotalCantidad.Location = New System.Drawing.Point(789, 40)
        Me.celdaTotalCantidad.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.celdaTotalCantidad.Name = "celdaTotalCantidad"
        Me.celdaTotalCantidad.ReadOnly = True
        Me.celdaTotalCantidad.Size = New System.Drawing.Size(86, 20)
        Me.celdaTotalCantidad.TabIndex = 19
        '
        'etiquetaTotales
        '
        Me.etiquetaTotales.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.etiquetaTotales.AutoSize = True
        Me.etiquetaTotales.Location = New System.Drawing.Point(786, 17)
        Me.etiquetaTotales.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.etiquetaTotales.Name = "etiquetaTotales"
        Me.etiquetaTotales.Size = New System.Drawing.Size(42, 13)
        Me.etiquetaTotales.TabIndex = 1
        Me.etiquetaTotales.Text = "Totales"
        '
        'panelDgTotales
        '
        Me.panelDgTotales.Controls.Add(Me.dgDocumentos)
        Me.panelDgTotales.Dock = System.Windows.Forms.DockStyle.Left
        Me.panelDgTotales.Location = New System.Drawing.Point(0, 0)
        Me.panelDgTotales.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.panelDgTotales.Name = "panelDgTotales"
        Me.panelDgTotales.Size = New System.Drawing.Size(328, 120)
        Me.panelDgTotales.TabIndex = 0
        '
        'dgDocumentos
        '
        Me.dgDocumentos.AllowUserToAddRows = False
        Me.dgDocumentos.AllowUserToDeleteRows = False
        Me.dgDocumentos.AllowUserToOrderColumns = True
        Me.dgDocumentos.BackgroundColor = System.Drawing.SystemColors.Control
        Me.dgDocumentos.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgDocumentos.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.colClave, Me.colDocumento, Me.colDatos})
        Me.dgDocumentos.Dock = System.Windows.Forms.DockStyle.Fill
        Me.dgDocumentos.Location = New System.Drawing.Point(0, 0)
        Me.dgDocumentos.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.dgDocumentos.MultiSelect = False
        Me.dgDocumentos.Name = "dgDocumentos"
        Me.dgDocumentos.ReadOnly = True
        Me.dgDocumentos.RowTemplate.Height = 24
        Me.dgDocumentos.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.dgDocumentos.Size = New System.Drawing.Size(328, 120)
        Me.dgDocumentos.TabIndex = 1
        '
        'colClave
        '
        Me.colClave.HeaderText = "Clave"
        Me.colClave.Name = "colClave"
        Me.colClave.ReadOnly = True
        Me.colClave.Visible = False
        '
        'colDocumento
        '
        Me.colDocumento.HeaderText = "Document"
        Me.colDocumento.Name = "colDocumento"
        Me.colDocumento.ReadOnly = True
        '
        'colDatos
        '
        Me.colDatos.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill
        Me.colDatos.HeaderText = "Data"
        Me.colDatos.Name = "colDatos"
        Me.colDatos.ReadOnly = True
        '
        'panelDatos
        '
        Me.panelDatos.Controls.Add(Me.celdaRSCliente)
        Me.panelDatos.Controls.Add(Me.etiquetaCustomer)
        Me.panelDatos.Controls.Add(Me.celdaIDAprobado)
        Me.panelDatos.Controls.Add(Me.celdaIDCCosto)
        Me.panelDatos.Controls.Add(Me.botonCCosto)
        Me.panelDatos.Controls.Add(Me.celdaCCosto)
        Me.panelDatos.Controls.Add(Me.etiquetaCCosto)
        Me.panelDatos.Controls.Add(Me.GroupBox1)
        Me.panelDatos.Controls.Add(Me.botonAutorizado)
        Me.panelDatos.Controls.Add(Me.celdaAutorizado)
        Me.panelDatos.Controls.Add(Me.etiquetaAutorizado)
        Me.panelDatos.Controls.Add(Me.celdaSolicitante)
        Me.panelDatos.Controls.Add(Me.etiquetaSolicitante)
        Me.panelDatos.Controls.Add(Me.gbRelacion)
        Me.panelDatos.Controls.Add(Me.gbCliente)
        Me.panelDatos.Dock = System.Windows.Forms.DockStyle.Top
        Me.panelDatos.Location = New System.Drawing.Point(0, 0)
        Me.panelDatos.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.panelDatos.Name = "panelDatos"
        Me.panelDatos.Size = New System.Drawing.Size(1018, 258)
        Me.panelDatos.TabIndex = 0
        '
        'celdaRSCliente
        '
        Me.celdaRSCliente.Location = New System.Drawing.Point(608, 226)
        Me.celdaRSCliente.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.celdaRSCliente.Name = "celdaRSCliente"
        Me.celdaRSCliente.Size = New System.Drawing.Size(296, 20)
        Me.celdaRSCliente.TabIndex = 35
        '
        'etiquetaCustomer
        '
        Me.etiquetaCustomer.AutoSize = True
        Me.etiquetaCustomer.Location = New System.Drawing.Point(439, 229)
        Me.etiquetaCustomer.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.etiquetaCustomer.Name = "etiquetaCustomer"
        Me.etiquetaCustomer.Size = New System.Drawing.Size(165, 13)
        Me.etiquetaCustomer.TabIndex = 34
        Me.etiquetaCustomer.Text = "Customer Service Representative"
        '
        'celdaIDAprobado
        '
        Me.celdaIDAprobado.Location = New System.Drawing.Point(744, 193)
        Me.celdaIDAprobado.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.celdaIDAprobado.Name = "celdaIDAprobado"
        Me.celdaIDAprobado.Size = New System.Drawing.Size(28, 20)
        Me.celdaIDAprobado.TabIndex = 33
        Me.celdaIDAprobado.Visible = False
        '
        'celdaIDCCosto
        '
        Me.celdaIDCCosto.Location = New System.Drawing.Point(744, 163)
        Me.celdaIDCCosto.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.celdaIDCCosto.Name = "celdaIDCCosto"
        Me.celdaIDCCosto.Size = New System.Drawing.Size(28, 20)
        Me.celdaIDCCosto.TabIndex = 32
        Me.celdaIDCCosto.Visible = False
        '
        'botonCCosto
        '
        Me.botonCCosto.Location = New System.Drawing.Point(712, 162)
        Me.botonCCosto.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.botonCCosto.Name = "botonCCosto"
        Me.botonCCosto.Size = New System.Drawing.Size(28, 20)
        Me.botonCCosto.TabIndex = 29
        Me.botonCCosto.Text = "..."
        Me.botonCCosto.TextAlign = System.Drawing.ContentAlignment.TopCenter
        Me.botonCCosto.UseVisualStyleBackColor = True
        '
        'celdaCCosto
        '
        Me.celdaCCosto.Location = New System.Drawing.Point(526, 162)
        Me.celdaCCosto.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.celdaCCosto.Name = "celdaCCosto"
        Me.celdaCCosto.Size = New System.Drawing.Size(182, 20)
        Me.celdaCCosto.TabIndex = 31
        '
        'etiquetaCCosto
        '
        Me.etiquetaCCosto.AutoSize = True
        Me.etiquetaCCosto.Location = New System.Drawing.Point(440, 166)
        Me.etiquetaCCosto.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.etiquetaCCosto.Name = "etiquetaCCosto"
        Me.etiquetaCCosto.Size = New System.Drawing.Size(65, 13)
        Me.etiquetaCCosto.TabIndex = 30
        Me.etiquetaCCosto.Text = "Cost Center "
        '
        'GroupBox1
        '
        Me.GroupBox1.AutoSize = True
        Me.GroupBox1.Controls.Add(Me.rbCliente)
        Me.GroupBox1.Controls.Add(Me.rbHilos)
        Me.GroupBox1.Location = New System.Drawing.Point(789, 134)
        Me.GroupBox1.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Padding = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.GroupBox1.Size = New System.Drawing.Size(206, 85)
        Me.GroupBox1.TabIndex = 28
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Devolution costs"
        '
        'rbCliente
        '
        Me.rbCliente.AutoSize = True
        Me.rbCliente.Location = New System.Drawing.Point(4, 45)
        Me.rbCliente.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.rbCliente.Name = "rbCliente"
        Me.rbCliente.Size = New System.Drawing.Size(57, 17)
        Me.rbCliente.TabIndex = 24
        Me.rbCliente.TabStop = True
        Me.rbCliente.Text = "Cliente"
        Me.rbCliente.UseVisualStyleBackColor = True
        '
        'rbHilos
        '
        Me.rbHilos.AutoSize = True
        Me.rbHilos.Location = New System.Drawing.Point(4, 19)
        Me.rbHilos.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.rbHilos.Name = "rbHilos"
        Me.rbHilos.Size = New System.Drawing.Size(123, 17)
        Me.rbHilos.TabIndex = 23
        Me.rbHilos.TabStop = True
        Me.rbHilos.Text = "HILOS Y ALGODON"
        Me.rbHilos.UseVisualStyleBackColor = True
        '
        'botonAutorizado
        '
        Me.botonAutorizado.Location = New System.Drawing.Point(712, 189)
        Me.botonAutorizado.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.botonAutorizado.Name = "botonAutorizado"
        Me.botonAutorizado.Size = New System.Drawing.Size(28, 20)
        Me.botonAutorizado.TabIndex = 23
        Me.botonAutorizado.Text = "..."
        Me.botonAutorizado.TextAlign = System.Drawing.ContentAlignment.TopCenter
        Me.botonAutorizado.UseVisualStyleBackColor = True
        '
        'celdaAutorizado
        '
        Me.celdaAutorizado.Location = New System.Drawing.Point(526, 189)
        Me.celdaAutorizado.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.celdaAutorizado.Name = "celdaAutorizado"
        Me.celdaAutorizado.Size = New System.Drawing.Size(182, 20)
        Me.celdaAutorizado.TabIndex = 27
        '
        'etiquetaAutorizado
        '
        Me.etiquetaAutorizado.AutoSize = True
        Me.etiquetaAutorizado.Location = New System.Drawing.Point(440, 193)
        Me.etiquetaAutorizado.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.etiquetaAutorizado.Name = "etiquetaAutorizado"
        Me.etiquetaAutorizado.Size = New System.Drawing.Size(67, 13)
        Me.etiquetaAutorizado.TabIndex = 26
        Me.etiquetaAutorizado.Text = "Approved by"
        '
        'celdaSolicitante
        '
        Me.celdaSolicitante.Location = New System.Drawing.Point(525, 125)
        Me.celdaSolicitante.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.celdaSolicitante.Name = "celdaSolicitante"
        Me.celdaSolicitante.Size = New System.Drawing.Size(182, 20)
        Me.celdaSolicitante.TabIndex = 25
        '
        'etiquetaSolicitante
        '
        Me.etiquetaSolicitante.AutoSize = True
        Me.etiquetaSolicitante.Location = New System.Drawing.Point(439, 129)
        Me.etiquetaSolicitante.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.etiquetaSolicitante.Name = "etiquetaSolicitante"
        Me.etiquetaSolicitante.Size = New System.Drawing.Size(73, 13)
        Me.etiquetaSolicitante.TabIndex = 24
        Me.etiquetaSolicitante.Text = "Requested by"
        '
        'gbRelacion
        '
        Me.gbRelacion.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.gbRelacion.Controls.Add(Me.panelBotones)
        Me.gbRelacion.Controls.Add(Me.dgFactura)
        Me.gbRelacion.Location = New System.Drawing.Point(440, 2)
        Me.gbRelacion.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.gbRelacion.Name = "gbRelacion"
        Me.gbRelacion.Padding = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.gbRelacion.Size = New System.Drawing.Size(535, 115)
        Me.gbRelacion.TabIndex = 10
        Me.gbRelacion.TabStop = False
        Me.gbRelacion.Text = "Return Information"
        '
        'panelBotones
        '
        Me.panelBotones.Controls.Add(Me.botonMenos)
        Me.panelBotones.Controls.Add(Me.botonMas)
        Me.panelBotones.Dock = System.Windows.Forms.DockStyle.Right
        Me.panelBotones.Location = New System.Drawing.Point(487, 15)
        Me.panelBotones.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.panelBotones.Name = "panelBotones"
        Me.panelBotones.Size = New System.Drawing.Size(46, 98)
        Me.panelBotones.TabIndex = 1
        '
        'botonMenos
        '
        Me.botonMenos.Image = CType(resources.GetObject("botonMenos.Image"), System.Drawing.Image)
        Me.botonMenos.Location = New System.Drawing.Point(11, 46)
        Me.botonMenos.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.botonMenos.Name = "botonMenos"
        Me.botonMenos.Size = New System.Drawing.Size(26, 25)
        Me.botonMenos.TabIndex = 45
        Me.botonMenos.UseVisualStyleBackColor = True
        '
        'botonMas
        '
        Me.botonMas.Image = Global.KARIMs_SGI.My.Resources.Resources.plus
        Me.botonMas.Location = New System.Drawing.Point(11, 10)
        Me.botonMas.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.botonMas.Name = "botonMas"
        Me.botonMas.Size = New System.Drawing.Size(26, 25)
        Me.botonMas.TabIndex = 4
        Me.botonMas.UseVisualStyleBackColor = True
        '
        'dgFactura
        '
        Me.dgFactura.AllowUserToAddRows = False
        Me.dgFactura.AllowUserToDeleteRows = False
        Me.dgFactura.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.dgFactura.BackgroundColor = System.Drawing.SystemColors.Control
        Me.dgFactura.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgFactura.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.colNumeroF, Me.colFechaF, Me.colReferenciaF, Me.colAnioF, Me.colCatalogoF, Me.colAgregar})
        Me.dgFactura.Location = New System.Drawing.Point(2, 15)
        Me.dgFactura.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.dgFactura.Name = "dgFactura"
        Me.dgFactura.RowTemplate.Height = 24
        Me.dgFactura.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.dgFactura.Size = New System.Drawing.Size(480, 98)
        Me.dgFactura.TabIndex = 0
        '
        'colNumeroF
        '
        Me.colNumeroF.HeaderText = "Number"
        Me.colNumeroF.Name = "colNumeroF"
        Me.colNumeroF.ReadOnly = True
        '
        'colFechaF
        '
        Me.colFechaF.HeaderText = "Date"
        Me.colFechaF.Name = "colFechaF"
        Me.colFechaF.ReadOnly = True
        '
        'colReferenciaF
        '
        Me.colReferenciaF.HeaderText = "Reference"
        Me.colReferenciaF.Name = "colReferenciaF"
        Me.colReferenciaF.ReadOnly = True
        '
        'colAnioF
        '
        Me.colAnioF.HeaderText = "Anio"
        Me.colAnioF.Name = "colAnioF"
        Me.colAnioF.ReadOnly = True
        '
        'colCatalogoF
        '
        Me.colCatalogoF.HeaderText = "Catalogo"
        Me.colCatalogoF.Name = "colCatalogoF"
        Me.colCatalogoF.ReadOnly = True
        Me.colCatalogoF.Visible = False
        '
        'colAgregar
        '
        Me.colAgregar.HeaderText = "Agregar"
        Me.colAgregar.Name = "colAgregar"
        Me.colAgregar.Visible = False
        '
        'gbCliente
        '
        Me.gbCliente.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.gbCliente.Controls.Add(Me.celdaDesactivar)
        Me.gbCliente.Controls.Add(Me.celdaEmpresa)
        Me.gbCliente.Controls.Add(Me.celdaUsuario)
        Me.gbCliente.Controls.Add(Me.botonMoneda)
        Me.gbCliente.Controls.Add(Me.dtpFecha)
        Me.gbCliente.Controls.Add(Me.celdaNIT)
        Me.gbCliente.Controls.Add(Me.celdaIdMoneda)
        Me.gbCliente.Controls.Add(Me.celdaIdCliente)
        Me.gbCliente.Controls.Add(Me.celdaDate)
        Me.gbCliente.Controls.Add(Me.checkActivo)
        Me.gbCliente.Controls.Add(Me.celdaTasa)
        Me.gbCliente.Controls.Add(Me.celdaMoneda)
        Me.gbCliente.Controls.Add(Me.celdaDireccion)
        Me.gbCliente.Controls.Add(Me.botonCliente)
        Me.gbCliente.Controls.Add(Me.celdaCliente)
        Me.gbCliente.Controls.Add(Me.celdaNumero)
        Me.gbCliente.Controls.Add(Me.celdaCatalogo)
        Me.gbCliente.Controls.Add(Me.celdaAnio)
        Me.gbCliente.Controls.Add(Me.etiquetaTasa)
        Me.gbCliente.Controls.Add(Me.etiquetaMoneda)
        Me.gbCliente.Controls.Add(Me.etiquetaDireccion)
        Me.gbCliente.Controls.Add(Me.etiquetaCliente)
        Me.gbCliente.Controls.Add(Me.etiquetaFecha)
        Me.gbCliente.Controls.Add(Me.etiquetaNumero)
        Me.gbCliente.Controls.Add(Me.etiquetaAnio)
        Me.gbCliente.Location = New System.Drawing.Point(2, 2)
        Me.gbCliente.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.gbCliente.Name = "gbCliente"
        Me.gbCliente.Padding = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.gbCliente.Size = New System.Drawing.Size(420, 253)
        Me.gbCliente.TabIndex = 1
        Me.gbCliente.TabStop = False
        Me.gbCliente.Text = "Return"
        '
        'celdaDesactivar
        '
        Me.celdaDesactivar.AutoSize = True
        Me.celdaDesactivar.BackColor = System.Drawing.Color.Red
        Me.celdaDesactivar.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.celdaDesactivar.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.celdaDesactivar.Location = New System.Drawing.Point(296, 52)
        Me.celdaDesactivar.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.celdaDesactivar.Name = "celdaDesactivar"
        Me.celdaDesactivar.Size = New System.Drawing.Size(116, 17)
        Me.celdaDesactivar.TabIndex = 48
        Me.celdaDesactivar.Text = "DESACTIVADO"
        Me.celdaDesactivar.Visible = False
        '
        'celdaEmpresa
        '
        Me.celdaEmpresa.Location = New System.Drawing.Point(179, 37)
        Me.celdaEmpresa.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.celdaEmpresa.Name = "celdaEmpresa"
        Me.celdaEmpresa.Size = New System.Drawing.Size(62, 20)
        Me.celdaEmpresa.TabIndex = 23
        Me.celdaEmpresa.Visible = False
        '
        'celdaUsuario
        '
        Me.celdaUsuario.Location = New System.Drawing.Point(311, 230)
        Me.celdaUsuario.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.celdaUsuario.Name = "celdaUsuario"
        Me.celdaUsuario.Size = New System.Drawing.Size(76, 20)
        Me.celdaUsuario.TabIndex = 21
        Me.celdaUsuario.Visible = False
        '
        'botonMoneda
        '
        Me.botonMoneda.Location = New System.Drawing.Point(170, 191)
        Me.botonMoneda.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.botonMoneda.Name = "botonMoneda"
        Me.botonMoneda.Size = New System.Drawing.Size(28, 20)
        Me.botonMoneda.TabIndex = 22
        Me.botonMoneda.Text = "..."
        Me.botonMoneda.TextAlign = System.Drawing.ContentAlignment.TopCenter
        Me.botonMoneda.UseVisualStyleBackColor = True
        '
        'dtpFecha
        '
        Me.dtpFecha.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.dtpFecha.Location = New System.Drawing.Point(80, 88)
        Me.dtpFecha.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.dtpFecha.Name = "dtpFecha"
        Me.dtpFecha.Size = New System.Drawing.Size(86, 20)
        Me.dtpFecha.TabIndex = 20
        '
        'celdaNIT
        '
        Me.celdaNIT.Location = New System.Drawing.Point(326, 95)
        Me.celdaNIT.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.celdaNIT.Name = "celdaNIT"
        Me.celdaNIT.Size = New System.Drawing.Size(76, 20)
        Me.celdaNIT.TabIndex = 19
        Me.celdaNIT.Visible = False
        '
        'celdaIdMoneda
        '
        Me.celdaIdMoneda.Location = New System.Drawing.Point(202, 192)
        Me.celdaIdMoneda.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.celdaIdMoneda.Name = "celdaIdMoneda"
        Me.celdaIdMoneda.Size = New System.Drawing.Size(28, 20)
        Me.celdaIdMoneda.TabIndex = 18
        Me.celdaIdMoneda.Visible = False
        '
        'celdaIdCliente
        '
        Me.celdaIdCliente.Location = New System.Drawing.Point(325, 119)
        Me.celdaIdCliente.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.celdaIdCliente.Name = "celdaIdCliente"
        Me.celdaIdCliente.Size = New System.Drawing.Size(62, 20)
        Me.celdaIdCliente.TabIndex = 18
        Me.celdaIdCliente.Visible = False
        '
        'celdaDate
        '
        Me.celdaDate.Location = New System.Drawing.Point(168, 89)
        Me.celdaDate.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.celdaDate.Name = "celdaDate"
        Me.celdaDate.Size = New System.Drawing.Size(62, 20)
        Me.celdaDate.TabIndex = 17
        Me.celdaDate.Visible = False
        '
        'checkActivo
        '
        Me.checkActivo.AutoSize = True
        Me.checkActivo.Checked = True
        Me.checkActivo.CheckState = System.Windows.Forms.CheckState.Checked
        Me.checkActivo.Location = New System.Drawing.Point(298, 33)
        Me.checkActivo.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.checkActivo.Name = "checkActivo"
        Me.checkActivo.Size = New System.Drawing.Size(56, 17)
        Me.checkActivo.TabIndex = 16
        Me.checkActivo.Text = "Active"
        Me.checkActivo.UseVisualStyleBackColor = True
        '
        'celdaTasa
        '
        Me.celdaTasa.Location = New System.Drawing.Point(80, 224)
        Me.celdaTasa.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.celdaTasa.Name = "celdaTasa"
        Me.celdaTasa.ReadOnly = True
        Me.celdaTasa.Size = New System.Drawing.Size(86, 20)
        Me.celdaTasa.TabIndex = 15
        '
        'celdaMoneda
        '
        Me.celdaMoneda.Location = New System.Drawing.Point(80, 193)
        Me.celdaMoneda.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.celdaMoneda.Name = "celdaMoneda"
        Me.celdaMoneda.Size = New System.Drawing.Size(86, 20)
        Me.celdaMoneda.TabIndex = 14
        '
        'celdaDireccion
        '
        Me.celdaDireccion.Location = New System.Drawing.Point(80, 145)
        Me.celdaDireccion.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.celdaDireccion.Multiline = True
        Me.celdaDireccion.Name = "celdaDireccion"
        Me.celdaDireccion.ReadOnly = True
        Me.celdaDireccion.Size = New System.Drawing.Size(271, 40)
        Me.celdaDireccion.TabIndex = 13
        '
        'botonCliente
        '
        Me.botonCliente.Location = New System.Drawing.Point(297, 116)
        Me.botonCliente.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.botonCliente.Name = "botonCliente"
        Me.botonCliente.Size = New System.Drawing.Size(28, 24)
        Me.botonCliente.TabIndex = 8
        Me.botonCliente.Text = "..."
        Me.botonCliente.TextAlign = System.Drawing.ContentAlignment.TopCenter
        Me.botonCliente.UseVisualStyleBackColor = True
        '
        'celdaCliente
        '
        Me.celdaCliente.Location = New System.Drawing.Point(80, 119)
        Me.celdaCliente.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.celdaCliente.Name = "celdaCliente"
        Me.celdaCliente.ReadOnly = True
        Me.celdaCliente.Size = New System.Drawing.Size(214, 20)
        Me.celdaCliente.TabIndex = 12
        '
        'celdaNumero
        '
        Me.celdaNumero.Location = New System.Drawing.Point(80, 60)
        Me.celdaNumero.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.celdaNumero.Name = "celdaNumero"
        Me.celdaNumero.Size = New System.Drawing.Size(86, 20)
        Me.celdaNumero.TabIndex = 10
        '
        'celdaCatalogo
        '
        Me.celdaCatalogo.Location = New System.Drawing.Point(145, 13)
        Me.celdaCatalogo.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.celdaCatalogo.Name = "celdaCatalogo"
        Me.celdaCatalogo.Size = New System.Drawing.Size(62, 20)
        Me.celdaCatalogo.TabIndex = 8
        Me.celdaCatalogo.Visible = False
        '
        'celdaAnio
        '
        Me.celdaAnio.Location = New System.Drawing.Point(80, 32)
        Me.celdaAnio.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.celdaAnio.Name = "celdaAnio"
        Me.celdaAnio.ReadOnly = True
        Me.celdaAnio.Size = New System.Drawing.Size(86, 20)
        Me.celdaAnio.TabIndex = 7
        '
        'etiquetaTasa
        '
        Me.etiquetaTasa.AutoSize = True
        Me.etiquetaTasa.Location = New System.Drawing.Point(14, 224)
        Me.etiquetaTasa.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.etiquetaTasa.Name = "etiquetaTasa"
        Me.etiquetaTasa.Size = New System.Drawing.Size(30, 13)
        Me.etiquetaTasa.TabIndex = 6
        Me.etiquetaTasa.Text = "Rate"
        '
        'etiquetaMoneda
        '
        Me.etiquetaMoneda.AutoSize = True
        Me.etiquetaMoneda.Location = New System.Drawing.Point(14, 193)
        Me.etiquetaMoneda.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.etiquetaMoneda.Name = "etiquetaMoneda"
        Me.etiquetaMoneda.Size = New System.Drawing.Size(28, 13)
        Me.etiquetaMoneda.TabIndex = 5
        Me.etiquetaMoneda.Text = "Coin"
        '
        'etiquetaDireccion
        '
        Me.etiquetaDireccion.AutoSize = True
        Me.etiquetaDireccion.Location = New System.Drawing.Point(12, 145)
        Me.etiquetaDireccion.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.etiquetaDireccion.Name = "etiquetaDireccion"
        Me.etiquetaDireccion.Size = New System.Drawing.Size(40, 13)
        Me.etiquetaDireccion.TabIndex = 4
        Me.etiquetaDireccion.Text = "Addres"
        '
        'etiquetaCliente
        '
        Me.etiquetaCliente.AutoSize = True
        Me.etiquetaCliente.Location = New System.Drawing.Point(12, 119)
        Me.etiquetaCliente.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.etiquetaCliente.Name = "etiquetaCliente"
        Me.etiquetaCliente.Size = New System.Drawing.Size(33, 13)
        Me.etiquetaCliente.TabIndex = 3
        Me.etiquetaCliente.Text = "Client"
        '
        'etiquetaFecha
        '
        Me.etiquetaFecha.AutoSize = True
        Me.etiquetaFecha.Location = New System.Drawing.Point(12, 89)
        Me.etiquetaFecha.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.etiquetaFecha.Name = "etiquetaFecha"
        Me.etiquetaFecha.Size = New System.Drawing.Size(30, 13)
        Me.etiquetaFecha.TabIndex = 2
        Me.etiquetaFecha.Text = "Date"
        '
        'etiquetaNumero
        '
        Me.etiquetaNumero.AutoSize = True
        Me.etiquetaNumero.Location = New System.Drawing.Point(12, 60)
        Me.etiquetaNumero.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.etiquetaNumero.Name = "etiquetaNumero"
        Me.etiquetaNumero.Size = New System.Drawing.Size(44, 13)
        Me.etiquetaNumero.TabIndex = 1
        Me.etiquetaNumero.Text = "Number"
        '
        'etiquetaAnio
        '
        Me.etiquetaAnio.AutoSize = True
        Me.etiquetaAnio.Location = New System.Drawing.Point(12, 32)
        Me.etiquetaAnio.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.etiquetaAnio.Name = "etiquetaAnio"
        Me.etiquetaAnio.Size = New System.Drawing.Size(29, 13)
        Me.etiquetaAnio.TabIndex = 0
        Me.etiquetaAnio.Text = "Year"
        '
        'botonImprimir
        '
        Me.botonImprimir.Image = CType(resources.GetObject("botonImprimir.Image"), System.Drawing.Image)
        Me.botonImprimir.Location = New System.Drawing.Point(204, 12)
        Me.botonImprimir.Name = "botonImprimir"
        Me.botonImprimir.Size = New System.Drawing.Size(57, 43)
        Me.botonImprimir.TabIndex = 10
        Me.botonImprimir.Text = "Imprimir"
        Me.botonImprimir.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.botonImprimir.UseVisualStyleBackColor = True
        '
        'botonImprimirPackingList
        '
        Me.botonImprimirPackingList.Image = CType(resources.GetObject("botonImprimirPackingList.Image"), System.Drawing.Image)
        Me.botonImprimirPackingList.ImageAlign = System.Drawing.ContentAlignment.TopCenter
        Me.botonImprimirPackingList.Location = New System.Drawing.Point(270, 12)
        Me.botonImprimirPackingList.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.botonImprimirPackingList.Name = "botonImprimirPackingList"
        Me.botonImprimirPackingList.Size = New System.Drawing.Size(83, 43)
        Me.botonImprimirPackingList.TabIndex = 11
        Me.botonImprimirPackingList.Text = "Print Packing"
        Me.botonImprimirPackingList.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.botonImprimirPackingList.UseVisualStyleBackColor = True
        '
        'BarraTitulo1
        '
        Me.BarraTitulo1.BackColor = System.Drawing.Color.WhiteSmoke
        Me.BarraTitulo1.Dock = System.Windows.Forms.DockStyle.Top
        Me.BarraTitulo1.Location = New System.Drawing.Point(0, 72)
        Me.BarraTitulo1.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.BarraTitulo1.Name = "BarraTitulo1"
        Me.BarraTitulo1.Size = New System.Drawing.Size(1028, 30)
        Me.BarraTitulo1.TabIndex = 1
        '
        'Encabezado1
        '
        Me.Encabezado1.Dock = System.Windows.Forms.DockStyle.Top
        Me.Encabezado1.Location = New System.Drawing.Point(0, 0)
        Me.Encabezado1.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.Encabezado1.Name = "Encabezado1"
        Me.Encabezado1.Size = New System.Drawing.Size(1028, 72)
        Me.Encabezado1.TabIndex = 0
        '
        'frmDevoluciones
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1028, 708)
        Me.Controls.Add(Me.botonImprimirPackingList)
        Me.Controls.Add(Me.botonImprimir)
        Me.Controls.Add(Me.panelDetalle)
        Me.Controls.Add(Me.panelLista)
        Me.Controls.Add(Me.BarraTitulo1)
        Me.Controls.Add(Me.Encabezado1)
        Me.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.Name = "frmDevoluciones"
        Me.Text = "Devoluciones"
        Me.WindowState = System.Windows.Forms.FormWindowState.Maximized
        Me.panelLista.ResumeLayout(False)
        CType(Me.dgLista, System.ComponentModel.ISupportInitialize).EndInit()
        Me.panelEncabezadoLista.ResumeLayout(False)
        Me.panelEncabezadoLista.PerformLayout()
        Me.panelDetalle.ResumeLayout(False)
        Me.Panel1.ResumeLayout(False)
        CType(Me.DgDetalle, System.ComponentModel.ISupportInitialize).EndInit()
        Me.panelTotales.ResumeLayout(False)
        Me.panelTotales.PerformLayout()
        Me.panelOculto.ResumeLayout(False)
        CType(Me.dgOculto, System.ComponentModel.ISupportInitialize).EndInit()
        Me.panelDgTotales.ResumeLayout(False)
        CType(Me.dgDocumentos, System.ComponentModel.ISupportInitialize).EndInit()
        Me.panelDatos.ResumeLayout(False)
        Me.panelDatos.PerformLayout()
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.gbRelacion.ResumeLayout(False)
        Me.panelBotones.ResumeLayout(False)
        CType(Me.dgFactura, System.ComponentModel.ISupportInitialize).EndInit()
        Me.gbCliente.ResumeLayout(False)
        Me.gbCliente.PerformLayout()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents Encabezado1 As encabezado
    Friend WithEvents BarraTitulo1 As BarraTitulo
    Friend WithEvents panelLista As Panel
    Friend WithEvents dgLista As DataGridView
    Friend WithEvents panelEncabezadoLista As Panel
    Friend WithEvents botonClienteE As Button
    Friend WithEvents celdaClienteE As TextBox
    Friend WithEvents etiquetaClienteE As Label
    Friend WithEvents botonActualizar As Button
    Friend WithEvents etiquetaFechas As Label
    Friend WithEvents dtpFinal As DateTimePicker
    Friend WithEvents dtpInicial As DateTimePicker
    Friend WithEvents checkFechas As System.Windows.Forms.CheckBox
    Friend WithEvents panelDetalle As Panel
    Friend WithEvents panelDatos As Panel
    Friend WithEvents gbCliente As GroupBox
    Friend WithEvents botonMoneda As Button
    Friend WithEvents dtpFecha As DateTimePicker
    Friend WithEvents celdaNIT As TextBox
    Friend WithEvents celdaIdMoneda As TextBox
    Friend WithEvents celdaIdCliente As TextBox
    Friend WithEvents celdaDate As TextBox
    Friend WithEvents checkActivo As System.Windows.Forms.CheckBox
    Friend WithEvents celdaTasa As TextBox
    Friend WithEvents celdaMoneda As TextBox
    Friend WithEvents celdaDireccion As TextBox
    Friend WithEvents botonCliente As Button
    Friend WithEvents celdaCliente As TextBox
    Friend WithEvents celdaNumero As TextBox
    Friend WithEvents celdaCatalogo As TextBox
    Friend WithEvents celdaAnio As TextBox
    Friend WithEvents etiquetaTasa As Label
    Friend WithEvents etiquetaMoneda As Label
    Friend WithEvents etiquetaDireccion As Label
    Friend WithEvents etiquetaCliente As Label
    Friend WithEvents etiquetaFecha As Label
    Friend WithEvents etiquetaNumero As Label
    Friend WithEvents etiquetaAnio As Label
    Friend WithEvents DgDetalle As DataGridView
    Friend WithEvents panelTotales As Panel
    Friend WithEvents celdaUsuario As TextBox
    Friend WithEvents celdaTotal As TextBox
    Friend WithEvents celdaTotalCantidad As TextBox
    Friend WithEvents etiquetaTotales As Label
    Friend WithEvents panelDgTotales As Panel
    Friend WithEvents dgDocumentos As DataGridView
    Friend WithEvents gbRelacion As GroupBox
    Friend WithEvents panelBotones As Panel
    Friend WithEvents botonMenos As Button
    Friend WithEvents botonMas As Button
    Friend WithEvents dgFactura As DataGridView
    Friend WithEvents botonAutorizado As Button
    Friend WithEvents celdaAutorizado As TextBox
    Friend WithEvents etiquetaAutorizado As Label
    Friend WithEvents celdaSolicitante As TextBox
    Friend WithEvents etiquetaSolicitante As Label
    Friend WithEvents rbCliente As RadioButton
    Friend WithEvents rbHilos As RadioButton
    Friend WithEvents GroupBox1 As GroupBox
    Friend WithEvents Panel1 As Panel
    Friend WithEvents botonQuitar As Button
    Friend WithEvents botonAgregar As Button
    Friend WithEvents botonCCosto As Button
    Friend WithEvents celdaCCosto As TextBox
    Friend WithEvents etiquetaCCosto As Label
    Friend WithEvents etiquetaComentarios As Label
    Friend WithEvents celdaComentarios As TextBox
    Friend WithEvents celdaEmpresa As System.Windows.Forms.TextBox
    Friend WithEvents celdaIDAprobado As System.Windows.Forms.TextBox
    Friend WithEvents celdaIDCCosto As System.Windows.Forms.TextBox
    Friend WithEvents panelOculto As System.Windows.Forms.Panel
    Friend WithEvents dgOculto As System.Windows.Forms.DataGridView
    Friend WithEvents colNumero As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colFecha As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colCodEmpresa As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colCliente As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colReferencia As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colAnio As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colEstado As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colDireccion As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colMoneda As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colTasa As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colIDAprovado As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colAprovadoPor As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents coLIDCCosto As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colCCosto As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colDevolucion As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colComentario As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colEmp As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colEmpBultos As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colCatBox As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colAnioBox As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colNumBox As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colLineaDetalle As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colLineaBox As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colReferenciaBox As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colTara As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colPaquetes As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colCantidadMedida As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colXtraBox As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents botonImprimir As System.Windows.Forms.Button
    Friend WithEvents botonImprimirPackingList As System.Windows.Forms.Button
    Friend WithEvents celdaRSCliente As System.Windows.Forms.TextBox
    Friend WithEvents etiquetaCustomer As System.Windows.Forms.Label
    Friend WithEvents colClave As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colDocumento As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colDatos As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents celdaDesactivar As System.Windows.Forms.Label
    Friend WithEvents colNumeroF As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colFechaF As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colReferenciaF As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colAnioF As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colCatalogoF As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colAgregar As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colEmpresa As DataGridViewTextBoxColumn
    Friend WithEvents colCatalogo As DataGridViewTextBoxColumn
    Friend WithEvents colAnioFactura As DataGridViewTextBoxColumn
    Friend WithEvents colCodigoDet As DataGridViewTextBoxColumn
    Friend WithEvents colProductoDet As DataGridViewTextBoxColumn
    Friend WithEvents colFacturaDet As DataGridViewTextBoxColumn
    Friend WithEvents colLinea As DataGridViewTextBoxColumn
    Friend WithEvents colLineaDevolucion As DataGridViewTextBoxColumn
    Friend WithEvents colIDMedida As DataGridViewTextBoxColumn
    Friend WithEvents colUMedida As DataGridViewTextBoxColumn
    Friend WithEvents colLoteDet As DataGridViewTextBoxColumn
    Friend WithEvents colLoteDetDev As DataGridViewTextBoxColumn
    Friend WithEvents colCantidadDet As DataGridViewTextBoxColumn
    Friend WithEvents colPrecioDet As DataGridViewTextBoxColumn
    Friend WithEvents colPrecioKg As DataGridViewTextBoxColumn
    Friend WithEvents colCantidadKG As DataGridViewTextBoxColumn
    Friend WithEvents colBultosDet As DataGridViewTextBoxColumn
    Friend WithEvents colReferenciaDet As DataGridViewTextBoxColumn
    Friend WithEvents colTejedoraDet As DataGridViewTextBoxColumn
    Friend WithEvents colXtra As DataGridViewTextBoxColumn
End Class
