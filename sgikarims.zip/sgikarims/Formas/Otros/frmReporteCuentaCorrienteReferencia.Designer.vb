﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class frmReporteCuentaCorrienteReferencia
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.dtpFechaFinal = New System.Windows.Forms.DateTimePicker()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.dtpFechaInicial = New System.Windows.Forms.DateTimePicker()
        Me.rbPorFecha = New System.Windows.Forms.RadioButton()
        Me.GroupBox2 = New System.Windows.Forms.GroupBox()
        Me.celdaPorReferencia = New System.Windows.Forms.TextBox()
        Me.rbPorReferencia = New System.Windows.Forms.RadioButton()
        Me.GroupBox3 = New System.Windows.Forms.GroupBox()
        Me.celdaIdNumeroFinal = New System.Windows.Forms.TextBox()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.celdaIdNumeroInicial = New System.Windows.Forms.TextBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.rbPorCorrelativo = New System.Windows.Forms.RadioButton()
        Me.botonBuscar = New System.Windows.Forms.Button()
        Me.dgListado = New System.Windows.Forms.DataGridView()
        Me.col_Fecha = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.col_Poliza = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.col_referencia = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.col_tipo = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.col_anio = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.col_numero = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.col_dua = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.col_contenedor = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.col_bl = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.col_correlativo = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.col_regimen = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.col_origen = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.col_aduana = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.col_marchamo = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.col_naviera = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.col_archivo = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.col_notas = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.col_contador = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.botonTodo = New System.Windows.Forms.Button()
        Me.botonSeleccion = New System.Windows.Forms.Button()
        Me.botonCerrar = New System.Windows.Forms.Button()
        Me.panelDetalle = New System.Windows.Forms.Panel()
        Me.panelBotones = New System.Windows.Forms.Panel()
        Me.GroupBox1.SuspendLayout()
        Me.GroupBox2.SuspendLayout()
        Me.GroupBox3.SuspendLayout()
        CType(Me.dgListado, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.panelDetalle.SuspendLayout()
        Me.panelBotones.SuspendLayout()
        Me.SuspendLayout()
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.Label2)
        Me.GroupBox1.Controls.Add(Me.dtpFechaFinal)
        Me.GroupBox1.Controls.Add(Me.Label1)
        Me.GroupBox1.Controls.Add(Me.dtpFechaInicial)
        Me.GroupBox1.Controls.Add(Me.rbPorFecha)
        Me.GroupBox1.Location = New System.Drawing.Point(37, 15)
        Me.GroupBox1.Margin = New System.Windows.Forms.Padding(4)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Padding = New System.Windows.Forms.Padding(4)
        Me.GroupBox1.Size = New System.Drawing.Size(287, 107)
        Me.GroupBox1.TabIndex = 0
        Me.GroupBox1.TabStop = False
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(141, 44)
        Me.Label2.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(72, 17)
        Me.Label2.TabIndex = 5
        Me.Label2.Text = "Final Date"
        '
        'dtpFechaFinal
        '
        Me.dtpFechaFinal.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.dtpFechaFinal.Location = New System.Drawing.Point(145, 64)
        Me.dtpFechaFinal.Margin = New System.Windows.Forms.Padding(4)
        Me.dtpFechaFinal.Name = "dtpFechaFinal"
        Me.dtpFechaFinal.Size = New System.Drawing.Size(120, 22)
        Me.dtpFechaFinal.TabIndex = 4
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(20, 44)
        Me.Label1.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(78, 17)
        Me.Label1.TabIndex = 3
        Me.Label1.Text = "Initial Date "
        '
        'dtpFechaInicial
        '
        Me.dtpFechaInicial.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.dtpFechaInicial.Location = New System.Drawing.Point(24, 64)
        Me.dtpFechaInicial.Margin = New System.Windows.Forms.Padding(4)
        Me.dtpFechaInicial.Name = "dtpFechaInicial"
        Me.dtpFechaInicial.Size = New System.Drawing.Size(112, 22)
        Me.dtpFechaInicial.TabIndex = 2
        '
        'rbPorFecha
        '
        Me.rbPorFecha.AutoSize = True
        Me.rbPorFecha.Location = New System.Drawing.Point(70, -2)
        Me.rbPorFecha.Margin = New System.Windows.Forms.Padding(4)
        Me.rbPorFecha.Name = "rbPorFecha"
        Me.rbPorFecha.Size = New System.Drawing.Size(154, 21)
        Me.rbPorFecha.TabIndex = 1
        Me.rbPorFecha.Text = "By Date (of Income)"
        Me.rbPorFecha.UseVisualStyleBackColor = True
        '
        'GroupBox2
        '
        Me.GroupBox2.Controls.Add(Me.celdaPorReferencia)
        Me.GroupBox2.Controls.Add(Me.rbPorReferencia)
        Me.GroupBox2.Location = New System.Drawing.Point(37, 129)
        Me.GroupBox2.Margin = New System.Windows.Forms.Padding(4)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Padding = New System.Windows.Forms.Padding(4)
        Me.GroupBox2.Size = New System.Drawing.Size(287, 71)
        Me.GroupBox2.TabIndex = 1
        Me.GroupBox2.TabStop = False
        '
        'celdaPorReferencia
        '
        Me.celdaPorReferencia.Location = New System.Drawing.Point(24, 28)
        Me.celdaPorReferencia.Margin = New System.Windows.Forms.Padding(4)
        Me.celdaPorReferencia.Name = "celdaPorReferencia"
        Me.celdaPorReferencia.Size = New System.Drawing.Size(241, 22)
        Me.celdaPorReferencia.TabIndex = 3
        '
        'rbPorReferencia
        '
        Me.rbPorReferencia.AutoSize = True
        Me.rbPorReferencia.Checked = True
        Me.rbPorReferencia.Location = New System.Drawing.Point(51, -1)
        Me.rbPorReferencia.Margin = New System.Windows.Forms.Padding(4)
        Me.rbPorReferencia.Name = "rbPorReferencia"
        Me.rbPorReferencia.Size = New System.Drawing.Size(115, 21)
        Me.rbPorReferencia.TabIndex = 2
        Me.rbPorReferencia.TabStop = True
        Me.rbPorReferencia.Text = "By Reference"
        Me.rbPorReferencia.UseVisualStyleBackColor = True
        '
        'GroupBox3
        '
        Me.GroupBox3.Controls.Add(Me.celdaIdNumeroFinal)
        Me.GroupBox3.Controls.Add(Me.Label4)
        Me.GroupBox3.Controls.Add(Me.celdaIdNumeroInicial)
        Me.GroupBox3.Controls.Add(Me.Label3)
        Me.GroupBox3.Controls.Add(Me.rbPorCorrelativo)
        Me.GroupBox3.Location = New System.Drawing.Point(347, 15)
        Me.GroupBox3.Margin = New System.Windows.Forms.Padding(4)
        Me.GroupBox3.Name = "GroupBox3"
        Me.GroupBox3.Padding = New System.Windows.Forms.Padding(4)
        Me.GroupBox3.Size = New System.Drawing.Size(267, 107)
        Me.GroupBox3.TabIndex = 2
        Me.GroupBox3.TabStop = False
        '
        'celdaIdNumeroFinal
        '
        Me.celdaIdNumeroFinal.Location = New System.Drawing.Point(149, 64)
        Me.celdaIdNumeroFinal.Margin = New System.Windows.Forms.Padding(4)
        Me.celdaIdNumeroFinal.Name = "celdaIdNumeroFinal"
        Me.celdaIdNumeroFinal.Size = New System.Drawing.Size(97, 22)
        Me.celdaIdNumeroFinal.TabIndex = 4
        Me.celdaIdNumeroFinal.Text = "0"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(145, 44)
        Me.Label4.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(92, 17)
        Me.Label4.TabIndex = 3
        Me.Label4.Text = "Final Number"
        '
        'celdaIdNumeroInicial
        '
        Me.celdaIdNumeroInicial.Location = New System.Drawing.Point(8, 64)
        Me.celdaIdNumeroInicial.Margin = New System.Windows.Forms.Padding(4)
        Me.celdaIdNumeroInicial.Name = "celdaIdNumeroInicial"
        Me.celdaIdNumeroInicial.Size = New System.Drawing.Size(101, 22)
        Me.celdaIdNumeroInicial.TabIndex = 2
        Me.celdaIdNumeroInicial.Text = "0"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(8, 44)
        Me.Label3.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(94, 17)
        Me.Label3.TabIndex = 1
        Me.Label3.Text = "Initial Number"
        '
        'rbPorCorrelativo
        '
        Me.rbPorCorrelativo.AutoSize = True
        Me.rbPorCorrelativo.Location = New System.Drawing.Point(42, -2)
        Me.rbPorCorrelativo.Margin = New System.Windows.Forms.Padding(4)
        Me.rbPorCorrelativo.Name = "rbPorCorrelativo"
        Me.rbPorCorrelativo.Size = New System.Drawing.Size(172, 21)
        Me.rbPorCorrelativo.TabIndex = 0
        Me.rbPorCorrelativo.Text = "By Correlative Of entry"
        Me.rbPorCorrelativo.UseVisualStyleBackColor = True
        '
        'botonBuscar
        '
        Me.botonBuscar.Image = Global.KARIMs_SGI.My.Resources.Resources.zoom
        Me.botonBuscar.ImageAlign = System.Drawing.ContentAlignment.TopCenter
        Me.botonBuscar.Location = New System.Drawing.Point(347, 129)
        Me.botonBuscar.Margin = New System.Windows.Forms.Padding(4)
        Me.botonBuscar.Name = "botonBuscar"
        Me.botonBuscar.Size = New System.Drawing.Size(103, 53)
        Me.botonBuscar.TabIndex = 3
        Me.botonBuscar.Text = "                     Search"
        Me.botonBuscar.UseVisualStyleBackColor = True
        '
        'dgListado
        '
        Me.dgListado.AllowUserToAddRows = False
        Me.dgListado.AllowUserToDeleteRows = False
        Me.dgListado.AllowUserToOrderColumns = True
        Me.dgListado.BackgroundColor = System.Drawing.SystemColors.Control
        Me.dgListado.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgListado.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.col_Fecha, Me.col_Poliza, Me.col_referencia, Me.col_tipo, Me.col_anio, Me.col_numero, Me.col_dua, Me.col_contenedor, Me.col_bl, Me.col_correlativo, Me.col_regimen, Me.col_origen, Me.col_aduana, Me.col_marchamo, Me.col_naviera, Me.col_archivo, Me.col_notas, Me.col_contador})
        Me.dgListado.Dock = System.Windows.Forms.DockStyle.Fill
        Me.dgListado.Location = New System.Drawing.Point(0, 0)
        Me.dgListado.Margin = New System.Windows.Forms.Padding(4)
        Me.dgListado.MultiSelect = False
        Me.dgListado.Name = "dgListado"
        Me.dgListado.ReadOnly = True
        Me.dgListado.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.dgListado.Size = New System.Drawing.Size(577, 154)
        Me.dgListado.TabIndex = 4
        '
        'col_Fecha
        '
        Me.col_Fecha.HeaderText = "Date"
        Me.col_Fecha.Name = "col_Fecha"
        Me.col_Fecha.ReadOnly = True
        '
        'col_Poliza
        '
        Me.col_Poliza.HeaderText = "Policy"
        Me.col_Poliza.Name = "col_Poliza"
        Me.col_Poliza.ReadOnly = True
        '
        'col_referencia
        '
        Me.col_referencia.HeaderText = "Reference"
        Me.col_referencia.Name = "col_referencia"
        Me.col_referencia.ReadOnly = True
        '
        'col_tipo
        '
        Me.col_tipo.HeaderText = "tipo"
        Me.col_tipo.Name = "col_tipo"
        Me.col_tipo.ReadOnly = True
        Me.col_tipo.Visible = False
        '
        'col_anio
        '
        Me.col_anio.HeaderText = "año"
        Me.col_anio.Name = "col_anio"
        Me.col_anio.ReadOnly = True
        Me.col_anio.Visible = False
        '
        'col_numero
        '
        Me.col_numero.HeaderText = "numero"
        Me.col_numero.Name = "col_numero"
        Me.col_numero.ReadOnly = True
        Me.col_numero.Visible = False
        '
        'col_dua
        '
        Me.col_dua.HeaderText = "dua"
        Me.col_dua.Name = "col_dua"
        Me.col_dua.ReadOnly = True
        Me.col_dua.Visible = False
        Me.col_dua.Width = 300
        '
        'col_contenedor
        '
        Me.col_contenedor.HeaderText = "contenedor"
        Me.col_contenedor.Name = "col_contenedor"
        Me.col_contenedor.ReadOnly = True
        Me.col_contenedor.Visible = False
        '
        'col_bl
        '
        Me.col_bl.HeaderText = "bl"
        Me.col_bl.Name = "col_bl"
        Me.col_bl.ReadOnly = True
        Me.col_bl.Visible = False
        '
        'col_correlativo
        '
        Me.col_correlativo.HeaderText = "correlativo"
        Me.col_correlativo.Name = "col_correlativo"
        Me.col_correlativo.ReadOnly = True
        Me.col_correlativo.Visible = False
        '
        'col_regimen
        '
        Me.col_regimen.HeaderText = "regimen"
        Me.col_regimen.Name = "col_regimen"
        Me.col_regimen.ReadOnly = True
        Me.col_regimen.Visible = False
        '
        'col_origen
        '
        Me.col_origen.HeaderText = "origen"
        Me.col_origen.Name = "col_origen"
        Me.col_origen.ReadOnly = True
        Me.col_origen.Visible = False
        '
        'col_aduana
        '
        Me.col_aduana.HeaderText = "aduana"
        Me.col_aduana.Name = "col_aduana"
        Me.col_aduana.ReadOnly = True
        Me.col_aduana.Visible = False
        '
        'col_marchamo
        '
        Me.col_marchamo.HeaderText = "marchamo"
        Me.col_marchamo.Name = "col_marchamo"
        Me.col_marchamo.ReadOnly = True
        Me.col_marchamo.Visible = False
        '
        'col_naviera
        '
        Me.col_naviera.HeaderText = "naviera"
        Me.col_naviera.Name = "col_naviera"
        Me.col_naviera.ReadOnly = True
        Me.col_naviera.Visible = False
        '
        'col_archivo
        '
        Me.col_archivo.HeaderText = "archivo"
        Me.col_archivo.Name = "col_archivo"
        Me.col_archivo.ReadOnly = True
        Me.col_archivo.Visible = False
        '
        'col_notas
        '
        Me.col_notas.HeaderText = "notas"
        Me.col_notas.Name = "col_notas"
        Me.col_notas.ReadOnly = True
        Me.col_notas.Visible = False
        '
        'col_contador
        '
        Me.col_contador.HeaderText = "contador"
        Me.col_contador.Name = "col_contador"
        Me.col_contador.ReadOnly = True
        Me.col_contador.Visible = False
        '
        'botonTodo
        '
        Me.botonTodo.Location = New System.Drawing.Point(37, 39)
        Me.botonTodo.Margin = New System.Windows.Forms.Padding(4)
        Me.botonTodo.Name = "botonTodo"
        Me.botonTodo.Size = New System.Drawing.Size(100, 28)
        Me.botonTodo.TabIndex = 5
        Me.botonTodo.Text = "All"
        Me.botonTodo.UseVisualStyleBackColor = True
        '
        'botonSeleccion
        '
        Me.botonSeleccion.Location = New System.Drawing.Point(161, 39)
        Me.botonSeleccion.Margin = New System.Windows.Forms.Padding(4)
        Me.botonSeleccion.Name = "botonSeleccion"
        Me.botonSeleccion.Size = New System.Drawing.Size(100, 28)
        Me.botonSeleccion.TabIndex = 6
        Me.botonSeleccion.Text = "Selection"
        Me.botonSeleccion.UseVisualStyleBackColor = True
        '
        'botonCerrar
        '
        Me.botonCerrar.Location = New System.Drawing.Point(514, 39)
        Me.botonCerrar.Margin = New System.Windows.Forms.Padding(4)
        Me.botonCerrar.Name = "botonCerrar"
        Me.botonCerrar.Size = New System.Drawing.Size(100, 28)
        Me.botonCerrar.TabIndex = 7
        Me.botonCerrar.Text = "Cancel"
        Me.botonCerrar.UseVisualStyleBackColor = True
        '
        'panelDetalle
        '
        Me.panelDetalle.Controls.Add(Me.dgListado)
        Me.panelDetalle.Location = New System.Drawing.Point(37, 207)
        Me.panelDetalle.Name = "panelDetalle"
        Me.panelDetalle.Size = New System.Drawing.Size(577, 154)
        Me.panelDetalle.TabIndex = 8
        '
        'panelBotones
        '
        Me.panelBotones.Controls.Add(Me.botonTodo)
        Me.panelBotones.Controls.Add(Me.botonSeleccion)
        Me.panelBotones.Controls.Add(Me.botonCerrar)
        Me.panelBotones.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.panelBotones.Location = New System.Drawing.Point(0, 367)
        Me.panelBotones.Name = "panelBotones"
        Me.panelBotones.Size = New System.Drawing.Size(641, 96)
        Me.panelBotones.TabIndex = 9
        '
        'frmReporteCuentaCorrienteReferencia
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(641, 463)
        Me.Controls.Add(Me.panelBotones)
        Me.Controls.Add(Me.panelDetalle)
        Me.Controls.Add(Me.botonBuscar)
        Me.Controls.Add(Me.GroupBox3)
        Me.Controls.Add(Me.GroupBox2)
        Me.Controls.Add(Me.GroupBox1)
        Me.Margin = New System.Windows.Forms.Padding(4)
        Me.Name = "frmReporteCuentaCorrienteReferencia"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "By Reference"
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.GroupBox2.ResumeLayout(False)
        Me.GroupBox2.PerformLayout()
        Me.GroupBox3.ResumeLayout(False)
        Me.GroupBox3.PerformLayout()
        CType(Me.dgListado, System.ComponentModel.ISupportInitialize).EndInit()
        Me.panelDetalle.ResumeLayout(False)
        Me.panelBotones.ResumeLayout(False)
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents GroupBox1 As GroupBox
    Friend WithEvents Label2 As Label
    Friend WithEvents dtpFechaFinal As DateTimePicker
    Friend WithEvents Label1 As Label
    Friend WithEvents dtpFechaInicial As DateTimePicker
    Friend WithEvents rbPorFecha As RadioButton
    Friend WithEvents GroupBox2 As GroupBox
    Friend WithEvents celdaPorReferencia As TextBox
    Friend WithEvents rbPorReferencia As RadioButton
    Friend WithEvents GroupBox3 As GroupBox
    Friend WithEvents celdaIdNumeroFinal As TextBox
    Friend WithEvents Label4 As Label
    Friend WithEvents celdaIdNumeroInicial As TextBox
    Friend WithEvents Label3 As Label
    Friend WithEvents rbPorCorrelativo As RadioButton
    Friend WithEvents botonBuscar As Button
    Friend WithEvents dgListado As DataGridView
    Friend WithEvents botonTodo As Button
    Friend WithEvents botonSeleccion As Button
    Friend WithEvents botonCerrar As Button
    Friend WithEvents col_Fecha As DataGridViewTextBoxColumn
    Friend WithEvents col_Poliza As DataGridViewTextBoxColumn
    Friend WithEvents col_referencia As DataGridViewTextBoxColumn
    Friend WithEvents col_tipo As DataGridViewTextBoxColumn
    Friend WithEvents col_anio As DataGridViewTextBoxColumn
    Friend WithEvents col_numero As DataGridViewTextBoxColumn
    Friend WithEvents col_dua As DataGridViewTextBoxColumn
    Friend WithEvents col_contenedor As DataGridViewTextBoxColumn
    Friend WithEvents col_bl As DataGridViewTextBoxColumn
    Friend WithEvents col_correlativo As DataGridViewTextBoxColumn
    Friend WithEvents col_regimen As DataGridViewTextBoxColumn
    Friend WithEvents col_origen As DataGridViewTextBoxColumn
    Friend WithEvents col_aduana As DataGridViewTextBoxColumn
    Friend WithEvents col_marchamo As DataGridViewTextBoxColumn
    Friend WithEvents col_naviera As DataGridViewTextBoxColumn
    Friend WithEvents col_archivo As DataGridViewTextBoxColumn
    Friend WithEvents col_notas As DataGridViewTextBoxColumn
    Friend WithEvents col_contador As DataGridViewTextBoxColumn
    Friend WithEvents panelDetalle As System.Windows.Forms.Panel
    Friend WithEvents panelBotones As System.Windows.Forms.Panel
End Class
