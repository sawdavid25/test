﻿Public Class frmBCheque
    Private Const STR_CODIGO As String = "Fmt_Cheque"
    Private Const MAX_DETALLE As Integer = 18
    Private ID As Integer

    Private intCuenta As Integer
    Private intTipo As Integer
    Private intCiclo As Integer
    Private intNumero As Integer

    Private Reporte As New rptCheque
    Private Campos As New Dictionary(Of String, String)
    Private Base As New clsBancos

    Public Property Titulo As String = "Bank Account"

    'Prepara la presentación del reporte
    Public Sub PrepararDocumento(ByVal Cuenta As Integer, ByVal Tipo As Integer, ByVal Ciclo As Integer, ByVal Numero As Integer)
        'ID de cuenta bancaria y documento
        intCuenta = Cuenta
        intTipo = Tipo
        intCiclo = Ciclo
        intNumero = Numero

        AsignarCampos()
        CargarPosiciones()
        CargarDatos()
    End Sub

    'Carga el reporte al visor
    Public Sub CargarReporte()
        Visor.ReportSource = Reporte
        Visor.Show()
    End Sub

    'Llena el listado de campos
    Private Sub AsignarCampos()
        Const DEF_POS As String = "0.0.0"
        Campos.Clear()

        'Datos de encabezado
        Campos.Add("fecha", DEF_POS)
        Campos.Add("nombre", DEF_POS)
        Campos.Add("monto", DEF_POS)
        Campos.Add("letras", DEF_POS)
        Campos.Add("descripcion", DEF_POS)
        Campos.Add("referencia", DEF_POS)
        Campos.Add("numero", DEF_POS)

        'Datos del detalle
        Campos.Add("detalle_cuenta", DEF_POS)
        Campos.Add("detalle_descripcion", DEF_POS)
        Campos.Add("detalle_debe", DEF_POS)
        Campos.Add("detalle_haber", DEF_POS)

        'Datos del pie de página
        Campos.Add("pie_nombre", DEF_POS)
        Campos.Add("pie_descripcion", DEF_POS)
        Campos.Add("pie_monto", DEF_POS)
        Campos.Add("cuenta", DEF_POS)
        Campos.Add("dia", DEF_POS)
        Campos.Add("mes", DEF_POS)
        Campos.Add("ciclo", DEF_POS)
        Campos.Add("usuario", DEF_POS)

        'Fecha y hora de impresión
        Campos.Add("impresion_fecha", DEF_POS)
        Campos.Add("impresion_hora", DEF_POS)
    End Sub

    'Carga los datos del cheque
    Private Sub CargarDatos()
        Const MAX_CHAR As Integer = 70

        Dim strSQL As String = STR_VACIO
        Dim strCC As String, strTemp As String, strDato As String
        Dim dblDato As Double = 0.0
        Dim intIdCompra As Integer
        Dim intMas As Integer = INT_CERO
        Dim i As Integer = INT_CERO

        Dim cmd As MySqlCommand
        Dim da As New MySqlDataAdapter
        Dim dt As New System.Data.DataTable
        Dim dr As DataRow

        'Recuperar datos de encabezado
        If (Sesion.IdEmpresa = 15) Or (Sesion.IdEmpresa = 18) Or (Sesion.IdEmpresa = 19) Then
            strSQL = " SELECT CONCAT(CONCAT(UCASE(l.cat_desc),'         '),DAY(e.HDoc_Doc_Fec),CONCAT('          ',MONTH(e.HDoc_Doc_Fec),'          ',YEAR(e.HDoc_Doc_Fec))) Fecha,  "
        Else
            strSQL = " SELECT CONCAT(CONCAT(UCASE(l.cat_desc),', '),CONCAT(DAY(e.HDoc_Doc_Fec),' DE ',ELT(MONTH(e.HDoc_Doc_Fec),'ENERO','FEBRERO','MARZO','ABRIL','MAYO','JUNIO','JULIO','AGOSTO','SEPTIEMBRE','OCTUBRE','NOVIEMBRE','DICIEMBRE'),' DE ', YEAR(e.HDoc_Doc_Fec))) Fecha,"
        End If
        strSQL &= "        DAY(e.HDoc_Doc_Fec) Dia, MONTH(e.HDoc_Doc_Fec) Mes, YEAR(e.HDoc_Doc_Fec) Ciclo," &
                "        e.HDoc_DR1_Num Numero, e.HDoc_Usuario Usuario, " &
                "        CONCAT('',FORMAT(e.HDoc_RF1_Dbl,2),'') Monto," &
                "        CONCAT(CAST(IFNULL(m.cat_clave,'') AS CHAR),' ',FORMAT(e.HDoc_RF1_Dbl,2),'') Monto2," &
                "        e.HDoc_Emp_Per Nombre," &
                "        CONCAT('*** ',e.HDoc_RF2_Txt,' ***') Letras," &
                "        e.HDoc_RF1_Cod Descripcion," &
                "        {ref} Referencia,'SUMAS IGUALES' totalL,CURDATE() Fecha2,IF(e.HDoc_Doc_Mon = 182,ROUND((e.HDoc_RF1_Dbl),2),ROUND((e.HDoc_RF1_Dbl * e.HDoc_Doc_TC),2)) Monto3, " &
                 "        IFNULL((SELECT CONCAT(b.BCta_Num_Cue,' / ',b.BCta_Des_Cue) FROM CtasBcos b WHERE b.BCta_Sis_Emp = e.HDoc_Sis_Emp AND b.BCta_Num = e.HDoc_RF1_Num LIMIT 1),'N/A') Cuenta " &
                " FROM Dcmtos_HDR e" &
                "      INNER JOIN Catalogos l ON l.cat_clase = 'Lugares' AND l.cat_clave = 'Cheques'" &
               "      LEFT JOIN Catalogos m ON m.cat_clase = 'Monedas' AND m.cat_num = e.HDoc_Doc_Mon" &
                " WHERE e.HDoc_Sis_Emp=@empresa AND e.HDoc_Doc_Cat=@tipo AND e.HDoc_Doc_Ano=@ciclo AND e.HDoc_Doc_Num=@numero"
        If Sesion.IdEmpresa = 12 Or Sesion.IdEmpresa = 10 Then
            strSQL = strSQL.Replace("{ref}", "''")
        ElseIf (Sesion.IdEmpresa = 18) Or (Sesion.IdEmpresa = 15) Or (Sesion.IdEmpresa = 19) Then
            strSQL = strSQL.Replace("{ref}", "IF(e.HDoc_Doc_Mon=182,e.HDoc_DR1_Num,e.HDoc_DR2_Num) ")
        Else
            strSQL = strSQL.Replace("{ref}", "e.HDoc_DR2_Num ")
        End If

        cmd = New MySqlCommand(strSQL, CON)
        cmd.Parameters.AddWithValue("@empresa", Sesion.IdEmpresa)
        cmd.Parameters.AddWithValue("@tipo", intTipo)
        cmd.Parameters.AddWithValue("@ciclo", intCiclo)
        cmd.Parameters.AddWithValue("@numero", intNumero)
        da = New MySqlDataAdapter(cmd)
        da.Fill(dt)

        If dt.Rows.Count > INT_CERO Then
            dr = dt.Rows(INT_CERO)

            Reporte.SetParameterValue("fecha", dr("fecha"))
            Reporte.SetParameterValue("monto", CDbl(dr("monto")).ToString(FORMATO_MONEDA))
            Reporte.SetParameterValue("nombre", dr("nombre"))
            Reporte.SetParameterValue("letras", dr("letras"))
            Reporte.SetParameterValue("descripcion", dr("descripcion"))
            Reporte.SetParameterValue("referencia", dr("referencia"))
            If (Sesion.IdEmpresa = 18) Or (Sesion.IdEmpresa = 15) Or (Sesion.IdEmpresa = 19) Then
                Reporte.SetParameterValue("numero", STR_VACIO) ' CDbl(dr("Monto3")).ToString(FORMATO_MONEDA))
                Reporte.SetParameterValue("usuario", STR_VACIO) ' dr("usuario"))
                Reporte.SetParameterValue("dia", STR_VACIO) ' dr("dia"))
                Reporte.SetParameterValue("mes", STR_VACIO) ' dr("mes"))
                Reporte.SetParameterValue("ciclo", STR_VACIO) ' dr("ciclo"))
            Else
                Reporte.SetParameterValue("numero", dr("numero"))
                Reporte.SetParameterValue("usuario", dr("usuario"))
                Reporte.SetParameterValue("dia", dr("dia"))
                Reporte.SetParameterValue("mes", dr("mes"))
                Reporte.SetParameterValue("ciclo", dr("ciclo"))
            End If

            If (Sesion.IdEmpresa = 18) Or (Sesion.IdEmpresa = 15) Or (Sesion.IdEmpresa = 19) Then
                Reporte.SetParameterValue("cuenta", STR_VACIO) ' dr("cuenta"))
                Reporte.SetParameterValue("pie_descripcion", STR_VACIO) 'dr("totalL"))
                Reporte.SetParameterValue("pie_nombre", STR_VACIO) ' dr("nombre"))
            Else
                Reporte.SetParameterValue("cuenta", dr("cuenta"))
                Reporte.SetParameterValue("pie_descripcion", dr("descripcion"))
                Reporte.SetParameterValue("pie_nombre", dr("nombre"))
            End If

            If (Sesion.IdEmpresa = 18) Or (Sesion.IdEmpresa = 15) Or (Sesion.IdEmpresa = 19) Then
                Reporte.SetParameterValue("pie_monto", STR_VACIO) ' dr("monto2"))
                Reporte.SetParameterValue("impresion_fecha", STR_VACIO) ' CDbl(dr("Monto3")).ToString(FORMATO_MONEDA))
            Else
                Reporte.SetParameterValue("pie_monto", dr("monto2"))
                Reporte.SetParameterValue("impresion_fecha", dr("Fecha2"))
            End If
                ' fin Filas 
            End If

            'Centro de costos
            strSQL = " SELECT IF(MAX(cc.cost_num) = 0, 0,1) Costo " &
                 " FROM {conta}.detalle_polizas d" &
                 " LEFT JOIN {conta}.costos cc ON cc.cost_num=d.centro_costos" &
                 " WHERE d.Empresa = @empresa AND d.ref_tipo=@tipo AND d.ref_ciclo=@ciclo AND d.ref_numero=@numero"
        strSQL = strSQL.Replace("{conta}", Sesion.BaseConta)
        cmd = New MySqlCommand(strSQL, CON)
        cmd.Parameters.AddWithValue("@empresa", Sesion.IdEmpresa)
        cmd.Parameters.AddWithValue("@tipo", intTipo)
        cmd.Parameters.AddWithValue("@ciclo", intCiclo)
        cmd.Parameters.AddWithValue("@numero", intNumero)
        strCC = cmd.ExecuteScalar.ToString

        'Recuperar detalle de documento
        intIdCompra = Base.ObtenerIdDocumentoCompra

        strSQL = " SELECT IFNULL(l.DDoc_RF1_Txt,'') Texto, l.DDoc_RF1_Dbl Monto, " &
                 "        IFNULL(dp.cuenta,'') Cuenta, IFNULL(cu.nombre,'') Nombre, IFNULL(dp.importe,0) Importe , IFNULL(dp.operacion,'') Operacion " &
                 " FROM Dcmtos_HDR h " &
                 "      LEFT JOIN {conta}.detalle_polizas dp ON dp.ref_tipo = h.HDoc_Doc_Cat And dp.empresa = h.HDoc_Sis_Emp And dp.ref_ciclo = h.HDoc_Doc_Ano And dp.ref_numero = h.HDoc_Doc_Num" &
                 "      LEFT JOIN {conta}.cuentas cu on cu.empresa = dp.empresa And cu.id_cuenta = dp.cuenta " &
                 "      LEFT JOIN Dcmtos_DTL l on l.DDoc_Sis_Emp = h.HDoc_Sis_Emp And l.DDoc_Doc_Cat = h.HDoc_Doc_Cat And l.DDoc_Doc_Ano = h.HDoc_Doc_Ano And l.DDoc_Doc_Num = h.HDoc_Doc_Num  " &
                 "      LEFT JOIN Dcmtos_HDR e ON e.HDoc_Sis_Emp = l.DDoc_Sis_Emp And e.HDoc_Doc_Cat={compra} And e.HDoc_Doc_Ano = l.DDoc_RF2_Num And e.HDoc_Doc_Num = l.DDoc_RF3_Num " &
                 "      LEFT JOIN Dcmtos_DTL d ON d.DDoc_Sis_Emp = e.HDoc_Sis_Emp And d.DDoc_Doc_Cat = e.HDoc_Doc_Cat And d.DDoc_Doc_Ano = e.HDoc_Doc_Ano And d.DDoc_Doc_Num = e.HDoc_Doc_Num " &
                 " WHERE h.HDoc_Sis_Emp=@empresa And h.HDoc_Doc_Cat=@tipo And h.HDoc_Doc_Ano=@ciclo And h.HDoc_Doc_Num=@numero" &
                 " GROUP BY dp.poliza, dp.item " &
                 " ORDER BY dp.operacion DESC"
        strSQL = strSQL.Replace("{conta}", Sesion.BaseConta)
        strSQL = strSQL.Replace("{compra}", intIdCompra)

        cmd = New MySqlCommand(strSQL, CON)
        cmd.Parameters.AddWithValue("@empresa", Sesion.IdEmpresa)
        cmd.Parameters.AddWithValue("@tipo", intTipo)
        cmd.Parameters.AddWithValue("@ciclo", intCiclo)
        cmd.Parameters.AddWithValue("@numero", intNumero)
        da = New MySqlDataAdapter(cmd)
        dt = New System.Data.DataTable
        da.Fill(dt)

        If dt.Rows.Count > INT_CERO Then
            i = 1
            For Each dr In dt.Rows
                strDato = String.Empty
                strTemp = dr("texto")
                If i <= MAX_DETALLE Then
                    strTemp &= dr("nombre")
                End If
                If InStr(strTemp, " de fecha ") > INT_CERO Then
                    strTemp = Replace(strTemp, "N° ", String.Empty)
                    strTemp = Replace(strTemp, " de fecha ", " - ")
                End If
                If Len(strTemp) > MAX_CHAR Then
                    strTemp = strTemp.Substring(INT_CERO, MAX_CHAR) & "..."
                End If
                If i = MAX_DETALLE Then
                    strDato = strTemp
                End If
                If i < MAX_DETALLE Then
                    Reporte.DataDefinition.FormulaFields("detalle_cuenta_" & i.ToString("D2")).Text = Base.Text("-> " & dr("cuenta"))
                    Reporte.DataDefinition.FormulaFields("detalle_descripcion_" & i.ToString("D2")).Text = Base.Text(dr("nombre"))
                    If dr("operacion").ToString.Equals("A") Then
                        Reporte.DataDefinition.FormulaFields("detalle_haber_" & i.ToString("D2")).Text = Base.Text(CDbl(dr("importe")).ToString(FORMATO_MONEDA))
                    ElseIf dr("operacion").ToString.Equals("C") Then
                        Reporte.DataDefinition.FormulaFields("detalle_debe_" & i.ToString("D2")).Text = Base.Text(CDbl(dr("importe")).ToString(FORMATO_MONEDA))
                    End If
                    i += 1
                Else
                    dblDato += CDbl(dr("monto"))
                    intMas += 1
                End If
            Next
        End If
    End Sub

    'Recupera la configuracion de posicion de los controles
    Private Sub CargarPosiciones()
        Dim strSQL As String
        Dim strCampo As String
        Dim strDato As String
        Dim cmd As MySqlCommand
        Dim obj As Object
        Dim c As Integer

        'Buscar tipo de documento para formato de cheque
        ID = Base.ObtenerIdDeDocumento(STR_CODIGO,, False)
        If ID.Equals(INT_CERO) Then
            ID = CrearTipo()
        End If

        strSQL = "SELECT e.HDoc_Doc_Ano FROM Dcmtos_HDR e WHERE e.HDoc_Sis_Emp={empresa} And e.HDoc_Doc_Cat={tipo} And e.HDoc_Doc_Num={numero}"
        strSQL = strSQL.Replace("{empresa}", Sesion.IdEmpresa)
        strSQL = strSQL.Replace("{tipo}", ID)
        strSQL = strSQL.Replace("{numero}", intCuenta)
        c = INT_CERO
        cmd = New MySqlCommand(strSQL, CON)
        obj = cmd.ExecuteScalar
        If obj IsNot Nothing Then
            c = CInt(obj)
        Else
            'Crear documento y detalle para formato de esta cuenta 
            c = CrearDocumento(ID, intCuenta)
        End If

        'Recorrer el detalle del documento para cargar posiciones
        strSQL = "SELECT d.DDoc_RF1_Cod Campo, IFNULL(d.DDoc_RF1_Txt,'0.0.0') Posicion FROM Dcmtos_DTL d WHERE d.DDoc_Sis_Emp={empresa} AND d.DDoc_Doc_Cat={tipo} AND d.DDoc_Doc_Ano={ciclo} AND d.DDoc_Doc_Num={numero} ORDER BY d.DDoc_Doc_Lin"
        strSQL = strSQL.Replace("{empresa}", Sesion.IdEmpresa)
        strSQL = strSQL.Replace("{tipo}", ID)
        strSQL = strSQL.Replace("{ciclo}", c)
        strSQL = strSQL.Replace("{numero}", intCuenta)
        cmd = New MySqlCommand(strSQL, CON)
        Using dr As MySqlDataReader = cmd.ExecuteReader
            While dr.Read()
                strCampo = dr.GetString(0)
                strDato = dr.GetString(1)
                If Campos.ContainsKey(strCampo) Then
                    Campos(strCampo) = strDato
                End If
            End While
        End Using

        'Ajustar posición de datos de encabezado
        AjustarPosicion("fecha")
        AjustarPosicion("monto")
        AjustarPosicion("nombre")
        AjustarPosicion("letras")
        AjustarPosicion("descripcion")
        AjustarPosicion("referencia")
        AjustarPosicion("numero")
        AjustarPosicion("cuenta")
        AjustarPosicion("usuario")
        AjustarPosicion("dia")
        AjustarPosicion("mes")
        AjustarPosicion("ciclo")

        'Ajustar posición de datos de pie
        AjustarPosicion("pie_nombre")
        AjustarPosicion("pie_descripcion")
        AjustarPosicion("pie_monto")

        'Ajustar posición de datos de impresion
        AjustarPosicion("impresion_fecha")
        AjustarPosicion("impresion_hora")

        'Ajustar posición de detalle
        AjustarPosicion("detalle_cuenta", MAX_DETALLE)
        AjustarPosicion("detalle_descripcion", MAX_DETALLE)
        AjustarPosicion("detalle_debe", MAX_DETALLE)
        AjustarPosicion("detalle_haber", MAX_DETALLE)
    End Sub

    'Crea el tipo de documento para formato de cheque 
    Private Function CrearTipo() As Integer
        Dim SQL As New clsQuery
        Dim cmd As MySqlCommand
        Dim strSQL As String
        Dim intID As Integer

        intID = Base.ObtenerNuevoCatalogoID

        SQL.Name = "Catalogos"
        SQL.Kind = clsQuery.Mode.Insert

        SQL.Add("cat_num", intID)
        SQL.Add("cat_clase", Base.Text("Formatos"))
        SQL.Add("cat_clave", Base.Text("Cheque"))
        SQL.Add("cat_desc", Base.Text("Formatos para impresion de cheque"))
        SQL.Add("cat_sist", Base.Text(STR_CODIGO))

        strSQL = SQL.SQLString
        cmd = New MySqlCommand(strSQL, CON)
        cmd.ExecuteNonQuery()

        Return intID
    End Function

    'Crea el documento para el formato de cheque de la cuenta actual (devuelve el año)
    Private Function CrearDocumento(ByVal Tipo As Integer, ByVal Numero As Integer) As Integer
        Dim strSQL As String
        Dim SQL As New clsQuery
        Dim cmd As MySqlCommand
        Dim c As Integer = Year(Today)
        Dim i As Integer

        SQL.Name = "Dcmtos_HDR"
        SQL.Kind = clsQuery.Mode.Insert

        SQL.Add("HDoc_Sis_Emp", Sesion.IdEmpresa)
        SQL.Add("HDoc_Doc_Cat", ID)
        SQL.Add("HDoc_Doc_Ano", c)
        SQL.Add("HDoc_Doc_Num", Numero)
        SQL.Add("HDoc_Doc_Fec", "CURRENT_DATE()")
        SQL.Add("HDoc_Emp_Cod", INT_CERO)
        SQL.Add("HDoc_Emp_Nom", Base.Text(Titulo))
        SQL.Add("HDoc_Emp_Dir", Base.Text("FORMATO"))
        SQL.Add("HDoc_Emp_Per", Base.Text(String.Empty))

        strSQL = SQL.SQLString
        cmd = New MySqlCommand(strSQL, CON)
        cmd.ExecuteNonQuery()

        'Detalle del documento
        i = INT_CERO
        For Each cmp As KeyValuePair(Of String, String) In Campos
            i += 1
            SQL = New clsQuery
            SQL.Name = "Dcmtos_DTL"
            SQL.Kind = clsQuery.Mode.Insert

            SQL.Add("DDoc_Sis_Emp", Sesion.IdEmpresa)
            SQL.Add("DDoc_Doc_Cat", Tipo)
            SQL.Add("DDoc_Doc_Ano", c)
            SQL.Add("DDoc_Doc_Num", Numero)
            SQL.Add("DDoc_Doc_Lin", i)

            SQL.Add("DDoc_RF1_Cod", Base.Text(cmp.Key))
            SQL.Add("DDoc_RF1_Txt", Base.Text(cmp.Value))

            strSQL = SQL.SQLString
            cmd = New MySqlCommand(strSQL, CON)
            cmd.ExecuteNonQuery()
        Next

        Return c
    End Function

    'Ajusta la posicion de un control dentro del reporte
    Private Sub AjustarPosicion(ByVal Nombre As String, Optional Lineas As Byte = INT_CERO)
        Dim pos As Padding
        Dim n As String
        Dim i As Integer
        Dim logMultiple As Boolean = (Lineas > INT_CERO)

        pos = PrepararPosicion(Campos(Nombre))
        If Lineas > INT_CERO Then
            Lineas -= 1
        End If
        For i = INT_CERO To Lineas
            n = Nombre
            'Nombre del control si son varias lineas
            If logMultiple Then
                n &= "_" & CInt(i + 1).ToString("D2")
            End If
            'Asignar posiciones
            With Reporte.Page.ReportObjects(n)
                .Left = pos.Left
                .Top = pos.Top
                .Width = pos.Right
                'Sumar altura para siguiente control
                pos.Top += .Height
            End With
        Next
    End Sub

    'Separa los valores y los convierte de milimetros a puntos para (X, Y & W)
    Private Function PrepararPosicion(ByVal Texto As String) As Padding
        Const DEF_POS As String = "0.0.0"
        Const S_FACTOR As Double = 56.7
        Dim pos As Padding
        Dim s() As String

        pos.Left = INT_CERO
        pos.Top = INT_CERO
        pos.Right = 1000
        If InStr(Texto, ".") > INT_CERO And Not Texto.Equals(DEF_POS) Then
            s = Texto.Split(".")
            pos.Left = CInt(CDbl(s(0)) * S_FACTOR)
            pos.Top = CInt(CDbl(s(1)) * S_FACTOR)
            pos.Right = CInt(CDbl(s(2)) * S_FACTOR)
        End If
        Return pos
    End Function

    Private Sub Visor_Load(sender As Object, e As EventArgs) Handles Visor.Load

    End Sub
End Class
