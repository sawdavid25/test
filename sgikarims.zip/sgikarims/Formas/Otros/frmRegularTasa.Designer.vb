﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmRegularTasa
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.panelLista = New System.Windows.Forms.Panel()
        Me.dgLista = New System.Windows.Forms.DataGridView()
        Me.panelFechas = New System.Windows.Forms.Panel()
        Me.botonAnio = New System.Windows.Forms.Button()
        Me.celdaAnio = New System.Windows.Forms.TextBox()
        Me.botonActualizar = New System.Windows.Forms.Button()
        Me.checkFecha = New System.Windows.Forms.CheckBox()
        Me.panelDetalle = New System.Windows.Forms.Panel()
        Me.celdaTasa = New System.Windows.Forms.TextBox()
        Me.etiquetaTasa = New System.Windows.Forms.Label()
        Me.dtFecha = New System.Windows.Forms.DateTimePicker()
        Me.BarraTitulo1 = New KARIMs_SGI.BarraTitulo()
        Me.Encabezado1 = New KARIMs_SGI.encabezado()
        Me.colAnio = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colIdMes = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colMes = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colTasa = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.panelLista.SuspendLayout()
        CType(Me.dgLista, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.panelFechas.SuspendLayout()
        Me.panelDetalle.SuspendLayout()
        Me.SuspendLayout()
        '
        'panelLista
        '
        Me.panelLista.Controls.Add(Me.dgLista)
        Me.panelLista.Controls.Add(Me.panelFechas)
        Me.panelLista.Dock = System.Windows.Forms.DockStyle.Top
        Me.panelLista.Location = New System.Drawing.Point(0, 109)
        Me.panelLista.Name = "panelLista"
        Me.panelLista.Size = New System.Drawing.Size(681, 89)
        Me.panelLista.TabIndex = 1
        '
        'dgLista
        '
        Me.dgLista.AllowUserToAddRows = False
        Me.dgLista.AllowUserToDeleteRows = False
        Me.dgLista.AllowUserToOrderColumns = True
        Me.dgLista.BackgroundColor = System.Drawing.SystemColors.Control
        Me.dgLista.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgLista.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.colAnio, Me.colIdMes, Me.colMes, Me.colTasa})
        Me.dgLista.Dock = System.Windows.Forms.DockStyle.Fill
        Me.dgLista.Location = New System.Drawing.Point(0, 44)
        Me.dgLista.MultiSelect = False
        Me.dgLista.Name = "dgLista"
        Me.dgLista.ReadOnly = True
        Me.dgLista.RowTemplate.Height = 24
        Me.dgLista.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.dgLista.Size = New System.Drawing.Size(681, 45)
        Me.dgLista.TabIndex = 0
        '
        'panelFechas
        '
        Me.panelFechas.BackColor = System.Drawing.SystemColors.Info
        Me.panelFechas.Controls.Add(Me.botonAnio)
        Me.panelFechas.Controls.Add(Me.celdaAnio)
        Me.panelFechas.Controls.Add(Me.botonActualizar)
        Me.panelFechas.Controls.Add(Me.checkFecha)
        Me.panelFechas.Dock = System.Windows.Forms.DockStyle.Top
        Me.panelFechas.Location = New System.Drawing.Point(0, 0)
        Me.panelFechas.Name = "panelFechas"
        Me.panelFechas.Size = New System.Drawing.Size(681, 44)
        Me.panelFechas.TabIndex = 2
        '
        'botonAnio
        '
        Me.botonAnio.Location = New System.Drawing.Point(340, 10)
        Me.botonAnio.Name = "botonAnio"
        Me.botonAnio.Size = New System.Drawing.Size(32, 23)
        Me.botonAnio.TabIndex = 6
        Me.botonAnio.Text = "..."
        Me.botonAnio.UseVisualStyleBackColor = True
        '
        'celdaAnio
        '
        Me.celdaAnio.Location = New System.Drawing.Point(230, 10)
        Me.celdaAnio.Name = "celdaAnio"
        Me.celdaAnio.ReadOnly = True
        Me.celdaAnio.Size = New System.Drawing.Size(100, 22)
        Me.celdaAnio.TabIndex = 5
        '
        'botonActualizar
        '
        Me.botonActualizar.Location = New System.Drawing.Point(557, 6)
        Me.botonActualizar.Name = "botonActualizar"
        Me.botonActualizar.Size = New System.Drawing.Size(82, 30)
        Me.botonActualizar.TabIndex = 4
        Me.botonActualizar.Text = "Update"
        Me.botonActualizar.UseVisualStyleBackColor = True
        '
        'checkFecha
        '
        Me.checkFecha.AutoSize = True
        Me.checkFecha.Checked = True
        Me.checkFecha.CheckState = System.Windows.Forms.CheckState.Checked
        Me.checkFecha.Location = New System.Drawing.Point(12, 12)
        Me.checkFecha.Name = "checkFecha"
        Me.checkFecha.Size = New System.Drawing.Size(213, 21)
        Me.checkFecha.TabIndex = 0
        Me.checkFecha.Text = "Show Documents of the Year"
        Me.checkFecha.UseVisualStyleBackColor = True
        '
        'panelDetalle
        '
        Me.panelDetalle.Controls.Add(Me.celdaTasa)
        Me.panelDetalle.Controls.Add(Me.etiquetaTasa)
        Me.panelDetalle.Controls.Add(Me.dtFecha)
        Me.panelDetalle.Location = New System.Drawing.Point(69, 204)
        Me.panelDetalle.Name = "panelDetalle"
        Me.panelDetalle.Size = New System.Drawing.Size(548, 213)
        Me.panelDetalle.TabIndex = 2
        '
        'celdaTasa
        '
        Me.celdaTasa.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.celdaTasa.Location = New System.Drawing.Point(263, 121)
        Me.celdaTasa.Name = "celdaTasa"
        Me.celdaTasa.Size = New System.Drawing.Size(100, 24)
        Me.celdaTasa.TabIndex = 2
        '
        'etiquetaTasa
        '
        Me.etiquetaTasa.AutoSize = True
        Me.etiquetaTasa.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.etiquetaTasa.Location = New System.Drawing.Point(158, 124)
        Me.etiquetaTasa.Name = "etiquetaTasa"
        Me.etiquetaTasa.Size = New System.Drawing.Size(85, 18)
        Me.etiquetaTasa.TabIndex = 1
        Me.etiquetaTasa.Text = "Cuerrency"
        '
        'dtFecha
        '
        Me.dtFecha.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.dtFecha.Location = New System.Drawing.Point(42, 49)
        Me.dtFecha.Name = "dtFecha"
        Me.dtFecha.Size = New System.Drawing.Size(129, 22)
        Me.dtFecha.TabIndex = 0
        '
        'BarraTitulo1
        '
        Me.BarraTitulo1.BackColor = System.Drawing.Color.WhiteSmoke
        Me.BarraTitulo1.Dock = System.Windows.Forms.DockStyle.Top
        Me.BarraTitulo1.Location = New System.Drawing.Point(0, 75)
        Me.BarraTitulo1.Margin = New System.Windows.Forms.Padding(4)
        Me.BarraTitulo1.Name = "BarraTitulo1"
        Me.BarraTitulo1.Size = New System.Drawing.Size(681, 34)
        Me.BarraTitulo1.TabIndex = 3
        '
        'Encabezado1
        '
        Me.Encabezado1.Dock = System.Windows.Forms.DockStyle.Top
        Me.Encabezado1.Location = New System.Drawing.Point(0, 0)
        Me.Encabezado1.Margin = New System.Windows.Forms.Padding(4)
        Me.Encabezado1.Name = "Encabezado1"
        Me.Encabezado1.Size = New System.Drawing.Size(681, 75)
        Me.Encabezado1.TabIndex = 0
        '
        'colAnio
        '
        Me.colAnio.HeaderText = "Year"
        Me.colAnio.Name = "colAnio"
        Me.colAnio.ReadOnly = True
        '
        'colIdMes
        '
        Me.colIdMes.HeaderText = "idMes"
        Me.colIdMes.Name = "colIdMes"
        Me.colIdMes.ReadOnly = True
        Me.colIdMes.Visible = False
        '
        'colMes
        '
        Me.colMes.HeaderText = "Month"
        Me.colMes.Name = "colMes"
        Me.colMes.ReadOnly = True
        '
        'colTasa
        '
        Me.colTasa.HeaderText = "T.C."
        Me.colTasa.Name = "colTasa"
        Me.colTasa.ReadOnly = True
        '
        'frmRegularTasa
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(681, 418)
        Me.Controls.Add(Me.panelDetalle)
        Me.Controls.Add(Me.panelLista)
        Me.Controls.Add(Me.BarraTitulo1)
        Me.Controls.Add(Me.Encabezado1)
        Me.Name = "frmRegularTasa"
        Me.Text = "Regular Tasa"
        Me.panelLista.ResumeLayout(False)
        CType(Me.dgLista, System.ComponentModel.ISupportInitialize).EndInit()
        Me.panelFechas.ResumeLayout(False)
        Me.panelFechas.PerformLayout()
        Me.panelDetalle.ResumeLayout(False)
        Me.panelDetalle.PerformLayout()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents Encabezado1 As encabezado
    Friend WithEvents panelLista As Panel
    Friend WithEvents dgLista As DataGridView
    Friend WithEvents panelDetalle As Panel
    Friend WithEvents celdaTasa As TextBox
    Friend WithEvents etiquetaTasa As Label
    Friend WithEvents dtFecha As DateTimePicker
    Friend WithEvents panelFechas As Panel
    Friend WithEvents botonAnio As Button
    Friend WithEvents celdaAnio As TextBox
    Friend WithEvents botonActualizar As Button
    Friend WithEvents checkFecha As System.Windows.Forms.CheckBox
    Friend WithEvents BarraTitulo1 As BarraTitulo
    Friend WithEvents colAnio As DataGridViewTextBoxColumn
    Friend WithEvents colIdMes As DataGridViewTextBoxColumn
    Friend WithEvents colMes As DataGridViewTextBoxColumn
    Friend WithEvents colTasa As DataGridViewTextBoxColumn
End Class
