﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class frmPedidosClient_proforma_
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmPedidosClient_proforma_))
        Dim DataGridViewCellStyle3 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle4 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Me.dgLista = New System.Windows.Forms.DataGridView()
        Me.colNumero = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colFechaLista = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colClienteLista = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colReferenciaLista = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colDireccionLista = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colAñoLista = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colRevisado = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.etiquetaYFecha = New System.Windows.Forms.Label()
        Me.dtpFinal = New System.Windows.Forms.DateTimePicker()
        Me.dtpInicio = New System.Windows.Forms.DateTimePicker()
        Me.botonActualizar = New System.Windows.Forms.Button()
        Me.gbDatosPedido = New System.Windows.Forms.GroupBox()
        Me.celdaDescripcionP = New System.Windows.Forms.TextBox()
        Me.celdaProyecto = New System.Windows.Forms.TextBox()
        Me.celdaDescripcion = New System.Windows.Forms.TextBox()
        Me.celdaidflujodetalle = New System.Windows.Forms.TextBox()
        Me.celdaidTarea = New System.Windows.Forms.TextBox()
        Me.celdaidProyecto = New System.Windows.Forms.TextBox()
        Me.etiquetaAnulada = New System.Windows.Forms.Label()
        Me.celdaComentario = New System.Windows.Forms.TextBox()
        Me.celdaNumeroReq = New System.Windows.Forms.TextBox()
        Me.etiquetaNumber = New System.Windows.Forms.Label()
        Me.etiquetaImpuestos = New System.Windows.Forms.Label()
        Me.celdaImpuestos = New System.Windows.Forms.TextBox()
        Me.etiquetaRevisado = New System.Windows.Forms.Label()
        Me.celdaRevisado = New System.Windows.Forms.TextBox()
        Me.celdaDefault = New System.Windows.Forms.TextBox()
        Me.celdaUsuario = New System.Windows.Forms.TextBox()
        Me.celdaCatalogo = New System.Windows.Forms.TextBox()
        Me.celdaEmpresa = New System.Windows.Forms.TextBox()
        Me.etiquetaUsuario = New System.Windows.Forms.Label()
        Me.etiquetaCatalogo = New System.Windows.Forms.Label()
        Me.etiquetaEmpresa = New System.Windows.Forms.Label()
        Me.celdaCode = New System.Windows.Forms.TextBox()
        Me.dtpFecha1 = New System.Windows.Forms.DateTimePicker()
        Me.celdaIDMoneda = New System.Windows.Forms.TextBox()
        Me.botonMoneda = New System.Windows.Forms.Button()
        Me.celdaIDCliente = New System.Windows.Forms.TextBox()
        Me.BotonCliente = New System.Windows.Forms.Button()
        Me.botonDespachos = New System.Windows.Forms.Button()
        Me.ckeckPagaImp = New System.Windows.Forms.CheckBox()
        Me.celdaTC = New System.Windows.Forms.TextBox()
        Me.etiquetaTasa = New System.Windows.Forms.Label()
        Me.celdaNit = New System.Windows.Forms.TextBox()
        Me.etiquetaNIT = New System.Windows.Forms.Label()
        Me.checkActivo = New System.Windows.Forms.CheckBox()
        Me.celdaCliente = New System.Windows.Forms.TextBox()
        Me.celdaTelefono = New System.Windows.Forms.TextBox()
        Me.celdaMoneda = New System.Windows.Forms.TextBox()
        Me.celdaDireccion = New System.Windows.Forms.TextBox()
        Me.celdaNumero = New System.Windows.Forms.TextBox()
        Me.celdaAño = New System.Windows.Forms.TextBox()
        Me.etiquetaMoneda = New System.Windows.Forms.Label()
        Me.etiquetaTelefono = New System.Windows.Forms.Label()
        Me.etiquetaDireccion = New System.Windows.Forms.Label()
        Me.etiquetaCliente = New System.Windows.Forms.Label()
        Me.etiquetaFecha = New System.Windows.Forms.Label()
        Me.etiquetaNumero = New System.Windows.Forms.Label()
        Me.etiquetaAño = New System.Windows.Forms.Label()
        Me.gbDatosRequer = New System.Windows.Forms.GroupBox()
        Me.Contrato = New System.Windows.Forms.Label()
        Me.celdaContrato = New System.Windows.Forms.TextBox()
        Me.checkCarta = New System.Windows.Forms.CheckBox()
        Me.etiquetaDate = New System.Windows.Forms.Label()
        Me.dtpFecha = New System.Windows.Forms.DateTimePicker()
        Me.celdaIDSolicitante = New System.Windows.Forms.TextBox()
        Me.botonSolicitante = New System.Windows.Forms.Button()
        Me.celdaPhone = New System.Windows.Forms.TextBox()
        Me.etiquetaTelef = New System.Windows.Forms.Label()
        Me.celdaDirec = New System.Windows.Forms.TextBox()
        Me.etiquetaDirectio = New System.Windows.Forms.Label()
        Me.celdaSolicitante = New System.Windows.Forms.TextBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.dgContratos = New System.Windows.Forms.GroupBox()
        Me.panelContratos = New System.Windows.Forms.Panel()
        Me.botonRecargar = New System.Windows.Forms.Button()
        Me.botonEliminar = New System.Windows.Forms.Button()
        Me.botonAgregar = New System.Windows.Forms.Button()
        Me.dgContratosLista = New System.Windows.Forms.DataGridView()
        Me.colAñoContrato = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colNumeroContrato = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colFechaContrato = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colUsuarioContrato = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colReferenciaContrato = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colCat = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.dgDetalle = New System.Windows.Forms.DataGridView()
        Me.colCatalogo = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colYear = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colCodigo = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colDescripcion = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colNumMedida = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colMedida = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colPrecio = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colPrecioKG = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colDestino = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colNumDestino = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colFecha = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colCantidad = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colTotal = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colReference = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colCancelado = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colPrograma = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colDivision = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colEstilo = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colLineaDet = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colDescargos = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colFechInicio = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colFechFinal = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colFabricante = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colCodFabricante = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colAgrega = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colCodArt = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colObservacion = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.panelDetalle = New System.Windows.Forms.Panel()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.panelBotones = New System.Windows.Forms.Panel()
        Me.botonDelete = New System.Windows.Forms.Button()
        Me.botonAdd = New System.Windows.Forms.Button()
        Me.panelReferencias = New System.Windows.Forms.Panel()
        Me.dgReferencias = New System.Windows.Forms.DataGridView()
        Me.colID = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colAnio = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colContrato = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colLine = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colReferencia = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colDescargo = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.panelDetalle2 = New System.Windows.Forms.Panel()
        Me.dgDetalleDoc = New System.Windows.Forms.DataGridView()
        Me.colClave = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colDocumentos = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colDatos = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.celdaTotales2 = New System.Windows.Forms.TextBox()
        Me.celdaTotales = New System.Windows.Forms.TextBox()
        Me.etiquetaTotales = New System.Windows.Forms.Label()
        Me.dgDetalle2 = New System.Windows.Forms.DataGridView()
        Me.colLinea = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colAño = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colNDespacho = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colCantida = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colSaldoActual = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.panelDocumento = New System.Windows.Forms.Panel()
        Me.panelLista = New System.Windows.Forms.Panel()
        Me.celdaColorAmarillo = New System.Windows.Forms.TextBox()
        Me.celdaColorRojo = New System.Windows.Forms.TextBox()
        Me.etiquetaNoImpreso = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Checkfecha = New System.Windows.Forms.CheckBox()
        Me.TextBox8 = New System.Windows.Forms.TextBox()
        Me.botonImprimir = New System.Windows.Forms.Button()
        Me.botonContrato = New System.Windows.Forms.Button()
        Me.botonBuscar = New System.Windows.Forms.Button()
        Me.BotonHoras = New System.Windows.Forms.Button()
        Me.botonOrdenProduccion = New System.Windows.Forms.Button()
        Me.BarraTitulo1 = New KARIMs_SGI.BarraTitulo()
        Me.Encabezado1 = New KARIMs_SGI.encabezado()
        CType(Me.dgLista, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.gbDatosPedido.SuspendLayout()
        Me.gbDatosRequer.SuspendLayout()
        Me.dgContratos.SuspendLayout()
        Me.panelContratos.SuspendLayout()
        CType(Me.dgContratosLista, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.dgDetalle, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.panelDetalle.SuspendLayout()
        Me.Panel1.SuspendLayout()
        Me.panelBotones.SuspendLayout()
        Me.panelReferencias.SuspendLayout()
        CType(Me.dgReferencias, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.panelDetalle2.SuspendLayout()
        CType(Me.dgDetalleDoc, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.dgDetalle2, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.panelDocumento.SuspendLayout()
        Me.panelLista.SuspendLayout()
        Me.SuspendLayout()
        '
        'dgLista
        '
        Me.dgLista.AllowUserToAddRows = False
        Me.dgLista.AllowUserToDeleteRows = False
        Me.dgLista.AllowUserToOrderColumns = True
        Me.dgLista.BackgroundColor = System.Drawing.SystemColors.Control
        Me.dgLista.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgLista.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.colNumero, Me.colFechaLista, Me.colClienteLista, Me.colReferenciaLista, Me.colDireccionLista, Me.colAñoLista, Me.colRevisado})
        Me.dgLista.Dock = System.Windows.Forms.DockStyle.Fill
        Me.dgLista.Location = New System.Drawing.Point(0, 47)
        Me.dgLista.MultiSelect = False
        Me.dgLista.Name = "dgLista"
        Me.dgLista.ReadOnly = True
        Me.dgLista.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.dgLista.Size = New System.Drawing.Size(833, 53)
        Me.dgLista.TabIndex = 1
        '
        'colNumero
        '
        Me.colNumero.HeaderText = "Number"
        Me.colNumero.Name = "colNumero"
        Me.colNumero.ReadOnly = True
        '
        'colFechaLista
        '
        Me.colFechaLista.HeaderText = "Date"
        Me.colFechaLista.Name = "colFechaLista"
        Me.colFechaLista.ReadOnly = True
        '
        'colClienteLista
        '
        Me.colClienteLista.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill
        Me.colClienteLista.HeaderText = "Client"
        Me.colClienteLista.Name = "colClienteLista"
        Me.colClienteLista.ReadOnly = True
        '
        'colReferenciaLista
        '
        Me.colReferenciaLista.HeaderText = "Reference"
        Me.colReferenciaLista.Name = "colReferenciaLista"
        Me.colReferenciaLista.ReadOnly = True
        '
        'colDireccionLista
        '
        Me.colDireccionLista.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill
        Me.colDireccionLista.HeaderText = "Direction"
        Me.colDireccionLista.Name = "colDireccionLista"
        Me.colDireccionLista.ReadOnly = True
        '
        'colAñoLista
        '
        Me.colAñoLista.HeaderText = "Year"
        Me.colAñoLista.Name = "colAñoLista"
        Me.colAñoLista.ReadOnly = True
        Me.colAñoLista.Visible = False
        '
        'colRevisado
        '
        Me.colRevisado.HeaderText = "Revisado"
        Me.colRevisado.Name = "colRevisado"
        Me.colRevisado.ReadOnly = True
        Me.colRevisado.Visible = False
        '
        'etiquetaYFecha
        '
        Me.etiquetaYFecha.AutoSize = True
        Me.etiquetaYFecha.Location = New System.Drawing.Point(319, 19)
        Me.etiquetaYFecha.Name = "etiquetaYFecha"
        Me.etiquetaYFecha.Size = New System.Drawing.Size(52, 13)
        Me.etiquetaYFecha.TabIndex = 4
        Me.etiquetaYFecha.Text = "And Date"
        '
        'dtpFinal
        '
        Me.dtpFinal.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.dtpFinal.Location = New System.Drawing.Point(392, 18)
        Me.dtpFinal.Name = "dtpFinal"
        Me.dtpFinal.Size = New System.Drawing.Size(98, 20)
        Me.dtpFinal.TabIndex = 3
        '
        'dtpInicio
        '
        Me.dtpInicio.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.dtpInicio.Location = New System.Drawing.Point(203, 18)
        Me.dtpInicio.Name = "dtpInicio"
        Me.dtpInicio.Size = New System.Drawing.Size(98, 20)
        Me.dtpInicio.TabIndex = 2
        '
        'botonActualizar
        '
        Me.botonActualizar.Location = New System.Drawing.Point(512, 15)
        Me.botonActualizar.Name = "botonActualizar"
        Me.botonActualizar.Size = New System.Drawing.Size(75, 23)
        Me.botonActualizar.TabIndex = 1
        Me.botonActualizar.Text = "Update"
        Me.botonActualizar.UseVisualStyleBackColor = True
        '
        'gbDatosPedido
        '
        Me.gbDatosPedido.Controls.Add(Me.celdaDescripcionP)
        Me.gbDatosPedido.Controls.Add(Me.celdaProyecto)
        Me.gbDatosPedido.Controls.Add(Me.celdaDescripcion)
        Me.gbDatosPedido.Controls.Add(Me.celdaidflujodetalle)
        Me.gbDatosPedido.Controls.Add(Me.celdaidTarea)
        Me.gbDatosPedido.Controls.Add(Me.celdaidProyecto)
        Me.gbDatosPedido.Controls.Add(Me.etiquetaAnulada)
        Me.gbDatosPedido.Controls.Add(Me.celdaComentario)
        Me.gbDatosPedido.Controls.Add(Me.celdaNumeroReq)
        Me.gbDatosPedido.Controls.Add(Me.etiquetaNumber)
        Me.gbDatosPedido.Controls.Add(Me.etiquetaImpuestos)
        Me.gbDatosPedido.Controls.Add(Me.celdaImpuestos)
        Me.gbDatosPedido.Controls.Add(Me.etiquetaRevisado)
        Me.gbDatosPedido.Controls.Add(Me.celdaRevisado)
        Me.gbDatosPedido.Controls.Add(Me.celdaDefault)
        Me.gbDatosPedido.Controls.Add(Me.celdaUsuario)
        Me.gbDatosPedido.Controls.Add(Me.celdaCatalogo)
        Me.gbDatosPedido.Controls.Add(Me.celdaEmpresa)
        Me.gbDatosPedido.Controls.Add(Me.etiquetaUsuario)
        Me.gbDatosPedido.Controls.Add(Me.etiquetaCatalogo)
        Me.gbDatosPedido.Controls.Add(Me.etiquetaEmpresa)
        Me.gbDatosPedido.Controls.Add(Me.celdaCode)
        Me.gbDatosPedido.Controls.Add(Me.dtpFecha1)
        Me.gbDatosPedido.Controls.Add(Me.celdaIDMoneda)
        Me.gbDatosPedido.Controls.Add(Me.botonMoneda)
        Me.gbDatosPedido.Controls.Add(Me.celdaIDCliente)
        Me.gbDatosPedido.Controls.Add(Me.BotonCliente)
        Me.gbDatosPedido.Controls.Add(Me.botonDespachos)
        Me.gbDatosPedido.Controls.Add(Me.ckeckPagaImp)
        Me.gbDatosPedido.Controls.Add(Me.celdaTC)
        Me.gbDatosPedido.Controls.Add(Me.etiquetaTasa)
        Me.gbDatosPedido.Controls.Add(Me.celdaNit)
        Me.gbDatosPedido.Controls.Add(Me.etiquetaNIT)
        Me.gbDatosPedido.Controls.Add(Me.checkActivo)
        Me.gbDatosPedido.Controls.Add(Me.celdaCliente)
        Me.gbDatosPedido.Controls.Add(Me.celdaTelefono)
        Me.gbDatosPedido.Controls.Add(Me.celdaMoneda)
        Me.gbDatosPedido.Controls.Add(Me.celdaDireccion)
        Me.gbDatosPedido.Controls.Add(Me.celdaNumero)
        Me.gbDatosPedido.Controls.Add(Me.celdaAño)
        Me.gbDatosPedido.Controls.Add(Me.etiquetaMoneda)
        Me.gbDatosPedido.Controls.Add(Me.etiquetaTelefono)
        Me.gbDatosPedido.Controls.Add(Me.etiquetaDireccion)
        Me.gbDatosPedido.Controls.Add(Me.etiquetaCliente)
        Me.gbDatosPedido.Controls.Add(Me.etiquetaFecha)
        Me.gbDatosPedido.Controls.Add(Me.etiquetaNumero)
        Me.gbDatosPedido.Controls.Add(Me.etiquetaAño)
        Me.gbDatosPedido.Location = New System.Drawing.Point(12, 4)
        Me.gbDatosPedido.Name = "gbDatosPedido"
        Me.gbDatosPedido.Size = New System.Drawing.Size(428, 286)
        Me.gbDatosPedido.TabIndex = 3
        Me.gbDatosPedido.TabStop = False
        Me.gbDatosPedido.Text = "Invoice  Information"
        '
        'celdaDescripcionP
        '
        Me.celdaDescripcionP.Location = New System.Drawing.Point(310, 238)
        Me.celdaDescripcionP.Margin = New System.Windows.Forms.Padding(2)
        Me.celdaDescripcionP.Name = "celdaDescripcionP"
        Me.celdaDescripcionP.Size = New System.Drawing.Size(8, 20)
        Me.celdaDescripcionP.TabIndex = 59
        Me.celdaDescripcionP.Visible = False
        Me.celdaDescripcionP.WordWrap = False
        '
        'celdaProyecto
        '
        Me.celdaProyecto.Location = New System.Drawing.Point(298, 238)
        Me.celdaProyecto.Margin = New System.Windows.Forms.Padding(2)
        Me.celdaProyecto.Name = "celdaProyecto"
        Me.celdaProyecto.Size = New System.Drawing.Size(8, 20)
        Me.celdaProyecto.TabIndex = 58
        Me.celdaProyecto.Visible = False
        Me.celdaProyecto.WordWrap = False
        '
        'celdaDescripcion
        '
        Me.celdaDescripcion.Location = New System.Drawing.Point(286, 238)
        Me.celdaDescripcion.Margin = New System.Windows.Forms.Padding(2)
        Me.celdaDescripcion.Name = "celdaDescripcion"
        Me.celdaDescripcion.Size = New System.Drawing.Size(8, 20)
        Me.celdaDescripcion.TabIndex = 57
        Me.celdaDescripcion.Visible = False
        Me.celdaDescripcion.WordWrap = False
        '
        'celdaidflujodetalle
        '
        Me.celdaidflujodetalle.Location = New System.Drawing.Point(273, 238)
        Me.celdaidflujodetalle.Margin = New System.Windows.Forms.Padding(2)
        Me.celdaidflujodetalle.Name = "celdaidflujodetalle"
        Me.celdaidflujodetalle.Size = New System.Drawing.Size(8, 20)
        Me.celdaidflujodetalle.TabIndex = 56
        Me.celdaidflujodetalle.Text = "-1"
        Me.celdaidflujodetalle.Visible = False
        Me.celdaidflujodetalle.WordWrap = False
        '
        'celdaidTarea
        '
        Me.celdaidTarea.Location = New System.Drawing.Point(254, 238)
        Me.celdaidTarea.Margin = New System.Windows.Forms.Padding(2)
        Me.celdaidTarea.Name = "celdaidTarea"
        Me.celdaidTarea.Size = New System.Drawing.Size(8, 20)
        Me.celdaidTarea.TabIndex = 55
        Me.celdaidTarea.Text = "-1"
        Me.celdaidTarea.Visible = False
        Me.celdaidTarea.WordWrap = False
        '
        'celdaidProyecto
        '
        Me.celdaidProyecto.Location = New System.Drawing.Point(228, 261)
        Me.celdaidProyecto.Margin = New System.Windows.Forms.Padding(2)
        Me.celdaidProyecto.Name = "celdaidProyecto"
        Me.celdaidProyecto.ReadOnly = True
        Me.celdaidProyecto.Size = New System.Drawing.Size(35, 20)
        Me.celdaidProyecto.TabIndex = 54
        Me.celdaidProyecto.Text = "-1"
        Me.celdaidProyecto.Visible = False
        '
        'etiquetaAnulada
        '
        Me.etiquetaAnulada.AutoSize = True
        Me.etiquetaAnulada.BackColor = System.Drawing.Color.Red
        Me.etiquetaAnulada.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.etiquetaAnulada.Location = New System.Drawing.Point(160, 21)
        Me.etiquetaAnulada.Name = "etiquetaAnulada"
        Me.etiquetaAnulada.Size = New System.Drawing.Size(91, 24)
        Me.etiquetaAnulada.TabIndex = 45
        Me.etiquetaAnulada.Text = "Canceled"
        Me.etiquetaAnulada.Visible = False
        '
        'celdaComentario
        '
        Me.celdaComentario.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.celdaComentario.Location = New System.Drawing.Point(392, 193)
        Me.celdaComentario.Margin = New System.Windows.Forms.Padding(2)
        Me.celdaComentario.Name = "celdaComentario"
        Me.celdaComentario.Size = New System.Drawing.Size(27, 20)
        Me.celdaComentario.TabIndex = 44
        Me.celdaComentario.Visible = False
        '
        'celdaNumeroReq
        '
        Me.celdaNumeroReq.Location = New System.Drawing.Point(250, 50)
        Me.celdaNumeroReq.Name = "celdaNumeroReq"
        Me.celdaNumeroReq.Size = New System.Drawing.Size(175, 20)
        Me.celdaNumeroReq.TabIndex = 43
        '
        'etiquetaNumber
        '
        Me.etiquetaNumber.AutoSize = True
        Me.etiquetaNumber.Location = New System.Drawing.Point(187, 53)
        Me.etiquetaNumber.Name = "etiquetaNumber"
        Me.etiquetaNumber.Size = New System.Drawing.Size(62, 13)
        Me.etiquetaNumber.TabIndex = 42
        Me.etiquetaNumber.Text = "PO Number"
        '
        'etiquetaImpuestos
        '
        Me.etiquetaImpuestos.AutoSize = True
        Me.etiquetaImpuestos.Location = New System.Drawing.Point(149, 245)
        Me.etiquetaImpuestos.Name = "etiquetaImpuestos"
        Me.etiquetaImpuestos.Size = New System.Drawing.Size(55, 13)
        Me.etiquetaImpuestos.TabIndex = 41
        Me.etiquetaImpuestos.Text = "Impuestos"
        Me.etiquetaImpuestos.Visible = False
        '
        'celdaImpuestos
        '
        Me.celdaImpuestos.Location = New System.Drawing.Point(31, 263)
        Me.celdaImpuestos.Name = "celdaImpuestos"
        Me.celdaImpuestos.Size = New System.Drawing.Size(27, 20)
        Me.celdaImpuestos.TabIndex = 40
        Me.celdaImpuestos.Text = "-1"
        Me.celdaImpuestos.Visible = False
        '
        'etiquetaRevisado
        '
        Me.etiquetaRevisado.AutoSize = True
        Me.etiquetaRevisado.Location = New System.Drawing.Point(388, 238)
        Me.etiquetaRevisado.Name = "etiquetaRevisado"
        Me.etiquetaRevisado.Size = New System.Drawing.Size(52, 13)
        Me.etiquetaRevisado.TabIndex = 39
        Me.etiquetaRevisado.Text = "Revisado"
        Me.etiquetaRevisado.Visible = False
        '
        'celdaRevisado
        '
        Me.celdaRevisado.Location = New System.Drawing.Point(392, 254)
        Me.celdaRevisado.Name = "celdaRevisado"
        Me.celdaRevisado.Size = New System.Drawing.Size(27, 20)
        Me.celdaRevisado.TabIndex = 38
        Me.celdaRevisado.Text = "0"
        Me.celdaRevisado.Visible = False
        '
        'celdaDefault
        '
        Me.celdaDefault.Location = New System.Drawing.Point(130, 268)
        Me.celdaDefault.Name = "celdaDefault"
        Me.celdaDefault.Size = New System.Drawing.Size(71, 20)
        Me.celdaDefault.TabIndex = 37
        Me.celdaDefault.Text = resources.GetString("celdaDefault.Text")
        Me.celdaDefault.Visible = False
        '
        'celdaUsuario
        '
        Me.celdaUsuario.Location = New System.Drawing.Point(222, 223)
        Me.celdaUsuario.Name = "celdaUsuario"
        Me.celdaUsuario.Size = New System.Drawing.Size(27, 20)
        Me.celdaUsuario.TabIndex = 36
        Me.celdaUsuario.Text = "-1"
        Me.celdaUsuario.Visible = False
        '
        'celdaCatalogo
        '
        Me.celdaCatalogo.Location = New System.Drawing.Point(94, 238)
        Me.celdaCatalogo.Name = "celdaCatalogo"
        Me.celdaCatalogo.Size = New System.Drawing.Size(27, 20)
        Me.celdaCatalogo.TabIndex = 35
        Me.celdaCatalogo.Text = "-1"
        Me.celdaCatalogo.Visible = False
        '
        'celdaEmpresa
        '
        Me.celdaEmpresa.Location = New System.Drawing.Point(62, 225)
        Me.celdaEmpresa.Name = "celdaEmpresa"
        Me.celdaEmpresa.Size = New System.Drawing.Size(27, 20)
        Me.celdaEmpresa.TabIndex = 34
        Me.celdaEmpresa.Text = "-1"
        Me.celdaEmpresa.Visible = False
        '
        'etiquetaUsuario
        '
        Me.etiquetaUsuario.AutoSize = True
        Me.etiquetaUsuario.Location = New System.Drawing.Point(178, 225)
        Me.etiquetaUsuario.Name = "etiquetaUsuario"
        Me.etiquetaUsuario.Size = New System.Drawing.Size(43, 13)
        Me.etiquetaUsuario.TabIndex = 33
        Me.etiquetaUsuario.Text = "Usuario"
        Me.etiquetaUsuario.Visible = False
        '
        'etiquetaCatalogo
        '
        Me.etiquetaCatalogo.AutoSize = True
        Me.etiquetaCatalogo.Location = New System.Drawing.Point(5, 245)
        Me.etiquetaCatalogo.Name = "etiquetaCatalogo"
        Me.etiquetaCatalogo.Size = New System.Drawing.Size(49, 13)
        Me.etiquetaCatalogo.TabIndex = 32
        Me.etiquetaCatalogo.Text = "Catalogo"
        Me.etiquetaCatalogo.Visible = False
        '
        'etiquetaEmpresa
        '
        Me.etiquetaEmpresa.AutoSize = True
        Me.etiquetaEmpresa.Location = New System.Drawing.Point(5, 225)
        Me.etiquetaEmpresa.Name = "etiquetaEmpresa"
        Me.etiquetaEmpresa.Size = New System.Drawing.Size(48, 13)
        Me.etiquetaEmpresa.TabIndex = 31
        Me.etiquetaEmpresa.Text = "Empresa"
        Me.etiquetaEmpresa.Visible = False
        '
        'celdaCode
        '
        Me.celdaCode.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.celdaCode.Location = New System.Drawing.Point(397, 15)
        Me.celdaCode.Margin = New System.Windows.Forms.Padding(2)
        Me.celdaCode.Name = "celdaCode"
        Me.celdaCode.Size = New System.Drawing.Size(27, 20)
        Me.celdaCode.TabIndex = 30
        Me.celdaCode.Visible = False
        '
        'dtpFecha1
        '
        Me.dtpFecha1.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.dtpFecha1.Location = New System.Drawing.Point(62, 68)
        Me.dtpFecha1.Name = "dtpFecha1"
        Me.dtpFecha1.Size = New System.Drawing.Size(98, 20)
        Me.dtpFecha1.TabIndex = 29
        '
        'celdaIDMoneda
        '
        Me.celdaIDMoneda.Location = New System.Drawing.Point(173, 195)
        Me.celdaIDMoneda.Name = "celdaIDMoneda"
        Me.celdaIDMoneda.Size = New System.Drawing.Size(27, 20)
        Me.celdaIDMoneda.TabIndex = 25
        Me.celdaIDMoneda.Text = "-1"
        Me.celdaIDMoneda.Visible = False
        '
        'botonMoneda
        '
        Me.botonMoneda.Location = New System.Drawing.Point(138, 193)
        Me.botonMoneda.Name = "botonMoneda"
        Me.botonMoneda.Size = New System.Drawing.Size(30, 23)
        Me.botonMoneda.TabIndex = 24
        Me.botonMoneda.Text = "..."
        Me.botonMoneda.UseVisualStyleBackColor = True
        '
        'celdaIDCliente
        '
        Me.celdaIDCliente.Location = New System.Drawing.Point(355, 71)
        Me.celdaIDCliente.Name = "celdaIDCliente"
        Me.celdaIDCliente.Size = New System.Drawing.Size(27, 20)
        Me.celdaIDCliente.TabIndex = 23
        Me.celdaIDCliente.Text = "-1"
        Me.celdaIDCliente.Visible = False
        '
        'BotonCliente
        '
        Me.BotonCliente.Location = New System.Drawing.Point(355, 92)
        Me.BotonCliente.Name = "BotonCliente"
        Me.BotonCliente.Size = New System.Drawing.Size(30, 23)
        Me.BotonCliente.TabIndex = 22
        Me.BotonCliente.Text = "..."
        Me.BotonCliente.UseVisualStyleBackColor = True
        '
        'botonDespachos
        '
        Me.botonDespachos.Image = CType(resources.GetObject("botonDespachos.Image"), System.Drawing.Image)
        Me.botonDespachos.Location = New System.Drawing.Point(341, 199)
        Me.botonDespachos.Name = "botonDespachos"
        Me.botonDespachos.Size = New System.Drawing.Size(40, 27)
        Me.botonDespachos.TabIndex = 21
        Me.botonDespachos.Text = "Reviewed"
        Me.botonDespachos.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.botonDespachos.UseVisualStyleBackColor = True
        Me.botonDespachos.Visible = False
        '
        'ckeckPagaImp
        '
        Me.ckeckPagaImp.AutoSize = True
        Me.ckeckPagaImp.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ckeckPagaImp.Location = New System.Drawing.Point(62, 254)
        Me.ckeckPagaImp.Name = "ckeckPagaImp"
        Me.ckeckPagaImp.Size = New System.Drawing.Size(94, 17)
        Me.ckeckPagaImp.TabIndex = 20
        Me.ckeckPagaImp.Text = "PAY TAXES"
        Me.ckeckPagaImp.UseVisualStyleBackColor = True
        '
        'celdaTC
        '
        Me.celdaTC.Location = New System.Drawing.Point(257, 199)
        Me.celdaTC.Name = "celdaTC"
        Me.celdaTC.Size = New System.Drawing.Size(71, 20)
        Me.celdaTC.TabIndex = 19
        '
        'etiquetaTasa
        '
        Me.etiquetaTasa.AutoSize = True
        Me.etiquetaTasa.Location = New System.Drawing.Point(227, 202)
        Me.etiquetaTasa.Name = "etiquetaTasa"
        Me.etiquetaTasa.Size = New System.Drawing.Size(30, 13)
        Me.etiquetaTasa.TabIndex = 18
        Me.etiquetaTasa.Text = "Rate"
        '
        'celdaNit
        '
        Me.celdaNit.Enabled = False
        Me.celdaNit.Location = New System.Drawing.Point(256, 171)
        Me.celdaNit.Name = "celdaNit"
        Me.celdaNit.Size = New System.Drawing.Size(129, 20)
        Me.celdaNit.TabIndex = 17
        '
        'etiquetaNIT
        '
        Me.etiquetaNIT.AutoSize = True
        Me.etiquetaNIT.Location = New System.Drawing.Point(226, 174)
        Me.etiquetaNIT.Name = "etiquetaNIT"
        Me.etiquetaNIT.Size = New System.Drawing.Size(25, 13)
        Me.etiquetaNIT.TabIndex = 16
        Me.etiquetaNIT.Text = "NIT"
        '
        'checkActivo
        '
        Me.checkActivo.AutoSize = True
        Me.checkActivo.Checked = True
        Me.checkActivo.CheckState = System.Windows.Forms.CheckState.Checked
        Me.checkActivo.Location = New System.Drawing.Point(282, 27)
        Me.checkActivo.Name = "checkActivo"
        Me.checkActivo.Size = New System.Drawing.Size(56, 17)
        Me.checkActivo.TabIndex = 15
        Me.checkActivo.Text = "Active"
        Me.checkActivo.UseVisualStyleBackColor = True
        '
        'celdaCliente
        '
        Me.celdaCliente.Enabled = False
        Me.celdaCliente.Location = New System.Drawing.Point(62, 94)
        Me.celdaCliente.Name = "celdaCliente"
        Me.celdaCliente.Size = New System.Drawing.Size(287, 20)
        Me.celdaCliente.TabIndex = 14
        '
        'celdaTelefono
        '
        Me.celdaTelefono.Enabled = False
        Me.celdaTelefono.Location = New System.Drawing.Point(90, 169)
        Me.celdaTelefono.Name = "celdaTelefono"
        Me.celdaTelefono.Size = New System.Drawing.Size(104, 20)
        Me.celdaTelefono.TabIndex = 13
        '
        'celdaMoneda
        '
        Me.celdaMoneda.Location = New System.Drawing.Point(61, 195)
        Me.celdaMoneda.Name = "celdaMoneda"
        Me.celdaMoneda.Size = New System.Drawing.Size(71, 20)
        Me.celdaMoneda.TabIndex = 12
        '
        'celdaDireccion
        '
        Me.celdaDireccion.Enabled = False
        Me.celdaDireccion.Location = New System.Drawing.Point(62, 116)
        Me.celdaDireccion.Multiline = True
        Me.celdaDireccion.Name = "celdaDireccion"
        Me.celdaDireccion.Size = New System.Drawing.Size(323, 44)
        Me.celdaDireccion.TabIndex = 10
        '
        'celdaNumero
        '
        Me.celdaNumero.Enabled = False
        Me.celdaNumero.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.celdaNumero.ForeColor = System.Drawing.Color.SteelBlue
        Me.celdaNumero.Location = New System.Drawing.Point(62, 46)
        Me.celdaNumero.Name = "celdaNumero"
        Me.celdaNumero.Size = New System.Drawing.Size(71, 20)
        Me.celdaNumero.TabIndex = 9
        '
        'celdaAño
        '
        Me.celdaAño.Enabled = False
        Me.celdaAño.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.celdaAño.ForeColor = System.Drawing.Color.SteelBlue
        Me.celdaAño.Location = New System.Drawing.Point(62, 24)
        Me.celdaAño.Name = "celdaAño"
        Me.celdaAño.Size = New System.Drawing.Size(71, 20)
        Me.celdaAño.TabIndex = 8
        Me.celdaAño.Text = "2016"
        '
        'etiquetaMoneda
        '
        Me.etiquetaMoneda.AutoSize = True
        Me.etiquetaMoneda.Location = New System.Drawing.Point(6, 195)
        Me.etiquetaMoneda.Name = "etiquetaMoneda"
        Me.etiquetaMoneda.Size = New System.Drawing.Size(49, 13)
        Me.etiquetaMoneda.TabIndex = 7
        Me.etiquetaMoneda.Text = "Currency"
        '
        'etiquetaTelefono
        '
        Me.etiquetaTelefono.AutoSize = True
        Me.etiquetaTelefono.Location = New System.Drawing.Point(6, 174)
        Me.etiquetaTelefono.Name = "etiquetaTelefono"
        Me.etiquetaTelefono.Size = New System.Drawing.Size(78, 13)
        Me.etiquetaTelefono.TabIndex = 6
        Me.etiquetaTelefono.Text = "Phone Number"
        '
        'etiquetaDireccion
        '
        Me.etiquetaDireccion.AutoSize = True
        Me.etiquetaDireccion.Location = New System.Drawing.Point(6, 119)
        Me.etiquetaDireccion.Name = "etiquetaDireccion"
        Me.etiquetaDireccion.Size = New System.Drawing.Size(45, 13)
        Me.etiquetaDireccion.TabIndex = 4
        Me.etiquetaDireccion.Text = "Address"
        '
        'etiquetaCliente
        '
        Me.etiquetaCliente.AutoSize = True
        Me.etiquetaCliente.Location = New System.Drawing.Point(6, 97)
        Me.etiquetaCliente.Name = "etiquetaCliente"
        Me.etiquetaCliente.Size = New System.Drawing.Size(51, 13)
        Me.etiquetaCliente.TabIndex = 3
        Me.etiquetaCliente.Text = "Customer"
        '
        'etiquetaFecha
        '
        Me.etiquetaFecha.AutoSize = True
        Me.etiquetaFecha.Location = New System.Drawing.Point(6, 71)
        Me.etiquetaFecha.Name = "etiquetaFecha"
        Me.etiquetaFecha.Size = New System.Drawing.Size(30, 13)
        Me.etiquetaFecha.TabIndex = 2
        Me.etiquetaFecha.Text = "Date"
        '
        'etiquetaNumero
        '
        Me.etiquetaNumero.AutoSize = True
        Me.etiquetaNumero.Location = New System.Drawing.Point(6, 49)
        Me.etiquetaNumero.Name = "etiquetaNumero"
        Me.etiquetaNumero.Size = New System.Drawing.Size(44, 13)
        Me.etiquetaNumero.TabIndex = 1
        Me.etiquetaNumero.Text = "Number"
        '
        'etiquetaAño
        '
        Me.etiquetaAño.AutoSize = True
        Me.etiquetaAño.Location = New System.Drawing.Point(6, 27)
        Me.etiquetaAño.Name = "etiquetaAño"
        Me.etiquetaAño.Size = New System.Drawing.Size(29, 13)
        Me.etiquetaAño.TabIndex = 0
        Me.etiquetaAño.Text = "Year"
        '
        'gbDatosRequer
        '
        Me.gbDatosRequer.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.gbDatosRequer.Controls.Add(Me.Contrato)
        Me.gbDatosRequer.Controls.Add(Me.celdaContrato)
        Me.gbDatosRequer.Controls.Add(Me.checkCarta)
        Me.gbDatosRequer.Controls.Add(Me.etiquetaDate)
        Me.gbDatosRequer.Controls.Add(Me.dtpFecha)
        Me.gbDatosRequer.Controls.Add(Me.celdaIDSolicitante)
        Me.gbDatosRequer.Controls.Add(Me.botonSolicitante)
        Me.gbDatosRequer.Controls.Add(Me.celdaPhone)
        Me.gbDatosRequer.Controls.Add(Me.etiquetaTelef)
        Me.gbDatosRequer.Controls.Add(Me.celdaDirec)
        Me.gbDatosRequer.Controls.Add(Me.etiquetaDirectio)
        Me.gbDatosRequer.Controls.Add(Me.celdaSolicitante)
        Me.gbDatosRequer.Controls.Add(Me.Label1)
        Me.gbDatosRequer.Location = New System.Drawing.Point(446, 7)
        Me.gbDatosRequer.Name = "gbDatosRequer"
        Me.gbDatosRequer.Size = New System.Drawing.Size(597, 184)
        Me.gbDatosRequer.TabIndex = 4
        Me.gbDatosRequer.TabStop = False
        Me.gbDatosRequer.Text = "Pyment Information"
        '
        'Contrato
        '
        Me.Contrato.AutoSize = True
        Me.Contrato.Location = New System.Drawing.Point(218, 18)
        Me.Contrato.Name = "Contrato"
        Me.Contrato.Size = New System.Drawing.Size(47, 13)
        Me.Contrato.TabIndex = 32
        Me.Contrato.Text = "Contrato"
        Me.Contrato.Visible = False
        '
        'celdaContrato
        '
        Me.celdaContrato.Location = New System.Drawing.Point(267, 16)
        Me.celdaContrato.Name = "celdaContrato"
        Me.celdaContrato.Size = New System.Drawing.Size(74, 20)
        Me.celdaContrato.TabIndex = 31
        Me.celdaContrato.Text = "-1"
        '
        'checkCarta
        '
        Me.checkCarta.AutoSize = True
        Me.checkCarta.Location = New System.Drawing.Point(9, 24)
        Me.checkCarta.Margin = New System.Windows.Forms.Padding(2)
        Me.checkCarta.Name = "checkCarta"
        Me.checkCarta.Size = New System.Drawing.Size(98, 17)
        Me.checkCarta.TabIndex = 30
        Me.checkCarta.Text = "Letter  of Credit"
        Me.checkCarta.UseVisualStyleBackColor = True
        '
        'etiquetaDate
        '
        Me.etiquetaDate.AutoSize = True
        Me.etiquetaDate.Location = New System.Drawing.Point(230, 47)
        Me.etiquetaDate.Name = "etiquetaDate"
        Me.etiquetaDate.Size = New System.Drawing.Size(30, 13)
        Me.etiquetaDate.TabIndex = 29
        Me.etiquetaDate.Text = "Date"
        '
        'dtpFecha
        '
        Me.dtpFecha.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.dtpFecha.Location = New System.Drawing.Point(264, 41)
        Me.dtpFecha.Name = "dtpFecha"
        Me.dtpFecha.Size = New System.Drawing.Size(101, 20)
        Me.dtpFecha.TabIndex = 28
        '
        'celdaIDSolicitante
        '
        Me.celdaIDSolicitante.Location = New System.Drawing.Point(338, 68)
        Me.celdaIDSolicitante.Name = "celdaIDSolicitante"
        Me.celdaIDSolicitante.Size = New System.Drawing.Size(27, 20)
        Me.celdaIDSolicitante.TabIndex = 25
        Me.celdaIDSolicitante.Text = "-1"
        Me.celdaIDSolicitante.Visible = False
        '
        'botonSolicitante
        '
        Me.botonSolicitante.Location = New System.Drawing.Point(367, 66)
        Me.botonSolicitante.Name = "botonSolicitante"
        Me.botonSolicitante.Size = New System.Drawing.Size(30, 23)
        Me.botonSolicitante.TabIndex = 24
        Me.botonSolicitante.Text = "..."
        Me.botonSolicitante.UseVisualStyleBackColor = True
        '
        'celdaPhone
        '
        Me.celdaPhone.Enabled = False
        Me.celdaPhone.Location = New System.Drawing.Point(90, 147)
        Me.celdaPhone.Name = "celdaPhone"
        Me.celdaPhone.Size = New System.Drawing.Size(138, 20)
        Me.celdaPhone.TabIndex = 20
        '
        'etiquetaTelef
        '
        Me.etiquetaTelef.AutoSize = True
        Me.etiquetaTelef.Location = New System.Drawing.Point(6, 147)
        Me.etiquetaTelef.Name = "etiquetaTelef"
        Me.etiquetaTelef.Size = New System.Drawing.Size(78, 13)
        Me.etiquetaTelef.TabIndex = 19
        Me.etiquetaTelef.Text = "Phone Number"
        '
        'celdaDirec
        '
        Me.celdaDirec.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.celdaDirec.Enabled = False
        Me.celdaDirec.Location = New System.Drawing.Point(69, 91)
        Me.celdaDirec.Multiline = True
        Me.celdaDirec.Name = "celdaDirec"
        Me.celdaDirec.Size = New System.Drawing.Size(522, 41)
        Me.celdaDirec.TabIndex = 16
        '
        'etiquetaDirectio
        '
        Me.etiquetaDirectio.AutoSize = True
        Me.etiquetaDirectio.Location = New System.Drawing.Point(6, 94)
        Me.etiquetaDirectio.Name = "etiquetaDirectio"
        Me.etiquetaDirectio.Size = New System.Drawing.Size(45, 13)
        Me.etiquetaDirectio.TabIndex = 15
        Me.etiquetaDirectio.Text = "Address"
        '
        'celdaSolicitante
        '
        Me.celdaSolicitante.Enabled = False
        Me.celdaSolicitante.Location = New System.Drawing.Point(69, 67)
        Me.celdaSolicitante.Name = "celdaSolicitante"
        Me.celdaSolicitante.Size = New System.Drawing.Size(293, 20)
        Me.celdaSolicitante.TabIndex = 14
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(6, 71)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(51, 13)
        Me.Label1.TabIndex = 13
        Me.Label1.Text = "Customer"
        '
        'dgContratos
        '
        Me.dgContratos.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.dgContratos.Controls.Add(Me.panelContratos)
        Me.dgContratos.Controls.Add(Me.dgContratosLista)
        Me.dgContratos.Location = New System.Drawing.Point(446, 197)
        Me.dgContratos.Name = "dgContratos"
        Me.dgContratos.Size = New System.Drawing.Size(604, 100)
        Me.dgContratos.TabIndex = 5
        Me.dgContratos.TabStop = False
        Me.dgContratos.Text = "Contracts  (PM)"
        '
        'panelContratos
        '
        Me.panelContratos.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.panelContratos.Controls.Add(Me.botonRecargar)
        Me.panelContratos.Controls.Add(Me.botonEliminar)
        Me.panelContratos.Controls.Add(Me.botonAgregar)
        Me.panelContratos.Location = New System.Drawing.Point(552, 8)
        Me.panelContratos.Name = "panelContratos"
        Me.panelContratos.Size = New System.Drawing.Size(50, 85)
        Me.panelContratos.TabIndex = 1
        '
        'botonRecargar
        '
        Me.botonRecargar.Enabled = False
        Me.botonRecargar.Image = CType(resources.GetObject("botonRecargar.Image"), System.Drawing.Image)
        Me.botonRecargar.Location = New System.Drawing.Point(4, 58)
        Me.botonRecargar.Name = "botonRecargar"
        Me.botonRecargar.Size = New System.Drawing.Size(30, 23)
        Me.botonRecargar.TabIndex = 2
        Me.botonRecargar.UseVisualStyleBackColor = True
        '
        'botonEliminar
        '
        Me.botonEliminar.Enabled = False
        Me.botonEliminar.Image = CType(resources.GetObject("botonEliminar.Image"), System.Drawing.Image)
        Me.botonEliminar.Location = New System.Drawing.Point(4, 32)
        Me.botonEliminar.Name = "botonEliminar"
        Me.botonEliminar.Size = New System.Drawing.Size(30, 23)
        Me.botonEliminar.TabIndex = 1
        Me.botonEliminar.UseVisualStyleBackColor = True
        '
        'botonAgregar
        '
        Me.botonAgregar.Enabled = False
        Me.botonAgregar.Image = CType(resources.GetObject("botonAgregar.Image"), System.Drawing.Image)
        Me.botonAgregar.Location = New System.Drawing.Point(4, 7)
        Me.botonAgregar.Name = "botonAgregar"
        Me.botonAgregar.Size = New System.Drawing.Size(30, 23)
        Me.botonAgregar.TabIndex = 0
        Me.botonAgregar.UseVisualStyleBackColor = True
        '
        'dgContratosLista
        '
        Me.dgContratosLista.AllowUserToAddRows = False
        Me.dgContratosLista.AllowUserToDeleteRows = False
        Me.dgContratosLista.AllowUserToOrderColumns = True
        Me.dgContratosLista.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.dgContratosLista.BackgroundColor = System.Drawing.SystemColors.Control
        Me.dgContratosLista.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgContratosLista.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.colAñoContrato, Me.colNumeroContrato, Me.colFechaContrato, Me.colUsuarioContrato, Me.colReferenciaContrato, Me.colCat})
        Me.dgContratosLista.Location = New System.Drawing.Point(2, 15)
        Me.dgContratosLista.MultiSelect = False
        Me.dgContratosLista.Name = "dgContratosLista"
        Me.dgContratosLista.ReadOnly = True
        Me.dgContratosLista.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.dgContratosLista.Size = New System.Drawing.Size(543, 81)
        Me.dgContratosLista.TabIndex = 0
        '
        'colAñoContrato
        '
        Me.colAñoContrato.HeaderText = "Year"
        Me.colAñoContrato.Name = "colAñoContrato"
        Me.colAñoContrato.ReadOnly = True
        '
        'colNumeroContrato
        '
        Me.colNumeroContrato.HeaderText = "No."
        Me.colNumeroContrato.Name = "colNumeroContrato"
        Me.colNumeroContrato.ReadOnly = True
        '
        'colFechaContrato
        '
        Me.colFechaContrato.HeaderText = "Date"
        Me.colFechaContrato.Name = "colFechaContrato"
        Me.colFechaContrato.ReadOnly = True
        '
        'colUsuarioContrato
        '
        Me.colUsuarioContrato.HeaderText = "User"
        Me.colUsuarioContrato.Name = "colUsuarioContrato"
        Me.colUsuarioContrato.ReadOnly = True
        '
        'colReferenciaContrato
        '
        Me.colReferenciaContrato.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill
        Me.colReferenciaContrato.HeaderText = "Reference"
        Me.colReferenciaContrato.Name = "colReferenciaContrato"
        Me.colReferenciaContrato.ReadOnly = True
        '
        'colCat
        '
        Me.colCat.HeaderText = "NumeroCat"
        Me.colCat.Name = "colCat"
        Me.colCat.ReadOnly = True
        Me.colCat.Visible = False
        '
        'dgDetalle
        '
        Me.dgDetalle.AllowUserToAddRows = False
        Me.dgDetalle.AllowUserToDeleteRows = False
        Me.dgDetalle.AllowUserToOrderColumns = True
        Me.dgDetalle.BackgroundColor = System.Drawing.SystemColors.Control
        Me.dgDetalle.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgDetalle.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.colCatalogo, Me.colYear, Me.colCodigo, Me.colDescripcion, Me.colNumMedida, Me.colMedida, Me.colPrecio, Me.colPrecioKG, Me.colDestino, Me.colNumDestino, Me.colFecha, Me.colCantidad, Me.colTotal, Me.colReference, Me.colCancelado, Me.colPrograma, Me.colDivision, Me.colEstilo, Me.colLineaDet, Me.colDescargos, Me.colFechInicio, Me.colFechFinal, Me.colFabricante, Me.colCodFabricante, Me.colAgrega, Me.colCodArt, Me.colObservacion})
        Me.dgDetalle.Dock = System.Windows.Forms.DockStyle.Fill
        Me.dgDetalle.Location = New System.Drawing.Point(0, 0)
        Me.dgDetalle.Name = "dgDetalle"
        Me.dgDetalle.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.dgDetalle.Size = New System.Drawing.Size(986, 136)
        Me.dgDetalle.TabIndex = 6
        '
        'colCatalogo
        '
        Me.colCatalogo.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.colCatalogo.HeaderText = "Catalogo"
        Me.colCatalogo.Name = "colCatalogo"
        Me.colCatalogo.Visible = False
        Me.colCatalogo.Width = 74
        '
        'colYear
        '
        Me.colYear.HeaderText = "Año"
        Me.colYear.Name = "colYear"
        Me.colYear.Visible = False
        '
        'colCodigo
        '
        Me.colCodigo.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.colCodigo.HeaderText = "Code*"
        Me.colCodigo.Name = "colCodigo"
        Me.colCodigo.ReadOnly = True
        Me.colCodigo.Width = 61
        '
        'colDescripcion
        '
        Me.colDescripcion.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.colDescripcion.HeaderText = "Description"
        Me.colDescripcion.Name = "colDescripcion"
        Me.colDescripcion.ReadOnly = True
        Me.colDescripcion.Width = 85
        '
        'colNumMedida
        '
        Me.colNumMedida.HeaderText = "NumMedida"
        Me.colNumMedida.Name = "colNumMedida"
        Me.colNumMedida.Visible = False
        '
        'colMedida
        '
        Me.colMedida.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.colMedida.HeaderText = "Measure"
        Me.colMedida.Name = "colMedida"
        Me.colMedida.ReadOnly = True
        Me.colMedida.Width = 73
        '
        'colPrecio
        '
        Me.colPrecio.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.colPrecio.HeaderText = "Price"
        Me.colPrecio.Name = "colPrecio"
        Me.colPrecio.Width = 56
        '
        'colPrecioKG
        '
        Me.colPrecioKG.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        DataGridViewCellStyle3.SelectionBackColor = System.Drawing.SystemColors.Info
        DataGridViewCellStyle3.SelectionForeColor = System.Drawing.Color.Black
        Me.colPrecioKG.DefaultCellStyle = DataGridViewCellStyle3
        Me.colPrecioKG.HeaderText = "KG Price"
        Me.colPrecioKG.Name = "colPrecioKG"
        Me.colPrecioKG.Width = 74
        '
        'colDestino
        '
        Me.colDestino.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.colDestino.HeaderText = "Destination*"
        Me.colDestino.Name = "colDestino"
        Me.colDestino.ReadOnly = True
        Me.colDestino.Width = 89
        '
        'colNumDestino
        '
        Me.colNumDestino.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.colNumDestino.HeaderText = "NumDestino"
        Me.colNumDestino.Name = "colNumDestino"
        Me.colNumDestino.Visible = False
        Me.colNumDestino.Width = 90
        '
        'colFecha
        '
        Me.colFecha.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.colFecha.HeaderText = "Date"
        Me.colFecha.Name = "colFecha"
        Me.colFecha.Visible = False
        Me.colFecha.Width = 55
        '
        'colCantidad
        '
        Me.colCantidad.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.colCantidad.HeaderText = "Quantity"
        Me.colCantidad.Name = "colCantidad"
        Me.colCantidad.Width = 71
        '
        'colTotal
        '
        Me.colTotal.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.colTotal.HeaderText = "Total"
        Me.colTotal.Name = "colTotal"
        Me.colTotal.ReadOnly = True
        Me.colTotal.Width = 56
        '
        'colReference
        '
        Me.colReference.HeaderText = "Referencia"
        Me.colReference.Name = "colReference"
        Me.colReference.Visible = False
        '
        'colCancelado
        '
        Me.colCancelado.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.colCancelado.HeaderText = "Canceled*"
        Me.colCancelado.Name = "colCancelado"
        Me.colCancelado.ReadOnly = True
        Me.colCancelado.Width = 81
        '
        'colPrograma
        '
        Me.colPrograma.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.colPrograma.HeaderText = "Program*"
        Me.colPrograma.Name = "colPrograma"
        Me.colPrograma.ReadOnly = True
        Me.colPrograma.Width = 75
        '
        'colDivision
        '
        Me.colDivision.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.colDivision.HeaderText = "Division*"
        Me.colDivision.Name = "colDivision"
        Me.colDivision.ReadOnly = True
        Me.colDivision.Width = 73
        '
        'colEstilo
        '
        Me.colEstilo.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.colEstilo.HeaderText = "Style"
        Me.colEstilo.Name = "colEstilo"
        Me.colEstilo.Visible = False
        Me.colEstilo.Width = 55
        '
        'colLineaDet
        '
        Me.colLineaDet.HeaderText = "Line"
        Me.colLineaDet.Name = "colLineaDet"
        Me.colLineaDet.ReadOnly = True
        Me.colLineaDet.Visible = False
        '
        'colDescargos
        '
        Me.colDescargos.HeaderText = "Descargos"
        Me.colDescargos.Name = "colDescargos"
        Me.colDescargos.Visible = False
        '
        'colFechInicio
        '
        Me.colFechInicio.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        DataGridViewCellStyle4.Format = "d"
        DataGridViewCellStyle4.NullValue = Nothing
        DataGridViewCellStyle4.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.colFechInicio.DefaultCellStyle = DataGridViewCellStyle4
        Me.colFechInicio.HeaderText = "Start Date"
        Me.colFechInicio.Name = "colFechInicio"
        Me.colFechInicio.Visible = False
        Me.colFechInicio.Width = 80
        '
        'colFechFinal
        '
        Me.colFechFinal.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.colFechFinal.HeaderText = "Final Date"
        Me.colFechFinal.Name = "colFechFinal"
        Me.colFechFinal.Visible = False
        Me.colFechFinal.Width = 80
        '
        'colFabricante
        '
        Me.colFabricante.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.colFabricante.HeaderText = "Manufacturer*"
        Me.colFabricante.Name = "colFabricante"
        Me.colFabricante.Visible = False
        Me.colFabricante.Width = 99
        '
        'colCodFabricante
        '
        Me.colCodFabricante.HeaderText = "CodFabricante"
        Me.colCodFabricante.Name = "colCodFabricante"
        Me.colCodFabricante.Visible = False
        '
        'colAgrega
        '
        Me.colAgrega.HeaderText = "Agregar"
        Me.colAgrega.Name = "colAgrega"
        Me.colAgrega.Visible = False
        '
        'colCodArt
        '
        Me.colCodArt.HeaderText = "CodigoArt"
        Me.colCodArt.Name = "colCodArt"
        Me.colCodArt.Visible = False
        '
        'colObservacion
        '
        Me.colObservacion.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.colObservacion.HeaderText = "Observation"
        Me.colObservacion.Name = "colObservacion"
        Me.colObservacion.Width = 89
        '
        'panelDetalle
        '
        Me.panelDetalle.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.panelDetalle.Controls.Add(Me.Panel1)
        Me.panelDetalle.Controls.Add(Me.panelBotones)
        Me.panelDetalle.Location = New System.Drawing.Point(12, 303)
        Me.panelDetalle.Name = "panelDetalle"
        Me.panelDetalle.Size = New System.Drawing.Size(1036, 136)
        Me.panelDetalle.TabIndex = 7
        '
        'Panel1
        '
        Me.Panel1.Controls.Add(Me.dgDetalle)
        Me.Panel1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Panel1.Location = New System.Drawing.Point(0, 0)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(986, 136)
        Me.Panel1.TabIndex = 4
        '
        'panelBotones
        '
        Me.panelBotones.Controls.Add(Me.botonDelete)
        Me.panelBotones.Controls.Add(Me.botonAdd)
        Me.panelBotones.Dock = System.Windows.Forms.DockStyle.Right
        Me.panelBotones.Location = New System.Drawing.Point(986, 0)
        Me.panelBotones.Name = "panelBotones"
        Me.panelBotones.Size = New System.Drawing.Size(50, 136)
        Me.panelBotones.TabIndex = 3
        '
        'botonDelete
        '
        Me.botonDelete.Image = CType(resources.GetObject("botonDelete.Image"), System.Drawing.Image)
        Me.botonDelete.Location = New System.Drawing.Point(5, 48)
        Me.botonDelete.Name = "botonDelete"
        Me.botonDelete.Size = New System.Drawing.Size(30, 23)
        Me.botonDelete.TabIndex = 1
        Me.botonDelete.UseVisualStyleBackColor = True
        '
        'botonAdd
        '
        Me.botonAdd.Image = CType(resources.GetObject("botonAdd.Image"), System.Drawing.Image)
        Me.botonAdd.Location = New System.Drawing.Point(5, 15)
        Me.botonAdd.Name = "botonAdd"
        Me.botonAdd.Size = New System.Drawing.Size(30, 23)
        Me.botonAdd.TabIndex = 0
        Me.botonAdd.UseVisualStyleBackColor = True
        '
        'panelReferencias
        '
        Me.panelReferencias.Controls.Add(Me.dgReferencias)
        Me.panelReferencias.Location = New System.Drawing.Point(869, 38)
        Me.panelReferencias.Margin = New System.Windows.Forms.Padding(2)
        Me.panelReferencias.Name = "panelReferencias"
        Me.panelReferencias.Size = New System.Drawing.Size(313, 102)
        Me.panelReferencias.TabIndex = 7
        Me.panelReferencias.Visible = False
        '
        'dgReferencias
        '
        Me.dgReferencias.AllowUserToAddRows = False
        Me.dgReferencias.AllowUserToDeleteRows = False
        Me.dgReferencias.AllowUserToOrderColumns = True
        Me.dgReferencias.BackgroundColor = System.Drawing.SystemColors.Control
        Me.dgReferencias.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgReferencias.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.colID, Me.colAnio, Me.colContrato, Me.colLine, Me.colReferencia, Me.colDescargo})
        Me.dgReferencias.Dock = System.Windows.Forms.DockStyle.Fill
        Me.dgReferencias.Location = New System.Drawing.Point(0, 0)
        Me.dgReferencias.Margin = New System.Windows.Forms.Padding(2)
        Me.dgReferencias.MultiSelect = False
        Me.dgReferencias.Name = "dgReferencias"
        Me.dgReferencias.ReadOnly = True
        Me.dgReferencias.RowTemplate.Height = 24
        Me.dgReferencias.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.dgReferencias.Size = New System.Drawing.Size(313, 102)
        Me.dgReferencias.TabIndex = 0
        Me.dgReferencias.Visible = False
        '
        'colID
        '
        Me.colID.HeaderText = "ID"
        Me.colID.Name = "colID"
        Me.colID.ReadOnly = True
        '
        'colAnio
        '
        Me.colAnio.HeaderText = "Año"
        Me.colAnio.Name = "colAnio"
        Me.colAnio.ReadOnly = True
        '
        'colContrato
        '
        Me.colContrato.HeaderText = "Contrato"
        Me.colContrato.Name = "colContrato"
        Me.colContrato.ReadOnly = True
        '
        'colLine
        '
        Me.colLine.HeaderText = "Linea"
        Me.colLine.Name = "colLine"
        Me.colLine.ReadOnly = True
        '
        'colReferencia
        '
        Me.colReferencia.HeaderText = "Referencia"
        Me.colReferencia.Name = "colReferencia"
        Me.colReferencia.ReadOnly = True
        '
        'colDescargo
        '
        Me.colDescargo.HeaderText = "Descargo"
        Me.colDescargo.Name = "colDescargo"
        Me.colDescargo.ReadOnly = True
        '
        'panelDetalle2
        '
        Me.panelDetalle2.Controls.Add(Me.panelReferencias)
        Me.panelDetalle2.Controls.Add(Me.dgDetalleDoc)
        Me.panelDetalle2.Controls.Add(Me.celdaTotales2)
        Me.panelDetalle2.Controls.Add(Me.celdaTotales)
        Me.panelDetalle2.Controls.Add(Me.etiquetaTotales)
        Me.panelDetalle2.Controls.Add(Me.dgDetalle2)
        Me.panelDetalle2.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.panelDetalle2.Location = New System.Drawing.Point(0, 445)
        Me.panelDetalle2.Name = "panelDetalle2"
        Me.panelDetalle2.Size = New System.Drawing.Size(1056, 128)
        Me.panelDetalle2.TabIndex = 8
        '
        'dgDetalleDoc
        '
        Me.dgDetalleDoc.AllowUserToAddRows = False
        Me.dgDetalleDoc.AllowUserToDeleteRows = False
        Me.dgDetalleDoc.AllowUserToOrderColumns = True
        Me.dgDetalleDoc.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.dgDetalleDoc.BackgroundColor = System.Drawing.SystemColors.Control
        Me.dgDetalleDoc.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgDetalleDoc.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.colClave, Me.colDocumentos, Me.colDatos})
        Me.dgDetalleDoc.Location = New System.Drawing.Point(3, 3)
        Me.dgDetalleDoc.Name = "dgDetalleDoc"
        Me.dgDetalleDoc.ReadOnly = True
        Me.dgDetalleDoc.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.dgDetalleDoc.Size = New System.Drawing.Size(337, 125)
        Me.dgDetalleDoc.TabIndex = 12
        Me.dgDetalleDoc.Visible = False
        '
        'colClave
        '
        Me.colClave.HeaderText = "Clave"
        Me.colClave.Name = "colClave"
        Me.colClave.ReadOnly = True
        Me.colClave.Visible = False
        '
        'colDocumentos
        '
        Me.colDocumentos.HeaderText = "Documents"
        Me.colDocumentos.Name = "colDocumentos"
        Me.colDocumentos.ReadOnly = True
        Me.colDocumentos.Width = 200
        '
        'colDatos
        '
        Me.colDatos.HeaderText = "Data"
        Me.colDatos.Name = "colDatos"
        Me.colDatos.ReadOnly = True
        '
        'celdaTotales2
        '
        Me.celdaTotales2.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.celdaTotales2.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.celdaTotales2.Location = New System.Drawing.Point(906, 3)
        Me.celdaTotales2.Multiline = True
        Me.celdaTotales2.Name = "celdaTotales2"
        Me.celdaTotales2.ReadOnly = True
        Me.celdaTotales2.Size = New System.Drawing.Size(92, 30)
        Me.celdaTotales2.TabIndex = 11
        Me.celdaTotales2.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'celdaTotales
        '
        Me.celdaTotales.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.celdaTotales.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.celdaTotales.Location = New System.Drawing.Point(808, 3)
        Me.celdaTotales.Multiline = True
        Me.celdaTotales.Name = "celdaTotales"
        Me.celdaTotales.ReadOnly = True
        Me.celdaTotales.Size = New System.Drawing.Size(93, 30)
        Me.celdaTotales.TabIndex = 10
        Me.celdaTotales.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'etiquetaTotales
        '
        Me.etiquetaTotales.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.etiquetaTotales.AutoSize = True
        Me.etiquetaTotales.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.etiquetaTotales.Location = New System.Drawing.Point(755, 13)
        Me.etiquetaTotales.Name = "etiquetaTotales"
        Me.etiquetaTotales.Size = New System.Drawing.Size(47, 17)
        Me.etiquetaTotales.TabIndex = 9
        Me.etiquetaTotales.Text = "Totals"
        '
        'dgDetalle2
        '
        Me.dgDetalle2.AllowUserToAddRows = False
        Me.dgDetalle2.AllowUserToDeleteRows = False
        Me.dgDetalle2.AllowUserToOrderColumns = True
        Me.dgDetalle2.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.dgDetalle2.BackgroundColor = System.Drawing.SystemColors.Control
        Me.dgDetalle2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgDetalle2.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.colLinea, Me.colAño, Me.colNDespacho, Me.colCantida, Me.colSaldoActual})
        Me.dgDetalle2.Location = New System.Drawing.Point(346, 38)
        Me.dgDetalle2.MultiSelect = False
        Me.dgDetalle2.Name = "dgDetalle2"
        Me.dgDetalle2.ReadOnly = True
        Me.dgDetalle2.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.dgDetalle2.Size = New System.Drawing.Size(652, 80)
        Me.dgDetalle2.TabIndex = 0
        '
        'colLinea
        '
        Me.colLinea.HeaderText = "Line"
        Me.colLinea.Name = "colLinea"
        Me.colLinea.ReadOnly = True
        Me.colLinea.Width = 50
        '
        'colAño
        '
        Me.colAño.HeaderText = "Year"
        Me.colAño.Name = "colAño"
        Me.colAño.ReadOnly = True
        Me.colAño.Width = 50
        '
        'colNDespacho
        '
        Me.colNDespacho.HeaderText = "No. Dispatch"
        Me.colNDespacho.Name = "colNDespacho"
        Me.colNDespacho.ReadOnly = True
        Me.colNDespacho.Width = 80
        '
        'colCantida
        '
        Me.colCantida.HeaderText = "Quantity"
        Me.colCantida.Name = "colCantida"
        Me.colCantida.ReadOnly = True
        Me.colCantida.Width = 50
        '
        'colSaldoActual
        '
        Me.colSaldoActual.HeaderText = "Current Balance"
        Me.colSaldoActual.Name = "colSaldoActual"
        Me.colSaldoActual.ReadOnly = True
        Me.colSaldoActual.Width = 80
        '
        'panelDocumento
        '
        Me.panelDocumento.Controls.Add(Me.gbDatosPedido)
        Me.panelDocumento.Controls.Add(Me.panelDetalle2)
        Me.panelDocumento.Controls.Add(Me.gbDatosRequer)
        Me.panelDocumento.Controls.Add(Me.panelDetalle)
        Me.panelDocumento.Controls.Add(Me.dgContratos)
        Me.panelDocumento.Location = New System.Drawing.Point(18, 248)
        Me.panelDocumento.Name = "panelDocumento"
        Me.panelDocumento.Size = New System.Drawing.Size(1056, 573)
        Me.panelDocumento.TabIndex = 9
        '
        'panelLista
        '
        Me.panelLista.Controls.Add(Me.celdaColorAmarillo)
        Me.panelLista.Controls.Add(Me.celdaColorRojo)
        Me.panelLista.Controls.Add(Me.etiquetaNoImpreso)
        Me.panelLista.Controls.Add(Me.Label3)
        Me.panelLista.Controls.Add(Me.Checkfecha)
        Me.panelLista.Controls.Add(Me.etiquetaYFecha)
        Me.panelLista.Controls.Add(Me.dtpFinal)
        Me.panelLista.Controls.Add(Me.dtpInicio)
        Me.panelLista.Controls.Add(Me.botonActualizar)
        Me.panelLista.Controls.Add(Me.dgLista)
        Me.panelLista.Controls.Add(Me.TextBox8)
        Me.panelLista.Location = New System.Drawing.Point(18, 129)
        Me.panelLista.Name = "panelLista"
        Me.panelLista.Size = New System.Drawing.Size(833, 100)
        Me.panelLista.TabIndex = 10
        '
        'celdaColorAmarillo
        '
        Me.celdaColorAmarillo.BackColor = System.Drawing.Color.Yellow
        Me.celdaColorAmarillo.Location = New System.Drawing.Point(713, 20)
        Me.celdaColorAmarillo.Name = "celdaColorAmarillo"
        Me.celdaColorAmarillo.ReadOnly = True
        Me.celdaColorAmarillo.Size = New System.Drawing.Size(19, 20)
        Me.celdaColorAmarillo.TabIndex = 34
        '
        'celdaColorRojo
        '
        Me.celdaColorRojo.BackColor = System.Drawing.Color.YellowGreen
        Me.celdaColorRojo.Location = New System.Drawing.Point(616, 20)
        Me.celdaColorRojo.Name = "celdaColorRojo"
        Me.celdaColorRojo.ReadOnly = True
        Me.celdaColorRojo.Size = New System.Drawing.Size(19, 20)
        Me.celdaColorRojo.TabIndex = 33
        '
        'etiquetaNoImpreso
        '
        Me.etiquetaNoImpreso.AutoSize = True
        Me.etiquetaNoImpreso.BackColor = System.Drawing.SystemColors.Info
        Me.etiquetaNoImpreso.Location = New System.Drawing.Point(740, 24)
        Me.etiquetaNoImpreso.Name = "etiquetaNoImpreso"
        Me.etiquetaNoImpreso.Size = New System.Drawing.Size(50, 13)
        Me.etiquetaNoImpreso.TabIndex = 36
        Me.etiquetaNoImpreso.Text = "REVIEW"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.BackColor = System.Drawing.SystemColors.Info
        Me.Label3.Location = New System.Drawing.Point(641, 24)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(65, 13)
        Me.Label3.TabIndex = 35
        Me.Label3.Text = "REVIEWED"
        '
        'Checkfecha
        '
        Me.Checkfecha.AutoSize = True
        Me.Checkfecha.Checked = True
        Me.Checkfecha.CheckState = System.Windows.Forms.CheckState.Checked
        Me.Checkfecha.Location = New System.Drawing.Point(12, 19)
        Me.Checkfecha.Margin = New System.Windows.Forms.Padding(2)
        Me.Checkfecha.Name = "Checkfecha"
        Me.Checkfecha.Size = New System.Drawing.Size(176, 17)
        Me.Checkfecha.TabIndex = 5
        Me.Checkfecha.Text = "Show documents between date"
        Me.Checkfecha.UseVisualStyleBackColor = True
        '
        'TextBox8
        '
        Me.TextBox8.BackColor = System.Drawing.SystemColors.Info
        Me.TextBox8.Dock = System.Windows.Forms.DockStyle.Top
        Me.TextBox8.Location = New System.Drawing.Point(0, 0)
        Me.TextBox8.Multiline = True
        Me.TextBox8.Name = "TextBox8"
        Me.TextBox8.Size = New System.Drawing.Size(833, 47)
        Me.TextBox8.TabIndex = 2
        '
        'botonImprimir
        '
        Me.botonImprimir.Image = CType(resources.GetObject("botonImprimir.Image"), System.Drawing.Image)
        Me.botonImprimir.Location = New System.Drawing.Point(203, 11)
        Me.botonImprimir.Name = "botonImprimir"
        Me.botonImprimir.Size = New System.Drawing.Size(84, 43)
        Me.botonImprimir.TabIndex = 23
        Me.botonImprimir.Text = "Print Proforma"
        Me.botonImprimir.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.botonImprimir.UseVisualStyleBackColor = True
        '
        'botonContrato
        '
        Me.botonContrato.Image = CType(resources.GetObject("botonContrato.Image"), System.Drawing.Image)
        Me.botonContrato.Location = New System.Drawing.Point(293, 12)
        Me.botonContrato.Name = "botonContrato"
        Me.botonContrato.Size = New System.Drawing.Size(90, 42)
        Me.botonContrato.TabIndex = 24
        Me.botonContrato.Text = "Print Contract"
        Me.botonContrato.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.botonContrato.UseVisualStyleBackColor = True
        '
        'botonBuscar
        '
        Me.botonBuscar.Image = Global.KARIMs_SGI.My.Resources.Resources.search1
        Me.botonBuscar.Location = New System.Drawing.Point(464, 11)
        Me.botonBuscar.Name = "botonBuscar"
        Me.botonBuscar.Size = New System.Drawing.Size(65, 42)
        Me.botonBuscar.TabIndex = 25
        Me.botonBuscar.Text = "Search"
        Me.botonBuscar.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.botonBuscar.UseVisualStyleBackColor = True
        '
        'BotonHoras
        '
        Me.BotonHoras.Location = New System.Drawing.Point(604, 82)
        Me.BotonHoras.Margin = New System.Windows.Forms.Padding(2)
        Me.BotonHoras.Name = "BotonHoras"
        Me.BotonHoras.Size = New System.Drawing.Size(47, 20)
        Me.BotonHoras.TabIndex = 49
        Me.BotonHoras.Text = "..."
        Me.BotonHoras.UseVisualStyleBackColor = True
        Me.BotonHoras.Visible = False
        '
        'botonOrdenProduccion
        '
        Me.botonOrdenProduccion.Image = CType(resources.GetObject("botonOrdenProduccion.Image"), System.Drawing.Image)
        Me.botonOrdenProduccion.Location = New System.Drawing.Point(389, 12)
        Me.botonOrdenProduccion.Name = "botonOrdenProduccion"
        Me.botonOrdenProduccion.Size = New System.Drawing.Size(69, 42)
        Me.botonOrdenProduccion.TabIndex = 50
        Me.botonOrdenProduccion.Text = "Print PO"
        Me.botonOrdenProduccion.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.botonOrdenProduccion.UseVisualStyleBackColor = True
        Me.botonOrdenProduccion.Visible = False
        '
        'BarraTitulo1
        '
        Me.BarraTitulo1.BackColor = System.Drawing.Color.WhiteSmoke
        Me.BarraTitulo1.Dock = System.Windows.Forms.DockStyle.Top
        Me.BarraTitulo1.Location = New System.Drawing.Point(0, 72)
        Me.BarraTitulo1.Margin = New System.Windows.Forms.Padding(4)
        Me.BarraTitulo1.Name = "BarraTitulo1"
        Me.BarraTitulo1.Size = New System.Drawing.Size(1223, 30)
        Me.BarraTitulo1.TabIndex = 2
        '
        'Encabezado1
        '
        Me.Encabezado1.Dock = System.Windows.Forms.DockStyle.Top
        Me.Encabezado1.Location = New System.Drawing.Point(0, 0)
        Me.Encabezado1.Margin = New System.Windows.Forms.Padding(4)
        Me.Encabezado1.Name = "Encabezado1"
        Me.Encabezado1.Size = New System.Drawing.Size(1223, 72)
        Me.Encabezado1.TabIndex = 1
        '
        'frmPedidosClient_proforma_
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1223, 823)
        Me.Controls.Add(Me.botonOrdenProduccion)
        Me.Controls.Add(Me.BotonHoras)
        Me.Controls.Add(Me.botonBuscar)
        Me.Controls.Add(Me.botonContrato)
        Me.Controls.Add(Me.botonImprimir)
        Me.Controls.Add(Me.panelLista)
        Me.Controls.Add(Me.panelDocumento)
        Me.Controls.Add(Me.BarraTitulo1)
        Me.Controls.Add(Me.Encabezado1)
        Me.Name = "frmPedidosClient_proforma_"
        Me.Text = "frmPedidosClient_proforma_"
        Me.WindowState = System.Windows.Forms.FormWindowState.Maximized
        CType(Me.dgLista, System.ComponentModel.ISupportInitialize).EndInit()
        Me.gbDatosPedido.ResumeLayout(False)
        Me.gbDatosPedido.PerformLayout()
        Me.gbDatosRequer.ResumeLayout(False)
        Me.gbDatosRequer.PerformLayout()
        Me.dgContratos.ResumeLayout(False)
        Me.panelContratos.ResumeLayout(False)
        CType(Me.dgContratosLista, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.dgDetalle, System.ComponentModel.ISupportInitialize).EndInit()
        Me.panelDetalle.ResumeLayout(False)
        Me.Panel1.ResumeLayout(False)
        Me.panelBotones.ResumeLayout(False)
        Me.panelReferencias.ResumeLayout(False)
        CType(Me.dgReferencias, System.ComponentModel.ISupportInitialize).EndInit()
        Me.panelDetalle2.ResumeLayout(False)
        Me.panelDetalle2.PerformLayout()
        CType(Me.dgDetalleDoc, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.dgDetalle2, System.ComponentModel.ISupportInitialize).EndInit()
        Me.panelDocumento.ResumeLayout(False)
        Me.panelLista.ResumeLayout(False)
        Me.panelLista.PerformLayout()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents dtpInicio As System.Windows.Forms.DateTimePicker
    Friend WithEvents botonActualizar As System.Windows.Forms.Button
    Friend WithEvents Encabezado1 As KARIMs_SGI.encabezado
    Friend WithEvents BarraTitulo1 As KARIMs_SGI.BarraTitulo
    Friend WithEvents dtpFinal As System.Windows.Forms.DateTimePicker
    Friend WithEvents etiquetaYFecha As System.Windows.Forms.Label
    Friend WithEvents dgLista As System.Windows.Forms.DataGridView
    Friend WithEvents gbDatosPedido As System.Windows.Forms.GroupBox
    Friend WithEvents celdaTC As System.Windows.Forms.TextBox
    Friend WithEvents etiquetaTasa As System.Windows.Forms.Label
    Friend WithEvents celdaNit As System.Windows.Forms.TextBox
    Friend WithEvents etiquetaNIT As System.Windows.Forms.Label
    Friend WithEvents checkActivo As System.Windows.Forms.CheckBox
    Friend WithEvents celdaCliente As System.Windows.Forms.TextBox
    Friend WithEvents celdaTelefono As System.Windows.Forms.TextBox
    Friend WithEvents celdaMoneda As System.Windows.Forms.TextBox
    Friend WithEvents celdaDireccion As System.Windows.Forms.TextBox
    Friend WithEvents celdaNumero As System.Windows.Forms.TextBox
    Friend WithEvents celdaAño As System.Windows.Forms.TextBox
    Friend WithEvents etiquetaMoneda As System.Windows.Forms.Label
    Friend WithEvents etiquetaTelefono As System.Windows.Forms.Label
    Friend WithEvents etiquetaDireccion As System.Windows.Forms.Label
    Friend WithEvents etiquetaCliente As System.Windows.Forms.Label
    Friend WithEvents etiquetaFecha As System.Windows.Forms.Label
    Friend WithEvents etiquetaNumero As System.Windows.Forms.Label
    Friend WithEvents etiquetaAño As System.Windows.Forms.Label
    Friend WithEvents botonDespachos As System.Windows.Forms.Button
    Friend WithEvents ckeckPagaImp As System.Windows.Forms.CheckBox
    Friend WithEvents gbDatosRequer As System.Windows.Forms.GroupBox
    Friend WithEvents celdaPhone As System.Windows.Forms.TextBox
    Friend WithEvents etiquetaTelef As System.Windows.Forms.Label
    Friend WithEvents celdaDirec As System.Windows.Forms.TextBox
    Friend WithEvents etiquetaDirectio As System.Windows.Forms.Label
    Friend WithEvents celdaSolicitante As System.Windows.Forms.TextBox
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents dgContratos As System.Windows.Forms.GroupBox
    Friend WithEvents panelContratos As System.Windows.Forms.Panel
    Friend WithEvents botonRecargar As System.Windows.Forms.Button
    Friend WithEvents botonEliminar As System.Windows.Forms.Button
    Friend WithEvents botonAgregar As System.Windows.Forms.Button
    Friend WithEvents dgContratosLista As System.Windows.Forms.DataGridView
    Friend WithEvents dgDetalle As System.Windows.Forms.DataGridView
    Friend WithEvents panelDetalle As System.Windows.Forms.Panel
    Friend WithEvents panelDetalle2 As System.Windows.Forms.Panel
    Friend WithEvents celdaTotales As System.Windows.Forms.TextBox
    Friend WithEvents etiquetaTotales As System.Windows.Forms.Label
    Friend WithEvents celdaTotales2 As System.Windows.Forms.TextBox
    Friend WithEvents dgDetalle2 As System.Windows.Forms.DataGridView
    Friend WithEvents dgDetalleDoc As System.Windows.Forms.DataGridView
    Friend WithEvents panelDocumento As System.Windows.Forms.Panel
    Friend WithEvents panelLista As System.Windows.Forms.Panel
    Friend WithEvents TextBox8 As System.Windows.Forms.TextBox
    Friend WithEvents BotonCliente As System.Windows.Forms.Button
    Friend WithEvents celdaIDCliente As System.Windows.Forms.TextBox
    Friend WithEvents celdaIDMoneda As System.Windows.Forms.TextBox
    Friend WithEvents botonMoneda As System.Windows.Forms.Button
    Friend WithEvents celdaIDSolicitante As System.Windows.Forms.TextBox
    Friend WithEvents botonSolicitante As System.Windows.Forms.Button
    Friend WithEvents etiquetaDate As System.Windows.Forms.Label
    Friend WithEvents dtpFecha As System.Windows.Forms.DateTimePicker
    Friend WithEvents dtpFecha1 As System.Windows.Forms.DateTimePicker
    Friend WithEvents checkCarta As System.Windows.Forms.CheckBox
    Friend WithEvents colClave As DataGridViewTextBoxColumn
    Friend WithEvents colDocumentos As DataGridViewTextBoxColumn
    Friend WithEvents colDatos As DataGridViewTextBoxColumn
    Friend WithEvents colLinea As DataGridViewTextBoxColumn
    Friend WithEvents colAño As DataGridViewTextBoxColumn
    Friend WithEvents colNDespacho As DataGridViewTextBoxColumn
    Friend WithEvents colCantida As DataGridViewTextBoxColumn
    Friend WithEvents colSaldoActual As DataGridViewTextBoxColumn
    Friend WithEvents celdaCode As TextBox
    Friend WithEvents Checkfecha As System.Windows.Forms.CheckBox
    Friend WithEvents colAñoContrato As DataGridViewTextBoxColumn
    Friend WithEvents colNumeroContrato As DataGridViewTextBoxColumn
    Friend WithEvents colFechaContrato As DataGridViewTextBoxColumn
    Friend WithEvents colUsuarioContrato As DataGridViewTextBoxColumn
    Friend WithEvents colReferenciaContrato As DataGridViewTextBoxColumn
    Friend WithEvents colCat As DataGridViewTextBoxColumn
    Friend WithEvents panelBotones As Panel
    Friend WithEvents botonDelete As Button
    Friend WithEvents botonAdd As Button
    Friend WithEvents panelReferencias As System.Windows.Forms.Panel
    Friend WithEvents dgReferencias As System.Windows.Forms.DataGridView
    Friend WithEvents colID As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colAnio As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colContrato As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colLine As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colReferencia As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colDescargo As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents celdaUsuario As System.Windows.Forms.TextBox
    Friend WithEvents celdaCatalogo As System.Windows.Forms.TextBox
    Friend WithEvents celdaEmpresa As System.Windows.Forms.TextBox
    Friend WithEvents etiquetaUsuario As System.Windows.Forms.Label
    Friend WithEvents etiquetaCatalogo As System.Windows.Forms.Label
    Friend WithEvents etiquetaEmpresa As System.Windows.Forms.Label
    Friend WithEvents celdaDefault As System.Windows.Forms.TextBox
    Friend WithEvents Contrato As System.Windows.Forms.Label
    Friend WithEvents celdaContrato As System.Windows.Forms.TextBox
    Friend WithEvents colNumero As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colFechaLista As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colClienteLista As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colReferenciaLista As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colDireccionLista As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colAñoLista As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colRevisado As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents celdaColorAmarillo As System.Windows.Forms.TextBox
    Friend WithEvents celdaColorRojo As System.Windows.Forms.TextBox
    Friend WithEvents etiquetaNoImpreso As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents botonImprimir As System.Windows.Forms.Button
    Friend WithEvents etiquetaRevisado As System.Windows.Forms.Label
    Friend WithEvents celdaRevisado As System.Windows.Forms.TextBox
    Friend WithEvents etiquetaImpuestos As System.Windows.Forms.Label
    Friend WithEvents celdaImpuestos As System.Windows.Forms.TextBox
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
    Friend WithEvents botonContrato As System.Windows.Forms.Button
    Friend WithEvents celdaNumeroReq As System.Windows.Forms.TextBox
    Friend WithEvents etiquetaNumber As System.Windows.Forms.Label
    Friend WithEvents celdaComentario As System.Windows.Forms.TextBox
    Friend WithEvents botonBuscar As System.Windows.Forms.Button
    Friend WithEvents etiquetaAnulada As System.Windows.Forms.Label
    Friend WithEvents celdaDescripcionP As TextBox
    Friend WithEvents celdaProyecto As TextBox
    Friend WithEvents celdaDescripcion As TextBox
    Friend WithEvents celdaidflujodetalle As TextBox
    Friend WithEvents celdaidTarea As TextBox
    Friend WithEvents celdaidProyecto As TextBox
    Friend WithEvents BotonHoras As Button
    Friend WithEvents colCatalogo As DataGridViewTextBoxColumn
    Friend WithEvents colYear As DataGridViewTextBoxColumn
    Friend WithEvents colCodigo As DataGridViewTextBoxColumn
    Friend WithEvents colDescripcion As DataGridViewTextBoxColumn
    Friend WithEvents colNumMedida As DataGridViewTextBoxColumn
    Friend WithEvents colMedida As DataGridViewTextBoxColumn
    Friend WithEvents colPrecio As DataGridViewTextBoxColumn
    Friend WithEvents colPrecioKG As DataGridViewTextBoxColumn
    Friend WithEvents colDestino As DataGridViewTextBoxColumn
    Friend WithEvents colNumDestino As DataGridViewTextBoxColumn
    Friend WithEvents colFecha As DataGridViewTextBoxColumn
    Friend WithEvents colCantidad As DataGridViewTextBoxColumn
    Friend WithEvents colTotal As DataGridViewTextBoxColumn
    Friend WithEvents colReference As DataGridViewTextBoxColumn
    Friend WithEvents colCancelado As DataGridViewTextBoxColumn
    Friend WithEvents colPrograma As DataGridViewTextBoxColumn
    Friend WithEvents colDivision As DataGridViewTextBoxColumn
    Friend WithEvents colEstilo As DataGridViewTextBoxColumn
    Friend WithEvents colLineaDet As DataGridViewTextBoxColumn
    Friend WithEvents colDescargos As DataGridViewTextBoxColumn
    Friend WithEvents colFechInicio As DataGridViewTextBoxColumn
    Friend WithEvents colFechFinal As DataGridViewTextBoxColumn
    Friend WithEvents colFabricante As DataGridViewTextBoxColumn
    Friend WithEvents colCodFabricante As DataGridViewTextBoxColumn
    Friend WithEvents colAgrega As DataGridViewTextBoxColumn
    Friend WithEvents colCodArt As DataGridViewTextBoxColumn
    Friend WithEvents colObservacion As DataGridViewTextBoxColumn
    Friend WithEvents botonOrdenProduccion As Button
End Class
