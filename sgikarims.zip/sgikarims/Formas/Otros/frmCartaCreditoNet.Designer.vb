﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmCartaCreditoNet
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim DataGridViewCellStyle1 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle2 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle3 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Me.panelDocumento = New System.Windows.Forms.Panel()
        Me.panelReceipt = New System.Windows.Forms.Panel()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.celdaTotalYRM = New System.Windows.Forms.TextBox()
        Me.dgCargoReceipt = New System.Windows.Forms.DataGridView()
        Me.colNumCargo = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colMonto = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colNumYRM = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.panelDetalle = New System.Windows.Forms.Panel()
        Me.dgDetalle = New System.Windows.Forms.DataGridView()
        Me.colNumero = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colLin = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colCantidad = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colidMedida = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colMedida = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colTotal = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colPresentacion = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colPago = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colCatalogo = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colAnio = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colNum = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colLinea = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colEstado = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.PanelControles = New System.Windows.Forms.Panel()
        Me.botonEliminar = New System.Windows.Forms.Button()
        Me.botonAgregar = New System.Windows.Forms.Button()
        Me.panelEncabezado = New System.Windows.Forms.Panel()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.checkActive = New System.Windows.Forms.CheckBox()
        Me.celdaDireccion = New System.Windows.Forms.TextBox()
        Me.etiquetaDireccion = New System.Windows.Forms.Label()
        Me.celdaidMoneda = New System.Windows.Forms.TextBox()
        Me.celdaidCliente = New System.Windows.Forms.TextBox()
        Me.celdaTasa = New System.Windows.Forms.TextBox()
        Me.etiquetaTasa = New System.Windows.Forms.Label()
        Me.botonMoneda = New System.Windows.Forms.Button()
        Me.celdaMoneda = New System.Windows.Forms.TextBox()
        Me.etiquetaMoneda = New System.Windows.Forms.Label()
        Me.celdaTotal = New System.Windows.Forms.TextBox()
        Me.etiquetaMonto = New System.Windows.Forms.Label()
        Me.celdaNit = New System.Windows.Forms.TextBox()
        Me.etiquetaNit = New System.Windows.Forms.Label()
        Me.botonCliente = New System.Windows.Forms.Button()
        Me.celdaCliente = New System.Windows.Forms.TextBox()
        Me.etiquetaCliente = New System.Windows.Forms.Label()
        Me.dtpFecha = New System.Windows.Forms.DateTimePicker()
        Me.etiquetaFecha = New System.Windows.Forms.Label()
        Me.etiquetaNumero = New System.Windows.Forms.Label()
        Me.celdaNumero = New System.Windows.Forms.TextBox()
        Me.etiquetaAño = New System.Windows.Forms.Label()
        Me.celdaAño = New System.Windows.Forms.TextBox()
        Me.panelPO = New System.Windows.Forms.Panel()
        Me.celdaLC = New System.Windows.Forms.TextBox()
        Me.etiquetaLC = New System.Windows.Forms.Label()
        Me.celdaDrawee = New System.Windows.Forms.TextBox()
        Me.etiquetaDrawee = New System.Windows.Forms.Label()
        Me.dtpFechaExpiracion = New System.Windows.Forms.DateTimePicker()
        Me.celdaComentario = New System.Windows.Forms.TextBox()
        Me.etiquetaComentario = New System.Windows.Forms.Label()
        Me.etiquetaFechaExpiracion = New System.Windows.Forms.Label()
        Me.etiquetaPO = New System.Windows.Forms.Label()
        Me.celdaPO = New System.Windows.Forms.TextBox()
        Me.PanelLista = New System.Windows.Forms.Panel()
        Me.dgLista = New System.Windows.Forms.DataGridView()
        Me.colCodigo1 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colAño = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colFecha = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colCliente = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colLC = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colName = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colEstado2 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.panelFiltro = New System.Windows.Forms.Panel()
        Me.botonActualizar = New System.Windows.Forms.Button()
        Me.checkFiltroFecha = New System.Windows.Forms.CheckBox()
        Me.dtpFechaFinal = New System.Windows.Forms.DateTimePicker()
        Me.dtpFechaInicial = New System.Windows.Forms.DateTimePicker()
        Me.BarraTitulo1 = New KARIMs_SGI.BarraTitulo()
        Me.Encabezado1 = New KARIMs_SGI.encabezado()
        Me.panelDocumento.SuspendLayout()
        Me.panelReceipt.SuspendLayout()
        CType(Me.dgCargoReceipt, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.panelDetalle.SuspendLayout()
        CType(Me.dgDetalle, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.PanelControles.SuspendLayout()
        Me.panelEncabezado.SuspendLayout()
        Me.Panel1.SuspendLayout()
        Me.panelPO.SuspendLayout()
        Me.PanelLista.SuspendLayout()
        CType(Me.dgLista, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.panelFiltro.SuspendLayout()
        Me.SuspendLayout()
        '
        'panelDocumento
        '
        Me.panelDocumento.Controls.Add(Me.panelReceipt)
        Me.panelDocumento.Controls.Add(Me.panelDetalle)
        Me.panelDocumento.Controls.Add(Me.panelEncabezado)
        Me.panelDocumento.Location = New System.Drawing.Point(12, 159)
        Me.panelDocumento.Name = "panelDocumento"
        Me.panelDocumento.Size = New System.Drawing.Size(949, 388)
        Me.panelDocumento.TabIndex = 3
        '
        'panelReceipt
        '
        Me.panelReceipt.Controls.Add(Me.Label1)
        Me.panelReceipt.Controls.Add(Me.celdaTotalYRM)
        Me.panelReceipt.Controls.Add(Me.dgCargoReceipt)
        Me.panelReceipt.Dock = System.Windows.Forms.DockStyle.Fill
        Me.panelReceipt.Location = New System.Drawing.Point(0, 433)
        Me.panelReceipt.Name = "panelReceipt"
        Me.panelReceipt.Size = New System.Drawing.Size(949, 0)
        Me.panelReceipt.TabIndex = 2
        '
        'Label1
        '
        Me.Label1.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(754, 4)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(67, 13)
        Me.Label1.TabIndex = 29
        Me.Label1.Text = "Total YRM"
        '
        'celdaTotalYRM
        '
        Me.celdaTotalYRM.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.celdaTotalYRM.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.celdaTotalYRM.Location = New System.Drawing.Point(757, 21)
        Me.celdaTotalYRM.Name = "celdaTotalYRM"
        Me.celdaTotalYRM.ReadOnly = True
        Me.celdaTotalYRM.Size = New System.Drawing.Size(146, 19)
        Me.celdaTotalYRM.TabIndex = 13
        '
        'dgCargoReceipt
        '
        Me.dgCargoReceipt.AllowUserToAddRows = False
        Me.dgCargoReceipt.AllowUserToDeleteRows = False
        Me.dgCargoReceipt.AllowUserToOrderColumns = True
        Me.dgCargoReceipt.BackgroundColor = System.Drawing.SystemColors.Control
        Me.dgCargoReceipt.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgCargoReceipt.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.colNumCargo, Me.colMonto, Me.colNumYRM})
        Me.dgCargoReceipt.Dock = System.Windows.Forms.DockStyle.Left
        Me.dgCargoReceipt.Location = New System.Drawing.Point(0, 0)
        Me.dgCargoReceipt.Name = "dgCargoReceipt"
        Me.dgCargoReceipt.Size = New System.Drawing.Size(788, 0)
        Me.dgCargoReceipt.TabIndex = 0
        '
        'colNumCargo
        '
        Me.colNumCargo.HeaderText = "#Receipt"
        Me.colNumCargo.Name = "colNumCargo"
        '
        'colMonto
        '
        Me.colMonto.HeaderText = "Amount"
        Me.colMonto.Name = "colMonto"
        '
        'colNumYRM
        '
        Me.colNumYRM.HeaderText = "#YRM"
        Me.colNumYRM.Name = "colNumYRM"
        '
        'panelDetalle
        '
        Me.panelDetalle.Controls.Add(Me.dgDetalle)
        Me.panelDetalle.Controls.Add(Me.PanelControles)
        Me.panelDetalle.Dock = System.Windows.Forms.DockStyle.Top
        Me.panelDetalle.Location = New System.Drawing.Point(0, 243)
        Me.panelDetalle.Name = "panelDetalle"
        Me.panelDetalle.Size = New System.Drawing.Size(949, 190)
        Me.panelDetalle.TabIndex = 1
        '
        'dgDetalle
        '
        Me.dgDetalle.AllowUserToAddRows = False
        Me.dgDetalle.AllowUserToDeleteRows = False
        Me.dgDetalle.AllowUserToOrderColumns = True
        Me.dgDetalle.BackgroundColor = System.Drawing.SystemColors.Control
        Me.dgDetalle.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgDetalle.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.colNumero, Me.colLin, Me.colCantidad, Me.colidMedida, Me.colMedida, Me.colTotal, Me.colPresentacion, Me.colPago, Me.colCatalogo, Me.colAnio, Me.colNum, Me.colLinea, Me.colEstado})
        Me.dgDetalle.Dock = System.Windows.Forms.DockStyle.Fill
        Me.dgDetalle.Location = New System.Drawing.Point(0, 0)
        Me.dgDetalle.Name = "dgDetalle"
        Me.dgDetalle.ReadOnly = True
        Me.dgDetalle.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.dgDetalle.Size = New System.Drawing.Size(900, 190)
        Me.dgDetalle.TabIndex = 0
        '
        'colNumero
        '
        Me.colNumero.HeaderText = "#YRM"
        Me.colNumero.Name = "colNumero"
        Me.colNumero.ReadOnly = True
        '
        'colLin
        '
        Me.colLin.HeaderText = "Line"
        Me.colLin.Name = "colLin"
        Me.colLin.ReadOnly = True
        '
        'colCantidad
        '
        Me.colCantidad.HeaderText = "Quantity"
        Me.colCantidad.Name = "colCantidad"
        Me.colCantidad.ReadOnly = True
        '
        'colidMedida
        '
        Me.colidMedida.HeaderText = "idMedida"
        Me.colidMedida.Name = "colidMedida"
        Me.colidMedida.ReadOnly = True
        Me.colidMedida.Visible = False
        '
        'colMedida
        '
        Me.colMedida.HeaderText = "Measure"
        Me.colMedida.Name = "colMedida"
        Me.colMedida.ReadOnly = True
        '
        'colTotal
        '
        Me.colTotal.HeaderText = "Total"
        Me.colTotal.Name = "colTotal"
        Me.colTotal.ReadOnly = True
        '
        'colPresentacion
        '
        Me.colPresentacion.HeaderText = "Presented"
        Me.colPresentacion.Name = "colPresentacion"
        Me.colPresentacion.ReadOnly = True
        '
        'colPago
        '
        Me.colPago.HeaderText = "Payment"
        Me.colPago.Name = "colPago"
        Me.colPago.ReadOnly = True
        '
        'colCatalogo
        '
        Me.colCatalogo.HeaderText = "Catalogo"
        Me.colCatalogo.Name = "colCatalogo"
        Me.colCatalogo.ReadOnly = True
        Me.colCatalogo.Visible = False
        '
        'colAnio
        '
        Me.colAnio.HeaderText = "Anio"
        Me.colAnio.Name = "colAnio"
        Me.colAnio.ReadOnly = True
        Me.colAnio.Visible = False
        '
        'colNum
        '
        Me.colNum.HeaderText = "numero"
        Me.colNum.Name = "colNum"
        Me.colNum.ReadOnly = True
        Me.colNum.Visible = False
        '
        'colLinea
        '
        Me.colLinea.HeaderText = "Linea"
        Me.colLinea.Name = "colLinea"
        Me.colLinea.ReadOnly = True
        Me.colLinea.Visible = False
        '
        'colEstado
        '
        Me.colEstado.HeaderText = "Estado"
        Me.colEstado.Name = "colEstado"
        Me.colEstado.ReadOnly = True
        Me.colEstado.Visible = False
        '
        'PanelControles
        '
        Me.PanelControles.Controls.Add(Me.botonEliminar)
        Me.PanelControles.Controls.Add(Me.botonAgregar)
        Me.PanelControles.Dock = System.Windows.Forms.DockStyle.Right
        Me.PanelControles.Location = New System.Drawing.Point(900, 0)
        Me.PanelControles.Margin = New System.Windows.Forms.Padding(2)
        Me.PanelControles.Name = "PanelControles"
        Me.PanelControles.Size = New System.Drawing.Size(49, 190)
        Me.PanelControles.TabIndex = 1
        '
        'botonEliminar
        '
        Me.botonEliminar.Image = Global.KARIMs_SGI.My.Resources.Resources.delete3
        Me.botonEliminar.Location = New System.Drawing.Point(5, 59)
        Me.botonEliminar.Margin = New System.Windows.Forms.Padding(2)
        Me.botonEliminar.Name = "botonEliminar"
        Me.botonEliminar.Size = New System.Drawing.Size(38, 19)
        Me.botonEliminar.TabIndex = 1
        Me.botonEliminar.UseVisualStyleBackColor = True
        '
        'botonAgregar
        '
        Me.botonAgregar.Image = Global.KARIMs_SGI.My.Resources.Resources.add
        Me.botonAgregar.Location = New System.Drawing.Point(4, 14)
        Me.botonAgregar.Margin = New System.Windows.Forms.Padding(2)
        Me.botonAgregar.Name = "botonAgregar"
        Me.botonAgregar.Size = New System.Drawing.Size(38, 19)
        Me.botonAgregar.TabIndex = 0
        Me.botonAgregar.UseVisualStyleBackColor = True
        '
        'panelEncabezado
        '
        Me.panelEncabezado.Controls.Add(Me.Panel1)
        Me.panelEncabezado.Controls.Add(Me.panelPO)
        Me.panelEncabezado.Dock = System.Windows.Forms.DockStyle.Top
        Me.panelEncabezado.Location = New System.Drawing.Point(0, 0)
        Me.panelEncabezado.Name = "panelEncabezado"
        Me.panelEncabezado.Size = New System.Drawing.Size(949, 243)
        Me.panelEncabezado.TabIndex = 0
        '
        'Panel1
        '
        Me.Panel1.Controls.Add(Me.checkActive)
        Me.Panel1.Controls.Add(Me.celdaDireccion)
        Me.Panel1.Controls.Add(Me.etiquetaDireccion)
        Me.Panel1.Controls.Add(Me.celdaidMoneda)
        Me.Panel1.Controls.Add(Me.celdaidCliente)
        Me.Panel1.Controls.Add(Me.celdaTasa)
        Me.Panel1.Controls.Add(Me.etiquetaTasa)
        Me.Panel1.Controls.Add(Me.botonMoneda)
        Me.Panel1.Controls.Add(Me.celdaMoneda)
        Me.Panel1.Controls.Add(Me.etiquetaMoneda)
        Me.Panel1.Controls.Add(Me.celdaTotal)
        Me.Panel1.Controls.Add(Me.etiquetaMonto)
        Me.Panel1.Controls.Add(Me.celdaNit)
        Me.Panel1.Controls.Add(Me.etiquetaNit)
        Me.Panel1.Controls.Add(Me.botonCliente)
        Me.Panel1.Controls.Add(Me.celdaCliente)
        Me.Panel1.Controls.Add(Me.etiquetaCliente)
        Me.Panel1.Controls.Add(Me.dtpFecha)
        Me.Panel1.Controls.Add(Me.etiquetaFecha)
        Me.Panel1.Controls.Add(Me.etiquetaNumero)
        Me.Panel1.Controls.Add(Me.celdaNumero)
        Me.Panel1.Controls.Add(Me.etiquetaAño)
        Me.Panel1.Controls.Add(Me.celdaAño)
        Me.Panel1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Panel1.Location = New System.Drawing.Point(0, 0)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(310, 243)
        Me.Panel1.TabIndex = 1
        '
        'checkActive
        '
        Me.checkActive.AutoSize = True
        Me.checkActive.Location = New System.Drawing.Point(223, 28)
        Me.checkActive.Name = "checkActive"
        Me.checkActive.Size = New System.Drawing.Size(56, 17)
        Me.checkActive.TabIndex = 28
        Me.checkActive.Text = "Active"
        Me.checkActive.UseVisualStyleBackColor = True
        '
        'celdaDireccion
        '
        Me.celdaDireccion.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.celdaDireccion.Location = New System.Drawing.Point(62, 124)
        Me.celdaDireccion.Multiline = True
        Me.celdaDireccion.Name = "celdaDireccion"
        Me.celdaDireccion.ReadOnly = True
        Me.celdaDireccion.Size = New System.Drawing.Size(103, 34)
        Me.celdaDireccion.TabIndex = 27
        '
        'etiquetaDireccion
        '
        Me.etiquetaDireccion.AutoSize = True
        Me.etiquetaDireccion.Location = New System.Drawing.Point(3, 127)
        Me.etiquetaDireccion.Name = "etiquetaDireccion"
        Me.etiquetaDireccion.Size = New System.Drawing.Size(45, 13)
        Me.etiquetaDireccion.TabIndex = 20
        Me.etiquetaDireccion.Text = "Address"
        '
        'celdaidMoneda
        '
        Me.celdaidMoneda.Location = New System.Drawing.Point(257, 187)
        Me.celdaidMoneda.Name = "celdaidMoneda"
        Me.celdaidMoneda.Size = New System.Drawing.Size(23, 20)
        Me.celdaidMoneda.TabIndex = 19
        Me.celdaidMoneda.Visible = False
        '
        'celdaidCliente
        '
        Me.celdaidCliente.Location = New System.Drawing.Point(233, 68)
        Me.celdaidCliente.Name = "celdaidCliente"
        Me.celdaidCliente.Size = New System.Drawing.Size(23, 20)
        Me.celdaidCliente.TabIndex = 18
        Me.celdaidCliente.Visible = False
        '
        'celdaTasa
        '
        Me.celdaTasa.Location = New System.Drawing.Point(310, 217)
        Me.celdaTasa.Name = "celdaTasa"
        Me.celdaTasa.ReadOnly = True
        Me.celdaTasa.Size = New System.Drawing.Size(113, 20)
        Me.celdaTasa.TabIndex = 17
        '
        'etiquetaTasa
        '
        Me.etiquetaTasa.AutoSize = True
        Me.etiquetaTasa.Location = New System.Drawing.Point(274, 220)
        Me.etiquetaTasa.Name = "etiquetaTasa"
        Me.etiquetaTasa.Size = New System.Drawing.Size(30, 13)
        Me.etiquetaTasa.TabIndex = 16
        Me.etiquetaTasa.Text = "Rate"
        '
        'botonMoneda
        '
        Me.botonMoneda.Location = New System.Drawing.Point(214, 215)
        Me.botonMoneda.Name = "botonMoneda"
        Me.botonMoneda.Size = New System.Drawing.Size(30, 23)
        Me.botonMoneda.TabIndex = 15
        Me.botonMoneda.Text = "..."
        Me.botonMoneda.UseVisualStyleBackColor = True
        '
        'celdaMoneda
        '
        Me.celdaMoneda.Location = New System.Drawing.Point(62, 217)
        Me.celdaMoneda.Name = "celdaMoneda"
        Me.celdaMoneda.ReadOnly = True
        Me.celdaMoneda.Size = New System.Drawing.Size(146, 20)
        Me.celdaMoneda.TabIndex = 14
        '
        'etiquetaMoneda
        '
        Me.etiquetaMoneda.AutoSize = True
        Me.etiquetaMoneda.Location = New System.Drawing.Point(2, 220)
        Me.etiquetaMoneda.Name = "etiquetaMoneda"
        Me.etiquetaMoneda.Size = New System.Drawing.Size(49, 13)
        Me.etiquetaMoneda.TabIndex = 13
        Me.etiquetaMoneda.Text = "Currency"
        '
        'celdaTotal
        '
        Me.celdaTotal.Location = New System.Drawing.Point(62, 191)
        Me.celdaTotal.Name = "celdaTotal"
        Me.celdaTotal.Size = New System.Drawing.Size(146, 20)
        Me.celdaTotal.TabIndex = 12
        '
        'etiquetaMonto
        '
        Me.etiquetaMonto.AutoSize = True
        Me.etiquetaMonto.Location = New System.Drawing.Point(3, 194)
        Me.etiquetaMonto.Name = "etiquetaMonto"
        Me.etiquetaMonto.Size = New System.Drawing.Size(43, 13)
        Me.etiquetaMonto.TabIndex = 11
        Me.etiquetaMonto.Text = "Amount"
        '
        'celdaNit
        '
        Me.celdaNit.Location = New System.Drawing.Point(62, 163)
        Me.celdaNit.Name = "celdaNit"
        Me.celdaNit.ReadOnly = True
        Me.celdaNit.Size = New System.Drawing.Size(146, 20)
        Me.celdaNit.TabIndex = 10
        '
        'etiquetaNit
        '
        Me.etiquetaNit.AutoSize = True
        Me.etiquetaNit.Location = New System.Drawing.Point(2, 163)
        Me.etiquetaNit.Name = "etiquetaNit"
        Me.etiquetaNit.Size = New System.Drawing.Size(20, 13)
        Me.etiquetaNit.TabIndex = 9
        Me.etiquetaNit.Text = "Nit"
        '
        'botonCliente
        '
        Me.botonCliente.Location = New System.Drawing.Point(381, 98)
        Me.botonCliente.Name = "botonCliente"
        Me.botonCliente.Size = New System.Drawing.Size(33, 23)
        Me.botonCliente.TabIndex = 8
        Me.botonCliente.Text = "..."
        Me.botonCliente.UseVisualStyleBackColor = True
        '
        'celdaCliente
        '
        Me.celdaCliente.Location = New System.Drawing.Point(62, 98)
        Me.celdaCliente.Name = "celdaCliente"
        Me.celdaCliente.ReadOnly = True
        Me.celdaCliente.Size = New System.Drawing.Size(313, 20)
        Me.celdaCliente.TabIndex = 7
        '
        'etiquetaCliente
        '
        Me.etiquetaCliente.AutoSize = True
        Me.etiquetaCliente.Location = New System.Drawing.Point(3, 98)
        Me.etiquetaCliente.Name = "etiquetaCliente"
        Me.etiquetaCliente.Size = New System.Drawing.Size(33, 13)
        Me.etiquetaCliente.TabIndex = 6
        Me.etiquetaCliente.Text = "Client"
        '
        'dtpFecha
        '
        Me.dtpFecha.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.dtpFecha.Location = New System.Drawing.Point(62, 71)
        Me.dtpFecha.Name = "dtpFecha"
        Me.dtpFecha.Size = New System.Drawing.Size(126, 20)
        Me.dtpFecha.TabIndex = 5
        '
        'etiquetaFecha
        '
        Me.etiquetaFecha.AutoSize = True
        Me.etiquetaFecha.Location = New System.Drawing.Point(3, 71)
        Me.etiquetaFecha.Name = "etiquetaFecha"
        Me.etiquetaFecha.Size = New System.Drawing.Size(30, 13)
        Me.etiquetaFecha.TabIndex = 4
        Me.etiquetaFecha.Text = "Date"
        '
        'etiquetaNumero
        '
        Me.etiquetaNumero.AutoSize = True
        Me.etiquetaNumero.Location = New System.Drawing.Point(2, 44)
        Me.etiquetaNumero.Name = "etiquetaNumero"
        Me.etiquetaNumero.Size = New System.Drawing.Size(44, 13)
        Me.etiquetaNumero.TabIndex = 3
        Me.etiquetaNumero.Text = "Number"
        '
        'celdaNumero
        '
        Me.celdaNumero.Location = New System.Drawing.Point(62, 41)
        Me.celdaNumero.Name = "celdaNumero"
        Me.celdaNumero.ReadOnly = True
        Me.celdaNumero.Size = New System.Drawing.Size(126, 20)
        Me.celdaNumero.TabIndex = 2
        '
        'etiquetaAño
        '
        Me.etiquetaAño.AutoSize = True
        Me.etiquetaAño.Location = New System.Drawing.Point(2, 16)
        Me.etiquetaAño.Name = "etiquetaAño"
        Me.etiquetaAño.Size = New System.Drawing.Size(29, 13)
        Me.etiquetaAño.TabIndex = 1
        Me.etiquetaAño.Text = "Year"
        '
        'celdaAño
        '
        Me.celdaAño.Location = New System.Drawing.Point(62, 13)
        Me.celdaAño.Name = "celdaAño"
        Me.celdaAño.ReadOnly = True
        Me.celdaAño.Size = New System.Drawing.Size(126, 20)
        Me.celdaAño.TabIndex = 0
        '
        'panelPO
        '
        Me.panelPO.Controls.Add(Me.celdaLC)
        Me.panelPO.Controls.Add(Me.etiquetaLC)
        Me.panelPO.Controls.Add(Me.celdaDrawee)
        Me.panelPO.Controls.Add(Me.etiquetaDrawee)
        Me.panelPO.Controls.Add(Me.dtpFechaExpiracion)
        Me.panelPO.Controls.Add(Me.celdaComentario)
        Me.panelPO.Controls.Add(Me.etiquetaComentario)
        Me.panelPO.Controls.Add(Me.etiquetaFechaExpiracion)
        Me.panelPO.Controls.Add(Me.etiquetaPO)
        Me.panelPO.Controls.Add(Me.celdaPO)
        Me.panelPO.Dock = System.Windows.Forms.DockStyle.Right
        Me.panelPO.Location = New System.Drawing.Point(310, 0)
        Me.panelPO.Name = "panelPO"
        Me.panelPO.Size = New System.Drawing.Size(639, 243)
        Me.panelPO.TabIndex = 0
        '
        'celdaLC
        '
        Me.celdaLC.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.celdaLC.Location = New System.Drawing.Point(100, 37)
        Me.celdaLC.Name = "celdaLC"
        Me.celdaLC.Size = New System.Drawing.Size(434, 20)
        Me.celdaLC.TabIndex = 28
        '
        'etiquetaLC
        '
        Me.etiquetaLC.AutoSize = True
        Me.etiquetaLC.Location = New System.Drawing.Point(8, 40)
        Me.etiquetaLC.Name = "etiquetaLC"
        Me.etiquetaLC.Size = New System.Drawing.Size(20, 13)
        Me.etiquetaLC.TabIndex = 27
        Me.etiquetaLC.Text = "LC"
        '
        'celdaDrawee
        '
        Me.celdaDrawee.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.celdaDrawee.Location = New System.Drawing.Point(100, 145)
        Me.celdaDrawee.Name = "celdaDrawee"
        Me.celdaDrawee.Size = New System.Drawing.Size(434, 20)
        Me.celdaDrawee.TabIndex = 30
        '
        'etiquetaDrawee
        '
        Me.etiquetaDrawee.AutoSize = True
        Me.etiquetaDrawee.Location = New System.Drawing.Point(8, 145)
        Me.etiquetaDrawee.Name = "etiquetaDrawee"
        Me.etiquetaDrawee.Size = New System.Drawing.Size(44, 13)
        Me.etiquetaDrawee.TabIndex = 25
        Me.etiquetaDrawee.Text = "Drawee"
        '
        'dtpFechaExpiracion
        '
        Me.dtpFechaExpiracion.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.dtpFechaExpiracion.Location = New System.Drawing.Point(100, 108)
        Me.dtpFechaExpiracion.Name = "dtpFechaExpiracion"
        Me.dtpFechaExpiracion.Size = New System.Drawing.Size(157, 20)
        Me.dtpFechaExpiracion.TabIndex = 24
        '
        'celdaComentario
        '
        Me.celdaComentario.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.celdaComentario.Location = New System.Drawing.Point(100, 171)
        Me.celdaComentario.Multiline = True
        Me.celdaComentario.Name = "celdaComentario"
        Me.celdaComentario.Size = New System.Drawing.Size(434, 69)
        Me.celdaComentario.TabIndex = 31
        '
        'etiquetaComentario
        '
        Me.etiquetaComentario.AutoSize = True
        Me.etiquetaComentario.Location = New System.Drawing.Point(6, 174)
        Me.etiquetaComentario.Name = "etiquetaComentario"
        Me.etiquetaComentario.Size = New System.Drawing.Size(51, 13)
        Me.etiquetaComentario.TabIndex = 22
        Me.etiquetaComentario.Text = "Comment"
        '
        'etiquetaFechaExpiracion
        '
        Me.etiquetaFechaExpiracion.AutoSize = True
        Me.etiquetaFechaExpiracion.Location = New System.Drawing.Point(6, 108)
        Me.etiquetaFechaExpiracion.Name = "etiquetaFechaExpiracion"
        Me.etiquetaFechaExpiracion.Size = New System.Drawing.Size(79, 13)
        Me.etiquetaFechaExpiracion.TabIndex = 20
        Me.etiquetaFechaExpiracion.Text = "Expiration Date"
        '
        'etiquetaPO
        '
        Me.etiquetaPO.AutoSize = True
        Me.etiquetaPO.Location = New System.Drawing.Point(8, 75)
        Me.etiquetaPO.Name = "etiquetaPO"
        Me.etiquetaPO.Size = New System.Drawing.Size(42, 13)
        Me.etiquetaPO.TabIndex = 19
        Me.etiquetaPO.Text = "No PO."
        '
        'celdaPO
        '
        Me.celdaPO.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.celdaPO.Location = New System.Drawing.Point(100, 72)
        Me.celdaPO.Name = "celdaPO"
        Me.celdaPO.Size = New System.Drawing.Size(434, 20)
        Me.celdaPO.TabIndex = 29
        '
        'PanelLista
        '
        Me.PanelLista.Controls.Add(Me.dgLista)
        Me.PanelLista.Controls.Add(Me.panelFiltro)
        Me.PanelLista.Dock = System.Windows.Forms.DockStyle.Top
        Me.PanelLista.Location = New System.Drawing.Point(0, 102)
        Me.PanelLista.Margin = New System.Windows.Forms.Padding(2)
        Me.PanelLista.Name = "PanelLista"
        Me.PanelLista.Size = New System.Drawing.Size(972, 52)
        Me.PanelLista.TabIndex = 4
        '
        'dgLista
        '
        Me.dgLista.AllowUserToAddRows = False
        Me.dgLista.AllowUserToDeleteRows = False
        Me.dgLista.BackgroundColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle1.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.dgLista.ColumnHeadersDefaultCellStyle = DataGridViewCellStyle1
        Me.dgLista.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgLista.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.colCodigo1, Me.colAño, Me.colFecha, Me.colCliente, Me.colLC, Me.colName, Me.colEstado2})
        DataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle2.BackColor = System.Drawing.SystemColors.Window
        DataGridViewCellStyle2.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.ControlText
        DataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.[False]
        Me.dgLista.DefaultCellStyle = DataGridViewCellStyle2
        Me.dgLista.Dock = System.Windows.Forms.DockStyle.Fill
        Me.dgLista.Location = New System.Drawing.Point(0, 38)
        Me.dgLista.Margin = New System.Windows.Forms.Padding(2)
        Me.dgLista.MultiSelect = False
        Me.dgLista.Name = "dgLista"
        Me.dgLista.ReadOnly = True
        DataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle3.BackColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle3.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle3.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle3.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle3.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.dgLista.RowHeadersDefaultCellStyle = DataGridViewCellStyle3
        Me.dgLista.RowTemplate.Height = 24
        Me.dgLista.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.dgLista.Size = New System.Drawing.Size(972, 14)
        Me.dgLista.TabIndex = 0
        '
        'colCodigo1
        '
        Me.colCodigo1.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.colCodigo1.HeaderText = "Code"
        Me.colCodigo1.Name = "colCodigo1"
        Me.colCodigo1.ReadOnly = True
        Me.colCodigo1.Width = 57
        '
        'colAño
        '
        Me.colAño.HeaderText = "YEAR"
        Me.colAño.Name = "colAño"
        Me.colAño.ReadOnly = True
        Me.colAño.Visible = False
        '
        'colFecha
        '
        Me.colFecha.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.colFecha.HeaderText = "Date"
        Me.colFecha.Name = "colFecha"
        Me.colFecha.ReadOnly = True
        Me.colFecha.Width = 55
        '
        'colCliente
        '
        Me.colCliente.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.colCliente.HeaderText = "Client"
        Me.colCliente.Name = "colCliente"
        Me.colCliente.ReadOnly = True
        Me.colCliente.Width = 58
        '
        'colLC
        '
        Me.colLC.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.colLC.HeaderText = "LC"
        Me.colLC.Name = "colLC"
        Me.colLC.ReadOnly = True
        Me.colLC.Width = 45
        '
        'colName
        '
        Me.colName.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.colName.HeaderText = "PO Name"
        Me.colName.Name = "colName"
        Me.colName.ReadOnly = True
        Me.colName.Width = 78
        '
        'colEstado2
        '
        Me.colEstado2.HeaderText = "Status"
        Me.colEstado2.Name = "colEstado2"
        Me.colEstado2.ReadOnly = True
        '
        'panelFiltro
        '
        Me.panelFiltro.Controls.Add(Me.botonActualizar)
        Me.panelFiltro.Controls.Add(Me.checkFiltroFecha)
        Me.panelFiltro.Controls.Add(Me.dtpFechaFinal)
        Me.panelFiltro.Controls.Add(Me.dtpFechaInicial)
        Me.panelFiltro.Dock = System.Windows.Forms.DockStyle.Top
        Me.panelFiltro.Location = New System.Drawing.Point(0, 0)
        Me.panelFiltro.Margin = New System.Windows.Forms.Padding(2)
        Me.panelFiltro.Name = "panelFiltro"
        Me.panelFiltro.Size = New System.Drawing.Size(972, 38)
        Me.panelFiltro.TabIndex = 4
        '
        'botonActualizar
        '
        Me.botonActualizar.Location = New System.Drawing.Point(474, 9)
        Me.botonActualizar.Margin = New System.Windows.Forms.Padding(2)
        Me.botonActualizar.Name = "botonActualizar"
        Me.botonActualizar.Size = New System.Drawing.Size(110, 24)
        Me.botonActualizar.TabIndex = 3
        Me.botonActualizar.Text = "Update"
        Me.botonActualizar.UseVisualStyleBackColor = True
        '
        'checkFiltroFecha
        '
        Me.checkFiltroFecha.AutoSize = True
        Me.checkFiltroFecha.Checked = True
        Me.checkFiltroFecha.CheckState = System.Windows.Forms.CheckState.Checked
        Me.checkFiltroFecha.Location = New System.Drawing.Point(10, 10)
        Me.checkFiltroFecha.Margin = New System.Windows.Forms.Padding(2)
        Me.checkFiltroFecha.Name = "checkFiltroFecha"
        Me.checkFiltroFecha.Size = New System.Drawing.Size(183, 17)
        Me.checkFiltroFecha.TabIndex = 0
        Me.checkFiltroFecha.Text = "Show Documents between dates"
        Me.checkFiltroFecha.UseVisualStyleBackColor = True
        '
        'dtpFechaFinal
        '
        Me.dtpFechaFinal.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.dtpFechaFinal.Location = New System.Drawing.Point(333, 10)
        Me.dtpFechaFinal.Margin = New System.Windows.Forms.Padding(2)
        Me.dtpFechaFinal.Name = "dtpFechaFinal"
        Me.dtpFechaFinal.Size = New System.Drawing.Size(114, 20)
        Me.dtpFechaFinal.TabIndex = 2
        '
        'dtpFechaInicial
        '
        Me.dtpFechaInicial.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.dtpFechaInicial.Location = New System.Drawing.Point(215, 9)
        Me.dtpFechaInicial.Margin = New System.Windows.Forms.Padding(2)
        Me.dtpFechaInicial.Name = "dtpFechaInicial"
        Me.dtpFechaInicial.Size = New System.Drawing.Size(114, 20)
        Me.dtpFechaInicial.TabIndex = 1
        '
        'BarraTitulo1
        '
        Me.BarraTitulo1.BackColor = System.Drawing.Color.WhiteSmoke
        Me.BarraTitulo1.Dock = System.Windows.Forms.DockStyle.Top
        Me.BarraTitulo1.Location = New System.Drawing.Point(0, 72)
        Me.BarraTitulo1.Margin = New System.Windows.Forms.Padding(4)
        Me.BarraTitulo1.Name = "BarraTitulo1"
        Me.BarraTitulo1.Size = New System.Drawing.Size(972, 30)
        Me.BarraTitulo1.TabIndex = 1
        '
        'Encabezado1
        '
        Me.Encabezado1.Dock = System.Windows.Forms.DockStyle.Top
        Me.Encabezado1.Location = New System.Drawing.Point(0, 0)
        Me.Encabezado1.Margin = New System.Windows.Forms.Padding(4)
        Me.Encabezado1.Name = "Encabezado1"
        Me.Encabezado1.Size = New System.Drawing.Size(972, 72)
        Me.Encabezado1.TabIndex = 0
        '
        'frmCartaCreditoNet
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(972, 557)
        Me.Controls.Add(Me.PanelLista)
        Me.Controls.Add(Me.panelDocumento)
        Me.Controls.Add(Me.BarraTitulo1)
        Me.Controls.Add(Me.Encabezado1)
        Me.Name = "frmCartaCreditoNet"
        Me.Text = "frmCartaCreditoNet"
        Me.panelDocumento.ResumeLayout(False)
        Me.panelReceipt.ResumeLayout(False)
        Me.panelReceipt.PerformLayout()
        CType(Me.dgCargoReceipt, System.ComponentModel.ISupportInitialize).EndInit()
        Me.panelDetalle.ResumeLayout(False)
        CType(Me.dgDetalle, System.ComponentModel.ISupportInitialize).EndInit()
        Me.PanelControles.ResumeLayout(False)
        Me.panelEncabezado.ResumeLayout(False)
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        Me.panelPO.ResumeLayout(False)
        Me.panelPO.PerformLayout()
        Me.PanelLista.ResumeLayout(False)
        CType(Me.dgLista, System.ComponentModel.ISupportInitialize).EndInit()
        Me.panelFiltro.ResumeLayout(False)
        Me.panelFiltro.PerformLayout()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents Encabezado1 As encabezado
    Friend WithEvents BarraTitulo1 As BarraTitulo
    Friend WithEvents panelDocumento As Panel
    Friend WithEvents panelEncabezado As Panel
    Friend WithEvents Panel1 As Panel
    Friend WithEvents etiquetaAño As Label
    Friend WithEvents celdaAño As TextBox
    Friend WithEvents panelPO As Panel
    Friend WithEvents celdaTasa As TextBox
    Friend WithEvents etiquetaTasa As Label
    Friend WithEvents botonMoneda As Button
    Friend WithEvents celdaMoneda As TextBox
    Friend WithEvents etiquetaMoneda As Label
    Friend WithEvents celdaTotal As TextBox
    Friend WithEvents etiquetaMonto As Label
    Friend WithEvents celdaNit As TextBox
    Friend WithEvents etiquetaNit As Label
    Friend WithEvents botonCliente As Button
    Friend WithEvents celdaCliente As TextBox
    Friend WithEvents etiquetaCliente As Label
    Friend WithEvents dtpFecha As DateTimePicker
    Friend WithEvents etiquetaFecha As Label
    Friend WithEvents etiquetaNumero As Label
    Friend WithEvents celdaNumero As TextBox
    Friend WithEvents celdaPO As TextBox
    Friend WithEvents panelDetalle As Panel
    Friend WithEvents celdaComentario As TextBox
    Friend WithEvents etiquetaComentario As Label
    Friend WithEvents etiquetaFechaExpiracion As Label
    Friend WithEvents etiquetaPO As Label
    Friend WithEvents dtpFechaExpiracion As DateTimePicker
    Friend WithEvents dgDetalle As DataGridView
    Friend WithEvents panelReceipt As Panel
    Friend WithEvents dgCargoReceipt As DataGridView
    Friend WithEvents celdaDrawee As TextBox
    Friend WithEvents etiquetaDrawee As Label
    Friend WithEvents PanelControles As Panel
    Friend WithEvents botonEliminar As Button
    Friend WithEvents botonAgregar As Button
    Friend WithEvents celdaidCliente As TextBox
    Friend WithEvents celdaidMoneda As TextBox
    Friend WithEvents celdaDireccion As TextBox
    Friend WithEvents etiquetaDireccion As Label
    Friend WithEvents colNumCargo As DataGridViewTextBoxColumn
    Friend WithEvents colMonto As DataGridViewTextBoxColumn
    Friend WithEvents colNumYRM As DataGridViewTextBoxColumn
    Friend WithEvents checkActive As System.Windows.Forms.CheckBox
    Friend WithEvents PanelLista As Panel
    Friend WithEvents dgLista As DataGridView
    Friend WithEvents panelFiltro As Panel
    Friend WithEvents botonActualizar As Button
    Friend WithEvents checkFiltroFecha As System.Windows.Forms.CheckBox
    Friend WithEvents dtpFechaFinal As DateTimePicker
    Friend WithEvents dtpFechaInicial As DateTimePicker
    Friend WithEvents colNumero As DataGridViewTextBoxColumn
    Friend WithEvents colLin As DataGridViewTextBoxColumn
    Friend WithEvents colCantidad As DataGridViewTextBoxColumn
    Friend WithEvents colidMedida As DataGridViewTextBoxColumn
    Friend WithEvents colMedida As DataGridViewTextBoxColumn
    Friend WithEvents colTotal As DataGridViewTextBoxColumn
    Friend WithEvents colPresentacion As DataGridViewTextBoxColumn
    Friend WithEvents colPago As DataGridViewTextBoxColumn
    Friend WithEvents colCatalogo As DataGridViewTextBoxColumn
    Friend WithEvents colAnio As DataGridViewTextBoxColumn
    Friend WithEvents colNum As DataGridViewTextBoxColumn
    Friend WithEvents colLinea As DataGridViewTextBoxColumn
    Friend WithEvents colEstado As DataGridViewTextBoxColumn
    Friend WithEvents celdaLC As TextBox
    Friend WithEvents etiquetaLC As Label
    Friend WithEvents Label1 As Label
    Friend WithEvents celdaTotalYRM As TextBox
    Friend WithEvents colCodigo1 As DataGridViewTextBoxColumn
    Friend WithEvents colAño As DataGridViewTextBoxColumn
    Friend WithEvents colFecha As DataGridViewTextBoxColumn
    Friend WithEvents colCliente As DataGridViewTextBoxColumn
    Friend WithEvents colLC As DataGridViewTextBoxColumn
    Friend WithEvents colName As DataGridViewTextBoxColumn
    Friend WithEvents colEstado2 As DataGridViewTextBoxColumn
End Class
