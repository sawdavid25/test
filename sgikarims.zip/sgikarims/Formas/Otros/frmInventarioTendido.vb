﻿Public Class frmInventarioTendido

#Region "Funciones y Procedimientos"
    Private Function SqlInventario() As String
        Dim strSQl As String = STR_VACIO
        Try
            strSQl = " select m.parcat  catalogo, m.parano ano, m.parnum numero, m.parlin linea,m.fecha fecha , sum(m.entrada) entrada , sum(m.salida) salida, (sum(m.entrada)  - sum(m.salida ))inventario , m.tipo , "
            strSQl &= "  (select (sum(b.BDoc_Box_QTY) - ifnull(  "
            strSQl &= "     (select sum(bb.BDoc_Box_QTY)  from Dcmtos_DTL_Pro p "
            strSQl &= "         left join Dcmtos_DTL_Box bb on bb.BDoc_Sis_Emp = p.PDoc_Sis_Emp and bb.BDoc_Doc_Cat = p.PDoc_Chi_Cat and bb.BDoc_Doc_Ano = p.PDoc_Chi_Ano and bb.BDoc_Doc_Num = p.PDoc_Chi_Num and bb.BDoc_Doc_Lin = p.PDoc_Chi_Lin "
            strSQl &= "       where p.PDoc_Sis_Emp = b.BDoc_Sis_Emp and p.PDoc_Par_Cat = b.BDoc_Doc_Cat and p.PDoc_Par_Ano = b.BDoc_Doc_Ano and p.PDoc_Par_Num = b.BDoc_Doc_Num and p.PDoc_Par_Lin = b.BDoc_Doc_Lin),0))   "
            strSQl &= "   from Dcmtos_DTL_Box b "
            strSQl &= "   where b.BDoc_Sis_Emp = m.empresa and b.BDoc_Doc_Cat = m.parcat and b.BDoc_Doc_Ano = m.parano and b.BDoc_Doc_Num = m.parnum and b.BDoc_Doc_Lin = m.parlin) bultos, d.DDoc_Prd_Des descripcion, h.HDoc_DR1_Num referencia , c.cat_clave medida , concat(m.parano, m.parnum , m.parlin  ) llave, d.DDoc_Prd_NET precio "
            strSQl &= " from Movimientos_Inventario m  "
            strSQl &= "  left join Dcmtos_DTL d on d.DDoc_Sis_Emp = m.empresa and d.DDoc_Doc_Cat = m.parcat and d.DDoc_Doc_Ano = m.parano and d.DDoc_Doc_Num = m.parnum and d.DDoc_Doc_Lin = m.parlin  "
            strSQl &= "  left join Dcmtos_HDR h on h.HDoc_Sis_Emp = d.DDoc_Sis_Emp and h.HDoc_Doc_Cat = d.DDoc_Doc_Cat and h.HDoc_Doc_Ano = d.DDoc_Doc_Ano and h.HDoc_Doc_Num = d.DDoc_Doc_Num 	 "
            strSQl &= "  	left join Catalogos c on c.cat_num = d.DDoc_Prd_UM "
            strSQl &= "  where m.tipo = 0  "
            strSQl &= "  group by m.parcat , m.parano , m.parnum , m.parlin   "
            strSQl &= "  having inventario >=1 and referencia like '%{referencia}%'  "

            strSQl = Replace(strSQl, "{referencia}", celdaReferencia.Text)


        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        Return strSQl
    End Function

    Private Sub CargarLista()
        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader
        Dim strFila As String = STR_VACIO
        Dim strSQL As String = STR_VACIO
        Try
            strSQL = SqlInventario()
            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSQL, CON)
            REA = COM.ExecuteReader
            dgLista.Rows.Clear()
            If REA.HasRows Then
                Do While REA.Read
                    strFila = REA.GetInt32("ano") & "|"
                    strFila &= REA.GetInt32("numero") & "|"
                    strFila &= REA.GetInt32("linea") & "|"
                    strFila &= "0" & "|"
                    strFila &= REA.GetString("descripcion") & "|"
                    strFila &= REA.GetString("referencia") & "|"
                    strFila &= REA.GetString("medida") & "|"
                    strFila &= REA.GetInt32("bultos") & "|"
                    strFila &= REA.GetDouble("inventario") & "|"
                    strFila &= REA.GetDouble("precio") & "|"

                    strFila &= "0" & "|"
                    strFila &= "0" & "|"
                    strFila &= REA.GetString("llave")

                    cFunciones.AgregarFila(dgLista, strFila)
                Loop
            End If
            'For i As Integer = 0 To dg.Rows.Count - 1

            'Next

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub
#End Region

    Private Sub botonAceptar_Click(sender As Object, e As EventArgs) Handles botonAceptar.Click
        Me.DialogResult = System.Windows.Forms.DialogResult.OK
    End Sub

    Private Sub botonCancelar_Click(sender As Object, e As EventArgs) Handles botonCancelar.Click
        Me.DialogResult = System.Windows.Forms.DialogResult.Cancel
    End Sub

    Private Sub botonRefrescar_Click(sender As Object, e As EventArgs) Handles botonRefrescar.Click
        CargarLista()
    End Sub

    Private Sub celdaReferencia_KeyDown(sender As Object, e As KeyEventArgs) Handles celdaReferencia.KeyDown
        If e.KeyCode = Keys.Enter Then
            CargarLista()
            dgLista.Focus()
            e.Handled = True
            e.SuppressKeyPress = True
        End If
    End Sub
End Class