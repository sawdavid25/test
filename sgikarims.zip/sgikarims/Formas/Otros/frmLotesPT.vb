﻿Public Class frmLotesPT

#Region "Variables"
    Dim strKey As String = STR_VACIO
    Dim Proceso As Integer
    Dim CodigosMat As String = STR_VACIO
    Dim logInsertar As Boolean = False
    Dim logConsultar As Boolean = False
    Dim logEditar As Boolean = False
    Dim LogBorrar As Boolean = False
    Const cat_num As Integer = 737
    Dim cfun As New clsFunciones
    Dim intTipoDoc As Integer
    Dim NotaDev As String
    Dim VerOpcion As Integer
    Dim varPromedioCosto As Double = 0
    Dim Tbl_Documentos As String = "Dcmtos_HDR"
#End Region
#Region "Propiedades"
    Public Property Key As String
        Get
            Return strKey
        End Get
        Set(value As String)
            strKey = value
        End Set
    End Property
#End Region
#Region "Procedimientos"
    Private Function SQLListaPrincipal()
        Dim strSQL As String = STR_VACIO

        'strSQL = " Select 
        '            h.HDoc_Sis_Emp Empresa, 
        '            h.HDoc_Doc_Cat Catalogo, 
        '            h.HDoc_Doc_Ano Anio, 
        '            h.HDoc_Doc_Num Numero, 
        '            1 as Linea,
        '            h.HDoc_DR1_Num NumeroLote, 
        '            h.HDoc_Doc_Fec fecha, 
        '            10 pesoBruto,
        '            11 pesoNeto,
        '            (SELECT a.art_DCorta Descripcion FROM articulos a WHERE a.art_codigo=h.HDoc_Emp_Cod ) producto, 
        '            h.HDoc_Doc_Status estatus "
        'strSQL &= "     From Dcmtos_HDR h"
        'strSQL &= "         Where h.HDoc_Sis_Emp= {empresa} AND h.HDoc_Doc_Cat = 737 "


        strSQL = "SELECT 
	                    h.HDoc_Sis_Emp, h.HDoc_Doc_Cat catalogo, h.HDoc_Doc_Ano Anio, h.HDoc_Doc_Num numero, h.HDoc_Doc_Fec fecha, h.HDoc_DR1_Num numeroLote
	                    ,h.HDoc_RF1_Dbl poID
	                    ,(SELECT hh.HDoc_Doc_Ano YEAR
		                    FROM  Dcmtos_HDR hh 
		                    WHERE hh.HDoc_Sis_Emp = 15 And hh.HDoc_Doc_Cat = 980 AND hh.HDoc_Doc_Ano=h.HDoc_RF3_Dbl AND hh.HDoc_Doc_Num=h.HDoc_RF1_Dbl) poIdAno
                       ,(SELECT hh.HDoc_DR1_Num Reference
		                    FROM  Dcmtos_HDR hh 
		                    WHERE hh.HDoc_Sis_Emp = 15 And hh.HDoc_Doc_Cat = 980 AND hh.HDoc_Doc_Ano=h.HDoc_RF3_Dbl AND hh.HDoc_Doc_Num=h.HDoc_RF1_Dbl) po
	                    ,h.HDoc_DR1_Cat colorConoID
	                    ,cc.cat_desc colorCono
	                    ,h.HDoc_DR1_Dbl tara
	                    ,h.HDoc_DR1_Emp colorEtiquetaID
	                    ,ce.cat_desc colorEtiqueta
	                    ,h.HDoc_DR2_Cat FrameID
	                    ,f.cat_desc Frame
	                    ,h.HDoc_RF2_Dbl RollosCaja
	                    ,h.HDoc_RF2_Num correlativo
	                    ,h.HDoc_DR2_Emp empacadorId
	                    ,e.cat_desc empacador
	                    ,h.HDoc_RF1_Num tipoLoteId
	                    ,tl.cat_desc tipoLote
	                    ,h.HDoc_Emp_Cod ProductoId
	                    ,(SELECT a.art_DCorta Descripcion FROM Articulos a LEFT JOIN Inventarios i ON i.inv_sisemp = a.art_sisemp AND i.inv_artcodigo= a.art_codigo WHERE i.inv_numero=h.HDoc_Emp_Cod ) producto
                    FROM Dcmtos_HDR h  
                    LEFT JOIN Catalogos_lotes cc ON cc.cat_num = h.HDoc_DR1_Cat AND cc.cat_clase='ColorCono'
                    LEFT JOIN Catalogos_lotes ce ON ce.cat_num = h.HDoc_DR1_Emp AND ce.cat_clase='ColorEtiqueta'
                    LEFT JOIN Catalogos_lotes f ON f.cat_num = h.HDoc_DR2_Cat AND f.cat_clase='Frame'
                    LEFT JOIN Catalogos_lotes e ON e.cat_num = h.HDoc_DR2_Emp AND e.cat_clase='Empacador'
                    LEFT JOIN Catalogos_lotes tl ON tl.cat_num = h.HDoc_RF1_Num AND tl.cat_clase='TipoLote'             
                    WHERE h.HDoc_Sis_Emp = {empresa} AND h.HDoc_Doc_Cat = 737"

        If checkFecha.Checked = True Then

            strSQL &= " AND (h.HDoc_Doc_Fec BETWEEN '{fechainicio}' AND '{fechafin}') "

            strSQL = Replace(strSQL, "{fechainicio}", dtpInicio.Value.ToString(FORMATO_MYSQL))
            strSQL = Replace(strSQL, "{fechafin}", dtpFin.Value.ToString(FORMATO_MYSQL))

        End If

        strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
        ' strSQL = Replace(strSQL, "{NumProceso}", NumProceso)

        Return strSQL
    End Function
    Public Sub ListaPrincipal()
        Dim strSQL As String = STR_VACIO
        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader
        Dim strFila As String = STR_VACIO

        strSQL = SQLListaPrincipal()

        Try
            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSQL, CON)
            REA = COM.ExecuteReader
            dgLista.Rows.Clear()
            If REA.HasRows Then
                Do While REA.Read
                    strFila = REA.GetInt32("Catalogo") & "|"
                    strFila &= REA.GetInt32("Anio") & "|"
                    strFila &= REA.GetInt32("Numero") & "|"
                    strFila &= REA.GetString("NumeroLote") & "|"
                    strFila &= REA.GetDateTime("fecha") & "|"
                    strFila &= REA.GetString("colorCono") & "|"
                    strFila &= REA.GetString("Producto") & "|"
                    strFila &= REA.GetString("colorEtiqueta") & "|"
                    strFila &= REA.GetString("Frame") & "|"
                    strFila &= REA.GetString("RollosCaja") & "|"
                    strFila &= REA.GetString("tipoLote")


                    cFunciones.AgregarFila(dgLista, strFila)
                Loop
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub
    Private Sub MostrarLista(Optional ByVal logMostrar As Boolean = True, Optional logInsert As Boolean = True)
        'Muestra Lista Principal
        If logMostrar = True Then
            panelListaPrincipal.Visible = True
            panelListaPrincipal.Dock = DockStyle.Fill
            panelDocumento.Visible = False
            panelDocumento.Dock = DockStyle.None
            BarraTitulo1.CambiarTitulo("Lotes de Produccion")
            Encabezado1.botonBorrar.Enabled = False
            Encabezado1.botonGuardar.Enabled = False

            ListaPrincipal()

        Else
            'Muestra Detalle
            panelListaPrincipal.Visible = False
            panelListaPrincipal.Dock = DockStyle.None
            panelDocumento.Visible = True
            panelDocumento.Dock = DockStyle.Fill

            'Verifica si se va a crear un nuevo documento o se va modificar
            If logInsert = False Then
                BarraTitulo1.CambiarTitulo("Modify Registration")
                Me.Tag = "Mod"
                BloquearBotones(False)
            Else
                BarraTitulo1.CambiarTitulo("New Register")
                Me.Tag = "Nuevo"
                BloquearBotones(False)
            End If

        End If

    End Sub
    Private Sub BloquearBotones(Optional ByVal logBloquear As Boolean = True)
        If logBloquear = True Then
            Encabezado1.botonBorrar.Enabled = False
            Encabezado1.botonGuardar.Enabled = False
        Else
            Encabezado1.botonBorrar.Enabled = True
            Encabezado1.botonGuardar.Enabled = True
        End If
    End Sub
    Private Sub Accesos()
        Dim cAcesos As New clsAccesos
        Try
            If cAcesos.Accesos(strKey) = True Then
                logInsertar = cAcesos.Insertar
                logEditar = cAcesos.Editar
                LogBorrar = cAcesos.Borrar
                logConsultar = cAcesos.Consultar
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub
    Private Sub Reset()
        dtpFecha.Value = Today
        dgDetalle.Rows.Clear()

        celdaAnio.Text = cFunciones.AñoMySQL
        celdaNumero.Text = STR_VACIO
        celdaNumeroLote.Text = STR_VACIO
        celdaCorrelativo.Text = 1
        celdaRollosCaja.Text = STR_VACIO
        celdaTara.Text = STR_VACIO
        celdaidAnoPO.Text = STR_VACIO
        celdaPO.Text = STR_VACIO

        celdaIdColorCono.Text = NO_FILA
        celdaIdEmpacador.Text = NO_FILA
        celdaIdColorEtiqueta.Text = NO_FILA
        celdaIdFrame.Text = NO_FILA
        celdaIdPO.Text = NO_FILA
        celdaIdTipoLote.Text = NO_FILA

        celdaColorCono.Text = STR_VACIO
        celdaEmpacador.Text = STR_VACIO
        celdaEtiquetaColor.Text = STR_VACIO
        celdaFrame.Text = STR_VACIO
        celdaPO.Text = STR_VACIO
        celdaTipoLote.Text = STR_VACIO

        celdaIdEmbalaje.Text = STR_VACIO
        celdaEmbalaje.Text = STR_VACIO


    End Sub
    Private Function ComprobarCampos() As Boolean
        Dim Comprobar As Boolean = True
        Dim i As Integer = 0
        Try
            If celdaIdPO.Text = NO_FILA Then
                MsgBox("Seleccione PO", vbCritical)
                Comprobar = False
                Exit Function
            End If
            If celdaIdColorCono.Text = NO_FILA Then
                MsgBox("Seleccione Color de Cono", vbCritical)
                Comprobar = False
                Exit Function
            End If
            If celdaIdColorEtiqueta.Text = NO_FILA Then
                MsgBox("Seleccione Color de Etiqueta", vbCritical)
                Comprobar = False
                Exit Function
            End If
            If celdaIdFrame.Text = NO_FILA Then
                MsgBox("Seleccione Frame", vbCritical)
                Comprobar = False
                Exit Function
            End If
            If celdaIdEmpacador.Text = NO_FILA Then
                MsgBox("Seleccione Empacador", vbCritical)
                Comprobar = False
                Exit Function
            End If
            If celdaIdTipoLote.Text = NO_FILA Then
                MsgBox("Seleccione Tipo de Lote", vbCritical)
                Comprobar = False
                Exit Function
            End If
            'If cFunciones.ValidarCampoNumerico(celdaNumeroLote) = False Then
            If celdaNumeroLote.Text = STR_VACIO Then
                Return False
                Exit Function
            End If
            If celdaTara.Text = STR_VACIO Or cFunciones.ValidarCampoNumerico(celdaTara) = False Then
                MsgBox("Ingrese Tara", vbCritical)
                Comprobar = False
                Exit Function
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        Return Comprobar
    End Function
    Private Function GuardarEncabezado() As Boolean
        Dim CHDR As New clsDcmtos_HDR
        Dim logResultado As Boolean = True
        Try

            CHDR.HDOC_SIS_EMP = Sesion.IdEmpresa
            CHDR.HDOC_DOC_CAT = cat_num
            CHDR.HDOC_DOC_ANO = celdaAnio.Text
            CHDR.HDoc_Doc_Fec_NET = dtpFecha.Value
            CHDR.HDOC_DR1_NUM = celdaNumeroLote.Text
            CHDR.HDOC_RF1_DBL = celdaIdPO.Text
            CHDR.HDOC_RF3_DBL = celdaidAnoPO.Text
            CHDR.HDOC_DR1_CAT = celdaIdColorCono.Text
            CHDR.HDOC_DR1_DBL = celdaTara.Text
            CHDR.HDOC_DR1_EMP = celdaIdColorEtiqueta.Text
            CHDR.HDOC_DR2_CAT = celdaIdFrame.Text
            CHDR.HDOC_RF2_DBL = celdaRollosCaja.Text
            CHDR.HDOC_RF2_NUM = celdaCorrelativo.Text
            CHDR.HDOC_DR2_EMP = celdaIdEmpacador.Text
            CHDR.HDOC_RF1_NUM = celdaIdTipoLote.Text
            CHDR.HDOC_EMP_COD = celdaIdProducto.Text
            CHDR.HDOC_RF2_TXT = celdaNumeroLote.Text    ''IDLOTE
            CHDR.HDOC_DR2_NUM = celdaIdEmbalaje.Text    'ID TIPO EMBAJALE - TABLA: CATALOGO_LOTES, clave Embajale

            CHDR.HDOC_DOC_STATUS = IIf(checkActivar.Checked = True, 1, vbEmpty)
            CHDR.CONEXION = strConexion
            If Me.Tag = "Nuevo" Then
                celdaNumero.Text = cFunciones.NuevoId(cat_num)
                CHDR.HDOC_DOC_NUM = celdaNumero.Text
                If CHDR.Guardar = False Then
                    logResultado = False
                    MsgBox(CHDR.MERROR.ToString)
                Else
                    logResultado = True
                End If
            Else
                CHDR.HDOC_DOC_NUM = celdaNumero.Text
                If CHDR.Actualizar = False Then
                    logResultado = False
                    MsgBox(CHDR.MERROR.ToString)
                Else
                    logResultado = True
                End If
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        Return logResultado
    End Function
    Private Function GuardarEncabezadoCajas() As Boolean
        Dim CHDR As New clsDcmtos_HDR
        Dim logResultado As Boolean = True
        Try

            CHDR.HDOC_SIS_EMP = Sesion.IdEmpresa
            CHDR.HDOC_DOC_CAT = 776
            CHDR.HDOC_DOC_ANO = celdaAnio.Text
            CHDR.HDoc_Doc_Fec_NET = dtpFecha.Value
            CHDR.HDOC_DR1_NUM = celdaNumeroLote.Text
            CHDR.HDOC_RF1_DBL = celdaIdPO.Text
            CHDR.HDOC_RF3_DBL = celdaidAnoPO.Text
            CHDR.HDOC_DR1_CAT = celdaIdColorCono.Text
            CHDR.HDOC_DR1_DBL = celdaTara.Text
            CHDR.HDOC_DR1_EMP = celdaIdColorEtiqueta.Text
            CHDR.HDOC_DR2_CAT = celdaIdFrame.Text
            CHDR.HDOC_RF2_DBL = celdaRollosCaja.Text
            CHDR.HDOC_RF2_NUM = celdaCorrelativo.Text
            CHDR.HDOC_DR2_EMP = celdaIdEmpacador.Text
            CHDR.HDOC_RF1_NUM = celdaIdTipoLote.Text
            CHDR.HDOC_EMP_COD = celdaIdProducto.Text
            CHDR.HDOC_RF1_TXT = 1

            CHDR.HDOC_RF2_COD = celdaAnio.Text
            CHDR.HDOC_RF2_TXT = celdaNumero.Text    ''IDLOTE
            CHDR.HDOC_DR2_NUM = celdaIdEmbalaje.Text    'ID TIPO EMBAJALE - TABLA: CATALOGO_LOTES, clave Embajale

            CHDR.HDOC_DOC_STATUS = IIf(checkActivar.Checked = True, 1, vbEmpty)
            CHDR.CONEXION = strConexion
            If Me.Tag = "Nuevo" Then
                CHDR.HDOC_DOC_NUM = celdaNumero.Text
                If CHDR.Guardar = False Then
                    logResultado = False
                    MsgBox(CHDR.MERROR.ToString)
                Else
                    logResultado = True
                End If
            Else
                CHDR.HDOC_DOC_NUM = celdaNumero.Text
                If CHDR.Actualizar = False Then
                    logResultado = False
                    MsgBox(CHDR.MERROR.ToString)
                Else
                    logResultado = True
                End If
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        Return logResultado
    End Function
    Private Function ActualizarEncabezadoCaja() As Boolean
        Dim CHDR As New clsDcmtos_HDR
        Dim COM As MySqlCommand
        Dim StrSQL As String
        Try
            StrSQL = "UPDATE Dcmtos_HDR SET 
             HDOC_DR1_NUM = '" & celdaNumeroLote.Text & "'" &
            ", HDOC_RF1_DBL = " & celdaIdPO.Text &
            ", HDOC_RF3_DBL = " & celdaidAnoPO.Text &
            ", HDOC_DR1_CAT = " & celdaIdColorCono.Text &
            ", HDOC_DR1_DBL = " & celdaTara.Text &
            ", HDOC_DR1_EMP = " & celdaIdColorEtiqueta.Text &
            ", HDOC_DR2_CAT = " & celdaIdFrame.Text &
            ", HDOC_RF2_DBL = " & celdaRollosCaja.Text &
            ", HDOC_RF2_NUM = " & celdaCorrelativo.Text &
            ", HDOC_DR2_EMP = " & celdaIdEmpacador.Text &
            ", HDOC_RF1_NUM = " & celdaIdTipoLote.Text &
            ", HDOC_EMP_COD = " & celdaIdProducto.Text &
            ", HDOC_DR2_NUM = " & celdaIdEmbalaje.Text &
            " WHERE HDoc_Sis_Emp = " & Sesion.IdEmpresa & " AND HDoc_Doc_Cat = 776 AND HDOC_RF2_COD = " & celdaAnio.Text & " AND  HDOC_RF2_TXT = " & celdaNumero.Text

            If Sesion.IdEmpresa = 18 Then

                StrSQL &= ";UPDATE PDM.Dcmtos_HDR SET 
             HDOC_DR1_NUM = '" & celdaNumeroLote.Text & "'" &
            ", HDOC_RF1_DBL = " & celdaIdPO.Text &
            ", HDOC_RF3_DBL = " & celdaidAnoPO.Text &
            ", HDOC_DR1_CAT = " & celdaIdColorCono.Text &
            ", HDOC_DR1_DBL = " & celdaTara.Text &
            ", HDOC_DR1_EMP = " & celdaIdColorEtiqueta.Text &
            ", HDOC_DR2_CAT = " & celdaIdFrame.Text &
            ", HDOC_RF2_DBL = " & celdaRollosCaja.Text &
            ", HDOC_RF2_NUM = " & celdaCorrelativo.Text &
            ", HDOC_DR2_EMP = " & celdaIdEmpacador.Text &
            ", HDOC_RF1_NUM = " & celdaIdTipoLote.Text &
            ", HDOC_EMP_COD = " & celdaIdProducto.Text &
            ", HDOC_DR2_NUM = " & celdaIdEmbalaje.Text &
            " WHERE HDoc_Sis_Emp = " & Sesion.IdEmpresa & " AND HDoc_Doc_Cat = 776 AND HDOC_RF2_COD = " & celdaAnio.Text & " AND  HDOC_RF2_TXT = " & celdaNumero.Text

            End If

            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(StrSQL, CON)
            COM.ExecuteNonQuery()
            Return True
        Catch ex As Exception
            MsgBox(ex.ToString)
            Return False
        End Try
    End Function
    Private Function SQLEncabezado(ByVal Anio As Integer, ByVal Num As Integer) As String
        Dim strSQL As String = STR_VACIO
        Try
            strSQL = "SELECT 
	                    h.HDoc_Sis_Emp, h.HDoc_Doc_Cat, h.HDoc_Doc_Ano Anio, h.HDoc_Doc_Num numero, h.HDoc_Doc_Fec fecha, h.HDoc_DR1_Num numeroLote
	                    ,h.HDoc_RF1_Dbl poID
	                    ,(SELECT hh.HDoc_Doc_Ano YEAR
		                    FROM  Dcmtos_HDR hh 
		                    WHERE hh.HDoc_Sis_Emp = {empresa} And hh.HDoc_Doc_Cat = 980 AND hh.HDoc_Doc_Ano=h.HDoc_RF3_Dbl AND hh.HDoc_Doc_Num=h.HDoc_RF1_Dbl) poIdAno
                       ,(SELECT hh.HDoc_DR1_Num Reference
		                    FROM  Dcmtos_HDR hh 
		                    WHERE hh.HDoc_Sis_Emp = {empresa} And hh.HDoc_Doc_Cat = 980 AND hh.HDoc_Doc_Ano=h.HDoc_RF3_Dbl AND hh.HDoc_Doc_Num=h.HDoc_RF1_Dbl) po
	                    ,h.HDoc_DR1_Cat colorConoID
                        ,cc.cat_desc colorCono
	                    ,h.HDoc_DR1_Dbl tara
	                    ,h.HDoc_DR1_Emp colorEtiquetaID
	                    ,ce.cat_desc colorEtiqueta
	                    ,h.HDoc_DR2_Cat FrameID
	                    ,f.cat_desc Frame
	                    ,h.HDoc_RF2_Dbl RollosCaja
	                    ,h.HDoc_RF2_Num correlativo
	                    ,h.HDoc_DR2_Emp empacadorId
	                    ,e.cat_desc empacador
	                    ,h.HDoc_RF1_Num tipoLoteId
	                    ,tl.cat_desc tipoLote
	                    ,IFNULL(h.HDoc_DR2_Num,'')  tipoEmbalajeId
	                    ,IFNULL(em.cat_desc,'') tipoEmbalaje
	                    ,h.HDoc_Emp_Cod ProductoId
	                    ,(SELECT a.art_DCorta Descripcion FROM Articulos a LEFT JOIN Inventarios i ON i.inv_sisemp = a.art_sisemp AND i.inv_artcodigo= a.art_codigo WHERE i.inv_numero=h.HDoc_Emp_Cod ) producto
                    FROM Dcmtos_HDR h  
                    LEFT JOIN Catalogos_lotes cc ON cc.cat_num = h.HDoc_DR1_Cat AND cc.cat_clase='ColorCono'
                    LEFT JOIN Catalogos_lotes ce ON ce.cat_num = h.HDoc_DR1_Emp AND ce.cat_clase='ColorEtiqueta'
                    LEFT JOIN Catalogos_lotes f ON f.cat_num = h.HDoc_DR2_Cat AND f.cat_clase='Frame'
                    LEFT JOIN Catalogos_lotes e ON e.cat_num = h.HDoc_DR2_Emp AND e.cat_clase='Empacador'
                    LEFT JOIN Catalogos_lotes tl ON tl.cat_num = h.HDoc_RF1_Num AND tl.cat_clase='TipoLote'
                    LEFT JOIN Catalogos_lotes em ON em.cat_num = h.HDoc_DR2_Num AND em.cat_clase='Embalaje'"
            strSQL &= "             WHERE h.HDoc_Sis_Emp = {empresa} AND h.HDoc_Doc_Cat = " & cat_num & " AND h.HDoc_Doc_Ano = {anio} AND h.HDoc_Doc_Num = {num} "
            strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
            strSQL = Replace(strSQL, "{anio}", Anio)
            strSQL = Replace(strSQL, "{num}", Num)
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        Return strSQL
    End Function
    Public Sub CargarEncabezado(ByVal Anio As Integer, ByVal Num As Integer)
        Dim strSQL As String = STR_VACIO
        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader

        strSQL = SQLEncabezado(Anio, Num)
        MyCnn.CONECTAR = strConexion
        COM = New MySqlCommand(strSQL, CON)
        REA = COM.ExecuteReader
        If REA.HasRows Then
            Do While REA.Read
                celdaAnio.Text = REA.GetInt32("Anio")
                celdaNumero.Text = REA.GetInt32("Numero")
                dtpFecha.Value = REA.GetDateTime("Fecha")
                celdaNumeroLote.Text = REA.GetString("NumeroLote")
                celdaIdPO.Text = REA.GetInt32("poId")
                celdaidAnoPO.Text = REA.GetInt32("poIdAno")
                celdaPO.Text = REA.GetString("po")
                celdaIdColorCono.Text = REA.GetInt32("colorConoID")
                celdaColorCono.Text = REA.GetString("colorCono")
                celdaTara.Text = REA.GetDouble("Tara")
                celdaIdColorEtiqueta.Text = REA.GetInt32("colorEtiquetaID")
                celdaEtiquetaColor.Text = REA.GetString("colorEtiqueta")
                celdaIdFrame.Text = REA.GetInt32("FrameID")
                celdaFrame.Text = REA.GetString("Frame")
                celdaRollosCaja.Text = REA.GetInt32("RollosCaja")
                celdaCorrelativo.Text = REA.GetInt32("correlativo")
                celdaIdEmpacador.Text = REA.GetInt32("empacadorId")
                celdaEmpacador.Text = REA.GetString("empacador")
                celdaIdTipoLote.Text = REA.GetInt32("tipoLoteId")
                celdaTipoLote.Text = REA.GetString("tipoLote")
                celdaIdProducto.Text = REA.GetInt32("ProductoId")
                celdaProducto.Text = REA.GetString("Producto")
                celdaIdEmbalaje.Text = REA.GetString("tipoEmbalajeId")
                celdaEmbalaje.Text = REA.GetString("tipoEmbalaje")
            Loop
        End If

    End Sub
    'Borrar Encabezado Ingreso
    Public Function BorrarEncabezado() As Boolean
        Dim logGuardar As Boolean
        Try
            Dim hdr As New clsDcmtos_HDR
            hdr.CONEXION = strConexion
            hdr.HDOC_SIS_EMP = Sesion.IdEmpresa
            hdr.HDOC_DOC_CAT = cat_num
            hdr.HDOC_DOC_ANO = celdaAnio.Text
            hdr.HDOC_DOC_NUM = celdaNumero.Text
            hdr.Borrar()
            logGuardar = True
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        Return logGuardar
    End Function
    Private Function BorrarDetalle() As Boolean
        Dim logGuardar As Boolean
        Dim strSQL As String = STR_VACIO
        Try
            If LogBorrar = True Then
                strSQL = "DDoc_Sis_Emp = {empresa} AND DDoc_Doc_Cat = " & cat_num & " AND DDoc_Doc_Ano  = {anio}   AND DDoc_Doc_Num  = {numero} ;"
                strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
                strSQL = Replace(strSQL, "{anio}", celdaAnio.Text)
                strSQL = Replace(strSQL, "{numero}", celdaNumero.Text)
                Dim dtl As New clsDcmtos_DTL
                dtl.CONEXION = strConexion
                dtl.Borrar(strSQL)
                logGuardar = True
            Else
                MsgBox("You don't have permission to this access")
                logGuardar = False
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        Return logGuardar
    End Function
    Private Function SQLDetalle(ByVal Anio As Integer, ByVal Num As Integer) As String
        Dim strSQL As String = STR_VACIO
        Try
            strSQL = "SELECT 
                        DDoc_Doc_Cat col_catalogo,
                        DDoc_Doc_Ano col_ano, 
                        DDoc_Doc_Num col_numero, 
                        DDoc_Doc_Lin col_linea, 
                        DDoc_RF1_Dbl col_numLote, 
                        DDoc_RF1_Fec col_fecha, 
                        DDoc_RF1_COD col_correlativo, 
                        DDoc_Prd_QTY col_PesoNeto, 
                        DDoc_Prd_COD col_PesoBruto, 
                        1 col_estado
                    FROM Dcmtos_DTL 
                    WHERE DDoc_Doc_Cat= " & cat_num & " AND DDoc_Doc_Ano= " & celdaAnio.Text & " AND DDoc_Doc_Num= " & celdaNumero.Text
            strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        Return strSQL
    End Function
    Public Sub CargarDetalle(ByVal Anio As Integer, ByVal Num As Integer)
        Dim strFila As String = STR_VACIO
        Dim strSQL As String = STR_VACIO
        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader
        Dim sumaCant As Double = 0
        Try
            strSQL = SQLDetalle(Anio, Num)
            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSQL, CON)
            COM.CommandTimeout = 300
            REA = COM.ExecuteReader
            If REA.HasRows Then
                Do While REA.Read
                    sumaCant = INT_CERO
                    strFila = REA.GetInt32("col_catalogo") & "|" 'Anio
                    strFila &= REA.GetInt32("col_ano") & "|" 'Catalogo
                    strFila &= REA.GetInt32("col_numero") & "|" 'Numero
                    strFila &= REA.GetInt32("col_linea") & "|" 'Codigo
                    strFila &= REA.GetInt32("col_numLote") & "|" 'frm.ListaClientes.Rows(i).Cells(6).Value & "|" 'Linea
                    strFila &= REA.GetString("col_fecha") & "|" ' Marca
                    strFila &= REA.GetString("col_correlativo") & "|" ' Descripcion
                    strFila &= REA.GetDouble("col_PesoNeto") & "|" ' Costo
                    strFila &= REA.GetDouble("col_PesoBruto") & "|" ' Precio Estimado
                    strFila &= INT_UNO  'Extra
                    cFunciones.AgregarFila(dgDetalle, strFila)
                Loop
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

#End Region
#Region "Eventos"
    Private Sub frmPedidoProduccionHilo_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Accesos()
        dtpInicio.Value = DateSerial(Year(Date.Now), Month(Date.Now) - 1, 30)
        dtpFin.Value = DateSerial(Year(Date.Now), Month(Date.Now) + 1, vbEmpty)
        MostrarLista()
    End Sub
    Private Sub Encabezado1_ClickNuevo(sender As Object, click As Boolean) Handles Encabezado1.ClickNuevo
        Me.Tag = "Nuevo"
        MostrarLista(False)
        celdaAnio.Text = cfun.AñoMySQL
        Reset()
    End Sub
    Private Sub frmPedidoProduccionHilo_FormClosing(sender As Object, e As FormClosingEventArgs) Handles MyBase.FormClosing
        Fprincipal.BarraDeTareas1.QuitarFormulario(strKey)
    End Sub
    Private Sub Encabezado1_ClickCerrar(sender As Object, click As Boolean) Handles Encabezado1.ClickCerrar
        If panelListaPrincipal.Visible = True Then
            Me.Close()
        ElseIf panelDocumento.Visible = True Then
            MostrarLista()
        End If
    End Sub
    Private Sub botonColorCono_Click(sender As Object, e As EventArgs) Handles botonColorCono.Click
        Dim frm As New frmSeleccionar
        Try
            frm.Titulo = "Color Cono"
            frm.Campos = " cat_num Codigo, cat_desc Descripcion"
            frm.Tabla = " Catalogos_lotes"
            frm.FiltroText = " Ingrese el color de cono"
            frm.Filtro = " cat_desc "
            frm.Condicion = "cat_clase = 'ColorCono'"

            frm.ShowDialog(Me)
            If frm.DialogResult = DialogResult.OK Then
                celdaIdColorCono.Text = frm.LLave
                celdaColorCono.Text = frm.Dato
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub
    Private Sub botonEtiquetaColor_Click(sender As Object, e As EventArgs) Handles botonEtiquetaColor.Click
        Dim frm As New frmSeleccionar
        Try
            frm.Titulo = "Color Etiqueta"
            frm.Campos = " cat_num Codigo, cat_desc Descripcion"
            frm.Tabla = " Catalogos_lotes"
            frm.FiltroText = " Ingrese el color de etiqueta"
            frm.Filtro = " cat_desc "
            frm.Condicion = "cat_clase = 'ColorEtiqueta'"

            frm.ShowDialog(Me)
            If frm.DialogResult = DialogResult.OK Then
                celdaIdColorEtiqueta.Text = frm.LLave
                celdaEtiquetaColor.Text = frm.Dato
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub
    Private Sub botonFrame_Click(sender As Object, e As EventArgs) Handles botonFrame.Click
        Dim frm As New frmSeleccionar
        Try
            frm.Titulo = "Frame"
            frm.Campos = " cat_num Codigo, cat_desc Descripcion"
            frm.Tabla = " Catalogos_lotes"
            frm.FiltroText = " Ingrese Frame"
            frm.Filtro = " cat_desc "
            frm.Condicion = "cat_clase = 'Frame'"

            frm.ShowDialog(Me)
            If frm.DialogResult = DialogResult.OK Then
                celdaIdFrame.Text = frm.LLave
                celdaFrame.Text = frm.Dato
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub
    Private Sub botonEmpacador_Click(sender As Object, e As EventArgs) Handles botonEmpacador.Click
        Dim frm As New frmSeleccionar
        Try
            frm.Titulo = "Empacador"
            frm.Campos = " cat_num Codigo, cat_desc Descripcion, cat_clave Nombre"
            frm.Tabla = " Catalogos_lotes"
            frm.FiltroText = " Ingrese Frame"
            frm.Filtro = " CONCAT(cat_desc, ' ', cat_clave) "
            frm.Condicion = "cat_clase = 'Empacador'"

            frm.ShowDialog(Me)
            If frm.DialogResult = DialogResult.OK Then
                celdaIdEmpacador.Text = frm.LLave
                celdaEmpacador.Text = frm.Dato
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub
    Private Sub botonTipoLote_Click(sender As Object, e As EventArgs) Handles botonTipoLote.Click
        Dim frm As New frmSeleccionar
        Try
            frm.Titulo = "Tipo Lote"
            frm.Campos = " cat_num Codigo, cat_desc Descripcion"
            frm.Tabla = " Catalogos_lotes"
            frm.FiltroText = " Ingrese Frame"
            frm.Filtro = " cat_desc "
            frm.Condicion = "cat_clase = 'TipoLote'"

            frm.ShowDialog(Me)
            If frm.DialogResult = DialogResult.OK Then
                celdaIdTipoLote.Text = frm.LLave
                celdaTipoLote.Text = frm.Dato
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub
    Private Sub botonProducto_Click(sender As Object, e As EventArgs) Handles botonProducto.Click
        Dim frm As New frmSeleccionar
        Dim strSQL As String = STR_VACIO
        Dim strCondicion As String = STR_VACIO
        strCondicion = "i.inv_generico=0  and art_sisemp = {empresa} and i.inv_prodlote = '" & Trim(celdaNumeroLote.Text) & "'"
        strCondicion = Replace(strCondicion, "{empresa}", Sesion.IdEmpresa)
        Try
            frm.Titulo = "Products"
            frm.FiltroText = " Enter The Product description or Lot number To Filter"
            frm.Campos = " i.inv_numero codigo, a.art_DCorta Descripcion, i.inv_prodlote Lote"
            frm.Tabla = "  Articulos a LEFT JOIN Inventarios i ON i.inv_sisemp = a.art_sisemp AND i.inv_artcodigo= a.art_codigo LEFT JOIN Catalogos c ON c.cat_num=a.art_clase and c.cat_ext IN ('Waste', 'Terminado') "
            frm.Filtro = " concat(art_DCorta,'', inv_prodlote) "
            frm.Condicion = strCondicion
            frm.Ordenamiento = "art_DCorta"
            frm.ShowDialog(Me)
            If frm.DialogResult = DialogResult.OK Then
                celdaIdProducto.Text = frm.LLave
                celdaProducto.Text = frm.Dato
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub
    Private Sub botonPO_Click(sender As Object, e As EventArgs) Handles botonPO.Click
        Dim frm As New frmSeleccionar
        Dim fechaInicio As Date
        Try
            fechaInicio = DateTime.Now.AddMonths(-14)
            frm.Titulo = "PO "
            frm.Campos = "  h.HDoc_Doc_Num ID, h.HDoc_Doc_Ano YEAR, h.HDoc_DR1_Num Reference "
            frm.Tabla = "   Dcmtos_HDR h "
            frm.FiltroText = " Enter the number of the PO to Filter"
            frm.Filtro = " Reference "
            frm.Condicion = "h.HDoc_Sis_Emp = " & Sesion.IdEmpresa & " And h.HDoc_Doc_Cat = 980 And HDoc_Doc_Status = 1 "

            frm.ShowDialog(Me)
            If frm.DialogResult = DialogResult.OK Then
                celdaPO.Text = frm.Dato2
                celdaIdPO.Text = frm.LLave
                celdaidAnoPO.Text = frm.Dato
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub
    Private Sub dgLista_KeyDown(sender As Object, e As KeyEventArgs) Handles dgLista.KeyDown
        Try
            If e.KeyCode = Keys.F3 Then
                cFunciones.BuscarenLista(dgLista)
                e.Handled = True
                e.SuppressKeyPress = True
            ElseIf e.KeyCode = Keys.F6 Then
                cFunciones.MostrarDependencias(cat_num, dgLista.SelectedCells(1).Value, dgLista.SelectedCells(2).Value)
            ElseIf e.KeyCode = Keys.F7 Then
                Dim rpt As New clsReportes
                rpt.Historial(dgLista.SelectedCells(2).Value, dgLista.SelectedCells(1).Value, cat_num)
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub
    Private Function NuevoRegistro() As Integer
        Dim strSQL As String = STR_VACIO
        Dim conec As New MySqlConnection
        Dim COM As MySqlCommand
        Dim numero As Integer

        strSQL = " Select IFNULL(MAX(HDR.HDoc_Doc_Num),0)+1 NUMERO  "
        strSQL &= " FROM Dcmtos_HDR HDR"
        strSQL &= " WHERE HDR.HDoc_Sis_Emp = {empresa} And HDR.HDoc_Doc_Cat = {catalogo}  "

        strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
        strSQL = Replace(strSQL, "{catalogo}", cat_num)


        conec = New MySqlConnection(strConexion)
        conec.Open()
        COM = New MySqlCommand(strSQL, conec)
        numero = COM.ExecuteScalar
        conec.Close()
        conec.Dispose()
        conec = Nothing
        System.GC.Collect()
        Return numero
    End Function
    Private Sub Encabezado1_ClickGuardar(sender As Object, click As Boolean) Handles Encabezado1.ClickGuardar

        Dim i As Integer
        Dim clsConta As New clsContabilidad
        Try
            If Me.Tag = "Nuevo" Then
                If ComprobarCampos() = True Then
                    GuardarEncabezado()
                    GuardarEncabezadoCajas()
                    cFunciones.EscribirRegistro(Tbl_Documentos, clsFunciones.AccEnum.acAdd, Sesion.idUsuario, cat_num, celdaAnio.Text, celdaNumero.Text)
                    If MsgBox("Information Saved Successfully", vbInformation, "Notice") = vbOK Then
                        MostrarLista(True)
                    Else
                        Me.Tag = "Mod"
                    End If
                Else
                    MsgBox("Please enter the minimum data to continue", vbExclamation, "Notice")
                    Exit Sub
                End If
            ElseIf Me.Tag = "Mod" Then
                GuardarEncabezado()
                If dgDetalle.RowCount > 0 Then
                    ActualizarEncabezadoCaja()
                End If
                cFunciones.EscribirRegistro(Tbl_Documentos, clsFunciones.AccEnum.acUpdate, Sesion.idUsuario, cat_num, celdaAnio.Text, celdaNumero.Text)
                If MsgBox("Information Saved Successfully", vbInformation, "Notice") = vbOK Then
                    MostrarLista(True)
                End If
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub
    Private Sub botonActualizar_Click(sender As Object, e As EventArgs) Handles botonActualizar.Click
        ListaPrincipal()
    End Sub
    Private Sub dgLista_DoubleClick(sender As Object, e As EventArgs) Handles dgLista.DoubleClick
        Reset()
        Dim intAnio As Integer
        Dim intNumero As Integer
        Dim intCat As Integer
        Try
            If dgLista.Rows.Count = 0 Then Exit Sub
            Me.Tag = "Mod"
            intAnio = dgLista.SelectedCells(1).Value
            intNumero = dgLista.SelectedCells(2).Value
            intCat = dgLista.SelectedCells(0).Value
            CargarEncabezado(intAnio, intNumero)
            CargarDetalle(intAnio, intNumero)
            MostrarLista(False, False)
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub
    Private Sub Encabezado1_ClickBorrar(sender As Object, click As Boolean) Handles Encabezado1.ClickBorrar
        If LogBorrar = True Then
            If MsgBox("Are You sure " & vbCr & vbCr & "¿do you want to delete this document? ", vbQuestion + vbYesNo, "Aviso") = vbYes Then
                BorrarEncabezado()
                BorrarDetalle()
                cFunciones.EscribirRegistro(Tbl_Documentos, clsFunciones.AccEnum.acDelete, Sesion.idUsuario, cat_num, celdaAnio.Text, celdaNumero.Text)
                MsgBox("Delete Complete")
                MostrarLista()
            End If
        Else
            MsgBox("You don't have permission to this access")
        End If
    End Sub

    Private Sub Label1_Click(sender As Object, e As EventArgs) Handles Label1.Click

    End Sub

    Private Sub botonEmbalaje_Click(sender As Object, e As EventArgs) Handles botonEmbalaje.Click
        Dim frm As New frmSeleccionar
        Try
            frm.Titulo = "Embalaje"
            frm.Campos = " cat_num Codigo, cat_desc Descripcion"
            frm.Tabla = " Catalogos_lotes"
            frm.FiltroText = " Ingrese el embalaje"
            frm.Filtro = " cat_desc "
            frm.Condicion = "cat_clase = 'Embalaje'"

            frm.ShowDialog(Me)
            If frm.DialogResult = System.Windows.Forms.DialogResult.OK Then
                celdaIdEmbalaje.Text = frm.LLave
                celdaEmbalaje.Text = frm.Dato
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub
#End Region
End Class