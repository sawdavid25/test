﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class FrmBloqueo
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(FrmBloqueo))
        Me.DgBloqueo = New System.Windows.Forms.DataGridView()
        Me.Encabezado1 = New KARIMs_SGI.encabezado()
        Me.BarraTitulo1 = New KARIMs_SGI.BarraTitulo()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.botonInprimir = New System.Windows.Forms.Button()
        Me.colNumero = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colClase = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colClave = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colDescripcion = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colPais = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colEstado = New System.Windows.Forms.DataGridViewTextBoxColumn()
        CType(Me.DgBloqueo, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Panel1.SuspendLayout()
        Me.SuspendLayout()
        '
        'DgBloqueo
        '
        Me.DgBloqueo.AllowUserToAddRows = False
        Me.DgBloqueo.AllowUserToDeleteRows = False
        Me.DgBloqueo.AllowUserToOrderColumns = True
        Me.DgBloqueo.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells
        Me.DgBloqueo.BackgroundColor = System.Drawing.SystemColors.Control
        Me.DgBloqueo.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DgBloqueo.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.colNumero, Me.colClase, Me.colClave, Me.colDescripcion, Me.colPais, Me.colEstado})
        Me.DgBloqueo.Dock = System.Windows.Forms.DockStyle.Fill
        Me.DgBloqueo.Location = New System.Drawing.Point(0, 0)
        Me.DgBloqueo.MultiSelect = False
        Me.DgBloqueo.Name = "DgBloqueo"
        Me.DgBloqueo.ReadOnly = True
        Me.DgBloqueo.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.DgBloqueo.Size = New System.Drawing.Size(649, 235)
        Me.DgBloqueo.TabIndex = 0
        '
        'Encabezado1
        '
        Me.Encabezado1.Dock = System.Windows.Forms.DockStyle.Top
        Me.Encabezado1.Location = New System.Drawing.Point(0, 0)
        Me.Encabezado1.Name = "Encabezado1"
        Me.Encabezado1.Size = New System.Drawing.Size(649, 72)
        Me.Encabezado1.TabIndex = 3
        '
        'BarraTitulo1
        '
        Me.BarraTitulo1.BackColor = System.Drawing.Color.WhiteSmoke
        Me.BarraTitulo1.Dock = System.Windows.Forms.DockStyle.Top
        Me.BarraTitulo1.Location = New System.Drawing.Point(0, 72)
        Me.BarraTitulo1.Name = "BarraTitulo1"
        Me.BarraTitulo1.Size = New System.Drawing.Size(649, 30)
        Me.BarraTitulo1.TabIndex = 4
        '
        'Panel1
        '
        Me.Panel1.Controls.Add(Me.DgBloqueo)
        Me.Panel1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Panel1.Location = New System.Drawing.Point(0, 102)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(649, 235)
        Me.Panel1.TabIndex = 5
        '
        'botonInprimir
        '
        Me.botonInprimir.Image = CType(resources.GetObject("botonInprimir.Image"), System.Drawing.Image)
        Me.botonInprimir.Location = New System.Drawing.Point(209, 12)
        Me.botonInprimir.Name = "botonInprimir"
        Me.botonInprimir.Size = New System.Drawing.Size(59, 45)
        Me.botonInprimir.TabIndex = 22
        Me.botonInprimir.Text = "Print"
        Me.botonInprimir.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.botonInprimir.UseVisualStyleBackColor = True
        '
        'colNumero
        '
        Me.colNumero.HeaderText = "Codigo"
        Me.colNumero.Name = "colNumero"
        Me.colNumero.ReadOnly = True
        Me.colNumero.Visible = False
        '
        'colClase
        '
        Me.colClase.HeaderText = "Clase"
        Me.colClase.Name = "colClase"
        Me.colClase.ReadOnly = True
        Me.colClase.Visible = False
        '
        'colClave
        '
        Me.colClave.HeaderText = "Clave"
        Me.colClave.Name = "colClave"
        Me.colClave.ReadOnly = True
        '
        'colDescripcion
        '
        Me.colDescripcion.HeaderText = "Descripcion"
        Me.colDescripcion.Name = "colDescripcion"
        Me.colDescripcion.ReadOnly = True
        '
        'colPais
        '
        Me.colPais.HeaderText = "Pais"
        Me.colPais.Name = "colPais"
        Me.colPais.ReadOnly = True
        Me.colPais.Visible = False
        '
        'colEstado
        '
        Me.colEstado.HeaderText = "Estado"
        Me.colEstado.Name = "colEstado"
        Me.colEstado.ReadOnly = True
        '
        'FrmBloqueo
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(649, 337)
        Me.Controls.Add(Me.botonInprimir)
        Me.Controls.Add(Me.Panel1)
        Me.Controls.Add(Me.BarraTitulo1)
        Me.Controls.Add(Me.Encabezado1)
        Me.Name = "FrmBloqueo"
        Me.Text = "FrmBloqueo"
        CType(Me.DgBloqueo, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Panel1.ResumeLayout(False)
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents DgBloqueo As DataGridView
    Friend WithEvents Encabezado1 As encabezado
    Friend WithEvents BarraTitulo1 As BarraTitulo
    Friend WithEvents Panel1 As Panel
    Friend WithEvents botonInprimir As Button
    Friend WithEvents colNumero As DataGridViewTextBoxColumn
    Friend WithEvents colClase As DataGridViewTextBoxColumn
    Friend WithEvents colClave As DataGridViewTextBoxColumn
    Friend WithEvents colDescripcion As DataGridViewTextBoxColumn
    Friend WithEvents colPais As DataGridViewTextBoxColumn
    Friend WithEvents colEstado As DataGridViewTextBoxColumn
End Class
