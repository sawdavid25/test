﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class frmPresupuesto
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.pnlOpciones = New System.Windows.Forms.Panel()
        Me.btnCargar = New System.Windows.Forms.Button()
        Me.BackgroundWorker1 = New System.ComponentModel.BackgroundWorker()
        Me.pnlPrincipal = New System.Windows.Forms.Panel()
        Me.dgwPresupuesto = New System.Windows.Forms.DataGridView()
        Me.pnlFecha = New System.Windows.Forms.Panel()
        Me.lblcentro = New System.Windows.Forms.Label()
        Me.lblCodigo = New System.Windows.Forms.Label()
        Me.btnCentro = New System.Windows.Forms.Button()
        Me.lblCosto = New System.Windows.Forms.Label()
        Me.Mes = New System.Windows.Forms.DateTimePicker()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.DOC_Total0 = New System.Windows.Forms.TextBox()
        Me.DOC_Total1 = New System.Windows.Forms.TextBox()
        Me.DOC_Total2 = New System.Windows.Forms.TextBox()
        Me.DOC_Total3 = New System.Windows.Forms.TextBox()
        Me.pnlBotones = New System.Windows.Forms.Panel()
        Me.gpIdioma = New System.Windows.Forms.GroupBox()
        Me.rbIngles = New System.Windows.Forms.RadioButton()
        Me.rbEspañol = New System.Windows.Forms.RadioButton()
        Me.gpMoneda = New System.Windows.Forms.GroupBox()
        Me.rbDolar = New System.Windows.Forms.RadioButton()
        Me.rbQuetzal = New System.Windows.Forms.RadioButton()
        Me.btnActualizar = New System.Windows.Forms.Button()
        Me.btnPresupuesto = New System.Windows.Forms.Button()
        Me.btnImprimir = New System.Windows.Forms.Button()
        Me.pnlFechas = New System.Windows.Forms.Panel()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.dtpFin = New System.Windows.Forms.DateTimePicker()
        Me.dtpIncio = New System.Windows.Forms.DateTimePicker()
        Me.BarraTitulo1 = New KARIMs_SGI.BarraTitulo()
        Me.Encabezado1 = New KARIMs_SGI.encabezado()
        Me.colCuenta = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Descripcion = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Presupuestos = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Monto = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Diferencia = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.mesgrid = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.pnlOpciones.SuspendLayout()
        Me.pnlPrincipal.SuspendLayout()
        CType(Me.dgwPresupuesto, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.pnlFecha.SuspendLayout()
        Me.Panel1.SuspendLayout()
        Me.pnlBotones.SuspendLayout()
        Me.gpIdioma.SuspendLayout()
        Me.gpMoneda.SuspendLayout()
        Me.pnlFechas.SuspendLayout()
        Me.SuspendLayout()
        '
        'pnlOpciones
        '
        Me.pnlOpciones.Controls.Add(Me.btnCargar)
        Me.pnlOpciones.Dock = System.Windows.Forms.DockStyle.Left
        Me.pnlOpciones.Location = New System.Drawing.Point(0, 49)
        Me.pnlOpciones.Margin = New System.Windows.Forms.Padding(4)
        Me.pnlOpciones.Name = "pnlOpciones"
        Me.pnlOpciones.Size = New System.Drawing.Size(112, 725)
        Me.pnlOpciones.TabIndex = 2
        '
        'btnCargar
        '
        Me.btnCargar.Image = Global.KARIMs_SGI.My.Resources.Resources.Exportar
        Me.btnCargar.ImageAlign = System.Drawing.ContentAlignment.TopCenter
        Me.btnCargar.Location = New System.Drawing.Point(15, 59)
        Me.btnCargar.Margin = New System.Windows.Forms.Padding(4)
        Me.btnCargar.Name = "btnCargar"
        Me.btnCargar.Size = New System.Drawing.Size(89, 65)
        Me.btnCargar.TabIndex = 0
        Me.btnCargar.Text = "Load"
        Me.btnCargar.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.btnCargar.UseVisualStyleBackColor = True
        '
        'pnlPrincipal
        '
        Me.pnlPrincipal.Controls.Add(Me.dgwPresupuesto)
        Me.pnlPrincipal.Controls.Add(Me.pnlFecha)
        Me.pnlPrincipal.Controls.Add(Me.Panel1)
        Me.pnlPrincipal.Controls.Add(Me.pnlBotones)
        Me.pnlPrincipal.Controls.Add(Me.pnlOpciones)
        Me.pnlPrincipal.Controls.Add(Me.pnlFechas)
        Me.pnlPrincipal.Dock = System.Windows.Forms.DockStyle.Fill
        Me.pnlPrincipal.Location = New System.Drawing.Point(0, 126)
        Me.pnlPrincipal.Margin = New System.Windows.Forms.Padding(4)
        Me.pnlPrincipal.Name = "pnlPrincipal"
        Me.pnlPrincipal.Size = New System.Drawing.Size(1139, 774)
        Me.pnlPrincipal.TabIndex = 3
        '
        'dgwPresupuesto
        '
        Me.dgwPresupuesto.AllowUserToAddRows = False
        Me.dgwPresupuesto.AllowUserToDeleteRows = False
        Me.dgwPresupuesto.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgwPresupuesto.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.colCuenta, Me.Descripcion, Me.Presupuestos, Me.Monto, Me.Diferencia, Me.mesgrid})
        Me.dgwPresupuesto.Dock = System.Windows.Forms.DockStyle.Fill
        Me.dgwPresupuesto.Location = New System.Drawing.Point(112, 108)
        Me.dgwPresupuesto.Margin = New System.Windows.Forms.Padding(4)
        Me.dgwPresupuesto.Name = "dgwPresupuesto"
        Me.dgwPresupuesto.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.dgwPresupuesto.ShowEditingIcon = False
        Me.dgwPresupuesto.ShowRowErrors = False
        Me.dgwPresupuesto.Size = New System.Drawing.Size(867, 604)
        Me.dgwPresupuesto.TabIndex = 0
        '
        'pnlFecha
        '
        Me.pnlFecha.Controls.Add(Me.lblcentro)
        Me.pnlFecha.Controls.Add(Me.lblCodigo)
        Me.pnlFecha.Controls.Add(Me.btnCentro)
        Me.pnlFecha.Controls.Add(Me.lblCosto)
        Me.pnlFecha.Controls.Add(Me.Mes)
        Me.pnlFecha.Dock = System.Windows.Forms.DockStyle.Top
        Me.pnlFecha.Location = New System.Drawing.Point(112, 49)
        Me.pnlFecha.Margin = New System.Windows.Forms.Padding(4)
        Me.pnlFecha.Name = "pnlFecha"
        Me.pnlFecha.Size = New System.Drawing.Size(867, 59)
        Me.pnlFecha.TabIndex = 14
        '
        'lblcentro
        '
        Me.lblcentro.AutoSize = True
        Me.lblcentro.Location = New System.Drawing.Point(316, 22)
        Me.lblcentro.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.lblcentro.Name = "lblcentro"
        Me.lblcentro.Size = New System.Drawing.Size(50, 17)
        Me.lblcentro.TabIndex = 15
        Me.lblcentro.Text = "Centro"
        Me.lblcentro.Visible = False
        '
        'lblCodigo
        '
        Me.lblCodigo.AutoSize = True
        Me.lblCodigo.Location = New System.Drawing.Point(415, 27)
        Me.lblCodigo.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.lblCodigo.Name = "lblCodigo"
        Me.lblCodigo.Size = New System.Drawing.Size(12, 17)
        Me.lblCodigo.TabIndex = 14
        Me.lblCodigo.Text = "."
        Me.lblCodigo.Visible = False
        '
        'btnCentro
        '
        Me.btnCentro.Location = New System.Drawing.Point(772, 21)
        Me.btnCentro.Margin = New System.Windows.Forms.Padding(4)
        Me.btnCentro.Name = "btnCentro"
        Me.btnCentro.Size = New System.Drawing.Size(65, 28)
        Me.btnCentro.TabIndex = 13
        Me.btnCentro.Text = "..."
        Me.btnCentro.UseVisualStyleBackColor = True
        Me.btnCentro.Visible = False
        '
        'lblCosto
        '
        Me.lblCosto.AutoSize = True
        Me.lblCosto.Location = New System.Drawing.Point(483, 27)
        Me.lblCosto.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.lblCosto.Name = "lblCosto"
        Me.lblCosto.Size = New System.Drawing.Size(12, 17)
        Me.lblCosto.TabIndex = 12
        Me.lblCosto.Text = "."
        Me.lblCosto.Visible = False
        '
        'Mes
        '
        Me.Mes.CustomFormat = "MMMM 'de' yyyy"
        Me.Mes.Format = System.Windows.Forms.DateTimePickerFormat.Custom
        Me.Mes.Location = New System.Drawing.Point(13, 22)
        Me.Mes.Margin = New System.Windows.Forms.Padding(4)
        Me.Mes.Name = "Mes"
        Me.Mes.Size = New System.Drawing.Size(211, 22)
        Me.Mes.TabIndex = 11
        '
        'Panel1
        '
        Me.Panel1.Controls.Add(Me.DOC_Total0)
        Me.Panel1.Controls.Add(Me.DOC_Total1)
        Me.Panel1.Controls.Add(Me.DOC_Total2)
        Me.Panel1.Controls.Add(Me.DOC_Total3)
        Me.Panel1.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.Panel1.Location = New System.Drawing.Point(112, 712)
        Me.Panel1.Margin = New System.Windows.Forms.Padding(4)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(867, 62)
        Me.Panel1.TabIndex = 13
        '
        'DOC_Total0
        '
        Me.DOC_Total0.BackColor = System.Drawing.SystemColors.ActiveCaption
        Me.DOC_Total0.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.DOC_Total0.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.DOC_Total0.Location = New System.Drawing.Point(300, 17)
        Me.DOC_Total0.Margin = New System.Windows.Forms.Padding(4)
        Me.DOC_Total0.Name = "DOC_Total0"
        Me.DOC_Total0.ReadOnly = True
        Me.DOC_Total0.Size = New System.Drawing.Size(133, 22)
        Me.DOC_Total0.TabIndex = 7
        Me.DOC_Total0.Text = "DOC_Total0"
        '
        'DOC_Total1
        '
        Me.DOC_Total1.BackColor = System.Drawing.SystemColors.ActiveCaption
        Me.DOC_Total1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.DOC_Total1.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.DOC_Total1.Location = New System.Drawing.Point(442, 17)
        Me.DOC_Total1.Margin = New System.Windows.Forms.Padding(4)
        Me.DOC_Total1.Name = "DOC_Total1"
        Me.DOC_Total1.ReadOnly = True
        Me.DOC_Total1.Size = New System.Drawing.Size(133, 22)
        Me.DOC_Total1.TabIndex = 8
        Me.DOC_Total1.Text = "DOC_Total1"
        '
        'DOC_Total2
        '
        Me.DOC_Total2.BackColor = System.Drawing.SystemColors.ActiveCaption
        Me.DOC_Total2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.DOC_Total2.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.DOC_Total2.Location = New System.Drawing.Point(583, 17)
        Me.DOC_Total2.Margin = New System.Windows.Forms.Padding(4)
        Me.DOC_Total2.Name = "DOC_Total2"
        Me.DOC_Total2.ReadOnly = True
        Me.DOC_Total2.Size = New System.Drawing.Size(133, 22)
        Me.DOC_Total2.TabIndex = 9
        Me.DOC_Total2.Text = "DOC_Total2"
        '
        'DOC_Total3
        '
        Me.DOC_Total3.BackColor = System.Drawing.SystemColors.ActiveCaption
        Me.DOC_Total3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.DOC_Total3.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.DOC_Total3.Location = New System.Drawing.Point(726, 17)
        Me.DOC_Total3.Margin = New System.Windows.Forms.Padding(4)
        Me.DOC_Total3.Name = "DOC_Total3"
        Me.DOC_Total3.ReadOnly = True
        Me.DOC_Total3.Size = New System.Drawing.Size(133, 22)
        Me.DOC_Total3.TabIndex = 10
        Me.DOC_Total3.Text = "DOC_Total3"
        Me.DOC_Total3.Visible = False
        '
        'pnlBotones
        '
        Me.pnlBotones.Controls.Add(Me.gpIdioma)
        Me.pnlBotones.Controls.Add(Me.gpMoneda)
        Me.pnlBotones.Controls.Add(Me.btnActualizar)
        Me.pnlBotones.Controls.Add(Me.btnPresupuesto)
        Me.pnlBotones.Controls.Add(Me.btnImprimir)
        Me.pnlBotones.Dock = System.Windows.Forms.DockStyle.Right
        Me.pnlBotones.Location = New System.Drawing.Point(979, 49)
        Me.pnlBotones.Margin = New System.Windows.Forms.Padding(4)
        Me.pnlBotones.Name = "pnlBotones"
        Me.pnlBotones.Size = New System.Drawing.Size(160, 725)
        Me.pnlBotones.TabIndex = 12
        '
        'gpIdioma
        '
        Me.gpIdioma.Controls.Add(Me.rbIngles)
        Me.gpIdioma.Controls.Add(Me.rbEspañol)
        Me.gpIdioma.Location = New System.Drawing.Point(21, 21)
        Me.gpIdioma.Margin = New System.Windows.Forms.Padding(4)
        Me.gpIdioma.Name = "gpIdioma"
        Me.gpIdioma.Padding = New System.Windows.Forms.Padding(4)
        Me.gpIdioma.Size = New System.Drawing.Size(109, 86)
        Me.gpIdioma.TabIndex = 1
        Me.gpIdioma.TabStop = False
        Me.gpIdioma.Text = "Language"
        '
        'rbIngles
        '
        Me.rbIngles.AutoSize = True
        Me.rbIngles.Location = New System.Drawing.Point(9, 54)
        Me.rbIngles.Margin = New System.Windows.Forms.Padding(4)
        Me.rbIngles.Name = "rbIngles"
        Me.rbIngles.Size = New System.Drawing.Size(75, 21)
        Me.rbIngles.TabIndex = 1
        Me.rbIngles.Text = "English"
        Me.rbIngles.UseVisualStyleBackColor = True
        '
        'rbEspañol
        '
        Me.rbEspañol.AutoSize = True
        Me.rbEspañol.Checked = True
        Me.rbEspañol.Location = New System.Drawing.Point(9, 25)
        Me.rbEspañol.Margin = New System.Windows.Forms.Padding(4)
        Me.rbEspañol.Name = "rbEspañol"
        Me.rbEspañol.Size = New System.Drawing.Size(80, 21)
        Me.rbEspañol.TabIndex = 0
        Me.rbEspañol.TabStop = True
        Me.rbEspañol.Text = "Spanish"
        Me.rbEspañol.UseVisualStyleBackColor = True
        '
        'gpMoneda
        '
        Me.gpMoneda.Controls.Add(Me.rbDolar)
        Me.gpMoneda.Controls.Add(Me.rbQuetzal)
        Me.gpMoneda.Location = New System.Drawing.Point(21, 151)
        Me.gpMoneda.Margin = New System.Windows.Forms.Padding(4)
        Me.gpMoneda.Name = "gpMoneda"
        Me.gpMoneda.Padding = New System.Windows.Forms.Padding(4)
        Me.gpMoneda.Size = New System.Drawing.Size(111, 84)
        Me.gpMoneda.TabIndex = 2
        Me.gpMoneda.TabStop = False
        Me.gpMoneda.Text = "Currency"
        '
        'rbDolar
        '
        Me.rbDolar.AutoSize = True
        Me.rbDolar.Location = New System.Drawing.Point(33, 50)
        Me.rbDolar.Margin = New System.Windows.Forms.Padding(4)
        Me.rbDolar.Name = "rbDolar"
        Me.rbDolar.Size = New System.Drawing.Size(37, 21)
        Me.rbDolar.TabIndex = 1
        Me.rbDolar.Text = "$"
        Me.rbDolar.UseVisualStyleBackColor = True
        '
        'rbQuetzal
        '
        Me.rbQuetzal.AutoSize = True
        Me.rbQuetzal.Checked = True
        Me.rbQuetzal.Location = New System.Drawing.Point(33, 23)
        Me.rbQuetzal.Margin = New System.Windows.Forms.Padding(4)
        Me.rbQuetzal.Name = "rbQuetzal"
        Me.rbQuetzal.Size = New System.Drawing.Size(40, 21)
        Me.rbQuetzal.TabIndex = 0
        Me.rbQuetzal.TabStop = True
        Me.rbQuetzal.Text = "Q"
        Me.rbQuetzal.UseVisualStyleBackColor = True
        '
        'btnActualizar
        '
        Me.btnActualizar.Image = Global.KARIMs_SGI.My.Resources.Resources.reload
        Me.btnActualizar.Location = New System.Drawing.Point(70, 252)
        Me.btnActualizar.Margin = New System.Windows.Forms.Padding(4)
        Me.btnActualizar.Name = "btnActualizar"
        Me.btnActualizar.Size = New System.Drawing.Size(60, 50)
        Me.btnActualizar.TabIndex = 3
        Me.btnActualizar.UseVisualStyleBackColor = True
        '
        'btnPresupuesto
        '
        Me.btnPresupuesto.Image = Global.KARIMs_SGI.My.Resources.Resources.money
        Me.btnPresupuesto.ImageAlign = System.Drawing.ContentAlignment.TopCenter
        Me.btnPresupuesto.Location = New System.Drawing.Point(31, 380)
        Me.btnPresupuesto.Margin = New System.Windows.Forms.Padding(4)
        Me.btnPresupuesto.Name = "btnPresupuesto"
        Me.btnPresupuesto.Size = New System.Drawing.Size(100, 58)
        Me.btnPresupuesto.TabIndex = 5
        Me.btnPresupuesto.Text = "Budget"
        Me.btnPresupuesto.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.btnPresupuesto.UseVisualStyleBackColor = True
        '
        'btnImprimir
        '
        Me.btnImprimir.Image = Global.KARIMs_SGI.My.Resources.Resources.print1
        Me.btnImprimir.Location = New System.Drawing.Point(31, 446)
        Me.btnImprimir.Margin = New System.Windows.Forms.Padding(4)
        Me.btnImprimir.Name = "btnImprimir"
        Me.btnImprimir.Size = New System.Drawing.Size(100, 55)
        Me.btnImprimir.TabIndex = 6
        Me.btnImprimir.Text = "Print"
        Me.btnImprimir.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.btnImprimir.UseVisualStyleBackColor = True
        '
        'pnlFechas
        '
        Me.pnlFechas.BackColor = System.Drawing.Color.Beige
        Me.pnlFechas.Controls.Add(Me.Label2)
        Me.pnlFechas.Controls.Add(Me.Label1)
        Me.pnlFechas.Controls.Add(Me.dtpFin)
        Me.pnlFechas.Controls.Add(Me.dtpIncio)
        Me.pnlFechas.Dock = System.Windows.Forms.DockStyle.Top
        Me.pnlFechas.Location = New System.Drawing.Point(0, 0)
        Me.pnlFechas.Margin = New System.Windows.Forms.Padding(4)
        Me.pnlFechas.Name = "pnlFechas"
        Me.pnlFechas.Size = New System.Drawing.Size(1139, 49)
        Me.pnlFechas.TabIndex = 3
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(360, 11)
        Me.Label2.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(64, 17)
        Me.Label2.TabIndex = 3
        Me.Label2.Text = "and date"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(21, 11)
        Me.Label1.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(180, 17)
        Me.Label1.TabIndex = 2
        Me.Label1.Text = "Show reports between date"
        '
        'dtpFin
        '
        Me.dtpFin.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.dtpFin.Location = New System.Drawing.Point(437, 9)
        Me.dtpFin.Margin = New System.Windows.Forms.Padding(4)
        Me.dtpFin.Name = "dtpFin"
        Me.dtpFin.Size = New System.Drawing.Size(128, 22)
        Me.dtpFin.TabIndex = 1
        '
        'dtpIncio
        '
        Me.dtpIncio.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.dtpIncio.Location = New System.Drawing.Point(218, 9)
        Me.dtpIncio.Margin = New System.Windows.Forms.Padding(4)
        Me.dtpIncio.Name = "dtpIncio"
        Me.dtpIncio.Size = New System.Drawing.Size(126, 22)
        Me.dtpIncio.TabIndex = 0
        '
        'BarraTitulo1
        '
        Me.BarraTitulo1.BackColor = System.Drawing.Color.WhiteSmoke
        Me.BarraTitulo1.Dock = System.Windows.Forms.DockStyle.Top
        Me.BarraTitulo1.Location = New System.Drawing.Point(0, 89)
        Me.BarraTitulo1.Margin = New System.Windows.Forms.Padding(5)
        Me.BarraTitulo1.Name = "BarraTitulo1"
        Me.BarraTitulo1.Size = New System.Drawing.Size(1139, 37)
        Me.BarraTitulo1.TabIndex = 1
        '
        'Encabezado1
        '
        Me.Encabezado1.Dock = System.Windows.Forms.DockStyle.Top
        Me.Encabezado1.Location = New System.Drawing.Point(0, 0)
        Me.Encabezado1.Margin = New System.Windows.Forms.Padding(5)
        Me.Encabezado1.Name = "Encabezado1"
        Me.Encabezado1.Size = New System.Drawing.Size(1139, 89)
        Me.Encabezado1.TabIndex = 0
        '
        'colCuenta
        '
        Me.colCuenta.HeaderText = "Cuenta"
        Me.colCuenta.Name = "colCuenta"
        Me.colCuenta.Visible = False
        '
        'Descripcion
        '
        Me.Descripcion.HeaderText = "Description"
        Me.Descripcion.Name = "Descripcion"
        Me.Descripcion.ReadOnly = True
        '
        'Presupuestos
        '
        Me.Presupuestos.HeaderText = "Budget"
        Me.Presupuestos.Name = "Presupuestos"
        Me.Presupuestos.ReadOnly = True
        '
        'Monto
        '
        Me.Monto.HeaderText = "Amount"
        Me.Monto.Name = "Monto"
        Me.Monto.ReadOnly = True
        '
        'Diferencia
        '
        Me.Diferencia.HeaderText = "Difference"
        Me.Diferencia.Name = "Diferencia"
        Me.Diferencia.ReadOnly = True
        '
        'mesgrid
        '
        Me.mesgrid.HeaderText = "mesgrid"
        Me.mesgrid.Name = "mesgrid"
        Me.mesgrid.ReadOnly = True
        Me.mesgrid.Visible = False
        '
        'frmPresupuesto
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.AutoScroll = True
        Me.ClientSize = New System.Drawing.Size(1139, 900)
        Me.Controls.Add(Me.pnlPrincipal)
        Me.Controls.Add(Me.BarraTitulo1)
        Me.Controls.Add(Me.Encabezado1)
        Me.Margin = New System.Windows.Forms.Padding(4)
        Me.Name = "frmPresupuesto"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent
        Me.Text = "Presupuesto"
        Me.WindowState = System.Windows.Forms.FormWindowState.Maximized
        Me.pnlOpciones.ResumeLayout(False)
        Me.pnlPrincipal.ResumeLayout(False)
        CType(Me.dgwPresupuesto, System.ComponentModel.ISupportInitialize).EndInit()
        Me.pnlFecha.ResumeLayout(False)
        Me.pnlFecha.PerformLayout()
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        Me.pnlBotones.ResumeLayout(False)
        Me.gpIdioma.ResumeLayout(False)
        Me.gpIdioma.PerformLayout()
        Me.gpMoneda.ResumeLayout(False)
        Me.gpMoneda.PerformLayout()
        Me.pnlFechas.ResumeLayout(False)
        Me.pnlFechas.PerformLayout()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents Encabezado1 As KARIMs_SGI.encabezado
    Friend WithEvents BarraTitulo1 As KARIMs_SGI.BarraTitulo
    Friend WithEvents pnlOpciones As System.Windows.Forms.Panel
    Friend WithEvents btnCargar As System.Windows.Forms.Button
    Friend WithEvents BackgroundWorker1 As System.ComponentModel.BackgroundWorker
    Friend WithEvents pnlPrincipal As System.Windows.Forms.Panel
    Friend WithEvents gpMoneda As System.Windows.Forms.GroupBox
    Friend WithEvents gpIdioma As System.Windows.Forms.GroupBox
    Friend WithEvents dgwPresupuesto As System.Windows.Forms.DataGridView
    Friend WithEvents pnlFechas As System.Windows.Forms.Panel
    Friend WithEvents btnActualizar As System.Windows.Forms.Button
    Friend WithEvents rbDolar As System.Windows.Forms.RadioButton
    Friend WithEvents rbQuetzal As System.Windows.Forms.RadioButton
    Friend WithEvents rbIngles As System.Windows.Forms.RadioButton
    Friend WithEvents rbEspañol As System.Windows.Forms.RadioButton
    Friend WithEvents btnImprimir As System.Windows.Forms.Button
    Friend WithEvents btnPresupuesto As System.Windows.Forms.Button
    Friend WithEvents DOC_Total3 As System.Windows.Forms.TextBox
    Friend WithEvents DOC_Total2 As System.Windows.Forms.TextBox
    Friend WithEvents DOC_Total1 As System.Windows.Forms.TextBox
    Friend WithEvents DOC_Total0 As System.Windows.Forms.TextBox
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents dtpFin As System.Windows.Forms.DateTimePicker
    Friend WithEvents dtpIncio As System.Windows.Forms.DateTimePicker
    Friend WithEvents Mes As System.Windows.Forms.DateTimePicker
    Friend WithEvents pnlBotones As System.Windows.Forms.Panel
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
    Friend WithEvents pnlFecha As System.Windows.Forms.Panel
    Friend WithEvents btnCentro As System.Windows.Forms.Button
    Friend WithEvents lblCosto As System.Windows.Forms.Label
    Friend WithEvents lblcentro As System.Windows.Forms.Label
    Friend WithEvents lblCodigo As System.Windows.Forms.Label
    Friend WithEvents colCuenta As DataGridViewTextBoxColumn
    Friend WithEvents Descripcion As DataGridViewTextBoxColumn
    Friend WithEvents Presupuestos As DataGridViewTextBoxColumn
    Friend WithEvents Monto As DataGridViewTextBoxColumn
    Friend WithEvents Diferencia As DataGridViewTextBoxColumn
    Friend WithEvents mesgrid As DataGridViewTextBoxColumn
End Class
