﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmMantenimientos
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.panelDetalle = New System.Windows.Forms.Panel()
        Me.dgDetalle = New System.Windows.Forms.DataGridView()
        Me.panelEncabezado = New System.Windows.Forms.Panel()
        Me.celdaIdEquipo = New System.Windows.Forms.TextBox()
        Me.celdaIdTipo = New System.Windows.Forms.TextBox()
        Me.etiquetaNumero = New System.Windows.Forms.Label()
        Me.botonEquipo = New System.Windows.Forms.Button()
        Me.etiquetaFecha = New System.Windows.Forms.Label()
        Me.botonTipo = New System.Windows.Forms.Button()
        Me.etiquetaTipo = New System.Windows.Forms.Label()
        Me.dtpFecha = New System.Windows.Forms.DateTimePicker()
        Me.etiquetaEquipo = New System.Windows.Forms.Label()
        Me.celdaEquipo = New System.Windows.Forms.TextBox()
        Me.celdaNumero = New System.Windows.Forms.TextBox()
        Me.celdaTipo = New System.Windows.Forms.TextBox()
        Me.panelLista = New System.Windows.Forms.Panel()
        Me.dgLista = New System.Windows.Forms.DataGridView()
        Me.colFecha = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colId = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colTipo = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colEquipo = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.panelFechas = New System.Windows.Forms.Panel()
        Me.botonActualizar = New System.Windows.Forms.Button()
        Me.etiquetaFechas = New System.Windows.Forms.Label()
        Me.dtpFinal = New System.Windows.Forms.DateTimePicker()
        Me.dtpInicial = New System.Windows.Forms.DateTimePicker()
        Me.checkFechas = New System.Windows.Forms.CheckBox()
        Me.BarraTitulo1 = New KARIMs_SGI.BarraTitulo()
        Me.Encabezado1 = New KARIMs_SGI.encabezado()
        Me.colIdProceso = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colTarea = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colDescripcion = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colComentario = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colCorreccion = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.panelDetalle.SuspendLayout()
        CType(Me.dgDetalle, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.panelEncabezado.SuspendLayout()
        Me.panelLista.SuspendLayout()
        CType(Me.dgLista, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.panelFechas.SuspendLayout()
        Me.SuspendLayout()
        '
        'panelDetalle
        '
        Me.panelDetalle.Controls.Add(Me.dgDetalle)
        Me.panelDetalle.Controls.Add(Me.panelEncabezado)
        Me.panelDetalle.Location = New System.Drawing.Point(84, 210)
        Me.panelDetalle.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.panelDetalle.Name = "panelDetalle"
        Me.panelDetalle.Size = New System.Drawing.Size(633, 263)
        Me.panelDetalle.TabIndex = 2
        '
        'dgDetalle
        '
        Me.dgDetalle.AllowUserToAddRows = False
        Me.dgDetalle.AllowUserToDeleteRows = False
        Me.dgDetalle.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells
        Me.dgDetalle.BackgroundColor = System.Drawing.SystemColors.Control
        Me.dgDetalle.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgDetalle.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.colIdProceso, Me.colTarea, Me.colDescripcion, Me.colComentario, Me.colCorreccion})
        Me.dgDetalle.Dock = System.Windows.Forms.DockStyle.Fill
        Me.dgDetalle.Location = New System.Drawing.Point(0, 101)
        Me.dgDetalle.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.dgDetalle.MultiSelect = False
        Me.dgDetalle.Name = "dgDetalle"
        Me.dgDetalle.RowTemplate.Height = 24
        Me.dgDetalle.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.dgDetalle.Size = New System.Drawing.Size(633, 162)
        Me.dgDetalle.TabIndex = 11
        '
        'panelEncabezado
        '
        Me.panelEncabezado.Controls.Add(Me.celdaIdEquipo)
        Me.panelEncabezado.Controls.Add(Me.celdaIdTipo)
        Me.panelEncabezado.Controls.Add(Me.etiquetaNumero)
        Me.panelEncabezado.Controls.Add(Me.botonEquipo)
        Me.panelEncabezado.Controls.Add(Me.etiquetaFecha)
        Me.panelEncabezado.Controls.Add(Me.botonTipo)
        Me.panelEncabezado.Controls.Add(Me.etiquetaTipo)
        Me.panelEncabezado.Controls.Add(Me.dtpFecha)
        Me.panelEncabezado.Controls.Add(Me.etiquetaEquipo)
        Me.panelEncabezado.Controls.Add(Me.celdaEquipo)
        Me.panelEncabezado.Controls.Add(Me.celdaNumero)
        Me.panelEncabezado.Controls.Add(Me.celdaTipo)
        Me.panelEncabezado.Dock = System.Windows.Forms.DockStyle.Top
        Me.panelEncabezado.Location = New System.Drawing.Point(0, 0)
        Me.panelEncabezado.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.panelEncabezado.Name = "panelEncabezado"
        Me.panelEncabezado.Size = New System.Drawing.Size(633, 101)
        Me.panelEncabezado.TabIndex = 10
        '
        'celdaIdEquipo
        '
        Me.celdaIdEquipo.Location = New System.Drawing.Point(261, 48)
        Me.celdaIdEquipo.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.celdaIdEquipo.Name = "celdaIdEquipo"
        Me.celdaIdEquipo.Size = New System.Drawing.Size(33, 22)
        Me.celdaIdEquipo.TabIndex = 11
        Me.celdaIdEquipo.Text = "-1"
        Me.celdaIdEquipo.Visible = False
        '
        'celdaIdTipo
        '
        Me.celdaIdTipo.Location = New System.Drawing.Point(261, 14)
        Me.celdaIdTipo.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.celdaIdTipo.Name = "celdaIdTipo"
        Me.celdaIdTipo.Size = New System.Drawing.Size(33, 22)
        Me.celdaIdTipo.TabIndex = 10
        Me.celdaIdTipo.Text = "-1"
        Me.celdaIdTipo.Visible = False
        '
        'etiquetaNumero
        '
        Me.etiquetaNumero.AutoSize = True
        Me.etiquetaNumero.Location = New System.Drawing.Point(3, 17)
        Me.etiquetaNumero.Name = "etiquetaNumero"
        Me.etiquetaNumero.Size = New System.Drawing.Size(58, 17)
        Me.etiquetaNumero.TabIndex = 0
        Me.etiquetaNumero.Text = "Numero"
        '
        'botonEquipo
        '
        Me.botonEquipo.Location = New System.Drawing.Point(572, 50)
        Me.botonEquipo.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.botonEquipo.Name = "botonEquipo"
        Me.botonEquipo.Size = New System.Drawing.Size(36, 23)
        Me.botonEquipo.TabIndex = 9
        Me.botonEquipo.Text = "..."
        Me.botonEquipo.UseVisualStyleBackColor = True
        '
        'etiquetaFecha
        '
        Me.etiquetaFecha.AutoSize = True
        Me.etiquetaFecha.Location = New System.Drawing.Point(3, 53)
        Me.etiquetaFecha.Name = "etiquetaFecha"
        Me.etiquetaFecha.Size = New System.Drawing.Size(47, 17)
        Me.etiquetaFecha.TabIndex = 1
        Me.etiquetaFecha.Text = "Fecha"
        '
        'botonTipo
        '
        Me.botonTipo.Location = New System.Drawing.Point(572, 14)
        Me.botonTipo.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.botonTipo.Name = "botonTipo"
        Me.botonTipo.Size = New System.Drawing.Size(36, 23)
        Me.botonTipo.TabIndex = 8
        Me.botonTipo.Text = "..."
        Me.botonTipo.UseVisualStyleBackColor = True
        '
        'etiquetaTipo
        '
        Me.etiquetaTipo.AutoSize = True
        Me.etiquetaTipo.Location = New System.Drawing.Point(300, 17)
        Me.etiquetaTipo.Name = "etiquetaTipo"
        Me.etiquetaTipo.Size = New System.Drawing.Size(40, 17)
        Me.etiquetaTipo.TabIndex = 2
        Me.etiquetaTipo.Text = "Type"
        '
        'dtpFecha
        '
        Me.dtpFecha.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.dtpFecha.Location = New System.Drawing.Point(67, 48)
        Me.dtpFecha.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.dtpFecha.Name = "dtpFecha"
        Me.dtpFecha.Size = New System.Drawing.Size(128, 22)
        Me.dtpFecha.TabIndex = 7
        '
        'etiquetaEquipo
        '
        Me.etiquetaEquipo.AutoSize = True
        Me.etiquetaEquipo.Location = New System.Drawing.Point(300, 57)
        Me.etiquetaEquipo.Name = "etiquetaEquipo"
        Me.etiquetaEquipo.Size = New System.Drawing.Size(66, 17)
        Me.etiquetaEquipo.TabIndex = 3
        Me.etiquetaEquipo.Text = "Inventory"
        '
        'celdaEquipo
        '
        Me.celdaEquipo.Location = New System.Drawing.Point(372, 53)
        Me.celdaEquipo.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.celdaEquipo.Name = "celdaEquipo"
        Me.celdaEquipo.ReadOnly = True
        Me.celdaEquipo.Size = New System.Drawing.Size(191, 22)
        Me.celdaEquipo.TabIndex = 6
        '
        'celdaNumero
        '
        Me.celdaNumero.ForeColor = System.Drawing.SystemColors.MenuHighlight
        Me.celdaNumero.Location = New System.Drawing.Point(67, 14)
        Me.celdaNumero.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.celdaNumero.Name = "celdaNumero"
        Me.celdaNumero.Size = New System.Drawing.Size(100, 22)
        Me.celdaNumero.TabIndex = 4
        '
        'celdaTipo
        '
        Me.celdaTipo.Location = New System.Drawing.Point(372, 14)
        Me.celdaTipo.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.celdaTipo.Name = "celdaTipo"
        Me.celdaTipo.ReadOnly = True
        Me.celdaTipo.Size = New System.Drawing.Size(191, 22)
        Me.celdaTipo.TabIndex = 5
        '
        'panelLista
        '
        Me.panelLista.Controls.Add(Me.dgLista)
        Me.panelLista.Controls.Add(Me.panelFechas)
        Me.panelLista.Location = New System.Drawing.Point(12, 121)
        Me.panelLista.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.panelLista.Name = "panelLista"
        Me.panelLista.Size = New System.Drawing.Size(525, 66)
        Me.panelLista.TabIndex = 3
        '
        'dgLista
        '
        Me.dgLista.AllowUserToAddRows = False
        Me.dgLista.AllowUserToDeleteRows = False
        Me.dgLista.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells
        Me.dgLista.BackgroundColor = System.Drawing.SystemColors.Control
        Me.dgLista.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgLista.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.colFecha, Me.colId, Me.colTipo, Me.colEquipo})
        Me.dgLista.Dock = System.Windows.Forms.DockStyle.Fill
        Me.dgLista.Location = New System.Drawing.Point(0, 53)
        Me.dgLista.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.dgLista.MultiSelect = False
        Me.dgLista.Name = "dgLista"
        Me.dgLista.RowTemplate.Height = 24
        Me.dgLista.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.dgLista.Size = New System.Drawing.Size(525, 13)
        Me.dgLista.TabIndex = 1
        '
        'colFecha
        '
        Me.colFecha.HeaderText = "Fecha"
        Me.colFecha.Name = "colFecha"
        '
        'colId
        '
        Me.colId.HeaderText = "Numero"
        Me.colId.Name = "colId"
        '
        'colTipo
        '
        Me.colTipo.HeaderText = "Tipo"
        Me.colTipo.Name = "colTipo"
        '
        'colEquipo
        '
        Me.colEquipo.HeaderText = "Equipo"
        Me.colEquipo.Name = "colEquipo"
        '
        'panelFechas
        '
        Me.panelFechas.Controls.Add(Me.botonActualizar)
        Me.panelFechas.Controls.Add(Me.etiquetaFechas)
        Me.panelFechas.Controls.Add(Me.dtpFinal)
        Me.panelFechas.Controls.Add(Me.dtpInicial)
        Me.panelFechas.Controls.Add(Me.checkFechas)
        Me.panelFechas.Dock = System.Windows.Forms.DockStyle.Top
        Me.panelFechas.Location = New System.Drawing.Point(0, 0)
        Me.panelFechas.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.panelFechas.Name = "panelFechas"
        Me.panelFechas.Size = New System.Drawing.Size(525, 53)
        Me.panelFechas.TabIndex = 0
        '
        'botonActualizar
        '
        Me.botonActualizar.Location = New System.Drawing.Point(483, 11)
        Me.botonActualizar.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.botonActualizar.Name = "botonActualizar"
        Me.botonActualizar.Size = New System.Drawing.Size(88, 25)
        Me.botonActualizar.TabIndex = 12
        Me.botonActualizar.Text = "Actualizar"
        Me.botonActualizar.UseVisualStyleBackColor = True
        '
        'etiquetaFechas
        '
        Me.etiquetaFechas.AutoSize = True
        Me.etiquetaFechas.Location = New System.Drawing.Point(272, 16)
        Me.etiquetaFechas.Name = "etiquetaFechas"
        Me.etiquetaFechas.Size = New System.Drawing.Size(45, 17)
        Me.etiquetaFechas.TabIndex = 10
        Me.etiquetaFechas.Text = "Hasta"
        '
        'dtpFinal
        '
        Me.dtpFinal.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.dtpFinal.Location = New System.Drawing.Point(333, 11)
        Me.dtpFinal.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.dtpFinal.Name = "dtpFinal"
        Me.dtpFinal.Size = New System.Drawing.Size(128, 22)
        Me.dtpFinal.TabIndex = 11
        '
        'dtpInicial
        '
        Me.dtpInicial.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.dtpInicial.Location = New System.Drawing.Point(129, 11)
        Me.dtpInicial.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.dtpInicial.Name = "dtpInicial"
        Me.dtpInicial.Size = New System.Drawing.Size(128, 22)
        Me.dtpInicial.TabIndex = 10
        '
        'checkFechas
        '
        Me.checkFechas.AutoSize = True
        Me.checkFechas.Checked = True
        Me.checkFechas.CheckState = System.Windows.Forms.CheckState.Checked
        Me.checkFechas.Location = New System.Drawing.Point(3, 15)
        Me.checkFechas.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.checkFechas.Name = "checkFechas"
        Me.checkFechas.Size = New System.Drawing.Size(109, 21)
        Me.checkFechas.TabIndex = 0
        Me.checkFechas.Text = "Filtrar desde"
        Me.checkFechas.UseVisualStyleBackColor = True
        '
        'BarraTitulo1
        '
        Me.BarraTitulo1.BackColor = System.Drawing.Color.WhiteSmoke
        Me.BarraTitulo1.Dock = System.Windows.Forms.DockStyle.Top
        Me.BarraTitulo1.Location = New System.Drawing.Point(0, 76)
        Me.BarraTitulo1.Margin = New System.Windows.Forms.Padding(5)
        Me.BarraTitulo1.Name = "BarraTitulo1"
        Me.BarraTitulo1.Size = New System.Drawing.Size(855, 37)
        Me.BarraTitulo1.TabIndex = 1
        '
        'Encabezado1
        '
        Me.Encabezado1.Dock = System.Windows.Forms.DockStyle.Top
        Me.Encabezado1.Location = New System.Drawing.Point(0, 0)
        Me.Encabezado1.Margin = New System.Windows.Forms.Padding(5)
        Me.Encabezado1.Name = "Encabezado1"
        Me.Encabezado1.Size = New System.Drawing.Size(855, 76)
        Me.Encabezado1.TabIndex = 0
        '
        'colIdProceso
        '
        Me.colIdProceso.HeaderText = "Id"
        Me.colIdProceso.Name = "colIdProceso"
        Me.colIdProceso.ReadOnly = True
        Me.colIdProceso.Width = 48
        '
        'colTarea
        '
        Me.colTarea.HeaderText = "Tarea"
        Me.colTarea.Name = "colTarea"
        Me.colTarea.ReadOnly = True
        Me.colTarea.Width = 75
        '
        'colDescripcion
        '
        Me.colDescripcion.HeaderText = "Descripción"
        Me.colDescripcion.Name = "colDescripcion"
        Me.colDescripcion.ReadOnly = True
        Me.colDescripcion.Width = 111
        '
        'colComentario
        '
        Me.colComentario.HeaderText = "Comentario"
        Me.colComentario.Name = "colComentario"
        Me.colComentario.Width = 109
        '
        'colCorreccion
        '
        Me.colCorreccion.HeaderText = "Correción Aplicada"
        Me.colCorreccion.Name = "colCorreccion"
        Me.colCorreccion.Width = 143
        '
        'frmMantenimientos
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(855, 603)
        Me.Controls.Add(Me.panelLista)
        Me.Controls.Add(Me.panelDetalle)
        Me.Controls.Add(Me.BarraTitulo1)
        Me.Controls.Add(Me.Encabezado1)
        Me.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Name = "frmMantenimientos"
        Me.Text = "Modulo de Mantenimientos"
        Me.panelDetalle.ResumeLayout(False)
        CType(Me.dgDetalle, System.ComponentModel.ISupportInitialize).EndInit()
        Me.panelEncabezado.ResumeLayout(False)
        Me.panelEncabezado.PerformLayout()
        Me.panelLista.ResumeLayout(False)
        CType(Me.dgLista, System.ComponentModel.ISupportInitialize).EndInit()
        Me.panelFechas.ResumeLayout(False)
        Me.panelFechas.PerformLayout()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents Encabezado1 As encabezado
    Friend WithEvents BarraTitulo1 As BarraTitulo
    Friend WithEvents panelDetalle As Panel
    Friend WithEvents etiquetaFecha As Label
    Friend WithEvents etiquetaNumero As Label
    Friend WithEvents botonEquipo As Button
    Friend WithEvents botonTipo As Button
    Friend WithEvents dtpFecha As DateTimePicker
    Friend WithEvents celdaEquipo As TextBox
    Friend WithEvents celdaTipo As TextBox
    Friend WithEvents celdaNumero As TextBox
    Friend WithEvents etiquetaEquipo As Label
    Friend WithEvents etiquetaTipo As Label
    Friend WithEvents dgDetalle As DataGridView
    Friend WithEvents panelEncabezado As Panel
    Friend WithEvents panelLista As Panel
    Friend WithEvents dgLista As DataGridView
    Friend WithEvents panelFechas As Panel
    Friend WithEvents botonActualizar As Button
    Friend WithEvents etiquetaFechas As Label
    Friend WithEvents dtpFinal As DateTimePicker
    Friend WithEvents dtpInicial As DateTimePicker
    Friend WithEvents checkFechas As System.Windows.Forms.CheckBox
    Friend WithEvents colFecha As DataGridViewTextBoxColumn
    Friend WithEvents colId As DataGridViewTextBoxColumn
    Friend WithEvents colTipo As DataGridViewTextBoxColumn
    Friend WithEvents colEquipo As DataGridViewTextBoxColumn
    Friend WithEvents celdaIdEquipo As TextBox
    Friend WithEvents celdaIdTipo As TextBox
    Friend WithEvents colIdProceso As DataGridViewTextBoxColumn
    Friend WithEvents colTarea As DataGridViewTextBoxColumn
    Friend WithEvents colDescripcion As DataGridViewTextBoxColumn
    Friend WithEvents colComentario As DataGridViewTextBoxColumn
    Friend WithEvents colCorreccion As DataGridViewTextBoxColumn
End Class
