﻿Public Class frmCategoriaMercadeo

#Region "Miembros"
    Dim strKey As String = STR_VACIO
    Dim logInsertar As Boolean = False
    Dim logConsultar As Boolean = False
    Dim logEditar As Boolean = False
    Dim LogBorrar As Boolean = False
    Dim cfun As New clsFunciones
    Dim YarnD As String = "YarnDivision"
    Dim intTipo As Integer = INT_UNO

#End Region

#Region "Prodiedades"
    Public Property Key As String
        Get
            Return strKey
        End Get
        Set(value As String)
            strKey = value
        End Set
    End Property
#End Region

#Region "Procedimientos"

    Private Function QueryListaPrincipal()
        Dim strSQL As String = STR_VACIO

        strSQL = " SELECT h.Cat_IdCategoria id, h.Cat_NombreCategoria nombre "
        strSQL &= "    FROM CategoriaMercadeo_HDR h "
        strSQL &= "      WHERE h.Cat_Empresa = {emp} "

        strSQL = Replace(strSQL, "{emp}", Sesion.IdEmpresa)

        Return strSQL

    End Function

    Private Sub LimpiarCampos()
        celdaNombre.Clear()
        celdaNumero.Text = NO_FILA
        CheckFavorito.Checked = False
        dglistadoDetalle.Rows.Clear()

    End Sub

    Private Function QueryDetalle(ByVal grupo As Integer)
        Dim strSQL As String = STR_VACIO

        strSQL = " SELECT h.Cat_IdCategoria id, h.Cat_NombreCategoria nombre, d.DCat_CodigoProd codigo,d.DCat_NombreProd producto,d.DCat_Linea linea "
        strSQL &= "    FROM CategoriaMercadeo_HDR h "
        strSQL &= "    LEFT JOIN CategoriaMercadeo_DTL d ON d.DCat_Empresa = h.Cat_Empresa AND d.DCat_IdCategoria = h.Cat_IdCategoria "
        strSQL &= "            WHERE h.Cat_Empresa = {emp} AND h.Cat_IdCategoria = {id} "


        strSQL = Replace(strSQL, "{emp}", Sesion.IdEmpresa)
        strSQL = Replace(strSQL, "{id}", grupo)

        Return strSQL
    End Function

    Public Function BorrarEncabezadoGrupo() As Boolean
        Dim logGuardar As Boolean
        Dim strSQL As String = STR_VACIO
        Dim COM As MySqlCommand
        Dim clsHDR As New clsDcmtos_HDR
        Try
            MyCnn.CONECTAR = strConexion
            strSQL = "  DELETE FROM CategoriaMercadeo_HDR  WHERE Cat_Empresa = {emp}  AND Cat_IdCategoria = {id} "
            strSQL = Replace(strSQL, "{id}", celdaNumero.Text)
            strSQL = Replace(strSQL, "{emp}", Sesion.IdEmpresa)
            COM = New MySqlCommand(strSQL, CON)
            COM.ExecuteNonQuery()
            COM = Nothing
            logGuardar = True
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        Return logGuardar
    End Function

    Public Function BorrarDetalleGrupo() As Boolean
        Dim logGuardar As Boolean
        Dim strSQL As String = STR_VACIO
        Dim COM As MySqlCommand
        Dim clsHDR As New clsDcmtos_HDR
        Try
            MyCnn.CONECTAR = strConexion
            strSQL = "  DELETE FROM CategoriaMercadeo_DTL  WHERE DCat_empresa = {emp}  AND DCat_IdCategoria = {id} "
            strSQL = Replace(strSQL, "{id}", celdaNumero.Text)
            strSQL = Replace(strSQL, "{emp}", Sesion.IdEmpresa)
            COM = New MySqlCommand(strSQL, CON)
            COM.ExecuteNonQuery()
            COM = Nothing
            logGuardar = True
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        Return logGuardar
    End Function

    Private Sub MostrarLista(Optional ByVal logMostrar As Boolean = True, Optional ByVal logInsert As Boolean = True)
        Try

            'Muestra el listado principal
            If logMostrar = True Then
                panelListaPrincipal.Visible = True
                panelListaPrincipal.Dock = DockStyle.Fill
                panelDetalle.Visible = False
                panelDetalle.Dock = DockStyle.None
                BarraTitulo1.CambiarTitulo("Category")
                BloquearBotones()

                ListaPrincipal()
            Else
                'Muestra el Detalle
                panelListaPrincipal.Visible = False
                panelListaPrincipal.Dock = DockStyle.None
                panelDetalle.Visible = True
                panelDetalle.Dock = DockStyle.Fill

                'Modificación
                If logInsert = False Then
                    BarraTitulo1.CambiarTitulo("Modifi Category")
                    Me.Tag = "Mod"
                    BloquearBotones(False)
                Else
                    'Nuevo
                    BarraTitulo1.CambiarTitulo("New Category")
                    Me.Tag = "Nuevo"
                    BloquearBotones(False)

                End If
            End If

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub BloquearBotones(Optional ByVal logBloquear As Boolean = True)
        If logBloquear = True Then
            Encabezado1.botonBorrar.Enabled = False
            Encabezado1.botonGuardar.Enabled = False
        Else
            Encabezado1.botonBorrar.Enabled = True
            Encabezado1.botonGuardar.Enabled = True
        End If

    End Sub

    Private Sub Accesos()
        Dim cAcesos As New clsAccesos

        Try
            If cAcesos.Accesos(strKey) = True Then
                logInsertar = cAcesos.Insertar
                logEditar = cAcesos.Editar
                LogBorrar = cAcesos.Borrar
                logConsultar = cAcesos.Consultar

            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Function ComprobarCampos()
        Dim comprobar As Boolean = True
        Try
            If celdaNombre.Text = vbNullString Then
                Return comprobar = False
                Exit Function
            End If
            If dglistadoDetalle.Rows.Count > 0 Then
            Else
                Return comprobar = False
                Exit Function
            End If

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        Return comprobar
    End Function

    Private Sub GuardarGrupo()
        Dim grp As New Tablas.TCATEGORIAMERCADEO_HDR

        Try
            grp.CONEXION = strConexion

            grp.CAT_EMPRESA = Sesion.IdEmpresa
            grp.CAT_IDCATEGORIA = celdaNumero.Text
            grp.CAT_NOMBRECATEGORIA = celdaNombre.Text
            grp.CAT_USUARIO = Sesion.Usuario

            If Me.Tag = "Nuevo" Then
                If grp.PINSERT() = False Then
                    MsgBox(grp.MERROR.ToString & "Could not save the document", MsgBoxStyle.Critical)
                End If
            Else
                If grp.PUPDATE() = False Then
                    MsgBox(grp.MERROR.ToString & "Could not update the document", MsgBoxStyle.Critical)
                End If


            End If

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub


    Private Sub GuardarDetalleGrp()
        Dim Det As New Tablas.TCATEGORIAMERCADEO_DTL
        Dim i As Integer = 0

        Try
            Det.CONEXION = strConexion

            For i = 0 To dglistadoDetalle.Rows.Count - 1

                Det.DCAT_EMPRESA = Sesion.IdEmpresa
                Det.DCAT_IDCATEGORIA = celdaNumero.Text


                If dglistadoDetalle.Rows(i).Cells("colLinea").Value = 0 Then '0 es Nuevo, 1 Modificación
                    dglistadoDetalle.Rows(i).Cells("colLinea").Value = NuevaLineaGrupo()
                    Det.DCAT_LINEA = dglistadoDetalle.Rows(i).Cells("colLinea").Value
                Else
                    Det.DCAT_LINEA = dglistadoDetalle.Rows(i).Cells("colLinea").Value
                End If

                Det.DCAT_CODIGOPROD = dglistadoDetalle.Rows(i).Cells("colCodigo").Value
                Det.DCAT_NOMBREPROD = dglistadoDetalle.Rows(i).Cells("colCliente").Value

                If dglistadoDetalle.Rows(i).Cells("colExtra").Value = 0 Then
                    If Det.PINSERT() = False Then
                        MsgBox(Det.MERROR.ToString & "Could not save the document", MsgBoxStyle.Critical)
                    End If
                End If
                If dglistadoDetalle.Rows(i).Cells("colExtra").Value = 1 Then
                    If Det.PUPDATE() = False Then
                        MsgBox(Det.MERROR.ToString & "Could not Update the document", MsgBoxStyle.Critical)
                    End If
                End If
                If dglistadoDetalle.Rows(i).Cells("colExtra").Value = 2 Then
                    If Det.PDELETE() = False Then
                        MsgBox(Det.MERROR.ToString & "Line not deleted", MsgBoxStyle.Critical)
                    End If
                End If
            Next


        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Function NuevaLineaGrupo()
        Dim strSQL As String = STR_VACIO
        Dim conec As New MySqlConnection
        Dim COM As MySqlCommand

        strSQL = " SELECT IFNULL(MAX(gd.DCat_Linea +1),1) Linea  "
        strSQL &= "    FROM CategoriaMercadeo_DTL gd "
        strSQL &= "         WHERE gd.DCat_Empresa = {emp} AND gd.DCat_IdCategoria = {num}"

        strSQL = Replace(strSQL, "{num}", celdaNumero.Text)
        strSQL = Replace(strSQL, "{emp}", Sesion.IdEmpresa)

        conec = New MySqlConnection(strConexion)
        conec.Open()
        COM = New MySqlCommand(strSQL, conec)
        Using conec
            Return COM.ExecuteScalar
            COM.Dispose()
            COM = Nothing
            conec.Close()
            conec.Dispose()
            conec = Nothing
            System.GC.Collect()

        End Using
    End Function

    Private Sub ListaPrincipal()
        Dim strSQL As String = STR_VACIO
        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader
        Dim strFila As String = STR_VACIO

        strSQL = QueryListaPrincipal()
        Try
            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSQL, CON)
            REA = COM.ExecuteReader
            dgListaPrincipal.Rows.Clear()
            If REA.HasRows Then

                Do While REA.Read
                    strFila = REA.GetInt32("id") & "|"
                    strFila &= REA.GetString("nombre") & "|"
                    strFila &= "" & "|"
                    strFila &= "" & "|"
                    strFila &= ""

                    cfun.AgregarFila(dgListaPrincipal, strFila)
                Loop

            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try

    End Sub

    Private Sub CargarDatosGrupo(ByVal intGrupo As Integer)
        Dim strSQL As String = STR_VACIO
        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader
        Dim strFila As String = STR_VACIO

        Try
            strSQL = QueryDetalle(intGrupo)

            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSQL, CON)
            REA = COM.ExecuteReader
            dglistadoDetalle.Rows.Clear()
            If REA.HasRows Then
                Do While REA.Read
                    celdaNombre.Text = REA.GetString("nombre")
                    celdaNumero.Text = REA.GetInt32("id")
                    'If REA.GetInt32("Favorito") = 1 Then
                    '    CheckFavorito.Checked = True
                    'Else
                    '    CheckFavorito.Checked = False
                    'End If

                    strFila = REA.GetString("codigo") & "|"
                    strFila &= REA.GetString("producto") & "|"
                    strFila &= REA.GetInt32("linea") & "|"
                    strFila &= Sesion.Empresa & "|"
                    strFila &= Sesion.IdEmpresa & "|"
                    strFila &= INT_UNO

                    cfun.AgregarFila(dglistadoDetalle, strFila)
                Loop
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try

    End Sub
    Private Sub CargarInformacion()
        Dim strSQL As String = STR_VACIO
        'Dim Opciones As New frmOption
        Dim frmS As New frmSeleccionar
        Dim strfila As String = STR_VACIO
        Dim i As Integer = 0

        'strSQL = " Select e.idEmpresa codigo, e.nombre_empresa nombre, e.codigo_empresa idempresa "
        'strSQL &= "    From YarnDivision.Empresa e "
        Try




            frmS.Titulo = "Products"
            frmS.Campos = "a.art_codigo codigo, a.art_DCorta Descripcion, a.art_sisemp empresa "

            frmS.Tabla = " Articulos a "
            frmS.FiltroText = "Enter the Product to filter"
            frmS.Filtro = " a.art_DCorta "
            frmS.Limite = 50
            frmS.Ordenamiento = " a.art_DCorta "
            frmS.TipoOrdenamiento = "Asc"
            frmS.Condicion = "a.art_sisemp =" & Sesion.IdEmpresa & " AND a.art_status = 1 "
            frmS.Multiple = True

                    frmS.ShowDialog(Me)

            If frmS.DialogResult = System.Windows.Forms.DialogResult.OK Then
                For j As Integer = 0 To frmS.DataGrid.Rows.Count - 1
                    If frmS.ListaClientes.Rows(j).Cells("colCheck").Value = True Then
                        If dglistadoDetalle.Rows.Count > 0 Then
                            For i = 0 To dglistadoDetalle.Rows.Count - 1
                                If frmS.ListaClientes.CurrentRow.Cells(1).Value = dglistadoDetalle.Rows(i).Cells("colCodigo").Value Then
                                    MsgBox("The Client already has been selected, please select other one", vbInformation, "Notice")
                                    Exit Sub
                                End If
                            Next
                        End If
                        strfila = frmS.ListaClientes.Rows(j).Cells(1).Value & "|"
                        strfila &= frmS.ListaClientes.Rows(j).Cells(2).Value & "|"
                        strfila &= 0 & "|"
                        strfila &= Sesion.Empresa & "|"
                        'strfila &= frmS.Dato2 & "|"
                        strfila &= Sesion.IdEmpresa & "|"
                        strfila &= 0

                        cfun.AgregarFila(dglistadoDetalle, strfila)
                    End If
                Next
            End If


        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try

    End Sub
#End Region

#Region "Eventos"
    Private Sub frmCategoriaMercadeo_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        MostrarLista()
        Accesos()
    End Sub

    Private Sub dgListaPrincipal_CellContentClick(sender As Object, e As DataGridViewCellEventArgs) Handles dgListaPrincipal.CellContentClick

    End Sub

    Private Sub Encabezado1_ClickNuevo(sender As Object, click As Boolean) Handles Encabezado1.ClickNuevo
        Dim frms As New frmSeleccionar

        Try
            If logInsertar = True Then
                Me.Tag = "Nuevo"

                LimpiarCampos()
                MostrarLista(False, True)
            Else
                MsgBox("You do not have permission for this action", MsgBoxStyle.Information)
            End If

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub Encabezado1_ClickCerrar(sender As Object, click As Boolean) Handles Encabezado1.ClickCerrar
        If panelListaPrincipal.Visible = True Then
            Me.Close()
            Fprincipal.BarraDeTareas1.QuitarFormulario(Key)
        Else
            MostrarLista()
        End If
    End Sub

    Private Sub botonAgregar_Click(sender As Object, e As EventArgs) Handles botonAgregar.Click
        CargarInformacion()
    End Sub

    Private Sub botonQuitar_Click(sender As Object, e As EventArgs) Handles botonQuitar.Click
        dglistadoDetalle.CurrentRow.Cells("colExtra").Value = 2
        dglistadoDetalle.CurrentRow.Visible = False
    End Sub

    Private Sub Encabezado1_ClickGuardar(sender As Object, click As Boolean) Handles Encabezado1.ClickGuardar
        Dim strSQL As String = STR_VACIO
        Dim COM As MySqlCommand
        Dim numeroGrupo As Integer = 0
        Try


            If Me.Tag = "Nuevo" Then
                strSQL = " Select ifnull(MAX(Cat_IdCategoria +1),1) num From CategoriaMercadeo_HDR c WHERE c.Cat_Empresa = " & Sesion.IdEmpresa
                MyCnn.CONECTAR = strConexion
                COM = New MySqlCommand(strSQL, CON)
                numeroGrupo = COM.ExecuteScalar
                celdaNumero.Text = numeroGrupo
            End If

            If celdaNumero.Text > 0 Then
                If logInsertar = True And Me.Tag = "Nuevo" Then
                    If ComprobarCampos() = True Then
                        GuardarGrupo()
                        GuardarDetalleGrp()

                        If MsgBox("Information Saved Successfully", vbInformation, "Notice") = vbOK Then
                            MostrarLista(True)
                        Else
                            Me.Tag = "Mod"
                        End If
                    Else
                        MsgBox("Please enter the minimum data to continue", vbExclamation, "Notice")
                        Exit Sub
                    End If

                ElseIf logEditar = True And Me.Tag = "Mod" Then ' Verifica si tiene permiso de editar
                    If ComprobarCampos() = True Then
                        GuardarGrupo()
                        GuardarDetalleGrp()

                        If MsgBox("Information Updated Successfully", vbInformation, "Notice") = vbOK Then
                            MostrarLista(True)
                        Else
                            Me.Tag = "Mod"
                        End If

                    Else
                        MsgBox("Please enter the minimum data to continue", vbExclamation, "Notice")
                        Exit Sub
                    End If
                Else
                    MsgBox("You do not have permission for this action", MsgBoxStyle.Information)
                    Exit Sub
                End If

            End If

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub dgListaPrincipal_DoubleClick(sender As Object, e As EventArgs) Handles dgListaPrincipal.DoubleClick
        Dim intGrupo As Integer = INT_CERO

        Try
            intGrupo = dgListaPrincipal.SelectedCells(0).Value
            ' intTipo = dgListaPrincipal.SelectedCells(2).Value
            LimpiarCampos()
            CargarDatosGrupo(intGrupo)
            MostrarLista(False, False)
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub
#End Region

    Private Sub dglistadoDetalle_CellContentClick(sender As Object, e As DataGridViewCellEventArgs) Handles dglistadoDetalle.CellContentClick

    End Sub

    Private Sub Encabezado1_ClickBorrar(sender As Object, click As Boolean) Handles Encabezado1.ClickBorrar
        If LogBorrar = True Then
            If MsgBox("Are You sure " & vbCr & vbCr & "¿do you want to delete this document? ", vbQuestion + vbYesNo, "Aviso") = vbYes Then
                BorrarEncabezadoGrupo()
                BorrarDetalleGrupo()
                MsgBox("Data deleted correctly", MsgBoxStyle.Information)
                MostrarLista()
            End If
        Else
            MsgBox("You do not have permission for this action", MsgBoxStyle.Information)
            Exit Sub
        End If

    End Sub
End Class