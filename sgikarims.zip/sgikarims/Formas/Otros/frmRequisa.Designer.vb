﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class frmRequisa
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Dim DataGridViewCellStyle1 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle2 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle3 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle4 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle5 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle6 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmRequisa))
        Me.PanelLista = New System.Windows.Forms.Panel()
        Me.dgLista = New System.Windows.Forms.DataGridView()
        Me.panelFiltro = New System.Windows.Forms.Panel()
        Me.checkLocal = New System.Windows.Forms.CheckBox()
        Me.checkInternacional = New System.Windows.Forms.CheckBox()
        Me.checkUrgente = New System.Windows.Forms.CheckBox()
        Me.botonActualizar = New System.Windows.Forms.Button()
        Me.checkFiltroFecha = New System.Windows.Forms.CheckBox()
        Me.dtpFechaFinal = New System.Windows.Forms.DateTimePicker()
        Me.dtpFechaInicial = New System.Windows.Forms.DateTimePicker()
        Me.PanelPiePagina = New System.Windows.Forms.Panel()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.TextBox1 = New System.Windows.Forms.TextBox()
        Me.etiquetaNaranja = New System.Windows.Forms.Label()
        Me.etiquetaISR = New System.Windows.Forms.Label()
        Me.etiquetaRoja = New System.Windows.Forms.Label()
        Me.celdaNaranja = New System.Windows.Forms.TextBox()
        Me.celdaRosa = New System.Windows.Forms.TextBox()
        Me.celdaRoja = New System.Windows.Forms.TextBox()
        Me.panelDocumento = New System.Windows.Forms.Panel()
        Me.PanelDetalle = New System.Windows.Forms.Panel()
        Me.dgDetalle = New System.Windows.Forms.DataGridView()
        Me.PanelTotal = New System.Windows.Forms.Panel()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.celdaComentarios = New System.Windows.Forms.TextBox()
        Me.celdaTotal = New System.Windows.Forms.TextBox()
        Me.Label17 = New System.Windows.Forms.Label()
        Me.PanelBotones = New System.Windows.Forms.Panel()
        Me.botonEliminar = New System.Windows.Forms.Button()
        Me.botonAgregar = New System.Windows.Forms.Button()
        Me.panelEncabezado = New System.Windows.Forms.Panel()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.rbLocal = New System.Windows.Forms.RadioButton()
        Me.rbInternacional = New System.Windows.Forms.RadioButton()
        Me.checkAutorizar = New System.Windows.Forms.CheckBox()
        Me.celdaNombre = New System.Windows.Forms.TextBox()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.dtpFecha = New System.Windows.Forms.DateTimePicker()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.celdaNumero = New System.Windows.Forms.TextBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.checkActive = New System.Windows.Forms.CheckBox()
        Me.celdaAño = New System.Windows.Forms.TextBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.rbRequisa = New System.Windows.Forms.RadioButton()
        Me.rbCotizacion = New System.Windows.Forms.RadioButton()
        Me.rbOrdenCompra = New System.Windows.Forms.RadioButton()
        Me.BarraTitulo1 = New KARIMs_SGI.BarraTitulo()
        Me.Encabezado1 = New KARIMs_SGI.encabezado()
        Me.colCodigo = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colDescripcionArticulo = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colIdMedida = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colUM = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colCantidad = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colNumeroCosto = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colCentroCosto = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colCodMaquina = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colDepartamento = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colDescripcionMaquina = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colNumeroParte = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colMarca = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colModelo = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colSerie = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colCatalogo = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colStockWarehouse = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colStock = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colUltimoPrecio = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colMontoAprox = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colPresupuesto = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colLinea = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colStatus = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colCodDepartamento = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colCodMaquinaRef = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colCodDepartamentoRef = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colPrioridad = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colFase = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colAnio = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colNumero = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colFecha = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colDescripcion = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colTipo = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colEstado = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colAutorizar = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.col_Fase = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.PanelLista.SuspendLayout()
        CType(Me.dgLista, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.panelFiltro.SuspendLayout()
        Me.PanelPiePagina.SuspendLayout()
        Me.panelDocumento.SuspendLayout()
        Me.PanelDetalle.SuspendLayout()
        CType(Me.dgDetalle, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.PanelTotal.SuspendLayout()
        Me.PanelBotones.SuspendLayout()
        Me.panelEncabezado.SuspendLayout()
        Me.GroupBox1.SuspendLayout()
        Me.SuspendLayout()
        '
        'PanelLista
        '
        Me.PanelLista.Controls.Add(Me.dgLista)
        Me.PanelLista.Controls.Add(Me.panelFiltro)
        Me.PanelLista.Controls.Add(Me.PanelPiePagina)
        Me.PanelLista.Location = New System.Drawing.Point(11, 87)
        Me.PanelLista.Margin = New System.Windows.Forms.Padding(2)
        Me.PanelLista.Name = "PanelLista"
        Me.PanelLista.Size = New System.Drawing.Size(513, 174)
        Me.PanelLista.TabIndex = 10
        '
        'dgLista
        '
        Me.dgLista.AllowUserToAddRows = False
        Me.dgLista.AllowUserToDeleteRows = False
        Me.dgLista.AllowUserToOrderColumns = True
        Me.dgLista.BackgroundColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle1.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.dgLista.ColumnHeadersDefaultCellStyle = DataGridViewCellStyle1
        Me.dgLista.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgLista.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.colAnio, Me.colNumero, Me.colFecha, Me.colDescripcion, Me.colTipo, Me.colEstado, Me.colAutorizar, Me.col_Fase})
        DataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle2.BackColor = System.Drawing.SystemColors.Window
        DataGridViewCellStyle2.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.ControlText
        DataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.[False]
        Me.dgLista.DefaultCellStyle = DataGridViewCellStyle2
        Me.dgLista.Dock = System.Windows.Forms.DockStyle.Fill
        Me.dgLista.Location = New System.Drawing.Point(0, 72)
        Me.dgLista.Margin = New System.Windows.Forms.Padding(2)
        Me.dgLista.MultiSelect = False
        Me.dgLista.Name = "dgLista"
        Me.dgLista.ReadOnly = True
        DataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle3.BackColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle3.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle3.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle3.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle3.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.dgLista.RowHeadersDefaultCellStyle = DataGridViewCellStyle3
        Me.dgLista.RowTemplate.Height = 24
        Me.dgLista.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.dgLista.Size = New System.Drawing.Size(513, 44)
        Me.dgLista.TabIndex = 0
        '
        'panelFiltro
        '
        Me.panelFiltro.Controls.Add(Me.rbOrdenCompra)
        Me.panelFiltro.Controls.Add(Me.rbCotizacion)
        Me.panelFiltro.Controls.Add(Me.rbRequisa)
        Me.panelFiltro.Controls.Add(Me.checkLocal)
        Me.panelFiltro.Controls.Add(Me.checkInternacional)
        Me.panelFiltro.Controls.Add(Me.checkUrgente)
        Me.panelFiltro.Controls.Add(Me.botonActualizar)
        Me.panelFiltro.Controls.Add(Me.checkFiltroFecha)
        Me.panelFiltro.Controls.Add(Me.dtpFechaFinal)
        Me.panelFiltro.Controls.Add(Me.dtpFechaInicial)
        Me.panelFiltro.Dock = System.Windows.Forms.DockStyle.Top
        Me.panelFiltro.Location = New System.Drawing.Point(0, 0)
        Me.panelFiltro.Margin = New System.Windows.Forms.Padding(2)
        Me.panelFiltro.Name = "panelFiltro"
        Me.panelFiltro.Size = New System.Drawing.Size(513, 72)
        Me.panelFiltro.TabIndex = 3
        '
        'checkLocal
        '
        Me.checkLocal.AutoSize = True
        Me.checkLocal.Checked = True
        Me.checkLocal.CheckState = System.Windows.Forms.CheckState.Checked
        Me.checkLocal.Location = New System.Drawing.Point(532, 35)
        Me.checkLocal.Margin = New System.Windows.Forms.Padding(2)
        Me.checkLocal.Name = "checkLocal"
        Me.checkLocal.Size = New System.Drawing.Size(52, 17)
        Me.checkLocal.TabIndex = 12
        Me.checkLocal.Text = "Local"
        Me.checkLocal.UseVisualStyleBackColor = True
        '
        'checkInternacional
        '
        Me.checkInternacional.AutoSize = True
        Me.checkInternacional.Checked = True
        Me.checkInternacional.CheckState = System.Windows.Forms.CheckState.Checked
        Me.checkInternacional.Location = New System.Drawing.Point(532, 11)
        Me.checkInternacional.Margin = New System.Windows.Forms.Padding(2)
        Me.checkInternacional.Name = "checkInternacional"
        Me.checkInternacional.Size = New System.Drawing.Size(84, 17)
        Me.checkInternacional.TabIndex = 11
        Me.checkInternacional.Text = "International"
        Me.checkInternacional.UseVisualStyleBackColor = True
        '
        'checkUrgente
        '
        Me.checkUrgente.AutoSize = True
        Me.checkUrgente.Location = New System.Drawing.Point(460, 11)
        Me.checkUrgente.Margin = New System.Windows.Forms.Padding(2)
        Me.checkUrgente.Name = "checkUrgente"
        Me.checkUrgente.Size = New System.Drawing.Size(58, 17)
        Me.checkUrgente.TabIndex = 10
        Me.checkUrgente.Text = "Urgent"
        Me.checkUrgente.UseVisualStyleBackColor = True
        '
        'botonActualizar
        '
        Me.botonActualizar.Location = New System.Drawing.Point(763, 19)
        Me.botonActualizar.Margin = New System.Windows.Forms.Padding(2)
        Me.botonActualizar.Name = "botonActualizar"
        Me.botonActualizar.Size = New System.Drawing.Size(56, 24)
        Me.botonActualizar.TabIndex = 3
        Me.botonActualizar.Text = "Update"
        Me.botonActualizar.TextAlign = System.Drawing.ContentAlignment.TopCenter
        Me.botonActualizar.UseVisualStyleBackColor = True
        '
        'checkFiltroFecha
        '
        Me.checkFiltroFecha.AutoSize = True
        Me.checkFiltroFecha.Checked = True
        Me.checkFiltroFecha.CheckState = System.Windows.Forms.CheckState.Checked
        Me.checkFiltroFecha.Location = New System.Drawing.Point(10, 10)
        Me.checkFiltroFecha.Margin = New System.Windows.Forms.Padding(2)
        Me.checkFiltroFecha.Name = "checkFiltroFecha"
        Me.checkFiltroFecha.Size = New System.Drawing.Size(183, 17)
        Me.checkFiltroFecha.TabIndex = 0
        Me.checkFiltroFecha.Text = "Show Documents between dates"
        Me.checkFiltroFecha.UseVisualStyleBackColor = True
        '
        'dtpFechaFinal
        '
        Me.dtpFechaFinal.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.dtpFechaFinal.Location = New System.Drawing.Point(333, 10)
        Me.dtpFechaFinal.Margin = New System.Windows.Forms.Padding(2)
        Me.dtpFechaFinal.Name = "dtpFechaFinal"
        Me.dtpFechaFinal.Size = New System.Drawing.Size(114, 20)
        Me.dtpFechaFinal.TabIndex = 2
        '
        'dtpFechaInicial
        '
        Me.dtpFechaInicial.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.dtpFechaInicial.Location = New System.Drawing.Point(215, 9)
        Me.dtpFechaInicial.Margin = New System.Windows.Forms.Padding(2)
        Me.dtpFechaInicial.Name = "dtpFechaInicial"
        Me.dtpFechaInicial.Size = New System.Drawing.Size(114, 20)
        Me.dtpFechaInicial.TabIndex = 1
        '
        'PanelPiePagina
        '
        Me.PanelPiePagina.Controls.Add(Me.Label5)
        Me.PanelPiePagina.Controls.Add(Me.TextBox1)
        Me.PanelPiePagina.Controls.Add(Me.etiquetaNaranja)
        Me.PanelPiePagina.Controls.Add(Me.etiquetaISR)
        Me.PanelPiePagina.Controls.Add(Me.etiquetaRoja)
        Me.PanelPiePagina.Controls.Add(Me.celdaNaranja)
        Me.PanelPiePagina.Controls.Add(Me.celdaRosa)
        Me.PanelPiePagina.Controls.Add(Me.celdaRoja)
        Me.PanelPiePagina.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.PanelPiePagina.Location = New System.Drawing.Point(0, 116)
        Me.PanelPiePagina.Margin = New System.Windows.Forms.Padding(2)
        Me.PanelPiePagina.Name = "PanelPiePagina"
        Me.PanelPiePagina.Size = New System.Drawing.Size(513, 58)
        Me.PanelPiePagina.TabIndex = 4
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(427, 37)
        Me.Label5.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(121, 13)
        Me.Label5.TabIndex = 10
        Me.Label5.Text = "MANAGER APPROVAL"
        '
        'TextBox1
        '
        Me.TextBox1.BackColor = System.Drawing.Color.YellowGreen
        Me.TextBox1.Location = New System.Drawing.Point(407, 32)
        Me.TextBox1.Margin = New System.Windows.Forms.Padding(2)
        Me.TextBox1.Name = "TextBox1"
        Me.TextBox1.Size = New System.Drawing.Size(16, 20)
        Me.TextBox1.TabIndex = 9
        '
        'etiquetaNaranja
        '
        Me.etiquetaNaranja.AutoSize = True
        Me.etiquetaNaranja.Location = New System.Drawing.Point(217, 37)
        Me.etiquetaNaranja.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.etiquetaNaranja.Name = "etiquetaNaranja"
        Me.etiquetaNaranja.Size = New System.Drawing.Size(176, 13)
        Me.etiquetaNaranja.TabIndex = 8
        Me.etiquetaNaranja.Text = "INTERNAL CONTROL APPROVAL"
        '
        'etiquetaISR
        '
        Me.etiquetaISR.AutoSize = True
        Me.etiquetaISR.Location = New System.Drawing.Point(129, 37)
        Me.etiquetaISR.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.etiquetaISR.Name = "etiquetaISR"
        Me.etiquetaISR.Size = New System.Drawing.Size(53, 13)
        Me.etiquetaISR.TabIndex = 7
        Me.etiquetaISR.Text = "URGENT"
        '
        'etiquetaRoja
        '
        Me.etiquetaRoja.AutoSize = True
        Me.etiquetaRoja.Location = New System.Drawing.Point(28, 36)
        Me.etiquetaRoja.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.etiquetaRoja.Name = "etiquetaRoja"
        Me.etiquetaRoja.Size = New System.Drawing.Size(70, 13)
        Me.etiquetaRoja.TabIndex = 6
        Me.etiquetaRoja.Text = "-CANCELED-"
        '
        'celdaNaranja
        '
        Me.celdaNaranja.BackColor = System.Drawing.Color.SkyBlue
        Me.celdaNaranja.Location = New System.Drawing.Point(197, 32)
        Me.celdaNaranja.Margin = New System.Windows.Forms.Padding(2)
        Me.celdaNaranja.Name = "celdaNaranja"
        Me.celdaNaranja.Size = New System.Drawing.Size(16, 20)
        Me.celdaNaranja.TabIndex = 2
        '
        'celdaRosa
        '
        Me.celdaRosa.BackColor = System.Drawing.Color.Orange
        Me.celdaRosa.Location = New System.Drawing.Point(109, 32)
        Me.celdaRosa.Margin = New System.Windows.Forms.Padding(2)
        Me.celdaRosa.Name = "celdaRosa"
        Me.celdaRosa.Size = New System.Drawing.Size(16, 20)
        Me.celdaRosa.TabIndex = 1
        '
        'celdaRoja
        '
        Me.celdaRoja.BackColor = System.Drawing.Color.LightCoral
        Me.celdaRoja.Location = New System.Drawing.Point(9, 32)
        Me.celdaRoja.Margin = New System.Windows.Forms.Padding(2)
        Me.celdaRoja.Name = "celdaRoja"
        Me.celdaRoja.Size = New System.Drawing.Size(16, 20)
        Me.celdaRoja.TabIndex = 0
        '
        'panelDocumento
        '
        Me.panelDocumento.Controls.Add(Me.PanelDetalle)
        Me.panelDocumento.Controls.Add(Me.panelEncabezado)
        Me.panelDocumento.Location = New System.Drawing.Point(11, 265)
        Me.panelDocumento.Margin = New System.Windows.Forms.Padding(2)
        Me.panelDocumento.Name = "panelDocumento"
        Me.panelDocumento.Size = New System.Drawing.Size(513, 415)
        Me.panelDocumento.TabIndex = 11
        '
        'PanelDetalle
        '
        Me.PanelDetalle.Controls.Add(Me.dgDetalle)
        Me.PanelDetalle.Controls.Add(Me.PanelTotal)
        Me.PanelDetalle.Controls.Add(Me.PanelBotones)
        Me.PanelDetalle.Dock = System.Windows.Forms.DockStyle.Fill
        Me.PanelDetalle.Location = New System.Drawing.Point(0, 135)
        Me.PanelDetalle.Margin = New System.Windows.Forms.Padding(2)
        Me.PanelDetalle.Name = "PanelDetalle"
        Me.PanelDetalle.Size = New System.Drawing.Size(513, 280)
        Me.PanelDetalle.TabIndex = 6
        '
        'dgDetalle
        '
        Me.dgDetalle.AllowUserToAddRows = False
        Me.dgDetalle.AllowUserToOrderColumns = True
        Me.dgDetalle.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells
        Me.dgDetalle.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells
        Me.dgDetalle.BackgroundColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle4.BackColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle4.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle4.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle4.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle4.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle4.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.dgDetalle.ColumnHeadersDefaultCellStyle = DataGridViewCellStyle4
        Me.dgDetalle.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgDetalle.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.colCodigo, Me.colDescripcionArticulo, Me.colIdMedida, Me.colUM, Me.colCantidad, Me.colNumeroCosto, Me.colCentroCosto, Me.colCodMaquina, Me.colDepartamento, Me.colDescripcionMaquina, Me.colNumeroParte, Me.colMarca, Me.colModelo, Me.colSerie, Me.colCatalogo, Me.colStockWarehouse, Me.colStock, Me.colUltimoPrecio, Me.colMontoAprox, Me.colPresupuesto, Me.colLinea, Me.colStatus, Me.colCodDepartamento, Me.colCodMaquinaRef, Me.colCodDepartamentoRef, Me.colPrioridad, Me.colFase})
        DataGridViewCellStyle5.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle5.BackColor = System.Drawing.SystemColors.Window
        DataGridViewCellStyle5.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle5.ForeColor = System.Drawing.SystemColors.ControlText
        DataGridViewCellStyle5.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle5.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle5.WrapMode = System.Windows.Forms.DataGridViewTriState.[False]
        Me.dgDetalle.DefaultCellStyle = DataGridViewCellStyle5
        Me.dgDetalle.Dock = System.Windows.Forms.DockStyle.Fill
        Me.dgDetalle.Location = New System.Drawing.Point(0, 0)
        Me.dgDetalle.Margin = New System.Windows.Forms.Padding(2)
        Me.dgDetalle.MultiSelect = False
        Me.dgDetalle.Name = "dgDetalle"
        DataGridViewCellStyle6.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle6.BackColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle6.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle6.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle6.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle6.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle6.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.dgDetalle.RowHeadersDefaultCellStyle = DataGridViewCellStyle6
        Me.dgDetalle.RowTemplate.Height = 24
        Me.dgDetalle.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.dgDetalle.Size = New System.Drawing.Size(471, 145)
        Me.dgDetalle.TabIndex = 0
        '
        'PanelTotal
        '
        Me.PanelTotal.Controls.Add(Me.Label6)
        Me.PanelTotal.Controls.Add(Me.celdaComentarios)
        Me.PanelTotal.Controls.Add(Me.celdaTotal)
        Me.PanelTotal.Controls.Add(Me.Label17)
        Me.PanelTotal.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.PanelTotal.Location = New System.Drawing.Point(0, 145)
        Me.PanelTotal.Margin = New System.Windows.Forms.Padding(2)
        Me.PanelTotal.Name = "PanelTotal"
        Me.PanelTotal.Size = New System.Drawing.Size(471, 135)
        Me.PanelTotal.TabIndex = 5
        '
        'Label6
        '
        Me.Label6.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(-1188, 5)
        Me.Label6.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(56, 13)
        Me.Label6.TabIndex = 28
        Me.Label6.Text = "Comments"
        '
        'celdaComentarios
        '
        Me.celdaComentarios.AllowDrop = True
        Me.celdaComentarios.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.celdaComentarios.BackColor = System.Drawing.SystemColors.HighlightText
        Me.celdaComentarios.ForeColor = System.Drawing.SystemColors.InfoText
        Me.celdaComentarios.Location = New System.Drawing.Point(-1185, 21)
        Me.celdaComentarios.Margin = New System.Windows.Forms.Padding(2)
        Me.celdaComentarios.Multiline = True
        Me.celdaComentarios.Name = "celdaComentarios"
        Me.celdaComentarios.ReadOnly = True
        Me.celdaComentarios.ScrollBars = System.Windows.Forms.ScrollBars.Both
        Me.celdaComentarios.Size = New System.Drawing.Size(997, 98)
        Me.celdaComentarios.TabIndex = 27
        Me.celdaComentarios.Text = "    "
        '
        'celdaTotal
        '
        Me.celdaTotal.AllowDrop = True
        Me.celdaTotal.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.celdaTotal.BackColor = System.Drawing.SystemColors.HighlightText
        Me.celdaTotal.Enabled = False
        Me.celdaTotal.ForeColor = System.Drawing.SystemColors.InfoText
        Me.celdaTotal.Location = New System.Drawing.Point(333, 21)
        Me.celdaTotal.Margin = New System.Windows.Forms.Padding(2)
        Me.celdaTotal.Name = "celdaTotal"
        Me.celdaTotal.Size = New System.Drawing.Size(121, 20)
        Me.celdaTotal.TabIndex = 26
        Me.celdaTotal.Text = "    "
        '
        'Label17
        '
        Me.Label17.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label17.AutoSize = True
        Me.Label17.Location = New System.Drawing.Point(330, 5)
        Me.Label17.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label17.Name = "Label17"
        Me.Label17.Size = New System.Drawing.Size(31, 13)
        Me.Label17.TabIndex = 3
        Me.Label17.Text = "Total"
        '
        'PanelBotones
        '
        Me.PanelBotones.Controls.Add(Me.botonEliminar)
        Me.PanelBotones.Controls.Add(Me.botonAgregar)
        Me.PanelBotones.Dock = System.Windows.Forms.DockStyle.Right
        Me.PanelBotones.Location = New System.Drawing.Point(471, 0)
        Me.PanelBotones.Margin = New System.Windows.Forms.Padding(2)
        Me.PanelBotones.Name = "PanelBotones"
        Me.PanelBotones.Size = New System.Drawing.Size(42, 280)
        Me.PanelBotones.TabIndex = 4
        '
        'botonEliminar
        '
        Me.botonEliminar.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.botonEliminar.BackColor = System.Drawing.SystemColors.Control
        Me.botonEliminar.Image = Global.KARIMs_SGI.My.Resources.Resources.delete3
        Me.botonEliminar.Location = New System.Drawing.Point(5, 44)
        Me.botonEliminar.Name = "botonEliminar"
        Me.botonEliminar.Size = New System.Drawing.Size(31, 28)
        Me.botonEliminar.TabIndex = 12
        Me.botonEliminar.UseVisualStyleBackColor = False
        '
        'botonAgregar
        '
        Me.botonAgregar.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.botonAgregar.BackColor = System.Drawing.SystemColors.Control
        Me.botonAgregar.Image = Global.KARIMs_SGI.My.Resources.Resources.add
        Me.botonAgregar.Location = New System.Drawing.Point(4, 8)
        Me.botonAgregar.Name = "botonAgregar"
        Me.botonAgregar.Size = New System.Drawing.Size(31, 28)
        Me.botonAgregar.TabIndex = 11
        Me.botonAgregar.UseVisualStyleBackColor = False
        '
        'panelEncabezado
        '
        Me.panelEncabezado.Controls.Add(Me.GroupBox1)
        Me.panelEncabezado.Dock = System.Windows.Forms.DockStyle.Top
        Me.panelEncabezado.Location = New System.Drawing.Point(0, 0)
        Me.panelEncabezado.Margin = New System.Windows.Forms.Padding(2)
        Me.panelEncabezado.Name = "panelEncabezado"
        Me.panelEncabezado.Size = New System.Drawing.Size(513, 135)
        Me.panelEncabezado.TabIndex = 7
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.rbLocal)
        Me.GroupBox1.Controls.Add(Me.rbInternacional)
        Me.GroupBox1.Controls.Add(Me.checkAutorizar)
        Me.GroupBox1.Controls.Add(Me.celdaNombre)
        Me.GroupBox1.Controls.Add(Me.Label4)
        Me.GroupBox1.Controls.Add(Me.dtpFecha)
        Me.GroupBox1.Controls.Add(Me.Label3)
        Me.GroupBox1.Controls.Add(Me.celdaNumero)
        Me.GroupBox1.Controls.Add(Me.Label2)
        Me.GroupBox1.Controls.Add(Me.checkActive)
        Me.GroupBox1.Controls.Add(Me.celdaAño)
        Me.GroupBox1.Controls.Add(Me.Label1)
        Me.GroupBox1.Dock = System.Windows.Forms.DockStyle.Left
        Me.GroupBox1.Location = New System.Drawing.Point(0, 0)
        Me.GroupBox1.Margin = New System.Windows.Forms.Padding(2)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Padding = New System.Windows.Forms.Padding(2)
        Me.GroupBox1.Size = New System.Drawing.Size(513, 135)
        Me.GroupBox1.TabIndex = 1
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Document Data"
        '
        'rbLocal
        '
        Me.rbLocal.AutoSize = True
        Me.rbLocal.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.rbLocal.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.rbLocal.Location = New System.Drawing.Point(376, 83)
        Me.rbLocal.Name = "rbLocal"
        Me.rbLocal.Size = New System.Drawing.Size(56, 17)
        Me.rbLocal.TabIndex = 20
        Me.rbLocal.TabStop = True
        Me.rbLocal.Text = "Local"
        Me.rbLocal.UseVisualStyleBackColor = True
        '
        'rbInternacional
        '
        Me.rbInternacional.AutoSize = True
        Me.rbInternacional.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.rbInternacional.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.rbInternacional.Location = New System.Drawing.Point(376, 54)
        Me.rbInternacional.Name = "rbInternacional"
        Me.rbInternacional.Size = New System.Drawing.Size(96, 17)
        Me.rbInternacional.TabIndex = 19
        Me.rbInternacional.TabStop = True
        Me.rbInternacional.Text = "International"
        Me.rbInternacional.UseVisualStyleBackColor = True
        '
        'checkAutorizar
        '
        Me.checkAutorizar.AutoSize = True
        Me.checkAutorizar.Location = New System.Drawing.Point(376, 10)
        Me.checkAutorizar.Margin = New System.Windows.Forms.Padding(2)
        Me.checkAutorizar.Name = "checkAutorizar"
        Me.checkAutorizar.Size = New System.Drawing.Size(70, 17)
        Me.checkAutorizar.TabIndex = 9
        Me.checkAutorizar.Text = "Authorize"
        Me.checkAutorizar.UseVisualStyleBackColor = True
        '
        'celdaNombre
        '
        Me.celdaNombre.ForeColor = System.Drawing.SystemColors.InfoText
        Me.celdaNombre.Location = New System.Drawing.Point(76, 92)
        Me.celdaNombre.Margin = New System.Windows.Forms.Padding(2)
        Me.celdaNombre.Name = "celdaNombre"
        Me.celdaNombre.Size = New System.Drawing.Size(296, 20)
        Me.celdaNombre.TabIndex = 8
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(4, 94)
        Me.Label4.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(56, 13)
        Me.Label4.TabIndex = 7
        Me.Label4.Text = "Requester"
        '
        'dtpFecha
        '
        Me.dtpFecha.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.dtpFecha.Location = New System.Drawing.Point(253, 60)
        Me.dtpFecha.Margin = New System.Windows.Forms.Padding(2)
        Me.dtpFecha.Name = "dtpFecha"
        Me.dtpFecha.Size = New System.Drawing.Size(117, 20)
        Me.dtpFecha.TabIndex = 6
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(216, 63)
        Me.Label3.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(30, 13)
        Me.Label3.TabIndex = 5
        Me.Label3.Text = "Date"
        '
        'celdaNumero
        '
        Me.celdaNumero.BackColor = System.Drawing.SystemColors.Window
        Me.celdaNumero.Enabled = False
        Me.celdaNumero.ForeColor = System.Drawing.SystemColors.MenuHighlight
        Me.celdaNumero.Location = New System.Drawing.Point(76, 58)
        Me.celdaNumero.Margin = New System.Windows.Forms.Padding(2)
        Me.celdaNumero.Name = "celdaNumero"
        Me.celdaNumero.ReadOnly = True
        Me.celdaNumero.Size = New System.Drawing.Size(80, 20)
        Me.celdaNumero.TabIndex = 4
        Me.celdaNumero.Text = "-1"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(4, 58)
        Me.Label2.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(44, 13)
        Me.Label2.TabIndex = 3
        Me.Label2.Text = "Number"
        '
        'checkActive
        '
        Me.checkActive.AutoSize = True
        Me.checkActive.Checked = True
        Me.checkActive.CheckState = System.Windows.Forms.CheckState.Checked
        Me.checkActive.Location = New System.Drawing.Point(253, 10)
        Me.checkActive.Margin = New System.Windows.Forms.Padding(2)
        Me.checkActive.Name = "checkActive"
        Me.checkActive.Size = New System.Drawing.Size(56, 17)
        Me.checkActive.TabIndex = 2
        Me.checkActive.Text = "Active"
        Me.checkActive.UseVisualStyleBackColor = True
        '
        'celdaAño
        '
        Me.celdaAño.Enabled = False
        Me.celdaAño.ForeColor = System.Drawing.SystemColors.MenuHighlight
        Me.celdaAño.Location = New System.Drawing.Point(76, 28)
        Me.celdaAño.Margin = New System.Windows.Forms.Padding(2)
        Me.celdaAño.Name = "celdaAño"
        Me.celdaAño.Size = New System.Drawing.Size(80, 20)
        Me.celdaAño.TabIndex = 1
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(4, 28)
        Me.Label1.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(29, 13)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "Year"
        '
        'rbRequisa
        '
        Me.rbRequisa.AutoSize = True
        Me.rbRequisa.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.rbRequisa.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.rbRequisa.Location = New System.Drawing.Point(635, 3)
        Me.rbRequisa.Name = "rbRequisa"
        Me.rbRequisa.Size = New System.Drawing.Size(88, 17)
        Me.rbRequisa.TabIndex = 20
        Me.rbRequisa.TabStop = True
        Me.rbRequisa.Text = "Requisition"
        Me.rbRequisa.UseVisualStyleBackColor = True
        '
        'rbCotizacion
        '
        Me.rbCotizacion.AutoSize = True
        Me.rbCotizacion.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.rbCotizacion.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.rbCotizacion.Location = New System.Drawing.Point(635, 26)
        Me.rbCotizacion.Name = "rbCotizacion"
        Me.rbCotizacion.Size = New System.Drawing.Size(66, 17)
        Me.rbCotizacion.TabIndex = 21
        Me.rbCotizacion.TabStop = True
        Me.rbCotizacion.Text = "Quoted"
        Me.rbCotizacion.UseVisualStyleBackColor = True
        '
        'rbOrdenCompra
        '
        Me.rbOrdenCompra.AutoSize = True
        Me.rbOrdenCompra.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.rbOrdenCompra.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.rbOrdenCompra.Location = New System.Drawing.Point(635, 49)
        Me.rbOrdenCompra.Name = "rbOrdenCompra"
        Me.rbOrdenCompra.Size = New System.Drawing.Size(113, 17)
        Me.rbOrdenCompra.TabIndex = 22
        Me.rbOrdenCompra.TabStop = True
        Me.rbOrdenCompra.Text = "Purchase Order"
        Me.rbOrdenCompra.UseVisualStyleBackColor = True
        '
        'BarraTitulo1
        '
        Me.BarraTitulo1.BackColor = System.Drawing.Color.WhiteSmoke
        Me.BarraTitulo1.Dock = System.Windows.Forms.DockStyle.Top
        Me.BarraTitulo1.Location = New System.Drawing.Point(0, 57)
        Me.BarraTitulo1.Margin = New System.Windows.Forms.Padding(4)
        Me.BarraTitulo1.Name = "BarraTitulo1"
        Me.BarraTitulo1.Size = New System.Drawing.Size(542, 24)
        Me.BarraTitulo1.TabIndex = 2
        '
        'Encabezado1
        '
        Me.Encabezado1.Dock = System.Windows.Forms.DockStyle.Top
        Me.Encabezado1.Location = New System.Drawing.Point(0, 0)
        Me.Encabezado1.Margin = New System.Windows.Forms.Padding(4)
        Me.Encabezado1.Name = "Encabezado1"
        Me.Encabezado1.Size = New System.Drawing.Size(542, 57)
        Me.Encabezado1.TabIndex = 1
        '
        'colCodigo
        '
        Me.colCodigo.HeaderText = "Code"
        Me.colCodigo.Name = "colCodigo"
        Me.colCodigo.Width = 57
        '
        'colDescripcionArticulo
        '
        Me.colDescripcionArticulo.HeaderText = "Description"
        Me.colDescripcionArticulo.Name = "colDescripcionArticulo"
        Me.colDescripcionArticulo.Width = 85
        '
        'colIdMedida
        '
        Me.colIdMedida.HeaderText = "IdUM"
        Me.colIdMedida.Name = "colIdMedida"
        Me.colIdMedida.Visible = False
        Me.colIdMedida.Width = 58
        '
        'colUM
        '
        Me.colUM.HeaderText = "UM"
        Me.colUM.Name = "colUM"
        Me.colUM.ReadOnly = True
        Me.colUM.Width = 49
        '
        'colCantidad
        '
        Me.colCantidad.HeaderText = "Quantity"
        Me.colCantidad.Name = "colCantidad"
        Me.colCantidad.Width = 71
        '
        'colNumeroCosto
        '
        Me.colNumeroCosto.HeaderText = "Cost Number"
        Me.colNumeroCosto.Name = "colNumeroCosto"
        Me.colNumeroCosto.ReadOnly = True
        Me.colNumeroCosto.Visible = False
        Me.colNumeroCosto.Width = 93
        '
        'colCentroCosto
        '
        Me.colCentroCosto.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.colCentroCosto.HeaderText = "Cost Center"
        Me.colCentroCosto.Name = "colCentroCosto"
        Me.colCentroCosto.ReadOnly = True
        Me.colCentroCosto.Width = 87
        '
        'colCodMaquina
        '
        Me.colCodMaquina.HeaderText = "codMaquina"
        Me.colCodMaquina.Name = "colCodMaquina"
        Me.colCodMaquina.Visible = False
        Me.colCodMaquina.Width = 91
        '
        'colDepartamento
        '
        Me.colDepartamento.HeaderText = "Department"
        Me.colDepartamento.Name = "colDepartamento"
        Me.colDepartamento.ReadOnly = True
        Me.colDepartamento.Width = 87
        '
        'colDescripcionMaquina
        '
        Me.colDescripcionMaquina.HeaderText = "Machine Description"
        Me.colDescripcionMaquina.Name = "colDescripcionMaquina"
        Me.colDescripcionMaquina.ReadOnly = True
        Me.colDescripcionMaquina.Width = 118
        '
        'colNumeroParte
        '
        Me.colNumeroParte.HeaderText = "Part N°"
        Me.colNumeroParte.Name = "colNumeroParte"
        Me.colNumeroParte.Width = 51
        '
        'colMarca
        '
        Me.colMarca.HeaderText = "Brand"
        Me.colMarca.Name = "colMarca"
        Me.colMarca.ReadOnly = True
        Me.colMarca.Width = 60
        '
        'colModelo
        '
        Me.colModelo.HeaderText = "Model"
        Me.colModelo.Name = "colModelo"
        Me.colModelo.ReadOnly = True
        Me.colModelo.Width = 61
        '
        'colSerie
        '
        Me.colSerie.HeaderText = "Series"
        Me.colSerie.Name = "colSerie"
        Me.colSerie.ReadOnly = True
        Me.colSerie.Visible = False
        Me.colSerie.Width = 61
        '
        'colCatalogo
        '
        Me.colCatalogo.HeaderText = "N° Catalog"
        Me.colCatalogo.Name = "colCatalogo"
        Me.colCatalogo.Width = 77
        '
        'colStockWarehouse
        '
        Me.colStockWarehouse.HeaderText = "Stock Warehouse"
        Me.colStockWarehouse.Name = "colStockWarehouse"
        Me.colStockWarehouse.Width = 108
        '
        'colStock
        '
        Me.colStock.HeaderText = "Stock"
        Me.colStock.Name = "colStock"
        Me.colStock.Visible = False
        Me.colStock.Width = 60
        '
        'colUltimoPrecio
        '
        Me.colUltimoPrecio.HeaderText = "Last Unit Price"
        Me.colUltimoPrecio.Name = "colUltimoPrecio"
        Me.colUltimoPrecio.Width = 93
        '
        'colMontoAprox
        '
        Me.colMontoAprox.HeaderText = "Aproximate Amount"
        Me.colMontoAprox.Name = "colMontoAprox"
        Me.colMontoAprox.Width = 113
        '
        'colPresupuesto
        '
        Me.colPresupuesto.HeaderText = "Budget"
        Me.colPresupuesto.Name = "colPresupuesto"
        Me.colPresupuesto.ReadOnly = True
        Me.colPresupuesto.Width = 66
        '
        'colLinea
        '
        Me.colLinea.HeaderText = "linea"
        Me.colLinea.Name = "colLinea"
        Me.colLinea.Visible = False
        Me.colLinea.Width = 54
        '
        'colStatus
        '
        Me.colStatus.HeaderText = "Status"
        Me.colStatus.Name = "colStatus"
        Me.colStatus.ReadOnly = True
        Me.colStatus.Width = 62
        '
        'colCodDepartamento
        '
        Me.colCodDepartamento.HeaderText = "Cod Department"
        Me.colCodDepartamento.Name = "colCodDepartamento"
        Me.colCodDepartamento.Visible = False
        '
        'colCodMaquinaRef
        '
        Me.colCodMaquinaRef.HeaderText = "MachineRef"
        Me.colCodMaquinaRef.Name = "colCodMaquinaRef"
        Me.colCodMaquinaRef.Visible = False
        Me.colCodMaquinaRef.Width = 90
        '
        'colCodDepartamentoRef
        '
        Me.colCodDepartamentoRef.HeaderText = "Department Ref"
        Me.colCodDepartamentoRef.Name = "colCodDepartamentoRef"
        Me.colCodDepartamentoRef.Visible = False
        Me.colCodDepartamentoRef.Width = 98
        '
        'colPrioridad
        '
        Me.colPrioridad.HeaderText = "Priority"
        Me.colPrioridad.Name = "colPrioridad"
        Me.colPrioridad.ReadOnly = True
        Me.colPrioridad.Width = 63
        '
        'colFase
        '
        Me.colFase.HeaderText = "Phase"
        Me.colFase.Name = "colFase"
        Me.colFase.ReadOnly = True
        Me.colFase.Width = 62
        '
        'colAnio
        '
        Me.colAnio.HeaderText = "Year"
        Me.colAnio.Name = "colAnio"
        Me.colAnio.ReadOnly = True
        Me.colAnio.Width = 67
        '
        'colNumero
        '
        Me.colNumero.HeaderText = "Number"
        Me.colNumero.Name = "colNumero"
        Me.colNumero.ReadOnly = True
        Me.colNumero.Width = 87
        '
        'colFecha
        '
        Me.colFecha.HeaderText = "Date"
        Me.colFecha.Name = "colFecha"
        Me.colFecha.ReadOnly = True
        Me.colFecha.Width = 67
        '
        'colDescripcion
        '
        Me.colDescripcion.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.colDescripcion.HeaderText = "Description"
        Me.colDescripcion.Name = "colDescripcion"
        Me.colDescripcion.ReadOnly = True
        Me.colDescripcion.Width = 85
        '
        'colTipo
        '
        Me.colTipo.HeaderText = "Type"
        Me.colTipo.Name = "colTipo"
        Me.colTipo.ReadOnly = True
        '
        'colEstado
        '
        Me.colEstado.HeaderText = "Status"
        Me.colEstado.Name = "colEstado"
        Me.colEstado.ReadOnly = True
        Me.colEstado.Width = 103
        '
        'colAutorizar
        '
        Me.colAutorizar.HeaderText = "Autorizar"
        Me.colAutorizar.Name = "colAutorizar"
        Me.colAutorizar.ReadOnly = True
        Me.colAutorizar.Visible = False
        '
        'col_Fase
        '
        Me.col_Fase.HeaderText = "Phase"
        Me.col_Fase.Name = "col_Fase"
        Me.col_Fase.ReadOnly = True
        Me.col_Fase.Visible = False
        '
        'frmRequisa
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(542, 724)
        Me.Controls.Add(Me.panelDocumento)
        Me.Controls.Add(Me.PanelLista)
        Me.Controls.Add(Me.BarraTitulo1)
        Me.Controls.Add(Me.Encabezado1)
        Me.Name = "frmRequisa"
        Me.Text = resources.GetString("$this.Text")
        Me.PanelLista.ResumeLayout(False)
        CType(Me.dgLista, System.ComponentModel.ISupportInitialize).EndInit()
        Me.panelFiltro.ResumeLayout(False)
        Me.panelFiltro.PerformLayout()
        Me.PanelPiePagina.ResumeLayout(False)
        Me.PanelPiePagina.PerformLayout()
        Me.panelDocumento.ResumeLayout(False)
        Me.PanelDetalle.ResumeLayout(False)
        CType(Me.dgDetalle, System.ComponentModel.ISupportInitialize).EndInit()
        Me.PanelTotal.ResumeLayout(False)
        Me.PanelTotal.PerformLayout()
        Me.PanelBotones.ResumeLayout(False)
        Me.panelEncabezado.ResumeLayout(False)
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents Encabezado1 As encabezado
    Friend WithEvents BarraTitulo1 As BarraTitulo
    Friend WithEvents PanelLista As Panel
    Friend WithEvents dgLista As DataGridView
    Friend WithEvents panelFiltro As Panel
    Friend WithEvents botonActualizar As Button
    Friend WithEvents checkFiltroFecha As System.Windows.Forms.CheckBox
    Friend WithEvents dtpFechaFinal As DateTimePicker
    Friend WithEvents dtpFechaInicial As DateTimePicker
    Friend WithEvents panelDocumento As Panel
    Friend WithEvents PanelDetalle As Panel
    Friend WithEvents dgDetalle As DataGridView
    Friend WithEvents PanelBotones As Panel
    Friend WithEvents botonEliminar As Button
    Friend WithEvents botonAgregar As Button
    Friend WithEvents panelEncabezado As Panel
    Friend WithEvents GroupBox1 As GroupBox
    Friend WithEvents celdaNombre As TextBox
    Friend WithEvents Label4 As Label
    Friend WithEvents dtpFecha As DateTimePicker
    Friend WithEvents Label3 As Label
    Friend WithEvents celdaNumero As TextBox
    Friend WithEvents Label2 As Label
    Friend WithEvents checkActive As System.Windows.Forms.CheckBox
    Friend WithEvents celdaAño As TextBox
    Friend WithEvents Label1 As Label
    Friend WithEvents checkAutorizar As System.Windows.Forms.CheckBox
    Friend WithEvents rbLocal As RadioButton
    Friend WithEvents rbInternacional As RadioButton
    Friend WithEvents PanelPiePagina As Panel
    Friend WithEvents etiquetaNaranja As Label
    Friend WithEvents etiquetaISR As Label
    Friend WithEvents etiquetaRoja As Label
    Friend WithEvents celdaNaranja As TextBox
    Friend WithEvents celdaRosa As TextBox
    Friend WithEvents celdaRoja As TextBox
    Friend WithEvents checkUrgente As System.Windows.Forms.CheckBox
    Friend WithEvents checkLocal As System.Windows.Forms.CheckBox
    Friend WithEvents checkInternacional As System.Windows.Forms.CheckBox
    Friend WithEvents Label5 As Label
    Friend WithEvents TextBox1 As TextBox
    Friend WithEvents PanelTotal As Panel
    Friend WithEvents celdaTotal As TextBox
    Friend WithEvents Label17 As Label
    Friend WithEvents celdaComentarios As TextBox
    Friend WithEvents Label6 As Label
    Friend WithEvents rbOrdenCompra As RadioButton
    Friend WithEvents rbCotizacion As RadioButton
    Friend WithEvents rbRequisa As RadioButton
    Friend WithEvents colCodigo As DataGridViewTextBoxColumn
    Friend WithEvents colDescripcionArticulo As DataGridViewTextBoxColumn
    Friend WithEvents colIdMedida As DataGridViewTextBoxColumn
    Friend WithEvents colUM As DataGridViewTextBoxColumn
    Friend WithEvents colCantidad As DataGridViewTextBoxColumn
    Friend WithEvents colNumeroCosto As DataGridViewTextBoxColumn
    Friend WithEvents colCentroCosto As DataGridViewTextBoxColumn
    Friend WithEvents colCodMaquina As DataGridViewTextBoxColumn
    Friend WithEvents colDepartamento As DataGridViewTextBoxColumn
    Friend WithEvents colDescripcionMaquina As DataGridViewTextBoxColumn
    Friend WithEvents colNumeroParte As DataGridViewTextBoxColumn
    Friend WithEvents colMarca As DataGridViewTextBoxColumn
    Friend WithEvents colModelo As DataGridViewTextBoxColumn
    Friend WithEvents colSerie As DataGridViewTextBoxColumn
    Friend WithEvents colCatalogo As DataGridViewTextBoxColumn
    Friend WithEvents colStockWarehouse As DataGridViewTextBoxColumn
    Friend WithEvents colStock As DataGridViewTextBoxColumn
    Friend WithEvents colUltimoPrecio As DataGridViewTextBoxColumn
    Friend WithEvents colMontoAprox As DataGridViewTextBoxColumn
    Friend WithEvents colPresupuesto As DataGridViewTextBoxColumn
    Friend WithEvents colLinea As DataGridViewTextBoxColumn
    Friend WithEvents colStatus As DataGridViewTextBoxColumn
    Friend WithEvents colCodDepartamento As DataGridViewTextBoxColumn
    Friend WithEvents colCodMaquinaRef As DataGridViewTextBoxColumn
    Friend WithEvents colCodDepartamentoRef As DataGridViewTextBoxColumn
    Friend WithEvents colPrioridad As DataGridViewTextBoxColumn
    Friend WithEvents colFase As DataGridViewTextBoxColumn
    Friend WithEvents colAnio As DataGridViewTextBoxColumn
    Friend WithEvents colNumero As DataGridViewTextBoxColumn
    Friend WithEvents colFecha As DataGridViewTextBoxColumn
    Friend WithEvents colDescripcion As DataGridViewTextBoxColumn
    Friend WithEvents colTipo As DataGridViewTextBoxColumn
    Friend WithEvents colEstado As DataGridViewTextBoxColumn
    Friend WithEvents colAutorizar As DataGridViewTextBoxColumn
    Friend WithEvents col_Fase As DataGridViewTextBoxColumn
End Class
