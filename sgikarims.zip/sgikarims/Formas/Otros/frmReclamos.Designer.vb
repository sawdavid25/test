﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmReclamos
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmReclamos))
        Me.dglista = New System.Windows.Forms.DataGridView()
        Me.panelFiltro = New System.Windows.Forms.Panel()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.txtCli = New System.Windows.Forms.TextBox()
        Me.btnfiltrar = New System.Windows.Forms.Button()
        Me.btnfactura = New System.Windows.Forms.Button()
        Me.btncliente = New System.Windows.Forms.Button()
        Me.CeldaFactura = New System.Windows.Forms.TextBox()
        Me.CeldaCliente = New System.Windows.Forms.TextBox()
        Me.chkfacturas = New System.Windows.Forms.CheckBox()
        Me.chkclientes = New System.Windows.Forms.CheckBox()
        Me.chkfechas = New System.Windows.Forms.CheckBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.dtpFin = New System.Windows.Forms.DateTimePicker()
        Me.dtpInicio = New System.Windows.Forms.DateTimePicker()
        Me.TAB_CLAIM = New System.Windows.Forms.TabControl()
        Me.tga_general = New System.Windows.Forms.TabPage()
        Me.dgdetalle = New System.Windows.Forms.DataGridView()
        Me.Factura = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Año = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Linea = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Fecha = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Quantity = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Lote = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Descripcion = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Proveedor = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Usuario = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.KI = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Panel2 = New System.Windows.Forms.Panel()
        Me.dgvsubDocumentos = New System.Windows.Forms.DataGridView()
        Me.Documentos = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Datos = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.lblañoclaim = New System.Windows.Forms.Label()
        Me.Lab = New System.Windows.Forms.Label()
        Me.lblIdClaim = New System.Windows.Forms.Label()
        Me.Claim = New System.Windows.Forms.Label()
        Me.CeldaNumClaim = New System.Windows.Forms.Label()
        Me.btnQuitarFila = New System.Windows.Forms.Button()
        Me.btninvoice = New System.Windows.Forms.Button()
        Me.Label23 = New System.Windows.Forms.Label()
        Me.LBLTotalQuantity = New System.Windows.Forms.Label()
        Me.Cod = New System.Windows.Forms.Label()
        Me.dtp_claim = New System.Windows.Forms.DateTimePicker()
        Me.celdapais = New System.Windows.Forms.Label()
        Me.Customer = New System.Windows.Forms.Label()
        Me.CeldaCustomer = New System.Windows.Forms.TextBox()
        Me.celdaLinea = New System.Windows.Forms.Label()
        Me.CeldaYearClaim = New System.Windows.Forms.Label()
        Me.btncustomer = New System.Windows.Forms.Button()
        Me.CeldaCodCustomer = New System.Windows.Forms.TextBox()
        Me.CeldaClaim = New System.Windows.Forms.Label()
        Me.celdaAnoClaim = New System.Windows.Forms.Label()
        Me.TabPage1 = New System.Windows.Forms.TabPage()
        Me.txtTotalDefect = New System.Windows.Forms.TextBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.CeldaTotalQuantity = New System.Windows.Forms.TextBox()
        Me.CeldaActionsDone = New System.Windows.Forms.TextBox()
        Me.CeldaAnalysisInspection = New System.Windows.Forms.TextBox()
        Me.Label16 = New System.Windows.Forms.Label()
        Me.Label15 = New System.Windows.Forms.Label()
        Me.Label14 = New System.Windows.Forms.Label()
        Me.CeldaConfirmacionProducto = New System.Windows.Forms.TextBox()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.CeldaDificultiesCustomer = New System.Windows.Forms.TextBox()
        Me.CeldaProblem = New System.Windows.Forms.TextBox()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.CeldaLocationProblem = New System.Windows.Forms.TextBox()
        Me.tgObeservation = New System.Windows.Forms.TabPage()
        Me.CeldaClaimRefence = New System.Windows.Forms.TextBox()
        Me.Label24 = New System.Windows.Forms.Label()
        Me.CeldaChargeback = New System.Windows.Forms.TextBox()
        Me.CeldaAmount = New System.Windows.Forms.TextBox()
        Me.Label22 = New System.Windows.Forms.Label()
        Me.Label21 = New System.Windows.Forms.Label()
        Me.CeldaConclusions = New System.Windows.Forms.TextBox()
        Me.CeldaNoExplain = New System.Windows.Forms.TextBox()
        Me.Label20 = New System.Windows.Forms.Label()
        Me.CeldaComments = New System.Windows.Forms.TextBox()
        Me.rdbno = New System.Windows.Forms.RadioButton()
        Me.rdbyes = New System.Windows.Forms.RadioButton()
        Me.Label19 = New System.Windows.Forms.Label()
        Me.Label18 = New System.Windows.Forms.Label()
        Me.Label17 = New System.Windows.Forms.Label()
        Me.btnImprimir = New System.Windows.Forms.Button()
        Me.Encabezado1 = New KARIMs_SGI.encabezado()
        Me.BarraTitulo1 = New KARIMs_SGI.BarraTitulo()
        CType(Me.dglista, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.panelFiltro.SuspendLayout()
        Me.GroupBox1.SuspendLayout()
        Me.TAB_CLAIM.SuspendLayout()
        Me.tga_general.SuspendLayout()
        CType(Me.dgdetalle, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Panel2.SuspendLayout()
        CType(Me.dgvsubDocumentos, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Panel1.SuspendLayout()
        Me.TabPage1.SuspendLayout()
        Me.tgObeservation.SuspendLayout()
        Me.SuspendLayout()
        '
        'dglista
        '
        Me.dglista.AllowUserToAddRows = False
        Me.dglista.AllowUserToDeleteRows = False
        Me.dglista.AllowUserToOrderColumns = True
        Me.dglista.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dglista.Dock = System.Windows.Forms.DockStyle.Fill
        Me.dglista.Location = New System.Drawing.Point(0, 155)
        Me.dglista.MultiSelect = False
        Me.dglista.Name = "dglista"
        Me.dglista.ReadOnly = True
        Me.dglista.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.dglista.Size = New System.Drawing.Size(557, 356)
        Me.dglista.TabIndex = 2
        '
        'panelFiltro
        '
        Me.panelFiltro.Controls.Add(Me.dglista)
        Me.panelFiltro.Controls.Add(Me.GroupBox1)
        Me.panelFiltro.Location = New System.Drawing.Point(615, 133)
        Me.panelFiltro.Name = "panelFiltro"
        Me.panelFiltro.Size = New System.Drawing.Size(557, 511)
        Me.panelFiltro.TabIndex = 3
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.txtCli)
        Me.GroupBox1.Controls.Add(Me.btnfiltrar)
        Me.GroupBox1.Controls.Add(Me.btnfactura)
        Me.GroupBox1.Controls.Add(Me.btncliente)
        Me.GroupBox1.Controls.Add(Me.CeldaFactura)
        Me.GroupBox1.Controls.Add(Me.CeldaCliente)
        Me.GroupBox1.Controls.Add(Me.chkfacturas)
        Me.GroupBox1.Controls.Add(Me.chkclientes)
        Me.GroupBox1.Controls.Add(Me.chkfechas)
        Me.GroupBox1.Controls.Add(Me.Label1)
        Me.GroupBox1.Controls.Add(Me.dtpFin)
        Me.GroupBox1.Controls.Add(Me.dtpInicio)
        Me.GroupBox1.Dock = System.Windows.Forms.DockStyle.Top
        Me.GroupBox1.Location = New System.Drawing.Point(0, 0)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(557, 155)
        Me.GroupBox1.TabIndex = 0
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Filtrar Por :"
        '
        'txtCli
        '
        Me.txtCli.Location = New System.Drawing.Point(85, 87)
        Me.txtCli.Name = "txtCli"
        Me.txtCli.Size = New System.Drawing.Size(30, 20)
        Me.txtCli.TabIndex = 15
        Me.txtCli.Visible = False
        '
        'btnfiltrar
        '
        Me.btnfiltrar.Location = New System.Drawing.Point(372, 45)
        Me.btnfiltrar.Name = "btnfiltrar"
        Me.btnfiltrar.Size = New System.Drawing.Size(53, 23)
        Me.btnfiltrar.TabIndex = 7
        Me.btnfiltrar.Text = "Filtrar"
        Me.btnfiltrar.UseVisualStyleBackColor = True
        '
        'btnfactura
        '
        Me.btnfactura.Location = New System.Drawing.Point(372, 120)
        Me.btnfactura.Name = "btnfactura"
        Me.btnfactura.Size = New System.Drawing.Size(38, 23)
        Me.btnfactura.TabIndex = 14
        Me.btnfactura.Text = "..."
        Me.btnfactura.UseVisualStyleBackColor = True
        Me.btnfactura.Visible = False
        '
        'btncliente
        '
        Me.btncliente.Location = New System.Drawing.Point(372, 87)
        Me.btncliente.Name = "btncliente"
        Me.btncliente.Size = New System.Drawing.Size(38, 23)
        Me.btncliente.TabIndex = 13
        Me.btncliente.Text = "..."
        Me.btncliente.UseVisualStyleBackColor = True
        '
        'CeldaFactura
        '
        Me.CeldaFactura.Location = New System.Drawing.Point(128, 120)
        Me.CeldaFactura.Name = "CeldaFactura"
        Me.CeldaFactura.Size = New System.Drawing.Size(227, 20)
        Me.CeldaFactura.TabIndex = 12
        Me.CeldaFactura.Visible = False
        '
        'CeldaCliente
        '
        Me.CeldaCliente.Location = New System.Drawing.Point(128, 87)
        Me.CeldaCliente.Name = "CeldaCliente"
        Me.CeldaCliente.Size = New System.Drawing.Size(227, 20)
        Me.CeldaCliente.TabIndex = 11
        '
        'chkfacturas
        '
        Me.chkfacturas.AutoSize = True
        Me.chkfacturas.Location = New System.Drawing.Point(12, 120)
        Me.chkfacturas.Name = "chkfacturas"
        Me.chkfacturas.Size = New System.Drawing.Size(62, 17)
        Me.chkfacturas.TabIndex = 10
        Me.chkfacturas.Text = "Factura"
        Me.chkfacturas.UseVisualStyleBackColor = True
        Me.chkfacturas.Visible = False
        '
        'chkclientes
        '
        Me.chkclientes.AutoSize = True
        Me.chkclientes.Location = New System.Drawing.Point(12, 87)
        Me.chkclientes.Name = "chkclientes"
        Me.chkclientes.Size = New System.Drawing.Size(58, 17)
        Me.chkclientes.TabIndex = 9
        Me.chkclientes.Text = "Cliente"
        Me.chkclientes.UseVisualStyleBackColor = True
        '
        'chkfechas
        '
        Me.chkfechas.AutoSize = True
        Me.chkfechas.Location = New System.Drawing.Point(12, 51)
        Me.chkfechas.Name = "chkfechas"
        Me.chkfechas.Size = New System.Drawing.Size(96, 17)
        Me.chkfechas.TabIndex = 8
        Me.chkfechas.Text = "Rango Fechas"
        Me.chkfechas.UseVisualStyleBackColor = True
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(24, 25)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(60, 13)
        Me.Label1.TabIndex = 7
        Me.Label1.Text = "Filtrar Por : "
        '
        'dtpFin
        '
        Me.dtpFin.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.dtpFin.Location = New System.Drawing.Point(271, 51)
        Me.dtpFin.Name = "dtpFin"
        Me.dtpFin.Size = New System.Drawing.Size(84, 20)
        Me.dtpFin.TabIndex = 6
        '
        'dtpInicio
        '
        Me.dtpInicio.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.dtpInicio.Location = New System.Drawing.Point(128, 51)
        Me.dtpInicio.Name = "dtpInicio"
        Me.dtpInicio.Size = New System.Drawing.Size(84, 20)
        Me.dtpInicio.TabIndex = 5
        '
        'TAB_CLAIM
        '
        Me.TAB_CLAIM.Controls.Add(Me.tga_general)
        Me.TAB_CLAIM.Controls.Add(Me.TabPage1)
        Me.TAB_CLAIM.Controls.Add(Me.tgObeservation)
        Me.TAB_CLAIM.Dock = System.Windows.Forms.DockStyle.Left
        Me.TAB_CLAIM.Location = New System.Drawing.Point(0, 72)
        Me.TAB_CLAIM.Name = "TAB_CLAIM"
        Me.TAB_CLAIM.SelectedIndex = 0
        Me.TAB_CLAIM.Size = New System.Drawing.Size(609, 584)
        Me.TAB_CLAIM.TabIndex = 5
        '
        'tga_general
        '
        Me.tga_general.Controls.Add(Me.dgdetalle)
        Me.tga_general.Controls.Add(Me.Panel2)
        Me.tga_general.Controls.Add(Me.Panel1)
        Me.tga_general.Controls.Add(Me.CeldaClaim)
        Me.tga_general.Controls.Add(Me.celdaAnoClaim)
        Me.tga_general.Location = New System.Drawing.Point(4, 22)
        Me.tga_general.Name = "tga_general"
        Me.tga_general.Padding = New System.Windows.Forms.Padding(3)
        Me.tga_general.Size = New System.Drawing.Size(601, 558)
        Me.tga_general.TabIndex = 0
        Me.tga_general.Text = "General Information"
        Me.tga_general.UseVisualStyleBackColor = True
        '
        'dgdetalle
        '
        Me.dgdetalle.AllowUserToAddRows = False
        Me.dgdetalle.AllowUserToDeleteRows = False
        Me.dgdetalle.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells
        Me.dgdetalle.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgdetalle.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.Factura, Me.Año, Me.Linea, Me.Fecha, Me.Quantity, Me.Lote, Me.Descripcion, Me.Proveedor, Me.Usuario, Me.KI})
        Me.dgdetalle.Dock = System.Windows.Forms.DockStyle.Fill
        Me.dgdetalle.Location = New System.Drawing.Point(3, 175)
        Me.dgdetalle.MultiSelect = False
        Me.dgdetalle.Name = "dgdetalle"
        Me.dgdetalle.ReadOnly = True
        Me.dgdetalle.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.dgdetalle.Size = New System.Drawing.Size(595, 268)
        Me.dgdetalle.TabIndex = 45
        '
        'Factura
        '
        Me.Factura.HeaderText = "Factura"
        Me.Factura.Name = "Factura"
        Me.Factura.ReadOnly = True
        Me.Factura.Width = 68
        '
        'Año
        '
        Me.Año.HeaderText = "Año"
        Me.Año.Name = "Año"
        Me.Año.ReadOnly = True
        Me.Año.Width = 51
        '
        'Linea
        '
        Me.Linea.HeaderText = "Linea"
        Me.Linea.Name = "Linea"
        Me.Linea.ReadOnly = True
        Me.Linea.Width = 58
        '
        'Fecha
        '
        Me.Fecha.HeaderText = "Fecha"
        Me.Fecha.Name = "Fecha"
        Me.Fecha.ReadOnly = True
        Me.Fecha.Width = 62
        '
        'Quantity
        '
        Me.Quantity.HeaderText = "Quantity"
        Me.Quantity.Name = "Quantity"
        Me.Quantity.ReadOnly = True
        Me.Quantity.Width = 71
        '
        'Lote
        '
        Me.Lote.HeaderText = "Lote"
        Me.Lote.Name = "Lote"
        Me.Lote.ReadOnly = True
        Me.Lote.Width = 53
        '
        'Descripcion
        '
        Me.Descripcion.HeaderText = "Descripcion"
        Me.Descripcion.Name = "Descripcion"
        Me.Descripcion.ReadOnly = True
        Me.Descripcion.Width = 88
        '
        'Proveedor
        '
        Me.Proveedor.HeaderText = "Proveedor"
        Me.Proveedor.Name = "Proveedor"
        Me.Proveedor.ReadOnly = True
        Me.Proveedor.Width = 81
        '
        'Usuario
        '
        Me.Usuario.HeaderText = "Usuario"
        Me.Usuario.Name = "Usuario"
        Me.Usuario.ReadOnly = True
        Me.Usuario.Width = 68
        '
        'KI
        '
        Me.KI.HeaderText = "KI"
        Me.KI.Name = "KI"
        Me.KI.ReadOnly = True
        Me.KI.Width = 42
        '
        'Panel2
        '
        Me.Panel2.Controls.Add(Me.dgvsubDocumentos)
        Me.Panel2.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.Panel2.Location = New System.Drawing.Point(3, 443)
        Me.Panel2.Name = "Panel2"
        Me.Panel2.Size = New System.Drawing.Size(595, 112)
        Me.Panel2.TabIndex = 47
        '
        'dgvsubDocumentos
        '
        Me.dgvsubDocumentos.AllowUserToAddRows = False
        Me.dgvsubDocumentos.AllowUserToDeleteRows = False
        Me.dgvsubDocumentos.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgvsubDocumentos.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.Documentos, Me.Datos})
        Me.dgvsubDocumentos.Location = New System.Drawing.Point(20, 7)
        Me.dgvsubDocumentos.Name = "dgvsubDocumentos"
        Me.dgvsubDocumentos.Size = New System.Drawing.Size(257, 99)
        Me.dgvsubDocumentos.TabIndex = 0
        '
        'Documentos
        '
        Me.Documentos.HeaderText = "Documentos"
        Me.Documentos.Name = "Documentos"
        Me.Documentos.ReadOnly = True
        '
        'Datos
        '
        Me.Datos.HeaderText = "Datos"
        Me.Datos.Name = "Datos"
        Me.Datos.ReadOnly = True
        '
        'Panel1
        '
        Me.Panel1.Controls.Add(Me.lblañoclaim)
        Me.Panel1.Controls.Add(Me.Lab)
        Me.Panel1.Controls.Add(Me.lblIdClaim)
        Me.Panel1.Controls.Add(Me.Claim)
        Me.Panel1.Controls.Add(Me.CeldaNumClaim)
        Me.Panel1.Controls.Add(Me.btnQuitarFila)
        Me.Panel1.Controls.Add(Me.btninvoice)
        Me.Panel1.Controls.Add(Me.Label23)
        Me.Panel1.Controls.Add(Me.LBLTotalQuantity)
        Me.Panel1.Controls.Add(Me.Cod)
        Me.Panel1.Controls.Add(Me.dtp_claim)
        Me.Panel1.Controls.Add(Me.celdapais)
        Me.Panel1.Controls.Add(Me.Customer)
        Me.Panel1.Controls.Add(Me.CeldaCustomer)
        Me.Panel1.Controls.Add(Me.celdaLinea)
        Me.Panel1.Controls.Add(Me.CeldaYearClaim)
        Me.Panel1.Controls.Add(Me.btncustomer)
        Me.Panel1.Controls.Add(Me.CeldaCodCustomer)
        Me.Panel1.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel1.Location = New System.Drawing.Point(3, 3)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(595, 172)
        Me.Panel1.TabIndex = 46
        '
        'lblañoclaim
        '
        Me.lblañoclaim.AutoSize = True
        Me.lblañoclaim.Location = New System.Drawing.Point(218, 15)
        Me.lblañoclaim.Name = "lblañoclaim"
        Me.lblañoclaim.Size = New System.Drawing.Size(0, 13)
        Me.lblañoclaim.TabIndex = 52
        '
        'Lab
        '
        Me.Lab.AutoSize = True
        Me.Lab.Location = New System.Drawing.Point(152, 15)
        Me.Lab.Name = "Lab"
        Me.Lab.Size = New System.Drawing.Size(26, 13)
        Me.Lab.TabIndex = 51
        Me.Lab.Text = "Año"
        '
        'lblIdClaim
        '
        Me.lblIdClaim.AutoSize = True
        Me.lblIdClaim.Location = New System.Drawing.Point(80, 16)
        Me.lblIdClaim.Name = "lblIdClaim"
        Me.lblIdClaim.Size = New System.Drawing.Size(0, 13)
        Me.lblIdClaim.TabIndex = 50
        '
        'Claim
        '
        Me.Claim.AutoSize = True
        Me.Claim.Location = New System.Drawing.Point(17, 16)
        Me.Claim.Name = "Claim"
        Me.Claim.Size = New System.Drawing.Size(46, 13)
        Me.Claim.TabIndex = 49
        Me.Claim.Text = "ID Claim"
        '
        'CeldaNumClaim
        '
        Me.CeldaNumClaim.AutoSize = True
        Me.CeldaNumClaim.Location = New System.Drawing.Point(337, 112)
        Me.CeldaNumClaim.Name = "CeldaNumClaim"
        Me.CeldaNumClaim.Size = New System.Drawing.Size(0, 13)
        Me.CeldaNumClaim.TabIndex = 48
        Me.CeldaNumClaim.Visible = False
        '
        'btnQuitarFila
        '
        Me.btnQuitarFila.Image = CType(resources.GetObject("btnQuitarFila.Image"), System.Drawing.Image)
        Me.btnQuitarFila.Location = New System.Drawing.Point(58, 119)
        Me.btnQuitarFila.Name = "btnQuitarFila"
        Me.btnQuitarFila.Size = New System.Drawing.Size(34, 33)
        Me.btnQuitarFila.TabIndex = 47
        Me.btnQuitarFila.UseVisualStyleBackColor = True
        '
        'btninvoice
        '
        Me.btninvoice.Image = CType(resources.GetObject("btninvoice.Image"), System.Drawing.Image)
        Me.btninvoice.Location = New System.Drawing.Point(17, 119)
        Me.btninvoice.Name = "btninvoice"
        Me.btninvoice.Size = New System.Drawing.Size(35, 33)
        Me.btninvoice.TabIndex = 32
        Me.btninvoice.UseVisualStyleBackColor = True
        '
        'Label23
        '
        Me.Label23.AutoSize = True
        Me.Label23.Location = New System.Drawing.Point(198, 135)
        Me.Label23.Name = "Label23"
        Me.Label23.Size = New System.Drawing.Size(70, 13)
        Me.Label23.TabIndex = 46
        Me.Label23.Text = "Quantity Sold"
        '
        'LBLTotalQuantity
        '
        Me.LBLTotalQuantity.AutoSize = True
        Me.LBLTotalQuantity.Location = New System.Drawing.Point(337, 134)
        Me.LBLTotalQuantity.Name = "LBLTotalQuantity"
        Me.LBLTotalQuantity.Size = New System.Drawing.Size(0, 13)
        Me.LBLTotalQuantity.TabIndex = 45
        '
        'Cod
        '
        Me.Cod.AutoSize = True
        Me.Cod.Location = New System.Drawing.Point(17, 58)
        Me.Cod.Name = "Cod"
        Me.Cod.Size = New System.Drawing.Size(26, 13)
        Me.Cod.TabIndex = 35
        Me.Cod.Text = "Cod"
        '
        'dtp_claim
        '
        Me.dtp_claim.Location = New System.Drawing.Point(345, 16)
        Me.dtp_claim.Name = "dtp_claim"
        Me.dtp_claim.Size = New System.Drawing.Size(200, 20)
        Me.dtp_claim.TabIndex = 6
        '
        'celdapais
        '
        Me.celdapais.AutoSize = True
        Me.celdapais.Location = New System.Drawing.Point(195, 112)
        Me.celdapais.Name = "celdapais"
        Me.celdapais.Size = New System.Drawing.Size(27, 13)
        Me.celdapais.TabIndex = 44
        Me.celdapais.Text = "Pais"
        '
        'Customer
        '
        Me.Customer.AutoSize = True
        Me.Customer.Location = New System.Drawing.Point(103, 56)
        Me.Customer.Name = "Customer"
        Me.Customer.Size = New System.Drawing.Size(51, 13)
        Me.Customer.TabIndex = 9
        Me.Customer.Text = "Customer"
        '
        'CeldaCustomer
        '
        Me.CeldaCustomer.Location = New System.Drawing.Point(99, 78)
        Me.CeldaCustomer.Name = "CeldaCustomer"
        Me.CeldaCustomer.ReadOnly = True
        Me.CeldaCustomer.Size = New System.Drawing.Size(357, 20)
        Me.CeldaCustomer.TabIndex = 16
        '
        'celdaLinea
        '
        Me.celdaLinea.AutoSize = True
        Me.celdaLinea.Location = New System.Drawing.Point(106, 136)
        Me.celdaLinea.Name = "celdaLinea"
        Me.celdaLinea.Size = New System.Drawing.Size(33, 13)
        Me.celdaLinea.TabIndex = 37
        Me.celdaLinea.Text = "Linea"
        '
        'CeldaYearClaim
        '
        Me.CeldaYearClaim.AutoSize = True
        Me.CeldaYearClaim.Location = New System.Drawing.Point(103, 112)
        Me.CeldaYearClaim.Name = "CeldaYearClaim"
        Me.CeldaYearClaim.Size = New System.Drawing.Size(26, 13)
        Me.CeldaYearClaim.TabIndex = 36
        Me.CeldaYearClaim.Text = "Año"
        '
        'btncustomer
        '
        Me.btncustomer.Location = New System.Drawing.Point(462, 76)
        Me.btncustomer.Name = "btncustomer"
        Me.btncustomer.Size = New System.Drawing.Size(39, 23)
        Me.btncustomer.TabIndex = 33
        Me.btncustomer.Text = "..."
        Me.btncustomer.UseVisualStyleBackColor = True
        '
        'CeldaCodCustomer
        '
        Me.CeldaCodCustomer.Enabled = False
        Me.CeldaCodCustomer.Location = New System.Drawing.Point(17, 78)
        Me.CeldaCodCustomer.Name = "CeldaCodCustomer"
        Me.CeldaCodCustomer.Size = New System.Drawing.Size(69, 20)
        Me.CeldaCodCustomer.TabIndex = 34
        '
        'CeldaClaim
        '
        Me.CeldaClaim.AutoSize = True
        Me.CeldaClaim.Location = New System.Drawing.Point(529, 178)
        Me.CeldaClaim.Name = "CeldaClaim"
        Me.CeldaClaim.Size = New System.Drawing.Size(0, 13)
        Me.CeldaClaim.TabIndex = 43
        Me.CeldaClaim.Visible = False
        '
        'celdaAnoClaim
        '
        Me.celdaAnoClaim.AutoSize = True
        Me.celdaAnoClaim.BackColor = System.Drawing.Color.Transparent
        Me.celdaAnoClaim.Location = New System.Drawing.Point(529, 115)
        Me.celdaAnoClaim.Name = "celdaAnoClaim"
        Me.celdaAnoClaim.Size = New System.Drawing.Size(0, 13)
        Me.celdaAnoClaim.TabIndex = 42
        Me.celdaAnoClaim.Visible = False
        '
        'TabPage1
        '
        Me.TabPage1.Controls.Add(Me.txtTotalDefect)
        Me.TabPage1.Controls.Add(Me.Label2)
        Me.TabPage1.Controls.Add(Me.CeldaTotalQuantity)
        Me.TabPage1.Controls.Add(Me.CeldaActionsDone)
        Me.TabPage1.Controls.Add(Me.CeldaAnalysisInspection)
        Me.TabPage1.Controls.Add(Me.Label16)
        Me.TabPage1.Controls.Add(Me.Label15)
        Me.TabPage1.Controls.Add(Me.Label14)
        Me.TabPage1.Controls.Add(Me.CeldaConfirmacionProducto)
        Me.TabPage1.Controls.Add(Me.Label12)
        Me.TabPage1.Controls.Add(Me.CeldaDificultiesCustomer)
        Me.TabPage1.Controls.Add(Me.CeldaProblem)
        Me.TabPage1.Controls.Add(Me.Label11)
        Me.TabPage1.Controls.Add(Me.Label10)
        Me.TabPage1.Controls.Add(Me.Label9)
        Me.TabPage1.Controls.Add(Me.CeldaLocationProblem)
        Me.TabPage1.Location = New System.Drawing.Point(4, 22)
        Me.TabPage1.Name = "TabPage1"
        Me.TabPage1.Size = New System.Drawing.Size(601, 558)
        Me.TabPage1.TabIndex = 3
        Me.TabPage1.Text = "Detalle"
        Me.TabPage1.UseVisualStyleBackColor = True
        '
        'txtTotalDefect
        '
        Me.txtTotalDefect.Location = New System.Drawing.Point(155, 424)
        Me.txtTotalDefect.Name = "txtTotalDefect"
        Me.txtTotalDefect.Size = New System.Drawing.Size(108, 20)
        Me.txtTotalDefect.TabIndex = 55
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(152, 405)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(108, 13)
        Me.Label2.TabIndex = 54
        Me.Label2.Text = "Total Defect Quantity"
        '
        'CeldaTotalQuantity
        '
        Me.CeldaTotalQuantity.Location = New System.Drawing.Point(24, 421)
        Me.CeldaTotalQuantity.Multiline = True
        Me.CeldaTotalQuantity.Name = "CeldaTotalQuantity"
        Me.CeldaTotalQuantity.Size = New System.Drawing.Size(116, 23)
        Me.CeldaTotalQuantity.TabIndex = 53
        '
        'CeldaActionsDone
        '
        Me.CeldaActionsDone.Location = New System.Drawing.Point(285, 326)
        Me.CeldaActionsDone.MaxLength = 100
        Me.CeldaActionsDone.Multiline = True
        Me.CeldaActionsDone.Name = "CeldaActionsDone"
        Me.CeldaActionsDone.Size = New System.Drawing.Size(200, 118)
        Me.CeldaActionsDone.TabIndex = 52
        '
        'CeldaAnalysisInspection
        '
        Me.CeldaAnalysisInspection.Location = New System.Drawing.Point(24, 271)
        Me.CeldaAnalysisInspection.Multiline = True
        Me.CeldaAnalysisInspection.Name = "CeldaAnalysisInspection"
        Me.CeldaAnalysisInspection.Size = New System.Drawing.Size(178, 118)
        Me.CeldaAnalysisInspection.TabIndex = 51
        '
        'Label16
        '
        Me.Label16.AutoSize = True
        Me.Label16.Location = New System.Drawing.Point(21, 405)
        Me.Label16.Name = "Label16"
        Me.Label16.Size = New System.Drawing.Size(115, 13)
        Me.Label16.TabIndex = 50
        Me.Label16.Text = "Total Salvage Quantity"
        '
        'Label15
        '
        Me.Label15.AutoSize = True
        Me.Label15.Location = New System.Drawing.Point(282, 297)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(96, 13)
        Me.Label15.TabIndex = 49
        Me.Label15.Text = "Actions to be done"
        '
        'Label14
        '
        Me.Label14.AutoSize = True
        Me.Label14.Location = New System.Drawing.Point(27, 242)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(105, 26)
        Me.Label14.TabIndex = 48
        Me.Label14.Text = "Type of Analysis and" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "         Inspection"
        '
        'CeldaConfirmacionProducto
        '
        Me.CeldaConfirmacionProducto.Location = New System.Drawing.Point(285, 185)
        Me.CeldaConfirmacionProducto.MaxLength = 200
        Me.CeldaConfirmacionProducto.Multiline = True
        Me.CeldaConfirmacionProducto.Name = "CeldaConfirmacionProducto"
        Me.CeldaConfirmacionProducto.Size = New System.Drawing.Size(200, 102)
        Me.CeldaConfirmacionProducto.TabIndex = 47
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.Location = New System.Drawing.Point(282, 150)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(144, 26)
        Me.Label12.TabIndex = 46
        Me.Label12.Text = "Verification and Confimacion " & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "            of the Product" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10)
        '
        'CeldaDificultiesCustomer
        '
        Me.CeldaDificultiesCustomer.Location = New System.Drawing.Point(27, 101)
        Me.CeldaDificultiesCustomer.Multiline = True
        Me.CeldaDificultiesCustomer.Name = "CeldaDificultiesCustomer"
        Me.CeldaDificultiesCustomer.ScrollBars = System.Windows.Forms.ScrollBars.Vertical
        Me.CeldaDificultiesCustomer.Size = New System.Drawing.Size(178, 123)
        Me.CeldaDificultiesCustomer.TabIndex = 45
        '
        'CeldaProblem
        '
        Me.CeldaProblem.Location = New System.Drawing.Point(285, 41)
        Me.CeldaProblem.Multiline = True
        Me.CeldaProblem.Name = "CeldaProblem"
        Me.CeldaProblem.ScrollBars = System.Windows.Forms.ScrollBars.Vertical
        Me.CeldaProblem.Size = New System.Drawing.Size(209, 102)
        Me.CeldaProblem.TabIndex = 44
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.Location = New System.Drawing.Point(27, 84)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(175, 13)
        Me.Label11.TabIndex = 43
        Me.Label11.Text = "Dificulties Experienced by Customer"
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Location = New System.Drawing.Point(282, 22)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(84, 13)
        Me.Label10.TabIndex = 42
        Me.Label10.Text = "Type of Problem"
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Location = New System.Drawing.Point(27, 22)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(113, 13)
        Me.Label9.TabIndex = 41
        Me.Label9.Text = "Location of te Problem"
        '
        'CeldaLocationProblem
        '
        Me.CeldaLocationProblem.Location = New System.Drawing.Point(27, 41)
        Me.CeldaLocationProblem.MaxLength = 20
        Me.CeldaLocationProblem.Name = "CeldaLocationProblem"
        Me.CeldaLocationProblem.ScrollBars = System.Windows.Forms.ScrollBars.Vertical
        Me.CeldaLocationProblem.Size = New System.Drawing.Size(151, 20)
        Me.CeldaLocationProblem.TabIndex = 40
        Me.CeldaLocationProblem.TabStop = False
        '
        'tgObeservation
        '
        Me.tgObeservation.Controls.Add(Me.CeldaClaimRefence)
        Me.tgObeservation.Controls.Add(Me.Label24)
        Me.tgObeservation.Controls.Add(Me.CeldaChargeback)
        Me.tgObeservation.Controls.Add(Me.CeldaAmount)
        Me.tgObeservation.Controls.Add(Me.Label22)
        Me.tgObeservation.Controls.Add(Me.Label21)
        Me.tgObeservation.Controls.Add(Me.CeldaConclusions)
        Me.tgObeservation.Controls.Add(Me.CeldaNoExplain)
        Me.tgObeservation.Controls.Add(Me.Label20)
        Me.tgObeservation.Controls.Add(Me.CeldaComments)
        Me.tgObeservation.Controls.Add(Me.rdbno)
        Me.tgObeservation.Controls.Add(Me.rdbyes)
        Me.tgObeservation.Controls.Add(Me.Label19)
        Me.tgObeservation.Controls.Add(Me.Label18)
        Me.tgObeservation.Controls.Add(Me.Label17)
        Me.tgObeservation.Location = New System.Drawing.Point(4, 22)
        Me.tgObeservation.Name = "tgObeservation"
        Me.tgObeservation.Size = New System.Drawing.Size(601, 558)
        Me.tgObeservation.TabIndex = 2
        Me.tgObeservation.Text = "Observation & Solutions"
        Me.tgObeservation.UseVisualStyleBackColor = True
        '
        'CeldaClaimRefence
        '
        Me.CeldaClaimRefence.Location = New System.Drawing.Point(346, 380)
        Me.CeldaClaimRefence.Name = "CeldaClaimRefence"
        Me.CeldaClaimRefence.ReadOnly = True
        Me.CeldaClaimRefence.Size = New System.Drawing.Size(123, 20)
        Me.CeldaClaimRefence.TabIndex = 14
        '
        'Label24
        '
        Me.Label24.AutoSize = True
        Me.Label24.Location = New System.Drawing.Point(247, 387)
        Me.Label24.Name = "Label24"
        Me.Label24.Size = New System.Drawing.Size(93, 13)
        Me.Label24.TabIndex = 13
        Me.Label24.Text = "Claim Register # : "
        '
        'CeldaChargeback
        '
        Me.CeldaChargeback.Location = New System.Drawing.Point(33, 480)
        Me.CeldaChargeback.Name = "CeldaChargeback"
        Me.CeldaChargeback.Size = New System.Drawing.Size(140, 20)
        Me.CeldaChargeback.TabIndex = 12
        '
        'CeldaAmount
        '
        Me.CeldaAmount.Location = New System.Drawing.Point(36, 399)
        Me.CeldaAmount.Name = "CeldaAmount"
        Me.CeldaAmount.Size = New System.Drawing.Size(137, 20)
        Me.CeldaAmount.TabIndex = 11
        '
        'Label22
        '
        Me.Label22.AutoSize = True
        Me.Label22.Location = New System.Drawing.Point(30, 442)
        Me.Label22.Name = "Label22"
        Me.Label22.Size = New System.Drawing.Size(129, 13)
        Me.Label22.TabIndex = 10
        Me.Label22.Text = "Total Claim Chargeback $"
        '
        'Label21
        '
        Me.Label21.AutoSize = True
        Me.Label21.Location = New System.Drawing.Point(33, 373)
        Me.Label21.Name = "Label21"
        Me.Label21.Size = New System.Drawing.Size(121, 13)
        Me.Label21.TabIndex = 9
        Me.Label21.Text = "Original  Claim Amount $"
        '
        'CeldaConclusions
        '
        Me.CeldaConclusions.Location = New System.Drawing.Point(30, 265)
        Me.CeldaConclusions.MaxLength = 3200
        Me.CeldaConclusions.Multiline = True
        Me.CeldaConclusions.Name = "CeldaConclusions"
        Me.CeldaConclusions.Size = New System.Drawing.Size(532, 74)
        Me.CeldaConclusions.TabIndex = 8
        '
        'CeldaNoExplain
        '
        Me.CeldaNoExplain.Location = New System.Drawing.Point(169, 188)
        Me.CeldaNoExplain.Name = "CeldaNoExplain"
        Me.CeldaNoExplain.Size = New System.Drawing.Size(211, 20)
        Me.CeldaNoExplain.TabIndex = 7
        '
        'Label20
        '
        Me.Label20.AutoSize = True
        Me.Label20.Location = New System.Drawing.Point(166, 159)
        Me.Label20.Name = "Label20"
        Me.Label20.Size = New System.Drawing.Size(64, 13)
        Me.Label20.TabIndex = 6
        Me.Label20.Text = "(No) Explain"
        '
        'CeldaComments
        '
        Me.CeldaComments.Location = New System.Drawing.Point(30, 73)
        Me.CeldaComments.MaxLength = 32000
        Me.CeldaComments.Multiline = True
        Me.CeldaComments.Name = "CeldaComments"
        Me.CeldaComments.Size = New System.Drawing.Size(532, 68)
        Me.CeldaComments.TabIndex = 5
        '
        'rdbno
        '
        Me.rdbno.AutoSize = True
        Me.rdbno.Location = New System.Drawing.Point(83, 188)
        Me.rdbno.Name = "rdbno"
        Me.rdbno.Size = New System.Drawing.Size(39, 17)
        Me.rdbno.TabIndex = 4
        Me.rdbno.Text = "No"
        Me.rdbno.UseVisualStyleBackColor = True
        '
        'rdbyes
        '
        Me.rdbyes.AutoSize = True
        Me.rdbyes.Checked = True
        Me.rdbyes.Location = New System.Drawing.Point(33, 188)
        Me.rdbyes.Name = "rdbyes"
        Me.rdbyes.Size = New System.Drawing.Size(43, 17)
        Me.rdbyes.TabIndex = 3
        Me.rdbyes.TabStop = True
        Me.rdbyes.Text = "Yes"
        Me.rdbyes.UseVisualStyleBackColor = True
        '
        'Label19
        '
        Me.Label19.AutoSize = True
        Me.Label19.Location = New System.Drawing.Point(30, 159)
        Me.Label19.Name = "Label19"
        Me.Label19.Size = New System.Drawing.Size(61, 13)
        Me.Label19.TabIndex = 2
        Me.Label19.Text = "Claim Apply"
        '
        'Label18
        '
        Me.Label18.AutoSize = True
        Me.Label18.Location = New System.Drawing.Point(27, 236)
        Me.Label18.Name = "Label18"
        Me.Label18.Size = New System.Drawing.Size(64, 13)
        Me.Label18.TabIndex = 1
        Me.Label18.Text = "Conclusions"
        '
        'Label17
        '
        Me.Label17.AutoSize = True
        Me.Label17.Location = New System.Drawing.Point(27, 47)
        Me.Label17.Name = "Label17"
        Me.Label17.Size = New System.Drawing.Size(56, 13)
        Me.Label17.TabIndex = 0
        Me.Label17.Text = "Comments"
        '
        'btnImprimir
        '
        Me.btnImprimir.Image = Global.KARIMs_SGI.My.Resources.Resources.print
        Me.btnImprimir.ImageAlign = System.Drawing.ContentAlignment.TopCenter
        Me.btnImprimir.Location = New System.Drawing.Point(203, 12)
        Me.btnImprimir.Name = "btnImprimir"
        Me.btnImprimir.Size = New System.Drawing.Size(61, 42)
        Me.btnImprimir.TabIndex = 7
        Me.btnImprimir.Text = "Imprimir"
        Me.btnImprimir.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.btnImprimir.UseVisualStyleBackColor = True
        '
        'Encabezado1
        '
        Me.Encabezado1.Dock = System.Windows.Forms.DockStyle.Top
        Me.Encabezado1.Location = New System.Drawing.Point(0, 0)
        Me.Encabezado1.Name = "Encabezado1"
        Me.Encabezado1.Size = New System.Drawing.Size(1184, 72)
        Me.Encabezado1.TabIndex = 0
        '
        'BarraTitulo1
        '
        Me.BarraTitulo1.BackColor = System.Drawing.Color.WhiteSmoke
        Me.BarraTitulo1.Dock = System.Windows.Forms.DockStyle.Top
        Me.BarraTitulo1.Location = New System.Drawing.Point(0, 72)
        Me.BarraTitulo1.Name = "BarraTitulo1"
        Me.BarraTitulo1.Size = New System.Drawing.Size(1184, 30)
        Me.BarraTitulo1.TabIndex = 1
        '
        'frmReclamos
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1184, 656)
        Me.Controls.Add(Me.btnImprimir)
        Me.Controls.Add(Me.TAB_CLAIM)
        Me.Controls.Add(Me.panelFiltro)
        Me.Controls.Add(Me.Encabezado1)
        Me.Name = "frmReclamos"
        Me.Text = "frmReclamos"
        Me.WindowState = System.Windows.Forms.FormWindowState.Maximized
        CType(Me.dglista, System.ComponentModel.ISupportInitialize).EndInit()
        Me.panelFiltro.ResumeLayout(False)
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.TAB_CLAIM.ResumeLayout(False)
        Me.tga_general.ResumeLayout(False)
        Me.tga_general.PerformLayout()
        CType(Me.dgdetalle, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Panel2.ResumeLayout(False)
        CType(Me.dgvsubDocumentos, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        Me.TabPage1.ResumeLayout(False)
        Me.TabPage1.PerformLayout()
        Me.tgObeservation.ResumeLayout(False)
        Me.tgObeservation.PerformLayout()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents Encabezado1 As KARIMs_SGI.encabezado
    Friend WithEvents BarraTitulo1 As KARIMs_SGI.BarraTitulo
    Friend WithEvents dglista As System.Windows.Forms.DataGridView
    Friend WithEvents panelFiltro As System.Windows.Forms.Panel
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents dtpInicio As System.Windows.Forms.DateTimePicker
    Friend WithEvents dtpFin As System.Windows.Forms.DateTimePicker
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents chkfechas As System.Windows.Forms.CheckBox
    Friend WithEvents chkfacturas As System.Windows.Forms.CheckBox
    Friend WithEvents chkclientes As System.Windows.Forms.CheckBox
    Friend WithEvents CeldaFactura As System.Windows.Forms.TextBox
    Friend WithEvents CeldaCliente As System.Windows.Forms.TextBox
    Friend WithEvents TAB_CLAIM As System.Windows.Forms.TabControl
    Friend WithEvents tga_general As System.Windows.Forms.TabPage
    Friend WithEvents Customer As System.Windows.Forms.Label
    Friend WithEvents CeldaCustomer As System.Windows.Forms.TextBox
    Friend WithEvents tgObeservation As System.Windows.Forms.TabPage
    Friend WithEvents CeldaChargeback As System.Windows.Forms.TextBox
    Friend WithEvents CeldaAmount As System.Windows.Forms.TextBox
    Friend WithEvents Label22 As System.Windows.Forms.Label
    Friend WithEvents Label21 As System.Windows.Forms.Label
    Friend WithEvents CeldaConclusions As System.Windows.Forms.TextBox
    Friend WithEvents CeldaNoExplain As System.Windows.Forms.TextBox
    Friend WithEvents Label20 As System.Windows.Forms.Label
    Friend WithEvents CeldaComments As System.Windows.Forms.TextBox
    Friend WithEvents rdbno As System.Windows.Forms.RadioButton
    Friend WithEvents rdbyes As System.Windows.Forms.RadioButton
    Friend WithEvents Label19 As System.Windows.Forms.Label
    Friend WithEvents Label18 As System.Windows.Forms.Label
    Friend WithEvents Label17 As System.Windows.Forms.Label
    Friend WithEvents btncliente As System.Windows.Forms.Button
    Friend WithEvents btnfactura As System.Windows.Forms.Button
    Friend WithEvents dtp_claim As System.Windows.Forms.DateTimePicker
    Friend WithEvents btncustomer As System.Windows.Forms.Button
    Friend WithEvents CeldaCodCustomer As System.Windows.Forms.TextBox
    Friend WithEvents Cod As System.Windows.Forms.Label
    Friend WithEvents CeldaYearClaim As System.Windows.Forms.Label
    Friend WithEvents Label24 As System.Windows.Forms.Label
    Friend WithEvents CeldaClaimRefence As System.Windows.Forms.TextBox
    Friend WithEvents btnfiltrar As System.Windows.Forms.Button
    Friend WithEvents btnImprimir As System.Windows.Forms.Button
    Friend WithEvents celdaAnoClaim As System.Windows.Forms.Label
    Friend WithEvents CeldaClaim As System.Windows.Forms.Label
    Friend WithEvents celdapais As System.Windows.Forms.Label
    Friend WithEvents txtCli As System.Windows.Forms.TextBox
    Friend WithEvents dgdetalle As System.Windows.Forms.DataGridView
    Friend WithEvents TabPage1 As System.Windows.Forms.TabPage
    Friend WithEvents CeldaDificultiesCustomer As System.Windows.Forms.TextBox
    Friend WithEvents CeldaProblem As System.Windows.Forms.TextBox
    Friend WithEvents Label11 As System.Windows.Forms.Label
    Friend WithEvents Label10 As System.Windows.Forms.Label
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents CeldaLocationProblem As System.Windows.Forms.TextBox
    Friend WithEvents celdaLinea As System.Windows.Forms.Label
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
    Friend WithEvents LBLTotalQuantity As System.Windows.Forms.Label
    Friend WithEvents Label23 As System.Windows.Forms.Label
    Friend WithEvents btninvoice As System.Windows.Forms.Button
    Friend WithEvents btnQuitarFila As System.Windows.Forms.Button
    Friend WithEvents CeldaTotalQuantity As System.Windows.Forms.TextBox
    Friend WithEvents CeldaActionsDone As System.Windows.Forms.TextBox
    Friend WithEvents CeldaAnalysisInspection As System.Windows.Forms.TextBox
    Friend WithEvents Label16 As System.Windows.Forms.Label
    Friend WithEvents Label15 As System.Windows.Forms.Label
    Friend WithEvents Label14 As System.Windows.Forms.Label
    Friend WithEvents CeldaConfirmacionProducto As System.Windows.Forms.TextBox
    Friend WithEvents Label12 As System.Windows.Forms.Label
    Friend WithEvents Factura As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Año As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Linea As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Fecha As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Quantity As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Lote As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Descripcion As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Proveedor As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Usuario As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents KI As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents CeldaNumClaim As System.Windows.Forms.Label
    Friend WithEvents lblañoclaim As System.Windows.Forms.Label
    Friend WithEvents Lab As System.Windows.Forms.Label
    Friend WithEvents lblIdClaim As System.Windows.Forms.Label
    Friend WithEvents Claim As System.Windows.Forms.Label
    Friend WithEvents txtTotalDefect As System.Windows.Forms.TextBox
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Panel2 As System.Windows.Forms.Panel
    Friend WithEvents dgvsubDocumentos As System.Windows.Forms.DataGridView
    Friend WithEvents Documentos As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Datos As System.Windows.Forms.DataGridViewTextBoxColumn
End Class
