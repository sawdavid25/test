﻿Public Class frmNotasCreditoProveedor

#Region "Miembros"
    Dim strKey As String = STR_VACIO
    Dim logInsertar As Boolean = False
    Dim logConsultar As Boolean = False
    Dim logEditar As Boolean = False
    Dim LogBorrar As Boolean = False
    Dim intTipoIngreso As Integer = NO_FILA
    Dim cfun As New clsFunciones

    Private Const CATALOGO = 39

#End Region

#Region "Propiedades"
    Public Property Key As String
        Get
            Return strKey
        End Get
        Set(value As String)
            strKey = value
        End Set
    End Property
#End Region

#Region "Procediminetos"
    Private Sub Accessos()
        Dim cAccesos As New clsAccesos
        Dim strSQL As String = STR_VACIO

        Try
            If cAccesos.Accesos(strKey) = True Then
                logInsertar = cAccesos.Insertar
                logConsultar = cAccesos.Consultar
                logEditar = cAccesos.Editar
                LogBorrar = cAccesos.Borrar

            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub BloquearBotones(Optional ByVal logBloquear As Boolean = True)
        If logBloquear = True Then
            Encabezado1.botonBorrar.Enabled = False
            Encabezado1.botonGuardar.Enabled = False
            'botonImprimir.Enabled = False
        Else
            If LogBorrar = True Then
                Encabezado1.botonBorrar.Enabled = True
            Else
                Encabezado1.botonBorrar.Enabled = False
            End If
            Encabezado1.botonGuardar.Enabled = True
            'botonImprimir.Enabled = True
        End If
    End Sub

    Private Sub LimpiarCampos()
        checkActivo.Checked = True
        checkActivo.Enabled = True
        etiquetaDocumento.Visible = False
        celdaTasa.Text = cFunciones.QueryTasa("CURDATE()")
        dtFechaDoc.Enabled = True
        botonProveedor.Enabled = True
        botonSerie.Enabled = True
        celdaCorrelativo.Clear()
        celdaAnio.Clear()
        celdaNumero.Clear()
        celdaProveedor.Clear()
        celdaDireccion.Clear()
        celdaTelefono.Clear()
        celdaNit.Clear()
        celdaUsuario.Clear()
        celdaUsuario.Text = Sesion.Usuario
        celdaIdProveedor.Clear()
        celdaConcepto.Clear()
        celdaAbono.Clear()
        dgFacturas.Rows.Clear()
        DgImpuesto.Rows.Clear()
        DgDetalle.Rows.Clear()
        celdaReferencia.Clear()
        ' celdaSerie.Clear()
        celdaMoneda.Text = "US$"
        celdaIDMoneda.Text = 178


    End Sub
    Private Sub MostrarLista(Optional ByVal logMostrar As Boolean = True, Optional logInsert As Boolean = False)
        If logMostrar = True Then
            'ocultar panel de documento
            panelDocumento.Dock = DockStyle.None
            panelDocumento.Visible = False
            'actualizar Titulo
            BarraTitulo1.CambiarTitulo("Credit / Provider Notes ")
            ListaPrincipal()
            'Mostrar Panel Filtro
            panelListaPrincipal.Visible = True
            panelListaPrincipal.Dock = DockStyle.Fill
            BloquearBotones()
            'Me.Tag = "Nuevo"
        Else
            'Ocultar Panel Filtro
            panelListaPrincipal.Visible = False
            panelListaPrincipal.Dock = DockStyle.None
            'Mostrar panel de documento
            panelDocumento.Dock = DockStyle.Fill
            panelDocumento.Visible = True
            'Verifica si se va a crear un nuevo documento o se va modifica
            If logInsert = False Then
                BarraTitulo1.CambiarTitulo("Credit Note")
                Me.Tag = "Mod"
                BloquearBotones(False)
                'botonImprimir.Enabled = True
            Else
                BarraTitulo1.CambiarTitulo("New Credit Note")
                Me.Tag = "Nuevo"
                BloquearBotones(False)
                'botonImprimir.Enabled = False

                LimpiarCampos()
            End If

            dgLista.DataSource = Nothing
        End If
    End Sub
    Private Sub frmNotasCreditoProveedor_Load(sender As Object, e As EventArgs) Handles Me.Load
        dtpInicio.Value = DateSerial(Year(Date.Now), Month(Date.Now) - 1, 30)
        dtpFin.Value = DateSerial(Year(Date.Now), Month(Date.Now) + 1, vbEmpty)

        Accessos()
        MostrarLista()
    End Sub
    Private Function SQLListaPrincipal()
        Dim strsql As String = STR_VACIO

        strsql = " SELECT h.HDoc_Doc_Ano Anio,IFNULL(h.HDoc_RF2_Cod,'') Correlativo,h.HDoc_Doc_Num Numero,h.HDoc_RF1_Dbl Numero2 ,h.HDoc_Doc_Fec Fecha, p.pro_proveedor Proveedor, h.HDoc_DR1_Num Referencia, h.HDoc_Doc_Status estatus "
        strsql &= "    From Dcmtos_HDR h "
        strsql &= "        Left JOIN Proveedores p ON p.pro_sisemp = h.HDoc_Sis_Emp AND p.pro_codigo = h.HDoc_Emp_Cod "
        strsql &= "            Left JOIN ECtaCte e ON e.ECta_Sis_Emp = h.HDoc_Sis_Emp AND e.ECta_Doc_Cat = h.HDoc_Doc_Cat AND e.ECta_Doc_Ano = h.HDoc_Doc_Ano AND e.ECta_Doc_Num = h.HDoc_Doc_Num "
        ' strsql &= "                Left JOIN Dcmtos_DTL d ON d.DDoc_Sis_Emp = e.ECta_Sis_Emp AND d.DDoc_Doc_Cat = e.ECta_Ref_Cat AND d.DDoc_Doc_Cat = e.ECta_Ref_Ano AND d.DDoc_Doc_Num = e.ECta_Ref_Num "
        strsql &= "                    WHERE h.HDoc_Sis_Emp = {empresa} AND h.HDoc_Doc_Cat = 39  "
        If checkFecha.Checked = True Then
            strsql &= " AND h.HDoc_Doc_Fec BETWEEN '{inicio}' AND '{fin}' "
        End If

        strsql &= "                        ORDER BY h.HDoc_Doc_Ano  DESC"

        strsql = Replace(strsql, "{empresa}", Sesion.IdEmpresa)
        strsql = Replace(strsql, "{inicio}", dtpInicio.Value.ToString(FORMATO_MYSQL))
        strsql = Replace(strsql, "{fin}", dtpFin.Value.ToString(FORMATO_MYSQL))

        Return strsql
    End Function
    Private Function ValidarNumero(ByVal Anio As Integer) As Integer
        Dim strSQL As String
        Dim COM As MySqlCommand
        Dim conec As MySqlConnection
        Dim intValidarNumero As Integer

        strSQL = " SELECT IFNULL(MAX(h.HDoc_Doc_Num),0) Numero "
        strSQL &= "     FROM Dcmtos_HDR h "
        strSQL &= "          WHERE  h.HDoc_Sis_Emp = {empresa} AND h.HDoc_Doc_Cat = 39 AND  h.HDoc_DR2_Num = '{serie}' "
        strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
        strSQL = Replace(strSQL, "{anio}", Anio)
        strSQL = Replace(strSQL, "{serie}", celdaSerie.Text)

        conec = New MySqlConnection(strConexion)
        conec.Open()
        COM = New MySqlCommand(strSQL, conec)
        intValidarNumero = COM.ExecuteScalar
        conec.Close()
        conec.Dispose()
        conec = Nothing
        System.GC.Collect()



        Return intValidarNumero
    End Function
    Private Function CorrelativoNCProveedor(ByVal Anio As Integer)
        Dim intNumero As Integer
        Dim strSQL As String = STR_VACIO
        Dim COM As MySqlCommand
        Dim conec As MySqlConnection

        strSQL = " SELECT ifnull(MAX(HDoc_Doc_Num),0)+1 Numero"
        strSQL &= "      FROM Dcmtos_HDR h "
        strSQL &= "         WHERE h.HDoc_Sis_Emp = {empresa} AND h.HDoc_Doc_Cat = 39 AND HDoc_Doc_Ano = {anio}  "
        strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
        strSQL = Replace(strSQL, "{anio}", Anio)
        strSQL = Replace(strSQL, "{serie}", celdaSerie.Text)

        conec = New MySqlConnection(strConexion)
        conec.Open()
        COM = New MySqlCommand(strSQL, conec)
        intNumero = COM.ExecuteScalar
        conec.Close()
        conec.Dispose()
        conec = Nothing
        System.GC.Collect()



        Return intNumero
    End Function
    Private Function Pais()
        Dim strSQL2 As String
        Dim COM2 As New MySqlCommand
        Dim conec2 As New MySqlConnection
        Dim intPais As Integer = INT_CERO

        strSQL2 = "SELECT e.emp_pais "
        strSQL2 &= "     FROM Empresas e"
        strSQL2 &= "         WHERE e.emp_no = {empresa} "

        strSQL2 = Replace(strSQL2, "{empresa}", Sesion.IdEmpresa)
        conec2 = New MySqlConnection(strConexion)
        conec2.Open()
        COM2 = New MySqlCommand(strSQL2, conec2)
        Using conec2
            intPais = COM2.ExecuteScalar
            COM2.Dispose()
            COM2 = Nothing
            conec2.Close()
            conec2.Dispose()
            conec2 = Nothing
            System.GC.Collect()
        End Using

        Return intPais
    End Function
    Private Function SQLNumero(ByVal Anio As Integer) As Integer
        Dim strSQL As String
        Dim COM As MySqlCommand
        Dim conec As MySqlConnection
        Dim intNumero As Integer

        strSQL = " SELECT ifnull(MAX(HDoc_RF1_Dbl),0)+1 Numero"
        strSQL &= "      FROM Dcmtos_HDR h "
        strSQL &= "         WHERE h.HDoc_Sis_Emp = {empresa} AND h.HDoc_Doc_Cat = 39 AND HDoc_Doc_Ano = {anio} AND  HDoc_DR2_Num = '{serie}' "
        strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
        strSQL = Replace(strSQL, "{anio}", Anio)
        strSQL = Replace(strSQL, "{serie}", celdaSerie.Text)

        conec = New MySqlConnection(strConexion)
        conec.Open()
        COM = New MySqlCommand(strSQL, conec)
        intNumero = COM.ExecuteScalar
        conec.Close()
        conec.Dispose()
        conec = Nothing
        System.GC.Collect()


        Return intNumero
    End Function
    Private Function SQLEmpresa() As Integer
        Dim strSQL As String = STR_VACIO
        Dim intEmpresa As Integer
        Dim COM As MySqlCommand
        Dim conec As MySqlConnection

        strSQL = "  SELECT e.emp_pais  "
        strSQL &= "     FROM Empresas e  "
        strSQL &= "         WHERE e.emp_no = {empresa} "
        strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)

        conec = New MySqlConnection(strConexion)
        conec.Open()
        COM = New MySqlCommand(strSQL, conec)
        intEmpresa = COM.ExecuteScalar
        conec.Close()
        conec.Dispose()
        conec = Nothing
        System.GC.Collect()

        Return intEmpresa
    End Function
    Private Function SQLCargarDatos(ByVal anio As Integer, ByVal num As Integer)
        Dim strsql As String = STR_VACIO
        strsql = " SELECT h.HDoc_Doc_Ano Anio,IFNULL(h.HDoc_RF2_Cod,'') Correlativo , h.HDoc_Doc_Num Numero, h.HDoc_DR1_DBL NumE ,h.HDoc_Doc_Fec Fecha,p.pro_codigo codigo,IFNULL(h.HDoc_DR2_Num,'') serie ,IFNULL(h.HDoc_RF1_Txt,'') Serie2,p.pro_proveedor Proveedor, p.pro_direccion direccion, p.pro_telefono telefono, p.pro_nit nit, h.HDoc_Doc_Mon Moneda, c.cat_clave signo,  h.HDoc_Doc_TC TC, h.HDoc_DR1_Num Referencia, h.HDoc_Doc_Status estatus,h.HDoc_Usuario usuario,h.HDoc_RF1_Cod concepto, h.HDoc_RF2_Dbl Abono, d.HDoc_Doc_Ano anioFact, d.HDoc_Doc_Num num, d.HDoc_Doc_Fec fechaFact, d.HDoc_Usuario userFact, CONCAT(d.HDoc_DR1_Num, ' ',d.HDoc_DR2_Num) factura, d.HDoc_DR1_Fec vence, IFNULL(d.HDoc_DR1_Emp,-1) Documento, IFNULL(h.HDoc_DR2_Cat,0) Exenta "
        strsql &= "    From Dcmtos_HDR h "
        strsql &= "        Left JOIN Proveedores p ON p.pro_sisemp = h.HDoc_Sis_Emp AND p.pro_codigo = h.HDoc_Emp_Cod "
        strsql &= "            Left JOIN ECtaCte e ON e.ECta_Sis_Emp = h.HDoc_Sis_Emp AND e.ECta_Doc_Cat = h.HDoc_Doc_Cat AND e.ECta_Doc_Ano = h.HDoc_Doc_Ano AND e.ECta_Doc_Num = h.HDoc_Doc_Num "
        strsql &= "                Left JOIN Dcmtos_HDR d ON d.HDoc_Sis_Emp = e.ECta_Sis_Emp AND d.HDoc_Doc_Cat = e.ECta_Ref_Cat AND d.HDoc_Doc_Ano = e.ECta_Ref_Ano AND d.HDoc_Doc_Num = e.ECta_Ref_Num "
        strsql &= "                  LEFT JOIN Catalogos c ON c.cat_num = h.HDoc_Doc_Mon "
        strsql &= "                      WHERE h.HDoc_Sis_Emp = {empresa} AND h.HDoc_Doc_Cat = 39 AND h.HDoc_Doc_Ano = {anio} AND h.HDoc_Doc_Num= {num} "

        strsql = Replace(strsql, "{empresa}", Sesion.IdEmpresa)
        strsql = Replace(strsql, "{anio}", anio)
        strsql = Replace(strsql, "{num}", num)

        Return strsql
    End Function
    Private Function SQLCargarFacturas()
        Dim strSQL As String = STR_VACIO
        strSQL = " SELECT g.*, ROUND(((g.Monto + g.Debitos) - (g.Creditos+ g.reten)) / g.Tasa,2) Saldo "
        strSQL &= "    FROM( "
        strSQL &= "        Select e.HDoc_Doc_Ano Anio, e.HDoc_Doc_Num Numero,e.HDoc_Doc_Fec Fecha, CONCAT(e.HDoc_DR1_Num,' ', "
        strSQL &= "            Replace(e.HDoc_DR2_Num,'N/A','')) Referencia, e.HDoc_Usuario Usuario, e.HDoc_Doc_Mon moneda, cm.cat_clave signo, e.HDoc_DR1_Fec vence, e.HDoc_Doc_TC Tasa, ROUND(e.HDoc_RF1_Dbl,2) Total, ROUND(e.HDoc_RF1_Dbl*e.HDoc_Doc_TC,2) Monto, SUM(IF(s.ECta_Doc_Cat IN (40,53,54), IF(e.HDoc_Doc_Mon=177, (CASE WHEN s.ECta_moneda=e.HDoc_Doc_Mon THEN s.ECta_Crgo_Loc ELSE ROUND(s.ECta_Crgo_Ext * s.ECta_TC,2) END), (CASE WHEN s.ECta_moneda=e.HDoc_Doc_Mon THEN ROUND(s.ECta_Crgo_Ext * e.HDoc_Doc_TC,2) ELSE s.ECta_Crgo_Loc END)), 0)) Debitos, SUM(IF(s.ECta_Doc_Cat IN (39,51,52), IF(e.HDoc_Doc_Mon=177, (CASE WHEN s.ECta_moneda = e.HDoc_Doc_Mon THEN s.ECta_Abno_Loc ELSE ROUND(s.ECta_Abno_Ext * s.ECta_TC, 2) END), (CASE WHEN s.ECta_moneda= e.HDoc_Doc_Mon THEN ROUND(s.ECta_Abno_Ext * e.HDoc_Doc_TC,2) ELSE (s.ECta_Abno_Ext * e.HDoc_Doc_TC) END)), 0)) Creditos,IFNULL(e.HDoc_DR1_Emp,-1) Documento, e.HDoc_DR2_Cat Exenta, IFNULL(( "
        strSQL &= "                Select  r.HDoc_RF1_Dbl "
        strSQL &= "                    From Dcmtos_HDR r "
        strSQL &= "                        WHERE r.HDoc_Sis_Emp=e.HDoc_Sis_Emp AND r.HDoc_Doc_Cat=220 AND r.HDoc_Pro_DCat=e.HDoc_Doc_Cat AND r.HDoc_Pro_DAno=e.HDoc_Doc_Ano AND r.HDoc_Pro_DNum=e.HDoc_Doc_Num "
        strSQL &= "                            LIMIT 1),0) reten "
        strSQL &= "                            From Dcmtos_HDR e "
        strSQL &= "                        Left JOIN ECtaCte s ON s.ECta_Sis_Emp=e.HDoc_Sis_Emp AND s.ECta_Ref_Cat=e.HDoc_Doc_Cat AND s.ECta_Ref_Ano=e.HDoc_Doc_Ano AND s.ECta_Ref_Num=e.HDoc_Doc_Num AND NOT(s.ECta_Doc_Cat=e.HDoc_Doc_Cat AND s.ECta_Doc_Ano=e.HDoc_Doc_Ano AND s.ECta_Doc_Num=e.HDoc_Doc_Num) "
        strSQL &= "                    Left JOIN Catalogos cm ON cm.cat_clase='Monedas' AND cm.cat_num=e.HDoc_Doc_Mon "
        strSQL &= "                WHERE e.HDoc_Sis_Emp = {empresa} AND e.HDoc_Doc_Cat = 44 AND e.HDoc_Emp_Cod = {cod}  "
        strSQL &= "            GROUP BY e.HDoc_Sis_Emp, e.HDoc_Doc_Cat, e.HDoc_Doc_Ano, e.HDoc_Doc_Num "
        strSQL &= "        HAVING ABS(ROUND((Monto + Debitos) - (Creditos + reten),2)) > 0.01) g "
        ' strSQL &= "    ORDER BY Fecha, Referencia "
        strSQL &= "         ORDER By Fecha Desc "
        strSQL = Replace(strSQL, "{cod}", celdaIdProveedor.Text)
        strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)

        Return strSQL
    End Function
    Private Sub ListaPrincipal()
        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader
        Dim strSQL As String = STR_VACIO
        Dim strfila As String = STR_VACIO

        Try
            strSQL = SQLListaPrincipal()
            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSQL, CON)
            REA = COM.ExecuteReader
            If REA.HasRows Then

                dgLista.Rows.Clear()
                If (Sesion.IdEmpresa = 12 And Pais() = 310) Then 'Or Sesion.IdEmpresa = 14 And Pais() = 327 Then
                    dgLista.Columns(1).Visible = False
                Else
                    dgLista.Columns(2).Visible = False
                End If


                Do While REA.Read
                    strfila = REA.GetInt32("Anio") & "|"
                    strfila &= REA.GetInt32("Numero") & "|"
                    strfila &= REA.GetInt32("Numero2") & "|"
                    strfila &= REA.GetDateTime("Fecha").ToString(FORMATO_MYSQL) & "|"
                    strfila &= REA.GetString("Proveedor") & "|"
                    strfila &= REA.GetString("Referencia") & "|"
                    strfila &= REA.GetString("Correlativo") & "|"
                    strfila &= REA.GetInt32("estatus")
                    If REA.GetString("estatus") = 1 Then
                        cfun.AgregarFila(dgLista, strfila)
                    Else
                        cfun.AgregarFila(dgLista, strfila, Color.Red)
                    End If

                Loop

            End If

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub
    Private Sub CargarDatos(ByVal anio As Integer, ByVal num As Integer)
        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader
        Dim strSQL As String = STR_VACIO
        Dim strFila As String = STR_VACIO
        Dim intEmpresa As Integer

        Try
            strSQL = SQLCargarDatos(anio, num)
            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSQL, CON)
            REA = COM.ExecuteReader

            If REA.HasRows Then
                Do While REA.Read
                    botonProveedor.Enabled = False
                    botonSerie.Enabled = False
                    dtFechaDoc.Enabled = False
                    celdaNumero.ReadOnly = True
                    celdaProveedor.ReadOnly = True
                    celdaDireccion.ReadOnly = True
                    celdaTelefono.ReadOnly = True
                    celdaNit.ReadOnly = True

                    intEmpresa = SQLEmpresa()

                    celdaAnio.Text = REA.GetInt32("Anio")
                    If Sesion.IdEmpresa = 12 And intEmpresa = 0 Or Sesion.IdEmpresa = 18 Or (Sesion.IdEmpresa = 15) Or (Sesion.IdEmpresa = 19) Then
                        celdaNumero.Text = REA.GetInt32("Numero")
                        celdaCorrelativo.Text = REA.GetString("Correlativo")

                    ElseIf Sesion.IdEmpresa = 12 And intEmpresa = 310 Or (Sesion.IdEmpresa = 16) Then
                        celdaTemporal.Text = REA.GetInt32("NumE")
                        celdaNumero.Text = REA.GetInt32("Numero")
                        celdaCorrelativo.Text = REA.GetString("Correlativo")
                        celdaNumero.Visible = True
                        celdaTemporal.Visible = False
                    ElseIf Sesion.IdEmpresa = 11 And intEmpresa = 1 Then
                        celdaNumero.Text = REA.GetInt32("Numero")
                        celdaCorrelativo.Text = REA.GetString("Correlativo")
                    ElseIf Sesion.IdEmpresa = 14 And intEmpresa = 327 Then
                        celdaNumero.Visible = True
                        celdaTemporal.Visible = False
                        celdaTemporal.Text = REA.GetInt32("NumE")
                        celdaNumero.Text = REA.GetInt32("Numero")
                        celdaCorrelativo.Text = REA.GetString("Correlativo")
                    End If

                    celdaNumero.Text = REA.GetInt32("Numero")
                    dtFechaDoc.Value = REA.GetDateTime("Fecha")
                    celdaIdProveedor.Text = REA.GetInt32("codigo")
                    celdaSerie.Text = REA.GetString("serie")
                    celdaSerie2.Text = REA.GetString("Serie2")
                    celdaProveedor.Text = REA.GetString("Proveedor")
                    celdaDireccion.Text = REA.GetString("direccion")
                    celdaTelefono.Text = REA.GetString("telefono")
                    celdaNit.Text = REA.GetString("nit")
                    celdaIDMoneda.Text = REA.GetInt32("Moneda")
                    celdaMoneda.Text = REA.GetString("signo")
                    celdaTasa.Text = REA.GetDouble("TC")
                    If REA.GetInt32("estatus") = 1 Then
                        checkActivo.Checked = True
                        checkActivo.Enabled = True
                    Else
                        checkActivo.Checked = False
                        checkActivo.Enabled = False
                    End If
                    celdaUsuario.Text = REA.GetString("usuario")
                    celdaConcepto.Text = REA.GetString("concepto")
                    celdaAbono.Text = REA.GetDouble("Abono").ToString(FORMATO_MONEDA)

                    strFila = REA.GetInt32("anioFact") & "|"
                    strFila &= REA.GetInt32("num") & "|"
                    strFila &= REA.GetDateTime("fechaFact").ToString(FORMATO_MYSQL) & "|"
                    strFila &= REA.GetString("userFact") & "|"
                    strFila &= REA.GetString("factura") & "|"
                    strFila &= 0 & "|"
                    strFila &= REA.GetDateTime("vence").ToString(FORMATO_MYSQL) & "|"
                    strFila &= REA.GetInt32("Documento") & "|"
                    strFila &= REA.GetInt32("Exenta")

                    If REA.GetInt32("Documento") = -1 Then ' Importacion

                    ElseIf REA.GetInt32("Documento") = 2 Then ' Pequeño Contribuñente

                    ElseIf REA.GetInt32("Exenta") = 1 Then
                        etiquetaDocumento.Visible = True
                        etiquetaDocumento.Text = "Extemporanea"
                        etiquetaDocumento.ForeColor = Color.Red
                        etiquetaDocumento.BackColor = Color.LightSkyBlue
                    ElseIf REA.GetInt32("Exenta") = 0 Then
                        etiquetaDocumento.Visible = True
                        etiquetaDocumento.Text = "No Extemporanea"
                        etiquetaDocumento.ForeColor = Color.Black
                        etiquetaDocumento.BackColor = Color.LightGreen
                    End If


                    cfun.AgregarFila(dgFacturas, strFila)
                    celdaReferencia.Text = REA.GetString("factura")
                Loop
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub
    Private Sub CargarFacturas()
        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader
        Dim strSQL As String = STR_VACIO
        Dim strNombreCuenta As String
        Dim strCuenta As String
        Dim strFila As String = STR_VACIO

        Try
            strSQL = SQLCargarFacturas()
            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSQL, CON)
            REA = COM.ExecuteReader
            DgImpuesto.Rows.Clear()
            DgDetalle.Rows.Clear()
            dgFacturas.Rows.Clear()
            If REA.HasRows Then
                Do While REA.Read
                    strFila = REA.GetInt32("Anio") & "|"
                    strFila &= REA.GetInt32("Numero") & "|"
                    strFila &= REA.GetDateTime("Fecha").ToString(FORMATO_MYSQL) & "|"
                    strFila &= REA.GetString("Usuario") & "|"
                    strFila &= REA.GetString("Referencia") & "|"
                    strFila &= 0 & "|"
                    strFila &= REA.GetDateTime("vence").ToString(FORMATO_MYSQL) & "|"
                    strFila &= REA.GetInt32("Documento") & "|"
                    strFila &= REA.GetInt32("Exenta")
                    cfun.AgregarFila(dgFacturas, strFila)

                    celdaIDMoneda.Text = REA.GetInt32("moneda")
                    celdaTasa.Text = REA.GetDouble("Tasa")
                    celdaMoneda.Text = REA.GetString("signo")
                    celdaReferencia.Text = REA.GetString("Referencia")

                Loop
            End If
            COM = Nothing
            REA.Close()
            REA = Nothing
            strSQL = STR_VACIO
            If dgFacturas.Rows.Count = 1 Then
                strSQL = " SELECT cc.id_cuenta Cuenta , cc.nombre Nombre   "
                strSQL &= "     from {Base}.cuentas cc  "
                strSQL &= "         WHERE  cc.id_cuenta  = '0501012'  AND cc.ejercicio = 0  "
                strSQL = Replace(strSQL, "{Base}", cFunciones.ContaEmpresa)
                MyCnn.CONECTAR = strConexion
                COM = New MySqlCommand(strSQL, CON)
                REA = COM.ExecuteReader
                If REA.HasRows Then
                    Do While REA.Read
                        strCuenta = REA.GetString("Cuenta")
                        strNombreCuenta = REA.GetString("Nombre")
                    Loop
                End If
                CargarDetalleFact(dgFacturas.CurrentRow.Cells("colAnioF").Value, dgFacturas.CurrentRow.Cells("colNumeroF").Value, strCuenta, strNombreCuenta)
            End If


        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub
    Private Function SQLImpuesto(ByVal Anio As Integer, ByVal Numero As Integer) As String
        Dim strSQL As String = STR_VACIO

        strSQL = " SELECT   MDoc_Lin_Base Base, MDoc_Lin_Monto Monto "
        strSQL &= "     FROM Dcmtos_IMP "
        strSQL &= "         WHERE MDoc_Sis_Emp = {empresa} AND MDoc_Doc_Cat = 39 AND MDoc_Doc_Ano = {anio} AND MDoc_Doc_Num = {numero} "
        strSQL &= "              ORDER BY MDoc_Doc_Lin "

        strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
        strSQL = Replace(strSQL, "{anio}", Anio)
        strSQL = Replace(strSQL, "{numero}", Numero)

        Return strSQL
    End Function
    Public Sub CargarImpuesto(ByVal Anio As Integer, ByVal Numero As Integer)
        Dim strSQL As String = STR_VACIO
        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader
        Dim strFila As String = STR_VACIO
        Try
            strSQL = SQLImpuesto(Anio, Numero)
            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSQL, CON)
            REA = COM.ExecuteReader
            DgImpuesto.Rows.Clear()
            If REA.HasRows Then

                Do While REA.Read
                    strFila = REA.GetDouble("Base").ToString(FORMATO_MONEDA) & "|"
                    strFila &= REA.GetDouble("Monto").ToString(FORMATO_MONEDA) & "|"
                    strFila &= (REA.GetDouble("Base") + REA.GetDouble("Monto")).ToString(FORMATO_MONEDA) & "|"
                    strFila &= "1"
                    cFunciones.AgregarFila(DgImpuesto, strFila)
                Loop
            End If

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub
    Private Function SQLFacturaDetalle(ByVal Anio As Integer, ByVal Numero As Integer) As String
        Dim strSQL As String = STR_VACIO

        strSQL = " SELECT d.DDoc_Doc_Lin LineaFactura, d.DDoc_Prd_NET Precio, IFNULL(d.DDoc_RF1_Cod,'') Cuenta, IFNULL(c.nombre,'') NomCuenta, ifnull (d.DDoc_RF3_Num, 0) Costo,  ifnull (c1.cost_nombre, '') CCosto, h.HDoc_Doc_TC Tasa "
        strSQL &= "     FROM Dcmtos_DTL d "
        strSQL &= "         LEFT JOIN Dcmtos_HDR h ON h.HDoc_Sis_Emp = d.DDoc_Sis_Emp AND h.HDoc_Doc_Cat = d.DDoc_Doc_Cat AND h.HDoc_Doc_Ano = d.DDoc_Doc_Ano AND h.HDoc_Doc_Num = d.DDoc_Doc_Num "
        strSQL &= "          left join {conta}.cuentas c on c.id_cuenta = d.DDoc_RF1_Cod  "
        strSQL &= "              left join {conta}.costos c1 on c1.cost_num = d.DDoc_RF3_Num "
        strSQL &= "                  left Join Tipos_Activo TA on TA.Empresa = d.DDoc_Sis_Emp and TA.Codigo = d.DDoc_RF2_Dbl "
        strSQL &= "                     WHERE d.DDoc_Sis_Emp = {empresa} AND d.DDoc_Doc_Cat = 44 AND d.DDoc_Doc_Ano = {anio} AND d.DDoc_Doc_Num = {numero} "
        strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
        strSQL = Replace(strSQL, "{anio}", Anio)
        strSQL = Replace(strSQL, "{numero}", Numero)
        strSQL = Replace(strSQL, "{conta}", cFunciones.ContaEmpresa)


        Return strSQL
    End Function
    Public Sub CargarDetalleFact(ByVal anio As Integer, ByVal Numero As Integer, Optional strCuenta As String = STR_VACIO, Optional strNombreCuenta As String = STR_VACIO)
        Dim strSQL As String = STR_VACIO

        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader
        Dim strFila As String = STR_VACIO
        Dim dblAbono As Double
        Try
            strSQL = SQLFacturaDetalle(anio, Numero)
            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSQL, CON)
            REA = COM.ExecuteReader
            If REA.HasRows Then
                Do While REA.Read

                    If dgFacturas.CurrentRow.Cells("colDocumento").Value = -1 Then ' Importacion
                        strFila = REA.GetInt32("LineaFactura") & "|"
                        strFila &= INT_CERO.ToString(FORMATO_MONEDA) & "|"
                        strFila &= strCuenta & "|"
                        strFila &= strNombreCuenta & "|"
                        strFila &= REA.GetString("Costo") & "|"
                        strFila &= REA.GetString("CCosto") & "|"
                        strFila &= "0"
                        dblAbono = dblAbono + INT_CERO

                    Else
                        strFila = REA.GetInt32("LineaFactura") & "|"
                        strFila &= REA.GetDouble("Precio").ToString(FORMATO_MONEDA) & "|"
                        strFila &= REA.GetString("Cuenta") & "|"
                        strFila &= REA.GetString("NomCuenta") & "|"
                        strFila &= REA.GetString("Costo") & "|"
                        strFila &= REA.GetString("CCosto") & "|"
                        strFila &= "0"
                        dblAbono = dblAbono + REA.GetDouble("Precio")
                    End If
                    cfun.AgregarFila(DgDetalle, strFila)
                    celdaTasa.Text = REA.GetDouble("Tasa")
                Loop
            End If
            COM = Nothing
            REA.Close()
            REA = Nothing
            celdaAbono.Text = dblAbono.ToString(FORMATO_MONEDA)

        


        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub
    Private Function NuevaLinea(ByVal Codigo As Integer) As Integer
        Dim strSQL As String = STR_VACIO
        Dim conec As New MySqlConnection
        Dim COM As MySqlCommand
        Dim LineaNueva As Integer

        strSQL = " Select IFNULL(MAX(DTL.DDoc_Doc_Lin),0) + 1  DTL "
        strSQL &= " FROM Dcmtos_DTL DTL "
        strSQL &= " WHERE DTL.DDoc_Sis_emp = {empresa} And DTL.DDoc_Doc_Cat = {catalogo} And DTL.DDoc_Doc_Ano = {anio} And DTL.DDoc_Doc_Num ={codigo} "

        strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
        strSQL = Replace(strSQL, "{catalogo}", 39)
        strSQL = Replace(strSQL, "{anio}", celdaAnio.Text)
        strSQL = Replace(strSQL, "{codigo}", Codigo)



        conec = New MySqlConnection(strConexion)
        conec.Open()
        COM = New MySqlCommand(strSQL, conec)
        LineaNueva = COM.ExecuteScalar
        conec.Close()
        conec.Dispose()
        conec = Nothing
        System.GC.Collect()
        Return LineaNueva
    End Function
    Private Sub CalcularTotal()
        Try
            Dim dblAbono As Double
            For i As Integer = 0 To DgDetalle.Rows.Count - 1
                If DgDetalle.Rows(i).Visible = True Then
                    dblAbono = dblAbono + DgDetalle.Rows(i).Cells("colPrecio").Value
                End If
            Next
            celdaAbono.Text = dblAbono
        Catch ex As Exception
            MsgBox("Invalid Data")
            celdaAbono.Text = 0
        End Try

    End Sub
    Private Function SQLDetalle() As String
        Dim strSQL As String = STR_VACIO

        strSQL = " SELECT d.DDoc_Doc_Lin Linea, d.DDoc_Prd_NET Precio, d.DDoc_RF1_Cod Cuenta, IFNULL(c.nombre,'') NomCuenta,IFNULL(d.DDoc_RF3_Num,0) Costo, IFNULL (c1.cost_nombre, '') CCosto "
        strSQL &= "     FROM Dcmtos_DTL d "
        strSQL &= "         LEFT JOIN {conta}.cuentas c ON c.empresa = d.DDoc_Sis_Emp AND  c.id_cuenta = d.DDoc_RF1_Cod "
        strSQL &= "             LEFT JOIN {conta}.costos c1 ON c1.cost_num = d.DDoc_RF3_Num "
        strSQL &= "                 WHERE d.DDoc_Sis_Emp = {empresa} AND d.DDoc_Doc_Cat = 39 AND d.DDoc_Doc_Ano = {anio} AND d.DDoc_Doc_Num = {numero} "

        strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
        strSQL = Replace(strSQL, "{anio}", celdaAnio.Text)
        strSQL = Replace(strSQL, "{numero}", celdaNumero.Text)
        strSQL = Replace(strSQL, "{conta}", cFunciones.ContaEmpresa)

        Return strSQL
    End Function
    Public Sub CargarDetalle()
        Dim strSQL As String = STR_VACIO
        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader
        Dim strFila As String
        Dim dblAbono As Double
        Try
            strSQL = SQLDetalle()
            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSQL, CON)
            REA = COM.ExecuteReader
            DgDetalle.Rows.Clear()
            If REA.HasRows Then
                Do While REA.Read
                    strFila = REA.GetInt32("Linea") & "|"
                    strFila &= REA.GetDouble("Precio").ToString(FORMATO_MONEDA) & "|"
                    strFila &= REA.GetString("Cuenta") & "|"
                    strFila &= REA.GetString("NomCuenta") & "|"
                    strFila &= REA.GetInt32("Costo") & "|"
                    strFila &= REA.GetString("CCosto") & "|"
                    strFila &= "1"

                    dblAbono = dblAbono + REA.GetDouble("Precio")

                    cFunciones.AgregarFila(DgDetalle, strFila)
                Loop
            End If
            celdaAbono.Text = dblAbono.ToString(FORMATO_MONEDA)
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub
    Private Function IVA() As String
        Dim strIva As String = STR_VACIO
        Dim strSQL As String = STR_VACIO
        Dim conec As MySqlConnection
        Dim COM As MySqlCommand
        strSQL = " SELECT c.cat_sist IVA "
        strSQL &= "     FROM Catalogos c "
        strSQL &= "       WHERE c.cat_clase = 'Impuestos' AND c.cat_clave = 'IVA' AND c.cat_sisemp = {empresa}  "
        strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)

        conec = New MySqlConnection(strConexion)
        conec.Open()
        COM = New MySqlCommand(strSQL, conec)
        strIva = COM.ExecuteScalar
        conec.Close()
        conec.Dispose()
        conec = Nothing
        System.GC.Collect()


        Return strIva
    End Function
    Public Sub QuitarReferencia()
        Dim COM As MySqlCommand
        Dim strSQL As String
        Try

            strSQL = " UPDATE  ECtaCte  e  SET ECta_Abno_Loc = 0 , ECta_Abno_Ext = 0"
            strSQL &= "     WHERE e.ECta_Sis_Emp = {empresa} AND e.ECta_Doc_Cat = 39  and e.ECta_Doc_Ano = {anio} and e.ECta_Doc_Num = {numero} "
            If Sesion.IdEmpresa = 18 Then
                strSQL &= "; UPDATE  PDM.ECtaCte  e  SET ECta_Abno_Loc = 0 , ECta_Abno_Ext = 0"
                strSQL &= "     WHERE e.ECta_Sis_Emp = {empresa} AND e.ECta_Doc_Cat = 39  and e.ECta_Doc_Ano = {anio} and e.ECta_Doc_Num = {numero} "
            End If
            strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
            strSQL = Replace(strSQL, "{anio}", celdaAnio.Text)
            strSQL = Replace(strSQL, "{numero}", celdaNumero.Text)
            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSQL, CON)
            COM.ExecuteNonQuery()
            COM.Dispose()
            System.GC.Collect()

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try

    End Sub
    Public Sub ActualizarReferencia()
        Dim COM As MySqlCommand
        Dim strSQL As String
        Dim dblAbonoExt As Double = 0
        Dim dblAbonoLoc As Double = 0
        Try


            If cfun.DivisaLocal = celdaIDMoneda.Text Then
                dblAbonoLoc = celdaAbono.Text
                dblAbonoExt = (celdaAbono.Text) / cFunciones.QueryTasa("CURDATE()")
            Else
                dblAbonoLoc = celdaAbono.Text * celdaTasa.Text
                dblAbonoExt = celdaAbono.Text
            End If

            strSQL = " UPDATE  ECtaCte  e  SET ECta_Abno_Loc = {total}, ECta_Abno_Ext = {totalext} "
            strSQL &= "     WHERE e.ECta_Sis_Emp = {empresa} AND e.ECta_Doc_Cat = 39  and e.ECta_Doc_Ano = {anio} and e.ECta_Doc_Num = {numero} "
            If Sesion.IdEmpresa = 18 Then
                strSQL &= "; UPDATE  PDM.ECtaCte  e  SET ECta_Abno_Loc = {total}, ECta_Abno_Ext = {totalext} "
                strSQL &= "     WHERE e.ECta_Sis_Emp = {empresa} AND e.ECta_Doc_Cat = 39  and e.ECta_Doc_Ano = {anio} and e.ECta_Doc_Num = {numero} "
            End If
            strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
            strSQL = Replace(strSQL, "{anio}", celdaAnio.Text)
            strSQL = Replace(strSQL, "{numero}", celdaNumero.Text)
            strSQL = Replace(strSQL, "{total}", dblAbonoLoc)
            strSQL = Replace(strSQL, "{totalext}", dblAbonoExt)
            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSQL, CON)
            COM.ExecuteNonQuery()
            COM.Dispose()
            System.GC.Collect()

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try

    End Sub



    'Guardar
    Private Function ComprobarCampos() As Boolean
        Dim Comprobar As Boolean = False
        If dgFacturas.Rows.Count > 1 Then
            MsgBox("You must Select only one Invoice", vbInformation, "Notice")
            Exit Function
        Else
            Comprobar = True
        End If

        If celdaConcepto.Text = STR_VACIO Then
            MsgBox("Enter the concept of the document", vbInformation, "Notice")
            Exit Function
        Else
            Comprobar = True
        End If
        If celdaAbono.Text = STR_VACIO Then
            MsgBox("Enter the Amount", vbInformation, "Notice")
            Exit Function
        Else
            Comprobar = True
        End If

        If celdaSerie.Text = STR_VACIO Then
            MsgBox("Enter the Sequence", vbInformation, "Notice")
            Exit Function
        Else
            Comprobar = True
        End If

        Return Comprobar
    End Function
    Private Function ComprobarFila() As Boolean
        Dim Comprobar As Boolean = False
        Try
            If DgDetalle.Rows.Count = 0 Then
                MsgBox("Fill all fields", MsgBoxStyle.Critical)
                Comprobar = False
            Else
                Comprobar = True
            End If


            For i As Integer = 0 To DgDetalle.Rows.Count - 1
                If DgDetalle.Rows(i).Visible = True Then
                    If DgDetalle.Rows(i).Cells("colPrecio").Value = STR_VACIO Then
                        Comprobar = False
                        MsgBox("Blank Price")
                    End If
                    If DgDetalle.Rows(i).Cells("colCuenta").Value = STR_VACIO Then
                        MsgBox("Blank Account")
                        Comprobar = False
                    End If

                    'If DgDetalle.Rows(i).Cells("colNCosto").Value = STR_VACIO Then
                    '    MsgBox("Blank Cost Center")
                    '    Comprobar = False
                    'End If
                End If

            Next
            Return Comprobar
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        Return False
    End Function
    Private Sub GuardarHDR()
        Dim hdr As New clsDcmtos_HDR
        Dim intEmpresa As Integer
        Dim intMesInicio As Integer
        Dim strFechaInicio As String
        Dim strFechaFin As String
        Dim ArrayFechaInicio() As String
        Dim ArrayFechaFin() As String
        Dim intMesFin As Integer
        Dim intMesValido As Integer


        strFechaInicio = dgFacturas.CurrentRow.Cells("colFechaF").Value
        ArrayFechaInicio = strFechaInicio.Split("-".ToCharArray)

        intMesFin = ArrayFechaInicio(INT_UNO)



        strFechaFin = dtFechaDoc.Value.ToString(FORMATO_MYSQL)
        intMesInicio = Month(strFechaFin)

        ' strFechaFin = dtFechaDoc.Value
        ' ArrayFechaFin = strFechaFin.Split("-".ToCharArray)

        '        intMesFin = ArrayFechaFin(INT_UNO)


        intMesValido = intMesInicio - intMesFin


        hdr.HDOC_SIS_EMP = Sesion.IdEmpresa
        hdr.HDOC_DOC_CAT = 39
        hdr.HDOC_DOC_ANO = celdaAnio.Text
        hdr.HDOC_DOC_NUM = celdaNumero.Text
        hdr.HDOC_USUARIO = celdaUsuario.Text
        hdr.HDOC_EMP_COD = celdaIdProveedor.Text
        hdr.HDOC_EMP_NOM = STR_VACIO
        hdr.HDOC_DOC_MON = celdaIDMoneda.Text
        hdr.HDOC_DOC_TC = celdaTasa.Text
        hdr.HDoc_Doc_Fec_NET = dtFechaDoc.Value.ToString(FORMATO_MYSQL)
        hdr.HDOC_DR1_NUM = celdaReferencia.Text
        hdr.HDOC_DR2_NUM = celdaSerie.Text
        hdr.HDOC_RF1_TXT = celdaSerie2.Text
        hdr.HDOC_RF1_COD = celdaConcepto.Text
        hdr.HDOC_RF2_COD = celdaCorrelativo.Text

        If dgFacturas.CurrentRow.Cells("colDocumento").Value = -1 Then ' Importacion

        ElseIf dgFacturas.CurrentRow.Cells("colDocumento").Value = 2 Then ' Pequeño Contribuñente

        ElseIf intMesValido <= 2 Then '  No Extemporanea 
            hdr.HDOC_DR2_CAT = 0
        ElseIf intMesValido > 2 Then
            hdr.HDOC_DR2_CAT = 1
        End If

        intEmpresa = SQLEmpresa()

        If Sesion.IdEmpresa = 12 And intEmpresa = 0 And Sesion.IdEmpresa = 18 Or (Sesion.IdEmpresa = 15) Or (Sesion.IdEmpresa = 19) Then
            hdr.HDOC_RF1_DBL = 0
        ElseIf Sesion.IdEmpresa = 12 And intEmpresa = 310 Or (Sesion.IdEmpresa = 16) Then
            hdr.HDOC_RF1_DBL = SQLNumero(celdaAnio.Text)
        ElseIf Sesion.IdEmpresa = 11 And intEmpresa = 1 Then
            hdr.HDOC_RF1_DBL = 0
        ElseIf Sesion.IdEmpresa = 14 And intEmpresa = 327 Then
            hdr.HDOC_RF1_DBL = SQLNumero(celdaAnio.Text)
        End If



        hdr.HDOC_RF2_DBL = celdaAbono.Text
        hdr.HDOC_DOC_STATUS = IIf(checkActivo.Checked = True, 1, 0)

        hdr.CONEXION = strConexion

        If Me.Tag = "Mod" Then
            If hdr.Actualizar() = False Then
                MsgBox(hdr.MERROR.ToString & "Could not update the document", MsgBoxStyle.Critical)
            End If
        Else
            If hdr.Guardar() = False Then
                MsgBox(hdr.MERROR.ToString & "Could not save the document", MsgBoxStyle.Critical)
            End If
        End If

    End Sub
    Private Sub GuardarCC()
        Dim cc As New Tablas.TECTACTE
        Dim dblAbonoExt As Double = 0
        Dim dblAbonoLoc As Double = 0

        If cfun.DivisaLocal = celdaIDMoneda.Text Then
            dblAbonoLoc = celdaAbono.Text
            dblAbonoExt = (celdaAbono.Text) / cFunciones.QueryTasa("CURDATE()")
        Else
            dblAbonoLoc = celdaAbono.Text * celdaTasa.Text
            dblAbonoExt = celdaAbono.Text
        End If

        For i As Integer = 0 To dgFacturas.Rows.Count - 1
            cc.ECTA_SIS_EMP = Sesion.IdEmpresa
            cc.ECTA_DOC_CAT = 39
            cc.ECTA_DOC_ANO = celdaAnio.Text
            cc.ECTA_DOC_NUM = celdaNumero.Text
            cc.ECTA_DOC_LIN = 1
            cc.ECTA_TIPOEMP = "Proveedores"

            cc.ECTA_CODEMP = celdaIdProveedor.Text
            cc.ECTA_SINI_LOC = INT_CERO
            cc.ECTA_CRGO_LOC = INT_CERO
            cc.ECTA_CRGO_EXT = INT_CERO
            ' cc.ECTA_ABNO_LOC = dblAbonoLoc
            cc.ECTA_ABNO_LOC = dblAbonoLoc
            cc.ECTA_ABNO_EXT = dblAbonoExt
            cc.ECTA_CONCEPTO = celdaConcepto.Text
            cc.ECta_FecDcmt_NET = dtFechaDoc.Value.ToString(FORMATO_MYSQL)
            cc.ECta_FecVenc_NET = dgFacturas.Rows(i).Cells("colFechaVence").Value
            cc.ECTA_MONEDA = celdaIDMoneda.Text
            cc.ECTA_TC = celdaTasa.Text
            cc.ECTA_REF_CAT = 44
            cc.ECTA_REF_ANO = dgFacturas.Rows(i).Cells("colAnioF").Value
            cc.ECTA_REF_NUM = dgFacturas.Rows(i).Cells("colNumeroF").Value

            cc.CONEXION = strConexion

            If Me.Tag = "Mod" Then
                ActualizarReferencia()
                If cc.PUPDATE() = False Then


                    MsgBox(cc.MERROR.ToString & "Could not update the document", MsgBoxStyle.Critical)
                End If
            Else
                If cc.PINSERT() = False Then
                    MsgBox(cc.MERROR.ToString & "Could not save the document", MsgBoxStyle.Critical)
                End If
            End If

            If checkActivo.Checked = False Then
                QuitarReferencia()
            End If


        Next

    End Sub
    Private Sub GuardarImpuesto()
        Dim IMP As New Tablas.TDCMTOS_IMP
        Dim intMesInicio As Integer
        Dim strFechaInicio As String
        Dim strFechaFin As String
        Dim ArrayFechaInicio() As String
        Dim ArrayFechaFin() As String
        Dim intMesFin As Integer
        Dim intMesValido As Integer
        Try


            For i As Integer = 0 To DgImpuesto.Rows.Count - 1

                IMP.CONEXION = strConexion
                IMP.MDOC_SIS_EMP = Sesion.IdEmpresa
                IMP.MDOC_DOC_CAT = 39
                IMP.MDOC_DOC_ANO = celdaAnio.Text
                IMP.MDOC_DOC_NUM = celdaNumero.Text
                IMP.MDOC_DOC_LIN = INT_UNO
                IMP.MDOC_LIN_ID = INT_CERO
                IMP.MDOC_LIN_CODIGO = "IVA"
                IMP.MDOC_LIN_TIPO = INT_CERO
                IMP.MDOC_LIN_DESC = "IVA"

                strFechaInicio = dgFacturas.CurrentRow.Cells("colFechaF").Value
                ArrayFechaInicio = strFechaInicio.Split("-".ToCharArray)

                intMesInicio = ArrayFechaInicio(INT_UNO)


                strFechaFin = dtFechaDoc.Value.ToString(FORMATO_MYSQL)
                intMesFin = Month(strFechaFin)
                ' strFechaFin = dtFechaDoc.Value
                ' ArrayFechaFin = strFechaFin.Split("-".ToCharArray)

                '  intMesFin = ArrayFechaFin(INT_UNO)

                intMesValido = intMesInicio - intMesFin


                If dgFacturas.CurrentRow.Cells("colDocumento").Value = -1 Then ' Importacion
                    IMP.MDOC_LIN_BASE = DgImpuesto.Rows(i).Cells("colMonto").Value
                    IMP.MDOC_LIN_CANTIDAD = INT_CERO
                    IMP.MDOC_LIN_FACTOR = 0
                    IMP.MDOC_LIN_MONTO = INT_CERO



                ElseIf dgFacturas.CurrentRow.Cells("colDocumento").Value = 2 Then ' Pequeño Contribuñente
                    IMP.MDOC_LIN_BASE = DgImpuesto.Rows(i).Cells("colMonto").Value
                    IMP.MDOC_LIN_CANTIDAD = INT_CERO
                    IMP.MDOC_LIN_FACTOR = 0
                    IMP.MDOC_LIN_MONTO = INT_CERO

                ElseIf dgFacturas.CurrentRow.Cells("colExenta").Value = 1 Then '  No Extemporanea 
                    IMP.MDOC_LIN_BASE = DgImpuesto.Rows(i).Cells("colMonto").Value
                    IMP.MDOC_LIN_CANTIDAD = INT_CERO
                    IMP.MDOC_LIN_FACTOR = 0
                    IMP.MDOC_LIN_MONTO = DgImpuesto.Rows(i).Cells("colImpuesto").Value

                ElseIf dgFacturas.CurrentRow.Cells("colExenta").Value = 0 Then ' Extemporanea 

                    If intMesValido <= 2 Then
                        IMP.MDOC_LIN_BASE = DgImpuesto.Rows(i).Cells("colMonto").Value
                        IMP.MDOC_LIN_CANTIDAD = INT_CERO
                        IMP.MDOC_LIN_FACTOR = 12
                        IMP.MDOC_LIN_MONTO = DgImpuesto.Rows(i).Cells("colImpuesto").Value

                    ElseIf intMesValido = 3 Then
                        IMP.MDOC_LIN_BASE = DgImpuesto.Rows(i).Cells("colMonto").Value
                        IMP.MDOC_LIN_CANTIDAD = INT_CERO
                        IMP.MDOC_LIN_FACTOR = 0
                        IMP.MDOC_LIN_MONTO = DgImpuesto.Rows(i).Cells("colImpuesto").Value

                    End If
                End If

                If Me.Tag = "Mod" Then
                    If IMP.PUPDATE = False Then
                        MsgBox(IMP.MERROR.ToString & "Could not update the document", MsgBoxStyle.Critical)
                    End If
                Else
                    If IMP.PINSERT = False Then
                        MsgBox(IMP.MERROR.ToString & "Could not update the document", MsgBoxStyle.Critical)
                    End If
                End If


            Next



        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub
    Private Sub GuardarDetalle()
        Dim DTL As New clsDcmtos_DTL
        Try
            For i As Integer = 0 To DgDetalle.Rows.Count - 1


                DTL.DDOC_SIS_EMP = Sesion.IdEmpresa
                DTL.DDOC_DOC_ANO = celdaAnio.Text
                DTL.DDOC_DOC_CAT = 39
                DTL.DDOC_PRD_NET = DgDetalle.Rows(i).Cells("colPrecio").Value
                DTL.DDOC_RF1_COD = DgDetalle.Rows(i).Cells("colCuenta").Value
                DTL.DDOC_RF3_NUM = DgDetalle.Rows(i).Cells("colNCosto").Value

                If DgDetalle.Rows(i).Cells("colStatus").Value = 0 Then
                    DTL.DDOC_DOC_LIN = NuevaLinea(celdaNumero.Text)
                    DTL.DDOC_DOC_NUM = celdaNumero.Text

                    If DTL.Guardar = False Then
                        MsgBox(DTL.MERROR.ToString & "Could not save the document", MsgBoxStyle.Critical)
                    End If
                End If
                If DgDetalle.Rows(i).Cells("colStatus").Value = 1 Then
                    DTL.DDOC_DOC_LIN = DgDetalle.Rows(i).Cells("colLinea").Value
                    DTL.DDOC_DOC_NUM = celdaNumero.Text
                    If DTL.Actualizar = False Then
                        MsgBox(DTL.MERROR.ToString & "Could not update the document", MsgBoxStyle.Critical)
                    End If
                End If
                If DgDetalle.Rows(i).Cells("colStatus").Value = 2 Then
                    DTL.DDOC_DOC_LIN = DgDetalle.Rows(i).Cells("colLinea").Value
                    DTL.DDOC_DOC_NUM = celdaNumero.Text
                    If Me.Tag = "Mod" Then
                        If DTL.Borrar = False Then
                            MsgBox(DTL.MERROR.ToString & "Could not delete the document", MsgBoxStyle.Critical)
                        End If
                    End If
                End If

            Next

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub
    Public Sub CalcularIVA()

        Dim dblIva As Double
        Dim dblIva2 As Double
        Dim dblBase As Double
        Dim intMesInicio As Integer
        Dim strFechaInicio As String
        Dim strFechaFin As String
        Dim ArrayFechaInicio() As String
        Dim ArrayFechaFin() As String
        Dim intMesFin As Integer
        Dim intMesValido As Integer
        Dim strFila As String = STR_VACIO
        strFechaInicio = dgFacturas.CurrentRow.Cells("colFechaF").Value
        ArrayFechaInicio = strFechaInicio.Split("-".ToCharArray)

        intMesFin = ArrayFechaInicio(INT_UNO)


        strFechaFin = dtFechaDoc.Value.ToString(FORMATO_MYSQL)
        intMesInicio = Month(strFechaFin)
        'ArrayFechaFin = strFechaFin.Split("-".ToCharArray)

        ' intMesFin = ArrayFechaFin(INT_UNO)



        intMesValido = intMesInicio - intMesFin



        If celdaAbono.Text <> STR_VACIO Then
            If dgFacturas.CurrentRow.Cells("colDocumento").Value = -1 Then ' Importacion
                DgImpuesto.Rows.Clear()
                'dblBase = celdaAbono.Text
                dblIva = INT_CERO
                If Me.Tag = "Nuevo" Then
                    strFila = celdaAbono.Text & "|"
                    strFila &= dblIva & "|"
                    strFila &= celdaAbono.Text & "|"
                    strFila &= "0"
                Else
                    strFila = celdaAbono.Text & "|"
                    strFila &= dblIva & "|"
                    strFila &= celdaAbono.Text & "|"
                    strFila &= "1"
                End If
                cFunciones.AgregarFila(DgImpuesto, strFila)


            ElseIf dgFacturas.CurrentRow.Cells("colDocumento").Value = 2 Then ' Pequeño Contribuñente
                '   dblBase = celdaAbono.Text
                DgImpuesto.Rows.Clear()
                ' dblBase = celdaAbono.Text
                dblIva = INT_CERO
                If Me.Tag = "Nuevo" Then
                    strFila = celdaAbono.Text & "|"
                    strFila &= dblIva.ToString(FORMATO_MONEDA) & "|"
                    strFila &= (celdaAbono.Text + dblIva).ToString(FORMATO_MONEDA) & "|"
                    strFila &= "0"
                Else
                    strFila = celdaAbono.Text & "|"
                    strFila &= dblIva.ToString(FORMATO_MONEDA) & "|"
                    strFila &= (celdaAbono.Text + dblIva).ToString(FORMATO_MONEDA) & "|"
                    strFila &= "1"
                End If
                cFunciones.AgregarFila(DgImpuesto, strFila)

            ElseIf dgFacturas.CurrentRow.Cells("colExenta").Value = 1 Then '   Extemporanea 
                ' dblBase = celdaAbono.Text
                DgImpuesto.Rows.Clear()
                dblIva = INT_CERO


                dblIva = IVA()
                dblIva2 = IVA()

                dblIva = (100 + dblIva) / 100
                dblIva2 = dblIva2 / 100


                dblBase = celdaAbono.Text / dblIva
                dblIva = dblBase * dblIva2
                If Me.Tag = "Nuevo" Then
                    strFila = dblBase.ToString(FORMATO_MONEDA) & "|"
                    strFila &= dblIva.ToString(FORMATO_MONEDA) & "|"
                    strFila &= (dblBase + dblIva).ToString(FORMATO_MONEDA) & "|"
                    strFila &= "0"
                Else
                    strFila = dblBase.ToString(FORMATO_MONEDA) & "|"
                    strFila &= dblIva.ToString(FORMATO_MONEDA) & "|"
                    strFila &= (dblBase + dblIva).ToString(FORMATO_MONEDA) & "|"
                    strFila &= "1"
                End If
                cFunciones.AgregarFila(DgImpuesto, strFila)

            ElseIf dgFacturas.CurrentRow.Cells("colExenta").Value = 0 Then ' NO Extemporanea 

                If intMesValido <= 2 Then
                    DgImpuesto.Rows.Clear()
                    If celdaAbono.Text = STR_VACIO Then


                    ElseIf cFunciones.ValidarCampoNumerico(celdaAbono) Then

                        dblIva = IVA()
                        dblIva2 = IVA()

                        dblIva = (100 + dblIva) / 100
                        dblIva2 = dblIva2 / 100


                        dblBase = celdaAbono.Text / dblIva
                        dblIva = dblBase * dblIva2
                        If Me.Tag = "Nuevo" Then
                            strFila = dblBase.ToString(FORMATO_MONEDA) & "|"
                            strFila &= dblIva.ToString(FORMATO_MONEDA) & "|"
                            strFila &= (dblBase + dblIva).ToString(FORMATO_MONEDA) & "|"
                            strFila &= "0"
                        Else
                            strFila = dblBase.ToString(FORMATO_MONEDA) & "|"
                            strFila &= dblIva.ToString(FORMATO_MONEDA) & "|"
                            strFila &= (dblBase + dblIva).ToString(FORMATO_MONEDA) & "|"
                            strFila &= "1"
                        End If


                        cFunciones.AgregarFila(DgImpuesto, strFila)
                    End If
                ElseIf intMesValido >= 3 Then
                    DgImpuesto.Rows.Clear()
                    dblIva = IVA()
                    dblIva2 = IVA()

                    dblIva = (100 + dblIva) / 100
                    dblIva2 = dblIva2 / 100




                    dblBase = celdaAbono.Text / dblIva
                    dblIva = dblBase * dblIva2
                    If Me.Tag = "Nuevo" Then
                        strFila = dblBase.ToString(FORMATO_MONEDA) & "|"
                        strFila &= dblIva.ToString(FORMATO_MONEDA) & "|"
                        strFila &= (dblBase + dblIva).ToString(FORMATO_MONEDA) & "|"
                        strFila &= "0"
                    Else
                        strFila = dblBase.ToString(FORMATO_MONEDA) & "|"
                        strFila &= dblIva.ToString(FORMATO_MONEDA) & "|"
                        strFila &= (dblBase + dblIva).ToString(FORMATO_MONEDA) & "|"
                        strFila &= "1"
                    End If
                    cFunciones.AgregarFila(DgImpuesto, strFila)

                End If




            End If
        Else
            Exit Sub
        End If


    End Sub
    Public Sub ValidarSerie()
        Dim strSQL As String = STR_VACIO
        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader
        Dim strSerie As String = STR_VACIO
        Dim i As Integer = INT_CERO
        strSQL = "SELECT c.cat_sist "
        strSQL &= " FROM  Catalogos c "
        strSQL &= "     WHERE c.cat_clase='Serie' AND c.cat_clave = 'Doc_Nota/CR' AND c.cat_sisemp = {empresa} "
        strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
        MyCnn.CONECTAR = strConexion
        COM = New MySqlCommand(strSQL, CON)
        REA = COM.ExecuteReader
        If REA.HasRows Then
            Do While REA.Read
                If i > 1 Then
                    celdaSerie.Text = STR_VACIO
                End If

                celdaSerie.Text = REA.GetString("cat_sist")
                i = i + 1

            Loop
        End If


    End Sub

    Private Sub BorrarEncabezado(ByVal num As Integer, ByVal anio As Integer)
        Try
            Dim hdr As New clsDcmtos_HDR
            hdr.CONEXION = strConexion
            hdr.HDOC_SIS_EMP = Sesion.IdEmpresa
            hdr.HDOC_DOC_CAT = CATALOGO
            hdr.HDOC_DOC_ANO = anio
            hdr.HDOC_DOC_NUM = num
            hdr.Borrar()
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub
    Private Sub BorrarDetalle(ByVal num As Integer, ByVal anio As Integer)
        Dim strSQL As String = STR_VACIO
        Try
            strSQL = "DDoc_Sis_Emp = {empresa}  AND DDoc_Doc_Cat = {cata} AND DDoc_Doc_Ano = {anio} AND DDoc_Doc_Num = {numero} "
            strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
            strSQL = Replace(strSQL, "{cata}", CATALOGO)
            strSQL = Replace(strSQL, "{anio}", anio)
            strSQL = Replace(strSQL, "{numero}", num)
            Dim dtl As New clsDcmtos_DTL
            dtl.CONEXION = strConexion
            dtl.Borrar(strSQL)

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub
    Private Sub BorrarEctate(ByVal num As Integer, ByVal anio As Integer)
        Dim strSQL As String = STR_VACIO

        Try
            strSQL = "ECta_Sis_Emp = {empresa} AND ECta_Doc_Cat = {cata} AND ECta_Doc_Ano = {anio} AND ECta_Doc_Num = {numero} "
            strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
            strSQL = Replace(strSQL, "{cata}", CATALOGO)
            strSQL = Replace(strSQL, "{anio}", anio)
            strSQL = Replace(strSQL, "{numero}", num)
            Dim ectacte As New Tablas.TECTACTE
            ectacte.CONEXION = strConexion
            ectacte.PDELETE(strSQL)

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub
    Private Sub BorrarImp(ByVal num As Integer, ByVal anio As Integer)
        Dim strSQL As String = STR_VACIO
        Try
            strSQL = "MDoc_Sis_Emp = {empresa} AND MDoc_Doc_Cat = {cata} AND MDoc_Doc_Ano = {anio} AND MDoc_Doc_Num = {numero} "
            strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
            strSQL = Replace(strSQL, "{cata}", CATALOGO)
            strSQL = Replace(strSQL, "{anio}", anio)
            strSQL = Replace(strSQL, "{numero}", num)
            Dim imp As New Tablas.TDCMTOS_IMP
            imp.CONEXION = strConexion
            imp.PDELETE(strSQL)

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub



#End Region
#Region "Eventos"
    Private Sub Encabezado1_ClickNuevo(sender As Object, click As Boolean) Handles Encabezado1.ClickNuevo

        Me.Tag = "Nuevo"
        celdaTasa.Text = INT_UNO
        If logInsertar = True Then
            If dtFechaDoc.Format = DateTimePickerFormat.Custom Then
            Else
                dtFechaDoc.Value = Now.ToString(FORMATO_MYSQL)
            End If

            ValidarSerie()
            LimpiarCampos()
            MostrarLista(False, True)
        Else
            MsgBox("You do not have the permissions to perform this action", vbInformation, "Notice")
        End If
    End Sub

    Private Sub Encabezado1_ClickCerrar(sender As Object, click As Boolean) Handles Encabezado1.ClickCerrar

        If panelDocumento.Visible = True Then
            MostrarLista()
        Else
            Me.Close()
            Fprincipal.BarraDeTareas1.QuitarFormulario(strKey)
        End If
    End Sub

    Private Sub botonActualizar_Click(sender As Object, e As EventArgs) Handles botonActualizar.Click
        ListaPrincipal()
    End Sub

    Private Sub dgLista_DoubleClick(sender As Object, e As EventArgs) Handles dgLista.DoubleClick
        Me.Tag = "Mod"
        Dim numero As Integer = dgLista.SelectedCells(1).Value
        Dim anio As Integer = dgLista.SelectedCells(0).Value
        LimpiarCampos()

        CargarDatos(anio, numero)
        CargarDetalle()
        CargarImpuesto(anio, numero)
        MostrarLista(False)

    End Sub

    Private Sub botonProveedor_Click(sender As Object, e As EventArgs) Handles botonProveedor.Click
        Dim strRemplazo As String = STR_VACIO
        Dim frm As New frmSeleccionar
        Dim strFila As String = STR_VACIO
        Dim CodProveedor As String = STR_VACIO


        strRemplazo = "p.pro_sisemp = {empresa}"
        strRemplazo = Replace(strRemplazo, "{empresa}", Sesion.IdEmpresa)


        Try


            frm.Titulo = "Providers"
            frm.Campos = "p.pro_codigo id, p.pro_proveedor Proveedor, p.pro_direccion Direccion,p.pro_telefono, p.pro_nit nit "
            frm.Tabla = "Proveedores p"
            frm.FiltroText = "Enter the provider To filter"
            frm.Filtro = "p.pro_proveedor"
            frm.Ordenamiento = "p.pro_proveedor, p.pro_status"
            frm.TipoOrdenamiento = ""
            frm.Condicion = strRemplazo

            frm.ShowDialog(Me)
            If frm.DialogResult = System.Windows.Forms.DialogResult.OK Then
                celdaIdProveedor.Text = frm.ListaClientes.SelectedCells(0).Value
                celdaProveedor.Text = frm.ListaClientes.SelectedCells(1).Value
                celdaDireccion.Text = frm.ListaClientes.SelectedCells(2).Value
                celdaTelefono.Text = frm.ListaClientes.SelectedCells(3).Value
                celdaNit.Text = frm.ListaClientes.SelectedCells(4).Value

                celdaAbono.Text = STR_VACIO

                CargarFacturas()

            End If

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try

    End Sub
    Private Sub botonMoneda_Click(sender As Object, e As EventArgs) Handles botonMoneda.Click
        Dim frm As New frmSeleccionar

        Try
            frm.Titulo = "Coin"
            frm.Campos = "c.cat_clave Moneda, c.cat_num ID, c.cat_sist"
            frm.Tabla = "Catalogos c"
            frm.FiltroText = " Enter the Coin To filter"
            frm.Filtro = " c.cat_clave "
            frm.Limite = 5
            frm.Ordenamiento = " c.cat_clave "
            frm.TipoOrdenamiento = ""
            frm.Condicion = "cat_clase='Monedas'"

            frm.ShowDialog(Me)

            If frm.DialogResult = System.Windows.Forms.DialogResult.OK Then
                celdaMoneda.Text = frm.LLave
                celdaIDMoneda.Text = frm.Dato
                If frm.Dato2 > 1 Then
                    celdaTasa.Text = cFunciones.TasaSegunFecha(dtFechaDoc.Text)
                Else
                    celdaTasa.Text = frm.Dato2
                End If
            End If

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub
    Private Sub dgFacturas_DoubleClick(sender As Object, e As EventArgs) Handles dgFacturas.DoubleClick
        Dim i As Integer = 0
        Dim strSQL As String = STR_VACIO
        Dim strCuenta As String = STR_VACIO
        Dim strNombreCuenta As String = STR_VACIO
        Dim COM As New MySqlCommand
        Dim REA As MySqlDataReader
        Dim strFila As String = STR_VACIO
        If Me.Tag = "Nuevo" Then
            For i = 0 To dgFacturas.Rows.Count - 1
                dgFacturas.CurrentRow.Cells(5).Value = 1
                If dgFacturas.Rows.Count = 1 Then
                    strFila = dgFacturas.Rows(i).Cells("colAnioF").Value & "|"
                    strFila &= dgFacturas.Rows(i).Cells("colNumeroF").Value & "|"
                    strFila &= dgFacturas.Rows(i).Cells("colFechaF").Value & "|"
                    strFila &= dgFacturas.Rows(i).Cells("colUsuarioF").Value & "|"
                    strFila &= dgFacturas.Rows(i).Cells("colReferenciaF").Value & "|"
                    strFila &= 1 & "|"
                    strFila &= dgFacturas.Rows(i).Cells("colFechaVence").Value & "|"
                    strFila &= dgFacturas.Rows(i).Cells("colDocumento").Value & "|"
                    strFila &= dgFacturas.Rows(i).Cells("colExenta").Value
                    celdaReferencia.Text = dgFacturas.Rows(i).Cells("colReferenciaF").Value
                ElseIf dgFacturas.Rows(i).Cells("colExtraF").Value = 1 Then

                    strFila = dgFacturas.Rows(i).Cells("colAnioF").Value & "|"
                    strFila &= dgFacturas.Rows(i).Cells("colNumeroF").Value & "|"
                    strFila &= dgFacturas.Rows(i).Cells("colFechaF").Value & "|"
                    strFila &= dgFacturas.Rows(i).Cells("colUsuarioF").Value & "|"
                    strFila &= dgFacturas.Rows(i).Cells("colReferenciaF").Value & "|"
                    strFila &= 1 & "|"
                    strFila &= dgFacturas.Rows(i).Cells("colFechaVence").Value & "|"
                    strFila &= dgFacturas.Rows(i).Cells("colDocumento").Value & "|"
                    strFila &= dgFacturas.Rows(i).Cells("colExenta").Value
                    celdaReferencia.Text = dgFacturas.Rows(i).Cells("colReferenciaF").Value
                End If

            Next
            dgFacturas.Rows.Clear()
            cfun.AgregarFila(dgFacturas, strFila)

            strSQL = " SELECT cc.id_cuenta Cuenta , cc.nombre Nombre   "
            strSQL &= "     from {base}.cuentas cc  "
            strSQL &= "         WHERE  cc.id_cuenta  = '0501012'  AND cc.ejercicio = 0  "
            strSQL = Replace(strSQL, "{base}", cFunciones.ContaEmpresa)
            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSQL, CON)
            REA = COM.ExecuteReader
            If REA.HasRows Then
                Do While REA.Read
                    strCuenta = REA.GetString("Cuenta")
                    strNombreCuenta = REA.GetString("Nombre")
                Loop
            End If
            CargarDetalleFact(dgFacturas.CurrentRow.Cells("colAnioF").Value, dgFacturas.CurrentRow.Cells("colNumeroF").Value, strCuenta, strNombreCuenta)
        End If

    End Sub
    Private Sub Encabezado1_ClickGuardar(sender As Object, click As Boolean) Handles Encabezado1.ClickGuardar
        Dim clsPoliza As New clsContabilidad
        Dim dtFechaConta As Date
        If Me.Tag = "Nuevo" Then
            ProcesoDeGuardadoDeDatos()

        Else
            dtFechaConta = cfun.SQLValidarFechaContable(39, celdaAnio.Text, celdaNumero.Text)

            If cfun.SQLVerificarCierre(39, celdaAnio.Text, celdaNumero.Text) = 0 Then
                ProcesoDeGuardadoDeDatos()
                clsPoliza.GenerarPoliza(39, celdaAnio.Text, celdaNumero.Text, dtFechaConta.ToString(FORMATO_MYSQL))
            Else
                'Si hay cierre solicita autorización para modificar
                MsgBox("You need authorization to modify this document", vbInformation, "Notice")
                If cfun.AutorizarCambios = True Then
                    'registra quien hace la autorización
                    cfun.EscribirRegistro("Dcmtos_HDR", clsFunciones.AccEnum.acConfirm, celdaIdProveedor.Text, 39, celdaAnio.Text, celdaNumero.Text, "Autorizó la modificación")
                    ProcesoDeGuardadoDeDatos()
                    clsPoliza.GenerarPoliza(39, celdaAnio.Text, celdaNumero.Text, dtFechaConta.ToString(FORMATO_MYSQL))
                End If

            End If

        End If

    End Sub

    Private Sub ProcesoDeGuardadoDeDatos()
        Dim clsPoliza As New clsContabilidad
        If logEditar = True Then
            If ComprobarCampos() = True Then
                If ComprobarFila() = True Then
                    If Me.Tag = "Nuevo" Then
                        celdaAnio.Text = cfun.AñoMySQL
                        If celdaNumero.Text <> STR_VACIO Then
                            If celdaNumero.Text = ValidarNumero(celdaAnio.Text) Then
                                MsgBox("the number " & celdaNumero.Text & " already exists add another number", vbInformation)
                                Exit Sub
                            End If
                        Else
                            celdaNumero.Text = CorrelativoNCProveedor(celdaAnio.Text)
                        End If
                    End If

                    GuardarHDR()
                    GuardarDetalle()
                    GuardarCC()
                    GuardarImpuesto()

                    If Me.Tag = "Nuevo" = True Then
                        cfun.EscribirRegistro("Dcmtos_HDR", clsFunciones.AccEnum.acAdd, -1, 39, Val(celdaAnio.Text), Val(celdaNumero.Text))
                        MsgBox("Data successfully saved", vbInformation, "Notice")
                        If cfun.SQLVerificarCierre(39, celdaAnio.Text, celdaNumero.Text) = 0 Then
                            clsPoliza.GenerarPoliza(39, celdaAnio.Text, celdaNumero.Text, dtFechaDoc.Value.ToString(FORMATO_MYSQL))
                        Else
                            clsPoliza.GenerarPoliza(39, celdaAnio.Text, celdaNumero.Text, cfun.HoyMySQL.ToString(FORMATO_MYSQL))
                        End If
                    Else
                        cfun.EscribirRegistro("Dcmtos_HDR", clsFunciones.AccEnum.acUpdate, -1, 39, Val(celdaAnio.Text), Val(celdaNumero.Text))
                        MsgBox("Correctly Updated Data", vbInformation, "Notice")
                    End If


                    MostrarLista()
                Else
                    Exit Sub
                End If

            Else
                Exit Sub
            End If
        Else
            MsgBox("You do not have the permissions to perform this action", vbInformation, "Notice")
        End If

    End Sub
    Private Sub celdaAbono_TextChanged(sender As Object, e As EventArgs) Handles celdaAbono.TextChanged
        If Me.Tag = "Nuevo" Then
            CalcularIVA()
        ElseIf Me.Tag = "Mod" Then

            If dgFacturas.Rows.Count = 0 Then
                Exit Sub
            Else
                CalcularIVA()
            End If
        End If


    End Sub
    Private Sub botonSerie_Click(sender As Object, e As EventArgs) Handles botonSerie.Click
        Dim frm As New frmSeleccionar

        Try
            frm.Titulo = "Sequence"
            frm.Campos = "cat_sist Sequence "
            frm.Tabla = "Catalogos c"
            frm.FiltroText = " Enter the Sequence To filter"
            frm.Filtro = " c.cat_sist "
            frm.Limite = 5
            frm.TipoOrdenamiento = ""
            frm.Condicion = "cat_clase='Serie' AND c.cat_clave = 'Doc_Nota/CR' AND c.cat_sisemp = " & Sesion.IdEmpresa
            frm.ShowDialog(Me)

            If frm.DialogResult = System.Windows.Forms.DialogResult.OK Then
                celdaSerie.Text = frm.LLave
            End If

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub
    Private Sub botonAgregar_Click(sender As Object, e As EventArgs) Handles botonAgregar.Click
        Dim Condicion As String = STR_VACIO
        Dim condicion1 As String = STR_VACIO
        Dim frm As New frmSeleccionar
        Dim strFila As String = STR_VACIO
        Try

            Condicion = "Empresa = {empresa}  "

            Condicion = Replace(Condicion, "{empresa}", Sesion.IdEmpresa)
            condicion1 = "{conta}"
            condicion1 = Replace(condicion1, "{conta}", cFunciones.ContaEmpresa)
            'Datospara mostrar en pantalla
            frm.Titulo = "Expenses"
            frm.FiltroText = "Enter the Name Expense To Filter "

            'Datos de Base para Llenar Grid
            frm.Campos = "id_cuenta, nombre"
            frm.Tabla = condicion1 & ".cuentas"
            frm.Condicion = Condicion
            frm.Limite =
        frm.Ordenamiento = "id_cuenta"
            frm.Filtro = " nombre"

            'Mostrar formulario
            frm.ShowDialog(Me)

            If frm.DialogResult = System.Windows.Forms.DialogResult.OK Then

                strFila = "0" & "|" ' Linea 
                strFila &= "" & "|" ' Monto 
                strFila &= frm.LLave & "|"  ' Cuenta
                strFila &= frm.Dato & "|" ' Nombre Cuenta 
                strFila &= "0" & "|" ' Costo
                strFila &= "" & "|" ' Centro de Costo
                strFila &= "0" ' Estado 
                cFunciones.AgregarFila(DgDetalle, strFila)
            End If

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub BotonEliminar_Click(sender As Object, e As EventArgs) Handles BotonEliminar.Click
        Try
            Dim Count As Integer
            If DgDetalle.SelectedRows Is Nothing Then Exit Sub
            If DgDetalle.Rows.Count > 1 Then
                Count = DgDetalle.Rows.GetRowCount(DataGridViewElementStates.Selected)
                For i As Integer = 0 To Count - 1
                    ' strTexto = "Remove " & CStr(dgCotizacion.SelectedCells(1).Value) & vbCrLf
                    If MsgBox("You sure you want to delete the row " & "OF THE ORDER " &
                     CInt(DgDetalle.SelectedCells(0).Value) & ", " & CStr(DgDetalle.SelectedCells(1).Value) & " " & CStr(DgDetalle.SelectedCells(2).Value) & " " & CStr(DgDetalle.SelectedCells(3).Value) & "?", vbQuestion + vbYesNo + vbDefaultButton2) = vbYes Then
                        If DgDetalle.SelectedCells(6).Value = 0 Or DgDetalle.SelectedCells(6).Value = 1 Then
                            DgDetalle.SelectedCells(6).Value = 2
                            If DgDetalle.SelectedCells(6).Value = 2 Then
                                DgDetalle.CurrentRow.Visible = False
                            End If
                        ElseIf DgDetalle.Rows(i).Selected = Nothing Then
                            '  dgDetalle.SelectedCells(6).Value = 3
                            ' dgDetalle.CurrentRow.Visible = False
                            DgDetalle.Rows.RemoveAt(DgDetalle.RowCount - 1)
                        End If
                    End If
                Next
            Else
            MsgBox("you can not delete the last row")
            Exit Sub
            End If
            DgDetalle.ReadOnly = False
            CalcularTotal()
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub DgDetalle_DoubleClick(sender As Object, e As EventArgs) Handles DgDetalle.DoubleClick
        Dim frm As New frmSeleccionar

        Select Case DgDetalle.CurrentCell.ColumnIndex
            Case 1



            Case 3
                DgDetalle.CurrentRow.Cells("colPrecio").ReadOnly = False
                Dim Condicion As String = STR_VACIO
                Dim condicion1 As String = STR_VACIO

                Condicion = "Empresa = {empresa}  "

                Condicion = Replace(Condicion, "{empresa}", Sesion.IdEmpresa)
                condicion1 = "{conta}"
                condicion1 = Replace(condicion1, "{conta}", cFunciones.ContaEmpresa)
                'Datospara mostrar en pantalla
                frm.Titulo = "Expenses"
                frm.FiltroText = "Enter the Name Expense To Filter "

                'Datos de Base para Llenar Grid
                frm.Campos = "id_cuenta, nombre"
                frm.Tabla = condicion1 & ".cuentas"
                frm.Condicion = Condicion
                frm.Limite =
                frm.Ordenamiento = "id_cuenta"
                frm.Filtro = " nombre"

                'Mostrar formulario
                frm.ShowDialog(Me)

                If frm.DialogResult = System.Windows.Forms.DialogResult.OK Then
                    DgDetalle.CurrentRow.Cells("colCuenta").Value = frm.LLave
                    DgDetalle.CurrentRow.Cells("colNombreCuenta").Value = frm.Dato
                End If

            Case 5
                Dim Condicion As String = STR_VACIO
                Dim condicion1 As String = STR_VACIO
                condicion1 = "{conta}"
                condicion1 = Replace(condicion1, "{conta}", cFunciones.ContaEmpresa)

                'Datospara mostrar en pantalla
                frm.Titulo = "Costes Center"
                frm.FiltroText = "Enter the Name Costes Center To Filter "

                'Datos de Base para Llenar Grid
                frm.Campos = "cost_num, cost_nombre"
                frm.Tabla = condicion1 & ".costos"
                frm.Condicion = "cost_num > 0"
                frm.Limite =
                        frm.Ordenamiento = "cost_num"
                frm.Filtro = "cost_nombre"

                'Mostrar formulario
                frm.ShowDialog(Me)

                If frm.DialogResult = System.Windows.Forms.DialogResult.OK Then
                    DgDetalle.CurrentRow.Cells("colNCosto").Value = frm.LLave
                    DgDetalle.CurrentRow.Cells("colCentroCosto").Value = frm.Dato
                End If

        End Select



    End Sub

    Private Sub DgDetalle_CellEndEdit(sender As Object, e As DataGridViewCellEventArgs) Handles DgDetalle.CellEndEdit

        '   If DgDetalle.CurrentRow.Cells("colPrecio").Value <> STR_VACIO Then
        CalcularTotal()
        '  End If

    End Sub



#End Region

    Private Sub botonPolizaC_Click(sender As Object, e As EventArgs) Handles botonPolizaC.Click
        Dim cls As New clsPolizaContable

        cls.Tipo = 39
        cls.Ciclo = celdaAnio.Text 
        cls.Numero = celdaNumero.Text
        cls.Modo = 26

        cls.MostrarPolizaContable()
    End Sub

    Private Sub Encabezado1_ClickBorrar(sender As Object, click As Boolean) Handles Encabezado1.ClickBorrar
        If LogBorrar = True Then
            If MsgBox("The document will be permanently deleted, do you want to continue?", vbQuestion + vbYesNo, "Question") = vbYes Then
                BorrarEncabezado(celdaNumero.Text, celdaAnio.Text)
                BorrarDetalle(celdaNumero.Text, celdaAnio.Text)
                BorrarEctate(celdaNumero.Text, celdaAnio.Text)
                BorrarImp(celdaNumero.Text, celdaAnio.Text)
                cfun.BorrarEncabezadoPoliza(celdaNumero.Text, celdaAnio.Text, 39)
                cfun.BorrarDetallePoliza(celdaNumero.Text, celdaAnio.Text, 39)
                cfun.EscribirRegistro("Dcmtos_HDR", clsFunciones.AccEnum.acDelete, -1, 39, Val(celdaAnio.Text), Val(celdaNumero.Text))
                MostrarLista()
            End If
        Else
            MsgBox("You do not have permission for this action", vbInformation, "Notice")
        End If
    End Sub

    Private Sub dtFechaDoc_ValueChanged(sender As Object, e As EventArgs) Handles dtFechaDoc.ValueChanged
        If celdaTasa.Text > 1 Then
            celdaTasa.Text = cFunciones.TasaSegunFecha(dtFechaDoc.Value.ToString(FORMATO_MYSQL))
        End If
    End Sub

    Private Sub dgLista_KeyDown(sender As Object, e As KeyEventArgs) Handles dgLista.KeyDown
        Try
            If e.KeyCode = Keys.F3 Then
                cfun.BuscarenLista(dgLista)
                e.Handled = True
                e.SuppressKeyPress = True
                'ElseIf e.KeyCode = Keys.F6 Then
                '    cfun.MostrarDependencias(36, dgLista.SelectedCells(0).Value, dgLista.SelectedCells(1).Value)
                'ElseIf e.KeyCode = Keys.F7 Then
                '    Dim rpt As New clsReportes
                '    rpt.Historial(dgLista.SelectedCells(1).Value, dgLista.SelectedCells(0).Value, 36)
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub
End Class