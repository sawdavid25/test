﻿Public Class frmConciliacionBancaria

#Region "Miembros"
    Dim strKey As String = STR_VACIO
    Dim logInsertar As Boolean = False
    Dim logConsultar As Boolean = False
    Dim logEditar As Boolean = False
    Dim LogBorrar As Boolean = False
    Dim dblBanco As Double
    Dim dblConta As Double
    Dim dblResiduo As Double
    Dim dblTotal As Double
    Dim intNumConciliacion As Integer = 0
    Dim intIDConciliacion As Integer = 0
    Dim intLinea As Integer = 0
    Dim CategoriaDoc As Integer
    Dim StatusDoc As Integer

    Dim dblParcial As Double = 0
    Dim dblTotalConta As Double = 0
    Dim strNombreDG As DataGridView
    Dim intGuardarConciliacion As Integer = NO_FILA

    Public dtaFechaInicio As Date
    Public dtaFechaFin As Date
    Public intBanco As Integer
    Public dblInicial As Double
    Public strClase As String

    'Id de los Documentos
    Private Const ID_CHEQUE = 51
    Private Const ID_DEBITO = 52
    Private Const ID_CREDITO = 53
    Private Const ID_DEPOSITO = 54

    'Estado Activo de los Documentos
    Private Const ACT_CHEQUE = vbEmpty
    Private Const ACT_DEBITO = vbEmpty
    Private Const ACT_CREDITO = 1
    Private Const ACT_DEPOSITO = 1

    Dim dblSumar As Double = vbEmpty
    Dim TotalLiquidacion As Double = vbEmpty
    'Opciones de Seleccion
    Private Const STR_SI = "x"

    'Identificador de Documento
    Private Const intCurDoc = 257

    'Polizas de conta excluidas
    Private Const POL_APERTURA = 3
    Private Const POL_CIERRE = 4

    Private Const CATALOGO = 257
#End Region

#Region "Propiedades"

    Public Property Key As String
        Get
            Return strKey
        End Get
        Set(value As String)
            strKey = value
        End Set
    End Property

    Public Property FechaInicio As Date
        Get
            Return dtaFechaInicio
        End Get
        Set(value As Date)
            dtaFechaInicio = value
        End Set
    End Property

    Public Property FechaFin As Date
        Get
            Return dtaFechaFin
        End Get
        Set(value As Date)
            dtaFechaFin = value
        End Set
    End Property

    Public Property Banco As Integer
        Get
            Return intBanco
        End Get
        Set(value As Integer)
            intBanco = value
        End Set
    End Property

    Public Property Inicial As Double
        Get
            Return dblInicial
        End Get
        Set(value As Double)
            dblInicial = value
        End Set
    End Property

    Public Property Clase As String
        Get
            Return strClase
        End Get
        Set(value As String)
            strClase = value
        End Set
    End Property

#End Region

#Region "Procedimiento"


    Private Sub CargarPendientes(ByVal LimpiarDg As Integer, ByRef Lista As DataGridView, ByRef Catalogos As Integer, ByVal Status As Integer, ByVal Inicio As Date, Optional ByVal Borrar As Boolean = False)
        Dim MesAnterior As Integer = INT_CERO
        Dim AñoAnterior As Integer = INT_CERO
        Dim strSQL As String = STR_VACIO
        Dim strFila As String = STR_VACIO
        Dim PrimerDia As Date
        Dim UltimoDia As Date
        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader

        MesAnterior = Month(Inicio)
        If MesAnterior = INT_UNO Then
            MesAnterior = 12
            AñoAnterior = Year(Inicio) - 1
        Else
            MesAnterior = MesAnterior - 1
            AñoAnterior = Year(Inicio)
        End If

        PrimerDia = DateSerial(AñoAnterior, MesAnterior + 0, 1)
        UltimoDia = DateSerial(AñoAnterior, MesAnterior + 1, 0)

        strSQL = " SELECT * "
        strSQL &= "     FROM Dcmtos_HDR"
        strSQL &= "          WHERE HDoc_Sis_Emp = {empresa} AND HDoc_Doc_Cat = {ID} AND HDoc_Doc_Fec < '{fecha}' AND HDoc_DR2_Fec IS NULL AND HDoc_RF1_Num = {banco} AND NOT HDoc_RF1_Dbl = {vacio} AND HDoc_Doc_Status = {status}"
        strSQL &= "       ORDER BY HDoc_Doc_Fec, HDoc_Doc_Num "

        strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
        strSQL = Replace(strSQL, "{ID}", Catalogos)
        strSQL = Replace(strSQL, "{fecha}", Inicio.ToString(FORMATO_MYSQL))
        strSQL = Replace(strSQL, "{status}", Status)
        strSQL = Replace(strSQL, "{vacio}", vbEmpty)
        strSQL = Replace(strSQL, "{banco}", Banco)


        MyCnn.CONECTAR = strConexion
        COM = New MySqlCommand(strSQL, CON)
        REA = COM.ExecuteReader

        If LimpiarDg = 1 Then
            Lista.Rows.Clear()
        End If

        If REA.HasRows Then

            Lista.Rows.Clear()

            Do While REA.Read

                strFila = " " & "|" & REA.GetString("HDoc_DR1_Num") & "|" & REA.GetDateTime("HDoc_Doc_Fec") & "|" & REA.GetDouble("HDoc_RF1_Dbl").ToString(FORMATO_MONEDA) & "|" & REA.GetInt32("HDoc_Doc_Num") & "|" & REA.GetInt32("HDoc_Doc_Ano")

                cFunciones.AgregarFila(Lista, strFila)
            Loop

        End If
    End Sub

    Private Sub CargarDocumentos(ByVal LimpiarDg As Integer, ByRef Lista As DataGridView, ByRef Catalogos As Integer, ByVal Status As Integer, ByVal Inicio As Date, ByVal Fin As Date, Optional ByVal Borrar As Boolean = False)
        Dim MesAnterior As Integer = INT_CERO
        Dim AñoAnterior As Integer = INT_CERO
        Dim strSQL As String = STR_VACIO
        Dim strFila As String = STR_VACIO
        Dim PrimerDia As Date
        Dim UltimoDia As Date
        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader

        MesAnterior = Month(Inicio)
        If MesAnterior = INT_UNO Then
            MesAnterior = 12
            AñoAnterior = Year(Inicio) - 1
        Else
            MesAnterior = MesAnterior - 1
            AñoAnterior = Year(Inicio)
        End If

        PrimerDia = DateSerial(AñoAnterior, MesAnterior + 0, 1)
        UltimoDia = DateSerial(AñoAnterior, MesAnterior + 1, 0)

        strSQL = " SELECT * "
        strSQL &= "     FROM Dcmtos_HDR"
        strSQL &= "          WHERE HDoc_Sis_Emp = {empresa} AND HDoc_Doc_Cat = {ID} AND HDoc_Doc_Fec BETWEEN '{fechaInicio}' AND '{fechaFin}' AND HDoc_DR2_Fec IS NULL AND HDoc_RF1_Num = {banco} AND NOT HDoc_RF1_Dbl = {vacio} AND HDoc_Doc_Status = {status}"
        strSQL &= "       ORDER BY HDoc_Doc_Fec, HDoc_Doc_Num "

        strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
        strSQL = Replace(strSQL, "{ID}", Catalogos)
        strSQL = Replace(strSQL, "{fechaInicio}", Inicio.ToString(FORMATO_MYSQL))
        strSQL = Replace(strSQL, "{fechaFin}", Fin.ToString(FORMATO_MYSQL))
        strSQL = Replace(strSQL, "{status}", Status)
        strSQL = Replace(strSQL, "{vacio}", vbEmpty)
        strSQL = Replace(strSQL, "{banco}", Banco)


        MyCnn.CONECTAR = strConexion
        COM = New MySqlCommand(strSQL, CON)
        REA = COM.ExecuteReader

        If LimpiarDg = 1 Then
            Lista.Rows.Clear()
        End If

        If REA.HasRows Then

            Lista.Rows.Clear()

            Do While REA.Read

                strFila = " " & "|" & REA.GetString("HDoc_DR1_Num") & "|" & REA.GetDateTime("HDoc_Doc_Fec") & "|" & REA.GetDouble("HDoc_RF1_Dbl").ToString(FORMATO_MONEDA) & "|" & REA.GetInt32("HDoc_Doc_Num") & "|" & REA.GetInt32("HDoc_Doc_Ano")

                cFunciones.AgregarFila(Lista, strFila)
            Loop

        End If
    End Sub

    Private Sub CargarActuales(ByVal LimpiarDg As Integer, ByRef Lista As DataGridView, ByRef Catalogos As Integer, ByVal Status As Integer, ByVal Inicio As Date, Optional ByVal Borrar As Boolean = False)
        Dim MesSiguiente As Integer = INT_CERO
        Dim AñoSiguiente As Integer = INT_CERO
        Dim strSQL As String = STR_VACIO
        Dim strFila As String = STR_VACIO
        Dim PrimerDia As Date
        Dim UltimoDia As Date
        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader

        MesSiguiente = Month(Inicio)
        If MesSiguiente = 12 Then
            MesSiguiente = INT_UNO
            AñoSiguiente = Year(Inicio)
        Else
            MesSiguiente = MesSiguiente + 1
            AñoSiguiente = Year(Inicio)
        End If

        PrimerDia = DateSerial(AñoSiguiente, MesSiguiente + 0, 1)
        UltimoDia = DateSerial(AñoSiguiente, MesSiguiente + 1, 0)

        strSQL = " SELECT * "
        strSQL &= "     FROM Dcmtos_HDR"
        strSQL &= "          WHERE HDoc_Sis_Emp = {empresa} AND HDoc_Doc_Cat = {ID} AND HDoc_Doc_Fec BETWEEN '{fechaInicio}' AND '{fechaFin}' AND HDoc_DR2_Fec IS NULL AND HDoc_RF1_Num = {banco} AND NOT HDoc_RF1_Dbl = {vacio} AND HDoc_Doc_Status = {status}"
        strSQL &= "       ORDER BY HDoc_Doc_Fec, HDoc_Doc_Num "

        strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
        strSQL = Replace(strSQL, "{ID}", Catalogos)
        strSQL = Replace(strSQL, "{fechaInicio}", PrimerDia.ToString(FORMATO_MYSQL))
        strSQL = Replace(strSQL, "{fechaFin}", UltimoDia.ToString(FORMATO_MYSQL))
        strSQL = Replace(strSQL, "{status}", Status)
        strSQL = Replace(strSQL, "{vacio}", vbEmpty)
        strSQL = Replace(strSQL, "{banco}", Banco)


        MyCnn.CONECTAR = strConexion
        COM = New MySqlCommand(strSQL, CON)
        REA = COM.ExecuteReader

        If LimpiarDg = 1 Then
            Lista.Rows.Clear()
        End If

        If REA.HasRows Then

            Lista.Rows.Clear()

            Do While REA.Read

                strFila = " " & "|" & REA.GetString("HDoc_DR1_Num") & "|" & REA.GetDateTime("HDoc_Doc_Fec") & "|" & REA.GetDouble("HDoc_RF1_Dbl").ToString(FORMATO_MONEDA) & "|" & REA.GetInt32("HDoc_Doc_Num") & "|" & REA.GetInt32("HDoc_Doc_Ano")

                cFunciones.AgregarFila(Lista, strFila)
            Loop

        End If
    End Sub

    Private Function CalculoCargarSeleccion(ByRef Lista As DataGridView, ByVal Catalogo As Integer)
        Dim i As Integer = vbEmpty
        dblSumar = vbEmpty
        For i = vbEmpty To Lista.RowCount - 1
            If Lista.Rows(i).Cells(0).Value = "x" Then
                dblSumar = dblSumar + Lista.Rows(i).Cells(3).Value
            End If
        Next

        If dblSumar < vbEmpty Then
            dblSumar = vbEmpty
        End If

        'Select Case Catalogo
        '    Case ID_CHEQUE, ID_DEBITO
        '        dblSumar = dblSumar * (-1)
        '    Case ID_DEPOSITO, ID_CREDITO
        '        dblSumar = dblSumar
        'End Select

        Return dblSumar
    End Function

    Private Sub CargarConciliacionAnterior()
        Dim strSQL As String = STR_VACIO
        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader

        strSQL = "SELECT IFNULL(h.HDoc_RF1_Dbl,0) Contabilidad, IFNULL(h.HDoc_RF2_Dbl,0) Banco"
        strSQL &= "  FROM Dcmtos_HDR h"
        strSQL &= "      WHERE h.HDoc_Sis_Emp = {empresa} AND h.HDoc_Doc_Cat = {categoria} AND h.HDoc_DR1_Cat = {banco}"
        strSQL &= "          ORDER BY h.HDoc_Doc_Ano DESC, h.HDoc_Doc_Num DESC"
        strSQL &= "      LIMIT 1 "

        strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
        strSQL = Replace(strSQL, "{categoria}", intCurDoc)
        strSQL = Replace(strSQL, "{banco}", intBanco)

        MyCnn.CONECTAR = strConexion
        COM = New MySqlCommand(strSQL, CON)
        REA = COM.ExecuteReader

        If REA.HasRows Then
            REA.Read()
            dblBanco = REA.GetDouble("Banco")
            dblConta = REA.GetDouble("Contabilidad")
        End If
        REA.Close()

        If dblBanco >= vbEmpty And dblConta < vbEmpty Then
            dblResiduo = dblBanco - (dblConta * -1)
        End If

        If dblConta >= vbEmpty And dblBanco < vbEmpty Then
            dblResiduo = dblConta - (dblBanco * -1)
        End If

        If dblBanco >= vbEmpty And dblConta >= vbEmpty Then
            dblResiduo = (dblBanco - dblConta)
        End If

        celdaSInicialBanco.Text = dblBanco.ToString(FORMATO_MONEDA)
        celdaSInicialConta.Text = dblConta.ToString(FORMATO_MONEDA)
        celdaDiferencia.Text = dblResiduo.ToString(FORMATO_MONEDA)
        celdaSubtotal4.Text = dblBanco.ToString(FORMATO_MONEDA)
        celdaSubtotal4.Text = Replace(celdaSubtotal4.Text, " ", "")
        etiquetaDatoDebit.Text = INT_CERO.ToString(FORMATO_MONEDA)
        etiquetaDatSaldo.Text = INT_CERO.ToString(FORMATO_MONEDA)
        etiquetaDatoCred.Text = celdaSubtotal4.Text

    End Sub

    Private Function SQLContabilidadAccountBalance(Optional Tipo As Integer = vbEmpty) As Double
        Dim strSQL As String = STR_VACIO
        Dim strSQL2 As String = STR_VACIO
        Dim strSQL3 As String = STR_VACIO
        Dim Cuenta As String = STR_VACIO
        Dim mon_banco As Integer
        Dim COM As MySqlCommand
        Dim conec As MySqlConnection
        Dim conec2 As MySqlConnection
        Dim conec3 As MySqlConnection
        Const criterio = "/ IFNULL(p.tasa,1)"

        'Obtiene la Cuenta Contable del Banco Actual
        strSQL = "SELECT BCta_Cuenta Cuenta"
        strSQL &= "  FROM CtasBcos"
        strSQL &= "      WHERE BCta_Sis_Emp = {empresa} AND BCta_Num = {banco}"

        strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
        strSQL = Replace(strSQL, "{banco}", intBanco)

        conec = New MySqlConnection(strConexion)
        conec.Open()
        COM = New MySqlCommand(strSQL, conec)
        Cuenta = COM.ExecuteScalar
        conec.Close()
        conec.Dispose()
        conec = Nothing
        System.GC.Collect()

        If IsDBNull(Cuenta) Or Cuenta = vbNullString Then
            MsgBox("The Bank does not have an Accounting account.", vbInformation, "Notice")
            Exit Function
        End If

        'Obtiene la Moneda del Banco Actual
        strSQL2 = "SELECT BCta_Mon Moneda"
        strSQL2 &= "     FROM CtasBcos"
        strSQL2 &= "         WHERE BCta_Sis_Emp = {empresa} AND BCta_Num = {banco}"

        strSQL2 = Replace(strSQL2, "{empresa}", Sesion.IdEmpresa)
        strSQL2 = Replace(strSQL2, "{banco}", intBanco)

        conec2 = New MySqlConnection(strConexion)
        conec2.Open()
        COM = New MySqlCommand(strSQL2, conec2)
        mon_banco = COM.ExecuteScalar
        conec2.Close()
        conec2.Dispose()
        conec2 = Nothing
        System.GC.Collect()

        Select Case Tipo
            Case vbEmpty
                strSQL3 = "SELECT ROUND(IFNULL(SUM(IF(d.operacion = 'C', (d.importe {criterio}), 0)) - SUM(IF(d.operacion = 'A', (d.importe {criterio}), 0)),0),3) Saldo"
            Case 1
                strSQL3 = "SELECT IFNULL(SUM(ROUND(IF(d.operacion = 'C', (d.importe {criterio}), 0),2)) - SUM(ROUND(IF(d.operacion = 'A', (d.importe {criterio}), 0),2)),0) Saldo "
        End Select
        strSQL3 &= "    FROM {conta}.polizas p"
        strSQL3 &= "         LEFT JOIN {conta}.detalle_polizas d ON d.empresa = p.empresa AND d.ejercicio = p.ejercicio AND d.poliza = p.poliza"
        strSQL3 &= "     WHERE p.empresa = {empresa} AND p.fecha <= '{fin}' AND d.cuenta = '{cuenta}' AND d.ref_tipo!=0 AND NOT (p.tipo = {apertura} OR p.tipo = {cierre}) "

        strSQL3 = Replace(strSQL3, "{empresa}", Sesion.IdEmpresa)
        strSQL3 = Replace(strSQL3, "{inicio}", FechaInicio.ToString(FORMATO_MYSQL))
        strSQL3 = Replace(strSQL3, "{fin}", FechaFin.ToString(FORMATO_MYSQL))
        strSQL3 = Replace(strSQL3, "{cuenta}", Cuenta)
        strSQL3 = Replace(strSQL3, "{conta}", cFunciones.ContaEmpresa)
        strSQL3 = Replace(strSQL3, "{criterio}", IIf(mon_banco = cFunciones.DivisaLocal, vbNullString, criterio))
        strSQL3 = Replace(strSQL3, "{apertura}", POL_APERTURA)
        strSQL3 = Replace(strSQL3, "{cierre}", POL_CIERRE)

        conec3 = New MySqlConnection(strConexion)
        conec3.Open()
        COM = New MySqlCommand(strSQL3, conec3)
        SQLContabilidadAccountBalance = COM.ExecuteScalar
        conec3.Close()
        conec3.Dispose()
        conec3 = Nothing
        System.GC.Collect()

    End Function

    Private Sub Monedas()
        Dim strSQL As String = STR_VACIO
        Dim COM As MySqlCommand
        Dim conec As MySqlConnection
        Dim Mon As String = STR_VACIO

        strSQL = " SELECT cat_clave"
        strSQL &= "      FROM CtasBcos"
        strSQL &= "          LEFT JOIN Catalogos ON cat_num = BCta_Mon"
        strSQL &= "      WHERE BCta_Sis_Emp = {empresa} AND BCta_Num = {banco}"

        strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
        strSQL = Replace(strSQL, "{banco}", intBanco)

        conec = New MySqlConnection(strConexion)
        conec.Open()
        COM = New MySqlCommand(strSQL, conec)
        Mon = COM.ExecuteScalar
        conec.Close()
        conec.Dispose()
        conec = Nothing
        System.GC.Collect()


        etiquetaMoneda.Text = Mon
        etiquetaMoneda2.Text = Mon
        etiquetaMoneda3.Text = Mon

    End Sub

    Public Sub TotalesNotasDeDebito()
        Dim SumarND As Double = 0
        Dim SumaTotal As Double = 0

        SumarND = CDbl(celdaLiquidarPendientes4.Text) + CDbl(celdaLiquidarDoc4.Text) + CDbl(celdaLiquidarActual4.Text)
        celdaSubTotal3.Text = (SumarND * -1).ToString(FORMATO_MONEDA)
        celdaSubTotal3.Text = Replace(celdaSubTotal3.Text, " ", "")
        SumaTotal = CDbl(celdaSubtotal4.Text) + CDbl(celdaSubtotal1.Text) + CDbl(celdaSubtotal2.Text) + CDbl(celdaSubTotal3.Text) + CDbl(celdaSubtotal0.Text)
        etiquetaDatoDebit.Text = CDbl(celdaSubtotal0.Text) + CDbl(celdaSubTotal3.Text)
        etiquetaDatoDebit.Text = (etiquetaDatoDebit.Text * (-1)).ToString(FORMATO_MONEDA)
        celdaTotal.Text = SumaTotal.ToString(FORMATO_MONEDA)
        celdaTotal.Text = Replace(celdaTotal.Text, " ", "")
        etiquetaDatSaldo.Text = celdaTotal.Text
    End Sub

    Public Sub TotalesNotasDeCredito()
        Dim SumarNC As Double = 0
        Dim SumaTotal As Double = 0

        SumarNC = CDbl(celdaLiquidarPendientes3.Text) + CDbl(celdaLiquidarDoc3.Text) + CDbl(celdaLiquidarActual3.Text)
        celdaSubtotal2.Text = (SumarNC).ToString(FORMATO_MONEDA)
        celdaSubtotal2.Text = Replace(celdaSubtotal2.Text, " ", "")
        SumaTotal = CDbl(celdaSubtotal4.Text) + CDbl(celdaSubtotal1.Text) + CDbl(celdaSubtotal2.Text) + CDbl(celdaSubTotal3.Text) + CDbl(celdaSubtotal0.Text)
        etiquetaDatoCred.Text = (CDbl(celdaSubtotal4.Text) + CDbl(celdaSubtotal1.Text) + CDbl(celdaSubtotal2.Text)).ToString(FORMATO_MONEDA)
        celdaTotal.Text = SumaTotal.ToString(FORMATO_MONEDA)
        celdaTotal.Text = Replace(celdaTotal.Text, " ", "")
        etiquetaDatSaldo.Text = celdaTotal.Text
    End Sub

    Public Sub TotalesDepositos()
        Dim SumarDepositos As Double = 0
        Dim SumaTotal As Double = 0

        SumarDepositos = CDbl(celdaLiquidarPendientes2.Text) + CDbl(celdaLiquidarDoc2.Text) + CDbl(celdaLiquidarActual2.Text)
        celdaSubtotal1.Text = (SumarDepositos).ToString(FORMATO_MONEDA)
        celdaSubtotal1.Text = Replace(celdaSubtotal1.Text, " ", "")
        SumaTotal = CDbl(celdaSubtotal4.Text) + CDbl(celdaSubtotal1.Text) + CDbl(celdaSubtotal2.Text) + CDbl(celdaSubTotal3.Text) + CDbl(celdaSubtotal0.Text)
        etiquetaDatoCred.Text = (CDbl(celdaSubtotal4.Text) + CDbl(celdaSubtotal1.Text) + CDbl(celdaSubtotal2.Text)).ToString(FORMATO_MONEDA)
        celdaTotal.Text = SumaTotal.ToString(FORMATO_MONEDA)
        celdaTotal.Text = Replace(celdaTotal.Text, " ", "")
        etiquetaDatSaldo.Text = celdaTotal.Text
    End Sub

    Public Sub TotaleCheques()
        Dim SumarCheques As Double = 0
        Dim SumaTotal As Double = 0

        SumarCheques = CDbl(celdaLiquidarPendientes.Text) + CDbl(celdaLiquidarDoc.Text) + CDbl(celdaLiquidarActual.Text)
        celdaSubtotal0.Text = (SumarCheques * -1).ToString(FORMATO_MONEDA)
        celdaSubtotal0.Text = Replace(celdaSubtotal0.Text, " ", "")
        SumaTotal = CDbl(celdaSubtotal4.Text) + CDbl(celdaSubtotal1.Text) + CDbl(celdaSubtotal2.Text) + CDbl(celdaSubTotal3.Text) + CDbl(celdaSubtotal0.Text)
        etiquetaDatoDebit.Text = CDbl(celdaSubtotal0.Text) + CDbl(celdaSubTotal3.Text)
        etiquetaDatoDebit.Text = (etiquetaDatoDebit.Text * (-1)).ToString(FORMATO_MONEDA)
        celdaTotal.Text = SumaTotal.ToString(FORMATO_MONEDA)
        celdaTotal.Text = Replace(celdaTotal.Text, " ", "")
        etiquetaDatSaldo.Text = celdaTotal.Text
    End Sub

    Private Function ExisteConciliacion() As Boolean
        Dim strSQL As String = STR_VACIO
        Dim COM As MySqlCommand
        Dim intExiste As Integer

        strSQL = " SELECT COUNT(HDoc_Doc_Num) FROM Dcmtos_HDR "
        strSQL &= "    WHERE HDoc_Sis_Emp = {emp} And HDoc_Doc_Cat = 257 And HDoc_Doc_Ano = {anio} And HDoc_DR1_Cat = {banco} And HDoc_DR2_Cat = {mes} "

        strSQL = Replace(strSQL, "{emp}", Sesion.IdEmpresa)
        strSQL = Replace(strSQL, "{anio}", Year(FechaInicio))
        strSQL = Replace(strSQL, "{banco}", intBanco)
        strSQL = Replace(strSQL, "{mes}", Month(FechaInicio))

        MyCnn.CONECTAR = strConexion
        COM = New MySqlCommand(strSQL, CON)
        intExiste = COM.ExecuteScalar()

        If intExiste = 0 Then
            ExisteConciliacion = False
        Else
            ExisteConciliacion = True
        End If

    End Function

    Public Sub GuardarEncabezado()
        Dim hdr As New clsDcmtos_HDR

        hdr.HDOC_SIS_EMP = Sesion.IdEmpresa
        hdr.HDOC_DOC_CAT = 257
        hdr.HDOC_DOC_ANO = Year(FechaInicio)
        hdr.HDOC_DOC_NUM = intNumConciliacion
        hdr.HDoc_Doc_Fec_NET = cFunciones.HoyMySQL.ToString(FORMATO_MYSQL)
        hdr.HDoc_DR1_Fec_NET = FechaInicio.ToString(FORMATO_MYSQL)
        hdr.HDOC_DR1_NUM = INT_UNO
        hdr.HDoc_DR2_Fec_NET = FechaFin.ToString(FORMATO_MYSQL)
        hdr.HDOC_DR1_CAT = intBanco
        hdr.HDOC_DR2_CAT = Month(FechaInicio)
        hdr.HDOC_RF1_DBL = celdaSaldoFinalConta.Text 'Saldo Contabilidad
        hdr.HDOC_RF2_DBL = celdaSaldoFinalBank.Text ' Saldo Banco
        hdr.HDOC_USUARIO = Sesion.Usuario

        MyCnn.CONECTAR = strConexion
        If hdr.Guardar() = False Then
            MsgBox(hdr.MERROR.ToString & "Could not save the document", MsgBoxStyle.Critical)
        End If

    End Sub

    Public Sub GuardarDetalle(ByVal cat As Integer, ByVal anio As Integer, ByVal numero As Integer, ByVal linea As Integer, ByVal estadoDoc As Integer)
        Dim dtl As New clsDcmtos_DTL

        Dim strSQL As String = STR_VACIO
        Dim COM As MySqlCommand
        Dim dbl_RF1Dbl As Double = 0

        Try

            strSQL = " SELECT HDoc_RF1_Dbl FROM Dcmtos_HDR WHERE HDoc_Sis_Emp = {emp} AND HDoc_Doc_Cat = {cat} AND HDoc_Doc_Ano = {anio} AND HDoc_Doc_Num = {num} "
        strSQL = Replace(strSQL, "{emp}", Sesion.IdEmpresa)
        strSQL = Replace(strSQL, "{cat}", cat)
        strSQL = Replace(strSQL, "{anio}", anio)
        strSQL = Replace(strSQL, "{num}", numero)

        MyCnn.CONECTAR = strConexion
        COM = New MySqlCommand(strSQL, CON)
        dbl_RF1Dbl = COM.ExecuteScalar

        dtl.DDOC_SIS_EMP = Sesion.IdEmpresa
        dtl.DDOC_DOC_CAT = 257
        dtl.DDOC_DOC_ANO = Year(FechaInicio)
        dtl.DDOC_DOC_NUM = intNumConciliacion
        dtl.DDOC_DOC_LIN = linea
        dtl.DDOC_RF1_NUM = cat
        dtl.DDOC_RF1_DBL = dbl_RF1Dbl
        dtl.DDOC_RF2_NUM = anio
        dtl.DDOC_RF2_DBL = estadoDoc
        dtl.DDOC_RF3_NUM = numero

        MyCnn.CONECTAR = strConexion
        If dtl.Guardar = False Then
            MsgBox(dtl .MERROR.ToString & "Could not save the document", MsgBoxStyle.Critical)
        End If


        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Public Sub MostrarDocumentosConciliación(Optional fechas As Integer = 0)
        Try
            celdaSaldoFinalBank.Text = Format(celdaSaldoFinalBank.Text, FORMATO_MONEDA)
            celdaSaldoFinalBank.Text = vbEmpty
            celdaBuscar.Text = vbNullString
            celdaSaldoFinalConta.Text = vbEmpty
            If fechas = 1 Then
                FechaInicio = dtpInicio.Value
                FechaFin = dtpFin.Value
            Else
                dtpInicio.Value = FechaInicio
                dtpFin.Value = FechaFin
            End If

            etiquetaMesesPendientes.Text = "Pending Months"

            etiquetaMesActual.Text = cFunciones.MesIngles(Month(FechaInicio)) & "/" & Year(FechaInicio)
            If Month(FechaInicio) = 12 Then
                etiquetaMesSiguiente.Text = cFunciones.MesIngles(Month(FechaInicio) - 11) & "/" & Year(FechaInicio) + 1
            Else

                etiquetaMesSiguiente.Text = cFunciones.MesIngles(Month(FechaInicio) + 1) & "/" & Year(FechaInicio)
            End If

            SaldoContabilidad()

            'Cargar Datagrid de Pendientes
            CargarPendientes(fechas, dgPenCheques, ID_CHEQUE, ACT_CHEQUE, FechaInicio.ToString(FORMATO_MYSQL), False)
            CargarPendientes(fechas, dgPenDepositos, ID_DEPOSITO, ACT_DEPOSITO, FechaInicio.ToString(FORMATO_MYSQL), False)
            CargarPendientes(fechas, dgPenNotasCredito, ID_CREDITO, ACT_CREDITO, FechaInicio.ToString(FORMATO_MYSQL), False)
            CargarPendientes(fechas, dgPenNotasDebit, ID_DEBITO, ACT_DEBITO, FechaInicio.ToString(FORMATO_MYSQL), False)

            'Cargar Datagrid de Documentos
            CargarDocumentos(fechas, dgDocCheques, ID_CHEQUE, ACT_CHEQUE, FechaInicio.ToString(FORMATO_MYSQL), FechaFin.ToString(FORMATO_MYSQL), False)
            CargarDocumentos(fechas, dgDocDepositos, ID_DEPOSITO, ACT_DEPOSITO, FechaInicio.ToString(FORMATO_MYSQL), FechaFin.ToString(FORMATO_MYSQL), False)
            CargarDocumentos(fechas, dgDocNotasCredit, ID_CREDITO, ACT_CREDITO, FechaInicio.ToString(FORMATO_MYSQL), FechaFin.ToString(FORMATO_MYSQL), False)
            CargarDocumentos(fechas, dgDocNotDebit, ID_DEBITO, ACT_DEBITO, FechaInicio.ToString(FORMATO_MYSQL), FechaFin.ToString(FORMATO_MYSQL), False)

            'Cargar Datagrid Actuales
            CargarActuales(fechas, dgActCheques, ID_CHEQUE, ACT_CHEQUE, FechaInicio.ToString(FORMATO_MYSQL), False)
            CargarActuales(fechas, dgActDepositos, ID_DEPOSITO, ACT_DEPOSITO, FechaInicio.ToString(FORMATO_MYSQL), False)
            CargarActuales(fechas, dgActNotCredit, ID_CREDITO, ACT_CREDITO, FechaInicio.ToString(FORMATO_MYSQL), False)
            CargarActuales(fechas, dgActNoteDebit, ID_DEBITO, ACT_DEBITO, FechaInicio.ToString(FORMATO_MYSQL), False)

            'Cargar dato de Moneda 
            Monedas()

            'Cargar Datos
            CargarConciliacionAnterior()

            'Saldo Contabilidad


        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Public Sub EliminarConciliacion(ByVal anio As Integer, ByVal NumConciliacion As Integer)
        Dim strSQL As String = STR_VACIO
        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader
        Dim dtFecFinal As Date
        Dim dtFecConciliacion As Date

        'Aqui se obtiene la fecha en final de la conciliación, y la fecha en que fue creada
        strSQL = " SELECT HDoc_DR2_Fec Mes, HDoc_Doc_Fec Conciliacion FROM Dcmtos_HDR "
        strSQL &= "    WHERE HDoc_Sis_Emp = {emp} AND HDoc_Doc_Cat = 257 AND HDoc_Doc_Ano = {anio} AND HDoc_Doc_Num = {num}"

        strSQL = Replace(strSQL, "{emp}", Sesion.IdEmpresa)
        strSQL = Replace(strSQL, "{anio}", anio)
        strSQL = Replace(strSQL, "{num}", NumConciliacion)
        MyCnn.CONECTAR = strConexion
        COM = New MySqlCommand(strSQL, CON)
        REA = COM.ExecuteReader


        If REA.HasRows Then
            Do While REA.Read
                dtFecFinal = REA.GetDateTime("Mes").ToString(FORMATO_MYSQL)
                dtFecConciliacion = REA.GetDateTime("Conciliacion").ToString(FORMATO_MYSQL)
            Loop

        End If
        COM.Dispose()
        COM = Nothing
        REA = Nothing

        strSQL = STR_VACIO
        ' Actualiza el Estado de los cheques y las notas de debito
        strSQL = " UPDATE Dcmtos_HDR Set HDoc_Doc_Status = 0 "
        strSQL &= " WHERE HDoc_Sis_Emp = {emp} AND (HDoc_Doc_Cat = 51 OR HDoc_Doc_Cat = 52) AND HDoc_DR1_Fec = '{ffinal}' AND HDoc_DR2_Fec = '{fconciliacion}' AND HDoc_RF1_Num = {idBanco}"

        If Sesion.IdEmpresa = 18 Then
            strSQL &= "; UPDATE PDM.Dcmtos_HDR Set HDoc_Doc_Status = 0 "
            strSQL &= " WHERE HDoc_Sis_Emp = {emp} AND (HDoc_Doc_Cat = 51 OR HDoc_Doc_Cat = 52) AND HDoc_DR1_Fec = '{ffinal}' AND HDoc_DR2_Fec = '{fconciliacion}' AND HDoc_RF1_Num = {idBanco}"
        End If

        strSQL = Replace(strSQL, "{emp}", Sesion.IdEmpresa)
        strSQL = Replace(strSQL, "{ffinal}", dtFecFinal.ToString(FORMATO_MYSQL))
        strSQL = Replace(strSQL, "{fconciliacion}", dtFecConciliacion.ToString(FORMATO_MYSQL))
        strSQL = Replace(strSQL, "{idBanco}", intBanco)

        MyCnn.CONECTAR = strConexion
        COM = New MySqlCommand(strSQL, CON)
        COM.ExecuteNonQuery()

        COM.Dispose()
        COM = Nothing
        strSQL = STR_VACIO

        'Elimina las fechas de la conciliación en los documentos
        strSQL = " UPDATE Dcmtos_HDR SET HDoc_DR1_Fec = NULL, HDoc_DR2_Fec = NULL "
        strSQL &= " WHERE HDoc_Sis_Emp = {emp} AND (HDoc_Doc_Cat = 51 OR HDoc_Doc_Cat = 52 OR HDoc_Doc_Cat = 53 OR HDoc_Doc_Cat = 54) AND HDoc_DR1_Fec = '{ffinal}' AND HDoc_DR2_Fec = '{fconciliacion}' AND HDoc_RF1_Num = {idBanco}"
        If Sesion.IdEmpresa = 18 Then
            strSQL &= "; UPDATE PDM.Dcmtos_HDR SET HDoc_DR1_Fec = NULL, HDoc_DR2_Fec = NULL "
            strSQL &= " WHERE HDoc_Sis_Emp = {emp} AND (HDoc_Doc_Cat = 51 OR HDoc_Doc_Cat = 52 OR HDoc_Doc_Cat = 53 OR HDoc_Doc_Cat = 54) AND HDoc_DR1_Fec = '{ffinal}' AND HDoc_DR2_Fec = '{fconciliacion}' AND HDoc_RF1_Num = {idBanco}"
        End If
        strSQL = Replace(strSQL, "{emp}", Sesion.IdEmpresa)
        strSQL = Replace(strSQL, "{ffinal}", dtFecFinal.ToString(FORMATO_MYSQL))
        strSQL = Replace(strSQL, "{fconciliacion}", dtFecConciliacion.ToString(FORMATO_MYSQL))
        strSQL = Replace(strSQL, "{idBanco}", intBanco)

        MyCnn.CONECTAR = strConexion
        COM = New MySqlCommand(strSQL, CON)
        COM.ExecuteNonQuery()

        COM.Dispose()
        COM = Nothing
        strSQL = STR_VACIO

        'elimina el encabezado de la conciliación
        Dim hdr As New clsDcmtos_HDR
        hdr.CONEXION = strConexion
        hdr.HDOC_SIS_EMP = Sesion.IdEmpresa
        hdr.HDOC_DOC_CAT = CATALOGO
        hdr.HDOC_DOC_ANO = anio
        hdr.HDOC_DOC_NUM = NumConciliacion
        hdr.Borrar()

        'Elimina el detalle de la conciliación
        strSQL = "DDoc_Sis_Emp = {emp} AND DDoc_Doc_Cat = {cata} AND DDoc_Doc_Ano = {anio} AND DDoc_Doc_Num = {num}"

        strSQL = Replace(strSQL, "{emp}", Sesion.IdEmpresa)
        strSQL = Replace(strSQL, "{cata}", CATALOGO)
        strSQL = Replace(strSQL, "{anio}", anio)
        strSQL = Replace(strSQL, "{num}", NumConciliacion)

        Dim dtl As New clsDcmtos_DTL
        dtl.CONEXION = strConexion
        dtl.Borrar(strSQL)

    End Sub

#End Region

#Region "Eventos"

    Private Sub frmConciliacionBancaria_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        MostrarDocumentosConciliación()
    End Sub

    Private Sub botonCerrar_Click(sender As Object, e As EventArgs) Handles botonCerrar.Click
        Me.Close()
    End Sub

    Private Sub botonConciliacion_Click(sender As Object, e As EventArgs) Handles botonConciliacion.Click

        Dim frm As New frmSeleccionar
        Dim strCondicion As String = STR_VACIO
        strCondicion = "HDoc_Sis_Emp = {empresa} AND HDoc_Doc_Cat = {intCurDoc} AND HDoc_DR1_Cat = {intBanco} "
        strCondicion = Replace(strCondicion, "{empresa}", Sesion.IdEmpresa)
        strCondicion = Replace(strCondicion, "{intBanco}", intBanco)
        strCondicion = Replace(strCondicion, " {intCurDoc}", intCurDoc)

        Try
            frm.Titulo = "Conciliations"
            frm.Campos = " MONTHNAME(HDoc_DR1_Fec) Month, HDoc_Doc_Ano Year, HDoc_RF1_Dbl Accounting, HDoc_RF2_Dbl Bank, ROUND(IF(HDoc_RF1_Dbl < 0,HDoc_RF2_Dbl - (HDoc_RF1_Dbl * -1),IF(HDoc_RF2_Dbl < 0, HDoc_RF1_Dbl -(HDoc_RF2_Dbl * -1), (HDoc_RF2_Dbl - HDoc_RF1_Dbl))),2) Diference, HDoc_Doc_Fec Created, HDoc_DR1_Fec Start, HDoc_Doc_Num Id "
            frm.Condicion = strCondicion
            frm.Tabla = " Dcmtos_HDR"
            frm.Filtro = "HDoc_DR2_Cat"
            frm.Ordenamiento = "HDoc_Doc_Ano, HDoc_DR2_Cat "
            frm.TipoOrdenamiento = " ASC "
            If frm.ShowDialog = System.Windows.Forms.DialogResult.OK Then
                Dim report As New clsReportes
                report.ImprimirConciliacionesPasadas(frm.ListaClientes.SelectedCells(7).Value, frm.ListaClientes.SelectedCells(1).Value, intBanco)
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try

    End Sub

    Private Sub botonEliminar_Click(sender As Object, e As EventArgs) Handles botonEliminar.Click

        Dim frm As New frmSeleccionar
        Dim intContarRegistros As Integer = 0
        Dim intRegistroSelec As Integer = 0
        Dim strCondicion As String = STR_VACIO
        strCondicion = "HDoc_Sis_Emp = {empresa} AND HDoc_Doc_Cat = {intCurDoc} AND HDoc_DR1_Cat = {intBanco} "
        strCondicion = Replace(strCondicion, "{empresa}", Sesion.IdEmpresa)
        strCondicion = Replace(strCondicion, "{intBanco}", intBanco)
        strCondicion = Replace(strCondicion, " {intCurDoc}", intCurDoc)

        Try
            frm.Titulo = "Conciliations"
            frm.Campos = " MONTHNAME(HDoc_DR1_Fec) Month, HDoc_Doc_Ano Year, HDoc_RF1_Dbl Accounting, HDoc_RF2_Dbl Bank, ROUND(IF(HDoc_RF1_Dbl < 0,HDoc_RF2_Dbl - (HDoc_RF1_Dbl * -1),IF(HDoc_RF2_Dbl < 0, HDoc_RF1_Dbl -(HDoc_RF2_Dbl * -1), (HDoc_RF2_Dbl - HDoc_RF1_Dbl))),2) Diference, HDoc_Doc_Fec Created, HDoc_DR1_Fec Start, HDoc_Doc_Num Id "
            frm.Condicion = strCondicion
            frm.Tabla = " Dcmtos_HDR"
            frm.Filtro = "HDoc_DR2_Cat"
            frm.Ordenamiento = "HDoc_Doc_Ano, HDoc_DR2_Cat "
            frm.TipoOrdenamiento = " ASC "
            If frm.ShowDialog = System.Windows.Forms.DialogResult.OK Then
                intContarRegistros = frm.ListaClientes.Rows.Count - 1

                For j As Integer = 0 To frm.ListaClientes.Rows.Count - 1
                    If frm.ListaClientes.Rows(j).Selected = True Then
                        intRegistroSelec = j
                        Exit For
                    End If
                Next

                If intRegistroSelec = intContarRegistros Then
                    If MsgBox("Remove reconciliation from " & frm.LLave, vbYesNo + vbQuestion, "Notice") = vbYes Then
                        'se envia el año y el numero de conciliación como parametros
                        EliminarConciliacion(frm.ListaClientes.SelectedCells(1).Value, frm.ListaClientes.SelectedCells(7).Value)
                        MsgBox("Conciliation deleted successfully.", vbInformation, "Notice")
                        MostrarDocumentosConciliación(1)
                        LimpiarCheck()
                    End If
                Else
                    MsgBox("Only the last reconciliation made can be deleted.", vbCritical, "Notice")
                End If


                'Dim report As New clsReportes
                'report.ImprimirConciliacionesPasadas(frm.ListaClientes.SelectedCells(7).Value, frm.ListaClientes.SelectedCells(1).Value, intBanco)
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try

    End Sub

    Public Sub LimpiarCheck()
        checkPenCheques.Checked = False
        checkPenDeposito.Checked = False
        checkPenCreditNotes.Checked = False
        checkPenDebitNotes.Checked = False
        checkDocCheques.Checked = False
        checkDocDepositos.Checked = False
        checkDocCrediNotes.Checked = False
        checkDocDebitNotes.Checked = False
        checkActualCheques.Checked = False
        checkActualDepositos.Checked = False
        checkActualCreditNotes.Checked = False
        checkActualDebitNotes.Checked = False
    End Sub
    Private Sub botonPoliza_Click(sender As Object, e As EventArgs) Handles botonPoliza.Click
        Dim CReportes As New clsReportes

        CReportes.ReporteSumaryPolicy(intBanco, dtaFechaInicio, dtaFechaFin)
    End Sub

    Private Sub botonAcFecha_Click(sender As Object, e As EventArgs) Handles botonAcFecha.Click

        MostrarDocumentosConciliación(1)

        'If Not Month(FechaInicio.ToString(FORMATO_MYSQL)) = Month(FechaFin.ToString(FORMATO_MYSQL)) Then
        '    MsgBox("Check the Date Range.", vbCritical, "Notice")
        '    Exit Sub
        'End If

        ''Cargar Datagrid de Pendientes
        'CargarPendientes(dgPenCheques, ID_CHEQUE, ACT_CHEQUE, FechaInicio.ToString(FORMATO_MYSQL), True)
        'CargarPendientes(dgPenDepositos, ID_DEPOSITO, ACT_DEPOSITO, FechaInicio.ToString(FORMATO_MYSQL), True)
        'CargarPendientes(dgPenNotasCredito, ID_CREDITO, ACT_CREDITO, FechaInicio.ToString(FORMATO_MYSQL), True)
        'CargarPendientes(dgPenNotasDebit, ID_DEBITO, ACT_DEBITO, FechaInicio.ToString(FORMATO_MYSQL), True)

        ''Cargar Datagrid de Documentos
        'CargarDocumentos(dgDocCheques, ID_CHEQUE, ACT_CHEQUE, FechaInicio.ToString(FORMATO_MYSQL), FechaFin.ToString(FORMATO_MYSQL), True)
        'CargarDocumentos(dgDocDepositos, ID_DEPOSITO, ACT_DEPOSITO, FechaInicio.ToString(FORMATO_MYSQL), FechaFin.ToString(FORMATO_MYSQL), True)
        'CargarDocumentos(dgDocNotasCredit, ID_CREDITO, ACT_CREDITO, FechaInicio.ToString(FORMATO_MYSQL), FechaFin.ToString(FORMATO_MYSQL), True)
        'CargarDocumentos(dgDocNotDebit, ID_DEBITO, ACT_DEBITO, FechaInicio.ToString(FORMATO_MYSQL), FechaFin.ToString(FORMATO_MYSQL), True)

        ''Cargar Datagrid Actuales
        'CargarActuales(dgActCheques, ID_CHEQUE, ACT_CHEQUE, FechaInicio.ToString(FORMATO_MYSQL), True)
        'CargarActuales(dgActDepositos, ID_DEPOSITO, ACT_DEPOSITO, FechaInicio.ToString(FORMATO_MYSQL), True)
        'CargarActuales(dgActNotCredit, ID_CREDITO, ACT_CREDITO, FechaInicio.ToString(FORMATO_MYSQL), True)
        'CargarActuales(dgActNoteDebit, ID_DEBITO, ACT_DEBITO, FechaInicio.ToString(FORMATO_MYSQL), True)


    End Sub

    Private Sub dgPenCheques_DoubleClick(sender As Object, e As EventArgs) Handles dgPenCheques.DoubleClick
        TotalLiquidacion = 0
        If dgPenCheques.CurrentRow.Cells(0).Value = " " Then
            dgPenCheques.CurrentRow.Cells(0).Value = "x"


            CalculoCargarSeleccion(dgPenCheques, ID_CHEQUE)

            TotalLiquidacion = dblSumar
            celdaLiquidarPendientes.Text = TotalLiquidacion.ToString(FORMATO_MONEDA)
        Else
            dgPenCheques.CurrentRow.Cells(0).Value = " "

            dblSumar = vbEmpty
            TotalLiquidacion = vbEmpty
            CalculoCargarSeleccion(dgPenCheques, ID_CHEQUE)

            TotalLiquidacion = dblSumar
            celdaLiquidarPendientes.Text = TotalLiquidacion.ToString(FORMATO_MONEDA)

        End If
        TotaleCheques()
    End Sub

    Private Sub dgPenDepositos_DoubleClick(sender As Object, e As EventArgs) Handles dgPenDepositos.DoubleClick

        If dgPenDepositos.CurrentRow.Cells(0).Value = " " Then
            dgPenDepositos.CurrentRow.Cells(0).Value = "x"


            CalculoCargarSeleccion(dgPenDepositos, ID_DEPOSITO)

            TotalLiquidacion = dblSumar
            celdaLiquidarPendientes2.Text = TotalLiquidacion.ToString(FORMATO_MONEDA)
        Else
            dgPenDepositos.CurrentRow.Cells(0).Value = " "

            dblSumar = vbEmpty
            TotalLiquidacion = vbEmpty
            CalculoCargarSeleccion(dgPenDepositos, ID_DEPOSITO)

            TotalLiquidacion = dblSumar
            celdaLiquidarPendientes2.Text = TotalLiquidacion.ToString(FORMATO_MONEDA)

        End If
        TotalesDepositos()
    End Sub

    Private Sub dgPenNotasCredito_DoubleClick(sender As Object, e As EventArgs) Handles dgPenNotasCredito.DoubleClick

        If dgPenNotasCredito.CurrentRow.Cells(0).Value = " " Then
            dgPenNotasCredito.CurrentRow.Cells(0).Value = "x"


            CalculoCargarSeleccion(dgPenNotasCredito, ID_CREDITO)

            TotalLiquidacion = dblSumar
            celdaLiquidarPendientes3.Text = TotalLiquidacion.ToString(FORMATO_MONEDA)
        Else
            dgPenNotasCredito.CurrentRow.Cells(0).Value = " "

            dblSumar = vbEmpty
            TotalLiquidacion = vbEmpty
            CalculoCargarSeleccion(dgPenNotasCredito, ID_CREDITO)

            TotalLiquidacion = dblSumar
            celdaLiquidarPendientes3.Text = TotalLiquidacion.ToString(FORMATO_MONEDA)

        End If
        TotalesNotasDeCredito()
    End Sub

    Private Sub dgPenNotasDebit_DoubleClick(sender As Object, e As EventArgs) Handles dgPenNotasDebit.DoubleClick

        If dgPenNotasDebit.CurrentRow.Cells(0).Value = " " Then
            dgPenNotasDebit.CurrentRow.Cells(0).Value = "x"


            CalculoCargarSeleccion(dgPenNotasDebit, ID_DEBITO)

            TotalLiquidacion = dblSumar
            celdaLiquidarPendientes4.Text = TotalLiquidacion.ToString(FORMATO_MONEDA)
        Else
            dgPenNotasDebit.CurrentRow.Cells(0).Value = " "

            dblSumar = vbEmpty
            TotalLiquidacion = vbEmpty
            CalculoCargarSeleccion(dgPenNotasDebit, ID_DEBITO)

            TotalLiquidacion = TotalLiquidacion + dblSumar
            celdaLiquidarPendientes4.Text = TotalLiquidacion.ToString(FORMATO_MONEDA)

        End If
        TotalesNotasDeDebito()
    End Sub

    Private Sub dgDocCheques_DoubleClick(sender As Object, e As EventArgs) Handles dgDocCheques.DoubleClick

        If dgDocCheques.CurrentRow.Cells(0).Value = " " Then
            dgDocCheques.CurrentRow.Cells(0).Value = "x"


            CalculoCargarSeleccion(dgDocCheques, ID_CHEQUE)

            TotalLiquidacion = dblSumar
            celdaLiquidarDoc.Text = TotalLiquidacion.ToString(FORMATO_MONEDA)
        Else
            dgDocCheques.CurrentRow.Cells(0).Value = " "

            dblSumar = vbEmpty
            TotalLiquidacion = vbEmpty
            CalculoCargarSeleccion(dgDocCheques, ID_CHEQUE)

            TotalLiquidacion = dblSumar
            celdaLiquidarDoc.Text = TotalLiquidacion.ToString(FORMATO_MONEDA)

        End If
        TotaleCheques()
    End Sub

    Private Sub dgDocDepositos_DoubleClick(sender As Object, e As EventArgs) Handles dgDocDepositos.DoubleClick

        If dgDocDepositos.CurrentRow.Cells(0).Value = " " Then
            dgDocDepositos.CurrentRow.Cells(0).Value = "x"


            CalculoCargarSeleccion(dgDocDepositos, ID_DEPOSITO)

            TotalLiquidacion = dblSumar
            celdaLiquidarDoc2.Text = TotalLiquidacion.ToString(FORMATO_MONEDA)
        Else
            dgDocDepositos.CurrentRow.Cells(0).Value = " "

            dblSumar = vbEmpty
            TotalLiquidacion = vbEmpty
            CalculoCargarSeleccion(dgDocDepositos, ID_DEPOSITO)

            TotalLiquidacion = dblSumar
            celdaLiquidarDoc2.Text = TotalLiquidacion.ToString(FORMATO_MONEDA)

        End If
        TotalesDepositos()
    End Sub

    Private Sub dgDocNotasCredit_DoubleClick(sender As Object, e As EventArgs) Handles dgDocNotasCredit.DoubleClick

        If dgDocNotasCredit.CurrentRow.Cells(0).Value = " " Then
            dgDocNotasCredit.CurrentRow.Cells(0).Value = "x"


            CalculoCargarSeleccion(dgDocNotasCredit, ID_CREDITO)

            TotalLiquidacion = dblSumar
            celdaLiquidarDoc3.Text = TotalLiquidacion.ToString(FORMATO_MONEDA)
        Else
            dgDocNotasCredit.CurrentRow.Cells(0).Value = " "

            dblSumar = vbEmpty
            TotalLiquidacion = vbEmpty
            CalculoCargarSeleccion(dgDocNotasCredit, ID_CREDITO)

            TotalLiquidacion = dblSumar
            celdaLiquidarDoc3.Text = TotalLiquidacion.ToString(FORMATO_MONEDA)

        End If
        TotalesNotasDeCredito()
    End Sub

    Private Sub dgDocNotDebit_DoubleClick(sender As Object, e As EventArgs) Handles dgDocNotDebit.DoubleClick

        If dgDocNotDebit.CurrentRow.Cells(0).Value = " " Then
            dgDocNotDebit.CurrentRow.Cells(0).Value = "x"


            CalculoCargarSeleccion(dgDocNotDebit, ID_DEBITO)

            TotalLiquidacion = dblSumar
            celdaLiquidarDoc4.Text = TotalLiquidacion.ToString(FORMATO_MONEDA)
        Else
            dgDocNotDebit.CurrentRow.Cells(0).Value = " "

            dblSumar = vbEmpty
            TotalLiquidacion = vbEmpty
            CalculoCargarSeleccion(dgDocNotDebit, ID_DEBITO)

            TotalLiquidacion = dblSumar
            celdaLiquidarDoc4.Text = TotalLiquidacion.ToString(FORMATO_MONEDA)

        End If
        TotalesNotasDeDebito()
    End Sub

    Private Sub dgActCheques_DoubleClick(sender As Object, e As EventArgs) Handles dgActCheques.DoubleClick

        If dgActCheques.CurrentRow.Cells(0).Value = " " Then
            dgActCheques.CurrentRow.Cells(0).Value = "x"


            CalculoCargarSeleccion(dgActCheques, ID_CHEQUE)

            TotalLiquidacion = dblSumar
            celdaLiquidarActual.Text = TotalLiquidacion.ToString(FORMATO_MONEDA)
        Else
            dgActCheques.CurrentRow.Cells(0).Value = " "

            dblSumar = vbEmpty
            TotalLiquidacion = vbEmpty
            CalculoCargarSeleccion(dgActCheques, ID_CHEQUE)

            TotalLiquidacion = dblSumar
            celdaLiquidarActual.Text = TotalLiquidacion.ToString(FORMATO_MONEDA)

        End If
        TotaleCheques()
    End Sub

    Private Sub dgActDepositos_DoubleClick(sender As Object, e As EventArgs) Handles dgActDepositos.DoubleClick

        If dgActDepositos.CurrentRow.Cells(0).Value = " " Then
            dgActDepositos.CurrentRow.Cells(0).Value = "x"


            CalculoCargarSeleccion(dgActDepositos, ID_DEPOSITO)

            TotalLiquidacion = dblSumar
            celdaLiquidarActual2.Text = TotalLiquidacion.ToString(FORMATO_MONEDA)
        Else
            dgActDepositos.CurrentRow.Cells(0).Value = " "

            dblSumar = vbEmpty
            TotalLiquidacion = vbEmpty
            CalculoCargarSeleccion(dgActDepositos, ID_DEPOSITO)

            TotalLiquidacion = dblSumar
            celdaLiquidarActual2.Text = TotalLiquidacion.ToString(FORMATO_MONEDA)

        End If
        TotalesDepositos()
    End Sub

    Private Sub dgActNotCredit_DoubleClick(sender As Object, e As EventArgs) Handles dgActNotCredit.DoubleClick

        If dgActNotCredit.CurrentRow.Cells(0).Value = " " Then
            dgActNotCredit.CurrentRow.Cells(0).Value = "x"


            CalculoCargarSeleccion(dgActNotCredit, ID_CREDITO)

            TotalLiquidacion = dblSumar
            celdaLiquidarActual3.Text = TotalLiquidacion.ToString(FORMATO_MONEDA)
        Else
            dgActNoteDebit.CurrentRow.Cells(0).Value = " "

            dblSumar = vbEmpty
            TotalLiquidacion = vbEmpty
            CalculoCargarSeleccion(dgActNoteDebit, ID_CREDITO)

            TotalLiquidacion = dblSumar
            celdaLiquidarActual3.Text = TotalLiquidacion.ToString(FORMATO_MONEDA)

        End If
        TotalesNotasDeCredito()
    End Sub

    Private Sub dgActNoteDebit_DoubleClick(sender As Object, e As EventArgs) Handles dgActNoteDebit.DoubleClick

        If dgActNoteDebit.CurrentRow.Cells(0).Value = " " Then
            dgActNoteDebit.CurrentRow.Cells(0).Value = "x"


            CalculoCargarSeleccion(dgActNoteDebit, ID_DEBITO)

            TotalLiquidacion = dblSumar
            celdaLiquidarActual4.Text = TotalLiquidacion.ToString(FORMATO_MONEDA)
        Else
            dgActNoteDebit.CurrentRow.Cells(0).Value = " "

            dblSumar = vbEmpty
            TotalLiquidacion = vbEmpty
            CalculoCargarSeleccion(dgActNoteDebit, ID_DEBITO)

            TotalLiquidacion = dblSumar
            celdaLiquidarActual4.Text = TotalLiquidacion.ToString(FORMATO_MONEDA)

        End If
        TotalesNotasDeDebito()
    End Sub

    Private Sub checkPenCheques_CheckedChanged(sender As Object, e As EventArgs) Handles checkPenCheques.CheckedChanged
        Dim i As Integer = vbEmpty

        If checkPenCheques.Checked = True Then
            For i = vbEmpty To dgPenCheques.RowCount - 1
                dgPenCheques.Rows(i).Cells(0).Value = "x"
            Next

            TotalLiquidacion = vbEmpty
            dblSumar = vbEmpty
            CalculoCargarSeleccion(dgPenCheques, ID_CHEQUE)

            'Select Case ID_CHEQUE
            '    Case ID_CHEQUE, ID_DEBITO
            '        dblSumar = dblSumar * (-1)
            '    Case ID_DEPOSITO, ID_CREDITO
            '        dblSumar = dblSumar
            'End Select

            TotalLiquidacion = TotalLiquidacion + dblSumar
            celdaLiquidarPendientes.Text = TotalLiquidacion.ToString(FORMATO_MONEDA)

        Else
            For i = vbEmpty To dgPenCheques.RowCount - 1
                dgPenCheques.Rows(i).Cells(0).Value = " "
            Next

            celdaLiquidarPendientes.Text = vbEmpty

        End If
        TotaleCheques()
    End Sub

    Private Sub checkPenDeposito_CheckedChanged(sender As Object, e As EventArgs) Handles checkPenDeposito.CheckedChanged
        Dim i As Integer = vbEmpty

        If checkPenDeposito.Checked = True Then
            For i = vbEmpty To dgPenDepositos.RowCount - 1
                dgPenDepositos.Rows(i).Cells(0).Value = "x"
            Next

            TotalLiquidacion = vbEmpty
            dblSumar = vbEmpty
            CalculoCargarSeleccion(dgPenDepositos, ID_DEPOSITO)

            'Select Case ID_CHEQUE
            '    Case ID_CHEQUE, ID_DEBITO
            '        dblSumar = dblSumar * (-1)
            '    Case ID_DEPOSITO, ID_CREDITO
            '        dblSumar = dblSumar
            'End Select

            TotalLiquidacion = TotalLiquidacion + dblSumar
            celdaLiquidarPendientes2.Text = TotalLiquidacion.ToString(FORMATO_MONEDA)

        Else
            For i = vbEmpty To dgPenDepositos.RowCount - 1
                dgPenDepositos.Rows(i).Cells(0).Value = " "
            Next

            celdaLiquidarPendientes2.Text = vbEmpty

        End If
    End Sub

    Private Sub checkPenCreditNotes_CheckedChanged(sender As Object, e As EventArgs) Handles checkPenCreditNotes.CheckedChanged
        Dim i As Integer = vbEmpty

        If checkPenCreditNotes.Checked = True Then
            For i = vbEmpty To dgPenNotasCredito.RowCount - 1
                dgPenNotasCredito.Rows(i).Cells(0).Value = "x"
            Next

            TotalLiquidacion = vbEmpty
            dblSumar = vbEmpty
            CalculoCargarSeleccion(dgPenNotasCredito, ID_CREDITO)

            'Select Case ID_CHEQUE
            '    Case ID_CHEQUE, ID_DEBITO
            '        dblSumar = dblSumar * (-1)
            '    Case ID_DEPOSITO, ID_CREDITO
            '        dblSumar = dblSumar
            'End Select


            TotalLiquidacion = TotalLiquidacion + dblSumar
            celdaLiquidarPendientes3.Text = TotalLiquidacion.ToString(FORMATO_MONEDA)

        Else
            For i = vbEmpty To dgPenNotasCredito.RowCount - 1
                dgPenNotasCredito.Rows(i).Cells(0).Value = " "
            Next

            celdaLiquidarPendientes3.Text = vbEmpty

        End If
        TotalesNotasDeCredito()
    End Sub


    Private Sub checkPenDebitNotes_CheckedChanged(sender As Object, e As EventArgs) Handles checkPenDebitNotes.CheckedChanged
        Dim i As Integer = vbEmpty

        If checkPenDebitNotes.Checked = True Then
            For i = vbEmpty To dgPenNotasDebit.RowCount - 1
                dgPenNotasDebit.Rows(i).Cells(0).Value = "x"
            Next

            TotalLiquidacion = vbEmpty
            dblSumar = vbEmpty
            CalculoCargarSeleccion(dgPenNotasDebit, ID_DEBITO)

            'Select Case ID_CHEQUE
            '    Case ID_CHEQUE, ID_DEBITO
            '        dblSumar = dblSumar * (-1)
            '    Case ID_DEPOSITO, ID_CREDITO
            '        dblSumar = dblSumar
            'End Select

            TotalLiquidacion = TotalLiquidacion + dblSumar
            celdaLiquidarPendientes4.Text = TotalLiquidacion.ToString(FORMATO_MONEDA)

        Else
            For i = vbEmpty To dgPenNotasCredito.RowCount - 1
                dgPenNotasDebit.Rows(i).Cells(0).Value = " "
            Next

            celdaLiquidarPendientes4.Text = vbEmpty

        End If
        TotalesNotasDeDebito()
    End Sub

    Private Sub checkDocCheques_CheckedChanged(sender As Object, e As EventArgs) Handles checkDocCheques.CheckedChanged
        Dim i As Integer = vbEmpty

        If checkDocCheques.Checked = True Then
            For i = vbEmpty To dgDocCheques.RowCount - 1
                dgDocCheques.Rows(i).Cells(0).Value = "x"
            Next

            TotalLiquidacion = vbEmpty
            dblSumar = vbEmpty
            CalculoCargarSeleccion(dgDocCheques, ID_CHEQUE)

            'Select Case ID_CHEQUE
            '    Case ID_CHEQUE, ID_DEBITO
            '        dblSumar = dblSumar * (-1)
            '    Case ID_DEPOSITO, ID_CREDITO
            '        dblSumar = dblSumar
            'End Select


            TotalLiquidacion = TotalLiquidacion + dblSumar
            celdaLiquidarDoc.Text = TotalLiquidacion.ToString(FORMATO_MONEDA)

        Else
            For i = vbEmpty To dgDocCheques.RowCount - 1
                dgDocCheques.Rows(i).Cells(0).Value = " "
            Next

            celdaLiquidarDoc.Text = vbEmpty

        End If
        TotaleCheques()
    End Sub

    Private Sub checkDocDepositos_CheckedChanged(sender As Object, e As EventArgs) Handles checkDocDepositos.CheckedChanged
        Dim i As Integer = vbEmpty

        If checkDocDepositos.Checked = True Then
            For i = vbEmpty To dgDocDepositos.RowCount - 1
                dgDocDepositos.Rows(i).Cells(0).Value = "x"
            Next

            TotalLiquidacion = vbEmpty
            dblSumar = vbEmpty
            CalculoCargarSeleccion(dgDocDepositos, ID_DEPOSITO)

            'Select Case ID_DEPOSITO
            '    Case ID_CHEQUE, ID_DEBITO
            '        dblSumar = dblSumar * (-1)
            '    Case ID_DEPOSITO, ID_CREDITO
            '        dblSumar = dblSumar
            'End Select

            TotalLiquidacion = dblSumar
            celdaLiquidarDoc2.Text = TotalLiquidacion.ToString(FORMATO_MONEDA)

        Else
            For i = vbEmpty To dgDocDepositos.RowCount - 1
                dgDocDepositos.Rows(i).Cells(0).Value = " "
            Next

            celdaLiquidarDoc2.Text = vbEmpty

        End If
        TotalesDepositos()
    End Sub

    Private Sub checkDocCrediNotes_CheckedChanged(sender As Object, e As EventArgs) Handles checkDocCrediNotes.CheckedChanged
        Dim SumarNC As Double = 0

        If checkDocCrediNotes.Checked = True Then
            For i = vbEmpty To dgDocNotasCredit.RowCount - 1
                dgDocNotasCredit.Rows(i).Cells(0).Value = "x"
            Next

            TotalLiquidacion = vbEmpty
            dblSumar = vbEmpty
            CalculoCargarSeleccion(dgDocNotasCredit, ID_CREDITO)

            'Select Case ID_CREDITO
            '    Case ID_CHEQUE, ID_DEBITO
            '        dblSumar = dblSumar * (-1)
            '    Case ID_DEPOSITO, ID_CREDITO
            '        dblSumar = dblSumar
            'End Select

            TotalLiquidacion = TotalLiquidacion + dblSumar
            celdaLiquidarDoc3.Text = TotalLiquidacion.ToString(FORMATO_MONEDA)

        Else
            For i = vbEmpty To dgDocNotasCredit.RowCount - 1
                dgDocNotasCredit.Rows(i).Cells(0).Value = " "
            Next

            celdaLiquidarDoc3.Text = vbEmpty

        End If
        TotalesNotasDeCredito()
    End Sub

    Private Sub checkDocDebitNotes_CheckedChanged(sender As Object, e As EventArgs) Handles checkDocDebitNotes.CheckedChanged
        Dim i As Integer = vbEmpty

        If checkDocDebitNotes.Checked = True Then
            For i = vbEmpty To dgDocNotDebit.RowCount - 1
                dgDocNotDebit.Rows(i).Cells(0).Value = "x"
            Next

            TotalLiquidacion = vbEmpty
            dblSumar = vbEmpty
            CalculoCargarSeleccion(dgDocNotDebit, ID_DEBITO)

            'Select Case ID_DEBITO
            '    Case ID_CHEQUE, ID_DEBITO
            '        dblSumar = dblSumar * (-1)
            '    Case ID_DEPOSITO, ID_CREDITO
            '        dblSumar = dblSumar
            'End Select

            TotalLiquidacion = TotalLiquidacion + dblSumar
            celdaLiquidarDoc4.Text = TotalLiquidacion.ToString(FORMATO_MONEDA)

        Else
            For i = vbEmpty To dgDocNotDebit.RowCount - 1
                dgDocNotDebit.Rows(i).Cells(0).Value = " "
            Next

            celdaLiquidarDoc4.Text = vbEmpty

        End If
        TotalesNotasDeDebito()
    End Sub

    Private Sub checkActualCheques_CheckedChanged(sender As Object, e As EventArgs) Handles checkActualCheques.CheckedChanged
        Dim i As Integer = vbEmpty

        If checkActualCheques.Checked = True Then
            For i = vbEmpty To dgActCheques.RowCount - 1
                dgActCheques.Rows(i).Cells(0).Value = "x"
            Next

            TotalLiquidacion = vbEmpty
            dblSumar = vbEmpty
            CalculoCargarSeleccion(dgActCheques, ID_CHEQUE)

            'Select Case ID_CHEQUE
            '    Case ID_CHEQUE, ID_DEBITO
            '        dblSumar = dblSumar * (-1)
            '    Case ID_DEPOSITO, ID_CREDITO
            '        dblSumar = dblSumar
            'End Select

            TotalLiquidacion = TotalLiquidacion + dblSumar
            celdaLiquidarActual.Text = TotalLiquidacion.ToString(FORMATO_MONEDA)

        Else
            For i = vbEmpty To dgActCheques.RowCount - 1
                dgActCheques.Rows(i).Cells(0).Value = " "
            Next

            celdaLiquidarActual.Text = vbEmpty

        End If
        TotaleCheques()
    End Sub

    Private Sub checkActualDepositos_CheckedChanged(sender As Object, e As EventArgs) Handles checkActualDepositos.CheckedChanged
        Dim SumarDepositos As Double = 0

        If checkActualDepositos.Checked = True Then
            For i = vbEmpty To dgActDepositos.RowCount - 1
                dgActCheques.Rows(i).Cells(0).Value = "x"
            Next

            TotalLiquidacion = vbEmpty
            dblSumar = vbEmpty
            CalculoCargarSeleccion(dgActDepositos, ID_DEPOSITO)

            'Select Case ID_DEPOSITO
            '    Case ID_CHEQUE, ID_DEBITO
            '        dblSumar = dblSumar * (-1)
            '    Case ID_DEPOSITO, ID_CREDITO
            '        dblSumar = dblSumar
            'End Select

            TotalLiquidacion = TotalLiquidacion + dblSumar
            celdaLiquidarActual2.Text = TotalLiquidacion.ToString(FORMATO_MONEDA)

        Else
            For i = vbEmpty To dgActDepositos.RowCount - 1
                dgActDepositos.Rows(i).Cells(0).Value = " "
            Next

            celdaLiquidarActual2.Text = vbEmpty

        End If
        TotalesDepositos()
    End Sub

    Private Sub checkActualCreditNotes_CheckedChanged(sender As Object, e As EventArgs) Handles checkActualDepositos.CheckedChanged

        Dim i As Integer = vbEmpty

        If checkActualCreditNotes.Checked = True Then
            For i = vbEmpty To dgActNotCredit.RowCount - 1
                dgActNotCredit.Rows(i).Cells(0).Value = "x"
            Next

            TotalLiquidacion = vbEmpty
            dblSumar = vbEmpty
            CalculoCargarSeleccion(dgActNotCredit, ID_CREDITO)

            Select Case ID_CREDITO
                Case ID_CHEQUE, ID_DEBITO
                    dblSumar = dblSumar * (-1)
                Case ID_DEPOSITO, ID_CREDITO
                    dblSumar = dblSumar
            End Select


            TotalLiquidacion = TotalLiquidacion + dblSumar
            celdaLiquidarActual3.Text = TotalLiquidacion.ToString(FORMATO_MONEDA)
        Else
            For i = vbEmpty To dgActNotCredit.RowCount - 1
                dgActNotCredit.Rows(i).Cells(0).Value = " "
            Next

            celdaLiquidarActual3.Text = vbEmpty

        End If
    End Sub

    Private Sub checkActualDebitNotes_CheckedChanged(sender As Object, e As EventArgs) Handles checkActualDepositos.CheckedChanged

        Dim i As Integer = vbEmpty

        If checkActualDebitNotes.Checked = True Then
            For i = vbEmpty To dgActNoteDebit.RowCount - 1
                dgActNoteDebit.Rows(i).Cells(0).Value = "x"
            Next

            TotalLiquidacion = vbEmpty
            dblSumar = vbEmpty
            CalculoCargarSeleccion(dgActNoteDebit, ID_DEBITO)

            Select Case ID_DEBITO
                Case ID_CHEQUE, ID_DEBITO
                    dblSumar = dblSumar * (-1)
                Case ID_DEPOSITO, ID_CREDITO
                    dblSumar = dblSumar
            End Select


            TotalLiquidacion = TotalLiquidacion + dblSumar
            celdaLiquidarActual4.Text = TotalLiquidacion.ToString(FORMATO_MONEDA)
        Else
            For i = vbEmpty To dgActNotCredit.RowCount - 1
                dgActNotCredit.Rows(i).Cells(0).Value = " "
            Next

            celdaLiquidarActual4.Text = vbEmpty

        End If
    End Sub

    Private Sub SaldoContabilidad()
        Dim Saldo1 As Double
        Dim Saldo2 As Double
        Dim Op As Integer
        Dim opt As New frmOption

        Saldo1 = SQLContabilidadAccountBalance(vbEmpty)
        Saldo2 = SQLContabilidadAccountBalance(1)

        If Not (Saldo1.ToString(FORMATO_MONEDA) = Saldo2.ToString(FORMATO_MONEDA)) Then
            MsgBox("By approximation methods, the following balances were found in accounting, " & vbNewLine & "Select the balance you want to use.", vbInformation, "Notice")

            opt.Titulo = "Option"
            opt.Mensaje = "Seleccione el Saldo que desea utilizar"
            opt.Opciones = Saldo1 & "|" & Saldo2

            opt.ShowDialog(frmSPrincipal)
            If opt.DialogResult = System.Windows.Forms.DialogResult.OK Then
                Op = opt.Seleccion
            End If
        Else
            Op = 1
        End If

        Select Case Op
            Case 0
                celdaSaldoFinalConta.Text = Saldo1.ToString(FORMATO_MONEDA)
                celdaSaldoFinalConta.Text = Replace(celdaSaldoFinalConta.Text, " ", "")
            Case 1
                celdaSaldoFinalConta.Text = Saldo2.ToString(FORMATO_MONEDA)
                celdaSaldoFinalConta.Text = Replace(celdaSaldoFinalConta.Text, " ", "")
        End Select
    End Sub

    Private Sub CalcularTotales()

        dblTotal = dblBanco

        dblTotal = 0 - celdaLiquidarPendientes.Text + celdaLiquidarPendientes2.Text - celdaLiquidarPendientes3.Text + celdaLiquidarPendientes4.Text

        dblTotal = 0 - celdaLiquidarActual.Text + celdaLiquidarActual2.Text - celdaLiquidarActual3.Text + celdaLiquidarActual4.Text

        dblTotal = 0 - celdaLiquidarDoc.Text + celdaLiquidarDoc2.Text - celdaLiquidarDoc3.Text + celdaLiquidarDoc4.Text

    End Sub

    Private Sub checkActualCreditNotes_CheckedChanged_1(sender As Object, e As EventArgs) Handles checkActualCreditNotes.CheckedChanged
        Dim SumarNC As Double = 0

        If checkActualCreditNotes.Checked = True Then
            For i = vbEmpty To dgActNotCredit.RowCount - 1
                dgActNotCredit.Rows(i).Cells(0).Value = "x"
            Next

            TotalLiquidacion = vbEmpty
            dblSumar = vbEmpty
            CalculoCargarSeleccion(dgActNotCredit, ID_CREDITO)

            'Select Case ID_CREDITO
            '    Case ID_CHEQUE, ID_DEBITO
            '        dblSumar = dblSumar * (-1)
            '    Case ID_DEPOSITO, ID_CREDITO
            '        dblSumar = dblSumar
            'End Select

            TotalLiquidacion = TotalLiquidacion + dblSumar
            celdaLiquidarDoc3.Text = TotalLiquidacion.ToString(FORMATO_MONEDA)

        Else
            For i = vbEmpty To dgActNotCredit.RowCount - 1
                dgActNotCredit.Rows(i).Cells(0).Value = " "
            Next

            celdaLiquidarDoc3.Text = vbEmpty

        End If
        TotalesNotasDeCredito()
    End Sub

    Private Sub checkActualDebitNotes_CheckedChanged_1(sender As Object, e As EventArgs) Handles checkActualDebitNotes.CheckedChanged
        Dim i As Integer = vbEmpty

        If checkActualDebitNotes.Checked = True Then
            For i = vbEmpty To dgActNoteDebit.RowCount - 1
                dgActNoteDebit.Rows(i).Cells(0).Value = "x"
            Next

            TotalLiquidacion = vbEmpty
            dblSumar = vbEmpty
            CalculoCargarSeleccion(dgActNoteDebit, ID_DEBITO)

            'Select Case ID_DEBITO
            '    Case ID_CHEQUE, ID_DEBITO
            '        dblSumar = dblSumar * (-1)
            '    Case ID_DEPOSITO, ID_CREDITO
            '        dblSumar = dblSumar
            'End Select

            TotalLiquidacion = TotalLiquidacion + dblSumar
            celdaLiquidarDoc4.Text = TotalLiquidacion.ToString(FORMATO_MONEDA)

        Else
            For i = vbEmpty To dgActNoteDebit.RowCount - 1
                dgActNoteDebit.Rows(i).Cells(0).Value = " "
            Next

            celdaLiquidarDoc4.Text = vbEmpty

        End If
        TotalesNotasDeDebito()
    End Sub

    Private Sub botonGuardar_Click(sender As Object, e As EventArgs) Handles botonGuardar.Click
        Dim strSQL As String = STR_VACIO
        intGuardarConciliacion = NO_FILA
        If ExisteConciliacion() = True Then
            MsgBox("The conciliation of " & cFunciones.MesIngles(Month(FechaInicio)) & "/" & Year(FechaInicio) & " it was already done.", vbInformation, "Notice")
            Exit Sub
        End If

        If Not Format(Val(Trim(celdaSaldoFinalBank.Text)), FORMATO_MONEDA) = (celdaTotal.Text) Then
            If MsgBox("Bank balances do not match." & vbCrLf & "do you wish to continue?", vbYesNo, "Notice") = vbNo Then
                Exit Sub
            End If
        End If

        ImprimirConciliacion(INT_UNO)
        If intGuardarConciliacion <> NO_FILA Then
            MsgBox("Balances do not reconcile", vbInformation)
            Exit Sub
        End If
        If MsgBox("that make the reconciliation of " & cFunciones.MesIngles(Month(FechaInicio)) & " " & Year(FechaInicio) & "?", vbQuestion + vbYesNo, "Bank Conciliation") = vbYes Then
            intNumConciliacion = cFunciones.NuevoId(257, Year(FechaInicio))

            GuardarEncabezado()
            intLinea = 0
            '//Documentos Actuales
            For i As Integer = 0 To 3
                Select Case i
                    Case 0
                        CategoriaDoc = 51 'Cheque
                        StatusDoc = 1
                        strNombreDG = dgDocCheques
                    Case 1
                        CategoriaDoc = 54 'Depósitos
                        StatusDoc = 1
                        strNombreDG = dgDocDepositos
                    Case 2
                        CategoriaDoc = 53 'Nota de Credito
                        StatusDoc = 1
                        strNombreDG = dgDocNotasCredit
                    Case 3
                        CategoriaDoc = 52 'Nota de Debito
                        StatusDoc = 1
                        strNombreDG = dgDocNotDebit
                End Select

                RecorrerDatagridParaGuardar(strNombreDG, CategoriaDoc, StatusDoc, 1, 0)

            Next

            '//Documentos Pendientes
            For i As Integer = 0 To 3
                Select Case i
                    Case 0
                        CategoriaDoc = 51 'Cheque
                        StatusDoc = 1
                        strNombreDG = dgPenCheques
                    Case 1
                        CategoriaDoc = 54 'Depósitos
                        StatusDoc = 1
                        strNombreDG = dgPenDepositos
                    Case 2
                        CategoriaDoc = 53 'Nota de Credito
                        StatusDoc = 1
                        strNombreDG = dgPenNotasCredito
                    Case 3
                        CategoriaDoc = 52 'Nota de Debito
                        StatusDoc = 1
                        strNombreDG = dgPenNotasDebit
                End Select

                RecorrerDatagridParaGuardar(strNombreDG, CategoriaDoc, StatusDoc, 0, 0)

            Next

            '//Documentos del siguiente mes
            For i As Integer = 0 To 3
                Select Case i
                    Case 0
                        CategoriaDoc = 51 'Cheque
                        StatusDoc = 1
                        strNombreDG = dgActCheques
                    Case 1
                        CategoriaDoc = 54 'Depósitos
                        StatusDoc = 1
                        strNombreDG = dgActDepositos
                    Case 2
                        CategoriaDoc = 53 'Nota de Credito
                        StatusDoc = 1
                        strNombreDG = dgActNotCredit
                    Case 3
                        CategoriaDoc = 52 'Nota de Debito
                        StatusDoc = 1
                        strNombreDG = dgActNoteDebit
                End Select

                RecorrerDatagridParaGuardar(strNombreDG, CategoriaDoc, StatusDoc, 2, 1)

            Next

            MsgBox("Conciliation completed successfully.", vbInformation, "Notice")
            MostrarDocumentosConciliación(1)
            LimpiarCheck()
        End If

    End Sub

    Private Sub RecorrerDatagridParaGuardar(ByVal dg As DataGridView, ByVal cat As Integer, ByVal estado As Integer, ByVal estadoDoc As Integer, Optional tipoDoc As Integer = 0)
        Dim strSQL As String = STR_VACIO
        Dim COM As MySqlCommand
        Dim contLine As Integer = 0
        Try
            If dg.Rows.Count = 0 Then
                Exit Sub
            End If

            strSQL = " SELECT IFNULL(MAX(d.DDoc_Doc_Lin),0) line FROM Dcmtos_DTL d "
            strSQL &= " WHERE d.DDoc_Sis_Emp = {emp} And d.DDoc_Doc_Cat = 257 And d.DDoc_Doc_Ano = {anio} And d.DDoc_Doc_Num = {num} "

            strSQL = Replace(strSQL, "{emp}", Sesion.IdEmpresa)
            strSQL = Replace(strSQL, "{anio}", Year(FechaInicio))
            strSQL = Replace(strSQL, "{num}", intNumConciliacion)

            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSQL, CON)
            contLine = COM.ExecuteScalar

            COM.Dispose()
            COM = Nothing
            strSQL = STR_VACIO

            For j As Integer = 0 To dg.Rows.Count - 1
                If dg.Rows(j).Cells(0).Value = "x" Then

                    strSQL = " UPDATE Dcmtos_HDR SET HDoc_DR1_Fec = '{final}', HDoc_DR2_Fec = '{actual}', HDoc_RF2_Cod = {idBanco}, HDoc_Doc_Status = {status} "
                    strSQL &= "   WHERE HDoc_Sis_Emp = {emp} AND HDoc_Doc_Cat = {cat} AND HDoc_Doc_Ano = {anio} AND HDoc_Doc_Num = {num} "
                    If Sesion.IdEmpresa = 18 Then
                        strSQL &= "; UPDATE PDM.Dcmtos_HDR SET HDoc_DR1_Fec = '{final}', HDoc_DR2_Fec = '{actual}', HDoc_RF2_Cod = {idBanco}, HDoc_Doc_Status = {status} "
                        strSQL &= "   WHERE HDoc_Sis_Emp = {emp} AND HDoc_Doc_Cat = {cat} AND HDoc_Doc_Ano = {anio} AND HDoc_Doc_Num = {num} "
                    End If
                    strSQL = Replace(strSQL, "{emp}", Sesion.IdEmpresa)
                    strSQL = Replace(strSQL, "{cat}", cat)
                    strSQL = Replace(strSQL, "{anio}", dg.Rows(j).Cells(5).Value)
                    strSQL = Replace(strSQL, "{num}", dg.Rows(j).Cells(4).Value)
                    strSQL = Replace(strSQL, "{status}", estado)
                    strSQL = Replace(strSQL, "{idBanco}", intBanco)
                    strSQL = Replace(strSQL, "{actual}", cFunciones.HoyMySQL.ToString(FORMATO_MYSQL))
                    strSQL = Replace(strSQL, "{final}", FechaFin.ToString(FORMATO_MYSQL))

                    MyCnn.CONECTAR = strConexion
                    COM = New MySqlCommand(strSQL, CON)
                    COM.ExecuteNonQuery()

                    COM.Dispose()
                    COM = Nothing
                    strSQL = STR_VACIO
                Else

                    If tipoDoc = 0 Then
                        contLine = contLine + 1
                        GuardarDetalle(cat, dg.Rows(j).Cells(5).Value, dg.Rows(j).Cells(4).Value, contLine, estadoDoc)

                    End If
                End If
            Next
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub RecorrerDatagridParaImpresion(ByVal catDoc As Integer, ByVal dg As DataGridView, ByVal f As Byte, ByVal logEncabezado As Boolean, ByVal k As Integer, ByVal strConcepto As String, Optional Total As Integer = 0, Optional intTipoImpresion_ As Integer = 0)

        Dim strSQL As String = STR_VACIO
        Dim dblTotalImp As Double = 0

        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader
        dblParcial = 0
        logEncabezado = False
        For i As Integer = 0 To dg.Rows.Count - 1
            If Total >= 1 Then
                If dg.Rows(i).Cells(0).Value = "x" Then
                    dblParcial = 0
                    logEncabezado = False
                    If logEncabezado = False Then

                        Print(f, "<tr>")
                        Print(f, "<td></td>")
                        Print(f, "<td colspan=3><b>" & strConcepto & "</b></td>")
                        Print(f, "<td></td>")
                        Print(f, "<td></td>")
                        Print(f, "</tr>")
                        logEncabezado = True
                    End If

                    strSQL = " SELECT h.HDoc_Doc_Fec FechaDoc, h.HDoc_DR1_Num NumeroDoc, IF(h.HDoc_Emp_Nom = '',h.HDoc_Emp_Per,h.HDoc_Emp_Nom) Nombre, h.HDoc_RF1_Dbl Monto "
                    strSQL &= "    From Dcmtos_HDR h "
                    strSQL &= "    WHERE h.HDoc_Sis_Emp = {emp} AND h.HDoc_Doc_Cat = {cat} AND h.HDoc_Doc_Ano = {anio} AND h.HDoc_Doc_Num = {num} "

                    strSQL = Replace(strSQL, "{emp}", Sesion.IdEmpresa)
                    strSQL = Replace(strSQL, "{cat}", catDoc)
                    strSQL = Replace(strSQL, "{anio}", dg.Rows(i).Cells(5).Value)
                    strSQL = Replace(strSQL, "{num}", dg.Rows(i).Cells(4).Value)

                    MyCnn.CONECTAR = strConexion
                    COM = New MySqlCommand(strSQL, CON)
                    REA = COM.ExecuteReader

                    If REA.HasRows Then
                        Do While REA.Read

                            Print(f, "<tr>")
                            Print(f, "<td>" & Format(REA.GetDateTime("FechaDoc").ToString(FORMATO_MYSQL)) & "</td>")
                            Print(f, "<td>" & REA.GetString("NumeroDoc") & "</td>")
                            Print(f, "<td class='izquierda'>" & REA.GetString("Nombre") & "</td>")


                            Select Case catDoc
                                Case 51, 52 'Cheque y nota de Dédito
                                    Print(f, "<td>(" & Format(REA.GetDouble("Monto"), FMT_MSO_CANTIDAD) & ")</td>")
                                    dblTotalConta = dblTotal - REA.GetDouble("Monto")

                                Case 53, 54 'Nota de Crédit, Depósitos
                                    Print(f, "<td>" & Format(REA.GetDouble("Monto"), FMT_MSO_CANTIDAD) & "</td>")
                                    dblTotalConta = dblTotal - REA.GetDouble("Monto")

                            End Select
                            dblParcial = dblParcial + REA.GetDouble("Monto")
                        Loop

                    End If

                End If
            Else
                If Not dg.Rows(i).Cells(0).Value = "x" Then

                    If logEncabezado = False Then

                        Print(f, "<tr>")
                        Print(f, "<td></td>")
                        Print(f, "<td colspan=3><b>" & strConcepto & "</b></td>")
                        Print(f, "<td></td>")
                        Print(f, "<td></td>")
                        Print(f, "</tr>")
                        logEncabezado = True
                    End If

                    strSQL = " SELECT h.HDoc_Doc_Fec FechaDoc, h.HDoc_DR1_Num NumeroDoc, IF(h.HDoc_Emp_Nom = '',h.HDoc_Emp_Per,h.HDoc_Emp_Nom) Nombre, h.HDoc_RF1_Dbl Monto "
                    strSQL &= "    From Dcmtos_HDR h "
                    strSQL &= "    WHERE h.HDoc_Sis_Emp = {emp} AND h.HDoc_Doc_Cat = {cat} AND h.HDoc_Doc_Ano = {anio} AND h.HDoc_Doc_Num = {num} "

                    strSQL = Replace(strSQL, "{emp}", Sesion.IdEmpresa)
                    strSQL = Replace(strSQL, "{cat}", catDoc)
                    strSQL = Replace(strSQL, "{anio}", dg.Rows(i).Cells(5).Value)
                    strSQL = Replace(strSQL, "{num}", dg.Rows(i).Cells(4).Value)

                    MyCnn.CONECTAR = strConexion
                    COM = New MySqlCommand(strSQL, CON)
                    REA = COM.ExecuteReader

                    If REA.HasRows Then
                        Do While REA.Read

                            Print(f, "<tr>")
                            Print(f, "<td>" & Format(REA.GetDateTime("FechaDoc").ToString(FORMATO_MYSQL)) & "</td>")
                            Print(f, "<td>" & REA.GetString("NumeroDoc") & "</td>")
                            Print(f, "<td class='izquierda'>" & REA.GetString("Nombre") & "</td>")


                            Select Case catDoc
                                Case 51, 52 'Cheque y nota de Dédito
                                    Print(f, "<td>(" & Format(REA.GetDouble("Monto"), FMT_MSO_CANTIDAD) & ")</td>")
                                    dblTotal = dblTotal - REA.GetDouble("Monto")

                                Case 53, 54 'Nota de Crédit, Depósitos
                                    Print(f, "<td>" & Format(REA.GetDouble("Monto"), FMT_MSO_CANTIDAD) & "</td>")
                                    dblTotal = dblTotal + REA.GetDouble("Monto")
                            End Select
                            dblParcial = dblParcial + REA.GetDouble("Monto")
                            Print(f, "<td></td>")
                            Print(f, "<td></td>")
                            Print(f, "</tr>")
                        Loop

                    End If

                End If
            End If

        Next

        If dblParcial > 0 Then


            Print(f, "<tr style='background-color: Silver'>")
            Print(f, "<td colspan=3><b>TOTAL</b></td>")
            Print(f, "<td>-</td>")
            Print(f, "<td>-</td>")

            Select Case k
                Case 0, 3
                    Print(f, "<td><b>(" & Format(dblParcial, FMT_MSO_CANTIDAD) & ")</b></td>")
                Case 1, 2
                    Print(f, "<td><b>" & Format(dblParcial, FMT_MSO_CANTIDAD) & "</b></td>")
            End Select
        End If
        dblParcial = INT_CERO
        logEncabezado = False

        If Total = 1 And intTipoImpresion_ = INT_UNO Then
            Print(f, "<tr style='border: none'>")
            Print(f, "<td colspan=4><b>SUMAS</b></td>")
            Print(f, "<td style='background-color: Silver'><b>" & Format((celdaSaldoFinalConta.Text + dblTotalConta), FMT_MSO_CANTIDAD) & "</b></td>")
            Print(f, "<td style='background-color: Silver'><b>" & Format((celdaSaldoFinalBank.Text + (dblTotal)), FMT_MSO_CANTIDAD) & " </b></td>")
            If intTipoImpresion_ = INT_UNO Then
                If Format((celdaSaldoFinalConta.Text + dblTotalConta), FMT_MSO_CANTIDAD) <> Format((celdaSaldoFinalBank.Text + (dblTotal)), FMT_MSO_CANTIDAD) Then
                    intGuardarConciliacion = INT_UNO
                End If
            End If
        End If
    End Sub

    Private Sub botonImprimir_Click(sender As Object, e As EventArgs) Handles botonImprimir.Click
        If Not Val(Trim(celdaSaldoFinalBank.Text)) = Val(celdaTotal.Text) Then
            If MsgBox("Bank balances do not match." & vbCrLf & "do you wish to continue?", vbYesNo, "Notice") = vbNo Then
                Exit Sub
            End If
            ImprimirConciliacion()
        Else
            ImprimirConciliacion()
        End If

    End Sub

#Region "ImprimirConciliaciActual"

    Private Function EncabezadoConciliacion()
        Dim strSQL As String = STR_VACIO

        strSQL = " SELECT l.cat_desc nombre, c.cat_desc Moneda, b.BCta_Tip_Cue Tipo, b.BCta_Num_Cue Cuenta "
        strSQL &= "    FROM CtasBcos b "
        strSQL &= "    LEFT JOIN Catalogos c ON c.cat_num = b.BCta_Mon "
        strSQL &= "    LEFT JOIN Catalogos l ON l.cat_num = b.BCta_Cod_Ban "
        strSQL &= "        WHERE b.BCta_Sis_Emp = {empresa} AND b.BCta_Num = {banco} "

        strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
        strSQL = Replace(strSQL, "{banco}", intBanco)

        Return strSQL
    End Function

    Public Sub ImprimirConciliacion(Optional intTipoImpresion As Integer = 0)
        Dim STR_TITULO As String = STR_VACIO

        Dim strTemp As String
        Dim strSQL As String = STR_VACIO
        Dim strConcepto As String = STR_VACIO
        Dim strRazon As String
        Dim intFinDoc As Integer = 0


        Dim dblParcial As Double
        Dim dblContabilidad As Double = 0
        Dim dblBancos As Double = 0
        Dim strMonedaCheq As String = STR_VACIO
        Dim strMoneda As String = STR_VACIO
        Dim logEncabezado As Boolean = False
        Dim REA As MySqlDataReader
        Dim COM As MySqlCommand
        Dim rpt As New clsReportes
        Dim intTipoDocumento As Integer = 0
        Dim f As Byte
        Try

            Dim intLinea As Integer

            STR_TITULO = "Conciliacion Bancaria"
            strTemp = cFunciones.ArchivoTemporal
            f = FreeFile()
            FileOpen(f, strTemp, OpenMode.Append)
            Print(f, "<html>")
            Print(f, "<head>")
            Print(f, "<title>" & STR_TITULO & "</title>")
            Print(f, "<style type='text/css'>")
            Print(f, " table {table-layout: fixed; empty-cells: show; border-collapse:collapse}")
            Print(f, " caption {padding: 5px; text-align:left; font-family: Tahoma, Arial;font-size: 8pt}")
            Print(f, " th {width: 1.8cm; border:solid Gray 1px; background-color: Black; color: White; padding:2px 5px; font-family: Tahoma, Arial;font-size: 7pt}")
            Print(f, " td {text-align:center;border:solid Gray 1px; padding:3px 5px; font-family: Tahoma, Arial;font-size: 7pt}")
            Print(f, " td.numero {text-align:right; mso-number-format:\#\,\#\#0\.00}")
            Print(f, " td.unitario {text-align:right; mso-number-format:\#\,\#\#0\.00#####}")
            Print(f, " .titulo {font-family: Tahoma, Arial;font-size: 9pt}")
            Print(f, " .subtitulo {font-family: Tahoma, Arial;font-size: 7pt}")
            Print(f, " .datos {text-align:left; font-family: Tahoma; font-size: 8pt}")
            Print(f, " .encabezado {text-align: left; border: none; width: 3.1cm}")
            Print(f, " .pie {font-family: Tahoma, Arial;font-size: 7pt}")
            Print(f, " .izquierda {text-align:left}")
            Print(f, " .centro {text-align:center}")
            Print(f, " .derecha {text-align:right}")
            Print(f, " .info {text-align:left; border:none}")
            Print(f, " .color {text-align:left; width: 1.8cm; border:solid Gray 1px; background-color: White; color: Black; padding:2px 5px; font-family: Tahoma, Arial;font-size: 7pt}")
            Print(f, " .colornumero {text-align:center; width: 1.8cm; border:solid Gray 1px; background-color: White; color: Black; padding:2px 5px; font-family: Tahoma, Arial;font-size: 7pt}")
            Print(f, "</style>")
            Print(f, "</head>")
            Print(f, "<body>")

            Print(f, "<table style ='width: 18cm'>")
            Print(f, "<tr><td style='border: none'><center>")
            Print(f, "<span class='titulo'><b>" & Sesion.Empresa & "</b></span><br/><br/>")
            Print(f, "</center></td></tr>")
            intNumConciliacion = cFunciones.NuevoId(257)
            strSQL = EncabezadoConciliacion()
            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSQL, CON)
            REA = COM.ExecuteReader
            If REA.HasRows Then
                Do While REA.Read

                    Print(f, "<tr><td style='border: none'><center>")
                    Print(f, "<span class='titulo'><b>" & UCase(STR_TITULO) & "</b></span><br/>")
                    Print(f, "</center></td></tr>")
                    Print(f, "<tr><td style='border: none'><center>")
                    Print(f, "<span class='titulo'><b>" & UCase(REA.GetString("nombre")) & "</b></span><br/>")
                    Print(f, "</center></td></tr>")
                    Print(f, "<tr><td style='border: none'><center>")
                    Print(f, "<span class='titulo'><b>CUENTA EN " & UCase(REA.GetString("Moneda")) & " </b></span><br/>")
                    Print(f, "</center></td></tr>")
                    Print(f, "<tr><td style='border: none'><center>")
                    Print(f, "<span class='titulo'><b>" & UCase(cFunciones.MesALetras(Month(dtpInicio.Value.ToString(FORMATO_MYSQL)))) & " " & UCase(Year(dtpInicio.Value.ToString(FORMATO_MYSQL))) & " </b></span><br/>")
                    Print(f, "</center></td></tr>")
                    Print(f, "<tr><td style='border: none'><center>")
                    Print(f, "<span class='subtitulo'>Impreso: " & DateTime.Now.ToString(FORMATO_MYSQL) & " " & Now.ToString("hh:mm:ss") & "</span><br/>")
                    Print(f, "</center></td></tr>")
                    Print(f, "</table>")
                    Print(f, "</br>")
                    Print(f, "<span class='datos'><b>Tipo " & REA.GetString("Tipo") & "</b></span></br>")
                    Print(f, "<span class='datos'><b>Cuenta No. " & REA.GetString("Cuenta") & "</b></span></br>")
                    intLinea = 1
                    Print(f, "</table>")
                    'Tabla de Encabezado
                    Print(f, "<table cellspacing=0>")
                    Print(f, "<tr>")
                    Print(f, "<th style='width: 2cm'>Fecha</th>")
                    Print(f, "<th style='width: 2cm'>No. Documento</th>")
                    Print(f, "<th style='width: 10cm'>Descripción</th>")
                    Print(f, "<th style='width: 2cm'>Monto</th>")
                    Print(f, "<th style='width: 3cm'>Saldo según Contabilidad</th>")
                    Print(f, "<th style='width: 3cm'>Saldo según Banco</th>")
                    Print(f, "</tr>")

                    dblContabilidad = celdaSaldoFinalConta.Text
                    dblBancos = celdaSaldoFinalBank.Text

                    Print(f, "<tr>")
                    Print(f, "<td colspan=4>Saldo del " & (dtpInicio.Value.Day) & " al " & (dtpInicio.Value.Day) & " de " & cFunciones.MesALetras(Month(dtpInicio.Value.ToString(FORMATO_MYSQL))) & " de " & Year(dtpInicio.Value.ToString(FORMATO_MYSQL)) & " </td>")
                    Print(f, "<td>" & Format(dblContabilidad, FMT_MSO_CANTIDAD) & "</td>")
                    Print(f, "<td>" & Format(dblBancos, FMT_MSO_CANTIDAD) & "</td>")
                    Print(f, "</tr>")
                Loop
                strSQL = STR_VACIO
                dblTotal = 0
                dblParcial = 0

                For k As Integer = 0 To 3
                    ' Documentos del mes anterior
                    Select Case k
                        Case 0
                            CategoriaDoc = 51 'Cheque
                            StatusDoc = 1
                            strNombreDG = dgPenCheques
                            strConcepto = "(-) (Mes Anterior) Cheques en circulación"
                        Case 1
                            CategoriaDoc = 54 'Depósitos
                            StatusDoc = 1
                            strNombreDG = dgPenDepositos
                            strConcepto = "(+) (Mes Anterior) Depositos en transito"
                        Case 2
                            CategoriaDoc = 53 'Nota de Credito
                            StatusDoc = 1
                            strNombreDG = dgPenNotasCredito
                            strConcepto = "(+) (Mes Anterior) Notas de Credito no operadas"
                        Case 3
                            CategoriaDoc = 52 'Nota de Debito
                            StatusDoc = 1
                            strNombreDG = dgPenNotasDebit
                            strConcepto = "(-) (Mes Anterior) Notas de Debito no operadas"
                    End Select

                    RecorrerDatagridParaImpresion(CategoriaDoc, strNombreDG, f, logEncabezado, k, strConcepto)

                Next
                strSQL = STR_VACIO
                dblParcial = INT_CERO
                logEncabezado = False

                ' Documentos del Mes Actual
                For k As Integer = 0 To 3
                    Select Case k
                        Case 0
                            CategoriaDoc = 51 'Cheque
                            StatusDoc = 1
                            strNombreDG = dgDocCheques
                            strConcepto = "(-) (Mes Actual) Cheques en circulación"
                        Case 1
                            CategoriaDoc = 54 'Depósitos
                            StatusDoc = 1
                            strNombreDG = dgDocDepositos
                            strConcepto = "(+) (Mes Actual) Depositos en transito"
                        Case 2
                            CategoriaDoc = 53 'Nota de Credito
                            StatusDoc = 1
                            strNombreDG = dgDocNotasCredit
                            strConcepto = "(+) (Mes Actual) Notas de Credito no operadas"
                        Case 3
                            CategoriaDoc = 52 'Nota de Debito
                            StatusDoc = 1
                            strNombreDG = dgDocNotDebit
                            strConcepto = "(-) (Mes Actual) Notas de Debito no operadas"
                    End Select
                    RecorrerDatagridParaImpresion(CategoriaDoc, strNombreDG, f, logEncabezado, k, strConcepto)
                Next
                strSQL = STR_VACIO
                dblParcial = INT_CERO
                logEncabezado = False
                ' Documentos del Mes Siguiente 
                For k As Integer = 0 To 3
                    Select Case k
                        Case 0
                            CategoriaDoc = 51 'Cheque
                            StatusDoc = 1
                            strNombreDG = dgActCheques
                            intFinDoc = 2
                            strConcepto = "(-) (Siguiente mes) Cheques en circulación"
                        Case 1
                            CategoriaDoc = 54 'Depósitos
                            StatusDoc = 1
                            strNombreDG = dgActDepositos
                            intFinDoc = 2
                            strConcepto = "(+) (Siguiente mes) Depositos en transito"
                        Case 2
                            CategoriaDoc = 53 'Nota de Credito
                            StatusDoc = 1
                            strNombreDG = dgActNotCredit
                            intFinDoc = 2
                            strConcepto = "(+) (Siguiente mes) Notas de Credito no operadas"
                        Case 3
                            CategoriaDoc = 52 'Nota de Debito
                            StatusDoc = 1
                            strNombreDG = dgActNoteDebit
                            intFinDoc = 1
                            strConcepto = "(-) (Siguiente mes) Notas de Debito no operadas"
                    End Select
                    RecorrerDatagridParaImpresion(CategoriaDoc, strNombreDG, f, logEncabezado, k, strConcepto, intFinDoc, INT_UNO)
                Next

                Print(f, "</tr>")
                Print(f, "</table>")
                'Datos para firma
                Print(f, "</br>")
                Print(f, "<span class='datos'><b></b></span></br>")
                Print(f, "<span class='datos'> <b>Hecho por:____________________________________________________________________ </span></br></br>")
                Print(f, "<span class='datos'> <b>Revisado por:_________________________________________________________________ </span></br></br>")
                Print(f, "</body>")
                Print(f, "</html>")
                FileClose(f)
                If intTipoImpresion = 0 Then
                    rpt.MostarReporte(strTemp, False)
                Else
                    strTemp = STR_VACIO
                End If

            End If

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try

    End Sub

    Private Sub celdaSaldoFinalBank_TextChanged(sender As Object, e As EventArgs) Handles celdaSaldoFinalBank.TextChanged
        If celdaSaldoFinalBank.Text <> "" Or celdaSaldoFinalBank.Text = Nothing Then
            Format(celdaSaldoFinalBank.Text, FORMATO_MONEDA)
        End If

    End Sub


#End Region

#End Region


End Class