﻿Public Class frmDevoluciones
#Region "Miembros"
    Dim strKey As String = STR_VACIO
    Dim logInsertar As Boolean = False
    Dim logConsultar As Boolean = False
    Dim logEditar As Boolean = False
    Dim LogBorrar As Boolean = False
    Const CAT_ORD As Integer = 777
    Dim cfun As New clsFunciones
    Dim intTipoDoc As Integer
    Dim SDoc As New frmSubDocumentos
    Dim Tbl_Documentos As String = "Dcmtos_HDR"
    Dim NotaDev As String

#End Region


#Region "Propiedades"
    Public Property Key As String
        Get
            Return strKey
        End Get
        Set(value As String)
            strKey = value
        End Set
    End Property
#End Region

#Region "Procedimientos"
    Private Sub BloquearBotones(Optional ByVal logBloquear As Boolean = True)
        If logBloquear = True Then
            Encabezado1.botonBorrar.Enabled = False
            Encabezado1.botonGuardar.Enabled = False
            botonImprimir.Enabled = False
            botonImprimirPackingList.Enabled = False
        Else
            Encabezado1.botonBorrar.Enabled = True
            Encabezado1.botonGuardar.Enabled = True
            botonImprimir.Enabled = True
            botonImprimirPackingList.Enabled = True

        End If

    End Sub


    Private Sub Accesos()
        Dim cAcesos As New clsAccesos

        Try
            If cAcesos.Accesos(strKey) = True Then
                logInsertar = cAcesos.Insertar
                logEditar = cAcesos.Editar
                LogBorrar = cAcesos.Borrar
                logConsultar = cAcesos.Consultar

            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub MostrarLista(Optional ByVal logMostrar As Boolean = True, Optional logInsert As Boolean = False)
        If logMostrar = True Then
            panelLista.Visible = True
            panelLista.Dock = DockStyle.Fill
            panelDetalle.Visible = False
            panelDetalle.Dock = DockStyle.None
            BarraTitulo1.CambiarTitulo("Devolutions")
            Encabezado1.botonBorrar.Enabled = False
            Encabezado1.botonGuardar.Enabled = False
            botonImprimir.Enabled = False
            botonImprimirPackingList.Enabled = False

            dtpInicial.Value = DateSerial(Year(Date.Now), Month(Date.Now) - 1, 30)
            dtpFinal.Value = DateSerial(Year(Date.Now), Month(Date.Now) + 1, vbEmpty)

            queryListaPrincipal()

        Else
            panelLista.Visible = False
            panelLista.Dock = DockStyle.None
            panelDetalle.Visible = True
            panelDetalle.Dock = DockStyle.Fill

            'Verifica si se va a crear un nuevo documento o se va modifica
            If logInsert = False Then
                BarraTitulo1.CambiarTitulo("Modify Registration")
                Me.Tag = "Mod"
                BloquearBotones(False)
                botonImprimir.Enabled = True
                botonImprimirPackingList.Enabled = True

            Else
                BarraTitulo1.CambiarTitulo("New Register")
                Me.Tag = "Nuevo"
                BloquearBotones(False)
                botonImprimir.Enabled = False
                botonImprimirPackingList.Enabled = False
                Encabezado1.botonBorrar.Enabled = False
                Encabezado1.botonGuardar.Enabled = False
                Reset()
            End If

        End If

    End Sub

    Private Function SQLDatosFactura(ByVal numero As Integer, ByVal anio As Integer)
        Dim strSql As String = STR_VACIO

        strSql = " select c.cli_cliente Cliente from Dcmtos_DTL_Pro p "
        strSql &= " Left join Dcmtos_DTL_Pro po on po.PDoc_Sis_Emp = p.PDoc_Sis_Emp and po.PDoc_Chi_Cat = p.PDoc_Par_Cat and po.PDoc_Chi_Ano = p.PDoc_Par_Ano and po.PDoc_Chi_Num = p.PDoc_Par_Num and po.PDoc_Chi_Lin = p.PDoc_Par_Lin  and po.PDoc_Par_Cat = 75 "
        strSql &= " Left join Dcmtos_HDR h on h.HDoc_Sis_Emp = po.PDoc_Sis_Emp and h.HDoc_Doc_Cat = po.PDoc_Par_Cat and h.HDoc_Doc_Ano = po.PDoc_Par_Ano and h.HDoc_Doc_Num = po.PDoc_Par_Num  "
        strSql &= " Left join Clientes c on c.cli_sisemp = h.HDoc_Sis_Emp and c.cli_codigo = h.HDoc_DR1_Emp  "
        strSql &= " where p.PDoc_Sis_Emp = {empresa} and p.PDoc_Chi_Cat = 36 and p.PDoc_Chi_Ano = 2016 and p.PDoc_Chi_Num = {numero} "
        strSql &= " group by c.cli_sisemp , c.cli_codigo  "

        strSql = Replace(strSql, "{empresa}", Sesion.IdEmpresa)
        strSql = Replace(strSql, "{numero}", numero)
        strSql = Replace(strSql, "{anio}", anio)

        Return strSql

    End Function

    Private Function SQLDetalle(ByVal numero As String, ByVal anio As Integer)
        Dim strSql As String = STR_VACIO

        strSql = " SELECT d.DDoc_Sis_Emp empresa, d.DDoc_Doc_Cat catalogo, d.DDoc_Doc_Ano anioFactura, d.DDoc_Prd_Cod Codigo, d.DDoc_Prd_Des Descripcion, d.DDoc_Doc_Num Factura, d.DDoc_Doc_Lin Linea, d.DDoc_Prd_UM IdMedida, d.DDoc_Prd_PUQ Precio, d.DDoc_RF1_Txt Referencia, cat_clave Medida, IFNULL(inv.inv_prodlote, ' ') LoteFisico, a.art_DCorta DCorta"
        strSql &= "     FROM Dcmtos_DTL d"
        strSql &= "         LEFT JOIN Catalogos ON cat_num = d.DDoc_Prd_UM"
        strSql &= "              LEFT JOIN Inventarios inv ON inv.inv_numero = d.DDoc_Prd_Cod AND inv.inv_prodano = d.DDoc_Doc_Ano"
        strSql &= "          LEFT JOIN Inventarios inve ON inve.inv_sisemp = d.DDoc_Sis_Emp AND inve.inv_numero = d.DDoc_Prd_Cod"
        strSql &= "     LEFT JOIN Articulos a ON a.art_sisemp = inve.inv_sisemp AND a.art_codigo = inve.inv_artcodigo"
        strSql &= " WHERE d.DDoc_Sis_Emp ={empresa} and d.DDoc_Doc_Cat = 36 and d.DDoc_Doc_Num IN({numero}) and d.DDoc_Doc_Ano = {anio} "

        strSql = Replace(strSql, "{empresa}", Sesion.IdEmpresa)
        strSql = Replace(strSql, "{numero}", numero)
        strSql = Replace(strSql, "{anio}", anio)

        Return strSql

    End Function

    Private Function SqlSubDocumento(ByVal numero As Integer, ByVal anio As Integer)
        Dim strSql As String = STR_VACIO

        strSql = " SELECT cat_clave, cat_desc, ( "
        strSql &= " Select COUNT(*) "
        strSql &= " From Dcmtos_ACC "
        strSql &= " WHERE ADoc_Sis_Emp = {empresa} AND ADoc_Doc_Cat = 490 AND ADoc_Doc_Ano = {anio} AND ADoc_Doc_Num = {numero} AND ADoc_Doc_Sub = cat_clave) Cantidad "
        strSql &= " From Catalogos "
        strSql &= " WHERE cat_clase = 'SubDcmtos' AND cat_sist = 'Doc_RADevolucion' "
        strSql &= " ORDER BY cat_clave "

        strSql = Replace(strSql, "{empresa}", Sesion.IdEmpresa)
        strSql = Replace(strSql, "{anio}", anio)
        strSql = Replace(strSql, "{numero}", numero)

        Return strSql

    End Function

    Public Sub QueryDatosFactura(ByVal numero As Integer, ByVal anio As Integer)
        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader
        Dim strSQL As String = STR_VACIO

        strSQL = SQLDatosFactura(numero, anio)

        Try
            MyCnn.CONECTAR = strConexion

            COM = New MySqlCommand(strSQL, CON)
            REA = COM.ExecuteReader

            If REA.HasRows Then

                Do While REA.Read
                    celdaSolicitante.Text = REA.GetString("Cliente")
                Loop
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Public Sub QueryDetalle(ByVal numero As String, ByVal anio As Integer)
        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader
        Dim strSQL As String = STR_VACIO
        Dim strFila As String = STR_VACIO
        Dim contador As Integer = 0

        strSQL = SQLDetalle(numero, anio)

        Try
            MyCnn.CONECTAR = strConexion

            COM = New MySqlCommand(strSQL, CON)
            REA = COM.ExecuteReader

            If REA.HasRows Then

                Do While REA.Read
                    strFila = REA.GetInt32("empresa") & "|"
                    strFila &= REA.GetInt32("catalogo") & "|"
                    strFila &= REA.GetInt32("anioFactura") & "|"
                    strFila &= REA.GetInt32("Codigo") & "|"
                    strFila &= REA.GetString("DCorta") & "|"
                    strFila &= REA.GetInt32("Factura") & "|"
                    strFila &= REA.GetInt32("Linea") & "|"
                    strFila &= 0 & "|"
                    strFila &= REA.GetInt32("IdMedida") & "|"
                    strFila &= REA.GetString("Medida") & "|"
                    strFila &= REA.GetString("LoteFisico") & "|"
                    strFila &= "" & "|"
                    strFila &= 0 & "|"
                    If REA.GetInt32("IdMedida") = 69 Then
                        strFila &= REA.GetDouble("Precio") & "|"
                        strFila &= 0 & "|"
                    Else
                        strFila &= 0 & "|"
                        strFila &= REA.GetDouble("Precio") & "|"

                    End If
                    strFila &= 0 & "|"
                    strFila &= 0 & "|"
                    strFila &= REA.GetString("Referencia") & "|"
                    strFila &= "" & "|"
                    strFila &= 0

                    cFunciones.AgregarFila(DgDetalle, strFila)
                Loop


                For i As Integer = vbEmpty To DgDetalle.Rows.Count - 1
                    'If DgDetalle.Rows(i).Visible = True Then
                    contador = contador + 1
                    DgDetalle.Rows(i).Cells("colLineaDevolucion").Value = contador
                    'End If
                Next
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try

    End Sub

    Public Sub NuevoDetalle()
        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader
        Dim strSql As String = STR_VACIO
        Dim strFila As String = STR_VACIO
        Dim contador As Integer = 0
        Dim strTEMP As String = STR_VACIO

        For i = 0 To dgFactura.Rows.Count - 1
            If i > 0 Then
                strTEMP = strTEMP & " OR "
            End If
            If dgFactura.Rows.Count - 1 >= 0 Then
                strTEMP = strTEMP & " ( d.DDoc_Doc_Ano = " & dgFactura.Rows(i).Cells("colAnioF").Value & " AND DDoc_Doc_Num = " & dgFactura.Rows(i).Cells("colNumeroF").Value & ")"
            Else
            End If

        Next


        strSql = " SELECT d.DDoc_Sis_Emp empresa, d.DDoc_Doc_Cat catalogo, d.DDoc_Doc_Ano anioFactura, d.DDoc_Prd_Cod Codigo, d.DDoc_Prd_Des Descripcion, d.DDoc_Doc_Num Factura, d.DDoc_Doc_Lin Linea, d.DDoc_Prd_UM IdMedida, d.DDoc_Prd_PUQ Precio, d.DDoc_RF1_Txt Referencia, cat_clave Medida, IFNULL(inv.inv_prodlote, ' ') LoteFisico, a.art_DCorta DCorta"
        strSql &= "     FROM Dcmtos_DTL d"
        strSql &= "         LEFT JOIN Catalogos ON cat_num = d.DDoc_Prd_UM"
        strSql &= "              LEFT JOIN Inventarios inv ON inv.inv_numero = d.DDoc_Prd_Cod AND inv.inv_prodano = d.DDoc_Doc_Ano"
        strSql &= "          LEFT JOIN Inventarios inve ON inve.inv_sisemp = d.DDoc_Sis_Emp AND inve.inv_numero = d.DDoc_Prd_Cod"
        strSql &= "     LEFT JOIN Articulos a ON a.art_sisemp = inve.inv_sisemp AND a.art_codigo = inve.inv_artcodigo"
        strSql &= " WHERE d.DDoc_Sis_Emp ={empresa} and d.DDoc_Doc_Cat = 36 AND ({Lista})"

        strSql = Replace(strSql, "{empresa}", Sesion.IdEmpresa)
        strSql = Replace(strSql, "{Lista}", strTEMP)

        Try
            MyCnn.CONECTAR = strConexion

            COM = New MySqlCommand(strSql, CON)
            REA = COM.ExecuteReader

            If REA.HasRows Then

                Do While REA.Read
                    strFila = REA.GetInt32("empresa") & "|"
                    strFila &= REA.GetInt32("catalogo") & "|"
                    strFila &= REA.GetInt32("anioFactura") & "|"
                    strFila &= REA.GetInt32("Codigo") & "|"
                    strFila &= REA.GetString("DCorta") & "|"
                    strFila &= REA.GetInt32("Factura") & "|"
                    strFila &= REA.GetInt32("Linea") & "|"
                    strFila &= 0 & "|"
                    strFila &= REA.GetInt32("IdMedida") & "|"
                    strFila &= REA.GetString("Medida") & "|"
                    strFila &= REA.GetString("LoteFisico") & "|"
                    strFila &= "" & "|"
                    strFila &= 0 & "|"
                    strFila &= REA.GetDouble("Precio") & "|"
                    strFila &= 0 & "|"
                    strFila &= "" & "|"
                    strFila &= 0 & "|"
                    strFila &= REA.GetString("Referencia") & "|"
                    strFila &= "" & "|"
                    strFila &= 0

                    cFunciones.AgregarFila(DgDetalle, strFila)
                Loop


                For i As Integer = vbEmpty To DgDetalle.Rows.Count - 1
                    'If DgDetalle.Rows(i).Visible = True Then
                    contador = contador + 1
                    DgDetalle.Rows(i).Cells("colLineaDevolucion").Value = contador
                    'End If
                Next
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try

    End Sub


    Public Sub CargarDatos(ByVal numero As Integer, ByVal anio As Integer)
        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader
        Dim strSQL As String = STR_VACIO
        Dim strFila As String = STR_VACIO
        Dim cantidad As Integer

        strSQL = SqlSubDocumento(numero, anio)

        Try

            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSQL, CON)
            REA = COM.ExecuteReader

            If REA.HasRows Then
                Do While REA.Read
                    strFila = REA.GetString("cat_clave") & "|"
                    strFila &= REA.GetString("cat_desc") & "|"
                    cantidad = REA.GetInt32("Cantidad")
                    If cantidad > 0 Then
                        strFila &= "SI"
                    Else
                        strFila &= "NO"
                    End If

                    cFunciones.AgregarFila(dgDocumentos, strFila)

                Loop
            End If


        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub


    Private Sub CalcularTotales()
        Dim Cantidad As Double
        Dim Total As Double
        Dim i As Integer
        For i = 0 To DgDetalle.Rows.Count - 1

            Cantidad = Cantidad + CDbl(DgDetalle.Rows(i).Cells("colCantidadKG").Value)
            Total = Total + CDbl(DgDetalle.Rows(i).Cells("colBultosDet").Value)

        Next

        celdaTotalCantidad.Text = CDbl(Cantidad)
        celdaTotal.Text = CDbl(Total)

    End Sub

    Public Sub LimpiarCampos()
        Dim frm As New frmPackingDevoluciones
        celdaAnio.Text = NO_FILA
        celdaTasa.Text = INT_UNO
        celdaNumero.Text = NO_FILA
        celdaCatalogo.Text = 490
        dtpFecha.Text = cfun.HoyMySQL
        celdaDate.Text = dtpFecha.Value.ToString(FORMATO_MYSQL)
        celdaCliente.Clear()
        celdaIdCliente.Text = NO_FILA
        celdaNIT.Clear()
        celdaDireccion.Clear()
        celdaMoneda.Clear()
        celdaIdMoneda.Text = INT_LOC
        celdaUsuario.Clear()
        celdaTotal.Clear()
        celdaTotalCantidad.Clear()
        celdaSolicitante.Text = STR_VACIO
        celdaCCosto.Text = STR_VACIO
        celdaComentarios.Clear()
        rbHilos.Checked = False
        rbCliente.Checked = False
        rbCliente.Text = "Cliente"
        celdaAutorizado.Text = STR_VACIO
        celdaIDAprobado.Text = NO_FILA
        celdaIDCCosto.Text = NO_FILA
        celdaRSCliente.Text = STR_VACIO

        dgFactura.Rows.Clear()
        DgDetalle.Rows.Clear()
        dgDocumentos.Rows.Clear()
        dgOculto.Rows.Clear()
        dgDocumentos.Rows.Clear()
        frm.dgDetalle.Rows.Clear()
        frm.celdaAnio.Text = NO_FILA
        frm.celdaNumero.Text = NO_FILA
        frm.celdaCatalogo.Text = NO_FILA
        frm.celdaLinea.Text = NO_FILA


    End Sub


    'Query que carga Lista Principal
    Private Function SQLListaPrincipal(ByVal intAnio As Integer, ByVal intNumero As Integer) As String
        Dim strSQL As String = STR_VACIO

        strSQL = "SELECT h.HDoc_Sis_Emp empresa, h.HDoc_Doc_Cat catalogo, h.HDoc_Doc_Ano anio, h.HDoc_Doc_Num numero, h.HDoc_Doc_Fec fecha, h.HDoc_Emp_Cod CodEmpresa, h.HDoc_Emp_Nom cliente, IFNULL(h.HDoc_RF1_Txt,'') ref, h.HDoc_Doc_Status estado, IFNULL(h.HDoc_Emp_Dir,'') direccion, IFNULL(h.HDoc_Doc_Mon,0) Moneda, IFNULL(h.HDoc_Doc_TC,0) tasa, IFNULL(h.HDoc_RF1_Num,0) IDCode, IFNULL(d.dep_descripcion,'') CCosto, IFNULL(h.HDoc_RF2_Num,0) IDAprobado, IFNULL(c.cat_desc,'') NAprobado, IFNULL(h.HDoc_DR1_Cat,0) Devolucion, IFNULL(h.HDoc_RF2_Txt,'') Comentario, IFNULL(h.HDoc_Emp_NIT,'') nit, IFNULL(h.HDoc_Usuario,'') usuario, IFNULL(h.HDoc_RF1_Cod,'') RSCliente"
        strSQL &= "      FROM Dcmtos_HDR h"
        strSQL &= "             LEFT JOIN Departamentos d ON d.dep_sisemp = h.HDoc_Sis_Emp AND d.dep_no = h.HDoc_RF1_Num"
        strSQL &= "                  LEFT JOIN Catalogos c ON c.cat_num = h.HDoc_RF2_Num AND c.cat_clase = 'Devoluciones' AND c.cat_clave = 'Autorizacion'"
        strSQL &= "              WHERE h.HDoc_Sis_Emp = {empresa} AND h.HDoc_Doc_Cat = {catalogo} AND h.HDoc_Doc_Num = {numero} AND h.HDoc_Doc_Ano = {anio}"
        strSQL &= "  ORDER BY HDoc_Doc_Ano DESC, HDoc_Doc_Num DESC"

        strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
        strSQL = Replace(strSQL, "{catalogo}", 490)
        strSQL = Replace(strSQL, "{numero}", intNumero)
        strSQL = Replace(strSQL, "{anio}", intAnio)

        Return strSQL
    End Function

    'Query que carga Lista Principal
    Private Function SQLLista() As String
        Dim strSQL As String = STR_VACIO

        strSQL = "SELECT h.HDoc_Sis_Emp empresa, h.HDoc_Doc_Cat catalogo, h.HDoc_Doc_Ano anio, h.HDoc_Doc_Num numero, h.HDoc_Doc_Fec fecha, h.HDoc_Emp_Cod CodEmpresa, h.HDoc_Emp_Nom cliente, IFNULL(h.HDoc_RF1_Txt,'') ref, h.HDoc_Doc_Status estado, IFNULL(h.HDoc_Emp_Dir,'') direccion, IFNULL(h.HDoc_Doc_Mon,0) Moneda, IFNULL(h.HDoc_Doc_TC,0) tasa, IFNULL(h.HDoc_RF1_Num,0) IDCode, IFNULL(d.dep_descripcion,'') CCosto, IFNULL(h.HDoc_RF2_Num,0) IDAprobado, IFNULL(c.cat_desc,'') NAprobado, IFNULL(h.HDoc_DR1_Cat,0) Devolucion, IFNULL(h.HDoc_RF2_Txt,'') Comentario, IFNULL(h.HDoc_Emp_NIT,'') nit, IFNULL(h.HDoc_Usuario,'') usuario"
        strSQL &= "      FROM Dcmtos_HDR h"
        strSQL &= "             LEFT JOIN Departamentos d ON d.dep_sisemp = h.HDoc_Sis_Emp AND d.dep_no = h.HDoc_RF1_Num"
        strSQL &= "                  LEFT JOIN Catalogos c ON c.cat_num = h.HDoc_RF2_Num AND c.cat_clase = 'Devoluciones' AND c.cat_clave = 'Autorizacion'"
        strSQL &= "              WHERE h.HDoc_Sis_Emp = {empresa} AND h.HDoc_Doc_Cat = {catalogo}"


        If checkFechas.Checked = True Then

            strSQL &= " AND (HDoc_Doc_Fec BETWEEN '{fechainicio}' AND '{fechafin}') "

            strSQL = Replace(strSQL, "{fechainicio}", dtpInicial.Value.ToString(FORMATO_MYSQL))
            strSQL = Replace(strSQL, "{fechafin}", dtpFinal.Value.ToString(FORMATO_MYSQL))

        End If
        strSQL &= "  ORDER BY HDoc_Doc_Ano DESC, HDoc_Doc_Num DESC"

        strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
        strSQL = Replace(strSQL, "{catalogo}", 490)

        Return strSQL
    End Function

    'Procedimiento para Cargar dgLista Panel Principal
    Public Sub queryListaPrincipal()
        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader
        Dim strSQL As String = STR_VACIO
        Dim e As Integer

        strSQL = SQLLista()

        Try

            MyCnn.CONECTAR = strConexion

            COM = New MySqlCommand(strSQL, CON)
            REA = COM.ExecuteReader

            If REA.HasRows Then

                dgLista.Rows.Clear()

                Do While REA.Read
                    Dim strFila As String = STR_VACIO

                    strFila = REA.GetInt32("numero") & "|" & REA.GetDateTime("fecha") & "|" & REA.GetInt32("CodEmpresa") & "|" & REA.GetString("cliente") & "|" & REA.GetString("ref") & "|" & REA.GetInt32("anio") & "|" &
                              REA.GetInt32("estado") & "|" & REA.GetString("direccion") & "|" & REA.GetInt32("moneda") & "|" & REA.GetDouble("tasa") & "|" & REA.GetInt32("IDAprobado") & "|" & REA.GetString("NAprobado") & "|" &
                              REA.GetInt32("IDCode") & "|" & REA.GetString("CCosto") & "|" & REA.GetString("Devolucion") & "|" & REA.GetString("Comentario") & "|" & REA.GetInt32("empresa")

                    e = REA.GetInt32("estado")

                    AgregarFila(dgLista, strFila, e)

                Loop

            End If

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try

    End Sub

    Private Sub AgregarFila(ByRef Lista As DataGridView, ByVal strFila As String, ByVal Estado As Integer)

        Dim Celda As New DataGridViewTextBoxCell
        Dim Fila As New DataGridViewRow
        Dim strSQL As String = STR_VACIO
        Dim arrayFila() As String
        Dim i As Integer
        Try
            Lista.BackgroundColor = Color.White
            arrayFila = strFila.Split("|".ToCharArray)
            For i = 0 To arrayFila.Length - 1
                Celda = New DataGridViewTextBoxCell
                Celda.Value = arrayFila(i)

                If Estado = vbEmpty Then
                    If i = 0 Then
                        Celda.Style.BackColor = Color.Red
                    End If
                End If


                Fila.Cells.Add(Celda)

            Next

            Lista.Rows.Add(Fila)
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try

    End Sub

    'Query que carga Lista Detalle
    Private Function SQLDetalleD(ByVal intNumero As Integer, ByVal intAnio As Integer) As String

        Dim strsql As String = STR_VACIO

        strsql = " SELECT d.DDoc_Sis_Emp Empresa, d.DDoc_Doc_Cat Catalogo, d.DDoc_Doc_Ano Anio, d.DDoc_Doc_Num Numero, d.DDoc_Doc_Lin Linea, d.DDoc_Prd_Cod CodProducto, d.DDoc_Prd_Des Producto, d.DDoc_Prd_UM IDMedida, d.DDoc_RF3_Num Factura, d.DDoc_Prd_NET Precio, d.DDoc_RF1_Txt Referencia, IFNULL(d.DDoc_RF2_Cod,'') Tejedora, d.DDoc_RF2_Txt Lote, d.DDoc_RF2_Dbl CantKG, p.PDoc_QTY_Pro Cantidad, p.PDoc_Par_Num factura, p.PDoc_Par_Lin LinFactura, p.PDoc_Par_Ano AnioFactura, d.DDoc_Prd_Net Precio, d.DDoc_RF3_Txt LoteDet,"
        strsql &= "     ("
        strsql &= "          IFNULL((SELECT COUNT(*) FROM Dcmtos_DTL_Box b"
        strsql &= "                  WHERE b.BDoc_Sis_Emp = d.DDoc_Sis_Emp AND b.BDoc_Doc_Cat = d.DDoc_Doc_Cat AND b.BDoc_Doc_Ano = d.DDoc_Doc_Ano AND b.BDoc_Doc_Num = d.DDoc_Doc_Num AND b.BDoc_Doc_Lin = d.DDoc_Doc_Lin),0)"
        strsql &= "                          )bultos"
        strsql &= "                 FROM Dcmtos_DTL d"
        strsql &= "         INNER JOIN Dcmtos_DTL_Pro p ON p.PDoc_Sis_Emp = d.DDoc_Sis_Emp AND p.PDoc_Chi_Cat = d.DDoc_Doc_Cat AND p.PDoc_Chi_Ano = d.DDoc_Doc_Ano AND p.PDoc_Chi_Num = d.DDoc_Doc_Num AND p.PDoc_Chi_Lin = d.DDoc_Doc_Lin"
        strsql &= "     WHERE d.DDoc_Sis_Emp = {empresa} AND d.DDoc_Doc_Cat = 490 AND d.DDoc_Doc_Ano = {año} AND d.DDoc_Doc_Num = {numero}"
        strsql &= " ORDER BY d.DDoc_Doc_Lin"

        strsql = Replace(strsql, "{empresa}", Sesion.IdEmpresa)
        strsql = Replace(strsql, "{año}", intAnio)
        strsql = Replace(strsql, "{numero}", intNumero)

        Return strsql
    End Function

    'Procedimiento para CargardgDetalle 
    Public Sub queryDetalleD(ByVal intNumero As Integer, ByVal intAnio As Integer)
        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader
        Dim strSQL As String = STR_VACIO
        Dim strSQL2 As String = STR_VACIO
        Dim conec As MySqlConnection
        Dim COM2 As MySqlCommand
        Dim REA2 As MySqlDataReader

        strSQL = SQLDetalleD(intNumero, intAnio)

        Try

            MyCnn.CONECTAR = strConexion

            COM = New MySqlCommand(strSQL, CON)
            REA = COM.ExecuteReader

            If REA.HasRows Then

                DgDetalle.Rows.Clear()
                Do While REA.Read
                    Dim strFila As String = STR_VACIO

                    strFila = REA.GetInt32("Empresa") & "|"
                    strFila &= REA.GetInt32("Catalogo") & "|"
                    strFila &= REA.GetInt32("AnioFactura") & "|"
                    strFila &= REA.GetInt32("CodProducto") & "|"
                    strFila &= REA.GetString("Producto") & "|"
                    strFila &= REA.GetInt32("factura") & "|"
                    strFila &= REA.GetInt32("LinFactura") & "|"
                    strFila &= REA.GetInt32("Linea") & "|"
                    strFila &= REA.GetInt32("IDMedida") & "|"
                    If REA.GetInt32("IDMedida") = 69 Then
                        strFila &= "LBS" & "|"
                        strFila &= REA.GetString("LoteDet") & "|"
                        strFila &= REA.GetString("Lote") & "|"
                        strFila &= REA.GetDouble("Cantidad").ToString(FORMATO_MONEDA) & "|"
                        strFila &= REA.GetDouble("Precio").ToString(FORMATO_MONEDA) & "|"
                        strFila &= (REA.GetDouble("Precio") * 2.2046).ToString(FORMATO_MONEDA) & "|"
                        strFila &= (REA.GetDouble("CantKG")).ToString(FORMATO_MONEDA) & "|"
                        strFila &= REA.GetInt32("bultos") & "|"
                        strFila &= REA.GetString("Referencia") & "|"
                        strFila &= REA.GetString("Tejedora") & "|"
                        strFila &= 1
                    Else
                        strFila &= "KGS" & "|"
                        strFila &= REA.GetString("LoteDet") & "|"
                        strFila &= REA.GetString("Lote") & "|"
                        strFila &= (REA.GetDouble("Cantidad")).ToString(FORMATO_MONEDA) & "|"
                        strFila &= (REA.GetDouble("Precio") / 2.2046).ToString(FORMATO_MONEDA) & "|"
                        strFila &= REA.GetDouble("Precio").ToString(FORMATO_MONEDA) & "|"
                        strFila &= REA.GetDouble("CantKG").ToString(FORMATO_MONEDA) & "|"
                        strFila &= REA.GetInt32("bultos") & "|"
                        strFila &= REA.GetString("Referencia") & "|"
                        strFila &= REA.GetString("Tejedora") & "|"
                        strFila &= 1
                    End If

                    cFunciones.AgregarFila(DgDetalle, strFila)
                Loop
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try

    End Sub

    'Query que carga Lista de Facturas
    Private Function SQLFacturas() As String

        Dim strsql As String = STR_VACIO

        strsql = " SELECT DISTINCT(h.HDoc_Doc_Cat) Catalogo, h.HDoc_Doc_Num Numero, h.HDoc_Doc_Ano Anio, h.HDoc_Doc_Num Factura, h.HDoc_Doc_Fec Fecha, h.HDoc_DR1_Num Referencia"
        strsql &= "     FROM Dcmtos_DTL_Pro p"
        strsql &= "         INNER JOIN Dcmtos_HDR h ON h.HDoc_Sis_Emp = p.PDoc_Sis_Emp AND h.HDoc_Doc_Cat = p.PDoc_Par_Cat AND h.HDoc_Doc_Ano = p.PDoc_Par_Ano AND h.HDoc_Doc_Num = p.PDoc_Par_Num"
        strsql &= "             WHERE p.PDoc_Sis_Emp = {empresa} AND p.PDoc_Chi_Cat = 490 AND p.PDoc_Chi_Ano = {año} AND p.PDoc_Chi_Num = {numero}"
        strsql &= "   ORDER BY h.HDoc_Doc_Num"

        strsql = Replace(strsql, "{empresa}", Sesion.IdEmpresa)
        strsql = Replace(strsql, "{año}", Val(celdaAnio.Text))
        strsql = Replace(strsql, "{numero}", Val(celdaNumero.Text))

        Return strsql
    End Function


    'Procedimiento para Cargar dgFacturas 
    Public Sub queryFacturas()
        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader
        Dim strSQL As String = STR_VACIO
        Dim strSQL2 As String = STR_VACIO
        Dim conec As MySqlConnection
        Dim COM2 As MySqlCommand
        Dim REA2 As MySqlDataReader

        strSQL = SQLFacturas()

        Try

            MyCnn.CONECTAR = strConexion

            COM = New MySqlCommand(strSQL, CON)
            REA = COM.ExecuteReader

            If REA.HasRows Then

                dgFactura.Rows.Clear()
                Do While REA.Read
                    Dim strFila As String = STR_VACIO

                    strFila = REA.GetInt32("Numero") & "|"
                    strFila &= REA.GetDateTime("Fecha") & "|"
                    strFila &= REA.GetString("Referencia") & "|"
                    strFila &= REA.GetInt32("Anio") & "|"
                    strFila &= REA.GetInt32("Catalogo")

                    cFunciones.AgregarFila(dgFactura, strFila)
                Loop
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try

    End Sub

    'Query que carga Lista de Facturas
    Private Function SQLCargarCajas() As String

        Dim strsql As String = STR_VACIO
        strsql = " SELECT b.BDoc_Sis_Emp Empresa, b.BDoc_Doc_Cat Catalogo, b.BDoc_Doc_Ano Anio, b.BDoc_Doc_Num Numero, b.BDoc_Doc_Lin Linea, b.BDoc_Box_Lin LineaBox, IFNULL(b.BDoc_Box_Cod,'') Referencia, b.BDoc_Box_Ord Tara, b.BDoc_Box_QTY Paquetes, b.BDoc_Box_LB CantidadMedida"
        strsql &= "     FROM Dcmtos_DTL_Box b"
        strsql &= "         WHERE b.BDoc_Sis_Emp = {empresa} AND b.BDoc_Doc_Cat = 490 AND b.BDoc_Doc_Ano = {año} AND b.BDoc_Doc_Num = {numero}"

        strsql = Replace(strsql, "{empresa}", Sesion.IdEmpresa)
        strsql = Replace(strsql, "{año}", Val(celdaAnio.Text))
        strsql = Replace(strsql, "{numero}", Val(celdaNumero.Text))

        Return strsql
    End Function


    'Procedimiento para Cargar dgOculto PackingList
    Public Sub queryCargarCajas()
        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader
        Dim strSQL As String = STR_VACIO
        Dim strSQL2 As String = STR_VACIO
        Dim conec As MySqlConnection
        Dim COM2 As MySqlCommand
        Dim REA2 As MySqlDataReader

        strSQL = SQLCargarCajas()

        Try

            MyCnn.CONECTAR = strConexion

            COM = New MySqlCommand(strSQL, CON)
            REA = COM.ExecuteReader

            If REA.HasRows Then

                dgOculto.Rows.Clear()
                Do While REA.Read
                    Dim strFila As String = STR_VACIO

                    strFila = REA.GetInt32("Empresa") & "|"
                    strFila &= REA.GetInt32("Catalogo") & "|"
                    strFila &= REA.GetInt32("Anio") & "|"
                    strFila &= REA.GetInt32("Numero") & "|"
                    strFila &= REA.GetInt32("Linea") & "|"
                    strFila &= REA.GetInt32("LineaBox") & "|"
                    strFila &= REA.GetString("Referencia") & "|"
                    strFila &= REA.GetDouble("Tara").ToString(FORMATO_MONEDA) & "|"
                    strFila &= REA.GetInt32("Paquetes") & "|"
                    strFila &= REA.GetDouble("CantidadMedida").ToString(FORMATO_MONEDA) & "|"
                    strFila &= 1

                    cFunciones.AgregarFila(dgOculto, strFila)
                Loop
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try

    End Sub

    'Query que carga Lista de Facturas
    Private Function sqlSubdocumentosCargar(ByVal intNumero As Integer, ByVal intAnio As Integer) As String

        Dim strsql As String = STR_VACIO

        strsql = " SELECT cat_clave, cat_desc, IF(("
        strsql &= "     SELECT COUNT(*)"
        strsql &= "         FROM Dcmtos_ACC"
        strsql &= "             WHERE ADoc_Sis_Emp = {empresa} AND ADoc_Doc_Cat = 490 AND ADoc_Doc_Ano = {año} AND ADoc_Doc_Num = {numero} AND ADoc_Doc_Sub = cat_clave) >0,'SI','NO') Cantidad"
        strsql &= "          FROM Catalogos"
        strsql &= "      WHERE cat_clase = 'SubDcmtos' AND cat_sist = 'Doc_RADevolucion' AND (cat_sisemp IN (0,12))"
        strsql &= "   ORDER BY cat_clave "

        strsql = Replace(strsql, "{empresa}", Sesion.IdEmpresa)
        strsql = Replace(strsql, "{año}", intAnio)
        strsql = Replace(strsql, "{numero}", intNumero)

        Return strsql
    End Function

    Private Function sqlTraerNota() As String
        Dim strSQL As String

        strSQL = " SELECT cat_desc "
        strSQL &= "    FROM Catalogos "
        strSQL &= " WHERE cat_pid = 490 "

        Return strSQL
    End Function

    Public Sub CargarSubdocumentos(ByVal numero As Integer, ByVal anio As Integer)
        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader
        Dim strSQL As String = STR_VACIO
        Dim strFila As String = STR_VACIO
        Dim cantidad As Integer

        strSQL = sqlSubdocumentosCargar(numero, anio)

        Try

            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSQL, CON)
            REA = COM.ExecuteReader

            If REA.HasRows Then
                Do While REA.Read
                    strFila = REA.GetString("cat_clave") & "|"
                    strFila &= REA.GetString("cat_desc") & "|"
                    strFila &= REA.GetString("Cantidad")

                    cFunciones.AgregarFila(dgDocumentos, strFila)

                Loop
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub


    Public Sub TraerNota()
        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader
        Dim strSQL As String = STR_VACIO

        strSQL = sqlTraerNota()

        Try

            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSQL, CON)
            REA = COM.ExecuteReader

            If REA.HasRows Then
                Do While REA.Read
                    NotaDev = REA.GetString("cat_desc")
                Loop
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub
    Private Function GuardarEncabezado() As Boolean
        Dim logResultado As Boolean = True
        Dim COM As New MySqlCommand
        Dim conec As New MySqlConnection

        Try

            Dim chdr As New clsDcmtos_HDR
            chdr.CONEXION = strConexion

            chdr.HDOC_SIS_EMP = celdaEmpresa.Text
            chdr.HDOC_DOC_CAT = celdaCatalogo.Text
            chdr.HDOC_DOC_ANO = celdaAnio.Text           'Documento
            chdr.HDOC_DOC_NUM = celdaNumero.Text
            chdr.HDoc_Doc_Fec_NET = dtpFecha.Text

            chdr.HDOC_EMP_COD = celdaIdCliente.Text
            chdr.HDOC_EMP_NOM = celdaCliente.Text
            chdr.HDOC_EMP_DIR = celdaDireccion.Text     'Coctacto
            chdr.HDOC_EMP_NIT = celdaNIT.Text

            chdr.HDOC_DOC_TC = celdaTasa.Text           'Cod Moneda
            chdr.HDOC_DOC_MON = celdaIdMoneda.Text      ' Tasa de Cambio

            chdr.HDOC_RF1_TXT = celdaSolicitante.Text       'Quien hace el requerimiento
            chdr.HDOC_RF1_NUM = celdaIDCCosto.Text             ' Almacena el ID del Centro de Conto
            chdr.HDOC_RF2_NUM = celdaIDAprobado.Text            'Almacena el ID de quien Autoriza la Devolución

            chdr.HDOC_DOC_STATUS = IIf(checkActivo.Checked = True, 1, vbEmpty)         'Estado: 1/Activo
            If Not (celdaComentarios.Text) = vbNullString Then
                If Me.Tag = "Mod" Then
                    chdr.HDOC_RF2_TXT = celdaComentarios.Text
                Else
                    chdr.HDOC_RF2_TXT = celdaComentarios.Text & vbCrLf & NotaDev
                End If

            Else
                chdr.HDOC_RF2_TXT = ""
            End If
            chdr.HDOC_RF1_COD = celdaRSCliente.Text


            If rbHilos.Checked = True Then
                chdr.HDOC_DR1_CAT = INT_UNO
            ElseIf rbCliente.Checked = True Then
                chdr.HDOC_DR1_CAT = CInt(celdaIdCliente.Text)
            End If

            chdr.HDOC_USUARIO = celdaUsuario.Text

            If Me.Tag = "Mod" Then
                If chdr.Actualizar() = False Then
                    MsgBox(chdr.MERROR.ToString & "Could not update the document", MsgBoxStyle.Critical)
                End If
            Else
                If chdr.Guardar() = False Then
                    MsgBox(chdr.MERROR.ToString & "Could not save the document", MsgBoxStyle.Critical)
                End If
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        Return logResultado
    End Function

    Private Function GuardarDetalle() As Boolean
        Dim logResultado As Boolean = True
        Dim Dtl As New clsDcmtos_DTL
        Dim COM As MySqlCommand
        Dim conec As MySqlConnection
        Dim i As Integer
        Dim strSQL As String = STR_VACIO
        Dim Orden As Double
        Dim j As Integer = 0

        Dtl.CONEXION = strConexion

        Try
            For i = 0 To DgDetalle.Rows.Count - 1
                If DgDetalle.Rows(i).Visible = True Then
                    Dtl.DDOC_SIS_EMP = celdaEmpresa.Text
                    Dtl.DDOC_DOC_CAT = celdaCatalogo.Text
                    Dtl.DDOC_DOC_ANO = celdaAnio.Text
                    Dtl.DDOC_DOC_NUM = celdaNumero.Text
                    Dtl.DDOC_DOC_LIN = DgDetalle.Rows(i).Cells("colLineaDevolucion").Value

                    Dtl.DDOC_PRD_COD = DgDetalle.Rows(i).Cells("colCodigoDet").Value
                    Dtl.DDOC_PRD_DES = DgDetalle.Rows(i).Cells("colProductoDet").Value
                    Dtl.DDOC_PRD_UM = DgDetalle.Rows(i).Cells("colIDMedida").Value
                    Dtl.DDOC_RF3_NUM = DgDetalle.Rows(i).Cells("colFacturaDet").Value

                    If DgDetalle.Rows(i).Cells("colIDMedida").Value = 69 Then
                        Dtl.DDOC_PRD_PUQ = DgDetalle.Rows(i).Cells("colPrecioDet").Value
                        Dtl.DDOC_PRD_NET = DgDetalle.Rows(i).Cells("colPrecioDet").Value

                        Dtl.DDOC_PRD_QTY = DgDetalle.Rows(i).Cells("colCantidadDet").Value
                    Else
                        Dtl.DDOC_PRD_PUQ = DgDetalle.Rows(i).Cells("colPrecioKg").Value
                        Dtl.DDOC_PRD_NET = DgDetalle.Rows(i).Cells("colPrecioKg").Value
                        Dtl.DDOC_PRD_QTY = DgDetalle.Rows(i).Cells("colCantidadDet").Value
                    End If

                    Dtl.DDOC_RF3_TXT = DgDetalle.Rows(i).Cells("colLoteDet").Value
                    Dtl.DDOC_RF1_TXT = DgDetalle.Rows(i).Cells("colReferenciaDet").Value
                    Dtl.DDoc_RF1_Fec_NET = celdaDate.Text
                    If DgDetalle.Rows(i).Cells("colTejedoraDet").Value = Nothing Then
                        Dtl.DDOC_RF2_COD = "NULL"
                    Else
                        Dtl.DDOC_RF2_COD = DgDetalle.Rows(i).Cells("colTejedoraDet").Value
                    End If


                    Dtl.DDOC_RF2_TXT = DgDetalle.Rows(i).Cells("colLoteDetDev").Value
                    Dtl.DDOC_RF2_DBL = DgDetalle.Rows(i).Cells("colCantidadKG").Value
                    If DgDetalle.Rows(i).Cells("colPrecioKg").Value = "" Then
                        Dtl.DDOC_RF3_DBL = 0
                    Else
                        Dtl.DDOC_RF3_DBL = DgDetalle.Rows(i).Cells("colPrecioKg").Value
                    End If


                    If DgDetalle.Rows(i).Cells("colXtra").Value = 1 Then
                        If Dtl.Actualizar() = False Then
                            MsgBox(Dtl.MERROR.ToString & "Could not update the document", MsgBoxStyle.Critical)
                        End If
                    ElseIf DgDetalle.Rows(i).Cells("colXtra").Value = 0 Then
                        If Dtl.Guardar() = False Then
                            MsgBox(Dtl.MERROR.ToString & "Could not save the document", MsgBoxStyle.Critical)
                            'Else
                            '    DgDetalle.Rows(i).Cells("colXtra").Value = 1
                        End If
                    ElseIf DgDetalle.Rows(i).Cells("colXtra").Value = 2 Then
                        If Dtl.Borrar() = False Then
                            MsgBox(Dtl.MERROR.ToString & "Could not update the document", MsgBoxStyle.Critical)
                        End If
                    End If
                End If
            Next
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        Return logResultado
    End Function

    'Guarda los bultos/cajas de este documento
    Private Function GuardarBultos() As Boolean
        Dim logResultado As Boolean = True
        Dim DtlBox As New Tablas.TDCMTOS_DTL_BOX
        Const I_CODIGO As Integer = 1
        Dim j As Integer = 0

        DtlBox.CONEXION = strConexion
        Try
            For i As Integer = 0 To dgOculto.Rows.Count - 1

                DtlBox.BDOC_SIS_EMP = dgOculto.Rows(i).Cells("colEmpBultos").Value
                DtlBox.BDOC_DOC_CAT = dgOculto.Rows(i).Cells("colCatBox").Value
                DtlBox.BDOC_DOC_ANO = dgOculto.Rows(i).Cells("colAnioBox").Value
                DtlBox.BDOC_DOC_NUM = celdaNumero.Text
                DtlBox.BDOC_DOC_LIN = dgOculto.Rows(i).Cells("colLineaDetalle").Value
                    DtlBox.BDOC_BOX_LIN = i + 1
                DtlBox.BDOC_BOX_ORD = dgOculto.Rows(i).Cells("colTara").Value
                If dgOculto.Rows(i).Cells("colReferenciaBox").Value = "" Then
                    DtlBox.BDOC_BOX_COD = "NULL"
                Else
                    DtlBox.BDOC_BOX_COD = dgOculto.Rows(i).Cells("colReferenciaBox").Value
                End If

                DtlBox.BDOC_BOX_QTY = dgOculto.Rows(i).Cells("colPaquetes").Value
                DtlBox.BDOC_BOX_LB = dgOculto.Rows(i).Cells("colCantidadMedida").Value


                If dgOculto.Rows(i).Cells("colXtraBox").Value = 1 Then
                    If DtlBox.PUPDATE = False Then
                        MsgBox(DtlBox.MERROR.ToString & "Could not Update the document", MsgBoxStyle.Critical)
                    End If

                ElseIf dgOculto.Rows(i).Cells("colXtraBox").Value = 0 Then
                    If DtlBox.PINSERT = False Then
                        MsgBox(DtlBox.MERROR.ToString & "Could not Save the document", MsgBoxStyle.Critical)
                    Else
                        dgOculto.Rows(i).Cells("colXtraBox").Value = 1
                    End If

                End If

            Next
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        Return logResultado
    End Function

    Private Sub EliminarLineasBultos()
        Dim DtlBox As New Tablas.TDCMTOS_DTL_BOX
        Const I_CODIGO As Integer = 1
        Dim j As Integer = 0
        Dim cantLineas As Integer
        cantLineas = dgOculto.Rows.Count


        DtlBox.CONEXION = strConexion
        Try
            For i As Integer = 0 To dgOculto.Rows.Count - 1

                DtlBox.BDOC_SIS_EMP = dgOculto.Rows(i).Cells("colEmpBultos").Value
                DtlBox.BDOC_DOC_CAT = dgOculto.Rows(i).Cells("colCatBox").Value
                DtlBox.BDOC_DOC_ANO = dgOculto.Rows(i).Cells("colAnioBox").Value
                DtlBox.BDOC_DOC_NUM = celdaNumero.Text
                DtlBox.BDOC_DOC_LIN = dgOculto.Rows(i).Cells("colLineaDetalle").Value
                DtlBox.BDOC_BOX_LIN = dgOculto.Rows(i).Cells("colLineaBox").Value
                DtlBox.BDOC_BOX_ORD = dgOculto.Rows(i).Cells("colTara").Value
                DtlBox.BDOC_BOX_COD = dgOculto.Rows(i).Cells("colReferenciaBox").Value
                DtlBox.BDOC_BOX_QTY = dgOculto.Rows(i).Cells("colPaquetes").Value
                DtlBox.BDOC_BOX_LB = dgOculto.Rows(i).Cells("colCantidadMedida").Value

                If dgOculto.Rows(i).Cells("colXtraBox").Value = 2 Then
                    If DtlBox.PDELETE = False Then
                        MsgBox(DtlBox.MERROR.ToString & "Could not Save the document", MsgBoxStyle.Critical)
                    End If
                End If
            Next
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub


    Private Sub GuardarDescargo()
        Dim clsDTLPro As New clsDcmtos_DTL_Pro
        Dim cfun As New clsFunciones
        Dim dblCantidad As Double

        clsDTLPro.CONEXION = strConexion
        Try
            For i As Integer = 0 To DgDetalle.Rows.Count - 1
                clsDTLPro.PDOC_SIS_EMP = celdaEmpresa.Text
                clsDTLPro.PDOC_PAR_CAT = 36
                clsDTLPro.PDOC_PAR_ANO = DgDetalle.Rows(i).Cells("colAnioFactura").Value
                clsDTLPro.PDOC_PAR_NUM = DgDetalle.Rows(i).Cells("colFacturaDet").Value
                clsDTLPro.PDOC_PAR_LIN = DgDetalle.Rows(i).Cells("colLinea").Value

                clsDTLPro.PDOC_CHI_CAT = 490
                clsDTLPro.PDOC_CHI_ANO = celdaAnio.Text
                clsDTLPro.PDOC_CHI_NUM = celdaNumero.Text
                clsDTLPro.PDOC_CHI_LIN = DgDetalle.Rows(i).Cells("colLineaDevolucion").Value
                clsDTLPro.PDOC_PROV_COD = celdaIdCliente.Text                                'Cód. del proveedor
                clsDTLPro.PDOC_PRD_COD = DgDetalle.Rows(i).Cells("colCodigoDet").Value           'Cód. del pedido
                'clsDTLPro.PDOC_PRD_PNR = DgDetalle.Rows(i).Cells("colNumParte").Value         'DDoc_Prd_PNr/N° de parte
                If DgDetalle.Rows(i).Cells("colIDMedida").Value = 69 Then
                    clsDTLPro.PDOC_PRD_NET = DgDetalle.Rows(i).Cells("colPrecioDet").Value            'DDoc_Prd_NET/Precio neto
                Else
                    clsDTLPro.PDOC_PRD_NET = DgDetalle.Rows(i).Cells("colPrecioKg").Value            'DDoc_Prd_NET/Precio neto Kilogramos
                End If

                dblCantidad = vbEmpty
                If checkActivo.Checked = True Then
                    dblCantidad = DgDetalle.Rows(i).Cells("colCantidadDet").Value
                End If
                clsDTLPro.PDOC_QTY_ORD = DgDetalle.Rows(i).Cells("colCantidadDet").Value     'A Despachar
                clsDTLPro.PDOC_QTY_PRO = dblCantidad                                        'A despachar (vacío para documentos anulados/inactivos)

                If DgDetalle.Rows(i).Cells("colXtra").Value = 1 Then
                    If clsDTLPro.Actualizar() = False Then
                        MsgBox(clsDTLPro.MERROR.ToString)
                    End If

                ElseIf DgDetalle.Rows(i).Cells("colXtra").Value = 0 Then
                    If clsDTLPro.Guardar() = False Then
                        MsgBox(clsDTLPro.MERROR.ToString)
                        'Else
                        '    DgDetalle.Rows(i).Cells("colXtra").Value = 1
                    End If
                ElseIf DgDetalle.Rows(i).Cells("colXtra").Value = 2 Then
                    If clsDTLPro.Borrar() = False Then
                        MsgBox(clsDTLPro.MERROR.ToString)
                    End If
                End If

            Next
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub SeleccionarCliente(ByVal intaño As Integer, ByVal intnumero As Integer)
        Dim strSQL As String = STR_VACIO
        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader

        Try
            strSQL = SQLListaPrincipal(intaño, intnumero)

            MyCnn.CONECTAR = strConexion

            COM = New MySqlCommand(strSQL, CON)
            REA = COM.ExecuteReader

            If REA.HasRows Then

                Do While REA.Read

                    celdaAnio.Text = REA.GetInt32("anio")
                    celdaNumero.Text = REA.GetInt32("numero")
                    celdaDate.Text = REA.GetDateTime("fecha")
                    celdaIdCliente.Text = REA.GetInt32("CodEmpresa")
                    celdaCliente.Text = REA.GetString("cliente")
                    celdaDireccion.Text = REA.GetString("direccion")
                    celdaNIT.Text = REA.GetString("nit")
                    celdaTasa.Text = REA.GetDouble("tasa")
                    celdaSolicitante.Text = REA.GetString("ref")
                    celdaIDCCosto.Text = REA.GetInt32("IDCode")
                    celdaCCosto.Text = REA.GetString("CCosto")
                    celdaIDAprobado.Text = REA.GetInt32("IDAprobado")
                    celdaAutorizado.Text = REA.GetString("NAprobado")
                    celdaComentarios.Text = REA.GetString("Comentario")

                    celdaEmpresa.Text = Sesion.IdEmpresa
                    celdaCatalogo.Text = 490
                    celdaUsuario.Text = REA.GetString("usuario")

                    celdaIdMoneda.Text = REA.GetInt32("Moneda")
                    If REA.GetInt32("Moneda") = 178 Then
                        celdaMoneda.Text = "US$"
                    ElseIf REA.GetInt32("Moneda") = 177 Then
                        celdaMoneda.Text = "Q/"
                    ElseIf REA.GetInt32("Moneda") = 182 Then
                        celdaMoneda.Text = "LPS"
                    ElseIf REA.GetInt32("Moneda") = 179 Then
                        celdaMoneda.Text = "EU"
                    End If

                    If REA.GetInt32("estado") = 1 Then
                        checkActivo.Checked = True
                        celdaDesactivar.Visible = False
                        'checkActivo.Enabled = True
                    Else
                        checkActivo.Checked = False
                        celdaDesactivar.Visible = True
                        'checkActivo.Enabled = False
                    End If

                    If REA.GetInt32("Devolucion") = INT_UNO Then
                        rbHilos.Checked = True
                        rbCliente.Checked = False
                        rbCliente.Text = celdaCliente.Text
                    Else
                        rbHilos.Checked = False
                        rbCliente.Checked = True
                        rbCliente.Text = celdaCliente.Text
                    End If

                    celdaRSCliente.Text = REA.GetString("RSCliente")
                Loop
                MostrarLista(False)
            End If

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Function ComprobarCampos() As Boolean
        Dim comprobar As Boolean = True
        'Revisar que los datos de la cabecera no estén en blanco.

        If celdaEmpresa.Text = vbNullString Or
            celdaIdCliente.Text = NO_FILA Then
            MsgBox("To generate a return you need to at least select a customer", vbCritical)
            'Exit Function
            comprobar = False
        End If
        Return comprobar
    End Function

#End Region

#Region "Eventos"

    Private Sub frmDevoluciones_FormClosed(sender As Object, e As FormClosedEventArgs)

        Try
            frmSPrincipal.BarraDeTareas1.QuitarFormulario(strKey)
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try

    End Sub

    Private Sub frmPolizaExportacion_Load(sender As Object, e As EventArgs) Handles Me.Load
        MostrarLista()
        botonImprimir.Enabled = False
        botonImprimirPackingList.Enabled = False
        Encabezado1.botonGuardar.Enabled = False
        Encabezado1.botonBorrar.Enabled = False
    End Sub

    Private Sub Encabezado1_ClickNuevo(sender As Object, click As Boolean) Handles Encabezado1.ClickNuevo
        LimpiarCampos()
        Me.Tag = "Nuevo"
        botonImprimir.Enabled = True
        botonImprimirPackingList.Enabled = True

        celdaAnio.Text = cFunciones.AñoMySQL
        celdaNumero.Text = -1
        dtpFecha.Value = (cFunciones.HoyMySQL).ToString(FORMATO_MYSQL)
        celdaEmpresa.Text = Sesion.IdEmpresa
        celdaCatalogo.Text = 490
        celdaMoneda.Text = "US$"
        celdaIdMoneda.Text = 178
        celdaUsuario.Text = Sesion.Usuario
        CargarDatos(celdaNumero.Text, celdaAnio.Text)
        celdaIDAprobado.Text = NO_FILA
        celdaIDCCosto.Text = NO_FILA
        MostrarLista(False)

        If checkActivo.Checked = True Then
            celdaDesactivar.Visible = False
        Else
            celdaDesactivar.Visible = True
        End If
    End Sub

    Private Sub Encabezado1_ClickCerrar(sender As Object, click As Boolean) Handles Encabezado1.ClickCerrar
        If panelLista.Visible = True Then
            Me.Close()
        ElseIf panelDetalle.Visible = True Then
            MostrarLista()
        End If
        botonImprimir.Enabled = False
        botonImprimirPackingList.Enabled = False
        Encabezado1.botonGuardar.Enabled = False
        Encabezado1.botonBorrar.Enabled = False
    End Sub

    Private Sub Encabezado1_ClickGuardar(sender As Object, click As Boolean) Handles Encabezado1.ClickGuardar
        Dim strSQL As String = STR_VACIO
        Dim strTemp As String
        Dim COM As MySqlCommand
        Dim conec As MySqlConnection
        Dim longID As Long
        Dim logPrint As Boolean


        If Me.Tag = "Nuevo" Then
            longID = celdaNumero.Text
            celdaNumero.Text = cfun.Verificacion_Nuevo_Registro(longID, "Dcmtos", 490, celdaAnio.Text)
            If celdaNumero.Text > 0 Then
                If ComprobarCampos() = True Then
                    TraerNota()
                    GuardarEncabezado()
                    GuardarDetalle()

                    GuardarDescargo()
                    'EliminarLineasBultos()
                    GuardarBultos()

                    'Escribe el registro 
                    cfun.EscribirRegistro(Tbl_Documentos, clsFunciones.AccEnum.acAdd, -1, 490, Val(celdaAnio.Text), Val(celdaNumero.Text))

                    If MsgBox("The document has been saved." & vbCr & vbCr & "¿To Print?", vbQuestion + vbYesNo + vbDefaultButton2, "To Print") = vbYes Then
                        Dim intNumero As Integer = INT_CERO
                        Dim intAño As Integer = INT_CERO


                        intNumero = celdaNumero.Text
                        intAño = celdaAnio.Text
                        Dim CReportes As New clsReportes
                        CReportes.Devoluciones(intAño, intNumero)

                    Else
                        MostrarLista()
                        'queryListaPrincipal()
                    End If
                End If
                Me.Tag = "Mod"
            End If

            'ElseIf logEditar Then
        ElseIf Me.Tag = "Mod" Then    'ACTUALIZAR
            If ComprobarCampos() = True Then
                GuardarEncabezado()
                GuardarDetalle()

                GuardarDescargo()
                EliminarLineasBultos()
                GuardarBultos()

                'Dim acUpdate As clsFunciones.AccEnum
                cfun.EscribirRegistro(Tbl_Documentos, clsFunciones.AccEnum.acUpdate, -1, 490, Val(celdaAnio.Text), Val(celdaNumero.Text))

                If MsgBox("The document has been updated." & vbCr & vbCr & "¿To Print?", vbQuestion + vbYesNo + vbDefaultButton2, "To Print") = vbYes Then
                    Dim intNumero As Integer = INT_CERO
                    Dim intAño As Integer = INT_CERO


                    intNumero = celdaNumero.Text
                    intAño = celdaAnio.Text
                    Dim CReportes As New clsReportes
                    CReportes.Devoluciones(intAño, intNumero)
                Else
                    MostrarLista()
                    'queryListaPrincipal()
                End If
            End If
        Else
            MsgBox("It was not possible to classify the operation to save", vbExclamation, "Notice")
        End If
    End Sub

    Private Sub botonCliente_Click(sender As Object, e As EventArgs) Handles botonCliente.Click
        DgDetalle.Rows.Clear()
        dgFactura.Rows.Clear()
        dgOculto.Rows.Clear()

        Dim frm As New frmSeleccionar
        Dim condicion As String = STR_VACIO
        condicion = " cli_sisemp = {empresa}"
        condicion = Replace(condicion, "{empresa}", Sesion.IdEmpresa)
        Me.Tag = "Nuevo"
        Try

            frm.Titulo = "Customers"
            frm.Campos = " cli_codigo IdClient, cli_cliente Client, cli_direccion Direction, cli_nit NIT, cli_moneda IdCurrency, cat_clave Symbol, cat_sist TC "
            frm.Tabla = " Clientes LEFT JOIN Catalogos On cat_num = cli_moneda "
            frm.FiltroText = "Enter the Name Of the Client To Filter"
            frm.Filtro = "cli_cliente"
            frm.Condicion = condicion
            frm.Ordenamiento = "cli_cliente"
            frm.TipoOrdenamiento = "ASC"
            frm.Limite = 30

            frm.ShowDialog(Me)

            If frm.DialogResult = System.Windows.Forms.DialogResult.OK Then
                celdaIdCliente.Text = frm.ListaClientes.SelectedCells(0).Value
                celdaCliente.Text = frm.ListaClientes.SelectedCells(1).Value
                celdaDireccion.Text = frm.ListaClientes.SelectedCells(2).Value
                celdaNIT.Text = frm.ListaClientes.SelectedCells(3).Value
                celdaIdMoneda.Text = frm.ListaClientes.SelectedCells(4).Value
                celdaMoneda.Text = frm.ListaClientes.SelectedCells(5).Value
                celdaTasa.Text = frm.ListaClientes.SelectedCells(6).Value

                rbCliente.Text = celdaCliente.Text
            End If

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub botonClienteE_Click(sender As Object, e As EventArgs) Handles botonClienteE.Click
        Dim strRemplazo As String = STR_VACIO
        Dim frm As New frmSeleccionar
        Dim strFila As String = STR_VACIO

        strRemplazo = "c.cli_sisemp = {empresa}"
        strRemplazo = Replace(strRemplazo, "{empresa}", Sesion.IdEmpresa)


        Try

            frm.Titulo = "Customers"
            frm.Campos = "c.cli_codigo ID, c.cli_cliente Client"
            frm.Tabla = "Clientes c"
            frm.FiltroText = "Enter the Client To filter"
            frm.Filtro = "c.cli_cliente"
            frm.Ordenamiento = "c.cli_cliente"
            frm.TipoOrdenamiento = ""
            frm.Condicion = strRemplazo

            frm.ShowDialog(Me)

            If frm.DialogResult = System.Windows.Forms.DialogResult.OK Then
                celdaClienteE.Text = frm.Dato
            End If

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub botonMoneda_Click(sender As Object, e As EventArgs) Handles botonMoneda.Click
        Dim frm As New frmSeleccionar

        Try
            frm.Titulo = "Coin"
            frm.Campos = "c.cat_clave Coin, c.cat_num ID, c.cat_sist Description"
            frm.Tabla = "Catalogos c"
            frm.FiltroText = " Enter the Coin To filter"
            frm.Filtro = " c.cat_clave "
            frm.Limite = 5
            frm.Ordenamiento = " c.cat_clave "
            frm.TipoOrdenamiento = ""
            frm.Condicion = "cat_clase='Monedas'"

            frm.ShowDialog(Me)

            If frm.DialogResult = System.Windows.Forms.DialogResult.OK Then
                celdaMoneda.Text = frm.LLave
                celdaIdMoneda.Text = frm.Dato
                If frm.Dato2 > 1 Then
                    celdaTasa.Text = cFunciones.TasaSegunFecha(dtpFecha.Value.ToString(FORMATO_MYSQL))
                Else
                    celdaTasa.Text = frm.Dato2
                End If
            End If

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub botonMas_Click(sender As Object, e As EventArgs) Handles botonMas.Click
        Dim frm As New frmSeleccionar
        Dim strRemplazo As String = STR_VACIO
        Dim strFila As String = STR_VACIO

        strRemplazo = "HDoc_Sis_Emp = {empresa} and HDoc_Doc_Cat = 36 and HDoc_Emp_Cod = {codigo}"
        strRemplazo = Replace(strRemplazo, "{empresa}", Sesion.IdEmpresa)
        strRemplazo = Replace(strRemplazo, "{codigo}", celdaIdCliente.Text)

        Try
            frm.Titulo = "Bills"
            frm.Campos = "HDoc_Doc_Num Number, HDoc_Doc_Fec Date, HDoc_DR1_Num Reference, HDoc_Doc_Ano Year, HDoc_Doc_Cat Catalog, HDoc_DR2_Num Series"
            frm.Tabla = "Dcmtos_HDR"
            frm.FiltroText = " Enter the Bills To filter"
            frm.Filtro = " HDoc_Doc_Num "
            frm.Limite = 30
            frm.Ordenamiento = " HDoc_Doc_Num "
            frm.TipoOrdenamiento = "Desc"
            frm.Condicion = strRemplazo

            frm.ShowDialog(Me)

            If frm.DialogResult = System.Windows.Forms.DialogResult.OK Then
                strFila = frm.LLave & "|"
                strFila &= frm.Dato & "|"
                strFila &= frm.Dato2 & "|"
                strFila &= frm.Dato3 & "|"
                strFila &= frm.Dato4

                For i As Integer = 0 To dgFactura.Rows.Count - 1
                    If dgFactura.Rows(i).Cells("colNumeroF").Value = frm.LLave Then
                        MsgBox("Cant not make a repeat of repeated invoices ", MsgBoxStyle.Information)
                        Exit Sub
                    End If
                Next

                cFunciones.AgregarFila(dgFactura, strFila)

                QueryDatosFactura(frm.LLave, frm.Dato3)
                QueryDetalle(frm.LLave, frm.Dato3)
            End If

            'CalcularTotales()

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub botonMenos_Click(sender As Object, e As EventArgs) Handles botonMenos.Click
        Try
            Dim intAÑO As Integer = vbEmpty
            Dim INTnUMERI As Integer = vbEmpty
            Dim COUNT As Integer
            Dim i As Integer
            Dim strTemp As String = STR_VACIO

            If dgFactura.SelectedRows Is Nothing Then Exit Sub

            If dgFactura.Rows.Count > 1 Then
                COUNT = dgFactura.Rows.GetRowCount(DataGridViewElementStates.Selected)
                For i = 0 To COUNT - 1
                    If MsgBox("You sure you want to delete the row Of the Invoicing" & Space(2) & Val(dgFactura.SelectedCells(0).Value) & " ?", vbQuestion + vbYesNo + vbDefaultButton2) = vbYes Then
                        dgFactura.Rows(i).Cells("colAgregar").Value = 2
                        dgFactura.Rows(i).Visible = False
                        'Me.dgFactura.Rows.Remove(dgFactura.SelectedRows(0))
                        DgDetalle.Rows.Clear()
                        NuevoDetalle()
                    End If
                    COUNT = dgFactura.Rows.GetRowCount(DataGridViewElementStates.Selected)
                Next


            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub


    Private Sub botonQuitar_Click(sender As Object, e As EventArgs) Handles botonQuitar.Click
        Try
            Dim intaño As Integer = vbEmpty
            Dim intNumero As Integer = vbEmpty
            Dim Count As Integer

            If DgDetalle.SelectedRows Is Nothing Then Exit Sub

            If DgDetalle.Rows.Count > 1 Then
                Count = DgDetalle.Rows.GetRowCount(DataGridViewElementStates.Selected)
                For i As Integer = 0 To Count - 1
                    If MsgBox("You sure you want to delete the row " & Val(DgDetalle.SelectedCells(6).Value) & " Of the invoicing" & Val(DgDetalle.SelectedCells(5).Value) & " ?", vbQuestion + vbYesNo + vbDefaultButton2) = vbYes Then
                        intNumero = DgDetalle.SelectedCells(5).Value
                        Me.DgDetalle.Rows.Remove(DgDetalle.SelectedRows(0))

                        Count = Count = DgDetalle.Rows.GetRowCount(DataGridViewElementStates.Selected)
                    End If
                Next
            Else
                Exit Sub
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub botonAgregar_Click(sender As Object, e As EventArgs) Handles botonAgregar.Click
        Dim frm As New frmSeleccionar
        Dim strRemplazo As String = STR_VACIO
        Dim strFila As String = STR_VACIO

        If dgFactura.Rows.Count > 0 Then
            strRemplazo = "d.DDoc_Sis_Emp ={empresa} and d.DDoc_Doc_Cat = 36 and d.DDoc_Doc_Num = {numero} and DDoc_Doc_Ano = {anio}"
            strRemplazo = Replace(strRemplazo, "{empresa}", Sesion.IdEmpresa)
            strRemplazo = Replace(strRemplazo, "{numero}", dgFactura.SelectedCells(0).Value)
            strRemplazo = Replace(strRemplazo, "{anio}", dgFactura.SelectedCells(3).Value)

            Try
                frm.Titulo = "Line"
                frm.Campos = " d.DDoc_Prd_Cod Code, d.DDoc_Prd_Des Description, d.DDoc_Doc_Num Invoice, d.DDoc_Doc_Lin Line, d.DDoc_Prd_UM IdMeasure, d.DDoc_Prd_PUQ Price, d.DDoc_RF1_Txt Reference, cat_clave Measure "
                frm.Tabla = " Dcmtos_DTL d left join Catalogos on cat_num = d.DDoc_Prd_UM "
                frm.FiltroText = " Enter the Code To filter"
                frm.Filtro = " d.DDoc_Prd_Cod "
                'frm.Limite =
                frm.Ordenamiento = " d.DDoc_Prd_Cod  "
                frm.TipoOrdenamiento = ""
                frm.Condicion = strRemplazo

                frm.ShowDialog(Me)

                If frm.DialogResult = System.Windows.Forms.DialogResult.OK Then
                    strFila = celdaEmpresa.Text & "|"
                    strFila &= 36 & "|"
                    strFila &= celdaAnio.Text & "|"
                    strFila &= frm.ListaClientes.SelectedCells(0).Value & "|"
                    strFila &= frm.ListaClientes.SelectedCells(1).Value & "|"
                    strFila &= frm.ListaClientes.SelectedCells(2).Value & "|"
                    strFila &= frm.ListaClientes.SelectedCells(3).Value & "|"
                    strFila &= "" & "|"
                    strFila &= "" & "|"
                    strFila &= frm.ListaClientes.SelectedCells(7).Value & "|"
                    strFila &= "" & "|"
                    strFila &= "" & "|"
                    strFila &= frm.ListaClientes.SelectedCells(5).Value & "|"
                    strFila &= "" & "|"
                    strFila &= "" & "|"
                    strFila &= "" & "|"
                    strFila &= "" & "|"
                    strFila &= "" & "|"
                    strFila &= "" & "|"
                    strFila &= 0




                    cFunciones.AgregarFila(DgDetalle, strFila)

                End If
                'CalcularTotales()

            Catch ex As Exception
                MsgBox(ex.ToString)
            End Try
        End If
    End Sub

    Private Sub DgDetalle_DoubleClick(sender As Object, e As EventArgs) Handles DgDetalle.DoubleClick
        Try
            Dim frm As New frmPackingDevoluciones


            Select Case DgDetalle.CurrentCell.ColumnIndex
                Case 12
                    MostrarPackingList()

                Case 15
                    MostrarPackingList()
            End Select
            CalcularTotales()
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub


    Private Sub botonCCosto_DoubleClick(sender As Object, e As EventArgs) Handles botonCCosto.DoubleClick

    End Sub

    Private Sub botonCCosto_Click(sender As Object, e As EventArgs) Handles botonCCosto.Click
        Dim frm As New frmSeleccionar
        Dim strRemplazo As String = STR_VACIO


        strRemplazo = "dep_sisemp ={empresa} "
        strRemplazo = Replace(strRemplazo, "{empresa}", Sesion.IdEmpresa)


        Try
            frm.Titulo = "Cost Center"
            frm.Campos = " dep_no Code, dep_descripcion Description "
            frm.Tabla = " Departamentos "
            frm.FiltroText = " Enter the Cost Center filter"
            frm.Filtro = " dep_descripcion "
            'frm.Limite =
            frm.Ordenamiento = " dep_no  "
            frm.TipoOrdenamiento = ""
            frm.Condicion = strRemplazo

            frm.ShowDialog(Me)

            If frm.DialogResult = System.Windows.Forms.DialogResult.OK Then
                celdaIDCCosto.Text = frm.LLave
                celdaCCosto.Text = frm.Dato
            End If

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub


    Private Sub dgDocumentos_DoubleClick(sender As Object, e As EventArgs) Handles dgDocumentos.DoubleClick
        Dim SDoc As New frmSubDocumentos
        Dim longID As Integer = INT_CERO
        Try



            Dim strDoc As String

            strDoc = dgDocumentos.SelectedCells(0).Value

            If dgDocumentos.SelectedCells(2).Value = "SI" Then
                SDoc.SubDocumento = dgDocumentos.SelectedCells(0).Value
                SDoc.Año = CInt(celdaAnio.Text)
                SDoc.Numero = CInt(celdaNumero.Text)
                SDoc.Catalogo = 490
                SDoc.Doc = strDoc

                SDoc.ShowDialog(Me)
            Else
                dgDocumentos.SelectedCells(2).Value = "NO"

                SDoc.SubDocumento = dgDocumentos.SelectedCells(0).Value
                SDoc.Año = celdaAnio.Text
                SDoc.Numero = celdaNumero.Text
                SDoc.Doc = strDoc
                SDoc.Catalogo = 490
                SDoc.ShowDialog(Me)
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub botonAutorizado_Click(sender As Object, e As EventArgs) Handles botonAutorizado.Click
        Dim frm As New frmSeleccionar
        Dim strRemplazo As String = STR_VACIO


        strRemplazo = "cat_clase = 'Devoluciones' and cat_clave ='Autorizacion'"

        Try
            frm.Titulo = "Approval Returns"
            frm.Campos = " cat_num Number, cat_Desc Description"
            frm.Tabla = " Catalogos "
            frm.FiltroText = " Enter the Descripcion filter"
            frm.Filtro = " cat_Desc "
            'frm.Limite =
            frm.Ordenamiento = " cat_Desc "
            frm.TipoOrdenamiento = "ASC"
            frm.Condicion = strRemplazo

            frm.ShowDialog(Me)

            If frm.DialogResult = System.Windows.Forms.DialogResult.OK Then
                celdaIDAprobado.Text = frm.LLave
                celdaAutorizado.Text = frm.Dato
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub MostrarPackingList()
        Dim frm As New frmPackingDevoluciones
        Dim i As Integer = INT_CERO
        Dim strSQL As String = STR_VACIO
        Dim j As Integer = INT_CERO
        Dim aceptado As Boolean
        Dim strFila As String = STR_VACIO
        Dim taraKG As Double
        Dim KGNetos As Double
        Dim taraLbs As Double
        Dim LBSNetas As Double
        Dim existe As Boolean


        If dgOculto.Rows.Count = 0 Then

            frm.Catalogo = celdaCatalogo.Text
            frm.Linea = DgDetalle.SelectedCells(7).Value
            frm.Numero = celdaNumero.Text
            frm.Anio = celdaAnio.Text
            frm.Medida = DgDetalle.SelectedCells(8).Value
            frm.ShowDialog(Me)

        ElseIf dgOculto.Rows.Count > 0 Then
            For j = 0 To dgOculto.Rows.Count - 1
                If dgOculto.Rows(j).Cells("colLineaDetalle").Value = DgDetalle.SelectedCells(6).Value Then
                    existe = True
                End If
            Next

            If existe = True Then
                For i = 0 To dgOculto.Rows.Count - 1
                    If dgOculto.Rows(i).Cells("colLineaDetalle").Value = DgDetalle.SelectedCells(7).Value Then
                        If dgOculto.Rows(i).Cells("colXtraBox").Value = 1 Or dgOculto.Rows(i).Cells("colXtraBox").Value = 0 Then
                            strFila = dgOculto.Rows(i).Cells("colPaquetes").Value & "|"
                            If DgDetalle.SelectedCells(8).Value = 69 Then
                                taraKG = CDbl(dgOculto.Rows(i).Cells("colTara").Value / 2.2046)
                                KGNetos = (dgOculto.Rows(i).Cells("colCantidadMedida").Value / 2.2046)
                                taraLbs = dgOculto.Rows(i).Cells("colTara").Value
                                LBSNetas = dgOculto.Rows(i).Cells("colCantidadMedida").Value

                                strFila &= taraKG.ToString(FORMATO_MONEDA) & "|"
                                strFila &= taraLbs.ToString(FORMATO_MONEDA) & "|"
                                strFila &= KGNetos.ToString(FORMATO_MONEDA) & "|"
                                strFila &= (taraKG + KGNetos).ToString(FORMATO_MONEDA) & "|"
                                strFila &= LBSNetas.ToString(FORMATO_MONEDA) & "|"
                                strFila &= (taraLbs + LBSNetas).ToString(FORMATO_MONEDA) & "|"
                                strFila &= dgOculto.Rows(i).Cells("colReferenciaBox").Value & "|"
                                strFila &= 1 & "|"
                                'strFila &= dgOculto.Rows(i).Cells("colXtraBox").Value & "|"
                                strFila &= dgOculto.Rows(i).Cells("colLineaDetalle").Value & "|"
                                strFila &= dgOculto.Rows(i).Cells("colLineaBox").Value
                            Else
                                taraKG = CDbl((dgOculto.Rows(i).Cells("colTara").Value) / 2.2046)
                                KGNetos = (dgOculto.Rows(i).Cells("colCantidadMedida").Value / 2.2046)
                                taraLbs = dgOculto.Rows(i).Cells("colTara").Value
                                LBSNetas = CDbl((dgOculto.Rows(i).Cells("colCantidadMedida").Value))

                                strFila &= taraKG.ToString(FORMATO_MONEDA) & "|"
                                strFila &= taraLbs.ToString(FORMATO_MONEDA) & "|"
                                strFila &= KGNetos.ToString(FORMATO_MONEDA) & "|"
                                strFila &= (taraKG + KGNetos).ToString(FORMATO_MONEDA) & "|"
                                strFila &= LBSNetas.ToString(FORMATO_MONEDA) & "|"
                                strFila &= (taraLbs + LBSNetas).ToString(FORMATO_MONEDA) & "|"
                                strFila &= dgOculto.Rows(i).Cells("colReferenciaBox").Value & "|"
                                strFila &= 1 & "|"
                                strFila &= dgOculto.Rows(i).Cells("colLineaDetalle").Value & "|"
                                strFila &= dgOculto.Rows(i).Cells("colLineaBox").Value

                            End If
                            cFunciones.AgregarFila(frm.dgDetalle, strFila)
                        End If
                    End If
                Next
            End If
            frm.Catalogo = celdaCatalogo.Text
            frm.Linea = DgDetalle.SelectedCells(7).Value
            frm.Numero = Val(celdaNumero.Text)
            frm.Anio = (celdaAnio.Text)
            frm.ShowDialog(Me)
        End If


        aceptado = frm.Aceptado
        If aceptado = True Then
            For k As Integer = 0 To frm.dgDetalle.Rows.Count - 1
                If frm.dgDetalle.Rows(k).Cells("colXtraPack").Value = 0 Then
                    Dim Contador As Integer
                    Dim NDuplica As Boolean
                    Contador = dgOculto.Rows.Count - 1

                    'dgOculto.Rows.Clear()

                    'For i = 0 To frm.dgDetalle.Rows.Count - 1
                    '    For k As Integer = 0 To Contador
                    '        If dgOculto.Rows(k).Cells("colLineaDetalle").Value = frm.dgDetalle.Rows(i).Cells("colLineaDet").Value And
                    '           dgOculto.Rows(k).Cells("colLineaBox").Value = frm.dgDetalle.Rows(i).Cells("colLineaPack").Value Then
                    '            'dgOculto.Rows(k).Cells("colXtraBox").Value = frm.dgDetalle.Rows(i).Cells("colXtraPack").Value Then

                    '        Else
                    '            dgOculto.Rows.Remove(dgOculto.Rows(k))
                    '            Contador = dgOculto.Rows.Count - 1
                    '            Exit For

                    '        End If
                    '    Next
                    'Next

                    strSQL = celdaEmpresa.Text & "|"
                    strSQL &= frm.celdaCatalogo.Text & "|"
                    strSQL &= celdaAnio.Text & "|"
                    strSQL &= celdaNumero.Text & "|"
                    strSQL &= frm.dgDetalle.Rows(k).Cells("colLineaDet").Value & "|"
                    'lineaDet = frm.dgDetalle.Rows(i).Cells("colLineaDet").Value
                    strSQL &= frm.dgDetalle.Rows(k).Cells("colLineaPack").Value & "|"
                    'lineaPack = frm.dgDetalle.Rows(i).Cells("colLineaPack").Value
                    strSQL &= frm.dgDetalle.Rows(k).Cells("colReferencia").Value & "|"
                    'If DgDetalle.SelectedCells(8).Value = 69 Then
                    strSQL &= frm.dgDetalle.Rows(k).Cells("colTaraLbs").Value & "|"
                    'Else
                    'strSQL &= frm.dgDetalle.Rows(k).Cells("colTara").Value & "|"
                    'End If

                    strSQL &= frm.dgDetalle.Rows(k).Cells("colBultos").Value & "|"
                    'If DgDetalle.SelectedCells(8).Value = 69 Then
                    strSQL &= frm.dgDetalle.Rows(k).Cells("colLibrasNetas").Value & "|"
                    'ElseIf DgDetalle.SelectedCells(8).Value = 70 Then
                    '    strSQL &= frm.dgDetalle.Rows(k).Cells("colKilosNetos").Value & "|"
                    'End If
                    strSQL &= frm.dgDetalle.Rows(k).Cells("colXtraPack").Value


                    cFunciones.AgregarFila(dgOculto, strSQL)
                    'Next
                ElseIf frm.dgDetalle.Rows(k).Cells("colXtraPack").Value = 2 Then
                    For l As Integer = 0 To dgOculto.Rows.Count - 1
                        If dgOculto.Rows(l).Cells("colLineaDetalle").Value = frm.dgDetalle.Rows(k).Cells("colLineaDet").Value And
                           dgOculto.Rows(l).Cells("colLineaBox").Value = frm.dgDetalle.Rows(k).Cells("colLineaPack").Value Then

                            dgOculto.Rows(l).Cells("colXtraBox").Value = 2

                        End If

                    Next


                End If
            Next
            'Next

            If frm.DialogResult = System.Windows.Forms.DialogResult.OK Then
                DgDetalle.SelectedCells(12).Value = frm.LLave
                DgDetalle.SelectedCells(15).Value = frm.Dato
                DgDetalle.SelectedCells(16).Value = frm.Dato2

                If DgDetalle.SelectedCells(8).Value = 69 Then
                    DgDetalle.SelectedCells(13).Value = (Val(DgDetalle.SelectedCells(13).Value)).ToString(FORMATO_MONEDA)
                    DgDetalle.SelectedCells(14).Value = (Val(DgDetalle.SelectedCells(13).Value * 2.2046)).ToString(FORMATO_MONEDA)
                Else
                    DgDetalle.SelectedCells(14).Value = (Val(DgDetalle.SelectedCells(14).Value)).ToString(FORMATO_MONEDA)
                    DgDetalle.SelectedCells(13).Value = (Val(DgDetalle.SelectedCells(14).Value / 2.2046)).ToString(FORMATO_MONEDA)
                End If
            End If
        End If
    End Sub

    Public Sub New()

        ' Llamada necesaria para el diseñador.
        InitializeComponent()

        ' Agregue cualquier inicialización después de la llamada a InitializeComponent().

    End Sub

    Private Sub botonActualizar_Click(sender As Object, e As EventArgs) Handles botonActualizar.Click
        Dim logCancelar As Boolean

        If CDate(dtpInicial.Value) > CDate(dtpFinal.Value) Then
            MsgBox("The start date may not exceed the final date", vbExclamation, "Notice")
            logCancelar = True
        End If
        If Not (logCancelar) Then
            queryListaPrincipal()
        End If
    End Sub

    Private Sub dgLista_DoubleClick(sender As Object, e As EventArgs) Handles dgLista.DoubleClick
        LimpiarCampos()
        Dim intAnio As Integer = 0
        Dim intNumero As Integer = 0

        Try
            If dgLista.SelectedRows.Count = INT_CERO Then Exit Sub
            Me.Tag = "Mod"

            intAnio = dgLista.SelectedCells(5).Value
            intNumero = dgLista.SelectedCells(0).Value
            SeleccionarCliente(intAnio, intNumero)
            queryDetalleD(intNumero, intAnio)
            queryFacturas()
            queryCargarCajas()
            CargarSubdocumentos(intNumero, intAnio)

            CalcularTotales()
            botonImprimir.Enabled = True
            botonImprimirPackingList.Enabled = True

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub botonImprimir_Click(sender As Object, e As EventArgs) Handles botonImprimir.Click
        Dim intNumero As Integer = INT_CERO
        Dim intAño As Integer = INT_CERO


        intNumero = celdaNumero.Text
        intAño = celdaAnio.Text
        Dim CReportes As New clsReportes
        CReportes.Devoluciones(intAño, intNumero)

    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles botonImprimirPackingList.Click
        Dim intNumero As String = STR_VACIO
        Dim intAño As String = STR_VACIO

        intNumero = Val(celdaNumero.Text)
        intAño = Val(celdaAnio.Text)
        Dim CReportes As New clsReportes
        CReportes.ReportePackingListDevoluciones(intAño, intNumero)

        MostrarLista(False)
    End Sub

    Private Sub dgOculto_CellContentClick(sender As Object, e As DataGridViewCellEventArgs) Handles dgOculto.CellContentClick

    End Sub



#End Region

    Private Sub dgLista_CellContentClick(sender As Object, e As DataGridViewCellEventArgs) Handles dgLista.CellContentClick

    End Sub

    Private Sub Encabezado1_Load(sender As Object, e As EventArgs) Handles Encabezado1.Load

    End Sub

    Private Sub dtpFecha_ValueChanged(sender As Object, e As EventArgs) Handles dtpFecha.ValueChanged
        If celdaTasa.Text > 1 Then
            celdaTasa.Text = cFunciones.TasaSegunFecha(dtpFecha.Value.ToString(FORMATO_MYSQL))
        End If
    End Sub
End Class