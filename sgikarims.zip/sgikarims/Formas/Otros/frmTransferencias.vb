﻿Imports System
Imports System.IO
'Imports Microsoft.Office.Core
'Imports Microsoft.Office.Interop.Excel
Imports System.Data


Public Class frmTransferencias
    Private Structure ProvTrans
        Dim codigo As Integer
        Dim nombre As String
        Dim direccion As String
        Dim telefono As String
        Dim nit As String
        Dim plazo As Integer
    End Structure

    Dim ProveedorT As ProvTrans
    Dim ArticuloT As Integer = 0
    Dim Cat_Padre As Integer = NO_FILA
    Dim Ano_Padre As Integer = NO_FILA
    Dim Num_Padre As Integer = NO_FILA

    Dim Cat_Hijo As Integer = NO_FILA
    Dim Ano_Hijo As Integer = NO_FILA
    Dim Num_Hijo As Integer = NO_FILA
    Dim Existe As Integer = NO_FILA
    Dim Correlativo As Integer = 0
    Dim EmpTransf As Integer = NO_FILA
    Dim BaseTransf As String = STR_VACIO

    Dim strKey As String = STR_VACIO
    Dim logInsertar As Boolean = False
    Dim logConsultar As Boolean = False
    Dim logEditar As Boolean = False
    Dim LogBorrar As Boolean = False
    Dim cfun As New clsFunciones

    Private Sub GuardarDEC(ByVal cat As Integer, ByVal año As Integer, ByVal num As Integer, ByVal lin As Integer)
        Dim DEC As New Tablas.TDCMTOS_DEC
        Dim strSQL As String = STR_VACIO
        Dim REA As MySqlDataReader
        Dim cone As MySqlConnection
        Dim COM As MySqlCommand

        strSQL &= " select  db.EDoc_Lin_Frac  arancel , db.EDoc_Lin_Desc descripcion from Dcmtos_DTL_Pro t  "
        strSQL &= " left join Dcmtos_DTL_Pro f on f.PDoc_Sis_Emp = t.PDoc_Sis_Emp and f.PDoc_Chi_Cat = t.PDoc_Par_Cat and f.PDoc_Chi_Ano = t.PDoc_Par_Ano and f.PDoc_Chi_Num = t.PDoc_Par_Num and f.PDoc_Chi_Lin = t.PDoc_Par_Lin   "
        strSQL &= " left join Dcmtos_DTL_Pro i on i.PDoc_Sis_Emp = f.PDoc_Sis_Emp and i.PDoc_Chi_Cat = f.PDoc_Par_Cat and i.PDoc_Chi_Ano = f.PDoc_Par_Ano and i.PDoc_Chi_Num = f.PDoc_Par_Num and i.PDoc_Chi_Lin = f.PDoc_Par_Lin and i.PDoc_Par_Cat = 47  "
        strSQL &= " left join Dcmtos_DTL_Pro p on p.PDoc_Sis_Emp = i.PDoc_Sis_Emp and p.PDoc_Chi_Cat = i.PDoc_Par_Cat and p.PDoc_Chi_Ano = i.PDoc_Par_Ano and p.PDoc_Chi_Num = i.PDoc_Par_Num and p.PDoc_Chi_Lin = i.PDoc_Par_Lin   "
        strSQL &= " left join Dcmtos_DEC db on db.EDoc_Sis_Emp = p.PDoc_Sis_Emp and db.EDoc_Doc_Cat = p.PDoc_Par_Cat and db.EDoc_Doc_Ano = p.PDoc_Par_Ano and db.EDoc_Doc_Num = p.PDoc_Par_Num and db.EDoc_Doc_Lin = p.PDoc_Par_Lin   "
        strSQL &= " where t.PDoc_Sis_Emp = {empresa} and t.PDoc_Chi_Cat = {catalogo} and  t.PDoc_Chi_Ano = {ano} and t.PDoc_Chi_Num = {numero} and t.PDoc_Par_Lin = {linea}  "

        strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
        strSQL = Replace(strSQL, "{catalogo}", 45)
        strSQL = Replace(strSQL, "{ano}", CeldaAño.Text)
        strSQL = Replace(strSQL, "{numero}", CeldaNumero.Text)
        strSQL = Replace(strSQL, "{linea}", lin)
        Try
            cone = New MySqlConnection(strConexion)
            cone.Open()
            COM = New MySqlCommand(strSQL, cone)
            REA = COM.ExecuteReader
            If REA.HasRows = True Then
                REA.Read()
                DEC.EDOC_SIS_EMP = EmpTrasnferencia()
                DEC.EDOC_DOC_ANO = año
                DEC.EDOC_DOC_CAT = cat
                DEC.EDOC_DOC_NUM = num
                DEC.EDOC_DOC_LIN = 1
                DEC.EDOC_LIN_FRAC = REA.GetString("arancel")
                DEC.EDOC_LIN_DESC = REA.GetString("descripcion")
                DEC.CONEXION = StringTransaccion()
                If DEC.PINSERT = False Then
                    MsgBox(DEC.MERROR.ToString)
                End If
            End If
            cone.Close()
        Catch ex As Exception
            MsgBox(ex.ToString)
        Finally
            DEC.Dispose()
            DEC = Nothing

        End Try
    End Sub


    Private Sub RecuperarProveedorTrans()
        Dim strSQL As String = STR_VACIO
        Dim REA As MySqlDataReader
        Dim COM As MySqlCommand
        Try
            strSQL = "SELECT pro_codigo,pro_proveedor,pro_nombre,pro_direccion,pro_telefono,pro_nit, pro_plazoCR " & _
                 "FROM Catalogos ctl " & _
                 "left join Proveedores cli on cli.pro_sisemp = ctl.cat_sisemp and cli.pro_codigo = ctl.cat_clave " & _
                 "WHERE ctl.cat_clase = 'Defaults' and ctl.cat_pid = {empresa} and ctl.cat_sist = 'DEF_PROTRANS' "

            strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)

            MyCnn.CONECTAR = StringTransaccion()
            COM = New MySqlCommand(strSQL, CON)
            REA = COM.ExecuteReader
            If REA.HasRows Then
                REA.Read()
                ProveedorT.codigo = REA.GetInt32("pro_codigo")
                ProveedorT.nombre = REA.GetString("pro_proveedor")
                ProveedorT.direccion = REA.GetString("pro_direccion")
                ProveedorT.nit = REA.GetString("pro_nit")
                ProveedorT.telefono = REA.GetString("pro_telefono")
                ProveedorT.plazo = REA.GetInt32("pro_plazoCR")
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Public Function buscarRegistro(ByVal empresa As Integer, ByVal catalogo As Integer, ByVal referencia As String, ByVal conexion As String) As Integer
        Dim strSQL As String = ""
        Dim CON As MySqlConnection
        Dim COM As MySqlCommand
        Dim Existe As Integer = 0



        strSQL = "SELECT COUNT(*) EXISTE " & _
                 "FROM Dcmtos_HDR " & _
                 "WHERE HDoc_Sis_Emp = {empresa} AND HDoc_Doc_Cat = {cat} AND HDoc_DR1_Num =  '{referencia}' "

        strSQL = Replace(strSQL, "{empresa}", empresa)
        strSQL = Replace(strSQL, "{cat}", catalogo)
        strSQL = Replace(strSQL, "{referencia}", referencia.Trim)


        CON = New MySqlConnection(conexion)
        CON.Open()


        Try
            COM = New MySqlCommand(strSQL, CON)
            Existe = COM.ExecuteScalar

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try


        CON.Close()

        Return Existe

    End Function

    Public Function buscarNumero(ByVal empresa As Integer, ByVal catalogo As Integer, ByVal referencia As String, ByVal conexion As String) As Integer
        Dim strSQL As String = ""
        Dim CON As MySqlConnection
        Dim COM As MySqlCommand
        Dim ExisteNum As Integer = 0



        strSQL = "SELECT HDoc_Doc_Num Numero " & _
                 "FROM Dcmtos_HDR " & _
                 "WHERE HDoc_Sis_Emp = {empresa} AND HDoc_Doc_Cat = {cat} AND HDoc_DR1_Num =  '{referencia}' "

        strSQL = Replace(strSQL, "{empresa}", empresa)
        strSQL = Replace(strSQL, "{cat}", catalogo)
        strSQL = Replace(strSQL, "{referencia}", referencia.Trim)


        CON = New MySqlConnection(conexion)
        CON.Open()


        Try
            COM = New MySqlCommand(strSQL, CON)
            ExisteNum = COM.ExecuteScalar

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try

        CON.Close()

        Return ExisteNum

    End Function

    Private Sub Reset()
        lblcodMoneda.Text = 178
        dgvTransferencia.Rows.Clear()
    End Sub

    Public Property Key As String

        Get
            Return strKey
        End Get
        Set(value As String)
            strKey = value
        End Set

    End Property

    Public Function BuscarTransferencia(Optional ByVal cat As Integer = 0) As Integer

        Dim strSQL As String = STR_VACIO
        Dim CON As MySqlConnection
        Dim COM As MySqlCommand
        Dim Valor As Integer = INT_CERO

        strSQL = "SELECT count(*) Existe " & _
                 "FROM Dcmtos_HDR " & _
                 "WHERE HDoc_Sis_Emp = {empresa} and HDoc_Doc_Cat = {catalogo} AND HDoc_Doc_Num =  {numero} AND HDoc_Doc_Ano = {año} "

        strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
        strSQL = Replace(strSQL, "{catalogo}", cat)
        strSQL = Replace(strSQL, "{numero}", CeldaNumero.Text)
        strSQL = Replace(strSQL, "{año}", CeldaAño.Text)

        CON = New MySqlConnection(strConexion)
        CON.Open()

        Try
            COM = New MySqlCommand(strSQL, CON)
            Valor = COM.ExecuteScalar

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try

        CON.Close()


        Return Valor

    End Function

    Private Sub Seleccionar(ByVal intNumero As Integer, ByVal intAÑo As Integer)
        SeleccionarEncabezado(intNumero, intAÑo)
        SeleccionarDetalle(intNumero, intAÑo)
    End Sub

    Private Sub SeleccionarEncabezado(ByVal intNumero As Integer, ByVal intAÑo As Integer)
        Dim cHDR As New clsDcmtos_HDR
        Dim strCampos As String = STR_VACIO
        Dim strCondicion As String = STR_VACIO
        strCampos = "HDoc_Doc_Num, HDoc_Doc_Ano, HDoc_Doc_Fec,HDoc_Emp_Cod,HDoc_Emp_Nom,HDoc_Emp_Dir,HDoc_Doc_TC,HDoc_Doc_Mon,HDoc_DR1_Cat,HDoc_DR1_Num,HDoc_RF1_Txt,HDoc_RF2_Cod"
        strCondicion = "HDoc_Doc_Num = {numero} AND HDoc_Doc_Ano = {año} AND HDoc_Doc_Cat =  {catalogo} AND HDoc_Sis_Emp = {empresa}"
        strCondicion = Replace(strCondicion, "{numero}", intNumero)
        strCondicion = Replace(strCondicion, "{año}", intAÑo)
        strCondicion = Replace(strCondicion, "{catalogo}", 45)
        strCondicion = Replace(strCondicion, "{empresa}", Sesion.IdEmpresa)

        Try
            cHDR.CONEXION = strConexion

            If cHDR.Seleccionar(strCondicion, strCampos) = True Then

                CeldaNumero.Text = cHDR.HDOC_DOC_NUM.ToString
                CeldaAño.Text = cHDR.HDOC_DOC_ANO.ToString
                dtpFecha.Value = CDate(cHDR.HDOC_DOC_FEC)
                txtSat.Text = cHDR.HDOC_RF2_COD
                CeldaCliente.Text = cHDR.HDOC_EMP_NOM
                lblTasa.Text = cHDR.HDOC_DOC_TC.ToString
                CeldaMoneda.Text = cHDR.HDOC_DOC_MON

            Else

                MsgBox(cHDR.MERROR.ToString)

            End If

        Catch ex As Exception

            MsgBox(ex.ToString)

        End Try
    End Sub


    Private Function UnidadMedida(ByVal codPeso As Integer) As String
        Dim strSQL As String = STR_VACIO
        Dim CON As MySqlConnection
        Dim COM As MySqlCommand
        Dim strValor As String = STR_VACIO

        strSQL = "SELECT cat_clave " & _
                 "From Catalogos " & _
                 "Where cat_num = {codPeso}"

        strSQL = Replace(strSQL, "{codPeso}", codPeso)

        CON = New MySqlConnection(strConexion)
        CON.Open()


        Try

            COM = New MySqlCommand(strSQL, CON)
            strValor = COM.ExecuteScalar


        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try

        CON.Close()

        Return strValor
    End Function

    Private Function tipoBulto(ByVal numero As Integer, ByVal año As Integer, ByVal Linea As Integer) As String
        Dim strSQL As String = STR_VACIO
        Dim CON As MySqlConnection
        Dim COM As MySqlCommand
        Dim Valor As String = STR_VACIO


        strSQL = "SELECT Fact.DDoc_RF2_Txt " & _
                 "FROM Dcmtos_HDR A " & _
                 "LEFT JOIN Dcmtos_DTL DTL ON DTL.DDoc_Sis_Emp = A.HDoc_Sis_Emp AND DTL.DDoc_Doc_Cat = A.HDoc_Doc_Cat AND  " & _
                 "DTL.DDoc_Doc_Ano = A.HDoc_Doc_Ano AND DTL.DDoc_Doc_Num = A.HDoc_Doc_Num " & _
                 "LEFT JOIN Dcmtos_DTL_Pro PRO ON PRO.PDoc_Sis_Emp = DTL.DDoc_Sis_Emp AND PRO.PDoc_Chi_Cat = DTL.DDoc_Doc_Cat AND " & _
                 "PRO.PDoc_Chi_Ano = DTL.DDoc_Doc_Ano AND PRO.PDoc_Chi_Num = DTL.DDoc_Doc_Num AND PRO.PDoc_Chi_Lin = DTL.DDoc_Doc_Lin " & _
                 "LEFT JOIN Dcmtos_DTL Fact ON Fact.DDoc_Sis_Emp = A.HDoc_Sis_Emp AND Fact.DDoc_Doc_Cat = PRO.PDoc_Par_Cat AND " & _
                 "Fact.DDoc_Doc_Ano = PRO.PDoc_Par_Ano AND Fact.DDoc_Doc_Num = PRO.PDoc_Par_Num AND  Fact.DDoc_Doc_Lin = PRO.PDoc_Par_Lin " & _
                 "WHERE A.HDoc_Sis_Emp = {empresa} AND A.HDoc_Doc_Cat = 45 AND A.HDoc_Doc_Ano = {año} AND A.HDoc_Doc_Num = {numero} AND Fact.DDoc_Doc_Lin = {linea} "

        strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
        strSQL = Replace(strSQL, "{año}", año)
        strSQL = Replace(strSQL, "{numero}", numero)
        strSQL = Replace(strSQL, "{linea}", Linea)


        CON = New MySqlConnection(strConexion)
        CON.Open()


        Try

            COM = New MySqlCommand(strSQL, CON)
            Valor = COM.ExecuteScalar

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try

        CON.Close()

        Return Valor

    End Function



    Private Sub SeleccionarDetalle(ByVal intNumero As Integer, ByVal intAÑo As Integer)

        Dim cDTL As New clsDcmtos_DTL

        Dim strCampos As String = STR_VACIO
        Dim strCondicion As String = STR_VACIO
        Dim strFIla As String = STR_VACIO
        Dim Contador As Integer = 1

        strCampos = "0,0,0, DDoc_Prd_Cod, DDoc_Prd_Des, DDoc_Prd_NET,DDoc_Prd_QTY,  DDoc_RF1_Txt, DDoc_Prd_UM,DDoc_RF2_Num ,DDoc_RF2_Txt, DDoc_RF1_Dbl "

        strCondicion = "DDoc_Doc_Num = {numero} AND DDoc_Doc_Ano = {año} AND DDoc_Doc_Cat =  {catalogo} AND DDoc_Sis_Emp = {empresa}"
        strCondicion = Replace(strCondicion, "{numero}", intNumero)
        strCondicion = Replace(strCondicion, "{año}", intAÑo)
        strCondicion = Replace(strCondicion, "{catalogo}", 45)
        strCondicion = Replace(strCondicion, "{empresa}", Sesion.IdEmpresa)

        Try
            cDTL.CONEXION = strConexion
            If cDTL.SeleccionarLista(strCondicion, strCampos) = True Then

                Do While cDTL.SiguienteRegistro = True

                    strFIla = 0 & "|" & 0 & "|" & 0 & "|" & cDTL.DDOC_PRD_COD & "|" & cDTL.DDOC_PRD_DES & "|" & cDTL.DDOC_PRD_NET & "|" & cDTL.DDOC_PRD_QTY & "|" & cDTL.DDOC_PRD_NET * cDTL.DDOC_PRD_QTY & "|" & cDTL.DDOC_RF1_TXT & "|" & cDTL.DDOC_PRD_UM & "|" & UnidadMedida(cDTL.DDOC_PRD_UM) & "|" & cDTL.DDOC_RF2_NUM & "|" & tipoBulto(intNumero, intAÑo, Contador) & "|" & cDTL.DDOC_RF1_DBL
                    cfun.AgregarFila(dgvTransferencia, strFIla)
                    CeldaMonto.Text = MontoActualizado().ToString(FORMATO_MONEDA)

                    Contador = Contador + 1
                Loop

            Else
                MsgBox(cDTL.MERROR.ToString)
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try

    End Sub

    Private Sub Accessos()

        Dim cAccesos As New clsAccesos
        Try
            If cAccesos.Accesos(strKey) = True Then
                logInsertar = cAccesos.Insertar
                logConsultar = cAccesos.Consultar
                logEditar = cAccesos.Editar
                LogBorrar = cAccesos.Borrar
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try

    End Sub

    Private Sub BloquearBotones(Optional ByVal logBloquear As Boolean = True)

        If logBloquear = True Then

            Encabezado1.botonBorrar.Enabled = False
            Encabezado1.botonGuardar.Enabled = False
            'btnIngreso.Enabled = True
            botonImprimir.Enabled = False

        Else

            Encabezado1.botonBorrar.Enabled = True
            Encabezado1.botonGuardar.Enabled = True
            'btnIngreso.Visible = True
            botonImprimir.Enabled = True

        End If

    End Sub

    Private Function SQlLista() As String
        Dim strSQL As String = STR_VACIO

        strSQL = "select h.HDoc_Doc_Num Correlativo, h.HDoc_Doc_Ano Ciclo, h.HDoc_Doc_Fec Date, h.HDoc_Emp_Nom Custumer, "
        strSQL &= "ifnull((  "
        strSQL &= "Select format(Round(sum(d.DDoc_Prd_QTY * d.DDoc_Prd_NET),2),2) "
        strSQL &= "from Dcmtos_DTL d "
        strSQL &= "where d.DDoc_Sis_Emp = h.HDoc_Sis_Emp and d.DDoc_Doc_Cat = h.HDoc_Doc_Cat and d.DDoc_Doc_Num = h.HDoc_Doc_Num ),0) Total,h.HDoc_RF2_Cod Clave "
        strSQL &= ",if(h.HDoc_Doc_Status =1,'ON','OFF') Active from Dcmtos_HDR h "
        strSQL &= "where  h.HDoc_Sis_Emp = {empresa} and h.HDoc_Doc_Cat= {CAT_ORD} "
        If checkFechas.Checked = True Then
            strSQL &= " and h.HDoc_Doc_Fec between '{inicio}' and '{fin}' "
            strSQL = Replace(strSQL, "{inicio}", dtpInicio.Value.ToString(FORMATO_MYSQL))
            strSQL = Replace(strSQL, "{fin}", dtpFin.Value.ToString(FORMATO_MYSQL))
        End If
        strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
        strSQL = Replace(strSQL, "{CAT_ORD}", 45)

        Return strSQL

    End Function

    Public Function mostrarEmpresa() As String

        Dim strSQL As String = STR_VACIO
        Dim Valor As String = STR_VACIO
        Dim COM As MySqlCommand
        Dim CON As MySqlConnection

        strSQL = "SELECT cli_cliente " & _
                 "FROM Catalogos ctl " & _
                 "left join Clientes cli on cli.cli_sisemp = ctl.cat_sisemp and cli.cli_codigo = ctl.cat_clave " & _
                 "WHERE ctl.cat_clase = 'Defaults' and ctl.cat_sisemp = {empresa} and ctl.cat_sist = 'DEF_CUSTRANS' "

        strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)

        CON = New MySqlConnection(strConexion)
        CON.Open()

        Try

            COM = New MySqlCommand(strSQL, CON)
            Valor = COM.ExecuteScalar

        Catch ex As Exception

            MsgBox(ex.ToString)

        End Try

        CON.Close()

        Return Valor

    End Function

    Public Sub LimpiarCampos()
        lblañot.Text = INT_CERO
        lblcodCustomer.Text = INT_CERO
        lblcodMoneda.Text = INT_CERO
        lblnumerot.Text = INT_CERO
        lblTasa.Text = INT_CERO
        CeldaMonto.Text = INT_CERO
        CeldaMoneda.Text = STR_VACIO
    End Sub

    Private Sub MostrarLista(Optional ByVal logMostrar As Boolean = True, Optional logInsert As Boolean = False)
        Dim cfun As New clsFunciones
        If logMostrar = True Then
            'ocultar panel de documento
            panelDocumento.Dock = DockStyle.None
            panelDocumento.Visible = False
            'actualizar Titulo
            BarraTitulo1.CambiarTitulo("Transferencias")
            'Cargar Datos
            cfun.CargarLista(dgLista, SQlLista, False)
            'Mostrar Panel Filtro
            panelLista.Visible = True
            panelLista.Dock = DockStyle.Fill
            BloquearBotones()
            Me.Tag = ""
        Else
            Dim referencias As String = STR_VACIO
            'Ocultar Panel Filtro
            BloquearBotones()
            panelLista.Visible = False
            panelLista.Dock = DockStyle.None
            'Mostrar panel de documento
            panelDocumento.Dock = DockStyle.Fill
            panelDocumento.Visible = True

            For i As Integer = 0 To dgvTransferencia.Rows.Count - 1
                Dim empresa As Integer = 0

                empresa = EmpTrasnferencia()

                referencias = dgvTransferencia.Rows(i).Cells("colRef").Value

                If buscarRegistro(empresa, 47, referencias, StringTransaccion) = 1 Then
                    ' btnIngreso.Enabled = False

                Else
                    'btnIngreso.Enabled = True
                End If

            Next

            'Verifica si se va a crear un nuevo documento o se va modifica
            If logInsert = False Then
                BarraTitulo1.CambiarTitulo("Modificar Registro")
                Me.Tag = "Mod"
                BloquearBotones()
                botonImprimir.Enabled = True
            Else
                BarraTitulo1.CambiarTitulo("Nuevo Registro")
                Me.Tag = "Nuevo"
                BloquearBotones(False)
                botonImprimir.Enabled = False
                Reset()
            End If

            dgLista.DataSource = Nothing
        End If
    End Sub

    Private Sub Encabezado1_ClickCerrar(sender As Object, click As Boolean) Handles Encabezado1.ClickCerrar

        If panelDocumento.Visible = True Then

            MostrarLista()
            BloquearBotones(True)
            Button1.Enabled = False
        Else
            Me.Close()
        End If

    End Sub

    Private Sub Encabezado1_ClickGuardar(sender As Object, click As Boolean) Handles Encabezado1.ClickGuardar
        'GuardarEncabezado()

        Try
            GuardarEncabezado(75)
            GuardarEncabezado(48)
            GuardarEncabezado(36)
            GuardarEncabezado(45)

            Button1.Enabled = True
        Catch ex As Exception
            MsgBox(ex.ToString)
            Button1.Enabled = False
        End Try


    End Sub

    Private Sub Encabezado1_ClickNuevo(sender As Object, click As Boolean) Handles Encabezado1.ClickNuevo

        MostrarLista(False)
        BloquearBotones(False)
        LimpiarCampos()
        dbTrasnferencia()
        dtpFecha.Value = cfun.HoyMySQL
        dgvTransferencia.Rows.Clear()
        btnAgregar.Enabled = True
        btnQuitar.Enabled = True
        Button1.Enabled = False
        lblTasa.Text = cfun.QueryTasa(dtpFecha.Value.ToString(FORMATO_MYSQL))
        txtSat.Text = ""
        lblcodMoneda.Text = 178
        CeldaMoneda.Text = "US$"

    End Sub

    Private Sub frmTransferencias_FormClosing(sender As Object, e As FormClosingEventArgs) Handles Me.FormClosing
        frmSPrincipal.BarraDeTareas1.QuitarFormulario(strKey)
    End Sub

    Private Sub frmTransferencias_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        RecuperarProveedorTrans()
        EmpTransf = EmpTrasnferencia()
        BaseTransf = BaseTransferencia()
        dtpFin.Value = Today
        dtpInicio.Value = dtpFin.Value.AddMonths(NO_FILA)
        Accessos()
        Button1.Enabled = False
        MostrarLista()
        CeldaCliente.Text = mostrarEmpresa()

    End Sub

    Private Function MontoActualizado() As Double ' Suma el total de cada fila agregada a el dgvTransferencia
        Dim dblMonto As Double = INT_CERO ' inicializa el monto a 0
        Dim celda As DataGridViewCell

        For i As Integer = 0 To dgvTransferencia.Rows.Count - 1 ' Ciclo para 
            celda = dgvTransferencia.Rows(i).Cells(7)
            dblMonto = dblMonto + celda.Value
        Next

        Return dblMonto

    End Function

    Public Sub GuardarEncabezado(ByVal cat As Integer, Optional ByVal Referencia As String = STR_VACIO)
        Dim HDR As New clsDcmtos_HDR
        Dim strSQL As String = STR_VACIO
        Dim intANo As Integer = NO_FILA
        Dim Numero As Integer = 0
        Dim CorrelativoPride As Integer = 0

        Dim intNum As Integer = NO_FILA
        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader
        Dim CON As MySqlConnection

        Ano_Padre = Ano_Hijo
        Num_Padre = Num_Hijo
        Cat_Padre = Cat_Hijo

        strSQL = "SELECT cli_codigo,cli_cliente,cli_nombre,cli_direccion,cli_telefono,cli_nit, cli_plazoCR " & _
                 "FROM Catalogos ctl " & _
                 "left join Clientes cli on cli.cli_sisemp = ctl.cat_sisemp and cli.cli_codigo = ctl.cat_clave " & _
                 "WHERE ctl.cat_clase = 'Defaults' and ctl.cat_sisemp = {empresa} and ctl.cat_sist = 'DEF_CUSTRANS' "

        strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)

        CON = New MySqlConnection(strConexion)

        CON.Open()

        COM = New MySqlCommand(strSQL, CON)
        REA = COM.ExecuteReader

        intANo = cFunciones.AñoMySQL
        intNum = cFunciones.NuevoId(cat)

        If Sesion.IdEmpresa = 8 Then
            CorrelativoPride = FacturaCorrelativo()
        End If

        Try

            If REA.HasRows Then

                Do While REA.Read

                    lblcodCustomer.Text = REA.GetInt32("cli_codigo")
                    CeldaCliente.Text = REA.GetString("cli_cliente")

                    HDR.HDOC_SIS_EMP = Sesion.IdEmpresa
                    HDR.HDOC_DOC_CAT = cat
                    HDR.HDOC_DOC_ANO = intANo
                    HDR.HDOC_DOC_NUM = intNum
                    HDR.HDoc_Doc_Fec_NET = dtpFecha.Value
                    HDR.HDOC_EMP_COD = CInt(lblcodCustomer.Text)
                    HDR.HDOC_EMP_NOM = REA.GetString("cli_cliente")
                    HDR.HDOC_EMP_DIR = REA.GetString("cli_direccion")
                    HDR.HDOC_EMP_TEL = REA.GetString("cli_telefono")
                    HDR.HDOC_EMP_NIT = REA.GetString("cli_nit")

                    HDR.HDOC_DOC_MON = CInt(lblcodMoneda.Text)
                    HDR.HDOC_DOC_TC = CDbl(lblTasa.Text)
                    HDR.HDOC_USUARIO = Sesion.Usuario

                    'contactos

                    HDR.HDOC_EMP_PER = "N/A"
                    HDR.HDOC_EMP_TEL = "N/A"
                    HDR.HDOC_RF2_COD = "N/A"
                    HDR.HDOC_RF1_COD = "N/A"

                    'campos propios de cada docuemento

                    Select Case cat

                        Case 127

                            HDR.HDOC_DR1_NUM = Referencia


                        Case 55

                            HDR.HDOC_DR1_NUM = Referencia

                        Case 180

                            HDR.HDOC_DR1_NUM = Referencia

                        Case 75

                            HDR.HDOC_DR1_CAT = cat
                            HDR.HDOC_DR1_NUM = "PF-" & intNum
                            HDR.HDoc_DR1_Fec_NET = dtpFecha.Value
                            HDR.HDOC_DR1_EMP = HDR.HDOC_EMP_COD
                            HDR.HDOC_DR2_CAT = HDR.HDOC_DOC_MON
                            HDR.HDOC_DR2_NUM = HDR.HDOC_DOC_TC
                            HDR.HDOC_RF1_TXT = HDR.HDOC_EMP_DIR
                            HDR.HDOC_RF2_TXT = "TRANSFERENCIA"

                        Case 36

                            HDR.HDOC_DR2_CAT = INT_CERO
                            If Sesion.IdEmpresa = 8 Then
                                HDR.HDOC_DR2_NUM = "3"
                            Else
                                HDR.HDOC_DR2_NUM = "A"
                            End If

                            HDR.HDOC_RF1_NUM = INT_UNO
                            HDR.HDOC_RF2_NUM = REA.GetInt32("cli_plazoCR")
                            HDR.HDOC_DR1_DBL = CorrelativoPride

                        Case 45

                            HDR.HDOC_RF2_COD = txtSat.Text

                    End Select

                    HDR.HDOC_DOC_STATUS = INT_UNO

                    If HDR.Guardar() = True Then

                        Num_Hijo = intNum
                        Ano_Hijo = intANo
                        Cat_Hijo = cat
                        GuardarDetalle(cat, intANo, intNum)

                    Else

                        MsgBox(HDR.MERROR.ToString)

                    End If

                Loop

            End If

            MostrarLista(True)

            CON.Close()

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub


    Private Function FabricanteTransferencia(ByVal inv As Integer) As Integer
        Dim intResult As Integer = NO_FILA
        Dim COM As MySqlCommand
        Dim strSQL As String = STR_VACIO

        Try
            MyCnn.CONECTAR = strConexion
            strSQL &= " select  ifnull(p.prov_destino,-1)  from Inventarios i "
            strSQL &= " left join Transferencia.Proveedores p on p.prov_origen = i.inv_provcod and p.emp_origen = i.inv_sisemp and p.emp_destino = {empresatransf} "
            strSQL &= " where i.inv_sisemp = {empresa} and i.inv_numero ={inventario} "

            strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
            strSQL = Replace(strSQL, "{inventario}", inv)
            strSQL = Replace(strSQL, "{empresatransf}", EmpTransf)
            COM = New MySqlCommand(strSQL, CON)
            intResult = COM.ExecuteScalar
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        Return intResult
    End Function



    Public Function datosSubdocumentos(ByVal Requisito As String)
        Dim strSQL As String = STR_VACIO
        Dim Valores As String = STR_VACIO
        Dim COM As MySqlCommand
        Dim CON As MySqlConnection


        For i As Integer = 0 To dgvTransferencia.Rows.Count - 1
            Dim Inventario As Integer = 0

            Inventario = dgvTransferencia.Rows(i).Cells("colCodigo").Value


            strSQL = "SELECT {requisito} " & _
               "FROM Inventarios inv " & _
               "LEFT JOIN Catalogos cat On cat.cat_num = inv.inv_lugarfab AND cat.cat_clase = 'Paises' " & _
               "LEFT JOIN Articulos art On art.art_sisemp = inv.inv_sisemp AND art.art_codigo = inv.inv_artcodigo " & _
               "LEFT JOIN Proveedores pro On pro.pro_sisemp = inv.inv_sisemp and pro.pro_codigo = inv.inv_provcod " & _
               "WHERE inv_sisemp = {empresa} and inv_numero = {inventario} "

            strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
            strSQL = Replace(strSQL, "{inventario}", Inventario)
            strSQL = Replace(strSQL, "{requisito}", Requisito)


            CON = New MySqlConnection(strConexion)
            CON.Open()


            Try

                COM = New MySqlCommand(strSQL, CON)
                Valores = Valores & "/" & COM.ExecuteScalar

            Catch ex As Exception
                MsgBox(ex.ToString)
            End Try
        Next

        Return Valores

    End Function

    Private Sub GuardarDetalle(ByVal cat As Integer, ByVal ano As Integer, ByVal num As Integer)

        Dim DTL As New clsDcmtos_DTL
        Dim PRO As New clsDcmtos_DTL_Pro
        Dim BOX As New Tablas.TDCMTOS_DTL_BOX
        Dim ACC As New Tablas.TDCMTOS_ACC
        Dim BanderaACC As Integer = 0

        For i As Integer = 0 To dgvTransferencia.Rows.Count - 1

            DTL.DDOC_SIS_EMP = Sesion.IdEmpresa
            DTL.DDOC_DOC_CAT = cat
            DTL.DDOC_DOC_ANO = ano
            DTL.DDOC_DOC_NUM = num
            DTL.DDOC_DOC_LIN = i + 1
            DTL.DDoc_RF1_Fec_NET = dtpFecha.Value
            DTL.DDOC_RF1_NUM = CInt(lblcodCustomer.Text)
            DTL.DDOC_PRD_COD = dgvTransferencia.Rows(i).Cells("colCodigo").Value
            DTL.DDOC_PRD_DES = dgvTransferencia.Rows(i).Cells("colDescripcion").Value
            DTL.DDOC_PRD_PUQ = dgvTransferencia.Rows(i).Cells("colPrecio").Value

            If cat = 45 Then

                DTL.DDOC_RF2_NUM = dgvTransferencia.Rows(i).Cells("colBultos").Value
                DTL.DDOC_RF2_TXT = dgvTransferencia.Rows(i).Cells("colType").Value
                DTL.DDOC_RF1_DBL = dgvTransferencia.Rows(i).Cells("colImpresion").Value
            End If

            If cat = 36 Then

                DTL.DDOC_RF2_NUM = dgvTransferencia.Rows(i).Cells("colBultos").Value
                DTL.DDOC_RF2_TXT = dgvTransferencia.Rows(i).Cells("colType").Value
                DTL.DDOC_RF1_COD = DTL.DDOC_PRD_COD
                BOX.CONEXION = strConexion
                BOX.BDOC_SIS_EMP = Sesion.IdEmpresa
                BOX.BDOC_DOC_CAT = cat
                BOX.BDOC_DOC_ANO = ano
                BOX.BDOC_DOC_NUM = num
                BOX.BDOC_DOC_LIN = DTL.DDOC_DOC_LIN
                BOX.BDOC_BOX_LIN = 1
                BOX.BDOC_BOX_COD = "1"
                BOX.BDOC_BOX_QTY = dgvTransferencia.Rows(i).Cells("colBultos").Value
                BOX.BDOC_BOX_LB = dgvTransferencia.Rows(i).Cells("colCantidad").Value

                If BOX.PINSERT = False Then
                    MsgBox(BOX.MERROR.ToString)
                End If


                If Sesion.IdEmpresa = 8 Then

                    If BanderaACC = 0 Then
                        Dim proveedores As String = STR_VACIO
                        Dim paises As String = STR_VACIO
                        Dim mill As String = STR_VACIO

                        proveedores = datosSubdocumentos("pro.pro_proveedor Proveedor")
                        paises = datosSubdocumentos("cat.cat_desc Pais")
                        mill = datosSubdocumentos("art.art_desc Mill")


                        Try

                            For j As Integer = 0 To 11

                                ACC.CONEXION = strConexion
                                ACC.ADOC_SIS_EMP = Sesion.IdEmpresa
                                ACC.ADOC_DOC_CAT = cat
                                ACC.ADOC_DOC_ANO = ano
                                ACC.ADOC_DOC_NUM = num
                                ACC.ADOC_DOC_SUB = "Doc_HFDatos"
                                ACC.ADoc_Dta_Fec_NET = "01/01/2001"

                                ACC.ADOC_DTA_TXT = ""
                                ACC.ADOC_DTA_CHR = ""

                                Select Case j

                                    Case 0
                                        ACC.ADOC_DOC_LIN = "01"
                                        ACC.ADOC_DTA_DES = "Cuenta y Riesgo de:"
                                        ACC.ADOC_DTA_TXT = "PRIDE YARN, S. DE R.L."

                                    Case 1
                                        ACC.ADOC_DOC_LIN = "03"
                                        ACC.ADOC_DTA_DES = "Nº de Contenedor"
                                        ACC.ADOC_DTA_CHR = ""

                                    Case 2
                                        ACC.ADOC_DOC_LIN = "04"
                                        ACC.ADOC_DTA_DES = "1. Lugar de Carga"
                                        ACC.ADOC_DTA_TXT = "ZOLI HONDURAS"

                                    Case 3
                                        ACC.ADOC_DOC_LIN = "05"
                                        ACC.ADOC_DTA_DES = "2. Destino Final"
                                        ACC.ADOC_DTA_TXT = "ZOLI HONDURAS"

                                    Case 4
                                        ACC.ADOC_DOC_LIN = "06"
                                        ACC.ADOC_DTA_DES = "3. Transporte"
                                        ACC.ADOC_DTA_CHR = " "

                                    Case 5
                                        ACC.ADOC_DOC_LIN = "08"
                                        ACC.ADOC_DTA_DES = "5. Mills"
                                        ACC.ADOC_DTA_CHR = proveedores

                                    Case 6
                                        ACC.ADOC_DOC_LIN = "09"
                                        ACC.ADOC_DTA_DES = "6. Origin"
                                        ACC.ADOC_DTA_CHR = paises

                                    Case 7
                                        ACC.ADOC_DOC_LIN = "10"
                                        ACC.ADOC_DTA_DES = "7. Nota"
                                        ACC.ADOC_DTA_TXT = " "

                                    Case 8
                                        ACC.ADOC_DOC_LIN = "11"
                                        ACC.ADOC_DTA_DES = "8. Wire"
                                        ACC.ADOC_DTA_TXT = "WIRE FUNDS PAYABLE TO PRIDE MANUFACTURING BANK: TD BANK MIAMI, FLORIDA ABA # 067-014-822 ACCT # 4247-000-378 SWIFT: NRTHUS33"

                                    Case 9
                                        ACC.ADOC_DOC_LIN = "13"
                                        ACC.ADOC_DTA_DES = "10. Hilados"
                                        ACC.ADOC_DTA_CHR = mill

                                    Case 10
                                        ACC.ADOC_DOC_LIN = "15"
                                        ACC.ADOC_DTA_DES = "13. Nombre de Conductor"
                                        ACC.ADOC_DTA_CHR = " "

                                    Case 11
                                        ACC.ADOC_DOC_LIN = "17"
                                        ACC.ADOC_DTA_DES = "14. Placas de Cabezal"
                                        ACC.ADOC_DTA_CHR = " "

                                    Case Else
                                        MsgBox("Error al Momento de Generar el SubDocumento")

                                End Select

                                If ACC.PINSERT = False Then
                                    MsgBox(ACC.MERROR.ToString)
                                End If

                            Next



                        Catch ex As Exception

                            MsgBox(ex.ToString)

                        End Try

                        BanderaACC = 1

                    End If


                End If

            End If

            DTL.DDOC_PRD_NET = dgvTransferencia.Rows(i).Cells("colPrecio").Value
            DTL.DDOC_PRD_QTY = dgvTransferencia.Rows(i).Cells("colCantidad").Value
            DTL.DDOC_PRD_FOB = dgvTransferencia.Rows(i).Cells("colTotal").Value
            DTL.DDOC_PRD_UM = dgvTransferencia.Rows(i).Cells("colMedida").Value
            DTL.DDOC_RF3_NUM = dgvTransferencia.Rows(i).Cells("colMedida").Value ' se Agrego la unidad de medida a esa columna
            DTL.DDOC_RF1_TXT = dgvTransferencia.Rows(i).Cells("colRef").Value

            If DTL.Guardar = True Then

                If cat = 48 Then

                    PRO.PDOC_SIS_EMP = Sesion.IdEmpresa
                    PRO.PDOC_PAR_CAT = 47
                    PRO.PDOC_PAR_ANO = dgvTransferencia.Rows(i).Cells("colAño").Value
                    PRO.PDOC_PAR_NUM = dgvTransferencia.Rows(i).Cells("colNumero").Value
                    PRO.PDOC_PAR_LIN = dgvTransferencia.Rows(i).Cells("colLinea").Value
                    PRO.PDOC_CHI_CAT = 48
                    PRO.PDOC_CHI_ANO = ano
                    PRO.PDOC_CHI_NUM = num
                    PRO.PDOC_CHI_LIN = i + 1
                    PRO.PDOC_QTY_ORD = dgvTransferencia.Rows(i).Cells("colCantidad").Value
                    PRO.PDOC_QTY_PRO = dgvTransferencia.Rows(i).Cells("colCantidad").Value

                    If PRO.Guardar = True Then
                        'MsgBox("Datos Almacenados con Existo" & num)
                    End If

                End If

                If cat <> 75 Then
                    GuardarPro(cat, ano, num, i, DTL.DDOC_PRD_QTY, DTL.DDOC_PRD_COD)
                End If

                If PRO.Guardar = True Then
                    'MsgBox("Datos Almacenados con Exito" & num)
                End If

            End If

        Next

    End Sub

    Private Sub GuardarPro(ByVal cat As Integer, ByVal ano As Integer, ByVal num As Integer, ByVal lin As Integer, ByVal descargo As Double, ByVal cliente As Integer)
        Dim PRO As New clsDcmtos_DTL_Pro

        Try
            PRO.PDOC_SIS_EMP = Sesion.IdEmpresa
            PRO.PDOC_PAR_CAT = Cat_Padre
            PRO.PDOC_PAR_ANO = Ano_Padre
            PRO.PDOC_PAR_NUM = Num_Padre
            PRO.PDOC_PAR_LIN = lin + 1
            PRO.PDOC_CHI_CAT = cat
            PRO.PDOC_CHI_ANO = ano
            PRO.PDOC_CHI_NUM = num
            PRO.PDOC_CHI_LIN = lin + 1
            PRO.PDOC_PROV_COD = cliente
            PRO.PDOC_QTY_ORD = descargo
            PRO.PDOC_QTY_PRO = descargo
            If PRO.Guardar = False Then
                MsgBox(PRO.MERROR.ToString)
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub btnSeleccionar_Click(sender As Object, e As EventArgs) Handles btnSeleccionar.Click
        Dim frmSelecionar As New frmSeleccionar
        Dim strTabla As String = STR_VACIO
        Dim strCondicion As String = STR_VACIO

        strCondicion = "cat_clase = 'Monedas'"

        frmSelecionar.Tabla = "Catalogos"
        frmSelecionar.Campos = "cat_num,cat_clave "
        frmSelecionar.Condicion = strCondicion

        If frmSelecionar.ShowDialog = System.Windows.Forms.DialogResult.OK Then
            lblcodMoneda.Text = frmSelecionar.LLave
            CeldaMoneda.Text = frmSelecionar.Dato
        End If

    End Sub

    Private Sub btnAgregar_Click(sender As Object, e As EventArgs) Handles btnAgregar.Click

        Dim frm As New frmSeleccionar
        Dim frmmjs As New frmMensaje
        Dim dblCantidad As Double = 0
        Dim dblBultos As Double = 0
        Const dblCentavo As Double = 0.01

        frm.Tabla = " Inventarios i left join Articulos a on a.art_sisemp = i.inv_sisemp and a.art_codigo = i.inv_artcodigo left join Catalogos c on c.cat_num = i.inv_lugarfab "
        frm.Campos = " i.inv_artcodigo Code, a.art_DCorta Yarn,  c.cat_num id_source, c.cat_desc Source "
        frm.Condicion = " i.inv_sisemp = " & Sesion.IdEmpresa & " and i.inv_generico = 1 "
        frm.Limite = 20
        frm.Filtro = " a.art_DCorta "
        frm.Titulo = " Generics Codes "
        frm.FiltroText = " Enter the description of the yarn to filter out "
        If frm.ShowDialog = System.Windows.Forms.DialogResult.OK Then

            frmmjs.Mensaje = "Consulting Data"
            frmmjs.Show()
            system.Windows.Forms.Application.DoEvents()
            ' MsgBox(frm.LLave & frm.Dato & frm.Dato2 & frm.Dato3)
            Dim frm2 As New frmSeleccionar

            frm2.Tabla &= " (select a.art_DCorta des, h.HDoc_DR1_Num  ref ,i.inv_sisemp empresa,  d.DDoc_Doc_Cat cat , d.DDoc_Doc_Ano ano , d.DDoc_Doc_Num  num , d.DDoc_Doc_Lin lin , i.inv_numero numero,  i.inv_artcodigo articulo, i.inv_provcod proveedor, i.inv_lugarfab origen , sum(d.DDoc_Prd_QTY) ingresos, sum(b.BDoc_Box_QTY ) bultosi,"
            frm2.Tabla &= " ifnull(( select round( sum( if(di.DDoc_Prd_UM = d.DDoc_Prd_UM , di.DDoc_Prd_QTY , if(di.DDoc_Prd_UM = 69,di.DDoc_Prd_QTY /2.2046, di.DDoc_Prd_QTY *2.2046))),2) from Dcmtos_DTL_Pro p  "
            frm2.Tabla &= " left join Dcmtos_DTL  di on di.DDoc_Sis_Emp = p.PDoc_Sis_Emp and di.DDoc_Doc_Cat = p.PDoc_Chi_Cat and di.DDoc_Doc_Ano = p.PDoc_Chi_Ano and di.DDoc_Doc_Num =p.PDoc_Chi_Num AND di.DDoc_Doc_Lin =p.PDoc_Chi_Lin "
            frm2.Tabla &= " left join Dcmtos_HDR h on h.HDoc_Sis_Emp = di.DDoc_Sis_Emp and h.HDoc_Doc_Cat = di.DDoc_Doc_Cat and h.HDoc_Doc_Ano = di.DDoc_Doc_Ano and h.HDoc_Doc_Num = di.DDoc_Doc_Num "
            frm2.Tabla &= " where p.PDoc_Sis_Emp =d.DDoc_Sis_Emp and p.PDoc_Par_Cat = d.DDoc_Doc_Cat and p.PDoc_Par_Ano = d.DDoc_Doc_Ano and p.PDoc_Par_Num = d.DDoc_Doc_Num and p.PDoc_Par_Lin =d.DDoc_Doc_Lin  and p.PDoc_Chi_Cat  = 48 and h.HDoc_Doc_Status = 1 "
            frm2.Tabla &= " ),0) egresos, "

            frm2.Tabla &= " ifnull((  "
            frm2.Tabla &= "  select sum(be.BDoc_Box_QTY) from Dcmtos_DTL_Pro p "
            frm2.Tabla &= "  left join Dcmtos_DTL     di on di.DDoc_Sis_Emp = p.PDoc_Sis_Emp and di.DDoc_Doc_Cat = p.PDoc_Chi_Cat and di.DDoc_Doc_Ano = p.PDoc_Chi_Ano and di.DDoc_Doc_Num =p.PDoc_Chi_Num AND di.DDoc_Doc_Lin =p.PDoc_Chi_Lin "
            frm2.Tabla &= "  left join Dcmtos_HDR h on h.HDoc_Sis_Emp = di.DDoc_Sis_Emp and h.HDoc_Doc_Cat = di.DDoc_Doc_Cat and h.HDoc_Doc_Ano = di.DDoc_Doc_Ano and h.HDoc_Doc_Num = di.DDoc_Doc_Num "
            frm2.Tabla &= "  left join Dcmtos_DTL_Box  be on be.BDoc_Sis_Emp =di.DDoc_Sis_Emp and be.BDoc_Doc_Cat = di.DDoc_Doc_Cat and be.BDoc_Doc_Ano = di.DDoc_Doc_Ano and be.BDoc_Doc_Num = di.DDoc_Doc_Num and be.BDoc_Doc_Lin = di.DDoc_Doc_Lin "
            frm2.Tabla &= "  where p.PDoc_Sis_Emp =d.DDoc_Sis_Emp and p.PDoc_Par_Cat = d.DDoc_Doc_Cat and p.PDoc_Par_Ano = d.DDoc_Doc_Ano and p.PDoc_Par_Num = d.DDoc_Doc_Num and p.PDoc_Par_Lin =d.DDoc_Doc_Lin  and p.PDoc_Chi_Cat  = 48 and h.HDoc_Doc_Status = 1 "
            frm2.Tabla &= "  ), 0) bultose "

            frm2.Tabla &= " from Inventarios i"
            frm2.Tabla &= " left join Articulos a on a.art_sisemp = i.inv_sisemp and a.art_codigo = i.inv_artcodigo"
            frm2.Tabla &= " left join Dcmtos_DTL d on d.DDoc_Sis_Emp = i.inv_sisemp and d.DDoc_Doc_Cat = 47 and d.DDoc_Prd_Cod = i.inv_numero "
            frm2.Tabla &= " left join Dcmtos_HDR h on h.HDoc_Sis_Emp = d.DDoc_Sis_Emp and h.HDoc_Doc_Cat = d.DDoc_Doc_Cat and h.HDoc_Doc_Ano = d.DDoc_Doc_Ano and h.HDoc_Doc_Num = d.DDoc_Doc_Num "
            frm2.Tabla &= " left join Dcmtos_DTL_Box b on b.BDoc_Sis_Emp = d.DDoc_Sis_Emp and b.BDoc_Doc_Cat = d.DDoc_Doc_Cat and b.BDoc_Doc_Ano = d.DDoc_Doc_Ano and b.BDoc_Doc_Num = d.DDoc_Doc_Num and b.BDoc_Doc_Lin = d.DDoc_Doc_Lin "

            frm2.Campos = "  cast(concat( ki.ano  , '-',ki.num  ,'-', ki.lin  ) as char) document,  ki.des Yarn,round((ki.ingresos-ki.egresos),2) stock,ifnull(if((ki.bultosi - ki.bultose)<=0,1,(ki.bultosi - ki.bultose)),1) bultos, ki.ref  reference "
            frm2.Condicion = " i.inv_sisemp = {empresa} and i.inv_artcodigo = {articulo} and i.inv_lugarfab = {origen}  "
            frm2.Condicion &= " group by d.DDoc_Sis_Emp , d.DDoc_Doc_Cat , d.DDoc_Doc_Ano , d.DDoc_Doc_Num , d.DDoc_Doc_Lin )ki  "
            frm2.Condicion &= " having stock>0.9 "

            frm2.Condicion = Replace(frm2.Condicion, "{empresa}", Sesion.IdEmpresa)
            frm2.Condicion = Replace(frm2.Condicion, "{articulo}", frm.LLave)
            frm2.Condicion = Replace(frm2.Condicion, "{origen}", frm.Dato2)

            frm2.Limite = 20
            'frm2.Filtro = " a.art_DCorta "
            frm2.Titulo = " Generics Codes "
            frm2.FiltroText = " Enter the description of the yarn to filter out "
            If frm2.ShowDialog = System.Windows.Forms.DialogResult.OK Then
                dblCantidad = CDbl(frm2.Dato2)
                dblBultos = CDbl(frm2.Dato3)


                Dim COM As MySqlCommand
                Dim REA As MySqlDataReader
                Dim strSQL As String = STR_VACIO
                Dim array() As String
                Dim strlinea As String = STR_VACIO

                Try
                    array = frm2.LLave.Split("-".ToCharArray)

                    strSQL &= " select d.DDoc_Doc_Ano ano,d.DDoc_Prd_UM unidad, d.DDoc_Doc_Num num, d.DDoc_Doc_Lin lin , d.DDoc_Prd_Cod cod , d.DDoc_Prd_Des des , d.DDoc_Prd_NET precio,Cat.cat_clave Peso, h.HDoc_DR1_Num ref from Dcmtos_DTL d  "
                    strSQL &= " left join Catalogos Cat On Cat.cat_num = d.DDoc_Prd_UM "
                    strSQL &= " left join Dcmtos_HDR h on h.HDoc_Sis_Emp = d.DDoc_Sis_Emp and h.HDoc_Doc_Cat = d.DDoc_Doc_Cat and h.HDoc_Doc_Ano = d.DDoc_Doc_Ano and h.HDoc_Doc_Num = d.DDoc_Doc_Num "
                    strSQL &= " where d.DDoc_Sis_Emp ={empresa} and d.DDoc_Doc_Cat = 47 and d.DDoc_Doc_Ano = {ano} and d.DDoc_Doc_Num ={num} and d.DDoc_Doc_Lin ={lin} "

                    strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
                    strSQL = Replace(strSQL, "{ano}", array(0))
                    strSQL = Replace(strSQL, "{num}", array(1))
                    strSQL = Replace(strSQL, "{lin}", array(2))
                    MyCnn.CONECTAR = strConexion
                    COM = New MySqlCommand(strSQL, CON)
                    REA = COM.ExecuteReader
                    If REA.HasRows = True Then
                        REA.Read()
                        strlinea = REA.GetInt32("ano") & "|" & REA.GetInt32("num") & "|" & REA.GetInt32("lin") & "|" & REA.GetInt32("cod") & "|" & REA.GetString("des") & "|" & FormatNumber(REA.GetDouble("precio") + dblCentavo, 2) & "|" &
                                   dblCantidad & "|" & ((REA.GetDouble("precio")) + dblCentavo).ToString(FORMATO_MONEDA) & "|" & REA.GetString("ref") & "|" & REA.GetInt32("unidad") & "|" & REA.GetString("Peso") & "|" & dblBultos
                        cFunciones.AgregarFila(dgvTransferencia, strlinea)
                    End If

                    'se asigna la suma total de cada fila agregadad al dgvTransferencia 
                    'y se le da un formato de N valores ,2 decimales
                    CeldaMonto.Text = FormatNumber(MontoActualizado(), 2)

                Catch ex As Exception
                    MsgBox(ex.ToString)
                End Try
            End If
            frmmjs.Close()
        End If

    End Sub

    Private Sub btnQuitar_Click(sender As Object, e As EventArgs) Handles btnQuitar.Click
        ' Elimina una fila seleccionada del dgvTransferencia y Actualiza el monto si fuera llamada
        If dgvTransferencia.SelectedRows.Count = INT_CERO Then Exit Sub
        dgvTransferencia.Rows.Remove(dgvTransferencia.CurrentRow)
        CeldaMonto.Text = FormatNumber(MontoActualizado(), 2)
    End Sub

    Private Sub btnImprimir_Click(sender As Object, e As EventArgs) Handles botonImprimir.Click

        Try

            If Sesion.IdEmpresa = 8 Then
                'GenerarDeclaracionUnica()
            Else

                Dim cRep As New clsReportes
                Dim origenes As New clsClaimRegister

                cRep.RepTransferencia(CeldaAño.Text, CeldaNumero.Text)
                cRep.Parent = frmSeleccionar

            End If


        Catch ex As Exception

            MsgBox(ex.ToString)

        End Try

    End Sub

    Public Function CrearCarpeta(ByVal CodTransferencia As Integer)

        Dim exist As Boolean
        Dim bandera As Integer = 1

        exist = System.IO.Directory.Exists(My.Computer.FileSystem.SpecialDirectories.MyDocuments & "\Transferencia\" & "Transferencia" & CodTransferencia)

        If exist = 0 Then
            System.IO.Directory.CreateDirectory(My.Computer.FileSystem.SpecialDirectories.MyDocuments & "\Transferencia\" & "Transferencia" & CodTransferencia)
        Else
            bandera = 1
        End If

        Return bandera

    End Function


    'Private Sub GenerarDeclaracionUnica()

    '    Dim CON As MySqlConnection
    '    Dim COM As MySqlCommand
    '    Dim REA As MySqlDataReader
    '    Dim CON1 As MySqlConnection
    '    Dim COM1 As MySqlCommand
    '    Dim REA1 As MySqlDataReader
    '    Dim acFob As Double = 0
    '    Dim strSQL As String = STR_VACIO
    '    Dim strSQL1 As String = STR_VACIO
    '    Dim reporte As New clsReportes
    '    Dim NumeroCelda As Integer = 36
    '    Dim bandera As Integer = 0
    '    Dim bandera1 As Integer = 0


    '    strSQL = reporte.TransferenciaArancelario(CeldaNumero.Text, CeldaAño.Text)
    '    strSQL1 = reporte.TransferenciaPoliza(CeldaNumero.Text, CeldaAño.Text)


    '    CON = New MySqlConnection(strConexion)
    '    CON.Open()

    '    CON1 = New MySqlConnection(strConexion)
    '    CON1.Open()

    '    Try

    '        COM = New MySqlCommand(strSQL, CON)
    '        REA = COM.ExecuteReader

    '        COM1 = New MySqlCommand(strSQL1, CON1)
    '        REA1 = COM1.ExecuteReader


    '        If REA.HasRows Then
    '            If REA1.HasRows Then

    '                Dim xLibro = New Microsoft.Office.Interop.Excel.Application
    '                xLibro.CopyObjectsWithCells = True

    '                CrearCarpeta(CeldaNumero.Text)

    '                With xLibro
    '                    Dim temp As String
    '                    Dim strExcelUbicacion = My.Computer.FileSystem.SpecialDirectories.MyDocuments & "\" & "Transferencia\Transferencia" & CeldaNumero.Text & "\"

    '                    strExcelUbicacion = strExcelUbicacion + " Transferencia " & CeldaNumero.Text & ".xlsx"
    '                    temp = "C:\Sistema.Net\DUAZHTRASLADOMERCADERIAPRIDEMFGZH.xls"
    '                    .Workbooks.Add(temp)

    '                    Do While REA1.Read
    '                        If bandera1 = 0 Then
    '                            .Range("F20").Value = "000-003-01-" & REA1.GetString("CPride")
    '                            bandera1 = 1
    '                        End If
    '                    Loop


    '                    Do While REA.Read

    '                        Dim Seguro As Double = 0
    '                        Dim Flete As Double = 0
    '                        Dim Fob As Double = 0
    '                        Dim TotalFob As Double = 0

    '                        Fob = REA.GetDouble("Fob")
    '                        Flete = Fob * 0.1
    '                        Seguro = Fob * 0.015

    '                        .Range("B" & NumeroCelda).Value = REA.GetInt32("Bulto")
    '                        .Range("C" & NumeroCelda).Value = "CJS"
    '                        If bandera = 0 Then

    '                            .Range("C30").Value = REA.GetDouble("Tasa")
    '                            bandera = 1
    '                        End If

    '                        TotalFob = Fob + Flete + Seguro

    '                        .Range("D" & NumeroCelda).Value = REA.GetDouble("Cantidad")
    '                        .Range("E" & NumeroCelda).Value = REA.GetString("Arancelaria")
    '                        .Range("F" & NumeroCelda).Value = REA.GetString("Mercaderia")
    '                        .Range("K" & NumeroCelda).Value = TotalFob

    '                        NumeroCelda = NumeroCelda + 1

    '                        acFob = acFob + Fob

    '                    Loop
    '                    .Range("D30").Value = acFob
    '                    .Range("F" & NumeroCelda).Value = "********** U. L. **********"

    '                    xLibro.ActiveWorkbook.SaveAs(strExcelUbicacion)
    '                    xLibro.Visible = True
    '                    ' xLibro.ActiveWorkbook.Close()
    '                    '  xLibro.Quit()


    '                End With

    '            End If

    '        End If

    '        CON.Close()
    '        CON1.Close()
    '        REA.Close()

    '    Catch ex As Exception
    '        MsgBox(ex.ToString)
    '    End Try

    'End Sub

    Private Sub dgLista_DoubleClick(sender As Object, e As EventArgs) Handles dgLista.DoubleClick
        Dim intID As Integer = NO_FILA
        Dim intAño As Integer = NO_FILA
        Dim strClave As String = STR_VACIO

        Try

            If dgLista.SelectedRows.Count = INT_CERO Then Exit Sub
            Me.Tag = "mod"
            BarraTitulo1.CambiarTitulo("Modificar Registro")
            intID = dgLista.SelectedCells(0).Value
            intAño = dgLista.SelectedCells(1).Value
            strClave = dgLista.SelectedCells(5).Value
            btnAgregar.Enabled = False
            btnQuitar.Enabled = False
            Reset()
            Seleccionar(intID, intAño)

            If strClave.Length > 4 Then
                Button1.Enabled = False

            Else
                Button1.Enabled = True
            End If

            BloquearBotones()
            'lblTasa.Text = cfun.QueryTasa(dtpFecha.Value.ToString(FORMATO_MYSQL))
            MostrarLista(False)
        Catch ex As Exception

            MsgBox(ex.ToString)

        End Try
    End Sub

    Public Function dbTrasnferencia() As String
        Dim strSQL As String = STR_VACIO
        Dim CON As MySqlConnection
        Dim COM As MySqlCommand
        Dim BD As String = STR_VACIO

        strSQL = "SELECT cat_dato " & _
                 "FROM Catalogos " & _
                 "WHERE cat_sisemp = {empresa} AND cat_clase = 'Defaults' AND cat_sist = 'DEF_CUSTRANS'  "


        strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)

        CON = New MySqlConnection(strConexion)
        CON.Open()

        Try

            COM = New MySqlCommand(strSQL, CON)
            BD = COM.ExecuteScalar

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try

        CON.Close()

        Return BD

    End Function

    Private Function EmpTrasnferencia() As Integer
        Dim strSQL As String = STR_VACIO
        Dim CON As MySqlConnection
        Dim COM As MySqlCommand
        Dim Empresa As Integer = NO_FILA

        strSQL = "SELECT cat_pid " & _
                 "FROM Catalogos " & _
                 "WHERE cat_sisemp = {empresa} AND cat_clase = 'Defaults' AND cat_sist = 'DEF_CUSTRANS'  "


        strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)

        CON = New MySqlConnection(strConexion)
        CON.Open()

        Try

            COM = New MySqlCommand(strSQL, CON)
            Empresa = COM.ExecuteScalar

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try

        Return Empresa

    End Function
    Private Function BaseTransferencia() As String
        Dim Base As String = STR_VACIO
        Dim strSQL As String = STR_VACIO
        Dim CON As MySqlConnection
        Dim COM As MySqlCommand

        strSQL = "SELECT cat_ext " & _
                 "FROM Catalogos " & _
                 "WHERE cat_sisemp = {empresa} AND cat_clase = 'Defaults' AND cat_sist = 'DEF_CUSTRANS'  "


        strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)

        CON = New MySqlConnection(strConexion)
        CON.Open()

        Try

            COM = New MySqlCommand(strSQL, CON)
            Base = COM.ExecuteScalar

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try

        CON.Close()

        Return Base
    End Function

    Private Function StringTransaccion() As String
        Dim strConexionTransaccion As String = "server={server};uid={user};password={pass};database={db}"

        If Sesion.IdEmpresa = 8 Then
            strConexionTransaccion = Replace(strConexion, "Pride", "PrideYarn")
        ElseIf Sesion.IdEmpresa = 3 Then
            strConexionTransaccion = Replace(strConexion, "Contabilidad", "Hilos")
        End If


        'strConexionTransaccion = Replace(strConexionTransaccion, "{server}", Conexion.local.Servidor)
        'strConexionTransaccion = Replace(strConexionTransaccion, "{user}", Conexion.local.Usuario)
        'strConexionTransaccion = Replace(strConexionTransaccion, "{pass}", Conexion.local.Clave)
        'strConexionTransaccion = Replace(strConexionTransaccion, "{db}", dbTrasnferencia)

        Return strConexionTransaccion

    End Function

    Public Function buscarArticulo(ByVal art As Integer) As Integer

        Dim strSQL As String = STR_VACIO
        Dim Articulo As Integer = 0
        Dim CON As MySqlConnection
        Dim COM As MySqlCommand

        strSQL = "SELECT inv_artcodigo " & _
                 "FROM Inventarios Inv " & _
                 "WHERE Inv.inv_sisemp = {empresa} and Inv.inv_numero = {articulo} "

        strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
        strSQL = Replace(strSQL, "{articulo}", art)

        CON = New MySqlConnection(strConexion)
        CON.Open()

        Try
            COM = New MySqlCommand(strSQL, CON)
            Articulo = COM.ExecuteScalar

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try

        CON.Close()

        Return Articulo

    End Function

    Public Function MaximoInventarioN(ByVal conexion As String, ByVal empresa As Integer)
        Dim strSQL As String = STR_VACIO
        Dim CON As MySqlConnection
        Dim COM As MySqlCommand
        Dim Correlativo As Integer

        strSQL = "SELECT IFNULL(MAX(inv_numero),0)+1 Correlativo  " & _
                 "FROM Inventarios  " & _
                 "WHERE inv_sisemp = {empresa}  "

        strSQL = Replace(strSQL, "{empresa}", empresa)

        CON = New MySqlConnection(conexion)
        CON.Open()

        Try

            COM = New MySqlCommand(strSQL, CON)
            Correlativo = COM.ExecuteScalar

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try

        Return Correlativo
    End Function

    Public Function buscarArticuloTranferencia(ByVal art As Integer, ByVal conexion As String, ByVal Empresa As Integer) As Integer
        Dim strSQL As String = STR_VACIO
        Dim Articulo As Integer = 0
        Dim CON As MySqlConnection
        Dim COM As MySqlCommand

        strSQL = " select ifnull(destino_art,-1) from Inventarios i " & _
                 " left join Transferencia.Transfer t on t.origen_emp = i.inv_sisemp  and t.origen_art = i.inv_artcodigo  " & _
                 " where i.inv_sisemp = {empresa} and i.inv_numero = {articulo}  "

        strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
        strSQL = Replace(strSQL, "{articulo}", art)

        CON = New MySqlConnection(strConexion)
        CON.Open()

        Try
            COM = New MySqlCommand(strSQL, CON)
            Articulo = COM.ExecuteScalar

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try

        CON.Close()

        Return Articulo
        System.GC.Collect()

    End Function


    Public Sub GuardarDetalleTransferencia(ByVal empresa As Integer, ByVal cat As Integer, ByVal año As Integer, ByVal num As Integer,
                                           ByVal Conexion As String, ByVal CodigoHilo As Integer, ByVal existe As Integer,
                                           Optional ByVal NumTrans As Integer = 0)
        Dim CON As MySqlConnection
        Dim COM As MySqlCommand
        Dim CON1 As MySqlConnection
        Dim COM1 As MySqlCommand
        'Dim BOX As Tablas.TDCMTOS_DTL_BOX
        Dim REA1 As MySqlDataReader
        Dim strSQL As String = STR_VACIO
        Dim Articulo As Integer = 0
        'Dim ArticuloT As Integer = 0

        strSQL = "SELECT DDoc_Prd_Cod, DDoc_Prd_Des, DDoc_Prd_UM, DDoc_Prd_PUQ,DDoc_Prd_NET, DDoc_Prd_QTY, DDoc_Prd_Fob " & _
                 "FROM Dcmtos_DTL " & _
                 "WHERE DDoc_Sis_Emp = {empresa} AND DDoc_Doc_Cat = 45  AND DDoc_Doc_Ano = {año} AND DDoc_Doc_Num = {num} AND DDoc_Prd_Cod = {linea}  "

        strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
        strSQL = Replace(strSQL, "{año}", CInt(CeldaAño.Text))
        strSQL = Replace(strSQL, "{num}", CInt(CeldaNumero.Text))
        strSQL = Replace(strSQL, "{linea}", CInt(CodigoHilo))

        CON = New MySqlConnection(Conexion)
        CON.Open()

        CON1 = New MySqlConnection(strConexion)
        CON1.Open()

        Try

            COM1 = New MySqlCommand(strSQL, CON1)
            REA1 = COM1.ExecuteReader

            If REA1.HasRows Then

                Do While REA1.Read

                    Try

                        If cat = 127 Then

                            Articulo = buscarArticulo(REA1.GetInt32("DDoc_Prd_Cod"))
                            ArticuloT = buscarArticuloTranferencia(REA1.GetInt32("DDoc_Prd_Cod"), Conexion, empresa)

                            If Articulo > 0 Then

                                If ArticuloT > 0 Then
                                    Dim CON3 As MySqlConnection
                                    Dim COM3 As MySqlCommand
                                    Dim REA3 As MySqlDataReader
                                    Dim CON4 As MySqlConnection
                                    Dim COM4 As MySqlCommand


                                    Dim strSQLC As String = STR_VACIO

                                    strSQLC = "SELECT * " & _
                                              "FROM Inventarios " & _
                                              "WHERE inv_sisemp = {empresa} and inv_numero = {invnumero} "

                                    strSQLC = Replace(strSQLC, "{empresa}", Sesion.IdEmpresa)
                                    strSQLC = Replace(strSQLC, "{invnumero}", REA1.GetInt32("DDoc_Prd_Cod"))


                                    CON3 = New MySqlConnection(strConexion)
                                    CON3.Open()

                                    CON4 = New MySqlConnection(Conexion)
                                    CON4.Open()

                                    Try

                                        COM3 = New MySqlCommand(strSQLC, CON3)
                                        REA3 = COM3.ExecuteReader

                                        If REA3.HasRows Then

                                            Do While REA3.Read

                                                Dim fecha As Date = REA3.GetMySqlDateTime("inv_fecha")

                                                Correlativo = MaximoInventarioN(Conexion, empresa)

                                                COM4 = CON4.CreateCommand

                                                COM4.CommandText = "INSERT INTO Inventarios(inv_sisemp,inv_numero,inv_fecha,inv_artcodigo,inv_provcod,inv_partnum," & _
                                                                    "inv_lugarfab,inv_prodano,inv_prodsem,inv_prodlote,inv_UMventa,inv_UMcmpra,inv_UMfac,inv_costo," & _
                                                                    "inv_PRECIOmin,inv_PRECIOmax,inv_PRECIOfac,inv_status,inv_notas)" & _
                                                                    "VALUES(?P1,?P2,?P3,?P4,?P5,?P6,?P7,?P8,?P9,?P10,?P11,?P12,?P13,?P14,?P15,?P16,?P17,?P18,?P19)"


                                                COM4.CommandType = CommandType.Text

                                                If empresa = 0 Then
                                                    COM4.Parameters.AddWithValue("?P1", DBNull.Value)
                                                Else
                                                    COM4.Parameters.AddWithValue("?P1", MySqlDbType.Int32).Value = empresa
                                                End If

                                                If Correlativo = 0 Then
                                                    COM4.Parameters.AddWithValue("?P2", DBNull.Value)
                                                Else
                                                    COM4.Parameters.AddWithValue("?P2", MySqlDbType.Int32).Value = Correlativo
                                                End If

                                                COM4.Parameters.AddWithValue("?P3", fecha.ToString(FORMATO_MYSQL))

                                                If REA3.GetInt32("inv_artcodigo") = 0 Then
                                                    COM4.Parameters.AddWithValue("?P4", DBNull.Value)
                                                Else
                                                    COM4.Parameters.AddWithValue("?P4", ArticuloT)
                                                End If


                                                If REA3.GetInt32("inv_provcod") = 0 Then
                                                    COM4.Parameters.AddWithValue("?P5", DBNull.Value)
                                                Else
                                                    COM4.Parameters.AddWithValue("?P5", REA3.GetInt32("inv_provcod"))
                                                End If


                                                If REA3.GetString("inv_partnum") = "" Then
                                                    COM4.Parameters.AddWithValue("?P6", DBNull.Value)
                                                Else
                                                    COM4.Parameters.AddWithValue("?P6", REA3.GetString("inv_partnum"))
                                                End If

                                                If REA3.GetInt32("inv_lugarfab") = 0 Then
                                                    COM4.Parameters.AddWithValue("?P7", DBNull.Value)
                                                Else
                                                    COM4.Parameters.AddWithValue("?P7", REA3.GetInt32("inv_lugarfab"))
                                                End If

                                                If REA3.GetInt32("inv_prodano") = 0 Then
                                                    COM4.Parameters.AddWithValue("?P8", DBNull.Value)
                                                Else
                                                    COM4.Parameters.AddWithValue("?P8", REA3.GetInt32("inv_prodano"))
                                                End If

                                                If REA3.GetInt32("inv_prodsem") = 0 Then
                                                    COM4.Parameters.AddWithValue("?P9", DBNull.Value)
                                                Else
                                                    COM4.Parameters.AddWithValue("?P9", REA3.GetInt32("inv_prodsem"))
                                                End If


                                                If REA3.GetString("inv_prodlote") = "NULL" Then
                                                    COM4.Parameters.AddWithValue("?P10", DBNull.Value)
                                                Else
                                                    COM4.Parameters.AddWithValue("?P10", REA3.GetString("inv_prodlote"))
                                                End If


                                                If REA3.GetInt32("inv_UMventa") = 0 Then
                                                    COM4.Parameters.AddWithValue("?P11", DBNull.Value)
                                                Else
                                                    COM4.Parameters.AddWithValue("?P11", REA3.GetInt32("inv_UMventa"))
                                                End If

                                                If REA3.GetDouble("inv_UMcmpra") = 0 Then
                                                    COM4.Parameters.AddWithValue("?P12", DBNull.Value)
                                                Else
                                                    COM4.Parameters.AddWithValue("?P12", REA3.GetDouble("inv_UMcmpra"))
                                                End If

                                                If REA3.GetInt32("inv_UMfac") = 0 Then
                                                    COM4.Parameters.AddWithValue("?P13", DBNull.Value)
                                                Else
                                                    COM4.Parameters.AddWithValue("?P13", REA3.GetInt32("inv_UMfac"))
                                                End If

                                                If REA3.GetDouble("inv_costo") = 0 Then
                                                    COM4.Parameters.AddWithValue("?P14", DBNull.Value)
                                                Else
                                                    COM4.Parameters.AddWithValue("?P14", REA3.GetDouble("inv_costo"))
                                                End If

                                                If REA3.GetDouble("inv_PRECIOmin") = 0 Then
                                                    COM4.Parameters.AddWithValue("?P15", DBNull.Value)
                                                Else
                                                    COM4.Parameters.AddWithValue("?P15", REA3.GetDouble("inv_PRECIOmin"))
                                                End If

                                                If REA3.GetDouble("inv_PRECIOmax") = 0 Then
                                                    COM4.Parameters.AddWithValue("?P16", DBNull.Value)
                                                Else
                                                    COM4.Parameters.AddWithValue("?P16", REA3.GetDouble("inv_PRECIOmax"))
                                                End If

                                                If REA3.GetInt32("inv_PRECIOfac") = 0 Then
                                                    COM4.Parameters.AddWithValue("?P17", DBNull.Value)
                                                Else
                                                    COM4.Parameters.AddWithValue("?P17", REA3.GetInt32("inv_PRECIOfac"))
                                                End If


                                                If REA3.GetString("inv_status") = "NULL" Then
                                                    COM4.Parameters.AddWithValue("?P18", DBNull.Value)
                                                Else
                                                    COM4.Parameters.AddWithValue("?P18", REA3.GetString("inv_status"))
                                                End If

                                                If REA3.GetString("inv_notas") = "NULL" Then
                                                    COM4.Parameters.AddWithValue("?P19", DBNull.Value)
                                                Else
                                                    COM4.Parameters.AddWithValue("?P19", REA3.GetString("inv_notas"))
                                                End If

                                                COM4.ExecuteNonQuery()
                                                COM4.Dispose()
                                                COM4 = Nothing

                                            Loop

                                        End If

                                    Catch ex As Exception
                                        MsgBox(ex.ToString)
                                    End Try

                                    CON3.Close()
                                    CON4.Close()

                                End If

                            End If

                        End If

                        COM = CON.CreateCommand

                        'If existe = 1 Then
                        '    Dim strSQLD As String = STR_VACIO

                        '    strSQLD = "UPDATE Dcmtos_DTL " & _
                        '              "SET DDoc_Sis_Emp = ?P1,DDoc_Doc_Cat = ?P2,DDoc_Doc_Ano = ?P8,DDoc_Doc_Num = ?P19,DDoc_Doc_Lin = ?P5,DDoc_Prd_PNr = ?P6,DDoc_Prd_Cod = ?P7," & _
                        '              "DDoc_Prd_Des = ?P8,DDoc_Prd_UM = ?P9,DDoc_Prd_PUQ = ?P10,DDoc_Prd_NET = ?P11,DDoc_Prd_QTY = ?P12,DDoc_Prd_Fob = ?P13) " & _
                        '              "WHERE DDoc_Sis_Emp = {empresa} AND DDoc_Doc_Cat = {cat} AND DDoc_Doc_Ano = {año} AND DDoc_Doc_Num = {num}  "

                        '    strSQLD = Replace(strSQLD, "{empresa}", empresa)
                        '    strSQLD = Replace(strSQLD, "{cat}", cat)
                        '    strSQLD = Replace(strSQLD, "{año}", CInt(CeldaAño.Text))
                        '    strSQLD = Replace(strSQLD, "{num}", NumTrans)

                        '    COM.CommandText = strSQLD

                        '    COM.CommandType = CommandType.Text

                        '    If CInt(CeldaAño.Text) = NO_FILA Then
                        '        COM.Parameters.AddWithValue("?P18", DBNull.Value)
                        '    Else
                        '        COM.Parameters.AddWithValue("?P18", CInt(CeldaAño.Text))
                        '    End If

                        '    If CInt(num) = NO_FILA Then
                        '        COM.Parameters.AddWithValue("?19", DBNull.Value)
                        '    Else
                        '        COM.Parameters.AddWithValue("?P19", NumTrans)
                        '    End If


                        '    MsgBox("Ingresa")

                        'Else

                        Dim Contador As Integer = 0
                        COM.CommandText = "INSERT INTO Dcmtos_DTL (DDoc_Sis_Emp,DDoc_Doc_Cat,DDoc_Doc_Ano,DDoc_Doc_Num,DDoc_Doc_Lin,DDoc_Prd_PNr,DDoc_Prd_Cod," & _
                                          "DDoc_Prd_Des,DDoc_Prd_UM,DDoc_Prd_PUQ,DDoc_Prd_NET,DDoc_Prd_QTY,DDoc_Prd_Fob)" & _
                                          "VALUES(?P1,?P2,?P3,?P4,?P5,?P6,?P7,?P8,?P9,?P10,?P11,?P12,?P13) "

                        COM.CommandType = CommandType.Text


                        If año = NO_FILA Then
                            COM.Parameters.AddWithValue("?P3", DBNull.Value)
                        Else
                            COM.Parameters.AddWithValue("?P3", año)
                        End If

                        If num = NO_FILA Then
                            COM.Parameters.AddWithValue("?P4", DBNull.Value)
                        Else
                            COM.Parameters.AddWithValue("?P4", num)
                        End If

                        'End If

                        If empresa = NO_FILA Then
                            COM.Parameters.AddWithValue("?P1", DBNull.Value)
                        Else
                            COM.Parameters.AddWithValue("?P1", empresa)
                        End If

                        If cat = NO_FILA Then
                            COM.Parameters.AddWithValue("?P2", DBNull.Value)
                        Else
                            COM.Parameters.AddWithValue("?P2", cat)
                        End If

                        COM.Parameters.AddWithValue("?P5", 1)

                        COM.Parameters.AddWithValue("?P6", "N/A")

                        If REA1.GetInt32("DDoc_Prd_Cod") = NO_FILA Then
                            COM.Parameters.AddWithValue("?P7", DBNull.Value)
                        Else
                            If cat = 127 Or cat = 55 Or cat = 180 Or cat = 47 Then
                                COM.Parameters.AddWithValue("?P7", Correlativo)
                            Else
                                COM.Parameters.AddWithValue("?P7", Correlativo)
                            End If
                        End If

                        If REA1.GetString("DDoc_Prd_Des").ToUpper = "NULL" Then
                            COM.Parameters.AddWithValue("?P8", DBNull.Value)
                        Else
                            COM.Parameters.AddWithValue("?P8", REA1.GetString("DDoc_Prd_Des").ToUpper)
                        End If

                        If REA1.GetInt32("DDoc_Prd_UM") = NO_FILA Then
                            COM.Parameters.AddWithValue("?P9", DBNull.Value)
                        Else
                            COM.Parameters.AddWithValue("?P9", REA1.GetInt32("DDoc_Prd_UM"))
                        End If

                        If REA1.GetDouble("DDoc_Prd_PUQ") = NO_FILA Then
                            COM.Parameters.AddWithValue("?P10", DBNull.Value)
                        Else
                            COM.Parameters.AddWithValue("?P10", REA1.GetDouble("DDoc_Prd_PUQ"))
                        End If

                        If REA1.GetDouble("DDoc_Prd_NET") = NO_FILA Then
                            COM.Parameters.AddWithValue("?P11", DBNull.Value)
                        Else
                            COM.Parameters.AddWithValue("?P11", REA1.GetDouble("DDoc_Prd_NET"))
                        End If


                        If REA1.GetDouble("DDoc_Prd_QTY") = NO_FILA Then
                            COM.Parameters.AddWithValue("?P12", DBNull.Value)
                        Else
                            COM.Parameters.AddWithValue("?P12", REA1.GetDouble("DDoc_Prd_QTY"))
                        End If


                        If REA1.GetDouble("DDoc_Prd_Fob") = NO_FILA Then
                            COM.Parameters.AddWithValue("?P13", DBNull.Value)
                        Else
                            COM.Parameters.AddWithValue("?P13", REA1.GetDouble("DDoc_Prd_Fob"))
                        End If

                        COM.ExecuteNonQuery()


                        If cat = 47 Then
                            'BOX.BDOC_SIS_EMP = Sesion.IdEmpresa
                            'BOX.BDOC_DOC_CAT = cat
                            'BOX.BDOC_DOC_ANO = año
                            'BOX.BDOC_DOC_NUM = num
                            'BOX.BDOC_DOC_LIN = Contador
                            'BOX.BDOC_BOX_LIN = 1
                            'BOX.BDOC_BOX_COD = "1"
                            ''BOX.BDOC_BOX_QTY = dgvTransferencia.Rows(i).Cells("colBultos").Value
                            ''BOX.BDOC_BOX_LB = dgvTransferencia.Rows(i).Cells("colCantidad").Value

                            'If BOX.PINSERT = False Then
                            '    MsgBox(BOX.MERROR.ToString)
                            'End If

                        End If

                        If cat = 180 Then
                            Dim CON5 As MySqlConnection
                            Dim COM5 As MySqlCommand

                            CON5 = New MySqlConnection(Conexion)
                            CON5.Open()

                            Try

                                COM5 = CON.CreateCommand

                                COM5.CommandText = "INSERT INTO Dcmtos_ACC(ADoc_Sis_Emp,ADoc_Doc_Cat,ADoc_Doc_Ano,ADoc_Doc_Num,ADoc_Doc_Sub,ADoc_Doc_Lin,ADoc_Dta_Des,ADoc_Dta_Chr,ADoc_Dta_Txt)" & _
                                                  "VALUES(?P1,?P2,?P3,?P4,?P5,?P6,?P7,?P8,?P9)"

                                COM5.CommandType = CommandType.Text

                                If empresa = 0 Then
                                    COM5.Parameters.AddWithValue("?P1", DBNull.Value)
                                Else
                                    COM5.Parameters.AddWithValue("?P1", empresa)
                                End If

                                If cat = 0 Then
                                    COM5.Parameters.AddWithValue("?P2", DBNull.Value)
                                Else
                                    COM5.Parameters.AddWithValue("?P2", cat)
                                End If

                                If CInt(CeldaAño.Text) = 0 Then
                                    COM5.Parameters.AddWithValue("?P3", DBNull.Value)
                                Else
                                    COM5.Parameters.AddWithValue("?P3", CInt(CeldaAño.Text))
                                End If

                                If num = 0 Then
                                    COM5.Parameters.AddWithValue("?P4", DBNull.Value)
                                Else
                                    COM5.Parameters.AddWithValue("?P4", num)
                                End If

                                COM5.Parameters.AddWithValue("?P5", "Doc_PolImp")

                                COM5.Parameters.AddWithValue("?P6", "01")

                                COM5.Parameters.AddWithValue("?P7", "Numero / Number")


                                If txtSat.Text = "" Then
                                    COM5.Parameters.AddWithValue("?P8", DBNull.Value)
                                Else
                                    COM5.Parameters.AddWithValue("?P8", txtSat.Text)
                                End If

                                COM5.Parameters.AddWithValue("?P9", " ")

                                COM5.ExecuteNonQuery()
                                COM5.Dispose()
                                COM5 = Nothing

                            Catch ex As Exception
                                MsgBox(ex.ToString)
                            End Try

                        End If

                        If cat <> 127 Then
                            GuardarProTransferencia(cat, año, num, REA1.GetDouble("DDoc_Prd_QTY"), REA1.GetInt32("DDoc_Prd_Cod"), Conexion, empresa)
                        End If
                        COM.Dispose()
                        COM = Nothing
                        CON.Close()

                    Catch ex As Exception
                        MsgBox(ex.ToString)
                    End Try

                Loop

            End If

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try

    End Sub

    Public Function FacturaCorrelativo() As Integer
        Dim CON As MySqlConnection
        Dim COM As MySqlCommand
        Dim Correlativo As Integer
        Dim strSQL As String = STR_VACIO


        strSQL = "Select ifnull(MAX(HDoc_DR1_Dbl),0)+1 Correlativo " & _
                 "FROM Dcmtos_HDR " & _
                 "WHERE HDoc_Sis_Emp = {empresa} and HDoc_Doc_Cat = 36 and HDoc_DR2_Num = '3'"

        strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)

        CON = New MySqlConnection(strConexion)
        CON.Open()

        Try
            COM = New MySqlCommand(strSQL, CON)
            Correlativo = COM.ExecuteScalar
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try

        Return Correlativo

    End Function
    Private Function ObetenerArticulo(ByVal inventario As Integer) As Integer
        Dim strSQL As String = STR_VACIO
        Dim ART As Integer = NO_FILA
        Dim COM As MySqlCommand
        Dim cone As MySqlConnection
        Try
            cone = New MySqlConnection(strConexion)
            cone.Open()
            strSQL = " select IFNULL(i.inv_artcodigo,0)  from Inventarios i where i.inv_sisemp = {empresa} and i.inv_numero = {inventario}"
            strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
            strSQL = Replace(strSQL, "{inventario}", inventario)
            COM = New MySqlCommand(strSQL, CON)
            ART = COM.ExecuteScalar
            cone.Clone()
        Catch ex As Exception
            MsgBox(ex.ToString)
        Finally

        End Try

        Return ART
    End Function
    Private Function NuevoInventario(ByVal inv As Integer) As Integer
        Dim intInv As Integer = NO_FILA
        Dim strSQL As String = STR_VACIO
        Dim intArtEqu As Integer = NO_FILA
        Dim intProv As Integer = NO_FILA
        Dim COM As MySqlCommand
        Dim Cone As MySqlConnection

        Try
            intArtEqu = buscarArticuloTranferencia(inv, strConexion, Sesion.IdEmpresa)
            intInv = MaximoInventarioN(StringTransaccion, EmpTransf)
            intProv = FabricanteTransferencia(inv)
            strSQL = " insert into {baset}.Inventarios "
            strSQL &= " select  {empresatrans}, {nuevo} , i.inv_DEmp , i.inv_DTipo , i.inv_DAno , i.inv_DNum , i.inv_fecha , {articulo}, {mill} , i.inv_partnum , i.inv_lugarfab, "
            strSQL &= " i.inv_prodano ,i.inv_prodsem ,i.inv_prodlote ,i.inv_UMventa,i.inv_UMcmpra,i.inv_UMfac, i.inv_costo,i.inv_precio,i.inv_PRECIOmin, "
            strSQL &= " i.inv_PRECIOmax,i.inv_PRECIOfac,i.inv_dscto,i.inv_cantidad,i.inv_compras,i.inv_ventas,i.inv_status,i.inv_notas,i.inv_generico,i.inv_ref,i.inv_anterior, "
            strSQL &= " i.inv_activo  from Inventarios i "
            strSQL &= " where i.inv_sisemp = {empresa} and i.inv_numero = {inventario} "

            strSQL = Replace(strSQL, "{baset}", BaseTransf)
            strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
            strSQL = Replace(strSQL, "{inventario}", inv)
            strSQL = Replace(strSQL, "{empresatrans}", EmpTransf)
            strSQL = Replace(strSQL, "{articulo}", intArtEqu)
            strSQL = Replace(strSQL, "{mill}", intProv)
            strSQL = Replace(strSQL, "{nuevo}", intInv)

            Cone = New MySqlConnection(strConexion)
            Cone.Open()
            COM = New MySqlCommand(strSQL, CON)
            COM.ExecuteNonQuery()
            Cone.Close()
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        Return intInv
    End Function

    Private Sub GuardarDetalleImpotacion(ByVal cat As Integer, ByVal ano As Integer, ByVal numero As Integer, ByVal ref As String, ByVal inventario As Integer, ByVal desc As String, ByVal precio As Double, ByVal cantidad As Double, ByVal bultos As Integer, ByVal medida As Integer, ByVal linea As Integer)
        Dim cdtl As New clsDcmtos_DTL
        Try

            cdtl.DDOC_SIS_EMP = EmpTransf
            cdtl.DDOC_DOC_CAT = cat
            cdtl.DDOC_DOC_ANO = ano
            cdtl.DDOC_DOC_NUM = numero
            cdtl.DDOC_DOC_LIN = INT_UNO
            cdtl.DDOC_PRD_PNR = "N/A"
            cdtl.DDOC_PRD_DES = desc
            cdtl.DDOC_PRD_UM = medida
            cdtl.DDOC_PRD_PUQ = precio
            cdtl.DDOC_PRD_DSP = INT_CERO
            cdtl.DDOC_PRD_DSQ = INT_CERO
            cdtl.DDOC_PRD_NET = precio
            cdtl.DDOC_PRD_QTY = cantidad
            cdtl.DDOC_RF2_DBL = INT_CERO
            cdtl.DDOC_RF3_DBL = INT_CERO

            Select Case cat
                Case 127
                    Correlativo = NuevoInventario(inventario)
                    cdtl.DDOC_RF1_COD = " "
                    cdtl.DDOC_RF1_DBL = cantidad * precio
                    cdtl.DDOC_PRD_FOB = precio
                    cdtl.DDOC_PRD_CIF = precio

                Case 55
                    cdtl.DDOC_RF1_NUM = INT_CERO
                    cdtl.DDOC_RF1_DBL = cantidad * precio
                    cdtl.DDOC_PRD_FOB = precio
                    cdtl.DDOC_PRD_CIF = precio

                Case 180
                    cdtl.DDOC_RF1_NUM = INT_CERO
                    cdtl.DDOC_RF1_DBL = cantidad * precio
                    cdtl.DDOC_PRD_FOB = precio
                    cdtl.DDOC_PRD_CIF = precio

                Case 47
                    cdtl.DDOC_RF1_NUM = INT_CERO
                    cdtl.DDOC_RF1_COD = Correlativo
                    cdtl.DDOC_RF1_TXT = " "
                    cdtl.DDOC_RF1_DBL = cantidad
                    cdtl.DDOC_RF2_COD = "E4"
                    cdtl.DDOC_RF2_TXT = " "
            End Select
            cdtl.DDOC_PRD_COD = Correlativo
            cdtl.CONEXION = StringTransaccion()
            If cdtl.Guardar = False Then
                MsgBox(cdtl.MERROR.ToString)

            Else

                Select Case cat
                    Case 127
                    Case 55
                    Case 180
                        GuardarACC(cat, ano, numero, inventario, precio, cantidad)
                        GuardarDEC(cat, ano, numero, linea)
                    Case 47
                        GuardarBultos(cdtl.DDOC_SIS_EMP, cdtl.DDOC_DOC_CAT, cdtl.DDOC_DOC_ANO, cdtl.DDOC_DOC_NUM, cdtl.DDOC_DOC_LIN, bultos, cantidad, StringTransaccion)
                End Select
            End If
            If cat <> 127 Then
                GuardarProTransferencia(cat, ano, numero, cantidad, inventario, StringTransaccion, EmpTransf)
            End If

        Catch ex As Exception
            MsgBox(ex.ToString)
        Finally
            cdtl.Dispose()
            cdtl = Nothing
            System.GC.Collect()
        End Try
    End Sub
    Private Sub GuardarEncabezadoImportacion(ByVal cat As Integer, ByVal ref As String, ByVal inventario As Integer, ByVal desc As String, ByVal precio As Double, ByVal cantidad As Double, ByVal bultos As Integer, ByVal medida As Integer, ByVal linea As Integer)
        Dim Año As Integer = NO_FILA
        Dim Numero As Integer = NO_FILA
        Dim chdr As New clsDcmtos_HDR
        Try
            Ano_Padre = Ano_Hijo
            Num_Padre = Num_Hijo
            Cat_Padre = Cat_Hijo

            Año = cfun.AñoMySQL
            Numero = cfun.MaximoTranferencia(cat, StringTransaccion(), EmpTransf)

            chdr.HDOC_SIS_EMP = EmpTransf
            chdr.HDOC_DOC_NUM = Numero
            chdr.HDOC_DOC_CAT = cat
            chdr.HDOC_DOC_ANO = Año
            chdr.HDoc_Doc_Fec_NET = cfun.HoyMySQL
            chdr.HDOC_EMP_COD = ProveedorT.codigo
            chdr.HDOC_EMP_NOM = ProveedorT.nombre
            chdr.HDOC_EMP_DIR = ProveedorT.direccion
            chdr.HDOC_EMP_NIT = ProveedorT.nit
            chdr.HDOC_EMP_TEL = ProveedorT.telefono
            chdr.HDOC_DOC_TC = CDbl(lblTasa.Text)
            chdr.HDOC_DR1_NUM = ref
            chdr.HDOC_DR1_DBL = INT_CERO
            chdr.HDOC_USUARIO = Sesion.Usuario
            chdr.HDOC_DOC_MON = 178
            chdr.HDOC_RF1_DBL = INT_CERO
            chdr.HDOC_RF2_DBL = INT_CERO
            chdr.HDOC_RF3_DBL = INT_CERO
            Select Case cat
                Case 127
                    chdr.HDOC_RF1_TXT = "CIF"
                    chdr.HDOC_DOC_STATUS = INT_UNO
                Case 55
                    chdr.HDOC_DR1_CAT = INT_CERO
                    chdr.HDOC_DR2_EMP = INT_CERO
                    chdr.HDOC_RF1_TXT = "CIF"
                    chdr.HDOC_DOC_STATUS = INT_UNO
                Case 180
                    chdr.HDOC_DR1_CAT = INT_CERO
                    chdr.HDOC_RF1_TXT = "CIF"
                    chdr.HDOC_DOC_STATUS = INT_UNO
                Case 47
                    chdr.HDOC_DR1_CAT = INT_CERO
                    chdr.HDOC_RF2_NUM = INT_CERO
                    chdr.HDOC_RF2_TXT = ref
                    chdr.HDOC_DOC_STATUS = INT_CERO
            End Select

            chdr.CONEXION = StringTransaccion()

            If chdr.Guardar = True Then
                Num_Hijo = Numero
                Ano_Hijo = Año
                Cat_Hijo = cat

                GuardarDetalleImpotacion(chdr.HDOC_DOC_CAT, chdr.HDOC_DOC_ANO, chdr.HDOC_DOC_NUM, ref, inventario, desc, precio, cantidad, bultos, medida, linea)
            Else
                MsgBox(chdr.MERROR.ToString)
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        Finally
            chdr.Dispose()
            chdr = Nothing
            System.GC.Collect()
        End Try




    End Sub
    Public Sub GuardarEncabezadoTransferencia(ByVal cat As Integer, ByVal referencia As String, ByVal Conexion As String, ByVal Empresa As Integer, ByVal CodigoHilo As Integer, ByVal Bultos As Integer, ByVal Cantidad As Double)
        Dim CON As MySqlConnection
        Dim CON1 As MySqlConnection
        Dim Existe As Integer = 0
        Dim strSQL As String = 0
        Dim COM As MySqlCommand
        Dim COM1 As MySqlCommand
        Dim REA1 As MySqlDataReader
        Dim Año As Integer = 0
        Dim Numero As Integer = 0
        Dim Num As Integer = 0

        Ano_Padre = Ano_Hijo
        Num_Padre = Num_Hijo
        Cat_Padre = Cat_Hijo

        strSQL = "SELECT pro_codigo,pro_proveedor,pro_nombre,pro_direccion,pro_telefono,pro_nit, pro_plazoCR " & _
                 "FROM Catalogos ctl " & _
                 "left join Proveedores cli on cli.pro_sisemp = ctl.cat_sisemp and cli.pro_codigo = ctl.cat_clave " & _
                 "WHERE ctl.cat_clase = 'Defaults' and ctl.cat_pid = {empresa} and ctl.cat_sist = 'DEF_PROTRANS' "

        strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)


        CON = New MySqlConnection(Conexion)
        CON.Open()

        CON1 = New MySqlConnection(Conexion)
        CON1.Open()


        COM1 = New MySqlCommand(strSQL, CON1)
        REA1 = COM1.ExecuteReader

        Año = cfun.AñoMySQL

        Do While REA1.Read

            Try

                COM = CON.CreateCommand

                Existe = buscarRegistro(Empresa, cat, referencia, Conexion)
                Num = buscarNumero(Empresa, cat, referencia, Conexion)
                Existe = 0
                If Existe = 1 Then
                    MsgBox("ya tiene ingreso a bodega")
                    Exit Sub

                Else

                    COM.CommandText = "INSERT INTO Dcmtos_HDR (HDoc_Sis_Emp,HDoc_Doc_Cat,HDoc_Doc_Ano,HDoc_Doc_Num,HDoc_Doc_Fec,HDoc_Emp_Cod,HDoc_Emp_Nom " & _
                                      ",HDoc_Emp_Dir,HDoc_Emp_Per,HDoc_Emp_Tel,HDoc_Emp_NIT,HDoc_DR1_Num,HDoc_RF1_Txt,HDoc_Usuario,HDoc_Doc_TC,HDoc_Doc_Mon,HDoc_Doc_Status,HDoc_RF1_Cod, " & _
                                      "HDoc_DR1_Cat, HDoc_DR2_Cat)" & _
                                      "VALUES(?P1,?P2,?P3,?P4,?P5,?P6,?P7,?P8,?P9,?P10,?P11,?P12,?P13,?P14,?P15,?P16,?P17,?P18,?P19,?P20)"

                    Año = cfun.AñoMySQL
                    Numero = cfun.MaximoTranferencia(cat, Conexion, Empresa)

                    COM.CommandType = CommandType.Text

                    If Año = NO_FILA Then
                        COM.Parameters.AddWithValue("?P3", DBNull.Value)
                    Else
                        COM.Parameters.AddWithValue("?P3", Año)
                    End If


                    If Numero = NO_FILA Then
                        COM.Parameters.AddWithValue("?P4", DBNull.Value)
                    Else
                        COM.Parameters.AddWithValue("?P4", Numero)
                    End If

                End If

                If Empresa = NO_FILA Then

                    COM.Parameters.AddWithValue("?P1", DBNull.Value)
                Else
                    COM.Parameters.AddWithValue("?P1", Empresa)
                End If

                If cat = NO_FILA Then
                    COM.Parameters.AddWithValue("?P2", DBNull.Value)
                Else
                    COM.Parameters.AddWithValue("?P2", cat)
                End If

                COM.Parameters.AddWithValue("?P5", dtpFecha.Value)

                If REA1.GetInt32("pro_codigo") = NO_FILA Then
                    COM.Parameters.AddWithValue("?P6", DBNull.Value)
                Else
                    COM.Parameters.AddWithValue("?P6", REA1.GetInt32("pro_codigo"))
                End If

                If REA1.GetString("pro_proveedor").ToUpper = "NULL" Then
                    COM.Parameters.AddWithValue("?P7", DBNull.Value)
                Else
                    COM.Parameters.AddWithValue("?P7", REA1.GetString("pro_proveedor").ToUpper)
                End If

                If REA1.GetString("pro_direccion").ToUpper = "NULL" Then
                    COM.Parameters.AddWithValue("?P8", DBNull.Value)
                Else
                    COM.Parameters.AddWithValue("?P8", REA1.GetString("pro_direccion").ToUpper)
                End If

                COM.Parameters.AddWithValue("?P9", "N/A")

                If REA1.GetString("pro_telefono") = STR_VACIO Then
                    COM.Parameters.AddWithValue("?P10", DBNull.Value)
                Else
                    COM.Parameters.AddWithValue("?P10", REA1.GetString("pro_telefono"))
                End If

                If REA1.GetString("pro_nit").ToUpper = "NULL" Then
                    COM.Parameters.AddWithValue("?P11", DBNull.Value)
                Else
                    COM.Parameters.AddWithValue("?P11", REA1.GetString("pro_nit").ToUpper)
                End If

                If referencia = "NULL" Then
                    COM.Parameters.AddWithValue("?P12", DBNull.Value)
                Else
                    COM.Parameters.AddWithValue("?P12", referencia)
                End If

                COM.Parameters.AddWithValue("?P14", Sesion.Usuario)

                If lblTasa.Text = NO_FILA Then
                    COM.Parameters.AddWithValue("?P15", DBNull.Value)
                Else
                    COM.Parameters.AddWithValue("?P15", lblTasa.Text)
                End If

                If lblcodMoneda.Text = NO_FILA Then
                    COM.Parameters.AddWithValue("?P16", DBNull.Value)
                Else
                    COM.Parameters.AddWithValue("?P16", lblcodMoneda.Text)
                End If

                COM.Parameters.AddWithValue("?P17", 1)
                COM.Parameters.AddWithValue("?P20", 0)
                COM.Parameters.AddWithValue("?P18", " ")
                Select Case cat
                    Case 127
                        COM.Parameters.AddWithValue("?P13", "CIF")

                        COM.Parameters.AddWithValue("?P19", 0)

                    Case 55
                        COM.Parameters.AddWithValue("?P13", "CIF")
                        'COM.Parameters.AddWithValue("?P18", " ")
                        COM.Parameters.AddWithValue("?P19", 0)

                    Case 180
                        COM.Parameters.AddWithValue("?P13", "CIF")
                        ' COM.Parameters.AddWithValue("?P18", " ")
                        COM.Parameters.AddWithValue("?P19", 0)

                    Case 47
                        COM.Parameters.AddWithValue("?P13", "CIF")
                        'COM.Parameters.AddWithValue("?P18", " ")
                        COM.Parameters.AddWithValue("?P19", 0)

                End Select

                Try
                    COM.ExecuteNonQuery()
                Catch ex As Exception
                    MsgBox(ex.ToString)
                End Try

                Num_Hijo = Numero
                Ano_Hijo = Año
                Cat_Hijo = cat

                GuardarDetalleTransferencia(Empresa, cat, Año, Numero, Conexion, CodigoHilo, Existe, Num)

                COM.Dispose()
                COM = Nothing
                CON.Close()


            Catch ex As Exception
                MsgBox(ex, ToString)
            End Try

        Loop
        REA1.Close()
        CON1.Close()

    End Sub
    Private Sub GuardarBultos(ByVal empresa As Integer, ByVal cat As Integer, ByVal ano As Integer, ByVal numero As Integer, ByVal linea As Integer, ByVal bultos As Integer, ByVal cantidad As Double, ByVal conexion As String)
        Dim box As New Tablas.TDCMTOS_DTL_BOX
        Try

            box.BDOC_SIS_EMP = empresa
            box.BDOC_DOC_CAT = cat
            box.BDOC_DOC_ANO = ano
            box.BDOC_DOC_NUM = numero
            box.BDOC_DOC_LIN = linea
            box.BDOC_BOX_LIN = INT_UNO
            box.BDOC_BOX_COD = INT_UNO
            box.BDOC_BOX_ORD = INT_CERO
            box.BDOC_BOX_QTY = bultos
            box.BDOC_BOX_LB = cantidad
            box.CONEXION = conexion
            If box.PINSERT = False Then
                MsgBox(box.MERROR.ToString)
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub
    Private Sub GuardarACC(ByVal cat As Integer, ByVal ano As Integer, ByVal numero As Integer, ByVal inventario As Integer, ByVal precio As Double, ByVal cantidad As Double)
        Dim acc As New Tablas.TDCMTOS_ACC
        Try

            acc.ADOC_SIS_EMP = EmpTransf
            acc.ADOC_DOC_CAT = cat
            acc.ADOC_DOC_ANO = ano
            acc.ADOC_DOC_NUM = numero
            acc.ADOC_DOC_SUB = "Doc_PolImp"
            acc.ADOC_DOC_LIN = "01"
            acc.ADOC_DTA_DES = "Numero / Number"
            acc.ADOC_DTA_CHR = txtSat.Text
            acc.ADOC_DTA_TXT = " "
            acc.CONEXION = StringTransaccion()
            If acc.PINSERT = False Then
                MsgBox(acc.MERROR.ToString)
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub
    Private Sub btnIngreso_Click(sender As Object, e As EventArgs) Handles btnIngreso.Click

        If txtSat.Text.Length > 5 Then
            Dim conexion As String = StringTransaccion()

            Try

                For i As Integer = 0 To dgvTransferencia.Rows.Count - 1

                    Dim referencia As String = STR_VACIO

                    Dim Codigo As Integer = 0
                    Dim Bultos As Integer = 0
                    Dim Libras As Double = 0

                    Codigo = dgvTransferencia.Rows(i).Cells("colCodigo").Value
                    referencia = dgvTransferencia.Rows(i).Cells("colRef").Value
                    Bultos = dgvTransferencia.Rows(i).Cells("colBultos").Value
                    Libras = dgvTransferencia.Rows(i).Cells("colCantidad").Value


                    GuadarSat()
                    GuardarEncabezadoTransferencia(127, referencia, conexion, EmpTrasnferencia, Codigo, Bultos, Libras)
                    GuardarEncabezadoTransferencia(55, referencia, conexion, EmpTrasnferencia, Codigo, Bultos, Libras)
                    GuardarEncabezadoTransferencia(180, referencia, conexion, EmpTrasnferencia, Codigo, Bultos, Libras)
                    GuardarEncabezadoTransferencia(47, referencia, conexion, EmpTrasnferencia, Codigo, Bultos, Libras)
                Next

                MsgBox("DATOS ALMACENADOS", MsgBoxStyle.Information)


                btnIngreso.Enabled = False

            Catch ex As Exception
                MsgBox(ex.ToString)
            End Try

        Else
            MsgBox("Debe Ingresar un registro Sat", MsgBoxStyle.Information)
        End If

        Correlativo = 0

    End Sub

    Private Sub GuardarProTransferencia(cat As Integer, año As Integer, num As Integer, p5 As Double, p6 As Integer, ByVal Conexion As String, ByVal empresa As Integer)
        Dim CON As New MySqlConnection
        Dim COM As New MySqlCommand

        CON = New MySqlConnection(Conexion)
        CON.Open()

        Try

            COM = CON.CreateCommand
            COM.CommandText = "INSERT INTO Dcmtos_DTL_Pro (PDoc_Sis_Emp,PDoc_Par_Cat,PDoc_Par_Ano,PDoc_Par_Num,PDoc_Par_Lin,PDoc_Chi_Cat," & _
                              "PDoc_Chi_Ano,PDoc_Chi_Num,PDoc_Chi_Lin,PDoc_Prd_Cod,PDoc_QTY_Ord)" & _
                              "VALUES(?P1,?P2,?P3,?P4,?P5,?P6,?P7,?P8,?P9,?P10,?P11)"

            COM.CommandType = CommandType.Text

            If empresa = NO_FILA Then
                COM.Parameters.AddWithValue("?P1", DBNull.Value)
            Else
                COM.Parameters.AddWithValue("?P1", empresa)
            End If

            If Cat_Padre = NO_FILA Then
                COM.Parameters.AddWithValue("?P2", DBNull.Value)
            Else
                COM.Parameters.AddWithValue("?P2", Cat_Padre)
            End If

            If Ano_Padre = NO_FILA Then
                COM.Parameters.AddWithValue("?P3", DBNull.Value)
            Else
                COM.Parameters.AddWithValue("?P3", Ano_Padre)
            End If

            If Num_Padre = NO_FILA Then
                COM.Parameters.AddWithValue("?P4", DBNull.Value)
            Else
                COM.Parameters.AddWithValue("?P4", Num_Padre)
            End If

            COM.Parameters.AddWithValue("?P5", 1)

            If Cat_Hijo = NO_FILA Then
                COM.Parameters.AddWithValue("?P6", DBNull.Value)
            Else
                COM.Parameters.AddWithValue("?P6", Cat_Hijo)
            End If

            If Ano_Hijo = NO_FILA Then
                COM.Parameters.AddWithValue("?P7", DBNull.Value)
            Else
                COM.Parameters.AddWithValue("?P7", Ano_Hijo)
            End If

            If Num_Hijo = NO_FILA Then
                COM.Parameters.AddWithValue("?P8", DBNull.Value)
            Else
                COM.Parameters.AddWithValue("?P8", Num_Hijo)
            End If

            COM.Parameters.AddWithValue("?P9", 1)

            If p6 = NO_FILA Then
                COM.Parameters.AddWithValue("?P10", DBNull.Value)
            Else
                COM.Parameters.AddWithValue("?P10", p6)
            End If

            If p5 = NO_FILA Then
                COM.Parameters.AddWithValue("?P11", DBNull.Value)
            Else
                COM.Parameters.AddWithValue("?P11", p5)
            End If

            COM.ExecuteNonQuery()
            COM.Dispose()
            COM = Nothing

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try

        CON.Close()
    End Sub

    Public Sub GuadarSat()
        Dim CON As MySqlConnection
        Dim COM As MySqlCommand
        Dim strSQL As String = STR_VACIO

        CON = New MySqlConnection(strConexion)
        CON.Open()

        Try

            COM = CON.CreateCommand

            strSQL = "UPDATE Dcmtos_HDR " &
                     "SET HDoc_RF2_Cod = ?P1  " &
                     "WHERE HDoc_Sis_Emp = {empresa} AND HDoc_Doc_Cat = 45 AND HDoc_Doc_Ano = {año} and HDoc_Doc_Num = {num}"

            If Sesion.IdEmpresa = 18 Then
                strSQL &= ";UPDATE PDM.Dcmtos_HDR " &
                     "SET HDoc_RF2_Cod = ?P1  " &
                     "WHERE HDoc_Sis_Emp = {empresa} AND HDoc_Doc_Cat = 45 AND HDoc_Doc_Ano = {año} and HDoc_Doc_Num = {num}"
            End If

            strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
            strSQL = Replace(strSQL, "{año}", CeldaAño.Text)
            strSQL = Replace(strSQL, "{num}", CeldaNumero.Text)

            COM.CommandText = strSQL

            COM.CommandType = CommandType.Text

            If txtSat.Text = "" Then
                COM.Parameters.AddWithValue("?P1", DBNull.Value)
            Else
                COM.Parameters.AddWithValue("?P1", txtSat.Text)
            End If

            COM.ExecuteNonQuery()
            COM.Dispose()
            COM = Nothing

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try

    End Sub

    Private Function ComprobarDatos() As Boolean
        Dim logResult As Boolean = True
        For i As Integer = 0 To dgvTransferencia.Rows.Count - 1
            If buscarArticuloTranferencia(dgvTransferencia.Rows(i).Cells("colCodigo").Value, strConexion, Sesion.IdEmpresa) = NO_FILA Then
                dgvTransferencia.Rows(i).DefaultCellStyle.BackColor = Color.Red
                logResult = False
            ElseIf FabricanteTransferencia(dgvTransferencia.Rows(i).Cells("colCodigo").Value) = NO_FILA Then
                dgvTransferencia.Rows(i).DefaultCellStyle.BackColor = Color.Orange
                logResult = False
            Else
                dgvTransferencia.Rows(i).DefaultCellStyle.BackColor = Color.White
            End If

        Next

        Return logResult

    End Function


    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Dim frm As New frmMensaje
        If ComprobarDatos() = True Then
            'Exit Sub

            If txtSat.Text.Length > 5 Then
                Dim conexion As String = StringTransaccion()

                Button1.Enabled = False
                Try

                    For i As Integer = 0 To dgvTransferencia.Rows.Count - 1

                        Dim referencia As String = STR_VACIO

                        Dim Codigo As Integer = 0
                        Dim Bultos As Integer = 0
                        Dim Libras As Double = 0
                        Dim descripcion As String = STR_VACIO
                        Codigo = dgvTransferencia.Rows(i).Cells("colCodigo").Value
                        referencia = dgvTransferencia.Rows(i).Cells("colRef").Value
                        Bultos = dgvTransferencia.Rows(i).Cells("colBultos").Value
                        Libras = dgvTransferencia.Rows(i).Cells("colCantidad").Value
                        descripcion = dgvTransferencia.Rows(i).Cells("colDescripcion").Value


                        frm = New frmMensaje
                        frm.Mensaje = "Generando Embarque linea " & i + 1
                        frm.Show()
                        system.Windows.Forms.Application.DoEvents()
                        GuardarEncabezadoImportacion(127, referencia, Codigo, descripcion, dgvTransferencia.Rows(i).Cells("colPrecio").Value, Libras, Bultos, dgvTransferencia.Rows(i).Cells("colMedida").Value, i + 1)

                        frm.Close()
                        frm = New frmMensaje
                        frm.Mensaje = "Generando Datos de Poliza linea " & i + 1
                        frm.Show()
                        system.Windows.Forms.Application.DoEvents()
                        GuardarEncabezadoImportacion(55, referencia, Codigo, descripcion, dgvTransferencia.Rows(i).Cells("colPrecio").Value, Libras, Bultos, dgvTransferencia.Rows(i).Cells("colMedida").Value, i + 1)


                        frm.Close()
                        frm = New frmMensaje
                        frm.Mensaje = "Generando Poliza de Importaccion linea " & i + 1
                        frm.Show()
                        system.Windows.Forms.Application.DoEvents()
                        GuardarEncabezadoImportacion(180, referencia, Codigo, descripcion, dgvTransferencia.Rows(i).Cells("colPrecio").Value, Libras, Bultos, dgvTransferencia.Rows(i).Cells("colMedida").Value, i + 1)
                        frm.Close()
                        frm = New frmMensaje
                        frm.Mensaje = "Generando Ingreso a Bodega linea " & i + 1
                        system.Windows.Forms.Application.DoEvents()
                        frm.Show()
                        GuardarEncabezadoImportacion(47, referencia, Codigo, descripcion, dgvTransferencia.Rows(i).Cells("colPrecio").Value, Libras, Bultos, dgvTransferencia.Rows(i).Cells("colMedida").Value, i + 1)
                        GuadarSat()

                        frm.Close()
                    Next

                    MsgBox("DATOS ALMACENADOS", MsgBoxStyle.Information)

                    MostrarLista()

                Catch ex As Exception
                    MsgBox(ex.ToString)
                End Try

            Else
                MsgBox("Debe Ingresar un registro Sat", MsgBoxStyle.Information)
            End If

            Correlativo = 0
        Else
            MsgBox("Las linea marcadas no tiene un numeero de producto asigando en " & BaseTransf, MsgBoxStyle.Critical)
        End If
    End Sub


    Private Sub botonActualizar_Click(sender As Object, e As EventArgs) Handles botonActualizar.Click
        Dim strSQL As String = STR_VACIO
        Dim COM As MySqlCommand
        Dim Impresion As Double = 0
        Dim strTemp As String = STR_VACIO

     
        Try

            For i As Integer = 0 To dgvTransferencia.Rows.Count - 1

                strTemp = STR_VACIO
                strTemp &= " update Dcmtos_DTL d "
                strTemp &= " set d.DDoc_RF1_Dbl = {cantidad} "
                strTemp &= " where d.DDoc_Sis_Emp = {empresa} and d.DDoc_Doc_Cat = 45 and d.DDoc_Doc_Ano = {ano}  "
                strTemp &= " and d.DDoc_Doc_Num = {numero} and d.DDoc_Doc_Lin = {linea} "
                If Sesion.IdEmpresa = 18 Then
                    strTemp &= "; update PDM.Dcmtos_DTL d "
                    strTemp &= " set d.DDoc_RF1_Dbl = {cantidad} "
                    strTemp &= " where d.DDoc_Sis_Emp = {empresa} and d.DDoc_Doc_Cat = 45 and d.DDoc_Doc_Ano = {ano}  "
                    strTemp &= " and d.DDoc_Doc_Num = {numero} and d.DDoc_Doc_Lin = {linea} "
                End If

                strTemp = Replace(strTemp, "{empresa}", Sesion.IdEmpresa)
                strTemp = Replace(strTemp, "{numero}", CeldaNumero.Text)
                strTemp = Replace(strTemp, "{ano}", CeldaAño.Text)


                If dgvTransferencia.Rows(i).Cells("colImpresion").Value = Nothing Then
                    Impresion = 0
                Else
                    Impresion = dgvTransferencia.Rows(i).Cells("colImpresion").Value
                End If
                MyCnn.CONECTAR = strConexion
                strTemp = Replace(strTemp, "{linea}", i + INT_UNO)
                strTemp = Replace(strTemp, "{cantidad}", Impresion)
                COM = New MySqlCommand(strTemp, CON)

                COM.ExecuteNonQuery()
            Next
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try

    End Sub

End Class