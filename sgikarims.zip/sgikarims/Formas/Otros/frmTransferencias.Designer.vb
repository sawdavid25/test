﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmTransferencias
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim DataGridViewCellStyle1 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Me.panelLista = New System.Windows.Forms.Panel()
        Me.dgLista = New System.Windows.Forms.DataGridView()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.botonFiltrar = New System.Windows.Forms.Button()
        Me.dtpFin = New System.Windows.Forms.DateTimePicker()
        Me.dtpInicio = New System.Windows.Forms.DateTimePicker()
        Me.checkFechas = New System.Windows.Forms.CheckBox()
        Me.panelDocumento = New System.Windows.Forms.Panel()
        Me.pnlCentral = New System.Windows.Forms.Panel()
        Me.pnlgTrasferencia = New System.Windows.Forms.Panel()
        Me.dgvTransferencia = New System.Windows.Forms.DataGridView()
        Me.colAño = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colNumero = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colLinea = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colCodigo = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colDescripcion = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colPrecio = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colCantidad = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colTotal = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colRef = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colMedida = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Measure = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colBultos = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colType = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colImpresion = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.pnright = New System.Windows.Forms.Panel()
        Me.btnQuitar = New System.Windows.Forms.Button()
        Me.btnAgregar = New System.Windows.Forms.Button()
        Me.pnlTop = New System.Windows.Forms.Panel()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.txtSat = New System.Windows.Forms.TextBox()
        Me.lblTasa = New System.Windows.Forms.Label()
        Me.celdaTasa = New System.Windows.Forms.Label()
        Me.lblnumerot = New System.Windows.Forms.Label()
        Me.lblañot = New System.Windows.Forms.Label()
        Me.lblcodMoneda = New System.Windows.Forms.Label()
        Me.lblcodCustomer = New System.Windows.Forms.Label()
        Me.CeldaCliente = New System.Windows.Forms.TextBox()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Number = New System.Windows.Forms.Label()
        Me.Year = New System.Windows.Forms.Label()
        Me.btnSeleccionar = New System.Windows.Forms.Button()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.CeldaMonto = New System.Windows.Forms.TextBox()
        Me.CeldaMoneda = New System.Windows.Forms.TextBox()
        Me.CeldaNumero = New System.Windows.Forms.TextBox()
        Me.CeldaAño = New System.Windows.Forms.TextBox()
        Me.dtpFecha = New System.Windows.Forms.DateTimePicker()
        Me.botonImprimir = New System.Windows.Forms.Button()
        Me.btnIngreso = New System.Windows.Forms.Button()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.botonActualizar = New System.Windows.Forms.Button()
        Me.BarraTitulo1 = New KARIMs_SGI.BarraTitulo()
        Me.Encabezado1 = New KARIMs_SGI.encabezado()
        Me.panelLista.SuspendLayout()
        CType(Me.dgLista, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox1.SuspendLayout()
        Me.panelDocumento.SuspendLayout()
        Me.pnlCentral.SuspendLayout()
        Me.pnlgTrasferencia.SuspendLayout()
        CType(Me.dgvTransferencia, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.pnright.SuspendLayout()
        Me.pnlTop.SuspendLayout()
        Me.SuspendLayout()
        '
        'panelLista
        '
        Me.panelLista.Controls.Add(Me.dgLista)
        Me.panelLista.Controls.Add(Me.GroupBox1)
        Me.panelLista.Location = New System.Drawing.Point(12, 128)
        Me.panelLista.Name = "panelLista"
        Me.panelLista.Size = New System.Drawing.Size(619, 451)
        Me.panelLista.TabIndex = 0
        '
        'dgLista
        '
        Me.dgLista.AllowUserToAddRows = False
        Me.dgLista.AllowUserToDeleteRows = False
        Me.dgLista.AllowUserToResizeColumns = False
        Me.dgLista.AllowUserToResizeRows = False
        Me.dgLista.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgLista.Dock = System.Windows.Forms.DockStyle.Fill
        Me.dgLista.GridColor = System.Drawing.SystemColors.Control
        Me.dgLista.Location = New System.Drawing.Point(0, 82)
        Me.dgLista.MultiSelect = False
        Me.dgLista.Name = "dgLista"
        Me.dgLista.ReadOnly = True
        Me.dgLista.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.dgLista.Size = New System.Drawing.Size(619, 369)
        Me.dgLista.TabIndex = 0
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.botonFiltrar)
        Me.GroupBox1.Controls.Add(Me.dtpFin)
        Me.GroupBox1.Controls.Add(Me.dtpInicio)
        Me.GroupBox1.Controls.Add(Me.checkFechas)
        Me.GroupBox1.Dock = System.Windows.Forms.DockStyle.Top
        Me.GroupBox1.Location = New System.Drawing.Point(0, 0)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(619, 82)
        Me.GroupBox1.TabIndex = 1
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Filtrar por:"
        '
        'botonFiltrar
        '
        Me.botonFiltrar.Location = New System.Drawing.Point(221, 48)
        Me.botonFiltrar.Name = "botonFiltrar"
        Me.botonFiltrar.Size = New System.Drawing.Size(75, 23)
        Me.botonFiltrar.TabIndex = 3
        Me.botonFiltrar.Text = "Filtrar"
        Me.botonFiltrar.UseVisualStyleBackColor = True
        '
        'dtpFin
        '
        Me.dtpFin.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.dtpFin.Location = New System.Drawing.Point(118, 48)
        Me.dtpFin.Name = "dtpFin"
        Me.dtpFin.Size = New System.Drawing.Size(97, 20)
        Me.dtpFin.TabIndex = 2
        '
        'dtpInicio
        '
        Me.dtpInicio.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.dtpInicio.Location = New System.Drawing.Point(15, 48)
        Me.dtpInicio.Name = "dtpInicio"
        Me.dtpInicio.Size = New System.Drawing.Size(97, 20)
        Me.dtpInicio.TabIndex = 1
        '
        'checkFechas
        '
        Me.checkFechas.AutoSize = True
        Me.checkFechas.Checked = True
        Me.checkFechas.CheckState = System.Windows.Forms.CheckState.Checked
        Me.checkFechas.Location = New System.Drawing.Point(15, 25)
        Me.checkFechas.Name = "checkFechas"
        Me.checkFechas.Size = New System.Drawing.Size(111, 17)
        Me.checkFechas.TabIndex = 0
        Me.checkFechas.Text = "Rango de Fechas"
        Me.checkFechas.UseVisualStyleBackColor = True
        '
        'panelDocumento
        '
        Me.panelDocumento.Controls.Add(Me.pnlCentral)
        Me.panelDocumento.Controls.Add(Me.pnlTop)
        Me.panelDocumento.Location = New System.Drawing.Point(647, 128)
        Me.panelDocumento.Name = "panelDocumento"
        Me.panelDocumento.Size = New System.Drawing.Size(662, 451)
        Me.panelDocumento.TabIndex = 1
        '
        'pnlCentral
        '
        Me.pnlCentral.Controls.Add(Me.pnlgTrasferencia)
        Me.pnlCentral.Controls.Add(Me.pnright)
        Me.pnlCentral.Dock = System.Windows.Forms.DockStyle.Fill
        Me.pnlCentral.Location = New System.Drawing.Point(0, 135)
        Me.pnlCentral.Name = "pnlCentral"
        Me.pnlCentral.Size = New System.Drawing.Size(662, 316)
        Me.pnlCentral.TabIndex = 2
        '
        'pnlgTrasferencia
        '
        Me.pnlgTrasferencia.Controls.Add(Me.dgvTransferencia)
        Me.pnlgTrasferencia.Dock = System.Windows.Forms.DockStyle.Fill
        Me.pnlgTrasferencia.Location = New System.Drawing.Point(0, 0)
        Me.pnlgTrasferencia.Name = "pnlgTrasferencia"
        Me.pnlgTrasferencia.Size = New System.Drawing.Size(612, 316)
        Me.pnlgTrasferencia.TabIndex = 2
        '
        'dgvTransferencia
        '
        Me.dgvTransferencia.AllowUserToAddRows = False
        Me.dgvTransferencia.AllowUserToDeleteRows = False
        Me.dgvTransferencia.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells
        Me.dgvTransferencia.BackgroundColor = System.Drawing.SystemColors.ActiveBorder
        Me.dgvTransferencia.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgvTransferencia.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.colAño, Me.colNumero, Me.colLinea, Me.colCodigo, Me.colDescripcion, Me.colPrecio, Me.colCantidad, Me.colTotal, Me.colRef, Me.colMedida, Me.Measure, Me.colBultos, Me.colType, Me.colImpresion})
        Me.dgvTransferencia.Dock = System.Windows.Forms.DockStyle.Fill
        Me.dgvTransferencia.Location = New System.Drawing.Point(0, 0)
        Me.dgvTransferencia.Name = "dgvTransferencia"
        Me.dgvTransferencia.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.dgvTransferencia.Size = New System.Drawing.Size(612, 316)
        Me.dgvTransferencia.TabIndex = 0
        '
        'colAño
        '
        Me.colAño.HeaderText = "Year"
        Me.colAño.Name = "colAño"
        Me.colAño.Visible = False
        Me.colAño.Width = 54
        '
        'colNumero
        '
        Me.colNumero.HeaderText = "Number"
        Me.colNumero.Name = "colNumero"
        Me.colNumero.Visible = False
        Me.colNumero.Width = 69
        '
        'colLinea
        '
        Me.colLinea.HeaderText = "Line"
        Me.colLinea.Name = "colLinea"
        Me.colLinea.Visible = False
        Me.colLinea.Width = 52
        '
        'colCodigo
        '
        Me.colCodigo.HeaderText = "Code"
        Me.colCodigo.Name = "colCodigo"
        Me.colCodigo.Width = 57
        '
        'colDescripcion
        '
        Me.colDescripcion.HeaderText = "Description"
        Me.colDescripcion.Name = "colDescripcion"
        Me.colDescripcion.Width = 85
        '
        'colPrecio
        '
        Me.colPrecio.HeaderText = "Price"
        Me.colPrecio.Name = "colPrecio"
        Me.colPrecio.Width = 56
        '
        'colCantidad
        '
        Me.colCantidad.HeaderText = "Quantity"
        Me.colCantidad.Name = "colCantidad"
        Me.colCantidad.Width = 71
        '
        'colTotal
        '
        Me.colTotal.HeaderText = "Amount"
        Me.colTotal.Name = "colTotal"
        Me.colTotal.Width = 68
        '
        'colRef
        '
        Me.colRef.HeaderText = "Reference"
        Me.colRef.Name = "colRef"
        Me.colRef.Width = 82
        '
        'colMedida
        '
        Me.colMedida.HeaderText = "Measure"
        Me.colMedida.Name = "colMedida"
        Me.colMedida.Visible = False
        Me.colMedida.Width = 73
        '
        'Measure
        '
        Me.Measure.HeaderText = "Measure"
        Me.Measure.Name = "Measure"
        Me.Measure.Width = 73
        '
        'colBultos
        '
        Me.colBultos.HeaderText = "Packages"
        Me.colBultos.Name = "colBultos"
        Me.colBultos.Width = 80
        '
        'colType
        '
        Me.colType.HeaderText = "Type Packeges"
        Me.colType.Name = "colType"
        Me.colType.Width = 98
        '
        'colImpresion
        '
        DataGridViewCellStyle1.NullValue = "0"
        Me.colImpresion.DefaultCellStyle = DataGridViewCellStyle1
        Me.colImpresion.HeaderText = "Quantity Print"
        Me.colImpresion.Name = "colImpresion"
        Me.colImpresion.Width = 87
        '
        'pnright
        '
        Me.pnright.Controls.Add(Me.btnQuitar)
        Me.pnright.Controls.Add(Me.btnAgregar)
        Me.pnright.Dock = System.Windows.Forms.DockStyle.Right
        Me.pnright.Location = New System.Drawing.Point(612, 0)
        Me.pnright.Name = "pnright"
        Me.pnright.Size = New System.Drawing.Size(50, 316)
        Me.pnright.TabIndex = 1
        '
        'btnQuitar
        '
        Me.btnQuitar.Image = Global.KARIMs_SGI.My.Resources.Resources.delete3
        Me.btnQuitar.Location = New System.Drawing.Point(8, 43)
        Me.btnQuitar.Name = "btnQuitar"
        Me.btnQuitar.Size = New System.Drawing.Size(39, 32)
        Me.btnQuitar.TabIndex = 2
        Me.btnQuitar.UseVisualStyleBackColor = True
        '
        'btnAgregar
        '
        Me.btnAgregar.Image = Global.KARIMs_SGI.My.Resources.Resources.plus
        Me.btnAgregar.Location = New System.Drawing.Point(6, 6)
        Me.btnAgregar.Name = "btnAgregar"
        Me.btnAgregar.Size = New System.Drawing.Size(39, 31)
        Me.btnAgregar.TabIndex = 1
        Me.btnAgregar.UseVisualStyleBackColor = True
        '
        'pnlTop
        '
        Me.pnlTop.Controls.Add(Me.Label1)
        Me.pnlTop.Controls.Add(Me.txtSat)
        Me.pnlTop.Controls.Add(Me.lblTasa)
        Me.pnlTop.Controls.Add(Me.celdaTasa)
        Me.pnlTop.Controls.Add(Me.lblnumerot)
        Me.pnlTop.Controls.Add(Me.lblañot)
        Me.pnlTop.Controls.Add(Me.lblcodMoneda)
        Me.pnlTop.Controls.Add(Me.lblcodCustomer)
        Me.pnlTop.Controls.Add(Me.CeldaCliente)
        Me.pnlTop.Controls.Add(Me.Label4)
        Me.pnlTop.Controls.Add(Me.Label3)
        Me.pnlTop.Controls.Add(Me.Number)
        Me.pnlTop.Controls.Add(Me.Year)
        Me.pnlTop.Controls.Add(Me.btnSeleccionar)
        Me.pnlTop.Controls.Add(Me.Label11)
        Me.pnlTop.Controls.Add(Me.Label6)
        Me.pnlTop.Controls.Add(Me.CeldaMonto)
        Me.pnlTop.Controls.Add(Me.CeldaMoneda)
        Me.pnlTop.Controls.Add(Me.CeldaNumero)
        Me.pnlTop.Controls.Add(Me.CeldaAño)
        Me.pnlTop.Controls.Add(Me.dtpFecha)
        Me.pnlTop.Dock = System.Windows.Forms.DockStyle.Top
        Me.pnlTop.Location = New System.Drawing.Point(0, 0)
        Me.pnlTop.Name = "pnlTop"
        Me.pnlTop.Size = New System.Drawing.Size(662, 135)
        Me.pnlTop.TabIndex = 1
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(19, 109)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(57, 13)
        Me.Label1.TabIndex = 41
        Me.Label1.Text = "Reference"
        '
        'txtSat
        '
        Me.txtSat.Location = New System.Drawing.Point(84, 106)
        Me.txtSat.Name = "txtSat"
        Me.txtSat.Size = New System.Drawing.Size(159, 20)
        Me.txtSat.TabIndex = 40
        '
        'lblTasa
        '
        Me.lblTasa.Anchor = System.Windows.Forms.AnchorStyles.Right
        Me.lblTasa.AutoSize = True
        Me.lblTasa.Location = New System.Drawing.Point(548, 97)
        Me.lblTasa.Name = "lblTasa"
        Me.lblTasa.Size = New System.Drawing.Size(0, 13)
        Me.lblTasa.TabIndex = 39
        '
        'celdaTasa
        '
        Me.celdaTasa.Anchor = System.Windows.Forms.AnchorStyles.Right
        Me.celdaTasa.AutoSize = True
        Me.celdaTasa.Location = New System.Drawing.Point(511, 96)
        Me.celdaTasa.Name = "celdaTasa"
        Me.celdaTasa.Size = New System.Drawing.Size(31, 13)
        Me.celdaTasa.TabIndex = 38
        Me.celdaTasa.Text = "Tasa"
        '
        'lblnumerot
        '
        Me.lblnumerot.AutoSize = True
        Me.lblnumerot.Location = New System.Drawing.Point(562, 38)
        Me.lblnumerot.Name = "lblnumerot"
        Me.lblnumerot.Size = New System.Drawing.Size(42, 13)
        Me.lblnumerot.TabIndex = 37
        Me.lblnumerot.Text = "numero"
        Me.lblnumerot.Visible = False
        '
        'lblañot
        '
        Me.lblañot.AutoSize = True
        Me.lblañot.Location = New System.Drawing.Point(562, 15)
        Me.lblañot.Name = "lblañot"
        Me.lblañot.Size = New System.Drawing.Size(25, 13)
        Me.lblañot.TabIndex = 36
        Me.lblañot.Text = "año"
        Me.lblañot.Visible = False
        '
        'lblcodMoneda
        '
        Me.lblcodMoneda.AutoSize = True
        Me.lblcodMoneda.Location = New System.Drawing.Point(356, 52)
        Me.lblcodMoneda.Name = "lblcodMoneda"
        Me.lblcodMoneda.Size = New System.Drawing.Size(0, 13)
        Me.lblcodMoneda.TabIndex = 35
        Me.lblcodMoneda.Visible = False
        '
        'lblcodCustomer
        '
        Me.lblcodCustomer.Anchor = System.Windows.Forms.AnchorStyles.Right
        Me.lblcodCustomer.AutoSize = True
        Me.lblcodCustomer.Location = New System.Drawing.Point(329, 86)
        Me.lblcodCustomer.Name = "lblcodCustomer"
        Me.lblcodCustomer.Size = New System.Drawing.Size(0, 13)
        Me.lblcodCustomer.TabIndex = 34
        Me.lblcodCustomer.Visible = False
        '
        'CeldaCliente
        '
        Me.CeldaCliente.Location = New System.Drawing.Point(76, 72)
        Me.CeldaCliente.Name = "CeldaCliente"
        Me.CeldaCliente.Size = New System.Drawing.Size(200, 20)
        Me.CeldaCliente.TabIndex = 31
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(19, 79)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(51, 13)
        Me.Label4.TabIndex = 30
        Me.Label4.Text = "Customer"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(19, 14)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(30, 13)
        Me.Label3.TabIndex = 29
        Me.Label3.Text = "Date"
        '
        'Number
        '
        Me.Number.AutoSize = True
        Me.Number.Location = New System.Drawing.Point(148, 45)
        Me.Number.Name = "Number"
        Me.Number.Size = New System.Drawing.Size(44, 13)
        Me.Number.TabIndex = 28
        Me.Number.Text = "Number"
        '
        'Year
        '
        Me.Year.AutoSize = True
        Me.Year.Location = New System.Drawing.Point(19, 45)
        Me.Year.Name = "Year"
        Me.Year.Size = New System.Drawing.Size(29, 13)
        Me.Year.TabIndex = 27
        Me.Year.Text = "Year"
        '
        'btnSeleccionar
        '
        Me.btnSeleccionar.Anchor = System.Windows.Forms.AnchorStyles.Right
        Me.btnSeleccionar.Location = New System.Drawing.Point(475, 39)
        Me.btnSeleccionar.Name = "btnSeleccionar"
        Me.btnSeleccionar.Size = New System.Drawing.Size(35, 20)
        Me.btnSeleccionar.TabIndex = 26
        Me.btnSeleccionar.Text = "..."
        Me.btnSeleccionar.UseVisualStyleBackColor = True
        '
        'Label11
        '
        Me.Label11.Anchor = System.Windows.Forms.AnchorStyles.Right
        Me.Label11.AutoSize = True
        Me.Label11.Location = New System.Drawing.Point(406, 74)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(43, 13)
        Me.Label11.TabIndex = 25
        Me.Label11.Text = "Amount"
        '
        'Label6
        '
        Me.Label6.Anchor = System.Windows.Forms.AnchorStyles.Right
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(406, 21)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(49, 13)
        Me.Label6.TabIndex = 24
        Me.Label6.Text = "Currency"
        '
        'CeldaMonto
        '
        Me.CeldaMonto.Anchor = System.Windows.Forms.AnchorStyles.Right
        Me.CeldaMonto.BackColor = System.Drawing.SystemColors.Info
        Me.CeldaMonto.Enabled = False
        Me.CeldaMonto.Location = New System.Drawing.Point(409, 90)
        Me.CeldaMonto.Name = "CeldaMonto"
        Me.CeldaMonto.Size = New System.Drawing.Size(77, 20)
        Me.CeldaMonto.TabIndex = 4
        '
        'CeldaMoneda
        '
        Me.CeldaMoneda.Anchor = System.Windows.Forms.AnchorStyles.Right
        Me.CeldaMoneda.BackColor = System.Drawing.SystemColors.Info
        Me.CeldaMoneda.Enabled = False
        Me.CeldaMoneda.Location = New System.Drawing.Point(409, 40)
        Me.CeldaMoneda.Name = "CeldaMoneda"
        Me.CeldaMoneda.Size = New System.Drawing.Size(60, 20)
        Me.CeldaMoneda.TabIndex = 3
        '
        'CeldaNumero
        '
        Me.CeldaNumero.Location = New System.Drawing.Point(198, 38)
        Me.CeldaNumero.Name = "CeldaNumero"
        Me.CeldaNumero.Size = New System.Drawing.Size(57, 20)
        Me.CeldaNumero.TabIndex = 2
        Me.CeldaNumero.Text = "-1"
        Me.CeldaNumero.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'CeldaAño
        '
        Me.CeldaAño.Location = New System.Drawing.Point(76, 38)
        Me.CeldaAño.Name = "CeldaAño"
        Me.CeldaAño.Size = New System.Drawing.Size(54, 20)
        Me.CeldaAño.TabIndex = 1
        Me.CeldaAño.Text = "-1"
        Me.CeldaAño.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'dtpFecha
        '
        Me.dtpFecha.Location = New System.Drawing.Point(76, 8)
        Me.dtpFecha.Name = "dtpFecha"
        Me.dtpFecha.Size = New System.Drawing.Size(200, 20)
        Me.dtpFecha.TabIndex = 0
        '
        'botonImprimir
        '
        Me.botonImprimir.Image = Global.KARIMs_SGI.My.Resources.Resources.print
        Me.botonImprimir.ImageAlign = System.Drawing.ContentAlignment.TopCenter
        Me.botonImprimir.Location = New System.Drawing.Point(206, 12)
        Me.botonImprimir.Name = "botonImprimir"
        Me.botonImprimir.Size = New System.Drawing.Size(61, 42)
        Me.botonImprimir.TabIndex = 8
        Me.botonImprimir.Text = "Imprimir"
        Me.botonImprimir.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.botonImprimir.UseVisualStyleBackColor = True
        '
        'btnIngreso
        '
        Me.btnIngreso.Location = New System.Drawing.Point(428, 12)
        Me.btnIngreso.Name = "btnIngreso"
        Me.btnIngreso.Size = New System.Drawing.Size(61, 42)
        Me.btnIngreso.TabIndex = 40
        Me.btnIngreso.Text = "Ingreso Bodega"
        Me.btnIngreso.UseVisualStyleBackColor = True
        Me.btnIngreso.Visible = False
        '
        'Button1
        '
        Me.Button1.Location = New System.Drawing.Point(354, 12)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(68, 42)
        Me.Button1.TabIndex = 41
        Me.Button1.Text = "Ingreso a Bodega"
        Me.Button1.UseVisualStyleBackColor = True
        '
        'botonActualizar
        '
        Me.botonActualizar.Location = New System.Drawing.Point(273, 12)
        Me.botonActualizar.Name = "botonActualizar"
        Me.botonActualizar.Size = New System.Drawing.Size(75, 42)
        Me.botonActualizar.TabIndex = 42
        Me.botonActualizar.Text = "Actualizar"
        Me.botonActualizar.UseVisualStyleBackColor = True
        '
        'BarraTitulo1
        '
        Me.BarraTitulo1.BackColor = System.Drawing.Color.WhiteSmoke
        Me.BarraTitulo1.Dock = System.Windows.Forms.DockStyle.Top
        Me.BarraTitulo1.Location = New System.Drawing.Point(0, 72)
        Me.BarraTitulo1.Name = "BarraTitulo1"
        Me.BarraTitulo1.Size = New System.Drawing.Size(1339, 30)
        Me.BarraTitulo1.TabIndex = 3
        '
        'Encabezado1
        '
        Me.Encabezado1.Dock = System.Windows.Forms.DockStyle.Top
        Me.Encabezado1.Location = New System.Drawing.Point(0, 0)
        Me.Encabezado1.Name = "Encabezado1"
        Me.Encabezado1.Size = New System.Drawing.Size(1339, 72)
        Me.Encabezado1.TabIndex = 2
        '
        'frmTransferencias
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1339, 636)
        Me.Controls.Add(Me.botonActualizar)
        Me.Controls.Add(Me.Button1)
        Me.Controls.Add(Me.btnIngreso)
        Me.Controls.Add(Me.botonImprimir)
        Me.Controls.Add(Me.panelDocumento)
        Me.Controls.Add(Me.panelLista)
        Me.Controls.Add(Me.BarraTitulo1)
        Me.Controls.Add(Me.Encabezado1)
        Me.MinimizeBox = False
        Me.Name = "frmTransferencias"
        Me.Text = "Transferencias"
        Me.WindowState = System.Windows.Forms.FormWindowState.Maximized
        Me.panelLista.ResumeLayout(False)
        CType(Me.dgLista, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.panelDocumento.ResumeLayout(False)
        Me.pnlCentral.ResumeLayout(False)
        Me.pnlgTrasferencia.ResumeLayout(False)
        CType(Me.dgvTransferencia, System.ComponentModel.ISupportInitialize).EndInit()
        Me.pnright.ResumeLayout(False)
        Me.pnlTop.ResumeLayout(False)
        Me.pnlTop.PerformLayout()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents panelLista As System.Windows.Forms.Panel
    Friend WithEvents dgLista As System.Windows.Forms.DataGridView
    Friend WithEvents Encabezado1 As KARIMs_SGI.encabezado
    Friend WithEvents BarraTitulo1 As KARIMs_SGI.BarraTitulo
    Friend WithEvents panelDocumento As System.Windows.Forms.Panel
    Friend WithEvents pnlTop As System.Windows.Forms.Panel
    Friend WithEvents pnlCentral As System.Windows.Forms.Panel
    Friend WithEvents pnright As System.Windows.Forms.Panel
    Friend WithEvents pnlgTrasferencia As System.Windows.Forms.Panel
    Friend WithEvents dgvTransferencia As System.Windows.Forms.DataGridView
    Friend WithEvents btnQuitar As System.Windows.Forms.Button
    Friend WithEvents btnAgregar As System.Windows.Forms.Button
    Friend WithEvents CeldaAño As System.Windows.Forms.TextBox
    Friend WithEvents dtpFecha As System.Windows.Forms.DateTimePicker
    Friend WithEvents CeldaNumero As System.Windows.Forms.TextBox
    Friend WithEvents CeldaMonto As System.Windows.Forms.TextBox
    Friend WithEvents CeldaMoneda As System.Windows.Forms.TextBox
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents Label11 As System.Windows.Forms.Label
    Friend WithEvents btnSeleccionar As System.Windows.Forms.Button
    Friend WithEvents CeldaCliente As System.Windows.Forms.TextBox
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Number As System.Windows.Forms.Label
    Friend WithEvents Year As System.Windows.Forms.Label
    Friend WithEvents lblcodMoneda As System.Windows.Forms.Label
    Friend WithEvents lblcodCustomer As System.Windows.Forms.Label
    Friend WithEvents lblnumerot As System.Windows.Forms.Label
    Friend WithEvents lblañot As System.Windows.Forms.Label
    Friend WithEvents lblTasa As System.Windows.Forms.Label
    Friend WithEvents celdaTasa As System.Windows.Forms.Label
    Friend WithEvents botonImprimir As System.Windows.Forms.Button
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents botonFiltrar As System.Windows.Forms.Button
    Friend WithEvents dtpFin As System.Windows.Forms.DateTimePicker
    Friend WithEvents dtpInicio As System.Windows.Forms.DateTimePicker
    Friend WithEvents checkFechas As System.Windows.Forms.CheckBox
    Friend WithEvents btnIngreso As System.Windows.Forms.Button
    Friend WithEvents txtSat As System.Windows.Forms.TextBox
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Button1 As System.Windows.Forms.Button
    Friend WithEvents botonActualizar As System.Windows.Forms.Button
    Friend WithEvents colAño As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colNumero As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colLinea As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colCodigo As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colDescripcion As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colPrecio As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colCantidad As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colTotal As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colRef As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colMedida As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Measure As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colBultos As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colType As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colImpresion As System.Windows.Forms.DataGridViewTextBoxColumn
End Class
