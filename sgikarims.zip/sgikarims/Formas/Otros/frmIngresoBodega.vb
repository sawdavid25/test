﻿Imports System.ComponentModel
Imports System.IO
Imports System.Windows

Public Class frmIngresoBodega

#Region "Miembros"
    Dim strKey As String = STR_VACIO
    Dim logInsertar As Boolean = False
    Dim logConsultar As Boolean = False
    Dim logEditar As Boolean = False
    Dim LogBorrar As Boolean = False
    Dim intTipoIngreso As Integer = NO_FILA
    Dim intTipoWaste As Integer = NO_FILA
    Dim intTipoInvisible As Integer = NO_FILA
    Dim cfun As New clsFunciones

    Dim intTipo As Integer

    Dim intMultiple As Integer
    Dim dblDocCantidad As Double
    Dim dblDocTotal As Double
    Dim CodProv As Integer = vbEmpty
    Dim logProduction As Boolean

    Dim productoDatos(15) As String
    Dim anoPO, idPO As Integer
    'Constantes
    Public Const TBL_DOCUMENTOS As String = "Dcmtos_HDR"
    Private Const CATALOGO = 47
#End Region

#Region "Propiedades"
    Public Property Key As String
        Get
            Return strKey
        End Get
        Set(value As String)
            strKey = value
        End Set
    End Property
#End Region

#Region "Procedimientos"

    Private Sub PintarTipoIngreso()
        etiquetaRefFactura.Text = "Reference Invoice"
        EtiquetaRef1.Text = "Ref. No. 1 "
        etiquetaRef2.Text = "Ref. No. 2"
        If Sesion.IdEmpresa = 22 And (intTipo = 2 Or intTipo = 14 Or intTipo = 15 Or intTipo = 16 Or intTipo = 17) Then
            etiquetaRefFactura.Text = "Batch"
            EtiquetaRef1.Text = "Color"
            etiquetaRef2.Text = "Fabric Form"
        End If
        If intTipo = 4 Then 'desperdicio
            dgDetalle.Columns("colPrdPNr").Visible = True
            dgDetalle.Columns("colPrdPNr").ReadOnly = False
            dgDetalle.Columns("colPrdPNr").HeaderText = "Waste Ref"
        Else
            dgDetalle.Columns("colPrdPNr").Visible = False
            dgDetalle.Columns("colPrdPNr").ReadOnly = True
        End If
        Select Case intTipo
            Case 0
                celdaTipoIng.Text = "IMPORT"
                celdaTipoIng.BackColor = Color.LightYellow
                celdaTipoIng.ForeColor = Color.Black
            Case 1
                celdaTipoIng.Text = "PACKING"
                celdaTipoIng.BackColor = Color.DarkBlue
                celdaTipoIng.ForeColor = Color.White
            Case 2
                If Sesion.IdEmpresa = 22 Then
                    celdaTipoIng.Text = "GREIGE"
                Else
                    celdaTipoIng.Text = "YARN PRODUCTION"
                End If

                celdaTipoIng.BackColor = Color.LightGreen
                celdaTipoIng.ForeColor = Color.Black
            Case 3
                celdaTipoIng.Text = "CONSUMABLE"
                celdaTipoIng.BackColor = Color.Orange
                celdaTipoIng.ForeColor = Color.Black

            Case 4
                celdaTipoIng.Text = "WASTE"
                celdaTipoIng.BackColor = Color.Salmon
                celdaTipoIng.ForeColor = Color.Black
            Case 5
                celdaTipoIng.Text = "INVISIBLE"
                celdaTipoIng.BackColor = Color.Blue
                celdaTipoIng.ForeColor = Color.White
            Case 6
                celdaTipoIng.Text = "PRODUCT ON PROCESS"
                celdaTipoIng.BackColor = Color.Salmon
                celdaTipoIng.ForeColor = Color.Black
            Case 7
                celdaTipoIng.Text = "Return of Consumables"
                celdaTipoIng.BackColor = Color.Salmon
                celdaTipoIng.ForeColor = Color.Black
            Case 8
                celdaTipoIng.Text = "2% inventory"
                celdaTipoIng.BackColor = Color.Salmon
                celdaTipoIng.ForeColor = Color.Black
            Case 9
                celdaTipoIng.Text = "Reusable Spare Parts"
                celdaTipoIng.BackColor = Color.Salmon
                celdaTipoIng.ForeColor = Color.Black
            Case 10
                celdaTipoIng.Text = "Partially Used Spare Parts"
                celdaTipoIng.BackColor = Color.Salmon
                celdaTipoIng.ForeColor = Color.Black
            Case 11
                celdaTipoIng.Text = "Guarantee revenue"
                celdaTipoIng.BackColor = Color.Salmon
                celdaTipoIng.ForeColor = Color.Black
            Case 12
                celdaTipoIng.Text = "Per Contract"
                celdaTipoIng.BackColor = Color.Salmon
                celdaTipoIng.ForeColor = Color.Black
            Case 13
                celdaTipoIng.Text = "transit repairs"
                celdaTipoIng.BackColor = Color.Salmon
                celdaTipoIng.ForeColor = Color.Black
            Case 14
                celdaTipoIng.Text = "DYEING"
                celdaTipoIng.BackColor = Color.LightGreen
                celdaTipoIng.ForeColor = Color.Black
            Case 15
                celdaTipoIng.Text = "FINISHING"
                celdaTipoIng.BackColor = Color.LightGreen
                celdaTipoIng.ForeColor = Color.Black
            Case 16
                celdaTipoIng.Text = "ROLLING"
                celdaTipoIng.BackColor = Color.LightGreen
                celdaTipoIng.ForeColor = Color.Black
            Case 17
                celdaTipoIng.Text = "FINISH GOOD"
                celdaTipoIng.BackColor = Color.LightGreen
                celdaTipoIng.ForeColor = Color.Black
        End Select

    End Sub

    Private Sub Accessos()
        Dim cAccesos As New clsAccesos
        Dim strSQL As String = STR_VACIO
        Dim com As MySqlCommand
        Try
            If cAccesos.Accesos(strKey) = True Then
                logInsertar = cAccesos.Insertar
                logConsultar = cAccesos.Consultar
                logEditar = cAccesos.Editar
                LogBorrar = cAccesos.Borrar

                strSQL = "select ifnull(pms_nivel, -1) permiso "
                strSQL &= " from Permisos p  "
                strSQL &= " where p.pms_empresa = {empresa} and p.pms_modulo = 15 and p.pms_usuario = '{usuario}' "

                strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
                strSQL = Replace(strSQL, "{usuario}", Sesion.Usuario)
                MyCnn.CONECTAR = strConexion
                com = New MySqlCommand(strSQL, CON)
                intTipoIngreso = com.ExecuteScalar

            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub BloquearBotones(Optional ByVal logBloquear As Boolean = True)
        If logBloquear = True Then
            Encabezado1.botonBorrar.Enabled = False
            Encabezado1.botonGuardar.Enabled = False
            botonImprimir.Enabled = False

            BotonImprimirRotulo.Visible = False


        Else
            Encabezado1.botonBorrar.Enabled = True
            Encabezado1.botonGuardar.Enabled = True
            botonImprimir.Enabled = True
            If Sesion.idGiro = 1 Then
                BotonImprimirRotulo.Visible = True
            End If


        End If
    End Sub

    'Limpia todos los campos y datagrid's del panel de Fcaturacion
    Private Sub LimpiarFormulario()
        celdaAnio.Text = NO_FILA
        celdaNumero.Text = NO_FILA
        celdaEmpresa.Text = NO_FILA
        celdaUsuario.Text = STR_VACIO
        'dtpFech.Text = NO_FILA
        celdaCliente.Text = STR_VACIO
        celdaIDCliente.Text = NO_FILA
        celdaDireccion.Text = STR_VACIO
        celdaMoneda.Text = STR_VACIO
        celdaIDMoneda.Text = NO_FILA
        celdaTasa.Text = NO_FILA
        celdaSubTotal.Text = NO_FILA
        celdaTotal.Text = NO_FILA
        celdaTipoIng.Clear()
        If intTipo = 0 Then
            If Sesion.IdEmpresa = 18 Then
                celdaRefFactura.ReadOnly = False
                celdaRef1.ReadOnly = False
                celdaRef2.ReadOnly = False
            Else
                celdaRefFactura.ReadOnly = True
                celdaRef1.ReadOnly = True
                celdaRef2.ReadOnly = True
            End If

        ElseIf intTipo = 1 Then
            celdaRefFactura.ReadOnly = False
            celdaRef1.ReadOnly = False
            celdaRef2.ReadOnly = False
        End If
        If Sesion.idGiro = 2 Then
            checkTendido.Visible = True
            checkTendido.Enabled = True
        Else
            checkTendido.Visible = False
            checkTendido.Checked = False
        End If
        checkTendido.Checked = False
        celdaRefFactura.Text = STR_VACIO
        celdaRef1.Text = STR_VACIO
        celdaRef2.Text = STR_VACIO
        celdaRevisado.Text = NO_FILA
        botonDespachos.BackColor = Color.LightGray
        If (Sesion.IdEmpresa = 15) Or (Sesion.IdEmpresa = 18) Or (Sesion.IdEmpresa = 19) Or (Sesion.IdEmpresa = 20) Then
            botonPacas.Enabled = False
        Else
            botonPacas.Visible = False
        End If
        If Me.Tag = "Nuevo" Then
            botonQuitDetalle.Enabled = True
        Else
            botonQuitDetalle.Enabled = False
        End If
        If Sesion.idGiro = 2 And intTipo = 6 Then
            CheckIngreso.Checked = False
            CheckIngreso.Enabled = True
            CheckIngreso.Visible = True
        Else
            CheckIngreso.Checked = False
            CheckIngreso.Visible = False
        End If

        dgPolizasImportacion.Rows.Clear()
        dgDetalle.Rows.Clear()
        dgSubdocumentos.Rows.Clear()
        dgDescargos.Rows.Clear()
        dgOculto.Rows.Clear()
        botonPOWE.Visible = False
    End Sub

    Private Sub MostrarLista(Optional ByVal logMostrar As Boolean = True, Optional logInsert As Boolean = False)
        Dim cfun As New clsFunciones
        If logMostrar = True Then
            'ocultar panel de documento
            panelDocumento.Dock = DockStyle.None
            panelDocumento.Visible = False
            'actualizar Titulo
            BarraTitulo1.CambiarTitulo("Entrance Of Merchandise To Warehouse ")
            'Cargar Datos
            'cfun.CargarLista(dgLista, SQLlista, False)
            queryListaPrincipal()
            'Mostrar Panel Filtro
            panelLista.Visible = True
            panelLista.Dock = DockStyle.Fill
            BloquearBotones()
            'Me.Tag = "Nuevo"
        Else
            'Ocultar Panel Filtro
            panelLista.Visible = False
            panelLista.Dock = DockStyle.None
            'Mostrar panel de documento
            panelDocumento.Dock = DockStyle.Fill
            panelDocumento.Visible = True
            'Verifica si se va a crear un nuevo documento o se va modifica

            If logInsert = False Then
                BarraTitulo1.CambiarTitulo("Entrance To Warehouse Import Policy")
                Me.Tag = "Mod"
                BloquearBotones(False)
                'botonImprimir.Enabled = True
            Else
                BarraTitulo1.CambiarTitulo("New Register")
                Me.Tag = "Nuevo"
                BloquearBotones(False)
                'botonImprimir.Enabled = False

                Reset()
            End If
            If Sesion.IdEmpresa = 22 And (intTipo = 2 Or intTipo = 14 Or intTipo = 15 Or intTipo = 16 Or intTipo = 17) Then
                etiquetaRefFactura.Text = "Batch"
                EtiquetaRef1.Text = "Color"
                etiquetaRef2.Text = "Fabric Form"
            End If
            dgLista.DataSource = Nothing
        End If
        botonPOWE.Visible = False
    End Sub

    'Query que carga Lista Principal
    Private Function SQLlista() As String

        Dim strsql As String = STR_VACIO

        strsql = " Select IFNULL(h.HDoc_Doc_Ano,0) Anio, IFNULL(h.HDoc_Doc_Num,0) Numero, IFNULL(h.HDoc_Doc_Fec,'') Fecha, IFNULL(h.HDoc_Emp_Nom,'') Nombre, IFNULL(h.HDoc_Emp_Dir,'') Direccion, IFNULL(h.HDoc_Doc_TC,0) tasa, IFNULL(h.HDoc_Doc_Mon,0) IDMoneda, IFNULL(c.cat_clave,'') SimMoneda, 
                    ELT(IFNULL(h.HDoc_DR1_Cat,0)+1,'Import','Devolution','{prod}','Consumables', 'Waste', 'Invisible Waste','Process','Return of Consumables','2% inventory','Reusable Spare Parts', 'Partially Used Spare Parts', 'Guarantee revenue', 'Per Contract', 'transit repairs','Dyeing','Finishing','Rolling','Finish good') Clase, 
                    IFNULL(h.HDoc_DR1_Num,'') Referencia, IFNULL(GROUP_CONCAT(DISTINCT(d.DDoc_RF2_Cod)),'')Bodega, IFNULL(h.HDoc_Pro_DCat, 0) Revisado, IFNULL(("
        strsql &= "  SELECT a.ADoc_Dta_Chr"
        strsql &= "    FROM Dcmtos_ACC a"
        strsql &= "      WHERE a.ADoc_Sis_Emp=h.HDoc_Sis_Emp AND a.ADoc_Doc_Cat=h.HDoc_Doc_Cat AND a.ADoc_Doc_Ano=h.HDoc_Doc_Ano AND a.ADoc_Doc_Num=h.HDoc_Doc_Num AND a.ADoc_Doc_Sub='Doc_DIngreso' AND a.ADoc_Doc_Lin='01'),'') Correlativo, "
        strsql &= "     IFNULL(( "
        strsql &= "         SELECT COUNT(*) "
        strsql &= "             FROM Dcmtos_DTL_Box b  "
        strsql &= "                 WHERE b.BDoc_Sis_Emp = h.HDoc_Sis_Emp AND b.BDoc_Doc_Cat = h.HDoc_Doc_Cat AND b.BDoc_Doc_Ano = h.HDoc_Doc_Ano AND b.BDoc_Doc_Num = h.HDoc_Doc_Num  AND b.BDoc_Box_Hsm > 0),0) Cajas "
        strsql &= "         FROM Dcmtos_HDR h"
        strsql &= "           INNER JOIN Catalogos c ON c.cat_num = h.HDoc_Doc_Mon"
        strsql &= "      LEFT JOIN Dcmtos_DTL d ON d.DDoc_Sis_Emp =h.HDoc_Sis_Emp AND d.DDoc_Doc_Cat = h.HDoc_Doc_Cat AND d.DDoc_Doc_Ano = h.HDoc_Doc_Ano AND d.DDoc_Doc_Num = h.HDoc_Doc_Num"
        strsql &= "   WHERE h.HDoc_Sis_Emp={empresa} AND h.HDoc_Doc_Cat=47  {hsm}"

        If (Sesion.IdEmpresa = 15) Or (Sesion.IdEmpresa = 18) Or (Sesion.IdEmpresa = 19) Or (Sesion.IdEmpresa = 20) Then 'hsm
            If intTipoIngreso > NO_FILA Then
                ' strsql = Replace(strsql, "{hsm}", " and HDoc_Ant_Com = " & intTipoIngreso)
                strsql = Replace(strsql, "{hsm}", STR_VACIO)
            Else
                strsql = Replace(strsql, "{hsm}", STR_VACIO)
            End If
        Else
            strsql = Replace(strsql, "{hsm}", STR_VACIO)
        End If
        If Sesion.IdEmpresa = 22 Then
            strsql = Replace(strsql, "{prod}", "Greige")
        Else
            strsql = Replace(strsql, "{prod}", "Production")
        End If

        If checkFecha.Checked = True Then

            strsql &= " AND (HDoc_Doc_Fec BETWEEN '{fechainicio}' AND '{fechafin}') "

            strsql = Replace(strsql, "{fechainicio}", dtpInicio.Value.ToString(FORMATO_MYSQL))
            strsql = Replace(strsql, "{fechafin}", dtpFin.Value.ToString(FORMATO_MYSQL))

        End If
        strsql &= "  GROUP BY h.HDoc_Sis_Emp, h.HDoc_Doc_Cat, h.HDoc_Doc_Num, h.HDoc_Doc_Ano"
        strsql &= "     ORDER BY HDoc_Doc_Ano DESC, HDoc_Doc_Num DESC"
        strsql = Replace(strsql, "{empresa}", Sesion.IdEmpresa)
        Return strsql

    End Function

    'Query que carga Lista Detalle
    Private Function SQLDetalle() As String
        Dim strsql As String = STR_VACIO

        strsql = " SELECT DDoc_Prd_Ref MKT, DDoc_Doc_Cat, DDoc_Doc_Ano, DDoc_Doc_Num, DDoc_Doc_Lin, DDoc_Prd_Cod, DDoc_Prd_Des, DDoc_Prd_UM, IFNULL(m.cat_clave,0) UM, DDoc_Prd_DSP, DDoc_Prd_DSQ, DDoc_Prd_Net,DDoc_Prd_QTY, DDoc_RF1_Num, DDoc_RF1_Cod, IFNULL(DDoc_RF1_Txt,'')DDoc_RF1_Txt, DDoc_RF1_Dbl, IFNULL(DDoc_RF2_Num,0) DDoc_RF2_Num, DDoc_RF2_Cod,DDoc_RF2_Txt, DDoc_Prd_PNr, DDoc_RF3_Txt, IFNULL(SUM(BDoc_Box_QTY),0) cantidad, (DDoc_Prd_NET * DDoc_Prd_Qty) Lin_Subtotal, IFNULL(inv_notas,'') Notas, IFNULL(PDoc_Par_Cat,0) PDoc_Par_Cat, IFNULL(PDoc_Par_Ano,0) PDoc_Par_Ano, IFNULL(PDoc_Par_Num,0) PDoc_Par_Num, IFNULL(PDoc_Par_Lin,0) PDoc_Par_Lin, IFNULL(PDoc_Sis_Emp,0) PDoc_Sis_Emp, IFNULL(( "
        strsql &= "  SELECT SUM(cantidad)"
        strsql &= "   FROM Reserva"
        strsql &= "     WHERE id_empresa=DDoc_Sis_Emp AND doc_tipo=DDoc_Doc_Cat AND doc_ciclo=DDoc_Doc_Ano AND doc_num=DDoc_Doc_Num AND doc_lin=DDoc_Doc_Lin AND NOT(estado=2)),0) Reservado {marca} , ifnull(DDoc_RF2_Num,0) idStatus , 
                           /*IF(IFNULL(DDoc_RF2_Num,0)=0,'GOOD',if(DDoc_RF2_NUM=1,'CLEARENCE','BAD')) EstadoH,*/ IFNULL(ca.cat_desc,'') EstadoH,
                           (SELECT COUNT(*)
                            FROM Dcmtos_DTL_Box b
                                WHERE b.BDoc_Sis_Emp = DDoc_Sis_Emp AND b.BDoc_Doc_Cat = DDoc_Doc_Cat AND b.BDoc_Doc_Ano = DDoc_Doc_Ano AND b.BDoc_Doc_Num = DDoc_Doc_Num AND b.BDoc_Doc_Lin = DDoc_Doc_Lin) QtyBultos 
                            , IFNULL(Dcmtos_DTL_Box.BDoc_Box_Gin,'') Gin, IFNULL(Dcmtos_DTL_Box.BDoc_Box_GBac,'') GBac, IFNULL(Dcmtos_DTL_Box.BDoc_Box_Crp,'') Crp"
        strsql &= "         FROM Dcmtos_DTL"
        strsql &= "             LEFT JOIN Catalogos m ON m.cat_num = DDoc_Prd_UM AND m.cat_clase = 'Medidas'"
        strsql &= "             LEFT JOIN Catalogos ca ON ca.cat_num = DDoc_RF2_Num AND ca.cat_clase = 'StatusIngBdg'"
        strsql &= "             LEFT JOIN Inventarios ON inv_sisemp = {empresa} AND inv_numero = DDoc_Prd_Cod"
        strsql &= "             LEFT JOIN Dcmtos_DTL_Box ON BDoc_Sis_Emp = DDoc_Sis_Emp AND BDoc_Doc_Cat = DDoc_Doc_Cat AND BDoc_Doc_Ano = DDoc_Doc_Ano AND BDoc_Doc_Num = DDoc_Doc_Num AND BDoc_Doc_Lin = DDoc_Doc_Lin"
        strsql &= "             LEFT JOIN Dcmtos_DTL_Pro  ON PDoc_Sis_Emp = DDoc_Sis_Emp AND PDoc_Chi_Cat = DDoc_Doc_Cat AND PDoc_Chi_Ano = DDoc_Doc_Ano AND PDoc_Chi_Num = DDoc_Doc_Num AND PDoc_Chi_Lin = DDoc_Doc_Lin"
        strsql &= "         WHERE DDoc_Sis_Emp = {empresa} AND DDoc_Doc_Cat = 47 AND DDoc_Doc_Ano = {anio} AND DDoc_Doc_Num = {numero}"
        strsql &= "     GROUP BY DDoc_Sis_Emp, DDoc_Doc_Cat, DDoc_Doc_Ano, DDoc_Doc_Num, DDoc_Doc_Lin"
        strsql &= "  ORDER BY DDoc_Doc_Lin"

        strsql = Replace(strsql, "{empresa}", Sesion.IdEmpresa)
        strsql = Replace(strsql, "{anio}", Val(celdaAnio.Text))
        strsql = Replace(strsql, "{numero}", Val(celdaNumero.Text))
        'Este replace sirve mas que todo para HSM para que les jale la marca de la fibra
        strsql = Replace(strsql, "{marca}", ", IFNULL(inv_prodlote,'') marca ")

        Return strsql
    End Function

    'Procedimiento para Cargar dgLista Panel Principal
    Public Sub queryListaPrincipal()
        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader
        Dim strSQL As String = STR_VACIO
        Dim e As Integer
        Dim c As String
        Dim r As Integer
        Dim ch As Integer

        strSQL = SQLlista()

        Try

            MyCnn.CONECTAR = strConexion

            COM = New MySqlCommand(strSQL, CON)
            REA = COM.ExecuteReader
            dgLista.Rows.Clear()
            If REA.HasRows Then

                dgLista.Rows.Clear()

                Do While REA.Read
                    Dim strFila As String = STR_VACIO

                    strFila = REA.GetInt32("Numero") & "|" & REA.GetDateTime("Fecha") & "|" & REA.GetString("Nombre") & "|" & REA.GetString("Clase") & "|" & REA.GetString("Referencia") & "|" & REA.GetString("Bodega") & "|" &
                              REA.GetInt32("Anio") & "|" & REA.GetString("Direccion") & "|" & REA.GetDouble("Tasa") & "|" & REA.GetInt32("IDMoneda") & "|" & REA.GetString("SimMoneda") & "|" & REA.GetString("Correlativo") & "|" & REA.GetInt32("Revisado")

                    c = REA.GetString("Correlativo")
                    r = REA.GetInt32("Revisado")
                    e = REA.GetInt32("Cajas")
                    AgregarFila(dgLista, strFila, c, r, e)

                Loop

            End If

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try

    End Sub

    Private Function queryDetalleProduccion() As String
        Dim strSQL As String = STR_VACIO

        strSQL = "SELECT IFNULL(d.DDoc_RF3_Txt,'') ramplas ,IFNULL(d.DDoc_RF1_Txt,'') comentario, d.DDoc_Prd_Ref MKT, h.HDoc_Sis_Emp empresa, h.HDoc_Doc_Cat catalogo, h.HDoc_Doc_Ano anio, h.HDoc_Doc_Num numero, h.HDoc_Usuario usuario, d.DDoc_Doc_Lin linea, d.DDoc_Prd_Cod codigo, d.DDoc_Prd_Des descPO, a.art_DCorta descripcion, d.DDoc_Prd_UM IDMedida, d.DDoc_Prd_PUQ, d.DDoc_Prd_NET precio, d.DDoc_Prd_QTY cantidadProcesar, d.DDoc_RF4_Dbl cantidadEnEspera, d.DDoc_RF1_Cod referencia, d.DDoc_RF1_Dbl Cantidad, c.cat_Clave medida, 
                	(SELECT SUM(bb.BDoc_Box_QTY) FROM Dcmtos_DTL_Box bb where bb.BDoc_Sis_Emp = d.DDoc_Sis_Emp AND bb.BDoc_Doc_Cat = d.DDoc_Doc_Cat AND bb.BDoc_Doc_Ano = d.DDoc_Doc_Ano AND bb.BDoc_Doc_Num = d.DDoc_Doc_Num AND bb.BDoc_Doc_Lin = d.DDoc_Doc_Lin ) bultos,  d.DDoc_RF1_Cod Cod,d.DDoc_RF2_Cod,IFNULL(d.DDoc_RF2_Num,0) idStatus,IF(IFNULL(d.DDoc_RF2_Num,0)=0,'GOOD',if(d.DDoc_RF2_NUM=1,'CLEARENCE','BAD')) EstadoH,d.DDoc_Sis_Emp Empresa,"
        strSQL &= "IFNULL(p.PDoc_Par_Num,0)  ParNum, IFNULL(p.PDoc_Par_Ano,0) ParAno, IFNULL(d.DDoc_Doc_Lin,0) ParLin, d.DDoc_Prd_PNr"
        strSQL &= "     FROM Dcmtos_DTL d"
        strSQL &= "      LEFT JOIN Dcmtos_DTL_Pro p ON p.PDoc_Sis_Emp = d.DDoc_Sis_Emp AND p.PDoc_Chi_Cat=d.DDoc_Doc_Cat AND p.PDoc_Chi_Num=d.DDoc_Doc_Num AND p.PDoc_Chi_Ano=d.DDoc_Doc_Ano AND p.PDoc_Chi_Lin=d.DDoc_Doc_Lin "
        strSQL &= "          INNER JOIN Dcmtos_HDR h ON h.HDoc_Sis_Emp = d.DDoc_Sis_Emp AND h.HDoc_Doc_Cat = d.DDoc_Doc_Cat AND h.HDoc_Doc_Ano = d.DDoc_Doc_Ano AND h.HDoc_Doc_Num = d.DDoc_Doc_Num"
        strSQL &= "              INNER JOIN Catalogos c ON d.DDoc_Prd_UM = c.cat_num"
        'strSQL &= "                  INNER JOIN Dcmtos_DTL_Box b ON b.BDoc_Sis_Emp = d.DDoc_Sis_Emp AND b.BDoc_Doc_Cat = d.DDoc_Doc_Cat AND b.BDoc_Doc_Ano = d.DDoc_Doc_Ano AND b.BDoc_Doc_Num = d.DDoc_Doc_Num AND b.BDoc_Doc_Lin = d.DDoc_Doc_Lin"
        strSQL &= " LEFT JOIN Inventarios i ON i.inv_numero= d.DDoc_Prd_Cod LEFT JOIN Articulos a ON  a.art_codigo=i.inv_artcodigo AND i.inv_sisemp  =a.art_sisemp "
        strSQL &= "      WHERE d.DDoc_Sis_Emp = {empresa} AND d.DDoc_Doc_Cat = 47 AND d.DDoc_Doc_Ano = {anio} AND d.DDoc_Doc_Num = {numero} GROUP BY DDoc_Doc_Lin"

        strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
        strSQL = Replace(strSQL, "{anio}", celdaAnio.Text)
        strSQL = Replace(strSQL, "{numero}", celdaNumero.Text)

        Return strSQL
    End Function

    'Procedimiento para CargardgDetalle 
    Public Sub queryDetalle()
        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader
        Dim strSQL As String = STR_VACIO
        Dim r As Double

        strSQL = SQLDetalle()
        Try

            MyCnn.CONECTAR = strConexion

            COM = New MySqlCommand(strSQL, CON)
            REA = COM.ExecuteReader

            If REA.HasRows Then

                dgDetalle.Rows.Clear()
                Do While REA.Read
                    Dim strFila As String = STR_VACIO


                    strFila = REA.GetInt32("DDoc_Prd_Cod") & "|"
                    strFila &= REA.GetString("DDoc_Prd_Des") & "|"
                    strFila &= REA.GetInt32("DDoc_Prd_UM") & "|"
                    strFila &= REA.GetString("UM") & "|"
                    strFila &= REA.GetDouble("DDoc_Prd_NET") & "|"
                    strFila &= REA.GetDouble("DDoc_Prd_DSQ") & "|"
                    strFila &= REA.GetDouble("DDoc_Prd_DSP") & "|"
                    strFila &= REA.GetDouble("DDoc_Prd_QTY") & "|"
                    strFila &= REA.GetInt32("cantidad") & "|"
                    strFila &= REA.GetDouble("Lin_SubTotal").ToString(FORMATO_MONEDA) & "|"
                    strFila &= REA.GetString("DDoc_RF2_Cod") & "|"
                    strFila &= REA.GetString("MKT") & "|"
                    'If Not REA.GetString("DDoc_RF3_Txt") = vbNullString Then
                    'strFila &= REA.GetString("DDoc_RF3_Txt") & "|"
                    'Else
                    strFila &= REA.GetString("DDoc_RF1_Txt") & "|"
                    'End If

                    strFila &= REA.GetString("DDoc_RF2_Txt") & "|"
                    strFila &= REA.GetString("DDoc_RF1_Txt") & "|"
                    'Cantidad original
                    If REA.GetDouble("DDoc_RF1_Dbl") = vbEmpty Then
                        strFila &= REA.GetDouble("DDoc_Prd_QTY") & "|"
                    Else
                        strFila &= REA.GetDouble("DDoc_RF1_Dbl") & "|"
                    End If
                    'Si está vacío se copia el original
                    If REA.GetString("DDoc_RF1_Cod") = vbNullString Then
                        strFila &= REA.GetString("DDoc_Prd_Cod") & "|"
                    Else
                        strFila &= REA.GetString("DDoc_RF1_Cod") & "|"
                    End If
                    strFila &= REA.GetInt32("DDoc_RF2_Num") & "|"
                    strFila &= REA.GetString("DDoc_RF2_Cod") & "|"
                    strFila &= REA.GetInt32("DDoc_Doc_Lin") & "|"
                    strFila &= REA.GetString("DDoc_Prd_PNr") & "|"
                    strFila &= REA.GetString("Notas") & "|"
                    strFila &= REA.GetInt32("DDoc_RF1_Num") & "|"
                    If (REA.GetDouble("DDoc_Prd_QTY") - REA.GetDouble("Reservado")) = 0 Then
                        strFila &= REA.GetDouble("DDoc_Prd_QTY") & "|"
                    Else
                        strFila &= (REA.GetDouble("DDoc_Prd_QTY") - REA.GetDouble("Reservado")) & "|"
                    End If

                    strFila &= 0 & "|"
                    strFila &= REA.GetInt32("PDoc_Sis_Emp") & "|"
                    strFila &= REA.GetInt32("PDoc_Par_Ano") & "|"
                    strFila &= REA.GetInt32("PDoc_Par_Num") & "|"
                    strFila &= REA.GetInt32("PDoc_Par_Lin") & "|"
                    strFila &= REA.GetString("marca") & "|"
                    strFila &= REA.GetInt32("idStatus") & "|"
                    strFila &= REA.GetString("EstadoH") & "|"
                    strFila &= STR_VACIO & "|"
                    strFila &= STR_VACIO & "|"
                    strFila &= REA.GetString("MKT") & "|"
                    strFila &= REA.GetString("DDoc_RF3_Txt") & "|"
                    strFila &= REA.GetString("Gin") & "|"
                    strFila &= REA.GetString("GBac") & "|"
                    strFila &= REA.GetString("Crp")
                    r = REA.GetDouble("Reservado")

                    AgregarFilaDetalle(dgDetalle, strFila, r, REA.GetInt32("QtyBultos"))
                Loop
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try

    End Sub

    'Procedimiento para CargardgDetalle 
    Public Sub CargarDetalleProduccion()
        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader
        Dim strSQL As String = STR_VACIO
        Dim r As Double

        strSQL = queryDetalleProduccion()
        Try

            MyCnn.CONECTAR = strConexion

            COM = New MySqlCommand(strSQL, CON)
            REA = COM.ExecuteReader

            If REA.HasRows Then

                dgDetalle.Rows.Clear()
                Do While REA.Read
                    Dim strFila As String = STR_VACIO

                    strFila = REA.GetInt32("codigo") & "|"
                    strFila &= REA.GetString("descripcion") & "|"
                    strFila &= REA.GetInt32("IDMedida") & "|"
                    strFila &= REA.GetString("medida") & "|"
                    strFila &= REA.GetDouble("precio") & "|"
                    strFila &= 0 & "|"
                    strFila &= 0 & "|"
                    If REA.GetDouble("cantidadProcesar") = 0 Then
                        strFila &= REA.GetDouble("cantidadEnEspera") & "|"
                        strFila &= REA.GetInt32("bultos") & "|"
                        strFila &= REA.GetDouble("cantidadEnEspera") * REA.GetDouble("Precio") & "|"
                    Else
                        strFila &= REA.GetDouble("cantidadProcesar") & "|"
                        strFila &= REA.GetInt32("bultos") & "|"
                        strFila &= REA.GetDouble("cantidadProcesar") * REA.GetDouble("Precio") & "|"
                    End If
                    strFila &= REA.GetString("DDoc_RF2_Cod") & "|"
                    strFila &= REA.GetString("MKT") & "|"
                    'If Not REA.GetString("DDoc_RF3_Txt") = vbNullString Then
                    '    strFila &= vbNullString & "|"
                    'Else
                    strFila &= REA.GetString("comentario") & "|" ' Comentario o reserva
                    'End If

                    strFila &= vbNullString & "|"
                    strFila &= REA.GetString("comentario") & "|"
                    'Cantidad original
                    'If REA.GetDouble("DDoc_RF1_Dbl") = vbEmpty Then
                    If REA.GetDouble("cantidadProcesar") = 0 Then
                        strFila &= REA.GetDouble("cantidadEnEspera") & "|"
                    Else
                        strFila &= REA.GetDouble("cantidadProcesar") & "|"
                    End If

                    'Else
                    'strFila &= REA.GetDouble("Cantidad") & "|"
                    'End If
                    'Si está vacío se copia el original
                    'If REA.GetString("DDoc_RF1_Cod") = vbNullString Then
                    '    strFila &= REA.GetString("DDoc_Prd_Cod") & "|"
                    'Else
                    strFila &= REA.GetString("Cod") & "|"
                    'End If
                    strFila &= 0 & "|"
                    strFila &= REA.GetString("DDoc_RF2_Cod") & "|"
                    strFila &= REA.GetInt32("linea") & "|"

                    If intTipo = 4 Then                                        '''''''columna de referencia de Desperdicio Waste Ref
                        strFila &= REA.GetString("DDoc_Prd_PNr") & "|"
                    Else
                        strFila &= vbNullString & "|"
                    End If

                    strFila &= vbNullString & "|"
                    strFila &= 0 & "|"
                    'If (REA.GetDouble("DDoc_Prd_QTY") - REA.GetDouble("Reservado")) = 0 Then
                    '    strFila &= REA.GetDouble("DDoc_Prd_QTY") & "|"
                    'Else
                    strFila &= 0 & "|"
                    'End If

                    strFila &= 0 & "|"
                    strFila &= REA.GetInt32("Empresa") & "|"
                    strFila &= REA.GetInt32("ParAno") & "|"
                    strFila &= REA.GetInt32("ParNum") & "|"
                    strFila &= REA.GetInt32("ParLin") & "|"

                    strFila &= "" & "|"
                    strFila &= REA.GetInt32("idStatus") & "|"
                    strFila &= REA.GetString("EstadoH") & "|"
                    strFila &= INT_CERO & "|" ' MO y GF
                    strFila &= INT_CERO & "|" ' Tipo Cambio
                    strFila &= STR_VACIO & "|" 'Ref MKT
                    strFila &= REA.GetString("ramplas") ' ref pallet
                    'r = REA.GetDouble("Reservado")

                    AgregarFilaDetalle(dgDetalle, strFila, r)
                Loop
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try

    End Sub

    Private Sub AgregarFilaDetalle(ByRef Lista As DataGridView, ByVal strFila As String, ByVal reservado As Double, Optional QtyB As Integer = 0)

        Dim Celda As New DataGridViewTextBoxCell
        Dim Fila As New DataGridViewRow
        Dim strSQL As String = STR_VACIO
        Dim arrayFila() As String
        Dim i As Integer
        Try
            Lista.BackgroundColor = Color.White
            arrayFila = strFila.Split("|".ToCharArray)
            For i = 0 To arrayFila.Length - 1
                Celda = New DataGridViewTextBoxCell
                Celda.Value = arrayFila(i)

                If Sesion.IdEmpresa = 15 Or Sesion.IdEmpresa = 18 Or Sesion.IdEmpresa = 19 Or (Sesion.IdEmpresa = 20) Then
                    If QtyB = 1 Then
                        If i = 8 Then
                            Celda.Style.BackColor = Color.YellowGreen
                            Celda.Style.SelectionBackColor = Color.YellowGreen
                            'Celda.Style.ForeColor = Color.Black
                        End If
                    End If
                End If

                If reservado > 0 Then
                    If i = 11 Then
                        Celda.Style.BackColor = Color.Yellow
                        'Else
                        '    Celda.Style.BackColor = Color.White
                    End If
                End If
                Fila.Cells.Add(Celda)
            Next

            Lista.Rows.Add(Fila)
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try

    End Sub

    Private Sub AgregarFila(ByRef Lista As DataGridView, ByVal strFila As String, ByVal correlativo As String, ByVal Revisado As Integer, Optional Cajas As Integer = NO_FILA)

        Dim Celda As New DataGridViewTextBoxCell
        Dim Fila As New DataGridViewRow
        Dim strSQL As String = STR_VACIO
        Dim arrayFila() As String
        Dim i As Integer
        Try
            Lista.BackgroundColor = Color.White
            arrayFila = strFila.Split("|".ToCharArray)
            For i = 0 To arrayFila.Length - 1
                Celda = New DataGridViewTextBoxCell
                Celda.Value = arrayFila(i)

                If correlativo = vbNullString Then
                    If i = 0 Then
                        Celda.Style.BackColor = Color.Yellow
                        'Else
                        '    Celda.Style.BackColor = Color.White
                    End If
                End If
                If Revisado = vbEmpty Then
                    If i = 1 Then
                        Celda.Style.BackColor = Color.Orchid
                    End If
                Else
                    If i = 1 Then
                        Celda.Style.BackColor = Color.YellowGreen
                    End If
                End If
                If (Sesion.IdEmpresa = 18) Or (Sesion.IdEmpresa = 15) Or (Sesion.IdEmpresa = 19) Or (Sesion.IdEmpresa = 20) Then
                    If Cajas > 0 Then
                        If i = 4 Then
                            Celda.Style.BackColor = Color.LightBlue
                        End If
                    End If

                End If
                Fila.Cells.Add(Celda)
            Next

            Lista.Rows.Add(Fila)
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try

    End Sub

    Private Sub Seleccionar(ByVal intanio As Integer, ByVal intnumero As Integer)
        SeleccionarCliente(intanio, intnumero)
        'SeleccionarSubdocumentos(año, numero)

    End Sub

    Private Sub SeleccionarCliente(ByVal intanio As Integer, ByVal intnumero As Integer)
        Dim HDR As New clsDcmtos_HDR
        Dim CA As New clsCatalogos
        Dim COM As MySqlCommand
        Dim conec As MySqlConnection
        Dim strCampos As String = STR_VACIO
        Dim strCondicion As String = STR_VACIO
        Dim strSQL As String = STR_VACIO
        Dim intRevisado As Integer

        strCampos = " HDoc_RF1_Dbl, HDoc_DR2_Cat, HDoc_Doc_Ano, HDoc_Doc_Num, HDoc_Doc_Fec, HDoc_Emp_Cod, HDoc_Emp_Nom, HDoc_Emp_Dir, HDoc_Doc_TC, HDoc_Usuario,HDoc_Doc_Mon, HDoc_DR1_Cat, HDoc_DR1_Num, HDoc_RF1_Cod, HDoc_DR2_Num, HDoc_RF2_Txt, HDoc_DR1_Num, HDoc_Pro_DCat, HDoc_Ant_Com "
        strCondicion = " HDoc_Sis_Emp = {empresa} AND HDoc_Doc_Cat = 47 AND HDoc_Doc_Ano = {anio} AND HDoc_Doc_Num = {numero}"
        strCondicion = Replace(strCondicion, "{empresa}", Sesion.IdEmpresa)
        strCondicion = Replace(strCondicion, "{anio}", intanio)
        strCondicion = Replace(strCondicion, "{numero}", intnumero)
        'If Sesion.IdEmpresa = 22 Then
        '    etiquetaRef2.Text = "Fabric Form"
        'End If
        Try
            HDR.CONEXION = strConexion
            If HDR.Seleccionar(strCondicion, strCampos) Then
                celdaAnio.Text = HDR.HDOC_DOC_ANO
                celdaNumero.Text = HDR.HDOC_DOC_NUM
                dtpFech.Text = HDR.HDOC_DOC_FEC
                celdaIDCliente.Text = HDR.HDOC_EMP_COD
                celdaCliente.Text = HDR.HDOC_EMP_NOM
                celdaDireccion.Text = HDR.HDOC_EMP_DIR
                celdaTasa.Text = HDR.HDOC_DOC_TC
                celdaEmpresa.Text = Sesion.IdEmpresa
                celdaCatalogo.Text = 47
                celdaUsuario.Text = HDR.HDOC_USUARIO
                celdaRefFactura.Text = HDR.HDOC_DR1_NUM
                celdaRef1.Text = HDR.HDOC_DR2_NUM
                celdaRef2.Text = HDR.HDOC_RF2_TXT

                celdaTasa.Text = HDR.HDOC_DOC_TC
                celdaTipoIngreso.Text = HDR.HDOC_ANT_COM

                If HDR.HDOC_DOC_MON = 178 Then
                    celdaMoneda.Text = "US$"
                    celdaIDMoneda.Text = HDR.HDOC_DOC_MON
                ElseIf HDR.HDOC_DOC_MON = 177 Then
                    celdaMoneda.Text = "Q/"
                    celdaIDMoneda.Text = HDR.HDOC_DOC_MON
                ElseIf HDR.HDOC_DOC_MON = 182 Then
                    If (Sesion.IdEmpresa = 18) Or (Sesion.IdEmpresa = 19) Or (Sesion.IdEmpresa = 21) Then
                        celdaMoneda.Text = "C$"
                        celdaIDMoneda.Text = HDR.HDOC_DOC_MON
                    Else
                        celdaMoneda.Text = "LPS"
                        celdaIDMoneda.Text = HDR.HDOC_DOC_MON
                    End If
                End If
                '0/Póliza, 1/Devolución
                intTipo = HDR.HDOC_DR1_CAT
                If Sesion.idGiro = 2 And intTipo = 6 Then
                    CheckIngreso.Visible = True
                Else
                    CheckIngreso.Visible = False
                End If
                'Ingreso de producto terminado, de otra planta, procesado en una y terminado en otra
                If HDR.HDOC_DR2_CAT = 1 Then
                    CheckIngreso.Checked = True
                    CheckIngreso.Enabled = False
                Else
                    CheckIngreso.Checked = False
                    CheckIngreso.Enabled = True
                End If
                If intTipo = 0 Then
                    If HDR.HDOC_RF1_DBL = 1 Then
                        checkTendido.Checked = True
                        checkTendido.Enabled = False
                    Else
                        checkTendido.Checked = False
                        checkTendido.Enabled = False
                    End If
                    celdaRefFactura.ReadOnly = True
                    celdaRef1.ReadOnly = True
                    celdaRef2.ReadOnly = True
                ElseIf intTipo = 1 Then
                    celdaRefFactura.ReadOnly = False
                    celdaRef1.ReadOnly = False
                    celdaRef2.ReadOnly = False
                End If

                'Verifica estado de la poliza
                strSQL = "SELECT revisado"
                strSQL &= "  FROM " & Sesion.BaseConta & ".polizas"
                strSQL &= "          WHERE empresa = {empresa} AND ref_tipo = 47 AND ref_ciclo = {ciclo} AND ref_numero = {numero} "

                strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
                strSQL = Replace(strSQL, "{ciclo}", celdaAnio.Text)
                strSQL = Replace(strSQL, "{numero}", celdaNumero.Text)
                conec = New MySqlConnection(strConexion)
                conec.Open()
                COM = New MySqlCommand(strSQL, conec)
                intRevisado = COM.ExecuteScalar
                conec.Close()
                conec.Dispose()
                conec = Nothing
                System.GC.Collect()

                checkRevisado.Checked = IIf(intRevisado = vbEmpty, checkRevisado.Checked = False, checkRevisado.Checked = True)

                If HDR.HDOC_PRO_DCAT = 1 Then
                    botonDespachos.BackColor = Color.YellowGreen
                Else
                    botonDespachos.BackColor = Color.LightGray

                End If
                celdaRevisado.Text = HDR.HDOC_PRO_DCAT
                PintarTipoIngreso()
            End If

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Function sqlDocumentosProcesados() As String
        Dim strSQL As String = STR_VACIO

        strSQL = "SELECT DISTINCT HDoc_Doc_Cat, HDoc_Doc_Ano, HDoc_Doc_Num, HDoc_Doc_Fec, HDoc_Usuario, HDoc_DR1_Num"
        strSQL &= "      FROM Dcmtos_DTL_Pro a"
        strSQL &= "          INNER JOIN Dcmtos_HDR b ON a.PDoc_Sis_Emp = b.HDoc_Sis_Emp AND a.PDoc_Par_Cat = b.HDoc_Doc_Cat AND a.PDoc_Par_Ano = b.HDoc_Doc_Ano AND a.PDoc_Par_Num = b.HDoc_Doc_Num"
        strSQL &= "              WHERE a.PDoc_Sis_Emp = {empresa} AND a.PDoc_Chi_Cat = 47 AND a.PDoc_Par_Cat = 180 AND a.PDoc_Chi_Ano = {anio} AND a.PDoc_Chi_Num = {numero}"

        strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
        strSQL = Replace(strSQL, "{anio}", celdaAnio.Text)
        strSQL = Replace(strSQL, "{numero}", celdaNumero.Text)

        Return strSQL
    End Function

    'Query que carga Lista de Facturas
    Private Function SQLCargarCajas() As String

        Dim strsql As String = STR_VACIO
        strsql = " SELECT b.BDoc_Sis_Emp Empresa, b.BDoc_Doc_Cat Catalogo, b.BDoc_Doc_Ano Anio, b.BDoc_Doc_Num Numero, b.BDoc_Doc_Lin Linea, b.BDoc_Box_Lin LineaBox, IFNULL(b.BDoc_Box_Cod,'') Color_Cono, 
                b.BDoc_Box_Ord NumeroCaja, b.BDoc_Box_QTY Paquetes, b.BDoc_Box_LB PesoNeto, IFNULL(b.BDoc_Box_Ctg,'') Turno, b.BDoc_Box_LBExt PesoBruto, ((b.BDoc_Box_LBExt)-(b.BDoc_Box_LB )) Tara, b.BDoc_Box_Hsm Conos, 
                IFNULL(b.BDoc_Box_Gin,'') Gin, IFNULL(b.BDoc_Box_GBac,'') GinBac, IFNULL(b.BDoc_Box_Crp,'') Crp, IFNULL(b.BDoc_Box_Ref,'') Ref_KI"
        strsql &= "     FROM Dcmtos_DTL_Box b"
        strsql &= "         WHERE b.BDoc_Sis_Emp = {empresa} AND b.BDoc_Doc_Cat = 47 AND b.BDoc_Doc_Ano = {anio} AND b.BDoc_Doc_Num = {numero}"

        strsql = Replace(strsql, "{empresa}", Sesion.IdEmpresa)
        strsql = Replace(strsql, "{anio}", Val(celdaAnio.Text))
        strsql = Replace(strsql, "{numero}", Val(celdaNumero.Text))

        Return strsql
    End Function

    'Procedimiento para Cargar dgOculto PackingList
    Public Sub queryCargarCajas()
        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader
        Dim strSQL As String = STR_VACIO
        Dim strSQL2 As String = STR_VACIO
        Dim conec As MySqlConnection
        Dim COM2 As MySqlCommand
        Dim REA2 As MySqlDataReader
        Dim i As Integer = INT_CERO

        strSQL = SQLCargarCajas()

        Try

            MyCnn.CONECTAR = strConexion

            COM = New MySqlCommand(strSQL, CON)
            REA = COM.ExecuteReader

            If REA.HasRows Then

                dgOculto.Rows.Clear()
                Do While REA.Read
                    Dim strFila As String = STR_VACIO
                    i = i + 1
                    strFila = REA.GetInt32("Empresa") & "|"
                    strFila &= REA.GetInt32("Catalogo") & "|"
                    strFila &= REA.GetInt32("Anio") & "|"
                    strFila &= REA.GetInt32("Numero") & "|"
                    strFila &= REA.GetInt32("Linea") & "|"
                    strFila &= i & "|"
                    strFila &= REA.GetString("Color_Cono") & "|"
                    strFila &= REA.GetString("Conos") & "|"
                    strFila &= REA.GetString("Turno") & "|"
                    strFila &= REA.GetDouble("PesoBruto").ToString(FORMATO_MONEDA) & "|"
                    strFila &= REA.GetDouble("PesoNeto").ToString(FORMATO_MONEDA) & "|"
                    strFila &= REA.GetDouble("NumeroCaja") & "|"
                    strFila &= REA.GetDouble("Tara") & "|"
                    strFila &= 1 & "|"
                    strFila &= REA.GetString("Gin") & "|"
                    strFila &= REA.GetString("GinBac") & "|"
                    strFila &= REA.GetString("Crp") & "|"
                    strFila &= REA.GetString("Ref_KI")

                    cFunciones.AgregarFila(dgOculto, strFila)
                Loop
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try

    End Sub

    'Agrega a la lista los despachos hechos para este documento
    Private Sub CargarDescargos()
        Dim strSQL As String = STR_VACIO
        Dim strTemp As String = STR_VACIO
        Dim intLinea As Integer
        Dim dblCantidad As Double
        Dim dblSaldo As Double
        Dim i As Integer
        Dim f As Integer
        Dim REA As MySqlDataReader
        Dim COM As MySqlCommand


        strSQL = "SELECT d.PDoc_Par_Lin, d.PDoc_Chi_Ano, d.PDoc_Chi_Num, d.PDoc_Chi_Lin, d.PDoc_QTY_Pro, CAST(CONCAT(p.PDoc_Par_Ano,' / ',p.PDoc_Par_Num) AS CHAR) Pedido, ei.HDoc_Doc_Status IEstado, IFNULL(ef.HDoc_Doc_Status,-1) FEstado"
        strSQL &= "   FROM Dcmtos_DTL_Pro d"
        strSQL &= "          LEFT JOIN Dcmtos_HDR ei ON ei.HDoc_Sis_Emp=d.PDoc_Sis_Emp AND ei.HDoc_Doc_Cat=d.PDoc_Chi_Cat AND ei.HDoc_Doc_Ano=d.PDoc_Chi_Ano AND ei.HDoc_Doc_Num=d.PDoc_Chi_Num"
        strSQL &= "               LEFT JOIN Dcmtos_DTL_Pro rf ON rf.PDoc_Sis_Emp=d.PDoc_Sis_Emp AND rf.PDoc_Par_Cat=d.PDoc_Chi_Cat AND rf.PDoc_Par_Ano=d.PDoc_Chi_Ano AND rf.PDoc_Par_Num=d.PDoc_Chi_Num AND rf.PDoc_Par_Lin=d.PDoc_Chi_Lin  AND rf.PDoc_Chi_Cat=36"
        strSQL &= "                     LEFT JOIN Dcmtos_HDR ef ON ef.HDoc_Sis_Emp=rf.PDoc_Sis_Emp AND ef.HDoc_Doc_Cat=rf.PDoc_Chi_Cat AND ef.HDoc_Doc_Ano=rf.PDoc_Chi_Ano AND ef.HDoc_Doc_Num=rf.PDoc_Chi_Num"
        strSQL &= "                 LEFT JOIN Dcmtos_DTL_Pro p ON p.PDoc_Sis_Emp=d.PDoc_Sis_Emp AND p.PDoc_Chi_Cat=d.PDoc_Chi_Cat AND p.PDoc_Chi_Ano=d.PDoc_Chi_Ano AND p.PDoc_Chi_Num=d.PDoc_Chi_Num AND p.PDoc_Chi_Lin=d.PDoc_Chi_Lin AND p.PDoc_Par_Cat=75"
        strSQL &= "            WHERE d.PDoc_Sis_Emp={empresa} AND d.PDoc_Par_Cat=47 AND d.PDoc_Par_Ano={anio} AND d.PDoc_Par_Num={numero} AND d.PDoc_Chi_Cat=48"
        strSQL &= "      ORDER BY d.PDoc_Par_Lin, d.PDoc_Chi_Num, d.PDoc_Chi_Lin"

        strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
        strSQL = Replace(strSQL, "{anio}", celdaAnio.Text)
        strSQL = Replace(strSQL, "{numero}", celdaNumero.Text)

        Try
            intLinea = NO_FILA
            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSQL, CON)
            REA = COM.ExecuteReader
            If REA.HasRows Then
                Do While REA.Read

                    If Not (REA.GetInt32("PDoc_Par_Lin") = intLinea) Then
                        'obtiene los datos de la linea del pedido
                        intLinea = REA.GetInt32("PDoc_Par_Lin")
                        intLinea = (intLinea - 1)
                        dblCantidad = dgDetalle.Rows(intLinea).Cells("colCantidad").Value
                        dblSaldo = dblCantidad
                    End If

                    'Calcula el saldo
                    dblSaldo = (dblSaldo - REA.GetDouble("PDoc_QTY_Pro"))

                    strTemp = REA.GetInt32("PDoc_Par_Lin") & "|"
                    strTemp &= REA.GetInt32("PDoc_Chi_Ano") & "|"
                    strTemp &= REA.GetInt32("PDoc_Chi_Num") & "|"
                    strTemp &= REA.GetDouble("PDoc_QTY_Pro") & "|"
                    strTemp &= dblSaldo.ToString(FORMATO_MONEDA) & "|"
                    strTemp &= REA.GetString("Pedido") & "|"
                    strTemp &= REA.GetInt32("PDoc_Chi_Lin") & "|"
                    strTemp &= REA.GetInt32("IEstado") & "|"
                    strTemp &= REA.GetInt32("FEstado")


                    i = REA.GetInt32("IEstado")
                    f = REA.GetInt32("FEstado")

                    AgregarFila2(dgDescargos, strTemp, i, f)
                Loop
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try

    End Sub

    Private Sub AgregarFila2(ByRef Lista As DataGridView, ByVal strFila As String, ByVal IEstado As Integer, ByVal FEstado As Integer)

        Dim Celda As New DataGridViewTextBoxCell
        Dim Fila As New DataGridViewRow
        Dim strSQL As String = STR_VACIO
        Dim arrayFila() As String
        Dim i As Integer
        Try
            Lista.BackgroundColor = Color.White
            arrayFila = strFila.Split("|".ToCharArray)
            For i = 0 To arrayFila.Length - 1
                Celda = New DataGridViewTextBoxCell
                Celda.Value = arrayFila(i)

                If FEstado = vbEmpty Then
                    If i = 2 Then
                        Celda.Style.BackColor = Color.Red
                        Celda.Style.ForeColor = Color.Yellow
                    ElseIf IEstado = vbEmpty Then
                        If i = 2 Then
                            Celda.Style.BackColor = Color.Red
                            Celda.Style.ForeColor = Color.White
                        End If
                    ElseIf FEstado = NO_FILA Then
                        If i = 2 Then
                            Celda.Style.BackColor = Color.Yellow
                            Celda.Style.ForeColor = Color.Red
                        End If
                    End If
                End If
                Fila.Cells.Add(Celda)
            Next

            Lista.Rows.Add(Fila)
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try

    End Sub

    Private Function SqlListarSubDatos() As String
        Dim strSQL As String = STR_VACIO

        strSQL = "SELECT cat_clave, cat_desc, IF(("
        strSQL &= "      SELECT COUNT(*)"
        strSQL &= "              FROM Dcmtos_ACC"
        strSQL &= "                   WHERE ADoc_Sis_Emp = {empresa}  AND ADoc_Doc_Cat = 47 AND ADoc_Doc_Ano = {anio} AND ADoc_Doc_Num = {numero} AND ADoc_Doc_Sub = cat_clave) >0,'SI','NO') AS cantidad"
        strSQL &= "              FROM Catalogos"
        strSQL &= "        WHERE cat_clase = 'SubDcmtos' AND cat_sist = 'Doc_B/Ing' AND (cat_sisemp IN (0,12))"
        strSQL &= "    ORDER BY cat_clave; "

        strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
        strSQL = Replace(strSQL, "{anio}", celdaAnio.Text)
        strSQL = Replace(strSQL, "{numero}", celdaNumero.Text)

        Return strSQL
    End Function

    'procedimiento que cargar SubDocumentos
    Public Sub SeleccionarSubdocumentos(ByVal intanio As Integer, ByVal intnumero As Integer)
        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader
        Dim strSQL As String = STR_VACIO

        strSQL = SqlListarSubDatos()

        Try

            MyCnn.CONECTAR = strConexion

            COM = New MySqlCommand(strSQL, CON)
            REA = COM.ExecuteReader

            If REA.HasRows Then

                dgSubdocumentos.Rows.Clear()

                Do While REA.Read
                    Dim strFila As String = STR_VACIO


                    strFila = REA.GetString("cat_clave") & "|"
                    strFila &= REA.GetString("cat_desc") & "|"
                    strFila &= REA.GetString("Cantidad")

                    cFunciones.AgregarFila(dgSubdocumentos, strFila)

                Loop

            End If

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try

    End Sub

    'Detalle de importaciones pendientes de ingreso
    Private Function SqlDetalleParaProcesar() As String
        Dim strSQL As String = STR_VACIO


        strSQL = "SELECT a.HDoc_Doc_TC tc, a.HDoc_Sis_Emp, a.HDoc_Doc_Cat, a.HDoc_Doc_Ano, a.HDoc_Doc_Num, HDoc_Usuario, b.DDoc_Doc_Lin, b.DDoc_Prd_Cod, b.DDoc_Prd_PNr, b.DDoc_Prd_NET, TRIM(CONCAT(art_DCorta,' ', IFNULL(p.cat_clave,''))) art_DCorta, b.DDoc_RF1_Num, ca.cat_num, f.cat_clave, inv_costo, d.inv_partnum, d.inv_UMcmpra UM, inv_generico, b.DDoc_Prd_PUQ, d.inv_UMfac, inv_notas Notas, SUM(b.DDoc_Prd_QTY) - COALESCE(("
        strSQL &= "      SELECT SUM(c.PDoc_QTY_Pro)"
        strSQL &= "           FROM Dcmtos_DTL_Pro c"
        strSQL &= "               WHERE c.PDoc_Sis_Emp = b.DDoc_Sis_Emp AND c.PDoc_Par_Cat = b.DDoc_Doc_Cat AND c.PDoc_Par_Ano = b.DDoc_Doc_Ano AND c.PDoc_Par_Num = b.DDoc_Doc_Num AND c.PDoc_Par_Lin = b.DDoc_Doc_Lin AND c.PDoc_Chi_Cat = 47), 0) Sum_QTY, cat.cat_num idEstado, cat.cat_desc Estado"
        strSQL &= "                   FROM Dcmtos_HDR a"
        strSQL &= "                       INNER JOIN Dcmtos_DTL b ON a.HDoc_Sis_Emp = b.DDoc_Sis_Emp AND a.HDoc_Doc_Cat = b.DDoc_Doc_Cat AND a.HDoc_Doc_Ano = b.DDoc_Doc_Ano AND a.HDoc_Doc_Num = b.DDoc_Doc_Num"
        strSQL &= "                           INNER JOIN Inventarios d ON b.DDoc_Prd_Cod = d.inv_numero AND b.DDoc_Sis_Emp = d.inv_sisemp"
        strSQL &= "                        INNER JOIN Articulos e ON d.inv_artcodigo = e.art_codigo AND d.inv_sisemp = e.art_sisemp"
        strSQL &= "                          INNER JOIN Catalogos cat ON cat.cat_clase = 'StatusIngBdg'AND cat.cat_desc = 'GOOD'"
        strSQL &= "                     INNER JOIN Catalogos f ON d.inv_UMcmpra = f.cat_num"
        strSQL &= "                 LEFT JOIN Catalogos p ON p.cat_clase = 'Paises' AND p.cat_num = d.inv_lugarfab"
        strSQL &= "                   LEFT JOIN Catalogos ca ON ca.cat_clase = 'Monedas' AND ca.cat_num = HDoc_Doc_Mon"
        strSQL &= "               WHERE HDoc_Sis_Emp = {empresa} AND HDoc_Doc_Cat = 180 and a.HDoc_Doc_Fec<='{filtroFecha}' AND HDoc_Emp_Cod = {codEmpresa}  {documentos}"
        strSQL &= "           GROUP BY a.HDoc_Sis_Emp, a.HDoc_Doc_Cat, a.HDoc_Doc_Ano, a.HDoc_Doc_Num, b.DDoc_Doc_Lin"
        strSQL &= "       HAVING Sum_Qty > 0"

        strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
        strSQL = Replace(strSQL, "{codEmpresa}", celdaIDCliente.Text)
        strSQL = Replace(strSQL, "{documentos}", ListaParaProcesar)
        strSQL = Replace(strSQL, "{filtroFecha}", dtpFech.Value.ToString(FORMATO_MYSQL))

        Return strSQL
    End Function

    'Lista de importaciones para procesar
    Private Function ListaParaProcesar() As String
        Dim i As Integer = 0
        Dim strSQL As String = STR_VACIO
        Dim intRevision As Integer = 0

        For i = 0 To dgPolizasImportacion.Rows.Count - 1
            If dgPolizasImportacion.Rows.Count > 0 Then
                If dgPolizasImportacion.Rows(i).Visible = True Then
                    strSQL &= IIf(intRevision = 0, "(", " OR (")
                    strSQL &= "HDoc_Doc_Ano = " & dgPolizasImportacion.Rows(i).Cells("colAno").Value & " AND "
                    strSQL &= "HDoc_Doc_Num = " & dgPolizasImportacion.Rows(i).Cells("colNumero").Value & ")"
                    intRevision = intRevision + 1
                End If

            End If
        Next

        If strSQL = vbNullString Then
            ListaParaProcesar = "AND 1 = 1 "
        Else
            ListaParaProcesar = "AND (" & strSQL & ")"
        End If
    End Function

    'Cargar Detalle de los documentos en le listado (para procesar)
    Private Sub ProcesarDocumentos()
        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader
        Dim dblCantidad As Double
        Dim dblPrecio As Double
        Dim SubTotal As Double
        Dim strSQL As String = STR_VACIO
        Dim i As Integer = 0
        Try

            If dgPolizasImportacion.Rows.Count > vbEmpty Then
                strSQL = SqlDetalleParaProcesar()

                MyCnn.CONECTAR = strConexion
                COM = New MySqlCommand(strSQL, CON)
                REA = COM.ExecuteReader

                Do While REA.Read
                    dblCantidad = REA.GetDouble("Sum_QTY")
                    dblPrecio = REA.GetDouble("inv_costo")

                    If Not (intTipo > vbEmpty) Then
                        If REA.GetInt32("inv_generico") Then
                            'Si no ses generico
                            dblPrecio = REA.GetDouble("inv_costo")
                        Else
                            dblPrecio = REA.GetDouble("DDoc_Prd_PUQ")
                        End If
                    End If

                    SubTotal = (dblCantidad * dblPrecio)
                    i = i + 1

                    strSQL = REA.GetInt32("DDoc_Prd_Cod") & "|"
                    strSQL &= REA.GetString("art_DCorta") & "|"
                    strSQL &= REA.GetInt32("UM") & "|"
                    strSQL &= REA.GetString("cat_clave") & "|"
                    strSQL &= dblPrecio & "|"
                    strSQL &= 0 & "|"
                    strSQL &= 0 & "|"
                    strSQL &= dblCantidad & "|"
                    strSQL &= 1 & "|"
                    strSQL &= SubTotal.ToString(FORMATO_MONEDA) & "|"
                    strSQL &= vbNullString & "|" 'Bodega
                    strSQL &= vbNullString & "|"
                    strSQL &= vbNullString & "|" 'Reserva(Texto)
                    strSQL &= vbNullString & "|" 'Problema
                    strSQL &= vbNullString & "|" 'Comentario
                    'Catidad Original
                    strSQL &= dblCantidad & "|"
                    'Codigo Original
                    strSQL &= REA.GetInt32("DDoc_Prd_Cod") & "|"
                    strSQL &= vbNullString & "|"
                    strSQL &= 0 & "|"
                    'strSQL &= vbNullString & "|"
                    strSQL &= i & "|"
                    strSQL &= REA.GetString("inv_partnum") & "|"
                    strSQL &= REA.GetString("Notas") & "|"
                    strSQL &= REA.GetInt32("DDoc_RF1_Num") & "|"
                    strSQL &= 1 & "|"
                    strSQL &= 1 & "|"
                    strSQL &= REA.GetInt32("HDoc_Sis_Emp") & "|"
                    strSQL &= REA.GetInt32("HDoc_Doc_Ano") & "|"
                    strSQL &= REA.GetInt32("HDoc_Doc_Num") & "|"
                    strSQL &= REA.GetInt32("DDoc_Doc_Lin") & "|"
                    strSQL &= 0 & "|"
                    strSQL &= REA.GetInt32("idEstado") & "|"
                    strSQL &= REA.GetString("Estado")

                    cFunciones.AgregarFila(dgDetalle, strSQL)

                    dgDetalle.CurrentRow.Cells("colReserva").ReadOnly = True
                    celdaTasa.Text = REA.GetDouble("tc")
                Loop
            End If

            CalcularTotales()

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try

    End Sub

    'Devuelve la consulta de selección con los documentos por procesar
    Public Function SqlGetDocumentsList(Optional ByVal Clase As Boolean = False, Optional ByVal Codigo As Boolean = False, Optional ByVal Estado As Boolean = True, Optional Actual As Boolean = False, Optional ByVal Identificador As Boolean = False, Optional ByVal Saldo As Boolean = True, Optional ByVal curDoc As Integer = vbEmpty) As String
        'Parámetros: empresa, tipo, clase, codigo, estado
        Dim strSQL As String = STR_VACIO

        strSQL = "SELECT DISTINCT"
        If Identificador Then
            strSQL &= " HDoc_Sis_Emp empresa, HDoc_Doc_Cat tipo, HDoc_Doc_Ano anio, HDoc_Doc_Num numero, HDoc_Doc_Fec fecha, COALESCE(HDoc_DR1_Num,'') HDoc_DR1_Num referencia, HDoc_Usuario usuario, HDoc_RF1_Dbl Total"
        Else
            strSQL &= " HDoc_Sis_Emp, HDoc_Doc_Cat, HDoc_Doc_Ano, HDoc_Doc_Num, HDoc_Doc_Fec, COALESCE(HDoc_DR1_Num,'') HDoc_DR1_Num, HDoc_Usuario, HDoc_RF1_Dbl Total"
        End If
        strSQL &= "     FROM Dcmtos_HDR a"
        strSQL &= "          LEFT JOIN Dcmtos_DTL b ON a.HDoc_Sis_Emp = b.DDoc_Sis_Emp AND a.HDoc_Doc_Cat = b.DDoc_Doc_Cat AND a.HDoc_Doc_Ano = b.DDoc_Doc_Ano AND a.HDoc_Doc_Num = b.DDoc_Doc_Num"
        strSQL &= "                  WHERE HDoc_Sis_Emp = {empresa} AND (HDoc_Doc_Cat = 180)  AND a.HDoc_Doc_Fec<='{fechaFiltro}' "

        If Clase Then
            'Clase: importación, devolución, transferencia
            strSQL &= "                   AND COALESCE(HDoc_DR1_Cat,0) = {clase}"
        End If

        If Codigo Then
            'Código de la empresa (cliente/proveedor)
            strSQL &= "                      AND (HDoc_Emp_Cod = {codigo})"
        End If

        If Estado Then
            'Estado del Documento
            strSQL &= "                          AND HDoc_Doc_Status = 1"
        End If

        'Sólo documentos con saldo
        If Saldo Then
            strSQL &= "                          AND (COALESCE((SELECT SUM(c.PDoc_QTY_Pro)"
            strSQL &= "                      FROM Dcmtos_DTL_Pro c"
            strSQL &= "                  WHERE c.PDoc_Sis_Emp = b.DDoc_Sis_Emp AND c.PDoc_Par_Cat = b.DDoc_Doc_Cat AND c.PDoc_Par_Ano = b.DDoc_Doc_Ano AND c.PDoc_Par_Num = b.DDoc_Doc_Num AND c.PDoc_Par_Lin = b.DDoc_Doc_Lin "
            If Actual Then
                'Documento que descarga (actual)
                strSQL &= "          AND c.PDoc_Chi_Cat = {actual}"
            End If
            If curDoc = 47 Then
                strSQL &= "      ), 0) < b.DDoc_RF3_Dbl)"
            Else
                strSQL &= "      ), 0) < b.DDoc_Prd_QTY)"
            End If
        End If

        strSQL &= "              ORDER BY HDoc_Doc_Ano DESC, HDoc_Doc_Num DESC"


        'Devuelve el Resultado
        SqlGetDocumentsList = strSQL

    End Function

    Private Function GuardarBultos() As Boolean
        Dim logResultado As Boolean = True
        Dim DtlBox As New Tablas.TDCMTOS_DTL_BOX
        Const I_CODIGO As Integer = 1
        Dim i As Integer = 0
        Dim j As Integer = 0
        Dim k As Integer = 0
        Dim logExiste As Boolean



        DtlBox.CONEXION = strConexion
        Try
            'If VerificarPacas_() Or (intTipo <> 0 And intTipo <> 4) Then
            For i = 0 To dgDetalle.Rows.Count - 1
                If dgOculto.Rows.Count > dgDetalle.Rows.Count Then
                    logExiste = False
                    For j = 0 To dgOculto.Rows.Count - 1



                        '<<<<<<< Updated upstream
                        '=======
                        '>>>>>>> Stashed changes
                        If dgDetalle.Rows(i).Cells("colLinea").Value = dgOculto.Rows(j).Cells("colLineaDetalle").Value Then
                            logExiste = True
                            DtlBox.BDOC_SIS_EMP = dgOculto.Rows(j).Cells("colEmpresa").Value 'empresa
                            DtlBox.BDOC_DOC_CAT = dgOculto.Rows(j).Cells("colCat").Value 'catalogo
                            DtlBox.BDOC_DOC_ANO = dgOculto.Rows(j).Cells("colAnio2").Value 'anio
                            DtlBox.BDOC_DOC_NUM = celdaNumero.Text ' numeor
                            DtlBox.BDOC_DOC_LIN = dgOculto.Rows(j).Cells("colLineaDetalle").Value 'linea detalle
                            DtlBox.BDOC_BOX_LIN = j + 1 ' linea
                            DtlBox.BDOC_BOX_ORD = dgOculto.Rows(j).Cells("colTipoBulto").Value 'tara
                            DtlBox.BDOC_BOX_CTG = dgOculto.Rows(j).Cells("colPaquetes").Value 'Categoria - Turno
                            If dgOculto.Rows(j).Cells("colRef").Value = "" Then
                                DtlBox.BDOC_BOX_COD = "NULL"
                            Else
                                DtlBox.BDOC_BOX_COD = dgOculto.Rows(j).Cells("colRef").Value 'Marca - Color de cono
                            End If
                            DtlBox.BDOC_BOX_QTY = 1
                            DtlBox.BDOC_BOX_LB = dgOculto.Rows(j).Cells("colPesoNeto").Value

                            '<<<<<<< Updated upstream


                            '=======
                            '>>>>>>> Stashed changes
                            If dgOculto.Rows(j).Cells("colXtraBox").Value = 1 Then
                                If logEditar = True Then
                                    If DtlBox.PUPDATE = False Then
                                        MsgBox(DtlBox.MERROR.ToString & "Could not update the document", MsgBoxStyle.Critical)
                                    End If
                                Else
                                    MsgBox("You do not have access to save a new revenue from goods to warehouse", vbInformation)
                                End If
                            ElseIf dgOculto.Rows(j).Cells("colXtraBox").Value = 0 Then
                                If logInsertar = True Then
                                    If DtlBox.PINSERT = False Then
                                        MsgBox(DtlBox.MERROR.ToString & "Could not save the document", MsgBoxStyle.Critical)
                                    End If
                                Else
                                    MsgBox("You do not have access to save a new revenue from goods to warehouse", vbInformation)
                                End If
                            End If
                        End If
                    Next
                    If logExiste = False Then
                        DtlBox.BDOC_SIS_EMP = celdaEmpresa.Text
                        DtlBox.BDOC_DOC_CAT = celdaCatalogo.Text
                        DtlBox.BDOC_DOC_ANO = celdaAnio.Text
                        DtlBox.BDOC_DOC_NUM = celdaNumero.Text
                        If dgDetalle.Rows(i).Visible = True Then
                            k = i + 1
                        End If
                        DtlBox.BDOC_DOC_LIN = k
                        DtlBox.BDOC_BOX_LIN = 1
                        DtlBox.BDOC_BOX_COD = 1
                        DtlBox.BDOC_BOX_QTY = dgDetalle.Rows(i).Cells("colBultos").Value
                        DtlBox.BDOC_BOX_LB = dgDetalle.Rows(i).Cells("colCantidad").Value



                        If dgDetalle.Rows(i).Cells("colAgregar").Value = 0 Then
                            If DtlBox.PUPDATE = False Then
                                MsgBox(DtlBox.MERROR.ToString & "Could not update the document", MsgBoxStyle.Critical)
                            End If
                        ElseIf dgDetalle.Rows(i).Cells("colAgregar").Value = 1 Then
                            If DtlBox.PINSERT = False Then
                                MsgBox(DtlBox.MERROR.ToString & "Could not save the document", MsgBoxStyle.Critical)
                            End If
                        End If



                    End If
                Else
                    DtlBox.BDOC_SIS_EMP = celdaEmpresa.Text
                    DtlBox.BDOC_DOC_CAT = celdaCatalogo.Text
                    DtlBox.BDOC_DOC_ANO = celdaAnio.Text
                    DtlBox.BDOC_DOC_NUM = celdaNumero.Text
                    If dgDetalle.Rows(i).Visible = True Then
                        k = i + 1
                    End If
                    DtlBox.BDOC_DOC_LIN = k
                    DtlBox.BDOC_BOX_LIN = 1
                    DtlBox.BDOC_BOX_COD = 1
                    DtlBox.BDOC_BOX_QTY = dgDetalle.Rows(i).Cells("colBultos").Value
                    DtlBox.BDOC_BOX_LB = dgDetalle.Rows(i).Cells("colCantidad").Value

                    '<<<<<<< Updated upstream


                    '=======
                    '>>>>>>> Stashed changes
                    If VerificarPacas_() = False Then
                        If dgDetalle.Rows(i).Cells("colAgregar").Value = 0 Then
                            If DtlBox.PUPDATE = False Then
                                MsgBox(DtlBox.MERROR.ToString & "Could not update the document", MsgBoxStyle.Critical)
                            End If
                        ElseIf dgDetalle.Rows(i).Cells("colAgregar").Value = 1 Then
                            If DtlBox.PINSERT = False Then
                                MsgBox(DtlBox.MERROR.ToString & "Could not save the document", MsgBoxStyle.Critical)
                            End If
                        End If
                    Else
                        If intTipo = 0 Or intTipo = 4 Then
                            If dgDetalle.Rows(i).Cells("colAgregar").Value = 0 Then ' si ya tiene pacas, no actualiza
                                'If DtlBox.PUPDATE = False Then
                                '    MsgBox(DtlBox.MERROR.ToString & "Could not update the document", MsgBoxStyle.Critical)
                                'End If
                            ElseIf dgDetalle.Rows(i).Cells("colAgregar").Value = 1 Then
                                If DtlBox.PINSERT = False Then
                                    MsgBox(DtlBox.MERROR.ToString & "Could not save the document", MsgBoxStyle.Critical)
                                End If
                            End If
                        Else
                            If dgDetalle.Rows(i).Cells("colAgregar").Value = 0 Then
                                If DtlBox.PUPDATE = False Then
                                    MsgBox(DtlBox.MERROR.ToString & "Could not update the document", MsgBoxStyle.Critical)
                                End If
                            ElseIf dgDetalle.Rows(i).Cells("colAgregar").Value = 1 Then
                                If DtlBox.PINSERT = False Then
                                    MsgBox(DtlBox.MERROR.ToString & "Could not save the document", MsgBoxStyle.Critical)
                                End If
                            End If
                        End If
                    End If
                End If
            Next


            'End If
            '<<<<<<< Updated upstream


            '=======
            '>>>>>>> Stashed changes
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        Return logResultado
    End Function

    Private Sub EliminarLineasBultos()
        Dim DtlBox As New Tablas.TDCMTOS_DTL_BOX
        Dim j As Integer = 0
        Dim cantLineas As Integer
        cantLineas = dgOculto.Rows.Count


        DtlBox.CONEXION = strConexion
        Try
            For i As Integer = 0 To dgOculto.Rows.Count - 1

                DtlBox.BDOC_SIS_EMP = dgOculto.Rows(i).Cells("colEmpresa").Value
                DtlBox.BDOC_DOC_CAT = dgOculto.Rows(i).Cells("colCat").Value
                DtlBox.BDOC_DOC_ANO = dgOculto.Rows(i).Cells("colAnio2").Value
                DtlBox.BDOC_DOC_NUM = dgOculto.Rows(i).Cells("colNumero2").Value
                DtlBox.BDOC_DOC_LIN = dgOculto.Rows(i).Cells("colLineaDetalle").Value
                DtlBox.BDOC_BOX_LIN = dgOculto.Rows(i).Cells("colLinea2").Value
                DtlBox.BDOC_BOX_ORD = dgOculto.Rows(i).Cells("colTipoBulto").Value
                DtlBox.BDOC_BOX_COD = dgOculto.Rows(i).Cells("colRef").Value
                DtlBox.BDOC_BOX_QTY = 1
                DtlBox.BDOC_BOX_LB = dgOculto.Rows(i).Cells("colPesoNeto").Value
                DtlBox.BDOC_BOX_CTG = dgOculto.Rows(i).Cells("colPaquetes").Value

                If dgOculto.Rows(i).Cells("colXtraBox").Value = 2 Then
                    If DtlBox.PDELETE = False Then
                        MsgBox(DtlBox.MERROR.ToString & "Could not Save the document", MsgBoxStyle.Critical)
                    End If

                End If
            Next
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Function GuardarDocumento() As Boolean
        Dim chdr As New clsDcmtos_HDR
        Try
            chdr.CONEXION = strConexion

            chdr.HDOC_SIS_EMP = celdaEmpresa.Text
            chdr.HDOC_DOC_CAT = celdaCatalogo.Text
            chdr.HDOC_DOC_ANO = celdaAnio.Text
            chdr.HDOC_DOC_NUM = celdaNumero.Text
            chdr.HDoc_Doc_Fec_NET = dtpFech.Value.ToString(FORMATO_MYSQL)

            chdr.HDOC_EMP_COD = celdaIDCliente.Text
            chdr.HDOC_EMP_NOM = celdaCliente.Text
            chdr.HDOC_EMP_DIR = celdaDireccion.Text
            chdr.HDOC_EMP_NIT = celdaNit.Text
            chdr.HDOC_EMP_TEL = celdaTelefono.Text

            chdr.HDOC_DOC_MON = celdaIDMoneda.Text
            chdr.HDOC_DOC_TC = celdaTasa.Text

            chdr.HDOC_PRO_DCAT = IIf(celdaRevisado.Text = 0 Or celdaRevisado.Text = NO_FILA, 0, 1)
            chdr.HDOC_DR2_CAT = IIf(CheckIngreso.Checked = False, 0, 1) ' Guarda si es un ingreso de producto terminado, procedente de otra planta (procesado en una y finalizado en otra)
            chdr.HDOC_DR1_CAT = intTipo
            chdr.HDOC_DR1_NUM = celdaRefFactura.Text
            chdr.HDOC_DR2_NUM = celdaRef1.Text
            chdr.HDOC_RF1_DBL = IIf(checkTendido.Checked = True, 1, 0)
            If celdaRef2.Text.Length > 2 Then
                chdr.HDOC_RF2_TXT = celdaRef2.Text
            Else
                chdr.HDOC_RF2_TXT = "NULL"
            End If
            chdr.HDOC_RF2_DBL = 0       ' boton powe
            chdr.HDOC_USUARIO = celdaUsuario.Text
            chdr.HDOC_ANT_COM = celdaTipoIngreso.Text
            If Sesion.idGiro = 2 Then
                chdr.HDOC_RF3_DBL = IIf(checkMuestra.Checked = True, 1, 0)
            End If
            If Me.Tag = "Mod" Then
                If logEditar = True Then
                    If chdr.Actualizar() = False Then
                        MsgBox(chdr.MERROR.ToString & "Could not update the document", MsgBoxStyle.Critical)
                        Return False
                    End If
                Else
                    MsgBox("You do not have access to save a new revenue from goods to warehouse", vbInformation)
                    Return False
                End If
            Else
                If logInsertar = True Then
                    If chdr.Guardar() = False Then
                        MsgBox(chdr.MERROR.ToString & "Could not save the document", MsgBoxStyle.Critical)
                        Return False
                    End If
                Else
                    MsgBox("You do not have access to save a new revenue from goods to warehouse", vbInformation)
                    Return False
                End If
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
            Return False
        End Try
        Return True
    End Function
    'Permiso para poder cambiar el Status de Hilo
    Private Function PermisoActualizar() As Boolean
        Dim strSQL As String = STR_VACIO
        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader
        Dim logResultado As Boolean = False
        strSQL = "SELECT p.pms_codigo Permiso"
        strSQL &= "     FROM Permisos p "
        strSQL &= "         WHERE p.pms_usuario = '{usuario}' AND p.pms_modulo = 55 AND p.pms_codigo  ='STATUS'"
        strSQL = Replace(strSQL, "{usuario}", Sesion.Usuario)
        MyCnn.CONECTAR = strConexion
        COM = New MySqlCommand(strSQL, CON)
        REA = COM.ExecuteReader
        If REA.HasRows Then
            Do While REA.Read
                If REA.GetString("Permiso") = "STATUS" Then
                    logResultado = True
                End If
            Loop
        End If
        Return logResultado
    End Function
    Public Function HacerDescargoAIngreso() As Boolean
        Dim strSQL As String = STR_VACIO
        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader
        Dim logResultado As Boolean = False
        strSQL = "SELECT p.pms_nivel nivel"
        strSQL &= "     FROM Permisos p "
        strSQL &= "         WHERE p.pms_empresa='{empresa}' AND p.pms_usuario = '{usuario}' AND p.pms_modulo = 47 AND p.pms_codigo  ='MakePOWE'"
        strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
        strSQL = Replace(strSQL, "{usuario}", Sesion.Usuario)
        MyCnn.CONECTAR = strConexion
        COM = New MySqlCommand(strSQL, CON)
        REA = COM.ExecuteReader
        If REA.HasRows Then
            Do While REA.Read
                If REA.GetInt16("nivel") = 1 Then
                    logResultado = True
                End If
            Loop
        End If
        Return logResultado
    End Function
    'Update Directo cambio Status de hilo 
    Public Sub ActualizarEstado()
        Dim strSQL As String = STR_VACIO
        Dim COM As MySqlCommand
        Dim strInfo As String = STR_VACIO
        If Me.Tag = "Mod" Then
            strSQL = "UPDATE Dcmtos_DTL d SET d.DDoc_RF2_Num = {numEstado} "
            strSQL &= " WHERE d.DDoc_Sis_Emp = {empresa} AND d.DDoc_Doc_Cat = 47 AND d.DDoc_Doc_Ano = {anio} AND d.DDoc_Doc_Num = {numero}  AND d.DDoc_Doc_Lin = {linea}"
            If Sesion.IdEmpresa = 18 Then
                strSQL &= ";UPDATE PDM.Dcmtos_DTL d SET d.DDoc_RF2_Num = {numEstado} "
                strSQL &= " WHERE d.DDoc_Sis_Emp = {empresa} AND d.DDoc_Doc_Cat = 47 AND d.DDoc_Doc_Ano = {anio} AND d.DDoc_Doc_Num = {numero}  AND d.DDoc_Doc_Lin = {linea}"
            End If
            strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
            strSQL = Replace(strSQL, "{anio}", celdaAnio.Text)
            strSQL = Replace(strSQL, "{numero}", celdaNumero.Text)
            strSQL = Replace(strSQL, "{linea}", dgDetalle.CurrentRow.Cells("colLinea").Value)
            strSQL = Replace(strSQL, "{numEstado}", dgDetalle.CurrentRow.Cells("colIdEstado").Value)
            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSQL, CON)
            COM.ExecuteNonQuery()
            COM.Dispose()
            System.GC.Collect()
            strInfo &= "The status was update to " & dgDetalle.CurrentRow.Cells("colEstado").Value

            cFunciones.EscribirRegistro(TBL_DOCUMENTOS, clsFunciones.AccEnum.acUpdate, celdaIDCliente.Text, 47, celdaAnio.Text, celdaNumero.Text, strInfo)
            MsgBox("Update successful. Don't click on save button.")
        End If
    End Sub

    Public Sub GuardarKardexPO(ByVal intTipoKardex As Integer)
        Dim kar As New Tablas.TKARDEX
        ' Variables que capturan los datos actuales de la PO
        Dim strsql As String = STR_VACIO
        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader
        Dim Conec As MySqlConnection
        Dim Cantidad_Kardex As Double = INT_CERO
        Dim Total_Kardex As Double = INT_CERO
        Dim CostoPromedioKardex As Double = INT_CERO
        Dim j As Integer = 0

        Dim Costo_Ingreso As Double

        ' ML --> proceso para hacer cálculo y registro del documento según el precio promedio de la PO

        'MyCnn.CONECTAR = strConexion

        Try
            For i As Integer = 0 To dgDetalle.Rows.Count - 1
                'Datos Ingresp
                Costo_Ingreso = INT_CERO
                ' Datos Kardex
                Cantidad_Kardex = INT_CERO
                Total_Kardex = INT_CERO
                CostoPromedioKardex = INT_CERO
                ' se consultan datos, según la ultima transacción
                'If intTipoKardex = 0 Then
                If intTipoKardex = 1 Then
                    strsql = cfun.Kardex_DatosIngresoEliminado(47, celdaAnio.Text, celdaNumero.Text, dgDetalle.Rows(i).Cells("colLinea").Value)

                    Conec = New MySqlConnection(strConexion)
                    Conec.Open()
                    COM = New MySqlCommand(strsql, Conec)
                    Using Conec
                        REA = COM.ExecuteReader()
                        If REA.HasRows Then
                            'Do While
                            REA.Read()

                            Costo_Ingreso = ConvertirSinNotacionCientifica(REA.GetString("Cprom"), 8)

                            'Loop
                        End If
                        COM = Nothing
                        REA.Close()
                        Conec.Close()
                        Conec.Dispose()
                        Conec = Nothing
                        System.GC.Collect()
                    End Using
                End If

                strsql = STR_VACIO
                strsql = cfun.Kardex_PProceso(980, dgDetalle.Rows(i).Cells("colAnioPoliza").Value, dgDetalle.Rows(i).Cells("colNumPoliza").Value)

                Conec = New MySqlConnection(strConexion)
                Conec.Open()
                COM = New MySqlCommand(strsql, Conec)
                Using Conec
                    REA = COM.ExecuteReader()
                    If REA.HasRows Then
                        'Do While
                        REA.Read()
                        Cantidad_Kardex = ConvertirSinNotacionCientifica(REA.GetDouble("Cantidad"), 8) ' Saldo de la PO (lb)
                        Total_Kardex = ConvertirSinNotacionCientifica(REA.GetDouble("Total"), 8)       ' Saldo de la PO ($)
                        CostoPromedioKardex = ConvertirSinNotacionCientifica(REA.GetDouble("Cprom"), 8) ' costo promedio PO
                        'Loop
                    End If
                    COM = Nothing
                    REA.Close()
                    Conec.Close()
                    Conec.Dispose()
                    Conec = Nothing
                    System.GC.Collect()
                End Using

                kar.KAR_SIS_EMP = Sesion.IdEmpresa
                kar.KAR_DOC_CAT = 47
                kar.KAR_DOC_ANO = celdaAnio.Text
                kar.KAR_DOC_NUM = celdaNumero.Text
                If dgDetalle.Rows(i).Visible = True Then
                    j = j + 1
                End If
                kar.KAR_DOC_LIN = j
                kar.KAR_ONHAND = CDbl(dgDetalle.Rows(i).Cells("colCantidad").Value) 'Cantidad ingresada en el ingreso a Bodega

                If intTipoKardex = 0 Then
                    kar.KAR_COST_LOC = Math.Round(CostoPromedioKardex, 10)  ' Precio promedio del ingreso
                    kar.KAR_ONTRANSIT = Math.Round(CDbl(dgDetalle.Rows(i).Cells("colCantidad").Value) * CostoPromedioKardex, 10) ' Total $ del ingreso
                    kar.KAR_COMMITTED = Math.Round(Cantidad_Kardex - CDbl(dgDetalle.Rows(i).Cells("colCantidad").Value), 10)  'Saldo de libras, restando lo que se está ingresando con la linea anterior
                    kar.KAR_PHY_INC = Math.Round(Total_Kardex - (CDbl(dgDetalle.Rows(i).Cells("colCantidad").Value) * CostoPromedioKardex), 10) 'Saldo en $, restando el total que está ingresando con la linea anterior
                    kar.KAR_COST_EXT = Math.Round((Total_Kardex - (CDbl(dgDetalle.Rows(i).Cells("colCantidad").Value) * CostoPromedioKardex)) / (Cantidad_Kardex - CDbl(dgDetalle.Rows(i).Cells("colCantidad").Value)), 10) 'Costo Promedio para la PO
                Else
                    kar.KAR_COST_LOC = Math.Round(Costo_Ingreso, 10)   ' Precio promedio del ingreso
                    kar.KAR_ONTRANSIT = Math.Round(CDbl(dgDetalle.Rows(i).Cells("colCantidad").Value) * Costo_Ingreso, 10) ' Total $ del ingreso
                    kar.KAR_COMMITTED = Math.Round(Cantidad_Kardex + CDbl(dgDetalle.Rows(i).Cells("colCantidad").Value), 10)  'Saldo de libras, sumando lo que se está ingresando con la linea anterior
                    kar.KAR_PHY_INC = Math.Round(Total_Kardex + (CDbl(dgDetalle.Rows(i).Cells("colCantidad").Value) * Costo_Ingreso), 10) 'Saldo en $, sumando el total que está ingresando con la linea anterior
                    kar.KAR_COST_EXT = Math.Round((Total_Kardex + (CDbl(dgDetalle.Rows(i).Cells("colCantidad").Value) * Costo_Ingreso)) / (Cantidad_Kardex + CDbl(dgDetalle.Rows(i).Cells("colCantidad").Value)), 10) 'Costo Promedio para la PO
                End If
                kar.KAR_DOC_MON = celdaIDMoneda.Text
                kar.KAR_DOC_TC = celdaTasa.Text
                kar.Kar_Opr_Fec_NET = cfun.HoyMySQL.ToString(FORMATO_MYSQL) ' Fecha que se está operando el registro
                kar.Kar_Doc_Fec_NET = dtpFech.Value.ToString(FORMATO_MYSQL) ' Fecha del documento
                ' llave de PO
                kar.KAR_PO_CAT = 980
                kar.KAR_PO_ANO = dgDetalle.Rows(i).Cells("colAnioPoliza").Value
                kar.KAR_PO_NUM = dgDetalle.Rows(i).Cells("colNumPoliza").Value
                kar.KAR_TRANSID = 0

                kar.CONEXION = strConexion

                If kar.PINSERT = False Then
                    MsgBox(kar.MERROR.ToString & "Could Not save the document", MsgBoxStyle.Critical)
                End If
            Next
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub
    'Query para guardar Datos del Detalle

    Function ConvertirSinNotacionCientifica(valorTexto As String, decimales As Integer) As Double
        If String.IsNullOrWhiteSpace(valorTexto) Then
            Throw New ArgumentException("El valor proporcionado está vacío o es nulo.")
        End If

        ' Eliminar notación científica si existe
        Dim indexE As Integer = valorTexto.ToLower().IndexOf("e")
        If indexE >= 0 Then
            valorTexto = valorTexto.Substring(0, indexE)
        End If

        ' Convertir y redondear
        Dim valor As Double = Double.Parse(valorTexto, System.Globalization.CultureInfo.InvariantCulture)
        Return Math.Round(valor, decimales, MidpointRounding.AwayFromZero)
    End Function


    Private Function GuardarDetalle() As Boolean
        Dim logResultado As Boolean = True
        Dim Dtl As New clsDcmtos_DTL
        Dtl.CONEXION = strConexion
        Dim j As Integer = 0

        Try
            For i As Integer = 0 To dgDetalle.Rows.Count - 1
                Dtl.DDOC_SIS_EMP = celdaEmpresa.Text
                Dtl.DDOC_DOC_CAT = celdaCatalogo.Text
                Dtl.DDOC_DOC_ANO = celdaAnio.Text
                Dtl.DDOC_DOC_NUM = celdaNumero.Text


                If Me.Tag = "Nuevo" Then
                    If dgDetalle.Rows(i).Visible = True Then
                        j = j + 1
                    End If
                    Dtl.DDOC_DOC_LIN = j
                    'Dtl.DDOC_RF2_NUM = INT_CERO
                    If Sesion.idGiro = 2 Then
                        Dtl.DDOC_RF2_NUM = If(dgDetalle.Rows(i).Cells("colIdEstado").Value = vbNullString, 2605, (dgDetalle.Rows(i).Cells("colIdEstado").Value))
                    Else
                        Dtl.DDOC_RF2_NUM = If(dgDetalle.Rows(i).Cells("colIdEstado").Value = vbNullString, 3089, (dgDetalle.Rows(i).Cells("colIdEstado").Value))
                    End If
                Else
                    Dtl.DDOC_DOC_LIN = dgDetalle.Rows(i).Cells("colLinea").Value
                    If Sesion.idGiro = 2 Then
                        Dtl.DDOC_RF2_NUM = If(dgDetalle.Rows(i).Cells("colIdEstado").Value = vbNullString, 2605, (dgDetalle.Rows(i).Cells("colIdEstado").Value))
                    Else
                        Dtl.DDOC_RF2_NUM = If(dgDetalle.Rows(i).Cells("colIdEstado").Value = vbNullString, 3089, (dgDetalle.Rows(i).Cells("colIdEstado").Value))
                    End If
                End If

                Dtl.DDOC_PRD_COD = dgDetalle.Rows(i).Cells("colCodigo").Value
                If intTipo = 4 Then
                    Dtl.DDOC_PRD_PNR = dgDetalle.Rows(i).Cells("colBoxNumber").Value
                Else
                    Dtl.DDOC_PRD_PNR = dgDetalle.Rows(i).Cells("colPrdPNr").Value
                End If
                Dtl.DDOC_PRD_DES = dgDetalle.Rows(i).Cells("colArticulo").Value
                Dtl.DDOC_PRD_UM = dgDetalle.Rows(i).Cells("colIDMedida").Value

                Dtl.DDOC_PRD_PUQ = CDbl(dgDetalle.Rows(i).Cells("colPrecio").Value)
                Dtl.DDOC_PRD_DSP = dgDetalle.Rows(i).Cells("colDescuento").Value
                Dtl.DDOC_PRD_DSQ = dgDetalle.Rows(i).Cells("colDesDolar").Value
                Dtl.DDOC_PRD_NET = CDbl(dgDetalle.Rows(i).Cells("colPrecio").Value)
                Dtl.DDOC_PRD_QTY = CDbl(dgDetalle.Rows(i).Cells("colCantidad").Value)

                Dtl.DDOC_RF1_TXT = dgDetalle.Rows(i).Cells("colReserva").Value
                'Dtl.DDOC_RF1_COD = CDbl(dgDetalle.Rows(i).Cells("colCodOriginal").Value)
                If Not IsDBNull(dgDetalle.Rows(i).Cells("colCodOriginal").Value) AndAlso Not String.IsNullOrWhiteSpace(dgDetalle.Rows(i).Cells("colCodOriginal").Value.ToString()) Then
                    Dtl.DDOC_RF1_COD = CDbl(dgDetalle.Rows(i).Cells("colCodOriginal").Value)
                End If
                Dtl.DDOC_RF1_DBL = CDbl(dgDetalle.Rows(i).Cells("colCantidad").Value)

                Dtl.DDOC_RF2_COD = dgDetalle.Rows(i).Cells("colBodegga").Value
                Dtl.DDOC_RF2_TXT = dgDetalle.Rows(i).Cells("colProblema").Value

                If intTipo = 6 Then ' ingresos sin póliza
                    Dtl.DDOC_RF3_TXT = dgDetalle.Rows(i).Cells("colReferenciaRamplas").Value
                End If
                If intTipo = 3 Then
                    Dtl.DDOC_PRD_REF = dgDetalle.Rows(i).Cells("colRefMKT").Value
                Else
                    If dgDetalle.Rows(i).Cells("colRefMKT").Value = Nothing Then
                        Dtl.DDOC_PRD_REF = STR_VACIO
                    Else
                        Dtl.DDOC_PRD_REF = dgDetalle.Rows(i).Cells("colRefMKT").Value
                    End If
                End If


                If dgDetalle.Rows(i).Cells("colAgregar").Value = 0 Then
                    If logEditar = True Then
                        If Dtl.Actualizar() = False Then
                            MsgBox(Dtl.MERROR.ToString & "Could not update the document", MsgBoxStyle.Critical)
                        End If
                    Else
                        MsgBox("You do not have access to save a new revenue from goods to warehouse", vbInformation)
                    End If
                ElseIf dgDetalle.Rows(i).Cells("colAgregar").Value = 1 Then
                    If logInsertar = True Then
                        If Dtl.Guardar() = False Then
                            MsgBox(Dtl.MERROR.ToString & "Could not save the document", MsgBoxStyle.Critical)
                        End If
                    Else
                        MsgBox("You do not have access to save a new revenue from goods to warehouse", vbInformation)
                    End If
                ElseIf dgDetalle.Rows(i).Cells("colAgregar").Value = 2 Then
                    If Me.Tag = "Mod" Then
                        If Dtl.Borrar() = False Then
                            MsgBox(Dtl.MERROR.ToString & "Could not update the document", MsgBoxStyle.Critical)
                        End If
                    End If
                End If
            Next

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        Return logResultado
    End Function

    Private Sub HabilitarTipo(ByVal Tipo As Integer)
        Dim logActivo As Boolean
        Dim logRx As Boolean

        If intTipo = 0 Then
            logActivo = True
        ElseIf intTipo = 1 Then
            logRx = True
        End If

        If logRx Then
            dgDetalle.Columns("colProblema").Visible = True
        Else
            dgDetalle.Columns("colProblema").Visible = False
        End If

        dgDetalle.Columns("colComentario").Visible = False

        celdaRefFactura.Enabled = True
        celdaRefFactura.ReadOnly = False
        celdaRef1.Enabled = True
        celdaRef1.ReadOnly = False
        celdaRef2.Enabled = True
        celdaRef2.ReadOnly = False

        celdaRefFactura.BackColor = Color.White
        celdaRef1.BackColor = Color.White
        celdaRef2.BackColor = Color.White
    End Sub

    'Procedimiento para GuardarDescargos
    Private Sub GuardarDescargoHSM()
        Dim dblSaldo As Double
        Dim dblCantidad As Double
        Dim strSQL As String = STR_VACIO
        Dim i As Integer = 0
        Dim REA As MySqlDataReader
        Dim COM1 As MySqlCommand
        Dim conec As MySqlConnection
        Dim DTLPro As New clsDcmtos_DTL_Pro
        DTLPro.CONEXION = strConexion
        Dim cfun As New clsFunciones
        Dim logResultado As Boolean = True
        Dim j As Integer = 0
        Dim LinPo As Integer = 0

        Try
            If dgPolizasImportacion.Rows.Count = 0 Then
                Exit Sub
            End If
            For i = 0 To dgDetalle.Rows.Count - 1

                strSQL = " SELECT d.DDoc_Doc_Lin 
                        FROM Dcmtos_DTL d
                    WHERE d.DDoc_Sis_Emp = {emp} AND d.DDoc_Doc_Cat = {ca} AND d.DDoc_Doc_Ano = {anio} AND d.DDoc_Doc_Num = {num}
                    ORDER BY d.DDoc_Doc_Lin asc
                    LIMIT 1"
                If intTipo > 13 Then
                    strSQL = strSQL.Replace("{ca}", 47)
                Else
                    strSQL = strSQL.Replace("{ca}", 980)
                End If
                strSQL = strSQL.Replace("{emp}", Sesion.IdEmpresa)
                strSQL = strSQL.Replace("{anio}", dgDetalle.Rows(i).Cells("colAnioPoliza").Value)
                strSQL = strSQL.Replace("{num}", dgDetalle.Rows(i).Cells("colNumPoliza").Value)

                conec = New MySqlConnection(strConexion)
                conec.Open()
                COM1 = New MySqlCommand(strSQL, conec)
                Using conec
                    LinPo = COM1.ExecuteScalar()
                    COM1.Dispose()
                    COM1 = Nothing
                    conec.Close()
                    conec.Dispose()
                    conec = Nothing
                    System.GC.Collect()
                End Using

                dblCantidad = dgDetalle.Rows(i).Cells("colCantidad").Value

                If dblCantidad > vbEmpty Then

                    DTLPro.PDOC_SIS_EMP = Sesion.IdEmpresa
                    DTLPro.PDOC_CHI_CAT = 47
                    DTLPro.PDOC_CHI_ANO = celdaAnio.Text
                    DTLPro.PDOC_CHI_NUM = celdaNumero.Text
                    If dgDetalle.Rows(i).Visible = True Then
                        j = j + 1
                    End If
                    DTLPro.PDOC_CHI_LIN = j

                    If intTipo > 13 Then
                        DTLPro.PDOC_PAR_CAT = 47
                    Else
                        DTLPro.PDOC_PAR_CAT = 980
                    End If

                    DTLPro.PDOC_PAR_ANO = dgDetalle.Rows(i).Cells("colAnioPoliza").Value
                    DTLPro.PDOC_PAR_NUM = dgDetalle.Rows(i).Cells("colNumPoliza").Value
                    'If intTipo > 13 Then
                    '    DTLPro.PDOC_PAR_LIN = dgDetalle.Rows(i).Cells("colLineaPoliza").Value
                    'Else
                    DTLPro.PDOC_PAR_LIN = LinPo
                    'End If

                    DTLPro.PDOC_PROV_COD = celdaIDCliente.Text
                    DTLPro.PDOC_PRD_COD = dgDetalle.Rows(i).Cells("ColCodigo").Value
                    DTLPro.PDOC_PRD_PNR = "N/A"
                    DTLPro.PDOC_PRD_NET = dgDetalle.Rows(i).Cells("colPrecio").Value
                    DTLPro.PDOC_QTY_ORD = dblCantidad.ToString(FORMATO_MONEDA)
                    DTLPro.PDOC_QTY_PRO = dblCantidad.ToString(FORMATO_MONEDA)

                End If
                If dgDetalle.Rows(i).Cells("colAgregar").Value = 0 Then
                    If logEditar = True Then
                        If DTLPro.Actualizar = False Then
                            MsgBox(DTLPro.MERROR.ToString & "Could not update the document", MsgBoxStyle.Critical)
                        End If
                    Else
                        MsgBox("You do not have access to save a new revenue from goods to warehouse", vbInformation)
                    End If
                ElseIf dgDetalle.Rows(i).Cells("colAgregar").Value = 1 Then
                    If logEditar = True Then
                        If DTLPro.Guardar() = False Then
                            MsgBox(DTLPro.MERROR.ToString & "Could not save the document", MsgBoxStyle.Critical)
                        End If
                    Else
                        MsgBox("You do not have access to save a new revenue from goods to warehouse", vbInformation)
                    End If
                End If
            Next
            'conne.Close()
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        strSQL = STR_VACIO
        strSQL = SqlDetalleParaProcesar()


    End Sub

    'Procedimiento para GuardarDescargos
    Private Sub GuardarDescargo()
        Dim dblSaldo As Double
        Dim dblCantidad As Double
        Dim strSQL As String = STR_VACIO
        Dim i As Integer = 0
        Dim REA As MySqlDataReader
        Dim COM As MySqlCommand
        Dim conne As MySqlConnection
        Dim DTLPro As New clsDcmtos_DTL_Pro
        DTLPro.CONEXION = strConexion
        Dim cfun As New clsFunciones
        Dim logResultado As Boolean = True
        Dim j As Integer = 0

        Try
            For i = 0 To dgDetalle.Rows.Count - 1
                DTLPro.PDOC_SIS_EMP = dgDetalle.Rows(i).Cells("colEmpresaPol").Value
                DTLPro.PDOC_PAR_CAT = 180
                DTLPro.PDOC_PAR_ANO = dgDetalle.Rows(i).Cells("colAnioPoliza").Value
                DTLPro.PDOC_PAR_NUM = dgDetalle.Rows(i).Cells("colNumPoliza").Value
                DTLPro.PDOC_PAR_LIN = dgDetalle.Rows(i).Cells("colLineaPoliza").Value

                DTLPro.PDOC_CHI_CAT = 47
                DTLPro.PDOC_CHI_ANO = celdaAnio.Text
                DTLPro.PDOC_CHI_NUM = celdaNumero.Text
                If dgDetalle.Rows(i).Visible = True Then
                    j = j + 1
                End If
                DTLPro.PDOC_CHI_LIN = j
                DTLPro.PDOC_PROV_COD = celdaIDCliente.Text
                DTLPro.PDOC_PRD_COD = dgDetalle.Rows(i).Cells("ColCodigo").Value
                DTLPro.PDOC_PRD_PNR = "N/A"
                DTLPro.PDOC_PRD_NET = dgDetalle.Rows(i).Cells("colPrecio").Value
                DTLPro.PDOC_QTY_ORD = dgDetalle.Rows(i).Cells("colCantidad").Value
                DTLPro.PDOC_QTY_PRO = dgDetalle.Rows(i).Cells("colCantidad").Value


                If dgDetalle.Rows(i).Cells("colAgregar").Value = 0 Then
                    If logEditar = True Then
                        If DTLPro.Actualizar = False Then
                            MsgBox(DTLPro.MERROR.ToString & "Could not update the document", MsgBoxStyle.Critical)
                        End If
                    Else
                        MsgBox("You do not have access to save a new revenue from goods to warehouse", vbInformation)
                    End If
                ElseIf dgDetalle.Rows(i).Cells("colAgregar").Value = 1 Then
                    If logInsertar = True Then
                        If DTLPro.Guardar() = False Then
                            MsgBox(DTLPro.MERROR.ToString & "Could not save the document", MsgBoxStyle.Critical)
                        End If
                    Else
                        MsgBox("You do not have access to save a new revenue from goods to warehouse", vbInformation)
                    End If
                End If
            Next
            'conne.Close()
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try

        strSQL = SqlDetalleParaProcesar()


    End Sub
    Private Sub GuardarDesperdicio()
        Dim strSQL As String = STR_VACIO
        Dim i As Integer = 0
        Dim DTLPro As New clsDcmtos_DTL_Pro
        DTLPro.CONEXION = strConexion
        Dim cfun As New clsFunciones
        Dim logResultado As Boolean = True
        Dim j As Integer = 0
        Dim COM1 As MySqlCommand
        Dim conec As MySqlConnection
        Dim linPO As Integer

        Try
            For i = 0 To dgDetalle.Rows.Count - 1
                'strSQL = " SELECT d.DDoc_Doc_Lin 
                '        FROM Dcmtos_DTL d
                '    WHERE d.DDoc_Sis_Emp = {emp} AND d.DDoc_Doc_Cat = 980 AND d.DDoc_Doc_Ano = {anio} AND d.DDoc_Doc_Num = {num}
                '    ORDER BY d.DDoc_Doc_Lin asc
                '    LIMIT 1"
                'strSQL = strSQL.Replace("{emp}", Sesion.IdEmpresa)
                '    strSQL = strSQL.Replace("{anio}", dgDetalle.Rows(i).Cells("colAnioPoliza").Value)
                '    strSQL = strSQL.Replace("{num}", dgDetalle.Rows(i).Cells("colNumPoliza").Value)

                '    conec = New MySqlConnection(strConexion)
                '    conec.Open()
                '    COM1 = New MySqlCommand(strSQL, conec)
                '    Using conec
                '        linPO = COM1.ExecuteScalar()
                '        COM1.Dispose()
                '        COM1 = Nothing
                '        conec.Close()
                '        conec.Dispose()
                '        conec = Nothing
                '        System.GC.Collect()
                '    End Using

                If dgDetalle.Rows(i).Visible = True Then
                    j = j + 1
                End If

                DTLPro.PDOC_SIS_EMP = Sesion.IdEmpresa
                DTLPro.PDOC_CHI_CAT = 47
                DTLPro.PDOC_CHI_ANO = celdaAnio.Text
                DTLPro.PDOC_CHI_NUM = celdaNumero.Text
                DTLPro.PDOC_PAR_LIN = dgDetalle.Rows(i).Cells("colLineaPoliza").Value

                DTLPro.PDOC_PAR_CAT = 980
                DTLPro.PDOC_PAR_ANO = dgDetalle.Rows(i).Cells("colAnioPoliza").Value
                DTLPro.PDOC_PAR_NUM = dgDetalle.Rows(i).Cells("colNumPoliza").Value

                DTLPro.PDOC_CHI_LIN = j
                DTLPro.PDOC_PROV_COD = celdaIDCliente.Text
                DTLPro.PDOC_PRD_COD = dgDetalle.Rows(i).Cells("ColCodigo").Value
                DTLPro.PDOC_PRD_PNR = "N/A"
                DTLPro.PDOC_PRD_NET = dgDetalle.Rows(i).Cells("colPrecio").Value
                DTLPro.PDOC_QTY_ORD = dgDetalle.Rows(i).Cells("colCantidad").Value
                DTLPro.PDOC_QTY_PRO = dgDetalle.Rows(i).Cells("colCantidad").Value


                If dgDetalle.Rows(i).Cells("colAgregar").Value = 0 Then
                    If logEditar = True Then
                        If DTLPro.Actualizar = False Then
                            MsgBox(DTLPro.MERROR.ToString & "Could not update the document", MsgBoxStyle.Critical)
                        End If
                    Else
                        MsgBox("You do not have access to save a new revenue from goods to warehouse", vbInformation)
                    End If
                ElseIf dgDetalle.Rows(i).Cells("colAgregar").Value = 1 Then
                    If logInsertar = True Then
                        If DTLPro.Guardar() = False Then
                            MsgBox(DTLPro.MERROR.ToString & "Could not save the document", MsgBoxStyle.Critical)
                        End If
                    Else
                        MsgBox("You do not have access to save a new revenue from goods to warehouse", vbInformation)
                    End If
                End If
            Next
            'conne.Close()
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        strSQL = STR_VACIO
        strSQL = SqlDetalleParaProcesar()


    End Sub
    Public Sub GuardarReserva()
        Dim REA As MySqlDataReader
        Dim COM As MySqlCommand
        Dim strSQL As String = STR_VACIO
        Dim conec As MySqlConnection
        Dim tbl As New Tablas.TRESERVA
        Dim strRef As String = STR_VACIO

        Try

            strSQL = SQLGuardarReserva()
            conec = New MySqlConnection(strConexion)
            conec.Open()
            COM = New MySqlCommand(strSQL, conec)
            REA = COM.ExecuteReader

            If REA.HasRows Then
                tbl.CONEXION = strConexion
                Do While REA.Read

                    If REA.GetInt32("estado") <> 0 Then
                        strRef = "***** AGREGADO *****" & vbCrLf & "Fecha: " & cfun.HoyMySQL & vbCrLf & "Usuario: SGI" & vbCrLf & "Cliente: " & REA.GetString("cliente") & vbCrLf & "Cantidad: " & REA.GetDouble("cantidad").ToString(FORMATO_MONEDA)
                        tbl.ID_EMPRESA = Sesion.IdEmpresa
                        tbl.DOC_TIPO = 47
                        tbl.DOC_CICLO = celdaAnio.Text
                        tbl.DOC_NUM = celdaNumero.Text
                        tbl.DOC_LIN = REA.GetInt32("linea")
                        tbl.LINEA = 1
                        tbl.ID_ENTIDAD = If(Len(REA.GetInt32("idCliente") > 0), REA.GetInt32("idCliente"), 0)
                        tbl.NOMBRE = REA.GetString("cliente")
                        tbl.CANTIDAD = REA.GetDouble("cantidad")
                        tbl.NOTA = ""
                        tbl.marca_NET = cfun.HoyMySQL
                        tbl.REFERENCIA = strRef
                        tbl.ESTADO = INT_CERO
                        tbl.USUARIO = "SGI"

                        If Me.Tag = "Nuevo" Then
                            If tbl.PINSERT() = False Then
                                MsgBox(tbl.MERROR.ToString & "The reservation has not been saved", MsgBoxStyle.Critical)
                            End If
                        End If
                    End If
                Loop
            End If
            conec.Close()
            REA.Close()
            REA = Nothing
            COM = Nothing
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try

    End Sub

    Private Function SQLGuardarReserva()
        Dim strSQL As String = STR_VACIO

        strSQL = " SELECT dl.DDoc_RF1_Num estado, dl.DDoc_Doc_Lin linea, dl.DDoc_RF2_Cod cliente, dl.DDoc_RF3_Num idCliente, dl.DDoc_Prd_QTY cantidad FROM Dcmtos_HDR h "
        strSQL &= "    Left JOIN Dcmtos_DTL tl ON tl.DDoc_Sis_Emp = h.HDoc_Sis_Emp AND tl.DDoc_Doc_Cat = h.HDoc_Doc_Cat AND tl.DDoc_Doc_Ano = h.HDoc_Doc_Ano AND tl.DDoc_Doc_Num = h.HDoc_Doc_Num "
        strSQL &= "    Left JOIN Dcmtos_DTL_Pro p ON p.PDoc_Sis_Emp = tl.DDoc_Sis_Emp AND p.PDoc_Chi_Cat = tl.DDoc_Doc_Cat AND p.PDoc_Chi_Ano = tl.DDoc_Doc_Ano AND p.PDoc_Chi_Num = tl.DDoc_Doc_Num AND p.PDoc_Chi_Lin = tl.DDoc_Doc_Lin AND p.PDoc_Par_Cat = 180 "
        strSQL &= "    Left JOIN Dcmtos_DTL_Pro p1 ON p1.PDoc_Sis_Emp = p.PDoc_Sis_Emp AND p1.PDoc_Chi_Cat = p.PDoc_Par_Cat AND p1.PDoc_Chi_Ano = p.PDoc_Par_Ano AND p1.PDoc_Chi_Num = p.PDoc_Par_Num AND p1.PDoc_Chi_Lin = p.PDoc_Par_Lin AND p1.PDoc_Par_Cat = 55 "
        strSQL &= "    Left JOIN Dcmtos_DTL_Pro p2 ON p2.PDoc_Sis_Emp = p1.PDoc_Sis_Emp AND p2.PDoc_Chi_Cat = p1.PDoc_Par_Cat AND p2.PDoc_Chi_Ano = p1.PDoc_Par_Ano AND p2.PDoc_Chi_Num = p1.PDoc_Par_Num AND p2.PDoc_Chi_Lin = p1.PDoc_Par_Lin AND p2.PDoc_Par_Cat = 127 "
        strSQL &= "    Left JOIN Dcmtos_DTL dl ON dl.DDoc_Sis_Emp = p2.PDoc_Sis_Emp AND dl.DDoc_Doc_Cat = p2.PDoc_Par_Cat AND dl.DDoc_Doc_Ano = p2.PDoc_Par_Ano AND dl.DDoc_Doc_Num = p2.PDoc_Par_Num AND dl.DDoc_Doc_Lin = p2.PDoc_Par_Lin "
        strSQL &= "        WHERE h.HDoc_Sis_Emp = {emp} AND h.HDoc_Doc_Cat = 47 AND h.HDoc_Doc_Ano = {anio} AND h.HDoc_Doc_Num = {num} "

        strSQL = Replace(strSQL, "{emp}", Sesion.IdEmpresa)
        strSQL = Replace(strSQL, "{anio}", celdaAnio.Text)
        strSQL = Replace(strSQL, "{num}", celdaNumero.Text)

        Return strSQL
    End Function
    Private Function GuardarExistencia() As Boolean
        Dim logResultado As Boolean = True
        Dim i As Integer = vbEmpty
        Dim strSQL As String = STR_VACIO
        Dim REA As MySqlDataReader
        Dim COM As MySqlCommand
        Dim Exis As New Tablas.TEXISTENCIA
        Dim j As Integer = 0

        For i = 0 To dgDetalle.Rows.Count - 1
            strSQL = "SELECT ("
            strSQL &= "  SELECT (IFNULL(MAX(Ex_Id),0) + 1) ID"
            strSQL &= "         FROM Existencia) ID, inv_artcodigo Articulo, inv_lugarfab Pais, inv_prodlote Lote, inv_prodano Ciclo, inv_prodsem Semana"
            strSQL &= "       FROM Inventarios"
            strSQL &= "     WHERE inv_sisemp = {empresa} AND inv_numero = {numero}"
            strSQL &= " LIMIT 1"

            strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
            strSQL = Replace(strSQL, "{numero}", dgDetalle.Rows(i).Cells("colCodigo").Value)

            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSQL, CON)
            REA = COM.ExecuteReader

            Try
                Exis.CONEXION = strConexion
                Do While REA.Read
                    Exis.EX_DOC_EMP = celdaEmpresa.Text
                    Exis.EX_DOC_TIPO = 47
                    Exis.EX_DOC_CICLO = celdaAnio.Text
                    Exis.EX_DOC_NUM = celdaNumero.Text
                    Exis.Ex_Doc_Fec_NET = dtpFech.Value
                    If dgDetalle.Rows(i).Visible = True Then
                        j = j + 1
                    End If
                    Exis.EX_DOC_LIN = j

                    'Exis.EX_DOC_LIN = i + 1
                    Exis.Ex_Fec_NET = dtpFech.Value
                    Exis.EX_ID = REA.GetInt32("ID")
                    Exis.EX_ARTICULO = REA.GetInt32("Articulo")
                    Exis.EX_CODIGO = dgDetalle.Rows(i).Cells("colCodigo").Value
                    Exis.EX_DESCRIPCION = dgDetalle.Rows(i).Cells("colArticulo").Value
                    Exis.EX_PAIS = REA.GetInt32("Pais")
                    Exis.EX_REFERENCIA = celdaRefFactura.Text
                    Exis.EX_LOTE = REA.GetString("Lote")
                    Exis.EX_CICLO = REA.GetInt32("Ciclo")
                    Exis.EX_SEMANA = REA.GetInt32("Semana")
                    Exis.EX_UM = dgDetalle.Rows(i).Cells("colIDMedida").Value
                    Exis.EX_INGRESO = dgDetalle.Rows(i).Cells("colCantidad").Value
                    Exis.EX_EGRESO = vbEmpty
                    Exis.EX_BULTOS = dgDetalle.Rows(i).Cells("colBultos").Value
                    Exis.EX_MONEDA = celdaIDMoneda.Text
                    Exis.EX_TC = celdaTasa.Text
                    Exis.EX_COSTO = dgDetalle.Rows(i).Cells("colPrecio").Value
                    Exis.EX_TOTAL = (dgDetalle.Rows(i).Cells("colPrecio").Value * dgDetalle.Rows(i).Cells("colCantidad").Value)

                    If dgDetalle.Rows(i).Cells("colAgregar").Value = 0 Then
                        If logEditar = True Then
                            If Exis.PUPDATE = False Then
                                MsgBox(Exis.MERROR.ToString & "Could not update the document", MsgBoxStyle.Critical)
                            End If
                        Else
                            MsgBox("You do not have access to save a new revenue from goods to warehouse", vbInformation)
                        End If
                    ElseIf dgDetalle.Rows(i).Cells("colAgregar").Value = 1 Then
                        If logInsertar = True Then
                            If Exis.PINSERT = False Then
                                MsgBox(Exis.MERROR.ToString & "Could not save the document", MsgBoxStyle.Critical)
                            End If
                        Else
                            MsgBox("You do not have access to save a new revenue from goods to warehouse", vbInformation)
                        End If
                    ElseIf dgDetalle.Rows(i).Cells("colAgregar").Value = 2 Then
                        If Me.Tag = "Mod" Then

                            If Exis.PDELETE = False Then
                                MsgBox("You do not have access to save a new revenue from goods to warehouse", vbInformation)
                            End If
                        End If
                    End If
                Loop
                REA.Close()
                REA = Nothing

            Catch ex As Exception
                MsgBox(ex.ToString)
            End Try
        Next
        Return logResultado
    End Function

    Private Sub ComprobarDatos()
        Dim i As Integer = vbEmpty
        Dim cuentaLineas As Integer = 0

        If celdaEmpresa.Text = vbNullString And celdaCatalogo.Text = vbNullString And celdaUsuario.Text = vbNullString Then
            MsgBox("Datos de Sistema Incompletos", vbCritical)
            Exit Sub
        End If

        If celdaAnio.Text = STR_VACIO Or
           celdaNumero.Text = STR_VACIO Or
           celdaCliente.Text = vbNullString Or
           celdaIDCliente.Text = STR_VACIO Or
           celdaMoneda.Text = vbNullString Or
           celdaIDMoneda.Text = STR_VACIO Or
           celdaTasa.Text = STR_VACIO Then
            MsgBox("Debe ingresar todos los datos minimos", vbCritical)
            Exit Sub
        End If

        If Not celdaAnio.Text = Year(dtpFech.Value) Then
            MsgBox("La fecha ingresada no coincide con el año del documento", vbExclamation, "Aviso")
        End If
        If Not intTipo >= 2 Then
            If dgPolizasImportacion.Rows.Count > 1 Then
                For j As Integer = 0 To dgPolizasImportacion.Rows.Count - 1
                    If dgPolizasImportacion.Rows(j).Visible = True Then
                        cuentaLineas = cuentaLineas + 1
                    End If
                Next
                If cuentaLineas > 1 Then
                    MsgBox("No se admite mas de un documento de referencia.", vbExclamation)
                    Exit Sub
                End If
            End If
        End If
        'Verifica Datos en el DETALLE.
        For i = vbEmpty To dgDetalle.Rows.Count - 1

        Next

        'Verifica que total > 0
        CalcularTotales()

    End Sub

    Private Function ComprobarFilas() As Boolean
        Dim i As Integer = vbEmpty
        Dim Comprobacion As Boolean = True

        For i = 0 To dgDetalle.Rows.Count - 1

            If dgDetalle.Rows(i).Cells("colAgregar").Value = 1 Then

                If dgDetalle.Rows(i).Cells("colCodigo").Value = vbNullString Then
                    Comprobacion = False
                    MsgBox("Article code invalid")
                End If
                If dgDetalle.Rows(i).Cells("colArticulo").Value = vbNullString Then
                    Comprobacion = False
                    MsgBox("Item Descripcion is Invalid")
                End If
                If dgDetalle.Rows(i).Cells("colPrecio").Value = NO_FILA Then
                    Comprobacion = False
                    MsgBox("Item Price is invalid")
                End If
                If dgDetalle.Rows(i).Cells("colCantidad").Value = NO_FILA Then
                    Comprobacion = False
                    MsgBox("Item Quantity is invalid")
                End If
                If dgDetalle.Rows(i).Cells("colBultos").Value = vbNullString Then
                    Comprobacion = False
                    MsgBox("Packages Quantity is Invalid")
                End If
            End If

        Next
        Return Comprobacion
    End Function

    Private Sub ImportarInfoReferencia()
        If dgPolizasImportacion.Rows.Count > 0 Then
            Dim strSQL As String = STR_VACIO
            Dim REA As MySqlDataReader
            Dim COM As MySqlCommand

            strSQL = "SELECT HDoc_DR1_Num, HDoc_DR2_Num, HDoc_RF2_Txt, HDoc_RF1_Txt, HDoc_RF1_Dbl, HDoc_RF2_Dbl"
            strSQL &= "      FROM Dcmtos_HDR"
            strSQL &= "          WHERE HDoc_Sis_Emp = {empresa} AND HDoc_Doc_Cat = 180 AND HDoc_Doc_Ano = {anio} AND HDoc_Doc_Num = {numero} and HDoc_Doc_Fec<='{fechaFiltro}'"

            strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
            strSQL = Replace(strSQL, "{anio}", dgPolizasImportacion.CurrentRow.Cells(4).Value)
            strSQL = Replace(strSQL, "{numero}", dgPolizasImportacion.CurrentRow.Cells(0).Value)
            strSQL = Replace(strSQL, "{fechaFiltro}", dtpFech.Value.ToString(FORMATO_MYSQL))

            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSQL, CON)
            REA = COM.ExecuteReader
            Do While REA.Read

                celdaRefFactura.Text = REA.GetString("HDoc_DR1_Num")
                celdaRef1.Text = REA.GetString("HDoc_DR2_Num")
                celdaRef2.Text = REA.GetString("HDoc_RF2_Txt")
            Loop
        End If
    End Sub

    Private Function ValidarReferencias() As Boolean

        If (intTipo = vbEmpty) And (intMultiple = vbEmpty) Then

            'Importación
            ValidarReferencias = True
        Else
            'Devolución
            If celdaRefFactura.Text = vbNullString Or celdaRef1.Text = vbNullString Then
                MsgBox("Debe ingresar al menos dos Referencias Validas", vbExclamation, "Note")
            ElseIf intTipo = 2 And celdaRef2.Text = vbNullString Then
                MsgBox("No ha ingresado el numero de transferencia", vbExclamation, "Note")
            Else
                ValidarReferencias = True
            End If
        End If
        Return ValidarReferencias
    End Function

    Private Function PedirComentario() As String
        Dim strTemp As String = STR_VACIO
        Dim frm As New frmPedirComentarios
        Dim strSQL As String = STR_VACIO
        Dim COM As MySqlCommand


        frm.Text = "ANNOTATIONS"
        If dgDetalle.CurrentRow.Cells(14).Value = vbNullString Then
        Else
            frm.celdaInfo.Text = dgDetalle.CurrentRow.Cells(14).Value
        End If
        frm.ShowDialog(Me)

        If frm.Aceptado Then
            strTemp = frm.celdaInfo.Text

            PedirComentario = strTemp


            If Me.Tag = "Mod" Then
                strSQL = "UPDATE Dcmtos_DTL "
                strSQL &= "      SET DDOC_RF1_TXT = '{strTemp}' "
                strSQL &= "         WHERE DDoc_Sis_Emp = {empresa} and DDoc_Doc_Cat = 47 and DDoc_Doc_Ano = {anio} and DDoc_Doc_Num = {numero} and DDoc_Doc_Lin = {lin}"

                If Sesion.IdEmpresa = 18 Then
                    strSQL &= ";UPDATE PDM.Dcmtos_DTL "
                    strSQL &= "      SET DDOC_RF1_TXT = '{strTemp}' "
                    strSQL &= "         WHERE DDoc_Sis_Emp = {empresa} and DDoc_Doc_Cat = 47 and DDoc_Doc_Ano = {anio} and DDoc_Doc_Num = {numero} and DDoc_Doc_Lin = {lin}"
                End If

                strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
                strSQL = Replace(strSQL, "{anio}", celdaAnio.Text)
                strSQL = Replace(strSQL, "{numero}", celdaNumero.Text)
                strSQL = Replace(strSQL, "{strTemp}", strTemp)
                strSQL = Replace(strSQL, "{lin}", dgDetalle.CurrentRow.Cells(19).Value)
                'Ejecuta la instrucción
                MyCnn.CONECTAR = strConexion
                COM = New MySqlCommand(strSQL, CON)
                COM.ExecuteNonQuery()
            End If

            dgDetalle.CurrentRow.Cells("colReserva").Value = strTemp


            If Me.Tag = "Mod" Then
                MsgBox("The annotation has been saved " & vbCr & vbCr & "NOTE: It is not necessary to save the document", vbInformation, "Notice")
            End If
        End If

    End Function

    Private Sub TraerProduccion()
        Dim strSQL As String = STR_VACIO
        Dim strFila As String = STR_VACIO
        Dim frm As New frmSeleccionar
        Dim strCondicion As String = STR_VACIO
        Dim intAnio As Integer
        Dim intNumero As Integer

        Try
            strCondicion = "h.HDoc_Sis_Emp = {empresa} AND h.HDoc_Doc_Cat = 952 AND h.HDoc_Doc_Ano = {anio} AND h.HDoc_Pro_DNum = 1 and h.HDoc_Doc_Status = 1 having Balance>0"
            strCondicion = Replace(strCondicion, "{empresa}", Sesion.IdEmpresa)
            strCondicion = Replace(strCondicion, "{anio}", celdaAnio.Text)

            frm.Titulo = "  Production Phase II"
            frm.Campos = " h.HDoc_Doc_Num Number, h.HDoc_Doc_Fec Date, h.HDoc_Usuario User, h.HDoc_DR1_Num Reference, h.HDoc_Doc_Ano Year," &
                         "   (SELECT  IFNULL(SUM(IFNULL(d.DDoc_RF1_Dbl,0) - IFNULL(dd.DDoc_Prd_QTY,0) ),0)  saldo FROM Dcmtos_DTL d" &
                         "      LEFT JOIN Dcmtos_DTL_Pro p ON p.PDoc_Sis_Emp = d.DDoc_Sis_Emp AND p.PDoc_Par_Cat = d.DDoc_Doc_Cat AND p.PDoc_Par_Ano =d.DDoc_Doc_Ano AND p.PDoc_Par_Num =d.DDoc_Doc_Num and p.PDoc_Par_Lin = d.DDoc_Doc_Lin " &
                         "          LEFT JOIN Dcmtos_DTL dd ON dd.DDoc_Sis_Emp = p.PDoc_Sis_Emp AND dd.DDoc_Doc_Cat = p.PDoc_Chi_Cat AND dd.DDoc_Doc_Ano = p.PDoc_Chi_Ano AND dd.DDoc_Doc_Num = p.PDoc_Chi_Num AND dd.DDoc_Doc_Lin = p.PDoc_Chi_Lin " &
                         "              WHERE d.DDoc_Sis_Emp = h.HDoc_Sis_Emp  AND d.DDoc_Doc_Cat = h.HDoc_Doc_Cat  AND d.DDoc_Doc_Ano = h.HDoc_Doc_Ano  AND d.DDoc_Doc_Num = h.HDoc_Doc_Num ) Balance"
            frm.Tabla = " Dcmtos_HDR h"
            frm.FiltroText = " Enter the Number ProductioN to filter"
            frm.Filtro = "  h.HDoc_Doc_Num"
            frm.Limite = 30
            frm.Ordenamiento = " h.HDoc_Doc_Num "
            frm.TipoOrdenamiento = ""
            frm.Condicion = strCondicion

            frm.ShowDialog(Me)
            If frm.DialogResult = DialogResult.OK Then
                strFila = frm.LLave & "|"
                strFila &= frm.Dato & "|"
                strFila &= frm.Dato2 & "|"
                strFila &= frm.Dato3 & "|"
                strFila &= frm.Dato4 & "|"
                strFila &= 952 & "|"
                strFila &= 0

                intAnio = frm.Dato4
                intNumero = frm.LLave
                cFunciones.AgregarFila(dgPolizasImportacion, strFila)
            End If

            'Jala el detalle de la produccion seleccionada
            ProcesarDetalleProduccion(intAnio, intNumero)

            CalcularTotales()
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try


    End Sub

    Private Sub ProcesarDetalleProduccion(ByVal intanio As Integer, ByVal intNumero As Integer)
        Dim strSQL As String = STR_VACIO
        Dim strFila As String = STR_VACIO
        Dim REA As MySqlDataReader
        Dim COM As MySqlCommand
        Dim dblPrecio As Double
        Dim dblCantidad As Double
        Dim SubTotal As Double
        Dim i As Integer = INT_CERO

        strSQL = "SELECT h.HDoc_Sis_Emp empresa, h.HDoc_Doc_Cat catalogo, h.HDoc_Doc_Ano anio, h.HDoc_Doc_Num numero, h.HDoc_Usuario usuario, d.DDoc_Doc_Lin linea, d.DDoc_Prd_Cod codigo, d.DDoc_Prd_Des descripcion, d.DDoc_Prd_UM IDMedida, d.DDoc_Prd_PUQ, d.DDoc_Prd_NET precio, d.DDoc_Prd_QTY cantidadProcesar, d.DDoc_RF1_Cod referencia, d.DDoc_RF1_Dbl Cantidad, c.cat_Clave medida"
        strSQL &= "     FROM Dcmtos_DTL d"
        strSQL &= "          INNER JOIN Dcmtos_HDR h ON h.HDoc_Sis_Emp = d.DDoc_Sis_Emp AND h.HDoc_Doc_Cat = d.DDoc_Doc_Cat AND h.HDoc_Doc_Ano = d.DDoc_Doc_Ano AND h.HDoc_Doc_Num = d.DDoc_Doc_Num"
        strSQL &= "              INNER JOIN Catalogos c ON d.DDoc_Prd_UM = c.cat_num"
        strSQL &= "      WHERE d.DDoc_Sis_Emp = {empresa} AND d.DDoc_Doc_Cat = 952 AND d.DDoc_Doc_Ano = {anio} AND d.DDoc_Doc_Num = {numero}"

        strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
        strSQL = Replace(strSQL, "{anio}", intanio)
        strSQL = Replace(strSQL, "{numero}", intNumero)

        MyCnn.CONECTAR = strConexion
        COM = New MySqlCommand(strSQL, CON)
        REA = COM.ExecuteReader

        If REA.HasRows Then
            Do While REA.Read

                dblPrecio = REA.GetDouble("precio")
                dblCantidad = REA.GetDouble("Cantidad")
                SubTotal = (dblPrecio * dblCantidad)
                i = i + 1

                strFila = REA.GetInt32("codigo") & "|"
                strFila &= REA.GetString("descripcion") & "|"
                strFila &= REA.GetInt32("IDMedida") & "|"
                strFila &= REA.GetString("medida") & "|"
                strFila &= dblPrecio.ToString(FORMATO_MONEDA) & "|"
                strFila &= 0 & "|"
                strFila &= 0 & "|"
                strFila &= dblCantidad & "|"
                strFila &= 1 & "|"
                strFila &= SubTotal.ToString(FORMATO_MONEDA) & "|"
                strFila &= vbNullString & "|" 'Bodega
                strFila &= vbNullString & "|" 'Reserva(Texto)
                strFila &= vbNullString & "|" 'Problema
                strFila &= vbNullString & "|" 'Comentario
                'Catidad Original
                strFila &= dblCantidad & "|"
                'Codigo Original
                strFila &= REA.GetInt32("codigo") & "|"
                strFila &= vbNullString & "|"
                strFila &= 0 & "|"
                strFila &= i & "|"
                strFila &= vbNullString & "|"
                strFila &= vbNullString & "|"
                strFila &= 0 & "|"
                strFila &= 1 & "|"
                strFila &= 1 & "|"
                strFila &= REA.GetInt32("empresa") & "|"
                strFila &= REA.GetInt32("anio") & "|"
                strFila &= REA.GetInt32("numero") & "|"
                strFila &= REA.GetInt32("linea")

                cFunciones.AgregarFila(dgDetalle, strFila)

            Loop
        End If
    End Sub

    Private Function ObtenerNumero(ByVal intAnio As Integer)
        Dim strSQL As String = STR_VACIO
        Dim COM As MySqlCommand
        Dim conec As MySqlConnection
        Dim Numero As Integer

        strSQL = "SELECT MAX(h.HDoc_Doc_Num) MaxNum "
        strSQL &= "FROM Dcmtos_HDR h "
        strSQL &= "WHERE h.HDoc_Sis_Emp = {empresa} and h.HDoc_Doc_Cat = 47 and h.HDoc_Doc_Ano = {anio}"

        strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
        strSQL = Replace(strSQL, "{anio}", intAnio)

        conec = New MySqlConnection(strConexion)
        conec.Open()
        COM = New MySqlCommand(strSQL, conec)
        Numero = COM.ExecuteScalar()
        conec.Close()

        Return Numero
    End Function

    Public Sub InsertPacas(ByVal directorio As String)
        Dim docReader As New StreamReader(directorio)
        Dim docReader2 As New StreamReader(directorio)
        Dim linea As String = ""
        Dim linea2 As String = ""
        Dim arrayText As New ArrayList
        Dim i As Integer = 0
        Dim tb_Box As New Tablas.TDCMTOS_DTL_BOX
        Dim temp As String      'correlativo HSM
        Dim temp1 As String   ' categoria 
        Dim temp2 As Double 'peso packing
        Dim temp3 As Double 'peso HSM
        Dim temp4 As Double ' tara
        Dim temp5 As String ' GIN
        Dim temp6 As String ' Gin Bac
        Dim temp7 As String ' CRP
        Dim temp8 As String  'Referencia
        Dim CantLinea As Integer
        Dim categoria As String = STR_VACIO
        Dim strSQL As String = STR_VACIO
        Dim COM As MySqlCommand
        Dim cuentabultos As Integer = 0
        Dim SumaPesos As Double = 0
        Dim SumaPesoNeto As Double = 0
        Dim subtotal As Double = 0
        Dim celdaSubT As Double = 0
        Dim celdaTotall As Double = 0
        Dim validarGuardado As Boolean = True
        Dim SumaTara As Double = 0
        Dim DifLbs As Double = 0
        Dim SumaProdTerminado As Double = 0

        Try

            Do
                temp = 0
                temp1 = vbNullString
                temp2 = 0
                temp3 = 0
                temp4 = 0
                temp5 = vbNullString
                temp6 = vbNullString
                temp7 = vbNullString
                temp8 = vbNullString
                linea = docReader.ReadLine
                If Not linea Is Nothing Then
                    arrayText.Add(linea)
                    If i <> 0 Then
                        Dim DesArray = linea.Split(",")
                        If DesArray(0).LongCount > 1 Then
                            temp = CStr(DesArray(1))
                            temp1 = CStr(DesArray(2))
                            temp2 = CDbl(DesArray(3))
                            temp3 = CDbl(DesArray(4))
                            temp4 = CDbl(DesArray(5))
                            temp5 = CStr(DesArray(6))
                            temp6 = CStr(DesArray(7))
                            temp7 = CStr(DesArray(8))
                            temp8 = CStr(DesArray(9))
                            CantLinea = CantLinea + 1

                            SumaTara = SumaTara + CDbl(DesArray(5))
                            SumaPesos = SumaPesos + CDbl(DesArray(3))
                            cuentabultos = cuentabultos + 1
                            SumaProdTerminado = SumaProdTerminado + CDbl(DesArray(4))

                        Else
                            Exit Sub
                        End If
                    End If

                    i = i + 1
                Else
                    Exit Do
                End If
            Loop Until linea Is Nothing
            docReader.Close()
        Catch ex As Exception
            MsgBox("The file has errors, please check the line " & CInt(CantLinea + 1), vbCritical, "Notice")
            Exit Sub
        End Try

        i = 0
        CantLinea = 0

        Try
            If celdaTipoIngreso.Text = 1 Then
                SumaPesoNeto = (SumaProdTerminado)
            Else
                SumaPesoNeto = (SumaProdTerminado) - (SumaTara)
            End If

            If (dgDetalle.CurrentRow.Cells("colCantidad").Value = SumaPesoNeto) Then ' Verifica que la cantidad ingresada en detalle sea la misma que suman las pacas

            Else
                DifLbs = dgDetalle.CurrentRow.Cells("colCantidad").Value - SumaPesoNeto
                If MsgBox("The pounds quantity in this document doesn't match with de bales' weight loaded in the File. Do you want continue anyway?" & vbCrLf & vbCrLf & "Document: " & dgDetalle.CurrentRow.Cells("colCantidad").Value & vbCrLf & "File: " & SumaPesoNeto & vbCrLf & vbCrLf & "Difence: " & DifLbs & " Lbs", vbOKCancel + vbInformation, "Notice") = vbOK Then
                Else
                    validarGuardado = False
                End If
            End If

            If validarGuardado = True Then
                If dgDetalle.CurrentRow.Cells("colBultos").Value = cuentabultos Then ' verifica que el numero de bultos ingresados en detalle sea lo mismo que el documento que se sube
                Else
                    If MsgBox("The bales' number in this document doesn't match with de bales' number loaded in the File. Do you want continue anyway?", vbOKCancel + vbInformation, "Notice") = vbOK Then
                    Else
                        validarGuardado = False
                    End If
                End If

            End If
            If validarGuardado = True Then

                Dim dtlBox As New Tablas.TDCMTOS_DTL_BOX
                dtlBox.CONEXION = strConexion
                Dim condicion = "BDoc_Sis_Emp = {empresa} AND BDoc_Doc_Cat = {cata} AND BDoc_Doc_Ano = {anio} AND BDoc_Doc_Num = {num} AND BDoc_Doc_Lin = {linea} "
                condicion = Replace(condicion, "{empresa}", Sesion.IdEmpresa)
                condicion = Replace(condicion, "{anio}", celdaAnio.Text)
                condicion = Replace(condicion, "{cata}", CATALOGO)
                condicion = Replace(condicion, "{num}", celdaNumero.Text)
                condicion = Replace(condicion, "{linea}", dgDetalle.CurrentRow.Cells("colLinea").Value)
                dtlBox.PDELETE(condicion)

                tb_Box.CONEXION = strConexion
                cuentabultos = 0
                Do

                    linea2 = docReader2.ReadLine
                    If Not linea2 Is Nothing Then
                        arrayText.Add(linea2)
                        If i > 0 Then
                            Dim DesArray2 = linea2.Split(",")

                            tb_Box.BDOC_SIS_EMP = Sesion.IdEmpresa
                            tb_Box.BDOC_DOC_CAT = 47
                            tb_Box.BDOC_DOC_ANO = celdaAnio.Text
                            tb_Box.BDOC_DOC_NUM = celdaNumero.Text
                            tb_Box.BDOC_DOC_LIN = dgDetalle.CurrentRow.Cells("colLinea").Value
                            tb_Box.BDOC_BOX_LIN = i
                            tb_Box.BDOC_BOX_HSM = DesArray2(1) 'Correlativo HSM
                            categoria = Replace(DesArray2(2), Chr(34), vbNullString) ' categoria asignado por el sistema de algodon
                            tb_Box.BDOC_BOX_CTG = categoria ' categoria
                            tb_Box.BDOC_BOX_COD = DesArray2(0) 'Marca
                            tb_Box.BDOC_BOX_ORD = DesArray2(5) ' tara
                            tb_Box.BDOC_BOX_QTY = 1
                            tb_Box.BDOC_BOX_LB = DesArray2(4) ' Peso HSM
                            tb_Box.BDOC_BOX_LBEXT = DesArray2(3) 'peso de packing
                            tb_Box.BDOC_BOX_GIN = DesArray2(6) ' Gin
                            tb_Box.BDOC_BOX_GBAC = DesArray2(7) ' Gin Bac
                            tb_Box.BDOC_BOX_CRP = DesArray2(8) ' Crp
                            tb_Box.BDOC_BOX_REF = DesArray2(9) ' Referencia

                            cuentabultos = cuentabultos + 1
                            SumaPesos = SumaPesos + DesArray2(3)

                            If tb_Box.PINSERT = False Then
                                MsgBox(tb_Box.MERROR.ToString & "Could not save the document", MsgBoxStyle.Critical)
                            End If
                        End If
                        i = i + 1
                    End If
                Loop Until linea2 Is Nothing
                docReader2.Close()
                MsgBox("Bales stored correctly", vbInformation, "Notice")

                dgDetalle.CurrentRow.Cells("colCantidad").Value = Math.Round(SumaPesoNeto, 2)
                dgDetalle.CurrentRow.Cells("colBultos").Value = cuentabultos
                subtotal = (dgDetalle.CurrentRow.Cells("colSubtotal").Value / dgDetalle.CurrentRow.Cells("colCantidad").Value)
                dgDetalle.CurrentRow.Cells("colPrecio").Value = Math.Round(subtotal, 7)

                For k As Integer = 0 To dgDescargos.Rows.Count - 1
                    celdaSubT = dgDetalle.CurrentRow.Cells("colCantidad").Value
                    celdaTotall = dgDetalle.CurrentRow.Cells("colSubtotal").Value
                Next
                CalcularTotales()
                'celdaSubTotal.Text = celdaSubT
                'celdaTotal.Text = celdaTotall

                dgOculto.Rows.Clear()
                GuardarDetalle()
                queryCargarCajas()
                MostrarLista(False)

            Else
                MsgBox("The bales were not saved", vbInformation, "Notice")
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try

    End Sub
    Private Function DependeciasIngreso() As Integer
        Dim intValidacion As Integer
        Dim COM As MySqlCommand
        Dim conec As MySqlConnection
        Dim strSQL As String = STR_VACIO
        Try
            strSQL = "  SELECT COUNT(*) "
            strSQL &= "    	FROM Dcmtos_DTL_Pro p "
            strSQL &= "         WHERE p.PDoc_Sis_Emp = {empresa} AND p.PDoc_Par_Cat = 47 AND p.PDoc_Par_Ano = {anio} AND p.PDoc_Par_Num = {numero}   "
            strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
            strSQL = Replace(strSQL, "{anio}", celdaAnio.Text)
            strSQL = Replace(strSQL, "{numero}", celdaNumero.Text)
            conec = New MySqlConnection(strConexion)
            conec.Open()
            COM = New MySqlCommand(strSQL, conec)
            Using conec
                intValidacion = COM.ExecuteScalar
                COM.Dispose()
                COM = Nothing
                conec.Close()
                conec.Dispose()
                conec = Nothing
                System.GC.Collect()
            End Using
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        Return intValidacion
    End Function
    'Borrar Encabezado Ingreso
    Public Function BorrarEncabezadoIngreso() As Boolean
        Dim logGuardar As Boolean
        Dim chdr As New clsDcmtos_HDR
        Try
            chdr.CONEXION = strConexion

            chdr.HDOC_SIS_EMP = Sesion.IdEmpresa
            chdr.HDOC_DOC_CAT = CATALOGO
            chdr.HDOC_DOC_ANO = celdaAnio.Text
            chdr.HDOC_DOC_NUM = celdaNumero.Text

            logGuardar = chdr.Borrar()
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        Return logGuardar
    End Function
    ' Borrar Detalle Ingreso
    Private Function BorrarDetalleIngreso() As Boolean
        Dim logGuardar As Boolean
        Try
            If LogBorrar = True Then
                For i = 0 To dgDetalle.Rows.Count - 1
                    Dim Dtl As New clsDcmtos_DTL
                    Dtl.CONEXION = strConexion

                    Dtl.DDOC_SIS_EMP = Sesion.IdEmpresa
                    Dtl.DDOC_DOC_CAT = CATALOGO
                    Dtl.DDOC_DOC_ANO = celdaAnio.Text
                    Dtl.DDOC_DOC_NUM = celdaNumero.Text
                    Dtl.DDOC_DOC_LIN = dgDetalle.Rows(i).Cells("colLinea").Value
                    Dtl.Borrar()
                Next
                logGuardar = True
            Else
                MsgBox("You don't have permission to this access")
                logGuardar = False
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        Return logGuardar
    End Function
    'BorrarDetalleLotes NO SE USA
    Private Function BorrarDetalleLotes() As Boolean
        Dim logGuardar As Boolean
        Dim strSQL As String = STR_VACIO
        Dim COM As MySqlCommand
        Try
            If LogBorrar = True Then
                strSQL = "  DELETE FROM Dcmtos_Box_Pro WHERE ADoc_Sis_Emp = {empresa} AND ADoc_Doc_Cat = 47 AND ADoc_Doc_Ano  = {anio}   AND ADoc_Doc_Num  = {numero}   "
                strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
                strSQL = Replace(strSQL, "{anio}", celdaAnio.Text)
                strSQL = Replace(strSQL, "{numero}", celdaNumero.Text)
                MyCnn.CONECTAR = strConexion
                COM = New MySqlCommand(strSQL, CON)
                COM.ExecuteNonQuery()
                logGuardar = True
            Else
                MsgBox("You don't have permission to this access")
                logGuardar = False
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        Return logGuardar
    End Function

    ' Borrar Acc Ingreso 
    Private Function BorrarAccIngreso() As Boolean
        Dim logGuardar As Boolean
        Try
            If LogBorrar = True Then
                Dim acc As New Tablas.TDCMTOS_ACC
                acc.CONEXION = strConexion
                Dim condicion As String = "ADoc_Sis_Emp = {empresa} AND ADoc_Doc_Cat = {cata} AND ADoc_Doc_Ano  = {anio}   AND ADoc_Doc_Num  = {numero}"
                condicion = Replace(condicion, "{empresa}", Sesion.IdEmpresa)
                condicion = Replace(condicion, "{anio}", celdaAnio.Text)
                condicion = Replace(condicion, "{cata}", CATALOGO)
                condicion = Replace(condicion, "{numero}", celdaNumero.Text)

                logGuardar = acc.PDELETE(condicion)
            Else
                MsgBox("You don't have permission to this access")
                logGuardar = False
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        Return logGuardar
    End Function
    'Borrar Descargo 
    Private Function BorrarDescargosIngreso() As Boolean
        Dim logGuardar As Boolean
        Try
            If LogBorrar = True Then
                Dim pro As New clsDcmtos_DTL_Pro
                pro.CONEXION = strConexion

                Dim condicion = "PDoc_Sis_Emp = {empresa} AND PDoc_Chi_Cat = {cata} AND PDoc_Chi_Ano  = {anio} AND PDoc_Chi_Num = {numero}  ;"
                condicion = Replace(condicion, "{empresa}", Sesion.IdEmpresa)
                condicion = Replace(condicion, "{anio}", celdaAnio.Text)
                condicion = Replace(condicion, "{cata}", CATALOGO)
                condicion = Replace(condicion, "{numero}", celdaNumero.Text)

                logGuardar = pro.Borrar(condicion)
            Else
                MsgBox("You don't have permission to this access")
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        Return logGuardar
    End Function
    Private Function BorrarBultosIngreso() As Boolean
        Dim logGuardar As Boolean
        Try
            If LogBorrar = True Then
                Dim dtlBox As New Tablas.TDCMTOS_DTL_BOX
                dtlBox.CONEXION = strConexion
                Dim condicion = "BDoc_Sis_Emp = {empresa} AND BDoc_Doc_Cat = {cata} AND BDoc_Doc_Ano  = {anio} AND BDoc_Doc_Num = {numero}  ;"
                condicion = Replace(condicion, "{empresa}", Sesion.IdEmpresa)
                condicion = Replace(condicion, "{anio}", celdaAnio.Text)
                condicion = Replace(condicion, "{cata}", CATALOGO)
                condicion = Replace(condicion, "{numero}", celdaNumero.Text)

                logGuardar = dtlBox.PDELETE(condicion)
            Else
                MsgBox("You don't have permission to this access")
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        Return logGuardar
    End Function
    Private Function BorrarExistencias() As Boolean
        Dim logGuardar As Boolean
        Try
            If LogBorrar = True Then
                Dim existencia As New Tablas.TEXISTENCIA
                existencia.CONEXION = strConexion
                Dim condicion = "Ex_Doc_Emp = {empresa} AND Ex_Doc_Tipo = {cata} AND Ex_Doc_Ciclo  = {anio} AND Ex_Doc_Num = {numero}  ;"
                condicion = Replace(condicion, "{empresa}", Sesion.IdEmpresa)
                condicion = Replace(condicion, "{anio}", celdaAnio.Text)
                condicion = Replace(condicion, "{cata}", CATALOGO)
                condicion = Replace(condicion, "{numero}", celdaNumero.Text)

                logGuardar = existencia.PDELETE(condicion)
            Else
                MsgBox("You don't have permission to this access")
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        Return logGuardar
    End Function

    Private Sub BorrarReservas()
        Try
            If LogBorrar = True Then
                Dim reserva As New Tablas.TRESERVA
                reserva.CONEXION = strConexion
                Dim condicion = "id_empresa = {empresa} AND doc_tipo = {cata} AND doc_ciclo  = {anio} AND doc_num = {numero}  ;"
                condicion = Replace(condicion, "{empresa}", Sesion.IdEmpresa)
                condicion = Replace(condicion, "{anio}", celdaAnio.Text)
                condicion = Replace(condicion, "{cata}", CATALOGO)
                condicion = Replace(condicion, "{numero}", celdaNumero.Text)
                reserva.PDELETE(condicion)

            Else
                MsgBox("You don't have permission to this access")
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try

    End Sub

    'Borrar Kardex
    Public Sub BorrarKardex()
        Try

            Dim k As New Tablas.TKARDEX
            k.CONEXION = strConexion

            Dim condicion = "Kar_Sis_Emp = {emp} AND Kar_Doc_Cat = {cata} AND Kar_Doc_Ano = {anio} AND Kar_Doc_Num = {num} "

            condicion = Replace(condicion, "{emp}", Sesion.IdEmpresa)
            condicion = Replace(condicion, "{anio}", celdaAnio.Text)
            condicion = Replace(condicion, "{cata}", CATALOGO)
            condicion = Replace(condicion, "{num}", celdaNumero.Text)

            k.PDELETE(condicion)

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Public Sub BloquearFel2()
        celdaAnio.Enabled = False
        celdaNumero.Enabled = False
        dtpFech.Enabled = False
        celdaDireccion.Enabled = False
        celdaMoneda.Enabled = False
        celdaTasa.Enabled = False
        gbPedidoClientes.Enabled = False
        gbInformación.Enabled = False
        panelDetalle.Enabled = True
        Panel1.Enabled = False
        dgSubdocumentos.Enabled = False
        Encabezado1.botonGuardar.Enabled = True
        'botonImprimir.Enabled = False
        ' Encabezado1.botonBorrar.Enabled = False

    End Sub

    Public Sub BloquearFel()
        celdaAnio.Enabled = False
        celdaNumero.Enabled = False
        dtpFech.Enabled = False
        celdaDireccion.Enabled = False
        celdaMoneda.Enabled = False
        celdaTasa.Enabled = False
        gbPedidoClientes.Enabled = False
        gbInformación.Enabled = False
        panelDetalle.Enabled = False
        Panel1.Enabled = False
        dgSubdocumentos.Enabled = False
        Encabezado1.botonGuardar.Enabled = False
        'Encabezado1.botonBorrar.Enabled = False
    End Sub
    Public Sub ActivarFel(Optional intfel As Integer = 0)
        celdaNumero.Enabled = True
        celdaAnio.Enabled = True
        celdaNumero.Enabled = True
        dtpFech.Enabled = True
        celdaDireccion.Enabled = True
        celdaMoneda.Enabled = True
        celdaTasa.Enabled = True
        gbPedidoClientes.Enabled = True
        gbInformación.Enabled = True
        If intfel = 1 Then
            panelDetalle.Enabled = False
        Else
            panelDetalle.Enabled = True
        End If
        Panel1.Enabled = True
        dgSubdocumentos.Enabled = True
        Encabezado1.botonGuardar.Enabled = True
        Encabezado1.botonBorrar.Enabled = True

    End Sub
    Public Sub CambioEstadoDetalle()
        For i As Integer = 0 To dgDetalle.Rows.Count - 1
            dgDetalle.Rows(i).Cells("colAgregar").Value = 0
        Next
    End Sub
    Public Sub CambioEstadoOculto()
        For i As Integer = 0 To dgOculto.Rows.Count - 1
            dgOculto.Rows(i).Cells("colXtraBox").Value = 1
        Next
    End Sub
#End Region

#Region "Eventos"

    Private Sub frmIngresoBodega_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        ' If (Sesion.IdEmpresa = 15) Or (Sesion.IdEmpresa = 18) Or (Sesion.IdEmpresa = 19) Or (Sesion.IdEmpresa = 20) Or (Sesion.IdEmpresa = 21) Then
        If Sesion.idGiro = 2 Then
            celdaTipoIng.Visible = True
        Else
            celdaTipoIng.Visible = True
        End If

        BotonImprimirRotulo.Visible = False
        dtpInicio.Value = DateSerial(Year(Date.Now), Month(Date.Now) - 1, 30)
        dtpFin.Value = DateSerial(Year(Date.Now), Month(Date.Now) + 1, vbEmpty)

        Accessos()
        MostrarLista()

    End Sub

    Private Sub Encabezado1_ClickNuevo(sender As Object, click As Boolean) Handles Encabezado1.ClickNuevo
        Dim selectFecha As New frmDateTimePicker
        Dim opt As New frmOption
        Dim opt2 As New frmOption
        Dim anio As Integer
        Dim numero As Integer
        Me.Tag = "Nuevo"
        Dim frm As New frmPackingDevoluciones

        If logInsertar = True Then
            opt.Titulo = "Option"
            opt.Mensaje = "Select an option"
            If Sesion.idGiro = 2 Then
                If Sesion.IdEmpresa = 22 Then
                    opt.Opciones = "Import Policies" & "|" & "Returns (exports)" & "|" & "Greige" & "|" & "Waste Material" & "|" & "Invisible" & "|" & "Process / Pallets" & "|" & "Return of Consumables" & "|" & "Free" & "|" & "Dyeing" & "|" & "Finishing" & "|" & "Rolling" & "|" & "Finish goods"
                Else
                    opt.Opciones = "Import Policies" & "|" & "Returns (exports)" & "|" & "Yarn Production" & "|" & "Waste Material" & "|" & "Invisible" & "|" & "Process / Pallets" & "|" & "Return of Consumables" & "|" & "Free"
                End If
                ' opt.Opciones = "Import Policies" & "|" & "Returns (exports)" & "|" & "Yarn Production" & "|" & "Waste Material" & "|" & "Invisible" & "|" & "Process / Pallets" & "|" & "Return of Consumables" & "|" & "Free"
                If opt.ShowDialog = System.Windows.Forms.DialogResult.OK Then

                    Select Case opt.Seleccion

                        Case 0
                            intTipo = 0 'Import Policies
                        Case 1
                            intTipo = 1 'Returns (exports)
                        Case 2
                            intTipo = 2  'inttipo = 2 Producto Terminado Plantas (NT - Greige), intTipo = 3 (Consumibles)
                        Case 3
                            intTipo = 4     'desperdicio
                        Case 4
                            intTipo = 5     'invisible
                        Case 5
                            intTipo = 6     ' Producto en proceso / pallets
                        Case 6
                            intTipo = 7 ' Devolución de consumibles
                        Case 7
                            intTipo = 8 ' Others
                        Case 8
                            intTipo = 14 ' Dyeing
                        Case 9
                            intTipo = 15 ' Finishing
                        Case 10
                            intTipo = 16 ' Rolling
                        Case 11
                            intTipo = 17 ' Finish goods
                    End Select
                Else
                    Exit Sub
                End If
                If intTipo = 8 Then

                    opt2.Titulo = "Option"
                    opt2.Mensaje = "Select an option"
                    opt2.Opciones = "2% inventory" & "|" & "Reusable Spare Parts" & "|" & "Partially Used Spare Parts" & "|" & "Guarantee revenue" & "|" & "Per contract" & "|" & "transit repairs"
                    If opt2.ShowDialog = Forms.DialogResult.OK Then

                        Select Case opt2.Seleccion

                            Case 0
                                intTipo = 8 ' 2%
                            Case 1
                                intTipo = 9 ' Reusable Spare Parts
                            Case 2
                                intTipo = 10 ' Partially Used Spare Parts
                            Case 3
                                intTipo = 11 ' Guarantee revenue
                            Case 4
                                intTipo = 12 ' Per contract
                            Case 5
                                intTipo = 13 ' Transito
                        End Select

                    Else
                        Exit Sub
                    End If
                ElseIf intTipo = 4 And Sesion.IdEmpresa = 22 Then
                    opt2.Titulo = "Option"
                    opt2.Mensaje = "Select an option"
                    opt2.Opciones = "Knniting - Greige" & "|" & "Finishing - Rolling" & "|" & "Rolling - Finish good"
                    If opt2.ShowDialog = Forms.DialogResult.OK Then

                        Select Case opt2.Seleccion
                            Case 0
                                intTipoWaste = 0
                            Case 1
                                intTipoWaste = 1
                            Case 2
                                intTipoWaste = 2
                        End Select
                    End If
                ElseIf intTipo = 5 And Sesion.IdEmpresa = 22 Then
                    opt2.Titulo = "Option"
                    opt2.Mensaje = "Select an option"
                    opt2.Opciones = "Knniting - Greige" & "|" & "Finishing - Rolling" & "|" & "Rolling - Finish good"
                    If opt2.ShowDialog = Forms.DialogResult.OK Then

                        Select Case opt2.Seleccion
                            Case 0
                                intTipoInvisible = 0
                            Case 1
                                intTipoInvisible = 1
                            Case 2
                                intTipoInvisible = 2
                        End Select
                    End If
                End If
            Else
                opt.Opciones = "Import Policies" & "|" & "Returns (exports)" & "|" & "Pallets"

                If opt.ShowDialog = Forms.DialogResult.OK Then

                    Select Case opt.Seleccion

                        Case 0
                            intTipo = 0
                        Case 1
                            intTipo = 1
                        Case 2
                            intTipo = 6
                    End Select
                Else
                    Exit Sub
                End If

            End If
            LimpiarFormulario()
            MostrarLista(False, True)

            celdaAnio.Text = cFunciones.AñoMySQL
            celdaNumero.Text = -1
            'dtpFech.Text = (cFunciones.HoyMySQL).ToString(FORMATO_MYSQL)
            'dtpFecha2.Text = (cFunciones.HoyMySQL).ToString(FORMATO_MYSQL)
            celdaEmpresa.Text = Sesion.IdEmpresa
            celdaCatalogo.Text = 47
            celdaUsuario.Text = Sesion.Usuario
            If intTipo > 7 And intTipo <= 13 Then
                celdaMoneda.Text = cfun.TraerMoneda(182)
                celdaIDMoneda.Text = 182
                celdaTasa.Text = INT_UNO
            Else
                celdaMoneda.Text = "US$"
                celdaIDMoneda.Text = 178
                celdaTasa.Text = cFunciones.QueryTasa("CURDATE()")
            End If

            dgDetalle.ReadOnly = False
            If Me.Tag = "Nuevo" Then
                botonParciales.Visible = True

                selectFecha.ShowDialog(Me)
                If selectFecha.DialogResult = Forms.DialogResult.OK Then
                    If intTipo <= 7 Or intTipo >= 14 Then
                        dtpFech.Text = selectFecha.LLave
                        celdaTasa.Text = cFunciones.TasaSegunFecha(dtpFech.Value.ToString(FORMATO_MYSQL))
                    End If
                End If
                dtpFech.Enabled = False

            Else
                botonParciales.Visible = False
            End If

            anio = celdaAnio.Text
            numero = celdaNumero.Text
            SeleccionarSubdocumentos(anio, numero)
            'botonQuitDetalle.Enabled = False

            ' celdaRefFactura.ReadOnly = True
            celdaRefFactura.BackColor = Color.Beige
            'celdaRef1.ReadOnly = True
            celdaRef1.BackColor = Color.Beige
            ' celdaRef2.ReadOnly = True
            celdaRef2.BackColor = Color.Beige
            dtpFecha2.Value = dtpFech.Value

            PintarTipoIngreso()
            frm.dgDetalle.Rows.Clear()
            dgDetalle.Columns("colMarcaHSM").Visible = False

            If (Sesion.idGiro = 2 And intTipo = 4) Then
                dgDetalle.Columns("colCantidad").ReadOnly = False
                dgDetalle.Columns("colPrecio").ReadOnly = False
                botonAgreDetalle.Enabled = True
                botonProduccion.Visible = False
                celdaRef1.ReadOnly = False
                celdaRefFactura.ReadOnly = False
                celdaRef2.ReadOnly = False
                dgPolizasImportacion.Columns("colNumero").HeaderText = "Waste Material"
                etiquetaRef2.Text = "Cone Color"
                gbPedidoClientes.Text = "Waste Material"
            ElseIf (Sesion.idGiro = 2 And intTipo = 5) Then
                dgDetalle.Columns("colCantidad").ReadOnly = False
                dgDetalle.Columns("colPrecio").ReadOnly = False
                botonAgreDetalle.Enabled = True
                botonProduccion.Visible = False
                celdaRef1.ReadOnly = False
                celdaRefFactura.ReadOnly = False
                celdaRef2.ReadOnly = False
                dgPolizasImportacion.Columns("colNumero").HeaderText = "Invisible"
                etiquetaRef2.Text = "Cone Color"
                gbPedidoClientes.Text = "Invisible"

            ElseIf (Sesion.IdEmpresa = 22 And (intTipo = 2 Or intTipo = 14 Or intTipo = 15 Or intTipo = 16 Or intTipo = 17)) Then '(intTipo = 2 OR intTipo  = 14 OR intTipo  = 15 OR intTipo  = 16 OR intTipo  = 17)
                dgDetalle.Columns("colCantidad").ReadOnly = False
                dgDetalle.Columns("colPrecio").ReadOnly = False
                botonAgreDetalle.Enabled = True
                botonProduccion.Visible = False
                celdaRef1.ReadOnly = False
                celdaRefFactura.ReadOnly = False
                celdaRef2.ReadOnly = False
                If Sesion.IdEmpresa = 22 Then
                    etiquetaRefFactura.Text = "Batch"
                    EtiquetaRef1.Text = "Color"
                    etiquetaRef2.Text = "Fabric Form"
                    celdaRef2.ReadOnly = True
                    If intTipo = 2 Then
                        dgPolizasImportacion.Columns("colNumero").HeaderText = "Greige"
                        gbPedidoClientes.Text = "Greige"

                    ElseIf intTipo = 14 Then
                        dgPolizasImportacion.Columns("colNumero").HeaderText = "Dyeing"
                        gbPedidoClientes.Text = "Dyeing"
                    ElseIf intTipo = 15 Then
                        dgPolizasImportacion.Columns("colNumero").HeaderText = "Finishing"
                        gbPedidoClientes.Text = "Finishing"
                        celdaRef1.ReadOnly = True
                        celdaRefFactura.ReadOnly = True
                    ElseIf intTipo = 16 Then
                        dgPolizasImportacion.Columns("colNumero").HeaderText = "Rolling"
                        gbPedidoClientes.Text = "Rolling"
                        celdaRef1.ReadOnly = True
                        celdaRefFactura.ReadOnly = True
                    Else
                        dgPolizasImportacion.Columns("colNumero").HeaderText = "Finish good"
                        gbPedidoClientes.Text = "Finish good"
                        celdaRef1.ReadOnly = True
                        celdaRefFactura.ReadOnly = True
                    End If

                Else
                    dgPolizasImportacion.Columns("colNumero").HeaderText = "Yarn Production"
                    gbPedidoClientes.Text = "Yarn Production"

                End If

            ElseIf (Sesion.IdEmpresa = 11 And intTipo = 6) Or (Sesion.idGiro = 2 And intTipo >= 6) Then
                dgDetalle.Columns("colCantidad").ReadOnly = False
                dgDetalle.Columns("colPrecio").ReadOnly = False
                botonAgreDetalle.Enabled = True
                botonProduccion.Visible = False
                celdaRef1.ReadOnly = False
                celdaRefFactura.ReadOnly = False
                celdaRef2.ReadOnly = False
                dgPolizasImportacion.Columns("colNumero").HeaderText = "Invisible"
                etiquetaRef2.Text = "Cone Color"
                gbPedidoClientes.Text = "Invisible"

            ElseIf (Sesion.IdEmpresa = 15 And intTipo = 1) Or (Sesion.IdEmpresa = 18 And intTipo = 1) Or (Sesion.IdEmpresa = 19 And intTipo = 1) Or (Sesion.IdEmpresa = 20 And intTipo = 1) Or (Sesion.IdEmpresa = 21 And intTipo = 1) Then
                dgDetalle.Columns("colCantidad").ReadOnly = True
                dgDetalle.Columns("colPrecio").ReadOnly = True
                botonAgreDetalle.Enabled = False
                botonQuitDetalle.Enabled = False
                botonProduccion.Visible = False
                dgPolizasImportacion.Columns("colNumero").HeaderText = "Policy"
                etiquetaRef2.Text = "Ref. No. 2"
                gbPedidoClientes.Text = "Import Policy"
            ElseIf (Sesion.idGiro = 2 And intTipo = 0) And Not Sesion.IdEmpresa = 22 Then
                dgDetalle.Columns("colCantidad").ReadOnly = True
                dgDetalle.Columns("colPrecio").ReadOnly = True
                botonAgreDetalle.Enabled = False
                botonQuitDetalle.Enabled = False
                botonProduccion.Visible = False
                dgPolizasImportacion.Columns("colNumero").HeaderText = "Policy"
                etiquetaRef2.Text = "Ref. No. 2"
                gbPedidoClientes.Text = "Import Policy"
            End If
            If Sesion.idGiro = 2 And intTipo = 2 And Not Sesion.IdEmpresa = 22 Then '(intTipo = 2 OR intTipo  = 14 OR intTipo  = 15 OR intTipo  = 16 OR intTipo  = 17)
                dgDetalle.Columns("colPrecio").Visible = False
                dgDetalle.Columns("colSubtotal").Visible = False
                botonAgreDetalle.Enabled = True
                celdaTotal.Visible = False
            Else
                dgDetalle.Columns("colPrecio").Visible = True
                dgDetalle.Columns("colSubtotal").Visible = True
                celdaTotal.Visible = True
            End If
        Else
            MsgBox("You do not have access to create a new revenue from goods to warehouse", vbInformation)
        End If

        If Sesion.idGiro = 2 Then ' 1 Comercilaizadora, 2 Planta
            dgDetalle.Columns("colRefMKT").Visible = False
            If (Sesion.IdEmpresa = 15 Or Sesion.IdEmpresa = 20) And intTipo = 6 Then
                dgDetalle.Columns("colReferenciaRamplas").Visible = True
            Else
                dgDetalle.Columns("colReferenciaRamplas").Visible = False
            End If
        ElseIf Sesion.IdEmpresa = 11 And intTipo = 6 Then
            dgDetalle.Columns("colReferenciaRamplas").Visible = True
        Else
            dgDetalle.Columns("colRefMKT").Visible = False
            dgDetalle.Columns("colReferenciaRamplas").Visible = False
        End If


    End Sub

    Private Sub Encabezado1_ClickCerrar(sender As Object, click As Boolean) Handles Encabezado1.ClickCerrar

        If panelDocumento.Visible = True Then
            MostrarLista()
        Else
            Me.Close()
        End If

    End Sub
    Public Function NuevoIngreso(ByVal intAnio As Integer) As Integer
        Dim strSQL As String = STR_VACIO
        Dim conec As New MySqlConnection
        Dim COM As MySqlCommand
        Dim CodigoProyecto As Integer

        strSQL = "Select IFNULL(MAX(HDR.HDoc_Doc_Num),0)+1 NUMERO "
        strSQL &= "FROM Dcmtos_HDR HDR "
        strSQL &= "WHERE HDR.HDoc_Sis_Emp = {empresa} And HDR.HDoc_Doc_Cat = {catalogo} AND HDR.HDoc_Doc_Ano = {anio}"

        strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
        strSQL = Replace(strSQL, "{catalogo}", 47)
        strSQL = Replace(strSQL, "{anio}", intAnio)


        conec = New MySqlConnection(strConexion)
        conec.Open()
        COM = New MySqlCommand(strSQL, conec)
        CodigoProyecto = COM.ExecuteScalar
        conec.Close()
        conec.Dispose()
        conec = Nothing
        System.GC.Collect()
        Return CodigoProyecto
    End Function

    Public Function pressPOWE(numero As Integer, anio As String) As Integer
        Dim strSQL As String = STR_VACIO
        Dim conec As New MySqlConnection
        Dim COM As MySqlCommand
        Dim CodigoProyecto As Integer

        strSQL = " Select IFNULL(HDoc_RF2_Dbl,1) NUMERO"
        strSQL &= " FROM Dcmtos_HDR HDR"
        strSQL &= " WHERE HDR.HDoc_Sis_Emp = {empresa} And HDR.HDoc_Doc_Cat = 47 and HDR.HDoc_Doc_Ano={anio} AND HDR.HDoc_Doc_Num={numero} "

        strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
        strSQL = Replace(strSQL, "{anio}", anio)
        strSQL = Replace(strSQL, "{numero}", numero)


        conec = New MySqlConnection(strConexion)
        conec.Open()
        COM = New MySqlCommand(strSQL, conec)
        CodigoProyecto = Val(COM.ExecuteScalar)
        conec.Close()
        conec.Dispose()
        conec = Nothing
        System.GC.Collect()
        Return CodigoProyecto
    End Function
    Public Function ObtenerPO(numero As Integer, anio As String) As Integer
        Dim strSQL As String = STR_VACIO
        Dim conec As New MySqlConnection
        Dim COM As MySqlCommand
        Dim CodigoProyecto As Integer

        strSQL = " Select IFNULL(HDoc_RF1_TXT,0) NUMERO"
        strSQL &= " FROM Dcmtos_HDR HDR"
        strSQL &= " WHERE HDR.HDoc_Sis_Emp = {empresa} And HDR.HDoc_Doc_Cat = 47 and HDR.HDoc_Doc_Ano={anio} AND HDR.HDoc_Doc_Num={numero} "

        strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
        strSQL = Replace(strSQL, "{anio}", anio)
        strSQL = Replace(strSQL, "{numero}", numero)


        conec = New MySqlConnection(strConexion)
        conec.Open()
        COM = New MySqlCommand(strSQL, conec)
        CodigoProyecto = Val(COM.ExecuteScalar)
        conec.Close()
        conec.Dispose()
        conec = Nothing
        System.GC.Collect()
        Return CodigoProyecto
    End Function
    Private Sub Encabezado1_ClickGuardar(sender As Object, click As Boolean) Handles Encabezado1.ClickGuardar
        If Me.Tag = "Mod" Then
            If Sesion.idGiro = 1 And intTipo.Equals(0) And cfun.ValidaFacturaVenta(47, celdaAnio.Text, celdaNumero.Text) Then
                If AutorizarGuardar() = False Then
                    Exit Sub
                End If
            End If
        End If
        Dim IDExistente As Integer
        Dim clsConta As New clsContabilidad
        Dim dtFechaConta As Date

        If logEditar = True Or Me.Tag = "Nuevo" Then
            If dgDetalle.Rows.Count > vbEmpty Then
                Dim cls As New clsFunciones

                If Me.Tag = "Nuevo" Then
                    ComprobarDatos()
                    If celdaNumero.Text = NO_FILA Then
                        celdaNumero.Text = NuevoIngreso(celdaAnio.Text)
                        If Not (celdaNumero.Text = NO_FILA) Then
                            If MsgBox("Year: " & vbTab & celdaAnio.Text & vbCrLf & "Number: " & vbTab & celdaNumero.Text & vbCrLf & vbCrLf & "¿Do you confirm the use of this document number?", vbExclamation + vbYesNo, "Confirm") = vbNo Then
                                celdaNumero.Focus()
                                Exit Sub
                            End If
                        End If
                    ElseIf celdaNumero.Text > 0 Then
                        IDExistente = ObtenerNumero(celdaAnio.Text)
                        If celdaNumero.Text = IDExistente Then
                            MsgBox("This number of income already exists, can not be used, must generate another", vbInformation)
                            Exit Sub
                        End If
                    End If

                    If GuardarDocumento() Then
                        GuardarDetalle()
                        If Sesion.idGiro = 2 And (intTipo = 2 Or intTipo = 4 Or intTipo = 5) Then ' Or intTipo = 14 Or intTipo = 15 Or intTipo = 16 Or intTipo = 17) Then
                            GuardarKardexPO(INT_CERO)
                        End If

                        EliminarLineasBultos()
                        GuardarBultos()
                        If (intTipo = 2 Or intTipo = 14 Or intTipo = 15 Or intTipo = 16 Or intTipo = 17) Then
                            GuardarDescargoHSM()
                        ElseIf (intTipo = 4) Or (intTipo = 5) Or (intTipo = 6) Then ''material de desperdicio
                            GuardarDesperdicio()
                        ElseIf intTipo > 6 Then
                            ' no debe guardar ninguna relación
                        ElseIf intTipo = 0 And checkTendido.Checked = True Then
                            ' no debe guardar ninguna relación
                        Else
                            GuardarDescargo()
                            'Guardar Reserva si Aplica
                            GuardarReserva()
                        End If
                        GuardarExistencia()

                        cFunciones.EscribirRegistro(TBL_DOCUMENTOS, clsFunciones.AccEnum.acAdd, celdaIDCliente.Text, 47, celdaAnio.Text, celdaNumero.Text)

                        If MsgBox("The document has been saved" & vbCr & vbCr & "¿Do you want close the document?", vbQuestion + vbYesNo + vbDefaultButton2, "Close document") = vbYes Then
                            MostrarLista()
                        Else
                            If cFunciones.SQLVerificarCierre(celdaCatalogo.Text, celdaAnio.Text, celdaNumero.Text) = 0 Then
                                clsConta.GenerarPoliza(celdaCatalogo.Text, celdaAnio.Text, celdaNumero.Text, dtpFech.Value.ToString(FORMATO_MYSQL))
                                ' Si hay cierre guarda la fecha de hoy
                            Else
                                clsConta.GenerarPoliza(celdaCatalogo.Text, celdaAnio.Text, celdaNumero.Text, cFunciones.HoyMySQL.ToString(FORMATO_MYSQL))
                            End If
                            Me.Tag = "Mod"
                            CambioEstadoDetalle()
                            CambioEstadoOculto()
                            ' Si no hay cierre, guarda la fecha del documento
                        End If
                    Else
                        MsgBox("Document not saved, generate again", vbInformation, "Notice")
                        celdaNumero.Text = NO_FILA
                    End If
                ElseIf Me.Tag = "Mod" Then

                    ComprobarDatos()
                    ' Si es modificación verifica la fecha del documento o de la poliza, si es que tiene poliza
                    dtFechaConta = cFunciones.SQLValidarFechaContable(celdaCatalogo.Text, celdaAnio.Text, celdaNumero.Text)

                    ' Si no hay cierre guarda la fecha que devuelve el query de arriba
                    If cFunciones.SQLVerificarCierre(celdaCatalogo.Text, celdaAnio.Text, celdaNumero.Text) = 0 Then
                        GuardarModificacionDeDocumento()
                        clsConta.GenerarPoliza(celdaCatalogo.Text, celdaAnio.Text, celdaNumero.Text, dtFechaConta.ToString(FORMATO_MYSQL))
                    Else
                        'Autorizacion
                        MsgBox("You need authorization to modify this document", vbInformation, "Notice")
                        If cFunciones.AutorizarCambios() = True Then
                            ' Si hay cierre guarda la fecha que trae el query
                            cfun.EscribirRegistro("Dcmtos_HDR", clsFunciones.AccEnum.acConfirm, celdaIDCliente.Text, 47, celdaAnio.Text, celdaNumero.Text)
                            GuardarModificacionDeDocumento()
                            clsConta.GenerarPoliza(celdaCatalogo.Text, celdaAnio.Text, celdaNumero.Text, dtFechaConta.ToString(FORMATO_MYSQL))
                        End If

                    End If

                End If
                ''''''////////////////////////////////////////////
            Else
                MsgBox("Detail is empty", vbInformation)
            End If
            If Me.Tag = "Nuevo" And celdaNumero.Text <> NO_FILA Then
                ' Si no hay cierre, guarda la fecha del documento
                If cFunciones.SQLVerificarCierre(celdaCatalogo.Text, celdaAnio.Text, celdaNumero.Text) = 0 Then
                    clsConta.GenerarPoliza(celdaCatalogo.Text, celdaAnio.Text, celdaNumero.Text, dtpFech.Value.ToString(FORMATO_MYSQL))
                    ' Si hay cierre guarda la fecha de hoy
                Else
                    clsConta.GenerarPoliza(celdaCatalogo.Text, celdaAnio.Text, celdaNumero.Text, cFunciones.HoyMySQL.ToString(FORMATO_MYSQL))
                End If
            End If
        Else
            MsgBox("You do not have access to save a new revenue from goods to warehouse", vbInformation)
        End If

    End Sub

    Private Sub GuardarModificacionDeDocumento()
        If GuardarDocumento() Then
            GuardarDetalle()
            If Sesion.idGiro = 2 And (intTipo = 2 Or intTipo = 4 Or intTipo = 5) Then  'Or intTipo = 14 Or intTipo = 15 Or intTipo = 16 Or intTipo = 17) Then
                ' BorrarKardex()
                GuardarKardexPO(INT_UNO)
                GuardarKardexPO(INT_CERO)
            End If

            EliminarLineasBultos()

            If botonPacas.Enabled Then
                GuardarBultos()
            End If

            If (intTipo = 2 Or intTipo = 6 Or intTipo = 14 Or intTipo = 15 Or intTipo = 16 Or intTipo = 17) Then
                GuardarDescargoHSM()
            ElseIf (intTipo = 4) Or (intTipo = 5) Then
                GuardarDesperdicio()
            ElseIf intTipo = 0 And checkTendido.Checked = True Then
                ' no guardar descargo
            Else
                GuardarDescargo()
            End If
            GuardarExistencia()

            cFunciones.EscribirRegistro(TBL_DOCUMENTOS, clsFunciones.AccEnum.acUpdate, celdaIDCliente.Text, 47, celdaAnio.Text, celdaNumero.Text)

            If MsgBox("The document has been update" & vbCr & vbCr & "¿Do you want close the document?", vbQuestion + vbYesNo + vbDefaultButton2, "Close document") = vbYes Then
                MostrarLista()
            End If
        Else
            MsgBox("Document not updated", vbInformation, "Notice")
        End If
    End Sub
    Private Sub botonActualizar_Click(sender As Object, e As EventArgs) Handles botonActualizar.Click

        Dim logCancelar As Boolean

        If CDate(dtpInicio.Value) > CDate(dtpFin.Value) Then
            MsgBox("The start date may not exceed the final date", vbExclamation, "Notice")
            logCancelar = True
        End If
        If Not (logCancelar) Then
            'strOrigen = PrepararListado

            'Procedimiento para cargar panel dgLista
            queryListaPrincipal()
        End If
    End Sub

    Private Sub dgLista_DoubleClick(sender As Object, e As EventArgs) Handles dgLista.DoubleClick
        Dim anio As Integer = vbEmpty
        Dim numero As Integer = vbEmpty
        Dim Linea As Integer = vbEmpty

        LimpiarFormulario()
        dgDetalle.Columns("colBoxNumber").Visible = False


        If Sesion.idGiro = 2 Then ' If (Sesion.IdEmpresa = 15) Or (Sesion.IdEmpresa = 18) Or (Sesion.IdEmpresa = 19) Or (Sesion.IdEmpresa = 20) Or (Sesion.IdEmpresa = 21) Then
            botonPacas.Enabled = True
        Else
            botonPacas.Visible = False
        End If

        Try
            If dgLista.SelectedRows.Count = INT_CERO Then Exit Sub
            Me.Tag = "mod"

            anio = dgLista.SelectedCells(6).Value
            numero = dgLista.SelectedCells(0).Value
            MostrarLista(0)
            SeleccionarCliente(anio, numero)
            If Sesion.IdEmpresa = 11 Or Sesion.IdEmpresa = 15 Or Sesion.IdEmpresa = 20 Then
                If intTipo = 6 Then
                    dgDetalle.Columns("colReferenciaRamplas").Visible = True
                Else
                    dgDetalle.Columns("colReferenciaRamplas").Visible = False
                End If
            Else
                dgDetalle.Columns("colReferenciaRamplas").Visible = False
            End If
            If intTipo = 2 Or dgLista.CurrentRow.Cells("colClase").Value = "Invisible Waste" Or dgLista.CurrentRow.Cells("colClase").Value = "Process" Or dgLista.CurrentRow.Cells("colClase").Value = "Waste" Or intTipo > 13 Then
                botonProduccion.Visible = True
                logProduction = True
                CargarDetalleProduccion()
                If intTipo < 6 Or intTipo > 13 Then
                    If intTipo = 0 And checkTendido.Checked = True Then
                    Else
                        DocumentosPendientesProduccion()
                    End If

                End If
            Else
                logProduction = False
                botonProduccion.Visible = False


                queryDetalle()
                CargarDescargos()
                DocumentosPendientes()


            End If
            'If (Sesion.IdEmpresa = 15 And celdaTipoIngreso.Text = 0) Or (Sesion.IdEmpresa = 18 And celdaTipoIngreso.Text = 0) Or (Sesion.IdEmpresa = 19 And celdaTipoIngreso.Text = 0) Or (Sesion.IdEmpresa = 20 And celdaTipoIngreso.Text = 0) Or (Sesion.IdEmpresa = 21 And celdaTipoIngreso.Text = 0) Then
            If Sesion.idGiro = 2 And celdaTipoIngreso.Text = 0 Then
                dgDetalle.Columns("colMarcaHSM").Visible = True
            Else
                dgDetalle.Columns("colMarcaHSM").Visible = False
            End If

            VerificarPacas_()
            queryCargarCajas()
            SeleccionarSubdocumentos(anio, numero)
            CalcularTotales()

            botonParciales.Visible = False

            ' celdaRefFactura.ReadOnly = True
            celdaRefFactura.BackColor = Color.Beige
            'celdaRef1.ReadOnly = True
            celdaRef1.BackColor = Color.Beige
            'celdaRef2.ReadOnly = True
            celdaRef2.BackColor = Color.Beige


            dtpFecha2.Value = dtpFech.Value

            'dgDetalle.SelectedCells(11).ReadOnly = True
            botonQuitDetalle.Enabled = False
            If Sesion.idGiro = 2 And intTipo = 2 And Sesion.IdEmpresa <> 22 Then ' (intTipo = 2 OR intTipo  = 14 OR intTipo  = 15 OR intTipo  = 16 OR intTipo  = 17)
                dgDetalle.Columns("colPrecio").Visible = False
                dgDetalle.Columns("colSubtotal").Visible = False
                celdaTotal.Visible = False
            Else
                dgDetalle.Columns("colPrecio").Visible = True
                dgDetalle.Columns("colSubtotal").Visible = True
                celdaTotal.Visible = True
            End If

            'If (Sesion.IdEmpresa = 15 And intTipo = 2) Or (Sesion.IdEmpresa = 18 And intTipo = 2) Or (Sesion.IdEmpresa = 19 And intTipo = 2) Or (Sesion.IdEmpresa = 20 And intTipo = 2) Or (Sesion.IdEmpresa = 21 And intTipo = 2) Then
            If Sesion.idGiro = 2 And (intTipo = 2 Or intTipo = 14 Or intTipo = 15 Or intTipo = 16 Or intTipo = 17) Then
                botonProduccion.Visible = False
                etiquetaRef2.Text = "Cone Color"
                If Sesion.IdEmpresa = 22 Then
                    etiquetaRef2.Text = "Fabric Form"
                    If intTipo = 2 Then
                        dgPolizasImportacion.Columns("colNumero").HeaderText = "Greige"
                        gbPedidoClientes.Text = "Greige"
                    ElseIf intTipo = 14 Then
                        dgPolizasImportacion.Columns("colNumero").HeaderText = "Greige"
                        gbPedidoClientes.Text = "Greige"
                    ElseIf intTipo = 15 Then
                        dgPolizasImportacion.Columns("colNumero").HeaderText = "Dyeing"
                        gbPedidoClientes.Text = "Dyeing"
                    ElseIf intTipo = 16 Then
                        dgPolizasImportacion.Columns("colNumero").HeaderText = "Finishing"
                        gbPedidoClientes.Text = "Finishing"
                    Else
                        dgPolizasImportacion.Columns("colNumero").HeaderText = "Rolling"
                        gbPedidoClientes.Text = "Rolling"
                    End If
                    dgPolizasImportacion.Columns("colNumero").HeaderText = "Finish good"
                    gbPedidoClientes.Text = "Finish good"
                Else
                    dgPolizasImportacion.Columns("colNumero").HeaderText = "Yarn Production"
                    gbPedidoClientes.Text = "Yarn Production"
                    etiquetaRef2.Text = "Ref. No. 2"
                End If

                botonQuitDetalle.Enabled = True
                botonAgreDetalle.Enabled = False
                ActivarFel()
            ElseIf intTipo = 1 Then
                dgPolizasImportacion.Columns("colNumero").HeaderText = "Policy"
                gbPedidoClientes.Text = "Import Policy"
                etiquetaRef2.Text = "Ref. No. 2"
                ActivarFel()
            ElseIf Sesion.idGiro = 2 And intTipo = 3 Then '(intTipo = 3 And Sesion.IdEmpresa = 15) Or (intTipo = 3 And Sesion.IdEmpresa = 18) Or (intTipo = 3 And Sesion.IdEmpresa = 19) Or (intTipo = 3 And Sesion.IdEmpresa = 20) Or (intTipo = 3 And Sesion.IdEmpresa = 21) Then
                dgPolizasImportacion.Columns("colNumero").HeaderText = "Consumables"
                gbPedidoClientes.Text = "Consumables"
                etiquetaRef2.Text = "Ref. No. 2"
                dgDetalle.Columns("colBoxNumber").Visible = True
                Dim i As Integer
                For i = 0 To dgDetalle.Columns.Count - 1
                    dgDetalle.Columns(i).ReadOnly = True
                Next
                dgDetalle.Columns("colBoxNumber").ReadOnly = False

                'Dim col As New DataGridViewTextBoxColumn
                'col.Name = "Box Number"
                'dgDetalle.Columns.Add(col)
                BloquearFel2()
            ElseIf Sesion.idGiro = 2 And intTipo = 4 Then '(intTipo = 4 And Sesion.IdEmpresa = 15) Or (intTipo = 4 And Sesion.IdEmpresa = 18) Or (intTipo = 4 And Sesion.IdEmpresa = 19) Or (intTipo = 4 And Sesion.IdEmpresa = 20) Or (intTipo = 4 And Sesion.IdEmpresa = 21) Then
                dgPolizasImportacion.Columns("colNumero").HeaderText = "Waste"
                gbPedidoClientes.Text = "Waste"

                ActivarFel()
            ElseIf (intTipo = 5 And Sesion.IdEmpresa = 15) Then 'Or (intTipo = 5 And Sesion.IdEmpresa = 18) Or (intTipo = 5 And Sesion.IdEmpresa = 19) Or (intTipo = 5 And Sesion.IdEmpresa = 20) Or (intTipo = 5 And Sesion.IdEmpresa = 21) Then
                dgPolizasImportacion.Columns("colNumero").HeaderText = "Invisible"
                gbPedidoClientes.Text = "Invisible"
                etiquetaRef2.Text = "Ref. No. 2"
                ActivarFel()
            ElseIf (intTipo = 6 And Sesion.IdEmpresa = 15) Or (intTipo = 6 And Sesion.IdEmpresa = 20) Or (intTipo = 6 And Sesion.IdEmpresa = 11) Then 'Or (intTipo = 5 And Sesion.IdEmpresa = 18) Or (intTipo = 5 And Sesion.IdEmpresa = 19) Or (intTipo = 5 And Sesion.IdEmpresa = 20) Or (intTipo = 5 And Sesion.IdEmpresa = 21) Then
                dgPolizasImportacion.Columns("colNumero").HeaderText = "Product on Process"
                gbPedidoClientes.Text = "Product on Process"
                etiquetaRef2.Text = "Ref. No. 2"
                dgDetalle.ReadOnly = False
                dgDetalle.Columns("colReferenciaRamplas").ReadOnly = False
                'ActivarFel(1)
            ElseIf intTipo = 7 Then
                dgPolizasImportacion.Columns("colNumero").HeaderText = "Return of Consumables"
                gbPedidoClientes.Text = "Return of Consumables"
                etiquetaRef2.Text = "Ref. No. 2"
            ElseIf intTipo = 8 Then
                dgPolizasImportacion.Columns("colNumero").HeaderText = "2% inventory"
                gbPedidoClientes.Text = "2% inventory"
                etiquetaRef2.Text = "Ref. No. 2"
            ElseIf intTipo = 9 Then
                dgPolizasImportacion.Columns("colNumero").HeaderText = "Reusable Spare Parts"
                gbPedidoClientes.Text = "Reusable Spare Parts"
                etiquetaRef2.Text = "Ref. No. 2"
            ElseIf intTipo = 10 Then
                dgPolizasImportacion.Columns("colNumero").HeaderText = "Partially Used Spare Parts"
                gbPedidoClientes.Text = "Partially Used Spare Parts"
                etiquetaRef2.Text = "Ref. No. 2"
            ElseIf intTipo = 11 Then
                dgPolizasImportacion.Columns("colNumero").HeaderText = "Guarantee revenue"
                gbPedidoClientes.Text = "Guarantee revenue"
                etiquetaRef2.Text = "Ref. No. 2"
            ElseIf intTipo = 12 Then
                dgPolizasImportacion.Columns("colNumero").HeaderText = "Per Contract"
                gbPedidoClientes.Text = "Per Contract"
                etiquetaRef2.Text = "Ref. No. 2"
            ElseIf intTipo = 13 Then
                dgPolizasImportacion.Columns("colNumero").HeaderText = "transit repairs"
                gbPedidoClientes.Text = "transit repairs"
                etiquetaRef2.Text = "Ref. No. 2"
            End If

            If Sesion.idGiro = 1 Then ' 1- comercializadoras, 2- Plantas
                dgDetalle.Columns("colRefMKT").Visible = False
            Else
                dgDetalle.Columns("colRefMKT").Visible = False
            End If
            PintarTipoIngreso()
            dtpFech.Enabled = False

            If HacerDescargoAIngreso() And pressPOWE(celdaNumero.Text, celdaAnio.Text) = 1 Then
                botonPOWE.Visible = True
            Else
                botonPOWE.Visible = False
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub botonClientes_Click(sender As Object, e As EventArgs) Handles botonClientes.Click
        Me.Tag = "Nuevo"
        Dim frm As New frmSeleccionar
        Dim strCondicion As String = STR_VACIO
        If intTipo >= 6 Then
            strCondicion = "pro_sisemp = {empresa} /* AND pro_ramo = 'Textil' */ AND pro_status = 'Activo'"
        Else
            strCondicion = "pro_sisemp = {empresa} AND pro_ramo = 'Textil' AND pro_status = 'Activo'"
        End If
        strCondicion = Replace(strCondicion, "{empresa}", Sesion.IdEmpresa)
        Try
            frm.Titulo = "  Provider"
            frm.Campos = " pro_codigo Code, pro_proveedor Name, pro_direccion Direction, IFNULL(pro_nit,0) RTN, IFNULL(pro_telefono,0) Phone"
            frm.Tabla = " Proveedores"
            frm.FiltroText = " Enter the provider to filter"
            frm.Filtro = "  pro_proveedor"
            frm.Limite = 30
            frm.Ordenamiento = " pro_proveedor "
            frm.TipoOrdenamiento = ""
            frm.Condicion = strCondicion

            frm.ShowDialog(Me)
            If frm.DialogResult = Forms.DialogResult.OK Then
                celdaIDCliente.Text = frm.LLave
                celdaCliente.Text = frm.Dato
                celdaDireccion.Text = frm.Dato2
                celdaNit.Text = frm.Dato3
                celdaTelefono.Text = frm.Dato4


                'celdaMoneda.Text = "US$"
                'celdaIDMoneda.Text = 178
                If Sesion.idGiro = 2 And checkTendido.Checked = True Or (Sesion.idGiro = 2 And intTipo = 2) Or (Sesion.idGiro = 2 And intTipo = 4) Or (Sesion.idGiro = 2 And intTipo = 5) Or (Sesion.idGiro = 2 And intTipo >= 6) Or (Sesion.IdEmpresa = 11 And intTipo = 6) Then
                    'IF (Sesion.IdEmpresa = 15 And intTipo = 2) Or
                    '(Sesion.IdEmpresa = 18 And intTipo = 2) Or
                    '(Sesion.IdEmpresa = 19 And intTipo = 2) Or
                    '(Sesion.IdEmpresa = 20 And intTipo = 2) Or
                    '(Sesion.IdEmpresa = 21 And intTipo = 2) Or
                    '(Sesion.IdEmpresa = 15 And intTipo = 4) Or
                    '(Sesion.IdEmpresa = 18 And intTipo = 4) Or
                    '(Sesion.IdEmpresa = 19 And intTipo = 4) Or
                    '(Sesion.IdEmpresa = 20 And intTipo = 4) Or
                    '(Sesion.IdEmpresa = 21 And intTipo = 4) Or
                    '(Sesion.IdEmpresa = 15 And intTipo = 5) Then
                Else
                    DocumentosPendientes()
                    ImportarInfoReferencia()
                    ProcesarDocumentos()
                    CalcularTotales()
                End If
            End If

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Function sqlDocumentosParaProcesar() As String
        Dim strSQL As String

        'Consulta de Seleccion
        strSQL = SqlGetDocumentsList(True, True, True, True)

        'Reemplaza los parametros
        strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
        strSQL = Replace(strSQL, "{tipo}", 180)
        strSQL = Replace(strSQL, "{actual}", 47)
        strSQL = Replace(strSQL, "{clase}", intTipo)
        strSQL = Replace(strSQL, "{codigo}", celdaIDCliente.Text)
        strSQL = Replace(strSQL, "{fechaFiltro}", dtpFech.Value.ToString(FORMATO_MYSQL))

        sqlDocumentosParaProcesar = strSQL

    End Function

    Private Function QueryPendientesProduccion()
        Dim strSQL As String = STR_VACIO

        strSQL = "SELECT DISTINCT(IFNULL(p.PDoc_Par_Num,0)) NUMBER, b.HDoc_Doc_Fec DATE, h.HDoc_Usuario USER, b.HDoc_DR1_Num Reference, IFNULL(p.PDoc_Chi_Ano,0) YEAR"
        strSQL &= "      FROM Dcmtos_HDR h"
        strSQL &= "          LEFT JOIN Dcmtos_DTL_Pro p ON p.PDoc_Sis_Emp = h.HDoc_Sis_Emp AND p.PDoc_Chi_Cat = h.HDoc_Doc_Cat and p.PDoc_Chi_Num = HDoc_Doc_Num and p.PDoc_Chi_Ano = h.HDoc_Doc_Ano"
        strSQL &= "        LEFT JOIN Dcmtos_HDR b ON b.HDoc_Sis_Emp = p.PDoc_Sis_Emp AND b.HDoc_Doc_Cat = p.PDoc_Par_Cat AND b.HDoc_Doc_Ano = p.PDoc_Par_Ano AND b.HDoc_Doc_Num = p.PDoc_Par_Num "
        strSQL &= "      WHERE h.HDoc_Sis_Emp = {empresa} and h.HDoc_Doc_Ano = {anio} AND h.HDoc_Doc_Num = {numero} and h.HDoc_Doc_Cat = 47 AND p.PDoc_Par_Cat=980"

        strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
        strSQL = Replace(strSQL, "{anio}", celdaAnio.Text)
        strSQL = Replace(strSQL, "{numero}", celdaNumero.Text)

        Return strSQL
    End Function

    'Importaciones pendientes de ingreso
    Private Sub DocumentosPendientesProduccion()
        Dim strOrigen As String = STR_VACIO
        Dim strTemp As String = STR_VACIO
        Dim REA As MySqlDataReader
        Dim COM As MySqlCommand
        Dim Referencia As String = STR_VACIO

        strOrigen = QueryPendientesProduccion()

        'Agreag todos los registros de la seleccion
        Try
            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strOrigen, CON)
            REA = COM.ExecuteReader
            Do While REA.Read
                If REA.GetInt32("Number") = INT_CERO Then
                    Exit Sub
                End If

                strOrigen = REA.GetInt32("Number") & "|"
                strOrigen &= REA.GetDateTime("DATE") & "|"
                strOrigen &= REA.GetString("USER") & "|"
                Referencia = REA.GetString("Reference")
                strOrigen &= Referencia & "|"
                strOrigen &= REA.GetInt32("YEAR") & "|"
                strOrigen &= 952 & "|"
                strOrigen &= 0

                cFunciones.AgregarFila(dgPolizasImportacion, strOrigen)
            Loop

            'If dgPolizasImporatcion.Rows.Count = 1 Then

            '    celdaRefFactura.Text = Referencia
            'End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    'Importaciones pendientes de ingreso
    Private Sub DocumentosPendientes()
        Dim strOrigen As String = STR_VACIO
        Dim strTemp As String = STR_VACIO
        Dim REA As MySqlDataReader
        Dim COM As MySqlCommand
        Dim Referencia As String = STR_VACIO


        If Me.Tag = "Mod" Then
            strOrigen = sqlDocumentosProcesados()
        Else
            strOrigen = sqlDocumentosParaProcesar()
        End If

        'Agreag todos los registros de la seleccion
        Try
            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strOrigen, CON)
            REA = COM.ExecuteReader
            Do While REA.Read


                strOrigen = REA.GetInt32("HDoc_Doc_Num") & "|"
                strOrigen &= REA.GetDateTime("HDoc_Doc_Fec") & "|"
                strOrigen &= REA.GetString("HDoc_Usuario") & "|"
                Referencia = REA.GetString("HDoc_DR1_Num")
                strOrigen &= Referencia & "|"
                strOrigen &= REA.GetInt32("HDoc_Doc_Ano") & "|"
                strOrigen &= REA.GetInt32("HDoc_Doc_Cat") & "|"
                strOrigen &= 1

                cFunciones.AgregarFila(dgPolizasImportacion, strOrigen)
            Loop

            'If dgPolizasImporatcion.Rows.Count = 1 Then

            '    celdaRefFactura.Text = Referencia
            'End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub botonQuitDetalle_Click(sender As Object, e As EventArgs) Handles botonQuitDetalle.Click
        Dim Linea As Integer
        If dgDetalle.SelectedRows.Count = 0 Then Exit Sub
        Try
            If dgDetalle.Rows.Count = 1 Then
            Else
                If MsgBox("You sure you want to delete the row Code " & Val(dgDetalle.SelectedCells(0).Value) & " ?", vbQuestion + vbYesNo + vbDefaultButton2) = vbYes Then
                    dgDetalle.CurrentRow.Cells(24).Value = 2
                    Linea = dgDetalle.CurrentRow.Cells(19).Value
                    dgDetalle.CurrentRow.Visible = False
                    '   dgDetalle.Rows.Remove(dgDetalle.CurrentRow)
                End If
            End If
            CalcularTotales()
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub MostrarPackingList()
        Dim frm As New frmPackingHSM
        Dim i As Integer = INT_CERO
        Dim j As Integer = INT_CERO
        Dim k As Integer = INT_CERO
        Dim strSQL As String = STR_VACIO
        Dim existe As Boolean
        Dim strFila As String = STR_VACIO
        Dim Tara As Double
        Dim KG As Double
        Dim LBS As Double

        Try
            If dgOculto.Rows.Count = 0 Then
                frm.dgDetalle.Rows.Clear()

                frm.Catalogo = celdaCatalogo.Text
                frm.Linea = dgDetalle.SelectedCells(19).Value
                frm.Numero = celdaNumero.Text
                frm.Anio = celdaAnio.Text
                frm.Medida = dgDetalle.SelectedCells(2).Value
                If Sesion.idGiro = 2 Then ' (Sesion.IdEmpresa = 15) Or (Sesion.IdEmpresa = 18) Or (Sesion.IdEmpresa = 19) Or (Sesion.IdEmpresa = 20) Or (Sesion.IdEmpresa = 21) Then
                    frm.gbKilos.Enabled = False
                    frm.gbLibras.Enabled = False
                    frm.dgDetalle.Columns(3).HeaderText = "Peso Auditado"
                    frm.dgDetalle.Columns(4).HeaderText = "Peso Facturado"
                    frm.dgDetalle.Columns(5).HeaderText = "Correlativo"
                End If
                frm.ShowDialog(Me)

            ElseIf dgOculto.Rows.Count > 0 Then
                frm.dgDetalle.Rows.Clear()
                If Sesion.idGiro = 2 Then ' (Sesion.IdEmpresa = 15) Or (Sesion.IdEmpresa = 18) Or (Sesion.IdEmpresa = 19) Or (Sesion.IdEmpresa = 20) Or (Sesion.IdEmpresa = 21) Then
                    frm.gbKilos.Enabled = False
                    frm.gbLibras.Enabled = False
                    frm.dgDetalle.Columns(3).HeaderText = "Peso Auditado"
                    frm.dgDetalle.Columns(4).HeaderText = "Peso Facturado"
                    frm.dgDetalle.Columns(5).HeaderText = "Correlativo"
                End If
                'For j = 0 To dgOculto.Rows.Count - 1
                '    If dgOculto.Rows(j).Cells("colLineaDetalle").Value = dgDetalle.CurrentRow.Cells("colLinea").Value Then
                '        existe = True
                '    End If



                For k = 0 To dgOculto.Rows.Count - 1
                    If dgOculto.Rows(k).Cells("colLineaDetalle").Value = dgDetalle.CurrentRow.Cells("colLinea").Value Then
                        existe = True
                    End If
                    If existe Then

                        If dgOculto.Rows(k).Cells("colLinea2").Value = dgDetalle.CurrentRow.Cells("colLinea").Value Then
                            If dgOculto.Rows(k).Cells("colXtraBox").Value = 1 Or dgOculto.Rows(k).Cells("colXtraBox").Value = 0 Then
                                'Tara = dgOculto.Rows(k).Cells("colTara").Value
                                LBS = dgOculto.Rows(k).Cells("colCantMedida").Value
                                KG = (LBS / 2.2046)

                                strFila = 1 & "|"         'Paquetes
                                strFila &= dgOculto.Rows(k).Cells("colNumCaja").Value & "|"   'Numero de Caja
                                strFila &= dgOculto.Rows(k).Cells("colTipoBulto").Value & "|"                ' Tara
                                strFila &= dgOculto.Rows(k).Cells("colPesoNeto").Value & "|"                 ' Peso Neto
                                strFila &= dgOculto.Rows(k).Cells("colCantMedida").Value & "|"               ' Peso Bruto
                                strFila &= dgOculto.Rows(k).Cells("colTara").Value & "|"                     ' Cantidad de Conos
                                strFila &= dgOculto.Rows(k).Cells("colRef").Value & "|"                      ' Color de cono

                                strFila &= 1 & "|"
                                strFila &= dgOculto.Rows(k).Cells("colLineaDetalle").Value & "|"
                                strFila &= dgOculto.Rows(k).Cells("colLinea2").Value & "|"
                                strFila &= dgOculto.Rows(k).Cells("colPaquetes").Value & "|"  ' Turno

                                strFila &= dgOculto.Rows(k).Cells("col_Gin").Value & "|"            ' Gin
                                strFila &= dgOculto.Rows(k).Cells("col_GBac").Value & "|"           ' Gin Bac
                                strFila &= dgOculto.Rows(k).Cells("col_Crp").Value & "|"              ' Crp
                                strFila &= dgOculto.Rows(k).Cells("col_Ref").Value

                                cFunciones.AgregarFila(frm.dgDetalle, strFila)
                            End If
                        End If
                    End If
                Next

                'End If
                'Next

                If existe Then
                    frm.Catalogo = celdaCatalogo.Text
                    frm.Linea = dgDetalle.SelectedCells(19).Value
                    frm.Numero = Val(celdaNumero.Text)
                    frm.Anio = (celdaAnio.Text)
                    frm.Medida = dgDetalle.SelectedCells(2).Value
                    'frm.Tara = dgOculto.CurrentRow.Cells("colTara").Value
                    'frm.LBS = dgOculto.CurrentRow.Cells("colCantMedida").Value
                    'frm.Referencia = dgOculto.CurrentRow.Cells("colRef").Value
                    frm.ShowDialog(Me)

                End If
                If existe = False Then
                    'frm.dgDetalle.Rows.Clear()
                    frm.Catalogo = celdaCatalogo.Text
                    frm.Linea = dgDetalle.SelectedCells(19).Value
                    frm.Numero = celdaNumero.Text
                    frm.Anio = celdaAnio.Text
                    frm.Medida = dgDetalle.SelectedCells(2).Value
                    frm.ShowDialog(Me)
                End If

            End If



            If frm.Aceptado = True Then


                For i = 0 To frm.dgDetalle.Rows.Count - 1

                    strSQL = Sesion.IdEmpresa & "|" '1
                    strSQL &= frm.celdaCatalogo.Text & "|" '2
                    strSQL &= frm.celdaAnio.Text & "|" '3
                    strSQL &= frm.celdaNumero.Text & "|" '4
                    strSQL &= frm.dgDetalle.Rows(i).Cells("colLineaPack").Value & "|" '5
                    strSQL &= frm.dgDetalle.Rows(i).Cells("colLineaDet").Value & "|" '6
                    strSQL &= frm.dgDetalle.Rows(i).Cells("colReferencia").Value & "|" 'Color de Conos 7
                    strSQL &= frm.dgDetalle.Rows(i).Cells("colLibrasBrutas").Value & "|" 'Conos 8
                    strSQL &= frm.dgDetalle.Rows(i).Cells("colTipoBulto").Value & "|" 'Turno
                    strSQL &= frm.dgDetalle.Rows(i).Cells("colKilosBrutos").Value & "|" 'lbs brutas 9
                    strSQL &= frm.dgDetalle.Rows(i).Cells("colKilosNetos").Value & "|" ' libras netas 10
                    strSQL &= frm.dgDetalle.Rows(i).Cells("colTara").Value & "|" 'Numero de caja 11
                    strSQL &= frm.dgDetalle.Rows(i).Cells("colTaraLbs").Value & "|" 'Tara 12
                    strSQL &= frm.dgDetalle.Rows(i).Cells("colXtraPack").Value & "|" '12

                    strSQL &= frm.dgDetalle.Rows(i).Cells("colGin").Value & "|" 'Gin
                    strSQL &= frm.dgDetalle.Rows(i).Cells("colGBac").Value & "|" 'GBac
                    strSQL &= frm.dgDetalle.Rows(i).Cells("colCrp").Value & "|" 'Crp
                    strSQL &= frm.dgDetalle.Rows(i).Cells("col_Ref").Value 'Ref
                    If dgOculto.Rows.Count > 0 Then
                        For l As Integer = 0 To dgOculto.Rows.Count - 1
                            If frm.dgDetalle.Rows(i).Cells("colLineaDet").Value = dgOculto.Rows(l).Cells("colLineaDetalle").Value And
                               frm.dgDetalle.Rows(i).Cells("colLineaPack").Value = dgOculto.Rows(l).Cells("colLinea2").Value And
                               frm.dgDetalle.Rows(i).Cells("colXtraPack").Value = 1 Then
                                Exit For
                            ElseIf frm.dgDetalle.Rows(i).Cells("colXtraPack").Value = 0 Then
                                cFunciones.AgregarFila(dgOculto, strSQL)
                                Exit For
                            ElseIf frm.dgDetalle.Rows(i).Cells("colXtraPack").Value = 2 And frm.dgDetalle.Rows(i).Cells("colXtraPack").Visible = False Then
                                dgOculto.Rows(l).Cells("colXtraBox").Value = 2
                                Exit For
                            End If
                        Next
                    Else
                        cFunciones.AgregarFila(dgOculto, strSQL)
                    End If

                Next

                'Procedimiento de cuadre de packingList con el detalle
                If frm.celdaSumaBultos.Text = dgDetalle.CurrentRow.Cells("colbultos").Value Then
                Else
                    If MsgBox("The number of packages does not match the detail, want to update packages the detail?", vbYesNo + vbExclamation + vbDefaultButton2, "Note") = vbYes Then
                        dgDetalle.CurrentRow.Cells("colBultos").Value = frm.celdaSumaBultos.Text

                    End If
                End If

                If frm.celdaTotalK.Text = dgDetalle.CurrentRow.Cells("colCantidad").Value Then 'libras netas
                Else
                    If MsgBox("The sum of packages does not match the detail, you want to update the amount in detail?", vbYesNo + vbExclamation + vbDefaultButton2, "Note") = vbYes Then
                        dgDetalle.CurrentRow.Cells("colCantidad").Value = frm.celdaTotalK.Text
                        dgDetalle.CurrentRow.Cells("colSubtotal").Value = (dgDetalle.CurrentRow.Cells("colPrecio").Value * dgDetalle.CurrentRow.Cells("colcantidad").Value)
                    End If
                End If


            End If

            CalcularTotales()
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub dgDetalle_DoubleClick(sender As Object, e As EventArgs) Handles dgDetalle.DoubleClick

        Dim frm As New frmSeleccionar
        Dim COM As New MySqlCommand
        Dim COM2 As New MySqlCommand
        Dim conec As New MySqlConnection
        Dim strCondicion As String = STR_VACIO
        Dim strSQL As String = STR_VACIO
        Dim strSQL2 As String = STR_VACIO
        Dim Bodega As String = STR_VACIO


        If dgDetalle.Rows.Count = vbEmpty Then Exit Sub

        Select Case dgDetalle.CurrentCell.ColumnIndex
            Case 7
                If Sesion.idGiro = 2 Then '' (Sesion.IdEmpresa = 18) Or (Sesion.IdEmpresa = 15) Or (Sesion.IdEmpresa = 19) Or (Sesion.IdEmpresa = 20) Or (Sesion.IdEmpresa = 21) Then
                    Dim Re As New frmRequisiciones
                    Dim dblSaldo As Double
                    Dim dblPrecio As Double
                    Dim dblPrecioFibra As Double = INT_CERO
                    Dim strFila As String = STR_VACIO
                    Dim logVerificar As Boolean = False
                    Dim strSql_ As String = STR_VACIO
                    Dim COM_ As MySqlCommand
                    Dim rea_ As MySqlDataReader

                    If (Sesion.IdEmpresa = 15 And intTipo = 2) Or (Sesion.IdEmpresa = 20 And intTipo = 2) Then
                        strSql_ = " SELECT c.cat_num id, i.inv_descripcion descripcion
                                    FROM Inventarios i
                                    LEFT JOIN Articulos a ON a.art_sisemp = i.inv_sisemp AND a.art_codigo = i.inv_artcodigo
                                    LEFT JOIN Catalogos c ON c.cat_num = art_clase AND c.cat_ext = 'Terminado'
                                    WHERE i.inv_sisemp = {emp} AND i.inv_numero = {num}"
                        strSql_ = strSql_.Replace("{emp}", Sesion.IdEmpresa)
                        strSql_ = strSql_.Replace("{num}", dgDetalle.CurrentRow.Cells("colCodigo").Value)

                        MyCnn.CONECTAR = strConexion
                        COM_ = New MySqlCommand(strSql_, CON)
                        rea_ = COM_.ExecuteReader

                        If rea_.HasRows Then
                            rea_.Read()
                            Re.codInventario = rea_.GetInt32("id")
                            Re.Orden = rea_.GetString("descripcion")
                        End If

                    End If
                    Re.Codigo = intTipo
                    If Me.Tag = "Nuevo" Then
                        If (intTipo = 2) Then
                            Re.Unico = True
                            Re.Cantidad = dgDetalle.CurrentRow.Cells("colCantidad").Value
                            Re.intnumero = dgDetalle.CurrentRow.Cells("colNumPoliza").Value
                            Re.intaño = dgDetalle.CurrentRow.Cells("colAnioPoliza").Value
                            Re.dtFecha = dtpFech.Value
                            Re.ShowDialog(Me)
                            Re.Hide()
                        ElseIf (intTipo = 4) Then
                            Re.Unico = True
                            Re.intTipoIngeso = intTipo
                            Re.Cantidad = dgDetalle.CurrentRow.Cells("colCantidad").Value
                            Re.intnumero = dgDetalle.CurrentRow.Cells("colNumPoliza").Value
                            Re.intaño = dgDetalle.CurrentRow.Cells("colAnioPoliza").Value
                            Re.dtFecha = dtpFech.Value
                            Re.Desperdicio = True
                            Re.intTipoWaste = intTipoWaste
                            Re.ShowDialog(Me)
                            Re.Hide()
                        ElseIf (intTipo = 5) Then
                            Re.Unico = True
                            Re.intTipoIngeso = intTipo
                            Re.Cantidad = dgDetalle.CurrentRow.Cells("colCantidad").Value
                            Re.intnumero = dgDetalle.CurrentRow.Cells("colNumPoliza").Value
                            Re.intaño = dgDetalle.CurrentRow.Cells("colAnioPoliza").Value
                            Re.dtFecha = dtpFech.Value
                            Re.Invisible = True
                            Re.TipoInvisible = intTipoInvisible
                            Re.ShowDialog(Me)
                            Re.Hide()
                        ElseIf (intTipo = 6) Then
                            Re.Unico = True
                            Re.Cantidad = dgDetalle.CurrentRow.Cells("colCantidad").Value
                            Re.intnumero = dgDetalle.CurrentRow.Cells("colNumPoliza").Value
                            Re.intaño = dgDetalle.CurrentRow.Cells("colAnioPoliza").Value
                            Re.dtFecha = dtpFech.Value
                            Re.Proceso = True
                            Re.ShowDialog(Me)
                            Re.Hide()
                        ElseIf (intTipo = 14) Then
                            Re.intTipoIngeso = intTipo
                            Re.Unico = True
                            Re.Cantidad = dgDetalle.CurrentRow.Cells("colCantidad").Value
                            Re.intnumero = dgDetalle.CurrentRow.Cells("colNumPoliza").Value
                            Re.intaño = dgDetalle.CurrentRow.Cells("colAnioPoliza").Value
                            Re.dtFecha = dtpFech.Value
                            Re.ShowDialog(Me)
                            Re.Hide()
                        ElseIf (intTipo = 15) Then
                            Re.intTipoIngeso = intTipo
                            Re.Unico = True
                            Re.Cantidad = dgDetalle.CurrentRow.Cells("colCantidad").Value
                            Re.intnumero = dgDetalle.CurrentRow.Cells("colNumPoliza").Value
                            Re.intaño = dgDetalle.CurrentRow.Cells("colAnioPoliza").Value
                            Re.dtFecha = dtpFech.Value
                            Re.ShowDialog(Me)
                            Re.Hide()
                        ElseIf (intTipo = 16) Then
                            Re.intTipoIngeso = intTipo
                            Re.Unico = True
                            Re.Cantidad = dgDetalle.CurrentRow.Cells("colCantidad").Value
                            Re.intnumero = dgDetalle.CurrentRow.Cells("colNumPoliza").Value
                            Re.intaño = dgDetalle.CurrentRow.Cells("colAnioPoliza").Value
                            Re.dtFecha = dtpFech.Value
                            Re.ShowDialog(Me)
                            Re.Hide()
                        ElseIf (intTipo = 17) Then
                            Re.intTipoIngeso = intTipo
                            Re.Unico = True
                            Re.Cantidad = dgDetalle.CurrentRow.Cells("colCantidad").Value
                            Re.intnumero = dgDetalle.CurrentRow.Cells("colNumPoliza").Value
                            Re.intaño = dgDetalle.CurrentRow.Cells("colAnioPoliza").Value
                            Re.dtFecha = dtpFech.Value
                            Re.ShowDialog(Me)
                            Re.Hide()

                        End If
                    ElseIf dgLista.CurrentRow.Cells("colClase").Value = "Production" Then
                        Re.Unico = True
                        Re.Cantidad = dgDetalle.CurrentRow.Cells("colCantidad").Value
                        Re.intnumero = dgDetalle.CurrentRow.Cells("colNumPoliza").Value
                        Re.intaño = dgDetalle.CurrentRow.Cells("colAnioPoliza").Value
                        Re.dtFecha = dtpFech.Value
                        Re.ShowDialog(Me)
                        Re.Hide()

                    End If

                    If Re.Aceptado Then
                        If dgPolizasImportacion.Rows.Count = 0 Then
                            For i As Integer = 0 To Re.dgLista.Rows.Count - 1
                                dblSaldo = Re.dgLista.Rows(i).Cells("colDescargo").Value
                                ' dblPrecio = Re.dgLista.Rows(i).Cells("colPrecio").Value + Re.dgLista.Rows(i).Cells("colGFMO").Value
                                dblPrecio = CDbl(Re.dgLista.Rows(i).Cells("colPrecio").Value) + CDbl(Re.dgLista.Rows(i).Cells("colGFMO").Value)
                                If dblSaldo > vbEmpty Then
                                    strFila = Re.dgLista.Rows(i).Cells("colNumero").Value & "|"
                                    strFila &= Re.dgLista.Rows(i).Cells("colFecha").Value & "|"
                                    strFila &= STR_VACIO & "|"
                                    strFila &= Re.dgLista.Rows(i).Cells("colReferencia").Value & "|"
                                    strFila &= Re.dgLista.Rows(i).Cells("colAno").Value & "|"
                                    strFila &= 980 & "|"
                                    strFila &= INT_CERO
                                    cFunciones.AgregarFila(dgPolizasImportacion, strFila)
                                    If intTipo >= 14 Or (Sesion.IdEmpresa = 22 And intTipo = 4) Or (Sesion.IdEmpresa = 22 And intTipo = 5) Then
                                        celdaRef2.Text = Re.dgLista.Rows(i).Cells("colFabricForm").Value
                                        celdaRefFactura.Text = Re.dgLista.Rows(i).Cells("colLoteProd").Value
                                        celdaRef1.Text = Re.dgLista.Rows(i).Cells("colTenido").Value
                                    End If
                                    dgDetalle.CurrentRow.Cells("colCantidad").Value = dblSaldo.ToString(FORMATO_MONEDA)
                                    dgDetalle.CurrentRow.Cells("colPrecio").Value = dblPrecio
                                    dgDetalle.CurrentRow.Cells("colAnioPoliza").Value = Re.dgLista.Rows(i).Cells("colAno").Value
                                    dgDetalle.CurrentRow.Cells("colNumPoliza").Value = Re.dgLista.Rows(i).Cells("colNumero").Value
                                End If
                            Next
                        Else
                            If Me.Tag = "Nuevo" Then
                                For i As Integer = 0 To Re.dgLista.Rows.Count - 1
                                    If dgDetalle.CurrentRow.Cells("colNumPoliza").Value = Re.dgLista.Rows(i).Cells("colNumero").Value And
                                            dgDetalle.CurrentRow.Cells("colAnioPoliza").Value = Re.dgLista.Rows(i).Cells("colAno").Value Then
                                        logVerificar = True
                                        Exit For
                                    Else
                                        logVerificar = False
                                    End If
                                Next

                                For j As Integer = 0 To Re.dgLista.Rows.Count - 1
                                    If logVerificar = True Then
                                        dblSaldo = Re.dgLista.Rows(j).Cells("colDescargo").Value
                                        ' dblPrecio = Re.dgLista.Rows(j).Cells("colPrecio").Value + Re.dgLista.Rows(j).Cells("colGFMO").Value
                                        dblPrecio = CDbl(Re.dgLista.Rows(j).Cells("colPrecio").Value) + CDbl(Re.dgLista.Rows(j).Cells("colGFMO").Value)
                                        If dblSaldo > vbEmpty Then
                                            dgPolizasImportacion.CurrentRow.Cells("colNumero").Value = Re.dgLista.Rows(j).Cells("colNumero").Value
                                            dgPolizasImportacion.CurrentRow.Cells("colFecha").Value = Re.dgLista.Rows(j).Cells("colFecha").Value
                                            dgPolizasImportacion.CurrentRow.Cells("colReference").Value = Re.dgLista.Rows(j).Cells("colReferencia").Value
                                            dgPolizasImportacion.CurrentRow.Cells("colAno").Value = Re.dgLista.Rows(j).Cells("colAno").Value
                                            dgDetalle.CurrentRow.Cells("colCantidad").Value = dblSaldo.ToString(FORMATO_MONEDA)
                                            dgDetalle.CurrentRow.Cells("colPrecio").Value = dblPrecio
                                            dgDetalle.CurrentRow.Cells("colAnioPoliza").Value = Re.dgLista.Rows(j).Cells("colAno").Value
                                            dgDetalle.CurrentRow.Cells("colNumPoliza").Value = Re.dgLista.Rows(j).Cells("colNumero").Value
                                        End If
                                    Else
                                        dblSaldo = Re.dgLista.Rows(j).Cells("colDescargo").Value
                                        ' dblPrecio = Re.dgLista.Rows(j).Cells("colPrecio").Value + Re.dgLista.Rows(j).Cells("colGFMO").Value
                                        dblPrecio = CDbl(Re.dgLista.Rows(j).Cells("colPrecio").Value) + CDbl(Re.dgLista.Rows(j).Cells("colGFMO").Value)
                                        If dblSaldo > vbEmpty Then
                                            strFila = Re.dgLista.Rows(j).Cells("colNumero").Value & "|"
                                            strFila &= Re.dgLista.Rows(j).Cells("colFecha").Value & "|"
                                            strFila &= STR_VACIO & "|"
                                            strFila &= Re.dgLista.Rows(j).Cells("colReferencia").Value & "|"
                                            strFila &= Re.dgLista.Rows(j).Cells("colAno").Value & "|"
                                            strFila &= 980 & "|"
                                            strFila &= INT_CERO
                                            cFunciones.AgregarFila(dgPolizasImportacion, strFila)

                                            dgDetalle.CurrentRow.Cells("colCantidad").Value = dblSaldo.ToString(FORMATO_MONEDA)
                                            dgDetalle.CurrentRow.Cells("colPrecio").Value = dblPrecio
                                            dgDetalle.CurrentRow.Cells("colAnioPoliza").Value = Re.dgLista.Rows(j).Cells("colAno").Value
                                            dgDetalle.CurrentRow.Cells("colNumPoliza").Value = Re.dgLista.Rows(j).Cells("colNumero").Value
                                        End If
                                    End If
                                Next
                            Else
                                For i As Integer = 0 To Re.dgLista.Rows.Count - 1
                                    dblSaldo = Re.dgLista.Rows(i).Cells("colDescargo").Value
                                    dblPrecio = CDbl(Re.dgLista.Rows(i).Cells("colPrecio").Value) + CDbl(Re.dgLista.Rows(i).Cells("colGFMO").Value)
                                    If dblSaldo > vbEmpty Then
                                        dgPolizasImportacion.CurrentRow.Cells("colNumero").Value = Re.dgLista.Rows(i).Cells("colNumero").Value
                                        dgPolizasImportacion.CurrentRow.Cells("colFecha").Value = Re.dgLista.Rows(i).Cells("colFecha").Value
                                        dgPolizasImportacion.CurrentRow.Cells("colReference").Value = Re.dgLista.Rows(i).Cells("colReferencia").Value
                                        dgPolizasImportacion.CurrentRow.Cells("colAno").Value = Re.dgLista.Rows(i).Cells("colAno").Value
                                        dgDetalle.CurrentRow.Cells("colCantidad").Value = dblSaldo.ToString(FORMATO_MONEDA)
                                        dgDetalle.CurrentRow.Cells("colPrecio").Value = dblPrecio
                                        dgDetalle.CurrentRow.Cells("colAnioPoliza").Value = Re.dgLista.Rows(i).Cells("colAno").Value
                                        dgDetalle.CurrentRow.Cells("colNumPoliza").Value = Re.dgLista.Rows(i).Cells("colNumero").Value
                                    End If
                                Next
                            End If
                        End If
                        CalcularTotales()
                    End If
                End If
            Case 8
                If dgDetalle.Columns("colBoxNumber").Visible = False Then

                    MostrarPackingList()
                End If


            Case 10
                Try
                    frm.Titulo = " Wharehouse"
                    frm.Campos = " c.cat_clave Warehouse, c.cat_desc Description"
                    frm.Tabla = " Catalogos c"
                    frm.FiltroText = " Enter the Wharehouse to filter"
                    frm.Filtro = " c.cat_clave "
                    frm.Condicion = "  c.cat_clase = 'Bodegas'"

                    frm.ShowDialog(Me)
                    If frm.DialogResult = Forms.DialogResult.OK Then
                        dgDetalle.SelectedCells(10).Value = frm.LLave
                        Bodega = frm.LLave
                        celdaBodega.Text = frm.LLave

                        'Actualiza fila Modificada
                        strSQL = "UPDATE Dcmtos_DTL SET DDoc_RF2_Cod = '{bodega}' WHERE DDoc_Sis_Emp = {empresa} AND DDoc_Doc_Cat = 47 AND DDoc_Doc_Ano = {anio} AND DDoc_Doc_Num = {numero} AND DDoc_Doc_Lin = {linea}"
                        If Sesion.IdEmpresa = 18 Then
                            strSQL &= "; UPDATE PDM.Dcmtos_DTL SET DDoc_RF2_Cod = '{bodega}' WHERE DDoc_Sis_Emp = {empresa} AND DDoc_Doc_Cat = 47 AND DDoc_Doc_Ano = {anio} AND DDoc_Doc_Num = {numero} AND DDoc_Doc_Lin = {linea}"
                        End If
                        strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
                        strSQL = Replace(strSQL, "{anio}", celdaAnio.Text)
                        strSQL = Replace(strSQL, "{numero}", celdaNumero.Text)
                        strSQL = Replace(strSQL, "{linea}", dgDetalle.SelectedCells(19).Value)
                        strSQL = Replace(strSQL, "{bodega}", Bodega)

                        MyCnn.CONECTAR = strConexion
                        COM = New MySqlCommand(strSQL, CON)
                        COM.ExecuteNonQuery()


                        'Actualizar Encabezado
                        strSQL2 = "UPDATE Dcmtos_HDR SET HDoc_RF1_Cod = '{bodega}' WHERE HDoc_Sis_Emp = {empresa} AND HDoc_Doc_Cat = 47 AND HDoc_Doc_Ano = {anio} AND HDoc_Doc_Num = {numero}"
                        If Sesion.IdEmpresa = 18 Then
                            strSQL2 &= "; UPDATE PDM.Dcmtos_HDR SET HDoc_RF1_Cod = '{bodega}' WHERE HDoc_Sis_Emp = {empresa} AND HDoc_Doc_Cat = 47 AND HDoc_Doc_Ano = {anio} AND HDoc_Doc_Num = {numero}"
                        End If
                        strSQL2 = Replace(strSQL2, "{empresa}", Sesion.IdEmpresa)
                        strSQL2 = Replace(strSQL2, "{anio}", celdaAnio.Text)
                        strSQL2 = Replace(strSQL2, "{numero}", celdaNumero.Text)
                        strSQL2 = Replace(strSQL2, "{bodega}", Bodega)

                        MyCnn.CONECTAR = strConexion
                        COM = New MySqlCommand(strSQL2, CON)
                        COM.ExecuteNonQuery()

                        If Me.Tag = "Mod" Then
                            MsgBox("The change of warehouse has already been carried out" & vbCr & vbCr & "NOTE: It is not necessary to save the document", vbInformation, "Notice")
                        End If


                    End If
                Catch ex As Exception
                    MsgBox(ex.ToString)
                End Try

            Case 12

                'If dgDetalle.Columns("colBoxNumber").Visible = False Then
                Dim opt As New frmOption

                opt.Titulo = " Option"
                opt.Mensaje = "Select an option"
                opt.Opciones = "Annotations" & "|" & "Inventory Reservation"

                If opt.ShowDialog = Forms.DialogResult.OK Then

                    Select Case opt.Seleccion

                        Case INT_CERO
                            dgDetalle.SelectedCells(12).ReadOnly = True
                            PedirComentario()
                        Case INT_UNO
                            MostrarReferencias(dgDetalle.Rows.Count)
                    End Select
                Else
                    Exit Sub
                End If
               ' End If


            'Case 30
                'Dim op As New frmOption
                'op.Opciones = "GOOD |" & " BAD |" & "CLEARENCE"
                'op.Titulo = " DOCUMENTS NOTES "
                'op.ShowDialog(Me)
                'Me.DialogResult = DialogResult.OK
                'Select Case op.Seleccion
                '    Case 0  ' Good
                '        dgDetalle.SelectedCells(30).Value = 0
                '        dgDetalle.SelectedCells(31).Value = "GOOD"
                '        If Me.Tag = "Mod" Then
                '            If PermisoActualizar() = True Then
                '                ActualizarEstado()
                '            Else
                '                MsgBox("You don't have access to update the status")
                '            End If
                '        End If
                '    Case 1 'BAD 
                '        dgDetalle.SelectedCells(30).Value = 2
                '        dgDetalle.SelectedCells(31).Value = "BAD"
                '        If Me.Tag = "Mod" Then
                '            If PermisoActualizar() = True Then
                '                ActualizarEstado()
                '            Else
                '                MsgBox("You don't have access to update the status")
                '            End If
                '        End If
                '    Case 2 'Clearence
                '        dgDetalle.SelectedCells(30).Value = 1
                '        dgDetalle.SelectedCells(31).Value = "CLEARENCE"
                '        If Me.Tag = "Mod" Then
                '            If PermisoActualizar() = True Then
                '                ActualizarEstado()
                '            Else
                '                MsgBox("You don't have access to update the status")
                '            End If
                '        End If
                'End Select

                ' MARCAR ESTADO DEL HILO GOOD/BAD'
                'If dgDetalle.SelectedCells(30).Value = "GOOD" Then
                '    dgDetalle.SelectedCells(29).Value = 1
                '    dgDetalle.SelectedCells(30).Value = "BAD"
                'Else
                '    dgDetalle.SelectedCells(29).Value = 0
                '    dgDetalle.SelectedCells(30).Value = "GOOD"
                'End If
            Case 31
                Dim idGood As Integer = INT_CERO
                Dim idClereance As Integer = INT_CERO
                Dim idOld As Integer = INT_CERO
                Dim COM31 As MySqlCommand
                Dim REA31 As MySqlDataReader
                Dim strSQL31 As String = STR_VACIO

                strSQL31 = SQLCargarEstado()
                Try
                    MyCnn.CONECTAR = strConexion

                    COM31 = New MySqlCommand(strSQL31, CON)
                    REA31 = COM31.ExecuteReader

                    If REA31.HasRows Then
                        Do While REA31.Read
                            If REA31.GetString("nombre") = "GOOD" Then
                                idGood = REA31.GetInt32("id")
                            ElseIf REA31.GetString("nombre") = "CLEREANCE" Then
                                idClereance = REA31.GetInt32("id")
                            ElseIf REA31.GetString("nombre") = "OLD INVENTORY" Then
                                idOld = REA31.GetInt32("id")
                            End If
                        Loop
                    End If
                Catch ex As Exception
                    MsgBox(ex.ToString)
                End Try

                Dim op As New frmOption
                op.Opciones = "GOOD |" & " CLEARENCE |" & "OLD INVENTORY"
                op.Titulo = " DOCUMENTS NOTES "
                op.ShowDialog(Me)
                Me.DialogResult = DialogResult.OK
                Select Case op.Seleccion
                    Case 0  ' Good
                        dgDetalle.SelectedCells(30).Value = idGood
                        dgDetalle.SelectedCells(31).Value = "GOOD"
                        If Me.Tag = "Mod" Then
                            ActualizarEstado()
                        End If
                    Case 1 '  Clearence
                        dgDetalle.SelectedCells(30).Value = idClereance
                        dgDetalle.SelectedCells(31).Value = "CLEARENCE"
                        If Me.Tag = "Mod" Then
                            ActualizarEstado()
                        End If
                    Case 2 ' Old Inventory
                        dgDetalle.SelectedCells(30).Value = idOld
                        dgDetalle.SelectedCells(31).Value = "OLD INVENTORY"
                        If Me.Tag = "Mod" Then
                            ActualizarEstado()
                        End If
                End Select

        End Select

    End Sub

    'Query que carga los estados
    Private Function SQLCargarEstado() As String

        Dim strsql As String = STR_VACIO
        strsql = " SELECT IFNULL(c.cat_num,0) id, IFNULL(c.cat_desc,'') nombre"
        strsql &= "     FROM Catalogos c"
        strsql &= "         WHERE c.cat_clase = 'StatusIngBdg'"

        Return strsql
    End Function

    'Configura y muestra la ventana para modificar reservas
    Private Sub MostrarReferencias(ByVal Fila As Integer)
        Dim Rsv As New frmReservas
        Dim strSQL As String = STR_VACIO
        Dim COM As MySqlCommand
        Dim conec As MySqlConnection
        Dim conteo As Integer = vbEmpty


        Rsv.Empresa = Sesion.IdEmpresa
        Rsv.Catalogo = 47
        Rsv.Anio = celdaAnio.Text
        Rsv.Numero = celdaNumero.Text
        Rsv.Linea = dgDetalle.SelectedCells(19).Value
        Rsv.InfoProducto = dgDetalle.SelectedCells(1).Value
        Rsv.Medida = dgDetalle.SelectedCells(3).Value
        Rsv.Cantidad = dgDetalle.SelectedCells(7).Value
        Rsv.Reservado = dgDetalle.SelectedCells(23).Value

        Rsv.ShowDialog(Me)

        If Rsv.Modificado Then
            dgDetalle.CurrentRow.Cells(12).Style.BackColor = Color.Yellow
        End If

    End Sub

    Private Sub CalcularTotales()

        Dim i As Integer = 0
        dblDocTotal = 0
        dblDocCantidad = 0
        For i = 0 To dgDetalle.Rows.Count - 1
            If Sesion.idGiro = 2 Then
                dgDetalle.Rows(i).Cells("colSubTotal").Value = CDbl(dgDetalle.Rows(i).Cells("colCantidad").Value * dgDetalle.Rows(i).Cells("colPrecio").Value).ToString(FORMATO_MONEDA)
            Else
                dgDetalle.Rows(i).Cells("colSubTotal").Value = (dgDetalle.Rows(i).Cells("colCantidad").Value * dgDetalle.Rows(i).Cells("colPrecio").Value)
            End If
            dblDocTotal = dblDocTotal + (dgDetalle.Rows(i).Cells("colSubTotal").Value)
            dblDocCantidad = dblDocCantidad + (dgDetalle.Rows(i).Cells("colCantidad").Value)
        Next

        celdaTotal.Text = dblDocTotal.ToString(FORMATO_MONEDA)
        celdaSubTotal.Text = dblDocCantidad.ToString(FORMATO_MONEDA)


    End Sub

    Private Sub botonParciales_Click(sender As Object, e As EventArgs) Handles botonParciales.Click
        If MsgBox("Import policies with multiple references or batches" & vbCr & vbCr & "This Option will allow you to enter a reference at a time" & vbCr & "For import policies with several reference invoices or with several products / lots on the same line.", vbOKCancel + vbExclamation + vbDefaultButton2, "Entering Warehouses") = vbOK Then
            intMultiple = vbOK
            HabilitarTipo(intMultiple)
            botonQuitDetalle.Enabled = True
        End If
    End Sub

    Private Sub dgSubdocumentos_DoubleClick(sender As Object, e As EventArgs) Handles dgSubdocumentos.DoubleClick
        Dim SDoc As New frmSubDocumentos

        Select Case dgSubdocumentos.CurrentCell.ColumnIndex
            Case 2

                SDoc.SubDocumento = dgSubdocumentos.SelectedCells(0).Value
                SDoc.Año = celdaAnio.Text
                SDoc.Numero = celdaNumero.Text
                SDoc.Doc = dgSubdocumentos.SelectedCells(0).Value
                SDoc.Catalogo = 47
                SDoc.Año = celdaAnio.Text
                SDoc.Numero = celdaNumero.Text
                SDoc.Line = dgDetalle.CurrentRow.Cells("colLinea").Value
                SDoc.ShowDialog(Me)
        End Select
    End Sub

    Private Sub botonDespachos_Click(sender As Object, e As EventArgs) Handles botonDespachos.Click
        Dim strSQL As String
        Dim strSQL2 As String
        Dim COM As MySqlCommand
        Dim COM2 As MySqlCommand
        Dim conec As MySqlConnection
        Dim Revisado As Integer



        strSQL = "SELECT COUNT(*)"
        strSQL &= "      FROM Permisos p"
        strSQL &= "              WHERE p.pms_empresa = {empresa} and p.pms_codigo = 'REVISAR' and p.pms_modulo = 55 and p.pms_usuario = '{usuario}'"

        strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
        strSQL = Replace(strSQL, "{usuario}", Sesion.Usuario)

        conec = New MySqlConnection(strConexion)
        conec.Open()
        COM = New MySqlCommand(strSQL, conec)
        Revisado = COM.ExecuteScalar()
        conec.Close()


        If Revisado = 1 Then
            If MsgBox("Are you sure you want to dial Revised brand if the changes are irreversible", vbQuestion + vbYesNo + vbDefaultButton2, ) = MsgBoxResult.Yes Then
                strSQL2 = "UPDATE Dcmtos_HDR"
                strSQL2 &= "      SET HDoc_Pro_DCat = 1"
                strSQL2 &= "              WHERE HDoc_Sis_Emp = {empresa} and HDoc_Doc_Cat = 47 and HDoc_Doc_Ano = {anio} and HDoc_Doc_Num = {numero}"
                If Sesion.IdEmpresa = 18 Then
                    strSQL2 &= ";UPDATE PDM.Dcmtos_HDR"
                    strSQL2 &= "      SET HDoc_Pro_DCat = 1"
                    strSQL2 &= "              WHERE HDoc_Sis_Emp = {empresa} and HDoc_Doc_Cat = 47 and HDoc_Doc_Ano = {anio} and HDoc_Doc_Num = {numero}"
                End If
                strSQL2 = Replace(strSQL2, "{empresa}", Sesion.IdEmpresa)
                strSQL2 = Replace(strSQL2, "{anio}", celdaAnio.Text)
                strSQL2 = Replace(strSQL2, "{numero}", celdaNumero.Text)

                'Ejecuta la instrucción
                MyCnn.CONECTAR = strConexion
                COM2 = New MySqlCommand(strSQL2, CON)
                COM2.ExecuteNonQuery()

                botonDespachos.BackColor = Color.YellowGreen
                celdaRevisado.Text = Revisado

                cFunciones.EscribirRegistro(TBL_DOCUMENTOS, clsFunciones.AccEnum.acUpdate, celdaIDCliente.Text, 47, celdaAnio.Text, celdaNumero.Text)
            End If
        Else
            MsgBox("You do not have permission to Mark PERFORMED this Proforma")

        End If
    End Sub

    Private Sub dgLista_KeyDown(sender As Object, e As KeyEventArgs) Handles dgLista.KeyDown
        Try
            If e.KeyCode = Keys.F3 Then
                cfun.BuscarenLista(dgLista)
                e.Handled = True
                e.SuppressKeyPress = True
            ElseIf e.KeyCode = Keys.F6 Then
                cfun.MostrarDependencias(47, dgLista.SelectedCells(6).Value, dgLista.SelectedCells(0).Value)
            ElseIf e.KeyCode = Keys.F7 Then
                Dim rpt As New clsReportes
                rpt.Historial(dgLista.SelectedCells(0).Value, dgLista.SelectedCells(6).Value, 47)
            ElseIf e.KeyCode = Keys.F2 Then
                CambiarReferencia(47, dgLista.SelectedCells(6).Value, dgLista.SelectedCells(0).Value)
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub CambiarReferencia(ByVal Tipo As Integer, ByVal Anio As Integer, ByVal Numero As Integer)
        Dim strSQL As String = STR_VACIO
        Dim strSQL2 As String = STR_VACIO
        Dim COM As MySqlCommand
        Dim COM2 As New MySqlCommand
        Dim conec As MySqlConnection
        Dim Referencias As String = STR_VACIO
        Dim strTemp As String = STR_VACIO

        If MsgBox("Rename Associated Reference?", vbQuestion + vbYesNo + vbDefaultButton2, "Reference Invoice") = vbYes Then
            strSQL = "SELECT HDoc_DR1_Num"
            strSQL &= "     FROM Dcmtos_HDR"
            strSQL &= "          WHERE HDoc_Sis_Emp = {empresa} AND HDoc_Doc_Cat = {tipo} AND HDoc_Doc_Ano = {anio} AND HDoc_Doc_Num = {numero}"

            strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
            strSQL = Replace(strSQL, "{anio}", Anio)
            strSQL = Replace(strSQL, "{numero}", Numero)
            strSQL = Replace(strSQL, "{tipo}", Tipo)

            conec = New MySqlConnection(strConexion)
            conec.Open()
            COM = New MySqlCommand(strSQL, conec)
            Referencias = COM.ExecuteScalar
            conec.Close()
            conec.Dispose()
            conec = Nothing
            System.GC.Collect()

            strTemp = InputBox("Enter the Correction to the reference of this winery income", "Change Reference", Referencias)
            If Not (strTemp = vbNullString) Then
                strTemp = Trim(strTemp)
                If Not (strTemp = vbNullString) Then
                    If Not (strTemp = Referencias) Then
                        If MsgBox("Change the Reference to the winery will be changed" & vbCr & vbCr & "Previous: " & vbTab & Referencias & vbCr & "New: " & vbTab & strTemp & vbCr & vbCr & "NOTE: This change does not modify all documents" & vbCr & "Already made on this income", vbExclamation + vbOKCancel + vbDefaultButton2, "Chance Reference") = vbOK Then
                            strSQL2 = "UPDATE Dcmtos_HDR SET HDoc_DR1_Num = '{referencia}'"
                            strSQL2 &= "WHERE HDoc_Sis_Emp = {empresa} AND HDoc_Doc_Cat = {tipo} AND HDoc_Doc_Ano = {anio} AND HDoc_Doc_Num = {numero}"
                            If Sesion.IdEmpresa = 18 Then
                                strSQL2 &= ";UPDATE PDM.Dcmtos_HDR SET HDoc_DR1_Num = '{referencia}'"
                                strSQL2 &= "WHERE HDoc_Sis_Emp = {empresa} AND HDoc_Doc_Cat = {tipo} AND HDoc_Doc_Ano = {anio} AND HDoc_Doc_Num = {numero}"
                            End If
                            strSQL2 = Replace(strSQL2, "{empresa}", Sesion.IdEmpresa)
                            strSQL2 = Replace(strSQL2, "{anio}", Anio)
                            strSQL2 = Replace(strSQL2, "{numero}", Numero)
                            strSQL2 = Replace(strSQL2, "{tipo}", Tipo)
                            strSQL2 = Replace(strSQL2, "{referencia}", strTemp)

                            MyCnn.CONECTAR = strConexion
                            COM2 = New MySqlCommand(strSQL2, CON)
                            COM2.ExecuteNonQuery()

                            MsgBox("Change Made", vbInformation, "Information")
                            queryListaPrincipal()
                        End If
                    End If
                End If
            End If
        End If
    End Sub


    Private Sub botonMoneda_Click(sender As Object, e As EventArgs) Handles botonMoneda.Click
        Dim frm As New frmSeleccionar

        Try
            frm.Titulo = "Coin"
            frm.Campos = "c.cat_clave Moneda, c.cat_num ID, c.cat_sist"
            frm.Tabla = "Catalogos c"
            frm.FiltroText = " Enter the Coin To filter"
            frm.Filtro = " c.cat_clave "
            frm.Limite = 5
            frm.Ordenamiento = " c.cat_clave "
            frm.TipoOrdenamiento = ""
            frm.Condicion = "cat_clase='Monedas'"

            frm.ShowDialog(Me)

            If frm.DialogResult = Forms.DialogResult.OK Then
                celdaMoneda.Text = frm.LLave
                celdaIDMoneda.Text = frm.Dato
                celdaTasa.Text = frm.Dato2

            End If

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub botonPolizaC_Click(sender As Object, e As EventArgs) Handles botonPolizaC.Click
        Dim frm As New frmOption
        Dim NP As New clsPolizaContable
        Dim NPC As New frmNPolizasContables

        Try

            NP.intTipo = 47
            NP.intCiclo = celdaAnio.Text
            NP.intNumero = celdaNumero.Text
            If Sesion.idGiro = 2 And intTipo = 3 Then
                NP.intModo = 32
            ElseIf (Sesion.IdEmpresa = 15 And intTipo = 4) Or (Sesion.IdEmpresa = 18 And intTipo = 4) Or (Sesion.IdEmpresa = 19 And intTipo = 4) Or (Sesion.IdEmpresa = 20 And intTipo = 4) Or (Sesion.IdEmpresa = 21 And intTipo = 4) Then
                NP.intModo = 31
            ElseIf (Sesion.IdEmpresa = 15 And intTipo = 5) Or (Sesion.IdEmpresa = 18 And intTipo = 5) Or (Sesion.IdEmpresa = 19 And intTipo = 5) Or (Sesion.IdEmpresa = 20 And intTipo = 5) Or (Sesion.IdEmpresa = 21 And intTipo = 5) Then
                NP.intModo = 34
            ElseIf Sesion.idGiro = 2 And intTipo = 6 Then
                NP.intModo = 35
            ElseIf (Sesion.idGiro = 2 And intTipo = 2) Then
                NP.intModo = 30
            ElseIf (Sesion.idGiro = 2 And intTipo = 14) Then
                NP.intModo = 38
            ElseIf (Sesion.idGiro = 2 And intTipo = 15) Then
                NP.intModo = 39
            ElseIf (Sesion.idGiro = 2 And intTipo = 16) Then
                NP.intModo = 40
            ElseIf (Sesion.idGiro = 2 And intTipo = 17) Then
                NP.intModo = 41
            ElseIf Sesion.idGiro = 2 And (intTipo > 6 And intTipoIngreso <= 13) Then
                NP.intModo = 36
            ElseIf (Sesion.IdEmpresa = 15) Or (Sesion.IdEmpresa = 18) Or (Sesion.IdEmpresa = 19) Or (Sesion.IdEmpresa = 20) Or (Sesion.IdEmpresa = 21) Then
                NP.intModo = 11
            Else
                If intTipo = 0 Then
                    NP.intModo = 11
                ElseIf intTipo = 3 Then
                    NP.intModo = 8
                Else
                    NP.intModo = 12
                End If
            End If
            NP.MostrarPolizaContable()

        Catch ex As Exception
            MsgBox("It has no Accounting Policy")
        End Try
    End Sub

    Private Sub dgPolizasImporatcion_DoubleClick(sender As Object, e As EventArgs) Handles dgPolizasImportacion.DoubleClick
        Dim i As Integer

        If dgPolizasImportacion.Rows.Count < 1 Then
            Exit Sub
        ElseIf dgPolizasImportacion.Rows.Count = 1 Then
            ImportarInfoReferencia()
            Exit Sub
        ElseIf dgPolizasImportacion.CurrentRow.Cells(6).Value = 1 Then
            dgPolizasImportacion.CurrentRow.Cells(6).Value = 3
            For j As Integer = 0 To dgPolizasImportacion.Rows.Count - 1

                If dgPolizasImportacion.Rows(j).Cells("colEliminar").Value = 3 Then
                    dgPolizasImportacion.Rows(j).Cells("colEliminar").Value = 1
                Else
                    dgPolizasImportacion.Rows(j).Cells("colEliminar").Value = 2
                    dgPolizasImportacion.Rows(j).Visible = False
                    'dgPolizasImporatcion.Rows.Remove(dgPolizasImporatcion.CurrentRow)

                End If
            Next

            ImportarInfoReferencia()

            dgDetalle.Rows.Clear()
            ProcesarDocumentos()
        End If
    End Sub

    Private Sub botonImprimir_Click(sender As Object, e As EventArgs) Handles botonImprimir.Click
        If Me.Tag = "Nuevo" Then

        Else
            Dim NumeroI As Integer
            Dim AnioI As Integer
            Dim CReport As New clsReportes

            NumeroI = celdaNumero.Text
            AnioI = celdaAnio.Text

            'CReport.IngresoABodega(NumeroI, AnioI)
            CReport.ReporteIngresoABodega(AnioI, NumeroI)
        End If
    End Sub

    Private Sub botonProduccion_Click(sender As Object, e As EventArgs) Handles botonProduccion.Click
        TraerProduccion()
    End Sub

    Private Sub botonPacas_Click(sender As Object, e As EventArgs) Handles botonPacas.Click
        Dim openFile As New OpenFileDialog

        openFile.InitialDirectory = "c:\"
        openFile.Filter = "csv file(*.csv)|*.csv"
        openFile.FilterIndex = 2
        openFile.RestoreDirectory = True


        If openFile.ShowDialog = System.Windows.Forms.DialogResult.OK Then
            InsertPacas(openFile.FileName)
        End If

    End Sub

    Private Sub Encabezado1_ClickBorrar(sender As Object, click As Boolean) Handles Encabezado1.ClickBorrar
        If LogBorrar = True Then
            If DependeciasIngreso() > INT_CERO Then
                MsgBox("This Document can not be canceled, is related to other agencies", MsgBoxStyle.Critical, "Warning")
                cfun.MostrarDependencias(47, celdaAnio.Text, celdaNumero.Text)
            Else
                If MsgBox("Are You sure " & vbCr & vbCr & "¿do you want to delete this document? ", vbQuestion + vbYesNo, "Aviso") = vbYes Then
                    BorrarEncabezadoIngreso()
                    BorrarDetalleIngreso()
                    'BorrarKardex()
                    If Sesion.idGiro = 2 And (intTipo = 2 Or intTipo = 4 Or intTipo = 5 Or intTipo = 14 Or intTipo = 15 Or intTipo = 16 Or intTipo = 17) Then
                        GuardarKardexPO(INT_UNO)
                    End If

                    BorrarAccIngreso()
                    BorrarDescargosIngreso()
                    BorrarBultosIngreso()
                    BorrarExistencias()
                    BorrarReservas()
                    cFunciones.BorrarEncabezadoPoliza(celdaNumero.Text, celdaAnio.Text, 47)
                    cFunciones.BorrarDetallePoliza(celdaNumero.Text, celdaAnio.Text, 47)
                    MsgBox("Delete Complete")
                    MostrarLista()
                End If
            End If
        End If
    End Sub

    Private Sub frmIngresoBodega_Closing(sender As Object, e As CancelEventArgs) Handles Me.Closing
        Fprincipal.BarraDeTareas1.QuitarFormulario(Key)
    End Sub

    Private Sub botonAgreDetalle_Click(sender As Object, e As EventArgs) Handles botonAgreDetalle.Click
        Dim frm As New frmSeleccionar
        Dim strCondicion As String = STR_VACIO
        Dim strTabla As String = STR_VACIO
        If (intTipo = 4) Then '' tipo -> desperdicio  
            strCondicion = "inv_sisemp = {empresa} AND inv_status = 'activo' AND inv_generico=0 AND t.cat_ext IN ('Waste')"
        ElseIf (intTipo = 5) Then ''tipo --> invisible
            strCondicion = "inv_sisemp = {empresa} AND inv_status = 'activo' AND inv_generico=0 AND t.cat_ext IN ('Invisible Waste', 'Polvo de Materia Prima')"
        ElseIf (intTipo = 6) Then ''tipo --> invisible
            If Sesion.IdEmpresa = 11 Then
                strCondicion = "inv_sisemp = {empresa} AND inv_status = 'activo' AND inv_generico=0 AND t.cat_ext IN ('Material de empaque')"
            Else
                strCondicion = "inv_sisemp = {empresa} AND inv_status = 'activo' AND inv_generico=0 AND t.cat_ext IN ('Product in process')"
            End If
        ElseIf intTipo > 13 Then
            strCondicion = "inv_sisemp = {empresa} AND inv_status = 'activo' AND inv_generico=0 AND t.cat_ext IN ('Tela')"
        ElseIf intTipo > 6 Then
            strCondicion = "inv_sisemp = {empresa} AND inv_status = 'activo' AND inv_generico=1 AND t.cat_sisemp IN (1)"
        ElseIf intTipo = 2 Then
            If Sesion.IdEmpresa = 22 Then
                strCondicion = "inv_sisemp = {empresa} AND inv_status = 'activo' AND inv_generico=0 AND t.cat_ext IN ('Tela')"
            Else
                strCondicion = "inv_sisemp = {empresa} AND inv_status = 'activo' AND inv_generico=0 AND t.cat_ext NOT IN ('Waste', 'Fibra')"
            End If

        Else
            strCondicion = "inv_sisemp = {empresa} AND inv_status = 'activo' AND inv_generico=0"
        End If
        strCondicion = Replace(strCondicion, "{empresa}", Sesion.IdEmpresa)
        strTabla = " Inventarios INNER JOIN Articulos ON art_sisemp = inv_sisemp AND art_codigo = inv_artcodigo LEFT JOIN Catalogos m ON m.cat_clase = 'Medidas' AND m.cat_num = inv_UMcmpra LEFT JOIN Catalogos p ON p.cat_clase = 'Paises' AND p.cat_num = inv_lugarfab LEFT JOIN Proveedores pro ON pro_sisemp = inv_sisemp AND pro_codigo = inv_provcod LEFT JOIN Catalogos t ON t.cat_clase='ClaseArt' AND art_clase=t.cat_num JOIN Catalogos cat ON cat.cat_clase = 'StatusIngBdg'AND cat.cat_desc = 'GOOD'"

        Try
            frm.Titulo = "List of Products"
            frm.FiltroText = "Enter the Product Name to filter"
            frm.Campos = "inv_numero Inventory, TRIM(CONCAT(art_DLarga, ' ', IFNULL(p.cat_clave,''))) Description, m.cat_num CodeUnit, m.cat_clave Unit,inv_costo Cost,  inv_artcodigo Product, IFNULL(pro.pro_proveedor,'')Manufacturer, IFNULL(p.cat_clave,'')Origin, inv_partnum Part, inv_prodlote Lot, inv_prodano Year, inv_prodsem Week, cat.cat_num idEstado, cat.cat_desc estado"
            frm.Tabla = strTabla
            frm.Condicion = strCondicion
            If Sesion.idGiro = 2 Then '(Sesion.IdEmpresa = 15) Or (Sesion.IdEmpresa = 18) Or (Sesion.IdEmpresa = 19) Or (Sesion.IdEmpresa = 20) Or (Sesion.IdEmpresa = 21) Then
                frm.Filtro = " art_DLarga "
            Else
                frm.Filtro = " inv_numero "
            End If
            frm.Ordenamiento = " inv_numero"
            frm.TipoOrdenamiento = "DESC"
            frm.Limite = 150

            frm.ShowDialog(Me)
            If frm.DialogResult = Forms.DialogResult.OK Then

                Dim strFila As String = STR_VACIO
                Dim linea As Integer = 0
                For i As Integer = 0 To dgDetalle.Rows.Count - 1
                    linea = dgDetalle.Rows(i).Cells("colLinea").Value
                Next
                '   strFila = celdaAño.Text & "|" & frm.LLave & "|" & linea + 1 & "|" & frm.LLave & "|" & frm.Dato & "|" & frm.Dato2 & "|" & frm.Dato3 & "|" & frm.Dato4 & "|" & 1 & "|" & frm.Dato4 * 1 & "|" & 0 & "|" & frm.LLave & "|" & "" & "|" & linea + 1 & "|" & "|" & "|" & "|" & INT_CERO & "|" & "|" & 1 & "|" & 0

                strFila = frm.LLave & "|"
                strFila &= frm.Dato & "|"
                strFila &= frm.Dato2 & "|"
                strFila &= frm.Dato3 & "|"
                strFila &= frm.Dato4 & "|"
                strFila &= 0 & "|"
                strFila &= 0 & "|"
                strFila &= 1 & "|"
                strFila &= 1 & "|"
                strFila &= frm.Dato4 * 1 & "|"
                strFila &= vbNullString & "|" 'Bodega
                strFila &= vbNullString & "|" 'box number
                strFila &= vbNullString & "|" 'Reserva(Texto)
                strFila &= vbNullString & "|" 'Problema
                strFila &= vbNullString & "|" 'Comentario
                'Catidad Original
                strFila &= 1 & "|"
                'Codigo Original
                strFila &= frm.LLave & "|"
                strFila &= vbNullString & "|"
                strFila &= 0 & "|"
                strFila &= linea + 1 & "|"
                strFila &= vbNullString & "|"
                strFila &= vbNullString & "|"
                strFila &= 0 & "|"
                strFila &= 1 & "|"
                strFila &= 1 & "|"
                strFila &= 0 & "|"
                strFila &= 0 & "|"
                strFila &= 0 & "|"
                strFila &= linea + 1 & "|"
                strFila &= 0 & "|"
                strFila &= frm.ListaClientes.SelectedCells(12).Value & "|" ' id estado
                strFila &= frm.ListaClientes.SelectedCells(13).Value


                cFunciones.AgregarFila(dgDetalle, strFila)

            End If

            If checkTendido.Checked = True Then
                dgDetalle.Columns("colPrecio").ReadOnly = False
                dgDetalle.Columns("colCantidad").ReadOnly = False
                dgDetalle.Columns("colBultos").ReadOnly = False

            End If
            For j As Integer = 0 To dgDetalle.Rows.Count - 1
                dgDetalle.Rows(j).Cells("colArticulo").Style.BackColor = Color.Beige
                dgDetalle.Rows(j).Cells("colMedida").Style.BackColor = Color.Beige
                dgDetalle.Rows(j).Cells("colSubtotal").Style.BackColor = Color.Beige

            Next

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub dgDetalle_CellEndEdit(sender As Object, e As DataGridViewCellEventArgs) Handles dgDetalle.CellEndEdit
        If dgDetalle.Rows.Count = vbEmpty Then Exit Sub

        Select Case dgDetalle.CurrentCell.ColumnIndex
            Case 4
                CalcularTotales()
            Case 7
                CalcularTotales()
            Case 31
                If Me.Tag = "Mod" Then
                    Dim strSQL As String = STR_VACIO
                    Dim COM As MySqlCommand

                    strSQL = "UPDATE Dcmtos_DTL d SET d.DDoc_Prd_Ref = '{Ref}' "
                    strSQL &= " WHERE d.DDoc_Sis_Emp = {empresa} AND d.DDoc_Doc_Cat = 47 AND d.DDoc_Doc_Ano = {anio} AND d.DDoc_Doc_Num = {numero}  AND d.DDoc_Doc_Lin = {linea}"
                    If Sesion.IdEmpresa = 18 Then
                        strSQL &= ";UPDATE PDM.Dcmtos_DTL d SET d.DDoc_Prd_Ref = '{Ref}' "
                        strSQL &= " WHERE d.DDoc_Sis_Emp = {empresa} AND d.DDoc_Doc_Cat = 47 AND d.DDoc_Doc_Ano = {anio} AND d.DDoc_Doc_Num = {numero}  AND d.DDoc_Doc_Lin = {linea}"
                    End If
                    strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
                    strSQL = Replace(strSQL, "{anio}", celdaAnio.Text)
                    strSQL = Replace(strSQL, "{numero}", celdaNumero.Text)
                    strSQL = Replace(strSQL, "{linea}", dgDetalle.CurrentRow.Cells("colLinea").Value)
                    strSQL = Replace(strSQL, "{Ref}", dgDetalle.CurrentRow.Cells("colRefMKT").Value)
                    MyCnn.CONECTAR = strConexion
                    COM = New MySqlCommand(strSQL, CON)
                    COM.ExecuteNonQuery()
                    COM.Dispose()
                    System.GC.Collect()

                    cFunciones.EscribirRegistro(TBL_DOCUMENTOS, clsFunciones.AccEnum.acUpdate, celdaIDCliente.Text, 47, celdaAnio.Text, celdaNumero.Text, "Modificación de Ref MKT")
                    MsgBox("Update successful. Don't click on save button.", vbInformation, "Notice")

                End If
            Case 34
                If Me.Tag = "Mod" Then
                    Dim strSQL As String = STR_VACIO
                    Dim COM As MySqlCommand

                    strSQL = "UPDATE Dcmtos_DTL d SET d.DDoc_Prd_Ref = '{Ref}' "
                    strSQL &= " WHERE d.DDoc_Sis_Emp = {empresa} AND d.DDoc_Doc_Cat = 47 AND d.DDoc_Doc_Ano = {anio} AND d.DDoc_Doc_Num = {numero}  AND d.DDoc_Doc_Lin = {linea}"
                    If Sesion.IdEmpresa = 18 Then
                        strSQL &= ";UPDATE PDM.Dcmtos_DTL d SET d.DDoc_Prd_Ref = '{Ref}' "
                        strSQL &= " WHERE d.DDoc_Sis_Emp = {empresa} AND d.DDoc_Doc_Cat = 47 AND d.DDoc_Doc_Ano = {anio} AND d.DDoc_Doc_Num = {numero}  AND d.DDoc_Doc_Lin = {linea}"
                    End If
                    strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
                    strSQL = Replace(strSQL, "{anio}", celdaAnio.Text)
                    strSQL = Replace(strSQL, "{numero}", celdaNumero.Text)
                    strSQL = Replace(strSQL, "{linea}", dgDetalle.CurrentRow.Cells("colLinea").Value)
                    strSQL = Replace(strSQL, "{Ref}", dgDetalle.CurrentRow.Cells("colRefMKT").Value)
                    MyCnn.CONECTAR = strConexion
                    COM = New MySqlCommand(strSQL, CON)
                    COM.ExecuteNonQuery()
                    COM.Dispose()
                    System.GC.Collect()

                    cFunciones.EscribirRegistro(TBL_DOCUMENTOS, clsFunciones.AccEnum.acUpdate, celdaIDCliente.Text, 47, celdaAnio.Text, celdaNumero.Text, "Modificación de Ref MKT")
                    MsgBox("Update successful. Don't click on save button.", vbInformation, "Notice")

                End If
        End Select

    End Sub
    Private Sub dtpFech_ValueChanged(sender As Object, e As EventArgs) Handles dtpFech.ValueChanged
        If celdaTasa.Text <> 1 Then
            celdaTasa.Text = cFunciones.TasaSegunFecha(dtpFech.Value.ToString(FORMATO_MYSQL))
        End If
    End Sub

    Private Function VerificarPacas_()

        Dim logActualizar As Boolean
        If (Sesion.IdEmpresa = 15 And (intTipo = 0 Or intTipo = 4)) Or (Sesion.IdEmpresa = 18 And (intTipo = 0 Or intTipo = 4)) Or (Sesion.IdEmpresa = 19 And (intTipo = 0 Or intTipo = 4)) Or (Sesion.IdEmpresa = 20 And (intTipo = 0 Or intTipo = 4)) Or (Sesion.IdEmpresa = 21 And (intTipo = 0 Or intTipo = 4)) Then

            Dim strsql As String = STR_VACIO
            Dim intBultos_ As Integer = 0
            Dim conec As MySqlConnection
            Dim COM As MySqlCommand

            strsql = " SELECT COUNT(*)
                        FROM Dcmtos_DTL_Box b
                            WHERE b.BDoc_Sis_Emp = {emp} AND b.BDoc_Doc_Cat = 47 AND b.BDoc_Doc_Ano = {anio} AND b.BDoc_Doc_Num = {num} AND b.BDoc_Doc_Lin = {lin}"

            strsql = strsql.Replace("{emp}", Sesion.IdEmpresa)
            strsql = strsql.Replace("{anio}", celdaAnio.Text)
            strsql = strsql.Replace("{num}", celdaNumero.Text)
            strsql = strsql.Replace("{lin}", dgDetalle.CurrentRow.Cells("colLinea").Value)

            conec = New MySqlConnection(strConexion)
            conec.Open()
            COM = New MySqlCommand(strsql, conec)
            intBultos_ = COM.ExecuteScalar()
            conec.Close()

            If intBultos_ > 1 Then
                botonPacas.Enabled = False
                logActualizar = False
            Else
                botonPacas.Enabled = True
                logActualizar = True
            End If
        Else
            botonPacas.Enabled = False
            logActualizar = False

        End If

        Return logActualizar
    End Function

    Private Sub dgDetalle_Click(sender As Object, e As EventArgs) Handles dgDetalle.Click
        If celdaNumero.Text > 0 Then
            VerificarPacas_()
        End If
    End Sub
    Private Sub BotonImprimirRotulo_Click(sender As Object, e As EventArgs) Handles BotonImprimirRotulo.Click
        If Me.Tag = "Mod" Then
            Dim NumeroI As Integer
            Dim AnioI As Integer
            Dim CReport As New clsReportes

            NumeroI = celdaNumero.Text
            AnioI = celdaAnio.Text

            'CReport.IngresoABodega(NumeroI, AnioI)
            CReport.ReporteRotuloIngresoBodega(AnioI, NumeroI)
        End If
    End Sub

    Private Sub checkTendido_CheckedChanged(sender As Object, e As EventArgs) Handles checkTendido.CheckedChanged
        If checkTendido.Checked = True Then
            botonAgreDetalle.Enabled = True
            botonQuitDetalle.Enabled = True
        Else
            botonAgreDetalle.Enabled = False
            botonQuitDetalle.Enabled = False
        End If
    End Sub

    Private Sub celdaRef2_DoubleClick(sender As Object, e As EventArgs) Handles celdaRef2.DoubleClick
        Dim opt As New frmOption
        If Sesion.IdEmpresa = 22 And intTipo = 2 Then
            opt.Titulo = " Option"
            opt.Mensaje = "Select an option"
            opt.Opciones = "Open Width" & "|" & "Tubler"
            If opt.ShowDialog = Forms.DialogResult.OK Then
                Select Case opt.Seleccion
                    Case 0
                        celdaRef2.Text = "Open Width"
                    Case 1
                        celdaRef2.Text = "Tubler"
                End Select
            End If

        End If
    End Sub
    Private Sub botonPOWE_Click(sender As Object, e As EventArgs) Handles botonPOWE.Click
        Dim COM As MySqlCommand
        Dim StrSQL As String
        Dim StrSQL2 As String
        Dim COM2 As MySqlCommand
        Dim clsConta As New clsContabilidad
        Dim fcajas As New frmCajasPT

        Dim pro As New clsDcmtos_DTL_Pro

        Try
            datosPO()
            datosProducto(anoPO, idPO, dtpFech.Value.ToString(FORMATO_MYSQL))

            If Val(productoDatos(3)) > 0 Then
                Try
                    ' cambio para el botón POWE
                    StrSQL = "UPDATE Dcmtos_HDR SET HDoc_RF2_Dbl='0' "
                    StrSQL &= "WHERE HDoc_Sis_Emp = {empresa} AND HDoc_Doc_Cat = {tipo} AND HDoc_Doc_Ano = {anio} AND HDoc_Doc_Num = {numero}"
                    If Sesion.IdEmpresa = 18 Then
                        StrSQL &= ";UPDATE PDM.Dcmtos_HDR SET HDoc_RF2_Dbl='0' "
                        StrSQL &= "WHERE HDoc_Sis_Emp = {empresa} AND HDoc_Doc_Cat = {tipo} AND HDoc_Doc_Ano = {anio} AND HDoc_Doc_Num = {numero}"
                    End If
                    StrSQL = Replace(StrSQL, "{empresa}", Sesion.IdEmpresa)
                    StrSQL = Replace(StrSQL, "{anio}", celdaAnio.Text)
                    StrSQL = Replace(StrSQL, "{numero}", celdaNumero.Text)
                    StrSQL = Replace(StrSQL, "{tipo}", 47)

                    MyCnn.CONECTAR = strConexion
                    COM2 = New MySqlCommand(StrSQL, CON)
                    COM2.ExecuteNonQuery()
                    StrSQL = STR_VACIO


                    ' PO -> Ingreso
                    pro.PDOC_SIS_EMP = Sesion.IdEmpresa
                    pro.PDOC_PAR_CAT = 980                  '980 PO
                    pro.PDOC_PAR_ANO = anoPO
                    pro.PDOC_PAR_NUM = idPO
                    pro.PDOC_PAR_LIN = fcajas.primeraLineaPO(anoPO, idPO)
                    pro.PDOC_CHI_CAT = 47                   '47 Ingreso
                    pro.PDOC_CHI_ANO = celdaAnio.Text
                    pro.PDOC_CHI_NUM = celdaNumero.Text
                    pro.PDOC_CHI_LIN = 1
                    pro.PDOC_QTY_PRO = dgDetalle.CurrentRow.Cells("colCantidad").Value

                    If celdaNumero.Text <> 0 Then
                        If logInsertar = True Then
                            If pro.Guardar() = False Then
                                MsgBox(pro.MERROR.ToString & "Could Not save the document", MsgBoxStyle.Critical)
                            End If
                        End If
                    End If


                    botonPOWE.Visible = False
                    ''            botonPOWE.Enabled = False


                    StrSQL2 = "UPDATE Dcmtos_DTL SET DDoc_Prd_QTY=DDoc_RF4_Dbl, DDoc_Prd_NET={precio} "
                    StrSQL2 &= "WHERE DDoc_Sis_Emp = {empresa} AND DDoc_Doc_Cat =47 AND DDoc_Doc_Ano = {anio} AND DDoc_Doc_Num = {numero}"
                    If Sesion.IdEmpresa = 18 Then
                        StrSQL2 &= ";UPDATE PDM.Dcmtos_DTL SET DDoc_Prd_QTY=DDoc_RF4_Dbl, DDoc_Prd_NET={precio} "
                        StrSQL2 &= "WHERE DDoc_Sis_Emp = {empresa} AND DDoc_Doc_Cat =47 AND DDoc_Doc_Ano = {anio} AND DDoc_Doc_Num = {numero}"
                    End If
                    StrSQL2 = Replace(StrSQL2, "{empresa}", Sesion.IdEmpresa)
                    StrSQL2 = Replace(StrSQL2, "{anio}", celdaAnio.Text)
                    StrSQL2 = Replace(StrSQL2, "{numero}", celdaNumero.Text)
                    StrSQL2 = Replace(StrSQL2, "{tipo}", 47)
                    StrSQL2 = Replace(StrSQL2, "{precio}", Val(productoDatos(6)) + Val(productoDatos(7)) + Val(productoDatos(8) + Val(productoDatos(9)) + Val(productoDatos(10))))  'precio

                    MyCnn.CONECTAR = strConexion
                    COM = New MySqlCommand(StrSQL2, CON)
                    COM.ExecuteNonQuery()
                    StrSQL2 = STR_VACIO
                    cFunciones.EscribirRegistro(TBL_DOCUMENTOS, clsFunciones.AccEnum.acUpdate, celdaIDCliente.Text, 47, celdaAnio.Text, celdaNumero.Text, "validacion del ingreso por boton POWE")
                Catch ex As Exception
                    MsgBox(ex.Message)
                    Exit Sub
                End Try

            Else
                MsgBox("Revise el saldo de la PO")
                Exit Sub
            End If

        Catch ex As Exception
            MsgBox(ex.ToString)
            Exit Sub
        End Try

        '' generacion de poliza del ingreso, luego de hacer todo el insert del detalle.
        '' se coloca en esta ubicación, para tener los datos que se guardaron en dtl, del ultimo registro.
        clsConta.GenerarPoliza(47, celdaAnio.Text, celdaNumero.Text, cFunciones.HoyMySQL.ToString(FORMATO_MYSQL))

        MsgBox("Change Made", vbInformation, "Information")
    End Sub
    Public Sub datosPO()
        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader
        Dim ciReq As New frmRequisiciones
        Dim strSQL As String = STR_VACIO
        Dim strTemp As String = STR_VACIO
        Dim int_InvNum As Integer = 0

        Try
            strSQL = "SELECT h.HDoc_RF1_Dbl idpo, h.HDoc_RF3_Dbl anoPO FROM Dcmtos_DTL_Pro p  
                    LEFT JOIN Dcmtos_HDR h ON h.HDoc_Sis_Emp=p.PDoc_Sis_Emp AND h.HDoc_Doc_Cat=p.PDoc_Par_Cat AND h.HDoc_Doc_Ano=p.PDoc_Par_Ano AND h.HDoc_Doc_Num=p.PDoc_Par_Num
                    WHERE p.PDoc_Sis_Emp={empresa} AND p.PDoc_Chi_Cat=47 AND p.PDoc_Chi_Ano={anio} AND p.PDoc_Chi_Num={numero} AND p.PDoc_Par_Cat = 776 LIMIT 1"
            strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
            strSQL = Replace(strSQL, "{anio}", celdaAnio.Text)
            strSQL = Replace(strSQL, "{numero}", celdaNumero.Text)

            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSQL, CON)
            REA = COM.ExecuteReader
            If REA.HasRows Then
                Do While REA.Read
                    idPO = REA.GetString("idpo").ToString
                    anoPO = REA.GetInt32("anoPO").ToString
                Loop
            End If
            strSQL = STR_VACIO
            COM.Dispose()
            REA.Close()
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub
    Public Sub datosProducto(anio As Integer, numero As Integer, fecha As String)
        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader
        Dim ciReq As New frmRequisiciones
        Dim strSQL As String = STR_VACIO
        Dim strTemp As String = STR_VACIO
        Dim int_InvNum As Integer = 0

        Try
            strSQL = ciReq.SqlInfoProduccion(True, fecha)
            strSQL = Replace(strSQL, "{numPO}", " AND h.HDoc_Doc_Ano= " & anio & " AND h.HDoc_Doc_Num = " & numero)
            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSQL, CON)
            REA = COM.ExecuteReader
            If REA.HasRows Then
                Do While REA.Read
                    productoDatos(0) = REA.GetString("Descripcion").ToString
                    productoDatos(1) = REA.GetInt32("codigo").ToString
                    productoDatos(2) = REA.GetString("Medida").ToString
                    productoDatos(3) = REA.GetDouble("Saldo").ToString
                    productoDatos(4) = REA.GetDouble("Cantidad").ToString
                    productoDatos(5) = REA.GetDouble("PO").ToString
                    productoDatos(6) = REA.GetDouble("Precio").ToString
                    productoDatos(7) = REA.GetDouble("MO").ToString
                    productoDatos(8) = REA.GetDouble("GF").ToString
                    productoDatos(9) = REA.GetDouble("Waste").ToString
                    productoDatos(10) = REA.GetDouble("Factores_").ToString
                    productoDatos(11) = REA.GetDouble("CantidadNecesaria").ToString
                    productoDatos(12) = REA.GetDouble("TipoCambio").ToString
                    productoDatos(13) = REA.GetInt16("codMedida").ToString
                    productoDatos(14) = REA.GetInt16("Waste").ToString
                    productoDatos(15) = REA.GetInt16("Factores_").ToString
                Loop
            End If
            strSQL = STR_VACIO
            COM.Dispose()
            REA.Close()
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub
    ' Valida al momento de Editar
    Public Function AutorizarGuardar() As Boolean
        Const STR_MARGEN As String = "MOD_INGRESO_BODEGA"
        Dim frm As New frmAutorización
        AutorizarGuardar = False
        frm.Iniciar(47, STR_MARGEN, 0, "Authorize Edit")
        frm.ShowDialog(Me)
        If frm.Aceptado Then
            AutorizarGuardar = True
        End If
    End Function
#End Region
End Class