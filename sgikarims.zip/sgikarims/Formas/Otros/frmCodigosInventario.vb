﻿Imports System.ComponentModel

Public Class frmCodigosInventario

#Region "Miembros"
    Dim strKey As String = STR_VACIO
    Dim logInsertar As Boolean = False
    Dim logConsultar As Boolean = False
    Dim logEditar As Boolean = False
    Dim LogBorrar As Boolean = False
    Const CAT_ORD As Integer = 777

    Private dblCif As Double
    'Private strCode As String = STR_VACIO
#End Region

#Region "Propiedades"
    Public Property Key As String
        Get
            Return strKey
        End Get
        Set(value As String)
            strKey = value
        End Set
    End Property
#End Region

#Region "Procedimientos"

    Private Function SqlCargarLista(ByVal intOpcion As Integer)
        Dim strSQL As String = STR_VACIO

        strSQL = " SELECT i.inv_numero Inventario, a.art_DCorta Descripcion, IFNULL (p.pro_proveedor, '') Proveedor, i.inv_costo Costo, i.inv_generico Generico, i.inv_activo Activo, i.inv_descripcion DescInventario "
        strSQL &= "   From Inventarios i "
        strSQL &= "        Left JOIN Proveedores p ON p.pro_sisemp = i.inv_sisemp AND p.pro_codigo = i.inv_provcod "
        strSQL &= "             INNER JOIN Articulos a ON a.art_sisemp = i.inv_sisemp AND a.art_codigo = i.inv_artcodigo "
        strSQL &= "        WHERE i.inv_sisemp = {empresa} "
        If intOpcion = 1 Then
            strSQL &= " AND a.art_DCorta like '%" & celdaBuscar.Text & "%' "
        End If
        strSQL &= "     ORDER BY i.inv_numero DESC "
        If intOpcion = 0 Then
            strSQL &= " LIMIT 100 "
        End If

        strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)

        Return strSQL

    End Function

    Private Function SqlCargarLista2()
        Dim strSQL As String = STR_VACIO

        strSQL = " SELECT inv_numero Inventario, art_DCorta Descripcion, IFNULL (pro_proveedor, '') Proveedor, inv_costo Costo, inv_generico Generico, inv_activo Activo "
        strSQL &= "   From Inventarios i "
        strSQL &= "        Left JOIN Proveedores p ON p.pro_sisemp = i.inv_sisemp AND p.pro_codigo = i.inv_provcod "
        strSQL &= "             INNER JOIN Articulos a ON a.art_sisemp = i.inv_sisemp AND a.art_codigo = i.inv_artcodigo "
        strSQL &= "        WHERE i.inv_sisemp = {empresa} "
        strSQL &= "     ORDER BY i.inv_numero DESC "

        strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)

        Return strSQL

    End Function

    Private Function SqlCargarDatos(ByVal numero As Integer)
        Dim strSQL As String = STR_VACIO

        strSQL = " SELECT inv_sisemp, inv_numero,inv_prodlote, inv_provcod, inv_Artcodigo, inv_prodsem,inv_prodano, inv_UMventa, inv_UMcmpra, inv_UMfac,inv_muestra ,inv_status,art_DCorta,Art_DLarga,inv_PRECIOfac,inv_PRECIOmax,inv_PRECIOmin,inv_costo,inv_partnum,inv_lugarfab, IFNULL(pro_proveedor,'') Proveedor, C.cat_desc, cat.cat_clave UMVenta, cat1.cat_clave UMCompra, ifnull (inv_notas, ' ') inv_notas, IFNULL (inv_activo, 0) inv_activo, inv_generico Generico, IFNULL(inv_descripcion,'') descripcion, inv_fecha "
        strSQL &= "    From Inventarios"
        strSQL &= "        Left JOIN Articulos ON art_sisemp = inv_sisemp and art_codigo = inv_artcodigo "
        strSQL &= "            Left JOIN Proveedores ON pro_sisemp = inv_sisemp and pro_codigo=inv_Provcod "
        strSQL &= "                Left JOIN Catalogos C ON C.cat_clase = 'Paises' AND C.cat_num= inv_lugarfab "
        strSQL &= "                Left JOIN Catalogos cat ON  cat.cat_clase = 'Medidas' AND cat.cat_num = inv_UMVenta "
        strSQL &= "            Left JOIN Catalogos cat1 ON  cat1.cat_clase = 'Medidas' AND cat1.cat_num = inv_UMcmpra "
        strSQL &= "        WHERE inv_sisemp = {empresa} AND inv_numero = {numero} "

        strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
        strSQL = Replace(strSQL, "{numero}", numero)

        Return strSQL
    End Function

    Private Function SqlCargarDetalle(ByVal codigo As Integer)
        Dim strSQL As String = STR_VACIO

        strSQL = " SELECT d.DDoc_Doc_Ano Anio, d.DDoc_Doc_Num Numero, d.DDoc_Doc_Lin Linea, e.HDoc_DR1_Num Referencia, d.DDoc_Prd_QTY Cantidad, d.DDoc_Prd_NET Precio "
        strSQL &= "    From Dcmtos_DTL d "
        strSQL &= "        Left JOIN Dcmtos_HDR e ON e.HDoc_Sis_Emp=d.DDoc_Sis_Emp AND e.HDoc_Doc_Cat=d.DDoc_Doc_Cat AND e.HDoc_Doc_Ano=d.DDoc_Doc_Ano AND e.HDoc_Doc_Num=d.DDoc_Doc_Num "
        strSQL &= "    WHERE d.DDoc_Sis_Emp={empresa} AND DDoc_Doc_Cat=47 AND DDoc_Prd_Cod={codigo} "
        strSQL &= " ORDER BY e.HDoc_Doc_Fec, d.DDoc_Doc_Num, d.DDoc_Doc_Lin "

        strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
        strSQL = Replace(strSQL, "{codigo}", codigo)

        Return strSQL

    End Function


    Private Sub CargarLista(ByVal intOpcion As Integer)
        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader
        Dim strSql As String = STR_VACIO
        Dim strFila As String = STR_VACIO
        Try

            strSql = SqlCargarLista(intOpcion)
            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSql, CON)
            REA = COM.ExecuteReader
            If REA.HasRows Then

                dgLista.Rows.Clear()
                Do While REA.Read
                    strFila = REA.GetInt32("Inventario") & "|"
                    strFila &= REA.GetString("Descripcion") & "|"
                    strFila &= REA.GetString("Proveedor") & "|"
                    strFila &= REA.GetDouble("Costo") & "|"
                    strFila &= REA.GetString("Generico") & "|"
                    strFila &= REA.GetString("Activo")

                    If REA.GetString("Descripcion") = REA.GetString("DescInventario") Then
                        cFunciones.AgregarFila(dgLista, strFila)
                    Else
                        cFunciones.AgregarFila(dgLista, strFila, Color.AliceBlue)
                    End If
                Loop

                For i As Integer = 0 To Me.dgLista.Rows.Count - 1
                    If Me.dgLista.Rows(i).Cells(5).Value = 1 Then
                        Me.dgLista.Rows(i).Cells(1).Style.BackColor = Color.Red
                    End If
                Next
            End If

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try


    End Sub

    Public Sub CargarDatos(ByVal numero As Integer)
        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader
        Dim strSql As String = STR_VACIO
        Dim situacion As String = STR_VACIO
        Try

            strSql = SqlCargarDatos(numero)
            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSql, CON)
            REA = COM.ExecuteReader
            If REA.HasRows Then
                Do While REA.Read
                    dtpFecha.Value = REA.GetDateTime("inv_fecha").ToString(FORMATO_MYSQL)
                    celdaCodigo.Text = REA.GetInt32("inv_numero")
                    celdaProducto.Text = REA.GetString("art_DCorta")
                    celdaIDProducto.Text = REA.GetInt32("inv_artcodigo")
                    celdaArticulo.Text = REA.GetInt32("inv_artcodigo") & vbCrLf & REA.GetString("art_DLarga")
                    celdaProveedor.Text = REA.GetString("Proveedor")
                    celdaIDProveedor.Text = REA.GetInt32("inv_provcod")
                    'strCode = REA.GetInt32("inv_provcod")
                    celdaNParte.Text = REA.GetString("inv_partnum")
                    celdaPais.Text = REA.GetString("cat_desc")
                    celdaIDPais.Text = REA.GetInt32("inv_lugarfab")
                    celdaLoteNumb.Text = REA.GetString("inv_prodlote")
                    celdaAño.Text = REA.GetInt32("inv_prodano")
                    celdaSemana.Text = REA.GetInt32("inv_prodsem")
                    situacion = REA.GetString("inv_status")
                    celdaDescripcion.Text = REA.GetString("descripcion")

                    If situacion = "Activo" Then
                        rbotonActivo.Checked = True
                        rbotonBaja.Checked = False
                    Else
                        rbotonActivo.Checked = False
                        rbotonBaja.Checked = True
                    End If

                    celdaVenta.Text = REA.GetString("UMVenta")
                    celdaIDVenta.Text = REA.GetInt32("inv_UMventa")
                    celdaCompra.Text = REA.GetString("UMCompra")
                    celdaIDCompra.Text = REA.GetInt32("inv_UMcmpra")
                    celdaContenido.Text = REA.GetDouble("inv_UMfac").ToString(FORMATO_MONEDA)
                    celdaCostoCIF.Text = REA.GetDouble("inv_costo")
                    celdaCIFAnterior.Text = REA.GetDouble("inv_costo")
                    celdaPrecioMin.Text = REA.GetDouble("inv_PRECIOmin")
                    celdaPrecioMax.Text = REA.GetDouble("inv_PRECIOmax")
                    celdaFactor.Text = REA.GetDouble("inv_PRECIOfac").ToString(FORMATO_MONEDA)
                    celdaNotas.Text = REA.GetString("inv_notas")
                    If REA.GetInt32("inv_activo") = 0 Then
                        checkDesactivar.Checked = False
                        celdaDesactivar.Visible = False
                    ElseIf REA.GetInt32("inv_activo") = 1 Then
                        checkDesactivar.Checked = True
                        celdaDesactivar.Visible = True
                    End If
                    If REA.GetInt32("inv_muestra") = 0 Then
                        checkMuestra.Checked = False
                    Else
                        checkMuestra.Checked = True
                    End If

                    If REA.GetString("Generico") = 0 Then 'NO ES GENERICO
                        checkGenerico.Checked = False
                        checkGenerico.Enabled = True
                    ElseIf REA.GetString("Generico") = 1 Then ' SI ES GENERICO
                        checkGenerico.Checked = True
                        checkGenerico.Enabled = False
                        BloquearCampos()
                    End If
                Loop
            End If


        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    'Public Sub CargarCostos()
    '    Dim COM As MySqlCommand
    '    Dim REA As MySqlDataReader
    '    Dim strSql As String = STR_VACIO
    '    Dim strFila As String = STR_VACIO
    '    Try

    '        strSql = 
    '        MyCnn.CONECTAR = strConexion
    '        COM = New MySqlCommand(strSql, CON)
    '        REA = COM.ExecuteReader
    '        If REA.HasRows Then
    '            Do While REA.Read

    '            Loop
    '        End If


    '    Catch ex As Exception
    '        MsgBox(ex.ToString)
    '    End Try
    'End Sub

    Public Sub CargarDetalle(ByVal codigo As Integer)
        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader
        Dim strSql As String = STR_VACIO
        Dim strFila As String = STR_VACIO
        Try
            dgDetalle.Rows.Clear()
            strSql = SqlCargarDetalle(codigo)
            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSql, CON)
            REA = COM.ExecuteReader
            If REA.HasRows Then
                Do While REA.Read
                    strFila = REA.GetInt32("Numero") & "|"
                    strFila &= REA.GetString("Referencia") & "|"
                    strFila &= REA.GetString("Cantidad") & "|"
                    strFila &= REA.GetDouble("Precio") & "|"
                    strFila &= REA.GetDouble("Anio") & "|"
                    strFila &= REA.GetInt32("Linea")

                    cFunciones.AgregarFila(dgDetalle, strFila)
                Loop
            End If


        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub


    Private Sub BloquearBotones(Optional ByVal logBloquear As Boolean = True)
        If logBloquear = True Then
            Encabezado1.botonBorrar.Enabled = False
            Encabezado1.botonGuardar.Enabled = False
        Else
            If LogBorrar = True Then
                Encabezado1.botonBorrar.Enabled = True
            Else
                Encabezado1.botonBorrar.Enabled = False
            End If
            Encabezado1.botonGuardar.Enabled = True

        End If
    End Sub

    Private Sub BloquearCampos()
        Try
            If checkGenerico.Checked = True Then 'Es Generico y boquea
                celdaProveedor.Enabled = False
                celdaProveedor.Text = vbNullString
                botonProveedor.Enabled = False
                celdaNParte.Enabled = False
                celdaNParte.Text = vbNullString
                celdaLoteNumb.Enabled = False
                celdaLoteNumb.Text = vbNullString
                celdaAño.Enabled = False
                celdaAño.Text = 0
                celdaSemana.Enabled = False
                celdaSemana.Text = 0
                celdaFactor.Text = 0
                rbotonActivo.Enabled = False
                rbotonBaja.Enabled = False
                gbCostos.Enabled = False
                celdaNotas.Enabled = False
                celdaNotas.Text = vbNullString

            ElseIf checkGenerico.Checked = False Then ' No es generico y desbloquea si está blequeado
                celdaProveedor.Enabled = True
                botonProveedor.Enabled = True
                celdaNParte.Enabled = True
                celdaLoteNumb.Enabled = True
                celdaAño.Enabled = True
                celdaSemana.Enabled = True
                rbotonActivo.Enabled = True
                rbotonBaja.Enabled = True
                gbCostos.Enabled = True
                celdaNotas.Enabled = True
                celdaFactor.Text = INT_UNO
            End If

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub Accessos()
        Dim cAccesos As New clsAccesos
        Try
            If cAccesos.Accesos(strKey) = True Then
                logInsertar = cAccesos.Insertar
                logConsultar = cAccesos.Consultar
                logEditar = cAccesos.Editar
                LogBorrar = cAccesos.Borrar
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub reset()

        celdaCodigo.Text = STR_VACIO
        celdaProducto.Text = STR_VACIO
        celdaIDProducto.Text = NO_FILA
        celdaArticulo.Text = STR_VACIO
        celdaProveedor.Text = STR_VACIO
        celdaIDProveedor.Text = INT_CERO
        celdaNParte.Text = STR_VACIO
        celdaPais.Text = STR_VACIO
        celdaIDPais.Text = NO_FILA
        celdaLoteNumb.Text = STR_VACIO
        celdaAño.Text = NO_FILA
        celdaSemana.Text = NO_FILA
        celdaVenta.Text = NO_FILA
        celdaIDVenta.Text = NO_FILA
        celdaCompra.Text = NO_FILA
        celdaIDCompra.Text = NO_FILA
        checkGenerico.Checked = False
        checkGenerico.Enabled = True
        checkActivoFijo.Checked = False
        checkDesactivar.Checked = False
        celdaNotas.Text = STR_VACIO
        dgDetalle.Rows.Clear()
        celdaCostoCIF.Text = STR_VACIO
        celdaCIFAnterior.Text = STR_VACIO
        celdaIDCostoCIF.Text = NO_FILA
        celdaPrecioMin.Text = NO_FILA
        celdaPrecioMax.Text = NO_FILA
        celdaFactor.Text = INT_UNO
        celdaDescripcion.Clear()

        BloquearCampos()

    End Sub

    Private Sub MostrarLista(Optional ByVal logMostrar As Boolean = True, Optional logInsert As Boolean = False)
        Dim cfun As New clsFunciones
        If logMostrar = True Then
            'Ocultar Panel de Documento
            panelDocumento.Dock = DockStyle.None
            panelDocumento.Visible = False
            'Actualizar Titulo
            BarraTitulo1.CambiarTitulo("Inventory Codes")
            'Cargar Datos
            CargarLista(0)
            'Mostrar Panel Filtro
            panelLista.Visible = True
            panelLista.Dock = DockStyle.Fill
            BloquearBotones()
            Me.Tag = "Nuevo"
        Else
            'Ocultar Panel Filtro
            panelLista.Visible = False
            panelLista.Dock = DockStyle.None
            'Mostrar Panel de Documento
            panelDocumento.Dock = DockStyle.Fill
            panelDocumento.Visible = True
            'Verifica si se va a Crear un nuevo Documento o se va a modificar
            If logInsert = False Then
                BarraTitulo1.CambiarTitulo("Modify Registry")
                Me.Tag = "Mod"
                BloquearBotones(False)

            Else
                BarraTitulo1.CambiarTitulo("New Registry")
                Me.Tag = "Nuevo"
                BloquearBotones(False)

                reset()
            End If

            dgLista.DataSource = Nothing
        End If
    End Sub

    Private Function ComprobarDatos() As Boolean
        Dim comprobar As Boolean = True
        Dim strNewKey As String = STR_VACIO
        Dim strSQL As String = STR_VACIO
        Dim strFecha As DateTime
        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader
        strFecha = dtpFecha.Value.ToString(FORMATO_MYSQL)
        'Si es un producto generico, se omite la validación
        If checkGenerico.Checked = True Then
            strNewKey = celdaIDProducto.Text & IIf(celdaIDProveedor.Text = vbNullString, "0", celdaIDProveedor.Text) & IIf(celdaIDPais.Text = vbNullString, "0", celdaIDPais.Text) & celdaIDVenta.Text & strFecha.ToString(FORMATO_MYSQL) '& IIf(celdaLoteNumb.Text = vbNullString, vbNullString, celdaLoteNumb.Text)

            If Me.Tag = "Nuevo" Then
                If IsRegisteredProduct(strNewKey) Then
                    MsgBox("Ya existe un producto generico con esas caracteristicas." & vbNewLine & "El Producto registrado tiene el siguiente codigo: " & strNewKey, vbExclamation, "NOTICE")
                    comprobar = False
                    Exit Function
                End If
            End If

            If celdaCodigo.Text = vbNullString Or
               celdaIDPais.Text = NO_FILA Or
               celdaIDCompra.Text = vbEmpty Or
               celdaIDVenta.Text = vbEmpty Or
                celdaPais.Text = vbNullString Then

                MsgBox("Debe ingresar la informacion minima para un codigo generico" & vbNewLine, vbExclamation, "Genéricos")
                comprobar = False
                Exit Function
            End If

            If celdaCostoCIF.Text = vbEmpty Or
                celdaPrecioMin.Text = vbEmpty Or
                celdaPrecioMax.Text = vbEmpty Then

                celdaCostoCIF.Text = INT_CERO
                celdaPrecioMin.Text = INT_CERO
                celdaPrecioMax.Text = INT_CERO

            End If
        Else
            'Revisar que los datos de la cabecera no esten en blanco
            If celdaCodigo.Text = vbEmpty Or
            celdaProducto.Text = vbNullString Or
            celdaArticulo.Text = vbNullString Or
            celdaIDProveedor.Text = vbEmpty Or
            celdaIDPais.Text = NO_FILA Or
            celdaPais.Text = vbNullString Or
            celdaAño.Text = vbEmpty Then
                MsgBox("Debe de ingresar todos los datos.", vbCritical)
                comprobar = False
                Exit Function
            End If

            'SE LEIBERO PARA QUE NO HAYA RESTRICCIONES

            'If Me.Tag = "Nuevo" Then 
            'If (Sesion.IdEmpresa = 18) Or (Sesion.IdEmpresa = 15) Or (Sesion.IdEmpresa = 19) Then
            '    strSQL = "SELECT i.inv_costo Precio,i.inv_partnum Lote,i.inv_prodsem Semana "
            '    strSQL &= "  FROM Inventarios i WHERE"
            '    strSQL &= "     i.inv_sisemp = {empresa} AND i.inv_provcod = {IDProveedor} AND i.inv_partnum = '{NumParte}' AND i.inv_lugarfab = {IDPais} AND i.inv_prodano ={anio} "
            '    strSQL &= "         AND i.inv_generico = {checkGenerico} AND i.inv_UMcmpra = {UVenta} AND i.inv_costo = {precio}  AND i.inv_prodlote = '{lote}'  And i.inv_prodsem = {semana} AND NOT i.inv_numero = {codigo} "

            '    strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
            '    strSQL = Replace(strSQL, "{codigo}", celdaCodigo.Text)
            '    strSQL = Replace(strSQL, "{IDProveedor}", celdaIDProveedor.Text)
            '    strSQL = Replace(strSQL, "{NumParte}", celdaNParte.Text)
            '    strSQL = Replace(strSQL, "{IDPais}", celdaIDPais.Text)
            '    strSQL = Replace(strSQL, "{anio}", celdaAño.Text)
            '    strSQL = Replace(strSQL, "{semana}", celdaSemana.Text)
            '    strSQL = Replace(strSQL, "{lote}", celdaLoteNumb.Text)
            '    strSQL = Replace(strSQL, "{checkGenerico}", 0)
            '    strSQL = Replace(strSQL, "{UVenta}", celdaIDVenta.Text)
            '    strSQL = Replace(strSQL, "{fecha}", dtpFecha.Value.ToString(FORMATO_MYSQL))
            '    strSQL = Replace(strSQL, "{precio}", celdaCostoCIF.Text)

            '    MyCnn.CONECTAR = strConexion
            '    COM = New MySqlCommand(strSQL, CON)
            '    REA = COM.ExecuteReader

            '    If REA.HasRows Then
            '        Do While REA.Read
            '            If (celdaCostoCIF.Text = REA.GetDouble("Precio")) Or (celdaLoteNumb.Text = REA.GetString("Lote")) Or (celdaSemana.Text = REA.GetString("Semana")) Then
            '                MsgBox("Ya existe un inventario con estas caracteristicas." & vbCr & vbCr & vbCr & "Precio: " & REA.GetDouble("Precio") & vbCr & vbCr & vbCr & "Lote: " & REA.GetString("Lote") & vbCr & vbCr & vbCr & "Semana: " & REA.GetString("Semana"), vbCritical, "Aviso")
            '                comprobar = False
            '                Exit Function
            '            End If
            '        Loop
            '    End If
            '    'End If
            'End If
        End If

        Return comprobar
    End Function

    Public Function IsRegisteredProduct(ByVal strKey As String) As Boolean
        Dim strSQL As String = STR_VACIO
        Dim conec As New MySqlConnection
        Dim COM As New MySqlCommand
        Dim Num As Integer

        Try

            strSQL = "SELECT ifnull(inv_numero,0)"
            strSQL &= "  FROM Inventarios "
            strSQL &= "       WHERE inv_sisemp= {empresa} AND CONCAT(inv_artcodigo, inv_provcod, inv_lugarfab, inv_prodlote, inv_UMventa,inv_fecha) = '" & strKey & "'"

            strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)

            conec = New MySqlConnection(strConexion)
            conec.Open()
            COM = New MySqlCommand(strSQL, conec)
            Using conec
                Num = COM.ExecuteScalar()
                COM.Dispose()
                COM = Nothing
                conec.Close()
                conec.Dispose()
                conec = Nothing
                System.GC.Collect()
            End Using

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try

        IsRegisteredProduct = (Num > vbEmpty)

    End Function

    Private Function GetProductIdFor(ByVal strKey As String) As String
        Dim strSQL As String
        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader

        If Not IsRegisteredProduct(strKey) Then
            'GetProductIdFor() = vbNullString
        Else
            strSQL = "SELECT inv_numero"
            strSQL &= "   FROM Inventarios "
            strSQL &= "       WHERE Concat(inv_artcodigo, inv_provcod, inv_lugarfab, inv_prodlote, inv_UMventa) = '" & strKey & "'"""

            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSQL, CON)
            REA = COM.ExecuteReader
            Do While REA.Read
                '   GetProductIdFor() = REA.GetInt32("inv_numero")
            Loop
        End If
    End Function


    'Query para guardar Datos Encabezado
    Private Function GuardarDocumento() As Boolean
        Dim strSQL As String

        Try
            Dim inv As New Tablas.TINVENTARIOS
            inv.CONEXION = strConexion

            inv.INV_SISEMP = Sesion.IdEmpresa
            inv.INV_NUMERO = celdaCodigo.Text
            inv.inv_fecha_NET = dtpFecha.Value.ToString(FORMATO_MYSQL)
            inv.INV_ARTCODIGO = celdaIDProducto.Text
            inv.INV_PROVCOD = celdaIDProveedor.Text
            inv.INV_PARTNUM = celdaNParte.Text
            inv.INV_LUGARFAB = celdaIDPais.Text
            inv.INV_PRODANO = celdaAño.Text
            inv.INV_PRODSEM = If(celdaSemana.Text = Nothing, 0, celdaSemana.Text)
            inv.INV_PRODLOTE = If(celdaLoteNumb.Text = Nothing, "", celdaLoteNumb.Text)
            inv.INV_UMVENTA = celdaIDVenta.Text
            inv.INV_UMCMPRA = celdaIDCompra.Text
            inv.INV_UMFAC = celdaContenido.Text
            inv.INV_COSTO = celdaCostoCIF.Text
            inv.INV_PRECIOMIN = celdaPrecioMin.Text
            inv.INV_PRECIOMAX = celdaPrecioMax.Text
            inv.INV_PRECIOFAC = celdaFactor.Text
            inv.INV_STATUS = IIf(rbotonActivo.Checked = True, 1, 0)
            inv.INV_NOTAS = celdaNotas.Text
            inv.INV_GENERICO = IIf(checkGenerico.Checked = True, 1, 0)
            inv.INV_ACTIVO = IIf(checkDesactivar.Checked = True, 1, 0)
            inv.INV_MUESTRA = IIf(checkMuestra.Checked = True, 1, 0)
            inv.INV_DESCRIPCION = IIf(celdaDescripcion.Text.LongCount = 0, STR_VACIO, celdaDescripcion.Text)

            If Me.Tag = "Mod" Then
                If inv.PUPDATE() = False Then
                    MsgBox(inv.MERROR.ToString & "Could not update the document", MsgBoxStyle.Critical)
                End If
            Else
                If inv.PINSERT = False Then
                    MsgBox(inv.MERROR.ToString & "Could not save the document", MsgBoxStyle.Critical)
                End If
            End If

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Function

    Private Sub ActualizarDatos()
        Dim strSQL As String = STR_VACIO
        Dim strOrigen As String = STR_VACIO
        Dim strDescripcion As String = STR_VACIO
        Dim COM As New MySqlCommand

        strSQL = " SELECT cat_clave FROM Catalogos WHERE cat_clase = 'Paises' AND cat_num = " & celdaIDPais.Text

        MyCnn.CONECTAR = strConexion
        COM = New MySqlCommand(strSQL, CON)
        strOrigen = COM.ExecuteScalar
        strSQL = STR_VACIO

        strSQL = " SELECT a.art_DLarga FROM Inventarios i LEFT JOIN Articulos a ON a.art_sisemp = i.inv_sisemp AND a.art_codigo = i.inv_artcodigo WHERE i.inv_sisemp = {empresa} AND i.inv_numero = {idProv} "
        strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
        strSQL = Replace(strSQL, "{idProv}", celdaCodigo.Text)

        MyCnn.CONECTAR = strConexion
        COM = New MySqlCommand(strSQL, CON)
        strDescripcion = COM.ExecuteScalar
        strSQL = STR_VACIO

        strSQL = " UPDATE Dcmtos_DTL_Pro SET PDoc_Prov_Cod= {Proveedor} WHERE PDoc_Prd_Cod= {codigo} AND NOT(PDoc_Prov_Cod= {Proveedor}) "
        If Sesion.IdEmpresa = 18 Then
            strSQL &= "; UPDATE PDM.Dcmtos_DTL_Pro SET PDoc_Prov_Cod= {Proveedor} WHERE PDoc_Prd_Cod= {codigo} AND NOT(PDoc_Prov_Cod= {Proveedor}) "
        End If
        strSQL = Replace(strSQL, "{Proveedor}", celdaIDProveedor.Text)
        strSQL = Replace(strSQL, "{codigo}", celdaCodigo.Text)
        MyCnn.CONECTAR = strConexion
        COM = New MySqlCommand(strSQL, CON)
        COM.ExecuteNonQuery()
        strSQL = STR_VACIO

        strSQL = " UPDATE Dcmtos_DTL SET DDoc_Prd_Des='{descripcion}' WHERE DDoc_Sis_Emp = {empresa} AND DDoc_Doc_Cat IN (55, 180, 47) AND DDoc_Prd_Cod={codigo} "
        If Sesion.IdEmpresa = 18 Then
            strSQL &= "; UPDATE PDM.Dcmtos_DTL SET DDoc_Prd_Des='{descripcion}' WHERE DDoc_Sis_Emp = {empresa} AND DDoc_Doc_Cat IN (55, 180, 47) AND DDoc_Prd_Cod={codigo} "
        End If
        strSQL = Replace(strSQL, "{descripcion}", celdaProducto.Text & Space(1) & strOrigen)
        strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
        strSQL = Replace(strSQL, "{codigo}", celdaCodigo.Text)
        MyCnn.CONECTAR = strConexion
        COM = New MySqlCommand(strSQL, CON)
        COM.ExecuteNonQuery()
        strSQL = STR_VACIO

        strSQL = " UPDATE Dcmtos_DTL SET DDoc_Prd_Des=  '{descripcion}' WHERE DDoc_Sis_Emp = {empresa} AND DDoc_Doc_Cat IN (75, 127) AND DDoc_Prd_Cod= {codigo} "
        If Sesion.IdEmpresa = 18 Then
            strSQL &= "; UPDATE PDM.Dcmtos_DTL SET DDoc_Prd_Des=  '{descripcion}' WHERE DDoc_Sis_Emp = {empresa} AND DDoc_Doc_Cat IN (75, 127) AND DDoc_Prd_Cod= {codigo} "
        End If
        strSQL = Replace(strSQL, "{descripcion}", CStr(strDescripcion) & "  " & CStr(strOrigen))
        strSQL = Replace(strSQL, "{codigo}", celdaCodigo.Text)
        strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
        MyCnn.CONECTAR = strConexion
        COM = New MySqlCommand(strSQL, CON)
        COM.ExecuteNonQuery()
        strSQL = STR_VACIO
    End Sub

    Private Function ValidarProveedor(ByVal IdProveedor As Integer) As Boolean
        Dim logCancelar As Boolean
        Dim strSQL As String = STR_VACIO
        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader
        Dim strMensaje As String = STR_VACIO

        'Si el cód. de prov. es dif. y el anterior no era vacío
        'If Not celdaIDProveedor.Text = strCode Or strCode = vbNullString Then
        If Not (IdProveedor = celdaIDProveedor.Text) Or (celdaIDProveedor.Text = vbNullString) Then
            strSQL = " SELECT d.PDoc_Chi_Ano, d.PDoc_Chi_Num, c.cat_desc"
            strSQL &= " FROM Dcmtos_DTL_Pro AS d LEFT JOIN Catalogos AS c ON c.cat_num = d.PDoc_Chi_Cat "
            strSQL &= "     WHERE d.PDoc_Sis_Emp = {empresa} AND d.PDoc_Prd_Cod = {codigo} AND NOT(d.PDoc_Prov_Cod = {idProveedor})"

            strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
            strSQL = Replace(strSQL, "{codigo}", celdaCodigo.Text)
            strSQL = Replace(strSQL, "{idProveedor}", celdaIDProveedor.Text)

            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSQL, CON)
            REA = COM.ExecuteReader

            If REA.HasRows Then
                Do While REA.Read
                    strMensaje = strMensaje & IIf(strMensaje = vbNullString, vbNullString, vbCr) & REA.GetInt32("PDoc_Chi_Ano") & "-" & REA.GetInt32("PDoc_Chi_Num") & vbTab & REA.GetString("cat_desc")
                Loop
            End If

            If Not (strMensaje = vbNullString) Then
                strMensaje = "Los siguientes documentos se verian afectados con el cambio de proveedor." & vbCr & vbCr & strMensaje & vbCr & vbCr & "SE SUGIERE NO REALIZAR DICHA MODIFICACION." & vbCr & vbCr & "¿Confirmar que desea continuar?"
                If MsgBox(strMensaje, vbExclamation + vbYesNo + vbDefaultButton2, "Confirmar modificacion") = vbNo Then
                    logCancelar = True
                End If
            End If
        End If

        ValidarProveedor = Not (logCancelar)
    End Function
    Private Function VerificarSiTieneDependencias()
        Dim strSQL As String = STR_VACIO

        strSQL = " SELECT COUNT(*)"
        strSQL &= "     FROM Dcmtos_DTL d "
        strSQL &= "         WHERE d.DDoc_Sis_Emp = {empresa} AND d.DDoc_Doc_Cat IN(127,75) AND d.DDoc_Prd_Cod = {num} "

        strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
        strSQL = Replace(strSQL, "{num}", celdaCodigo.Text)
        Return strSQL
    End Function
    Private Sub BorrarCodigosInventario2(ByVal num As Integer)
        Dim strSQL As String = STR_VACIO
        Try
            strSQL = "inv_sisemp = {empresa} AND inv_numero = {numero} "

            strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
            strSQL = Replace(strSQL, "{numero}", num)

            Dim inv As New Tablas.TINVENTARIOS
            inv.CONEXION = strConexion
            inv.PDELETE(strSQL)

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Public Function BorrarCodigosInventario(ByVal num As Integer) As Boolean
        BorrarCodigosInventario = False
        Dim inv As New Tablas.TINVENTARIOS
        Dim strCondicion As String = STR_VACIO
        'strCondicion = " inv_sisemp = {empresa} AND inv_numero = {numero}"
        'strCondicion = Replace(strCondicion, "{empresa}", Sesion.IdEmpresa)
        'strCondicion = Replace(strCondicion, "{numero}", num)
        Try
            inv.CONEXION = strConexion
            inv.INV_NUMERO = num
            If inv.PDELETE(strCondicion) = True Then
                BorrarCodigosInventario = True
                MsgBox("The record has been successfully deleted.", MsgBoxStyle.Information, "Deletion Successful")
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Function

#End Region

#Region "Eventos VB.NET"

    Private Sub frmCodigosInventario_FormClosing(sender As Object, e As FormClosingEventArgs) Handles Me.FormClosing
        Try
            frmSPrincipal.BarraDeTareas1.QuitarFormulario(strKey)
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try

    End Sub

    Private Sub frmCodigosInventarios_load(sender As Object, e As EventArgs) Handles MyBase.Load
        Accessos()
        MostrarLista()

        celdaNParte.Text = "N/A"
        celdaLoteNumb.Text = "N/A"
        celdaVenta.Text = "LBS"
        celdaIDVenta.Text = 69
        celdaCompra.Text = "LBS"
        celdaIDCompra.Text = 69
        celdaContenido.Text = 1
        celdaCostoCIF.Text = "0.00"
        celdaPrecioMin.Text = "0.00"
        celdaPrecioMax.Text = "0.00"
        celdaAño.Text = cFunciones.AñoMySQL
        rbotonActivo.Checked = True
        rbotonBaja.Checked = False

    End Sub

    Private Sub Encabezado1_ClickCerrar(sender As Object, click As Boolean) Handles Encabezado1.ClickCerrar
        If panelDocumento.Visible = False Then
            Me.Close()
        Else
            MostrarLista()
        End If
    End Sub

    Private Sub Encabezado1_ClickGuardar(sender As Object, click As Boolean) Handles Encabezado1.ClickGuardar
        Dim Respuesta As String = STR_VACIO
        Dim strSQL As String = STR_VACIO
        Dim strSQL2 As String = STR_VACIO
        Dim strSQL4 As String = STR_VACIO
        Dim strSQL5 As String = STR_VACIO
        Dim strCodigo As String = STR_VACIO
        Dim NumMax As String = STR_VACIO
        Dim MaxNum As Integer
        Dim conec As New MySqlConnection
        Dim conec2 As New MySqlConnection
        Dim conec3 As New MySqlConnection
        Dim conec4 As New MySqlConnection
        Dim COM2 As New MySqlCommand
        Dim COM3 As New MySqlCommand
        Dim COM4 As New MySqlCommand
        Dim COM As New MySqlCommand
        Dim strSQL3 As String = STR_VACIO
        Dim intCodigo As Integer
        Dim intTipo As Integer
        Dim strTexto As String = STR_VACIO

        If Me.Tag = "Nuevo" Then

            strSQL3 = "SELECT ifnull(MAX(inv_numero),0) + 1 AS Nuevo "
            strSQL3 &= "     FROM Inventarios"
            strSQL3 &= "             WHERE inv_sisemp = {empresa}"

            strSQL3 = Replace(strSQL3, "{empresa}", Sesion.IdEmpresa)

            conec3 = New MySqlConnection(strConexion)
            conec3.Open()
            COM3 = New MySqlCommand(strSQL3, conec3)
            Using conec3
                intCodigo = COM3.ExecuteScalar()
                COM3.Dispose()
                COM3 = Nothing
                conec3.Close()
                conec3.Dispose()
                conec3 = Nothing
                System.GC.Collect()
            End Using
            celdaCodigo.Text = intCodigo
        End If

        If Me.Tag = "Nuevo" Then
            'INSERTANDO

            If ComprobarDatos() = True Then

                If celdaCodigo.Text > 0 Then

                    GuardarDocumento()
                    cFunciones.EscribirRegistro("Inventarios", clsFunciones.AccEnum.acAdd, celdaCodigo.Text, 0, 0, 0, "COD:" & celdaIDProducto.Text)

                    MsgBox("The record has been saved.", vbInformation, "Inventory")
                End If
            Else
                Exit Sub
            End If
            MostrarLista(True)

        ElseIf Me.Tag = "Mod" Then

            If ComprobarDatos() = True Then

                If checkGenerico.Checked = False And Not celdaCostoCIF.Text = celdaCIFAnterior.Text Then
                    intTipo = 47

                    strSQL4 = "SELECT IFNULL(CAST(GROUP_CONCAT(DISTINCT CAST(CONCAT(e.HDoc_Doc_Ano,'/',e.HDoc_Doc_Num,' (',e.HDoc_DR1_Num,')') AS CHAR) ORDER BY e.HDoc_Doc_Ano, e.HDoc_Doc_Num SEPARATOR ', ') AS CHAR),'') Dato"
                    strSQL4 &= "     FROM Dcmtos_DTL d"
                    strSQL4 &= "            INNER JOIN Dcmtos_HDR e ON e.HDoc_Sis_Emp = d.DDoc_Sis_Emp AND e.HDoc_Doc_Cat = d.DDoc_Doc_Cat AND e.HDoc_Doc_Ano = d.DDoc_Doc_Ano AND e.HDoc_Doc_Num = d.DDoc_Doc_Num"
                    strSQL4 &= "     WHERE DDoc_Sis_Emp = {empresa} AND DDoc_Doc_Cat = 47 AND DDoc_Prd_Cod = {codigo}"

                    strSQL4 = Replace(strSQL4, "{empresa}", Sesion.IdEmpresa)
                    strSQL4 = Replace(strSQL4, "{codigo}", celdaCodigo.Text)

                    conec = New MySqlConnection(strConexion)
                    conec.Open()
                    COM = New MySqlCommand(strSQL4, conec)
                    Using conec
                        strTexto = COM.ExecuteScalar
                        COM.Dispose()
                        COM = Nothing
                        conec.Close()
                        conec.Dispose()
                        conec = Nothing
                        System.GC.Collect()
                    End Using

                    If Not (strTexto = vbNullString) Then
                        If dgDetalle.Rows.Count > INT_UNO Then
                            If MsgBox("Esta modificando un codigo utilizado en varias lineas" & vbCr & vbCr & "** SE SUGIERE NO CONTINUAR **", vbExclamation + vbOKCancel + vbDefaultButton2, "Cambio Multiple") = vbCancel Then
                                Exit Sub
                            End If
                        End If

                        Select Case MsgBox("Ha cambiado el costo de la mercancia" & vbCr & vbCr & "Referencias: " & vbCr & strTexto & vbCr & vbCr & "¿Cambiar el costo en el ingreso a bodega?", vbQuestion + vbYesNoCancel + vbDefaultButton3, "Confirmar")
                            Case vbYes
                                strSQL5 = "Update Dcmtos_DTL "
                                strSQL5 &= "    SET DDoc_Prd_PUQ = {costo}, DDoc_Prd_NET = {costo} "
                                strSQL5 &= "        WHERE DDoc_Sis_Emp = {empresa} AND DDoc_Doc_Cat ={tipo} AND DDoc_Prd_Cod = {codigo}"

                                If Sesion.IdEmpresa = 18 Then
                                    strSQL5 &= ";Update PDM.Dcmtos_DTL "
                                    strSQL5 &= "    SET DDoc_Prd_PUQ = {costo}, DDoc_Prd_NET = {costo} "
                                    strSQL5 &= "        WHERE DDoc_Sis_Emp = {empresa} AND DDoc_Doc_Cat ={tipo} AND DDoc_Prd_Cod = {codigo}"
                                End If

                                strSQL5 = Replace(strSQL5, "{empresa}", Sesion.IdEmpresa)
                                strSQL5 = Replace(strSQL5, "{tipo}", intTipo)
                                strSQL5 = Replace(strSQL5, "{codigo}", celdaCodigo.Text)
                                strSQL5 = Replace(strSQL5, "{costo}", celdaCostoCIF.Text)

                                conec = New MySqlConnection(strConexion)
                                conec.Open()
                                COM = New MySqlCommand(strSQL5, conec)
                                Using conec
                                    strTexto = COM.ExecuteNonQuery
                                    COM.Dispose()
                                    COM = Nothing
                                    conec.Close()
                                    conec.Dispose()
                                    conec = Nothing
                                    System.GC.Collect()
                                End Using

                            Case vbCancel
                                Exit Sub
                        End Select
                    End If
                End If
                GuardarDocumento()
                ActualizarDatos()

                'Guarda y Activa y Desactiva Productos con CheckProAct
                If celdaDesactivar.Visible = True Then
                    celdaDesactivar.Name = "¡WARNING!"
                    Respuesta = MsgBox("Are you sure you want to Deactivate this Product?", vbYesNo)
                    If Respuesta = vbYes Then
                        strSQL = "Update Inventarios"
                        strSQL &= " Set"
                        strSQL &= "  inv_activo ='1'"
                        strSQL &= "      Where"
                        strSQL &= "          inv_numero = " & intCodigo

                        If Sesion.IdEmpresa = 18 Then
                            strSQL &= ";Update PDM.Inventarios"
                            strSQL &= " Set"
                            strSQL &= "  inv_activo ='1'"
                            strSQL &= "      Where"
                            strSQL &= "          inv_numero = " & intCodigo
                        End If

                        conec = New MySqlConnection(strConexion)
                        conec.Open()
                        COM = New MySqlCommand(strSQL, conec)
                        Using conec
                            COM.ExecuteNonQuery()
                            COM.Dispose()
                            COM = Nothing
                            conec.Close()
                            conec.Dispose()
                            conec = Nothing
                            System.GC.Collect()
                        End Using
                    End If
                ElseIf celdaDesactivar.Visible = False Then
                    celdaDesactivar.Name = "¡WARNING!"
                    Respuesta = MsgBox("Are you sure you want to activate this product?", vbYesNo)
                    If Respuesta = vbYes Then
                        strSQL2 = "Update Inventarios"
                        strSQL2 &= " Set"
                        strSQL2 &= "  inv_activo ='0'"
                        strSQL2 &= "      Where"
                        strSQL2 &= "          inv_numero = " & intCodigo

                        If Sesion.IdEmpresa = 18 Then
                            strSQL2 &= ";Update PDM.Inventarios"
                            strSQL2 &= " Set"
                            strSQL2 &= "  inv_activo ='0'"
                            strSQL2 &= "      Where"
                            strSQL2 &= "          inv_numero = " & intCodigo
                        End If

                        conec = New MySqlConnection(strConexion)
                        conec.Open()
                        COM = New MySqlCommand(strSQL2, conec)
                        Using conec
                            COM.ExecuteNonQuery()
                            COM.Dispose()
                            COM = Nothing
                            conec.Close()
                            conec.Dispose()
                            conec = Nothing
                            System.GC.Collect()
                        End Using
                    End If
                End If
                cFunciones.EscribirRegistro("Inventarios", clsFunciones.AccEnum.acUpdate, celdaCodigo.Text, 0, 0, 0, "COD:" & celdaIDProducto.Text)

                MsgBox("El registro ha sido actualizado.", vbInformation, "Información")
                MostrarLista(True)
            End If


        Else
            MsgBox("No fue posible clasificar la operacion para guardar", vbExclamation, "Aviso")
        End If
    End Sub

    Private Sub encabezado1_ClickNuevo(sender As Object, click As Boolean) Handles Encabezado1.ClickNuevo
        Me.Tag = "Nuevo"
        Dim strSQL As String = STR_VACIO
        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader

        MostrarLista(False, True)

        strSQL = " SELECT cat_num,cat_clave
                    FROM Catalogos
                        WHERE cat_num = 69"
        MyCnn.CONECTAR = strConexion
        COM = New MySqlCommand(strSQL, CON)
        REA = COM.ExecuteReader

        If REA.HasRows Then
            Do While REA.Read
                celdaVenta.Text = REA.GetString("cat_clave")
                celdaIDVenta.Text = REA.GetInt32("cat_num")
                celdaCompra.Text = REA.GetString("cat_clave")
                celdaIDCompra.Text = REA.GetInt32("cat_num")
            Loop
        End If

        Encabezado1.botonBorrar.Enabled = False
            celdaCodigo.ReadOnly = True
            celdaNParte.Text = "N/A"
            celdaLoteNumb.Text = "N/A"
            celdaAño.Text = cFunciones.AñoMySQL
            celdaCostoCIF.Text = "0.00"
            celdaIDCostoCIF.Text = 0
            celdaPrecioMin.Text = "0.00"
            celdaPrecioMax.Text = "0.00"
            celdaFactor.Text = 1

            rbotonActivo.Checked = True
            rbotonBaja.Checked = False
            dtpFecha.Value = cFunciones.HoyMySQL

    End Sub



    Private Sub botonProveedor_Click(sender As Object, e As EventArgs) Handles botonProveedor.Click
        Dim frm As New frmSeleccionar

        Try

            'Datospara mostrar en pantalla
            frm.Titulo = "Providers"
            frm.FiltroText = "Enter the Provider to Filter Supplier"

            'Datos de Base para Llenar Grid
            frm.Campos = "pro_codigo Code, pro_proveedor Provider"
            frm.Tabla = "Proveedores"
            frm.Condicion = "pro_fabricante = 'Si' AND pro_sisemp=" & Sesion.IdEmpresa
            frm.Limite = 20
            frm.Ordenamiento = "pro_proveedor"
            frm.TipoOrdenamiento = ""
            frm.Filtro = "pro_proveedor"

            'Mostrar formulario
            frm.ShowDialog(Me)

            If frm.DialogResult = System.Windows.Forms.DialogResult.OK Then
                If Me.Tag = "Nuevo" Then
                    'Captura de datos seleccionados
                    celdaIDProveedor.Text = frm.LLave
                    'strCode = frm.LLave
                    celdaProveedor.Text = frm.Dato
                ElseIf Me.Tag = "Mod" Then
                    'If (frm.LLave = celdaIDProveedor.Text) Or (celdaIDProveedor.Text = vbNullString) Then
                    If Not ValidarProveedor(frm.LLave) Then
                        Exit Sub
                    Else
                        celdaIDProveedor.Text = frm.LLave
                        celdaProveedor.Text = frm.Dato
                    End If
                End If
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub botonPais_Click(sender As Object, e As EventArgs) Handles botonPais.Click

        Dim frm As New frmSeleccionar

        Try
            frm.Titulo = "Country"
            frm.Campos = " cat_num Code, cat_desc Country"
            frm.Tabla = " Catalogos"
            frm.FiltroText = " Ingrese el nombre del país para filtrar"
            frm.Filtro = " cat_desc "
            frm.Condicion = "cat_clase = 'paises'"

            frm.ShowDialog(Me)
            If frm.DialogResult = System.Windows.Forms.DialogResult.OK Then
                celdaIDPais.Text = frm.LLave
                celdaPais.Text = frm.Dato
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try

    End Sub

    Private Sub rbActivo_CheckedChanged(sender As Object, e As EventArgs) Handles rbotonActivo.CheckedChanged

        If rbotonActivo.Checked = True Then
            'MessageBox.Show("Usted ha marcado Si")
        Else
            rbotonBaja.Checked = False
            ' MessageBox.Show("Usted ha marcado No")
        End If

    End Sub

    Private Sub botonCostoCIF_Click(sender As Object, e As EventArgs) Handles botonCostoCIF.Click

        Dim frm As New frmPrecioUnitario

        frm.ShowDialog(Me)
        If frm.DialogResult = System.Windows.Forms.DialogResult.OK Then
            celdaCostoCIF.Text = frm.Aceptar
            celdaPrecioMin.Text = frm.Aceptar
            celdaPrecioMax.Text = frm.Aceptar

        End If

    End Sub

    Private Sub botonVenta_Click(sender As Object, e As EventArgs) Handles botonVenta.Click

        Dim frm As New frmSeleccionar

        Try
            frm.Titulo = "Sale"
            frm.Campos = " cat_num Code, cat_clave Measure, cat_desc Description"
            frm.Tabla = " Catalogos"
            frm.FiltroText = " Enter the extent to Filter"
            frm.Filtro = " cat_clave "
            frm.Condicion = "cat_clase = 'medidas'"

            frm.ShowDialog(Me)
            If frm.DialogResult = System.Windows.Forms.DialogResult.OK Then
                celdaIDVenta.Text = frm.LLave
                celdaVenta.Text = frm.Dato
                celdaArticulo.Text = frm.Dato2
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try

    End Sub

    Private Sub botonCompra_Click(sender As Object, e As EventArgs) Handles botonCompra.Click

        Dim frm As New frmSeleccionar
        Try
            frm.Titulo = "Sale"
            frm.Campos = " cat_num Code, cat_clave Measure"
            frm.Tabla = " Catalogos"
            frm.FiltroText = " Enter the extent to Filter"
            frm.Filtro = " cat_clave "
            frm.Condicion = "cat_clase = 'medidas'"

            frm.ShowDialog(Me)
            If frm.DialogResult = System.Windows.Forms.DialogResult.OK Then
                celdaIDCompra.Text = frm.LLave
                celdaCompra.Text = frm.Dato
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub botonProducto_Click(sender As Object, e As EventArgs) Handles botonProducto.Click

        Dim frm As New frmSeleccionar
        Try
            frm.Titulo = "Products"
            frm.Campos = " art_codigo Code, art_DCorta Short_Description, art_DLarga Long_Description "
            frm.Tabla = "Articulos"
            frm.FiltroText = " Enter Short Description About Filter"
            frm.Filtro = " art_DCorta"
            frm.Condicion = " art_sisemp =" & Sesion.IdEmpresa & " AND art_status = 1  and art_produccion = 1 "
            frm.Limite = 30
            frm.Ordenamiento = "art_DCorta"
            frm.TipoOrdenamiento = ""

            frm.ShowDialog(Me)
            If frm.DialogResult = System.Windows.Forms.DialogResult.OK Then
                celdaIDProducto.Text = frm.LLave
                celdaProducto.Text = frm.Dato
                celdaArticulo.Text = frm.Dato2
                celdaDescripcion.Text = frm.Dato
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try


    End Sub

    Private Sub dgLista_DoubleClick(sender As Object, e As EventArgs) Handles dgLista.DoubleClick
        reset()
        Me.Tag = "Mod"
        Dim numero As Integer

        numero = dgLista.SelectedCells(0).Value
        CargarDatos(numero)
        'CargarCostos()
        CargarDetalle(numero)
        MostrarLista(False)

        celdaVenta.ReadOnly = True
        celdaCompra.ReadOnly = True
        celdaCodigo.ReadOnly = True

    End Sub

    Private Sub checkDesactivar_Click(sender As Object, e As EventArgs) Handles checkDesactivar.Click
        If checkDesactivar.Checked = True Then
            celdaDesactivar.Visible = False
        ElseIf checkDesactivar.Checked = False Then
            celdaDesactivar.Visible = True
        End If
    End Sub

    Private Sub celdaAño_DoubleClick(sender As Object, e As EventArgs) Handles celdaAño.DoubleClick
        Try
            Dim Calendar As New frmDateTimePicker

            Calendar.CodigosInv = True
            Calendar.ShowDialog(Me)

            If Calendar.DialogResult = System.Windows.Forms.DialogResult.OK Then
                celdaSemana.Text = Calendar.LLaveCod
                celdaAño.Text = DatePart("YYYY", Calendar.LLave)

            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub botonActualizar_Click(sender As Object, e As EventArgs) Handles botonActualizar.Click
        Dim logCancelar As Boolean

        If Not (logCancelar) Then
            celdaBuscar.Text = vbNullString
            'Procedimiento para cargar panel dgLista
            CargarLista(0)

        End If
    End Sub

    Private Sub dgLista_KeyDown(sender As Object, e As KeyEventArgs) Handles dgLista.KeyDown
        Try
            If e.KeyCode = Keys.F3 Then
                cFunciones.BuscarenLista(dgLista)
                e.Handled = True
                e.SuppressKeyPress = True
            ElseIf e.KeyCode = Keys.F6 Then
                'cFunciones.MostrarDependencias(-1, dgLista.SelectedCells(0).Value, -1)
            ElseIf e.KeyCode = Keys.F7 Then
                Dim rpt As New clsReportes
                rpt.Historial(0, 0, 0, "Inventarios", dgLista.CurrentRow.Cells("colNumber").Value)

            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub botonMostrarAll_Click(sender As Object, e As EventArgs) Handles botonMostrarAll.Click
        celdaBuscar.Text = vbNullString
        CargarLista(2)
    End Sub

    Private Sub checkGenerico_CheckedChanged(sender As Object, e As EventArgs) Handles checkGenerico.CheckedChanged
        BloquearCampos()
    End Sub

    Private Sub botonBuscar_Click(sender As Object, e As EventArgs) Handles botonBuscar.Click
        CargarLista(1)
    End Sub

    Private Sub celdaCostoCIF_TextChanged(sender As Object, e As EventArgs) Handles celdaCostoCIF.TextChanged
        celdaPrecioMin.Text = celdaCostoCIF.Text
        celdaPrecioMax.Text = celdaCostoCIF.Text
    End Sub

#End Region

    Private Sub frmCodigosInventario_Closing(sender As Object, e As CancelEventArgs) Handles Me.Closing
        Fprincipal.BarraDeTareas1.QuitarFormulario(strKey)
    End Sub

    Private Sub Encabezado1_ClickBorrar(sender As Object, click As Boolean) Handles Encabezado1.ClickBorrar
        If LogBorrar = True Then
            Dim strSQL As String = STR_VACIO
            Dim COM As MySqlCommand
            Dim IntNumDocs As Integer

            strSQL = VerificarSiTieneDependencias()
            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSQL, CON)
            IntNumDocs = COM.ExecuteScalar()
            If IntNumDocs > 0 Then
                MsgBox("You can not delete a document in the process", vbInformation, "Notice")
            Else
                If MsgBox("The document will be permanently deleted, do you want to continue?", vbQuestion + vbYesNo, "Question") = vbYes Then
                    BorrarCodigosInventario(celdaCodigo.Text)
                    cFunciones.EscribirRegistro("Inventarios", clsFunciones.AccEnum.acDelete, celdaCodigo.Text, 0, 0, 0, "COD:" & celdaIDProducto.Text)
                    MostrarLista()
                End If
            End If
        End If
    End Sub
End Class