﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class frmPedidoFibra
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Dim DataGridViewCellStyle1 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Me.panelLista = New System.Windows.Forms.Panel()
        Me.Checkfecha = New System.Windows.Forms.CheckBox()
        Me.etiquetaYFecha = New System.Windows.Forms.Label()
        Me.dtpFinal = New System.Windows.Forms.DateTimePicker()
        Me.dtpInicio = New System.Windows.Forms.DateTimePicker()
        Me.botonActualizar = New System.Windows.Forms.Button()
        Me.dgLista = New System.Windows.Forms.DataGridView()
        Me.colNumero = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colFechaLista = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colClienteLista = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colReferenciaLista = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colDireccionLista = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colAñoLista = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colRevisado = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.TextBox8 = New System.Windows.Forms.TextBox()
        Me.panelDocumento = New System.Windows.Forms.Panel()
        Me.GbFabricante = New System.Windows.Forms.GroupBox()
        Me.celdaDireccionFabricante = New System.Windows.Forms.TextBox()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.celdaidFabricante = New System.Windows.Forms.TextBox()
        Me.botonFabricante = New System.Windows.Forms.Button()
        Me.celdaFabricante = New System.Windows.Forms.TextBox()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.GbProveedor = New System.Windows.Forms.GroupBox()
        Me.celdaDireccionProveedor = New System.Windows.Forms.TextBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.celdaidProveedor = New System.Windows.Forms.TextBox()
        Me.botonProveedor = New System.Windows.Forms.Button()
        Me.celdaProveedor = New System.Windows.Forms.TextBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.panelDetalle = New System.Windows.Forms.Panel()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.dgDetalle = New System.Windows.Forms.DataGridView()
        Me.colCatalogo = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colYear = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colCodigo = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colDescripcion = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colNumMedida = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colMedida = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colOrigen = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colPrecio = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colFecha = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colCantidad = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colTotal = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colLineaDet = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colDescargos = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colFechaInicio = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colAgrega = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colObservacion = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.panelBotones = New System.Windows.Forms.Panel()
        Me.botonDelete = New System.Windows.Forms.Button()
        Me.botonAdd = New System.Windows.Forms.Button()
        Me.gbDatosPedido = New System.Windows.Forms.GroupBox()
        Me.celdaCredit = New System.Windows.Forms.TextBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.celdaDescripcionP = New System.Windows.Forms.TextBox()
        Me.celdaProyecto = New System.Windows.Forms.TextBox()
        Me.celdaDescripcion = New System.Windows.Forms.TextBox()
        Me.celdaidflujodetalle = New System.Windows.Forms.TextBox()
        Me.celdaidTarea = New System.Windows.Forms.TextBox()
        Me.celdaidProyecto = New System.Windows.Forms.TextBox()
        Me.etiquetaAnulada = New System.Windows.Forms.Label()
        Me.celdaComentario = New System.Windows.Forms.TextBox()
        Me.celdaNumeroReq = New System.Windows.Forms.TextBox()
        Me.etiquetaNumber = New System.Windows.Forms.Label()
        Me.etiquetaImpuestos = New System.Windows.Forms.Label()
        Me.celdaImpuestos = New System.Windows.Forms.TextBox()
        Me.etiquetaRevisado = New System.Windows.Forms.Label()
        Me.celdaRevisado = New System.Windows.Forms.TextBox()
        Me.celdaUsuario = New System.Windows.Forms.TextBox()
        Me.celdaCatalogo = New System.Windows.Forms.TextBox()
        Me.celdaEmpresa = New System.Windows.Forms.TextBox()
        Me.etiquetaUsuario = New System.Windows.Forms.Label()
        Me.etiquetaCatalogo = New System.Windows.Forms.Label()
        Me.etiquetaEmpresa = New System.Windows.Forms.Label()
        Me.celdaCode = New System.Windows.Forms.TextBox()
        Me.dtpFecha1 = New System.Windows.Forms.DateTimePicker()
        Me.celdaIDMoneda = New System.Windows.Forms.TextBox()
        Me.botonMoneda = New System.Windows.Forms.Button()
        Me.celdaIDCliente = New System.Windows.Forms.TextBox()
        Me.BotonCliente = New System.Windows.Forms.Button()
        Me.celdaTC = New System.Windows.Forms.TextBox()
        Me.etiquetaTasa = New System.Windows.Forms.Label()
        Me.celdaNit = New System.Windows.Forms.TextBox()
        Me.etiquetaNIT = New System.Windows.Forms.Label()
        Me.checkActivo = New System.Windows.Forms.CheckBox()
        Me.celdaCliente = New System.Windows.Forms.TextBox()
        Me.celdaMoneda = New System.Windows.Forms.TextBox()
        Me.celdaDireccion = New System.Windows.Forms.TextBox()
        Me.celdaNumero = New System.Windows.Forms.TextBox()
        Me.celdaAño = New System.Windows.Forms.TextBox()
        Me.etiquetaMoneda = New System.Windows.Forms.Label()
        Me.etiquetaDireccion = New System.Windows.Forms.Label()
        Me.etiquetaCliente = New System.Windows.Forms.Label()
        Me.etiquetaFecha = New System.Windows.Forms.Label()
        Me.etiquetaNumero = New System.Windows.Forms.Label()
        Me.etiquetaAño = New System.Windows.Forms.Label()
        Me.BarraTitulo1 = New KARIMs_SGI.BarraTitulo()
        Me.Encabezado1 = New KARIMs_SGI.encabezado()
        Me.etiquetaTotales = New System.Windows.Forms.Label()
        Me.celdaTotales = New System.Windows.Forms.TextBox()
        Me.celdaTotales2 = New System.Windows.Forms.TextBox()
        Me.dgDetalle2 = New System.Windows.Forms.DataGridView()
        Me.colSaldoActual = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colCantida = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colNDespacho = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colAño = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colLinea = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.panelAbajo = New System.Windows.Forms.Panel()
        Me.panelLista.SuspendLayout()
        CType(Me.dgLista, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.panelDocumento.SuspendLayout()
        Me.GbFabricante.SuspendLayout()
        Me.GbProveedor.SuspendLayout()
        Me.panelDetalle.SuspendLayout()
        Me.Panel1.SuspendLayout()
        CType(Me.dgDetalle, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.panelBotones.SuspendLayout()
        Me.gbDatosPedido.SuspendLayout()
        CType(Me.dgDetalle2, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.panelAbajo.SuspendLayout()
        Me.SuspendLayout()
        '
        'panelLista
        '
        Me.panelLista.Controls.Add(Me.Checkfecha)
        Me.panelLista.Controls.Add(Me.etiquetaYFecha)
        Me.panelLista.Controls.Add(Me.dtpFinal)
        Me.panelLista.Controls.Add(Me.dtpInicio)
        Me.panelLista.Controls.Add(Me.botonActualizar)
        Me.panelLista.Controls.Add(Me.dgLista)
        Me.panelLista.Controls.Add(Me.TextBox8)
        Me.panelLista.Location = New System.Drawing.Point(12, 118)
        Me.panelLista.Name = "panelLista"
        Me.panelLista.Size = New System.Drawing.Size(833, 100)
        Me.panelLista.TabIndex = 11
        '
        'Checkfecha
        '
        Me.Checkfecha.AutoSize = True
        Me.Checkfecha.Checked = True
        Me.Checkfecha.CheckState = System.Windows.Forms.CheckState.Checked
        Me.Checkfecha.Location = New System.Drawing.Point(12, 19)
        Me.Checkfecha.Margin = New System.Windows.Forms.Padding(2)
        Me.Checkfecha.Name = "Checkfecha"
        Me.Checkfecha.Size = New System.Drawing.Size(176, 17)
        Me.Checkfecha.TabIndex = 5
        Me.Checkfecha.Text = "Show documents between date"
        Me.Checkfecha.UseVisualStyleBackColor = True
        '
        'etiquetaYFecha
        '
        Me.etiquetaYFecha.AutoSize = True
        Me.etiquetaYFecha.Location = New System.Drawing.Point(319, 19)
        Me.etiquetaYFecha.Name = "etiquetaYFecha"
        Me.etiquetaYFecha.Size = New System.Drawing.Size(52, 13)
        Me.etiquetaYFecha.TabIndex = 4
        Me.etiquetaYFecha.Text = "And Date"
        '
        'dtpFinal
        '
        Me.dtpFinal.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.dtpFinal.Location = New System.Drawing.Point(392, 18)
        Me.dtpFinal.Name = "dtpFinal"
        Me.dtpFinal.Size = New System.Drawing.Size(98, 20)
        Me.dtpFinal.TabIndex = 3
        '
        'dtpInicio
        '
        Me.dtpInicio.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.dtpInicio.Location = New System.Drawing.Point(203, 18)
        Me.dtpInicio.Name = "dtpInicio"
        Me.dtpInicio.Size = New System.Drawing.Size(98, 20)
        Me.dtpInicio.TabIndex = 2
        '
        'botonActualizar
        '
        Me.botonActualizar.Location = New System.Drawing.Point(512, 15)
        Me.botonActualizar.Name = "botonActualizar"
        Me.botonActualizar.Size = New System.Drawing.Size(75, 23)
        Me.botonActualizar.TabIndex = 1
        Me.botonActualizar.Text = "Update"
        Me.botonActualizar.UseVisualStyleBackColor = True
        '
        'dgLista
        '
        Me.dgLista.AllowUserToAddRows = False
        Me.dgLista.AllowUserToDeleteRows = False
        Me.dgLista.AllowUserToOrderColumns = True
        Me.dgLista.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells
        Me.dgLista.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells
        Me.dgLista.BackgroundColor = System.Drawing.SystemColors.Control
        Me.dgLista.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgLista.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.colNumero, Me.colFechaLista, Me.colClienteLista, Me.colReferenciaLista, Me.colDireccionLista, Me.colAñoLista, Me.colRevisado})
        Me.dgLista.Dock = System.Windows.Forms.DockStyle.Fill
        Me.dgLista.Location = New System.Drawing.Point(0, 47)
        Me.dgLista.MultiSelect = False
        Me.dgLista.Name = "dgLista"
        Me.dgLista.ReadOnly = True
        Me.dgLista.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.dgLista.Size = New System.Drawing.Size(833, 53)
        Me.dgLista.TabIndex = 1
        '
        'colNumero
        '
        Me.colNumero.HeaderText = "Number"
        Me.colNumero.Name = "colNumero"
        Me.colNumero.ReadOnly = True
        Me.colNumero.Width = 69
        '
        'colFechaLista
        '
        Me.colFechaLista.HeaderText = "Date"
        Me.colFechaLista.Name = "colFechaLista"
        Me.colFechaLista.ReadOnly = True
        Me.colFechaLista.Width = 55
        '
        'colClienteLista
        '
        Me.colClienteLista.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.colClienteLista.HeaderText = "Client"
        Me.colClienteLista.Name = "colClienteLista"
        Me.colClienteLista.ReadOnly = True
        Me.colClienteLista.Width = 58
        '
        'colReferenciaLista
        '
        Me.colReferenciaLista.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.colReferenciaLista.HeaderText = "Reference"
        Me.colReferenciaLista.Name = "colReferenciaLista"
        Me.colReferenciaLista.ReadOnly = True
        Me.colReferenciaLista.Width = 82
        '
        'colDireccionLista
        '
        Me.colDireccionLista.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.colDireccionLista.HeaderText = "Direction"
        Me.colDireccionLista.Name = "colDireccionLista"
        Me.colDireccionLista.ReadOnly = True
        Me.colDireccionLista.Width = 74
        '
        'colAñoLista
        '
        Me.colAñoLista.HeaderText = "Year"
        Me.colAñoLista.Name = "colAñoLista"
        Me.colAñoLista.ReadOnly = True
        Me.colAñoLista.Visible = False
        Me.colAñoLista.Width = 54
        '
        'colRevisado
        '
        Me.colRevisado.HeaderText = "Revisado"
        Me.colRevisado.Name = "colRevisado"
        Me.colRevisado.ReadOnly = True
        Me.colRevisado.Visible = False
        Me.colRevisado.Width = 77
        '
        'TextBox8
        '
        Me.TextBox8.BackColor = System.Drawing.SystemColors.Info
        Me.TextBox8.Dock = System.Windows.Forms.DockStyle.Top
        Me.TextBox8.Location = New System.Drawing.Point(0, 0)
        Me.TextBox8.Multiline = True
        Me.TextBox8.Name = "TextBox8"
        Me.TextBox8.Size = New System.Drawing.Size(833, 47)
        Me.TextBox8.TabIndex = 2
        '
        'panelDocumento
        '
        Me.panelDocumento.Controls.Add(Me.GbFabricante)
        Me.panelDocumento.Controls.Add(Me.GbProveedor)
        Me.panelDocumento.Controls.Add(Me.panelDetalle)
        Me.panelDocumento.Controls.Add(Me.panelAbajo)
        Me.panelDocumento.Controls.Add(Me.gbDatosPedido)
        Me.panelDocumento.Location = New System.Drawing.Point(12, 224)
        Me.panelDocumento.Name = "panelDocumento"
        Me.panelDocumento.Size = New System.Drawing.Size(892, 456)
        Me.panelDocumento.TabIndex = 12
        '
        'GbFabricante
        '
        Me.GbFabricante.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.GbFabricante.Controls.Add(Me.celdaDireccionFabricante)
        Me.GbFabricante.Controls.Add(Me.Label4)
        Me.GbFabricante.Controls.Add(Me.celdaidFabricante)
        Me.GbFabricante.Controls.Add(Me.botonFabricante)
        Me.GbFabricante.Controls.Add(Me.celdaFabricante)
        Me.GbFabricante.Controls.Add(Me.Label5)
        Me.GbFabricante.Location = New System.Drawing.Point(452, 131)
        Me.GbFabricante.Name = "GbFabricante"
        Me.GbFabricante.Size = New System.Drawing.Size(426, 100)
        Me.GbFabricante.TabIndex = 10
        Me.GbFabricante.TabStop = False
        Me.GbFabricante.Text = "Manufacturer"
        '
        'celdaDireccionFabricante
        '
        Me.celdaDireccionFabricante.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.celdaDireccionFabricante.Enabled = False
        Me.celdaDireccionFabricante.Location = New System.Drawing.Point(80, 47)
        Me.celdaDireccionFabricante.Multiline = True
        Me.celdaDireccionFabricante.Name = "celdaDireccionFabricante"
        Me.celdaDireccionFabricante.Size = New System.Drawing.Size(313, 44)
        Me.celdaDireccionFabricante.TabIndex = 29
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(4, 53)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(45, 13)
        Me.Label4.TabIndex = 28
        Me.Label4.Text = "Address"
        '
        'celdaidFabricante
        '
        Me.celdaidFabricante.Location = New System.Drawing.Point(395, 20)
        Me.celdaidFabricante.Name = "celdaidFabricante"
        Me.celdaidFabricante.Size = New System.Drawing.Size(27, 20)
        Me.celdaidFabricante.TabIndex = 27
        Me.celdaidFabricante.Text = "-1"
        Me.celdaidFabricante.Visible = False
        '
        'botonFabricante
        '
        Me.botonFabricante.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.botonFabricante.Location = New System.Drawing.Point(363, 18)
        Me.botonFabricante.Name = "botonFabricante"
        Me.botonFabricante.Size = New System.Drawing.Size(30, 23)
        Me.botonFabricante.TabIndex = 26
        Me.botonFabricante.Text = "..."
        Me.botonFabricante.UseVisualStyleBackColor = True
        '
        'celdaFabricante
        '
        Me.celdaFabricante.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.celdaFabricante.Enabled = False
        Me.celdaFabricante.Location = New System.Drawing.Point(80, 22)
        Me.celdaFabricante.Name = "celdaFabricante"
        Me.celdaFabricante.Size = New System.Drawing.Size(277, 20)
        Me.celdaFabricante.TabIndex = 25
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(4, 22)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(70, 13)
        Me.Label5.TabIndex = 24
        Me.Label5.Text = "Manufacturer"
        '
        'GbProveedor
        '
        Me.GbProveedor.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.GbProveedor.Controls.Add(Me.celdaDireccionProveedor)
        Me.GbProveedor.Controls.Add(Me.Label3)
        Me.GbProveedor.Controls.Add(Me.celdaidProveedor)
        Me.GbProveedor.Controls.Add(Me.botonProveedor)
        Me.GbProveedor.Controls.Add(Me.celdaProveedor)
        Me.GbProveedor.Controls.Add(Me.Label2)
        Me.GbProveedor.Location = New System.Drawing.Point(452, 22)
        Me.GbProveedor.Name = "GbProveedor"
        Me.GbProveedor.Size = New System.Drawing.Size(426, 100)
        Me.GbProveedor.TabIndex = 9
        Me.GbProveedor.TabStop = False
        Me.GbProveedor.Text = "Provider"
        '
        'celdaDireccionProveedor
        '
        Me.celdaDireccionProveedor.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.celdaDireccionProveedor.Enabled = False
        Me.celdaDireccionProveedor.Location = New System.Drawing.Point(60, 50)
        Me.celdaDireccionProveedor.Multiline = True
        Me.celdaDireccionProveedor.Name = "celdaDireccionProveedor"
        Me.celdaDireccionProveedor.Size = New System.Drawing.Size(323, 44)
        Me.celdaDireccionProveedor.TabIndex = 29
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(4, 53)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(45, 13)
        Me.Label3.TabIndex = 28
        Me.Label3.Text = "Address"
        '
        'celdaidProveedor
        '
        Me.celdaidProveedor.Location = New System.Drawing.Point(395, 20)
        Me.celdaidProveedor.Name = "celdaidProveedor"
        Me.celdaidProveedor.Size = New System.Drawing.Size(27, 20)
        Me.celdaidProveedor.TabIndex = 27
        Me.celdaidProveedor.Text = "-1"
        Me.celdaidProveedor.Visible = False
        '
        'botonProveedor
        '
        Me.botonProveedor.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.botonProveedor.Location = New System.Drawing.Point(353, 17)
        Me.botonProveedor.Name = "botonProveedor"
        Me.botonProveedor.Size = New System.Drawing.Size(30, 23)
        Me.botonProveedor.TabIndex = 26
        Me.botonProveedor.Text = "..."
        Me.botonProveedor.UseVisualStyleBackColor = True
        '
        'celdaProveedor
        '
        Me.celdaProveedor.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.celdaProveedor.Enabled = False
        Me.celdaProveedor.Location = New System.Drawing.Point(60, 19)
        Me.celdaProveedor.Name = "celdaProveedor"
        Me.celdaProveedor.Size = New System.Drawing.Size(287, 20)
        Me.celdaProveedor.TabIndex = 25
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(4, 22)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(46, 13)
        Me.Label2.TabIndex = 24
        Me.Label2.Text = "Provider"
        '
        'panelDetalle
        '
        Me.panelDetalle.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.panelDetalle.Controls.Add(Me.Panel1)
        Me.panelDetalle.Controls.Add(Me.panelBotones)
        Me.panelDetalle.Location = New System.Drawing.Point(12, 287)
        Me.panelDetalle.Name = "panelDetalle"
        Me.panelDetalle.Size = New System.Drawing.Size(866, 45)
        Me.panelDetalle.TabIndex = 8
        '
        'Panel1
        '
        Me.Panel1.Controls.Add(Me.dgDetalle)
        Me.Panel1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Panel1.Location = New System.Drawing.Point(0, 0)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(816, 45)
        Me.Panel1.TabIndex = 4
        '
        'dgDetalle
        '
        Me.dgDetalle.AllowUserToAddRows = False
        Me.dgDetalle.AllowUserToDeleteRows = False
        Me.dgDetalle.BackgroundColor = System.Drawing.SystemColors.Control
        Me.dgDetalle.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgDetalle.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.colCatalogo, Me.colYear, Me.colCodigo, Me.colDescripcion, Me.colNumMedida, Me.colMedida, Me.colOrigen, Me.colPrecio, Me.colFecha, Me.colCantidad, Me.colTotal, Me.colLineaDet, Me.colDescargos, Me.colFechaInicio, Me.colAgrega, Me.colObservacion})
        Me.dgDetalle.Dock = System.Windows.Forms.DockStyle.Fill
        Me.dgDetalle.Location = New System.Drawing.Point(0, 0)
        Me.dgDetalle.Name = "dgDetalle"
        Me.dgDetalle.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.dgDetalle.Size = New System.Drawing.Size(816, 45)
        Me.dgDetalle.TabIndex = 6
        '
        'colCatalogo
        '
        Me.colCatalogo.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.colCatalogo.HeaderText = "Catalogo"
        Me.colCatalogo.Name = "colCatalogo"
        Me.colCatalogo.Visible = False
        Me.colCatalogo.Width = 74
        '
        'colYear
        '
        Me.colYear.HeaderText = "Año"
        Me.colYear.Name = "colYear"
        Me.colYear.Visible = False
        '
        'colCodigo
        '
        Me.colCodigo.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.colCodigo.HeaderText = "Code*"
        Me.colCodigo.Name = "colCodigo"
        Me.colCodigo.ReadOnly = True
        Me.colCodigo.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        Me.colCodigo.Width = 42
        '
        'colDescripcion
        '
        Me.colDescripcion.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.colDescripcion.HeaderText = "Description"
        Me.colDescripcion.Name = "colDescripcion"
        Me.colDescripcion.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        Me.colDescripcion.Width = 66
        '
        'colNumMedida
        '
        Me.colNumMedida.HeaderText = "NumMedida"
        Me.colNumMedida.Name = "colNumMedida"
        Me.colNumMedida.Visible = False
        '
        'colMedida
        '
        Me.colMedida.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.colMedida.HeaderText = "Measure"
        Me.colMedida.Name = "colMedida"
        Me.colMedida.ReadOnly = True
        Me.colMedida.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        Me.colMedida.Width = 54
        '
        'colOrigen
        '
        Me.colOrigen.HeaderText = "Origin"
        Me.colOrigen.Name = "colOrigen"
        Me.colOrigen.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        '
        'colPrecio
        '
        Me.colPrecio.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.colPrecio.HeaderText = "Price"
        Me.colPrecio.Name = "colPrecio"
        Me.colPrecio.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        Me.colPrecio.Width = 37
        '
        'colFecha
        '
        Me.colFecha.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.colFecha.HeaderText = "Date"
        Me.colFecha.Name = "colFecha"
        Me.colFecha.Visible = False
        Me.colFecha.Width = 55
        '
        'colCantidad
        '
        Me.colCantidad.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.colCantidad.HeaderText = "Qty Required "
        Me.colCantidad.Name = "colCantidad"
        Me.colCantidad.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        Me.colCantidad.Width = 78
        '
        'colTotal
        '
        Me.colTotal.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.colTotal.HeaderText = "Total"
        Me.colTotal.Name = "colTotal"
        Me.colTotal.ReadOnly = True
        Me.colTotal.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        Me.colTotal.Width = 37
        '
        'colLineaDet
        '
        Me.colLineaDet.HeaderText = "Line"
        Me.colLineaDet.Name = "colLineaDet"
        Me.colLineaDet.ReadOnly = True
        Me.colLineaDet.Visible = False
        '
        'colDescargos
        '
        Me.colDescargos.HeaderText = "Descargos"
        Me.colDescargos.Name = "colDescargos"
        Me.colDescargos.Visible = False
        '
        'colFechaInicio
        '
        Me.colFechaInicio.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        DataGridViewCellStyle1.Format = "d"
        DataGridViewCellStyle1.NullValue = Nothing
        DataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.colFechaInicio.DefaultCellStyle = DataGridViewCellStyle1
        Me.colFechaInicio.HeaderText = "ETD"
        Me.colFechaInicio.Name = "colFechaInicio"
        Me.colFechaInicio.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        Me.colFechaInicio.Width = 35
        '
        'colAgrega
        '
        Me.colAgrega.HeaderText = "Agregar"
        Me.colAgrega.Name = "colAgrega"
        Me.colAgrega.Visible = False
        '
        'colObservacion
        '
        Me.colObservacion.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.colObservacion.HeaderText = "Observation"
        Me.colObservacion.Name = "colObservacion"
        Me.colObservacion.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        Me.colObservacion.Width = 70
        '
        'panelBotones
        '
        Me.panelBotones.Controls.Add(Me.botonDelete)
        Me.panelBotones.Controls.Add(Me.botonAdd)
        Me.panelBotones.Dock = System.Windows.Forms.DockStyle.Right
        Me.panelBotones.Location = New System.Drawing.Point(816, 0)
        Me.panelBotones.Name = "panelBotones"
        Me.panelBotones.Size = New System.Drawing.Size(50, 45)
        Me.panelBotones.TabIndex = 3
        '
        'botonDelete
        '
        Me.botonDelete.Image = Global.KARIMs_SGI.My.Resources.Resources.delete3
        Me.botonDelete.Location = New System.Drawing.Point(5, 48)
        Me.botonDelete.Name = "botonDelete"
        Me.botonDelete.Size = New System.Drawing.Size(30, 23)
        Me.botonDelete.TabIndex = 1
        Me.botonDelete.UseVisualStyleBackColor = True
        '
        'botonAdd
        '
        Me.botonAdd.Image = Global.KARIMs_SGI.My.Resources.Resources.add
        Me.botonAdd.Location = New System.Drawing.Point(5, 15)
        Me.botonAdd.Name = "botonAdd"
        Me.botonAdd.Size = New System.Drawing.Size(30, 23)
        Me.botonAdd.TabIndex = 0
        Me.botonAdd.UseVisualStyleBackColor = True
        '
        'gbDatosPedido
        '
        Me.gbDatosPedido.Controls.Add(Me.celdaCredit)
        Me.gbDatosPedido.Controls.Add(Me.Label1)
        Me.gbDatosPedido.Controls.Add(Me.celdaDescripcionP)
        Me.gbDatosPedido.Controls.Add(Me.celdaProyecto)
        Me.gbDatosPedido.Controls.Add(Me.celdaDescripcion)
        Me.gbDatosPedido.Controls.Add(Me.celdaidflujodetalle)
        Me.gbDatosPedido.Controls.Add(Me.celdaidTarea)
        Me.gbDatosPedido.Controls.Add(Me.celdaidProyecto)
        Me.gbDatosPedido.Controls.Add(Me.etiquetaAnulada)
        Me.gbDatosPedido.Controls.Add(Me.celdaComentario)
        Me.gbDatosPedido.Controls.Add(Me.celdaNumeroReq)
        Me.gbDatosPedido.Controls.Add(Me.etiquetaNumber)
        Me.gbDatosPedido.Controls.Add(Me.etiquetaImpuestos)
        Me.gbDatosPedido.Controls.Add(Me.celdaImpuestos)
        Me.gbDatosPedido.Controls.Add(Me.etiquetaRevisado)
        Me.gbDatosPedido.Controls.Add(Me.celdaRevisado)
        Me.gbDatosPedido.Controls.Add(Me.celdaUsuario)
        Me.gbDatosPedido.Controls.Add(Me.celdaCatalogo)
        Me.gbDatosPedido.Controls.Add(Me.celdaEmpresa)
        Me.gbDatosPedido.Controls.Add(Me.etiquetaUsuario)
        Me.gbDatosPedido.Controls.Add(Me.etiquetaCatalogo)
        Me.gbDatosPedido.Controls.Add(Me.etiquetaEmpresa)
        Me.gbDatosPedido.Controls.Add(Me.celdaCode)
        Me.gbDatosPedido.Controls.Add(Me.dtpFecha1)
        Me.gbDatosPedido.Controls.Add(Me.celdaIDMoneda)
        Me.gbDatosPedido.Controls.Add(Me.botonMoneda)
        Me.gbDatosPedido.Controls.Add(Me.celdaIDCliente)
        Me.gbDatosPedido.Controls.Add(Me.BotonCliente)
        Me.gbDatosPedido.Controls.Add(Me.celdaTC)
        Me.gbDatosPedido.Controls.Add(Me.etiquetaTasa)
        Me.gbDatosPedido.Controls.Add(Me.celdaNit)
        Me.gbDatosPedido.Controls.Add(Me.etiquetaNIT)
        Me.gbDatosPedido.Controls.Add(Me.checkActivo)
        Me.gbDatosPedido.Controls.Add(Me.celdaCliente)
        Me.gbDatosPedido.Controls.Add(Me.celdaMoneda)
        Me.gbDatosPedido.Controls.Add(Me.celdaDireccion)
        Me.gbDatosPedido.Controls.Add(Me.celdaNumero)
        Me.gbDatosPedido.Controls.Add(Me.celdaAño)
        Me.gbDatosPedido.Controls.Add(Me.etiquetaMoneda)
        Me.gbDatosPedido.Controls.Add(Me.etiquetaDireccion)
        Me.gbDatosPedido.Controls.Add(Me.etiquetaCliente)
        Me.gbDatosPedido.Controls.Add(Me.etiquetaFecha)
        Me.gbDatosPedido.Controls.Add(Me.etiquetaNumero)
        Me.gbDatosPedido.Controls.Add(Me.etiquetaAño)
        Me.gbDatosPedido.Location = New System.Drawing.Point(12, 12)
        Me.gbDatosPedido.Name = "gbDatosPedido"
        Me.gbDatosPedido.Size = New System.Drawing.Size(434, 269)
        Me.gbDatosPedido.TabIndex = 4
        Me.gbDatosPedido.TabStop = False
        Me.gbDatosPedido.Text = "Invoice  Information"
        '
        'celdaCredit
        '
        Me.celdaCredit.Location = New System.Drawing.Point(250, 68)
        Me.celdaCredit.Name = "celdaCredit"
        Me.celdaCredit.Size = New System.Drawing.Size(175, 20)
        Me.celdaCredit.TabIndex = 61
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(170, 71)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(61, 13)
        Me.Label1.TabIndex = 60
        Me.Label1.Text = "Term Credit"
        '
        'celdaDescripcionP
        '
        Me.celdaDescripcionP.Location = New System.Drawing.Point(310, 238)
        Me.celdaDescripcionP.Margin = New System.Windows.Forms.Padding(2)
        Me.celdaDescripcionP.Name = "celdaDescripcionP"
        Me.celdaDescripcionP.Size = New System.Drawing.Size(8, 20)
        Me.celdaDescripcionP.TabIndex = 59
        Me.celdaDescripcionP.Visible = False
        Me.celdaDescripcionP.WordWrap = False
        '
        'celdaProyecto
        '
        Me.celdaProyecto.Location = New System.Drawing.Point(298, 238)
        Me.celdaProyecto.Margin = New System.Windows.Forms.Padding(2)
        Me.celdaProyecto.Name = "celdaProyecto"
        Me.celdaProyecto.Size = New System.Drawing.Size(8, 20)
        Me.celdaProyecto.TabIndex = 58
        Me.celdaProyecto.Visible = False
        Me.celdaProyecto.WordWrap = False
        '
        'celdaDescripcion
        '
        Me.celdaDescripcion.Location = New System.Drawing.Point(286, 238)
        Me.celdaDescripcion.Margin = New System.Windows.Forms.Padding(2)
        Me.celdaDescripcion.Name = "celdaDescripcion"
        Me.celdaDescripcion.Size = New System.Drawing.Size(8, 20)
        Me.celdaDescripcion.TabIndex = 57
        Me.celdaDescripcion.Visible = False
        Me.celdaDescripcion.WordWrap = False
        '
        'celdaidflujodetalle
        '
        Me.celdaidflujodetalle.Location = New System.Drawing.Point(273, 238)
        Me.celdaidflujodetalle.Margin = New System.Windows.Forms.Padding(2)
        Me.celdaidflujodetalle.Name = "celdaidflujodetalle"
        Me.celdaidflujodetalle.Size = New System.Drawing.Size(8, 20)
        Me.celdaidflujodetalle.TabIndex = 56
        Me.celdaidflujodetalle.Text = "-1"
        Me.celdaidflujodetalle.Visible = False
        Me.celdaidflujodetalle.WordWrap = False
        '
        'celdaidTarea
        '
        Me.celdaidTarea.Location = New System.Drawing.Point(254, 238)
        Me.celdaidTarea.Margin = New System.Windows.Forms.Padding(2)
        Me.celdaidTarea.Name = "celdaidTarea"
        Me.celdaidTarea.Size = New System.Drawing.Size(8, 20)
        Me.celdaidTarea.TabIndex = 55
        Me.celdaidTarea.Text = "-1"
        Me.celdaidTarea.Visible = False
        Me.celdaidTarea.WordWrap = False
        '
        'celdaidProyecto
        '
        Me.celdaidProyecto.Location = New System.Drawing.Point(173, 242)
        Me.celdaidProyecto.Margin = New System.Windows.Forms.Padding(2)
        Me.celdaidProyecto.Name = "celdaidProyecto"
        Me.celdaidProyecto.ReadOnly = True
        Me.celdaidProyecto.Size = New System.Drawing.Size(35, 20)
        Me.celdaidProyecto.TabIndex = 54
        Me.celdaidProyecto.Text = "-1"
        Me.celdaidProyecto.Visible = False
        '
        'etiquetaAnulada
        '
        Me.etiquetaAnulada.AutoSize = True
        Me.etiquetaAnulada.BackColor = System.Drawing.Color.Red
        Me.etiquetaAnulada.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.etiquetaAnulada.Location = New System.Drawing.Point(153, 20)
        Me.etiquetaAnulada.Name = "etiquetaAnulada"
        Me.etiquetaAnulada.Size = New System.Drawing.Size(91, 24)
        Me.etiquetaAnulada.TabIndex = 45
        Me.etiquetaAnulada.Text = "Canceled"
        Me.etiquetaAnulada.Visible = False
        '
        'celdaComentario
        '
        Me.celdaComentario.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.celdaComentario.Location = New System.Drawing.Point(402, 196)
        Me.celdaComentario.Margin = New System.Windows.Forms.Padding(2)
        Me.celdaComentario.Name = "celdaComentario"
        Me.celdaComentario.Size = New System.Drawing.Size(27, 20)
        Me.celdaComentario.TabIndex = 44
        Me.celdaComentario.Visible = False
        '
        'celdaNumeroReq
        '
        Me.celdaNumeroReq.Location = New System.Drawing.Point(250, 45)
        Me.celdaNumeroReq.Name = "celdaNumeroReq"
        Me.celdaNumeroReq.Size = New System.Drawing.Size(175, 20)
        Me.celdaNumeroReq.TabIndex = 43
        '
        'etiquetaNumber
        '
        Me.etiquetaNumber.AutoSize = True
        Me.etiquetaNumber.Location = New System.Drawing.Point(162, 48)
        Me.etiquetaNumber.Name = "etiquetaNumber"
        Me.etiquetaNumber.Size = New System.Drawing.Size(87, 13)
        Me.etiquetaNumber.TabIndex = 42
        Me.etiquetaNumber.Text = "Contract Number"
        '
        'etiquetaImpuestos
        '
        Me.etiquetaImpuestos.AutoSize = True
        Me.etiquetaImpuestos.Location = New System.Drawing.Point(105, 244)
        Me.etiquetaImpuestos.Name = "etiquetaImpuestos"
        Me.etiquetaImpuestos.Size = New System.Drawing.Size(55, 13)
        Me.etiquetaImpuestos.TabIndex = 41
        Me.etiquetaImpuestos.Text = "Impuestos"
        Me.etiquetaImpuestos.Visible = False
        '
        'celdaImpuestos
        '
        Me.celdaImpuestos.Location = New System.Drawing.Point(60, 244)
        Me.celdaImpuestos.Name = "celdaImpuestos"
        Me.celdaImpuestos.Size = New System.Drawing.Size(27, 20)
        Me.celdaImpuestos.TabIndex = 40
        Me.celdaImpuestos.Text = "-1"
        Me.celdaImpuestos.Visible = False
        '
        'etiquetaRevisado
        '
        Me.etiquetaRevisado.AutoSize = True
        Me.etiquetaRevisado.Location = New System.Drawing.Point(334, 218)
        Me.etiquetaRevisado.Name = "etiquetaRevisado"
        Me.etiquetaRevisado.Size = New System.Drawing.Size(52, 13)
        Me.etiquetaRevisado.TabIndex = 39
        Me.etiquetaRevisado.Text = "Revisado"
        Me.etiquetaRevisado.Visible = False
        '
        'celdaRevisado
        '
        Me.celdaRevisado.Location = New System.Drawing.Point(337, 234)
        Me.celdaRevisado.Name = "celdaRevisado"
        Me.celdaRevisado.Size = New System.Drawing.Size(27, 20)
        Me.celdaRevisado.TabIndex = 38
        Me.celdaRevisado.Text = "0"
        Me.celdaRevisado.Visible = False
        '
        'celdaUsuario
        '
        Me.celdaUsuario.Location = New System.Drawing.Point(222, 223)
        Me.celdaUsuario.Name = "celdaUsuario"
        Me.celdaUsuario.Size = New System.Drawing.Size(27, 20)
        Me.celdaUsuario.TabIndex = 36
        Me.celdaUsuario.Text = "-1"
        Me.celdaUsuario.Visible = False
        '
        'celdaCatalogo
        '
        Me.celdaCatalogo.Location = New System.Drawing.Point(90, 218)
        Me.celdaCatalogo.Name = "celdaCatalogo"
        Me.celdaCatalogo.Size = New System.Drawing.Size(27, 20)
        Me.celdaCatalogo.TabIndex = 35
        Me.celdaCatalogo.Text = "-1"
        Me.celdaCatalogo.Visible = False
        '
        'celdaEmpresa
        '
        Me.celdaEmpresa.Location = New System.Drawing.Point(61, 218)
        Me.celdaEmpresa.Name = "celdaEmpresa"
        Me.celdaEmpresa.Size = New System.Drawing.Size(27, 20)
        Me.celdaEmpresa.TabIndex = 34
        Me.celdaEmpresa.Text = "-1"
        Me.celdaEmpresa.Visible = False
        '
        'etiquetaUsuario
        '
        Me.etiquetaUsuario.AutoSize = True
        Me.etiquetaUsuario.Location = New System.Drawing.Point(178, 225)
        Me.etiquetaUsuario.Name = "etiquetaUsuario"
        Me.etiquetaUsuario.Size = New System.Drawing.Size(43, 13)
        Me.etiquetaUsuario.TabIndex = 33
        Me.etiquetaUsuario.Text = "Usuario"
        Me.etiquetaUsuario.Visible = False
        '
        'etiquetaCatalogo
        '
        Me.etiquetaCatalogo.AutoSize = True
        Me.etiquetaCatalogo.Location = New System.Drawing.Point(5, 245)
        Me.etiquetaCatalogo.Name = "etiquetaCatalogo"
        Me.etiquetaCatalogo.Size = New System.Drawing.Size(49, 13)
        Me.etiquetaCatalogo.TabIndex = 32
        Me.etiquetaCatalogo.Text = "Catalogo"
        Me.etiquetaCatalogo.Visible = False
        '
        'etiquetaEmpresa
        '
        Me.etiquetaEmpresa.AutoSize = True
        Me.etiquetaEmpresa.Location = New System.Drawing.Point(2, 223)
        Me.etiquetaEmpresa.Name = "etiquetaEmpresa"
        Me.etiquetaEmpresa.Size = New System.Drawing.Size(48, 13)
        Me.etiquetaEmpresa.TabIndex = 31
        Me.etiquetaEmpresa.Text = "Empresa"
        Me.etiquetaEmpresa.Visible = False
        '
        'celdaCode
        '
        Me.celdaCode.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.celdaCode.Location = New System.Drawing.Point(403, 15)
        Me.celdaCode.Margin = New System.Windows.Forms.Padding(2)
        Me.celdaCode.Name = "celdaCode"
        Me.celdaCode.Size = New System.Drawing.Size(27, 20)
        Me.celdaCode.TabIndex = 30
        Me.celdaCode.Visible = False
        '
        'dtpFecha1
        '
        Me.dtpFecha1.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.dtpFecha1.Location = New System.Drawing.Point(62, 68)
        Me.dtpFecha1.Name = "dtpFecha1"
        Me.dtpFecha1.Size = New System.Drawing.Size(98, 20)
        Me.dtpFecha1.TabIndex = 29
        '
        'celdaIDMoneda
        '
        Me.celdaIDMoneda.Location = New System.Drawing.Point(173, 195)
        Me.celdaIDMoneda.Name = "celdaIDMoneda"
        Me.celdaIDMoneda.Size = New System.Drawing.Size(27, 20)
        Me.celdaIDMoneda.TabIndex = 25
        Me.celdaIDMoneda.Text = "-1"
        Me.celdaIDMoneda.Visible = False
        '
        'botonMoneda
        '
        Me.botonMoneda.Location = New System.Drawing.Point(138, 193)
        Me.botonMoneda.Name = "botonMoneda"
        Me.botonMoneda.Size = New System.Drawing.Size(30, 23)
        Me.botonMoneda.TabIndex = 24
        Me.botonMoneda.Text = "..."
        Me.botonMoneda.UseVisualStyleBackColor = True
        '
        'celdaIDCliente
        '
        Me.celdaIDCliente.Location = New System.Drawing.Point(397, 95)
        Me.celdaIDCliente.Name = "celdaIDCliente"
        Me.celdaIDCliente.Size = New System.Drawing.Size(27, 20)
        Me.celdaIDCliente.TabIndex = 23
        Me.celdaIDCliente.Text = "-1"
        Me.celdaIDCliente.Visible = False
        '
        'BotonCliente
        '
        Me.BotonCliente.Location = New System.Drawing.Point(355, 92)
        Me.BotonCliente.Name = "BotonCliente"
        Me.BotonCliente.Size = New System.Drawing.Size(30, 23)
        Me.BotonCliente.TabIndex = 22
        Me.BotonCliente.Text = "..."
        Me.BotonCliente.UseVisualStyleBackColor = True
        '
        'celdaTC
        '
        Me.celdaTC.Location = New System.Drawing.Point(257, 199)
        Me.celdaTC.Name = "celdaTC"
        Me.celdaTC.Size = New System.Drawing.Size(71, 20)
        Me.celdaTC.TabIndex = 19
        '
        'etiquetaTasa
        '
        Me.etiquetaTasa.AutoSize = True
        Me.etiquetaTasa.Location = New System.Drawing.Point(227, 202)
        Me.etiquetaTasa.Name = "etiquetaTasa"
        Me.etiquetaTasa.Size = New System.Drawing.Size(30, 13)
        Me.etiquetaTasa.TabIndex = 18
        Me.etiquetaTasa.Text = "Rate"
        '
        'celdaNit
        '
        Me.celdaNit.Enabled = False
        Me.celdaNit.Location = New System.Drawing.Point(61, 169)
        Me.celdaNit.Name = "celdaNit"
        Me.celdaNit.Size = New System.Drawing.Size(129, 20)
        Me.celdaNit.TabIndex = 17
        '
        'etiquetaNIT
        '
        Me.etiquetaNIT.AutoSize = True
        Me.etiquetaNIT.Location = New System.Drawing.Point(11, 171)
        Me.etiquetaNIT.Name = "etiquetaNIT"
        Me.etiquetaNIT.Size = New System.Drawing.Size(25, 13)
        Me.etiquetaNIT.TabIndex = 16
        Me.etiquetaNIT.Text = "NIT"
        '
        'checkActivo
        '
        Me.checkActivo.AutoSize = True
        Me.checkActivo.Checked = True
        Me.checkActivo.CheckState = System.Windows.Forms.CheckState.Checked
        Me.checkActivo.Location = New System.Drawing.Point(282, 27)
        Me.checkActivo.Name = "checkActivo"
        Me.checkActivo.Size = New System.Drawing.Size(56, 17)
        Me.checkActivo.TabIndex = 15
        Me.checkActivo.Text = "Active"
        Me.checkActivo.UseVisualStyleBackColor = True
        '
        'celdaCliente
        '
        Me.celdaCliente.Enabled = False
        Me.celdaCliente.Location = New System.Drawing.Point(62, 94)
        Me.celdaCliente.Name = "celdaCliente"
        Me.celdaCliente.Size = New System.Drawing.Size(287, 20)
        Me.celdaCliente.TabIndex = 14
        '
        'celdaMoneda
        '
        Me.celdaMoneda.Location = New System.Drawing.Point(61, 195)
        Me.celdaMoneda.Name = "celdaMoneda"
        Me.celdaMoneda.Size = New System.Drawing.Size(71, 20)
        Me.celdaMoneda.TabIndex = 12
        '
        'celdaDireccion
        '
        Me.celdaDireccion.Enabled = False
        Me.celdaDireccion.Location = New System.Drawing.Point(62, 116)
        Me.celdaDireccion.Multiline = True
        Me.celdaDireccion.Name = "celdaDireccion"
        Me.celdaDireccion.Size = New System.Drawing.Size(323, 44)
        Me.celdaDireccion.TabIndex = 10
        '
        'celdaNumero
        '
        Me.celdaNumero.Enabled = False
        Me.celdaNumero.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.celdaNumero.ForeColor = System.Drawing.Color.SteelBlue
        Me.celdaNumero.Location = New System.Drawing.Point(62, 46)
        Me.celdaNumero.Name = "celdaNumero"
        Me.celdaNumero.Size = New System.Drawing.Size(71, 20)
        Me.celdaNumero.TabIndex = 9
        '
        'celdaAño
        '
        Me.celdaAño.Enabled = False
        Me.celdaAño.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.celdaAño.ForeColor = System.Drawing.Color.SteelBlue
        Me.celdaAño.Location = New System.Drawing.Point(62, 24)
        Me.celdaAño.Name = "celdaAño"
        Me.celdaAño.Size = New System.Drawing.Size(71, 20)
        Me.celdaAño.TabIndex = 8
        Me.celdaAño.Text = "2016"
        '
        'etiquetaMoneda
        '
        Me.etiquetaMoneda.AutoSize = True
        Me.etiquetaMoneda.Location = New System.Drawing.Point(6, 195)
        Me.etiquetaMoneda.Name = "etiquetaMoneda"
        Me.etiquetaMoneda.Size = New System.Drawing.Size(49, 13)
        Me.etiquetaMoneda.TabIndex = 7
        Me.etiquetaMoneda.Text = "Currency"
        '
        'etiquetaDireccion
        '
        Me.etiquetaDireccion.AutoSize = True
        Me.etiquetaDireccion.Location = New System.Drawing.Point(6, 119)
        Me.etiquetaDireccion.Name = "etiquetaDireccion"
        Me.etiquetaDireccion.Size = New System.Drawing.Size(45, 13)
        Me.etiquetaDireccion.TabIndex = 4
        Me.etiquetaDireccion.Text = "Address"
        '
        'etiquetaCliente
        '
        Me.etiquetaCliente.AutoSize = True
        Me.etiquetaCliente.Location = New System.Drawing.Point(6, 97)
        Me.etiquetaCliente.Name = "etiquetaCliente"
        Me.etiquetaCliente.Size = New System.Drawing.Size(51, 13)
        Me.etiquetaCliente.TabIndex = 3
        Me.etiquetaCliente.Text = "Customer"
        '
        'etiquetaFecha
        '
        Me.etiquetaFecha.AutoSize = True
        Me.etiquetaFecha.Location = New System.Drawing.Point(6, 71)
        Me.etiquetaFecha.Name = "etiquetaFecha"
        Me.etiquetaFecha.Size = New System.Drawing.Size(30, 13)
        Me.etiquetaFecha.TabIndex = 2
        Me.etiquetaFecha.Text = "Date"
        '
        'etiquetaNumero
        '
        Me.etiquetaNumero.AutoSize = True
        Me.etiquetaNumero.Location = New System.Drawing.Point(6, 49)
        Me.etiquetaNumero.Name = "etiquetaNumero"
        Me.etiquetaNumero.Size = New System.Drawing.Size(44, 13)
        Me.etiquetaNumero.TabIndex = 1
        Me.etiquetaNumero.Text = "Number"
        '
        'etiquetaAño
        '
        Me.etiquetaAño.AutoSize = True
        Me.etiquetaAño.Location = New System.Drawing.Point(6, 27)
        Me.etiquetaAño.Name = "etiquetaAño"
        Me.etiquetaAño.Size = New System.Drawing.Size(29, 13)
        Me.etiquetaAño.TabIndex = 0
        Me.etiquetaAño.Text = "Year"
        '
        'BarraTitulo1
        '
        Me.BarraTitulo1.BackColor = System.Drawing.Color.WhiteSmoke
        Me.BarraTitulo1.Dock = System.Windows.Forms.DockStyle.Top
        Me.BarraTitulo1.Location = New System.Drawing.Point(0, 72)
        Me.BarraTitulo1.Name = "BarraTitulo1"
        Me.BarraTitulo1.Size = New System.Drawing.Size(940, 30)
        Me.BarraTitulo1.TabIndex = 1
        '
        'Encabezado1
        '
        Me.Encabezado1.Dock = System.Windows.Forms.DockStyle.Top
        Me.Encabezado1.Location = New System.Drawing.Point(0, 0)
        Me.Encabezado1.Name = "Encabezado1"
        Me.Encabezado1.Size = New System.Drawing.Size(940, 72)
        Me.Encabezado1.TabIndex = 0
        '
        'etiquetaTotales
        '
        Me.etiquetaTotales.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.etiquetaTotales.AutoSize = True
        Me.etiquetaTotales.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.etiquetaTotales.Location = New System.Drawing.Point(554, 10)
        Me.etiquetaTotales.Name = "etiquetaTotales"
        Me.etiquetaTotales.Size = New System.Drawing.Size(47, 17)
        Me.etiquetaTotales.TabIndex = 12
        Me.etiquetaTotales.Text = "Totals"
        '
        'celdaTotales
        '
        Me.celdaTotales.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.celdaTotales.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.celdaTotales.Location = New System.Drawing.Point(606, 7)
        Me.celdaTotales.Multiline = True
        Me.celdaTotales.Name = "celdaTotales"
        Me.celdaTotales.ReadOnly = True
        Me.celdaTotales.Size = New System.Drawing.Size(93, 30)
        Me.celdaTotales.TabIndex = 13
        Me.celdaTotales.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'celdaTotales2
        '
        Me.celdaTotales2.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.celdaTotales2.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.celdaTotales2.Location = New System.Drawing.Point(705, 7)
        Me.celdaTotales2.Multiline = True
        Me.celdaTotales2.Name = "celdaTotales2"
        Me.celdaTotales2.ReadOnly = True
        Me.celdaTotales2.Size = New System.Drawing.Size(92, 30)
        Me.celdaTotales2.TabIndex = 14
        Me.celdaTotales2.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'dgDetalle2
        '
        Me.dgDetalle2.AllowUserToAddRows = False
        Me.dgDetalle2.AllowUserToDeleteRows = False
        Me.dgDetalle2.AllowUserToOrderColumns = True
        Me.dgDetalle2.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.dgDetalle2.BackgroundColor = System.Drawing.SystemColors.Control
        Me.dgDetalle2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgDetalle2.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.colLinea, Me.colAño, Me.colNDespacho, Me.colCantida, Me.colSaldoActual})
        Me.dgDetalle2.Location = New System.Drawing.Point(8, 26)
        Me.dgDetalle2.MultiSelect = False
        Me.dgDetalle2.Name = "dgDetalle2"
        Me.dgDetalle2.ReadOnly = True
        Me.dgDetalle2.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.dgDetalle2.Size = New System.Drawing.Size(363, 96)
        Me.dgDetalle2.TabIndex = 15
        '
        'colSaldoActual
        '
        Me.colSaldoActual.HeaderText = "Current Balance"
        Me.colSaldoActual.Name = "colSaldoActual"
        Me.colSaldoActual.ReadOnly = True
        Me.colSaldoActual.Width = 80
        '
        'colCantida
        '
        Me.colCantida.HeaderText = "Quantity"
        Me.colCantida.Name = "colCantida"
        Me.colCantida.ReadOnly = True
        Me.colCantida.Width = 50
        '
        'colNDespacho
        '
        Me.colNDespacho.HeaderText = "No. Dispatch"
        Me.colNDespacho.Name = "colNDespacho"
        Me.colNDespacho.ReadOnly = True
        Me.colNDespacho.Width = 80
        '
        'colAño
        '
        Me.colAño.HeaderText = "Year"
        Me.colAño.Name = "colAño"
        Me.colAño.ReadOnly = True
        Me.colAño.Width = 50
        '
        'colLinea
        '
        Me.colLinea.HeaderText = "Line"
        Me.colLinea.Name = "colLinea"
        Me.colLinea.ReadOnly = True
        Me.colLinea.Width = 50
        '
        'panelAbajo
        '
        Me.panelAbajo.Controls.Add(Me.dgDetalle2)
        Me.panelAbajo.Controls.Add(Me.celdaTotales2)
        Me.panelAbajo.Controls.Add(Me.celdaTotales)
        Me.panelAbajo.Controls.Add(Me.etiquetaTotales)
        Me.panelAbajo.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.panelAbajo.Location = New System.Drawing.Point(0, 331)
        Me.panelAbajo.Name = "panelAbajo"
        Me.panelAbajo.Size = New System.Drawing.Size(892, 125)
        Me.panelAbajo.TabIndex = 5
        '
        'frmPedidoFibra
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(940, 692)
        Me.Controls.Add(Me.panelDocumento)
        Me.Controls.Add(Me.panelLista)
        Me.Controls.Add(Me.BarraTitulo1)
        Me.Controls.Add(Me.Encabezado1)
        Me.Name = "frmPedidoFibra"
        Me.Text = "7"
        Me.panelLista.ResumeLayout(False)
        Me.panelLista.PerformLayout()
        CType(Me.dgLista, System.ComponentModel.ISupportInitialize).EndInit()
        Me.panelDocumento.ResumeLayout(False)
        Me.GbFabricante.ResumeLayout(False)
        Me.GbFabricante.PerformLayout()
        Me.GbProveedor.ResumeLayout(False)
        Me.GbProveedor.PerformLayout()
        Me.panelDetalle.ResumeLayout(False)
        Me.Panel1.ResumeLayout(False)
        CType(Me.dgDetalle, System.ComponentModel.ISupportInitialize).EndInit()
        Me.panelBotones.ResumeLayout(False)
        Me.gbDatosPedido.ResumeLayout(False)
        Me.gbDatosPedido.PerformLayout()
        CType(Me.dgDetalle2, System.ComponentModel.ISupportInitialize).EndInit()
        Me.panelAbajo.ResumeLayout(False)
        Me.panelAbajo.PerformLayout()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents Encabezado1 As encabezado
    Friend WithEvents BarraTitulo1 As BarraTitulo
    Friend WithEvents panelLista As Panel
    Friend WithEvents Checkfecha As System.Windows.Forms.CheckBox
    Friend WithEvents etiquetaYFecha As Label
    Friend WithEvents dtpFinal As DateTimePicker
    Friend WithEvents dtpInicio As DateTimePicker
    Friend WithEvents botonActualizar As Button
    Friend WithEvents dgLista As DataGridView
    Friend WithEvents TextBox8 As TextBox
    Friend WithEvents panelDocumento As Panel
    Friend WithEvents gbDatosPedido As GroupBox
    Friend WithEvents celdaDescripcionP As TextBox
    Friend WithEvents celdaProyecto As TextBox
    Friend WithEvents celdaDescripcion As TextBox
    Friend WithEvents celdaidflujodetalle As TextBox
    Friend WithEvents celdaidTarea As TextBox
    Friend WithEvents celdaidProyecto As TextBox
    Friend WithEvents etiquetaAnulada As Label
    Friend WithEvents celdaComentario As TextBox
    Friend WithEvents celdaNumeroReq As TextBox
    Friend WithEvents etiquetaNumber As Label
    Friend WithEvents etiquetaImpuestos As Label
    Friend WithEvents celdaImpuestos As TextBox
    Friend WithEvents etiquetaRevisado As Label
    Friend WithEvents celdaRevisado As TextBox
    Friend WithEvents celdaUsuario As TextBox
    Friend WithEvents celdaCatalogo As TextBox
    Friend WithEvents celdaEmpresa As TextBox
    Friend WithEvents etiquetaUsuario As Label
    Friend WithEvents etiquetaCatalogo As Label
    Friend WithEvents etiquetaEmpresa As Label
    Friend WithEvents celdaCode As TextBox
    Friend WithEvents dtpFecha1 As DateTimePicker
    Friend WithEvents celdaIDMoneda As TextBox
    Friend WithEvents botonMoneda As Button
    Friend WithEvents celdaIDCliente As TextBox
    Friend WithEvents BotonCliente As Button
    Friend WithEvents celdaTC As TextBox
    Friend WithEvents etiquetaTasa As Label
    Friend WithEvents celdaNit As TextBox
    Friend WithEvents etiquetaNIT As Label
    Friend WithEvents checkActivo As System.Windows.Forms.CheckBox
    Friend WithEvents celdaCliente As TextBox
    Friend WithEvents celdaMoneda As TextBox
    Friend WithEvents celdaDireccion As TextBox
    Friend WithEvents celdaNumero As TextBox
    Friend WithEvents celdaAño As TextBox
    Friend WithEvents etiquetaMoneda As Label
    Friend WithEvents etiquetaDireccion As Label
    Friend WithEvents etiquetaCliente As Label
    Friend WithEvents etiquetaFecha As Label
    Friend WithEvents etiquetaNumero As Label
    Friend WithEvents etiquetaAño As Label
    Friend WithEvents celdaCredit As TextBox
    Friend WithEvents Label1 As Label
    Friend WithEvents panelDetalle As Panel
    Friend WithEvents Panel1 As Panel
    Friend WithEvents dgDetalle As DataGridView
    Friend WithEvents panelBotones As Panel
    Friend WithEvents botonDelete As Button
    Friend WithEvents botonAdd As Button
    Friend WithEvents colNumero As DataGridViewTextBoxColumn
    Friend WithEvents colFechaLista As DataGridViewTextBoxColumn
    Friend WithEvents colClienteLista As DataGridViewTextBoxColumn
    Friend WithEvents colReferenciaLista As DataGridViewTextBoxColumn
    Friend WithEvents colDireccionLista As DataGridViewTextBoxColumn
    Friend WithEvents colAñoLista As DataGridViewTextBoxColumn
    Friend WithEvents colRevisado As DataGridViewTextBoxColumn
    Friend WithEvents GbFabricante As GroupBox
    Friend WithEvents celdaDireccionFabricante As TextBox
    Friend WithEvents Label4 As Label
    Friend WithEvents celdaidFabricante As TextBox
    Friend WithEvents botonFabricante As Button
    Friend WithEvents celdaFabricante As TextBox
    Friend WithEvents Label5 As Label
    Friend WithEvents GbProveedor As GroupBox
    Friend WithEvents celdaDireccionProveedor As TextBox
    Friend WithEvents Label3 As Label
    Friend WithEvents celdaidProveedor As TextBox
    Friend WithEvents botonProveedor As Button
    Friend WithEvents celdaProveedor As TextBox
    Friend WithEvents Label2 As Label
    Friend WithEvents colCatalogo As DataGridViewTextBoxColumn
    Friend WithEvents colYear As DataGridViewTextBoxColumn
    Friend WithEvents colCodigo As DataGridViewTextBoxColumn
    Friend WithEvents colDescripcion As DataGridViewTextBoxColumn
    Friend WithEvents colNumMedida As DataGridViewTextBoxColumn
    Friend WithEvents colMedida As DataGridViewTextBoxColumn
    Friend WithEvents colOrigen As DataGridViewTextBoxColumn
    Friend WithEvents colPrecio As DataGridViewTextBoxColumn
    Friend WithEvents colFecha As DataGridViewTextBoxColumn
    Friend WithEvents colCantidad As DataGridViewTextBoxColumn
    Friend WithEvents colTotal As DataGridViewTextBoxColumn
    Friend WithEvents colLineaDet As DataGridViewTextBoxColumn
    Friend WithEvents colDescargos As DataGridViewTextBoxColumn
    Friend WithEvents colFechaInicio As DataGridViewTextBoxColumn
    Friend WithEvents colAgrega As DataGridViewTextBoxColumn
    Friend WithEvents colObservacion As DataGridViewTextBoxColumn
    Friend WithEvents panelAbajo As Panel
    Friend WithEvents dgDetalle2 As DataGridView
    Friend WithEvents colLinea As DataGridViewTextBoxColumn
    Friend WithEvents colAño As DataGridViewTextBoxColumn
    Friend WithEvents colNDespacho As DataGridViewTextBoxColumn
    Friend WithEvents colCantida As DataGridViewTextBoxColumn
    Friend WithEvents colSaldoActual As DataGridViewTextBoxColumn
    Friend WithEvents celdaTotales2 As TextBox
    Friend WithEvents celdaTotales As TextBox
    Friend WithEvents etiquetaTotales As Label
End Class
