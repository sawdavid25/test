﻿Public Class frmReporteCuentaCorrienteReferencia

#Region "Variables"
    Dim dtFechaInicial As Date
    Dim dtFechaFinal As Date
    Dim intNumeroInicial As Integer
    Dim intNumeroFinal As Integer
    Dim strReferencia As String
    Dim LogTodo As Boolean
    Dim i As Integer

    Dim intOpcion As Integer

    Private intCurDoc As Integer
    Private LogInfo As Boolean = True

#End Region

#Region "Procedimientos"

    Public ReadOnly Property FechaInicial As Date
        Get
            Return dtFechaInicial
        End Get
    End Property
    Public ReadOnly Property FechaFinal As Date
        Get
            Return dtFechaFinal
        End Get
    End Property
    Public ReadOnly Property Opciones As Integer
        Get
            Return intOpcion
        End Get
    End Property
    Public ReadOnly Property Cod_NumeroInicial As Integer
        Get
            Return intNumeroInicial
        End Get
    End Property
    Public ReadOnly Property Cod_NumeroFinal As Integer
        Get
            Return intNumeroFinal
        End Get
    End Property
    Public ReadOnly Property Cod_Referencia As String
        Get
            Return strReferencia
        End Get
    End Property
    Public ReadOnly Property Todo As Boolean
        Get
            Return LogTodo
        End Get
    End Property
#End Region

    'Instrucción SELECT para los criterios especificados
    Private Function SqlReferencias(ByVal sDato As String, ByVal Inicio As Long, ByVal Fin As Long)
        Dim strSQL As String
        strSQL = vbNullString
        strSQL = strSQL & " SELECT h.HDoc_Doc_Cat tipo, h.HDoc_Doc_Ano anio, h.HDoc_Doc_Num numero, h.HDoc_Doc_Fec fecha,"
        strSQL = strSQL & "        LEFT(COALESCE(po.ADoc_Dta_Chr,''),15) poliza,"
        strSQL = strSQL & "        LEFT(COALESCE(pd.ADoc_Dta_Chr,''),35) dua,"
        strSQL = strSQL & "        LEFT(COALESCE(pb.ADoc_Dta_Chr,''),35) bl,"
        strSQL = strSQL & "        LEFT(COALESCE(dc.ADoc_Dta_Txt,''),35) contenedor,"
        strSQL = strSQL & "        h.HDoc_DR1_Num referencia, IFNULL(CAST(di.ADoc_Dta_Chr AS SIGNED),'') correlativo"
        If LogInfo Then
            strSQL = strSQL & ", IFNULL(pr.ADoc_Dta_Chr,'N/A') regimen"
            strSQL = strSQL & ", IFNULL(pp.ADoc_Dta_Chr,'N/A') origen"
            strSQL = strSQL & ", IFNULL(pa.ADoc_Dta_Chr,'N/A') aduana"
            strSQL = strSQL & ", IFNULL(da.ADoc_Dta_Chr,'N/A') archivo"
            strSQL = strSQL & ", IFNULL(dn.ADoc_Dta_Txt,'N/A') transportista"
            strSQL = strSQL & ", IFNULL(dm.ADoc_Dta_Txt,'N/A') marchamo"
            strSQL = strSQL & ", IFNULL(ds.ADoc_Dta_Txt,'') notas"
        End If
        strSQL = strSQL & " FROM Dcmtos_HDR h"
        strSQL = strSQL & "      LEFT JOIN"
        strSQL = strSQL & "      Dcmtos_DTL_Pro e1 ON e1.PDoc_Sis_Emp = h.HDoc_Sis_Emp AND"
        strSQL = strSQL & "                           e1.PDoc_Par_Cat = 180 AND"
        strSQL = strSQL & "                           e1.PDoc_Chi_Cat = h.HDoc_Doc_Cat AND"
        strSQL = strSQL & "                           e1.PDoc_Chi_Ano = h.HDoc_Doc_Ano AND"
        strSQL = strSQL & "                           e1.PDoc_Chi_Num = h.HDoc_Doc_Num"
        strSQL = strSQL & "      INNER JOIN"
        strSQL = strSQL & "      Dcmtos_HDR p ON p.HDoc_Sis_Emp = e1.PDoc_Sis_Emp AND"
        strSQL = strSQL & "                      p.HDoc_Doc_Cat = e1.PDoc_Par_Cat AND"
        strSQL = strSQL & "                      p.HDoc_Doc_Ano = e1.PDoc_Par_Ano AND"
        strSQL = strSQL & "                      p.HDoc_Doc_Num = e1.PDoc_Par_Num"
        strSQL = strSQL & "      LEFT JOIN"
        strSQL = strSQL & "      Dcmtos_DTL_Pro e2 ON e2.PDoc_Sis_Emp = p.HDoc_Sis_Emp AND"
        strSQL = strSQL & "                           e2.PDoc_Chi_Cat = p.HDoc_Doc_Cat AND"
        strSQL = strSQL & "                           e2.PDoc_Chi_Ano = p.HDoc_Doc_Ano AND"
        strSQL = strSQL & "                           e2.PDoc_Chi_Num = p.HDoc_Doc_Num"
        strSQL = strSQL & "      INNER JOIN"
        strSQL = strSQL & "      Dcmtos_HDR d ON d.HDoc_Sis_Emp = e2.PDoc_Sis_Emp AND"
        strSQL = strSQL & "                      d.HDoc_Doc_Cat = e2.PDoc_Par_Cat AND"
        strSQL = strSQL & "                      d.HDoc_Doc_Ano = e2.PDoc_Par_Ano AND"
        strSQL = strSQL & "                      d.HDoc_Doc_Num = e2.PDoc_Par_Num"
        strSQL = strSQL & "      LEFT JOIN"
        strSQL = strSQL & "      Dcmtos_ACC po ON po.ADoc_Sis_Emp = p.HDoc_Sis_Emp AND"
        strSQL = strSQL & "                       po.ADoc_Doc_Cat = p.HDoc_Doc_Cat AND"
        strSQL = strSQL & "                       po.ADoc_Doc_Ano = p.HDoc_Doc_Ano AND"
        strSQL = strSQL & "                       po.ADoc_Doc_Num = p.HDoc_Doc_Num AND"
        strSQL = strSQL & "                       po.ADoc_Doc_Sub = 'Doc_PolImp' AND"
        strSQL = strSQL & "                       po.ADoc_Doc_Lin = '01'"      'Póliza
        strSQL = strSQL & "      LEFT JOIN"
        strSQL = strSQL & "      Dcmtos_ACC pd ON pd.ADoc_Sis_Emp = p.HDoc_Sis_Emp AND"
        strSQL = strSQL & "                       pd.ADoc_Doc_Cat = p.HDoc_Doc_Cat AND"
        strSQL = strSQL & "                       pd.ADoc_Doc_Ano = p.HDoc_Doc_Ano AND"
        strSQL = strSQL & "                       pd.ADoc_Doc_Num = p.HDoc_Doc_Num AND"
        strSQL = strSQL & "                       pd.ADoc_Doc_Sub = 'Doc_PolImp' AND"
        strSQL = strSQL & "                       pd.ADoc_Doc_Lin = '04'"      'DUA
        strSQL = strSQL & "      LEFT JOIN"
        strSQL = strSQL & "      Dcmtos_ACC pb ON pb.ADoc_Sis_Emp = p.HDoc_Sis_Emp AND"
        strSQL = strSQL & "                       pb.ADoc_Doc_Cat = p.HDoc_Doc_Cat AND"
        strSQL = strSQL & "                       pb.ADoc_Doc_Ano = p.HDoc_Doc_Ano AND"
        strSQL = strSQL & "                       pb.ADoc_Doc_Num = p.HDoc_Doc_Num AND"
        strSQL = strSQL & "                       pb.ADoc_Doc_Sub = 'Doc_PolImp' AND"
        strSQL = strSQL & "                       pb.ADoc_Doc_Lin = '16'"      'Doc. de embarque
        strSQL = strSQL & "      LEFT JOIN"
        strSQL = strSQL & "      Dcmtos_ACC dc ON dc.ADoc_Sis_Emp = d.HDoc_Sis_Emp AND"
        strSQL = strSQL & "                       dc.ADoc_Doc_Cat = d.HDoc_Doc_Cat AND"
        strSQL = strSQL & "                       dc.ADoc_Doc_Ano = d.HDoc_Doc_Ano AND"
        strSQL = strSQL & "                       dc.ADoc_Doc_Num = d.HDoc_Doc_Num AND"
        strSQL = strSQL & "                       dc.ADoc_Doc_Sub = 'Doc_PBLading' AND"
        strSQL = strSQL & "                       dc.ADoc_Doc_Lin = '04'"      'Contenedor
        strSQL = strSQL & "      LEFT JOIN"
        strSQL = strSQL & "      Dcmtos_ACC di ON di.ADoc_Sis_Emp = h.HDoc_Sis_Emp AND"
        strSQL = strSQL & "                       di.ADoc_Doc_Cat = h.HDoc_Doc_Cat AND"
        strSQL = strSQL & "                       di.ADoc_Doc_Ano = h.HDoc_Doc_Ano AND"
        strSQL = strSQL & "                       di.ADoc_Doc_Num = h.HDoc_Doc_Num AND"
        strSQL = strSQL & "                       di.ADoc_Doc_Sub = 'Doc_DIngreso' AND"
        strSQL = strSQL & "                       di.ADoc_Doc_Lin = '01'"      'Correlativo de ingreso
        If LogInfo Then
            strSQL = strSQL & "     LEFT JOIN"
            strSQL = strSQL & "     Dcmtos_ACC pr ON pr.ADoc_Sis_Emp = p.HDoc_Sis_Emp AND"
            strSQL = strSQL & "                      pr.ADoc_Doc_Cat = p.HDoc_Doc_Cat AND"
            strSQL = strSQL & "                      pr.ADoc_Doc_Ano = p.HDoc_Doc_Ano AND"
            strSQL = strSQL & "                      pr.ADoc_Doc_Num = p.HDoc_Doc_Num AND"
            strSQL = strSQL & "                      pr.ADoc_Doc_Sub = 'Doc_PolImp' AND"
            strSQL = strSQL & "                      pr.ADoc_Doc_Lin = '22'"      'Régimen
            strSQL = strSQL & "     LEFT JOIN"
            strSQL = strSQL & "     Dcmtos_ACC pp ON pp.ADoc_Sis_Emp = p.HDoc_Sis_Emp AND"
            strSQL = strSQL & "                      pp.ADoc_Doc_Cat = p.HDoc_Doc_Cat AND"
            strSQL = strSQL & "                      pp.ADoc_Doc_Ano = p.HDoc_Doc_Ano AND"
            strSQL = strSQL & "                      pp.ADoc_Doc_Num = p.HDoc_Doc_Num AND"
            strSQL = strSQL & "                      pp.ADoc_Doc_Sub = 'Doc_PolImp' AND"
            strSQL = strSQL & "                      pp.ADoc_Doc_Lin = '21'"      'País origen
            strSQL = strSQL & "     LEFT JOIN"
            strSQL = strSQL & "     Dcmtos_ACC pa ON pa.ADoc_Sis_Emp = p.HDoc_Sis_Emp AND"
            strSQL = strSQL & "                      pa.ADoc_Doc_Cat = p.HDoc_Doc_Cat AND"
            strSQL = strSQL & "                      pa.ADoc_Doc_Ano = p.HDoc_Doc_Ano AND"
            strSQL = strSQL & "                      pa.ADoc_Doc_Num = p.HDoc_Doc_Num AND"
            strSQL = strSQL & "                      pa.ADoc_Doc_Sub = 'Doc_PolImp' AND"
            strSQL = strSQL & "                      pa.ADoc_Doc_Lin = '03'"      'País origen
            strSQL = strSQL & "     LEFT JOIN"
            strSQL = strSQL & "     Dcmtos_ACC da ON da.ADoc_Sis_Emp = h.HDoc_Sis_Emp AND"
            strSQL = strSQL & "                      da.ADoc_Doc_Cat = h.HDoc_Doc_Cat AND"
            strSQL = strSQL & "                      da.ADoc_Doc_Ano = h.HDoc_Doc_Ano AND"
            strSQL = strSQL & "                      da.ADoc_Doc_Num = h.HDoc_Doc_Num AND"
            strSQL = strSQL & "                      da.ADoc_Doc_Sub = 'Doc_DIngreso' AND"
            strSQL = strSQL & "                      da.ADoc_Doc_Lin = '03'"      'Archivo (leitz)
            strSQL = strSQL & "     LEFT JOIN"
            strSQL = strSQL & "     Dcmtos_ACC ds ON ds.ADoc_Sis_Emp = h.HDoc_Sis_Emp AND"
            strSQL = strSQL & "                      ds.ADoc_Doc_Cat = h.HDoc_Doc_Cat AND"
            strSQL = strSQL & "                      ds.ADoc_Doc_Ano = h.HDoc_Doc_Ano AND"
            strSQL = strSQL & "                      ds.ADoc_Doc_Num = h.HDoc_Doc_Num AND"
            strSQL = strSQL & "                      ds.ADoc_Doc_Sub = 'Doc_DIngreso' AND"
            strSQL = strSQL & "                      ds.ADoc_Doc_Lin = '04'"      'Notas y comentarios
            strSQL = strSQL & "     LEFT JOIN"
            strSQL = strSQL & "     Dcmtos_ACC dn ON dn.ADoc_Sis_Emp = d.HDoc_Sis_Emp AND"
            strSQL = strSQL & "                      dn.ADoc_Doc_Cat = d.HDoc_Doc_Cat AND"
            strSQL = strSQL & "                      dn.ADoc_Doc_Ano = d.HDoc_Doc_Ano AND"
            strSQL = strSQL & "                      dn.ADoc_Doc_Num = d.HDoc_Doc_Num AND"
            strSQL = strSQL & "                      dn.ADoc_Doc_Sub = 'Doc_PBLading' AND"
            strSQL = strSQL & "                      dn.ADoc_Doc_Lin = '02'"      'Transportista (naviera)
            strSQL = strSQL & "     LEFT JOIN"
            strSQL = strSQL & "     Dcmtos_ACC dm ON dm.ADoc_Sis_Emp = d.HDoc_Sis_Emp AND"
            strSQL = strSQL & "                      dm.ADoc_Doc_Cat = d.HDoc_Doc_Cat AND"
            strSQL = strSQL & "                      dm.ADoc_Doc_Ano = d.HDoc_Doc_Ano AND"
            strSQL = strSQL & "                      dm.ADoc_Doc_Num = d.HDoc_Doc_Num AND"
            strSQL = strSQL & "                      dm.ADoc_Doc_Sub = 'Doc_PBLading' AND"
            strSQL = strSQL & "                      dm.ADoc_Doc_Lin = '06'"      'Marchamo
        End If
        strSQL = strSQL & " WHERE h.HDoc_Sis_Emp = " & Sesion.IdEmpresa & " AND h.HDoc_Doc_Cat = " & intCurDoc
        If Not (sDato = vbNullString) Then
            If InStr(1, sDato, "*") > vbEmpty Then
                strSQL = strSQL & " AND h.HDoc_DR1_Num LIKE " & Replace(sDato, "*", "%")
            Else
                'sDato = "'" & sDato & "'"
                strSQL = strSQL & " AND h.HDoc_DR1_Num LIKE '%" & (sDato) & "%'"
            End If
        ElseIf (Inicio > vbEmpty) Then
            strSQL = strSQL & " AND CAST(di.ADoc_Dta_Chr AS SIGNED) BETWEEN {inicio} AND {fin}"
            strSQL = Replace(strSQL, "{inicio}", Inicio)
            strSQL = Replace(strSQL, "{fin}", Fin)
        Else
            strSQL = strSQL & " AND (h.HDoc_Doc_Fec BETWEEN '" & dtpFechaInicial.Value.ToString(FORMATO_MYSQL) & "' AND '" & dtpFechaFinal.Value.ToString(FORMATO_MYSQL) & "')"
        End If
        strSQL = strSQL & " GROUP BY"
        strSQL = strSQL & "     h.HDoc_Doc_Ano, h.HDoc_Doc_Num"

        SqlReferencias = strSQL
    End Function

    Private Sub botonBuscar_Click(sender As Object, e As EventArgs) Handles botonBuscar.Click
        Dim strsql As String
        Dim strdato As String
        Dim LngInicio As Long
        Dim lngFin As Long
        Dim REA As MySqlDataReader
        Dim COM As MySqlCommand
        Dim CF As New clsFunciones
        Dim contador As Integer = -1
        Try

            If rbPorReferencia.Checked = True Then
                dgListado.Rows.Clear()
                'Comprueba que se haya ingresado una referencia '
                strReferencia = Trim(celdaPorReferencia.Text)
                If strReferencia = vbNullString Then
                    MsgBox("Enter Reference ", MsgBoxStyle.Exclamation)
                    celdaPorReferencia.Focus()
                End If

            ElseIf rbPorCorrelativo.Checked = True Then
                dgListado.Rows.Clear()
                'Comprueba Los numeros'
                'If Not IsNumeric(celdaIdNumeroInicial.Text(vbEmpty)) And IsNumeric(celdaIdNumeroFinal.Text) Then
                '    MsgBox("El rango Correlativo debe de ser Numerico", MsgBoxStyle.Exclamation)
                '    celdaIdNumeroInicial.Focus()
                If Not IsNumeric(celdaIdNumeroInicial.Text) And celdaIdNumeroInicial.Text <> "" Then
                    MsgBox("Correlative range must be numeric", MsgBoxStyle.Exclamation)
                    celdaIdNumeroInicial.Text = ""
                    celdaIdNumeroInicial.Focus()
                End If

                If IsNumeric(celdaIdNumeroInicial.Text) <= 0 And celdaIdNumeroFinal.Text <= celdaIdNumeroInicial.Text Then
                    MsgBox(" The initial number must be greater than zero and less than or equal to the end ", MsgBoxStyle.Exclamation)
                    celdaIdNumeroInicial.Text = ""
                    celdaIdNumeroInicial.Focus()
                Else
                    strReferencia = vbNullString
                    LngInicio = celdaIdNumeroInicial.Text
                    lngFin = celdaIdNumeroFinal.Text
                End If
            ElseIf rbPorFecha.Checked = True Then
                dgListado.Rows.Clear()
                dtFechaInicial = dtpFechaInicial.Value
                dtFechaFinal = dtpFechaFinal.Value
                strReferencia = vbNullString

            End If

            strsql = SqlReferencias(strReferencia, LngInicio, lngFin)
            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strsql, CON)
            REA = COM.ExecuteReader

            If REA.HasRows Then

                Do While REA.Read
                    'strdato = Format(REA.GetDateTime("Fecha").ToString(FORMATO_MYSQL)) & vbTab & REA.GetString("Poliza") & vbTab & REA.GetString("Referencia") & vbTab & REA.GetInt32("Tipo") & vbTab & REA.GetInt32("Año") & vbTab & REA.GetInt32("Numero") & vbTab & REA.GetString("Dua") & vbTab & REA.GetString("Contenedor") & vbTab & REA.GetString("BL")
                    'If LogInfo Then
                    '    strdato = strdato & vbTab & REA.GetInt32("correlativo") & vbTab & REA.GetString("Regimen") & vbTab & REA.GetString("Origen") & vbTab & REA.GetString("Aduana") & vbTab & REA.GetString("marchamo") & vbTab & REA.GetString("transportista") & vbTab & REA.GetString("Archivo") & vbTab & REA.GetString("Notas")
                    'End If

                    contador = contador + 1
                    cFunciones.AgregarFila(dgListado, REA.GetDateTime("Fecha") & "|" & REA.GetString("Poliza") & "|" & REA.GetString("Referencia") & "|" & REA.GetInt32("Tipo") & "|" & REA.GetInt32("Anio") & "|" & REA.GetInt32("Numero") & "|" & REA.GetString("Dua") & "|" & REA.GetString("Contenedor") & "|" & REA.GetString("BL") & "|" & REA.GetString("correlativo") & "|" & REA.GetString("Regimen") & "|" & REA.GetString("Origen") & "|" & REA.GetString("Aduana") & "|" & REA.GetString("marchamo") & "|" & REA.GetString("transportista") & "|" & REA.GetString("Archivo") & "|" & REA.GetString("Notas") & "|" & contador)
                Loop

            Else
                MsgBox("No records were found matching the search criteria", MsgBoxStyle.Exclamation, "AVISO")
            End If


        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub frmReporteCuentaCorrienteReferencia_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        intCurDoc = 47
        dgListado.Rows.Clear()
        celdaPorReferencia.Text = STR_VACIO
        celdaIdNumeroInicial.Text = INT_CERO
        celdaIdNumeroFinal.Text = INT_CERO
        strReferencia = vbNullString
        rbPorCorrelativo.Checked = False
        rbPorFecha.Checked = False
        rbPorReferencia.Checked = True
        dtpFechaInicial.Enabled = False
        dtpFechaFinal.Enabled = False
        celdaIdNumeroInicial.Enabled = False
        celdaIdNumeroFinal.Enabled = False

    End Sub

    Private Sub botonCerrar_Click(sender As Object, e As EventArgs) Handles botonCerrar.Click
        Me.Close()

    End Sub

    Private Sub rbPorFecha_CheckedChanged(sender As Object, e As EventArgs) Handles rbPorFecha.CheckedChanged

        If rbPorFecha.Checked = True Then
            rbPorCorrelativo.Checked = False
            rbPorReferencia.Checked = False
            celdaPorReferencia.Enabled = False
            dtpFechaInicial.Enabled = True
            dtpFechaFinal.Enabled = True
            celdaIdNumeroInicial.Enabled = False
            celdaIdNumeroFinal.Enabled = False
        End If


    End Sub

    Private Sub rbPorCorrelativo_CheckedChanged(sender As Object, e As EventArgs) Handles rbPorCorrelativo.CheckedChanged
        If rbPorCorrelativo.Checked = True Then
            rbPorReferencia.Checked = False
            rbPorFecha.Checked = False
            celdaIdNumeroInicial.Enabled = True
            celdaIdNumeroFinal.Enabled = True
            dtpFechaInicial.Enabled = False
            dtpFechaFinal.Enabled = False
            celdaPorReferencia.Enabled = False
        End If
    End Sub

    Private Sub rbPorReferencia_CheckedChanged(sender As Object, e As EventArgs) Handles rbPorReferencia.CheckedChanged

        If rbPorReferencia.Checked = True Then
            rbPorCorrelativo.Checked = False
            rbPorFecha.Checked = False
            celdaPorReferencia.Enabled = True
            celdaIdNumeroInicial.Enabled = False
            celdaIdNumeroFinal.Enabled = False
            dtpFechaInicial.Enabled = False
            dtpFechaFinal.Enabled = False
        End If
    End Sub

    Private Sub botonSeleccion_Click(sender As Object, e As EventArgs) Handles botonSeleccion.Click
        Dim reporte As New clsReportes

        If dgListado.Rows.Count > vbEmpty Then

            dgListado.Focus()
        Else
            LogTodo = False
            MsgBox("Select an item in the listing ", MsgBoxStyle.Exclamation, "NOTICE")
        End If

        Me.DialogResult = DialogResult.OK
        Exit Sub
        reporte = Nothing


    End Sub

    Private Sub botonTodo_Click(sender As Object, e As EventArgs) Handles botonTodo.Click
        Dim reporte As New clsReportes
        If dgListado.Rows.Count > vbEmpty Then
            LogTodo = True
        Else
            MsgBox("No Record in Listing", MsgBoxStyle.Exclamation, "NOTICE")
            dgListado.Focus()
        End If
        Me.DialogResult = DialogResult.OK
        Exit Sub

    End Sub

    Private Sub dgListado_CellContentClick(sender As Object, e As DataGridViewCellEventArgs) Handles dgListado.CellContentClick
        Dim reporte As New clsReportes

        If dgListado.Rows.Count > vbEmpty Then

            dgListado.Focus()
        Else
            LogTodo = False
            MsgBox("Select an item in the listing ", MsgBoxStyle.Exclamation, "NOTICE")
        End If

        Me.DialogResult = DialogResult.OK
        Exit Sub
        reporte = Nothing
    End Sub

    Private Sub dgListado_DoubleClick(sender As Object, e As EventArgs) Handles dgListado.DoubleClick

        Dim reporte As New clsReportes
        If dgListado.Rows.Count > vbEmpty Then
            LogTodo = True
        Else
            MsgBox("No Record in Listing", MsgBoxStyle.Exclamation, "NOTICE")
            dgListado.Focus()
        End If
        Me.DialogResult = DialogResult.OK
        Exit Sub

    End Sub

    Private Sub celdaPorReferencia_KeyDown(sender As Object, e As KeyEventArgs) Handles celdaPorReferencia.KeyDown
        If e.KeyCode = Keys.Enter Then
            botonBuscar.Focus()
            e.Handled = True
            e.SuppressKeyPress = True
        End If
    End Sub
End Class

