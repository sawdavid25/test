﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmProduccionNSM
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.panelListaPrincipal = New System.Windows.Forms.Panel()
        Me.dgLista = New System.Windows.Forms.DataGridView()
        Me.colCatalogo = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colAnio = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colNumber = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colDate = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colReferencia = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colProducto = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.panelFecha = New System.Windows.Forms.Panel()
        Me.botonActualizar = New System.Windows.Forms.Button()
        Me.dtpFin = New System.Windows.Forms.DateTimePicker()
        Me.etiquetaFin = New System.Windows.Forms.Label()
        Me.dtpInicio = New System.Windows.Forms.DateTimePicker()
        Me.checkFecha = New System.Windows.Forms.CheckBox()
        Me.panelDocumento = New System.Windows.Forms.Panel()
        Me.panelDetalle = New System.Windows.Forms.Panel()
        Me.dgDetalle = New System.Windows.Forms.DataGridView()
        Me.panelBotones = New System.Windows.Forms.Panel()
        Me.botonQuitar = New System.Windows.Forms.Button()
        Me.botonAgregar = New System.Windows.Forms.Button()
        Me.panelEncabezado = New System.Windows.Forms.Panel()
        Me.etiquetaPO = New System.Windows.Forms.Label()
        Me.checkDespacharFibra = New System.Windows.Forms.CheckBox()
        Me.panelTipo = New System.Windows.Forms.Panel()
        Me.rbSpandex = New System.Windows.Forms.RadioButton()
        Me.rbRayon = New System.Windows.Forms.RadioButton()
        Me.rbPoly = New System.Windows.Forms.RadioButton()
        Me.rbCotton = New System.Windows.Forms.RadioButton()
        Me.rbMezcla = New System.Windows.Forms.RadioButton()
        Me.celdaSaldo = New System.Windows.Forms.TextBox()
        Me.celdaidAñoPO = New System.Windows.Forms.TextBox()
        Me.celdaidPONumero = New System.Windows.Forms.TextBox()
        Me.botonPO = New System.Windows.Forms.Button()
        Me.celdaPO = New System.Windows.Forms.TextBox()
        Me.botonPolizaC = New System.Windows.Forms.Button()
        Me.checkActivar = New System.Windows.Forms.CheckBox()
        Me.botonMoneda = New System.Windows.Forms.Button()
        Me.celdaIdMoneda = New System.Windows.Forms.TextBox()
        Me.celdaMoneda = New System.Windows.Forms.TextBox()
        Me.etiquetaMoneda = New System.Windows.Forms.Label()
        Me.celdaTasa = New System.Windows.Forms.TextBox()
        Me.etiquetaTasa = New System.Windows.Forms.Label()
        Me.celdaReferencia = New System.Windows.Forms.TextBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.celdaNumero = New System.Windows.Forms.TextBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.etiquetaAnio = New System.Windows.Forms.Label()
        Me.celdaAnio = New System.Windows.Forms.TextBox()
        Me.dtpFecha = New System.Windows.Forms.DateTimePicker()
        Me.etiquetaFecha = New System.Windows.Forms.Label()
        Me.panelAbajo = New System.Windows.Forms.Panel()
        Me.celdaLineas = New System.Windows.Forms.TextBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.celdaTotal = New System.Windows.Forms.TextBox()
        Me.etiquetaTotal = New System.Windows.Forms.Label()
        Me.celdaPeso = New System.Windows.Forms.TextBox()
        Me.etiquetaPeso = New System.Windows.Forms.Label()
        Me.celdaPrecio = New System.Windows.Forms.TextBox()
        Me.etiquetaPrecio = New System.Windows.Forms.Label()
        Me.BarraTitulo1 = New KARIMs_SGI.BarraTitulo()
        Me.Encabezado1 = New KARIMs_SGI.encabezado()
        Me.colRefAnio = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colRefCatalogo = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colRefNum = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colCodigo = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colLinea = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colMarca = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colDescripcion = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colPrecio = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colCantidad = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colPrecioMedida = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colTotal = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colidMedida = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colMedida = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colReferencia1 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colRefLin = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colBultoB = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colExtra = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colExtraPO = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colLineaPO = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colCorrelativo = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colTipoCambio = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.panelListaPrincipal.SuspendLayout()
        CType(Me.dgLista, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.panelFecha.SuspendLayout()
        Me.panelDocumento.SuspendLayout()
        Me.panelDetalle.SuspendLayout()
        CType(Me.dgDetalle, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.panelBotones.SuspendLayout()
        Me.panelEncabezado.SuspendLayout()
        Me.panelTipo.SuspendLayout()
        Me.panelAbajo.SuspendLayout()
        Me.SuspendLayout()
        '
        'panelListaPrincipal
        '
        Me.panelListaPrincipal.Controls.Add(Me.dgLista)
        Me.panelListaPrincipal.Controls.Add(Me.panelFecha)
        Me.panelListaPrincipal.Dock = System.Windows.Forms.DockStyle.Top
        Me.panelListaPrincipal.Location = New System.Drawing.Point(0, 126)
        Me.panelListaPrincipal.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.panelListaPrincipal.Name = "panelListaPrincipal"
        Me.panelListaPrincipal.Size = New System.Drawing.Size(804, 90)
        Me.panelListaPrincipal.TabIndex = 4
        '
        'dgLista
        '
        Me.dgLista.AllowUserToAddRows = False
        Me.dgLista.AllowUserToDeleteRows = False
        Me.dgLista.AllowUserToOrderColumns = True
        Me.dgLista.BackgroundColor = System.Drawing.SystemColors.Control
        Me.dgLista.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgLista.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.colCatalogo, Me.colAnio, Me.colNumber, Me.colDate, Me.colReferencia, Me.colProducto})
        Me.dgLista.Dock = System.Windows.Forms.DockStyle.Fill
        Me.dgLista.Location = New System.Drawing.Point(0, 54)
        Me.dgLista.Margin = New System.Windows.Forms.Padding(4)
        Me.dgLista.MultiSelect = False
        Me.dgLista.Name = "dgLista"
        Me.dgLista.ReadOnly = True
        Me.dgLista.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.dgLista.Size = New System.Drawing.Size(804, 36)
        Me.dgLista.TabIndex = 3
        '
        'colCatalogo
        '
        Me.colCatalogo.HeaderText = "Catalogo"
        Me.colCatalogo.Name = "colCatalogo"
        Me.colCatalogo.ReadOnly = True
        Me.colCatalogo.Visible = False
        '
        'colAnio
        '
        Me.colAnio.HeaderText = "Year"
        Me.colAnio.Name = "colAnio"
        Me.colAnio.ReadOnly = True
        Me.colAnio.Visible = False
        '
        'colNumber
        '
        Me.colNumber.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.colNumber.HeaderText = "Number"
        Me.colNumber.Name = "colNumber"
        Me.colNumber.ReadOnly = True
        Me.colNumber.Width = 87
        '
        'colDate
        '
        Me.colDate.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.colDate.HeaderText = "Date"
        Me.colDate.Name = "colDate"
        Me.colDate.ReadOnly = True
        Me.colDate.Width = 67
        '
        'colReferencia
        '
        Me.colReferencia.HeaderText = "Reference"
        Me.colReferencia.Name = "colReferencia"
        Me.colReferencia.ReadOnly = True
        '
        'colProducto
        '
        Me.colProducto.HeaderText = "PO"
        Me.colProducto.Name = "colProducto"
        Me.colProducto.ReadOnly = True
        '
        'panelFecha
        '
        Me.panelFecha.Controls.Add(Me.botonActualizar)
        Me.panelFecha.Controls.Add(Me.dtpFin)
        Me.panelFecha.Controls.Add(Me.etiquetaFin)
        Me.panelFecha.Controls.Add(Me.dtpInicio)
        Me.panelFecha.Controls.Add(Me.checkFecha)
        Me.panelFecha.Dock = System.Windows.Forms.DockStyle.Top
        Me.panelFecha.Location = New System.Drawing.Point(0, 0)
        Me.panelFecha.Margin = New System.Windows.Forms.Padding(4)
        Me.panelFecha.Name = "panelFecha"
        Me.panelFecha.Size = New System.Drawing.Size(804, 54)
        Me.panelFecha.TabIndex = 2
        '
        'botonActualizar
        '
        Me.botonActualizar.Location = New System.Drawing.Point(581, 15)
        Me.botonActualizar.Margin = New System.Windows.Forms.Padding(4)
        Me.botonActualizar.Name = "botonActualizar"
        Me.botonActualizar.Size = New System.Drawing.Size(100, 28)
        Me.botonActualizar.TabIndex = 5
        Me.botonActualizar.Text = "To Update"
        Me.botonActualizar.UseVisualStyleBackColor = True
        '
        'dtpFin
        '
        Me.dtpFin.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.dtpFin.Location = New System.Drawing.Point(435, 17)
        Me.dtpFin.Margin = New System.Windows.Forms.Padding(4)
        Me.dtpFin.Name = "dtpFin"
        Me.dtpFin.Size = New System.Drawing.Size(113, 22)
        Me.dtpFin.TabIndex = 4
        '
        'etiquetaFin
        '
        Me.etiquetaFin.AutoSize = True
        Me.etiquetaFin.Location = New System.Drawing.Point(361, 21)
        Me.etiquetaFin.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.etiquetaFin.Name = "etiquetaFin"
        Me.etiquetaFin.Size = New System.Drawing.Size(66, 17)
        Me.etiquetaFin.TabIndex = 3
        Me.etiquetaFin.Text = "and Date"
        '
        'dtpInicio
        '
        Me.dtpInicio.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.dtpInicio.Location = New System.Drawing.Point(243, 16)
        Me.dtpInicio.Margin = New System.Windows.Forms.Padding(4)
        Me.dtpInicio.Name = "dtpInicio"
        Me.dtpInicio.Size = New System.Drawing.Size(112, 22)
        Me.dtpInicio.TabIndex = 1
        '
        'checkFecha
        '
        Me.checkFecha.AutoSize = True
        Me.checkFecha.Checked = True
        Me.checkFecha.CheckState = System.Windows.Forms.CheckState.Checked
        Me.checkFecha.Location = New System.Drawing.Point(9, 21)
        Me.checkFecha.Margin = New System.Windows.Forms.Padding(4)
        Me.checkFecha.Name = "checkFecha"
        Me.checkFecha.Size = New System.Drawing.Size(224, 21)
        Me.checkFecha.TabIndex = 0
        Me.checkFecha.Text = "show documents between date"
        Me.checkFecha.UseVisualStyleBackColor = True
        '
        'panelDocumento
        '
        Me.panelDocumento.Controls.Add(Me.panelDetalle)
        Me.panelDocumento.Controls.Add(Me.panelEncabezado)
        Me.panelDocumento.Controls.Add(Me.panelAbajo)
        Me.panelDocumento.Location = New System.Drawing.Point(9, 244)
        Me.panelDocumento.Margin = New System.Windows.Forms.Padding(4)
        Me.panelDocumento.Name = "panelDocumento"
        Me.panelDocumento.Size = New System.Drawing.Size(781, 295)
        Me.panelDocumento.TabIndex = 5
        '
        'panelDetalle
        '
        Me.panelDetalle.Controls.Add(Me.dgDetalle)
        Me.panelDetalle.Controls.Add(Me.panelBotones)
        Me.panelDetalle.Dock = System.Windows.Forms.DockStyle.Fill
        Me.panelDetalle.Location = New System.Drawing.Point(0, 170)
        Me.panelDetalle.Margin = New System.Windows.Forms.Padding(4)
        Me.panelDetalle.Name = "panelDetalle"
        Me.panelDetalle.Size = New System.Drawing.Size(781, 82)
        Me.panelDetalle.TabIndex = 2
        '
        'dgDetalle
        '
        Me.dgDetalle.AllowUserToAddRows = False
        Me.dgDetalle.AllowUserToDeleteRows = False
        Me.dgDetalle.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells
        Me.dgDetalle.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells
        Me.dgDetalle.BackgroundColor = System.Drawing.SystemColors.Control
        Me.dgDetalle.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgDetalle.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.colRefAnio, Me.colRefCatalogo, Me.colRefNum, Me.colCodigo, Me.colLinea, Me.colMarca, Me.colDescripcion, Me.colPrecio, Me.colCantidad, Me.colPrecioMedida, Me.colTotal, Me.colidMedida, Me.colMedida, Me.colReferencia1, Me.colRefLin, Me.colBultoB, Me.colExtra, Me.colExtraPO, Me.colLineaPO, Me.colCorrelativo, Me.colTipoCambio})
        Me.dgDetalle.Dock = System.Windows.Forms.DockStyle.Fill
        Me.dgDetalle.Location = New System.Drawing.Point(0, 0)
        Me.dgDetalle.Margin = New System.Windows.Forms.Padding(4)
        Me.dgDetalle.MultiSelect = False
        Me.dgDetalle.Name = "dgDetalle"
        Me.dgDetalle.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.dgDetalle.Size = New System.Drawing.Size(690, 82)
        Me.dgDetalle.TabIndex = 1
        '
        'panelBotones
        '
        Me.panelBotones.Controls.Add(Me.botonQuitar)
        Me.panelBotones.Controls.Add(Me.botonAgregar)
        Me.panelBotones.Dock = System.Windows.Forms.DockStyle.Right
        Me.panelBotones.Location = New System.Drawing.Point(690, 0)
        Me.panelBotones.Margin = New System.Windows.Forms.Padding(4)
        Me.panelBotones.Name = "panelBotones"
        Me.panelBotones.Size = New System.Drawing.Size(91, 82)
        Me.panelBotones.TabIndex = 0
        '
        'botonQuitar
        '
        Me.botonQuitar.Image = Global.KARIMs_SGI.My.Resources.Resources.minus
        Me.botonQuitar.Location = New System.Drawing.Point(21, 63)
        Me.botonQuitar.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.botonQuitar.Name = "botonQuitar"
        Me.botonQuitar.Size = New System.Drawing.Size(53, 41)
        Me.botonQuitar.TabIndex = 52
        Me.botonQuitar.UseVisualStyleBackColor = True
        '
        'botonAgregar
        '
        Me.botonAgregar.Image = Global.KARIMs_SGI.My.Resources.Resources.add
        Me.botonAgregar.Location = New System.Drawing.Point(21, 17)
        Me.botonAgregar.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.botonAgregar.Name = "botonAgregar"
        Me.botonAgregar.Size = New System.Drawing.Size(53, 41)
        Me.botonAgregar.TabIndex = 51
        Me.botonAgregar.UseVisualStyleBackColor = True
        '
        'panelEncabezado
        '
        Me.panelEncabezado.Controls.Add(Me.etiquetaPO)
        Me.panelEncabezado.Controls.Add(Me.checkDespacharFibra)
        Me.panelEncabezado.Controls.Add(Me.panelTipo)
        Me.panelEncabezado.Controls.Add(Me.celdaSaldo)
        Me.panelEncabezado.Controls.Add(Me.celdaidAñoPO)
        Me.panelEncabezado.Controls.Add(Me.celdaidPONumero)
        Me.panelEncabezado.Controls.Add(Me.botonPO)
        Me.panelEncabezado.Controls.Add(Me.celdaPO)
        Me.panelEncabezado.Controls.Add(Me.botonPolizaC)
        Me.panelEncabezado.Controls.Add(Me.checkActivar)
        Me.panelEncabezado.Controls.Add(Me.botonMoneda)
        Me.panelEncabezado.Controls.Add(Me.celdaIdMoneda)
        Me.panelEncabezado.Controls.Add(Me.celdaMoneda)
        Me.panelEncabezado.Controls.Add(Me.etiquetaMoneda)
        Me.panelEncabezado.Controls.Add(Me.celdaTasa)
        Me.panelEncabezado.Controls.Add(Me.etiquetaTasa)
        Me.panelEncabezado.Controls.Add(Me.celdaReferencia)
        Me.panelEncabezado.Controls.Add(Me.Label2)
        Me.panelEncabezado.Controls.Add(Me.celdaNumero)
        Me.panelEncabezado.Controls.Add(Me.Label1)
        Me.panelEncabezado.Controls.Add(Me.etiquetaAnio)
        Me.panelEncabezado.Controls.Add(Me.celdaAnio)
        Me.panelEncabezado.Controls.Add(Me.dtpFecha)
        Me.panelEncabezado.Controls.Add(Me.etiquetaFecha)
        Me.panelEncabezado.Dock = System.Windows.Forms.DockStyle.Top
        Me.panelEncabezado.Location = New System.Drawing.Point(0, 0)
        Me.panelEncabezado.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.panelEncabezado.Name = "panelEncabezado"
        Me.panelEncabezado.Size = New System.Drawing.Size(781, 170)
        Me.panelEncabezado.TabIndex = 1
        '
        'etiquetaPO
        '
        Me.etiquetaPO.AutoSize = True
        Me.etiquetaPO.Location = New System.Drawing.Point(595, 44)
        Me.etiquetaPO.Name = "etiquetaPO"
        Me.etiquetaPO.Size = New System.Drawing.Size(71, 17)
        Me.etiquetaPO.TabIndex = 63
        Me.etiquetaPO.Text = "Select PO"
        '
        'checkDespacharFibra
        '
        Me.checkDespacharFibra.AutoSize = True
        Me.checkDespacharFibra.Location = New System.Drawing.Point(345, 36)
        Me.checkDespacharFibra.Margin = New System.Windows.Forms.Padding(4)
        Me.checkDespacharFibra.Name = "checkDespacharFibra"
        Me.checkDespacharFibra.Size = New System.Drawing.Size(121, 21)
        Me.checkDespacharFibra.TabIndex = 62
        Me.checkDespacharFibra.Text = "Dispatch Fiber"
        Me.checkDespacharFibra.UseVisualStyleBackColor = True
        '
        'panelTipo
        '
        Me.panelTipo.Controls.Add(Me.rbSpandex)
        Me.panelTipo.Controls.Add(Me.rbRayon)
        Me.panelTipo.Controls.Add(Me.rbPoly)
        Me.panelTipo.Controls.Add(Me.rbCotton)
        Me.panelTipo.Controls.Add(Me.rbMezcla)
        Me.panelTipo.Location = New System.Drawing.Point(472, 4)
        Me.panelTipo.Margin = New System.Windows.Forms.Padding(4)
        Me.panelTipo.Name = "panelTipo"
        Me.panelTipo.Size = New System.Drawing.Size(116, 164)
        Me.panelTipo.TabIndex = 61
        '
        'rbSpandex
        '
        Me.rbSpandex.AutoSize = True
        Me.rbSpandex.Location = New System.Drawing.Point(16, 127)
        Me.rbSpandex.Margin = New System.Windows.Forms.Padding(4)
        Me.rbSpandex.Name = "rbSpandex"
        Me.rbSpandex.Size = New System.Drawing.Size(84, 21)
        Me.rbSpandex.TabIndex = 54
        Me.rbSpandex.TabStop = True
        Me.rbSpandex.Text = "Spandex"
        Me.rbSpandex.UseVisualStyleBackColor = True
        '
        'rbRayon
        '
        Me.rbRayon.AutoSize = True
        Me.rbRayon.Location = New System.Drawing.Point(16, 101)
        Me.rbRayon.Margin = New System.Windows.Forms.Padding(4)
        Me.rbRayon.Name = "rbRayon"
        Me.rbRayon.Size = New System.Drawing.Size(70, 21)
        Me.rbRayon.TabIndex = 53
        Me.rbRayon.TabStop = True
        Me.rbRayon.Text = "Rayòn"
        Me.rbRayon.UseVisualStyleBackColor = True
        '
        'rbPoly
        '
        Me.rbPoly.AutoSize = True
        Me.rbPoly.Location = New System.Drawing.Point(16, 69)
        Me.rbPoly.Margin = New System.Windows.Forms.Padding(4)
        Me.rbPoly.Name = "rbPoly"
        Me.rbPoly.Size = New System.Drawing.Size(56, 21)
        Me.rbPoly.TabIndex = 52
        Me.rbPoly.TabStop = True
        Me.rbPoly.Text = "Poly"
        Me.rbPoly.UseVisualStyleBackColor = True
        '
        'rbCotton
        '
        Me.rbCotton.AutoSize = True
        Me.rbCotton.Location = New System.Drawing.Point(16, 44)
        Me.rbCotton.Margin = New System.Windows.Forms.Padding(4)
        Me.rbCotton.Name = "rbCotton"
        Me.rbCotton.Size = New System.Drawing.Size(70, 21)
        Me.rbCotton.TabIndex = 51
        Me.rbCotton.TabStop = True
        Me.rbCotton.Text = "Cotton"
        Me.rbCotton.UseVisualStyleBackColor = True
        '
        'rbMezcla
        '
        Me.rbMezcla.AutoSize = True
        Me.rbMezcla.Location = New System.Drawing.Point(16, 16)
        Me.rbMezcla.Margin = New System.Windows.Forms.Padding(4)
        Me.rbMezcla.Name = "rbMezcla"
        Me.rbMezcla.Size = New System.Drawing.Size(73, 21)
        Me.rbMezcla.TabIndex = 50
        Me.rbMezcla.TabStop = True
        Me.rbMezcla.Text = "Mezcla"
        Me.rbMezcla.UseVisualStyleBackColor = True
        '
        'celdaSaldo
        '
        Me.celdaSaldo.Location = New System.Drawing.Point(408, 63)
        Me.celdaSaldo.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.celdaSaldo.Name = "celdaSaldo"
        Me.celdaSaldo.ReadOnly = True
        Me.celdaSaldo.Size = New System.Drawing.Size(31, 22)
        Me.celdaSaldo.TabIndex = 60
        Me.celdaSaldo.Visible = False
        '
        'celdaidAñoPO
        '
        Me.celdaidAñoPO.Location = New System.Drawing.Point(632, 21)
        Me.celdaidAñoPO.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.celdaidAñoPO.Name = "celdaidAñoPO"
        Me.celdaidAñoPO.ReadOnly = True
        Me.celdaidAñoPO.Size = New System.Drawing.Size(31, 22)
        Me.celdaidAñoPO.TabIndex = 59
        Me.celdaidAñoPO.Visible = False
        '
        'celdaidPONumero
        '
        Me.celdaidPONumero.Location = New System.Drawing.Point(595, 20)
        Me.celdaidPONumero.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.celdaidPONumero.Name = "celdaidPONumero"
        Me.celdaidPONumero.ReadOnly = True
        Me.celdaidPONumero.Size = New System.Drawing.Size(31, 22)
        Me.celdaidPONumero.TabIndex = 58
        Me.celdaidPONumero.Visible = False
        '
        'botonPO
        '
        Me.botonPO.Location = New System.Drawing.Point(745, 64)
        Me.botonPO.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.botonPO.Name = "botonPO"
        Me.botonPO.Size = New System.Drawing.Size(33, 23)
        Me.botonPO.TabIndex = 57
        Me.botonPO.Text = "..."
        Me.botonPO.UseVisualStyleBackColor = True
        '
        'celdaPO
        '
        Me.celdaPO.Location = New System.Drawing.Point(595, 64)
        Me.celdaPO.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.celdaPO.Name = "celdaPO"
        Me.celdaPO.ReadOnly = True
        Me.celdaPO.Size = New System.Drawing.Size(144, 22)
        Me.celdaPO.TabIndex = 56
        '
        'botonPolizaC
        '
        Me.botonPolizaC.Image = Global.KARIMs_SGI.My.Resources.Resources.book_open1
        Me.botonPolizaC.Location = New System.Drawing.Point(633, 128)
        Me.botonPolizaC.Margin = New System.Windows.Forms.Padding(4)
        Me.botonPolizaC.Name = "botonPolizaC"
        Me.botonPolizaC.Size = New System.Drawing.Size(39, 28)
        Me.botonPolizaC.TabIndex = 55
        Me.botonPolizaC.UseVisualStyleBackColor = True
        '
        'checkActivar
        '
        Me.checkActivar.AutoSize = True
        Me.checkActivar.Checked = True
        Me.checkActivar.CheckState = System.Windows.Forms.CheckState.Checked
        Me.checkActivar.Location = New System.Drawing.Point(345, 12)
        Me.checkActivar.Margin = New System.Windows.Forms.Padding(4)
        Me.checkActivar.Name = "checkActivar"
        Me.checkActivar.Size = New System.Drawing.Size(68, 21)
        Me.checkActivar.TabIndex = 49
        Me.checkActivar.Text = "Active"
        Me.checkActivar.UseVisualStyleBackColor = True
        '
        'botonMoneda
        '
        Me.botonMoneda.Location = New System.Drawing.Point(172, 129)
        Me.botonMoneda.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.botonMoneda.Name = "botonMoneda"
        Me.botonMoneda.Size = New System.Drawing.Size(33, 23)
        Me.botonMoneda.TabIndex = 48
        Me.botonMoneda.Text = "..."
        Me.botonMoneda.UseVisualStyleBackColor = True
        '
        'celdaIdMoneda
        '
        Me.celdaIdMoneda.Location = New System.Drawing.Point(284, 17)
        Me.celdaIdMoneda.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.celdaIdMoneda.Name = "celdaIdMoneda"
        Me.celdaIdMoneda.ReadOnly = True
        Me.celdaIdMoneda.Size = New System.Drawing.Size(31, 22)
        Me.celdaIdMoneda.TabIndex = 47
        Me.celdaIdMoneda.Visible = False
        '
        'celdaMoneda
        '
        Me.celdaMoneda.Location = New System.Drawing.Point(81, 128)
        Me.celdaMoneda.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.celdaMoneda.Name = "celdaMoneda"
        Me.celdaMoneda.ReadOnly = True
        Me.celdaMoneda.Size = New System.Drawing.Size(76, 22)
        Me.celdaMoneda.TabIndex = 46
        '
        'etiquetaMoneda
        '
        Me.etiquetaMoneda.AutoSize = True
        Me.etiquetaMoneda.Location = New System.Drawing.Point(15, 135)
        Me.etiquetaMoneda.Name = "etiquetaMoneda"
        Me.etiquetaMoneda.Size = New System.Drawing.Size(36, 17)
        Me.etiquetaMoneda.TabIndex = 45
        Me.etiquetaMoneda.Text = "Coin"
        '
        'celdaTasa
        '
        Me.celdaTasa.Location = New System.Drawing.Point(275, 127)
        Me.celdaTasa.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.celdaTasa.Name = "celdaTasa"
        Me.celdaTasa.Size = New System.Drawing.Size(100, 22)
        Me.celdaTasa.TabIndex = 32
        '
        'etiquetaTasa
        '
        Me.etiquetaTasa.AutoSize = True
        Me.etiquetaTasa.Location = New System.Drawing.Point(231, 132)
        Me.etiquetaTasa.Name = "etiquetaTasa"
        Me.etiquetaTasa.Size = New System.Drawing.Size(38, 17)
        Me.etiquetaTasa.TabIndex = 31
        Me.etiquetaTasa.Text = "Rate"
        '
        'celdaReferencia
        '
        Me.celdaReferencia.Location = New System.Drawing.Point(81, 100)
        Me.celdaReferencia.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.celdaReferencia.Name = "celdaReferencia"
        Me.celdaReferencia.Size = New System.Drawing.Size(295, 22)
        Me.celdaReferencia.TabIndex = 24
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(3, 103)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(79, 17)
        Me.Label2.TabIndex = 23
        Me.Label2.Text = "Description"
        '
        'celdaNumero
        '
        Me.celdaNumero.Location = New System.Drawing.Point(81, 69)
        Me.celdaNumero.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.celdaNumero.Name = "celdaNumero"
        Me.celdaNumero.ReadOnly = True
        Me.celdaNumero.Size = New System.Drawing.Size(124, 22)
        Me.celdaNumero.TabIndex = 22
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(13, 71)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(21, 17)
        Me.Label1.TabIndex = 21
        Me.Label1.Text = "ID"
        '
        'etiquetaAnio
        '
        Me.etiquetaAnio.AutoSize = True
        Me.etiquetaAnio.Location = New System.Drawing.Point(13, 43)
        Me.etiquetaAnio.Name = "etiquetaAnio"
        Me.etiquetaAnio.Size = New System.Drawing.Size(38, 17)
        Me.etiquetaAnio.TabIndex = 19
        Me.etiquetaAnio.Text = "Year"
        '
        'celdaAnio
        '
        Me.celdaAnio.Location = New System.Drawing.Point(81, 38)
        Me.celdaAnio.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.celdaAnio.Name = "celdaAnio"
        Me.celdaAnio.ReadOnly = True
        Me.celdaAnio.Size = New System.Drawing.Size(124, 22)
        Me.celdaAnio.TabIndex = 20
        '
        'dtpFecha
        '
        Me.dtpFecha.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.dtpFecha.Location = New System.Drawing.Point(81, 10)
        Me.dtpFecha.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.dtpFecha.Name = "dtpFecha"
        Me.dtpFecha.Size = New System.Drawing.Size(124, 22)
        Me.dtpFecha.TabIndex = 18
        '
        'etiquetaFecha
        '
        Me.etiquetaFecha.AutoSize = True
        Me.etiquetaFecha.Location = New System.Drawing.Point(13, 17)
        Me.etiquetaFecha.Name = "etiquetaFecha"
        Me.etiquetaFecha.Size = New System.Drawing.Size(38, 17)
        Me.etiquetaFecha.TabIndex = 17
        Me.etiquetaFecha.Text = "Date"
        '
        'panelAbajo
        '
        Me.panelAbajo.Controls.Add(Me.celdaLineas)
        Me.panelAbajo.Controls.Add(Me.Label3)
        Me.panelAbajo.Controls.Add(Me.celdaTotal)
        Me.panelAbajo.Controls.Add(Me.etiquetaTotal)
        Me.panelAbajo.Controls.Add(Me.celdaPeso)
        Me.panelAbajo.Controls.Add(Me.etiquetaPeso)
        Me.panelAbajo.Controls.Add(Me.celdaPrecio)
        Me.panelAbajo.Controls.Add(Me.etiquetaPrecio)
        Me.panelAbajo.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.panelAbajo.Location = New System.Drawing.Point(0, 252)
        Me.panelAbajo.Margin = New System.Windows.Forms.Padding(4)
        Me.panelAbajo.Name = "panelAbajo"
        Me.panelAbajo.Size = New System.Drawing.Size(781, 43)
        Me.panelAbajo.TabIndex = 3
        '
        'celdaLineas
        '
        Me.celdaLineas.Location = New System.Drawing.Point(719, 13)
        Me.celdaLineas.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.celdaLineas.Name = "celdaLineas"
        Me.celdaLineas.ReadOnly = True
        Me.celdaLineas.Size = New System.Drawing.Size(55, 22)
        Me.celdaLineas.TabIndex = 27
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(600, 16)
        Me.Label3.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(112, 17)
        Me.Label3.TabIndex = 26
        Me.Label3.Text = "Number of bales"
        '
        'celdaTotal
        '
        Me.celdaTotal.Location = New System.Drawing.Point(462, 12)
        Me.celdaTotal.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.celdaTotal.Name = "celdaTotal"
        Me.celdaTotal.ReadOnly = True
        Me.celdaTotal.Size = New System.Drawing.Size(124, 22)
        Me.celdaTotal.TabIndex = 25
        '
        'etiquetaTotal
        '
        Me.etiquetaTotal.AutoSize = True
        Me.etiquetaTotal.Location = New System.Drawing.Point(411, 16)
        Me.etiquetaTotal.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.etiquetaTotal.Name = "etiquetaTotal"
        Me.etiquetaTotal.Size = New System.Drawing.Size(40, 17)
        Me.etiquetaTotal.TabIndex = 24
        Me.etiquetaTotal.Text = "Total"
        '
        'celdaPeso
        '
        Me.celdaPeso.Location = New System.Drawing.Point(266, 12)
        Me.celdaPeso.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.celdaPeso.Name = "celdaPeso"
        Me.celdaPeso.ReadOnly = True
        Me.celdaPeso.Size = New System.Drawing.Size(124, 22)
        Me.celdaPeso.TabIndex = 23
        '
        'etiquetaPeso
        '
        Me.etiquetaPeso.AutoSize = True
        Me.etiquetaPeso.Location = New System.Drawing.Point(206, 16)
        Me.etiquetaPeso.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.etiquetaPeso.Name = "etiquetaPeso"
        Me.etiquetaPeso.Size = New System.Drawing.Size(52, 17)
        Me.etiquetaPeso.TabIndex = 22
        Me.etiquetaPeso.Text = "Weight"
        '
        'celdaPrecio
        '
        Me.celdaPrecio.Location = New System.Drawing.Point(37, 15)
        Me.celdaPrecio.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.celdaPrecio.Name = "celdaPrecio"
        Me.celdaPrecio.ReadOnly = True
        Me.celdaPrecio.Size = New System.Drawing.Size(124, 22)
        Me.celdaPrecio.TabIndex = 21
        Me.celdaPrecio.Visible = False
        '
        'etiquetaPrecio
        '
        Me.etiquetaPrecio.AutoSize = True
        Me.etiquetaPrecio.Location = New System.Drawing.Point(34, 0)
        Me.etiquetaPrecio.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.etiquetaPrecio.Name = "etiquetaPrecio"
        Me.etiquetaPrecio.Size = New System.Drawing.Size(40, 17)
        Me.etiquetaPrecio.TabIndex = 0
        Me.etiquetaPrecio.Text = "Price"
        Me.etiquetaPrecio.Visible = False
        '
        'BarraTitulo1
        '
        Me.BarraTitulo1.BackColor = System.Drawing.Color.WhiteSmoke
        Me.BarraTitulo1.Dock = System.Windows.Forms.DockStyle.Top
        Me.BarraTitulo1.Location = New System.Drawing.Point(0, 89)
        Me.BarraTitulo1.Margin = New System.Windows.Forms.Padding(5)
        Me.BarraTitulo1.Name = "BarraTitulo1"
        Me.BarraTitulo1.Size = New System.Drawing.Size(804, 37)
        Me.BarraTitulo1.TabIndex = 1
        '
        'Encabezado1
        '
        Me.Encabezado1.Dock = System.Windows.Forms.DockStyle.Top
        Me.Encabezado1.Location = New System.Drawing.Point(0, 0)
        Me.Encabezado1.Margin = New System.Windows.Forms.Padding(5)
        Me.Encabezado1.Name = "Encabezado1"
        Me.Encabezado1.Size = New System.Drawing.Size(804, 89)
        Me.Encabezado1.TabIndex = 0
        '
        'colRefAnio
        '
        Me.colRefAnio.HeaderText = "Anio"
        Me.colRefAnio.Name = "colRefAnio"
        Me.colRefAnio.Visible = False
        Me.colRefAnio.Width = 65
        '
        'colRefCatalogo
        '
        Me.colRefCatalogo.HeaderText = "Catalogo"
        Me.colRefCatalogo.Name = "colRefCatalogo"
        Me.colRefCatalogo.Visible = False
        Me.colRefCatalogo.Width = 93
        '
        'colRefNum
        '
        Me.colRefNum.HeaderText = "Numero"
        Me.colRefNum.Name = "colRefNum"
        Me.colRefNum.Visible = False
        Me.colRefNum.Width = 87
        '
        'colCodigo
        '
        Me.colCodigo.HeaderText = "Code"
        Me.colCodigo.Name = "colCodigo"
        Me.colCodigo.ReadOnly = True
        Me.colCodigo.Width = 70
        '
        'colLinea
        '
        Me.colLinea.HeaderText = "Line"
        Me.colLinea.Name = "colLinea"
        Me.colLinea.ReadOnly = True
        Me.colLinea.Width = 64
        '
        'colMarca
        '
        Me.colMarca.HeaderText = "Mark"
        Me.colMarca.Name = "colMarca"
        Me.colMarca.ReadOnly = True
        Me.colMarca.Width = 68
        '
        'colDescripcion
        '
        Me.colDescripcion.HeaderText = "Description"
        Me.colDescripcion.Name = "colDescripcion"
        Me.colDescripcion.ReadOnly = True
        Me.colDescripcion.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        Me.colDescripcion.Width = 85
        '
        'colPrecio
        '
        Me.colPrecio.HeaderText = "Price Fyber"
        Me.colPrecio.Name = "colPrecio"
        Me.colPrecio.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        Me.colPrecio.Width = 86
        '
        'colCantidad
        '
        Me.colCantidad.HeaderText = "Weight"
        Me.colCantidad.Name = "colCantidad"
        Me.colCantidad.ReadOnly = True
        Me.colCantidad.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        Me.colCantidad.Width = 58
        '
        'colPrecioMedida
        '
        Me.colPrecioMedida.HeaderText = "Estimated Price"
        Me.colPrecioMedida.Name = "colPrecioMedida"
        Me.colPrecioMedida.ReadOnly = True
        Me.colPrecioMedida.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        Me.colPrecioMedida.Visible = False
        Me.colPrecioMedida.Width = 112
        '
        'colTotal
        '
        Me.colTotal.HeaderText = "Total"
        Me.colTotal.Name = "colTotal"
        Me.colTotal.ReadOnly = True
        Me.colTotal.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        Me.colTotal.Width = 46
        '
        'colidMedida
        '
        Me.colidMedida.HeaderText = "idMedida"
        Me.colidMedida.Name = "colidMedida"
        Me.colidMedida.Visible = False
        Me.colidMedida.Width = 94
        '
        'colMedida
        '
        Me.colMedida.HeaderText = "Measure"
        Me.colMedida.Name = "colMedida"
        Me.colMedida.ReadOnly = True
        Me.colMedida.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        Me.colMedida.Width = 69
        '
        'colReferencia1
        '
        Me.colReferencia1.HeaderText = "Reference"
        Me.colReferencia1.Name = "colReferencia1"
        Me.colReferencia1.ReadOnly = True
        Me.colReferencia1.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        Me.colReferencia1.Width = 80
        '
        'colRefLin
        '
        Me.colRefLin.HeaderText = "Linea"
        Me.colRefLin.Name = "colRefLin"
        Me.colRefLin.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        Me.colRefLin.Visible = False
        Me.colRefLin.Width = 49
        '
        'colBultoB
        '
        Me.colBultoB.HeaderText = "Bulto"
        Me.colBultoB.Name = "colBultoB"
        Me.colBultoB.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        Me.colBultoB.Visible = False
        Me.colBultoB.Width = 46
        '
        'colExtra
        '
        Me.colExtra.HeaderText = "Extra"
        Me.colExtra.Name = "colExtra"
        Me.colExtra.Visible = False
        Me.colExtra.Width = 69
        '
        'colExtraPO
        '
        Me.colExtraPO.HeaderText = "StatusPO"
        Me.colExtraPO.Name = "colExtraPO"
        Me.colExtraPO.Visible = False
        Me.colExtraPO.Width = 97
        '
        'colLineaPO
        '
        Me.colLineaPO.HeaderText = "LineaPO"
        Me.colLineaPO.Name = "colLineaPO"
        Me.colLineaPO.Visible = False
        Me.colLineaPO.Width = 92
        '
        'colCorrelativo
        '
        Me.colCorrelativo.HeaderText = "Correlative"
        Me.colCorrelativo.Name = "colCorrelativo"
        Me.colCorrelativo.ReadOnly = True
        Me.colCorrelativo.Width = 105
        '
        'colTipoCambio
        '
        Me.colTipoCambio.HeaderText = "Rate"
        Me.colTipoCambio.Name = "colTipoCambio"
        Me.colTipoCambio.Visible = False
        Me.colTipoCambio.Width = 67
        '
        'frmProduccionNSM
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(804, 549)
        Me.Controls.Add(Me.panelDocumento)
        Me.Controls.Add(Me.panelListaPrincipal)
        Me.Controls.Add(Me.BarraTitulo1)
        Me.Controls.Add(Me.Encabezado1)
        Me.Margin = New System.Windows.Forms.Padding(4)
        Me.Name = "frmProduccionNSM"
        Me.Text = "frmProduccionNSM"
        Me.panelListaPrincipal.ResumeLayout(False)
        CType(Me.dgLista, System.ComponentModel.ISupportInitialize).EndInit()
        Me.panelFecha.ResumeLayout(False)
        Me.panelFecha.PerformLayout()
        Me.panelDocumento.ResumeLayout(False)
        Me.panelDetalle.ResumeLayout(False)
        CType(Me.dgDetalle, System.ComponentModel.ISupportInitialize).EndInit()
        Me.panelBotones.ResumeLayout(False)
        Me.panelEncabezado.ResumeLayout(False)
        Me.panelEncabezado.PerformLayout()
        Me.panelTipo.ResumeLayout(False)
        Me.panelTipo.PerformLayout()
        Me.panelAbajo.ResumeLayout(False)
        Me.panelAbajo.PerformLayout()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents Encabezado1 As encabezado
    Friend WithEvents BarraTitulo1 As BarraTitulo
    Friend WithEvents panelListaPrincipal As Panel
    Friend WithEvents dgLista As DataGridView
    Friend WithEvents panelFecha As Panel
    Friend WithEvents botonActualizar As Button
    Friend WithEvents dtpFin As DateTimePicker
    Friend WithEvents etiquetaFin As Label
    Friend WithEvents dtpInicio As DateTimePicker
    Friend WithEvents checkFecha As System.Windows.Forms.CheckBox
    Friend WithEvents panelDocumento As Panel
    Friend WithEvents panelEncabezado As Panel
    Friend WithEvents botonQuitar As Button
    Friend WithEvents botonAgregar As Button
    Friend WithEvents botonMoneda As Button
    Friend WithEvents celdaIdMoneda As TextBox
    Friend WithEvents celdaMoneda As TextBox
    Friend WithEvents etiquetaMoneda As Label
    Friend WithEvents celdaTasa As TextBox
    Friend WithEvents etiquetaTasa As Label
    Friend WithEvents celdaReferencia As TextBox
    Friend WithEvents Label2 As Label
    Friend WithEvents celdaNumero As TextBox
    Friend WithEvents Label1 As Label
    Friend WithEvents etiquetaAnio As Label
    Friend WithEvents celdaAnio As TextBox
    Friend WithEvents dtpFecha As DateTimePicker
    Friend WithEvents etiquetaFecha As Label
    Friend WithEvents panelDetalle As Panel
    Friend WithEvents dgDetalle As DataGridView
    Friend WithEvents panelBotones As Panel
    Friend WithEvents panelAbajo As Panel
    Friend WithEvents celdaPrecio As TextBox
    Friend WithEvents etiquetaPrecio As Label
    Friend WithEvents celdaTotal As TextBox
    Friend WithEvents etiquetaTotal As Label
    Friend WithEvents celdaPeso As TextBox
    Friend WithEvents etiquetaPeso As Label
    Friend WithEvents checkActivar As System.Windows.Forms.CheckBox
    Friend WithEvents rbSpandex As RadioButton
    Friend WithEvents rbRayon As RadioButton
    Friend WithEvents rbPoly As RadioButton
    Friend WithEvents rbCotton As RadioButton
    Friend WithEvents rbMezcla As RadioButton
    Friend WithEvents botonPolizaC As Button
    Friend WithEvents botonPO As Button
    Friend WithEvents celdaPO As TextBox
    Friend WithEvents celdaidAñoPO As TextBox
    Friend WithEvents celdaidPONumero As TextBox
    Friend WithEvents colCatalogo As DataGridViewTextBoxColumn
    Friend WithEvents colAnio As DataGridViewTextBoxColumn
    Friend WithEvents colNumber As DataGridViewTextBoxColumn
    Friend WithEvents colDate As DataGridViewTextBoxColumn
    Friend WithEvents colReferencia As DataGridViewTextBoxColumn
    Friend WithEvents colProducto As DataGridViewTextBoxColumn
    Friend WithEvents celdaSaldo As TextBox
    Friend WithEvents panelTipo As Panel
    Friend WithEvents checkDespacharFibra As System.Windows.Forms.CheckBox
    Friend WithEvents celdaLineas As TextBox
    Friend WithEvents Label3 As Label
    Friend WithEvents etiquetaPO As Label
    Friend WithEvents colRefAnio As DataGridViewTextBoxColumn
    Friend WithEvents colRefCatalogo As DataGridViewTextBoxColumn
    Friend WithEvents colRefNum As DataGridViewTextBoxColumn
    Friend WithEvents colCodigo As DataGridViewTextBoxColumn
    Friend WithEvents colLinea As DataGridViewTextBoxColumn
    Friend WithEvents colMarca As DataGridViewTextBoxColumn
    Friend WithEvents colDescripcion As DataGridViewTextBoxColumn
    Friend WithEvents colPrecio As DataGridViewTextBoxColumn
    Friend WithEvents colCantidad As DataGridViewTextBoxColumn
    Friend WithEvents colPrecioMedida As DataGridViewTextBoxColumn
    Friend WithEvents colTotal As DataGridViewTextBoxColumn
    Friend WithEvents colidMedida As DataGridViewTextBoxColumn
    Friend WithEvents colMedida As DataGridViewTextBoxColumn
    Friend WithEvents colReferencia1 As DataGridViewTextBoxColumn
    Friend WithEvents colRefLin As DataGridViewTextBoxColumn
    Friend WithEvents colBultoB As DataGridViewTextBoxColumn
    Friend WithEvents colExtra As DataGridViewTextBoxColumn
    Friend WithEvents colExtraPO As DataGridViewTextBoxColumn
    Friend WithEvents colLineaPO As DataGridViewTextBoxColumn
    Friend WithEvents colCorrelativo As DataGridViewTextBoxColumn
    Friend WithEvents colTipoCambio As DataGridViewTextBoxColumn
End Class
