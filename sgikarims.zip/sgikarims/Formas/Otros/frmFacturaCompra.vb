﻿Imports System.ComponentModel
Imports System.Xml
Imports System.IO
Imports System.Xml.XmlText
Imports System.Xml.XmlDataDocument
Public Class frmFacturaCompra

#Region "Miembros"

    Dim strKey As String = STR_VACIO
    Dim logInsertar As Boolean = False
    Dim logConsultar As Boolean = False
    Dim logEditar As Boolean = False
    Dim LogBorrar As Boolean = False
    Const CAT_ORD As Integer = 777
    Dim cfun As New clsFunciones
    Dim intCurDoc As Integer
    Dim clic As Boolean = False
    Dim intmodo As String
    Dim ContarFilas As Integer
    Dim msj As String
    Dim PrecioNet As Double
    Dim Extemporaneo As Boolean = False
    Dim IVAPorcentaje As Double
    Dim logIVA As Boolean = False
    Dim LogNuevo As Boolean
    Dim LogModificar As Boolean
    Dim logConta As Boolean
    Dim NumISR As Integer
    Dim logAnulado As Boolean
    Dim LogProceso As Boolean
    Dim intControlador As Integer = NO_FILA

    Dim Tbl_Documentos As String = "Dcmtos_HDR"
    Dim intBien As Byte = vbEmpty
    Dim intServicio As Byte = 1

    Dim intDocumentoTipo As Integer = INT_CERO

#End Region

#Region "Propiedades"

    Public Property Key As String
        Get
            Return strKey
        End Get
        Set(value As String)
            strKey = value
        End Set
    End Property


#End Region

#Region "Procedimientos"
    'Procedimientos Fel

    Private Function GenerarUUID() As String
        Dim UUID As String
        UUID = System.Guid.NewGuid.ToString.ToUpper
        ' MsgBox(UUID)
        Return UUID
    End Function
    Private Function Pais()
        Dim strSQL2 As String
        Dim COM2 As New MySqlCommand
        Dim conec2 As New MySqlConnection
        Dim intPais As Integer

        strSQL2 = "SELECT e.emp_pais "
        strSQL2 &= "     FROM Empresas e"
        strSQL2 &= "         WHERE e.emp_no = {empresa} "

        strSQL2 = Replace(strSQL2, "{empresa}", Sesion.IdEmpresa)
        conec2 = New MySqlConnection(strConexion)
        conec2.Open()
        COM2 = New MySqlCommand(strSQL2, conec2)
        Using conec2
            intPais = COM2.ExecuteScalar
            COM2.Dispose()
            COM2 = Nothing
            conec2.Close()
            conec2.Dispose()
            conec2 = Nothing
            System.GC.Collect()
        End Using

        Return intPais
    End Function
    Public Sub ImprimirPDFGenerado(ByVal IP As String, ByVal strUsuario As String, ByVal strContrasena As String, ByVal strRuta As String)
        Dim Proceso As New Process
        Dim openSave As New SaveFileDialog
        Dim OpenFile As New OpenFileDialog
        Dim strGuardar As String = STR_VACIO
        Dim strArchivo As String = STR_VACIO
        Try
            strGuardar = ".pdf"
            openSave.InitialDirectory = "c:\"
            openSave.Filter = "All Files|*.*"
            openSave.RestoreDirectory = True
            openSave.AddExtension = False
            openSave.FileName = "FESPFel" & celdaNumOc.Text & strGuardar & strGuardar
            If openSave.ShowDialog = System.Windows.Forms.DialogResult.OK Then
                strArchivo = openSave.FileName
                If checkActive.Checked = True Then
                    My.Computer.Network.DownloadFile("file://" & IP & strRuta & "FESPFel" & celdaNumOc.Text & ".pdf" & "", strArchivo, strUsuario, strContrasena, True, 9000, True)
                Else
                    My.Computer.Network.DownloadFile("file://" & IP & strRuta & "\FelAnulacionESP" & celdaNumOc.Text & ".pdf" & "", strArchivo, strUsuario, strContrasena, True, 9000, True)
                End If
            End If
            'Proceso.StartInfo.FileName = "\\192.168.4.142\Archivos_Fel" & "\Fel" & celdaNumero.Text & ".pdf"
            'Proceso.StartInfo.Arguments = ""
            'Proceso.Start()

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub
    Public Sub CargarDatosFel()
        Dim strSQL As String = STR_VACIO
        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader
        Dim strCadena As String = STR_VACIO
        Dim arrayCadena() As String
        Try
            strSQL = "SELECT f.FechaEmisionDocumento,f.FechaHoraCertificacion,f.Serie, f.NumeroAutorizacion ,f.UUID "
            strSQL &= "  FROM Fel f  "
            strSQL &= "     WHERE f.Empresa = {empresa} AND f.catalogo = {catalogo} AND f.Anio = {anio} AND f.Numero = {numero} "
            strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
            strSQL = Replace(strSQL, "{catalogo}", 44)
            strSQL = Replace(strSQL, "{anio}", celdaAnioOc.Text)
            strSQL = Replace(strSQL, "{numero}", celdaNumOc.Text)
            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSQL, CON)
            REA = COM.ExecuteReader
            If REA.HasRows Then
                Do While REA.Read
                    celdaFechaEmisionDocumento.Text = REA.GetString("FechaEmisionDocumento")
                    celdaFechaHoraCertificacion.Text = REA.GetString("FechaHoraCertificacion")
                    celdaSerieFel.Text = REA.GetString("Serie")
                    celdaUUID.Text = REA.GetString("UUID")
                    strCadena = REA.GetString("Serie")
                    arrayCadena = strCadena.Split("-".ToCharArray)
                    etiquetaSerieF.Text = arrayCadena(INT_CERO)
                    etiquetaAutorizacion.Text = REA.GetString("NumeroAutorizacion")
                    etiquetaSerieF.Visible = True
                    etiquetaAutorizacion.Visible = True
                Loop
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub
    Private Function EnvioProyecto(ByVal strError As String) As Boolean
        Dim logEnvio As Boolean = False
        Dim mail As New clsCorreo
        Dim strSQL As String = STR_VACIO
        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader
        Dim correo As New Tablas.TCORREO
        Dim j As Integer
        Dim K As Integer
        Dim conec As New MySqlConnection
        Dim COM1 As MySqlCommand
        Dim strInsert As String = STR_VACIO
        Dim strUsuario As String
        Dim strSQL1 As String
        Dim strConexion2 As String
        Dim strTemporal As String = STR_VACIO
        Dim strTexto As String = STR_VACIO
        Dim ArrayServer() As String
        Dim ArrayAuxiliar() As String
        Try

            ArrayServer = strConexion.Split(";".ToCharArray)
            strConexion2 = "server={server};uid={user};password={password};database={database} ;Allow User Variables=True"
            ArrayAuxiliar = ArrayServer(INT_CERO).Split("=".ToCharArray)

            If ArrayAuxiliar(INT_UNO) = "192.168.4.9" Then
                strConexion2 = Replace(strConexion2, "{server}", MAIL_HOST)
                strConexion2 = Replace(strConexion2, "port={puerto};", vbNullString)
            Else
                strConexion2 = Replace(strConexion2, "{server}", MAIL_HOST_REMOTO)
                strConexion2 = Replace(strConexion2, "{puerto}", "3308")
            End If

            strConexion2 = Replace(strConexion2, "{user}", MAIL_USER)
            strConexion2 = Replace(strConexion2, "{password}", MAIL_PASS)
            strConexion2 = Replace(strConexion2, "{database}", MAIL_BASE)

            strSQL1 = " Select   CONCAT(per_nombre1 ,'  ' ,per_apellido1) Puesto  FRom Personal  WHERE per_codigo={usuario} "
            strSQL1 = Replace(strSQL1, "{usuario}", Sesion.idUsuario)
            conec = New MySqlConnection(strConexion)
            conec.Open()
            COM1 = New MySqlCommand(strSQL1, conec)
            strUsuario = COM1.ExecuteScalar
            conec.Close()
            conec.Dispose()
            conec = Nothing
            System.GC.Collect()

            strTexto &= " <tr> <td style='border-left:solid black 1px;border-right: solid black 1px;background-color:  #1976D2; color: white; padding:2px 5px; font-family: Tahoma, Arial;font-size:  7pt;width: 3.5cm;text-align: Left'>  USUARIO: </td> <td colspan='3' style='border-right: solid black 1px; border-bottom: solid black 1px;padding: 2px 5px; font-family: Tahoma, Arial;font-size:  7pt;width: 3.5cm;'>" & strUsuario & "</td> </tr>"
            strTexto &= " <tr> <td style='border-left:solid black 1px;border-right: solid black 1px;background-color:  #1976D2; color: white; padding:2px 5px; font-family: Tahoma, Arial;font-size:  7pt;width: 3.5cm;text-align: Left'>  FECHA INGRESO : </td> <td colspan='3' style='border-right: solid black 1px; border-bottom: solid black 1px;padding: 2px 5px; font-family: Tahoma, Arial;font-size:  7pt;width: 3.5cm;'> " & Now() & "</td> </tr>"
            strTexto &= "   <tr> <td style='border-left:solid black 1px;border-right: solid black 1px;background-color: #1976D2; color: white; padding:2px 5px; font-family: Tahoma, Arial;font-size: 7pt;width: 3.5cm;text-align: left'>  CONTRATO DE : </td> <td colspan='3' style='border-right: solid black 1px; border-bottom:solid black 1px;padding:2px 5px; font-family: Tahoma, Arial;font-size: 7pt;width: 3.5cm;'> " & celdaNumero.Text & " </td> </tr>"
            strTexto = Replace(strTexto, vbCrLf, "<br>")
            strTexto = Replace(strTexto, "'", Chr(34))

            strTemporal &= " <html> <BODY> <table cellspacing=0 > <tr> <td colspan='4'; style=' border:solid White 0px; background-color: #FFFFFF; color: Black; padding:2px 5px; font-family: Tahoma, Arial;font-size: 10pt;width: 3.5cm;text-align: center;border-bottom:solid black 1px; border-right: solid black 1px;border-left: solid black 1px;border-top:solid black 1px;font-weight:bold;'> " & strError & "</td> </tr> "
            strTemporal = Replace(strTemporal, "'", Chr(34))
            '  strSQL = SQLCorreo()
            ' MyCnn.CONECTAR = strConexion
            'COM = New MySqlCommand(strSQL, CON)
            ' REA = COM.ExecuteReader()
            'If REA.HasRows Then
            'Do While REA.Read
            strInsert &= ("INSERT INTO MailServer.Correo (idCorreo,Destinatario,Asunto,Contenido,Estado) Values(0,'" & "tisoportegt@grupokarims.com" & "',' Alerta de Seguridad ' ,'" & strTemporal & vbCrLf & strTexto & " </table> </body> </html>',0); ")
            '    Loop
            'COM = Nothing
            ' End If
            MyCnn.CONECTAR = strConexion2
            COM = New MySqlCommand(strInsert, CON)
            COM.ExecuteNonQuery()
            COM.Dispose()
            System.GC.Collect()
            logEnvio = True




        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        Return logEnvio
    End Function
    Public Function AnularFel(ByVal strSerieUUID As String, ByVal strFechaEmsionDocumento As String, ByVal IP As String, ByVal strUsuario As String, ByVal strContrasena As String, ByVal strRuta As String) As Boolean
        Dim logResultado As Boolean = True
        Dim strpath As String = System.Windows.Forms.Application.StartupPath & "\SolicitaToken.xml"
        Dim strpathF As String = System.Windows.Forms.Application.StartupPath & "\contenidoA.xml"
        Dim strpathR As String = System.Windows.Forms.Application.StartupPath & "\AnulacionFactESP.xml"
        Dim strpathPDF As String = System.Windows.Forms.Application.StartupPath & "\PDFAESP" & celdaNumOc.Text & ".xml"
        Dim strCodigo64BitsPDF As String = STR_VACIO
        Dim strSolicitarToken As String = STR_VACIO
        Dim strXMLAnulacion As String = STR_VACIO
        Dim strXMLRegistra As String = STR_VACIO
        Dim strXMLFinal As String = STR_VACIO
        Dim strXMLPDF As String = STR_VACIO
        Dim strNit As String = STR_VACIO
        Dim strValidarAnulacion As String = STR_VACIO
        Dim strFechaAnulacion As String = STR_VACIO
        Dim fs As FileStream
        Dim t As New Fel
        Dim strToken As String = STR_VACIO
        Dim strError As String = STR_VACIO
        Dim sw As StreamWriter
        Dim xml_Documento As New XmlDocument
        Dim nodos_lista As XmlNodeList
        Try
            If cFunciones.ExisteArchivo(strpath) Then
                'Solicita Token en el Web Service 
                strSolicitarToken = t.SolicitarToken1(strpath)
                If File.Exists(System.Windows.Forms.Application.StartupPath & "\TokenD.xml") Then
                    ' Abre Archivo TokenD.xml
                    sw = New StreamWriter(System.Windows.Forms.Application.StartupPath & "\TokenD.xml")
                    ' Copia el Token devuelvo del Web Service 
                    sw.Write(strSolicitarToken)
                    ' cierra el archivo 
                    sw.Close()
                    ' Carga el Archivo TokenD.xml
                    xml_Documento.Load(System.Windows.Forms.Application.StartupPath & "\TokenD.xml")
                    nodos_lista = xml_Documento.SelectNodes("/SolicitaTokenResponse")
                    'Iniciamos el ciclo de lectura
                    For Each nodo In nodos_lista
                        ' Asigna el Token Devuelto por Web Service 
                        strToken = nodo.ChildNodes.Item(1).InnerText
                    Next
                Else
                    'Crea Archivo TokenD.xml
                    fs = File.Create(System.Windows.Forms.Application.StartupPath & "\TokenD.xml")
                    fs.Close()
                    'Abre Archivo TokenD.xml
                    sw = New StreamWriter(System.Windows.Forms.Application.StartupPath & "\TokenD.xml")
                    ' Copia el Token devuelvo del Web Service 
                    sw.Write(strSolicitarToken)
                    ' Carga el Archivo TokenD.xml
                    xml_Documento.Load(System.Windows.Forms.Application.StartupPath & "\TokenD.xml")
                    nodos_lista = xml_Documento.SelectNodes("/SolicitaTokenResponse")
                    'Iniciamos el ciclo de lectura
                    For Each nodo In nodos_lista
                        ' Asigna el Token Devuelto por Web Service 
                        strToken = nodo.ChildNodes.Item(1).InnerText
                    Next
                    sw.Close()
                End If
            End If
            strNit = celdaNIT.Text
            strNit = Replace(strNit, " ", "")

            strFechaAnulacion = Now().ToString("yyyy-MM-ddTHH:mm:ss") & "-06:00"
            ' XML Firma Electronica 
            strXMLAnulacion &= "<?xml version='1.0' encoding='UTF-8'?>" & vbCrLf
            strXMLAnulacion &= "<FirmaDocumentoRequest id='A50E4C76-6084-11E9-8647-D663BD873D93'>" & vbCrLf
            strXMLAnulacion &= "<xml_dte>" & vbCrLf
            strXMLAnulacion &= "<![CDATA[ " & vbCrLf
            ' XML ANULACION
            strXMLAnulacion &= " <ns:GTAnulacionDocumento Version='0.1' xmlns:ns='http://www.sat.gob.gt/dte/fel/0.1.0' xmlns:xd='http://www.w3.org/2000/09/xmldsig#'>" & vbCrLf
            strXMLAnulacion &= "<ns:SAT>" & vbCrLf
            strXMLAnulacion &= "<ns:AnulacionDTE ID='DatosCertificados'>" & vbCrLf
            strXMLAnulacion &= "<ns:DatosGenerales ID='DatosAnulacion'" & vbCrLf
            strXMLAnulacion &= "NumeroDocumentoAAnular='" & celdaSerieFel.Text & "'" & vbCrLf
            strXMLAnulacion &= "NITEmisor='90028481' IDReceptor='" & strNit & "'" & vbCrLf
            strXMLAnulacion &= "FechaEmisionDocumentoAnular='" & celdaFechaEmisionDocumento.Text & "'" & vbCrLf
            strXMLAnulacion &= "FechaHoraAnulacion='" & strFechaAnulacion & "' MotivoAnulacion='Cancelacion'/>" & vbCrLf
            strXMLAnulacion &= "</ns:AnulacionDTE>" & vbCrLf
            strXMLAnulacion &= "</ns:SAT>" & vbCrLf
            strXMLAnulacion &= "</ns:GTAnulacionDocumento>" & vbCrLf
            'Fin Fima Electronica 
            strXMLAnulacion &= "]]>" & vbCrLf
            strXMLAnulacion &= "</xml_dte>" & vbCrLf
            strXMLAnulacion &= "</FirmaDocumentoRequest>" & vbCrLf

            sw = New StreamWriter(System.Windows.Forms.Application.StartupPath & "\contenidoA.xml")
            sw.Write(strXMLAnulacion)
            sw.Close()
            fs = File.Create(System.Windows.Forms.Application.StartupPath & "\firma.xml")
            fs.Close()
            sw = New StreamWriter(System.Windows.Forms.Application.StartupPath & "\firma.xml")
            sw.Write(t.FirmaElectronica(strpathF, strToken, logResultado))
            If logResultado = False Then
                MsgBox("fallo en la firma electronica")
                Exit Function
            End If
            sw.Close()
            xml_Documento.Load(System.Windows.Forms.Application.StartupPath & "\firma.xml")
            nodos_lista = xml_Documento.SelectNodes("/FirmaDocumentoResponse")
            'Iniciamos el ciclo de lectura
            For Each nodo In nodos_lista
                '    Asigna el Token Devuelto por Web Service 
                strXMLRegistra = "<?xml version='1.0' encoding='UTF-8'?>" & vbCrLf & "<AnulaDocumentoXMLRequest id='" & celdaSerieFel.Text & "'>" & vbCrLf & "<xml_dte><![CDATA[" & nodo.ChildNodes.Item(0).InnerText & " ]]></xml_dte>" & vbCrLf & "</AnulaDocumentoXMLRequest>"
            Next
            fs = File.Create(System.Windows.Forms.Application.StartupPath & "\AnulacionFactESP.xml")
            fs.Close()
            sw = New StreamWriter(System.Windows.Forms.Application.StartupPath & "\AnulacionFactESP.xml")
            sw.Write(strXMLRegistra)
            sw.Close()
            fs = File.Create(System.Windows.Forms.Application.StartupPath & "\AnulacionFelESP" & celdaNumOc.Text & ".xml")
            fs.Close()
            sw = New StreamWriter(System.Windows.Forms.Application.StartupPath & "\AnulacionFelESP" & celdaNumOc.Text & ".xml")
            ' Registra la factura Especial ya firmado
            strXMLRegistra = t.AnulaDocumento(strpathR, strToken, logResultado)
            If logResultado = False Then
                MsgBox("Fallo en el Anula documento de Fel ")
                strError &= "Fallo en el Anula documento de Fel"
                EnvioProyecto(strError)
                Exit Function
            End If
            sw.Write(strXMLRegistra)
            sw.Close()
            xml_Documento.Load(System.Windows.Forms.Application.StartupPath & "\AnulacionFelESP" & celdaNumOc.Text & ".xml")
            nodos_lista = xml_Documento.SelectNodes("/AnulaDocumentoXMLResponse")
            'iniciamos el ciclo de lectura
            For Each nodo In nodos_lista
                ' asigna el token devuelto por web service 
                strValidarAnulacion = nodo.ChildNodes.Item(1).InnerText
            Next
            If strValidarAnulacion = INT_UNO Then
                MsgBox("La factura registrada se encuentra anulado")
                logResultado = False
            Else
                MsgBox("La factura  se ha anulado correctamente ")
                logResultado = True
                ' Metodo para subir el archivo en una compartida
                'My.Computer.Network.UploadFile(system.Windows.Forms.Application.StartupPath & "\AnulacionFelESP" & celdaNumOc.Text & ".xml", "file://" & IP & strRuta & "\AnulacionFelESP" & celdaNumOc.Text & ".xml" & "", strUsuario, strContrasena, True, 9000, True)
                '' se modifica el 29/01/2025
                Try
                    ' Intento la primera subida con la ruta de red
                    My.Computer.Network.UploadFile(System.Windows.Forms.Application.StartupPath & "\AnulacionFelESP" & celdaNumOc.Text & ".xml", "file://" & IP & strRuta & "\AnulacionFelESP" & celdaNumOc.Text & ".xml" & "", strUsuario, strContrasena, True, 9000, True)
                Catch ex1 As Exception
                    MessageBox.Show("Error al subir el archivo: " & ex1.Message)
                End Try
                Try
                    ' Si falla, intento la segunda subida con la ruta local
                    My.Computer.Network.UploadFile(System.Windows.Forms.Application.StartupPath & "\AnulacionFelESP" & celdaNumero.Text & ".xml", "C:\Archivos_Fel\AnulacionFelESP" & celdaNumero.Text & ".xml" & "", strUsuario, strContrasena, True, 9000, True)
                Catch ex2 As Exception
                    MessageBox.Show("Error al guardar archivo: " & ex2.Message)
                End Try
            End If
            'Creacion de XML para consumir Webservice retorna pdf
            strXMLPDF &= "<?xml version='1.0' encoding='UTF-8'?>" & vbCrLf
            strXMLPDF &= "<RetornaPDFRequest>" & vbCrLf
            strXMLPDF &= "<uuid>" & celdaSerieFel.Text & "</uuid>" & vbCrLf
            strXMLPDF &= "</RetornaPDFRequest>" & vbCrLf
            fs = File.Create(System.Windows.Forms.Application.StartupPath & "\PDFESP" & celdaNumOc.Text & ".xml")
            fs.Close()
            sw = New StreamWriter(System.Windows.Forms.Application.StartupPath & "\PDFAESP" & celdaNumOc.Text & ".xml")
            sw.Write(strXMLPDF)
            sw.Close()

            fs = File.Create(System.Windows.Forms.Application.StartupPath & "\PDFFinalANESP" & celdaNumOc.Text & ".xml")
            fs.Close()
            sw = New StreamWriter(System.Windows.Forms.Application.StartupPath & "\PDFFinalANESP" & celdaNumOc.Text & ".xml")
            sw.Write(t.RetornaPDF(strpathPDF, strToken))
            sw.Close()
            xml_Documento.Load(System.Windows.Forms.Application.StartupPath & "\PDFFinalANESP" & celdaNumOc.Text & ".xml")
            nodos_lista = xml_Documento.SelectNodes("/RetornaPDFResponse")
            ''Iniciamos el ciclo de lectura
            For Each nodo In nodos_lista
                '    ' Asigna el Codigo 64 Bits
                strCodigo64BitsPDF = nodo.ChildNodes.Item(0).InnerText
            Next
            Dim str As String = strCodigo64BitsPDF
            Dim Base64Byte() As Byte = Convert.FromBase64String(str)
            Dim obj As FileStream = File.Create(System.Windows.Forms.Application.StartupPath & "\FelAnulacionESP" & celdaNumOc.Text & ".pdf")
            obj.Write(Base64Byte, 0, Base64Byte.Length)
            obj.Flush()
            obj.Close()
            ' Metodo para subir el archivo en una compartida
            'My.Computer.Network.UploadFile(system.Windows.Forms.Application.StartupPath & "\FelAnulacionESP" & celdaNumOc.Text & ".pdf", "file://" & IP & strRuta & "\FelAnulacionESP" & celdaNumOc.Text & ".pdf" & "", strUsuario, strContrasena, True, 9000, True)
            '' se modifica el 29/01/2025
            Try
                ' Intento la primera subida con la ruta de red
                My.Computer.Network.UploadFile(System.Windows.Forms.Application.StartupPath & "\FelAnulacionESP" & celdaNumOc.Text & ".pdf", "file://" & IP & strRuta & "\FelAnulacionESP" & celdaNumOc.Text & ".pdf" & "", strUsuario, strContrasena, True, 9000, True)
            Catch ex1 As Exception
                MessageBox.Show("Error al subir el archivo: " & ex1.Message)
            End Try
            Try
                ' Si falla, intento la segunda subida con la ruta local
                My.Computer.Network.UploadFile(System.Windows.Forms.Application.StartupPath & "\FelAnulacionESP" & celdaNumero.Text & ".pdf", "C:\Archivos_Fel\FelAnulacionESP" & celdaNumero.Text & ".pdf" & "", strUsuario, strContrasena, True, 9000, True)
            Catch ex2 As Exception
                MessageBox.Show("Error al guardar archivo: " & ex2.Message)
            End Try

            botonImprimir.Enabled = True
            If MsgBox("Open file PDF ?", MsgBoxStyle.OkCancel, "Info") = MsgBoxResult.Ok Then
                System.Diagnostics.Process.Start(System.Windows.Forms.Application.StartupPath & "\FelAnulacionESP" & celdaNumOc.Text & ".pdf")
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        Return logResultado
    End Function
    Private Function VerificarDocumentoXML(ByRef strToken As String, ByRef strUUID As String) As Integer
        Dim strpath As String = System.Windows.Forms.Application.StartupPath & "\SolicitaToken.xml"
        Dim strVerifica As String = System.Windows.Forms.Application.StartupPath & "\Verifica.xml"
        Dim strSolicitarToken As String = STR_VACIO
        Dim logResultado As Integer
        Dim strResultado As String = STR_VACIO
        Dim strXMLVerificaDocumento As String = STR_VACIO
        Dim t As New Fel
        Dim sw As StreamWriter
        Dim xml_Documento As New XmlDocument
        Dim nodos_lista As XmlNodeList
        Dim fs As FileStream
        If cFunciones.ExisteArchivo(strpath) Then
            'Solicita Token en el Web Service 
            strSolicitarToken = t.SolicitarToken1(strpath)
            If File.Exists(System.Windows.Forms.Application.StartupPath & "\TokenD.xml") Then
                ' Abre Archivo TokenD.xml
                sw = New StreamWriter(System.Windows.Forms.Application.StartupPath & "\TokenD.xml")
                ' Copia el Token devuelvo del Web Service 
                sw.Write(strSolicitarToken)
                ' cierra el archivo 
                sw.Close()
                ' Carga el Archivo TokenD.xml
                xml_Documento.Load(System.Windows.Forms.Application.StartupPath & "\TokenD.xml")
                nodos_lista = xml_Documento.SelectNodes("/SolicitaTokenResponse")
                'Iniciamos el ciclo de lectura
                For Each nodo In nodos_lista
                    ' Asigna el Token Devuelto por Web Service 
                    strToken = nodo.ChildNodes.Item(1).InnerText
                Next
            Else
                'Crea Archivo TokenD.xml
                fs = File.Create(System.Windows.Forms.Application.StartupPath & "\TokenD.xml")
                fs.Close()
                'Abre Archivo TokenD.xml
                sw = New StreamWriter(System.Windows.Forms.Application.StartupPath & "\TokenD.xml")
                ' Copia el Token devuelvo del Web Service 
                sw.Write(strSolicitarToken)
                ' Carga el Archivo TokenD.xml
                xml_Documento.Load(System.Windows.Forms.Application.StartupPath & "\TokenD.xml")
                nodos_lista = xml_Documento.SelectNodes("/SolicitaTokenResponse")
                'Iniciamos el ciclo de lectura
                For Each nodo In nodos_lista
                    ' Asigna el Token Devuelto por Web Service 
                    strToken = nodo.ChildNodes.Item(1).InnerText
                Next
                sw.Close()
            End If
        End If
        If celdaUUID.Text <> STR_VACIO Then
            strUUID = celdaUUID.Text
        Else
            strUUID = GenerarUUID()
            celdaUUID.Text = strUUID
        End If
        'strUUID = "4DFFD5BC-AC7E-4779-8D4C-8C3903322993"
        strXMLVerificaDocumento &= "<?xml version='1.0' encoding='UTF-8'?>" & vbCrLf
        strXMLVerificaDocumento &= "<VerificaDocumentoRequest id='" & strUUID & "'/>" & vbCrLf

        fs = File.Create(System.Windows.Forms.Application.StartupPath & "\Verifica.xml")
        fs.Close()
        sw = New StreamWriter(System.Windows.Forms.Application.StartupPath & "\Verifica.xml")
        sw.Write(strXMLVerificaDocumento)
        sw.Close()

        fs = File.Create(System.Windows.Forms.Application.StartupPath & "\Validacion.xml")
        fs.Close()
        sw = New StreamWriter(System.Windows.Forms.Application.StartupPath & "\Validacion.xml")
        sw.Write(t.VerificaDocumento(strVerifica, strToken))
        sw.Close()
        xml_Documento.Load(System.Windows.Forms.Application.StartupPath & "\Validacion.xml")
        nodos_lista = xml_Documento.SelectNodes("/VerificaDocumentoResponse")
        ''Iniciamos el ciclo de lectura
        For Each nodo In nodos_lista
            '    ' Asigna el Codigo 64 Bits
            strResultado = nodo.ChildNodes.Item(0).InnerText
            If strResultado = "0" Then
                logResultado = INT_CERO
                GuardarFel(STR_VACIO, STR_VACIO, STR_VACIO, STR_VACIO, STR_VACIO, strUUID)
            Else
                logResultado = INT_UNO
            End If
        Next


        Return logResultado
    End Function
    Public Sub GuardarFel(ByVal strFechaEmisionDocumento As String, ByVal strFechaHoraCertificacion As String, ByVal strSerie As String, ByVal strNumeroAutorizacion As String, ByVal strIncoterm As String, ByVal strUUID As String)
        Dim cFel As New Tablas.TFEL
        Try
            cFel.CONEXION = strConexion
            cFel.EMPRESA = Sesion.IdEmpresa
            cFel.CATALOGO = 44
            cFel.ANIO = celdaAnioOc.Text
            cFel.NUMERO = celdaNumOc.Text
            cFel.FECHAEMISIONDOCUMENTO = strFechaEmisionDocumento
            cFel.FECHAHORACERTIFICACION = strFechaHoraCertificacion
            cFel.SERIE = strSerie
            cFel.NUMEROAUTORIZACION = strNumeroAutorizacion
            cFel.INCOTERM = strIncoterm
            cFel.UUID = strUUID
            If cFel.PINSERT() = False Then
                MsgBox(cFel.MERROR.ToString & "Could not save the document", MsgBoxStyle.Critical)
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub
    Public Sub ActualizarFel(ByVal strFechaEmisionDocumento As String, ByVal strFechaHoraCertificacion As String, ByVal strSerie As String, ByVal strNumeroAutorizacion As String, ByVal strUUID As String)
        Dim cFel As New Tablas.TFEL
        Try
            cFel.CONEXION = strConexion
            cFel.EMPRESA = Sesion.IdEmpresa
            cFel.CATALOGO = 44
            cFel.ANIO = celdaAnioOc.Text
            cFel.NUMERO = celdaNumOc.Text
            cFel.FECHAEMISIONDOCUMENTO = strFechaEmisionDocumento
            cFel.FECHAHORACERTIFICACION = strFechaHoraCertificacion
            cFel.SERIE = strSerie
            cFel.NUMEROAUTORIZACION = strNumeroAutorizacion
            cFel.INCOTERM = STR_VACIO
            cFel.UUID = strUUID
            If cFel.PUPDATE() = False Then
                MsgBox(cFel.MERROR.ToString & "Could not save the document", MsgBoxStyle.Critical)
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub
    Private Function VerificarAcceso(ByRef IP As String, ByRef strUsuario As String, ByRef strContrasena As String, ByRef strRuta As String) As Boolean
        Dim COM As MySqlCommand
        Dim logVerificar As Boolean
        Dim strSQL As String = STR_VACIO
        Dim REA As MySqlDataReader
        Try
            strSQL = " SELECT c.cat_desc IP , c.cat_ext usuario, c.cat_sist Ruta , c.cat_dato Contrasena  "
            strSQL &= "     FROM Catalogos c "
            strSQL &= "         WHERE c.cat_clase = 'felFESP' AND c.cat_clave = 'FacturaEspecial' "
            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSQL, CON)
            REA = COM.ExecuteReader
            If REA.HasRows Then
                Do While REA.Read
                    IP = REA.GetString("IP")
                    strUsuario = REA.GetString("usuario")
                    strContrasena = REA.GetString("Contrasena")
                    strRuta = REA.GetString("Ruta")
                Loop
            End If


            If My.Computer.Network.Ping(IP) Then
                MessageBox.Show("Conexion correcta", "", MessageBoxButtons.OK, MessageBoxIcon.Information)
                logVerificar = True
            Else
                MessageBox.Show("Conexion erronea", "", MessageBoxButtons.OK, MessageBoxIcon.Error)
                logVerificar = False
            End If
        Catch ex As Net.NetworkInformation.PingException
            MessageBox.Show("Ocurrió el siguiente error:" & vbCrLf & ex.Message, "", MessageBoxButtons.OK, MessageBoxIcon.Error)
            logVerificar = False
        Catch ex As Exception
            MessageBox.Show("Ocurrió el siguiente error:" & vbCrLf & ex.Message, "", MessageBoxButtons.OK, MessageBoxIcon.Error)
            logVerificar = False
        End Try
        Return logVerificar
    End Function
    Public Function ImpresionFel(ByVal intAño As Integer, ByVal intNumero As Integer, ByVal strToken As String, ByVal strUUID As String, ByVal IP As String, ByVal strUsuario As String, ByVal strContrasena As String, ByVal strRuta As String) As Boolean
        Dim strpathF As String = System.Windows.Forms.Application.StartupPath & "\contenido.xml"
        Dim strpathR As String = System.Windows.Forms.Application.StartupPath & "\RegistraDocumento.xml"
        Dim strpathPDF As String = System.Windows.Forms.Application.StartupPath & "\FESPPDF" & celdaNumOc.Text & ".xml"
        Dim sw As StreamWriter
        Dim xml_Documento As New XmlDocument
        Dim nodos_lista As XmlNodeList
        Dim Horario As String = STR_VACIO
        Dim strXML As String = STR_VACIO
        Dim strXMLRegistra As String = STR_VACIO
        Dim strXMLFinal As String = STR_VACIO
        Dim strXMLFel As String = STR_VACIO
        Dim strXMLPDF As String = STR_VACIO
        Dim strXMLDTL As String = STR_VACIO
        Dim fs As FileStream
        Dim t As New Fel
        Dim strSQL As String = STR_VACIO
        Dim strMoneda As String = STR_VACIO
        Dim strNit As String = STR_VACIO
        Dim dblGranTotal As Double = INT_CERO
        Dim dblISRRetenido As Double = INT_CERO
        Dim dblTotalISRRetenido As Double = INT_CERO
        Dim dblIVARetenido As Double = INT_CERO
        Dim dblTotalIVaRetenido As Double = INT_CERO
        Dim dblTotalImpuesto As Double = INT_CERO
        Dim dblTotalRetenido As Double = INT_CERO
        Dim logEncabezado As Boolean = False
        Dim logResultado As Boolean = True
        Dim strFechaHoraCertificacion As String = STR_VACIO
        Dim strNitCertificador As String = STR_VACIO
        Dim strSerieDocumento As String = STR_VACIO
        Dim strNumeroAutorizacion As String = STR_VACIO
        Dim strCadenaEncontrada As String = STR_VACIO
        Dim arrayCadena() As String
        Dim strCodigo64BitsPDF As String = STR_VACIO
        Dim vlcResultado As String = STR_VACIO
        Dim strError As String = STR_VACIO
        ' Especifica el criterio
        Dim vlcCriterio As String = "dte:NumeroAutorizacion"
        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader
        Try
            botonImprimir.Enabled = False
            Horario = Now().ToString("yyyy-MM-ddTHH:mm:ss")

            strSQL = "SELECT l1.Clasificacion,l1.Linea ,l1.Cantidad,l1.PaisReceptor,l1.DireccionCliente,l1.CodigoMoneda,l1.NombreComercial,l1.DireccionEmisor,l1.dia ,l1.mes , l1.ano , l1.proveedor , 
                        l1.dic, l1.nit, l1.concepto , l1.precio , l1.total , l1.hechopor , l1.ISRRetenido,l1.IVA, 
                        ROUND((l1.IVA * l1.ISR),2) IVARetenido , l1.Moneda 
                        FROM  ( 
	                        select d.DDoc_RF1_Num Clasificacion,d.DDoc_Doc_Lin Linea ,d.DDoc_Prd_QTY Cantidad,cp.cat_clave PaisReceptor,p.pro_direccion DireccionCliente,cc.cat_num CodigoMoneda,
	                        e.emp_razon NombreComercial,e.emp_direccion DireccionEmisor,day(h.HDoc_Doc_Fec ) dia , month(h.HDoc_Doc_Fec ) mes, year(h.HDoc_Doc_Fec ) ano, p.pro_proveedor  proveedor, 
	                        ifnull(p.pro_direccion, 'N/A') dic, p.pro_nit nit , d.DDoc_Prd_Des concepto , d.DDoc_Prd_NET precio, (d.DDoc_Prd_QTY * d.DDoc_Prd_NET ) total, h.HDoc_Usuario hechopor,
	                        ifnull(hISR.HDoc_RF1_Dbl,0) ISRRetenido , ROUND(d.DDoc_Prd_NET  / (c.cat_sist / 100 + 1),2) IVA, (c.cat_sist / 100) ISR, cc.cat_clave Moneda 
	                        from Dcmtos_HDR h 
	                        left join Dcmtos_DTL d on d.DDoc_Sis_Emp = h.HDoc_Sis_Emp and d.DDoc_Doc_Cat = h.HDoc_Doc_Cat and d.DDoc_Doc_Ano = h.HDoc_Doc_Ano and d.DDoc_Doc_Num = h.HDoc_Doc_Num 
	                        LEFT JOIN Dcmtos_HDR hh ON hh.HDoc_Sis_Emp = h.HDoc_Sis_Emp AND hh.HDoc_Pro_DCat = h.HDoc_Doc_Cat  AND hh.HDoc_Pro_DNum = h.HDoc_Doc_Num  AND hh.HDoc_Emp_Cod = h.HDoc_Emp_Cod AND hh.HDoc_Ant_Com=1
	                        LEFT JOIN Dcmtos_HDR hISR ON hISR.HDoc_Sis_Emp = h.HDoc_Sis_Emp AND hISR.HDoc_Pro_DCat = h.HDoc_Doc_Cat  AND hISR.HDoc_Pro_DNum = h.HDoc_Doc_Num  AND hISR.HDoc_Emp_Cod = h.HDoc_Emp_Cod AND hISR.HDoc_Ant_Com=0
	                        LEFT JOIN Catalogos c ON c.cat_clase = 'Impuestos' AND c.cat_clave = 'IVA' AND c.cat_sisemp = {empresa} 
	                        LEFT JOIN Catalogos cc ON cc.cat_num = h.HDoc_Doc_Mon  AND cc.cat_clase = 'Monedas'
	                        left join Proveedores p on p.pro_sisemp = h.HDoc_Sis_Emp and p.pro_codigo = h.HDoc_Emp_Cod  	
	                        LEFT JOIN Catalogos cp ON cp.cat_num = p.pro_pais AND cp.cat_clase = 'Paises' 
	                        LEFT JOIN Empresas e ON e.emp_no = h.HDoc_Sis_Emp 
	                        where h.HDoc_Sis_Emp = {empresa} and h.HDoc_Doc_Cat = 44 and h.HDoc_Doc_Ano = {ano} and h.HDoc_Doc_Num = {numero} -- AND hh.HDoc_DR1_Num NOT LIKE '%IVA%'  
	                        GROUP BY h.HDoc_Doc_Ano , h.HDoc_Doc_Num 
                        ) l1"

            'strSQL &= " SELECT l1.Clasificacion,l1.Linea ,l1.Cantidad,l1.PaisReceptor,l1.DireccionCliente,l1.CodigoMoneda,l1.NombreComercial,l1.DireccionEmisor,l1.dia ,l1.mes , l1.ano , l1.proveedor , l1.dic, l1.nit, l1.concepto , l1.precio , l1.total , l1.hechopor , l1.ISRRetenido,l1.IVA, "
            'strSQL &= "     ROUND((l1.IVA * l1.ISR),2) IVARetenido , l1.Moneda "
            'strSQL &= "         FROM  ( "
            'strSQL &= "             select d.DDoc_RF1_Num Clasificacion,d.DDoc_Doc_Lin Linea ,d.DDoc_Prd_QTY Cantidad,cp.cat_clave PaisReceptor,p.pro_direccion DireccionCliente,cc.cat_num CodigoMoneda,e.emp_razon NombreComercial,e.emp_direccion DireccionEmisor,day(h.HDoc_Doc_Fec ) dia , month(h.HDoc_Doc_Fec ) mes, year(h.HDoc_Doc_Fec ) ano, p.pro_proveedor  proveedor, ifnull(p.pro_direccion, 'N/A') dic, p.pro_nit nit , d.DDoc_Prd_Des concepto , d.DDoc_Prd_NET precio, (d.DDoc_Prd_QTY * d.DDoc_Prd_NET ) total, h.HDoc_Usuario hechopor,hh.HDoc_RF1_Dbl ISRRetenido , ROUND(d.DDoc_Prd_NET  / (c.cat_sist / 100 + 1),2) IVA, (c.cat_sist / 100) ISR, cc.cat_clave Moneda "
            'strSQL &= "                 from Dcmtos_HDR h "
            'strSQL &= "                         left join Dcmtos_DTL d on d.DDoc_Sis_Emp = h.HDoc_Sis_Emp and d.DDoc_Doc_Cat = h.HDoc_Doc_Cat and d.DDoc_Doc_Ano = h.HDoc_Doc_Ano and d.DDoc_Doc_Num = h.HDoc_Doc_Num "
            'strSQL &= "                     LEFT JOIN Dcmtos_HDR hh ON hh.HDoc_Sis_Emp = h.HDoc_Sis_Emp AND hh.HDoc_Pro_DCat = h.HDoc_Doc_Cat  AND hh.HDoc_Pro_DNum = h.HDoc_Doc_Num  AND hh.HDoc_Emp_Cod = h.HDoc_Emp_Cod "
            'strSQL &= "                 LEFT JOIN Catalogos c ON c.cat_clase = 'Impuestos' AND c.cat_clave = 'IVA' AND c.cat_sisemp = {empresa} "
            'strSQL &= "             LEFT JOIN Catalogos cc ON cc.cat_num = h.HDoc_Doc_Mon  AND cc.cat_clase = 'Monedas'"
            'strSQL &= "         left join Proveedores p on p.pro_sisemp = h.HDoc_Sis_Emp and p.pro_codigo = h.HDoc_Emp_Cod  	"
            'strSQL &= "     LEFT JOIN Catalogos cp ON cp.cat_num = p.pro_pais AND cp.cat_clase = 'Paises' "
            'strSQL &= "   LEFT JOIN Empresas e ON e.emp_no = h.HDoc_Sis_Emp "
            'strSQL &= "     where h.HDoc_Sis_Emp = {empresa} and h.HDoc_Doc_Cat = 44 and h.HDoc_Doc_Ano = {ano} and h.HDoc_Doc_Num = {numero} AND hh.HDoc_DR1_Num NOT LIKE '%IVA%'  "
            'strSQL &= " GROUP By h.HDoc_Doc_Ano , h.HDoc_Doc_Num "
            'strSQL &= ") l1"

            strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
            strSQL = Replace(strSQL, "{ano}", celdaAnioOc.Text)
            strSQL = Replace(strSQL, "{numero}", celdaNumOc.Text)

            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSQL, CON)
            REA = COM.ExecuteReader
            If REA.HasRows Then
                Do While REA.Read
                    strNit = REA.GetString("nit")
                    strNit = Replace(strNit, "-", "")
                    strNit = Replace(strNit, " ", "")
                    dblISRRetenido = REA.GetDouble("ISRRetenido")
                    dblIVARetenido = REA.GetDouble("IVARetenido")
                    If REA.GetInt32("CodigoMoneda") = 177 Then
                        strMoneda = "GTQ"
                    ElseIf REA.GetInt32("CodigoMoneda") = 178 Then
                        strMoneda = "USD"
                    End If
                    If File.Exists(System.Windows.Forms.Application.StartupPath & "\contenido.xml") Then
                        If logEncabezado = False Then
                            strXML &= "<?xml version='1.0' encoding='UTF-8'?>" & vbCrLf
                            strXML &= "<FirmaDocumentoRequest id='A50E4C76-6084-11E9-8647-D663BD873D93'>" & vbCrLf
                            strXML &= "<xml_dte>" & vbCrLf
                            strXML &= "<![CDATA[ " & vbCrLf
                            ' Encabezado Factura Especial 
                            'strXML &= "<?xml version='1.0' encoding='UTF-8' standalone='no'?><dte:GTDocumento xmlns:dte='http://www.sat.gob.gt/dte/fel/0.1.0' xmlns:xd='http://www.w3.org/2000/09/xmldsig#' Version='0.4'>" & vbCrLf
                            strXML &= "<?xml version='1.0' encoding='UTF-8'?> <dte:GTDocumento xmlns:dte='http://www.sat.gob.gt/dte/fel/0.2.0' Version='0.1'>" & vbCrLf
                            strXML &= "<dte:SAT ClaseDocumento='dte'>" & vbCrLf
                            strXML &= "<dte:DTE ID='DatosCertificados'>" & vbCrLf
                            strXML &= "<dte:DatosEmision ID='DatosEmision'>" & vbCrLf
                            strXML &= "<dte:DatosGenerales CodigoMoneda='" & strMoneda & "' FechaHoraEmision='" & Horario & "-06:00" & "' Tipo='FESP'/>" & vbCrLf
                            strXML &= "<dte:Emisor AfiliacionIVA='GEN' CodigoEstablecimiento='1' CorreoEmisor='contabilidad@hilosyalgodon.com' NITEmisor='90028481' NombreComercial='" & REA.GetString("NombreComercial") & "' NombreEmisor='" & REA.GetString("NombreComercial") & "'>" & vbCrLf
                            strXML &= "<dte:DireccionEmisor>" & vbCrLf
                            strXML &= "<dte:Direccion>" & REA.GetString("DireccionEmisor") & "</dte:Direccion>" & vbCrLf
                            strXML &= "<dte:CodigoPostal>0</dte:CodigoPostal>" & vbCrLf
                            strXML &= "<dte:Municipio>Amatitlan</dte:Municipio>" & vbCrLf
                            strXML &= "<dte:Departamento> Guatemala </dte:Departamento>" & vbCrLf
                            strXML &= "<dte:Pais>GT</dte:Pais>" & vbCrLf
                            strXML &= "</dte:DireccionEmisor>" & vbCrLf
                            strXML &= "</dte:Emisor>" & vbCrLf
                            strXML &= "<dte:Receptor CorreoReceptor='contabilidad@hilosyalgodon.com' IDReceptor='" & strNit & "' NombreReceptor='" & REA.GetString("proveedor") & "' TipoEspecial='CUI'>" & vbCrLf

                            strXML &= "<dte:DireccionReceptor>" & vbCrLf
                            strXML &= "<dte:Direccion>" & REA.GetString("DireccionCliente") & "</dte:Direccion>" & vbCrLf
                            strXML &= "<dte:CodigoPostal>0</dte:CodigoPostal>" & vbCrLf
                            strXML &= "<dte:Municipio></dte:Municipio>" & vbCrLf
                            strXML &= "<dte:Departamento>  </dte:Departamento>" & vbCrLf
                            strXML &= "<dte:Pais>" & REA.GetString("PaisReceptor") & "</dte:Pais>" & vbCrLf
                            strXML &= "</dte:DireccionReceptor>" & vbCrLf
                            strXML &= "</dte:Receptor>" & vbCrLf
                            strXML &= "<dte:Items>" & vbCrLf
                            ' Detalle de la Factura Especial 
                            If REA.GetInt32("Clasificacion") = INT_CERO Then
                                strXML &= "<dte:Item BienOServicio='B' NumeroLinea='" & REA.GetInt32("Linea") & "'>" & vbCrLf
                            Else
                                strXML &= "<dte:Item BienOServicio='S' NumeroLinea='" & REA.GetInt32("Linea") & "'>" & vbCrLf
                            End If

                            strXML &= "<dte:Cantidad>" & REA.GetDouble("Cantidad") & "</dte:Cantidad>" & vbCrLf
                            strXML &= "<dte:UnidadMedida>0</dte:UnidadMedida>" & vbCrLf
                            strXML &= " <dte:Descripcion>" & REA.GetString("concepto") & "</dte:Descripcion> " & vbCrLf
                            strXML &= "<dte:PrecioUnitario>" & REA.GetDouble("precio") & "</dte:PrecioUnitario>" & vbCrLf
                            strXML &= "<dte:Precio>" & REA.GetDouble("total") & "</dte:Precio>" & vbCrLf
                            strXML &= "<dte:Descuento>0</dte:Descuento>"
                            dblGranTotal = dblGranTotal + REA.GetDouble("total")
                            dblTotalImpuesto = (dblGranTotal - dblIVARetenido)

                            'Adenda DTL'
                            strXMLDTL &= "<AdendaItem LineaReferencia='1'>" & vbCrLf
                            strXMLDTL &= "<Valor1></Valor1>" & vbCrLf
                            strXMLDTL &= "</AdendaItem>" & vbCrLf

                            strXML &= "<dte:Impuestos>" & vbCrLf
                            strXML &= "<dte:Impuesto>" & vbCrLf
                            strXML &= "<dte:NombreCorto>IVA</dte:NombreCorto>" & vbCrLf
                            strXML &= "<dte:CodigoUnidadGravable>1</dte:CodigoUnidadGravable>" & vbCrLf
                            strXML &= "<dte:MontoGravable>" & dblTotalImpuesto & "</dte:MontoGravable>" & vbCrLf
                            strXML &= "<dte:MontoImpuesto>" & dblIVARetenido & "</dte:MontoImpuesto>" & vbCrLf
                            strXML &= "</dte:Impuesto>" & vbCrLf
                            strXML &= "</dte:Impuestos>" & vbCrLf

                            strXML &= "<dte:Total>" & REA.GetDouble("total") & "</dte:Total>" & vbCrLf
                            strXML &= "</dte:Item>" & vbCrLf
                            logEncabezado = True
                        Else
                            ' Detalle de la Factura Especial 
                            If REA.GetInt32("Clasificacion") = INT_CERO Then
                                strXML &= "<dte:Item BienOServicio='B' NumeroLinea='" & REA.GetInt32("Linea") & "'>" & vbCrLf
                            Else
                                strXML &= "<dte:Item BienOServicio='S' NumeroLinea='" & REA.GetInt32("Linea") & "'>" & vbCrLf
                            End If

                            strXML &= "<dte:Cantidad>" & REA.GetDouble("Cantidad") & "</dte:Cantidad>" & vbCrLf
                            strXML &= "<dte:UnidadMedida>0</dte:UnidadMedida>" & vbCrLf
                            strXML &= " <dte:Descripcion>" & REA.GetString("concepto") & " </dte:Descripcion> " & vbCrLf
                            strXML &= "<dte:PrecioUnitario>" & REA.GetDouble("precio") & "</dte:PrecioUnitario>" & vbCrLf
                            strXML &= "<dte:Precio>" & REA.GetDouble("total") & "</dte:Precio>" & vbCrLf
                            strXML &= "<dte:Descuento>0</dte:Descuento>"
                            dblGranTotal = dblGranTotal + REA.GetDouble("total")
                            dblTotalImpuesto = (dblGranTotal - dblIVARetenido)



                            strXML &= "<dte:Impuestos>" & vbCrLf
                            strXML &= "<dte:Impuesto>" & vbCrLf
                            strXML &= "<dte:NombreCorto>IVA</dte:NombreCorto>" & vbCrLf
                            strXML &= "<dte:CodigoUnidadGravable>1</dte:CodigoUnidadGravable>" & vbCrLf
                            strXML &= "<dte:MontoGravable>" & dblTotalImpuesto & "</dte:MontoGravable>" & vbCrLf
                            strXML &= "<dte:MontoImpuesto>" & dblIVARetenido & "</dte:MontoImpuesto>" & vbCrLf
                            strXML &= "</dte:Impuesto>" & vbCrLf
                            strXML &= "</dte:Impuestos>" & vbCrLf
                            strXML &= "<dte:Total>" & REA.GetDouble("total") & "</dte:Total>" & vbCrLf
                            strXML &= "</dte:Item>" & vbCrLf
                        End If
                    Else
                        If logEncabezado = False Then
                            strXML &= "<?xml version='1.0' encoding='UTF-8'?>" & vbCrLf
                            strXML &= "<FirmaDocumentoRequest id='A50E4C76-6084-11E9-8647-D663BD873D93'>" & vbCrLf
                            strXML &= "<xml_dte>" & vbCrLf
                            strXML &= "<![CDATA[ " & vbCrLf
                            ' Encabezado Factura Especial 
                            ' strXML &= "<?xml version='1.0' encoding='UTF-8' standalone='no'?><dte:GTDocumento xmlns:dte='http://www.sat.gob.gt/dte/fel/0.1.0' xmlns:xd='http://www.w3.org/2000/09/xmldsig#' Version='0.4'>" & vbCrLf
                            strXML &= "<?xml version='1.0' encoding='UTF-8'?> <dte:GTDocumento xmlns:dte='http://www.sat.gob.gt/dte/fel/0.2.0' Version='0.1'>" & vbCrLf
                            strXML &= "<dte:SAT ClaseDocumento='dte'>" & vbCrLf
                            strXML &= "<dte:DTE ID='DatosCertificados'>" & vbCrLf
                            strXML &= "<dte:DatosEmision ID='DatosEmision'>" & vbCrLf
                            strXML &= "<dte:DatosGenerales CodigoMoneda='" & strMoneda & "' FechaHoraEmision='" & Horario & "-06:00" & "' Tipo='FESP'/>"
                            strXML &= "<dte:Emisor AfiliacionIVA='GEN' CodigoEstablecimiento='1' CorreoEmisor='contabilidad@hilosyalgodon.com' NITEmisor='90028481' NombreComercial='" & REA.GetString("NombreComercial") & "' NombreEmisor='" & REA.GetString("NombreComercial") & "'>" & vbCrLf
                            strXML &= "<dte:DireccionEmisor>" & vbCrLf
                            strXML &= "<dte:Direccion>" & REA.GetString("DireccionEmisor") & "</dte:Direccion>" & vbCrLf
                            strXML &= "<dte:CodigoPostal>0</dte:CodigoPostal>" & vbCrLf
                            strXML &= "<dte:Municipio>Amatitlan</dte:Municipio>" & vbCrLf
                            strXML &= "<dte:Departamento> Guatemala </dte:Departamento>" & vbCrLf
                            strXML &= "<dte:Pais>GT</dte:Pais>" & vbCrLf
                            strXML &= "</dte:DireccionEmisor>" & vbCrLf
                            strXML &= "</dte:Emisor>" & vbCrLf
                            strXML &= "<dte:Receptor CorreoReceptor='contabilidad@hilosyalgodon.com' IDReceptor='" & strNit & "' NombreReceptor='" & REA.GetString("proveedor") & "' TipoEspecial='CUI'>" & vbCrLf

                            strXML &= "<dte:DireccionReceptor>" & vbCrLf
                            strXML &= "<dte:Direccion>" & REA.GetString("DireccionCliente") & "</dte:Direccion>" & vbCrLf
                            strXML &= "<dte:CodigoPostal>0</dte:CodigoPostal>" & vbCrLf
                            strXML &= "<dte:Municipio></dte:Municipio>" & vbCrLf
                            strXML &= "<dte:Departamento>  </dte:Departamento>" & vbCrLf
                            strXML &= "<dte:Pais>" & REA.GetString("PaisReceptor") & "</dte:Pais>" & vbCrLf
                            strXML &= "</dte:DireccionReceptor>" & vbCrLf
                            strXML &= "</dte:Receptor>" & vbCrLf
                            strXML &= "<dte:Items>" & vbCrLf
                            ' Detalle de la Factura Especial 
                            If REA.GetInt32("Clasificacion") = INT_CERO Then
                                strXML &= "<dte:Item BienOServicio='B' NumeroLinea='" & REA.GetInt32("Linea") & "'>" & vbCrLf
                            Else
                                strXML &= "<dte:Item BienOServicio='S' NumeroLinea='" & REA.GetInt32("Linea") & "'>" & vbCrLf
                            End If

                            strXML &= "<dte:Cantidad>" & REA.GetDouble("Cantidad") & "</dte:Cantidad>" & vbCrLf
                            strXML &= "<dte:UnidadMedida>0</dte:UnidadMedida>" & vbCrLf
                            strXML &= " <dte:Descripcion>" & REA.GetString("concepto") & "</dte:Descripcion> " & vbCrLf
                            strXML &= "<dte:PrecioUnitario>" & REA.GetDouble("precio") & "</dte:PrecioUnitario>" & vbCrLf
                            strXML &= "<dte:Precio>" & REA.GetDouble("total") & "</dte:Precio>" & vbCrLf
                            strXML &= "<dte:Descuento>0</dte:Descuento>"
                            dblGranTotal = dblGranTotal + REA.GetDouble("total")
                            dblTotalImpuesto = (dblGranTotal - dblIVARetenido)

                            'Adenda DTL'
                            strXMLDTL &= "<AdendaItem LineaReferencia='1'>" & vbCrLf
                            strXMLDTL &= "<Valor1></Valor1>" & vbCrLf
                            strXMLDTL &= "</AdendaItem>" & vbCrLf


                            strXML &= "<dte:Impuestos>" & vbCrLf
                            strXML &= "<dte:Impuesto>" & vbCrLf
                            strXML &= "<dte:NombreCorto>IVA</dte:NombreCorto>" & vbCrLf
                            strXML &= "<dte:CodigoUnidadGravable>2</dte:CodigoUnidadGravable>" & vbCrLf
                            strXML &= "<dte:MontoGravable>" & dblTotalImpuesto & "</dte:MontoGravable>" & vbCrLf
                            strXML &= "<dte:MontoImpuesto>" & dblIVARetenido & "</dte:MontoImpuesto>" & vbCrLf
                            strXML &= "</dte:Impuesto>" & vbCrLf
                            strXML &= "</dte:Impuestos>" & vbCrLf

                            strXML &= "<dte:Total>" & REA.GetDouble("total") & "</dte:Total>" & vbCrLf
                            strXML &= "</dte:Item>" & vbCrLf
                            logEncabezado = True
                        Else
                            ' Detalle de la Factura Especial 
                            If REA.GetInt32("Clasificacion") = INT_CERO Then
                                strXML &= "<dte:Item BienOServicio='B' NumeroLinea='" & REA.GetInt32("Linea") & "'>" & vbCrLf
                            Else
                                strXML &= "<dte:Item BienOServicio='S' NumeroLinea='" & REA.GetInt32("Linea") & "'>" & vbCrLf
                            End If

                            strXML &= "<dte:Cantidad>" & REA.GetDouble("Cantidad") & "</dte:Cantidad>" & vbCrLf
                            strXML &= "<dte:UnidadMedida>0</dte:UnidadMedida>" & vbCrLf
                            strXML &= " <dte:Descripcion>" & REA.GetString("concepto") & " " & REA.GetString("art_DLarga") & "</dte:Descripcion> " & vbCrLf
                            strXML &= "<dte:PrecioUnitario>" & REA.GetDouble("precio") & "</dte:PrecioUnitario>" & vbCrLf
                            strXML &= "<dte:Precio>" & REA.GetDouble("total") & "</dte:Precio>" & vbCrLf
                            dblGranTotal = dblGranTotal + REA.GetDouble("total")
                            dblTotalImpuesto = (dblGranTotal - dblIVARetenido)

                            strXML &= "<dte:Impuestos>" & vbCrLf
                            strXML &= "<dte:Impuesto>" & vbCrLf
                            strXML &= "<dte:NombreCorto>IVA</dte:NombreCorto>" & vbCrLf
                            strXML &= "<dte:CodigoUnidadGravable>1</dte:CodigoUnidadGravable>" & vbCrLf
                            strXML &= "<dte:MontoGravable>" & dblTotalImpuesto & "</dte:MontoGravable>" & vbCrLf
                            strXML &= "<dte:MontoImpuesto>" & dblIVARetenido & "</dte:MontoImpuesto>" & vbCrLf
                            strXML &= "</dte:Impuesto>" & vbCrLf
                            strXML &= "</dte:Impuestos>" & vbCrLf
                            strXML &= "<dte:Total>" & REA.GetDouble("total") & "</dte:Total>" & vbCrLf
                            strXML &= "</dte:Item>" & vbCrLf
                        End If
                    End If
                Loop
            End If
            dblTotalRetenido = (dblGranTotal - dblISRRetenido - dblIVARetenido)
            strXML &= "</dte:Items>" & vbCrLf
            'Totales 
            strXML &= "<dte:Totales>" & vbCrLf
            strXML &= "<dte:TotalImpuestos>" & vbCrLf
            strXML &= "<dte:TotalImpuesto NombreCorto='IVA' TotalMontoImpuesto='" & dblIVARetenido & "'/>" & vbCrLf
            strXML &= "</dte:TotalImpuestos>" & vbCrLf
            strXML &= "<dte:GranTotal>" & dblGranTotal & "</dte:GranTotal>" & vbCrLf
            strXML &= "</dte:Totales>" & vbCrLf
            strXML &= "<dte:Complementos>" & vbCrLf
            strXML &= "<dte:Complemento NombreComplemento='FESP' URIComplemento='http://www.sat.gob.gt/face2/ComplementoFacturaEspecial/0.1.0'>" & vbCrLf
            strXML &= "<cfe:RetencionesFacturaEspecial xmlns:cfe='http://www.sat.gob.gt/face2/ComplementoFacturaEspecial/0.1.0'  Version='1'>" & vbCrLf
            strXML &= "<cfe:RetencionISR>" & dblISRRetenido.ToString("###0.00") & "</cfe:RetencionISR>" & vbCrLf
            strXML &= "<cfe:RetencionIVA>" & dblIVARetenido & "</cfe:RetencionIVA>" & vbCrLf
            strXML &= "<cfe:TotalMenosRetenciones>" & dblTotalRetenido & "</cfe:TotalMenosRetenciones>" & vbCrLf
            strXML &= "</cfe:RetencionesFacturaEspecial>" & vbCrLf
            strXML &= "</dte:Complemento>" & vbCrLf
            strXML &= "</dte:Complementos>" & vbCrLf
            strXML &= "</dte:DatosEmision>" & vbCrLf
            strXML &= "</dte:DTE>" & vbCrLf
            strXML &= "<dte:Adenda>" & vbCrLf
            strXML &= "<dte:AdendaDetail id='AdendaSummary'> " & vbCrLf
            strXML &= "<dte:AdendaSummary>" & vbCrLf
            strXML &= "<dte:Valor1> " & celdaNumero.Text & " " & """" & celdaSerie.Text & """" & "</dte:Valor1>" & vbCrLf
            strXML &= "</dte:AdendaSummary>" & vbCrLf
            strXML &= "<AdendaItems>" & vbCrLf
            strXML &= strXMLDTL
            strXML &= "</AdendaItems>" & vbCrLf
            strXML &= "</dte:AdendaDetail>" & vbCrLf
            strXML &= "</dte:Adenda>" & vbCrLf
            strXML &= "</dte:SAT>" & vbCrLf
            strXML &= "</dte:GTDocumento>" & vbCrLf

            'Fin Fima Electronica 
            strXML &= "]]>" & vbCrLf
            strXML &= "</xml_dte>" & vbCrLf
            strXML &= "</FirmaDocumentoRequest>" & vbCrLf
            sw = New StreamWriter(System.Windows.Forms.Application.StartupPath & "\contenido.xml")
            sw.Write(strXML)
            sw.Close()
            fs = File.Create(System.Windows.Forms.Application.StartupPath & "\firma.xml")
            fs.Close()
            sw = New StreamWriter(System.Windows.Forms.Application.StartupPath & "\firma.xml")
            sw.Write(t.FirmaElectronica(strpathF, strToken, logResultado))
            If logResultado = False Then
                MsgBox("Fallo en la Firma Electronica")
                strError &= " Fallo en la Firma Electronica "
                EnvioProyecto(strError)
                Exit Function
            End If
            sw.Close()
            xml_Documento.Load(System.Windows.Forms.Application.StartupPath & "\firma.xml")
            nodos_lista = xml_Documento.SelectNodes("/FirmaDocumentoResponse")
            'Iniciamos el ciclo de lectura
            For Each nodo In nodos_lista
                ' Asigna el Token Devuelto por Web Service 
                strXMLRegistra = "<?xml version='1.0' encoding='UTF-8'?>" & vbCrLf & "<RegistraDocumentoXMLRequest id='" & strUUID & "'>" & vbCrLf & "<xml_dte><![CDATA[" & nodo.ChildNodes.Item(0).InnerText & " ]]></xml_dte>" & vbCrLf & "</RegistraDocumentoXMLRequest>"
            Next
            fs = File.Create(System.Windows.Forms.Application.StartupPath & "\RegistraDocumento.xml")
            fs.Close()
            sw = New StreamWriter(System.Windows.Forms.Application.StartupPath & "\RegistraDocumento.xml")
            sw.Write(strXMLRegistra)
            sw.Close()
            fs = File.Create(System.Windows.Forms.Application.StartupPath & "\FactEspFel" & celdaNumOc.Text & ".xml")
            fs.Close()
            sw = New StreamWriter(System.Windows.Forms.Application.StartupPath & "\FactEspFel" & celdaNumOc.Text & ".xml")
            'Registra la factura ya firmado
            strXMLFinal = t.RegistrarDocumento(strpathR, strToken, logResultado)
            If logResultado = False Then
                MsgBox("Fallo en el registra documento de Fel ")
                strError &= "Fallo en el registra documento de Fel"
                EnvioProyecto(strError)
                Exit Function
            End If
            sw.Write(strXMLFinal)
            sw.Close()
            ' Metodo para subir el archivo en una compartida
            'My.Computer.Network.UploadFile(system.Windows.Forms.Application.StartupPath & "\FactEspFel" & celdaNumOc.Text & ".xml", "file://" & IP & strRuta & "\FactEspFel" & celdaNumOc.Text & ".xml" & "", strUsuario, strContrasena, True, 9000, True)
            '' se modifica el 29/01/2025
            Try
                ' Intento la primera subida con la ruta de red
                My.Computer.Network.UploadFile(System.Windows.Forms.Application.StartupPath & "\FactEspFel" & celdaNumOc.Text & ".xml", "file://" & IP & strRuta & "\FactEspFel" & celdaNumOc.Text & ".xml" & "", strUsuario, strContrasena, True, 9000, True)
            Catch ex1 As Exception
                MessageBox.Show("Error al subir el archivo: " & ex1.Message)
            End Try
            Try
                ' Si falla, intento la segunda subida con la ruta local
                My.Computer.Network.UploadFile(System.Windows.Forms.Application.StartupPath & "\FactEspFel" & celdaNumero.Text & ".xml", "C:\Archivos_Fel\FactEspFel" & celdaNumero.Text & ".xml" & "", strUsuario, strContrasena, True, 9000, True)
            Catch ex2 As Exception
                MessageBox.Show("Error al guardar archivo: " & ex2.Message)
            End Try


            xml_Documento.Load(System.Windows.Forms.Application.StartupPath & "\FactEspFel" & celdaNumOc.Text & ".xml")
            nodos_lista = xml_Documento.SelectNodes("/RegistraDocumentoXMLResponse")
            'iniciamos el ciclo de lectura
            For Each nodo In nodos_lista
                ' asigna el token devuelto por web service 
                strXMLFel = nodo.ChildNodes.Item(0).InnerText
            Next

            fs = File.Create(System.Windows.Forms.Application.StartupPath & "\FESPFel" & celdaNumOc.Text & ".xml")
            fs.Close()
            sw = New StreamWriter(System.Windows.Forms.Application.StartupPath & "\FESPFel" & celdaNumOc.Text & ".xml")
            sw.Write(strXMLFel)
            sw.Close()
            ' Metodo para subir el archivo en una compartida
            'My.Computer.Network.UploadFile(system.Windows.Forms.Application.StartupPath & "\FESPFel" & celdaNumOc.Text & ".xml", "file://" & IP & strRuta & "\FESPFel" & celdaNumOc.Text & ".xml" & "", strUsuario, strContrasena, True, 9000, True)
            '' se modifica el 29/01/2025
            Try
                ' Intento la primera subida con la ruta de red
                My.Computer.Network.UploadFile(System.Windows.Forms.Application.StartupPath & "\FESPFel" & celdaNumOc.Text & ".xml", "file://" & IP & strRuta & "\FESPFel" & celdaNumOc.Text & ".xml" & "", strUsuario, strContrasena, True, 9000, True)
            Catch ex1 As Exception
                MessageBox.Show("Error al subir el archivo: " & ex1.Message)
            End Try
            Try
                ' Si falla, intento la segunda subida con la ruta local
                My.Computer.Network.UploadFile(System.Windows.Forms.Application.StartupPath & "\FESPFel" & celdaNumero.Text & ".xml", "C:\Archivos_Fel\FESPFel" & celdaNumero.Text & ".xml" & "", strUsuario, strContrasena, True, 9000, True)
            Catch ex2 As Exception
                MessageBox.Show("Error al guardar archivo: " & ex2.Message)
            End Try

            xml_Documento.Load(System.Windows.Forms.Application.StartupPath & "\FESPFel" & celdaNumOc.Text & ".xml")
            nodos_lista = xml_Documento.GetElementsByTagName("dte:Certificacion")
            'iniciamos el ciclo de lectura
            For Each nodo In nodos_lista
                ' asigna el token devuelto por web service 
                strNitCertificador = nodo.ChildNodes.Item(0).InnerText  ' Nit MegaPrint
                '  strFechaHoraCertificacion = nodo.ChildNodes.Item(1).InnerText ' Nombre MegaPrint
                strSerieDocumento = nodo.ChildNodes.Item(2).InnerText ' Serie 
                strFechaHoraCertificacion = nodo.ChildNodes.Item(3).InnerText ' FechaCertificacion 
            Next
            ' Nombre del archivo a utilizar
            Dim vlcFileName As String = System.Windows.Forms.Application.StartupPath & "\FESPFel" & celdaNumOc.Text & ".xml"
            ' Si el archivo existe
            Dim vloFile As New StreamReader(vlcFileName)
            ' Ciclo de iteración entre líneas
            While True
                ' Cargar la línea
                Dim vlcLinea = vloFile.ReadLine()
                ' Si la línea es nula, sale del ciclo
                If vlcLinea Is Nothing Then Exit While
                ' Si la línea contiene el criterio
                If vlcLinea.Contains(vlcCriterio) Then
                    ' Obtener la línea como resultado,
                    ' Concatenando un retorno de carro si ya hay ocurrencias
                    vlcResultado += IIf(vlcResultado <> "", vbCrLf, "") & vlcLinea
                    ' Salir del ciclo
                    Exit While
                    ' Lo omites si quieres todas las ocurrencias
                End If
            End While
            'Realiza busqueda de la cadena para obtener el numero de Autorizacion
            strCadenaEncontrada = vlcResultado.Substring(vlcResultado.LastIndexOf("Numero=") + 1)
            'En un array parte la cadena despues que encuentre un igual 
            arrayCadena = strCadenaEncontrada.Split("=".ToCharArray)
            'carga el numero de autorizacion de cada documento
            strNumeroAutorizacion = arrayCadena(INT_UNO)
            'sustituye serie por cadena vacio para limpiar la cadena y solo obtenga el numero
            strNumeroAutorizacion = Replace(strNumeroAutorizacion, "Serie", STR_VACIO)
            'sustituye "" por cadena vacia para limpiar la cadena y solo obtenga el numero 
            strNumeroAutorizacion = Replace(strNumeroAutorizacion, """", STR_VACIO)
            'sustituye espacios por cadena vacia para limpiar la cadena y solo obtenga el numero 
            strNumeroAutorizacion = Replace(strNumeroAutorizacion, " ", STR_VACIO)

            ActualizarFel(Horario & "-06:00", strFechaHoraCertificacion, strSerieDocumento, strNumeroAutorizacion, strUUID)
            cFunciones.EscribirRegistro(Tbl_Documentos, clsFunciones.AccEnum.acPrint, celdaProveedor1.Text, 44, celdaAnioOc.Text, celdaNumOc.Text, Sesion.Usuario & " " & Horario)
            'Creacion de XML para consumir Webservice retorna pdf
            strXMLPDF &= "<?xml version='1.0' encoding='UTF-8'?>" & vbCrLf
            strXMLPDF &= "<RetornaPDFRequest>" & vbCrLf
            strXMLPDF &= "<uuid>" & strSerieDocumento & "</uuid>" & vbCrLf
            strXMLPDF &= "</RetornaPDFRequest>" & vbCrLf
            fs = File.Create(System.Windows.Forms.Application.StartupPath & "\FESPPDF" & celdaNumOc.Text & ".xml")
            fs.Close()
            sw = New StreamWriter(System.Windows.Forms.Application.StartupPath & "\FESPPDF" & celdaNumOc.Text & ".xml")
            sw.Write(strXMLPDF)
            sw.Close()

            fs = File.Create(System.Windows.Forms.Application.StartupPath & "\FESPPDFFinal" & celdaNumOc.Text & ".xml")
            fs.Close()
            sw = New StreamWriter(System.Windows.Forms.Application.StartupPath & "\FESPPDFFinal" & celdaNumOc.Text & ".xml")
            sw.Write(t.RetornaPDF(strpathPDF, strToken))
            sw.Close()
            xml_Documento.Load(System.Windows.Forms.Application.StartupPath & "\FESPPDFFinal" & celdaNumOc.Text & ".xml")
            nodos_lista = xml_Documento.SelectNodes("/RetornaPDFResponse")
            ''Iniciamos el ciclo de lectura
            For Each nodo In nodos_lista
                '    ' Asigna el Codigo 64 Bits
                strCodigo64BitsPDF = nodo.ChildNodes.Item(0).InnerText
            Next
            Dim str As String = strCodigo64BitsPDF
            Dim Base64Byte() As Byte = Convert.FromBase64String(str)
            Dim obj As FileStream = File.Create(System.Windows.Forms.Application.StartupPath & "\FESPFel" & celdaNumOc.Text & ".pdf")
            obj.Write(Base64Byte, 0, Base64Byte.Length)
            obj.Flush()
            obj.Close()
            ' Metodo para subir el archivo en una compartida
            'My.Computer.Network.UploadFile(system.Windows.Forms.Application.StartupPath & "\FESPFel" & celdaNumOc.Text & ".pdf", "file://" & IP & strRuta & "\FESPFel" & celdaNumOc.Text & ".pdf" & "", strUsuario, strContrasena, True, 9000, True)
            '' se modifica el 29/01/2025
            Try
                ' Intento la primera subida con la ruta de red
                My.Computer.Network.UploadFile(System.Windows.Forms.Application.StartupPath & "\FESPFel" & celdaNumOc.Text & ".pdf", "file://" & IP & strRuta & "\FESPFel" & celdaNumOc.Text & ".pdf" & "", strUsuario, strContrasena, True, 9000, True)
            Catch ex1 As Exception
                MessageBox.Show("Error al subir el archivo: " & ex1.Message)
            End Try
            Try
                ' Si falla, intento la segunda subida con la ruta local
                My.Computer.Network.UploadFile(System.Windows.Forms.Application.StartupPath & "\FESPFel" & celdaNumero.Text & ".pdf", "C:\Archivos_Fel\FESPFel" & celdaNumero.Text & ".pdf" & "", strUsuario, strContrasena, True, 9000, True)
            Catch ex2 As Exception
                MessageBox.Show("Error al guardar archivo: " & ex2.Message)
            End Try


            botonImprimir.Enabled = True

            If MsgBox("Open file PDF ?", MsgBoxStyle.OkCancel, "Info") = MsgBoxResult.Ok Then
                System.Diagnostics.Process.Start(System.Windows.Forms.Application.StartupPath & "\FESPFel" & celdaNumOc.Text & ".pdf")
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        Return logResultado
    End Function
    Private Sub ImprimirFactruaEspecial()
        Dim strSQL As String = STR_VACIO
        Dim rpt As New rptFactraEspecial
        Try
            strSQL &= " SELECT l1.dia ,l1.mes , l1.ano , l1.proveedor , l1.dic, l1.nit, l1.concepto , l1.precio , l1.total , l1.hechopor , l1.ISRRetenido,l1.IVA, "
            strSQL &= "     ROUND((l1.IVA * l1.ISR),2) IVARetenido , l1.Moneda "
            strSQL &= "         FROM  ( "
            strSQL &= "             select day(h.HDoc_Doc_Fec ) dia , month(h.HDoc_Doc_Fec ) mes, year(h.HDoc_Doc_Fec ) ano, p.pro_proveedor  proveedor, ifnull(p.pro_direccion, 'N/A') dic, p.pro_nit nit , d.DDoc_Prd_Des concepto , d.DDoc_Prd_NET precio, (d.DDoc_Prd_QTY * d.DDoc_Prd_NET ) total, h.HDoc_Usuario hechopor,hh.HDoc_RF1_Dbl ISRRetenido , ROUND(d.DDoc_Prd_NET  / (c.cat_sist / 100 + 1),2) IVA, (c.cat_sist / 100) ISR, cc.cat_clave Moneda "
            strSQL &= "                 from Dcmtos_HDR h "
            strSQL &= "                         left join Dcmtos_DTL d on d.DDoc_Sis_Emp = h.HDoc_Sis_Emp and d.DDoc_Doc_Cat = h.HDoc_Doc_Cat and d.DDoc_Doc_Ano = h.HDoc_Doc_Ano and d.DDoc_Doc_Num = h.HDoc_Doc_Num "
            strSQL &= "                     LEFT JOIN Dcmtos_HDR hh ON hh.HDoc_Sis_Emp = h.HDoc_Sis_Emp AND hh.HDoc_Pro_DCat = h.HDoc_Doc_Cat  AND hh.HDoc_Pro_DNum = h.HDoc_Doc_Num  AND hh.HDoc_Emp_Cod = h.HDoc_Emp_Cod "
            strSQL &= "                 LEFT JOIN Catalogos c ON c.cat_clase = 'Impuestos' AND c.cat_clave = 'IVA' AND c.cat_sisemp = {empresa} "
            strSQL &= "             LEFT JOIN Catalogos cc ON cc.cat_num = h.HDoc_Doc_Mon  AND cc.cat_clase = 'Monedas'"
            strSQL &= "         left join Proveedores p on p.pro_sisemp = h.HDoc_Sis_Emp and p.pro_codigo = h.HDoc_Emp_Cod  	"
            strSQL &= "     where h.HDoc_Sis_Emp = {empresa} and h.HDoc_Doc_Cat = 44 and h.HDoc_Doc_Ano = {ano} and h.HDoc_Doc_Num = {numero} AND hh.HDoc_DR1_Num NOT LIKE '%IVA%'  "
            strSQL &= " GROUP By h.HDoc_Doc_Ano , h.HDoc_Doc_Num "
            strSQL &= ") l1"

            strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
            strSQL = Replace(strSQL, "{ano}", celdaAnioOc.Text)
            strSQL = Replace(strSQL, "{numero}", celdaNumOc.Text)
            CrearXMl(strSQL)

            rpt.Load("C:\XML\FacturaEspecial.xml")
            Dim frm3 As New frmFactuarEspecial
            frm3.Reporte_A_Ver_NCHilos = rpt
            frm3.CrystalReportViewer1.RefreshReport()
            frm3.ShowDialog(Me)

            My.Computer.FileSystem.DeleteFile("C:\XML\FacturaEspecial.xml")

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub
    Private Function CrearXMl(ByVal strConsulta As String)
        Dim Tablas As New DataSet
        Dim adaptador As New MySqlDataAdapter

        MyCnn.CONECTAR = strConexion
        adaptador = New MySqlDataAdapter(strConsulta, CON)
        Tablas = New DataSet("tablas1")
        adaptador.Fill(Tablas, "Dcmtos_HDR")
        If Tablas.Tables("Dcmtos_HDR").Rows.Count = 0 Then
            MsgBox("")
        Else
            My.Computer.FileSystem.CreateDirectory("C:\XML")
            Tablas.WriteXml("C:\XML\FacturaEspecial.xml", XmlWriteMode.WriteSchema)
        End If

    End Function
    Private Sub BloquearBotones(Optional ByVal logBloquear As Boolean = True)
        If Sesion.IdEmpresa = 12 And Pais() = 0 Then
            botonPrevio.Visible = True
        Else
            botonPrevio.Visible = False
        End If
        botonPrevio.Enabled = True

        If logBloquear = True Then
            Encabezado1.botonBorrar.Enabled = False
            botonImprimir.Enabled = False
            Encabezado1.botonGuardar.Enabled = False

        Else
            Encabezado1.botonBorrar.Enabled = True
            Encabezado1.botonGuardar.Enabled = True
            botonImprimir.Enabled = True

        End If

    End Sub

    Private Sub Accesos()
        Dim cAcesos As New clsAccesos

        Try
            If cAcesos.Accesos(strKey) = True Then
                logInsertar = cAcesos.Insertar
                logEditar = cAcesos.Editar
                LogBorrar = cAcesos.Borrar
                logConsultar = cAcesos.Consultar

            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub MostrarLista(Optional ByVal panel As Integer = INT_CERO)
        Dim cfun As New clsFunciones
        Dim tipo As String
        tipo = "Todos"
        intmodo = panel

        If cFunciones.ContaActiva Then
            logConta = True
        End If


        Select Case panel
            Case 0
                'If logMostrar = True Then
                panelDocumento.Dock = DockStyle.None
                panelDocumento.Visible = False
                panelDetalle.Dock = DockStyle.None
                panelDetalle.Visible = False
                panelProrrateo.Dock = DockStyle.None
                panelProrrateo.Visible = False
                BarraTitulo1.CambiarTitulo("Factura de Compra")

                QueryListaPrincipal(tipo)

                panelLista.Visible = True
                panelLista.Dock = DockStyle.Fill
                Encabezado1.botonNuevo.Enabled = True
                BloquearBotones()
                'Me.Tag = ""
            Case 1
                'Else
                panelLista.Visible = False
                panelLista.Dock = DockStyle.None
                panelDetalle.Dock = DockStyle.None
                panelDetalle.Visible = False
                panelProrrateo.Dock = DockStyle.None
                panelProrrateo.Visible = False

                panelDocumento.Dock = DockStyle.Fill
                panelDocumento.Visible = True
                BloquearBotones(False)
            Case 2
                panelLista.Visible = False
                panelLista.Dock = DockStyle.None
                panelProrrateo.Dock = DockStyle.None
                panelProrrateo.Visible = False

                panelDetalle.Dock = DockStyle.Fill
                panelDetalle.Visible = True
                Encabezado1.botonNuevo.Enabled = True
                panelDocumento.Dock = DockStyle.None
                panelDocumento.Visible = False
                BloquearBotones(False)
                botonImprimir.Enabled = False
                botonPrevio.Enabled = False
            Case 3
                Encabezado1.botonNuevo.Enabled = True
                'If logInsert = False Then
                BarraTitulo1.CambiarTitulo("Modificar Registro")
                'Me.Tag = "Nuevo"
                BloquearBotones(False)
                botonImprimir.Enabled = True
            Case 4
                panelLista.Visible = False
                panelLista.Dock = DockStyle.None
                panelDetalle.Dock = DockStyle.None
                panelDetalle.Visible = False
                panelDocumento.Dock = DockStyle.None
                panelDocumento.Visible = False

                Encabezado1.botonNuevo.Enabled = False
                panelProrrateo.Dock = DockStyle.Fill
                panelProrrateo.Visible = True
                BarraTitulo1.CambiarTitulo("Seleccionar Centros de Costos")
                BloquearBotones(False)
        End Select
        'End If

        dgLista.DataSource = Nothing
        'End If
    End Sub

    Private Function PorcentajeIVA()
        Dim strsql As String = STR_VACIO
        Dim Impuesto As Double
        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader
        Dim conec As New MySqlConnection

        Try
            strsql = " SELECT cat_sist IVA "
            strsql &= " From Catalogos c "
            strsql &= " WHERE c.cat_clase = 'Impuestos' AND c.cat_clave ='IVA' AND c.cat_sisemp = {empresa} "

            strsql = Replace(strsql, "{empresa}", Sesion.IdEmpresa)

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try

        Return strsql

    End Function

    Private Function SQLListaPrincipal(ByVal category As String) As String
        Dim strsql As String = STR_VACIO

        strsql = " SELECT g.*, ROUND(((g.Monto + g.Debitos) - (g.Creditos + g.reten + g.anticipo - g.DifCambiario)),2) Saldo "
        strsql &= "    FROM("
        strsql &= "        Select IFNULL(e.HDoc_RF1_Num, 0) Clase, IFNULL(e.HDoc_DR1_Emp,0) Grupo, e.HDoc_Doc_Fec Fecha, e.HDoc_Doc_Cat Tipo, e.HDoc_Doc_Ano Anio, e.HDoc_Doc_Num Numero, ifnull (e.HDoc_Pro_Fec,'') Procesado, e.HDoc_Doc_Status Estado, CONCAT(e.HDoc_DR1_Num,' ',"
        strsql &= "            Replace(e.HDoc_DR2_Num,'N/A','')) Referencia, e.HDoc_Emp_Cod ID, e.HDoc_Emp_Nom Nombre, e.HDoc_DR1_Fec Vence, DATEDIFF(CURDATE(),e.HDoc_DR1_Fec) Dias, e.HDoc_Doc_Mon Divisa, cm.cat_ext Simbolo, e.HDoc_Doc_TC Tasa, ROUND(e.HDoc_RF1_Dbl,2) Total, IF(e.HDoc_Doc_Mon = {loc}, ROUND(e.HDoc_RF1_Dbl*e.HDoc_Doc_TC,2),ROUND(e.HDoc_RF1_Dbl,2)) Monto, SUM(IF(s.ECta_Doc_Cat IN (40,53,54), IF(e.HDoc_Doc_Mon={loc}, (CASE WHEN s.ECta_moneda=e.HDoc_Doc_Mon THEN s.ECta_Crgo_Loc ELSE ROUND(s.ECta_Crgo_Ext * s.ECta_TC,2) END), (CASE WHEN s.ECta_moneda=e.HDoc_Doc_Mon THEN ROUND(s.ECta_Crgo_Ext,2) ELSE s.ECta_Crgo_Loc END)), 0)) Debitos, SUM(IF(s.ECta_Doc_Cat IN (39,51,52), IF(e.HDoc_Doc_Mon={loc}, (CASE WHEN"
        strsql &= "                s.ECta_moneda = e.HDoc_Doc_Mon Then s.ECta_Abno_Loc Else ROUND(s.ECta_Abno_Ext * s.ECta_TC, 2) End), (Case When s.ECta_moneda= e.HDoc_Doc_Mon Then ROUND(s.ECta_Abno_Ext,2) Else (s.ECta_Abno_Ext) End)), 0)) Creditos, SUM(IF(s.ECta_Doc_Cat = 0, s.ECta_Crgo_Loc,0))DifCambiario, If(e.HDoc_RF1_Num=0 And HDoc_DR2_Emp=0,1,0) SIVA,IFNULL(f.Serie,'') Serie, IFNULL(f.NumeroAutorizacion,'') Autorizacion,"
        strsql &= "                    IFNULL((SELECT r.HDoc_Doc_Num
                                        FROM Dcmtos_HDR r
                                        LEFT JOIN Dcmtos_DTL dc ON dc.DDoc_Sis_Emp =r.HDoc_Sis_Emp AND dc.DDoc_Doc_Cat = r.HDoc_Doc_Cat AND dc.DDoc_Doc_Ano = r.HDoc_Doc_Ano AND dc.DDoc_Doc_Num = r.HDoc_Doc_Num
                                            WHERE r.HDoc_Sis_Emp = e.HDoc_Sis_Emp AND r.HDoc_Doc_Cat = 220 AND (r.HDoc_Pro_DCat = e.HDoc_Doc_Cat OR dc.DDoc_RF1_Num = e.HDoc_Doc_Cat) AND (r.HDoc_Pro_DAno = e.HDoc_Doc_Ano OR dc.DDoc_RF2_Num = e.HDoc_Doc_Ano) AND (r.HDoc_Pro_DNum = e.HDoc_Doc_Num OR dc.DDoc_RF3_Num = e.HDoc_Doc_Num)
                                             LIMIT 1),0) RISR, IFNULL(("
        strsql &= "                            SELECT SUM(r.HDoc_RF1_Dbl / e.HDoc_Doc_TC) FROM Dcmtos_HDR r
                                            LEFT JOIN Dcmtos_DTL dc ON dc.DDoc_Sis_Emp =r.HDoc_Sis_Emp AND dc.DDoc_Doc_Cat = r.HDoc_Doc_Cat AND dc.DDoc_Doc_Ano = r.HDoc_Doc_Ano AND dc.DDoc_Doc_Num = r.HDoc_Doc_Num
                                            WHERE r.HDoc_Sis_Emp = e.HDoc_Sis_Emp AND r.HDoc_Doc_Cat = 220 AND (r.HDoc_Pro_DCat = e.HDoc_Doc_Cat OR dc.DDoc_RF1_Num = e.HDoc_Doc_Cat) AND (r.HDoc_Pro_DAno = e.HDoc_Doc_Ano OR dc.DDoc_RF2_Num = e.HDoc_Doc_Ano) AND (r.HDoc_Pro_DNum = e.HDoc_Doc_Num OR dc.DDoc_RF3_Num = e.HDoc_Doc_Num) AND r.HDoc_Doc_Status <> 2
                                            LIMIT 1),0) reten, "
        strsql &= "                            IFNULL(( "
        strsql &= "                            Select SUM(l.DDoc_Prd_NET) "
        strsql &= "                            From Dcmtos_DTL l "
        strsql &= "                            Left JOIN Dcmtos_HDR r ON r.HDoc_Sis_Emp = l.DDoc_Sis_Emp AND r.HDoc_Doc_Cat = l.DDoc_Doc_Cat AND r.HDoc_Doc_Ano = l.DDoc_Doc_Ano AND r.HDoc_Doc_Num = l.DDoc_Doc_Num "
        strsql &= "                            WHERE l.DDoc_Sis_Emp = e.HDoc_Sis_Emp AND l.DDoc_Doc_Cat = 689 AND l.DDoc_RF1_Num = e.HDoc_Doc_Cat AND l.DDoc_RF2_Num = e.HDoc_Doc_Ano AND l.DDoc_RF3_Num = e.HDoc_Doc_Num AND r.HDoc_Doc_Status = 1),0) anticipo, ct.cat_Desc tipoDocumento,ifnull(e.HDoc_RF1_Cod,0) tipoOC "
        If Sesion.idGiro = 2 Then
            strsql &= "                            ,IFNULL((SELECT IFNULL(hdr.HDoc_Doc_Num,0)FROM Dcmtos_DTL_Pro pro JOIN Dcmtos_HDR hdr ON hdr.HDoc_Sis_Emp=pro.PDoc_Sis_Emp AND hdr.HDoc_Doc_Cat=pro.PDoc_Chi_Cat AND hdr.HDoc_Doc_Ano=pro.PDoc_Chi_Ano AND hdr.HDoc_Doc_Num=pro.PDoc_Chi_Num WHERE pro.PDoc_Sis_Emp=e.HDoc_Sis_Emp AND pro.PDoc_Par_Cat=e.HDoc_Doc_Cat AND pro.PDoc_Par_Ano=hdr.HDoc_Doc_Ano AND pro.PDoc_Par_Num=e.HDoc_Doc_Num and pro.PDoc_Par_Cat=44 LIMIT 1),0) SinIngresos"
        Else
            strsql &= ", 0 SinIngresos"
        End If

        strsql &= "                        From Dcmtos_HDR e"
        strsql &= "                    Left Join ECtaCte s ON s.ECta_Sis_Emp=e.HDoc_Sis_Emp And s.ECta_Ref_Cat=e.HDoc_Doc_Cat And s.ECta_Ref_Ano=e.HDoc_Doc_Ano And s.ECta_Ref_Num=e.HDoc_Doc_Num And Not(s.ECta_Doc_Cat=e.HDoc_Doc_Cat And s.ECta_Doc_Ano=e.HDoc_Doc_Ano And s.ECta_Doc_Num=e.HDoc_Doc_Num)"
        strsql &= "               LEFT JOIN Fel f ON f.Empresa = e.HDoc_Sis_Emp AND f.Catalogo = e.HDoc_Doc_Cat AND f.Anio = e.HDoc_Doc_Ano AND f.Numero = e.HDoc_Doc_Num "
        strsql &= "             Left Join Catalogos cm ON cm.cat_clase='Monedas' AND cm.cat_num=e.HDoc_Doc_Mon LEFT JOIN Catalogos ct ON ct.cat_clase='Documentos' AND ct.cat_num=e.HDoc_Doc_Cat"
        strsql &= "      WHERE e.HDoc_Sis_Emp = {empresa} And e.HDoc_Doc_Cat in (44, 209) And e.HDoc_DR1_Cat = 0 {categoria}"

        '///Filtra por Proveedor
        If Not celdaProveedores.Text = vbNullString Then
            strsql &= " And ( e.HDoc_Emp_Cod = {buscar})"
            strsql = Replace(strsql, "{buscar}", celdaidProveedores.Text)
        End If

        '/// Muestra Documentos de fecha "a" hasta fecha "b"
        If checkFecha.Checked = True Then
            strsql &= "            And (e.HDoc_Doc_Fec BETWEEN '{fechainicial}' And '{fechafinal}')"

        End If



        '/// Filtra si es Local

        Select Case category

            Case "Local"
                strsql = Replace(strsql, "{categoria}", " And IFNULL(e.HDoc_RF1_Num, 0) = 0")

            Case "Importacion"
                strsql = Replace(strsql, "{categoria}", "  And IFNULL(e.HDoc_RF1_Num, 0) = 1")
                'Case botonTodo.CausesValidation

            Case "Todos"
                strsql = Replace(strsql, "{categoria}", vbNullString)

        End Select

        'If botonLocal.Bottom = True Then
        '    strsql &= " And (e.HDoc_RF1_Num = '0')"
        'End If

        strsql &= "         GROUP BY e.HDoc_Sis_Emp, e.HDoc_Doc_Cat, e.HDoc_Doc_Ano, e.HDoc_Doc_Num"

        '///Muestra solo Documentos con saldo
        If checkDocSaldo.Checked = True Then
            strsql &= "           HAVING ABS(ROUND((Monto + Debitos) - (Creditos + reten + anticipo),2)) > 0.01 "
        End If

        strsql &= "      ) g"
        strsql &= "    ORDER BY Fecha, Nombre, Referencia "
        'strsql &= " Limit 100"

        'REMPLAZOS
        strsql = Replace(strsql, "{fechainicial}", dtpInicial.Value.ToString(FORMATO_MYSQL))
        strsql = Replace(strsql, "{fechafinal}", dtpFinal.Value.ToString(FORMATO_MYSQL))
        strsql = Replace(strsql, "{empresa}", Sesion.IdEmpresa)
        strsql = Replace(strsql, "{loc}", cfun.DivisaLocal)


        Return strsql

    End Function


    Private Function SQLDatosFactura(ByVal intAnio As Integer, ByVal intNumero As Integer, ByVal intCatOc As Integer) As String
        Dim strsql As String = STR_VACIO


        strsql = " Select IFNULL(e.HDoc_RF1_Cod,'-1') tipoOrden, IFNULL(e.HDoc_DR2_Fec,NOW())conta_,e.HDoc_RF1_Txt notas, e.HDoc_Emp_Cod CodigoEmp, e.HDoc_Emp_Nom Proveedor, IFNULL(p.pro_nit,'') Nit,  
                    e.HDoc_Doc_Cat Cat, e.HDoc_Doc_Mon IdMoneda, e.HDoc_Doc_Fec fecha, e.HDoc_DR1_Fec FechaVence, e.HDoc_Doc_Num Numero, IFNULL(r.HDoc_Doc_Ano,0) Pro_DAno, IFNULL(r.HDoc_Doc_Num,0) Pro_DNum, 
                    e.HDoc_DR1_Num NumFact, e.HDoc_DR2_Num Serie, Catalogos.cat_clave Moneda, e.HDoc_RF3_Dbl Monto, e.HDoc_Doc_TC TasaCambio, IFNULL(e.HDoc_RF2_Cod,'') CAI, e.HDoc_DR1_Emp Tipo, e.HDoc_DR2_Cat extemporaneo, 
                   e.HDoc_Ant_Com FacturaEsp, e.HDoc_Doc_Status, e.HDoc_DR1_Dbl MontoProd, c.cat_desc TipoDocumento, if(e.HDoc_Emp_Dir>0,e.HDoc_Emp_Dir,-1) idResolucion, IFNULL(s.cat_sist,'') Resolucion "
        strsql &= "    From Dcmtos_HDR e"
        strsql &= "        Left Join Dcmtos_HDR r ON r.HDoc_Sis_Emp=e.HDoc_Sis_Emp And r.HDoc_Doc_Cat=220 And r.HDoc_Pro_DCat=e.HDoc_Doc_Cat And r.HDoc_Pro_DAno=e.HDoc_Doc_Ano And r.HDoc_Pro_DNum=e.HDoc_Doc_Num"
        strsql &= "             Left Join Proveedores p on p.pro_codigo = e.HDoc_Emp_Cod AND p.pro_sisemp = e.HDoc_Sis_Emp"
        strsql &= "          left join Catalogos on cat_clase= 'Monedas' and cat_num= e.HDoc_Doc_Mon LEFT JOIN Catalogos c ON c.cat_Clase='Documentos' AND c.cat_num=e.HDoc_Doc_Cat"
        strsql &= "     LEFT JOIN Catalogos s ON s.cat_num = e.HDoc_Emp_Dir AND s.cat_clave = 'Doc_Resolucion' AND s.cat_desc<>'Registro de Exonerados'
                        WHERE e.HDoc_Sis_Emp = {empresa} And e.HDoc_Doc_Cat = {catalogo} And e.HDoc_Doc_Ano = {anio} And e.HDoc_Doc_Num = {numero}"
        strsql &= "    LIMIT 1"

        '' '' ''///Remplazos
        strsql = Replace(strsql, "{empresa}", Sesion.IdEmpresa)
        strsql = Replace(strsql, "{anio}", intAnio)
        strsql = Replace(strsql, "{numero}", intNumero)
        strsql = Replace(strsql, "{catalogo}", intCatOc)

        Return strsql

    End Function

    Private Function DetalleFact(ByVal intAnio As Integer, ByVal intNumero As Integer, ByVal intCatOc As Integer)
        Dim strsql As String = STR_VACIO

        strsql = " SELECT IFNULL(d.DDoc_RF4_Cod,'') Lote, d.DDoc_Sis_Emp Empresa, d.DDoc_Doc_Cat Tipo, d.DDoc_Doc_Ano Anio, d.DDoc_Doc_Num Numero, d.DDoc_Doc_Lin LineaFactura, d.DDoc_Prd_QTY Cantidad, d.DDoc_Prd_Des Descripcion, d.DDoc_Prd_NET Precio, d.DDoc_RF1_Dbl Total, COALESCE(ELT(d.DDoc_RF1_Num+1,'BIEN','SERVICIO'),'') Clasificacion, IFNULL(d.DDoc_RF1_Cod,'') Cuenta, IFNULL(c.nombre,'') NomCuenta, ifnull(d.DDoc_RF2_Dbl,-1) Codigo, ifnull (d.DDoc_RF3_Num, '') Costo, ifnull(c.nombre, '') nombre, ifnull (c1.cost_nombre, '') CCosto, ifnull (TA.Descripcion, ' ') AFijo, d.DDoc_RF3_Dbl PrecioSinIva, IFNULL(d.DDoc_RF1_Txt,'') CtaIVA, IFNULL(c2.nombre,'') nombreIVA, d.DDOC_RF2_TXT idRubro, IFNULL(n2.NombreIngles,'') NomRubro,  d.DDOC_RF3_TXT idCuenta,  IFNULL(n.NombreIngles,'') NomCuentaUSA, d.DDoc_Prd_Cod CodigoP {lin}"
        strsql &= "    From Dcmtos_DTL d"
        strsql &= "         left join {conta}.cuentas c on c.id_cuenta = d.DDoc_RF1_Cod AND c.empresa = d.DDoc_Sis_Emp"
        strsql &= "         left join {conta}.costos c1 on c1.cost_num = d.DDoc_RF3_Num "
        strsql &= "      left Join Tipos_Activo TA on TA.Empresa = d.DDoc_Sis_Emp and TA.Codigo = d.DDoc_RF2_Dbl"
        strsql &= "      LEFT JOIN {conta}.cuentas c2 ON c2.empresa = d.DDoc_Sis_Emp AND  c2.id_cuenta = d.DDoc_RF1_Txt "
        If rbOrdenDeCompra.Checked = True Then
            strsql &= "     LEFT JOIN Dcmtos_DTL_Pro p ON p.PDoc_Sis_Emp = d.DDoc_Sis_Emp AND p.PDoc_Chi_Cat = d.DDoc_Doc_Cat AND p.PDoc_Chi_Ano = d.DDoc_Doc_Ano AND p.PDoc_Chi_Num = d.DDoc_Doc_Num AND p.PDoc_Chi_Lin = d.DDoc_Doc_Lin "
            strsql = strsql.Replace("{lin}", ",p.PDoc_Par_Lin LineaOrden")
        Else
            strsql = strsql.Replace("{lin}", vbNullString)
        End If
        strsql &= "          LEFT JOIN {conta}.nomenclatura n ON n.idEmpresa = c.empresa AND n.idCuenta = c.id_nomenclatura AND n.Pertenencia = d.DDOC_RF2_TXT"
        strsql &= "          LEFT JOIN {conta}.nomenclatura n2 ON n2.idEmpresa = n.idEmpresa AND n2.idCuenta = n.Pertenencia"
        strsql &= "    WHERE DDoc_Sis_Emp = {empresa} AND DDoc_Doc_Cat = {catalogo} AND DDoc_Doc_Ano = {anio} AND DDoc_Doc_Num = {num}"
        strsql &= " ORDER BY DDoc_Doc_Lin"

        strsql = Replace(strsql, "{empresa}", Sesion.IdEmpresa)
        strsql = Replace(strsql, "{num}", intNumero)
        strsql = Replace(strsql, "{anio}", intAnio)
        strsql = Replace(strsql, "{catalogo}", intCatOc)
        strsql = Replace(strsql, "{conta}", Sesion.BaseConta)

        Return strsql
    End Function

    Private Function SQLImpuestos()
        Dim strsql As String = STR_VACIO

        strsql = " SELECT MDoc_Doc_Lin Linea, MDoc_Lin_ID ID, MDoc_Lin_Codigo Codigo, MDoc_Lin_Tipo Tipo, MDoc_Lin_Desc Descripcion, MDoc_Lin_Base Base, MDoc_Lin_Cantidad Cantidad, MDoc_Lin_Factor Factor, MDoc_Lin_Monto Monto, -1 Tag, {editar} Origen"
        strsql &= "     From Dcmtos_IMP"
        strsql &= "         Where MDoc_Sis_Emp = {empresa} And MDoc_Doc_Cat = 44 And MDoc_Doc_Ano = {anio} And MDoc_Doc_Num = {num}"
        strsql &= "     Order By MDoc_Doc_Lin"

        strsql = Replace(strsql, "{empresa}", Sesion.IdEmpresa)
        strsql = Replace(strsql, "{anio}", celdaAnioOc.Text)
        strsql = Replace(strsql, "{num}", celdaNumOc.Text)
        If Me.Tag = "Mod" Then
            strsql = Replace(strsql, "{editar}", 1)
        Else
            strsql = Replace(strsql, "{editar}", 0)
        End If


        Return strsql

    End Function

    Private Function SQLPolizaImport(ByVal intAnio As Integer, ByVal intNumero As Integer, ByVal intCatRelacion As Integer)
        Dim strsql As String = STR_VACIO

        strsql = "SELECT PDoc_Sis_Emp Empresa, PDoc_Par_Cat CatPadre, PDoc_Par_Ano anio, PDoc_Par_Num Numero, PDoc_Par_lin Linea, PDoc_Chi_Cat CatHijo, PDoc_Chi_Ano AnioH, PDoc_Chi_Num NumHijo, PDoc_Chi_Lin LinHijo, PDoc_Prd_PNr Documento, PDoc_Prd_Net PrecioNeto, PDoc_QTY_Ord Cantidad, (PDoc_Prd_Net*PDoc_QTY_Ord) total, h.HDoc_Emp_Nom NomEmpresa, h.HDoc_Doc_Fec fecha"
        strsql &= "    FROM Dcmtos_DTL_Pro p"
        strsql &= "      LEFT JOIN Dcmtos_HDR h ON h.HDoc_Sis_Emp = p.PDoc_Sis_Emp AND h.HDoc_Doc_Cat = p.PDoc_Par_Cat AND h.HDoc_Doc_Ano = p.PDoc_Par_Ano AND h.HDoc_Doc_Num = p.PDoc_Par_Num"
        strsql &= "        WHERE PDoc_Sis_Emp = {empresa} And PDoc_Chi_Cat = 44 And PDoc_Chi_Ano = {anio} And PDoc_Chi_Num = {num} And PDoc_Par_Cat = {catRelacion}"

        strsql = Replace(strsql, "{empresa}", Sesion.IdEmpresa)
        strsql = Replace(strsql, "{anio}", intAnio)
        strsql = Replace(strsql, "{num}", intNumero)
        strsql = Replace(strsql, "{catRelacion}", intCatRelacion)

        Return strsql

    End Function

    Private Function SQLPagos(ByVal intAnio As Integer, ByVal intNumero As Integer, ByVal intTipo As Integer)
        Dim strsql As String = STR_VACIO

        strsql = " SELECT m.ECta_Doc_Cat Tipo, m.ECta_Doc_Ano Anio, m.ECta_Doc_Num Numero, m.ECta_moneda Moneda, m.ECta_TC tasa, m.ECta_FecDcmt Fecha, COALESCE(t.cat_desc,'') Documento, COALESCE(e.HDoc_DR1_Num,'') Referencia, m.ECta_Concepto Concepto, h.HDoc_Doc_TC, m.ECta_Abno_Ext AbonoEx, IF(m.ECta_moneda = {loc},m.ECta_Abno_Loc, IF(h.HDoc_Doc_TC = 1,(m.ECta_Abno_Loc), ROUND((m.ECta_Abno_Ext * IF(m.ECta_TC <> 0, m.ECta_TC, h.HDoc_Doc_TC)),2))) Abono, m.ECta_Crgo_Ext CargoEx, m.ECta_Crgo_Loc Cargo, COALESCE((
                        SELECT (IF(c.ECta_moneda = {loc},(SUM(c.ECta_Crgo_Loc)- SUM(c.ECta_Abno_Loc)),(SUM(c.ECta_Crgo_Ext * h.HDoc_Doc_TC)- IF(h.HDoc_Doc_TC = 1,SUM(c.ECta_Abno_Loc * h.HDoc_Doc_TC),SUM(c.ECta_Abno_Ext * h.HDoc_Doc_TC))))) Suma
                        FROM ECtaCte c
                        WHERE c.ECta_Sis_Emp = m.ECta_Sis_Emp AND c.ECta_Ref_Cat = m.ECta_Ref_Cat AND c.ECta_Ref_Ano = m.ECta_Ref_Ano AND c.ECta_Ref_Num = m.ECta_Ref_Num AND (CONCAT(CAST(DATE_FORMAT(c.ECta_FecDcmt,'%Y%m%d') AS CHAR), LPAD(c.ECta_TransId,8,'0')) < CONCAT(CAST(DATE_FORMAT(m.ECta_FecDcmt,'%Y%m%d') AS CHAR), LPAD(m.ECta_TransId,8,'0')))),0) + IF(m.ECta_moneda = {loc},(m.ECta_Crgo_Loc - m.ECta_Abno_Loc),(m.ECta_Crgo_Ext - IF(h.HDoc_Doc_TC = 1, m.ECta_Abno_Loc , m.ECta_Abno_Ext)) * IF(m.ECta_TC <> 0, m.ECta_TC, h.HDoc_Doc_TC)) Saldo
                            FROM ECtaCte m
                            LEFT JOIN Dcmtos_HDR e ON e.HDoc_Sis_Emp = m.ECta_Sis_Emp AND e.HDoc_Doc_Cat = m.ECta_Doc_Cat AND e.HDoc_Doc_Ano = m.ECta_Doc_Ano AND e.HDoc_Doc_Num = m.ECta_Doc_Num
                            LEFT JOIN Dcmtos_HDR h ON h.HDoc_Sis_Emp = m.ECta_Sis_Emp AND h.HDoc_Doc_Cat = m.ECta_Ref_Cat AND h.HDoc_Doc_Ano = m.ECta_Ref_Ano AND h.HDoc_Doc_Num = m.ECta_Ref_Num
                            LEFT JOIN Catalogos t ON t.cat_clase = 'Documentos' AND t.cat_num = m.ECta_Doc_Cat 
                                WHERE m.ECta_Sis_Emp = {empresa} AND m.ECta_Ref_Cat = {catalogo} AND m.ECta_Ref_Ano = {anio} AND m.ECta_Ref_Num = {num}
                                ORDER BY m.ECta_FecDcmt, m.ECta_TransId "

        strsql = Replace(strsql, "{empresa}", Sesion.IdEmpresa)
        strsql = Replace(strsql, "{anio}", intAnio)
        strsql = Replace(strsql, "{num}", intNumero)
        strsql = Replace(strsql, "{catalogo}", intTipo)
        strsql = Replace(strsql, "{loc}", cfun.DivisaLocal)

        Return strsql

    End Function

    Private Function SQLFechaVence(ByVal num As Integer)
        Dim strsql As String = STR_VACIO

        strsql = " Select pro_plazoCR plazo"
        strsql &= "     From Proveedores"
        strsql &= "         WHERE pro_sisemp = {empresa} And pro_codigo = {cod}"

        strsql = Replace(strsql, "{empresa}", Sesion.IdEmpresa)
        strsql = Replace(strsql, "{cod}", num)

        Return strsql

    End Function

    Private Function SQLProrrateo()
        Dim strsql As String = STR_VACIO


        strsql = " Select cost_nombre Nombre, cost_num Id"
        strsql &= "    From {conta}.costos"
        strsql &= " ORDER BY cost_num"

        strsql = Replace(strsql, "{conta}", cfun.ContaEmpresa)

        Return strsql

    End Function

    Private Function sqlOrdenesSinAsignar(ByVal CodEmpresa As String)
        Dim strSQL As String

        strSQL = " Select h.HDoc_Sis_Emp empresa, h.HDoc_Doc_Cat tipo, h.HDoc_Doc_Ano anio, h.HDoc_Doc_Num numero, h.HDoc_Doc_Fec fecha, h.HDoc_DR1_Num referencia, h.HDoc_Emp_Nom Nombre, h.HDoc_Emp_Cod codempresa"
        strSQL &= "  FROM Dcmtos_HDR h"
        strSQL &= "      LEFT JOIN Dcmtos_DTL_Pro p On p.PDoc_Sis_Emp = h.HDoc_Sis_Emp And p.PDoc_Par_Cat = h.HDoc_Doc_Cat And p.PDoc_Par_Ano = h.HDoc_Doc_Ano And p.PDoc_Par_Num = h.HDoc_Doc_Num"
        strSQL &= "          LEFT JOIN Dcmtos_HDR hh On hh.HDoc_Sis_Emp = p.PDoc_Sis_Emp And hh.HDoc_Doc_Cat = p.PDoc_Chi_Cat And hh.HDoc_Doc_Ano = p.PDoc_Chi_Ano And hh.HDoc_Doc_Num = p.PDoc_Chi_Num And hh.HDoc_Doc_Status = 1"
        strSQL &= "      WHERE h.HDoc_Sis_Emp = {empresa} And h.HDoc_Doc_Cat = 777 And  h.HDoc_Doc_Status =1 And hh.HDoc_Sis_Emp Is NULL And h.HDoc_Emp_Cod = {codEmpresa}"
        strSQL &= "   ORDER BY h.HDoc_Sis_Emp , h.HDoc_Doc_Cat, h.HDoc_Doc_Ano desc , h.HDoc_Doc_Num desc"
        strSQL &= " LIMIT 20"

        strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
        strSQL = Replace(strSQL, "{codEmpresa}", CodEmpresa)

        Return strSQL
    End Function

    Private Function SQLRefEnImportacion(ByVal intAnio As Integer, ByVal intNum As Integer, ByVal strDoc As String)
        Dim strsql As String = STR_VACIO
        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader
        Dim strList As String
        Dim i As Integer
        Dim strTemp As String
        Dim Condicion As String = STR_VACIO
        Dim Tabla As String = STR_VACIO
        Dim frm As New frmSeleccionar
        Dim sumaFila As Integer = 0
        Dim strfila As String = STR_VACIO
        Dim logVerificar As Boolean = True

        strList = vbNullString

        Try
            Condicion = " a.Tipo> 0 "

            frm.Titulo = " Select the policy number to use "
            frm.Campos = " a.Tipo Tipo, a.Anio Anio,a.Numero Numero, a.Linea Linea, a.Descripcion Descripcion, a.Precio Precio, a.Cantidad Cantidad, a.fechaIngreso fechaIngreso, a.TC_Poliza TC_Poliza "
            Tabla = " (
                        SELECT d.DDoc_Doc_Cat Tipo, d.DDoc_Doc_Ano Anio, d.DDoc_Doc_Num Numero, d.DDoc_Doc_Lin Linea, a.art_DCorta Descripcion, d.DDoc_Prd_NET Precio, ((d.DDoc_Prd_QTY) - IFNULL((
                        SELECT SUM(c.PDoc_QTY_Pro)
                        FROM Dcmtos_DTL_Pro c
                        WHERE c.PDoc_Sis_Emp=d.DDoc_Sis_Emp AND c.PDoc_Par_Cat=d.DDoc_Doc_Cat AND c.PDoc_Par_Ano=d.DDoc_Doc_Ano AND c.PDoc_Par_Num=d.DDoc_Doc_Num AND c.PDoc_Par_Lin = d.DDoc_Doc_Lin AND c.PDoc_Chi_Cat=44),0)) Cantidad
                            , h.HDoc_Doc_TC TC_Poliza
	                            ,(		
	                            SELECT h47.HDoc_Doc_Fec 
	                            FROM Dcmtos_DTL_Pro pp180
	                            JOIN Dcmtos_HDR h47 
		                            ON pp180.PDoc_Sis_Emp=h47.HDoc_Sis_Emp
			                            AND pp180.PDoc_Chi_Cat=h47.HDoc_Doc_Cat
			                            AND pp180.PDoc_Chi_Ano=h47.HDoc_Doc_Ano
			                            AND pp180.PDoc_Chi_Num=h47.HDoc_Doc_Num
			                            AND h47.HDoc_Doc_Cat=47
	                            WHERE pp180.PDoc_Sis_Emp=h.HDoc_Sis_Emp
	                            AND pp180.PDoc_Par_Cat=d.DDoc_Doc_Cat
	                            AND pp180.PDoc_Par_Ano=d.DDoc_Doc_Ano
	                            AND pp180.PDoc_Par_Num=d.DDoc_Doc_Num
	                            AND pp180.PDoc_Par_Lin=d.DDoc_Doc_Lin	
	                            )fechaIngreso
                            FROM Dcmtos_DTL d
                            LEFT JOIN Inventarios i ON i.inv_sisemp=d.DDoc_Sis_Emp AND i.inv_numero=d.DDoc_Prd_Cod
                            LEFT JOIN Articulos a ON a.art_sisemp=i.inv_sisemp AND a.art_codigo=i.inv_artcodigo
                            LEFT JOIN Dcmtos_HDR h 
	                            ON d.DDoc_Sis_Emp=h.HDoc_Sis_Emp 
		                            AND d.DDoc_Doc_Cat=h.HDoc_Doc_Cat
		                            AND d.DDoc_Doc_Ano=h.HDoc_Doc_Ano
		                            AND d.DDoc_Doc_Num=h.HDoc_Doc_Num
                                WHERE d.DDoc_Sis_Emp= {emp} AND d.DDoc_Doc_Cat=180 AND d.DDoc_Doc_Ano=  {anio} AND d.DDoc_Doc_Num= {num}
                                HAVING Cantidad > 0) a "

            Tabla = Replace(Tabla, "{emp}", Sesion.IdEmpresa)
            Tabla = Replace(Tabla, "{anio}", intAnio)
            Tabla = Replace(Tabla, "{num}", intNum)

            frm.Tabla = Tabla

            frm.FiltroText = "Enter Number"
            frm.Filtro = "Numero"
            frm.Condicion = Condicion
            frm.Multiple = True
            frm.ShowDialog(Me)

            If frm.DialogResult = System.Windows.Forms.DialogResult.OK Then

                For i = INT_CERO To frm.DataGrid.Rows.Count - 1
                    If frm.ListaClientes.Rows(i).Cells("colCheck").Value = True Then
                        logVerificar = True

                        If logVerificar = True Then
                            ' Agrega al DataGrid de Polizas 
                            strfila = frm.ListaClientes.Rows(i).Cells(1).Value & "|" 'Catalogo
                            strfila &= frm.ListaClientes.Rows(i).Cells(2).Value & "|" 'Año
                            strfila &= frm.ListaClientes.Rows(i).Cells(3).Value & "|" ' Numero
                            strfila &= strDoc & "|" 'Referencia
                            strfila &= frm.ListaClientes.Rows(i).Cells(4).Value & "|" 'linea
                            strfila &= frm.ListaClientes.Rows(i).Cells(7).Value & "|" 'Cantidad
                            strfila &= frm.ListaClientes.Rows(i).Cells(6).Value & "|" ' Precio
                            strfila &= (frm.ListaClientes.Rows(i).Cells(7).Value * frm.ListaClientes.Rows(i).Cells(6).Value) 'Total

                            cFunciones.AgregarFila(dgPoliza, strfila)

                            ' Agrega al DataGrid de Detalle
                            AgregaAlDetalle(frm.ListaClientes.Rows(i).Cells(1).Value, frm.ListaClientes.Rows(i).Cells(2).Value, frm.ListaClientes.Rows(i).Cells(3).Value, frm.ListaClientes.Rows(i).Cells(4).Value)
                        End If
                    End If
                    dtpFechaPolizaC.Value = frm.ListaClientes.Rows(i).Cells(8).Value
                Next

                ' Actualiza el total
                CalcuarImpuesto()

                For i = 0 To dgImpuestos.Rows.Count - 1
                    sumaFila = sumaFila + 1
                Next

                If sumaFila > 1 Then

                    For i = 0 To dgImpuestos.Rows.Count - 1
                        If dgImpuestos.Rows(i).Cells(4).Value = "IVA" Then
                            dgImpuestos.Rows(i).Cells(7).Value = etiquetaMontoTotal.Text
                            Exit For
                        End If
                    Next
                End If
            End If

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try


    End Function

    Private Function SQLEstadoPoliza(ByVal intAnio As Integer, ByVal intNumero As Integer, ByVal intCatOc As Integer)
        Dim strsql As String = STR_VACIO

        strsql = " SELECT IFNULL(p.revisado,0) revisado"
        strsql &= " From Dcmtos_HDR h"
        strsql &= " Left JOIN {conta}.polizas p ON p.empresa = h.HDoc_Sis_Emp AND p.ref_tipo = h.HDoc_Doc_Cat AND p.ref_ciclo = h.HDoc_Doc_Ano AND p.ref_numero = h.HDoc_Doc_Num"
        strsql &= " WHERE h.HDoc_Sis_Emp = {empresa} AND h.HDoc_Doc_Cat = {catalogo} AND h.HDoc_Doc_Ano ={anio} AND h.HDoc_Doc_Num = {num}"

        strsql = Replace(strsql, "{empresa}", Sesion.IdEmpresa)
        strsql = Replace(strsql, "{conta}", cfun.ContaEmpresa)
        strsql = Replace(strsql, "{catalogo}", intCatOc)
        strsql = Replace(strsql, "{anio}", intAnio)
        strsql = Replace(strsql, "{num}", intNumero)

        Return strsql

    End Function

    Private Function SQLRelacion(ByVal tipo As Integer, ByVal anio As Integer, ByVal numero As Integer, ByVal linea As Integer)
        Dim strsql As String = STR_VACIO

        strsql = " SELECT d.DDoc_Doc_Cat Tipo, d.DDoc_Doc_Ano Anio, d.DDoc_Doc_Num Numero, d.DDoc_Doc_Lin Linea, a.art_DCorta Descripcion, d.DDoc_Prd_NET Precio, d.DDoc_Prd_QTY - IFNULL(( "
        strsql &= " Select SUM(c.PDoc_QTY_Pro) "
        strsql &= " From Dcmtos_DTL_Pro c "
        strsql &= " WHERE c.PDoc_Sis_Emp=d.DDoc_Sis_Emp AND c.PDoc_Par_Cat=d.DDoc_Doc_Cat AND c.PDoc_Par_Ano=d.DDoc_Doc_Ano AND c.PDoc_Par_Num=d.DDoc_Doc_Num AND c.PDoc_Par_Lin = d.DDoc_Doc_Lin AND c.PDoc_Chi_Cat=44),0) Cantidad "
        strsql &= " From Dcmtos_DTL d "
        strsql &= " Left JOIN Inventarios i ON i.inv_sisemp=d.DDoc_Sis_Emp AND i.inv_numero=d.DDoc_Prd_Cod "
        strsql &= " Left JOIN Articulos a ON a.art_sisemp=i.inv_sisemp AND a.art_codigo=i.inv_artcodigo "
        strsql &= " WHERE d.DDoc_Sis_Emp={empresa} AND d.DDoc_Doc_Cat=180 AND d.DDoc_Doc_Ano={anio} AND d.DDoc_Doc_Num={num} AND d.DDoc_Doc_Lin = {lin}"
        strsql &= " HAVING Cantidad > 0 "

        strsql = Replace(strsql, "{empresa}", Sesion.IdEmpresa)
        strsql = Replace(strsql, "{tipo}", tipo)
        strsql = Replace(strsql, "{anio}", anio)
        strsql = Replace(strsql, "{num}", numero)
        strsql = Replace(strsql, "{lin}", linea)

        Return strsql

    End Function

    Private Function QueryDetalleOrden(ByVal intAnio As Integer, ByVal intNumero As Integer)
        Dim strSQL As String = STR_VACIO

        strSQL = " SELECT l1.empresa empresa,l1.tipo tipo,l1.anio anio,l1.numero numero,l1.linea linea,l1.descripcion descripcion,l1.precio precio,ROUND(l1.cantidad - l1.Saldo,2) cantidad, l1.costCenter costCenter,l1.CodProducto CodProducto, l1.costNombre costNombre,l1.fecha fecha "
        strSQL &= " FROM ( "
        strSQL &= "    SELECT d.DDoc_Sis_Emp empresa, d.DDoc_Doc_Cat tipo, d.DDoc_Doc_Ano anio, d.DDoc_Doc_Num numero, d.DDoc_Doc_Lin linea, d.DDoc_Prd_Des descripcion, d.DDoc_Prd_NET precio, d.DDoc_Prd_QTY cantidad, d.DDoc_RF1_Num costCenter, d.DDoc_Prd_Cod CodProducto, c.cost_nombre costNombre,h.HDoc_Doc_Fec Fecha"
        strSQL &= "     ,IFNULL(( "
        strSQL &= "         SELECT SUM(p.PDoc_QTY_Ord) "
        strSQL &= "             FROM Dcmtos_DTL_Pro p "
        strSQL &= "                 WHERE p.PDoc_Sis_Emp = d.DDoc_Sis_Emp AND p.PDoc_Par_Cat = d.DDoc_Doc_Cat AND p.PDoc_Par_Ano = d.DDoc_Doc_Ano AND p.PDoc_Par_Num = d.DDoc_Doc_Num AND p.PDoc_Par_Lin = d.DDoc_Doc_Lin AND p.PDoc_Chi_Cat = 44),0) Saldo "
        strSQL &= "      FROM Dcmtos_DTL d"
        strSQL &= "           LEFT JOIN {conta}.costos c ON c.cost_num = d.DDoc_RF1_Num"
        strSQL &= "         LEFT JOIN Dcmtos_HDR h ON h.HDoc_Sis_Emp = d.DDoc_Sis_Emp AND h.HDoc_Doc_Cat = d.DDoc_Doc_Cat AND h.HDoc_Doc_Ano = d.DDoc_Doc_Ano AND h.HDoc_Doc_Num = d.DDoc_Doc_Num "
        strSQL &= "      WHERE d.DDoc_Sis_Emp ={empresa} AND d.DDoc_Doc_Cat = 777 AND d.DDoc_Doc_Ano = {anio} AND d.DDoc_Doc_Num = {numero} and d.DDoc_RF3_Num=0 )l1 HAVING(cantidad > 0) "

        strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
        strSQL = Replace(strSQL, "{anio}", intAnio)
        strSQL = Replace(strSQL, "{numero}", intNumero)
        strSQL = Replace(strSQL, "{conta}", cfun.ContaEmpresa)

        Return strSQL
    End Function

    Private Function GenerarRetencionISR(ByVal intAnio As Integer, ByVal intNum As Integer)
        Dim strSQL As String = STR_VACIO

        strSQL = " SELECT IFNULL(c.cat_clave,'') Moneda, e.HDoc_DR1_Num Documento, e.HDoc_DR2_Num Serie, e.HDoc_Emp_Cod ID, e.HDoc_Emp_Nom Nombre, e.HDoc_Emp_NIT NIT, e.HDoc_RF1_Dbl Total, e.HDoc_Doc_Mon Divisa, e.HDoc_Doc_TC Tasa, e.HDoc_Doc_Fec Fecha, CURDATE() Hoy, (e.HDoc_RF1_Num!=0) Importacion, (IFNULL(r.HDoc_Doc_Num,0)!=0) Retencion "
        strSQL &= " From Dcmtos_HDR e "
        strSQL &= " Left JOIN Dcmtos_HDR r ON r.HDoc_Sis_Emp=e.HDoc_Sis_Emp AND r.HDoc_Doc_Cat=e.HDoc_Pro_DCat AND r.HDoc_Pro_DAno=e.HDoc_Doc_Ano AND r.HDoc_Pro_DNum=e.HDoc_Doc_Num AND r.HDoc_Doc_Cat=220 "
        strSQL &= " Left JOIN Catalogos c ON c.cat_clase='Monedas' AND c.cat_num=e.HDoc_Doc_Mon "
        strSQL &= " WHERE e.HDoc_Sis_Emp={empresa} AND e.HDoc_Doc_Cat=44 AND e.HDoc_Doc_Ano={anio} AND e.HDoc_Doc_Num={num} "

        strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
        strSQL = Replace(strSQL, "{anio}", intAnio)
        strSQL = Replace(strSQL, "{num}", intNum)

        Return strSQL

    End Function

    Private Function FactorImpuestos()
        Dim strsql As String = STR_VACIO

        strsql = " SELECT ROUND(a.cat_sist,2) factorIVA, ROUND(c.cat_sist,2) factorISR "
        strsql &= " From Catalogos a "
        strsql &= " Left join Catalogos c on c.cat_clase = a.cat_clase and c.cat_clave = 'ISR_RG' "
        strsql &= " WHERE a.cat_clase='Impuestos' and a.cat_sisemp = {empresa} and a.cat_clave = 'IVA' "

        strsql = Replace(strsql, "{empresa}", Sesion.IdEmpresa)

        Return strsql

    End Function

    Private Function Activos(ByVal intCodigo As Integer)
        Dim strsql As String = STR_VACIO

        strsql = " SELECT a.Empresa,a.Codigo, t.Codigo CodigoTA,a.Descripcion, a.id_tipo,a.Marca,a.Modelo,a.SN,a.Color,a.id_Proveedor,a.Factura,a.Serie,a.Fecha,a.Id_Moneda,a.Tasa,a.Precio,a.Valor,a.Dias_Depreciados,a.Dias_Pendientes,a.Id_Usuario,a.Ref_Cat,a.Ref_año,a.Ref_Num,a.Ref_Lin,a.Pro_Fecha,a.Pro_Meses "
        strsql &= " From Activos a"
        strsql &= " Left Join tipos_activo t on t.Codigo = a.id_Tipo and t.Empresa = a.Empresa "
        strsql &= " WHERE a.Empresa = {empresa} AND a.Codigo = {cod} "

        strsql = Replace(strsql, "{empresa}", Sesion.IdEmpresa)
        strsql = Replace(strsql, "{cod}", intCodigo)

        Return strsql
    End Function

    Private Function VerificarProveedor() As Boolean
        Dim i As Integer
        Dim strSQL As String = STR_VACIO
        Dim strTemp As String
        Dim strDoc As String
        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader

        Try

            strDoc = vbNullString
            For i = 0 To dgPoliza.Rows.Count - 1
                strTemp = " HDoc_Sis_Emp = " & Sesion.IdEmpresa & " And" & " HDoc_Doc_Cat = " & dgPoliza.Rows(i).Cells("colTipo1").Value & " And" & " HDoc_Doc_Ano = " & dgPoliza.Rows(i).Cells("colAño").Value & " AND " & " HDoc_Doc_Num = " & dgPoliza.Rows(i).Cells("colNum").Value
                If InStr(1, strDoc, strTemp) = vbEmpty Then
                    strDoc = strDoc & IIf(strDoc = vbNullString, vbNullString, vbNullChar) & strTemp
                End If
            Next

            strDoc = "(" & Replace(strDoc, vbNullChar, ") Or (") & ")"

            strSQL = "Select Count(*) From Dcmtos_HDR Where Not(HDoc_Emp_Cod = " & celdaProveedor1.Text & ") And " & strDoc

            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSQL, CON)
            i = NO_FILA
            i = COM.ExecuteScalar

            VerificarProveedor = (i = vbEmpty)

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try

    End Function

    Private Function EnLibroCompras(ByVal Anio As Integer, ByVal Numero As Integer, Optional Mensaje As Boolean = False, Optional Texto As String = vbNullString) As Boolean
        Dim strsql As String = STR_VACIO
        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader
        Dim logCompra As Boolean = False

        strsql = " Select e.HDoc_Doc_Fec Fecha, e.HDoc_DR1_Num Mes "
        strsql &= " From Dcmtos_DTL d "
        strsql &= " Left JOIN Dcmtos_HDR e On e.HDoc_Sis_Emp=d.DDoc_Sis_Emp And e.HDoc_Doc_Cat=d.DDoc_Doc_Cat And e.HDoc_Doc_Ano=d.DDoc_Doc_Ano And e.HDoc_Doc_Num=d.DDoc_Doc_Num "
        strsql &= " WHERE d.DDoc_Sis_Emp={empresa} And d.DDoc_RF1_Num=44 And d.DDoc_RF2_Num={anio} And d.DDoc_RF3_Num={num} And e.HDoc_Doc_Status=1   AND d.DDoc_Doc_Cat = 286"
        strsql &= " LIMIT 1 "

        strsql = Replace(strsql, "{empresa}", Sesion.IdEmpresa)
        strsql = Replace(strsql, "{anio}", Anio)
        strsql = Replace(strsql, "{num}", Numero)

        Try
            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strsql, CON)
            REA = COM.ExecuteReader

            If REA.HasRows Then
                REA.Read()

                If Mensaje = True Then
                    MsgBox("La Factura se encuentra en el Libro " & REA.GetString("Mes") & IIf(Texto = vbNullString, vbNullString, vbCrLf & vbCrLf & Texto), IIf(Texto = vbNullString, vbInformation, vbExclamation), "Shopping Book")
                End If
                logCompra = True
            End If

            Return logCompra

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try


    End Function

    Private Function FechaActual(ByVal Fecha)
        Dim strSQL As String = STR_VACIO

        strSQL = " Select CURDATE() Fecha "
        strSQL &= " From Dcmtos_HDR "
        strSQL &= " WHERE HDoc_Sis_Emp={empresa} And HDoc_Doc_Cat=44 And DATE_FORMAT(HDoc_Doc_Fec,'%Y%m')='{fecha}' AND HDoc_Doc_Status=1 "
        strSQL &= " Limit 1 "

        strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
        strSQL = Replace(strSQL, "{fecha}", (Format(Fecha, "yyyyMM")))

        Return strSQL

    End Function

    Private Function CrearRISRProveedor() As Boolean
        Dim frm As New frmDateTimePicker
        Dim anio As Integer = celdaAnioOc.Text
        Dim numero As Integer = celdaNumOc.Text
        Dim strSQL As String = STR_VACIO
        Dim COM As New MySqlCommand
        Dim REA As MySqlDataReader
        Dim strSQL2 As String = STR_VACIO
        Dim COM2 As New MySqlCommand
        Dim REA2 As MySqlDataReader
        Dim conec As MySqlConnection
        Dim strfila As String = STR_VACIO
        Dim SelecFecha As Date
        Dim FISR As Double
        Dim FIVA As Double
        Dim montoDoc As Double
        Dim dblMonto As Double
        Dim dblImpuesto As Double
        Dim valorInput As Double
        Dim Titulo As String
        Dim Texto As String
        Dim Valor As String
        Dim dblTotal As Double
        Dim VerISR As Integer

        strSQL2 = " SELECT count(*) "
        strSQL2 &= " From Dcmtos_HDR r "
        strSQL2 &= " WHERE r.HDoc_Sis_Emp = {empresa} AND r.HDoc_Doc_Cat = 220 AND r.HDoc_Pro_DCat = 44 AND r.HDoc_Pro_DAno = {anio} AND r.HDoc_Pro_DNum = {num} "

        strSQL2 = Replace(strSQL2, "{empresa}", Sesion.IdEmpresa)
        strSQL2 = Replace(strSQL2, "{anio}", celdaAnioOc.Text)
        strSQL2 = Replace(strSQL2, "{num}", celdaNumOc.Text)

        conec = New MySqlConnection(strConexion)
        conec.Open()
        COM = New MySqlCommand(strSQL2, conec)
        VerISR = COM.ExecuteScalar
        conec.Close()

        strSQL = GenerarRetencionISR(anio, numero)

        Try

            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSQL, CON)
            REA = COM.ExecuteReader


            If Not REA.HasRows Then
                MsgBox("Invoice Not Found!", vbExclamation, "Notice")

            ElseIf rbImportación.Checked = True Then
                MsgBox("Does not apply to imports!", vbExclamation, "Notice")


            ElseIf VerISR > 0 Then
                MsgBox("This Invoice Already Has Withholding!", vbExclamation, "Notice")

            Else
                Do While REA.Read

                    frm.ShowDialog(Me)
                    If frm.DialogResult = System.Windows.Forms.DialogResult.OK Then
                        SelecFecha = frm.LLave

                        If SelecFecha < REA.GetDateTime("Fecha") Or SelecFecha > REA.GetDateTime("Hoy") Then
                            MsgBox("The retention document can not be dated less than the invoice or after the current one", vbExclamation, "Notice")
                        Else



                            strSQL2 = FactorImpuestos()

                            conec = New MySqlConnection(strConexion)
                            conec.Open()
                            COM2 = New MySqlCommand(strSQL2, conec)
                            REA2 = COM2.ExecuteReader

                            If REA2.HasRows Then
                                REA2.Read()

                                FISR = REA2.GetDouble("factorISR")
                                FIVA = REA2.GetDouble("factorIVA")

                                FIVA = 1 + (FIVA / 100)
                                conec.Close()

                                strSQL2 = STR_VACIO

                                strSQL2 = " SELECT IFNULL(SUM(MDoc_Lin_Monto),0) "
                                strSQL2 &= " From Dcmtos_IMP "
                                strSQL2 &= " WHERE MDoc_Sis_Emp={empres} AND MDoc_Doc_Cat=44 AND MDoc_Doc_Ano={anio} AND MDoc_Doc_Num={num} AND MDoc_Lin_Tipo=(-1) "

                                strSQL2 = Replace(strSQL2, "{empres}", Sesion.IdEmpresa)
                                strSQL2 = Replace(strSQL2, "{anio}", anio)
                                strSQL2 = Replace(strSQL2, "{num}", numero)

                                conec = New MySqlConnection(strConexion)
                                conec.Open()
                                COM2 = New MySqlCommand(strSQL2, conec)
                                montoDoc = COM2.ExecuteScalar
                                conec.Close()

                                FISR = (FISR / 100)
                                dblMonto = Math.Round((((REA.GetDouble("Total") * REA.GetDouble("Tasa")) - montoDoc) / FIVA), 2)
                                dblImpuesto = Math.Round(dblMonto * FISR, 2)


                                Titulo = "ISR RETENTION"
                                Texto = ("*VERIFICAR* " & vbLf & vbLf & " FECHA: " & frm.LLave & vbLf & " MONTO: " & dblMonto & vbLf & " PORCENTAJE: " & Math.Round(FISR, 2) * 100 & "% " & vbLf & " RETENCIÓN: " & dblImpuesto)
                                Valor = dblImpuesto

                                valorInput = InputBox(Texto, Titulo, Valor)

                                If Not valorInput = vbNullString Then

                                    valorInput = Trim(valorInput)

                                    If valorInput.ToString.Length > dblMonto.ToString.Length Then
                                        dblTotal = Val(valorInput.ToString.Substring(0, dblMonto.ToString.Length))
                                    Else
                                        dblTotal = Val(valorInput)
                                    End If


                                    Texto = "*CONFIRMAR*" & vbLf & vbLf & " FECHA: " & frm.LLave & vbLf & vbLf & " MONTO: " & dblMonto & vbLf & vbLf & " RETENCIÓN: " & valorInput

                                    If (dblTotal <= vbEmpty) Or (dblTotal >= dblMonto) Then
                                        MsgBox("The amount entered is not valid", vbExclamation, "Amount Invalid")
                                    ElseIf MsgBox(Texto, vbInformation + vbOKCancel, "Confirm Retention") = vbOK Then
                                        dblImpuesto = dblTotal

                                        If sqlGuardarRISRProveedor(dblImpuesto) = True Then
                                            CtaCorienteRISR(dblImpuesto)
                                            MsgBox("Retention document generated" & vbCrLf & vbCrLf & "Retention N°: " & NumISR & vbCrLf & "Date: " & celdaFecha1.Text & vbCrLf & vbCrLf & "Amount withheld: " & Divisa.Local.simbolo & " " & Math.Round(dblImpuesto, 2), vbInformation, "ISR Withholding / Provider")

                                            CrearRISRProveedor = True
                                        End If
                                    End If

                                End If

                            Else
                                MsgBox("The percentage of ISR to be withheld could not be determined", vbExclamation, "Notice")

                            End If

                        End If
                        'valorInput = InputBox("*VERIFICAR* " & vbLf & vbLf & " FECHA: " & frm.LLave & vbLf & " MONTO: " & dblMonto & vbLf & " PORCENTAJE: " & Math.Round(FISR, 2) * 100 & "% " & vbLf & " RETENCIÓN: " & dblImpuesto & vbLf, vbLf & "ISR RETENTION")

                    End If

                Loop


            End If

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Function

    Private Function sqlGuardarRISRProveedor(ByVal dblImpuesto As Double) As Boolean
        Dim logResultado As Boolean = False
        Dim HDR As New clsDcmtos_HDR


        HDR.CONEXION = strConexion

        NumISR = cfun.NuevoId(220)
        Try
            HDR.HDOC_SIS_EMP = Sesion.IdEmpresa
            HDR.HDOC_DOC_CAT = 220
            HDR.HDOC_DOC_ANO = celdaAnioOc.Text
            HDR.HDOC_DOC_NUM = NumISR
            HDR.HDoc_Doc_Fec_NET = celdaFecha1.Text
            HDR.HDOC_EMP_COD = celdaProveedor1.Text
            HDR.HDOC_EMP_NOM = celdaProveedor.Text
            HDR.HDOC_EMP_NIT = celdaNIT.Text
            HDR.HDOC_DR1_NUM = vbNullString
            HDR.HDOC_DR2_NUM = celdaNumero.Text & " " & celdaSerie.Text
            HDR.HDOC_RF1_TXT = celdaMoneda.Text & " " & celdaMonto.Text(FORMATO_MONEDA) & "/ T.C.: " & celdaTasa.Text(FORMATO_MONEDA)
            HDR.HDOC_USUARIO = Sesion.Usuario
            HDR.HDOC_PRO_DCAT = celdaCatOc.Text
            HDR.HDOC_PRO_DANO = celdaAnioOc.Text
            HDR.HDOC_PRO_DNUM = celdaNumOc.Text
            HDR.HDOC_DOC_TC = INT_UNO
            HDR.HDOC_DOC_MON = Divisa.Local.id
            HDR.HDOC_RF1_DBL = dblImpuesto
            HDR.HDOC_DOC_STATUS = vbEmpty

            If HDR.Guardar() = False Then
                MsgBox(HDR.MERROR.ToString & "Could not save the document", MsgBoxStyle.Critical)
            Else
                logResultado = True
            End If

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        Return logResultado

    End Function

    Private Function CtaCorienteRISR(ByVal impuesto As Double) As Boolean
        Dim logResultado As Boolean = False
        Dim cta As New Tablas.TECTACTE

        cta.CONEXION = strConexion

        Try
            cta.ECTA_SIS_EMP = Sesion.IdEmpresa
            cta.ECTA_DOC_CAT = 220
            cta.ECTA_DOC_ANO = celdaAnioOc.Text
            cta.ECTA_DOC_NUM = NumISR
            cta.ECTA_DOC_LIN = INT_UNO
            cta.ECTA_TIPOEMP = "Proveedores"
            cta.ECTA_CODEMP = celdaProveedor1.Text
            cta.ECTA_SINI_LOC = vbEmpty
            cta.ECTA_CRGO_LOC = vbEmpty
            cta.ECTA_ABNO_LOC = impuesto
            cta.ECTA_SINI_EXT = vbEmpty
            cta.ECTA_CRGO_EXT = vbEmpty
            cta.ECTA_ABNO_EXT = (impuesto / celdaTasa.Text)
            cta.ECTA_CONCEPTO = "Retencion ISR / " & celdaNumero.Text & " " & celdaSerie.Text
            cta.ECta_FecVenc_NET = celdaFecha1.Text
            cta.ECta_FecDcmt_NET = celdaFecha1.Text
            cta.ECTA_MONEDA = celdaMoneda1.Text
            cta.ECTA_TC = celdaTasa.Text
            cta.ECTA_REF_CAT = celdaCatOc.Text
            cta.ECTA_REF_ANO = celdaAnioOc.Text
            cta.ECTA_REF_NUM = celdaNumOc.Text

            If Me.Tag = "Mod" Then
                If cta.PUPDATE = False Then
                    MsgBox(cta.MERROR.ToString & "Could not update the document", MsgBoxStyle.Critical)
                End If
            Else
                If cta.PINSERT = False Then
                    MsgBox(cta.MERROR.ToString & "Could not update the document", MsgBoxStyle.Critical)
                End If
            End If

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try

        logResultado = True

    End Function

    Private Function sqlGuardarFact(ByVal datFecha As Date, ByVal dblDebito As Double, ByVal dblCredito As Double, ByVal dblTotal As Double, ByVal dblMontoProd As Double) As Boolean
        Dim intClase As Integer
        Dim logResultado As Boolean
        Dim hdr As New clsDcmtos_HDR

        hdr.CONEXION = strConexion

        Try
            hdr.HDOC_SIS_EMP = Sesion.IdEmpresa
            hdr.HDOC_DOC_CAT = celdaCatOc.Text
            hdr.HDOC_DOC_ANO = celdaAnioOc.Text
            hdr.HDOC_DOC_NUM = celdaNumOc.Text

            'Tipos de Factura
            If rbImportación.Checked = True Then
                'Importación
                intClase = NO_FILA
            ElseIf checkFacElectrónica.Checked = True Then
                'Electrónca
                intClase = INT_UNO
            ElseIf checkContribuyent.Checked = True Then
                'Pequeño Contribuyente
                intClase = 2
            ElseIf rbOrdenDeCompra.Checked = True Then
                'Orden de Compra
                intClase = 3
            Else
                intClase = vbEmpty
            End If

            hdr.HDoc_Doc_Fec_NET = celdaFecha1.Text 'Fecha
            hdr.HDoc_DR2_Fec_NET = dtpFechaPolizaC.Value.ToString(FORMATO_MYSQL)
            hdr.HDOC_EMP_COD = celdaProveedor1.Text 'id_Proveeedor
            hdr.HDOC_EMP_NOM = celdaProveedor.Text ' Proveedor
            hdr.HDOC_EMP_NIT = "NULL"
            hdr.HDOC_DR1_CAT = vbEmpty
            hdr.HDOC_EMP_DIR = celdaIdResolución.Text ' este campo viene de la orden de compra ( cat = 777 )
            hdr.HDOC_DR1_EMP = intClase ' Importación, electrónica o Peq. Contribuyente, Orden de Compra
            hdr.HDOC_DR1_NUM = Replace(celdaNumero.Text.ToString, "|", "")  'Numero de Factura
            hdr.HDoc_DR1_Fec_NET = celdaFechaVence.Text 'Fecha de Vencimiento
            hdr.HDOC_DR2_CAT = IIf(Extemporaneo, INT_UNO, vbEmpty) 'EXTEMPORANEO
            hdr.HDOC_DR2_NUM = celdaSerie.Text 'Serie de la Factura
            'hdr.HDoc_DR2_Fec_NET = IIf(checkCompra.Checked = True, "NULL", datFecha) ' si es importación ponga NULL si no ponga fecha
            hdr.HDOC_DR2_EMP = IIf(checkContribuyent.Checked = False, INT_UNO, vbEmpty) 'si es peq. Contribuyente ponga 0 si no ponga 1
            If rbImportación.Checked = True Then
                hdr.HDOC_RF1_NUM = INT_UNO
            ElseIf rbOrdenDeCompra.Checked = True Then
                hdr.HDOC_RF1_NUM = 2
            Else
                hdr.HDOC_RF1_NUM = INT_CERO
            End If
            hdr.HDOC_RF1_COD = IIf(celdaTipoOrden.Text = vbNullString, "NULL", IIf(celdaTipoOrden.Text = NO_FILA, "NULL", celdaTipoOrden.Text))
            hdr.HDOC_RF1_TXT = celdaNotas.Text 'Notas
            hdr.HDOC_RF2_NUM = IIf(checkActivoFijo.Checked = True, INT_UNO, vbEmpty) ' Si es activo Fijo ponga 1 si no 0
            hdr.HDOC_RF2_COD = STR_VACIO
            hdr.HDOC_RF2_TXT = ""
            hdr.HDOC_USUARIO = Sesion.Usuario ' Usuario
            hdr.HDOC_DOC_TC = celdaTasa.Text ' Tipo de Cambio
            hdr.HDOC_DOC_MON = celdaMoneda1.Text 'id Moneda
            hdr.HDOC_RF1_DBL = dblDebito
            hdr.HDOC_RF2_DBL = dblCredito
            hdr.HDOC_RF3_DBL = dblTotal
            hdr.HDOC_DR1_DBL = dblMontoProd ' total factura afectada con IVA NSM
            If checkActive.Visible = True Then
                hdr.HDOC_DOC_STATUS = IIf(checkActive.Checked = True, INT_UNO, INT_CERO)
            Else
                hdr.HDOC_DOC_STATUS = IIf(logAnulado, vbEmpty, INT_UNO)
            End If

            hdr.HDOC_RF2_COD = celdaCAI.Text
            hdr.HDOC_ANT_COM = IIf(CheckFactEspecial.Checked = True, 1, 0) ' 1 = Factura especial, 0= No es Factura Especial

            If Me.Tag = "Mod" Then
                If hdr.Actualizar() = False Then
                    MsgBox(hdr.MERROR.ToString & "Could not update the document", MsgBoxStyle.Critical)
                End If
            Else
                If hdr.Guardar() = False Then
                    MsgBox(hdr.MERROR.ToString & "Could not save the document", MsgBoxStyle.Critical)
                End If
            End If


        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try

        Return logResultado
    End Function

    Public Sub ActualizarCtaCorriente(ByVal dblCredito As Double, ByVal dblTasa As Double, ByVal strDato As String)
        Dim conec As MySqlConnection
        Dim intTransID As Integer
        Dim strsql As String
        Dim COMAND As MySqlCommand

        Try

            strsql = " SELECT e.ECta_TransId FROM ECtaCte e WHERE e.ECta_Sis_Emp = {empresa} AND e.ECta_Doc_Cat = {cat} AND e.ECta_Doc_Ano = {anio} AND e.ECta_Doc_Num = {num}"
            strsql = Replace(strsql, "{empresa}", Sesion.IdEmpresa)
            strsql = Replace(strsql, "{anio}", celdaAnioOc.Text)
            strsql = Replace(strsql, "{num}", celdaNumOc.Text)
            strsql = Replace(strsql, "{cat}", celdaCatOc.Text)

            conec = New MySqlConnection
            conec.ConnectionString = strConexion
            conec.Open()
            COMAND = New MySqlCommand(strsql, conec)
            intTransID = COMAND.ExecuteScalar

            conec.Close()
            conec.Dispose()
            conec = Nothing
            System.GC.Collect()

            strsql = STR_VACIO

            strsql = " Update ECtaCte  Set ECta_codemp = {emp}, ECta_Crgo_Loc = {cloc}, ECta_Abno_Loc= {aloc}, ECta_Crgo_Ext = {cext}, ECta_Abno_Ext = {aext}, ECta_Concepto = '{conc}', ECta_FecVenc = '{venc}', ECta_FecDcmt = '{fec}', ECta_moneda = {mon}, ECta_TC = {tc}"
            strsql &= " Where ECta_TransId = {trans} and ECta_Sis_Emp = {idemp} and ECta_Doc_Cat ={cat}  and ECta_Doc_Ano = {anio} and ECta_Doc_Num = {num} "

            If Sesion.IdEmpresa = 18 Then
                strsql &= "; Update PDM.ECtaCte  Set ECta_codemp = {emp}, ECta_Crgo_Loc = {cloc}, ECta_Abno_Loc= {aloc}, ECta_Crgo_Ext = {cext}, ECta_Abno_Ext = {aext}, ECta_Concepto = '{conc}', ECta_FecVenc = '{venc}', ECta_FecDcmt = '{fec}', ECta_moneda = {mon}, ECta_TC = {tc}"
                strsql &= " Where ECta_TransId = {trans} and ECta_Sis_Emp = {idemp} and ECta_Doc_Cat ={cat}  and ECta_Doc_Ano = {anio} and ECta_Doc_Num = {num} "

            End If

            strsql = Replace(strsql, "{idemp}", Sesion.IdEmpresa)
            strsql = Replace(strsql, "{anio}", celdaAnioOc.Text)
            strsql = Replace(strsql, "{num}", celdaNumOc.Text)
            strsql = Replace(strsql, "{cat}", celdaCatOc.Text)
            strsql = Replace(strsql, "{trans}", intTransID)

            strsql = Replace(strsql, "{emp}", celdaProveedor1.Text)
            strsql = Replace(strsql, "{cloc}", CDbl(etiquetaMontoTotal.Text))
            strsql = Replace(strsql, "{aloc}", CDbl(Math.Round((dblCredito * dblTasa), 2)))
            strsql = Replace(strsql, "{cext}", CDbl(celdaMonto.Text))
            strsql = Replace(strsql, "{aext}", CDbl(dblCredito))
            strsql = Replace(strsql, "{conc}", strDato)
            strsql = Replace(strsql, "{venc}", dtpFechaVence.Value.ToString(FORMATO_MYSQL))
            strsql = Replace(strsql, "{fec}", dtpFecha1.Value.ToString(FORMATO_MYSQL))
            strsql = Replace(strsql, "{mon}", celdaMoneda1.Text)
            strsql = Replace(strsql, "{tc}", celdaTasa.Text)

            conec = New MySqlConnection
            conec.ConnectionString = strConexion
            conec.Open()
            COMAND = New MySqlCommand(strsql, conec)
            COMAND.ExecuteNonQuery()

            conec.Close()
            conec.Dispose()
            conec = Nothing
            System.GC.Collect()

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Function GuardarFactCtaCoriente(ByVal dblTasa As Double, ByVal dblCredito As Double, ByVal strDato As String) As Boolean
        Dim logResultado As Boolean
        Dim cta As New Tablas.TECTACTE

        cta.CONEXION = strConexion


        Try
            cta.ECTA_SIS_EMP = Sesion.IdEmpresa
            cta.ECTA_DOC_CAT = celdaCatOc.Text
            cta.ECTA_DOC_ANO = celdaAnioOc.Text
            cta.ECTA_DOC_NUM = celdaNumOc.Text
            cta.ECTA_DOC_LIN = INT_UNO
            cta.ECTA_TIPOEMP = "Proveedores"
            cta.ECTA_CODEMP = celdaProveedor1.Text 'id Proveedor
            cta.ECTA_SINI_LOC = vbEmpty
            cta.ECTA_CRGO_LOC = etiquetaMontoTotal.Text
            cta.ECTA_ABNO_LOC = Math.Round((dblCredito * dblTasa), 2)
            cta.ECTA_SINI_EXT = vbEmpty
            cta.ECTA_CRGO_EXT = celdaMonto.Text
            cta.ECTA_ABNO_EXT = dblCredito
            cta.ECTA_CONCEPTO = strDato
            cta.ECta_FecVenc_NET = dtpFechaVence.Value.ToString(FORMATO_MYSQL)
            cta.ECta_FecDcmt_NET = dtpFecha1.Value.ToString(FORMATO_MYSQL) 'Fecha de Documento
            cta.ECTA_MONEDA = celdaMoneda1.Text 'id Moneda
            cta.ECTA_TC = celdaTasa.Text
            'Ecta_TransID ???????
            cta.ECTA_REF_CAT = celdaCatOc.Text
            cta.ECTA_REF_ANO = celdaAnioOc.Text
            cta.ECTA_REF_NUM = celdaNumOc.Text

            If Me.Tag = "Mod" Then
                ActualizarCtaCorriente(dblCredito, dblTasa, strDato)
            Else
                If cta.PINSERT = False Then
                    MsgBox(cta.MERROR.ToString & "Could not update the document", MsgBoxStyle.Critical)
                End If
            End If


        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try

        Return logResultado
    End Function


    Private Sub GuardarImpuestos()
        Dim i As Integer
        Dim Imp As New Tablas.TDCMTOS_IMP
        Dim factor As Double

        Imp.CONEXION = strConexion

        Try

            For i = 0 To dgImpuestos.Rows.Count - 1

                Imp.MDOC_SIS_EMP = Sesion.IdEmpresa
                Imp.MDOC_DOC_CAT = celdaCatOc.Text
                Imp.MDOC_DOC_ANO = celdaAnioOc.Text
                Imp.MDOC_DOC_NUM = celdaNumOc.Text

                Imp.MDOC_DOC_LIN = dgImpuestos.Rows(i).Cells("colLine").Value
                Imp.MDOC_LIN_ID = dgImpuestos.Rows(i).Cells("colID").Value
                Imp.MDOC_LIN_CODIGO = dgImpuestos.Rows(i).Cells("colCodigo1").Value
                Imp.MDOC_LIN_TIPO = dgImpuestos.Rows(i).Cells("colTipo").Value
                Imp.MDOC_LIN_DESC = dgImpuestos.Rows(i).Cells("colDescripcion1").Value
                Imp.MDOC_LIN_BASE = dgImpuestos.Rows(i).Cells("colBase").Value
                Imp.MDOC_LIN_CANTIDAD = dgImpuestos.Rows(i).Cells("colCantidad1").Value
                factor = Replace(dgImpuestos.Rows(i).Cells("colFactor").Value, "%", "")
                Imp.MDOC_LIN_FACTOR = factor
                Imp.MDOC_LIN_MONTO = dgImpuestos.Rows(i).Cells("colMonto").Value

                '  If Me.Tag = "Mod" Then
                If dgImpuestos.Rows(i).Cells("colOrigen").Value = INT_UNO Then
                    If Imp.PUPDATE = False Then
                        MsgBox(Imp.MERROR.ToString & "Could not update the document", MsgBoxStyle.Critical)
                    End If
                ElseIf dgImpuestos.Rows(i).Cells("colOrigen").Value = INT_CERO Then
                    If Imp.PINSERT = False Then
                        MsgBox(Imp.MERROR.ToString & "Could not update the document", MsgBoxStyle.Critical)
                    End If
                    dgImpuestos.Rows(i).Cells("colOrigen").Value = INT_UNO
                ElseIf dgImpuestos.Rows(i).Cells("colOrigen").Value = 2 Then
                    If Imp.PDELETE = False Then
                        MsgBox(Imp.MERROR.ToString & "Could not delete the document", MsgBoxStyle.Critical)
                    End If
                End If


            Next

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try

    End Sub

    Private Sub GuardarRelación()
        Dim DtlP As New clsDcmtos_DTL_Pro
        Dim i As Integer
        Dim strSQL As String
        Dim COM As MySqlCommand
        DtlP.CONEXION = strConexion

        Try
            If dgPoliza.Visible = True Then
                For i = 0 To dgPoliza.Rows.Count - 1
                    DtlP.PDOC_SIS_EMP = Sesion.IdEmpresa
                    DtlP.PDOC_PAR_CAT = dgPoliza.Rows(i).Cells("colTipo1").Value
                    DtlP.PDOC_PAR_ANO = dgPoliza.Rows(i).Cells("colAño").Value
                    DtlP.PDOC_PAR_NUM = dgPoliza.Rows(i).Cells("colNum").Value
                    DtlP.PDOC_PAR_LIN = dgPoliza.Rows(i).Cells("colLinea").Value
                    DtlP.PDOC_CHI_CAT = celdaCatOc.Text
                    DtlP.PDOC_CHI_ANO = celdaAnioOc.Text
                    DtlP.PDOC_CHI_NUM = celdaNumOc.Text
                    DtlP.PDOC_CHI_LIN = INT_UNO
                    DtlP.PDOC_PRD_PNR = dgPoliza.Rows(i).Cells("colPoliza").Value
                    DtlP.PDOC_PRD_NET = dgPoliza.Rows(i).Cells("colPrice").Value
                    DtlP.PDOC_QTY_ORD = dgPoliza.Rows(i).Cells("colCantida").Value
                    DtlP.PDOC_QTY_PRO = dgPoliza.Rows(i).Cells("colCantida").Value

                    If Me.Tag = "Mod" Then
                        If DtlP.Actualizar = False Then
                            MsgBox(DtlP.MERROR.ToString & "Could not update the document", MsgBoxStyle.Critical)
                        End If
                    Else
                        If DtlP.Guardar = False Then
                            MsgBox(DtlP.MERROR.ToString & "Could not update the document", MsgBoxStyle.Critical)
                        End If
                    End If
                Next
            Else
                For i = 0 To dgFacturas.Rows.Count - 1
                    DtlP.PDOC_SIS_EMP = Sesion.IdEmpresa
                    DtlP.PDOC_PAR_CAT = dgFacturas.Rows(i).Cells("colCat").Value
                    DtlP.PDOC_PAR_ANO = dgFacturas.Rows(i).Cells("colAnio").Value
                    DtlP.PDOC_PAR_NUM = dgFacturas.Rows(i).Cells("colNumber").Value
                    DtlP.PDOC_PAR_LIN = dgFacturas.Rows(i).Cells("colLineaOrden").Value
                    DtlP.PDOC_CHI_CAT = celdaCatOc.Text
                    DtlP.PDOC_CHI_ANO = celdaAnioOc.Text
                    DtlP.PDOC_CHI_NUM = celdaNumOc.Text
                    DtlP.PDOC_CHI_LIN = dgFacturas.Rows(i).Cells("colLineaFactura").Value
                    'DtlP.PDOC_PRD_PNR = dgFacturas.Rows(i).Cells("colPoliza").Value
                    DtlP.PDOC_PRD_NET = dgFacturas.Rows(i).Cells("colPrecio").Value
                    DtlP.PDOC_QTY_ORD = dgFacturas.Rows(i).Cells("colCantidad").Value
                    DtlP.PDOC_QTY_PRO = dgFacturas.Rows(i).Cells("colCantidad").Value

                    If Me.Tag = "Mod" Then
                        If dgFacturas.Rows(i).Cells("colAgregar").Value = 2 Or dgFacturas.Rows(i).Visible = False Then
                            strSQL = "PDoc_Sis_Emp = {empresa} AND PDoc_Chi_Cat = {cat}  AND PDoc_Chi_Ano = {anio} AND PDoc_Chi_Num= {num} AND PDoc_Par_Lin= {linea} "
                            strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
                            strSQL = Replace(strSQL, "{cat}", dgFacturas.Rows(i).Cells("colCat").Value)
                            strSQL = Replace(strSQL, "{anio}", dgFacturas.Rows(i).Cells("colAnio").Value)
                            strSQL = Replace(strSQL, "{num}", dgFacturas.Rows(i).Cells("colNumber").Value)
                            strSQL = Replace(strSQL, "{linea}", dgFacturas.Rows(i).Cells("colLineaOrden").Value)
                            Dim pro As New clsDcmtos_DTL_Pro
                            pro.CONEXION = strConexion
                            pro.Borrar(strSQL)
                        ElseIf DtlP.Actualizar = False Then
                            MsgBox(DtlP.MERROR.ToString & "Could not update the document", MsgBoxStyle.Critical)
                        End If
                    Else
                        If Not dgFacturas.Rows(i).Cells("colAgregar").Value = 2 Then
                            If DtlP.Guardar = False Then
                                MsgBox(DtlP.MERROR.ToString & "Could not update the document", MsgBoxStyle.Critical)
                            End If
                        End If

                    End If
                Next

            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try


    End Sub

    Public Sub GuardarActivos(ByVal intTipo As Integer, ByVal logID As Boolean, ByVal logNuevo As Boolean, ByVal dblPrecio As Double)
        Dim Act As New Tablas.TACTIVOS
        Dim i As Integer
        Dim strSQL As String
        Dim idCodigo As Integer


        strSQL = Activos(intTipo)

        Act.CONEXION = strConexion

        For i = 0 To dgFacturas.Rows.Count - 1

            Act.EMPRESA = Sesion.IdEmpresa
            Act.CODIGO = idCodigo
            Act.DESCRIPCION = dgFacturas.Rows(i).Cells("colDescripcion").Value
            Act.ID_TIPO = intTipo


        Next

    End Sub

    Private Function VerificaBloqueo()
        Dim strSQL As String = STR_VACIO
        Dim COM As MySqlCommand
        Dim Bloqueo As Integer = NO_FILA

        strSQL = " SELECT c.cat_pid Estado "
        strSQL &= "   From Catalogos c "
        strSQL &= "        WHERE  c.cat_clase = 'Bloqueo' AND c.cat_clave = 'Compras' AND cat_sisemp = {empresa}"

        strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)

        MyCnn.CONECTAR = strConexion
        COM = New MySqlCommand(strSQL, CON)
        Bloqueo = COM.ExecuteScalar

        Return Bloqueo
    End Function
    Public Sub QueryListaPrincipal(ByVal category As String)
        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader
        Dim strSQL As String = STR_VACIO
        Dim strCadena As String = STR_VACIO
        Dim arrayCadena() As String
        checkProrrateo.Checked = False
        botonProrrateo.Enabled = False

        strSQL = SQLListaPrincipal(category)

        Try
            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSQL, CON)
            REA = COM.ExecuteReader
            dgLista.Rows.Clear()
            If REA.HasRows Then
                celdaRetension.Clear()


                Do While REA.Read
                    If Sesion.IdEmpresa = 12 And Pais() = 310 Or Sesion.IdEmpresa = 14 And Pais() = 327 Or (Sesion.IdEmpresa = 16) Or Sesion.idGiro = 2 Then
                        dgLista.Columns(17).Visible = False
                        dgLista.Columns(18).Visible = False
                    Else
                        dgLista.Columns(17).Visible = True
                        dgLista.Columns(18).Visible = True
                    End If
                    Dim strFila As String = STR_VACIO

                    strFila = REA.GetInt32("ID") & "|"
                    strFila &= REA.GetInt32("Tipo") & "|"
                    strFila &= REA.GetInt32("Anio") & "|"
                    strFila &= REA.GetInt32("Numero") & "|"
                    strFila &= REA.GetDateTime("Fecha") & "|"
                    strFila &= REA.GetString("Referencia") & "|"
                    strFila &= REA.GetString("Nombre") & "|"
                    strFila &= REA.GetString("Simbolo") & "|"
                    strFila &= REA.GetDouble("Saldo") & "|"
                    If REA.GetInt32("Clase") = vbEmpty Then
                        strFila &= "Local" & "|"
                    ElseIf REA.GetInt32("Clase") = INT_UNO Then
                        strFila &= "Importación" & "|"
                    ElseIf REA.GetInt32("Clase") = 2 Then
                        strFila &= "Orden de Compra" & "|"
                    End If
                    strFila &= REA.GetInt32("Grupo") & "|"
                    strFila &= REA.GetString("Procesado") & "|"
                    strFila &= REA.GetInt32("Estado") & "|"
                    strFila &= REA.GetInt32("SIVA") & "|"
                    strFila &= REA.GetInt32("RISR") & "|"
                    strFila &= REA.GetDateTime("Vence") & "|"
                    strFila &= REA.GetDouble("reten") & "|"
                    strCadena = REA.GetString("Serie")
                    arrayCadena = strCadena.Split("-".ToCharArray)
                    strFila &= arrayCadena(INT_CERO) & "|"
                    strFila &= REA.GetString("Autorizacion") & "|"
                    strFila &= REA.GetString("tipoDocumento") & "|"
                    strFila &= REA.GetString("SinIngresos") & "|"
                    strFila &= REA.GetString("TipoOC")


                    cFunciones.AgregarFila(dgLista, strFila)

                Loop
                strSQL = STR_VACIO

                'Colorea
                For i As Integer = 0 To Me.dgLista.Rows.Count - 1
                    If Me.dgLista.Rows(i).Cells(14).Value > 0 Then
                        Me.dgLista.Rows(i).Cells(4).Style.BackColor = Color.RoyalBlue

                    End If
                    If Me.dgLista.Rows(i).Cells(9).Value = "Importación" Then
                        Me.dgLista.Rows(i).Cells(5).Style.BackColor = Color.YellowGreen
                    End If
                    If Me.dgLista.Rows(i).Cells(10).Value = 1 Then
                        Me.dgLista.Rows(i).Cells(5).Style.BackColor = Color.Orange
                    End If
                    If Me.dgLista.Rows(i).Cells(9).Value = "Local" And Me.dgLista.Rows(i).Cells(16).Value Is Nothing Then
                        Me.dgLista.Rows(i).Cells(4).Style.BackColor = Color.SkyBlue

                    End If
                    If Me.dgLista.Rows(i).Cells(9).Value = "Orden de Compra" Then
                        Me.dgLista.Rows(i).Cells(5).Style.BackColor = Color.BlueViolet
                    End If
                    If Me.dgLista.Rows(i).Cells(12).Value = 0 Then
                        Me.dgLista.Rows(i).Cells(5).Style.BackColor = Color.Red
                    End If
                    If Me.dgLista.Rows(i).Cells(13).Value > 0 Then
                        Me.dgLista.Rows(i).Cells(5).Style.BackColor = Color.LightYellow
                    End If
                    If Me.dgLista.Rows(i).Cells(7).Value = "$" Then
                        Me.dgLista.Rows(i).Cells(7).Style.BackColor = Color.LightYellow
                        Me.dgLista.Rows(i).Cells(7).Style.ForeColor = Color.Blue
                    ElseIf Me.dgLista.Rows(i).Cells(7).Value = "Q" Then
                        Me.dgLista.Rows(i).Cells(7).Style.ForeColor = Color.DarkRed
                    End If

                    If Me.dgLista.Rows(i).Cells(9).Value = "Orden de Compra" And Me.dgLista.Rows(i).Cells(20).Value = 0 And Me.dgLista.Rows(i).Cells(21).Value <> "1" Then
                        Me.dgLista.Rows(i).Cells(9).Style.BackColor = Color.Yellow
                        If Me.dgLista.Rows(i).Cells(19).Value <> "Factura / Compra" Then
                            Me.dgLista.Rows(i).Cells(9).Style.BackColor = Color.White
                        End If
                    End If

                Next

            End If

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try


    End Sub

    Public Sub VerificarDcmtosIngreso(ByVal intAnio As Integer, ByVal intNum As Integer)
        Dim strSQL As String = STR_VACIO
        Dim COM As MySqlCommand
        Dim intcuentaDTL_Pro As Integer = 0

        strSQL = " SELECT COUNT(*) "
        strSQL &= "    From Dcmtos_DTL_Pro p "
        strSQL &= "        WHERE p.PDoc_Sis_Emp = {empresa} AND p.PDoc_Par_Cat = {catalogo} AND p.PDoc_Par_Ano = {anio} AND p.PDoc_Par_Num = {numero} AND p.PDoc_Chi_Cat = 47 "

        strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
        strSQL = Replace(strSQL, "{anio}", intAnio)
        strSQL = Replace(strSQL, "{numero}", intNum)
        strSQL = Replace(strSQL, "{catalogo}", celdaCatOc.Text)

        MyCnn.CONECTAR = strConexion
        COM = New MySqlCommand(strSQL, CON)
        intcuentaDTL_Pro = COM.ExecuteScalar
        If celdaTipoOrden.Text = 0 Then
            If intcuentaDTL_Pro > 0 Then
                botonGenerarIngreso.Enabled = False
                BloquearFel()
            Else
                botonGenerarIngreso.Enabled = True
            End If
        End If

    End Sub

    Public Sub QueryDatosFactura(ByVal intAnio As Integer, ByVal intNumero As Integer, ByVal retenNum As Integer, ByVal documentoTipo As Integer)

        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader
        Dim strSQL As String = STR_VACIO

        strSQL = SQLDatosFactura(intAnio, intNumero, documentoTipo)

        Try

            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSQL, CON)
            REA = COM.ExecuteReader
            LogModificar = True

            If REA.HasRows Then

                Do While REA.Read
                    celdaTipoOrden.Text = IIf(REA.GetString("tipoOrden") = 1, 1, IIf(REA.GetString("tipoOrden") = 0, 0, NO_FILA))
                    celdaNumero.Text = REA.GetString("NumFact")
                    celdaCatOc.Text = REA.GetInt32("Cat")
                    celdaDetalleDocumento.Text = REA.GetString("TipoDocumento")
                    celdaAnioOc.Text = intAnio
                    celdaNumOc.Text = REA.GetInt32("Numero")
                    celdaProveedor.Text = REA.GetString("Proveedor")
                    celdaSerie.Text = REA.GetString("Serie")
                    celdaNIT.Text = REA.GetString("Nit")
                    dtpFecha1.Text = REA.GetMySqlDateTime("fecha")
                    dtpFechaVence.Text = REA.GetMySqlDateTime("FechaVence")
                    celdaFecha1.Text = REA.GetDateTime("fecha").ToString(FORMATO_MYSQL)
                    celdaFechaVence.Text = REA.GetDateTime("FechaVence").ToString(FORMATO_MYSQL)
                    celdaProveedor1.Text = REA.GetString("CodigoEmp")
                    celdaMoneda1.Text = REA.GetString("IdMoneda")
                    celdaMoneda.Text = REA.GetString("Moneda")
                    celdaMonto.Text = REA.GetDouble("Monto").ToString(FORMATO_MONEDA)
                    celdaTasa.Text = REA.GetString("TasaCambio")
                    celdaCAI.Text = REA.GetString("CAI")
                    celdaNotas.Text = REA.GetString("notas")
                    celdaMontoProd.Text = REA.GetDouble("MontoProd").ToString(FORMATO_MONEDA)
                    dtpFechaPolizaC.Value = REA.GetDateTime("conta_")
                    Dim total As Double
                    total = ((REA.GetString("Monto") * REA.GetString("TasaCambio")).ToString(FORMATO_MONEDA))
                    etiquetaMontoTotal.Text = Math.Round(total, 2)

                    ''''Resolucion
                    celdaIdResolución.Text = REA.GetString("idResolucion")
                    celdaResolucion.Text = REA.GetString("Resolucion")
                    If Sesion.IdEmpresa = 15 Or Sesion.IdEmpresa = 20 Or Sesion.IdEmpresa = 22 Then
                        panelResolucion.Visible = True
                        If celdaIdResolución.Text > 0 Then
                            panelResolucion.Enabled = False
                        Else
                            panelResolucion.Enabled = True
                        End If
                    Else
                        panelResolucion.Visible = False
                    End If


                    'If REA.GetInt32("Tipo") = 1 Then
                    '    checkFacElectrónica.Checked = True
                    '    checkContribuyent.Checked = False
                    'ElseIf REA.GetInt32("Tipo") = 2 Then
                    '    checkFacElectrónica.Checked = False
                    '    checkContribuyent.Checked = True
                    'End If

                    If REA.GetInt32("HDoc_Doc_Status") = 1 Then
                        checkActive.Checked = True
                        checkActive.BackColor = Color.Transparent
                        checkActive.Enabled = True
                    Else
                        checkActive.Checked = False
                        checkActive.Enabled = False
                        checkActive.BackColor = Color.Coral
                    End If
                    If REA.GetInt32("extemporaneo") = 1 Then
                        Extemporaneo = True
                        etiquetaExtemporanea.Visible = True
                    Else
                        Extemporaneo = False
                        etiquetaExtemporanea.Visible = False
                    End If

                    If REA.GetInt32("FacturaEsp") = 1 Then
                        CheckFactEspecial.Checked = True
                        checkActive.Visible = True
                    Else
                        CheckFactEspecial.Checked = False
                        checkActive.Visible = False
                    End If

                Loop
                If dgLista.SelectedCells(13).Value = 1 Then
                    checkContribuyent.Checked = True
                Else
                    checkContribuyent.Checked = False
                End If

                If dgLista.SelectedCells(10).Value = 1 Then
                    checkFacElectrónica.Checked = True
                Else
                    checkFacElectrónica.Checked = False
                End If
                If dgLista.SelectedCells(9).Value = "Importación" Then
                    rbImportación.Checked = True
                    rbLocal.Enabled = False
                    rbOrdenDeCompra.Enabled = False
                    etiquetaInvoice.Visible = True
                    etiquetaSerie.Visible = False
                ElseIf dgLista.SelectedCells(9).Value = "Local" Then
                    rbLocal.Checked = True
                    rbImportación.Enabled = False
                    rbOrdenDeCompra.Enabled = False
                    etiquetaInvoice.Visible = False
                    etiquetaSerie.Visible = True
                ElseIf dgLista.SelectedCells(9).Value = "Orden de Compra" Then
                    rbOrdenDeCompra.Checked = True
                    rbLocal.Enabled = False
                    rbImportación.Enabled = False
                    etiquetaInvoice.Visible = False
                    etiquetaSerie.Visible = True
                    If celdaTipoOrden.Text = 0 Then
                        botonGenerarIngreso.Enabled = True
                    End If

                End If

                If retenNum > vbEmpty Then
                    celdaRetension.Text = "Ret. # " & intAnio & "-" & retenNum
                    celdaRetension.ForeColor = Color.Purple
                    celdaRetension.Font = New System.Drawing.Font("Arial", 12, FontStyle.Bold)

                End If
            End If

            '//////////////////////////////////////////////////////////
            'check Revisado

            strSQL = SQLEstadoPoliza(intAnio, intNumero, celdaCatOc.Text)
            celdaRevisado.Clear()
            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSQL, CON)
            REA = COM.ExecuteReader

            If REA.HasRows Then
                Do While REA.Read
                    celdaRevisado.Text = REA.GetString("Revisado")
                Loop
            End If

            If celdaRevisado.Text = 1 Then
                checkRevisado.Checked = True
                checkRevisado.Enabled = False
            Else
                checkRevisado.Checked = False
                checkRevisado.Enabled = True
            End If



        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try

    End Sub

    Public Sub QueryDetalleFact(ByVal intAnio As Integer, ByVal intNumero As Integer, ByVal intCatOc As Integer)

        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader
        Dim strSQL As String = STR_VACIO
        intNumero = celdaNumOc.Text
        Dim ctaActivo As String
        Dim ctaGasto As String
        Dim DescActivo As String
        Dim DescGasto As String
        Dim verificacion As Boolean = False
        Dim ver As String
        Dim strfila As String = STR_VACIO


        strSQL = DetalleFact(intAnio, intNumero, intCatOc)
        Me.checkActivoFijo.Enabled = True

        Try
            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSQL, CON)
            REA = COM.ExecuteReader

            If REA.HasRows Then

                dgFacturas.Rows.Clear()

                Do While REA.Read

                    strfila = REA.GetInt32("Tipo") & "|"
                    strfila &= REA.GetInt32("Anio") & "|"
                    strfila &= REA.GetInt32("Numero") & "|"
                    strfila &= REA.GetInt32("LineaFactura") & "|"
                    strfila &= 0 & "|"
                    strfila &= REA.GetDouble("Cantidad") & "|"
                    strfila &= REA.GetString("Descripcion") & "|"
                    strfila &= REA.GetDouble("PrecioSinIva") & "|" 'REA.GetString("Descripcion") & "|" ' Precio Sin IVA
                    strfila &= REA.GetDouble("Precio") & "|"  '.ToString(FORMATO_MONEDA) & "|"
                    strfila &= REA.GetDouble("Total").ToString(FORMATO_MONEDA) & "|"
                    strfila &= REA.GetInt32("Codigo") & "|"

                    If REA.GetInt32("Codigo") = NO_FILA Then
                        ctaActivo = vbNullString
                        DescActivo = vbNullString
                        ctaGasto = vbNullString
                        DescGasto = vbNullString

                    ElseIf (Val(REA.GetString("Codigo") = vbEmpty)) Then
                        If REA.GetString("Cuenta") = vbNullString Then
                            DescGasto = vbNullString
                            ctaGasto = vbNullString
                        Else
                            DescGasto = REA.GetString("NomCuenta")
                            ctaGasto = REA.GetString("Cuenta")
                        End If
                        ctaActivo = vbEmpty
                        DescActivo = vbNullString

                    Else
                        DescActivo = REA.GetString("AFijo")
                        ctaGasto = REA.GetString("Cuenta")
                        ctaActivo = REA.GetString("Cuenta")
                        DescGasto = REA.GetString("NomCuenta")
                        verificacion = True
                    End If


                    strfila &= ctaActivo & "|"
                    strfila &= DescActivo & "|"
                    strfila &= REA.GetString("CtaIVA") & "|" ' Nombre de cuenta
                    strfila &= ctaGasto & "|"
                    strfila &= DescGasto & "|"
                    strfila &= REA.GetString("Costo") & "|"
                    strfila &= REA.GetString("CCosto") & "|"
                    strfila &= REA.GetString("Clasificacion") & "|"

                    strfila &= 1 & "|"
                    strfila &= REA.GetString("nombreIVA") & "|" ' Numero de cuenta
                    strfila &= REA.GetInt32("CodigoP") & "|" ' Codigo Producto

                    If Sesion.idGiro = 1 Then
                        strfila &= REA.GetString("idCuenta") & "|"
                        strfila &= REA.GetString("NomCuentaUSA") & "|"
                        strfila &= REA.GetString("idRubro") & "|"
                        strfila &= REA.GetString("NomRubro")
                    Else
                        Me.dgFacturas.Columns(22).Visible = False
                        Me.dgFacturas.Columns(23).Visible = False
                        Me.dgFacturas.Columns(24).Visible = False
                        Me.dgFacturas.Columns(25).Visible = False
                    End If

                    If Sesion.IdEmpresa = 22 And rbOrdenDeCompra.Checked = True Then
                        strfila &= "||||" & REA.GetString("Lote")
                    Else
                        Me.dgFacturas.Columns("loteNum").Visible = False
                    End If

                    cFunciones.AgregarFila(dgFacturas, strfila)

                Loop

                If DescActivo = vbNullString Then

                    If verificacion = False Then
                        Me.checkActivoFijo.Checked = False
                        Me.dgFacturas.Columns(12).Visible = False
                    Else
                        Me.checkActivoFijo.Checked = True
                        Me.checkActivoFijo.Enabled = False
                        Me.dgFacturas.Columns(12).Visible = True

                    End If
                Else

                    Me.checkActivoFijo.Checked = True
                    Me.checkActivoFijo.Enabled = False
                    Me.dgFacturas.Columns(12).Visible = True


                End If
                If dgLista.SelectedCells(9).Value = "Importación" Then
                    Me.dgFacturas.Columns(15).Visible = False
                    Me.dgFacturas.Columns(17).Visible = False
                ElseIf dgLista.SelectedCells(10).Value = "Local" Then
                    Me.dgFacturas.Columns(15).Visible = True
                    Me.dgFacturas.Columns(17).Visible = True
                End If

                celdaDetFact.Clear()

                If checkContribuyent.Checked = True Then
                    celdaDetFact.Text = "NO GENERA DERECHO A CREDITO FISCAL"
                    celdaDetFact.BackColor = Color.Red
                    celdaDetFact.TextAlign = HorizontalAlignment.Center
                    celdaDetFact.ForeColor = Color.White
                ElseIf checkContribuyent.Checked = False Then
                    celdaDetFact.Text = "Detalle de Factura"
                    celdaDetFact.BackColor = Color.RoyalBlue
                    celdaDetFact.TextAlign = HorizontalAlignment.Left
                    celdaDetFact.ForeColor = Color.White
                End If
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub
    Private Function SQLImpuestosDocumento(ByVal Catalogo As Integer, ByVal Anio As Integer, ByVal Numero As Integer) As String
        Dim strSQL As String = STR_VACIO
        strSQL = "  SELECT MDoc_Doc_Lin Linea, MDoc_Lin_ID ID, MDoc_Lin_Codigo Codigo, MDoc_Lin_Tipo Tipo, "
        strSQL &= "     MDoc_Lin_Desc Descripcion, MDoc_Lin_Base Base, MDoc_Lin_Cantidad Cantidad, MDoc_Lin_Factor Factor, MDoc_Lin_Monto Monto, -1 Tag, 1 Origen "
        strSQL &= "         FROM Dcmtos_IMP "
        strSQL &= "             WHERE MDoc_Sis_Emp={empresa} AND MDoc_Doc_Cat={catalogo} AND MDoc_Doc_Ano={anio} AND MDoc_Doc_Num={numero} "
        strSQL &= "                 ORDER BY MDoc_Doc_Lin"
        strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
        strSQL = Replace(strSQL, "{catalogo}", Catalogo)
        strSQL = Replace(strSQL, "{anio}", Anio)
        strSQL = Replace(strSQL, "{numero}", Numero)

        Return strSQL
    End Function
    Public Sub CargarImpuesto(ByVal Catalogo As Integer, ByVal Anio As Integer, ByVal Numero As Integer)
        Dim strSQL As String = STR_VACIO
        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader
        Dim strFila As String = STR_VACIO
        Try
            strSQL = SQLImpuestosDocumento(Catalogo, Anio, Numero)
            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSQL, CON)
            dgImpuestos.Rows.Clear()
            REA = COM.ExecuteReader
            If REA.HasRows Then

                Do While REA.Read
                    strFila = REA.GetInt32("Linea") & "|"
                    strFila &= REA.GetInt32("ID") & "|"
                    strFila &= REA.GetString("Codigo") & "|"
                    strFila &= REA.GetInt32("Tipo") & "|"
                    strFila &= REA.GetString("Descripcion") & "|"
                    strFila &= REA.GetDouble("Cantidad") & "|"
                    strFila &= REA.GetDouble("Factor") & "|"
                    strFila &= REA.GetDouble("Base") & "|"
                    strFila &= REA.GetDouble("Monto") & "|"
                    strFila &= REA.GetInt32("Tag") & "|"
                    strFila &= INT_UNO
                    cFunciones.AgregarFila(dgImpuestos, strFila)
                Loop
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub
    Public Sub DesgloseImpuestos()
        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader
        Dim strSQL As String = STR_VACIO
        Dim strfila As String = STR_VACIO

        strSQL = SQLImpuestos()

        Try
            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSQL, CON)
            REA = COM.ExecuteReader

            dgImpuestos.Rows.Clear()

            'If REA.HasRows Then

            Do While REA.Read
                strfila = REA.GetInt32("Linea") & "|"
                strfila &= REA.GetInt32("ID") & "|"
                strfila &= REA.GetString("Codigo") & "|"
                strfila &= REA.GetInt32("Tipo") & "|"
                strfila &= REA.GetString("Descripcion") & "|"
                strfila &= REA.GetInt32("Cantidad") & "|"
                strfila &= REA.GetDouble("factor") & "|"
                strfila &= REA.GetDouble("Base").ToString(FORMATO_MONEDA) & "|"
                strfila &= REA.GetDouble("Monto").ToString(FORMATO_MONEDA) & "|"
                strfila &= REA.GetInt32("Tag") & "|"
                strfila &= REA.GetInt32("Origen")

                cFunciones.AgregarFila(dgImpuestos, strfila)
            Loop

            'End If

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try

    End Sub

    Public Sub queryPolizaImport(ByVal intAnio As Integer, ByVal intNumero As Integer, ByVal intCatRelacion As Integer)
        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader
        Dim strSQL As String = STR_VACIO
        Dim strfila As String = STR_VACIO

        intNumero = celdaNumOc.Text

        strSQL = SQLPolizaImport(intAnio, intNumero, intCatRelacion)
        Try
            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSQL, CON)
            REA = COM.ExecuteReader

            dgPoliza.Rows.Clear()

            If REA.HasRows Then

                Do While REA.Read


                    If REA.GetInt32("CatPadre") = 777 Then
                        strfila = REA.GetInt32("CatPadre") & "|"
                        strfila &= REA.GetInt32("anio") & "|"
                        strfila &= REA.GetInt32("Numero") & "|"
                        strfila &= REA.GetDateTime("fecha") & "|"
                        strfila &= REA.GetInt32("Linea") & "|"
                        strfila &= REA.GetString("NomEmpresa")

                        cFunciones.AgregarFila(dgOrdenes, strfila)
                        dgPoliza.Visible = False
                        dgOrdenes.Visible = True
                        gbPoliza.Text = "Purchase Order"
                    Else
                        strfila = REA.GetInt32("CatPadre") & "|"
                        strfila &= REA.GetInt32("anio") & "|"
                        strfila &= REA.GetInt32("Numero") & "|"
                        strfila &= REA.GetString("Documento") & "|"
                        strfila &= REA.GetInt32("Linea") & "|"
                        strfila &= REA.GetDouble("Cantidad") & "|"
                        strfila &= REA.GetDouble("PrecioNeto").ToString(FORMATO_MONEDA) & "|"
                        strfila &= REA.GetDouble("total").ToString(FORMATO_MONEDA)

                        cFunciones.AgregarFila(dgPoliza, strfila)
                        dgPoliza.Visible = True
                        dgOrdenes.Visible = False
                        gbPoliza.Text = "Impot Policy"
                    End If

                Loop

            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try


    End Sub

    Public Sub QueryPagos(ByVal intAnio As Integer, ByVal intNumero As Integer)
        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader
        Dim strSQL As String = STR_VACIO
        Dim strfila As String = STR_VACIO


        strSQL = SQLPagos(intAnio, intNumero, celdaCatOc.Text)
        Try
            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSQL, CON)
            REA = COM.ExecuteReader

            dgPagos.Rows.Clear()

            If REA.HasRows Then

                Do While REA.Read
                    strfila = REA.GetInt32("Tipo") & "|"
                    strfila &= REA.GetInt32("Anio") & "|"
                    strfila &= REA.GetInt32("Numero") & "|"
                    strfila &= REA.GetInt32("Moneda") & "|"
                    strfila &= REA.GetDouble("Tasa") & "|"
                    strfila &= REA.GetDouble("CargoEx").ToString(FORMATO_MONEDA) & "|" 'cargo
                    strfila &= REA.GetDouble("AbonoEX").ToString(FORMATO_MONEDA) & "|" ' abono
                    strfila &= REA.GetDateTime("Fecha").ToString(FORMATO_MYSQL) & "|"
                    strfila &= REA.GetString("Documento") & "|"
                    strfila &= REA.GetString("Referencia") & "|"
                    strfila &= REA.GetString("Concepto") & "|"
                    strfila &= REA.GetDouble("Cargo").ToString(FORMATO_MONEDA) & "|" ' cargo
                    strfila &= REA.GetDouble("Abono").ToString(FORMATO_MONEDA) & "|"
                    strfila &= REA.GetDouble("Saldo").ToString(FORMATO_MONEDA)

                    cFunciones.AgregarFila(dgPagos, strfila)

                Loop

            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Public Sub QueryFechaVence(ByVal num As Integer)
        Dim fecha As Date
        Dim fechaVence As Date
        Dim fechaV As Date
        Dim plazoCred As Integer
        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader
        Dim strSQL As String = STR_VACIO

        strSQL = SQLFechaVence(num)

        Try
            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSQL, CON)
            REA = COM.ExecuteReader

            If REA.HasRows Then
                REA.Read()
                plazoCred = REA.GetInt32("plazo")
                fecha = dtpFecha1.Value
                fechaV = dtpFechaVence.Value
                fechaVence = DateAdd(DateInterval.Day, plazoCred, fecha)
                If plazoCred = vbEmpty Then
                    MsgBox("There Is no credit term With this provider" & vbCrLf & vbCrLf & "The expiration must be entered manually", vbInformation, "Notice")
                ElseIf Not (fechaVence = fechaV) Then
                    If MsgBox("You have " & plazoCred & " days Of credit With this Provider" & vbCrLf & vbCrLf & "Due Date " & fechaVence & vbCrLf & "Date entered: " & fechaV & vbCrLf & vbCrLf & "Press OK to correct the date", vbInformation + vbOKCancel, "Due Date") = vbOK Then
                        dtpFechaVence.Text = fechaVence

                    End If

                End If

            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Public Sub QueryProrrateo()
        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader
        Dim strSQL As String = STR_VACIO
        Dim strfila As String = STR_VACIO


        strSQL = SQLProrrateo()
        Try

            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSQL, CON)
            REA = COM.ExecuteReader

            dgProrrateo.Rows.Clear()
            ContarFilas = 0
            If REA.HasRows Then

                Do While REA.Read
                    strfila = REA.GetInt32("ID") & "|"
                    strfila &= REA.GetString("Nombre") & "|"

                    cFunciones.AgregarFila(dgProrrateo, strfila)

                Loop

            End If

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Function ComprobarIngreso() As Boolean
        Dim strSQL As String = STR_VACIO
        Dim COM As MySqlCommand
        Dim NumFila As Integer
        Dim DateExtemporanea As Date
        Dim logVerificar As Boolean = False
        Dim logResp As Boolean
        Dim strTexto As String
        Dim strDateExtemporanea As String = STR_VACIO
        Dim strFec As String = STR_VACIO

        If VerificarDetalle() Then
            If celdaNumero.Text = vbNullString Then
                MsgBox("You have not entered the invoice number", vbExclamation, "Notice")
                celdaNumero.Focus()
                Exit Function
            ElseIf celdaFecha1.Text > Now Then
                MsgBox("Check the date of the document", vbExclamation, "Notice")
                dtpFecha1.Focus()
                Exit Function
            ElseIf dtpFecha1.Value > dtpFechaVence.Value Then
                MsgBox("The expiration date can not be less than the issue date", vbExclamation, "Notice")
                dtpFecha1.Focus()
                Exit Function

            ElseIf celdaProveedor1.Text = NO_FILA Then
                If (celdaCatOc.Text = 44) Then ' Or (celdaCatOc.Text = 209) Then
                    MsgBox("Select Supplier", vbExclamation, "Notice")
                    botonProveedor.Focus()
                    Exit Function
                Else
                    celdaProveedor1.Text = INT_CERO
                    Exit Function
                End If

            ElseIf celdaMoneda1.Text = NO_FILA Then
                MsgBox("Select Currency", vbExclamation, "Notice")
                botonMoneda.Focus()
                Exit Function
            ElseIf celdaMonto.Text = vbEmpty Then
                MsgBox("Invoice amount must be greater than zero", vbExclamation, "Notice")
                Exit Function

            ElseIf Sesion.idGiro = 1 And celdaSerie.Text = vbNullString And rbLocal.Checked = False And rbOrdenDeCompra.Checked = True Then
                MsgBox("You have not entered an invoice serial number", vbExclamation, "Notice")
                celdaSerie.Focus()
                Exit Function
                'ElseIf Sesion.IdEmpresa = 11 And (celdaCAI.Text = vbNull Or CDbl(celdaCAI.Text) = INT_UNO) Then
            ElseIf Sesion.IdEmpresa = 11 And celdaCatOc.Text = "44" And rbLocal.Checked = True And Not celdaCAI.Text.Length = 37 Then
                MsgBox("You have not entered an CAI number", vbExclamation, "Notice")
                celdaCAI.BackColor = Color.Orange
                Exit Function
            Else
                strSQL = " SELECT COUNT(*) "
                strSQL &= " From Dcmtos_HDR "
                strSQL &= " WHERE HDoc_Sis_Emp = {empresa} AND HDoc_Doc_Cat = {catalogo} AND HDoc_Emp_Cod = {prov} AND HDoc_DR1_Num = '{NFact}' AND HDoc_DR2_Num = '{serie}' AND NOT(HDoc_Doc_Ano = {anio} AND HDoc_Doc_Num = {num})"

                strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
                strSQL = Replace(strSQL, "{anio}", celdaAnioOc.Text)
                strSQL = Replace(strSQL, "{num}", celdaNumOc.Text)
                strSQL = Replace(strSQL, "{prov}", celdaProveedor1.Text)
                strSQL = Replace(strSQL, "{NFact}", celdaNumero.Text)
                strSQL = Replace(strSQL, "{serie}", celdaSerie.Text)
                strSQL = Replace(strSQL, "{catalogo}", celdaCatOc.Text)

                MyCnn.CONECTAR = strConexion
                COM = New MySqlCommand(strSQL, CON)
                NumFila = COM.ExecuteScalar

                If NumFila = 0 Then


                    If Not Me.Tag = "Mod" Then
                        DateExtemporanea = celdaFecha1.Text
                        If Sesion.idGiro = 2 Then
                            DateExtemporanea = DateSerial(Year(DateExtemporanea), Month(DateExtemporanea) + 11, 0)
                        Else
                            DateExtemporanea = DateSerial(Year(DateExtemporanea), Month(DateExtemporanea) + 3, 0)
                        End If

                        strDateExtemporanea = CStr(DateExtemporanea.ToString(FORMATO_MYSQL))
                        strFec = CStr(Now().ToString(FORMATO_MYSQL))
                        If strFec > strDateExtemporanea Then
                            If MsgBox("The invoice is entering out of time" & vbCrLf & vbCrLf & "NOTE: You want to save anyway", vbExclamation + vbOKCancel, "Notice") = vbCancel Then
                                logVerificar = False
                            Else
                                Extemporaneo = True
                                CalcuarImpuesto()
                            End If
                        End If
                    End If

                    logResp = Not (logVerificar)

                Else
                    strTexto = "The Invoice " & celdaNumero.Text & " " & celdaSerie.Text & vbCrLf & vbCrLf & "From " & celdaProveedor.Text & vbCrLf & "Already been admitted before"

                    MsgBox(strTexto, vbExclamation, "Notice")
                    celdaNumero.Focus()
                End If
            End If
        End If

        ComprobarIngreso = logResp
    End Function

    Private Function VerificarDetalle() As Boolean
        Dim logInvalido As Boolean
        Dim i As Integer
        Dim intRem As Integer

        For i = 0 To dgFacturas.Rows.Count - 1
            If dgFacturas.Rows(i).Cells("colAgregar").Value <> 2 Then
                If (dgFacturas.Rows(i).Cells("colCantidad").Value = vbEmpty) And
               (dgFacturas.Rows(i).Cells("colPrecio").Value = vbEmpty) And
               (dgFacturas.Rows(i).Cells("colTotal").Value = vbEmpty) And
               (dgFacturas.Rows(i).Cells("colDescripcion").Value = vbNullString) And
               (dgFacturas.Rows(i).Cells("colClasificacion").Value = vbNullString) Then
                    'And (dgFacturas.Rows(i).Cells("colCuenta").Value = vbNullString) Then

                    intRem = intRem + 1

                ElseIf dgFacturas.Rows(i).Cells("colDescripcion").Value = vbNullString Then
                    MsgBox("Row" & i & ": No description", vbExclamation, "Notice")

                    intRem = vbEmpty
                    logInvalido = True
                    Exit For

                    'Para facturas Locales (Cuenta Gasto)
                ElseIf rbLocal.Checked = True Then
                    If checkActivoFijo.Checked = False Then
                        If (dgFacturas.Rows(i).Cells("colGasto").Value = vbNullString) Then
                            MsgBox("Row " & i & ": No Expense account defined", vbExclamation, "Notice")
                            intRem = vbEmpty
                            logInvalido = True
                            Exit For
                        End If
                    End If
                    'Para eleccion de activos fijos 
                ElseIf checkActivoFijo.Checked = True Then
                    If (dgFacturas.Rows(i).Cells("colActivo").Value = vbNullString) Then
                        MsgBox("Row " & i & ": No asset account defined", vbExclamation, "Notice")
                    End If
                    'para Importacion de Activos
                ElseIf rbImportación.Checked = True Then
                    If dgFacturas.Rows(i).Cells("colActivo").Value = vbNullString And logConta And rbImportación.Checked = True And checkActivoFijo.Checked = True Then
                        MsgBox("Rows " & i & ": No active account defined", vbExclamation, "Notice")

                        intRem = vbEmpty
                        logInvalido = True
                        Exit For
                    End If
                    'Para facturas Locales (Centro de Costo)
                ElseIf dgFacturas.Rows(i).Cells("colCentro").Value = vbNullString And logConta And rbLocal.Checked = False Then
                    MsgBox("Row " & i & ": Cost Center has not been defined", vbExclamation, "Notice")

                    intRem = vbEmpty
                    logInvalido = True
                    Exit For

                    'cuenta local
                ElseIf dgFacturas.Rows(i).Cells("colCuenta").Value = vbNullString And logConta And rbImportación.Checked = False And celdaTipoOrden.Text = 1 Then
                    MsgBox("Row " & i & ": Account has not been defined", vbExclamation, "Notice")
                    intRem = vbEmpty
                    logInvalido = True
                    Exit For

                    'activos Locales
                ElseIf dgFacturas.Rows(i).Cells("colCentro").Value = vbNullString And logConta And rbLocal.Checked = False And checkActivoFijo.Checked = True Then
                    MsgBox("Row " & i & ": Cost Center has not been defined", vbExclamation, "Notice")

                    intRem = vbEmpty
                    logInvalido = True
                    Exit For

                    '    'cuenta local activo fijo
                    'ElseIf dgFacturas.Rows(i).Cells("colCuenta").Value = vbNullString And logConta And rbLocal.Checked = False And checkActivoFijo.Checked = True Then
                    '    MsgBox("Row " & i & ": Account has not been defined", vbExclamation, "Notice")

                    '    intRem = vbEmpty
                    '    logInvalido = True
                    '    Exit For

                ElseIf (dgFacturas.Rows(i).Cells("colCantidad").Value = vbEmpty) And
                   (dgFacturas.Rows(i).Cells("colPrecio").Value = vbEmpty) And
                   (dgFacturas.Rows(i).Cells("colTotal").Value = vbEmpty) And
                   (dgFacturas.Rows(i).Cells("colGasto")).Value = vbNullString Or
                   (dgFacturas.Rows(i).Cells("colCuentaActivo")).Value = vbNullString And
                   (dgFacturas.Rows(i).Cells("colClasificacion")).Value = vbNullString Then
                    'And (dgFacturas.Rows(i).Cells("colCuenta")).Value = vbNullString Then

                    If (dgFacturas.Rows(i).Cells("colCantidad").Value = vbEmpty) Or
               (dgFacturas.Rows(i).Cells("colPrecio").Value = vbEmpty) Or
               (dgFacturas.Rows(i).Cells("colTotal").Value = vbEmpty) And
               Not (rbImportación.Checked = True) Or (dgFacturas.Rows(i).Cells("colClasificacion")).Value = vbNullString Then

                        MsgBox("Row " & i & ": Incomplete data", vbExclamation, "Notice")

                        logInvalido = True
                        Exit For
                    End If
                End If
                If rbLocal.Checked Then
                    If dgFacturas.Rows(i).Cells("colCentro").Value = vbNullString Then
                        MsgBox("Row " & i & ": Cost Center has not been defined", vbExclamation, "Notice")

                        intRem = vbEmpty
                        logInvalido = True
                        Exit For
                    End If
                    'If dgFacturas.Rows(i).Cells("colCuenta").Value = vbNullString Then
                    '    MsgBox("Row " & i & ": Account has not been defined", vbExclamation, "Notice")

                    '    intRem = vbEmpty
                    '    logInvalido = True
                    '    Exit For
                    'End If
                End If
            End If
        Next

        If Not (intRem = vbEmpty) Then
            Dim strfila As String = STR_VACIO
            Try
                cFunciones.AgregarFila(dgFacturas, strfila)
            Catch ex As Exception
                MsgBox(ex.ToString)
            End Try
        End If

        VerificarDetalle = Not logInvalido
    End Function

    Private Function GuardarDocumento() As Boolean
        Dim logResultado As Boolean
        Dim datFecha As Date
        Dim datVence As Date
        Dim strSQL As String = STR_VACIO
        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader
        Dim dblTasa As Double
        Dim dblTotal As Double
        Dim dblDebito As Double
        Dim dblCredito As Double
        Dim strDato As String
        Dim Dias As Integer


        If celdaAnioOc.Text = NO_FILA Then

            celdaAnioOc.Text = Year(dtpFecha1.Value)
            celdaNumOc.Text = cfun.NuevoId(celdaCatOc.Text, Year(dtpFecha1.Value))

        End If

        strSQL = SQLFechaVence(celdaProveedor1.Text)
        MyCnn.CONECTAR = strConexion
        COM = New MySqlCommand(strSQL, CON)
        REA = COM.ExecuteReader

        If REA.HasRows Then
            REA.Read()
            Dias = REA.GetInt32("plazo")
        End If

        If celdaNumOc.Text > vbEmpty Then
            datFecha = celdaFecha1.Text
            datVence = DateAdd(DateInterval.Day, Dias, datFecha)

            If Not (Me.Tag = "Mod" Or rbImportación.Checked = True) Then

                strSQL = FechaActual(datFecha)
                Try
                    MyCnn.CONECTAR = strConexion
                    COM = New MySqlCommand(strSQL, CON)
                    REA = COM.ExecuteReader

                    If REA.HasRows Then
                        REA.Read()
                        datFecha = REA.GetDateTime("Fecha").ToString(FORMATO_MYSQL)
                    End If

                Catch ex As Exception
                    MsgBox(ex.ToString)
                End Try
            End If

            dblTasa = celdaTasa.Text
            dblTotal = celdaMonto.Text
            strDato = "Invoice No. " & celdaNumero.Text & " " & celdaSerie.Text

            If logAnulado = False Then
                'Si no está anulada
                dblDebito = dblTotal
            End If

            sqlGuardarFact(datFecha, dblDebito, dblCredito, dblTotal, celdaMontoProd.Text)
            GuardarFactCtaCoriente(dblTasa, dblCredito, strDato)

            cFunciones.EscribirRegistro(Tbl_Documentos, IIf(Me.Tag = "Nuevo", clsFunciones.AccEnum.acAdd, clsFunciones.AccEnum.acUpdate), , celdaCatOc.Text, celdaAnioOc.Text, celdaNumOc.Text, strDato)
            'Me.Tag = "Mod"
            logResultado = True

        End If

        Return logResultado
    End Function

    Private Sub GuardarDetalle()
        Dim i As Integer
        Dim linea As Integer = 0
        Dim dtl As New clsDcmtos_DTL
        Dim intTipo As Integer
        Dim strDetalle As String = STR_VACIO

        For i = 0 To dgFacturas.Rows.Count - 1
            If ComprobarFila(i, True) Then
                dtl.CONEXION = strConexion

                Try
                    dtl.DDOC_SIS_EMP = Sesion.IdEmpresa
                    dtl.DDOC_DOC_CAT = celdaCatOc.Text
                    dtl.DDOC_DOC_ANO = celdaAnioOc.Text
                    dtl.DDOC_DOC_NUM = celdaNumOc.Text
                    If dgFacturas.Rows(i).Cells("colAgregar").Value = 0 Then
                        dtl.DDOC_DOC_LIN = ObtenerLinea(celdaAnioOc.Text, celdaNumOc.Text)
                    Else
                        If Me.Tag = "Nuevo" Then
                            dtl.DDOC_DOC_LIN = ObtenerLinea(celdaAnioOc.Text, celdaNumOc.Text)
                        Else
                            dtl.DDOC_DOC_LIN = dgFacturas.Rows(i).Cells("colLineaFactura").Value
                        End If
                    End If


                    If dgFacturas.Rows(i).Cells("colClasificacion").Value = vbNullString Then
                        intTipo = NO_FILA
                    Else
                        intTipo = IIf(dgFacturas.Rows(i).Cells("colClasificacion").Value = "BIEN", intBien, intServicio)
                    End If

                    If rbOrdenDeCompra.Checked = True Then
                        dtl.DDOC_PRD_COD = dgFacturas.Rows(i).Cells("colCodigoP").Value
                    Else
                        dtl.DDOC_PRD_COD = INT_CERO
                    End If

                    strDetalle = dgFacturas.Rows(i).Cells("colDescripcion").Value
                    strDetalle = strDetalle.Replace("|", "/")

                    dtl.DDOC_PRD_DES = strDetalle
                    dtl.DDOC_PRD_QTY = dgFacturas.Rows(i).Cells("colCantidad").Value
                    dtl.DDOC_PRD_NET = dgFacturas.Rows(i).Cells("colPrecio").Value
                    dtl.DDOC_RF1_DBL = dgFacturas.Rows(i).Cells("colTotal").Value
                    dtl.DDOC_RF1_NUM = intTipo

                    If Sesion.idGiro = 2 Then
                        dtl.DDOC_RF1_TXT = dgFacturas.Rows(i).Cells("colidCuentaIVA").Value
                        dtl.DDOC_RF3_DBL = dgFacturas.Rows(i).Cells("colPrecioSinIVA").Value
                    End If

                    If logConta Then
                        If Not dgFacturas.Rows(i).Cells("colCodigo").Value = vbEmpty Then
                            dtl.DDOC_RF1_COD = dgFacturas.Rows(i).Cells("colCuentaActivo").Value
                            dtl.DDOC_RF2_DBL = dgFacturas.Rows(i).Cells("colCodigo").Value
                        Else
                            dtl.DDOC_RF1_COD = dgFacturas.Rows(i).Cells("colCuenta").Value
                            dtl.DDOC_RF2_DBL = vbEmpty
                        End If
                        If Not dgFacturas.Rows(i).Cells("colCosto").Value = vbNullString Then
                            dtl.DDOC_RF3_NUM = dgFacturas.Rows(i).Cells("colCosto").Value
                        End If
                    End If

                    If Sesion.idGiro = 1 Then
                        dtl.DDOC_RF2_TXT = If(dgFacturas.Rows(i).Cells("col_idRubro").Value = vbNullString, "", dgFacturas.Rows(i).Cells("col_idRubro").Value)
                        dtl.DDOC_RF3_TXT = If(dgFacturas.Rows(i).Cells("col_idCuenta").Value = vbNullString, "", dgFacturas.Rows(i).Cells("col_idCuenta").Value)
                    End If

                    If Sesion.IdEmpresa = 22 And rbOrdenDeCompra.Checked = True Then
                        dtl.DDOC_RF4_COD = IIf(dgFacturas.Rows(i).Cells("loteNum").Value = vbNullString, STR_VACIO, dgFacturas.Rows(i).Cells("loteNum").Value)
                    End If


                    If dgFacturas.Rows(i).Cells("colAgregar").Value = 1 Then
                        If dtl.Actualizar() = False Then
                            MsgBox(dtl.MERROR.ToString & "Could not update the document", MsgBoxStyle.Critical)
                        End If
                    ElseIf dgFacturas.Rows(i).Cells("colAgregar").Value = 0 Then
                        If dtl.Guardar() = False Then
                            MsgBox(dtl.MERROR.ToString & "Could not save the document", MsgBoxStyle.Critical)
                        End If
                        dgFacturas.Rows(i).Cells("colAgregar").Value = 1
                    ElseIf dgFacturas.Rows(i).Cells("colAgregar").Value = 2 Then
                        If dtl.Borrar = False Then
                            MsgBox(dtl.MERROR.ToString & "Could not save the document", MsgBoxStyle.Critical)
                        End If
                    End If

                Catch ex As Exception
                    MsgBox(ex.ToString)
                End Try
            End If

        Next

    End Sub

    Private Function FilaDeActivos(ByRef strLista As String) As Integer
        Dim i As Integer
        Dim valorTasa As Double
        Dim cuenta As String
        Dim SumaFilA As Integer = 0

        strLista = vbNullString

        For i = 0 To dgFacturas.Rows.Count - 1
            cuenta = dgFacturas.Rows(i).Cells("colCuentaActivo").Value
            If (ComprobarFila(i, True)) And (dgFacturas.Rows(i).Cells("colCantidad").Value) > 0 And Not (cuenta = vbNullString) Then
                valorTasa = TasaDeDepreciacion(cuenta)
                If valorTasa > 0 Then
                    strLista = Space(4) & dgFacturas.Rows(i).Cells("colDescripcion").Value & " (" & dgFacturas.Rows(i).Cells("colCantidad").Value & ")" & vbCrLf
                    SumaFilA = SumaFilA + 1
                End If
            End If
        Next

        FilaDeActivos = SumaFilA

    End Function

    Private Function TasaDeDepreciacion(ByVal cuenta As String) As Double
        Dim strSQL As String = STR_VACIO
        Dim dblDato As Double
        Dim COM As MySqlCommand

        strSQL = " SELECT Porcentaje "
        strSQL &= " From Tipos_Activo"
        strSQL &= " WHERE Empresa = {empresa} AND Cta_Activo = {cuenta} AND Depreciar = 1"

        strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
        strSQL = Replace(strSQL, "{cuenta}", cuenta)

        MyCnn.CONECTAR = strConexion
        COM = New MySqlCommand(strSQL, CON)
        dblDato = COM.ExecuteScalar

        TasaDeDepreciacion = dblDato

    End Function

    Private Function TrasladarActivos()
        Dim i As Integer
        Dim strcuenta As String

        For i = 0 To dgFacturas.Rows.Count - 1
            strcuenta = dgFacturas.Rows(i).Cells("colCuentaActivo").Value

            If ComprobarFila(i, True) And dgFacturas.Rows(i).Cells("colCantidad").Value > 0 And Not (strcuenta = vbNullString) Then
                If TasaDeDepreciacion(strcuenta) > 0 Then
                    RegistrarEnActivos(i)
                End If
            End If
        Next

    End Function

    Private Function RegistrarEnActivos(ByVal i As Integer)
        Dim dblPrecio As Double
        Dim dblTasa As Double

        Dim logNuevo As Boolean = True
        Dim logCreado As Boolean = True
        Dim logID As Boolean = True
        Dim dtFecha As Date

        Dim strDescripcion As String
        Dim strCuenta As String

        Dim intCantidad As Integer
        Dim intTipo As Integer
        Dim intDias As Integer
        Dim strSQL As String = STR_VACIO
        Dim COM As New MySqlCommand

        For i = 0 To dgFacturas.Rows.Count - 1
            intCantidad = dgFacturas.Rows(i).Cells("colCantidad").Value
            strDescripcion = dgFacturas.Rows(i).Cells("colDescripcion").Value
            strCuenta = dgFacturas.Rows(i).Cells("colCuentaActivo").Value

            strSQL = "SELECT Codigo FROM Tipos_Activo WHERE Empresa = {empresa} AND Cta_Activo = '{cuenta}' Limit 1"
            strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
            strSQL = Replace(strSQL, "{cuenta}", strCuenta)

            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSQL, CON)
            intTipo = COM.ExecuteScalar

            dblPrecio = dgFacturas.Rows(i).Cells("colPrecio").Value

        Next

        dblTasa = celdaTasa.Text

        'intDias = CalcularDiasActivos()

        GuardarActivos(intTipo, logID, logNuevo, dblPrecio)
        'Guardar Meses



    End Function


    Private Function ComprobarFila(ByVal i As Integer, Optional Opcion As Boolean = False) As Boolean
        Dim logesultado As Boolean = True
        If Not dgFacturas.Rows(i).Cells("colCantidad").Value = vbEmpty Or
            dgFacturas.Rows(i).Cells("colDescripcion").Value = vbNullString Or
            dgFacturas.Rows(i).Cells("colPrecio").Value = vbEmpty Or
            dgFacturas.Rows(i).Cells("colTotal").Value = vbEmpty Or
            dgFacturas.Rows(i).Cells("colCuenta").Value = vbNullString Or
            dgFacturas.Rows(i).Cells("colClasificacion").Value = vbNullString Then
            'Cantidades validas y descripcion 
            logesultado = True
        ElseIf dgFacturas.Rows(i).Cells("colCantidad").Value = vbEmpty And
            dgFacturas.Rows(i).Cells("colDescripcion").Value = vbNullString And
            dgFacturas.Rows(i).Cells("colPrecio").Value = vbEmpty And
            dgFacturas.Rows(i).Cells("colTotal").Value = vbEmpty And
            dgFacturas.Rows(i).Cells("colCuenta").Value = vbNullString And
            dgFacturas.Rows(i).Cells("colClasificacion").Value = vbNullString Then

            logesultado = True
        ElseIf rbImportación.Checked = True And Not dgFacturas.Rows(i).Cells("colCantidad").Value = vbEmpty Or
            dgFacturas.Rows(i).Cells("colDescripcion").Value = vbNullString Or
            dgFacturas.Rows(i).Cells("colPrecio").Value = vbEmpty Or
            dgFacturas.Rows(i).Cells("colTotal").Value = vbEmpty Then

            logesultado = True

        ElseIf Not Opcion Then
            MsgBox("Row " & i & "Invalid Data", vbExclamation, "Notice")
        End If

        Return logesultado
    End Function

    'Devuelve la instruccion para el listado de polizas(relaciones)
    Private Function SqlBuscarReferencia(ByVal Dato As String, Optional Varios As Boolean = False, Optional Excluir As Boolean = False) As String
        Dim strCriterio As String = vbNullString
        Dim strCriterio2 As String = vbNullString
        Dim strLista As String = vbNullString
        Dim strTemp As String = vbNullString
        Dim strSQL As String = vbNullString
        Dim i As Integer = INT_CERO
        Dim strreplace As String = vbNullString

        If Varios Then
            strCriterio2 = Replace(Dato, ",", "%¨ OR {0} LIKE ¨%")
            strCriterio = Replace("{0} LIKE ¨%{1}%¨", "{1}", strCriterio2)
        Else : strCriterio = "{0}='{referencia}'"
        End If

        strCriterio = Replace(strCriterio, "{0}", "e.HDoc_DR1_Num")
        strCriterio = Replace(strCriterio, "¨", Chr(34))

        If Excluir And dgPoliza.Rows.Count > vbEmpty Then
            For i = INT_CERO To dgPoliza.Rows.Count - 1
                strTemp = dgPoliza.Rows(i).Cells("colAño").Value & "-" & dgPoliza.Rows(i).Cells("colNum").Value
                If InStr(1, strLista, "|" & strTemp) = vbEmpty Then
                    strLista = strLista & IIf(strLista = vbNullString, "|", vbNullString) & strTemp
                End If
            Next
            If Not strLista = vbNullString Then
                strLista = Mid(strLista, 2, Len(strLista) - 2)
                strCriterio = strCriterio & Replace(" AND NOT (e.HDoc_Sis_Emp={empresa} AND e.HDoc_Doc_Cat= {catalogo} AND e.HDoc_Doc_Ano={0})", "{0}", Replace(Replace(strLista, "-", " AND e.HDoc_Doc_Num="), "|", ") OR (e.HDoc_Sis_Emp={empresa} AND e.HDoc_Doc_Cat={tipo} AND e.HDoc_Doc_Ano="))
            End If
        End If

        strSQL = "SELECT Empresa, Tipo, Anio, Numero, Fecha, Referencia, IFNULL(a.ADoc_Dta_Chr,'') Documento, SUM(Cantidad) Cantidad, ROUND(SUM(Cantidad * Precio),2) Monto, 
            COUNT(*) AS Lineas, TC_Poliza , cast(cast(fechaIngreso AS DATE) AS CHAR) fechaIngreso
"
        strSQL &= "  FROM ("
        strSQL &= "     SELECT d.DDoc_Sis_Emp Empresa, d.DDoc_Doc_Cat Tipo, d.DDoc_Doc_Ano Anio, d.DDoc_Doc_Num Numero, e.HDoc_Doc_Fec Fecha, e.HDoc_DR1_Num Referencia, d.DDoc_Prd_NET Precio, (d.DDoc_Prd_QTY) - IFNULL(("
        strSQL &= "         SELECT SUM(c.PDoc_QTY_Pro)"
        strSQL &= "             FROM Dcmtos_DTL_Pro c"
        strSQL &= "                 WHERE c.PDoc_Sis_Emp=d.DDoc_Sis_Emp AND c.PDoc_Par_Cat=d.DDoc_Doc_Cat AND c.PDoc_Par_Ano=d.DDoc_Doc_Ano AND c.PDoc_Par_Num=d.DDoc_Doc_Num AND c.PDoc_Par_Lin=d.DDoc_Doc_Lin AND c.PDoc_Chi_Cat={facturaCompra}),0) Cantidad
                                 , e.HDoc_Doc_TC TC_Poliza
	                             , IF(e.HDoc_DR1_Dbl = 1, e.HDoc_Doc_Fec, (
	                            SELECT h47.HDoc_Doc_Fec
	                            FROM Dcmtos_DTL_Pro pp180
	                            JOIN Dcmtos_HDR h47 ON pp180.PDoc_Sis_Emp=h47.HDoc_Sis_Emp AND pp180.PDoc_Chi_Cat=h47.HDoc_Doc_Cat AND pp180.PDoc_Chi_Ano=h47.HDoc_Doc_Ano AND pp180.PDoc_Chi_Num=h47.HDoc_Doc_Num AND h47.HDoc_Doc_Cat=47
	                            WHERE pp180.PDoc_Sis_Emp=e.HDoc_Sis_Emp AND pp180.PDoc_Par_Cat=d.DDoc_Doc_Cat AND pp180.PDoc_Par_Ano=d.DDoc_Doc_Ano AND pp180.PDoc_Par_Num=d.DDoc_Doc_Num AND pp180.PDoc_Par_Lin=d.DDoc_Doc_Lin	
		                            )) fechaIngreso  "
        strSQL &= "                     FROM Dcmtos_DTL d"
        strSQL &= "                          LEFT JOIN Dcmtos_HDR e ON e.HDoc_Sis_Emp = d.DDoc_Sis_Emp AND e.HDoc_Doc_Cat = d.DDoc_Doc_Cat AND e.HDoc_Doc_Ano = d.DDoc_Doc_Ano AND e.HDoc_Doc_Num = d.DDoc_Doc_Num"
        strSQL &= "                     WHERE d.DDoc_Sis_Emp={empresa} AND d.DDoc_Doc_Cat={polizaImpor} AND {criterio}"
        strSQL &= "                  HAVING Cantidad > 0) s1"
        strSQL &= "               LEFT JOIN Dcmtos_ACC a ON a.ADoc_Sis_Emp=s1.Empresa AND a.ADoc_Doc_Cat=s1.Tipo AND a.ADoc_Doc_Ano=s1.Anio AND a.ADoc_Doc_Num=s1.Numero AND a.ADoc_Doc_Sub='{dato}' AND a.ADoc_Doc_Lin='{linea}'"
        strSQL &= "           GROUP BY Empresa, Tipo, Anio, Numero"
        strSQL &= "       ORDER BY Fecha DESC, Numero DESC"

        strSQL = Replace(strSQL, "{criterio}", strCriterio)
        strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
        strSQL = Replace(strSQL, "{polizaImpor}", 180)
        strSQL = Replace(strSQL, "{facturaCompra}", celdaCatOc.Text)
        strSQL = Replace(strSQL, "{referencia}", Dato)
        strSQL = Replace(strSQL, "{dato}", "Doc_PolImp")
        strSQL = Replace(strSQL, "{linea}", "01")

        Return strSQL
    End Function

    Private Sub GenerarRelacion(ByVal Tipo As Integer, ByVal Año As Integer, ByVal Numero As Long, ByVal Referencia As String, Optional Lineas As String = vbNullString)
        Dim strSQL As String = vbNullString
        Dim COM As MySqlCommand
        Dim conec As MySqlConnection
        Dim REA As MySqlDataReader
        Dim i As Integer = INT_CERO
        Dim strFila As String = STR_VACIO
        Dim strFila2 As String = STR_VACIO

        'Agrega Relacion a Poliza
        strSQL = "SELECT d.DDoc_Sis_Emp Empresa, d.DDoc_Doc_Cat Tipo, d.DDoc_Doc_Ano Anio, d.DDoc_Doc_Num Numero, d.DDoc_Doc_Lin Linea, a.art_DCorta Descripcion, 
            d.DDoc_Prd_NET Precio, (d.DDoc_Prd_QTY) - IFNULL(("
        strSQL &= "  SELECT SUM(c.PDoc_QTY_Pro)"
        strSQL &= "      FROM Dcmtos_DTL_Pro c"
        strSQL &= "          WHERE c.PDoc_Sis_Emp=d.DDoc_Sis_Emp AND c.PDoc_Par_Cat=d.DDoc_Doc_Cat AND c.PDoc_Par_Ano=d.DDoc_Doc_Ano AND c.PDoc_Par_Num=d.DDoc_Doc_Num AND 
            c.PDoc_Par_Lin=d.DDoc_Doc_Lin AND c.PDoc_Chi_Cat={facturaCompra}),0) Cantidad "
        strSQL &= ", h.HDoc_Doc_TC TC_Poliza
                     ,CAST(IF(h.HDoc_DR1_Dbl = 1, h.HDoc_Doc_Fec,(
                        SELECT h47.HDoc_Doc_Fec
                        FROM Dcmtos_DTL_Pro pp180
                        JOIN Dcmtos_HDR h47 ON pp180.PDoc_Sis_Emp=h47.HDoc_Sis_Emp AND pp180.PDoc_Chi_Cat=h47.HDoc_Doc_Cat AND pp180.PDoc_Chi_Ano=h47.HDoc_Doc_Ano AND pp180.PDoc_Chi_Num=h47.HDoc_Doc_Num AND h47.HDoc_Doc_Cat=47
                        WHERE pp180.PDoc_Sis_Emp=h.HDoc_Sis_Emp AND pp180.PDoc_Par_Cat=d.DDoc_Doc_Cat AND pp180.PDoc_Par_Ano=d.DDoc_Doc_Ano AND pp180.PDoc_Par_Num=d.DDoc_Doc_Num AND pp180.PDoc_Par_Lin=d.DDoc_Doc_Lin)) AS DATE) fechaIngreso "
        strSQL &= "              FROM Dcmtos_DTL d"
        strSQL &= "           LEFT JOIN Inventarios i ON i.inv_sisemp=d.DDoc_Sis_Emp AND i.inv_numero=d.DDoc_Prd_Cod"
        strSQL &= "       LEFT JOIN Articulos a ON a.art_sisemp=i.inv_sisemp AND a.art_codigo=i.inv_artcodigo
            LEFT JOIN Dcmtos_HDR h 
                ON d.DDoc_Sis_Emp=h.HDoc_Sis_Emp 
                   AND d.DDoc_Doc_Cat=h.HDoc_Doc_Cat
                   AND d.DDoc_Doc_Ano=h.HDoc_Doc_Ano
                   AND d.DDoc_Doc_Num=h.HDoc_Doc_Num"
        strSQL &= "    WHERE d.DDoc_Sis_Emp={empresa} AND d.DDoc_Doc_Cat={cat} AND d.DDoc_Doc_Ano={anio} AND d.DDoc_Doc_Num={num}"
        strSQL &= "  HAVING Cantidad > 0"

        strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
        strSQL = Replace(strSQL, "{cat}", Tipo)
        strSQL = Replace(strSQL, "{anio}", Año)
        strSQL = Replace(strSQL, "{num}", Numero)
        strSQL = Replace(strSQL, "{facturaCompra}", celdaCatOc.Text)
        If (Lineas = vbNullString) Then
            strSQL = Replace(strSQL, "{lineas}", vbNullString)
        Else : strSQL = Replace(strSQL, "{lineas}", "AND .DDoc_Doc_Lin IN (" & Lineas & ")")
        End If

        Try
            conec = New MySqlConnection
            conec.ConnectionString = strConexion
            conec.Open()
            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSQL, conec)
            REA = COM.ExecuteReader

            'Sin Cantidad
            For i = INT_CERO To dgFacturas.Rows.Count - 1
                If dgFacturas.Rows(i).Cells("colCantidad").Value = vbEmpty Then
                    dgFacturas.Rows.Clear()
                End If
            Next

            If REA.HasRows Then
                i = INT_CERO
                Do While REA.Read
                    strFila = REA.GetInt32("Tipo") & "|"
                    strFila &= REA.GetInt32("Anio") & "|"
                    strFila &= REA.GetInt32("Numero") & "|"
                    strFila &= i + 1 & "|"
                    strFila &= REA.GetInt32("Linea") & "|"
                    strFila &= REA.GetDouble("Cantidad") & "|"
                    strFila &= REA.GetString("Descripcion") & "|"
                    strFila &= 0 & "|"
                    strFila &= REA.GetDouble("Precio") & "|"
                    strFila &= (REA.GetDouble("Cantidad") * REA.GetDouble("Precio")).ToString(FORMATO_MONEDA) & "|"
                    strFila &= INT_CERO & "|"
                    strFila &= INT_CERO & "|"
                    strFila &= INT_CERO & "|"
                    strFila &= INT_CERO & "|"
                    strFila &= INT_CERO & "|"
                    strFila &= INT_CERO & "|"
                    strFila &= INT_CERO & "|"
                    strFila &= INT_CERO & "|"
                    'strFila &= INT_CERO & "|"
                    strFila &= "BIEN" & "|"
                    strFila &= INT_CERO & "|"
                    strFila &= INT_CERO

                    cFunciones.AgregarFila(dgFacturas, strFila)

                    'Llena el datagrid de Polizas
                    strFila2 = REA.GetInt32("Tipo") & "|"
                    strFila2 &= REA.GetInt32("Anio") & "|"
                    strFila2 &= REA.GetInt32("Numero") & "|"
                    strFila2 &= Referencia & "|"
                    strFila2 &= REA.GetInt32("Linea") & "|"
                    strFila2 &= REA.GetDouble("Cantidad") & "|"
                    strFila2 &= REA.GetDouble("Precio") & "|"
                    strFila2 &= (REA.GetDouble("Cantidad") * REA.GetDouble("Precio")).ToString(FORMATO_MONEDA) & "|"
                    strFila2 &= REA.GetDateTime("fechaIngreso").ToString(FORMATO_MYSQL) & "|"
                    strFila2 &= REA.GetDouble("TC_Poliza")

                    If Sesion.idGiro = 1 And rbImportación.Checked Then
                        dtpFechaPolizaC.Value = REA.GetDateTime("fechaIngreso")
                        celdaTasa.Text = REA.GetDouble("TC_Poliza")
                    Else
                        celdaTasa.Text = REA.GetDouble("TC_Poliza")
                    End If

                    cFunciones.AgregarFila(dgPoliza, strFila2)
                Loop
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Function BuscarReferencia(ByVal Dato As String, ByVal Resultado As Integer, Optional Varios As Boolean = False) As Boolean
        Dim strSQL As String = vbNullString
        Dim strSQL2 As String = vbNullString
        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader
        Dim COM2 As MySqlCommand
        Dim REA2 As MySqlDataReader
        Dim conec As MySqlConnection
        Dim Tipo As Integer = INT_CERO
        Dim Anio As Integer = INT_CERO
        Dim NUmero As Integer = INT_CERO
        Dim Documento As String = STR_VACIO
        Dim fechaIngreso As String = STR_VACIO
        Dim TC_Poliza As Double = INT_CERO

        strSQL = SqlBuscarReferencia(Dato, Varios)

        Try
            conec = New MySqlConnection
            conec.ConnectionString = strConexion
            conec.Open()
            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSQL, conec)
            REA = COM.ExecuteReader

            If REA.HasRows Then
                Do While REA.Read
                    If REA.RecordsAffected > INT_UNO Then
                        'Más de una coincidencia
                        MsgBox("Se encontró más de una póliza con dicha referencia" & vbCr & vbCr & "Referencia: " & Dato, vbInformation, "Polizas de Importacion")
                    ElseIf MsgBox("Pólizas: " & vbTab & REA.GetString("Documento") & vbCr & "Fecha: " & vbTab & REA.GetDateTime("Fecha") & vbCr & vbCr & "Monto: " & vbTab & REA.GetDouble("Monto").ToString(FORMATO_MONEDA) & vbCr & "Saldo: " & vbTab & REA.GetDouble("Cantidad").ToString(FORMATO_MONEDA) & vbCr & vbCr & "Lineas: " & vbTab & REA.GetInt32("Lineas") & vbCr & vbCr & "Descargar Póliza de: " & REA.GetString("Referencia") & " completa?", vbQuestion + vbYesNo + vbDefaultButton2, "Póliza de importación") = vbYes Then
                        Tipo = REA.GetInt32("Tipo")
                        Anio = REA.GetInt32("Anio")
                        NUmero = REA.GetInt32("Numero")
                        Documento = REA.GetString("Documento")

                        fechaIngreso = REA.GetString("fechaIngreso")
                        TC_Poliza = REA.GetString("TC_Poliza")
                        GenerarRelacion(Tipo, Anio, NUmero, Documento)

                        'Utilizar tasa de cambio de importación
                        strSQL2 = "SELECT * "
                        strSQL2 &= "    FROM Dcmtos_HDR  LEFT JOIN Catalogos c ON c.cat_num = HDoc_Doc_Mon "
                        strSQL2 &= "         WHERE HDoc_Sis_Emp={empresa} AND HDoc_Doc_Cat= {cat} AND HDoc_Doc_Ano={Anio} AND HDoc_Doc_Num='{numero}'"

                        strSQL2 = Replace(strSQL2, "{empresa}", Sesion.IdEmpresa)
                        strSQL2 = Replace(strSQL2, "{cat}", REA.GetInt32("Tipo"))
                        strSQL2 = Replace(strSQL2, "{Anio}", REA.GetInt32("Anio"))
                        strSQL2 = Replace(strSQL2, "{numero}", REA.GetInt32("Numero"))

                        MyCnn.CONECTAR = strConexion
                        COM2 = New MySqlCommand(strSQL2, CON)
                        REA2 = COM2.ExecuteReader

                        If REA2.HasRows Then
                            Do While REA2.Read
                                If REA2.GetDouble("HDoc_Doc_TC") > vbEmpty Then
                                    celdaMoneda1.Text = REA2.GetInt32("HDoc_Doc_Mon")
                                    celdaMoneda.Text = REA2.GetString("cat_clave")
                                    celdaProveedor1.Text = REA2.GetInt32("HDoc_Emp_Cod")
                                    celdaProveedor.Text = REA2.GetString("HDoc_Emp_Nom")
                                    If Not celdaMoneda1.Text = NO_FILA Then
                                        celdaTasa.Text = REA2.GetDouble("HDoc_Doc_TC")

                                    Else
                                        celdaMoneda1.Text = NO_FILA
                                    End If
                                End If
                            Loop
                        End If
                        BuscarReferencia = True
                        'BuscarReferencia = True
                    Else : BuscarReferencia = False
                        Exit Function
                    End If
                Loop
            End If

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        Return BuscarReferencia
    End Function

    'Carga los datos de encabezado desde otro documento
    Private Sub CargarEncabezadoDesde(ByVal Tipo As Integer, ByVal Año As Integer, ByVal Numero As Long)
        Dim strSQL As String = STR_VACIO
        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader

        strSQL = "SELECT h.HDoc_Emp_Cod idEmpresa, h.HDoc_Emp_Nom Empresa, h.HDoc_Doc_Mon idMoneda, c.cat_desc Moneda, h.HDoc_Doc_TC Tasa, h.HDoc_Doc_Fec Fecha, p.pro_nit Nit, h.HDoc_DR2_Cat idResolucion, IFNULL(s.cat_sist,'') Resolucion "
        strSQL &= "  FROM Dcmtos_HDR h"
        strSQL &= "      LEFT JOIN Catalogos c ON c.cat_num = h.HDoc_Doc_Mon and c.cat_clase = 'Monedas'"
        strSQL &= "           LEFT JOIN Proveedores p ON p.pro_codigo = h.HDoc_Emp_Cod
                        LEFT JOIN Catalogos s ON s.cat_num = HDoc_DR2_Cat"
        strSQL &= "      WHERE h.HDoc_Sis_Emp={empresa} AND h.HDoc_Doc_Cat={Tipo} AND h.HDoc_Doc_Ano={Año} AND h.HDoc_Doc_Num={Numero}"

        strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
        strSQL = Replace(strSQL, "{Tipo}", Tipo)
        strSQL = Replace(strSQL, "{Año}", Año)
        strSQL = Replace(strSQL, "{Numero}", Numero)

        Try
            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSQL, CON)
            REA = COM.ExecuteReader

            If REA.HasRows Then
                REA.Read()
                'Proveedor
                celdaProveedor1.Text = REA.GetInt32("idEmpresa")
                celdaProveedor.Text = REA.GetString("Empresa")

                'Tasa de Cambio
                celdaTasa.Text = REA.GetDouble("Tasa")

                'Moneda
                celdaMoneda1.Text = REA.GetInt32("idMoneda")
                celdaMoneda.Text = REA.GetString("Moneda")

                'fecha
                celdaFecha1.Text = REA.GetDateTime("Fecha")
                celdaFechaVence.Text = REA.GetDateTime("Fecha")

                celdaNIT.Text = REA.GetString("Nit")
                ValidarFechaVencimiento()
            End If

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub GuardarEncabezadoConfirmacion(ByVal intNumConfirmacion As Integer)
        Dim logResultado As Boolean = True
        Dim chdr As New clsDcmtos_HDR

        Try
            chdr.CONEXION = strConexion

            chdr.HDOC_SIS_EMP = Sesion.IdEmpresa
            chdr.HDOC_DOC_CAT = 127
            chdr.HDOC_DOC_ANO = celdaAnioOc.Text
            chdr.HDOC_DOC_NUM = intNumConfirmacion
            chdr.HDoc_Doc_Fec_NET = celdaFecha1.Text

            chdr.HDOC_EMP_COD = celdaProveedor1.Text
            chdr.HDOC_EMP_NOM = celdaProveedor.Text
            chdr.HDOC_EMP_DIR = "N/A"
            chdr.HDOC_EMP_PER = "N/A"
            chdr.HDOC_EMP_TEL = "N/A"
            chdr.HDOC_EMP_NIT = celdaNIT.Text
            chdr.HDOC_DOC_TC = celdaTasa.Text
            chdr.HDOC_DOC_MON = celdaMoneda1.Text

            chdr.HDOC_RF1_DBL = celdaMonto.Text
            chdr.HDOC_USUARIO = Sesion.Usuario
            chdr.HDOC_DOC_TC = celdaTasa.Text
            chdr.HDOC_ANT_COM = 3 ' tipo de Confirmación

            'If Me.Tag = "Mod" Then
            '    If chdr.Actualizar() = False Then
            '        MsgBox(chdr.MERROR.ToString & "Document could not be update", MsgBoxStyle.Critical)
            '    End If
            'ElseIf Me.Tag = "Nuevo" Then
            If chdr.Guardar() = False Then
                MsgBox(chdr.MERROR.ToString & "Document could not be saved", MsgBoxStyle.Critical)
            End If
            'End If

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try

    End Sub

    Private Sub GuardarDetalleConfirmacion(ByVal intNumConfirmacion As Integer)
        Dim clsDTL As New clsDcmtos_DTL
        Dim logResultado As Boolean = True
        clsDTL.CONEXION = strConexion
        Try
            For i As Integer = 0 To dgFacturas.Rows.Count - 1
                clsDTL.DDOC_SIS_EMP = Sesion.IdEmpresa
                clsDTL.DDOC_DOC_CAT = 127
                clsDTL.DDOC_DOC_ANO = cfun.AñoMySQL
                clsDTL.DDOC_DOC_NUM = intNumConfirmacion
                clsDTL.DDOC_DOC_LIN = dgFacturas.Rows(i).Cells("colLineaFactura").Value


                clsDTL.DDOC_PRD_COD = dgFacturas.Rows(i).Cells("colCodigo").Value
                clsDTL.DDOC_PRD_DES = dgFacturas.Rows(i).Cells("colDescripcion").Value
                clsDTL.DDOC_PRD_UM = 419 ' Unidad de Medida - Pieza

                clsDTL.DDOC_PRD_PUQ = dgFacturas.Rows(i).Cells("colPrecio").Value    'Precio/u
                clsDTL.DDOC_PRD_DSP = 0                                             'Descuento
                clsDTL.DDOC_PRD_DSQ = 0                                             'Monto(Desc)
                clsDTL.DDOC_PRD_NET = dgFacturas.Rows(i).Cells("colPrecio").Value    'Precio Neto
                clsDTL.DDOC_PRD_QTY = dgFacturas.Rows(i).Cells("colCantidad").Value  'Cantidad

                clsDTL.DDOC_PRD_FOB = dgFacturas.Rows(i).Cells("colPrecio").Value    'Valor FOB
                clsDTL.DDOC_PRD_CIF = dgFacturas.Rows(i).Cells("colPrecio").Value    'Valor CIF
                clsDTL.DDOC_RF1_DBL = dgFacturas.Rows(i).Cells("colTotal").Value     'Total

                'clsDTL.DDOC_RF1_COD = dgDetalle.Rows(i).Cells("colOrden").Value  'Referencia

                'If dgFacturas.Rows(i).Cells("colAgregar").Value = 1 Then
                '    If clsDTL.Actualizar() = False Then
                '        MsgBox(clsDTL.MERROR.ToString & "Could not update the document", MsgBoxStyle.Critical)
                '    End If
                'ElseIf dgFacturas.Rows(i).Cells("colAgregar").Value = 0 Then
                If clsDTL.Guardar() = False Then
                    MsgBox(clsDTL.MERROR.ToString & "Could not save the document", MsgBoxStyle.Critical)
                End If
                'ElseIf dgFacturas.Rows(i).Cells("colAgregar").Value = 2 Then
                '    If clsDTL.Borrar = False Then
                '        MsgBox(clsDTL.MERROR.ToString & "Could not save the document", MsgBoxStyle.Critical)
                '    End If
                'End If
            Next


        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub GuardarDescargosConfirmacion(ByVal intnumConfirmacion As Integer)
        'Guarda el descargo para la línea de detalle actual
        Dim DTPRO As New clsDcmtos_DTL_Pro
        Dim logResultado As Boolean = True
        DTPRO.CONEXION = strConexion
        Dim i As Integer = INT_CERO

        Try
            For i = INT_CERO To dgFacturas.Rows.Count - 1
                DTPRO.PDOC_SIS_EMP = Sesion.IdEmpresa

                'Documento a ser descargado
                DTPRO.PDOC_PAR_CAT = Val(celdaCatOc.Text)
                DTPRO.PDOC_PAR_ANO = Val(celdaAnioOc.Text)
                DTPRO.PDOC_PAR_NUM = Val(celdaNumOc.Text)
                DTPRO.PDOC_PAR_LIN = dgFacturas.Rows(i).Cells("colLineaFactura").Value

                'Referencia al documento actual
                DTPRO.PDOC_CHI_CAT = 127
                DTPRO.PDOC_CHI_ANO = celdaAnioOc.Text
                DTPRO.PDOC_CHI_NUM = intnumConfirmacion
                DTPRO.PDOC_CHI_LIN = dgFacturas.Rows(i).Cells("colLineaFactura").Value

                DTPRO.PDOC_PROV_COD = celdaProveedor1.Text

                'Referencia al producto y despacho
                DTPRO.PDOC_PRD_COD = dgFacturas.Rows(i).Cells("colCodigo").Value
                DTPRO.PDOC_PRD_PNR = "N/A"
                DTPRO.PDOC_DR1_NUM = "0"
                DTPRO.PDOC_DR2_NUM = "0"
                DTPRO.PDOC_QTY_ORD = dgFacturas.Rows(i).Cells("colCantidad").Value
                DTPRO.PDOC_QTY_PRO = dgFacturas.Rows(i).Cells("colCantidad").Value

                'If dgFacturas.Rows(i).Cells("colAgregar").Value = 1 Then
                '    If DTPRO.Actualizar() = False Then
                '        MsgBox(DTPRO.MERROR.ToString & "Could not update the document", MsgBoxStyle.Critical)
                '    End If
                'ElseIf dgFacturas.Rows(i).Cells("colAgregar").Value = 0 Then
                If DTPRO.Guardar() = False Then
                    MsgBox(DTPRO.MERROR.ToString & "Could not save the document", MsgBoxStyle.Critical)
                End If
                'ElseIf dgFacturas.Rows(i).Cells("colAgregar").Value = 2 Then
                '    If DTPRO.Borrar = False Then
                '        MsgBox(DTPRO.MERROR.ToString & "Could not save the document", MsgBoxStyle.Critical)
                '    End If
                'End If

            Next
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub GuardarEncabezadoDatosPoliza(ByVal intNumDato As Integer)
        Dim cfun As New clsFunciones
        Dim logResultado As Boolean = True
        Dim chdr As New clsDcmtos_HDR

        Try
            chdr.CONEXION = strConexion
            chdr.HDOC_SIS_EMP = Sesion.IdEmpresa

            chdr.HDOC_DOC_CAT = 55
            chdr.HDOC_DOC_ANO = cfun.AñoMySQL
            chdr.HDOC_DOC_NUM = intNumDato
            chdr.HDoc_Doc_Fec_NET = celdaFecha1.Text

            chdr.HDOC_DOC_STATUS = 1
            chdr.HDOC_EMP_COD = celdaProveedor1.Text
            chdr.HDOC_EMP_NOM = celdaProveedor.Text

            chdr.HDOC_EMP_DIR = "N/A"
            chdr.HDOC_EMP_PER = "N/A"
            chdr.HDOC_EMP_TEL = "N/A"
            chdr.HDOC_EMP_NIT = "N/A"
            chdr.HDOC_DOC_TC = celdaTasa.Text
            chdr.HDOC_DOC_MON = celdaMoneda1.Text

            chdr.HDOC_DR1_NUM = "N/A"   'Factura de Referencia
            chdr.HDOC_DR2_NUM = "N/A"   'Ref.1
            chdr.HDOC_RF2_TXT = "N/A"   'Ref.2
            chdr.HDOC_ANT_COM = 3 ' tipo de datos para póliza

            chdr.HDOC_USUARIO = Sesion.Usuario

            'If Me.Tag = "Mod" Then
            '    If chdr.Actualizar() = False Then
            '        MsgBox(chdr.MERROR.ToString & "Document could not be updated", MsgBoxStyle.Critical)
            '    End If
            'ElseIf Me.Tag = "Nuevo" Then
            If chdr.Guardar() = False Then
                MsgBox(chdr.MERROR.ToString & "Document could not be saved", MsgBoxStyle.Critical)
            End If
            'End If

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub GuardarDetalleDatosPoliza(ByVal intNumDato As Integer)
        Dim clsDTL As New clsDcmtos_DTL
        Dim logResultado As Boolean = True
        Dim i As Integer = INT_CERO

        clsDTL.CONEXION = strConexion

        Try
            For i = 0 To dgFacturas.Rows.Count - 1
                clsDTL.DDOC_SIS_EMP = Sesion.IdEmpresa

                clsDTL.DDOC_DOC_CAT = 55
                clsDTL.DDOC_DOC_ANO = celdaAnioOc.Text
                clsDTL.DDOC_DOC_NUM = intNumDato
                clsDTL.DDOC_DOC_LIN = dgFacturas.Rows(i).Cells("colLineaFactura").Value

                clsDTL.DDOC_PRD_COD = dgFacturas.Rows(i).Cells("colCodigo").Value
                clsDTL.DDOC_PRD_DES = dgFacturas.Rows(i).Cells("colDescripcion").Value
                clsDTL.DDOC_PRD_UM = 419 ' Unidad de Medida - Pieza

                clsDTL.DDOC_PRD_PUQ = dgFacturas.Rows(i).Cells("colPrecio").Value    'Precio/u
                clsDTL.DDOC_PRD_DSP = 0                                             'Descuento
                clsDTL.DDOC_PRD_DSQ = 0                                             'Monto(Desc)
                clsDTL.DDOC_PRD_NET = dgFacturas.Rows(i).Cells("colPrecio").Value    'Precio Neto
                clsDTL.DDOC_PRD_QTY = dgFacturas.Rows(i).Cells("colCantidad").Value  'Cantidad

                clsDTL.DDOC_PRD_FOB = dgFacturas.Rows(i).Cells("colPrecio").Value    'Valor FOB
                clsDTL.DDOC_PRD_CIF = dgFacturas.Rows(i).Cells("colPrecio").Value    'Valor CIF
                clsDTL.DDOC_RF1_DBL = dgFacturas.Rows(i).Cells("colTotal").Value     'Total


                'If dgFacturas.Rows(i).Cells("colAgregar").Value = 1 Then
                '    If clsDTL.Actualizar() = False Then
                '        MsgBox(clsDTL.MERROR.ToString & "Could not update the document", MsgBoxStyle.Critical)
                '    End If
                'ElseIf dgFacturas.Rows(i).Cells("colAgregar").Value = 0 Then
                If clsDTL.Guardar() = False Then
                    MsgBox(clsDTL.MERROR.ToString & "Could not save the document", MsgBoxStyle.Critical)
                End If
                'ElseIf dgFacturas.Rows(i).Cells("colAgregar").Value = 2 Then
                '    If clsDTL.Borrar = False Then
                '        MsgBox(clsDTL.MERROR.ToString & "Could not save the document", MsgBoxStyle.Critical)
                '    End If
                'End If
            Next

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub GuardarDescargosDatosPoliza(ByVal intNumDato As Integer, ByVal intConfirmacion As Integer)
        'Guarda el descargo para la línea de detalle actual
        Dim DTPRO As New clsDcmtos_DTL_Pro
        Dim logResultado As Boolean = True
        Dim i As Integer = INT_CERO
        DTPRO.CONEXION = strConexion
        Try
            For i = 0 To dgFacturas.Rows.Count - 1
                DTPRO.PDOC_SIS_EMP = Sesion.IdEmpresa

                'Documento a ser descargado
                DTPRO.PDOC_PAR_CAT = 127
                DTPRO.PDOC_PAR_ANO = Val(celdaAnioOc.Text)
                DTPRO.PDOC_PAR_NUM = intConfirmacion
                DTPRO.PDOC_PAR_LIN = dgFacturas.Rows(i).Cells("colLineaFactura").Value

                'Referencia al documento actual
                DTPRO.PDOC_CHI_CAT = 55
                DTPRO.PDOC_CHI_ANO = Val(celdaAnioOc.Text)
                DTPRO.PDOC_CHI_NUM = intNumDato
                If Me.Tag = "nuevo" Then
                    DTPRO.PDOC_CHI_LIN = i + 1
                Else
                    DTPRO.PDOC_CHI_LIN = dgFacturas.Rows(i).Cells("colLineaFactura").Value
                End If
                DTPRO.PDOC_PROV_COD = Val(celdaProveedor1.Text)

                'Referencia al producto y despacho
                DTPRO.PDOC_PRD_COD = dgFacturas.Rows(i).Cells("colCodigo").Value
                DTPRO.PDOC_PRD_PNR = "N/A"
                DTPRO.PDOC_DR1_NUM = "0"
                DTPRO.PDOC_DR2_NUM = "0"

                DTPRO.PDOC_PRD_NET = dgFacturas.Rows(i).Cells("colprecio").Value
                DTPRO.PDOC_QTY_ORD = dgFacturas.Rows(i).Cells("colCantidad").Value

                DTPRO.PDOC_QTY_PRO = dgFacturas.Rows(i).Cells("colCantidad").Value

                'If dgFacturas.Rows(i).Cells("colAgregar").Value = 1 Then
                '    If DTPRO.Actualizar() = False Then
                '        MsgBox(DTPRO.MERROR.ToString & "Could not update the document", MsgBoxStyle.Critical)
                '    End If
                'ElseIf dgFacturas.Rows(i).Cells("colAgregar").Value = 0 Then
                If DTPRO.Guardar() = False Then
                    MsgBox(DTPRO.MERROR.ToString & "Could not save the document", MsgBoxStyle.Critical)
                End If
                'ElseIf dgFacturas.Rows(i).Cells("colAgregar").Value = 2 Then
                '    If DTPRO.Borrar = False Then
                '        MsgBox(DTPRO.MERROR.ToString & "Could not save the document", MsgBoxStyle.Critical)
                '    End If
                'End If
            Next
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub GuardarEncabezadoPolizaImportacion(ByVal intNumPoliza As Integer)
        Dim cfun As New clsFunciones
        Dim logResultado As Boolean = True
        Dim chdr As New clsDcmtos_HDR

        Try
            chdr.CONEXION = strConexion

            chdr.HDOC_SIS_EMP = Sesion.IdEmpresa
            chdr.HDOC_DOC_CAT = 180
            chdr.HDOC_DOC_ANO = cfun.AñoMySQL
            chdr.HDOC_DOC_NUM = intNumPoliza
            chdr.HDoc_Doc_Fec_NET = celdaFecha1.Text

            chdr.HDOC_DOC_STATUS = 1
            chdr.HDOC_EMP_COD = celdaProveedor1.Text
            chdr.HDOC_EMP_NOM = celdaProveedor.Text

            chdr.HDOC_EMP_DIR = "N/A"
            chdr.HDOC_EMP_PER = "N/A"
            chdr.HDOC_EMP_TEL = "N/A"
            chdr.HDOC_EMP_NIT = celdaNIT.Text
            chdr.HDOC_DOC_TC = celdaTasa.Text
            chdr.HDOC_DOC_MON = celdaMoneda1.Text

            chdr.HDOC_DR1_NUM = "N/A"   'Factura de Referencia
            chdr.HDOC_DR2_NUM = "N/A"   'Ref.1
            chdr.HDOC_RF2_TXT = "N/A"   'Ref.2
            chdr.HDOC_ANT_COM = 3 ' Tipo de Poliza

            chdr.HDOC_USUARIO = Sesion.Usuario

            'If Me.Tag = "Mod" Then
            '    If chdr.Actualizar() = False Then
            '        MsgBox(chdr.MERROR.ToString & "Document could not be updated", MsgBoxStyle.Critical)
            '    End If
            'ElseIf Me.Tag = "Nuevo" Then
            If chdr.Guardar() = False Then
                MsgBox(chdr.MERROR.ToString & "Document could not be saved", MsgBoxStyle.Critical)
            End If
            'End If

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Function GuardarDetallePolizaImportacion(ByVal intNumPoliza As Integer)
        Dim clsDTL As New clsDcmtos_DTL
        Dim logResultado As Boolean = True
        Dim i As Integer = INT_CERO

        clsDTL.CONEXION = strConexion

        Try
            For i = 0 To dgFacturas.Rows.Count - 1
                clsDTL.DDOC_SIS_EMP = Sesion.IdEmpresa
                clsDTL.DDOC_DOC_CAT = 180
                clsDTL.DDOC_DOC_ANO = celdaAnioOc.Text
                clsDTL.DDOC_DOC_NUM = intNumPoliza
                clsDTL.DDOC_DOC_LIN = dgFacturas.Rows(i).Cells("colLineaFactura").Value

                clsDTL.DDOC_PRD_COD = dgFacturas.Rows(i).Cells("colCodigo").Value
                clsDTL.DDOC_PRD_PNR = "N/A"
                clsDTL.DDOC_PRD_DES = dgFacturas.Rows(i).Cells("colDescripcion").Value
                clsDTL.DDOC_PRD_UM = 419 ' Catalogo de Pieza - (Unidad de medida)

                clsDTL.DDOC_PRD_PUQ = dgFacturas.Rows(i).Cells("colPrecio").Value    'Precio/u
                clsDTL.DDOC_PRD_DSP = 0                                             'Descuento
                clsDTL.DDOC_PRD_DSQ = 0                                             'Monto(Desc)
                clsDTL.DDOC_PRD_NET = dgFacturas.Rows(i).Cells("colPrecio").Value    'Precio Neto
                clsDTL.DDOC_PRD_QTY = dgFacturas.Rows(i).Cells("colCantidad").Value  'Cantidad

                clsDTL.DDOC_PRD_FOB = dgFacturas.Rows(i).Cells("colPrecio").Value    'Valor FOB
                clsDTL.DDOC_PRD_CIF = dgFacturas.Rows(i).Cells("colPrecio").Value    'Valor CIF
                clsDTL.DDOC_RF1_DBL = dgFacturas.Rows(i).Cells("colTotal").Value     'Total

                clsDTL.DDOC_RF2_NUM = 0
                clsDTL.DDOC_RF2_DBL = 0
                clsDTL.DDOC_RF3_NUM = 0
                clsDTL.DDOC_RF3_DBL = 0

                'If dgFacturas.Rows(i).Cells("colAgregar").Value = 1 Then
                '    If clsDTL.Actualizar() = False Then
                '        MsgBox(clsDTL.MERROR.ToString & "Could not update the document", MsgBoxStyle.Critical)
                '    End If
                'ElseIf dgFacturas.Rows(i).Cells("colAgregar").Value = 0 Then
                If clsDTL.Guardar() = False Then
                    MsgBox(clsDTL.MERROR.ToString & "Could not save the document", MsgBoxStyle.Critical)
                End If
                'ElseIf dgFacturas.Rows(i).Cells("colAgregar").Value = 2 Then
                '    If clsDTL.Borrar = False Then
                '        MsgBox(clsDTL.MERROR.ToString & "Could not save the document", MsgBoxStyle.Critical)
                '    End If
                'End If
            Next

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        Return logResultado
    End Function

    Private Function GuardarDescargosPolizaImportacion(ByVal intNumPoliza As Integer, ByVal intDatosPoliza As Integer)
        'Guarda el descargo para la línea de detalle actual
        Dim DTPRO As New clsDcmtos_DTL_Pro
        Dim logResultado As Boolean = True
        Dim i As Integer = INT_CERO
        DTPRO.CONEXION = strConexion
        Try
            For i = 0 To dgFacturas.Rows.Count - 1
                DTPRO.PDOC_SIS_EMP = Sesion.IdEmpresa

                'Documento a ser descargado
                DTPRO.PDOC_PAR_CAT = 55
                DTPRO.PDOC_PAR_ANO = Val(celdaAnioOc.Text)
                DTPRO.PDOC_PAR_NUM = intDatosPoliza
                DTPRO.PDOC_PAR_LIN = dgFacturas.Rows(i).Cells("colLineaFactura").Value

                'Referencia al documento actual
                DTPRO.PDOC_CHI_CAT = 180
                DTPRO.PDOC_CHI_ANO = Val(celdaAnioOc.Text)
                DTPRO.PDOC_CHI_NUM = intNumPoliza
                If Me.Tag = "nuevo" Then
                    DTPRO.PDOC_CHI_LIN = i + 1
                Else
                    DTPRO.PDOC_CHI_LIN = dgFacturas.Rows(i).Cells("colLineaFactura").Value
                End If
                DTPRO.PDOC_PROV_COD = Val(celdaProveedor1.Text)

                'Referencia al producto y despacho
                DTPRO.PDOC_PRD_COD = dgFacturas.Rows(i).Cells("colCodigo").Value
                DTPRO.PDOC_PRD_PNR = "N/A"
                DTPRO.PDOC_DR1_NUM = "0"
                DTPRO.PDOC_DR2_NUM = "0"

                DTPRO.PDOC_PRD_NET = dgFacturas.Rows(i).Cells("colprecio").Value
                DTPRO.PDOC_QTY_ORD = dgFacturas.Rows(i).Cells("colCantidad").Value

                DTPRO.PDOC_QTY_PRO = dgFacturas.Rows(i).Cells("colCantidad").Value

                'If dgFacturas.Rows(i).Cells("colAgregar").Value = 1 Then
                '    If DTPRO.Actualizar() = False Then
                '        MsgBox(DTPRO.MERROR.ToString & "Could not update the document", MsgBoxStyle.Critical)
                '    End If
                'ElseIf dgFacturas.Rows(i).Cells("colAgregar").Value = 0 Then
                If DTPRO.Guardar() = False Then
                    MsgBox(DTPRO.MERROR.ToString & "Could not save the document", MsgBoxStyle.Critical)
                End If
                'ElseIf dgFacturas.Rows(i).Cells("colAgregar").Value = 2 Then
                '    If DTPRO.Borrar = False Then
                '        MsgBox(DTPRO.MERROR.ToString & "Could not save the document", MsgBoxStyle.Critical)
                '    End If
                'End If
            Next
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Function

    Private Function ObtenerNumero(ByVal intCatalogo As Integer)
        Dim COM As New MySqlCommand
        Dim conec As MySqlConnection
        Dim strSQL As String = STR_VACIO
        Dim Numero As Integer = INT_CERO

        Try
            strSQL = "SELECT MAX(h.HDoc_Doc_Num + 1) num"
            strSQL &= "      FROM Dcmtos_HDR h"
            strSQL &= "           WHERE h.HDoc_Sis_Emp = {empresa} AND h.HDoc_Doc_Cat = {catalogo} "

            strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
            strSQL = Replace(strSQL, "{catalogo}", intCatalogo)

            conec = New MySqlConnection(strConexion)
            conec.Open()
            COM = New MySqlCommand(strSQL, conec)
            Numero = COM.ExecuteScalar
            conec.Close()
            conec.Dispose()
            conec = Nothing
            System.GC.Collect()

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try

        Return Numero
    End Function
    Private Function ObtenerUM_Producto(ByVal codProducto As Integer)
        Dim COM As New MySqlCommand
        Dim conec As MySqlConnection
        Dim strSQL As String = STR_VACIO
        Dim Numero As Integer = INT_CERO

        Try
            strSQL = "SELECT inv_UMcmpra FROM Inventarios WHERE inv_sisemp={empresa} and inv_numero = {invUMVenta} "

            strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
            strSQL = Replace(strSQL, "{invUMVenta}", codProducto)

            conec = New MySqlConnection(strConexion)
            conec.Open()
            COM = New MySqlCommand(strSQL, conec)
            Numero = COM.ExecuteScalar
            conec.Close()
            conec.Dispose()
            conec = Nothing
            System.GC.Collect()

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try

        Return Numero
    End Function
    Private Function ObtenerLinea(ByVal intAnio As Integer, ByVal intNumero As Integer)
        Dim Linea As Integer = INT_CERO
        Dim COM As New MySqlCommand
        Dim conec As MySqlConnection
        Dim strSQL As String = STR_VACIO

        Try
            strSQL = "SELECT IFNULL(MAX(d.DDoc_Doc_Lin),0) + 1 Linea"
            strSQL &= "      FROM Dcmtos_DTL d"
            strSQL &= "              WHERE d.DDoc_Sis_Emp = {empresa} and d.DDoc_Doc_Cat = {catalogo} and d.DDoc_Doc_Ano = {anio} and d.DDoc_Doc_Num = {numero}"

            strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
            strSQL = Replace(strSQL, "{anio}", intAnio)
            strSQL = Replace(strSQL, "{numero}", intNumero)
            strSQL = Replace(strSQL, "{catalogo}", celdaCatOc.Text)

            conec = New MySqlConnection(strConexion)
            conec.Open()
            COM = New MySqlCommand(strSQL, conec)
            Linea = COM.ExecuteScalar
            conec.Close()
            conec.Dispose()
            conec = Nothing
            System.GC.Collect()

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try

        Return Linea
    End Function

    Private Sub GuardarEncabezadoIngresoBodega(ByVal intNumIngreso As Integer)
        Dim chdr As New clsDcmtos_HDR
        Try
            chdr.CONEXION = strConexion

            chdr.HDOC_SIS_EMP = Sesion.IdEmpresa
            chdr.HDOC_DOC_CAT = 47
            chdr.HDOC_DOC_ANO = celdaAnioOc.Text
            chdr.HDOC_DOC_NUM = intNumIngreso
            chdr.HDoc_Doc_Fec_NET = dtpFecha1.Value

            chdr.HDOC_EMP_COD = celdaProveedor1.Text
            chdr.HDOC_EMP_NOM = celdaProveedor.Text
            chdr.HDOC_EMP_DIR = "N/A"
            chdr.HDOC_EMP_NIT = celdaNIT.Text
            chdr.HDOC_EMP_TEL = "N/A"
            chdr.HDOC_DR1_NUM = celdaNumero.Text
            chdr.HDOC_DR2_NUM = celdaSerie.Text
            chdr.HDOC_DOC_MON = celdaMoneda1.Text
            chdr.HDOC_DOC_TC = celdaTasa.Text

            chdr.HDOC_DR1_CAT = 3

            chdr.HDOC_USUARIO = Sesion.Usuario
            chdr.HDOC_ANT_COM = 3 ' Tipo de Ingreso a Bodega


            'If Me.Tag = "Mod" Then
            '    If chdr.Actualizar() = False Then
            '        MsgBox(chdr.MERROR.ToString & "Could not update the document", MsgBoxStyle.Critical)
            '    End If
            'Else
            If chdr.Guardar() = False Then
                MsgBox(chdr.MERROR.ToString & "Could not save the document", MsgBoxStyle.Critical)
            End If
            'End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub GuardarDetalleIngresoBodega(ByVal intNumIngreso As Integer)
        Dim logResultado As Boolean = True
        Dim Dtl As New clsDcmtos_DTL
        Dtl.CONEXION = strConexion
        Dim j As Integer = 0

        Try
            For i As Integer = 0 To dgFacturas.Rows.Count - 1
                Dtl.DDOC_SIS_EMP = Sesion.IdEmpresa
                Dtl.DDOC_DOC_CAT = 47
                Dtl.DDOC_DOC_ANO = celdaAnioOc.Text
                Dtl.DDOC_DOC_NUM = intNumIngreso

                Dtl.DDOC_DOC_LIN = i + 1

                Dtl.DDOC_PRD_COD = dgFacturas.Rows(i).Cells("colCodigoP").Value
                Dtl.DDOC_PRD_PNR = dgFacturas.Rows(i).Cells("colCuenta").Value
                Dtl.DDOC_PRD_UM = ObtenerUM_Producto(dgFacturas.Rows(i).Cells("colCodigoP").Value)
                ' Dtl.DDOC_PRD_UM = 419 ' Unidad de Medida - Pieza
                Dtl.DDOC_PRD_DES = dgFacturas.Rows(i).Cells("colDescripcion").Value

                Dtl.DDOC_PRD_PUQ = CDbl(dgFacturas.Rows(i).Cells("colPrecio").Value) ' Precio con IVA (Nicaragua)
                If Sesion.IdEmpresa = 18 Or Sesion.IdEmpresa = 19 And Sesion.IdEmpresa = 21 Then
                    Dtl.DDOC_PRD_NET = CDbl(dgFacturas.Rows(i).Cells("colPrecioSinIVA").Value) ' Precio Sin IVA (Nicaragua)
                Else
                    Dtl.DDOC_PRD_NET = CDbl(dgFacturas.Rows(i).Cells("colPrecio").Value)
                End If

                Dtl.DDOC_PRD_QTY = CDbl(dgFacturas.Rows(i).Cells("colCantidad").Value)

                'Dtl.DDOC_RF1_TXT = dgFacturas.Rows(i).Cells("colCosto").Value
                Dtl.DDOC_RF1_COD = CDbl(dgFacturas.Rows(i).Cells("colCodigoP").Value)
                Dtl.DDOC_RF1_DBL = CDbl(dgFacturas.Rows(i).Cells("colTotal").Value)

                Dtl.DDOC_RF2_COD = dgFacturas.Rows(i).Cells("colCuentaActivo").Value
                Dtl.DDOC_RF2_TXT = dgFacturas.Rows(i).Cells("colClasificacion").Value
                Dtl.DDOC_RF3_TXT = dgFacturas.Rows(i).Cells("colGasto").Value


                If Sesion.IdEmpresa = 22 And rbOrdenDeCompra.Checked = True Then
                    Dtl.DDOC_RF4_COD = IIf(dgFacturas.Rows(i).Cells("loteNum").Value = vbNullString, STR_VACIO, dgFacturas.Rows(i).Cells("loteNum").Value)
                End If

                'If dgFacturas.Rows(i).Cells("colAgregar").Value = 1 Then
                '    If Dtl.Actualizar() = False Then
                '        MsgBox(Dtl.MERROR.ToString & "Could not update the document", MsgBoxStyle.Critical)
                '    End If
                'ElseIf dgFacturas.Rows(i).Cells("colAgregar").Value = 0 Then
                If Dtl.Guardar() = False Then
                    MsgBox(Dtl.MERROR.ToString & "Could not save the document", MsgBoxStyle.Critical)
                End If
                'ElseIf dgFacturas.Rows(i).Cells("colAgregar").Value = 2 Then
                '    If Dtl.Borrar = False Then
                '        MsgBox(Dtl.MERROR.ToString & "Could not save the document", MsgBoxStyle.Critical)
                '    End If
                'End If
            Next

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub GuardarDescargosIngresoBodega(ByVal intNumIngreso As Integer, ByVal intNumPolizaImportacion As Integer)
        'Guarda el descargo para la línea de detalle actual
        Dim DTPRO As New clsDcmtos_DTL_Pro
        Dim logResultado As Boolean = True
        DTPRO.CONEXION = strConexion
        Dim i As Integer = INT_CERO

        Try
            For i = INT_CERO To dgFacturas.Rows.Count - 1
                DTPRO.PDOC_SIS_EMP = Sesion.IdEmpresa

                'Documento a ser descargado
                DTPRO.PDOC_PAR_CAT = Val(celdaCatOc.Text)
                DTPRO.PDOC_PAR_ANO = Val(celdaAnioOc.Text)
                DTPRO.PDOC_PAR_NUM = celdaNumOc.Text
                DTPRO.PDOC_PAR_LIN = dgFacturas.Rows(i).Cells("colLineaFactura").Value

                'Referencia al documento actual
                DTPRO.PDOC_CHI_CAT = 47
                DTPRO.PDOC_CHI_ANO = celdaAnioOc.Text
                DTPRO.PDOC_CHI_NUM = intNumIngreso
                DTPRO.PDOC_CHI_LIN = dgFacturas.Rows(i).Cells("colLineaFactura").Value

                DTPRO.PDOC_PROV_COD = celdaProveedor1.Text

                'Referencia al producto y despacho
                DTPRO.PDOC_PRD_COD = dgFacturas.Rows(i).Cells("colCodigo").Value
                DTPRO.PDOC_PRD_PNR = "N/A"
                DTPRO.PDOC_DR1_NUM = "0"
                DTPRO.PDOC_DR2_NUM = "0"

                DTPRO.PDOC_PRD_NET = dgFacturas.Rows(i).Cells("colprecio").Value
                DTPRO.PDOC_QTY_ORD = dgFacturas.Rows(i).Cells("colCantidad").Value
                DTPRO.PDOC_QTY_PRO = dgFacturas.Rows(i).Cells("colCantidad").Value


                'If dgFacturas.Rows(i).Cells("colAgregar").Value = 1 Then
                '    If DTPRO.Actualizar() = False Then
                '        MsgBox(DTPRO.MERROR.ToString & "Could not update the document", MsgBoxStyle.Critical)
                '    End If
                'ElseIf dgFacturas.Rows(i).Cells("colAgregar").Value = 0 Then
                If DTPRO.Guardar() = False Then
                    MsgBox(DTPRO.MERROR.ToString & "Could not save the document", MsgBoxStyle.Critical)
                End If
                'ElseIf dgFacturas.Rows(i).Cells("colAgregar").Value = 2 Then
                '    If DTPRO.Borrar = False Then
                '        MsgBox(DTPRO.MERROR.ToString & "Could not save the document", MsgBoxStyle.Critical)
                '    End If
                'End If

            Next
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub JalarCAI(ByVal intCodigo As Integer)
        Dim strSQL As String = STR_VACIO
        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader

        strSQL = "SELECT  IFNULL(p.pro_cai, '') CAI"
        strSQL &= "     FROM Proveedores p"
        strSQL &= "              WHERE p.pro_sisemp = {empresa} and p.pro_codigo = {codProducto}"

        strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
        strSQL = Replace(strSQL, "{codProducto}", intCodigo)

        Try
            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSQL, CON)
            REA = COM.ExecuteReader

            If REA.HasRows Then
                REA.Read()
                celdaCAI.Text = REA.GetString("CAI")
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try


    End Sub

    Private Sub ImprimirFormatoDominicana()
        Try
            Dim frm As New frmOption
            Dim rpt As New clsReportes

            frm.Titulo = "Seleccione el formato que desea imprimir"
            frm.Text = "Formato de Impresion"
            frm.Opciones = "Gasto Menor|Proveedor Informal"

            frm.ShowDialog(Me)
            If frm.DialogResult = System.Windows.Forms.DialogResult.OK Then
                rpt.ImprimirFacturaCompraDominicana(CInt(celdaAnioOc.Text), CInt(celdaNumOc.Text), frm.Seleccion)
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub
    Private Function DependeciasFacturaCompra() As Integer
        Dim intValidacion As Integer
        Dim COM As MySqlCommand
        Dim conec As MySqlConnection
        Dim strSQL As String = STR_VACIO
        Try
            strSQL = "  SELECT COUNT(*) "
            strSQL &= "    	FROM Dcmtos_DTL_Pro p "
            strSQL &= "         WHERE p.PDoc_Sis_Emp = {empresa} AND p.PDoc_Par_Cat = {catalogo} AND p.PDoc_Par_Ano = {anio} AND p.PDoc_Par_Num = {numero}   "
            strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
            strSQL = Replace(strSQL, "{anio}", celdaAnioOc.Text)
            strSQL = Replace(strSQL, "{numero}", celdaNumOc.Text)
            strSQL = Replace(strSQL, "{catalogo}", celdaCatOc.Text)
            conec = New MySqlConnection(strConexion)
            conec.Open()
            COM = New MySqlCommand(strSQL, conec)
            Using conec
                intValidacion = COM.ExecuteScalar
                COM.Dispose()
                COM = Nothing
                conec.Close()
                conec.Dispose()
                conec = Nothing
                System.GC.Collect()
            End Using
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        Return intValidacion
    End Function
    Private Function DependeciasVarias() As Integer
        Dim intValidacion As Integer
        Dim COM As MySqlCommand
        Dim conec As MySqlConnection
        Dim strSQL As String = STR_VACIO
        Try
            strSQL = "  SELECT COUNT(*) "
            strSQL &= "    	FROM ECtaCte ce "
            strSQL &= "         LEFT JOIN Dcmtos_HDR hh ON hh.HDoc_Sis_Emp = ce.ECta_Sis_Emp AND hh.HDoc_Doc_Cat =ce.ECta_Doc_Cat AND hh.HDoc_Doc_Ano = ce.ECta_Doc_Ano AND hh.HDoc_Doc_Num =ce.ECta_Doc_Num "
            strSQL &= "             LEFT JOIN Catalogos cc ON cc.cat_num = hh.HDoc_Doc_Cat "
            strSQL &= "         WHERE ce.ECta_Sis_Emp = {empresa} AND ce.ECta_Ref_Cat = {cat} AND ce.ECta_Ref_Ano = {anio} AND ce.ECta_Ref_Num = {numero} AND ce.ECta_Ref_Cat != ce.ECta_Doc_Cat 
                            AND NOT (if(hh.HDoc_Doc_Cat IN (689) AND hh.HDoc_Doc_Status=0, 3, hh.HDoc_Doc_Status))>1   "
            strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
            strSQL = Replace(strSQL, "{anio}", celdaAnioOc.Text)
            strSQL = Replace(strSQL, "{numero}", celdaNumOc.Text)
            strSQL = Replace(strSQL, "{cat}", celdaCatOc.Text)
            conec = New MySqlConnection(strConexion)
            conec.Open()
            COM = New MySqlCommand(strSQL, conec)
            Using conec
                intValidacion = COM.ExecuteScalar
                COM.Dispose()
                COM = Nothing
                conec.Close()
                conec.Dispose()
                conec = Nothing
                System.GC.Collect()
            End Using
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        Return intValidacion
    End Function
    'Borrar Encabezado Ingreso
    Public Function BorrarEncabezadoFacturaCompra() As Boolean
        Dim logGuardar As Boolean = False
        Try
            Dim hdr As New clsDcmtos_HDR
            hdr.CONEXION = strConexion
            hdr.HDOC_SIS_EMP = Sesion.IdEmpresa
            hdr.HDOC_DOC_CAT = celdaCatOc.Text
            hdr.HDOC_DOC_ANO = celdaAnioOc.Text
            hdr.HDOC_DOC_NUM = celdaNumOc.Text
            hdr.Borrar()
            logGuardar = True
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        Return logGuardar
    End Function
    ' Borrar Detalle Ingreso
    Private Function BorrarDetalleFacturaCompra() As Boolean
        Dim logGuardar As Boolean
        Try
            If LogBorrar = True Then
                For i = 0 To dgFacturas.Rows.Count - 1

                    Dim dtl As New clsDcmtos_DTL
                    dtl.CONEXION = strConexion
                    dtl.DDOC_SIS_EMP = Sesion.IdEmpresa
                    dtl.DDOC_DOC_CAT = celdaCatOc.Text
                    dtl.DDOC_DOC_ANO = celdaAnioOc.Text
                    dtl.DDOC_DOC_NUM = celdaNumOc.Text
                    dtl.DDOC_DOC_LIN = dgFacturas.Rows(i).Cells("colLineaFactura").Value
                    dtl.Borrar()

                Next
                logGuardar = True
            Else
                MsgBox("You don't have permission to this access")
                logGuardar = False
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        Return logGuardar
    End Function


    Private Sub BorrarImpuestosDoc()
        Dim strSQL As String = STR_VACIO
        Try
            strSQL = "MDoc_Sis_Emp = {empresa}  AND MDoc_Doc_Cat = {catalogo} AND MDoc_Doc_Ano = {anio} AND MDoc_Doc_Num = {numero} "
            strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
            strSQL = Replace(strSQL, "{anio}", celdaAnioOc.Text)
            strSQL = Replace(strSQL, "{numero}", celdaNumOc.Text)
            strSQL = Replace(strSQL, "{catalogo}", celdaCatOc.Text)
            Dim imp As New Tablas.TDCMTOS_IMP
            imp.CONEXION = strConexion
            imp.PDELETE(strSQL)
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub


    ' Borrar Acc Ingreso 
    Private Function BorrarAccFacturaCompra() As Boolean
        Dim logGuardar As Boolean
        Dim strSQL As String = STR_VACIO
        Try
            If LogBorrar = True Then
                strSQL = "ADoc_Sis_Emp = {empresa} AND ADoc_Doc_Cat = {catalogo} AND ADoc_Doc_Ano  = {anio}   AND ADoc_Doc_Num  = {numero}   "
                strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
                strSQL = Replace(strSQL, "{anio}", celdaAnioOc.Text)
                strSQL = Replace(strSQL, "{numero}", celdaNumOc.Text)
                strSQL = Replace(strSQL, "{catalogo}", celdaCatOc.Text)
                Dim acc As New Tablas.TDCMTOS_ACC
                acc.CONEXION = strConexion
                acc.PDELETE(strSQL)
                logGuardar = True
            Else
                MsgBox("You don't have permission to this access")
                logGuardar = False
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        Return logGuardar
    End Function
    'Borrar Ectate
    Private Function BorrarEctateFacturaCompra() As Boolean
        Dim logGuardar As Boolean
        Dim strSQl As String = STR_VACIO
        Try

            If LogBorrar = True Then
                strSQl = "ECta_Sis_Emp = {empresa} AND ECta_Doc_Cat = {catalogo} AND ECta_Doc_Ano  = {anio} AND ECta_Doc_Num = {numero}  "
                strSQl = Replace(strSQl, "{empresa}", Sesion.IdEmpresa)
                strSQl = Replace(strSQl, "{anio}", celdaAnioOc.Text)
                strSQl = Replace(strSQl, "{numero}", celdaNumOc.Text)
                strSQl = Replace(strSQl, "{catalogo}", celdaCatOc.Text)
                Dim ectacte As New Tablas.TECTACTE
                ectacte.CONEXION = strConexion
                ectacte.PDELETE(strSQl)
                logGuardar = True
            Else
                MsgBox("You don't have permission to this access")
            End If

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        Return logGuardar
    End Function
    'Borrar Descargo 
    Private Function BorrarDescargosFacturaCompra() As Boolean
        Dim logGuardar As Boolean
        Dim strSQl As String = STR_VACIO
        Try
            ' For i = 0 To dgPoliza.Rows.Count - 1
            If LogBorrar = True Then
                strSQl = "PDoc_Sis_Emp = {empresa} AND PDoc_Chi_Cat = {catalogo} AND PDoc_Chi_Ano  = {anio} AND PDoc_Chi_Num = {numero}  "
                strSQl = Replace(strSQl, "{empresa}", Sesion.IdEmpresa)
                strSQl = Replace(strSQl, "{anio}", celdaAnioOc.Text)
                strSQl = Replace(strSQl, "{numero}", celdaNumOc.Text)
                strSQl = Replace(strSQl, "{catalogo}", celdaCatOc.Text)
                ' strSQl = Replace(strSQl, "{linea}", dgPoliza.Rows(i).Cells("colLinea").Value)
                Dim pro As New clsDcmtos_DTL_Pro
                pro.CONEXION = strConexion
                pro.Borrar(strSQl)
                logGuardar = True
            Else
                MsgBox("You don't have permission to this access")
                '  Exit For
            End If
            '  Next
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        Return logGuardar
    End Function
    Private Function ActualizarNotasFechaVec() As Boolean
        Dim logGuardar As Boolean
        Dim strSQL As String = STR_VACIO
        Dim COM As MySqlCommand
        Try
            strSQL = " UPDATE  Dcmtos_HDR h SET h.HDoc_DR1_Fec = '{fecha}' , h.HDoc_RF1_Txt = '{nota}' WHERE h.HDoc_Sis_Emp = {empresa} AND h.HDoc_Doc_Cat = {catalogo} AND h.HDoc_Doc_Ano = {anio} AND h.HDoc_Doc_Num = {numero}"
            If Sesion.IdEmpresa = 18 Then
                strSQL &= "; UPDATE PDM.Dcmtos_HDR h SET h.HDoc_DR1_Fec = '{fecha}' , h.HDoc_RF1_Txt = '{nota}' WHERE h.HDoc_Sis_Emp = {empresa} AND h.HDoc_Doc_Cat = {catalogo} AND h.HDoc_Doc_Ano = {anio} AND h.HDoc_Doc_Num = {numero}"
            End If
            strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
            strSQL = Replace(strSQL, "{catalogo}", celdaCatOc.Text)
            strSQL = Replace(strSQL, "{anio}", celdaAnioOc.Text)
            strSQL = Replace(strSQL, "{numero}", celdaNumOc.Text)
            strSQL = Replace(strSQL, "{fecha}", dtpFechaVence.Value.ToString(FORMATO_MYSQL))
            strSQL = Replace(strSQL, "{nota}", celdaNotas.Text)
            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSQL, CON)
            COM.ExecuteNonQuery()
            COM = Nothing
            logGuardar = True
            MsgBox("correctly updated", MsgBoxStyle.Information)
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        Return logGuardar
    End Function

#End Region

#Region "Eventos"

    Private Sub frmFacturaCompra_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Control.CheckForIllegalCrossThreadCalls = False
        Accesos()
        dtpInicial.Value = Today.AddDays(-10)
        dtpFinal.Value = Today
        rbLocal.Checked = False
        MostrarLista()
        If Sesion.idGiro = 2 Then
            checkContribuyent.Text = "Does not Generate VAT"
            dgFacturas.Columns(8).ReadOnly = True ' columna de Precio
        Else
            checkContribuyent.Text = "Small Taxpayer / Import"
        End If
    End Sub

    Private Sub frmFacturaCompra_FormClosed(sender As Object, e As FormClosedEventArgs)
        Try
            frmSPrincipal.BarraDeTareas1.QuitarFormulario(strKey)
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub Encabezado1_ClickCerrar(sender As Object, click As Boolean) Handles Encabezado1.ClickCerrar
        If panelLista.Visible = True Then
            Me.Close()
            Fprincipal.BarraDeTareas1.QuitarFormulario(Key)
        ElseIf panelDetalle.Visible = True Then
            MostrarLista(1)
        ElseIf panelDocumento.Visible = True Then
            MostrarLista()
        ElseIf panelProrrateo.Visible = True Then
            MostrarLista(1)
        End If
    End Sub

    Private Sub Encabezado1_clickNuevo(sender As Object, click As Boolean) Handles Encabezado1.ClickNuevo
        If VerificaBloqueo() = 1 Then
            Me.Tag = "Nuevo"

            MostrarLista(1)
            Limpiar()
            ActivarFel()
            etiquetaSerieF.Visible = False
            etiquetaAutorizacion.Visible = False
            celdaNumero.Focus()
            Encabezado1.botonGuardar.Enabled = True
            Encabezado1.botonNuevo.Enabled = False
            Encabezado1.botonBorrar.Enabled = False
            logAnulado = False
            celdaProveedor.ReadOnly = True
            etiquetaSerie.Visible = True
            etiquetaInvoice.Visible = False

            checkActivoFijo.Enabled = True
            checkContribuyent.Checked = False
            checkFacElectrónica.Checked = False
            CheckFactEspecial.Checked = False
            celdaDetFact.Text = "Detalle de Factura"
            celdaDetFact.BackColor = Color.RoyalBlue
            celdaDetFact.TextAlign = HorizontalAlignment.Left
            celdaDetFact.ForeColor = Color.White

            dgFacturas.Columns("loteNum").Visible = False

            ' rbLocal.Checked = True
            'If Sesion.IdEmpresa = 18 Then
            '    dgFacturas.Columns(7).Visible = True
            '    dgFacturas.Columns(13).Visible = True
            'Else
            '    dgFacturas.Columns(7).Visible = False
            '    dgFacturas.Columns(13).Visible = False
            'End If
            rbImportación.Checked = False
            rbOrdenDeCompra.Checked = False
            rbLocal.Checked = True

            logIVA = False
            checkRevisado.Checked = False
            checkRevisado.Enabled = True
            botonISR.Enabled = False
            botonPagos.Enabled = False
            celdaCatOc.Text = INT_CERO  ' se mueve al proceso del boton.<
            etiquetaMontoTotal.Text = 0.0
            celdaMonto.Text = 0.0
            etiquetaExtemporanea.Visible = False
            celdaCAI.BackColor = Color.White
            If cfun.PermisoAnular() = True Then
                dtpFechaPolizaC.Enabled = True
            Else
                dtpFechaPolizaC.Enabled = False
            End If
            If Sesion.idGiro = 2 Then
                botonGenerarIngreso.Visible = True
                botonGenerarIngreso.Enabled = False
                celdaCAI.ReadOnly = False
            ElseIf Sesion.IdEmpresa = 11 Then
                celdaCAI.ReadOnly = False
            Else
                celdaCAI.ReadOnly = True
            End If
        Else
            MsgBox(" At this time you can not enter invoices, please contact the Financial Department ", vbInformation, "Notice")
        End If


    End Sub

    Private Sub botonActualizar_Click(sender As Object, e As EventArgs) Handles botonActualizar.Click

        Dim logCancelar As Boolean
        Dim tipo As String

        If CDate(dtpInicial.Value) > CDate(dtpFinal.Value) Then
            MsgBox("The start Date may Not exceed the final Date", vbExclamation, "Notice")
            logCancelar = True
        End If
        If Not (logCancelar) Then
            dgLista.Rows.Clear()

            'Procedimiento para cargar panel dgLista
            tipo = "Todos"
            QueryListaPrincipal(tipo)
            If checkDocSaldo.Checked = True Then

            End If

        End If

    End Sub

    Private Sub botonProveedores_Click(sender As Object, e As EventArgs) Handles botonProveedores.Click
        Dim frm As New frmSeleccionar
        Try
            frm.Titulo = "Provider"
            frm.Campos = " p.pro_codigo,p.pro_proveedor"
            frm.Tabla = "Proveedores p"
            frm.FiltroText = "Enter the Name Of the Provider To Filter"
            frm.Filtro = "p.pro_proveedor"
            frm.Condicion = "p.pro_sisemp = " & Sesion.IdEmpresa & " and p.pro_codigo > 0"
            frm.Ordenamiento = "p.pro_proveedor"

            frm.ShowDialog(Me)

            If frm.DialogResult = System.Windows.Forms.DialogResult.OK Then
                celdaidProveedores.Text = frm.LLave
                celdaProveedores.Text = frm.Dato


            End If



        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try

    End Sub

    Private Sub botonLocal_Click(sender As Object, e As EventArgs) Handles botonLocal.Click
        Dim tipo As String
        tipo = "Local"
        QueryListaPrincipal(tipo)

    End Sub

    Private Sub botonImportaciones_Click(sender As Object, e As EventArgs) Handles botonImportaciones.Click
        Dim tipo As String
        tipo = "Importacion"
        QueryListaPrincipal(tipo)
    End Sub

    Private Sub botonTodo_Click(sender As Object, e As EventArgs) Handles botonTodo.Click
        Dim tipo As String
        tipo = "Todos"
        QueryListaPrincipal(tipo)

    End Sub

    Private Sub dgLista_DoubleClick(sender As Object, e As EventArgs) Handles dgLista.DoubleClick
        Me.Tag = "Mod"
        logIVA = True
        Dim intAnio As Integer = INT_CERO
        Dim intNumero As Integer = INT_CERO

        Dim retenNum As Integer = INT_CERO
        Dim catRelacion As Integer = INT_CERO
        Dim clase As String = STR_VACIO
        intControlador = 0
        Limpiar()
        botonISR.Enabled = True
        botonPagos.Enabled = True
        Encabezado1.botonGuardar.Enabled = True
        Encabezado1.botonNuevo.Enabled = False
        BotonNotas.Enabled = True
        botonMas.Enabled = True
        celdaCAI.BackColor = Color.White
        If dgLista.SelectedRows.Count = INT_CERO Then Exit Sub

        intDocumentoTipo = dgLista.SelectedCells(1).Value
        intAnio = dgLista.SelectedCells(2).Value
        intNumero = dgLista.SelectedCells(3).Value
        retenNum = dgLista.SelectedCells(14).Value
        clase = dgLista.SelectedCells(9).Value


        BarraTitulo1.CambiarTitulo("Change Entry")
        QueryDatosFactura(intAnio, intNumero, retenNum, intDocumentoTipo)
        QueryDetalleFact(intAnio, intNumero, intDocumentoTipo)
        '  DesgloseImpuestos()
        CargarImpuesto(celdaCatOc.Text, intAnio, intNumero)
        intControlador = NO_FILA
        If clase = "Importación" Then
            botonGenerarIngreso.Visible = False
            catRelacion = 180
            queryPolizaImport(intAnio, intNumero, catRelacion)
        ElseIf clase = "Orden de Compra" Then
            catRelacion = 777
            botonGenerarIngreso.Enabled = False
            queryPolizaImport(intAnio, intNumero, catRelacion)
            If Sesion.idGiro = 2 Then
                botonGenerarIngreso.Visible = True
                VerificarDcmtosIngreso(intAnio, intNumero)
                celdaCAI.ReadOnly = False
            End If
        ElseIf clase = "Local" Then
            botonGenerarIngreso.Visible = False
        End If
        If Sesion.IdEmpresa = 11 Or Sesion.idGiro = 2 Then
            celdaCAI.ReadOnly = False
        Else
            celdaCAI.ReadOnly = True
        End If
        If Sesion.IdEmpresa = 12 And Pais() = 0 Then
            If CheckFactEspecial.Checked = True Then
                CargarDatosFel()
            End If
        End If
        Encabezado1.botonNuevo.Enabled = True
        MostrarLista(1)
        If Sesion.IdEmpresa = 12 And Pais() = 0 Then
            If celdaSerieFel.Text <> STR_VACIO Then
                BloquearFel()
            Else
                ActivarFel()
            End If
            'ElseIf (Sesion.idGiro = 2 And rbOrdenDeCompra.Checked = True And celdaTipoOrden.Text = 0) Then
            '    BloquearFel()
        End If
        If cfun.PermisoAnular() = True Then
            dtpFechaPolizaC.Enabled = True
        Else
            dtpFechaPolizaC.Enabled = False
        End If
        dgFacturas.Columns("colGasto").ReadOnly = True
        dgFacturas.Columns("colCentro").ReadOnly = True
        dgFacturas.Columns("colClasificacion").ReadOnly = True

        If intDocumentoTipo = 44 Then
            BloquearCuandoEsRecibo(False)
            celdaProveedor.ReadOnly = True
        ElseIf intDocumentoTipo = 209 Then
            BloquearCuandoEsRecibo(True)
            celdaProveedor.ReadOnly = False
        End If

    End Sub

    Private Sub checkProrrateo_Click(sender As Object, e As EventArgs) Handles checkProrrateo.Click
        If checkProrrateo.Checked = False Then
            botonProrrateo.Enabled = False
        ElseIf checkProrrateo.Checked = True Then
            botonProrrateo.Enabled = True
        End If
    End Sub

    Private Sub botonPagos_Click(sender As Object, e As EventArgs) Handles botonPagos.Click
        Dim intAnio As Integer
        Dim intNumero As Integer

        intAnio = celdaAnioOc.Text
        intNumero = celdaNumOc.Text

        MostrarLista(2)
        QueryPagos(intAnio, intNumero)


    End Sub

    'Private Sub botonTipo3_Click(sender As Object, e As EventArgs)
    '    Me.Tag = "Nuevo"
    '    Dim frm As New frmSeleccionar

    '    Try
    '        frm.Titulo = "Documents"
    '        frm.Campos = "c.cat_desc Documento, c.cat_num ID"
    '        frm.Tabla = "Catalogos c"
    '        frm.FiltroText = " Enter the Document To filter"
    '        frm.Filtro = " c.cat_desc "
    '        frm.Limite = 5
    '        frm.Ordenamiento = " c.cat_desc "
    '        frm.TipoOrdenamiento = ""
    '        frm.Condicion = "cat_clase='Documentos' AND (cat_sist='Doc_BCheque' OR cat_sist='Doc_PNota/DB' OR cat_sist='Doc_PNota/CR')"

    '        frm.ShowDialog(Me)

    '        If frm.DialogResult = System.Windows.Forms.DialogResult.OK Then
    '            celdaTipo3.Text = frm.LLave
    '        End If

    '    Catch ex As Exception
    '        MsgBox(ex.ToString)
    '    End Try
    'End Sub

    'Private Sub botonMoneda3_Click(sender As Object, e As EventArgs)
    '    Me.Tag = "Nuevo"
    '    Dim frm As New frmSeleccionar

    '    Try
    '        frm.Titulo = "Coin"
    '        frm.Campos = "c.cat_clave Moneda, c.cat_num ID, c.cat_sist"
    '        frm.Tabla = "Catalogos c"
    '        frm.FiltroText = " Enter the Coin To filter"
    '        frm.Filtro = " c.cat_clave "
    '        frm.Limite = 5
    '        frm.Ordenamiento = " c.cat_clave"
    '        frm.TipoOrdenamiento = ""
    '        frm.Condicion = "cat_clase='Monedas'"

    '        frm.ShowDialog(Me)

    '        If frm.DialogResult = System.Windows.Forms.DialogResult.OK Then
    '            celdaMoneda3.Text = frm.LLave
    '            celdaTasa3.Text = frm.Dato2
    '        End If

    '    Catch ex As Exception
    '        MsgBox(ex.ToString)
    '    End Try
    'End Sub

    Private Sub botonFecha_Click(sender As Object, e As EventArgs) Handles botonFecha.Click
        Dim num As Integer
        num = celdaProveedor1.Text

        If num > vbEmpty Then
            QueryFechaVence(num)
        End If
    End Sub

    Private Sub botonMoneda_Click(sender As Object, e As EventArgs) Handles botonMoneda.Click
        'Me.Tag = "Nuevo"
        Dim frm As New frmSeleccionar

        Try
            frm.Titulo = "Coin"
            frm.Campos = "c.cat_clave Moneda, c.cat_num ID, c.cat_sist"
            frm.Tabla = "Catalogos c"
            frm.FiltroText = " Enter the Coin To filter"
            frm.Filtro = " c.cat_clave "
            frm.Limite = 5
            frm.Ordenamiento = " c.cat_clave "
            frm.TipoOrdenamiento = ""
            frm.Condicion = "cat_clase='Monedas'"

            frm.ShowDialog(Me)

            If frm.DialogResult = System.Windows.Forms.DialogResult.OK Then
                celdaMoneda.Text = frm.LLave
                celdaMoneda1.Text = frm.Dato
                If frm.Dato2 > 1 Then
                    celdaTasa.Text = cfun.TasaSegunFecha(dtpFecha1.Value.ToString(FORMATO_MYSQL))
                Else
                    celdaTasa.Text = frm.Dato2
                End If

                If celdaMonto.Text.ToString.Length > 0 Then
                    etiquetaMontoTotal.Text = (celdaMonto.Text * celdaTasa.Text)
                    'logIVA = True
                    CalcuarImpuesto()

                End If

            End If

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try

    End Sub

    Private Sub botonProveedor_Click(sender As Object, e As EventArgs) Handles botonProveedor.Click
        'Me.Tag = "Nuevo"
        Dim strRemplazo As String = STR_VACIO
        Dim frm As New frmSeleccionar
        Dim strFila As String = STR_VACIO
        Dim CodProveedor As String = STR_VACIO

        strRemplazo = "p.pro_sisemp = {empresa} and p.pro_status = 'Activo'"
        strRemplazo = Replace(strRemplazo, "{empresa}", Sesion.IdEmpresa)


        Try
            frm.Titulo = "Providers"
            frm.Campos = "p.pro_codigo id, p.pro_proveedor Proveedor, p.pro_iva SIVA, p.pro_nit nit, p.pro_servicio Categoria, c.cat_clave Moneda, IFNULL(t.Tasa,1) TC, c.cat_num idMon,  t.Fecha FechaTasa"
            frm.Tabla = "Proveedores p LEFT JOIN Catalogos c ON c.cat_num = p.pro_moneda " & " LEFT JOIN ( SELECT t1.Exterior, t1.Tasa, t1.Fecha FROM TCambio t1 WHERE t1.Fecha <= '" & dtpFecha1.Value.ToString(FORMATO_MYSQL) & "' ORDER BY t1.Fecha DESC LIMIT 1) t ON t.Exterior = p.pro_moneda"
            frm.FiltroText = "Enter the provider to filter"
            frm.Filtro = "p.pro_proveedor"
            frm.Ordenamiento = "p.pro_proveedor, p.pro_status"
            frm.TipoOrdenamiento = ""
            frm.Condicion = strRemplazo

            frm.ShowDialog(Me)

            If frm.DialogResult = System.Windows.Forms.DialogResult.OK Then
                celdaProveedor1.Text = frm.LLave
                celdaProveedor.Text = frm.Dato
                celdaNIT.Text = frm.Dato3
                celdaMoneda.Text = frm.ListaClientes.SelectedCells(5).Value
                celdaMoneda1.Text = frm.ListaClientes.SelectedCells(7).Value
                celdaTasa.Text = frm.ListaClientes.SelectedCells(6).Value

                If frm.Dato2 = 0 Then
                    checkContribuyent.Checked = True
                    celdaDetFact.Text = "NO GENERA DERECHO A CREDITO FISCAL"
                    celdaDetFact.BackColor = Color.Red
                    celdaDetFact.TextAlign = HorizontalAlignment.Center
                    If Sesion.IdEmpresa = 12 Or Sesion.IdEmpresa = 10 Or Sesion.IdEmpresa = 9 Or Sesion.IdEmpresa = 3 Then

                        checkFacElectrónica.Checked = False
                    End If

                ElseIf frm.Dato2 = 1 Then
                    checkContribuyent.Checked = False
                    celdaDetFact.Text = "Detalle de Factura"
                    celdaDetFact.BackColor = Color.RoyalBlue
                    celdaDetFact.TextAlign = HorizontalAlignment.Left
                    celdaDetFact.ForeColor = Color.White
                    If Sesion.IdEmpresa = 12 Or Sesion.IdEmpresa = 10 Or Sesion.IdEmpresa = 9 Or Sesion.IdEmpresa = 3 Then
                        checkFacElectrónica.Checked = True

                    End If

                End If
                If frm.Dato4 = 1 Then
                    frm.Dato4 = "SERVICIO"
                Else
                    frm.Dato4 = "BIEN"
                End If

                CodProveedor = frm.LLave

                'Procedimiento que busca el CAI de cada proveedor y lo coloca en la celda correspondiente
                JalarCAI(CodProveedor)
                botonMas.Enabled = True
                ValidarFechaVencimiento()
            End If



        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub
    Public Sub Limpiar()
        celdaTipoOrden.Text = NO_FILA
        celdaNumero.Text = STR_VACIO
        celdaProveedor.Text = STR_VACIO
        celdaProveedor1.Text = NO_FILA
        celdaSerie.Text = STR_VACIO
        celdaNIT.Text = STR_VACIO
        celdaMonto.Text = STR_VACIO
        celdaMoneda.Text = Divisa.Local.simbolo
        celdaMoneda1.Text = Divisa.Local.id
        celdaTasa.Text = INT_UNO
        celdaNotas.Text = STR_VACIO
        celdaRetension.Text = STR_VACIO
        dtpFechaPolizaC.Value = (cFunciones.HoyMySQL).ToString(FORMATO_MYSQL)
        dtpFecha1.Text = (cFunciones.HoyMySQL).ToString(FORMATO_MYSQL)
        dtpFechaVence.Text = (cFunciones.HoyMySQL).ToString(FORMATO_MYSQL)
        celdaFecha1.Text = dtpFecha1.Value
        celdaFechaVence.Text = dtpFechaVence.Value
        celdaAnioOc.Text = NO_FILA
        celdaNumOc.Text = NO_FILA
        checkRevisado.Checked = False
        checkActivoFijo.Checked = False
        checkActive.BackColor = Color.Transparent
        checkActive.Enabled = True
        checkActive.Visible = False
        celdaRevisado.Clear()
        etiquetaMontoTotal.Text = STR_VACIO
        celdaCatOc.Text = INT_CERO
        celdaDetalleDocumento.Text = STR_VACIO
        dgFacturas.Rows.Clear()
        dgImpuestos.Rows.Clear()
        dgPoliza.Rows.Clear()
        dgOrdenes.Rows.Clear()
        rbLocal.Checked = False
        rbImportación.Checked = False
        rbOrdenDeCompra.Checked = False
        celdaMontoProd.Text = INT_CERO
        celdaCAI.Text = INT_UNO

        Extemporaneo = False
        rbLocal.Enabled = True
        rbImportación.Enabled = True
        rbOrdenDeCompra.Enabled = True

        celdaSerieFel.Text = STR_VACIO
        celdaFechaHoraCertificacion.Text = STR_VACIO
        celdaFechaEmisionDocumento.Text = STR_VACIO
        celdaUUID.Text = STR_VACIO
        etiquetaAutorizacion.Text = STR_VACIO
        etiquetaSerieF.Text = STR_VACIO
        botonMas.Enabled = False
        BotonNotas.Enabled = False

        celdaResolucion.Text = ""
        celdaIdResolución.Text = -1
        If Sesion.IdEmpresa = 15 Or Sesion.IdEmpresa = 20 Or Sesion.IdEmpresa = 22 Then
            panelResolucion.Visible = True
            celdaResolucion.Enabled = True
        Else
            panelResolucion.Visible = False
            celdaResolucion.Text = ""
        End If

    End Sub
    Public Sub BloquearFel()
        celdaNumero.Enabled = False
        celdaProveedor.Enabled = False
        celdaProveedor1.Enabled = False
        celdaSerie.Enabled = False
        celdaNIT.Enabled = False
        celdaMonto.Enabled = False
        celdaMoneda.Enabled = False
        celdaMoneda1.Enabled = False
        celdaTasa.Enabled = False
        celdaNotas.Enabled = False
        celdaRetension.Enabled = False
        dtpFecha1.Enabled = False
        dtpFechaVence.Enabled = False
        celdaFecha1.Enabled = False
        celdaFechaVence.Enabled = False
        celdaAnioOc.Enabled = False
        celdaNumOc.Enabled = False
        checkRevisado.Checked = False
        checkActivoFijo.Checked = False
        celdaRevisado.Enabled = False
        etiquetaMontoTotal.Enabled = False
        ''        celdaCatOc.Text = INT_CERO
        dgFacturas.Enabled = False
        dgImpuestos.Enabled = False
        dgPoliza.Enabled = False
        dgOrdenes.Enabled = False
        rbLocal.Enabled = False
        rbImportación.Enabled = False
        rbOrdenDeCompra.Enabled = False
        botonProveedor.Enabled = False

        checkContribuyent.Enabled = False
        checkFacElectrónica.Enabled = False
        CheckFactEspecial.Enabled = False
        botonISR.Enabled = False
        checkRevisado.Enabled = False
        checkActivoFijo.Enabled = False


        rbLocal.Enabled = False
        rbImportación.Enabled = False
        rbOrdenDeCompra.Enabled = False
        botonMoneda.Enabled = False
        botonMenos.Enabled = False
        botonMas.Enabled = False
        botonRelacionar.Enabled = False
        botonDesligar.Enabled = False
        panelBotones.Enabled = False
        Encabezado1.botonGuardar.Enabled = False
        Encabezado1.botonBorrar.Enabled = False
    End Sub
    Public Sub ActivarFel()
        celdaNumero.Enabled = True
        celdaProveedor.Enabled = True
        celdaProveedor1.Enabled = True
        celdaSerie.Enabled = True
        celdaNIT.Enabled = True
        celdaMonto.Enabled = True
        celdaMoneda.Enabled = True
        celdaMoneda1.Enabled = True
        celdaTasa.Enabled = True
        celdaNotas.Enabled = True
        celdaRetension.Enabled = True
        dtpFecha1.Enabled = True
        dtpFechaVence.Enabled = True
        celdaFecha1.Enabled = True
        celdaFechaVence.Enabled = True
        celdaAnioOc.Enabled = True
        celdaNumOc.Enabled = True
        checkRevisado.Checked = True
        celdaRevisado.Enabled = True
        etiquetaMontoTotal.Enabled = True
        dgFacturas.Enabled = True
        dgImpuestos.Enabled = True
        dgPoliza.Enabled = True
        dgOrdenes.Enabled = True
        rbLocal.Enabled = True
        rbImportación.Enabled = True
        rbOrdenDeCompra.Enabled = True
        botonMoneda.Enabled = True
        botonProveedor.Enabled = True

        checkContribuyent.Enabled = True
        checkFacElectrónica.Enabled = True
        CheckFactEspecial.Enabled = True
        botonISR.Enabled = True
        checkRevisado.Enabled = True
        checkActivoFijo.Enabled = True

        rbLocal.Enabled = True
        rbImportación.Enabled = True
        rbOrdenDeCompra.Enabled = True
        botonProveedor.Enabled = True
        botonMenos.Enabled = True

        botonRelacionar.Enabled = True
        botonDesligar.Enabled = True
        panelBotones.Enabled = True
        Encabezado1.botonGuardar.Enabled = True
        Encabezado1.botonBorrar.Enabled = True

    End Sub
    Private Function SQLDetalleOrden(ByVal intAnio As Integer, ByVal intNumero As Integer, ByVal intLinea As Integer) As String
        Dim strSQL As String = STR_VACIO
        strSQL = " SELECT l1.empresa empresa,l1.tipo tipo,l1.anio anio,l1.numero numero,l1.linea linea,l1.descripcion descripcion,l1.precio precio,ROUND(l1.cantidad - l1.Saldo,2) cantidad, l1.costCenter costCenter,l1.CodProducto CodProducto, l1.costNombre costNombre,l1.fecha fecha "
        strSQL &= " FROM ( "
        strSQL &= "    SELECT d.DDoc_Sis_Emp empresa, d.DDoc_Doc_Cat tipo, d.DDoc_Doc_Ano anio, d.DDoc_Doc_Num numero, d.DDoc_Doc_Lin linea, d.DDoc_Prd_Des descripcion, d.DDoc_Prd_NET precio, d.DDoc_Prd_QTY cantidad, d.DDoc_RF1_Num costCenter, d.DDoc_Prd_Cod CodProducto, c.cost_nombre costNombre,h.HDoc_Doc_Fec Fecha"
        strSQL &= "     ,IFNULL(( "
        strSQL &= "         SELECT SUM(p.PDoc_QTY_Ord) "
        strSQL &= "             FROM Dcmtos_DTL_Pro p "
        strSQL &= "                 WHERE p.PDoc_Sis_Emp = d.DDoc_Sis_Emp AND p.PDoc_Par_Cat = d.DDoc_Doc_Cat AND p.PDoc_Par_Ano = d.DDoc_Doc_Ano AND p.PDoc_Par_Num = d.DDoc_Doc_Num AND p.PDoc_Par_Lin = d.DDoc_Doc_Lin AND p.PDoc_Chi_Cat = {catalogo}),0) Saldo "
        strSQL &= "      FROM Dcmtos_DTL d"
        strSQL &= "           LEFT JOIN {conta}.costos c ON c.cost_num = d.DDoc_RF1_Num"
        strSQL &= "         LEFT JOIN Dcmtos_HDR h ON h.HDoc_Sis_Emp = d.DDoc_Sis_Emp AND h.HDoc_Doc_Cat = d.DDoc_Doc_Cat AND h.HDoc_Doc_Ano = d.DDoc_Doc_Ano AND h.HDoc_Doc_Num = d.DDoc_Doc_Num "
        strSQL &= "      WHERE d.DDoc_Sis_Emp ={empresa} AND d.DDoc_Doc_Cat = 777 AND d.DDoc_Doc_Ano = {anio} AND d.DDoc_Doc_Num = {numero} AND d.DDoc_Doc_Lin = {linea})l1 HAVING(cantidad > 0) "

        strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
        strSQL = Replace(strSQL, "{anio}", intAnio)
        strSQL = Replace(strSQL, "{numero}", intNumero)
        strSQL = Replace(strSQL, "{linea}", intLinea)
        strSQL = Replace(strSQL, "{conta}", cfun.ContaEmpresa)
        strSQL = Replace(strSQL, "{catalogo}", celdaCatOc.Text)

        Return strSQL
    End Function
    Public Sub CargarDetalleOrden(ByVal intAnio As Integer, ByVal intNumero As Integer, ByVal intLinea As Integer)
        Dim strSQL As String = STR_VACIO
        Dim strFila As String = STR_VACIO
        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader
        Dim i As Integer = INT_CERO
        Dim logVerificar As Boolean = True
        Try
            strSQL = SQLDetalleOrden(intAnio, intNumero, intLinea)
            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSQL, CON)
            REA = COM.ExecuteReader
            If REA.HasRows Then
                Do While REA.Read
                    strFila = REA.GetInt32("tipo") & "|"
                    strFila &= REA.GetInt32("anio") & "|"
                    strFila &= REA.GetInt32("numero") & "|"
                    strFila &= INT_CERO & "|"
                    strFila &= REA.GetInt32("linea") & "|"
                    strFila &= REA.GetInt32("cantidad") & "|"
                    strFila &= REA.GetString("descripcion") & "|"
                    strFila &= REA.GetDouble("precio") & "|"
                    strFila &= REA.GetDouble("precio") & "|"
                    strFila &= (REA.GetInt32("cantidad") * REA.GetDouble("precio")).ToString(FORMATO_MONEDA) & "|"
                    strFila &= 0 & "|"
                    strFila &= 0 & "|"
                    strFila &= 0 & "|"
                    strFila &= STR_VACIO & "|"
                    strFila &= STR_VACIO & "|"
                    strFila &= STR_VACIO & "|"
                    strFila &= REA.GetInt32("costCenter") & "|"
                    strFila &= REA.GetString("costNombre") & "|"
                    strFila &= "BIEN" & "|"
                    strFila &= INT_CERO & "|"
                    strFila &= INT_CERO & "|"
                    strFila &= REA.GetInt32("CodProducto")
                    cFunciones.AgregarFila(dgFacturas, strFila)
                    ' Agrega al DataGrid de Ordenes
                    strFila = REA.GetInt32("tipo") & "|"
                    strFila &= REA.GetInt32("anio") & "|"
                    strFila &= REA.GetInt32("numero") & "|"
                    strFila &= REA.GetDateTime("fecha").ToString(FORMATO_MYSQL) & "|"
                    strFila &= REA.GetInt32("linea") & "|"
                    strFila &= STR_VACIO
                    cFunciones.AgregarFila(dgOrdenes, strFila)
                    For i = INT_CERO To dgFacturas.Rows.Count - 1
                        dgFacturas.Rows(i).Cells("colLineaFactura").Value = i + 1
                    Next
                Loop
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub
    Private Sub AgregarDetalleOrden(ByVal intAnio As Integer, ByVal intNumero As Integer)
        Dim strSQL As String = STR_VACIO
        Dim strFila As String = STR_VACIO
        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader
        Dim i As Integer = INT_CERO

        strSQL = QueryDetalleOrden(intAnio, intNumero)

        Try
            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSQL, CON)
            REA = COM.ExecuteReader

            If REA.HasRows Then
                Do While REA.Read

                    'strFila = REA.GetInt32("tipo") & "|"
                    'strFila &= REA.GetInt32("anio") & "|"
                    'strFila &= REA.GetInt32("numero") & "|"
                    'strFila &= REA.GetInt32("linea") & "|"
                    'strFila &= 0 & "|"
                    'strFila &= REA.GetInt32("cantidad") & "|"
                    'strFila &= REA.GetString("descripcion") & "|"
                    'strFila &= REA.GetDouble("precio").ToString(FORMATO_MONEDA) & "|"
                    'strFila &= REA.GetDouble("precio").ToString(FORMATO_MONEDA) & "|"
                    'strFila &= (REA.GetInt32("cantidad") * REA.GetDouble("precio")).ToString(FORMATO_MONEDA) & "|"
                    'strFila &= REA.GetInt32("CodProducto") & "|"
                    'strFila &= 0 & "|"
                    'strFila &= 0 & "|"
                    'strFila &= 0 & "|"
                    'strFila &= 0 & "|"
                    'strFila &= 0 & "|"
                    'strFila &= REA.GetInt32("costCenter") & "|"
                    'strFila &= REA.GetString("costNombre") & "|"
                    'strFila &= "BIEN" & "|"
                    'strFila &= INT_CERO & "|"
                    'strFila &= INT_CERO
                    'cFunciones.AgregarFila(dgFacturas, strFila)
                    strFila = REA.GetInt32("tipo") & "|"
                    strFila &= REA.GetInt32("anio") & "|"
                    strFila &= REA.GetInt32("numero") & "|"
                    strFila &= INT_CERO & "|"
                    strFila &= REA.GetInt32("linea") & "|"
                    strFila &= REA.GetInt32("cantidad") & "|"
                    strFila &= REA.GetString("descripcion") & "|"
                    strFila &= REA.GetDouble("precio") & "|"
                    strFila &= REA.GetDouble("precio") & "|"
                    strFila &= (REA.GetInt32("cantidad") * REA.GetDouble("precio")).ToString(FORMATO_MONEDA) & "|"
                    strFila &= 0 & "|"
                    strFila &= 0 & "|"
                    strFila &= 0 & "|"
                    strFila &= STR_VACIO & "|"
                    strFila &= STR_VACIO & "|"
                    strFila &= STR_VACIO & "|"
                    strFila &= REA.GetInt32("costCenter") & "|"
                    strFila &= REA.GetString("costNombre") & "|"
                    strFila &= "BIEN" & "|"
                    strFila &= INT_CERO & "|"
                    strFila &= INT_CERO & "|"
                    strFila &= REA.GetInt32("CodProducto")
                    cFunciones.AgregarFila(dgFacturas, strFila)


                    ' AGREGAR FILA LOTE - NT DDOC_RF4_COD
                    If Sesion.IdEmpresa = 22 AndAlso rbOrdenDeCompra.Checked = True Then
                        Dim lastRowIndex As Integer = dgFacturas.Rows.Count - 1
                        If lastRowIndex >= 0 Then
                            dgFacturas.Rows(lastRowIndex).Cells("loteNum").Value = "" ' Cambia "Nuevo valor" por lo que necesites
                        End If
                    End If

                    ' Agrega al DataGrid de Ordenes
                    strFila = REA.GetInt32("tipo") & "|"
                    strFila &= REA.GetInt32("anio") & "|"
                    strFila &= REA.GetInt32("numero") & "|"
                    strFila &= REA.GetDateTime("fecha").ToString(FORMATO_MYSQL) & "|"
                    strFila &= REA.GetInt32("linea") & "|"
                    strFila &= STR_VACIO
                    cFunciones.AgregarFila(dgOrdenes, strFila)
                Loop
            End If
            dgFacturas.Columns("colCodigo").Visible = False
            dgFacturas.Columns("colCuentaActivo").Visible = False
            dgFacturas.Columns("colActivo").Visible = False
            dgFacturas.Columns("colCuenta").Visible = False
            dgFacturas.Columns("colCosto").Visible = False

            For i = INT_CERO To dgFacturas.Rows.Count - 1
                dgFacturas.Rows(i).Cells("colLineaFactura").Value = i + 1
            Next

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub
    Private Sub AgregaAlDetalle(ByVal cat As Integer, ByVal anio As Integer, ByVal num As Integer, ByVal linea As Integer)
        'Dim frm As New frmImportaciones
        Dim strSQL As String = STR_VACIO
        Dim strSQL2 As String = STR_VACIO
        Dim COM As MySqlCommand
        Dim COM2 As MySqlCommand
        Dim REA As MySqlDataReader
        Dim REA2 As MySqlDataReader
        Dim strfila As String = STR_VACIO
        Dim i As Integer

        strSQL = SQLRelacion(cat, anio, num, linea)

        Try
            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSQL, CON)
            REA = COM.ExecuteReader
            strfila = STR_VACIO
            Dim total As Double

            If REA.HasRows Then

                Do While REA.Read

                    PrecioNet = REA.GetDouble("Precio")

                    'For i = 0 To dgFacturas.Rows.Count - 1
                    'If dgFacturas.Rows(i).Cells("colCantidad").Value = 0 Then
                    '    dgFacturas.Rows(i).Cells("colCantidad").Value = REA.GetDouble("Cantidad")
                    '    dgFacturas.Rows(i).Cells("colDescripcion").Value = REA.GetString("Descripcion")
                    '    dgFacturas.Rows(i).Cells("colPrecio").Value = REA.GetDouble("Precio")
                    '    total = REA.GetDouble("Cantidad") * REA.GetDouble("Precio")
                    '    dgFacturas.Rows(i).Cells("colTotal").Value = total
                    '    dgFacturas.Rows(i).Cells("colCodigo").Value = vbEmpty
                    '    dgFacturas.Rows(i).Cells("colCuentaActivo").Value = vbEmpty
                    '    dgFacturas.Rows(i).Cells("colActivo").Value = vbEmpty
                    '    dgFacturas.Rows(i).Cells("colCuentaGasto").Value = vbNullString
                    '    dgFacturas.Rows(i).Cells("colGasto").Value = vbNullString
                    '    dgFacturas.Rows(i).Cells("colCosto").Value = vbNullString
                    '    dgFacturas.Rows(i).Cells("colCentro").Value = vbNullString
                    '    dgFacturas.Rows(i).Cells("colClasificacion").Value = "BIEN"
                    'Else
                    strfila = 180 & "|"
                    strfila &= REA.GetDouble("Anio") & "|"
                    strfila &= REA.GetInt32("Numero") & "|"
                    strfila &= i + 1 & "|"
                    strfila &= REA.GetDouble("Linea") & "|"
                    strfila &= REA.GetDouble("Cantidad") & "|"
                    strfila &= REA.GetString("Descripcion") & "|"
                    strfila &= vbEmpty & "|"
                    strfila &= REA.GetDouble("Precio") & "|"
                    total = (REA.GetDouble("Cantidad") * REA.GetDouble("Precio")).ToString(FORMATO_MONEDA)
                    strfila &= total & "|"
                    strfila &= vbEmpty & "|"
                    strfila &= vbEmpty & "|"
                    strfila &= vbEmpty & "|"
                    strfila &= vbNullString & "|"
                    strfila &= vbNullString & "|"
                    strfila &= vbNullString & "|"
                    strfila &= vbNullString & "|"
                    strfila &= vbNullString & "|"
                    strfila &= "BIEN" & "|"
                    strfila &= INT_CERO & "|"
                    strfila &= INT_CERO

                    cFunciones.AgregarFila(dgFacturas, strfila)

                    'End If
                    ' Next


                Loop


            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try

    End Sub

    Private Sub RefreshTotal()
        Dim i As Integer
        Dim sumaT As Double
        Dim SumaEnQ As Double

        For i = 0 To dgFacturas.Rows.Count - 1
            sumaT = sumaT + dgFacturas.Rows(i).Cells("colTotal").Value
        Next

        celdaMonto.Text = sumaT.ToString(FORMATO_MONEDA)

        SumaEnQ = (celdaMonto.Text * celdaTasa.Text).ToString(FORMATO_MONEDA)

        etiquetaMontoTotal.Text = Math.Round(SumaEnQ, 2)

    End Sub

    Private Sub CalcuarImpuesto()
        Dim base As Double
        Dim cantidad As Double
        Dim factor As Double
        Dim i As Integer
        Dim sumaFila As Integer = 0
        Dim suma As Double
        Dim strSQL1 As String = STR_VACIO
        Dim COM1 As MySqlCommand
        Dim REA1 As MySqlDataReader
        Dim conec As MySqlConnection
        Dim dblImp As Double = 0

        If celdaCatOc.Text.Length > 0 Then
            If celdaCatOc.Text = 44 Then
                If dgFacturas.Rows.Count > 0 Then
                    For i = 0 To dgFacturas.Rows.Count - 1
                        If Not dgFacturas.Rows(i).Cells("colAgregar").Value = 2 Then
                            suma = suma + dgFacturas.Rows(i).Cells("colTotal").Value
                        End If
                    Next
                    If Sesion.idGiro = 2 Then
                        base = celdaMontoProd.Text * celdaTasa.Text
                    Else
                        base = suma * celdaTasa.Text
                    End If
                Else
                    base = 0
                End If
                If rbImportación.Checked = True Or checkContribuyent.Checked = True Or Extemporaneo = True Then
                    factor = 1
                Else
                    strSQL1 = PorcentajeIVA()
                    conec = New MySqlConnection(strConexion)
                    conec.Open()
                    COM1 = New MySqlCommand(strSQL1, conec)
                    Using conec
                        REA1 = COM1.ExecuteReader
                        If REA1.HasRows Then
                            REA1.Read()
                            factor = REA1.GetDouble("IVA")
                            factor = (factor / 100) + 1
                            conec.Close()
                            conec.Dispose()
                            conec = Nothing
                            System.GC.Collect()
                        End If
                    End Using

                End If
                For i = 0 To dgImpuestos.Rows.Count - 1
                    sumaFila = sumaFila + 1
                Next

                If sumaFila >= 1 Then

                    For i = 0 To dgImpuestos.Rows.Count - 1
                        If dgImpuestos.Rows(i).Cells(4).Value = "IVA" Then
                            If rbImportación.Checked = True Or checkContribuyent.Checked = True Or Extemporaneo = True Then
                                dgImpuestos.Rows(i).Cells(7).Value = (base)
                                dgImpuestos.Rows(i).Cells(8).Value = INT_CERO.ToString(FORMATO_MONEDA)
                            Else
                                base = base - dblImp
                                cantidad = Math.Round(base / factor, 2)
                                dgImpuestos.Rows(i).Cells(7).Value = cantidad
                                dgImpuestos.Rows(i).Cells(8).Value = (base) - (cantidad)
                            End If
                            Exit For
                        Else
                            dblImp = dgImpuestos.Rows(i).Cells(8).Value
                        End If
                    Next
                End If
            End If
        End If




    End Sub

    Private Sub botonRelacionar_Click(sender As Object, e As EventArgs) Handles botonRelacionar.Click

        Dim frm As New frmSeleccionar
        Dim frmLinea As New frmSeleccionar
        Dim strSQL As String = STR_VACIO
        Dim COM As MySqlCommand
        Dim COM2 As MySqlCommand
        Dim REA As MySqlDataReader
        Dim REA2 As MySqlDataReader
        Dim strfila As String = STR_VACIO
        Dim ref As String
        Dim strReplace As String
        Dim CodEmpresa As String = STR_VACIO
        Dim logEx As Boolean
        Dim strRef As String = STR_VACIO
        Dim intRes As Integer = INT_CERO
        Dim strLista As String = STR_VACIO
        Dim Condicion As String = STR_VACIO
        Dim LogVerificar As Boolean
        Dim i As Integer = INT_CERO
        Dim SumaFila As Double
        Dim intNumP As Integer
        Dim intAnioP As Integer
        Dim intCat As Integer
        Dim strDocP As String
        strRef = celdaNumero.Text
        Dim Condicion2 As String = STR_VACIO

        If rbImportación.Checked = False And rbOrdenDeCompra.Checked = False Then
            MsgBox("You must select some type purchase to be able to generate this process", vbInformation)
        Else
            If rbImportación.Checked = True Then
                If celdaNumero.Text = STR_VACIO Or celdaNumero.Text = "0" Then
                    MsgBox("You have not entered an invoice number", vbExclamation, "Aviso")
                    Exit Sub
                End If
                'Busca Referencia Actual
                logEx = BuscarReferencia(strRef, intRes)

                If logEx = False Then
                    'Jala los datos de las Importacion
                    strSQL = SqlBuscarReferencia(strRef, intRes)

                    MyCnn.CONECTAR = strConexion
                    COM = New MySqlCommand(strSQL, CON)
                    REA = COM.ExecuteReader

                    If REA.HasRows Then
                        Do While REA.Read
                            intNumP = REA.GetInt64("Numero")
                            intAnioP = REA.GetInt64("Anio")
                            strDocP = REA.GetString("Documento")
                        Loop
                    End If
                    strSQL = STR_VACIO
                    ' Muestra las lineas de la póliza
                    SQLRefEnImportacion(intAnioP, intNumP, strDocP)
                    'Cargar los datos del Proveedor
                    If celdaProveedor1.Text = NO_FILA And dgPoliza.Rows.Count > vbEmpty Then
                        CargarEncabezadoDesde(dgPoliza.CurrentRow.Cells(0).Value, dgPoliza.CurrentRow.Cells(1).Value, dgPoliza.CurrentRow.Cells(2).Value)
                    ElseIf celdaProveedor1.Text = vbEmpty And dgOrdenes.Rows.Count > vbEmpty Then
                        CargarEncabezadoDesde(dgOrdenes.CurrentRow.Cells(0).Value, dgOrdenes.CurrentRow.Cells(1).Value, dgOrdenes.CurrentRow.Cells(2).Value)
                    End If
                Else
                    ValidarFechaVencimiento()
                End If


                'Se jalan datos de Orden de compra 
            ElseIf rbOrdenDeCompra.Checked = True Then
                'Comprueba que este seleccionado un proveedor para poder jalar los datos de la orden en base al proveedor
                CodEmpresa = celdaProveedor1.Text

                Try
                    If rbOrdenDeCompra.Checked = True Then
                        Condicion = "h.HDoc_Sis_Emp = {empresa} AND h.HDoc_Doc_Cat = 777 AND h.HDoc_Doc_Status = 1  AND h.HDoc_Emp_Cod = {codEmpresa}  AND d.DDoc_RF3_Num=0" &
                                    "   GROUP BY h.HDoc_Sis_Emp, h.HDoc_Doc_Cat, h.HDoc_Doc_Ano, h.HDoc_Doc_Num )l1 )l2 HAVING(Saldo > 0) "
                        Condicion = Replace(Condicion, "{empresa}", Sesion.IdEmpresa)
                        Condicion = Replace(Condicion, "{codEmpresa}", celdaProveedor1.Text)
                        Condicion = Replace(Condicion, "{catalogo}", celdaCatOc.Text)

                        frm.Titulo = "Select an Order"
                        frm.Campos = " l2.empresa empresa, l2.tipo tipo , l2.anio anio , l2.numero numero, l2.fecha fecha, l2.referencia referencia, l2.Nombre Nombre, l2.codempresa codempresa, l2.Saldo Saldo,l2.TipoOrden TipoOrden, l2.idresolucion idResolucion, l2.resolucion resolucion"

                        Dim SQLTABLAS As String = "   
                            (SELECT l1.empresa empresa,l1.tipo tipo, l1.anio anio,l1.numero numero, l1.fecha fecha,l1.referencia referencia,l1.Nombre Nombre,l1.codempresa codempresa, round(l1.Saldo,2) Saldo, l1.TOrden TipoOrden, ifnull(l1.idresolucion,-1) idResolucion , IFNULL(resolucion,'') Resolucion 
                            FROM ( 
                                SELECT h.HDoc_Sis_Emp empresa, h.HDoc_Doc_Cat tipo, h.HDoc_Doc_Ano anio, h.HDoc_Doc_Num numero, h.HDoc_Doc_Fec fecha, {referenciaNo} referencia, h.HDoc_Emp_Nom Nombre, h.HDoc_Emp_Cod codempresa, 
                                    SUM(d.DDoc_Prd_QTY) - SUM(IFNULL(( 
                                        Select SUM(p.PDoc_QTY_Ord)
                                        From Dcmtos_DTL_Pro p
                                        Where p.PDoc_Sis_Emp = d.DDoc_Sis_Emp And p.PDoc_Par_Cat = d.DDoc_Doc_Cat And p.PDoc_Par_Ano = d.DDoc_Doc_Ano And p.PDoc_Par_Num = d.DDoc_Doc_Num And p.PDoc_Par_Lin = d.DDoc_Doc_Lin And p.PDoc_Chi_Cat = " & celdaCatOc.Text & " ),0)) Saldo,
                                h.HDoc_Ant_Com TOrden, h.HDoc_DR2_Cat idresolucion, IFNULL(s.cat_sist,'') resolucion 
                                From Dcmtos_HDR h 
                                Left JOIN Dcmtos_DTL d ON d.DDoc_Sis_Emp = h.HDoc_Sis_Emp AND d.DDoc_Doc_Cat = h.HDoc_Doc_Cat AND d.DDoc_Doc_Ano = h.HDoc_Doc_Ano AND d.DDoc_Doc_Num = h.HDoc_Doc_Num 
                                LEFT JOIN Catalogos s ON s.cat_num = h.HDoc_DR2_Cat "

                        If Sesion.idGiro = 2 Then
                            SQLTABLAS = Replace(SQLTABLAS, "{referenciaNo}", "h.HDoc_DR1_Dbl")
                        Else
                            SQLTABLAS = Replace(SQLTABLAS, "{referenciaNo}", "h.HDoc_DR1_Num")
                        End If
                        frm.Tabla = SQLTABLAS

                        frm.FiltroText = "Enter Number"
                        frm.Filtro = "h.HDoc_Doc_Num"
                        frm.Condicion = Condicion
                        '   frm.Ordenamiento = "h.HDoc_Sis_Emp, h.HDoc_Doc_Cat, h.HDoc_Doc_Ano, h.HDoc_Doc_Num"
                        frm.Multiple = True
                        frm.ShowDialog(Me)

                        If frm.DialogResult = System.Windows.Forms.DialogResult.OK Then
                            For i = 0 To frm.DataGrid.Rows.Count - 1
                                If frm.ListaClientes.Rows(i).Cells("colCheck").Value = True Then
                                    LogVerificar = True
                                    If dgOrdenes.Rows.Count > 0 Then
                                        For k As Integer = 0 To dgOrdenes.Rows.Count - 1
                                            If frm.DataGrid.Rows(i).Cells(2).Value = dgOrdenes.Rows(k).Cells("colCatalogo").Value And frm.DataGrid.Rows(i).Cells(3).Value = dgOrdenes.Rows(k).Cells("colAñio").Value And frm.DataGrid.Rows(i).Cells(4).Value = dgOrdenes.Rows(k).Cells("colNumero").Value Then
                                                MsgBox("This order number has already been added", vbInformation)
                                                LogVerificar = False
                                            End If
                                        Next
                                        intCat = frm.DataGrid.Rows(i).Cells(2).Value
                                        intAnioP = frm.DataGrid.Rows(i).Cells(3).Value
                                        intNumP = frm.DataGrid.Rows(i).Cells(4).Value
                                        celdaTipoOrden.Text = frm.DataGrid.Rows(i).Cells(10).Value
                                        celdaIdResolución.Text = frm.DataGrid.Rows(i).Cells(11).Value
                                        celdaResolucion.Text = frm.DataGrid.Rows(i).Cells(12).Value
                                        celdaResolucion.Enabled = False
                                        botonResolción.Enabled = False
                                    Else
                                        intCat = frm.DataGrid.Rows(i).Cells(2).Value
                                        intAnioP = frm.DataGrid.Rows(i).Cells(3).Value
                                        intNumP = frm.DataGrid.Rows(i).Cells(4).Value
                                        celdaTipoOrden.Text = frm.DataGrid.Rows(i).Cells(10).Value
                                        celdaIdResolución.Text = frm.DataGrid.Rows(i).Cells(11).Value
                                        celdaResolucion.Text = frm.DataGrid.Rows(i).Cells(12).Value
                                        celdaResolucion.Enabled = False
                                        botonResolción.Enabled = True
                                    End If

                                    If LogVerificar = True Then
                                        If MsgBox("Purchase order" & vbCr & "Year: " & vbTab & frm.DataGrid.Rows(i).Cells(3).Value & vbCr & vbCr & "Number: " & vbTab & frm.DataGrid.Rows(i).Cells(4).Value & vbCr & " download all?", vbQuestion + vbYesNo + vbDefaultButton2, "Purchase Orders") = vbYes Then
                                            'Agrega al Datagrid de Detalle
                                            AgregarDetalleOrden(frm.ListaClientes.Rows(i).Cells(3).Value, frm.ListaClientes.Rows(i).Cells(4).Value)
                                        Else
                                            Condicion2 = "  d.DDoc_Sis_Emp = {empresa} AND d.DDoc_Doc_Cat = {cat} AND d.DDoc_Doc_Ano = {anio} AND d.DDoc_Doc_Num = {num}  AND d.DDoc_RF3_Num=0 )l1 )l2" &
                                                        "       HAVING(cantidad > 0)  "
                                            Condicion2 = Replace(Condicion2, "{empresa}", Sesion.IdEmpresa)
                                            Condicion2 = Replace(Condicion2, "{cat}", intCat)
                                            Condicion2 = Replace(Condicion2, "{anio}", intAnioP)
                                            Condicion2 = Replace(Condicion2, "{num}", intNumP)
                                            frmLinea.Titulo = "Select an Line order"
                                            frmLinea.Campos = " l2.empresa empresa, l2.tipo tipo , l2.anio anio, l2.numero numero , l2.linea linea , l2.descripcion descripcion, l2.precio precio, l2.Saldo cantidad ," &
                                                                                    " l2.costCenter costCenter, l2.CodProducto CodProducto " &
                                                                                    "    "
                                            frmLinea.Tabla = "  ( SELECT l1.empresa empresa,l1.tipo tipo,l1.anio anio,l1.numero numero,l1.linea linea,l1.descripcion descripcion,l1.precio precio,l1.cantidad cantidad, " &
                                                                                 "  l1.costCenter costCenter,l1.CodProducto CodProducto , ROUND(l1.cantidad - l1.Saldo,2) Saldo  " &
                                                                                " From ( SELECT d.DDoc_Sis_Emp empresa, d.DDoc_Doc_Cat tipo, d.DDoc_Doc_Ano anio, d.DDoc_Doc_Num numero, d.DDoc_Doc_Lin linea, d.DDoc_Prd_Des descripcion, " &
                                                                                 "      d.DDoc_Prd_NET precio, d.DDoc_Prd_QTY cantidad, d.DDoc_RF1_Num costCenter, d.DDoc_Prd_Cod CodProducto, c.cost_nombre costNombre, IFNULL(( " &
                                                                                 "          SELECT sum(p.PDoc_QTY_Ord) " &
                                                                                 "              FROM Dcmtos_DTL_Pro p " &
                                                                                 "                  WHERE p.PDoc_Sis_Emp = d.DDoc_Sis_Emp AND p.PDoc_Par_Cat = d.DDoc_Doc_Cat AND p.PDoc_Par_Ano = d.DDoc_Doc_Ano AND p.PDoc_Par_Num = d.DDoc_Doc_Num AND p.PDoc_Par_Lin = d.DDoc_Doc_Lin AND p.PDoc_Chi_Cat = " & celdaCatOc.Text & " and d.DDoc_RF3_Num=0  group by d.DDoc_Sis_Emp, d.DDoc_Doc_Cat, d.DDoc_Doc_Ano, d.DDoc_Doc_Num),0) Saldo " &
                                                                                 "              FROM Dcmtos_DTL d " &
                                                                                 "          LEFT JOIN " & cfun.ContaEmpresa & ".costos c ON c.cost_num = d.DDoc_RF1_Num "
                                            frmLinea.FiltroText = "Enter Number"
                                            frmLinea.Filtro = "d.DDoc_Doc_Num"
                                            frmLinea.Condicion = Condicion2
                                            frmLinea.Multiple = True
                                            frmLinea.ShowDialog(Me)
                                            If frmLinea.DialogResult = System.Windows.Forms.DialogResult.OK Then
                                                For j As Integer = 0 To frmLinea.DataGrid.Rows.Count - 1
                                                    If frmLinea.ListaClientes.Rows(j).Cells("colCheck").Value = True Then
                                                        CargarDetalleOrden(frmLinea.DataGrid.Rows(j).Cells(3).Value, frmLinea.DataGrid.Rows(j).Cells(4).Value, frmLinea.DataGrid.Rows(j).Cells(5).Value)
                                                    End If
                                                Next
                                            End If

                                        End If
                                    End If
                                End If
                            Next
                        End If

                        i = INT_CERO
                        'Coloca numero a las ordenes seleccionadas
                        For i = INT_CERO To dgOrdenes.Rows.Count - 1
                            dgOrdenes.Rows(i).Cells("colLineOrden").Value = i + 1
                        Next
                    End If
                Catch ex As Exception
                    MsgBox(ex.ToString)
                End Try
                'Cargar los datos del Proveedor
                If celdaProveedor1.Text = vbEmpty And dgPoliza.Rows.Count > vbEmpty Then
                    CargarEncabezadoDesde(dgPoliza.CurrentRow.Cells(0).Value, dgPoliza.CurrentRow.Cells(1).Value, dgPoliza.CurrentRow.Cells(2).Value)
                ElseIf celdaProveedor1.Text = vbEmpty And dgOrdenes.Rows.Count > vbEmpty Then
                    CargarEncabezadoDesde(dgOrdenes.CurrentRow.Cells(0).Value, dgOrdenes.CurrentRow.Cells(1).Value, dgOrdenes.CurrentRow.Cells(2).Value)
                End If
                'Total 
                ActualizarTotal()
                'CalcuarImpuesto()

                ' Actualiza el total
                CalcuarImpuesto()

                For i = 0 To dgImpuestos.Rows.Count - 1
                    SumaFila = SumaFila + 1
                Next

                If SumaFila > 1 Then

                    For i = 0 To dgImpuestos.Rows.Count - 1
                        If dgImpuestos.Rows(i).Cells(4).Value = "IVA" Then
                            dgImpuestos.Rows(i).Cells(7).Value = etiquetaMontoTotal.Text
                            Exit For
                        End If
                    Next
                End If
            End If
            'Total 
            ActualizarTotal()
            CalcuarImpuesto()

            If Sesion.IdEmpresa = 15 Or Sesion.IdEmpresa = 20 Or Sesion.IdEmpresa = 22 Then
                panelResolucion.Visible = True
                celdaResolucion.Enabled = True
            Else
                panelResolucion.Visible = False
                celdaResolucion.Text = ""
            End If

        End If
    End Sub

    Public Function strLimpiarLista(ByVal texto As String, ByVal separador As String) As String
        Dim lista() As String
        Dim strTemporal As String
        Dim i As Integer

        If InStr(1, texto, separador) Then
            strTemporal = vbNullString
            lista = Split(texto, separador)

            For i = vbEmpty To UBound(lista)

                lista(i) = Trim(lista(i))
                If Not (lista(i) = vbNullString) Then
                    strTemporal = strTemporal & IIf(strTemporal = vbNullString, vbNullString, separador) & lista(i)
                End If
            Next
        Else
            strTemporal = texto

        End If

        strLimpiarLista = strTemporal

    End Function

    Private Sub botonPolizaContable_Click(sender As Object, e As EventArgs) Handles botonPolizaContable.Click
        Dim cls As New clsPolizaContable

        cls.Tipo = celdaCatOc.Text
        cls.Ciclo = celdaAnioOc.Text
        cls.Numero = celdaNumOc.Text
        cls.Modo = 8

        cls.MostrarPolizaContable()
    End Sub

    Private Sub botonProrrateo_Click(sender As Object, e As EventArgs) Handles botonProrrateo.Click

        MostrarLista(4)
        QueryProrrateo()

    End Sub

    Private Sub dgProrrateo_DoubleClick(sender As Object, e As EventArgs) Handles dgProrrateo.DoubleClick
        If dgProrrateo.CurrentRow.Cells("colCheckP").Value = vbNullString Then
            dgProrrateo.CurrentRow.Cells("colCheckP").Value = "SI"
        Else
            dgProrrateo.CurrentRow.Cells("colCheckP").Value = vbNullString
        End If
    End Sub

    Private Sub botonSeleccionar_Click(sender As Object, e As EventArgs) Handles botonSeleccionar.Click
        Dim Seleccion As Integer = 0
        Dim i As Integer
        Dim dato As String = STR_VACIO
        Dim CodigoCCosto As Integer
        Dim DescCCosto As String
        Dim strfila As String = STR_VACIO
        Dim sumaFact As Double
        Dim sumaFactTotal As Double
        Dim sumLinea As Integer = 0

        For j As Integer = 0 To Me.dgProrrateo.Rows.Count - 1

            If Me.dgProrrateo.Rows(j).Cells("colCheckP").Value = "SI" Then

                'Cuenta cuantos Centros de costos han sido seleccionados
                Seleccion = Seleccion + 1
            End If

        Next


        msj = MsgBox("¿You are sure to Prorate the Document?", vbYesNo, "Advertencia")
        If msj = vbYes Then

            'Variables que guardan datos de linea seleccionada del dg
            Dim pCatalogo As Integer = dgFacturas.CurrentRow.Cells(0).Value
            Dim pAnio As Integer = dgFacturas.CurrentRow.Cells(1).Value
            Dim pNumero As Integer = dgFacturas.CurrentRow.Cells(2).Value
            Dim pLineaFactura As Integer = dgFacturas.CurrentRow.Cells(3).Value
            Dim pLineaOrden As Integer = dgFacturas.CurrentRow.Cells(4).Value
            Dim pCantidad As Double = dgFacturas.CurrentRow.Cells(5).Value
            Dim pDescripcion As String = dgFacturas.CurrentRow.Cells(6).Value
            Dim pPrecioSinIVA As Double = dgFacturas.CurrentRow.Cells(7).Value
            Dim pPrecio As Double = dgFacturas.CurrentRow.Cells(8).Value
            Dim pTotal As Double = dgFacturas.CurrentRow.Cells(9).Value
            Dim pCodigo As String = dgFacturas.CurrentRow.Cells(10).Value
            Dim pCuentaAct As String = dgFacturas.CurrentRow.Cells(11).Value
            Dim pActFijo As String = dgFacturas.CurrentRow.Cells(12).Value
            Dim pCtaIVA As String = dgFacturas.CurrentRow.Cells(13).Value
            Dim pNomenclatura As String = dgFacturas.CurrentRow.Cells(14).Value
            Dim pGasto As String = dgFacturas.CurrentRow.Cells(15).Value
            Dim pIdCosto As String = dgFacturas.CurrentRow.Cells(16).Value
            Dim pCCosto As String = dgFacturas.CurrentRow.Cells(17).Value
            Dim pClasificacion As String = dgFacturas.CurrentRow.Cells(18).Value
            Dim pNumCtaIVA As String = dgFacturas.CurrentRow.Cells(20).Value

            'elimina fila seleccionada
            Me.dgFacturas.CurrentRow.Cells(19).Value = 2

            'recorre dgProrrateo para verificar cuantos CCostos han sido seleccionados
            For i = 0 To Me.dgProrrateo.Rows.Count - 1

                If Me.dgProrrateo.Rows(i).Cells("colCheckP").Value = "SI" Then

                    ' Guarda Codigo y Centro de costo Seleccionado
                    CodigoCCosto = Me.dgProrrateo.Rows(i).Cells(0).Value
                    DescCCosto = Me.dgProrrateo.Rows(i).Cells(1).Value

                    strfila = pCatalogo & "|"
                    strfila &= pAnio & "|"
                    strfila &= pNumero & "|"
                    strfila &= 0 & "|"
                    strfila &= pLineaOrden & "|"
                    strfila &= pCantidad & "|"
                    strfila &= pDescripcion & "|"
                    strfila &= Math.Round(pPrecioSinIVA / Seleccion, 2) & "|" ' precio sin IVA
                    strfila &= Math.Round(pPrecio / Seleccion, 2) & "|"
                    Dim grandTotal As Double = (pCantidad * Math.Round(pPrecio / Seleccion, 2))
                    strfila &= grandTotal & "|"
                    strfila &= pCodigo & "|"
                    strfila &= pCuentaAct & "|"
                    strfila &= pActFijo & "|"
                    strfila &= pCtaIVA & "|"
                    strfila &= pNomenclatura & "|"
                    strfila &= pGasto & "|"
                    strfila &= CodigoCCosto & "|"
                    strfila &= DescCCosto & "|"
                    strfila &= pClasificacion & "|"
                    strfila &= 0 & "|"
                    strfila &= pNumCtaIVA

                    cFunciones.AgregarFila(dgFacturas, strfila)
                End If


            Next

            For k As Integer = 0 To dgFacturas.Rows.Count - 1

                If dgFacturas.Rows(k).Cells("colAgregar").Value = 2 Then
                    dgFacturas.Rows(k).Visible = False
                Else
                    sumaFact = sumaFact + dgFacturas.Rows(k).Cells(9).Value
                    'dgFacturas.Rows(k).Cells(3) = dgFacturas.Rows(k).Cells(2).Value * dgFacturas.Rows(k).Cells(0)
                End If
                sumLinea = sumLinea + 1
            Next

            sumaFactTotal = sumaFact - celdaMonto.Text

            If sumaFactTotal > 0 Or sumaFactTotal < 0 Then
                sumLinea = sumLinea - 1
                If sumLinea = dgFacturas.Rows.Count - 1 Then
                    dgFacturas.Rows(sumLinea).Cells(9).Value = dgFacturas.Rows(sumLinea).Cells(9).Value - sumaFactTotal
                    dgFacturas.Rows(sumLinea).Cells(8).Value = dgFacturas.Rows(sumLinea).Cells(9).Value / pCantidad
                End If

            End If


        End If
        MostrarLista(1)
    End Sub

    Private Sub checkActivoFijo_CheckedChanged(sender As Object, e As EventArgs) Handles checkActivoFijo.CheckedChanged
        Try


            If checkActivoFijo.Checked = True Then
                Me.dgFacturas.Columns(12).Visible = True
            Else
                Me.dgFacturas.Columns(12).Visible = False
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub dgFacturas_DoubleClick(sender As Object, e As EventArgs) Handles dgFacturas.DoubleClick
        Try
            Dim Frm As New frmSeleccionar
            Dim strCondicion As String = STR_VACIO
            Dim strFila As String = STR_VACIO
            Dim dbltotalLin As Double = 0

            Select Case dgFacturas.CurrentCell.ColumnIndex
                Case 12 'Elige Activo Fijo cuando la columna está visible
                    If dgFacturas.CurrentRow.Cells("colCantidad").Value > 0 Then
                        Dim Condicion As String = STR_VACIO
                        Condicion = " t.empresa = {empresa} "
                        Condicion = Replace(Condicion, "{empresa}", Sesion.IdEmpresa)

                        'Datospara mostrar en pantalla
                        Frm.Titulo = "Fixed Asset"
                        Frm.FiltroText = "Enter the Name Fixed Asset To Filter "

                        'Datos de Base para Llenar Grid
                        Frm.Campos = " DISTINCT(t.Codigo), t.Descripcion, t.Cta_Activo "
                        Frm.Tabla = " Tipos_Activo t "
                        Frm.Condicion = Condicion
                        Frm.Limite =
                        Frm.Ordenamiento = "t.Codigo"
                        Frm.Filtro = "t.Descripcion"
                        Frm.Limite = 50

                        'Mostrar formulario
                        Frm.ShowDialog(Me)

                        If Frm.DialogResult = System.Windows.Forms.DialogResult.OK Then
                            'Captura de datos seleccionados
                            dgFacturas.CurrentRow.Cells("colCodigo").Value = Frm.LLave
                            dgFacturas.CurrentRow.Cells("colCuentaActivo").Value = Frm.Dato2
                            dgFacturas.CurrentRow.Cells("colActivo").Value = Frm.Dato
                            dgFacturas.CurrentRow.Cells("colCuenta").Value = vbNullString
                            dgFacturas.CurrentRow.Cells("colGasto").Value = vbNullString

                        End If
                    End If

                Case 13 ' Elige cuenta de IVA para NSM

                    If checkContribuyent.Checked = False Then
                        Dim strSQL1 As String = STR_VACIO
                        Dim conec As MySqlConnection
                        Dim COM1 As MySqlCommand
                        Dim REA1 As MySqlDataReader
                        Dim factor As Double = 0

                        strSQL1 = PorcentajeIVA()
                        conec = New MySqlConnection(strConexion)
                        conec.Open()
                        COM1 = New MySqlCommand(strSQL1, conec)
                        Using conec
                            REA1 = COM1.ExecuteReader
                            If REA1.HasRows Then
                                REA1.Read()
                                factor = REA1.GetDouble("IVA")
                                factor = (factor / 100) + 1
                                conec.Close()
                                conec.Dispose()
                                conec = Nothing
                                System.GC.Collect()
                            End If
                        End Using

                        If Sesion.IdEmpresa = 22 Then
                            strCondicion = "c.empresa = {emp}"
                            Frm.Filtro = "c.nombre"
                        Else
                            strCondicion = "c.empresa = {emp} AND c.nombre LIKE 'IVA%'"
                            Frm.Filtro = "c.id_cuenta"
                        End If
                        strCondicion = strCondicion.Replace("{emp}", Sesion.IdEmpresa)

                        Frm.Titulo = "VAT"
                        Frm.Campos = "c.nombre, c.id_cuenta"
                        Frm.Tabla = cFunciones.ContaEmpresa & ".cuentas c"
                        Frm.Condicion = strCondicion

                        Frm.ShowDialog(Me)

                        If Frm.DialogResult = System.Windows.Forms.DialogResult.OK Then
                            dgFacturas.CurrentRow.Cells("colCtaIVA").Value = Frm.LLave
                            dgFacturas.CurrentRow.Cells("colidCuentaIVA").Value = Frm.Dato
                            'Recalcula los totales por linea
                            dgFacturas.CurrentRow.Cells("colPrecio").Value = dgFacturas.CurrentRow.Cells("colPrecioSinIVA").Value * factor
                            dbltotalLin = ((dgFacturas.CurrentRow.Cells("colPrecio").Value) * (dgFacturas.CurrentRow.Cells("colCantidad").Value))
                            dgFacturas.CurrentRow.Cells("colTotal").Value = dbltotalLin.ToString(FORMATO_MONEDA)
                        End If
                        ActualizarTotal()
                        CalcuarImpuesto()
                    End If

                Case 15 ' Elige que cuenta y el numero del gasto 

                    ' If dgFacturas.SelectedCells(6).Value > 0  Then
                    'If Not dgFacturas.SelectedCells(12).Value = vbNullString Then

                    'Else
                    Dim Condicion As String = STR_VACIO
                    Dim condicion1 As String = STR_VACIO
                    'Condicion = "c.empresa = {empresa} {tipo} "

                    'Condicion = Replace(Condicion, "{empresa}", Sesion.IdEmpresa)
                    'If Sesion.IdEmpresa = 10 Then
                    '    Condicion = Replace(Condicion, "{tipo}", "AND c.tipo_cuenta = 5")
                    'Else
                    'Condicion = Replace(Condicion, "{tipo}", "")
                    'End If
                    condicion1 = " (
                                    SELECT c.id_cuenta, c.nombre, IFNULL(n.Pertenencia,'0') idRubro, IFNULL(n2.NombreIngles,'') Rubro ,  IFNULL(n.idCuenta,'0') idCuentafectar, IFNULL(n.NombreIngles,'') Cuenta_Afectar, if ((
                                        SELECT COUNT(*)
                                        FROM {conta}.cuentas cc
                                        WHERE cc.empresa = c.empresa AND cc.pid =c.id_cuenta)= 0,'Hijo', 'Padre')Tipo
                                        FROM {conta}.cuentas c
                                        LEFT JOIN {conta}.nomenclatura n ON n.idEmpresa = c.empresa AND n.idCuenta = c.id_nomenclatura 
                                        LEFT JOIN {conta}.nomenclatura n2 ON n2.idEmpresa = n.idEmpresa AND n2.idCuenta = n.Pertenencia 
                                        WHERE Empresa = {empresa} ) l1 "
                    'condicion1 = "{conta}"
                    condicion1 = Replace(condicion1, "{conta}", cFunciones.ContaEmpresa)
                    condicion1 = Replace(condicion1, "{empresa}", Sesion.IdEmpresa)
                    'Datospara mostrar en pantalla
                    Frm.Titulo = "Expenses"
                    Frm.FiltroText = "Enter the Name Expense To Filter "

                    'Datos de Base para Llenar Grid
                    Frm.Campos = " l1.id_cuenta Account_, l1.nombre Name_, l1.idRubro idRubroOcultar, l1.Rubro Accounting_Item,  l1.idCuentafectar idCuentaAfectarOcultar, l1.Cuenta_Afectar Account_To_Affect, l1.Tipo Type_ "
                    Frm.Tabla = condicion1
                    Frm.Condicion = "LENGTH(l1.id_cuenta)>1"
                    Frm.Limite = 50
                    Frm.Ordenamiento = "id_cuenta"
                    Frm.Filtro = " nombre"

                    'Mostrar formulario
                    Frm.ShowDialog(Me)

                    If Frm.DialogResult = System.Windows.Forms.DialogResult.OK Then
                        'Captura de datos seleccionados
                        If Frm.ListaClientes.SelectedCells(6).Value = "Padre" Then
                            MsgBox("You can't use a father accounts")
                        Else
                            dgFacturas.CurrentRow.Cells("colCuenta").Value = Frm.LLave
                            dgFacturas.CurrentRow.Cells("colGasto").Value = Frm.Dato
                            dgFacturas.CurrentRow.Cells("col_idRubro").Value = Frm.Dato2
                            dgFacturas.CurrentRow.Cells("col_Rubro").Value = Frm.Dato3
                            dgFacturas.CurrentRow.Cells("col_idCuenta").Value = Frm.Dato4
                            dgFacturas.CurrentRow.Cells("col_NomCuentafectar").Value = Frm.ListaClientes.SelectedCells(5).Value
                        End If
                    End If
                    'End If
                    ' End If

                Case 17 ' Selecciona el Centro de Costos
                    If dgFacturas.CurrentRow.Cells("colCantidad").Value > 0 Then
                        Dim Condicion As String = STR_VACIO
                        Dim condicion1 As String = STR_VACIO
                        condicion1 = "{conta}"
                        condicion1 = Replace(condicion1, "{conta}", cFunciones.ContaEmpresa)

                        'Datospara mostrar en pantalla
                        Frm.Titulo = "Costes Center"
                        Frm.FiltroText = "Enter the Name Costes Center To Filter "

                        'Datos de Base para Llenar Grid
                        Frm.Campos = "cost_num, cost_nombre"
                        Frm.Tabla = condicion1 & ".costos"
                        Frm.Condicion = "cost_num > 0"
                        Frm.Limite =
                        Frm.Ordenamiento = "cost_num"
                        Frm.Filtro = "cost_nombre"

                        'Mostrar formulario
                        Frm.ShowDialog(Me)

                        If Frm.DialogResult = System.Windows.Forms.DialogResult.OK Then
                            'Captura de datos seleccionados
                            dgFacturas.CurrentRow.Cells("colCosto").Value = Frm.LLave
                            dgFacturas.CurrentRow.Cells("colCentro").Value = Frm.Dato
                        End If
                    End If

                Case 18
                    If dgFacturas.CurrentRow.Cells("colClasificacion").Value = "SERVICIO" Then
                        dgFacturas.CurrentRow.Cells("colClasificacion").Value = "BIEN"
                    ElseIf dgFacturas.CurrentRow.Cells("colClasificacion").Value = "BIEN" Then
                        dgFacturas.CurrentRow.Cells("colClasificacion").Value = "SERVICIO"
                    End If


            End Select

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try

    End Sub

    Private Sub botonMas_Click(sender As Object, e As EventArgs) Handles botonMas.Click
        Dim strfila As String = STR_VACIO
        Dim i As Integer = INT_CERO
        Dim strSQL As String = STR_VACIO
        Dim COM As MySqlCommand
        Dim strClass As String = STR_VACIO

        Try
            If celdaCatOc.Text = 44 Then
                strSQL = " SELECT IF(p.pro_servicio = 0,'BIEN','SERVICIO') Class FROM Proveedores p WHERE p.pro_sisemp = {emp} AND p.pro_codigo = {cod} "
                strSQL = Replace(strSQL, "{emp}", Sesion.IdEmpresa)
                strSQL = Replace(strSQL, "{cod}", celdaProveedor1.Text)
                MyCnn.CONECTAR = strConexion
                COM = New MySqlCommand(strSQL, CON)
                strClass = COM.ExecuteScalar
            Else
                strClass = "SERVICIO"
            End If

            For i = 0 To dgFacturas.Rows.Count - 1
                i = i + 1
            Next

            strfila = 0 & "|"
            strfila &= 0 & "|"
            strfila &= 0 & "|"
            strfila &= i & "|"
            strfila &= 0 & "|"
            strfila &= 0 & "|"
            strfila &= " " & "|"
            strfila &= 0 & "|"
            strfila &= 0 & "|"
            strfila &= 0 & "|"
            strfila &= 0 & "|"
            strfila &= vbNullString & "|"
            strfila &= vbNullString & "|"
            strfila &= vbNullString & "|"
            strfila &= vbNullString & "|"
            strfila &= vbNullString & "|"
            strfila &= vbNullString & "|"
            strfila &= vbNullString & "|"
            strfila &= strClass & "|"
            strfila &= 0 & "|"
            strfila &= vbNullString

            cFunciones.AgregarFila(dgFacturas, strfila)

            ' AGREGAR FILA LOTE - NT DDOC_RF4_COD
            If Sesion.IdEmpresa = 22 AndAlso rbOrdenDeCompra.Checked = True Then
                Dim lastRowIndex As Integer = dgFacturas.Rows.Count - 1
                If lastRowIndex >= 0 Then
                    dgFacturas.Rows(lastRowIndex).Cells("loteNum").Value = "" ' Cambia "Nuevo valor" por lo que necesites
                End If
            End If

            'dgFacturas.ReadOnly = False
            dgFacturas.Columns("colGasto").ReadOnly = True
            dgFacturas.Columns("colCentro").ReadOnly = True
            dgFacturas.Columns("colClasificacion").ReadOnly = True

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub EditardgFactura()
        Dim sumaLine As Double = 0
        Dim strfila As String
        Dim factor As Double
        Dim FactorIVA As Double
        Dim strSQL As String = STR_VACIO
        Dim COM As New MySqlCommand
        Dim REA As MySqlDataReader
        Dim Total As Double
        If dgFacturas.Rows.Count > 0 Then
            Total = (dgFacturas.CurrentRow.Cells("colCantidad").Value * dgFacturas.CurrentRow.Cells("colPrecio").Value)
            dgFacturas.CurrentRow.Cells("colTotal").Value = Total.ToString(FORMATO_MONEDA)
            'If (dgFacturas.Rows.Count - 1) >= 0 Then
            If dgFacturas.CurrentRow.Cells("colPrecio").Value > 0 Then
                If celdaCatOc.Text = 44 Then
                    RefreshTotal()

                    strSQL = PorcentajeIVA()
                    MyCnn.CONECTAR = strConexion
                    COM = New MySqlCommand(strSQL, CON)
                    REA = COM.ExecuteReader
                    If REA.HasRows Then
                        REA.Read()
                        factor = REA.GetDouble("IVA")
                    End If

                    If rbImportación.Checked = True Or checkContribuyent.Checked = True Or Extemporaneo = True Then
                        FactorIVA = 1

                    Else
                        FactorIVA = (factor / 100) + 1
                        logIVA = True
                    End If


                    If logIVA = False Then

                        strfila = 2 & "|"
                        strfila &= 121 & "|"
                        strfila &= "IVA" & "|"
                        strfila &= 0 & "|"
                        strfila &= "IVA" & "|"
                        strfila &= 0 & "|"
                        strfila &= factor & " % " & "|"
                        If checkContribuyent.Checked = True And rbImportación.Checked = True Then

                            strfila &= etiquetaMontoTotal.Text & "|"
                            strfila &= vbEmpty & "|"
                        Else
                            strfila &= Math.Round((etiquetaMontoTotal.Text / FactorIVA), 2) & "|"

                            strfila &= Math.Round((etiquetaMontoTotal.Text - (etiquetaMontoTotal.Text / FactorIVA)), 2) & "|"
                        End If

                        strfila &= -1 & "|"
                        strfila &= 1

                        cFunciones.AgregarFila(dgImpuestos, strfila)
                    End If
                    If logIVA = True Then
                        If checkContribuyent.Checked = True Or rbImportación.Checked = True Then
                            dgImpuestos.SelectedCells(6).Value = factor
                            dgImpuestos.SelectedCells(7).Value = etiquetaMontoTotal.Text
                            dgImpuestos.SelectedCells(8).Value = vbEmpty
                        Else
                            dgImpuestos.SelectedCells(6).Value = factor
                            dgImpuestos.SelectedCells(7).Value = Math.Round((etiquetaMontoTotal.Text / FactorIVA), 2)
                            dgImpuestos.SelectedCells(8).Value = Math.Round((etiquetaMontoTotal.Text - (etiquetaMontoTotal.Text / FactorIVA)), 2)
                        End If
                    End If

                    logIVA = True
                End If


            End If
        End If
    End Sub

    'Actualiza el total en base a la suma del detalle
    Private Sub ActualizarTotal()
        Dim i As Integer = INT_CERO
        Dim Total As Double = 0
        Dim TotalImp As Double = 0
        Dim Monto As Double
        If Sesion.idGiro = 2 Then
            For i = INT_CERO To dgFacturas.Rows.Count - 1
                If Not dgFacturas.Rows(i).Cells("colAgregar").Value = 2 Then
                    If Not dgFacturas.Rows(i).Cells("colidCuentaIVA").Value = vbNullString Then
                        TotalImp = TotalImp + dgFacturas.Rows(i).Cells("colTotal").Value
                    End If
                    Total = Total + dgFacturas.Rows(i).Cells("colTotal").Value
                End If
            Next
            celdaMontoProd.Text = TotalImp
            celdaMonto.Text = Total.ToString(FORMATO_MONEDA)
            Monto = (celdaMonto.Text * celdaTasa.Text).ToString(FORMATO_MONEDA)

            etiquetaMontoTotal.Text = Monto.ToString(FORMATO_MONEDA)
        Else
            For i = INT_CERO To dgFacturas.Rows.Count - 1
                If Not dgFacturas.Rows(i).Cells("colAgregar").Value = 2 Then
                    Total = Total + dgFacturas.Rows(i).Cells("colTotal").Value
                End If
            Next

            celdaMonto.Text = Total.ToString(FORMATO_MONEDA)
            Monto = (celdaMonto.Text * celdaTasa.Text).ToString(FORMATO_MONEDA)

            etiquetaMontoTotal.Text = Monto.ToString(FORMATO_MONEDA)
        End If

    End Sub

    Private Sub dgFacturas_CellEndEdit(sender As Object, e As DataGridViewCellEventArgs) Handles dgFacturas.CellEndEdit
        Dim i As Integer = INT_CERO
        Dim Total As Double

        Dim strSQL1 As String = STR_VACIO
        Dim conec As MySqlConnection
        Dim COM1 As MySqlCommand
        Dim REA1 As MySqlDataReader
        Dim factor As Double = 0

        Select Case dgFacturas.CurrentCell.ColumnIndex
            Case 5 ' Columna Cantidad
                If dgFacturas.CurrentRow.Cells("colCantidad").Value > vbEmpty Then
                    Total = INT_CERO
                    Total = (dgFacturas.CurrentRow.Cells("colPrecio").Value * dgFacturas.CurrentRow.Cells("colCantidad").Value)
                    dgFacturas.CurrentRow.Cells("colTotal").Value = Total.ToString(FORMATO_MONEDA)

                    ActualizarTotal()
                    CalcuarImpuesto()
                Else
                    MsgBox("La cantidad debe de ser mayor que cero", vbInformation)
                    dgFacturas.CurrentRow.Cells("colCantidad").Selected = True
                End If
            Case 7
                If dgFacturas.CurrentRow.Cells("colPrecioSinIVA").Value = 0 Then
                    MsgBox("El precio debe ser mayor a cero", vbInformation)
                    dgFacturas.CurrentRow.Cells("colPrecioSinIVA").Selected = True
                ElseIf dgFacturas.CurrentRow.Cells("colCantidad").Value <= 0 Then
                    MsgBox("Debe ingresar la cantidad antes que el cero", vbInformation)
                    dgFacturas.CurrentRow.Cells("colCantidad").Selected = True
                Else
                    If dgFacturas.CurrentRow.Cells("colidCuentaIVA").Value = vbNullString Then
                        factor = 1
                    Else
                        strSQL1 = PorcentajeIVA()
                        conec = New MySqlConnection(strConexion)
                        conec.Open()
                        COM1 = New MySqlCommand(strSQL1, conec)
                        Using conec
                            REA1 = COM1.ExecuteReader
                            If REA1.HasRows Then
                                REA1.Read()
                                factor = REA1.GetDouble("IVA")
                                factor = (factor / 100) + 1
                                conec.Close()
                                conec.Dispose()
                                conec = Nothing
                                System.GC.Collect()
                            End If
                        End Using
                    End If
                    'dgFacturas.CurrentRow.Cells("colPrecioSinIVA").Value = Total.ToString(FORMATO_MONEDA)
                    dgFacturas.CurrentRow.Cells("colPrecio").Value = dgFacturas.CurrentRow.Cells("colPrecioSinIVA").Value * factor
                    Total = (dgFacturas.CurrentRow.Cells("colPrecio").Value * dgFacturas.CurrentRow.Cells("colCantidad").Value)
                    dgFacturas.CurrentRow.Cells("colTotal").Value = Total.ToString(FORMATO_MONEDA)
                End If
                ActualizarTotal()
                CalcuarImpuesto()
            Case 8 ' Columna Precio 
                If dgFacturas.CurrentRow.Cells("colPrecio").Value = 0 Then
                    MsgBox("El precio debe ser mayor a cero", vbInformation)
                    dgFacturas.CurrentRow.Cells("colPrecio").Selected = True
                ElseIf dgFacturas.CurrentRow.Cells("colCantidad").Value <= 0 Then
                    MsgBox("Debe ingresar la cantidad antes que el cero", vbInformation)
                    dgFacturas.CurrentRow.Cells("colCantidad").Selected = True
                Else
                    Total = (dgFacturas.CurrentRow.Cells("colPrecio").Value * dgFacturas.CurrentRow.Cells("colCantidad").Value)
                    dgFacturas.CurrentRow.Cells("colTotal").Value = Total.ToString(FORMATO_MONEDA)
                End If
                ActualizarTotal()
                CalcuarImpuesto()

        End Select
        ' EditardgFactura()


    End Sub

    Private Sub botonOtrosImp_Click(sender As Object, e As EventArgs) Handles botonOtrosImp.Click
        Dim strRemplazo As String = STR_VACIO
        Dim strfila As String = STR_VACIO

        Dim frm As New frmSeleccionar

        strRemplazo = "c.cat_sisemp = {empresa}"
        strRemplazo = Replace(strRemplazo, "{empresa}", Sesion.IdEmpresa)

        Try

            frm.Titulo = "Other Taxes"
            frm.Campos = "d.cat_pid Linea, If(i.cat_pid = 0, i.cat_clave, i.cat_desc) Descripcion, d.cat_num ID"
            frm.Tabla = " Catalogos c LEFT JOIN Catalogos i ON i.cat_sisemp=c.cat_sisemp And i.cat_clase='Impuestos' AND i.cat_clave=c.cat_sist LEFT JOIN Catalogos d ON d.cat_sisemp=i.cat_sisemp AND d.cat_clase='DocImpuesto' AND d.cat_clave='Doc_PFactura' AND d.cat_sist=i.cat_clave"
            frm.FiltroText = "Enter the other taxes to filter"
            frm.Filtro = "Descripcion"
            frm.Ordenamiento = "d.cat_pid"
            frm.Agrupar = "i.cat_num"
            frm.TipoOrdenamiento = ""
            frm.Condicion = strRemplazo & " AND c.cat_clase='Contabilidad' AND c.cat_clave='Cuenta' AND NOT(i.cat_clave IN ('IVA')) AND NOT(ISNULL(d.cat_num))"

            frm.ShowDialog(Me)
            'If frm.LLave = 1 Then

            If frm.DialogResult = System.Windows.Forms.DialogResult.OK Then
                strfila = frm.LLave & "|"
                strfila &= frm.Dato2 & "|"
                strfila &= "IMP_DC" & "|"
                strfila &= -1 & "|"
                strfila &= frm.Dato & "|"
                strfila &= 0 & "|"
                strfila &= 0 & "|"
                strfila &= etiquetaMontoTotal.Text & "|"
                strfila &= 0 & "|"
                strfila &= 0 & "|"
                strfila &= 0

                cFunciones.AgregarFila(dgImpuestos, strfila)


                'dgImpuestos.Sort(dgFacturas.Columns("colLine"), ListSortDirection.Ascending)

            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try


    End Sub

    Private Sub botnEditar_Click(sender As Object, e As EventArgs) Handles botnEditar.Click
        If dgImpuestos.SelectedCells(0).Value <> 2 Then
            Dim totalBase As Double
            Dim i As Integer
            Dim frm As New frmDatosImpuestos
            frm.checkMonto.Checked = False
            frm.celdaTotalOpcional.Enabled = False

            If Me.Tag = "Mod" Then
                frm.Dato1 = dgImpuestos.CurrentRow.Cells("colDescripcion1").Value
                frm.Dato2 = dgImpuestos.CurrentRow.Cells("colFactor").Value
                frm.Dato3 = dgImpuestos.CurrentRow.Cells("colCantidad1").Value
                frm.Dato4 = dgImpuestos.CurrentRow.Cells("colMonto").Value
                frm.CargarDatos()
            End If

            frm.ShowDialog(Me)

            If frm.DialogResult = System.Windows.Forms.DialogResult.OK Then
                If dgImpuestos.SelectedCells(0).Value = 1 Then
                    dgImpuestos.SelectedCells(4).Value = frm.Dato1
                    dgImpuestos.SelectedCells(5).Value = frm.Dato3
                    dgImpuestos.SelectedCells(6).Value = frm.Dato2
                    dgImpuestos.SelectedCells(8).Value = frm.Dato4
                    totalBase = etiquetaMontoTotal.Text - frm.Dato4
                    dgImpuestos.SelectedCells(7).Value = Math.Round(totalBase, 2)
                    'dgImpuestos.Rows(0).Cells(7).Value = Math.Round((totalBase / 1.12), 2)
                    'dgImpuestos.Rows(0).Cells(8).Value = Math.Round((totalBase) - (totalBase / 1.12), 2)

                Else

                End If

            End If

            If dgImpuestos.SelectedCells(5).Value > 0 Then

                For i = 0 To dgImpuestos.Rows.Count - 1
                    If dgImpuestos.Rows(i).Cells(0).Value = 2 Then
                        dgImpuestos.Rows(i).Cells(7).Value = Math.Round((totalBase / 1.12), 2)
                        dgImpuestos.Rows(i).Cells(8).Value = Math.Round((totalBase) - (totalBase / 1.12), 2)
                        Exit For
                    End If
                Next

            Else
            End If


        Else

        End If


    End Sub

    Private Sub botonISR_Click(sender As Object, e As EventArgs) Handles botonISR.Click
        Dim strSql As String = STR_VACIO

        If CrearRISRProveedor() = True Then
            celdaRetension.Text = "Ret. #" & celdaAnioOc.Text & "-" & NumISR
            celdaRetension.ForeColor = Color.Purple
            celdaRetension.Font = New System.Drawing.Font("Arial", 12, FontStyle.Bold)
        End If
    End Sub

    Private Sub botonMenos_Click(sender As Object, e As EventArgs) Handles botonMenos.Click
        Dim i As Integer = INT_CERO
        If dgFacturas.Rows.Count = 1 Then
        ElseIf dgFacturas.SelectedRows Is Nothing Then
            Exit Sub
        ElseIf dgFacturas.CurrentRow.Cells(19).Value = 1 Or dgFacturas.CurrentRow.Cells(19).Value = 0 Then
            dgFacturas.CurrentRow.Cells(19).Value = 2
            For i = 0 To dgOrdenes.Rows.Count - 1
                If dgFacturas.CurrentRow.Cells(4).Value = dgOrdenes.Rows(i).Cells("colLineOrden").Value Then
                    dgOrdenes.Rows(i).Visible = False
                End If
            Next
            dgFacturas.CurrentRow.Visible = False
        End If

        ActualizarTotal()

        'For i = INT_CERO To dgFacturas.Rows.Count - 1
        '    If dgFacturas.Rows(i).Cells("colAgregar").Value = 0 Or dgFacturas.Rows(i).Cells("colAgregar").Value = 1 Then
        '        SumaTotal = dgFacturas.Rows(i).Cells("colTotal").Value
        '    End If
        'Next

        'celdaMonto.Text = SumaTotal
    End Sub

    Private Sub botonDesligar_Click(sender As Object, e As EventArgs) Handles botonDesligar.Click
        If dgPoliza.Visible = True Then
            Me.dgPoliza.Rows.Remove(dgPoliza.CurrentRow)
        ElseIf dgOrdenes.Visible = True Then
            Me.dgOrdenes.Rows.Remove(dgPoliza.CurrentRow)
        End If

    End Sub

    Private Sub botonEliminar_Click(sender As Object, e As EventArgs) Handles botonEliminar.Click
        'If dgImpuestos.SelectedCells(0).Value <> 2 Then
        'Me.dgImpuestos.Rows.Remove(dgImpuestos.CurrentRow)
        'Else
        ' End If
        Try
            Dim Count As Integer
            If dgImpuestos.SelectedCells(0).Value <> 2 Then

                If dgImpuestos.SelectedRows Is Nothing Then Exit Sub
                If dgImpuestos.Rows.Count > 1 Then
                    Count = dgImpuestos.Rows.GetRowCount(DataGridViewElementStates.Selected)
                    For i As Integer = 0 To Count - 1
                        '  strTexto = "Remove " & CStr(dgCotizacion.SelectedCells(1).Value) & vbCrLf
                        If MsgBox("You sure you want to delete the row " & "OF THE ORDER " &
                    CInt(dgImpuestos.SelectedCells(0).Value) & ", " &
               CStr(dgImpuestos.SelectedCells(4).Value) & " ," &
                CStr(dgImpuestos.SelectedCells(5).Value) & " ," &
                   CStr(dgImpuestos.SelectedCells(7).Value) & "?", vbQuestion + vbYesNo + vbDefaultButton2) =
                    vbYes Then
                            If dgImpuestos.SelectedCells(10).Value = 0 Or dgImpuestos.SelectedCells(10).Value = 1 Then
                                dgImpuestos.SelectedCells(10).Value = 2
                                If dgImpuestos.SelectedCells(10).Value = 2 Then
                                    dgImpuestos.CurrentRow.Visible = False
                                    CalcuarImpuesto()
                                End If
                            ElseIf dgImpuestos.Rows(i).Selected = Nothing Then
                                '  dgDetalle.SelectedCells(6).Value = 3
                                ' dgDetalle.CurrentRow.Visible = False
                                dgImpuestos.Rows.RemoveAt(dgImpuestos.RowCount - 1)
                            End If
                        End If
                    Next
                Else
                    MsgBox("you can not delete the last row")
                    Exit Sub
                End If
            End If
            dgImpuestos.ReadOnly = False
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub celdaRevisado_TextChanged(sender As Object, e As EventArgs) Handles celdaRevisado.TextChanged
        'If checkRevisado.Checked = True Then
        '    celdaRevisado.Text = 0
        'Else
        '    celdaRevisado.Text = 1
        'End If
    End Sub

    Private Sub checkRevisado_CheckedChanged(sender As Object, e As EventArgs) Handles checkRevisado.CheckedChanged
        If checkRevisado.Checked = True Then
            celdaRevisado.Text = 1
        Else
            celdaRevisado.Text = 0
        End If
    End Sub


    Private Sub Encabezado1_ClickGuardar(sender As Object, click As Boolean) Handles Encabezado1.ClickGuardar
        If Me.Tag = "Mod" Then
            If Sesion.idGiro = 1 And rbImportación.Checked = True And cfun.ValidaFacturaVenta(intDocumentoTipo, celdaAnioOc.Text, celdaNumOc.Text) Then
                If AutorizarGuardar(intDocumentoTipo) = False Then
                    Exit Sub
                End If
            End If
        End If

        Dim strSQL As String = STR_VACIO
        Dim COM As MySqlCommand
        Dim intExisteCierre As Integer

        'Verifica si hay cierre
        strSQL = " Select Count(*) From Cierre_Encabezado e Where e.CE_Empresa = {emp} and e.CE_Anio = {anio} and e.CE_Fecha_Final >= '{fec}' "
        strSQL = Replace(strSQL, "{emp}", Sesion.IdEmpresa)
        strSQL = Replace(strSQL, "{anio}", Year(dtpFecha1.Value.ToString(FORMATO_MYSQL)))
        strSQL = Replace(strSQL, "{fec}", dtpFecha1.Value.ToString(FORMATO_MYSQL))

        MyCnn.CONECTAR = strConexion
        COM = New MySqlCommand(strSQL, CON)
        intExisteCierre = COM.ExecuteScalar
        If rbImportación.Checked = True Then
            ValidacionEInsercion()
        Else
            If Year(dtpFecha1.Value) <> Year(Now) Then
                If Month(dtpFecha1.Value) = 12 Then
                    If intExisteCierre = 0 Then
                        ValidacionEInsercion()
                    Else
                        MsgBox("This document cannot be saved, please contact the financial department", vbCritical)
                    End If
                Else
                    'Verifica si hay cierre en diciembre cuando la factura no es de diciembre, y ya estamos en otro año

                    MyCnn.CONECTAR = strConexion
                    COM = New MySqlCommand(strSQL, CON)
                    intExisteCierre = COM.ExecuteScalar

                    If intExisteCierre = 0 Then
                        ValidacionEInsercion()
                    Else
                        MsgBox("This document cannot be saved, please contact the financial department", vbCritical)
                    End If

                End If

            Else
                ValidacionEInsercion()
            End If
        End If

    End Sub
    Private Function VerificarAccesoLocal(ByRef IP As String, ByRef strUsuario As String, ByRef strContrasena As String, ByRef strRuta As String) As Boolean
        Dim COM As MySqlCommand
        Dim logVerificar As Boolean
        Dim strSQL As String = STR_VACIO
        Dim REA As MySqlDataReader
        Try
            strSQL = " SELECT c.cat_desc IP , c.cat_ext usuario, c.cat_sist Ruta , c.cat_dato Contrasena  "
            strSQL &= "     FROM Catalogos c "
            strSQL &= "         WHERE c.cat_clase = 'felFESP' AND c.cat_clave = 'FacturaEspecial' "
            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSQL, CON)
            REA = COM.ExecuteReader
            If REA.HasRows Then
                Do While REA.Read
                    IP = REA.GetString("IP")
                    strUsuario = REA.GetString("usuario")
                    strContrasena = REA.GetString("Contrasena")
                    strRuta = REA.GetString("Ruta")
                Loop
            End If


            If My.Computer.Network.Ping(IP) Then
                MessageBox.Show("Conexion correcta", "", MessageBoxButtons.OK, MessageBoxIcon.Information)
                logVerificar = True
            Else
                MessageBox.Show("Conexion erronea", "", MessageBoxButtons.OK, MessageBoxIcon.Error)
                logVerificar = False
            End If
        Catch ex As Net.NetworkInformation.PingException
            MessageBox.Show("Ocurrió el siguiente error:" & vbCrLf & ex.Message, "", MessageBoxButtons.OK, MessageBoxIcon.Error)
            logVerificar = False
        Catch ex As Exception
            MessageBox.Show("Ocurrió el siguiente error:" & vbCrLf & ex.Message, "", MessageBoxButtons.OK, MessageBoxIcon.Error)
            logVerificar = False
        End Try
        Return logVerificar
    End Function
    Public Sub ValidacionEInsercion()
        Dim LogVerificar As Boolean = False
        Dim TotalImport As Double
        Dim conteo As Integer
        Dim strSQL As String = STR_VACIO
        Dim conta As New clsContabilidad
        Dim dtpFechaConta As Date
        Dim IP As String = STR_VACIO
        Dim strUsuario As String = STR_VACIO
        Dim strContrasena As String = STR_VACIO
        Dim strRuta As String = STR_VACIO
        Dim strConexion2 As String
        Dim ArrayServer() As String
        Dim ArrayAuxiliar() As String
        Dim strCadena As String = STR_VACIO
        Dim ArrayValidacion() As String
        Dim arrayIP() As String
        Dim IngresoTendido As Integer = NO_FILA

        If ValidaProductoFactura() Then
            Exit Sub
        End If

        If VerificaBloqueo() = 1 Then

            'Me.Tag = Not "Mod"
            '*********************************
            'FACTURA ELECTRONICA

            If checkFacElectrónica.Checked = True And (checkContribuyent.Checked = True Or rbImportación.Checked = True) Then
                MsgBox("The electronic invoice must be local and does not apply to small taxpayers", vbExclamation, "Electronic Bill")
                LogVerificar = True
            End If
            If celdaTasa.Text = 0 And celdaTasa.Text < 0 Then
                MsgBox("check exchange rate")
                Exit Sub
            End If
            '*********************************
            'IMPORTACION SIN RELACIONES
            If rbImportación.Checked = True Then
                For i As Integer = 0 To dgPoliza.Rows.Count - 1
                    TotalImport = Math.Round((TotalImport + dgPoliza.Rows(i).Cells(7).Value), 2)
                    conteo = conteo + 1
                Next

                If conteo = 0 Then
                    If MsgBox("You are saving an import invoice without relating it to any policy" & vbCrLf & vbCrLf & "Press [Cancel] to return and correct it.", vbExclamation + vbOKCancel, "Import") = vbCancel Then
                        LogVerificar = True
                    End If
                ElseIf (celdaMonto.Text - TotalImport) > 1 Then
                    If MsgBox("There is a difference between the amount of the invoice and the import policy" & vbCrLf & vbCrLf & "Bill: " & celdaMonto.Text & vbCrLf & vbCrLf & "Import: " & TotalImport & vbCrLf & vbCrLf & "Press [Cancel] to return and correct it.", vbExclamation + vbOKCancel, "Import") = vbCancel Then
                        LogVerificar = True
                    End If
                Else
                    'Comprobar proveedor

                    If Not VerificarProveedor() Then
                        If MsgBox("Supplier differs from import document", vbExclamation + vbOKCancel, "Import data") = vbCancel Then
                            LogVerificar = True
                        End If
                    End If
                End If
            ElseIf Me.Tag = "Mod" Then
                If celdaCatOc.Text = 44 Then
                    If EnLibroCompras(celdaAnioOc.Text, celdaNumOc.Text, True, "Nota: No se permiten modificaciones") Then
                        LogVerificar = True
                    End If
                End If

            End If
            If CheckFactEspecial.Checked = True Then
                If celdaUUID.Text <> STR_VACIO Then
                    If checkActive.Checked = False Then
                        ArrayServer = strConexion.Split(";".ToCharArray)
                        strConexion2 = "server={server};uid={user};password={password};database={database} ;Allow User Variables=True"
                        ArrayAuxiliar = ArrayServer(INT_CERO).Split("server=".ToCharArray)
                        strCadena = ArrayServer(INT_CERO)
                        ArrayValidacion = strCadena.Split(".".ToCharArray)
                        strCadena = ArrayValidacion(INT_CERO)
                        arrayIP = strCadena.Split("=".ToCharArray)
                        If arrayIP(INT_UNO) = "192" Then
                            If VerificarAccesoLocal(IP, strUsuario, strContrasena, strRuta) = True Then
                            Else
                                Exit Sub
                            End If
                        Else
                            If VerificarAcceso(IP, strUsuario, strContrasena, strRuta) = True Then
                            Else
                                Exit Sub
                            End If
                        End If
                        If cfun.PermisoAnular() = True Then
                            If AnularFel(celdaSerieFel.Text, celdaFechaEmisionDocumento.Text, IP, strUsuario, strContrasena, strRuta) = False Then
                                Exit Sub
                            End If
                        Else
                            MsgBox("You don't have access to cancel this document")
                            Exit Sub
                        End If
                    End If
                Else
                    If checkActive.Checked = False Then
                        MsgBox("You cannot cancel a document that is not transmitted" & vbNewLine & "please contact the Financial department.")
                        Exit Sub
                    End If
                End If
            End If


            If Not LogVerificar Then
                If ComprobarIngreso() Then
                    If Me.Tag = "Nuevo" Then
                        ProcedimientosDeGuardadoDeDocumentos()
                        If (rbImportación.Checked = False) Then

                            dtpFechaConta = cfun.SQLValidarFechaContable(celdaCatOc.Text, celdaAnioOc.Text, celdaNumOc.Text)
                            If cfun.SQLVerificarCierre(celdaCatOc.Text, celdaAnioOc.Text, celdaNumOc.Text) = 0 Then
                                If ValidarSiTieneRetenciones() = True Then
                                    If (rbOrdenDeCompra.Checked = True And celdaTipoOrden.Text = 1) Or (rbLocal.Checked = True) Or (IngresoTendido = 1) Then
                                        conta.GenerarPoliza(celdaCatOc.Text, Year(dtpFecha1.Value), celdaNumOc.Text, dtpFechaPolizaC.Value.ToString(FORMATO_MYSQL),,, IngresoTendido)
                                    End If
                                End If
                            Else
                                'Si hay cierre solicita autorizacion
                                MsgBox("You need authorization to save this document", vbInformation, "Notice")
                                If cFunciones.AutorizarCambios() = True Then
                                    'Registra quien autoriza
                                    cfun.EscribirRegistro(Tbl_Documentos, clsFunciones.AccEnum.acConfirm, celdaProveedor1.Text, 44, celdaNumOc.Text, celdaNumOc.Text)
                                    If (rbOrdenDeCompra.Checked = True And celdaTipoOrden.Text = 1) Or (rbLocal.Checked = True) Or (IngresoTendido = 1) Then
                                        conta.GenerarPoliza(celdaCatOc.Text, Year(dtpFecha1.Value), celdaNumOc.Text, dtpFechaPolizaC.Value.ToString(FORMATO_MYSQL),,, IngresoTendido)
                                    End If
                                Else
                                    EnviarCorreoAlCancelar()
                                End If
                            End If
                        End If

                    ElseIf Me.Tag = "Mod" Then
                        If rbImportación.Checked = True Then
                            IngresoTendido = IngresoTendidosEntrePlantas()
                        End If

                        'Como es una modificación verifica la fecha de la poliza si es que el documento tiene, si no captura la fecha del documento
                        dtpFechaConta = cfun.SQLValidarFechaContable(44, celdaAnioOc.Text, celdaNumOc.Text)

                        If cfun.SQLVerificarCierre(celdaCatOc.Text, celdaAnioOc.Text, celdaNumOc.Text) = 0 Then
                            If ValidarSiTieneRetenciones() = True Then
                                ProcedimientosDeGuardadoDeDocumentos()
                                'If (rbOrdenDeCompra.Checked = True) Then
                                If (IngresoTendido = 1) Or (rbLocal.Checked = True) Or (rbOrdenDeCompra.Checked = True And celdaTipoOrden.Text = 1) Then
                                    'conta.GenerarPoliza(44, Year(dtpFecha1.Value), celdaNumOc.Text, dtpFechaConta.ToString(FORMATO_MYSQL))
                                    conta.GenerarPoliza(celdaCatOc.Text, Year(dtpFecha1.Value), celdaNumOc.Text, dtpFechaPolizaC.Value.ToString(FORMATO_MYSQL),,, IngresoTendido)
                                End If
                            End If
                        Else
                            'Si hay cierre solicita autorizacion
                            MsgBox("You need authorization to modify this document", vbInformation, "Notice")
                            If cFunciones.AutorizarCambios() = True Then
                                'Registra quien autoriza
                                cfun.EscribirRegistro(Tbl_Documentos, clsFunciones.AccEnum.acConfirm, celdaProveedor1.Text, 44, celdaNumOc.Text, celdaNumOc.Text)
                                If ValidarSiTieneRetenciones() = True Then
                                    ProcedimientosDeGuardadoDeDocumentos()
                                    'If (rbOrdenDeCompra.Checked = True) Then
                                    If (IngresoTendido = 1) Or (rbLocal.Checked = True) Or (rbOrdenDeCompra.Checked = True And celdaTipoOrden.Text = 1) Then
                                        'conta.GenerarPoliza(44, Year(dtpFecha1.Value), celdaNumOc.Text, dtpFechaConta.ToString(FORMATO_MYSQL))
                                        conta.GenerarPoliza(celdaCatOc.Text, Year(dtpFecha1.Value), celdaNumOc.Text, dtpFechaPolizaC.Value.ToString(FORMATO_MYSQL),,, IngresoTendido)
                                    End If
                                End If

                            Else
                                EnviarCorreoAlCancelar()
                            End If
                        End If
                    End If
                End If
            End If

        Else
            MsgBox(" At this time you can not enter invoices, please contact the Financial Department", vbInformation, "Notice")
        End If
    End Sub

    Public Function ValidaProductoFactura() As Boolean
        Dim mensaje As String
        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader
        Dim strSQL As String
        Dim idProductos As String = "0"

        If rbOrdenDeCompra.Checked = False Then
            Return False
        End If

        If dgFacturas.Rows.Count <= vbEmpty Then
            Return False
        End If

        strSQL = "Select art_DCorta From Articulos a" & vbCrLf
        strSQL = strSQL & "Left Join Catalogos c On c.cat_num = a.art_clase And c.cat_clase = 'ClaseArt'" & vbCrLf
        strSQL = strSQL & "WHERE art_sisemp = {emp} AND cat_clave='PACKING' And a.art_codigo  IN ({idProductos})" & vbCrLf
        strSQL = strSQL & "ORDER BY art_codigo"
        strSQL = strSQL.Replace("{emp}", Sesion.IdEmpresa)
        For i = 0 To dgFacturas.Rows.Count - 1
            If (dgFacturas.Rows(i).Cells("colCosto").Value = vbNullString Or dgFacturas.Rows(i).Cells("colCosto").Value = "0") And dgFacturas.Rows(i).Visible Then
                If dgFacturas.Rows(i).Cells("colCodigoP").Value <> vbNullString Or dgFacturas.Rows(i).Cells("colCodigoP").Value <> "0" Then
                    idProductos = String.Concat(idProductos, ",", dgFacturas.Rows(i).Cells("colCodigoP").Value)
                End If
            End If
        Next
        strSQL = strSQL.Replace("{idProductos}", idProductos)
        MyCnn.CONECTAR = strConexion
        COM = New MySqlCommand(strSQL, CON)
        REA = COM.ExecuteReader
        If REA.HasRows Then
            mensaje = ""
            Do While REA.Read
                mensaje = mensaje & REA.GetString("art_DCorta") & vbCrLf
            Loop
            mensaje = mensaje & "Need Cost Center"
            MsgBox(mensaje, vbInformation, "notice")
            Return True
        End If

        Return False
    End Function
    Public Sub EnviarCorreoAlCancelar()
        Dim ArrayServer() As String
        Dim ArrayAuxiliar() As String
        Dim strConexion2 As String = STR_VACIO
        Dim strInsert As String = STR_VACIO
        Dim COMM As MySqlCommand
        Dim LLave As String = STR_VACIO
        Dim conec2 As MySqlConnection

        ArrayServer = strConexion.Split(";".ToCharArray)

        strConexion2 = "server={server};port={puerto};uid={user};password={password};database={database} ;Allow User Variables=True"
        ArrayAuxiliar = ArrayServer(INT_CERO).Split("=".ToCharArray)

        If ArrayAuxiliar(INT_UNO) = "192.168.4.9" Then
            strConexion2 = Replace(strConexion2, "{server}", MAIL_HOST)
            strConexion2 = Replace(strConexion2, "port={puerto};", vbNullString)
        Else
            strConexion2 = Replace(strConexion2, "{server}", MAIL_HOST_REMOTO)
            strConexion2 = Replace(strConexion2, "{puerto}", "3308")
        End If

        strConexion2 = Replace(strConexion2, "{user}", MAIL_USER)
        strConexion2 = Replace(strConexion2, "{password}", MAIL_PASS)
        strConexion2 = Replace(strConexion2, "{database}", MAIL_BASE)

        LLave = 44 & "-" & celdaAnioOc.Text & "-" & celdaNumOc.Text & " --> " & Sesion.Usuario
        strInsert &= ("INSERT INTO MailServer.Correo (idCorreo, Destinatario, Asunto, Contenido, Estado) Values(0,'" & "tisoportegt@grupokarims.com, delia.ramirez@grupokarims.com'" & "," & "'Alteración de Póliza'" & ",'" & LLave & "',0)")

        conec2 = New MySqlConnection(strConexion2)
        conec2.Open()
        Using conec2
            COMM = New MySqlCommand(strInsert, conec2)
            COMM.ExecuteNonQuery()
            COMM.Dispose()
            System.GC.Collect()

            COMM.Dispose()
            COMM = Nothing
            conec2.Close()
            conec2.Dispose()
            conec2 = Nothing
            System.GC.Collect()
        End Using
    End Sub

    Private Function ValidarSiTieneRetenciones()
        Dim strSQL As String = STR_VACIO
        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader
        Dim StrRet As String = STR_VACIO
        Dim TieneRet As Boolean = True
        If checkActive.Visible = True Then
            If checkActive.Checked = False Then
                strSQL = " SELECT r.HDoc_DR1_Num
                            FROM Dcmtos_HDR h
                            LEFT JOIN Dcmtos_HDR r ON r.HDoc_Sis_Emp = h.HDoc_Sis_Emp AND r.HDoc_Pro_DCat = h.HDoc_Doc_Cat AND r.HDoc_Pro_DAno = h.HDoc_Doc_Ano AND r.HDoc_Pro_DNum = h.HDoc_Doc_Num
                            WHERE h.HDoc_Sis_Emp = {emp} AND h.HDoc_Doc_Cat = {catalogo} AND h.HDoc_Doc_Ano = {anio} AND h.HDoc_Doc_Num = {num}"
                strSQL = strSQL.Replace("{emp}", Sesion.IdEmpresa)
                strSQL = strSQL.Replace("{anio}", celdaAnioOc.Text)
                strSQL = strSQL.Replace("{num}", celdaNumOc.Text)
                strSQL = strSQL.Replace("{catalogo}", celdaCatOc.Text)

                MyCnn.CONECTAR = strConexion
                COM = New MySqlCommand(strSQL, CON)
                REA = COM.ExecuteReader
                If REA.HasRows Then
                    Do While REA.Read
                        StrRet = StrRet & vbCrLf & REA.GetString("HDoc_DR1_Num")
                    Loop
                    MsgBox("You cannot Void the Invoice, you have Retentions anchored" & vbCrLf & vbCrLf & StrRet, vbInformation, "notice")
                    TieneRet = False
                Else

                End If
            End If
        End If
        Return TieneRet
    End Function

    Private Function IngresoTendidosEntrePlantas() As Integer
        Dim TIngreso As Integer = 0
        Dim strSql As String = STR_VACIO
        Dim COM As MySqlCommand

        strSql = " SELECT d.HDoc_DR1_Dbl 
                    FROM Dcmtos_HDR h
                    LEFT JOIN Dcmtos_DTL_Pro p ON p.PDoc_Sis_Emp = h.HDoc_Sis_Emp AND p.PDoc_Chi_Cat = h.HDoc_Doc_Cat AND p.PDoc_Chi_Ano = h.HDoc_Doc_Ano AND p.PDoc_Chi_Num = h.HDoc_Doc_Num AND p.PDoc_Par_Cat = 180
                    LEFT JOIN Dcmtos_HDR d ON d.HDoc_Sis_Emp = p.PDoc_Sis_Emp AND d.HDoc_Doc_Cat = p.PDoc_Par_Cat AND d.HDoc_Doc_Ano = p.PDoc_Par_Ano AND d.HDoc_Doc_Num = p.PDoc_Par_Num 
                        WHERE h.HDoc_Sis_Emp = {emp} AND h.HDoc_Doc_Cat = {catalogo} AND h.HDoc_Doc_Ano = {anio} AND h.HDoc_Doc_Num = {num}"
        strSql = strSql.Replace("{emp}", Sesion.IdEmpresa)
        strSql = strSql.Replace("{anio}", celdaAnioOc.Text)
        strSql = strSql.Replace("{num}", celdaNumOc.Text)
        strSql = strSql.Replace("{catalogo}", celdaCatOc.Text)

        MyCnn.CONECTAR = strConexion
        COM = New MySqlCommand(strSql, CON)
        TIngreso = COM.ExecuteScalar
        Return TIngreso
    End Function

    Private Sub ProcedimientosDeGuardadoDeDocumentos()
        Dim conta As New clsContabilidad
        Dim IngresoTendido As Integer = NO_FILA

        If GuardarDocumento() Then
            GuardarDetalle()
            GuardarImpuestos()
            If rbImportación.Checked = True Or rbOrdenDeCompra.Checked = True Then
                GuardarRelación()
            End If
            If rbImportación.Checked = True Then
                IngresoTendido = IngresoTendidosEntrePlantas()
            End If
            If Me.Tag = "Mod" Then
                cFunciones.EscribirRegistro(Tbl_Documentos, clsFunciones.AccEnum.acUpdate, celdaProveedor1.Text, celdaCatOc.Text, celdaAnioOc.Text, celdaNumOc.Text)
            Else
                cFunciones.EscribirRegistro(Tbl_Documentos, clsFunciones.AccEnum.acAdd, celdaProveedor1.Text, celdaCatOc.Text, celdaAnioOc.Text, celdaNumOc.Text)
                If cfun.SQLVerificarCierre(celdaCatOc.Text, celdaAnioOc.Text, celdaNumOc.Text) = 0 Then
                    'If (rbOrdenDeCompra.Checked = True) Then
                    If (rbLocal.Checked = True) Or (IngresoTendido = INT_UNO) Or (rbOrdenDeCompra.Checked = True And celdaTipoOrden.Text = 1) Then
                        'conta.GenerarPoliza(44, celdaAnioOc.Text, celdaNumOc.Text, dtpFecha1.Value.ToString(FORMATO_MYSQL))
                        conta.GenerarPoliza(celdaCatOc.Text, celdaAnioOc.Text, celdaNumOc.Text, dtpFechaPolizaC.Value.ToString(FORMATO_MYSQL),,, IngresoTendido)
                    End If
                Else ' Si hay cierre, guarda la poliza con fecha 1 del mes actual
                    'If (rbOrdenDeCompra.Checked = True) Then
                    If (rbLocal.Checked = True) Or (IngresoTendido = INT_UNO) Or (rbOrdenDeCompra.Checked = True And celdaTipoOrden.Text = 1) Then
                        If Year(dtpFecha1.Value) <> Year(Now) Then
                            'conta.GenerarPoliza(44, celdaAnioOc.Text, celdaNumOc.Text, (DateSerial(Year(dtpFecha1.Value), Month(dtpFecha1.Value), 1).ToString(FORMATO_MYSQL)))
                            conta.GenerarPoliza(celdaCatOc.Text, celdaAnioOc.Text, celdaNumOc.Text, dtpFechaPolizaC.Value.ToString(FORMATO_MYSQL),,, IngresoTendido)
                        Else
                            'conta.GenerarPoliza(44, celdaAnioOc.Text, celdaNumOc.Text, (DateSerial(Year(Date.Now), Month(Date.Now), 1).ToString(FORMATO_MYSQL)))
                            conta.GenerarPoliza(celdaCatOc.Text, celdaAnioOc.Text, celdaNumOc.Text, dtpFechaPolizaC.Value.ToString(FORMATO_MYSQL),,, IngresoTendido)

                        End If
                    End If

                End If
            End If

            ' genera automaticamente el ingreso a bodega
            ' wc
            ' 24-03-2022
            ' 
            ' GeneraIngresoBodega()

            If MsgBox("The document has been saved" & vbCr & vbCr & "¿Do you want close the document?", vbQuestion + vbYesNo + vbDefaultButton2, "Close document") = vbYes Then
                MostrarLista()
            Else
                If Sesion.idGiro = 2 Then ' (Sesion.IdEmpresa = 15) Or (Sesion.IdEmpresa = 18) Or (Sesion.IdEmpresa = 19) Then
                    Dim AnioDoc As Integer
                    Dim NumDoc As Integer

                    AnioDoc = celdaAnioOc.Text
                    NumDoc = celdaNumOc.Text
                    If rbOrdenDeCompra.Checked = True Then
                        VerificarDcmtosIngreso(AnioDoc, NumDoc)
                    End If

                End If

                Me.Tag = "Mod"
                botonPagos.Enabled = True

            End If

        End If
    End Sub
    Private Sub ValidarFechaVencimiento()
        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader
        Dim strSQL As String
        Dim dtpVence As Date
        If celdaProveedor1.Text = NO_FILA Then
            celdaFecha1.Text = dtpFecha1.Value
            dtpFechaVence.Value = dtpFecha1.Value
            celdaFechaVence.Text = dtpFecha1.Value
        Else
            celdaFecha1.Text = dtpFecha1.Value
            strSQL = SQLFechaVence(celdaProveedor1.Text)
            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSQL, CON)
            REA = COM.ExecuteReader
            If REA.HasRows Then
                Do While REA.Read
                    If REA.GetInt32("plazo") = 0 Then
                    Else
                        dtpVence = DateAdd(DateInterval.Day, REA.GetInt32("plazo"), dtpFecha1.Value)
                        dtpFechaVence.Value = dtpVence
                        celdaFechaVence.Text = dtpFechaVence.Value
                    End If
                Loop
            End If
            COM = Nothing


        End If
    End Sub
    Private Sub ValidacionDiasCredito()
        Dim dtpFecha As Date
        Dim dtpFechaVen As Date
        dtpFecha = dtpFecha1.Value
        dtpFechaVen = dtpFechaVence.Value
        etiquetaDiaCredito.Text = (DateDiff(DateInterval.Day, dtpFecha, dtpFechaVen)) & " Credit Days"
    End Sub
    Private Sub dtpFecha1_ValueChanged(sender As Object, e As EventArgs) Handles dtpFecha1.ValueChanged
        ValidarFechaVencimiento()
        ValidacionDiasCredito()
        If celdaTasa.Text > 1 And rbImportación.Checked = False Then
            celdaTasa.Text = cfun.TasaSegunFecha(dtpFecha1.Value.ToString(FORMATO_MYSQL))
        End If
    End Sub

    Private Sub dtpFechaVence_ValueChanged(sender As Object, e As EventArgs) Handles dtpFechaVence.ValueChanged
        celdaFechaVence.Text = dtpFechaVence.Value
        ValidacionDiasCredito()
    End Sub

    Private Sub rbLocal_CheckedChanged(sender As Object, e As EventArgs) Handles rbLocal.CheckedChanged

        If rbLocal.Checked = True Then
            rbImportación.Checked = False
            rbOrdenDeCompra.Checked = False
            'checkContribuyent.Checked = False

            dgPoliza.Visible = False
            dgOrdenes.Visible = False
            gbPoliza.Visible = False
            'dgFacturas.Rows.Clear()
            'dgImpuestos.Rows.Clear()
            ' dgPoliza.Rows.Clear()

            If rbLocal.Checked = True Then
                celdaDetFact.Text = "INVOICE DETAIL"
                celdaDetFact.TextAlign = HorizontalAlignment.Left
                celdaDetFact.BackColor = Color.RoyalBlue
                celdaDetFact.ForeColor = Color.White
            End If

            If Sesion.IdEmpresa = 22 And rbOrdenDeCompra.Checked = True Then
                dgFacturas.Columns("loteNum").Visible = True
            Else
                dgFacturas.Columns("loteNum").Visible = False
            End If


            dgFacturas.Columns(0).Visible = False
            dgFacturas.Columns(1).Visible = False
            dgFacturas.Columns(2).Visible = False
            dgFacturas.Columns(3).Visible = False
            dgFacturas.Columns(4).Visible = False
            dgFacturas.Columns(5).Visible = True
            dgFacturas.Columns(6).Visible = True
            If Sesion.idGiro = 2 Then
                dgFacturas.Columns(7).Visible = True
            Else
                dgFacturas.Columns(7).Visible = False
            End If
            dgFacturas.Columns(8).Visible = True
            dgFacturas.Columns(9).Visible = True
            dgFacturas.Columns(10).Visible = False
            dgFacturas.Columns(11).Visible = False
            dgFacturas.Columns(12).Visible = False
            If Sesion.idGiro = 2 Then
                dgFacturas.Columns(13).Visible = True
            Else
                dgFacturas.Columns(13).Visible = False
            End If

            dgFacturas.Columns(14).Visible = False
            dgFacturas.Columns(15).Visible = True
            dgFacturas.Columns(16).Visible = False
            dgFacturas.Columns(17).Visible = True
            dgFacturas.Columns(18).Visible = True

            etiquetaSerie.Visible = True
            etiquetaInvoice.Visible = False

            If Not LogProceso Then
                DesgloseImpuestos()
                CalcuarImpuesto()
            End If

        End If

    End Sub

    Private Sub rbImportación_CheckedChanged(sender As Object, e As EventArgs) Handles rbImportación.CheckedChanged
        If rbImportación.Checked = True Then
            rbLocal.Checked = False
            rbOrdenDeCompra.Checked = False

            gbPoliza.Visible = True
            dgPoliza.Visible = True
            dgOrdenes.Visible = False
            ' dgFacturas.Rows.Clear()
            'dgImpuestos.Rows.Clear()
            If dgPoliza.RowCount > 0 Then
            Else
                dgPoliza.Rows.Clear()
            End If

            If Sesion.IdEmpresa = 22 And rbOrdenDeCompra.Checked = True Then
                dgFacturas.Columns("loteNum").Visible = True
            Else
                dgFacturas.Columns("loteNum").Visible = False
            End If


            dgFacturas.Columns(0).Visible = False
            dgFacturas.Columns(1).Visible = False
            dgFacturas.Columns(2).Visible = False
            dgFacturas.Columns(3).Visible = False
            dgFacturas.Columns(4).Visible = False
            dgFacturas.Columns(5).Visible = True
            dgFacturas.Columns(6).Visible = True
            If Sesion.idGiro = 2 Then
                dgFacturas.Columns(7).Visible = True
            Else
                dgFacturas.Columns(7).Visible = False
            End If
            dgFacturas.Columns(8).Visible = True
            dgFacturas.Columns(9).Visible = True
            dgFacturas.Columns(10).Visible = False
            dgFacturas.Columns(11).Visible = False
            dgFacturas.Columns(12).Visible = False
            If Sesion.idGiro = 2 Then
                dgFacturas.Columns(13).Visible = True
            Else
                dgFacturas.Columns(13).Visible = False
            End If
            dgFacturas.Columns(14).Visible = False
            dgFacturas.Columns(15).Visible = False
            dgFacturas.Columns(16).Visible = False
            dgFacturas.Columns(17).Visible = False
            dgFacturas.Columns(18).Visible = True
            etiquetaSerie.Visible = False
            etiquetaInvoice.Visible = True

            gbPoliza.Text = "Import Policy"

            If rbImportación.Checked = True Then
                celdaDetFact.Text = "DOES NOT GENERATE RIGHT TO TAX CREDIT"
                celdaDetFact.TextAlign = HorizontalAlignment.Center
                celdaDetFact.BackColor = Color.Red
                checkContribuyent.Checked = True
                If Not LogProceso Then
                    DesgloseImpuestos()
                    CalcuarImpuesto()
                End If
            End If
        End If
    End Sub

    Private Sub rbOrdenDeCompra_CheckedChanged(sender As Object, e As EventArgs) Handles rbOrdenDeCompra.CheckedChanged
        If rbOrdenDeCompra.Checked = True Then
            rbLocal.Checked = False
            rbImportación.Checked = False

            gbPoliza.Visible = True
            botonGenerarIngreso.Enabled = False
            botonGenerarIngreso.Visible = True
            dgPoliza.Visible = False
            dgOrdenes.Visible = True
            ' dgFacturas.Rows.Clear()
            dgPoliza.Rows.Clear()
            'dgImpuestos.Rows.Clear()

            gbPoliza.Text = "Purchase Order"
            etiquetaSerie.Visible = True
            etiquetaInvoice.Visible = False


            If Sesion.IdEmpresa = 22 And rbOrdenDeCompra.Checked = True Then
                dgFacturas.Columns("loteNum").Visible = True
            Else
                dgFacturas.Columns("loteNum").Visible = False
            End If



            If rbOrdenDeCompra.Checked = True Then
                celdaDetFact.Text = "INVOICE DETAIL"
                celdaDetFact.TextAlign = HorizontalAlignment.Left
                celdaDetFact.BackColor = Color.White
                celdaDetFact.ForeColor = Color.Black
            End If
            If Not LogProceso Then
                DesgloseImpuestos()
                CalcuarImpuesto()
            End If
        End If
    End Sub

    Private Sub checkContribuyent_CheckedChanged(sender As Object, e As EventArgs) Handles checkContribuyent.CheckedChanged

        logIVA = (checkContribuyent.Checked = False)

        If checkContribuyent.Checked = True Then
            celdaDetFact.Text = "DOES NOT GENERATE RIGHT TO TAX CREDIT"
            celdaDetFact.TextAlign = HorizontalAlignment.Center
            celdaDetFact.BackColor = Color.Red
        Else
            celdaDetFact.Text = "INVOICE DETAIL"
            celdaDetFact.TextAlign = HorizontalAlignment.Left
            celdaDetFact.BackColor = Color.White
            celdaDetFact.ForeColor = Color.Black
        End If

        If Not LogProceso Then
            DesgloseImpuestos()
            CalcuarImpuesto()
        End If

    End Sub
    Private Sub botonResolción_Click(sender As Object, e As EventArgs) Handles botonResolción.Click
        Dim frm As New frmSeleccionar
        Dim strCondicion As String = STR_VACIO

        Try
            frm.Titulo = "Regsiter"
            frm.Campos = " c.cat_num id, c.cat_desc tipo, c.cat_sist Numero "
            frm.Tabla = " Catalogos c "
            frm.FiltroText = " Enter the Resolution Name"
            'frm.Filtro = " pro_proveedor "
            frm.Condicion = " c.cat_clase = 'Serie' AND c.cat_clave = 'Doc_Resolucion' AND c.cat_pid = 0"
            'frm.Limite = 10
            frm.ShowDialog(Me)
            If frm.DialogResult = System.Windows.Forms.DialogResult.OK Then
                celdaIdResolución.Text = frm.LLave
                celdaResolucion.Text = frm.Dato2
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub
    Private Sub botonGenerarIngreso_Click(sender As Object, e As EventArgs) Handles botonGenerarIngreso.Click
        GeneraIngresoBodega()
    End Sub
    Private Function GeneraIngresoBodega()
        Dim numConfirmacion As Integer = INT_CERO
        Dim numDatosParaPolizas As Integer = INT_CERO
        Dim numPolizaImportacion As Integer = INT_CERO
        Dim numIngresoBodega As Integer = INT_CERO
        Dim strSQL As String = STR_VACIO
        Dim COM As New MySqlCommand
        Dim conec As MySqlConnection
        Dim COM2 As New MySqlCommand
        Dim conec2 As MySqlConnection
        Dim conta As New clsContabilidad
        If Sesion.idGiro = 2 Then

            If celdaAnioOc.Text = NO_FILA Then
                celdaAnioOc.Text = cFunciones.AñoMySQL
                celdaNumOc.Text = cfun.NuevoId(44)
            End If

            ' bloquea el boton para que pueda generar documentos solo una vez
            botonGenerarIngreso.Enabled = False

            'Genera Confirmacion de Embarque
            'Catalogo 127
            'numConfirmacion = cfun.NuevoId(127)
            ' GuardarEncabezadoConfirmacion(numConfirmacion)
            ' GuardarDetalleConfirmacion(numConfirmacion)
            ' GuardarDescargosConfirmacion(numConfirmacion)

            'Genera Datos para Poliza 
            'Catalogo 55
            'numDatosParaPolizas = cfun.NuevoId(55)
            ' GuardarEncabezadoDatosPoliza(numDatosParaPolizas)
            ' GuardarDetalleDatosPoliza(numDatosParaPolizas)
            ' GuardarDescargosDatosPoliza(numDatosParaPolizas, numConfirmacion)

            'Genera Poliza de Importación
            'Catalogo 180
            'numPolizaImportacion = cfun.NuevoId(180)
            '  GuardarEncabezadoPolizaImportacion(numPolizaImportacion)
            ' GuardarDetallePolizaImportacion(numPolizaImportacion)
            ' GuardarDescargosPolizaImportacion(numPolizaImportacion, numDatosParaPolizas)

            'Genera Ingreso a Bodega
            'Catalogo 47
            numIngresoBodega = cfun.NuevoId(47, celdaAnioOc.Text)
            GuardarEncabezadoIngresoBodega(numIngresoBodega)
            GuardarDetalleIngresoBodega(numIngresoBodega)
            GuardarDescargosIngresoBodega(numIngresoBodega, numPolizaImportacion)
            If cFunciones.SQLVerificarCierre(47, celdaAnioOc.Text, numIngresoBodega) = 0 Then
                conta.GenerarPoliza(47, celdaAnioOc.Text, numIngresoBodega, dtpFecha1.Value)
            Else ' Si hay cierre guarda la fecha de hoy
                conta.GenerarPoliza(47, celdaAnioOc.Text, numIngresoBodega, cFunciones.HoyMySQL.ToString(FORMATO_MYSQL))
            End If
            BloquearFel()
            MsgBox("Income generated", vbInformation)
        End If

    End Function
    Private Sub dgLista_KeyDown(sender As Object, e As KeyEventArgs) Handles dgLista.KeyDown
        Try
            If e.KeyCode = Keys.F3 Then
                cFunciones.BuscarenLista(dgLista)
                e.Handled = True
                e.SuppressKeyPress = True
            ElseIf e.KeyCode = Keys.F6 Then
                cfun.MostrarDependencias(dgLista.SelectedCells(1).Value, dgLista.SelectedCells(2).Value, dgLista.SelectedCells(3).Value)
            ElseIf e.KeyCode = Keys.F7 Then
                Dim rpt As New clsReportes
                rpt.Historial(dgLista.SelectedCells(3).Value, dgLista.SelectedCells(2).Value, dgLista.SelectedCells(1).Value)
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub


#End Region
    Private Sub botonImprimir_Click(sender As Object, e As EventArgs) Handles botonImprimir.Click
        Dim strToken As String = STR_VACIO
        Dim strUUID As String = STR_VACIO
        Dim IP As String = STR_VACIO
        Dim strUsuario As String = STR_VACIO
        Dim strContrasena As String = STR_VACIO
        Dim strRuta As String = STR_VACIO
        Dim strSQL As String = STR_VACIO
        Dim COM As MySqlCommand
        If Sesion.IdEmpresa = 14 Then
            ImprimirFormatoDominicana()
        Else
            If celdaSerieFel.Text = STR_VACIO Then
                If CheckFactEspecial.Checked = True Then
                    If VerificarAcceso(IP, strUsuario, strContrasena, strRuta) = True Then
                        If MsgBox("Esta a punto de transmitir esta factura a SAT " & vbNewLine & "Esta seguro que desea continuar? El proceso sera irreversible ", vbQuestion + vbYesNo + vbDefaultButton2) = vbYes Then
                            If VerificarDocumentoXML(strToken, strUUID) = INT_CERO Then
                                If ImpresionFel(celdaAnioOc.Text, celdaNumOc.Text, strToken, strUUID, IP, strUsuario, strContrasena, strRuta) = True Then
                                    strSQL = STR_VACIO
                                    strSQL = "UPDATE Dcmtos_HDR h"
                                    strSQL &= " SET h.HDoc_Doc_Fec = CURDATE()"
                                    strSQL &= " WHERE h.HDoc_Sis_Emp = {empresa} and h.HDoc_Doc_Cat = {catalogo} and h.HDoc_Doc_Ano = {anio} and h.HDoc_Doc_Num = {numero}"
                                    If Sesion.IdEmpresa = 18 Then
                                        strSQL &= ";UPDATE PDM.Dcmtos_HDR h"
                                        strSQL &= " SET h.HDoc_Doc_Fec = CURDATE()"
                                        strSQL &= " WHERE h.HDoc_Sis_Emp = {empresa} and h.HDoc_Doc_Cat = {catalogo} and h.HDoc_Doc_Ano = {anio} and h.HDoc_Doc_Num = {numero}"

                                    End If
                                    strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
                                    strSQL = Replace(strSQL, "{anio}", celdaAnioOc.Text)
                                    strSQL = Replace(strSQL, "{numero}", celdaNumOc.Text)
                                    strSQL = Replace(strSQL, "{catalogo}", celdaCatOc.Text)
                                    'Ejecuta la instrucción
                                    MyCnn.CONECTAR = strConexion
                                    COM = New MySqlCommand(strSQL, CON)
                                    COM.ExecuteNonQuery()
                                End If
                            Else
                                MsgBox("El documento ya ha sido transmitido")
                            End If
                        Else
                            Exit Sub
                        End If
                    Else
                        Exit Sub
                    End If
                End If
            Else
                If VerificarAcceso(IP, strUsuario, strContrasena, strRuta) = True Then
                    ImprimirPDFGenerado(IP, strUsuario, strContrasena, strRuta)
                End If
            End If
        End If
    End Sub

    Private Sub Encabezado1_ClickBorrar(sender As Object, click As Boolean) Handles Encabezado1.ClickBorrar
        If LogBorrar = True Then
            If DependeciasFacturaCompra() > INT_CERO Then
                MsgBox("This Document can not be canceled, is related to other agencies", MsgBoxStyle.Critical, "Warning")
                cfun.MostrarDependencias(celdaCatOc.Text, celdaAnioOc.Text, celdaNumOc.Text)
            ElseIf DependeciasVarias() > INT_CERO Then
                MsgBox("This Document can not be canceled, is related to other agencies", MsgBoxStyle.Critical, "Warning")
                ' cfun.MostrarDependencias(44, celdaAnioOc.Text, celdaNumOc.Text)
            Else
                If MsgBox("Are You sure " & vbCr & vbCr & "¿do you want to delete this document? ", vbQuestion + vbYesNo, "Aviso") = vbYes Then
                    BorrarEncabezadoFacturaCompra()
                    BorrarDetalleFacturaCompra()
                    '    BorrarAccFacturaCompra()
                    BorrarImpuestosDoc()
                    BorrarDescargosFacturaCompra()
                    BorrarEctateFacturaCompra()
                    cFunciones.BorrarEncabezadoPoliza(celdaNumOc.Text, celdaAnioOc.Text, celdaCatOc.Text)
                    cFunciones.BorrarDetallePoliza(celdaNumOc.Text, celdaAnioOc.Text, celdaCatOc.Text)
                    cFunciones.EscribirRegistro(Tbl_Documentos, clsFunciones.AccEnum.acDelete, celdaProveedor1.Text, celdaCatOc.Text, celdaAnioOc.Text, celdaNumOc.Text)
                    MsgBox("Delete Complete")
                    MostrarLista()
                End If
            End If
        End If
    End Sub

    Private Sub checkActive_CheckStateChanged(sender As Object, e As EventArgs) Handles checkActive.CheckStateChanged
        'If checkActive.Checked = True Then
        '    Encabezado1.botonGuardar.Enabled = False
        'End If
    End Sub

    Private Sub frmFacturaCompra_FormClosing(sender As Object, e As FormClosingEventArgs) Handles Me.FormClosing
        Fprincipal.BarraDeTareas1.QuitarFormulario(strKey)
    End Sub
    Private Sub botonPrevio_Click(sender As Object, e As EventArgs) Handles botonPrevio.Click
        If CheckFactEspecial.Checked = True Then
            ImprimirFactruaEspecial()
        End If
    End Sub

    Private Sub CheckFactEspecial_CheckedChanged(sender As Object, e As EventArgs) Handles CheckFactEspecial.CheckedChanged
        If CheckFactEspecial.Checked = True Then
            checkActive.Visible = True
            checkActive.Checked = True
        Else
            checkActive.Visible = False

        End If
    End Sub

    Private Sub celdaTasa_TextChanged(sender As Object, e As EventArgs) Handles celdaTasa.TextChanged
        If intControlador = NO_FILA Then
            If celdaTasa.Text.LongCount >= 1 Then
                ActualizarTotal()
                If celdaCatOc.Text <> "" Then
                    CalcuarImpuesto()
                End If
            End If
        End If

    End Sub
    Private Sub BotonNotas_Click(sender As Object, e As EventArgs) Handles BotonNotas.Click
        ActualizarNotasFechaVec()
    End Sub

    Private Sub botonDocumentos_Click(sender As Object, e As EventArgs) Handles botonDocumentos.Click
        Dim frm As New frmSeleccionar
        Dim strTabla As String = STR_VACIO

        Try
            If (Sesion.IdEmpresa = 15) Or (Sesion.IdEmpresa = 11) Or (Sesion.IdEmpresa = 12) Or (Sesion.IdEmpresa = 14) Or (Sesion.IdEmpresa = 16) Or (Sesion.IdEmpresa >= 18) Then
                strTabla = " Catalogos c "
                frm.Titulo = "Document"
                frm.Campos = "c.cat_num ID, c.cat_desc Descripcion "
                frm.Tabla = strTabla
                frm.Condicion = " c.cat_clase ='Documentos' AND c.cat_sisemp = " & Sesion.IdEmpresa
            Else
                strTabla = "(SELECT DISTINCT BMov_Cat_Doc ID From MvtosBcos "
                '   strTabla = Replace(strTabla, "{empresa}", Sesion.IdEmpresa)
                '  strTabla = Replace(strTabla, "{cod}", celdaCodigo.Text)
                frm.Titulo = "Document"
                frm.Campos = "a.ID, c.cat_desc Descripcion "
                frm.Tabla = strTabla
                frm.Condicion = "  BMov_Sis_Emp = " & Sesion.IdEmpresa & " AND BMov_Cat_Doc > 0) a LEFT JOIN Catalogos c ON c.cat_num = a.ID WHERE c.cat_num IN(44,209)"
            End If
            frm.ShowDialog(Me)
            If frm.DialogResult = System.Windows.Forms.DialogResult.OK Then
                dgImpuestos.Rows.Clear()
                celdaCatOc.Text = frm.LLave
                celdaDetalleDocumento.Text = frm.Dato
                If celdaCatOc.Text = 44 Then            'factura
                    BloquearCuandoEsRecibo(False)
                    DesgloseImpuestos()
                    celdaProveedor.ReadOnly = True
                    celdaNumero.Text = INT_CERO
                    botonMas.Enabled = False
                ElseIf celdaCatOc.Text = 209 Then       'recibo
                    celdaNumero.Text = INT_CERO
                    celdaNumero.Text = 0 & cFunciones.NuevoId(celdaCatOc.Text)
                    celdaidProveedores.Text = 0
                    BloquearCuandoEsRecibo(True)
                    botonMas.Enabled = False
                    celdaProveedor.ReadOnly = True
                    'ValidarFechaVencimiento()
                Else
                    Exit Sub
                End If
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub
    Public Sub BloquearCuandoEsRecibo(ByVal bloqueo As Boolean)
        If bloqueo = False Then
            checkContribuyent.Enabled = True
            checkFacElectrónica.Enabled = True
            CheckFactEspecial.Enabled = True
            rbImportación.Enabled = True
            rbLocal.Enabled = True
            rbOrdenDeCompra.Enabled = True
        Else
            checkContribuyent.Enabled = False
            checkFacElectrónica.Enabled = False
            CheckFactEspecial.Enabled = False
            rbImportación.Enabled = False
            rbLocal.Enabled = True
            rbOrdenDeCompra.Enabled = False
        End If

    End Sub

    ' Valida al momento de Editar
    Public Function AutorizarGuardar(ByVal Tipo As Integer) As Boolean
        AutorizarGuardar = True
        If Tipo.Equals(44) Then
            Const STR_MARGEN As String = "MOD_FACTURA_COMPRA"
            Dim frm As frmAutorización
            AutorizarGuardar = False
            frm = New frmAutorización
            frm.Iniciar(Tipo, STR_MARGEN, 0, "Authorize Edit")
            frm.ShowDialog(Me)
            If frm.Aceptado Then
                AutorizarGuardar = True
            End If
        End If
    End Function
End Class