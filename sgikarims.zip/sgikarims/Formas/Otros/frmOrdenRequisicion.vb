﻿Public Class frmOrdenRequisicion
#Region "Variables"
    Dim strkey As String = STR_VACIO
    Dim logInsertar As Boolean = False
    Dim logConsultar As Boolean = False
    Dim logEditar As Boolean = False
    Dim LogBorrar As Boolean = False
    Dim SDoc As New frmSubDocumentos
    Public Const catalogos = 38
#End Region

#Region "Propiedades"
    Public Property key As String
        Get
            Return strkey
        End Get
        Set(value As String)
            strkey = value
        End Set
    End Property

#End Region

#Region "Funciones"
    Private Function sqlLista() As String
        Dim strSQL As String = STR_VACIO

        strSQL = "SELECT HDoc_Doc_Ano ano, HDoc_Doc_Num numero, HDoc_Doc_Fec fecha, HDoc_Emp_Nom nombre, HDoc_Emp_Per contacto,  "
        strSQL &= "IF(IFNULL(HDoc_DR1_Num,'')='','',HDoc_DR1_Num) referencia, HDoc_Doc_Status estado, IFNULL(( "
        strSQL &= "SELECT GROUP_CONCAT(DISTINCT TRIM(DDoc_RF1_Cod) SEPARATOR ', ') "
        strSQL &= "FROM Dcmtos_DTL "
        strSQL &= "WHERE DDoc_Sis_Emp=HDoc_Sis_Emp AND DDoc_Doc_Cat=HDoc_Doc_Cat AND DDoc_Doc_Ano=HDoc_Doc_Ano AND DDoc_Doc_Num=HDoc_Doc_Num),'') ordenes, IFNULL(( "
        strSQL &= "SELECT COUNT(*) "
        strSQL &= "FROM Dcmtos_DTL_Pro "
        strSQL &= "WHERE PDoc_Sis_Emp=HDoc_Sis_Emp AND PDoc_Par_Cat=HDoc_Doc_Cat AND PDoc_Par_Ano=HDoc_Doc_Ano AND PDoc_Par_Num=HDoc_Doc_Num  "
        strSQL &= "AND PDoc_Chi_Cat=127),0) descargo, ( "
        strSQL &= "SELECT COUNT(*) "
        strSQL &= "FROM Dcmtos_DTL "
        strSQL &= "WHERE DDoc_Sis_Emp=HDoc_Sis_Emp AND DDoc_Doc_Cat=HDoc_Doc_Cat AND DDoc_Doc_Ano=HDoc_Doc_Ano  "
        strSQL &= "AND DDoc_Doc_Num=HDoc_Doc_Num AND DDoc_RF2_Num=0) pendiente, IFNULL(( "
        strSQL &= "SELECT SUM(cantidad) "
        strSQL &= "FROM Reserva "
        strSQL &= "WHERE id_empresa=HDoc_Sis_Emp AND doc_tipo=HDoc_Doc_Cat AND doc_ciclo=HDoc_Doc_Ano AND doc_num=HDoc_Doc_Num  "
        strSQL &= "AND estado IN (0,1)),0) apartado "
        strSQL &= "FROM Dcmtos_HDR WHERE HDoc_Sis_Emp= {empresa} AND HDoc_Doc_Cat=38  "

        If chkFecha.Checked = True Then

            strSQL &= " AND (HDoc_Doc_Fec BETWEEN '{fechainicio}' AND '{fechafin}') "

            strSQL = Replace(strSQL, "{fechainicio}", dtpInicio.Value.ToString(FORMATO_MYSQL))
            strSQL = Replace(strSQL, "{fechafin}", dtpFinal.Value.ToString(FORMATO_MYSQL))

        End If

        strSQL &= "ORDER BY HDoc_Doc_Ano DESC, HDoc_Doc_Num DESC "
        strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)

        Return strSQL

    End Function

    Private Function sqlDocumentos(ByVal Año As Integer, ByVal numero As Integer) As String
        Dim strSQL As String = STR_VACIO


        strSQL = " SELECT cat_clave, cat_desc, ( "
        strSQL &= " SELECT COUNT(*) "
        strSQL &= " FROM Dcmtos_ACC "
        strSQL &= "  WHERE ADoc_Sis_Emp = {empresa} AND ADoc_Doc_Cat = 38 AND ADoc_Doc_Ano = {Año} AND ADoc_Doc_Num = {numero} AND ADoc_Doc_Sub = cat_clave) AS Cantidad "
        strSQL &= " FROM Catalogos "
        strSQL &= " WHERE cat_clase = 'SubDcmtos' AND cat_sist = 'Doc_POrd/Com'"
        strSQL &= " ORDER BY cat_clave "

        strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
        strSQL = Replace(strSQL, "{Año}", Año)
        strSQL = Replace(strSQL, "{numero}", numero)
        Return strSQL
    End Function
    Public Sub CargardgDocumentos(ByVal Año As Integer, ByVal numero As Integer)
        Dim strSQL = sqlDocumentos(Año, numero)
        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader
        Dim strFila As String = STR_VACIO
        Dim cantidad As Integer
        Try

            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSQL, CON)
            REA = COM.ExecuteReader
            If REA.HasRows Then
                Do While REA.Read
                    strFila = REA.GetString("cat_clave") & "|"
                    strFila &= REA.GetString("cat_desc") & "|"
                    cantidad = REA.GetInt32("Cantidad")
                    If cantidad > 0 Then
                        strFila &= "Si"
                    Else

                        ' strFila &= REA.GetString("cat_clave") & "|"
                        strFila &= "No"
                    End If



                    cFunciones.AgregarFila(dgdatos, strFila)
                Loop
            End If
            'REA.Close()
            'COM = Nothing
            'REA = Nothing
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub
    Public Sub queryListaOrden()
        Dim strSQL As String = STR_VACIO
        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader
        Dim strFila As String = STR_VACIO
        Try
            strSQL = sqlLista()
            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSQL, CON)
            REA = COM.ExecuteReader
            dgLista.Rows.Clear()
            Do While REA.Read
                strFila = REA.GetInt32("ano") & "|"
                strFila &= REA.GetInt32("numero") & "|"
                strFila &= REA.GetDateTime("fecha").ToString(FORMATO_MYSQL) & "|"
                strFila &= REA.GetString("nombre") & "|"
                strFila &= REA.GetString("contacto") & "|"
                strFila &= REA.GetString("referencia") & IIf(REA.GetString("ordenes") = STR_VACIO, STR_VACIO, " / " & REA.GetString("ordenes"))

                If REA.GetInt32("estado") = vbEmpty Then
                    cFunciones.AgregarFila(dgLista, strFila, Color.Red)
                ElseIf REA.GetInt32("pendiente") > vbEmpty Then
                    If REA.GetInt32("descargo") = vbEmpty Then
                        cFunciones.AgregarFila(dgLista, strFila, Color.Bisque)
                    Else
                        cFunciones.AgregarFila(dgLista, strFila, Color.LightGoldenrodYellow)
                    End If
                Else
                    cFunciones.AgregarFila(dgLista, strFila)
                End If
            Loop
            'dgLista.AlternatingRowsDefaultCellStyle.BackColor = Color.AntiqueWhite '
            'REA.Close()
            'REA = Nothing
            'COM = Nothing
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try

    End Sub
    Private Sub BloquearBotones(Optional ByVal logBloquear As Boolean = True)
        If logBloquear = True Then
            Encabezado1.botonBorrar.Enabled = False
            Encabezado1.botonGuardar.Enabled = False
            Encabezado1.botonNuevo.Enabled = True
            botonImprimir.Enabled = False
        Else
            If LogBorrar = True Then
                Encabezado1.botonBorrar.Enabled = True
            Else
                Encabezado1.botonBorrar.Enabled = False
            End If
            Encabezado1.botonGuardar.Enabled = True
            botonImprimir.Enabled = True
        End If

    End Sub
    Private Sub Accessos()
        Dim cAccesos As New clsAccesos
        Try
            If cAccesos.Accesos(strkey) = True Then
                logInsertar = cAccesos.Insertar
                logConsultar = cAccesos.Consultar
                logEditar = cAccesos.Editar
                LogBorrar = cAccesos.Borrar
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try

    End Sub
    Private Sub Reset()
        CeldaReferencia.Text = STR_VACIO
        CeldaMoneda.Text = STR_VACIO
        CeldaAño.Text = cFunciones.HoyMySQL
        CeldaNumero.Text = -1
        checkIntercompany.Checked = False
        checkJob.Checked = False
        rbJoMark.Checked = True
        celdaJob.Text = INT_CERO
        celdaPrice.Text = STR_VACIO
        'CeldaNombre.Text = STR_VACIO
        celdaCelular.Text = STR_VACIO
        celdaContactoProveedor.Text = STR_VACIO
        celdaNit.Text = STR_VACIO
        celdaidCliente.Text = INT_CERO
        celdaIdCliente2.Text = INT_CERO
        CeldaCliente.Text = STR_VACIO
        celdaCliente1.Text = STR_VACIO
        celdaContactoCliente.Text = STR_VACIO
        CeldaPedido.Text = STR_VACIO
        celdanumero1.Text = INT_CERO
        celdaAnio.Text = INT_CERO
        celdaCatalogo.Text = INT_CERO
        CeldaDireccion.Text = STR_VACIO
        celdaidMoneda.Text = 0
        CeldaTasa.Text = INT_CERO
        CeldaCantidad.Text = STR_VACIO
        CeldaTotal.Text = STR_VACIO
        dgvDetalle.Rows.Clear()
        dgdatos.Rows.Clear()
        dgvDescargos.Rows.Clear()
        dtpFecha.Value = Now()
        celdaContrato.Clear()
        CeldaObservacion.Clear()
        CeldaInfo1.Text = "'"
        CeldaInfo2.Text = "'"
        celdaDiasCredito.Clear()

    End Sub
    Private Function ComprobarDatos() As Boolean
        Dim logVerdadero As Boolean = True
        If celdaCliente1.Text = vbNullString Then
            MsgBox("BLANK NAME ")
            logVerdadero = False
            Exit Function
        End If
        If CeldaReferencia.Text = vbNullString Then
            MsgBox("BLANK REFERENCE")
            logVerdadero = False
            Exit Function
        End If
        Return logVerdadero
    End Function
    Private Function ComprobarFila() As Boolean
        Dim LogVerdadero As Boolean = True
        If dgvDetalle.Rows.Count = 0 Then
            MsgBox("Fill all fields", MsgBoxStyle.Critical)
            LogVerdadero = False
        Else
            LogVerdadero = True
        End If

        For i As Integer = 0 To dgvDetalle.RowCount - 1
            If dgvDetalle.Rows(i).Visible = True Then
                If dgvDetalle.Rows(i).Cells("colCodigo").Value = STR_VACIO Then
                    LogVerdadero = False
                    MsgBox("Blank Code")
                End If
                If dgvDetalle.Rows(i).Cells("colDescripcion").Value = vbNullString Then
                    MsgBox("Blank Product")
                    LogVerdadero = False
                End If

                If dgvDetalle.Rows(i).Cells("colCantidad").Value = INT_CERO Then
                    MsgBox("Amount invalid please add another number")
                    LogVerdadero = False
                End If
                If dgvDetalle.Rows(i).Cells("colStatus").Value = "Sold" Then
                    If (dgvDetalle.Rows(i).Cells("colidVendido").Value = INT_CERO) Then
                        MsgBox("Blank sold to")
                        LogVerdadero = False
                    End If

                End If
            End If
        Next
        Return LogVerdadero
    End Function
    Public Sub MostrarLista(Optional ByVal logMostrar As Boolean = True)

        If logMostrar = True Then

            PanelLista.Visible = True
            PanelLista.Dock = DockStyle.Fill
            BarraTitulo1.CambiarTitulo("Listado")
            BloquearBotones(True)
            queryListaOrden()
            pnlOrder.Visible = False
            pnlOrder.Dock = DockStyle.None

        Else
            PanelLista.Visible = False
            PanelLista.Dock = DockStyle.None
            BarraTitulo1.CambiarTitulo("Order/Requisicion")
            pnlOrder.Visible = True
            pnlOrder.Dock = DockStyle.Fill
            BloquearBotones(False)

        End If

    End Sub
    Public Sub CargarHilo(ByVal intHilo As Integer, ByVal Linea As Integer)
        Dim strSQL As String = STR_VACIO
        Dim COM2 As MySqlCommand
        Dim REA2 As MySqlDataReader
        Dim conec As New MySqlConnection

        conec.ConnectionString = strConexion
        conec.Open()
        Try

            strSQL = " SELECT a.art_DLarga descripcion, COALESCE(p.cat_clave,'') pais, COALESCE(v.pro_proveedor,'') proveedor, m.cat_clave Medida "
            strSQL &= " FROM Inventarios i "
            strSQL &= " INNER JOIN Articulos a ON a.art_sisemp = i.inv_sisemp AND a.art_codigo = i.inv_artcodigo "
            strSQL &= " LEFT JOIN Catalogos m ON m.cat_clase = 'Medidas' AND m.cat_num = inv_UMventa "
            strSQL &= " LEFT JOIN Catalogos p ON p.cat_clase = 'Paises' AND p.cat_num = i.inv_lugarfab "
            strSQL &= " LEFT JOIN Proveedores v ON v.pro_sisemp = i.inv_sisemp AND v.pro_codigo = i.inv_provcod "
            strSQL &= " WHERE i.inv_sisemp={empresa} AND i.inv_numero={codigo} "
            strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
            strSQL = Replace(strSQL, "{codigo}", intHilo)

            COM2 = New MySqlCommand(strSQL, conec)
            REA2 = COM2.ExecuteReader
            If REA2.HasRows Then
                Do While REA2.Read
                    For i As Integer = 0 To dgvDetalle.Rows.Count - 1

                        If REA2.GetString("proveedor") = vbNullString Then
                            CeldaInfo2.Text = REA2.GetString("descripcion") & "  " & REA2.GetString("pais")
                        Else
                            CeldaInfo2.Text = REA2.GetString("descripcion") & "  " & REA2.GetString("pais") & "/" & REA2.GetString("proveedor")
                        End If
                        ' Contador = Contador + 1

                    Next
                    CeldaInfo1.Text = Linea
                Loop
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        Finally
            conec.Close()
        End Try
        'REA.Close()
        'REA = Nothing
        'COM = Nothing
    End Sub
    Private Function sqlEncabezado(ByVal Codigo As Integer, ByVal anio As Integer) As String
        Dim strSQL As String = STR_VACIO
        strSQL = " SELECT e.HDoc_RF1_Txt credito, e.HDoc_Emp_Cod Codigo,e.HDoc_Doc_Status Estado,e.HDoc_Doc_Ano Anio, e.HDoc_Doc_Fec Fecha, e.HDoc_Emp_Nom Proveedor, e.HDoc_Emp_Dir Direccion, e.HDoc_Emp_Per Contacto,e.HDoc_Emp_Tel Telefono,e.HDoc_Emp_NIT NIT,c.cat_clave,e.HDoc_Doc_Mon,e.HDoc_Doc_TC Tasa,e.HDoc_DR1_Num Referencia,IFNULL(e.HDoc_DR1_Emp,0) cliente,IFNULL(cl.cli_cliente,'') Cliente,e.HDoc_RF1_Cod ContactoCliente ,e.HDoc_Pro_DCat Catalogo , e.HDoc_Pro_DAno Anio , e.HDoc_Pro_DNum Numero, IFNULL(e.HDoc_RF2_Cod,'') contrato, e.HDoc_RF2_Txt observacion, e.HDoc_Ant_Com,e.HDoc_DR1_Dbl Job ,e.HDoc_DR2_Num Precio"
        strSQL &= " FROM Dcmtos_HDR e "
        strSQL &= " LEFT JOIN Catalogos c ON c.cat_num = e.HDoc_Doc_Mon "
        strSQL &= " LEFT JOIN Clientes cl ON cl.cli_sisemp = e.HDoc_Sis_Emp AND cl.cli_codigo = e.HDoc_DR1_Emp "
        strSQL &= " WHERE e.HDoc_Sis_Emp={empresa} AND e.HDoc_Doc_Cat=38 AND e.HDoc_Doc_Ano={anio} AND e.HDoc_Doc_Num={numero} "
        strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
        strSQL = Replace(strSQL, "{anio}", anio)
        strSQL = Replace(strSQL, "{numero}", Codigo)

        Return strSQL
    End Function
    Private Function sqlDetalle(ByVal Codigo As Integer) As String
        Dim strSQL As String = STR_VACIO

        strSQL = " SELECT d.DDoc_Prd_DSQ MKT, d.DDoc_Doc_Lin Fila, d.DDoc_Prd_Cod Codigo, d.DDoc_Prd_Des Descripcion, COALESCE(c.cat_clave,'') Medida, d.DDoc_Prd_UM Unidad, d.DDoc_RF2_Dbl FOB, d.DDoc_RF3_Dbl CIF, d.DDoc_Prd_Net Precio, d.DDoc_Prd_Qty Cantidad, (d.DDoc_RF3_Dbl * d.DDoc_Prd_Qty) Total, COALESCE(p.PDoc_Par_Ano,0) Anio, COALESCE(p.PDoc_Par_Num,0) Numero, COALESCE(p.PDoc_Par_Lin,0) Linea, IFNULL(d.DDoc_RF1_Num,0) id_fabricante, IFNULL(o.pro_proveedor,'') Fabricante, IFNULL(d.DDoc_RF1_Cod,'') Orden, IFNULL(d.DDoc_RF1_Fec,'') Fecha, IFNULL(d.DDoc_RF2_Cod,'') Programa, IFNULL(d.DDoc_RF2_Num,0) Estado, IFNULL(cc.cli_cliente,'') NombreCliente ,IFNULL(cc.cli_codigo,0) CodigoCliente,MAX(IFNULL(d127.DDoc_RF1_Fec,'')) FechaETD,d127.DDoc_Doc_Num , IFNULL(( "
        strSQL &= " SELECT SUM(cantidad) "
        strSQL &= " FROM Reserva "
        strSQL &= " WHERE id_empresa=d.DDoc_Sis_Emp AND doc_tipo=d.DDoc_Doc_Cat AND doc_ciclo=d.DDoc_Doc_Ano AND doc_num=d.DDoc_Doc_Num AND doc_lin=d.DDoc_Doc_Lin AND NOT(estado=2)),0) Apartado,IFNULL(d.DDoc_RF3_Num,-1) IDP, IFNULL(d.DDoc_RF3_Txt,'') Pais,   "
        strSQL &= " ifnull(( "
        strSQL &= " SELECT SUM(ifnull(IDoc_Itm_QTY,0)) "
        strSQL &= " FROM Dcmtos_DTL_Itm "
        strSQL &= " WHERE IDoc_Sis_Emp=d.DDoc_Sis_Emp AND IDoc_Doc_Cat=d.DDoc_Doc_Cat AND IDoc_Doc_Ano=d.DDoc_Doc_Ano AND IDoc_Doc_Num=d.DDoc_Doc_Num AND IDoc_Doc_Lin=d.DDoc_Doc_Lin AND IFNULL(IDoc_RF1_Txt,'')='DESPACHO'),0) Despacho, IF(d.DDoc_Prd_Fob = 0, 'Unsold', 'Sold') estado, IFNULL(d.DDoc_Prd_PNr,'') Vendido_A, IFNULL(d.DDoc_RF4_Txt,'') certification "
        strSQL &= " FROM Dcmtos_DTL d "
        strSQL &= " LEFT JOIN Dcmtos_DTL_Pro p ON p.PDoc_Sis_Emp = d.DDoc_Sis_Emp AND p.PDoc_Par_Cat = 74 AND p.PDoc_Chi_Cat = 38 AND p.PDoc_Chi_Ano = d.DDoc_Doc_Ano AND p.PDoc_Chi_Num = d.DDoc_Doc_Num AND p.PDoc_Chi_Lin = d.DDoc_Doc_Lin"
        strSQL &= " LEFT JOIN Catalogos c ON c.cat_clase = 'Medidas' AND c.cat_num = d.DDoc_Prd_UM "
        strSQL &= " LEFT JOIN Inventarios i ON i.inv_sisemp = {empresa} AND i.inv_numero = d.DDoc_Prd_Cod "
        strSQL &= " LEFT JOIN Proveedores o ON o.pro_sisemp = {empresa} AND o.pro_codigo = d.DDoc_RF1_Num"
        strSQL &= " LEFT JOIN Clientes cc ON cc.cli_sisemp = d.DDoc_Sis_Emp AND cc.cli_codigo  = d.DDoc_Prd_PUQ"
        strSQL &= "  LEFT JOIN Dcmtos_DTL_Pro dp127 ON dp127.PDoc_Sis_Emp = d.DDoc_Sis_Emp AND dp127.PDoc_Par_Cat = d.DDoc_Doc_Cat AND dp127.PDoc_Par_Ano = d.DDoc_Doc_Ano AND dp127.PDoc_Par_Num = d.DDoc_Doc_Num AND dp127.PDoc_Par_Lin = d.DDoc_Doc_Lin AND dp127.PDoc_Chi_Cat = 127 "
        strSQL &= " LEFT JOIN Dcmtos_DTL d127 ON d127.DDoc_Sis_Emp = dp127.PDoc_Sis_Emp AND d127.DDoc_Doc_Cat = dp127.PDoc_Chi_Cat AND d127.DDoc_Doc_Ano = dp127.PDoc_Chi_Ano  AND d127.DDoc_Doc_Num = dp127.PDoc_Chi_Num AND d127.DDoc_Doc_Lin = dp127.PDoc_Chi_Lin  "
        strSQL &= " WHERE d.DDoc_Sis_Emp = {empresa} AND d.DDoc_Doc_Cat = 38 AND d.DDoc_Doc_Ano = {anio} AND d.DDoc_Doc_Num = {codigo} "
        strSQL &= " GROUP BY d.DDoc_Doc_Cat, d.DDoc_Doc_Ano, d.DDoc_Doc_Num, d.DDoc_Doc_Lin"
        strSQL &= " ORDER BY d.DDoc_Doc_Lin "

        strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
        strSQL = Replace(strSQL, "{anio}", CeldaAño.Text)
        strSQL = Replace(strSQL, "{codigo}", Codigo)

        Return strSQL
    End Function
    Private Function SQLDescargos(ByVal Codigo As Integer, ByVal Anio As Integer) As String
        Dim strSQL As String = STR_VACIO

        strSQL = " SELECT * "
        strSQL &= " FROM (( "
        strSQL &= " SELECT r.PDoc_Par_Lin Linea, r.PDoc_QTY_Pro Cantidad, r.PDoc_Chi_Ano Anio, r.PDoc_Chi_Num Numero, IFNULL(e.HDoc_DR1_Num,'(SIN REF.)') Documento, r.PDoc_Chi_Lin Fila, 'C' Clase, ( "
        strSQL &= " SELECT COUNT(*) "
        strSQL &= " FROM Dcmtos_DTL_Pro a "
        strSQL &= " LEFT JOIN Dcmtos_DTL_Pro m ON m.PDoc_Sis_Emp=a.PDoc_Sis_Emp AND m.PDoc_Par_Cat=a.PDoc_Chi_Cat AND m.PDoc_Par_Ano=a.PDoc_Chi_Ano AND m.PDoc_Par_Num=a.PDoc_Chi_Num AND m.PDoc_Par_Lin=a.PDoc_Chi_Lin "
        strSQL &= " LEFT JOIN Dcmtos_DTL_Pro n ON n.PDoc_Sis_Emp=m.PDoc_Sis_Emp AND n.PDoc_Par_Cat=m.PDoc_Chi_Cat AND n.PDoc_Par_Ano=m.PDoc_Chi_Ano AND n.PDoc_Par_Num=m.PDoc_Chi_Num AND n.PDoc_Par_Lin=m.PDoc_Chi_Lin  AND n.PDoc_Chi_Cat=47  "
        strSQL &= " WHERE a.PDoc_Sis_Emp=r.PDoc_Sis_Emp AND a.PDoc_Par_Cat=r.PDoc_Chi_Cat AND a.PDoc_Par_Ano=r.PDoc_Chi_Ano AND a.PDoc_Par_Num=r.PDoc_Chi_Num AND a.PDoc_Par_Lin=r.PDoc_Chi_Lin AND NOT(ISNULL(n .PDoc_Sis_Emp))) Ingreso "
        strSQL &= " FROM Dcmtos_DTL_Pro r "
        strSQL &= " LEFT JOIN Dcmtos_HDR e ON e.HDoc_Sis_Emp=r.PDoc_Sis_Emp AND e.HDoc_Doc_Cat=r.PDoc_Chi_Cat AND e.HDoc_Doc_Ano=r.PDoc_Chi_Ano AND e.HDoc_Doc_Num=r.PDoc_Chi_Num "
        strSQL &= " WHERE r.PDoc_Sis_Emp={empresa} AND r.PDoc_Par_Cat={catalogo} AND r.PDoc_Par_Ano={anio} AND r.PDoc_Par_Num={codigo} AND r.PDoc_Chi_Cat=127) UNION ( "
        strSQL &= " SELECT IDoc_Doc_Lin Linea, IDoc_Itm_QTY Cantidad, IDoc_Doc_Ano Año, IDoc_Doc_Num Numero, IFNULL (IDoc_RF2_Cod,'(SIN REF.)') Documento, IDoc_Doc_Itm Fila, 'M' Clase, 0 Ingreso "
        strSQL &= " FROM Dcmtos_DTL_Itm "
        strSQL &= " WHERE IDoc_Sis_Emp={empresa} AND IDoc_Doc_Cat={catalogo} AND IDoc_Doc_Ano={anio} AND IDoc_Doc_Num={codigo})) g "
        strSQL &= " ORDER BY Linea, Clase, Numero, Fila  "

        strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
        strSQL = Replace(strSQL, "{catalogo}", catalogos)
        strSQL = Replace(strSQL, "{anio}", Anio)
        strSQL = Replace(strSQL, "{codigo}", Codigo)


        Return strSQL
    End Function
    Private Function CalcularTotal() As Double
        Dim Aceptado As Boolean = False
        Dim sumaTotal As Double = 0
        Dim cantidadTotal As Double = 0
        For i As Integer = 0 To dgvDetalle.RowCount - 1
            If Not dgvDetalle.Rows(i).Cells("colDescEstado").Value = 2 Then

                If dgvDetalle.Rows(i).Cells("colCif").Value = STR_VACIO Then
                    dgvDetalle.Rows(i).Cells("colTotal").Value = CDbl((dgvDetalle.Rows(i).Cells("colCantidad").Value) * CDbl(dgvDetalle.Rows(i).Cells("colCif").Value)).ToString(FORMATO_MONEDA)
                Else
                    dgvDetalle.Rows(i).Cells("colTotal").Value = CDbl((dgvDetalle.Rows(i).Cells("colCif").Value) * CDbl(dgvDetalle.Rows(i).Cells("colCantidad").Value)).ToString(FORMATO_MONEDA)
                End If

                sumaTotal = sumaTotal + dgvDetalle.Rows(i).Cells("colTotal").Value
                cantidadTotal = cantidadTotal + CDbl(dgvDetalle.Rows(i).Cells("colCantidad").Value).ToString(FORMATO_MONEDA)
            End If
        Next
        CeldaTotal.Text = sumaTotal.ToString(FORMATO_MONEDA)
        CeldaCantidad.Text = cantidadTotal.ToString(FORMATO_MONEDA)
        Aceptado = True
        Return sumaTotal
    End Function
    Public Sub CargarEncabezado(ByVal Anio As Integer, ByVal Codigo As Integer)
        Dim strSQL As String = STR_VACIO
        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader

        MyCnn.CONECTAR = strConexion
        strSQL = sqlEncabezado(Codigo, Anio)
        COM = New MySqlCommand(strSQL, CON)
        REA = COM.ExecuteReader
        If REA.HasRows Then
            Do While REA.Read
                CeldaAño.Text = REA.GetInt32("Anio")
                CeldaNumero.Text = Codigo
                dtpFecha.Value = REA.GetDateTime("Fecha").ToString(FORMATO_MYSQL)
                If REA.GetInt32("Estado") = 1 Then
                    chkActivo.Checked = True
                Else
                    chkActivo.Checked = False
                End If
                celdaidCliente.Text = REA.GetInt32("Codigo")
                celdaCliente1.Text = REA.GetString("Proveedor")
                CeldaDireccion.Text = REA.GetString("Direccion")
                celdaContactoProveedor.Text = REA.GetString("Contacto")
                celdaCelular.Text = REA.GetString("Telefono")
                celdaNit.Text = REA.GetString("NIT")
                celdaidMoneda.Text = REA.GetInt32("HDoc_Doc_Mon")
                CeldaMoneda.Text = REA.GetString("cat_clave")
                CeldaTasa.Text = REA.GetDouble("Tasa")
                CeldaReferencia.Text = REA.GetString("Referencia")
                CeldaObservacion.Text = REA.GetString("observacion")
                'Dias crédito para las plantas
                celdaDiasCredito.Text = REA.GetString("credito")

                If REA.GetString("HDoc_Ant_Com") = 1 Then
                    checkIntercompany.Checked = True
                Else
                    checkIntercompany.Checked = False
                End If
                If REA.GetInt32("Job") = 0 Then
                    checkJob.Checked = False
                    celdaJob.Text = REA.GetInt32("Job")
                Else
                    checkJob.Checked = True
                    celdaJob.Text = REA.GetInt32("Job")
                End If
                celdaPrice.Text = REA.GetString("Precio")
                celdaIdCliente2.Text = REA.GetInt32("cliente")
                CeldaCliente.Text = REA.GetString("Cliente")
                celdaContactoCliente.Text = REA.GetString("ContactoCliente")
                celdaContrato.Text = REA.GetString("contrato")
                If REA.GetInt32("Numero") = INT_CERO Then
                    CeldaPedido.Text = STR_VACIO
                Else
                    CeldaPedido.Text = "PF " & REA.GetInt32("Numero")
                End If

                celdaCatalogo.Text = REA.GetInt32("Catalogo")
                celdaAnio.Text = REA.GetInt32("Anio")
                celdanumero1.Text = REA.GetInt32("Numero")
            Loop
        End If
    End Sub
    Private Sub CargarDetalle(ByVal Codigo As Integer)
        Dim strSQL As String = STR_VACIO
        Dim COM As MySqlCommand
        Dim REA1 As MySqlDataReader
        Dim strLinea1 As String
        Dim intCantidad As Integer = NO_FILA
        Dim intTotal As Integer = NO_FILA
        Try
            strSQL = sqlDetalle(Codigo)
            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSQL, CON)
            REA1 = COM.ExecuteReader

            If REA1.HasRows Then
                dgvDetalle.Rows.Clear()
                Do While REA1.Read
                    strLinea1 = REA1.GetInt32("Codigo") & "|"
                    strLinea1 &= REA1.GetString("Descripcion") & "|"
                    strLinea1 &= REA1.GetString("Medida") & "|"
                    strLinea1 &= REA1.GetInt32("Unidad") & "|"
                    strLinea1 &= REA1.GetDouble("FOB") & "|"
                    strLinea1 &= REA1.GetDouble("CIF") & "|"
                    strLinea1 &= REA1.GetDouble("Precio") & "|"
                    strLinea1 &= REA1.GetDouble("Cantidad") & "|"
                    strLinea1 &= REA1.GetInt32("Total") & "|"
                    strLinea1 &= REA1.GetInt32("Fila") & "|"
                    strLinea1 &= REA1.GetInt32("Anio") & "|"
                    strLinea1 &= REA1.GetInt32("Numero") & "|"
                    strLinea1 &= REA1.GetInt32("Linea") & "|"
                    strLinea1 &= REA1.GetInt32("id_fabricante") & "|"
                    strLinea1 &= REA1.GetString("Fabricante") & "|"
                    strLinea1 &= REA1.GetString("Orden") & "|"
                    strLinea1 &= REA1.GetString("FechaETD") & "|"
                    strLinea1 &= "" & "|"
                    strLinea1 &= REA1.GetString("Programa") & "|"
                    If REA1.GetInt32("Estado") = 0 Then
                        strLinea1 &= "" & "|"
                    Else
                        strLinea1 &= "SI" & "|"
                    End If

                    strLinea1 &= "" & "|"
                    strLinea1 &= REA1.GetInt32("IDP") & "|"
                    strLinea1 &= REA1.GetString("Pais") & "|"
                    strLinea1 &= REA1.GetInt32("Despacho") & "|"
                    strLinea1 &= REA1.GetString("estado") & "|"
                    strLinea1 &= REA1.GetString("NombreCliente") & "|"
                    strLinea1 &= REA1.GetString("CodigoCliente") & "|"
                    strLinea1 &= "1|"
                    strLinea1 &= REA1.GetString("certification") & "|"
                    strLinea1 &= REA1.GetString("MKT")
                    cFunciones.AgregarFila(dgvDetalle, strLinea1)
                Loop
                CalcularTotal()
                'CargarHilo(REA1.GetInt32("Codigo"), REA1.GetInt32("Fila"))

            End If
            'REA.Close()
            'REA = Nothing
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try

    End Sub
    Private Sub CargarDescargo(ByVal Codigo As Integer, ByVal Anio As Integer)
        Dim strSQL As String = STR_VACIO
        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader
        Dim strLinea As String = STR_VACIO
        Dim intLinea As Integer = NO_FILA
        Dim dblCantidad As Integer
        Dim dblSaldo As Double
        Dim dblTemporal As Double

        Try

            strSQL = SQLDescargos(Codigo, Anio)
            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSQL, CON)
            REA = COM.ExecuteReader

            If REA.HasRows Then
                dgvDescargos.Rows.Clear()
                Do While REA.Read
                    For i As Integer = 0 To dgvDetalle.Rows.Count - 1
                        '  dblSaldo = dgvDetalle.Rows(i).Cells("colCantidad").Value

                        If REA.GetInt32("Linea") = dgvDetalle.Rows(i).Cells("colFila").Value Then
                            If Not REA.GetInt32("Linea") = intLinea Then
                                intLinea = REA.GetInt32("Linea")
                                'dblCantidad = dgvDetalle.CurrentRow.Cells("colCantidad").Value
                                dblCantidad = dgvDetalle.Rows(i).Cells("colCantidad").Value
                                dblSaldo = dblCantidad
                            End If
                            dblSaldo = dblSaldo - REA.GetDouble("Cantidad")

                            strLinea = REA.GetInt32("Linea") & "|"
                            strLinea &= REA.GetInt32("Anio") & "|"
                            strLinea &= REA.GetInt32("Numero") & "|"
                            strLinea &= REA.GetString("Documento") & "|"
                            strLinea &= REA.GetDouble("Cantidad") & "|"
                            strLinea &= dblSaldo.ToString(FORMATO_MONEDA) & "|"
                            strLinea &= REA.GetInt32("Fila") & "|"
                            strLinea &= REA.GetString("Clase") & "|"
                            strLinea &= REA.GetInt32("Ingreso")


                            If REA.GetString("Clase") = "M" Then
                                cFunciones.AgregarFila(dgvDescargos, strLinea, Color.Yellow)
                            ElseIf REA.GetInt32("Ingreso") = vbEmpty Then
                                cFunciones.AgregarFila(dgvDescargos, strLinea, Color.Orange)
                            Else
                                cFunciones.AgregarFila(dgvDescargos, strLinea)
                            End If

                        End If

                    Next
                Loop
                'Next
            End If




        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub
    Private Function NuevaRequisicion() As Integer
        Dim Intnumero As Integer = INT_CERO
        Dim strSQL As String = STR_VACIO
        Dim conec As New MySqlConnection
        Dim COM As MySqlCommand

        strSQL = " Select IFNULL(MAX(HDR.HDoc_Doc_Num),0)+1 NUMERO  "
        strSQL &= " FROM Dcmtos_HDR HDR "
        strSQL &= " WHERE HDR.HDoc_Sis_Emp = {empresa} And HDR.HDoc_Doc_Cat = {catalogo}  "

        strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
        strSQL = Replace(strSQL, "{catalogo}", catalogos)
        strSQL = Replace(strSQL, "{anio}", cFunciones.AñoMySQL)
        conec = New MySqlConnection(strConexion)
        conec.Open()
        COM = New MySqlCommand(strSQL, conec)
        Intnumero = COM.ExecuteScalar
        conec.Close()
        conec.Dispose()
        conec = Nothing
        System.GC.Collect()
        Return Intnumero
    End Function
    Private Function NuevaJob() As Integer
        Dim Intnumero As Integer = INT_CERO
        Dim strSQL As String = STR_VACIO
        Dim conec As New MySqlConnection
        Dim COM As MySqlCommand

        strSQL = " Select IFNULL(MAX(HDR.HDoc_DR1_Dbl),0)+1 NUMERO  "
        strSQL &= " FROM Dcmtos_HDR HDR "
        strSQL &= " WHERE HDR.HDoc_Sis_Emp = {empresa} And HDR.HDoc_Doc_Cat = {catalogo}  "

        strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
        strSQL = Replace(strSQL, "{catalogo}", catalogos)
        strSQL = Replace(strSQL, "{anio}", cFunciones.AñoMySQL)
        conec = New MySqlConnection(strConexion)
        conec.Open()
        COM = New MySqlCommand(strSQL, conec)
        Intnumero = COM.ExecuteScalar
        conec.Close()
        conec.Dispose()
        conec = Nothing
        System.GC.Collect()
        Return Intnumero
    End Function

    Private Function NuevaLinea(ByVal Codigo As Integer) As Integer
        Dim strSQL As String = STR_VACIO
        Dim conec As New MySqlConnection
        Dim COM As MySqlCommand
        Dim LineaNueva As Integer

        strSQL = " Select IFNULL(MAX(DTL.DDoc_Doc_Lin),0) + 1  DTL "
        strSQL &= " FROM Dcmtos_DTL DTL "
        strSQL &= " WHERE DTL.DDoc_Sis_emp = {empresa} And DTL.DDoc_Doc_Cat = {catalogo} And DTL.DDoc_Doc_Ano = {anio} And DTL.DDoc_Doc_Num ={codigo} "

        strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
        strSQL = Replace(strSQL, "{catalogo}", catalogos)
        strSQL = Replace(strSQL, "{anio}", CeldaAño.Text)
        strSQL = Replace(strSQL, "{codigo}", Codigo)



        conec = New MySqlConnection(strConexion)
        conec.Open()
        COM = New MySqlCommand(strSQL, conec)
        LineaNueva = COM.ExecuteScalar
        conec.Close()
        conec.Dispose()
        conec = Nothing
        System.GC.Collect()
        Return LineaNueva


    End Function
    Private Function Guardar() As Boolean
        Dim LogVerdadero As Boolean = False
        Dim HDR As New clsDcmtos_HDR
        Try
            HDR.HDOC_SIS_EMP = Sesion.IdEmpresa
            HDR.HDOC_DOC_CAT = catalogos
            HDR.HDOC_DOC_ANO = CeldaAño.Text
            HDR.HDOC_EMP_COD = celdaidCliente.Text
            HDR.HDOC_EMP_NOM = celdaCliente1.Text
            HDR.HDOC_EMP_DIR = CeldaDireccion.Text
            HDR.HDOC_EMP_PER = celdaContactoProveedor.Text
            HDR.HDOC_EMP_TEL = celdaCelular.Text
            HDR.HDOC_EMP_NIT = celdaNit.Text
            HDR.HDOC_DR1_NUM = CeldaReferencia.Text
            HDR.HDOC_DOC_MON = celdaidMoneda.Text
            HDR.HDOC_DOC_TC = CeldaTasa.Text
            HDR.HDOC_USUARIO = Sesion.Usuario
            HDR.HDOC_DR1_EMP = celdaIdCliente2.Text
            HDR.HDOC_RF1_COD = celdaContactoCliente.Text

            'Pedido 
            HDR.HDOC_PRO_DCAT = celdaCatalogo.Text
            HDR.HDOC_PRO_DANO = celdaAnio.Text
            HDR.HDOC_PRO_DNUM = celdanumero1.Text
            HDR.HDOC_RF2_COD = IIf(celdaContrato.Text = STR_VACIO, STR_VACIO, celdaContrato.Text)
            HDR.HDOC_RF2_TXT = IIf(CeldaObservacion.Text = STR_VACIO, STR_VACIO, CeldaObservacion.Text)
            HDR.HDOC_ANT_COM = IIf(checkIntercompany.Checked = True, 1, 0)
            HDR.HDOC_RF1_TXT = IIf(celdaDiasCredito.Text = STR_VACIO, STR_VACIO, celdaDiasCredito.Text)


            If chkActivo.Checked = True Then
                HDR.HDOC_DOC_STATUS = 1 ' Check Activo
            Else
                HDR.HDOC_DOC_STATUS = 0 ' ANULADO
            End If
            If dtpFecha.Format = DateTimePickerFormat.Custom Then
            Else
                HDR.HDoc_Doc_Fec_NET = dtpFecha.Value
            End If

            HDR.CONEXION = strConexion
            If Me.Tag = "Nuevo" Then
                If logInsertar = True Then
                    If checkJob.Checked = True Then
                        'Info Pride Manufacturing 
                        celdaJob.Text = NuevaJob()
                        HDR.HDOC_DR2_NUM = celdaPrice.Text
                        HDR.HDOC_DR1_DBL = NuevaJob()
                    End If
                    CeldaNumero.Text = NuevaRequisicion()
                    HDR.HDOC_DOC_NUM = CeldaNumero.Text
                    cFunciones.EscribirRegistro("Dcmtos_HDR", clsFunciones.AccEnum.acAdd, 0, catalogos, CeldaAño.Text, HDR.HDOC_DOC_NUM)
                    If HDR.Guardar = False Then
                        MsgBox(HDR.MERROR.ToString & " Could not save this document ", MsgBoxStyle.Critical)
                    Else
                        LogVerdadero = True
                    End If
                    If GuardarDetalle(HDR.HDOC_DOC_NUM) = True Then
                        LogVerdadero = True
                    Else
                        LogVerdadero = False
                    End If
                End If
            Else
                If logEditar = True Then
                    If checkJob.Checked = True Then
                        'Info Pride Manufacturing 
                        HDR.HDOC_DR2_NUM = celdaPrice.Text
                        If celdaJob.Text = INT_CERO Then
                            HDR.HDOC_DR1_DBL = NuevaJob()
                            celdaJob.Text = NuevaJob()
                        Else
                            HDR.HDOC_DR1_DBL = celdaJob.Text
                        End If
                    End If
                    HDR.HDOC_DOC_NUM = CeldaNumero.Text
                    cFunciones.EscribirRegistro("Dcmtos_HDR", clsFunciones.AccEnum.acUpdate, 0, catalogos, CeldaAño.Text, CeldaNumero.Text)
                    If HDR.Actualizar = False Then
                        MsgBox(HDR.MERROR.ToString & " Could not Modify this document ", MsgBoxStyle.Critical)
                    Else
                        LogVerdadero = True
                    End If
                    If GuardarDetalle(CeldaNumero.Text) = True Then
                        LogVerdadero = True
                    Else
                        LogVerdadero = False
                    End If

                Else
                    MsgBox("You Dont Have Permissions")
                End If
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        Return LogVerdadero
    End Function
    Private Function GuardarDetalle(ByVal Codigo As Integer) As Boolean
        Dim logVerdadero As Boolean
        Dim DTL As New clsDcmtos_DTL

        DTL.CONEXION = strConexion
        Try
            For i As Integer = 0 To dgvDetalle.RowCount - 1
                If Me.Tag = "Nuevo" Then
                    dgvDetalle.Rows(i).Cells("colFila").Value = NuevaLinea(Codigo)
                    DTL.DDOC_DOC_LIN = dgvDetalle.Rows(i).Cells("colFila").Value
                    DTL.DDOC_DOC_NUM = Codigo
                Else
                    If dgvDetalle.Rows(i).Cells("colDescEstado").Value = 0 Then
                        dgvDetalle.Rows(i).Cells("colFila").Value = NuevaLinea(Codigo)
                        DTL.DDOC_DOC_LIN = dgvDetalle.Rows(i).Cells("colFila").Value
                    Else
                        DTL.DDOC_DOC_LIN = dgvDetalle.Rows(i).Cells("colFila").Value
                    End If
                    DTL.DDOC_DOC_NUM = CeldaNumero.Text
                End If
                DTL.DDOC_SIS_EMP = Sesion.IdEmpresa
                DTL.DDOC_DOC_CAT = catalogos
                DTL.DDOC_DOC_ANO = CeldaAño.Text
                DTL.DDOC_PRD_COD = dgvDetalle.Rows(i).Cells("colCodigo").Value
                DTL.DDOC_PRD_DES = dgvDetalle.Rows(i).Cells("colDescripcion").Value
                DTL.DDOC_PRD_UM = dgvDetalle.Rows(i).Cells("colUnidad").Value
                DTL.DDOC_PRD_PUQ = dgvDetalle.Rows(i).Cells("colidVendido").Value
                DTL.DDOC_RF2_DBL = dgvDetalle.Rows(i).Cells("colFob").Value
                DTL.DDOC_RF3_DBL = dgvDetalle.Rows(i).Cells("colCif").Value
                DTL.DDOC_PRD_QTY = dgvDetalle.Rows(i).Cells("colCantidad").Value
                'Ref MKT
                DTL.DDOC_PRD_DSQ = IIf(dgvDetalle.Rows(i).Cells("colMKTRef").Value = vbNullString, 0, dgvDetalle.Rows(i).Cells("colMKTRef").Value)
                If dgvDetalle.Rows(i).Cells("CodFabricante").Value = STR_VACIO Then
                    DTL.DDOC_RF1_NUM = 0
                Else
                    DTL.DDOC_RF1_NUM = dgvDetalle.Rows(i).Cells("CodFabricante").Value
                End If
                If dgvDetalle.Rows(i).Cells("colOrden").Value = STR_VACIO Then
                    If checkJob.Checked = True Then
                        DTL.DDOC_RF1_COD = "JOB-" & celdaJob.Text
                    Else
                        DTL.DDOC_RF1_COD = CeldaNumero.Text
                    End If
                Else
                    DTL.DDOC_RF1_COD = dgvDetalle.Rows(i).Cells("colOrden").Value
                End If
                If (dgvDetalle.Rows(i).Cells("colOrden").Value = STR_VACIO) Then
                    If checkJob.Checked = True Then
                        dgvDetalle.Rows(i).Cells("colOrden").Value = "JOB-" & celdaJob.Text
                    Else
                        dgvDetalle.Rows(i).Cells("colOrden").Value = CeldaNumero.Text
                    End If
                End If
                '  DTL.DDOC_RF1_COD = If(dgvDetalle.Rows(i).Cells("colOrden").Value = STR_VACIO, CeldaNumero.Text, dgvDetalle.Rows(i).Cells("colOrden").Value)
                '   If (dgvDetalle.Rows(i).Cells("colOrden").Value = STR_VACIO) Then
                '  dgvDetalle.Rows(i).Cells("colOrden").Value = CeldaNumero.Text
                ' End If
                '   If dgvDetalle.Rows(i).Cells("colFechaDetalle").Value = STR_VACIO Then
                '  DTL.DDOC_RF1_FEC = Nothing
                ' Else
                'DTL.DDoc_RF1_Fec_NET = dgvDetalle.Rows(i).Cells("colFechaDetalle").Value
                'End If
                DTL.DDOC_RF2_COD = dgvDetalle.Rows(i).Cells("colPrograma").Value
                If dgvDetalle.Rows(i).Cells("colEstadoDetalle").Value = "SI" Then
                    DTL.DDOC_RF2_NUM = 1
                Else
                    DTL.DDOC_RF2_NUM = 0
                End If
                DTL.DDOC_RF3_NUM = dgvDetalle.Rows(i).Cells("colIDP").Value
                DTL.DDOC_RF3_TXT = dgvDetalle.Rows(i).Cells("colPais").Value
                DTL.DDOC_PRD_FOB = IIf(dgvDetalle.Rows(i).Cells("colStatus").Value = "Unsold", 0, 1)
                DTL.DDOC_PRD_PNR = dgvDetalle.Rows(i).Cells("colVendido").Value
                If dgvDetalle.Rows(i).Cells("colDescEstado").Value = 0 Then
                    If DTL.Guardar = False Then
                        MsgBox(DTL.MERROR.ToString() & " Could Not Save this document", MsgBoxStyle.Critical)
                        Return False
                        Exit Function
                    Else
                        logVerdadero = True
                    End If
                End If
                DTL.DDOC_RF4_TXT = dgvDetalle.Rows(i).Cells("certification").Value
                If dgvDetalle.Rows(i).Cells("colDescEstado").Value = 1 Then

                    If DTL.Actualizar = False Then
                        MsgBox(DTL.MERROR.ToString() & " Could not modify this document ", MsgBoxStyle.Critical)
                        Return False
                        Exit Function
                    Else
                        logVerdadero = True
                    End If
                End If
                If dgvDetalle.Rows(i).Cells("colDescEstado").Value = 2 Then

                    If DTL.Borrar = False Then
                        MsgBox(DTL.MERROR.ToString & " Could not Modify this document ", MsgBoxStyle.Critical)
                    End If
                End If
            Next

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        Return logVerdadero
    End Function
    Private Sub DividirCantidadEnContenedores()
        Dim strFila As String = STR_VACIO
        Dim CantidadContenedores As Integer = INT_CERO
        Dim CantidadLBS As Double = INT_CERO
        Dim dblPrecioCIF As Double = INT_CERO
        Dim IntNumLinea As Integer = 0

        CantidadContenedores = Math.Round((dgvDetalle.CurrentRow.Cells(7).Value / 40000) + 0.01, 0)
        CantidadLBS = dgvDetalle.CurrentRow.Cells(7).Value / CantidadContenedores
        dblPrecioCIF = dgvDetalle.CurrentRow.Cells(5).Value
        dgvDetalle.CurrentRow.Cells(27).Value = 2
        If Me.Tag = "Mod" Then
            IntNumLinea = NuevaLinea(CeldaNumero.Text)
        End If

        For i As Integer = 1 To CantidadContenedores
            strFila = dgvDetalle.CurrentRow.Cells(0).Value & "|"
            strFila &= dgvDetalle.CurrentRow.Cells(1).Value & "|"
            strFila &= dgvDetalle.CurrentRow.Cells(2).Value & "|"
            strFila &= dgvDetalle.CurrentRow.Cells(3).Value & "|"
            strFila &= dgvDetalle.CurrentRow.Cells(4).Value & "|"
            strFila &= dblPrecioCIF & "|"
            strFila &= dgvDetalle.CurrentRow.Cells(6).Value & "|"
            strFila &= CantidadLBS & "|"
            strFila &= (dblPrecioCIF) * (CantidadLBS) & "|"
            strFila &= IntNumLinea & "|"
            strFila &= dgvDetalle.CurrentRow.Cells(10).Value & "|"
            strFila &= dgvDetalle.CurrentRow.Cells(11).Value & "|"
            strFila &= dgvDetalle.CurrentRow.Cells(12).Value & "|"
            strFila &= dgvDetalle.CurrentRow.Cells(13).Value & "|"
            strFila &= dgvDetalle.CurrentRow.Cells(14).Value & "|"
            strFila &= dgvDetalle.CurrentRow.Cells(15).Value & "|"
            strFila &= dgvDetalle.CurrentRow.Cells(16).Value & "|"
            strFila &= dgvDetalle.CurrentRow.Cells(17).Value & "|"
            strFila &= dgvDetalle.CurrentRow.Cells(18).Value & "|"
            strFila &= dgvDetalle.CurrentRow.Cells(19).Value & "|"
            strFila &= dgvDetalle.CurrentRow.Cells(20).Value & "|"
            strFila &= dgvDetalle.CurrentRow.Cells(21).Value & "|"
            strFila &= dgvDetalle.CurrentRow.Cells(22).Value & "|"
            strFila &= dgvDetalle.CurrentRow.Cells(23).Value & "|"
            strFila &= "Unsold" & "|"
            strFila &= STR_VACIO & "|"
            strFila &= 0

            If Me.Tag = "Mod" Then
                IntNumLinea = IntNumLinea + 1
            End If

            cFunciones.AgregarFila(dgvDetalle, strFila)
        Next

        For i = 0 To dgvDetalle.Rows.Count - 1
            If dgvDetalle.Rows(i).Cells("colDescEstado").Value = 2 Then
                dgvDetalle.Rows(i).Visible = False
            End If
        Next

    End Sub
    Private Function Dependecias() As Integer
        Dim intValidacion As Integer
        Dim COM As MySqlCommand
        Dim conec As MySqlConnection
        Dim strSQL As String = STR_VACIO
        Try
            strSQL = "  SELECT COUNT(*)"
            strSQL &= "    	FROM Dcmtos_DTL_Pro d"
            strSQL &= "         WHERE d.PDoc_Sis_Emp = {empresa} AND d.PDoc_Par_Cat = 38 AND d.PDoc_Par_Ano = {anio} AND d.PDoc_Par_Num = {numero}"
            strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
            strSQL = Replace(strSQL, "{anio}", CeldaAño.Text)
            strSQL = Replace(strSQL, "{numero}", CeldaNumero.Text)
            conec = New MySqlConnection(strConexion)
            conec.Open()
            COM = New MySqlCommand(strSQL, conec)
            Using conec
                intValidacion = COM.ExecuteScalar
                COM.Dispose()
                COM = Nothing
                conec.Close()
                conec.Dispose()
                conec = Nothing
                System.GC.Collect()
            End Using
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        Return intValidacion
    End Function
    'Borrar Orden Requisicion
    Public Function BorrarEncabezadoOrden(ByVal anio As Integer, ByVal numero As Integer) As Boolean
        Dim logGuardar As Boolean
        Dim strSQL As String = STR_VACIO
        Try

            Dim hdr As New clsDcmtos_HDR
            hdr.CONEXION = strConexion
            hdr.HDOC_SIS_EMP = Sesion.IdEmpresa
            hdr.HDOC_DOC_CAT = 38
            hdr.HDOC_DOC_ANO = anio
            hdr.HDOC_DOC_NUM = numero
            logGuardar = hdr.Borrar()

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        Return logGuardar
    End Function
    Private Function BorrarDetalleOrden(ByVal anio As Integer, ByVal numero As Integer) As Boolean
        Dim logGuardar As Boolean
        Dim strSQL As String = STR_VACIO
        Try
            strSQL = "DDoc_Sis_Emp = {emp} AND DDoc_Doc_Cat = {cat} AND DDoc_Doc_Ano = {anio} AND DDoc_Doc_Num = {num} "
            strSQL = Replace(strSQL, "{emp}", Sesion.IdEmpresa)
            strSQL = Replace(strSQL, "{cat}", 38)
            strSQL = Replace(strSQL, "{anio}", anio)
            strSQL = Replace(strSQL, "{num}", numero)

            Dim dtl As New clsDcmtos_DTL
            dtl.CONEXION = strConexion
            logGuardar = dtl.Borrar(strSQL)

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        Return logGuardar
    End Function
    Private Function BorrarITMOrden(ByVal anio As Integer, ByVal numero As Integer) As Boolean
        Dim logGuardar As Boolean
        Dim strSQL As String = STR_VACIO
        Try
            strSQL = "IDoc_Sis_Emp = {emp} AND IDoc_Doc_Cat = {cat} AND IDoc_Doc_Ano = {anio} AND IDoc_Doc_Num = {num} "
            strSQL = Replace(strSQL, "{emp}", Sesion.IdEmpresa)
            strSQL = Replace(strSQL, "{cat}", 38)
            strSQL = Replace(strSQL, "{anio}", anio)
            strSQL = Replace(strSQL, "{num}", numero)

            Dim itm As New Tablas.TDCMTOS_DTL_ITM
            itm.CONEXION = strConexion
            logGuardar = itm.PDELETE(strSQL)
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        Return logGuardar
    End Function
    Public Sub BloquearJob()
        If checkJob.Checked = True Then
            gbInfo2.Enabled = True
            botonImprimirOrden.Enabled = True
        Else
            gbInfo2.Enabled = False
            botonImprimirOrden.Enabled = False
        End If
    End Sub
    Private Function BuscarRegistrosOrdenJob(ByVal strConsulta As String)
        Dim Tablas As New DataSet
        Dim adaptador As New MySqlDataAdapter

        MyCnn.CONECTAR = strConexion
        adaptador = New MySqlDataAdapter(strConsulta, CON)
        Tablas = New DataSet("JOB")
        adaptador.Fill(Tablas, "Dcmtos_HDR")
        If Tablas.Tables("Dcmtos_HDR").Rows.Count = 0 Then
            MsgBox("")
        Else
            My.Computer.FileSystem.CreateDirectory("C:\XML")
            Tablas.WriteXml("C:\XML\DcmtosHDRJOB.xml", XmlWriteMode.WriteSchema)
        End If
    End Function
    Private Function BuscarRegistroNotificacion(ByVal strConsulta As String)
        Dim Tablas As New DataSet
        Dim adaptador As New MySqlDataAdapter

        MyCnn.CONECTAR = strConexion
        adaptador = New MySqlDataAdapter(strConsulta, CON)
        Tablas = New DataSet("Notificacion")
        adaptador.Fill(Tablas, "Notificaciones")
        If Tablas.Tables("Notificaciones").Rows.Count = 0 Then
            MsgBox("")
        Else
            My.Computer.FileSystem.CreateDirectory("C:\XML")
            Tablas.WriteXml("C:\XML\Notificaciones.xml", XmlWriteMode.WriteSchema)
        End If
    End Function

    Private Sub OrdenJobPrideManufacturing()
        Dim strSQL As String = STR_VACIO
        Dim strSQL2 As String = STR_VACIO
        Dim repCR As New OrdenPrideManufacturing
        Dim repCR2 As New OrdenJoMar
        Dim repCR3 As New OrdenLatinTextiles
        Dim repCR4 As New OrdenTrulyfibers

        strSQL = " SELECT p2.pro_proveedor NombreV , p2.pro_direccion DireccionV , IFNULL(p1.pro_proveedor,p1.pro_nombre) NombreB , p1.pro_direccion DireccionB , e.emp_nombre NombreE, "
        strSQL &= "     e.emp_direccion DireccionE , h.HDoc_Doc_Fec Fecha , CONCAT(h.HDoc_Doc_Num ,'/ ',h.HDoc_DR1_Num) Ref , CONCAT(p.per_nombre1,' ',p.per_apellido1) Nombre ,h.HDoc_DR2_Num Price,IF(e.emp_web=1, IF((h.HDoc_DR2_Num ='CIF' OR h.HDoc_DR2_Num ='CIP'),(d.DDoc_Prd_QTY * d.DDoc_RF3_Dbl), 0),(d.DDoc_Prd_QTY * d.DDoc_RF2_Dbl)) Total,
sum(IF(e.emp_web=1, IF((h.HDoc_DR2_Num ='CIF' OR h.HDoc_DR2_Num ='CIP'),(d.DDoc_Prd_QTY * d.DDoc_RF3_Dbl), 0),(d.DDoc_Prd_QTY * d.DDoc_RF2_Dbl))) Total2, 
 h.HDoc_DR1_Dbl Job, d.DDoc_Prd_Des Descripcion, d.DDoc_Prd_QTY Cantidad , IF(e.emp_web=1 AND h.HDoc_DR2_Num IN ('CIF','CIP'),d.DDoc_RF3_Dbl, d.DDoc_RF2_Dbl) Precio, h.HDoc_DR1_Num Referencia, h.HDoc_RF1_Cod Credi, h.HDoc_Sis_Emp Empr, e.emp_web giro, d.DDoc_RF3_Dbl CIF, d.DDoc_RF2_Dbl FOB, c.cat_clave UnidadM"
        strSQL &= "         FROM Dcmtos_HDR  h"
        strSQL &= "                 LEFT JOIN Proveedores p1 ON p1.pro_sisemp = h.HDoc_Sis_Emp AND p1.pro_codigo = h.HDoc_Emp_Cod "
        strSQL &= "             LEFT JOIN Dcmtos_DTL d ON d.DDoc_Sis_Emp = h.HDoc_Sis_Emp AND d.DDoc_Doc_Cat = h.HDoc_Doc_Cat AND d.DDoc_Doc_Ano = h.HDoc_Doc_Ano  AND d.DDoc_Doc_Num = h.HDoc_Doc_Num "
        strSQL &= "      LEFT JOIN Proveedores p2 ON p2.pro_sisemp = d.DDoc_Sis_Emp AND p2.pro_codigo = d.DDoc_RF1_Num "
        strSQL &= "    LEFT JOIN Empresas e ON e.emp_no = {empresa} "
        strSQL &= "  LEFT JOIN Personal p ON p.per_sisemp = h.HDoc_Sis_Emp AND p.per_usuario = h.HDoc_Usuario "
        strSQL &= "  LEFT JOIN Catalogos c ON c.cat_num = d.DDoc_Prd_UM "
        strSQL &= " WHERE h.HDoc_Sis_Emp = {empresa} AND h.HDoc_Doc_Cat = 38 AND h.HDoc_Doc_Ano = {anio} AND h.HDoc_Doc_Num = {numero} "
        strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
        strSQL = Replace(strSQL, "{numero}", CeldaNumero.Text)
        strSQL = Replace(strSQL, "{anio}", CeldaAño.Text)

        If BuscarRegistrosOrdenJob(strSQL) = True Then
        End If
        repCR.Load("C:\XML\DcmtosHDRJOB.xml")
        Dim frm3 As New FrmFacturaCMC
        If rbJoMark.Checked = True Then
            frm3.Reporte_A_Ver_FacturaCMC = repCR2
            frm3.Name = "Order JOB"
            frm3.CrystalReportViewer1.ReportSource = repCR2
            frm3.CrystalReportViewer1.RefreshReport()
        ElseIf rbPrideM.Checked = True Then
            frm3.Reporte_A_Ver_FacturaCMC = repCR
            frm3.Name = "Order JOB"
            frm3.CrystalReportViewer1.ReportSource = repCR
            frm3.CrystalReportViewer1.RefreshReport()
        ElseIf rbLatinTextiles.Checked = True Then
            frm3.Reporte_A_Ver_FacturaCMC = repCR3
            frm3.Name = "Order JOB"
            frm3.CrystalReportViewer1.ReportSource = repCR3
            frm3.CrystalReportViewer1.RefreshReport()
        ElseIf rbTrulyfibers.Checked = True Then
            frm3.Reporte_A_Ver_FacturaCMC = repCR4
            frm3.Name = "Order JOB"
            frm3.CrystalReportViewer1.ReportSource = repCR4
            frm3.CrystalReportViewer1.RefreshReport()
        End If
        frm3.ShowDialog(Me)
        My.Computer.FileSystem.DeleteFile("C:\XML\DcmtosHDRJOB.xml")
    End Sub
#End Region

#Region "Eventos"
    Private Sub frmOrdenRequisicion_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        dtpInicio.Value = DateSerial(Year(Date.Now), Month(Date.Now) - 1, 1)
        dtpFinal.Value = DateSerial(Year(Date.Now), Month(Date.Now) + 1, vbEmpty)
        Accessos()
        If Sesion.IdEmpresa = 15 Or Sesion.IdEmpresa = 18 Or Sesion.IdEmpresa = 19 Or Sesion.IdEmpresa = 20 Or Sesion.IdEmpresa = 21 Then
            panelDiasCredito.Visible = True
        Else
            panelDiasCredito.Visible = False
        End If
        MostrarLista()

    End Sub
    Private Sub Encabezado1_ClickCerrar(sender As Object, click As Boolean) Handles Encabezado1.ClickCerrar
        If pnlOrder.Visible = True Then
            MostrarLista()
        Else
            Me.Close()
            Fprincipal.BarraDeTareas1.QuitarFormulario(key)
        End If
    End Sub
    Private Sub Encabezado1_ClickNuevo(sender As Object, click As Boolean) Handles Encabezado1.ClickNuevo
        MostrarLista(False)
        Reset()
        CeldaAño.Text = cFunciones.AñoMySQL
        CargardgDocumentos(CeldaAño.Text, CeldaNumero.Text)
        Encabezado1.botonBorrar.Enabled = False
        Me.Tag = "Nuevo"
        If Sesion.idGiro = 1 Then
            Label21.Text = "Incotern"
            Label20.Text = "Credit Days"
            botonContactoCliente.Visible = False
            botonContactoCliente.Enabled = False
            celdaContactoCliente.ReadOnly = False
            celdaPrice.ReadOnly = True
            botonIncotern.Visible = True

        Else
            Label20.Text = "Contac"
            Label21.Text = "Price"
            botonContactoCliente.Visible = True
            celdaContactoCliente.ReadOnly = True
            botonContactoCliente.Enabled = True
            celdaPrice.ReadOnly = False
            botonIncotern.Visible = False
        End If
    End Sub
    Private Sub btnNombre_Click(sender As Object, e As EventArgs) Handles btnNombre.Click
        Dim frm As New frmSeleccionar
        Dim strSql As String = STR_VACIO
        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader
        Dim strLinea As String = STR_VACIO

        Try

            frm.Titulo = "Provider "
            frm.Campos = " pro_codigo Codigo , pro_proveedor Proveedor "
            frm.Tabla = " Proveedores  "
            frm.FiltroText = " Enter the flow to be filtered"
            frm.Filtro = " pro_proveedor "
            frm.Condicion = " pro_sisemp = " & Sesion.IdEmpresa & " AND (pro_ramo = 'Textil' OR pro_fabricante = 'Si') AND pro_status = 'Activo'   "
            frm.Ordenamiento = " pro_proveedor "
            frm.TipoOrdenamiento = " ASC "
            frm.ShowDialog(Me)
            If frm.DialogResult = System.Windows.Forms.DialogResult.OK Then
                celdaidCliente.Text = frm.LLave

                strSql = " SELECT pro_proveedor Proveedor,pro_direccion Direccion,pro_nit NIT, cat_clave Moneda,cat_num idMoneda, cat_sist Tasa "
                strSql &= " FROM Proveedores "
                strSql &= "  LEFT JOIN Catalogos ON cat_num=pro_moneda "
                strSql &= " WHERE pro_sisemp={empresa} AND pro_codigo= {proveedor} "
                strSql = Replace(strSql, "{empresa}", Sesion.IdEmpresa)
                strSql = Replace(strSql, "{proveedor}", celdaidCliente.Text)

                MyCnn.CONECTAR = strConexion
                COM = New MySqlCommand(strSql, CON)
                REA = COM.ExecuteReader
                If REA.HasRows Then
                    Do While REA.Read
                        celdaCliente1.Text = REA.GetString("Proveedor")
                        CeldaDireccion.Text = REA.GetString("Direccion")
                        celdaNit.Text = REA.GetString("NIT")
                        CeldaMoneda.Text = REA.GetString("Moneda")
                        celdaidMoneda.Text = REA.GetInt32("idMoneda")
                        CeldaTasa.Text = REA.GetString("Tasa")
                        celdaContactoProveedor.Text = "N/A"
                        celdaCelular.Text = "N/A"
                    Loop
                End If
                'REA.Close()
                'REA = Nothing
                'COM = Nothing
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub
    Private Sub botonCliente_Click(sender As Object, e As EventArgs) Handles botonCliente.Click
        Dim frm As New frmSeleccionar
        Dim strSql As String = STR_VACIO
        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader
        Dim strLinea As String = STR_VACIO

        Try
            frm.Titulo = "Client "
            frm.Campos = " cli_codigo Codigo , cli_cliente Cliente"
            frm.Tabla = "  Clientes "
            frm.FiltroText = " Enter the flow to be filtered"
            frm.Filtro = " cli_cliente "
            frm.Condicion = " cli_sisemp  = " & Sesion.IdEmpresa & " AND cli_status = 'Activo'  "
            frm.Ordenamiento = " cli_cliente "
            frm.TipoOrdenamiento = " ASC "
            frm.ShowDialog(Me)
            If frm.DialogResult = System.Windows.Forms.DialogResult.OK Then
                celdaIdCliente2.Text = frm.LLave
                CeldaCliente.Text = frm.Dato
            End If

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub
    Private Sub botonContactoProveedor_Click(sender As Object, e As EventArgs) Handles botonContactoProveedor.Click
        Dim frm As New frmSeleccionar
        Dim strSql As String = STR_VACIO
        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader
        Dim strLinea As String = STR_VACIO

        Try


            frm.Titulo = " Contact Supplier "
            frm.Campos = " cnt_codigo Codigo , cnt_nombre,cnt_celular "
            frm.Tabla = "   Contactos "
            frm.FiltroText = " Enter the flow to be filtered"
            frm.Filtro = " cnt_codigo "
            frm.Condicion = " cnt_sisemp = " & Sesion.IdEmpresa & " AND cnt_tipoemp= 'Proveedores' AND cnt_codemp = " & celdaidCliente.Text & ""
            frm.ShowDialog(Me)
            If frm.DialogResult = System.Windows.Forms.DialogResult.OK Then
                celdaContactoProveedor.Text = frm.Dato
                celdaCelular.Text = frm.Dato2
            End If

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub
    Private Sub btnMoneda_Click(sender As Object, e As EventArgs) Handles btnMoneda.Click
        Dim frm As New frmSeleccionar
        Try
            frm.Titulo = "Select a Currency"
            frm.Campos = " c.cat_clave Moneda, c.cat_num ID, c.cat_sist "
            frm.Tabla = " Catalogos c "
            frm.FiltroText = " Enter The Name Of The Currency To Filter "
            frm.Filtro = "  c.cat_clave  "
            frm.Condicion = " cat_clase='Monedas' ORDER BY c.cat_clave LIMIT 5"

            frm.ShowDialog(Me)
            If frm.DialogResult = System.Windows.Forms.DialogResult.OK Then
                CeldaMoneda.Text = frm.LLave
                celdaidMoneda.Text = frm.Dato
                If frm.Dato2 > 1 Then
                    CeldaTasa.Text = cFunciones.TasaSegunFecha(dtpFecha.Value.ToString(FORMATO_MYSQL))
                Else
                    CeldaTasa.Text = frm.Dato2
                End If
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub
    Private Sub botonContactoCliente_Click(sender As Object, e As EventArgs) Handles botonContactoCliente.Click
        Dim frm As New frmSeleccionar
        Dim strSql As String = STR_VACIO
        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader
        Dim strLinea As String = STR_VACIO

        Try

            frm.Titulo = " Contact Supplier "
                frm.Campos = " cnt_codigo Codigo , cnt_nombre,cnt_celular "
                frm.Tabla = "   Contactos "
                frm.FiltroText = " Enter the flow to be filtered"
                frm.Filtro = " cnt_codigo "
                frm.Condicion = " cnt_sisemp = " & Sesion.IdEmpresa & " AND cnt_tipoemp= 'Clientes' AND cnt_codemp = " & celdaIdCliente2.Text & ""
                frm.ShowDialog(Me)
            If frm.DialogResult = System.Windows.Forms.DialogResult.OK Then
                celdaIdContactoCliente.Text = frm.LLave
                celdaContactoCliente.Text = frm.Dato

            End If

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub
    Private Sub botonAgregar_Click(sender As Object, e As EventArgs) Handles botonAgregar.Click
        Dim frm As New frmSeleccionar
        Dim strSQL As String = STR_VACIO
        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader
        Dim strLinea As String = STR_VACIO
        Dim Contador As Integer

        Try
            frm.Titulo = "Article"
            frm.Campos = " inv_numero Inventario,art_codigo Codigo,art_DCorta Descripcion,m.cat_num id,m.cat_clave Medida,(inv_PRECIOmin * inv_PRECIOfac) Precio,p.cat_clave Origen  "
            frm.Tabla = " Inventarios INNER JOIN Articulos ON art_sisemp = inv_sisemp AND art_codigo = inv_artcodigo " & "LEFT JOIN Catalogos m ON m.cat_clase = 'Medidas' AND m.cat_num = inv_UMventa LEFT JOIN Catalogos p ON p.cat_clase = 'Paises' AND p.cat_num = inv_lugarfab "

            frm.FiltroText = " Enter the Article to  Filtered"
            frm.Filtro = " art_DCorta  "
            frm.Condicion = " inv_generico = 1 AND inv_sisemp =" & Sesion.IdEmpresa & " AND inv_status = 'Activo' AND inv_activo = 0   "
            frm.Ordenamiento = " inv_numero "
            frm.TipoOrdenamiento = " ASC "


            frm.ShowDialog(Me)
            If frm.DialogResult = System.Windows.Forms.DialogResult.OK Then

                'strSQL = " SELECT a.art_DLarga descripcion, COALESCE(p.cat_clave,'') pais, COALESCE(v.pro_proveedor,'') proveedor, m.cat_clave Medida,m.cat_num id "
                'strSQL &= " FROM Inventarios i "
                'strSQL &= " INNER JOIN Articulos a ON a.art_sisemp = i.inv_sisemp AND a.art_codigo = i.inv_artcodigo "
                'strSQL &= " LEFT JOIN Catalogos m ON m.cat_clase = 'Medidas' AND m.cat_num = inv_UMventa "
                'strSQL &= " LEFT JOIN Catalogos p ON p.cat_clase = 'Paises' AND p.cat_num = i.inv_lugarfab "
                'strSQL &= " LEFT JOIN Proveedores v ON v.pro_sisemp = i.inv_sisemp AND v.pro_codigo = i.inv_provcod "
                'strSQL &= " WHERE i.inv_sisemp={empresa} AND i.inv_numero={codigo} "
                'strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
                'strSQL = Replace(strSQL, "{codigo}", frm.LLave)

                'MyCnn.CONECTAR = strConexion
                'COM = New MySqlCommand(strSQL, CON)
                'REA = COM.ExecuteReader


                strLinea = frm.LLave & "|"
                strLinea &= frm.Dato2 & "|"
                strLinea &= frm.Dato4 & "|"
                strLinea &= frm.Dato3 & "|"
                strLinea &= "0.00|"
                strLinea &= "0.00|"
                strLinea &= "|"
                strLinea &= "0.00|"
                strLinea &= "|"
                strLinea &= "|"
                strLinea &= "|"
                strLinea &= "|"
                strLinea &= "|"
                strLinea &= "|"
                strLinea &= "|"
                strLinea &= "|"
                strLinea &= "|"
                strLinea &= "|"
                strLinea &= "|"
                strLinea &= "|"
                strLinea &= "|"
                strLinea &= "0|"
                strLinea &= "|"
                strLinea &= "|"
                strLinea &= "Unsold" & "|"
                strLinea &= "|"
                strLinea &= INT_CERO & "|"
                strLinea &= INT_CERO
                cFunciones.AgregarFila(dgvDetalle, strLinea)
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub
    Private Sub dgvDetalle_DoubleClick(sender As Object, e As EventArgs) Handles dgvDetalle.DoubleClick
        If dgvDetalle.Rows.Count = 0 Then Exit Sub
        Try
            Select Case dgvDetalle.CurrentCell.ColumnIndex
                Case 0
                    Dim frm As New frmSeleccionar
                    Dim strSQL As String = STR_VACIO
                    Dim strLinea As String = STR_VACIO

                    Try

                        frm.Titulo = "Article"
                        frm.Campos = " inv_numero Inventario,art_codigo Codigo,art_DCorta Descripcion,m.cat_num id,m.cat_clave Medida,(inv_PRECIOmin * inv_PRECIOfac) Precio,p.cat_clave Origen  "
                        frm.Tabla = " Inventarios INNER JOIN Articulos ON art_sisemp = inv_sisemp AND art_codigo = inv_artcodigo " & "LEFT JOIN Catalogos m ON m.cat_clase = 'Medidas' AND m.cat_num = inv_UMventa LEFT JOIN Catalogos p ON p.cat_clase = 'Paises' AND p.cat_num = inv_lugarfab "

                        frm.FiltroText = " Enter the Article to  Filtered"
                        frm.Filtro = " art_DCorta  "
                        frm.Condicion = " inv_generico = 1 AND inv_sisemp =" & Sesion.IdEmpresa & " AND inv_status = 'Activo' AND inv_activo = 0   "
                        frm.Ordenamiento = " art_DCorta "
                        frm.TipoOrdenamiento = " ASC "

                        frm.ShowDialog(Me)
                        If frm.DialogResult = System.Windows.Forms.DialogResult.OK Then
                            dgvDetalle.CurrentRow.Cells("colCodigo").Value = frm.LLave
                            dgvDetalle.CurrentRow.Cells("colDescripcion").Value = frm.Dato2
                            dgvDetalle.CurrentRow.Cells("colMedidas").Value = frm.Dato4
                            dgvDetalle.CurrentRow.Cells("colUnidad").Value = frm.Dato3
                        End If
                    Catch ex As Exception
                        MsgBox(ex.ToString)
                    End Try
                Case 14
                        Dim frm As New frmSeleccionar
                        frm.Titulo = " Catalog of purchases "
                        frm.Campos = " pro_codigo, pro_proveedor, pro_status "
                        frm.Tabla = " Proveedores"
                        frm.FiltroText = " Enter The Name of the manufacturer "
                        frm.Filtro = "   pro_proveedor "
                        frm.Condicion = " pro_sisemp = " & Sesion.IdEmpresa & " AND pro_fabricante='Si' "
                        frm.Ordenamiento = " pro_codigo "
                        frm.ShowDialog(Me)
                        If frm.DialogResult = System.Windows.Forms.DialogResult.OK Then
                            dgvDetalle.CurrentRow.Cells("CodFabricante").Value = frm.LLave
                            dgvDetalle.CurrentRow.Cells("colFabricante").Value = frm.Dato
                        End If
                    '     Case 16
                    '       Dim frm As New frmDateTimePicker
                    '     frm.ShowDialog(Me)
                    '     If frm.DialogResult = System.Windows.Forms.DialogResult.OK Then
                    '     dgvDetalle.CurrentRow.Cells("colFechaDetalle").Value = frm.LLave
              '      End If
                        Case 19
                        Dim frm As New frmOption
                        frm.Opciones = "ACTIVO |" & " Cancelado (despachado) "
                        frm.Titulo = " DOCUMENTS NOTES "
                        frm.ShowDialog(Me)
                        Me.DialogResult = DialogResult.OK
                        Select Case frm.Seleccion
                            Case 0  ' Notas de Ingreso 
                                dgvDetalle.CurrentRow.Cells("colEstadoDetalle").Value = " "
                            Case 1 ' Sin Notas 
                                dgvDetalle.CurrentRow.Cells("colEstadoDetalle").Value = "SI"
                        End Select
                Case 23
                    Dim frmDownload As New frmDescargosPO

                    frmDownload.Anio = CeldaAño.Text
                    frmDownload.Numero = CeldaNumero.Text
                    frmDownload.Linea = dgvDetalle.CurrentRow.Cells("colFila").Value
                    frmDownload.ShowDialog(Me)
                    If frmDownload.DialogResult = System.Windows.Forms.DialogResult.OK Then
                        CargarDetalle(CeldaNumero.Text)
                        CargarDescargo(CeldaNumero.Text, CeldaAño.Text)

                    Else
                        CargarDescargo(CeldaNumero.Text, CeldaAño.Text)
                        CargarDetalle(CeldaNumero.Text)
                    End If
                Case 22
                        Dim frm As New frmSeleccionar
                        frm.Titulo = " Destination Country"
                        frm.Campos = " cat_pid ID, cat_clave Codigo, UPPER(cat_desc) Descripcion "
                        frm.Tabla = " Catalogos "
                        frm.FiltroText = " enter the name of the country to filter "
                        frm.Filtro = " cat_desc "
                        frm.Condicion = " cat_clase='PaisDestino' "
                        frm.Ordenamiento = " cat_pid "
                        frm.TipoOrdenamiento = " ASC "

                        frm.ShowDialog(Me)
                    If frm.DialogResult = System.Windows.Forms.DialogResult.OK Then
                        dgvDetalle.CurrentRow.Cells("colIDP").Value = frm.LLave
                        dgvDetalle.CurrentRow.Cells("colPais").Value = frm.Dato2


                    End If

                Case 24
                        Dim frm As New frmOption
                        frm.Opciones = "Unsold |" & " Sold "
                        frm.Titulo = " Status "
                        frm.ShowDialog(Me)
                        Me.DialogResult = DialogResult.OK
                    Select Case frm.Seleccion
                        Case 0  ' Notas de Ingreso 
                            dgvDetalle.CurrentRow.Cells("colStatus").Value = "Unsold"
                            dgvDetalle.CurrentRow.Cells("colVendido").Value = STR_VACIO
                            dgvDetalle.CurrentRow.Cells("colidVendido").Value = INT_CERO
                        Case 1 ' Sin Notas 
                            dgvDetalle.CurrentRow.Cells("colStatus").Value = "Sold"
                    End Select

                Case 25
                        Dim frm As New frmSeleccionar
                        If dgvDetalle.CurrentRow.Cells("colStatus").Value = "Sold" Then

                            'Propiedades de la consulta 
                            frm.Campos = " cli_codigo Code, cli_cliente Client"
                            frm.Tabla = " Clientes"
                            frm.Condicion = " cli_sisemp = " & Sesion.IdEmpresa & ""
                            frm.Ordenamiento = " cli_cliente"
                            frm.Filtro = " cli_cliente"
                            frm.Limite = " 20 "
                            ' Propiedades del Formulario 
                            frm.Titulo = "Provider"
                            frm.FiltroText = "Enter the name of the client to filter"
                            frm.ShowDialog(Me)
                            If frm.DialogResult = System.Windows.Forms.DialogResult.OK Then
                                dgvDetalle.CurrentRow.Cells("colVendido").Value = frm.Dato
                                dgvDetalle.CurrentRow.Cells("colidVendido").Value = frm.LLave
                            End If
                        End If
            End Select


        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub
    Private Sub dgvDetalle_SelectionChanged(sender As Object, e As EventArgs) Handles dgvDetalle.SelectionChanged
        VerInformacionDeHilo()

    End Sub

    Private Sub VerInformacionDeHilo()
        Dim intHilo As Integer
        Try

            If dgvDetalle.Rows.Count > 0 Then
                intHilo = dgvDetalle.CurrentRow.Cells("colCodigo").Value
                If Me.Tag = "Mod" Then
                    CargarHilo(intHilo, dgvDetalle.CurrentRow.Cells("colFila").Value)
                Else
                    CargarHilo(intHilo, dgvDetalle.CurrentRow.Index + 1)
                End If
            End If
            'End If

        Catch ex As Exception
            ' MsgBox(ex.ToString)
        End Try
    End Sub
    Private Sub Encabezado1_ClickGuardar(sender As Object, click As Boolean) Handles Encabezado1.ClickGuardar
        Try
            If ComprobarDatos() Then
                If ComprobarFila() Then
                    If Guardar() = True Then
                        If MsgBox("Do you want to close the document?", vbYesNo, "Notice") = vbYes Then
                            MostrarLista(True)
                        Else
                            For i As Integer = 0 To dgvDetalle.Rows.Count - 1
                                dgvDetalle.Rows(i).Cells("colDescEstado").Value = 1
                            Next
                            Me.Tag = "Mod"
                        End If
                        Me.Tag = "Mod"
                    End If
                    End If
            End If

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub
    Private Sub btnPedido_Click(sender As Object, e As EventArgs) Handles btnPedido.Click
        Dim frm As New frmOption
        Dim frmS As New frmSeleccionar
        Dim frmA As New frmSeleccionar
        Try



            frm.Opciones = CeldaCliente.Text & "|" & " otro (seleccionar del listado) "
            frm.Titulo = " DOCUMENTS NOTES "
            frm.ShowDialog(Me)
            Me.DialogResult = DialogResult.OK
            Select Case frm.Seleccion
                Case 0  ' Cliente seleccionado 
                    frmS.Titulo = "Client "
                    frmS.Campos = " DISTINCT HDoc_Sis_Emp empresa, HDoc_Doc_Cat tipo, HDoc_Doc_Ano año, HDoc_Doc_Num numero, HDoc_Doc_Fec fecha, COALESCE(HDoc_DR1_Num,'') referencia, HDoc_Usuario usuario, HDoc_RF1_Dbl Total "
                    frmS.Tabla = "  Dcmtos_HDR a  LEFT JOIN Dcmtos_DTL b ON a.HDoc_Sis_Emp = b.DDoc_Sis_Emp AND a.HDoc_Doc_Cat = b.DDoc_Doc_Cat AND a.HDoc_Doc_Ano = b.DDoc_Doc_Ano AND a.HDoc_Doc_Num = b.DDoc_Doc_Num  "
                    'frmS.FiltroText = " Enter the flow to be filtered"
                    ' frmS.Filtro = " cli_cliente "
                    frmS.Condicion = " HDoc_Sis_Emp = " & Sesion.IdEmpresa & " AND (HDoc_Doc_Cat = 75) AND (HDoc_Emp_Cod = " & celdaIdCliente2.Text & ") AND HDoc_Doc_Status = 1 AND b.DDoc_RF2_Num=0  "
                    frmS.Ordenamiento = " HDoc_Doc_Ano DESC, HDoc_Doc_Num  "
                    frmS.ShowDialog(Me)
                    If frmS.DialogResult = System.Windows.Forms.DialogResult.OK Then
                        celdaCatalogo.Text = frmS.Dato
                        celdaAnio.Text = frmS.Dato2
                        celdanumero1.Text = frmS.Dato3
                        CeldaPedido.Text = "PF " & frmS.Dato3
                        '  CeldaCliente.Text = frm.Dato
                    End If

                Case 1
                    frmS.Titulo = "Client "
                    frmS.Campos = " cli_codigo Codigo , cli_cliente Cliente"
                    frmS.Tabla = "  Clientes "
                    frmS.FiltroText = " Enter the flow to be filtered"
                    frmS.Filtro = " cli_cliente "
                    frmS.Condicion = " cli_sisemp  = " & Sesion.IdEmpresa & " AND cli_status = 'Activo'  "
                    frmS.Ordenamiento = " cli_cliente "
                    frmS.TipoOrdenamiento = " ASC "
                    frmS.ShowDialog(Me)
                    If frm.DialogResult = System.Windows.Forms.DialogResult.OK Then

                        frmA.Titulo = "Client "
                        frmA.Campos = " DISTINCT HDoc_Sis_Emp empresa, HDoc_Doc_Cat tipo, HDoc_Doc_Ano año, HDoc_Doc_Num numero, HDoc_Doc_Fec fecha, COALESCE(HDoc_DR1_Num,'') referencia, HDoc_Usuario usuario, HDoc_RF1_Dbl Total "
                        frmA.Tabla = "  Dcmtos_HDR a  LEFT JOIN Dcmtos_DTL b ON a.HDoc_Sis_Emp = b.DDoc_Sis_Emp AND a.HDoc_Doc_Cat = b.DDoc_Doc_Cat AND a.HDoc_Doc_Ano = b.DDoc_Doc_Ano AND a.HDoc_Doc_Num = b.DDoc_Doc_Num  "
                        'frmS.FiltroText = " Enter the flow to be filtered"
                        ' frmS.Filtro = " cli_cliente "
                        frmA.Condicion = " HDoc_Sis_Emp = " & Sesion.IdEmpresa & " AND (HDoc_Doc_Cat = 75) AND (HDoc_Emp_Cod = " & frmS.LLave & ") AND HDoc_Doc_Status = 1 AND b.DDoc_RF2_Num=0  "
                        frmA.Ordenamiento = " HDoc_Doc_Ano DESC, HDoc_Doc_Num  "
                        frmA.ShowDialog(Me)
                        If frmA.DialogResult = System.Windows.Forms.DialogResult.OK Then
                            celdaCatalogo.Text = frmA.Dato
                            celdaAnio.Text = frmA.Dato2
                            celdanumero1.Text = frmA.Dato3
                            CeldaPedido.Text = "PF " & frmA.Dato3
                            '  CeldaCliente.Text = frm.Dato
                        End If

                    End If



            End Select

        Catch ex As Exception

        End Try
    End Sub
    Private Sub dgLista_DoubleClick(sender As Object, e As EventArgs) Handles dgLista.DoubleClick
        Dim Codigo As Integer = NO_FILA
        Dim Anio As Integer = NO_FILA
        If dgLista.Rows.Count = 0 Then Exit Sub
        Try
            Reset()
            Me.Tag = "Mod"

            Anio = dgLista.SelectedCells(0).Value
            Codigo = dgLista.SelectedCells(1).Value
            CargarEncabezado(Anio, Codigo)
            CargarDetalle(Codigo)
            CargardgDocumentos(Anio, Codigo)
            CargarDescargo(Codigo, Anio)
            'Limpiar()
            MostrarLista(False)
            BloquearBotones(False)
            BloquearJob()

            If Sesion.idGiro = 1 Then
                Label21.Text = "Incotern"
                Label20.Text = "Credit Days"
                botonContactoCliente.Visible = False
                botonContactoCliente.Enabled = False
                celdaContactoCliente.ReadOnly = False
                celdaPrice.ReadOnly = True
                botonIncotern.Visible = True

            Else
                Label20.Text = "Contac"
                Label21.Text = "Price"
                botonContactoCliente.Visible = True
                celdaContactoCliente.ReadOnly = True
                botonContactoCliente.Enabled = True
                celdaPrice.ReadOnly = False
                botonIncotern.Visible = False
            End If
        Catch ex As Exception

        End Try
    End Sub
    Private Sub botonQuitar_Click(sender As Object, e As EventArgs) Handles botonQuitar.Click
        Try
            Dim Count As Integer
            If dgvDetalle.SelectedRows Is Nothing Then Exit Sub
            If dgvDetalle.Rows.Count > 1 Then
                Count = dgvDetalle.Rows.GetRowCount(DataGridViewElementStates.Selected)
                For i As Integer = 0 To Count - 1
                    If MsgBox("You sure you want to delete the row " & "OF THE ORDER " &
                    CInt(dgvDetalle.SelectedCells(0).Value) & ", " &
               CStr(dgvDetalle.SelectedCells(1).Value) & " " &
                CStr(dgvDetalle.SelectedCells(2).Value) & " " &
                   CStr(dgvDetalle.SelectedCells(3).Value) & "?", vbQuestion + vbYesNo + vbDefaultButton2) =
                    vbYes Then
                        If dgvDetalle.SelectedCells(27).Value = 0 Or dgvDetalle.SelectedCells(27).Value = 1 Then
                            dgvDetalle.SelectedCells(27).Value = 2
                            If dgvDetalle.SelectedCells(27).Value = 2 Then
                                dgvDetalle.CurrentRow.Visible = False
                            End If
                        ElseIf dgvDetalle.Rows(i).Selected = Nothing Then
                            '  dgDetalle.SelectedCells(6).Value = 3
                            ' dgDetalle.CurrentRow.Visible = False
                            dgvDetalle.Rows.RemoveAt(dgvDetalle.RowCount - 1)
                        End If
                    End If
                Next
            Else
                MsgBox("you can not delete the last row")
                Exit Sub
            End If
            dgvDetalle.ReadOnly = False
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub
    Private Sub dgLista_KeyDown(sender As Object, e As KeyEventArgs) Handles dgLista.KeyDown
        Try
            If e.KeyCode = Keys.F3 Then
                cFunciones.BuscarenLista(dgLista)
                e.Handled = True
                e.SuppressKeyPress = True
            ElseIf e.KeyCode = Keys.F6 Then
                '     cfun.MostrarDependencias(948, dgLista.SelectedCells(1).Value, dgLista.SelectedCells(0).Value)
            ElseIf e.KeyCode = Keys.F7 Then
                Dim rpt As New clsReportes
                rpt.Historial(dgLista.SelectedCells(1).Value, dgLista.SelectedCells(0).Value, catalogos)

            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub
    Private Sub dgvDetalle_CellEndEdit(sender As Object, e As DataGridViewCellEventArgs) Handles dgvDetalle.CellEndEdit
        CalcularTotal()
    End Sub
    Private Sub dgdatos_DoubleClick(sender As Object, e As EventArgs) Handles dgdatos.DoubleClick
        Dim strDocumento As String

        strDocumento = dgdatos.CurrentRow.Cells("colDes").Value
        SDoc.SubDocumento = dgdatos.CurrentRow.Cells("colDes").Value
        SDoc.Año = CInt(CeldaAño.Text)
        SDoc.Numero = CInt(CeldaNumero.Text)
        SDoc.Catalogo = catalogos
        SDoc.Doc = strDocumento
        SDoc.TasaC = CeldaTasa.Text

        SDoc.ShowDialog(Me)

    End Sub
    Private Sub btnFiltro_Click(sender As Object, e As EventArgs) Handles btnFiltro.Click
        queryListaOrden()
    End Sub

    Private Sub botonContenedores_Click(sender As Object, e As EventArgs) Handles botonContenedores.Click
        If Not dgvDetalle.SelectedRows.Count.Equals(INT_CERO) And dgvDetalle.CurrentRow IsNot Nothing Then
            DividirCantidadEnContenedores()
        Else
            MsgBox("You must select a record")
        End If
    End Sub

    Private Sub botonImprimir_Click(sender As Object, e As EventArgs) Handles botonImprimir.Click
        ImprimirOrden()
    End Sub

    Private Sub ImprimirOrden()
        If logConsultar = True Then
            Dim cRep As New clsReportes
            Dim frm As New frmOption
            Dim frm2 As New frmOption
            Dim logCIF As Boolean = False
            Dim logFOB As Boolean = False
            Dim Si As Boolean = False
            Dim No As Boolean = False

            frm2.Opciones = "Yes |" & "No"
            frm2.Titulo = "Printing Notes"
            frm2.Mensaje = "Do you want printing notes?"
            If frm2.ShowDialog = System.Windows.Forms.DialogResult.OK Then
                Select Case frm2.Seleccion
                    Case 0
                        Si = True
                        No = False
                    Case 1
                        Si = False
                        No = True
                End Select
            End If
            frm.Opciones = "Show FOB AND CIF |" & "Show Only CIF |" & "Show Only FOB "
            frm.Titulo = "Printing Formats "
            frm.Mensaje = "Select type of printing "
            If frm.ShowDialog = System.Windows.Forms.DialogResult.OK Then
                Select Case frm.Seleccion
                    Case 0
                        logCIF = True
                        logFOB = True
                        cRep.ReporteOrdenRequisicion(CInt(CeldaAño.Text), CInt(CeldaNumero.Text), logCIF, logFOB, Si, No)
                        cRep.Parent = Fprincipal

                    Case 1
                        logCIF = True
                        logFOB = False
                        cRep.ReporteOrdenRequisicion(CInt(CeldaAño.Text), CInt(CeldaNumero.Text), logCIF, logFOB, Si, No)
                        cRep.Parent = Fprincipal

                    Case 2
                        logCIF = False
                        logFOB = True
                        cRep.ReporteOrdenRequisicion(CInt(CeldaAño.Text), CInt(CeldaNumero.Text), logCIF, logFOB, Si, No)
                        cRep.Parent = Fprincipal

                End Select
            End If
        End If

    End Sub

    Private Sub Encabezado1_ClickBorrar(sender As Object, click As Boolean) Handles Encabezado1.ClickBorrar
        If LogBorrar = True Then
            Dim AnioDP As Integer = 0
            Dim NumeroDP As Integer = 0
            Dim strSQL As String = STR_VACIO
            Dim COM As MySqlCommand
            Dim REA As MySqlDataReader
            If Dependecias() > INT_CERO Then
                MsgBox("This Document can not be canceled, is related to other agencies", MsgBoxStyle.Critical, "Warning")

            Else
                If MsgBox("Are You sure " & vbCr & vbCr & "¿do you want to delete this document? ", vbQuestion + vbYesNo, "Aviso") = vbYes Then
                    BorrarEncabezadoOrden(celdaAnio.Text, CeldaNumero.Text)
                    BorrarDetalleOrden(celdaAnio.Text, CeldaNumero.Text)
                    BorrarITMOrden(celdaAnio.Text, CeldaNumero.Text)
                    MsgBox("Delete Complete")
                    MostrarLista()
                End If
            End If
        End If
    End Sub
    Private Sub checkJob_CheckedChanged(sender As Object, e As EventArgs) Handles checkJob.CheckedChanged
        BloquearJob()
    End Sub
    Private Sub botonImprimirOrden_Click(sender As Object, e As EventArgs) Handles botonImprimirOrden.Click

        OrdenJobPrideManufacturing()

    End Sub
    Private Sub dtpFecha_ValueChanged(sender As Object, e As EventArgs) Handles dtpFecha.ValueChanged
        If CeldaTasa.Text > 1 Then
            CeldaTasa.Text = cFunciones.TasaSegunFecha(dtpFecha.Value.ToString(FORMATO_MYSQL))
        End If
    End Sub

    Private Sub botonIncotern_Click(sender As Object, e As EventArgs) Handles botonIncotern.Click
        Dim strCondicion As String = STR_VACIO
        Dim frm As New frmSeleccionar

        frm.Tabla = "Catalogos"
        frm.Campos = "  cat_num, cat_desc"
        frm.Condicion = "  cat_clase = 'Costeo'"
        frm.Filtro = "cli_desc"
        frm.Titulo = "Costing"
        frm.FiltroText = "Enter the costing to filter out"
        If frm.ShowDialog = System.Windows.Forms.DialogResult.OK Then
            celdaIdIncotern.Text = frm.LLave
            celdaPrice.Text = frm.Dato
        End If
    End Sub

    Private Sub BarraTitulo1_Load(sender As Object, e As EventArgs)

    End Sub
#End Region


End Class