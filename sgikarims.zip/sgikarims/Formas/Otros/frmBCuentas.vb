﻿Imports System.ComponentModel

Public Class frmBCuentas
    'Modificado: 2019-08-28

#Region "Miembros"
    Private logInsertar As Boolean = False
    Private logConsultar As Boolean = False
    Private logEditar As Boolean = False
    Private logBorrar As Boolean = False

    Private intModo As Integer = INT_CERO
    Private intTipo As Integer = INT_CERO

    Private Base As New clsBancos
    Private cfun As New clsFunciones
#End Region

#Region "Constantes"
    Private Const MODO_LISTA As Integer = vbEmpty
    Private Const MODO_CUENTA As Integer = 1
    Private Const MODO_DOCUMENTO As Integer = 2
#End Region

#Region "Propiedades"
    Public Property Key As String
#End Region

#Region "Funciones"
    Private Sub Accessos()
        Dim cAccesos As New clsAccesos
        Try
            If cAccesos.Accesos(Key) = True Then
                logInsertar = cAccesos.Insertar
                logConsultar = cAccesos.Consultar
                logEditar = cAccesos.Editar
                logBorrar = cAccesos.Borrar
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    'Mostrar la interfaz correspondiente
    Private Sub MostrarLista(ByVal Modo As Integer)
        Select Case Modo
            Case MODO_LISTA
                'Listado de cuentas bancarias
                Titulo.CeldaTitulo.Text = "Bank Accounts".ToUpper
                Lista.Visible = True
                Lista.MostrarLista(Base)

                Botones.botonNuevo.Enabled = True
                Botones.botonGuardar.Enabled = False
                Botones.botonBorrar.Enabled = False
                botonImprimir.Visible = False
            Case MODO_CUENTA
                'Cuenta bancaria
                Cuenta.Visible = True
                Documento.Visible = False
                intTipo = INT_CERO
                Titulo.CeldaTitulo.Text = Cuenta.Titulo

                Botones.botonNuevo.Enabled = False
                Botones.botonGuardar.Enabled = True
                Botones.botonBorrar.Enabled = True
                botonImprimir.Visible = False
            Case MODO_DOCUMENTO
                'Documento
                Titulo.CeldaTitulo.Text = "Documento".ToUpper
                Cuenta.Visible = False
                botonImprimir.Visible = True
                If (Sesion.idGiro = 1) Then
                    botonImprimir.Enabled = True '(intTipo.Equals(Base.IdCheque))
                Else
                    botonImprimir.Enabled = (intTipo.Equals(Base.IdCheque))
                End If

                Select Case intTipo
                    Case Base.IdDeposito, Base.IdCredito, Base.IdCheque, Base.IdDebito
                        Documento.Visible = True
                        Documento.Focus()
                End Select
        End Select
        intModo = Modo
    End Sub

    'Selecciona el grupo del documento de acuerdo a su ID de catalogo
    Private Function SeleccionarGrupo(ByVal Tipo As Integer) As Integer
        Dim intID As Integer = NO_FILA
        Dim strSQL As String = Base.SQLGruposDeDocumento(Tipo)

        Using frm As New frmSeleccionar
            frm.Titulo = " Document Group for " & Base.TextoDeTipo(Tipo)
            frm.Tabla = strSQL
            frm.Campos = "x.ID, x.Description"
            frm.Condicion = "x.ID > 0"
            frm.FiltroText = "Select the group of the new document"
            frm.Filtro = "x.Description"
            frm.Ordenamiento = String.Empty
            frm.TipoOrdenamiento = String.Empty
            frm.ShowDialog()
            If frm.DialogResult = DialogResult.OK Then
                intID = (frm.LLave - 1)
            End If
        End Using
        Return intID
    End Function
#End Region

#Region "Eventos"
    Private Sub frmBCuenta_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Dim szDimension As New Size(Cuenta.Width, Cuenta.Height)
        Dim ptPosicion As New System.Drawing.Point(Cuenta.Left, Cuenta.Top)

        'Ajustar tamaño y posicion de controles
        Lista.Location = ptPosicion
        Documento.Location = ptPosicion

        Lista.Size = szDimension
        Documento.Size = szDimension

        'Nivel de acceso de usuario
        Accessos()
        '  Botones.botonNuevo.Visible = logInsertar
        '  Botones.botonGuardar.Visible = logEditar
        ' Botones.botonBorrar.Visible = logBorrar

        'Mostrar lista de cuentas
        MostrarLista(MODO_LISTA)

        'Cargar ID de documentos bancarios
        Base.CargarTipos()
    End Sub

    Private Sub frmBCuenta_Closing(sender As Object, e As CancelEventArgs) Handles Me.Closing
        Fprincipal.BarraDeTareas1.QuitarFormulario(Key)
    End Sub

    'Cerrar
    Private Sub Botones_ClickCerrar(sender As Object, click As Boolean) Handles Botones.ClickCerrar
        CerrarVista
    End Sub

    Private Sub CerrarVista()
        Dim logModificado As Boolean = False
        Select Case intModo
            Case MODO_LISTA
                'Cerrar formulario
                Me.Close()
                'Fprincipal.BarraDeTareas1.QuitarFormulario(Key)
            Case MODO_CUENTA
                'Cerrar cuenta
                MostrarLista(MODO_LISTA)
                Cuenta.Visible = False
                Lista.MostrarLista(Base)
                Lista.Focus()
            Case MODO_DOCUMENTO
                'Cerrar documento
                Select Case intTipo
                    Case Base.IdDeposito, Base.IdCredito, Base.IdCheque, Base.IdDebito
                        logModificado = Documento.Modificado
                End Select
                MostrarLista(MODO_CUENTA)
                system.Windows.Forms.Application.DoEvents()
                If logModificado Then
                    'Solo recargar para si hay cambios
                    Cuenta.RecargarMovimientos()
                End If
        End Select
    End Sub

    Private Sub Botones_ClickBorrar(sender As Object, click As Boolean) Handles Botones.ClickBorrar
        Dim intID As Integer = vbEmpty
        If logBorrar = True Then
            Select Case intModo
                Case MODO_CUENTA
                    'Borrar cuenta
                    If Cuenta.ID > INT_CERO Then
                        If Cuenta.BorrarCuenta() Then
                            CerrarVista()
                        End If
                    End If
                Case MODO_DOCUMENTO
                    'Borrar documento
                    If Documento.Numero > INT_CERO Then
                        If Documento.Borrar() Then
                            CerrarVista()
                            Cuenta.RecargarMovimientos()
                        End If
                    End If
            End Select
        Else
            MsgBox("You do not have permission for this action", vbInformation, "Notice")
        End If
    End Sub

    'Abrir cuenta seleccionada
    Private Sub Lista_CuentaSeleccionada(ID As Integer) Handles Lista.CuentaSeleccionada
        Cursor.Current = Cursors.WaitCursor

        MostrarLista(MODO_CUENTA)
        Lista.Visible = False

        Titulo.ForeColor = Color.OrangeRed
        Titulo.CeldaTitulo.Text = "Opening bank account..."
        system.Windows.Forms.Application.DoEvents()

        Cuenta.NuevaCuenta()
        Cuenta.CargarCuenta(ID)

        Titulo.ForeColor = SystemColors.ControlText
        Titulo.CeldaTitulo.Text = Cuenta.Titulo
        Cuenta.Focus()
    End Sub

    'Nueva cuenta
    Private Sub Botones_ClickNuevo(sender As Object, click As Boolean) Handles Botones.ClickNuevo
        Select Case intModo
            Case MODO_LISTA
                If logInsertar = True Then
                    'Nueva cuenta bancaria
                    MostrarLista(MODO_CUENTA)
                    Botones.botonBorrar.Enabled = False
                    Lista.Visible = False

                    Titulo.CeldaTitulo.Text = "New bank account"
                    system.Windows.Forms.Application.DoEvents()
                    Cuenta.NuevaCuenta()
                    Cuenta.Focus()
                Else
                    MsgBox("You do not have permission for this action", vbInformation, "Notice")
                End If
        End Select
    End Sub

    'Evento clic del boton Guardar
    Private Sub Botones_ClickGuardar(sender As Object, click As Boolean) Handles Botones.ClickGuardar
        'Dim frm As New frmSeleccionar
        'If Documento.CasillaCobrado.Checked Then
        '    MsgBox("You do not have permission for this action", vbInformation, "Notice")
        '    If cfun.AutorizarCambioDocumentosConciliados = True Then
        '        frm.DialogResult = DialogResult.OK
                'frm.ShowDialog(Me)
                'If frm.DialogResult = System.Windows.Forms.DialogResult.OK Then
        '        If MsgBox("Are You sure " & vbCr & vbCr & "¿do you want to delete this document? ", vbQuestion + vbYesNo, "Aviso") = vbYes Then
        '                GUARDAR()
        '            End If
                'Else
                '    Exit Sub
                'End If
        '    Else
        '        Me.DialogResult = System.Windows.Forms.DialogResult.Cancel
        '        Exit Sub

        '    End If
        'Else
            GUARDAR()
        'End If

    End Sub
    Private Function GUARDAR()
        Select Case intModo
            Case MODO_CUENTA
                'Guardar datos de cuenta bancaria
                If Cuenta.GuardarCuenta Then
                    MostrarLista(MODO_LISTA)
                    Cuenta.Visible = False
                    Lista.Focus()
                End If
            Case MODO_DOCUMENTO
                'Guardar datos de documento
                Select Case intTipo
                    Case Base.IdDeposito, Base.IdCredito, Base.IdCheque, Base.IdDebito

                        If Documento.Guardar(Documento.Fecha.Value) Then        'se envia la fecha como parametro para validar si hay conciliacion en la fecha del documento.
                            MostrarLista(MODO_CUENTA)
                            Documento.Visible = False
                            system.Windows.Forms.Application.DoEvents()
                            Cuenta.RecargarMovimientos()
                        End If
                End Select
        End Select
    End Function
    'Mostrar documento seleccionado o nuevo
    Private Sub Cuenta_DocumentoSeleccionado(Tipo As Integer, Ciclo As Integer, Numero As Integer, Documento As Integer) Handles Cuenta.DocumentoSeleccionado
        Dim intGrupo As Integer = NO_FILA

        'Determinar la clase del documento
        If Numero.Equals(INT_CERO) Then
            intGrupo = SeleccionarGrupo(Tipo)
        End If

        If Not (Numero.Equals(INT_CERO) And intGrupo.Equals(NO_FILA)) Then
            intTipo = Tipo
            MostrarLista(MODO_DOCUMENTO)

            Select Case Tipo
                Case Base.IdDeposito, Base.IdCredito, Base.IdCheque, Base.IdDebito
                    Me.Documento.Tipo = Tipo
                    Me.Documento.Ciclo = Ciclo
                    Me.Documento.Numero = Numero
                    Me.Documento.Documento = Documento
                    Me.Documento.Grupo = intGrupo
                    Me.Documento.Moneda = Cuenta.Moneda
                    Me.Documento.Cuenta = Cuenta.ID
                    Me.Documento.CargarDocumento()
                    Titulo.CeldaTitulo.Text = Me.Documento.Titulo
                Case Base.IdCheque
                Case Base.IdDebito
            End Select
        End If
    End Sub

    'Evento de impresión para cheques
    Private Sub botonImprimir_Click(sender As Object, e As EventArgs) Handles botonImprimir.Click
        If Not Documento.Numero.Equals(INT_CERO) Then
            If (Documento.Tipo = 51) Then 'CHEQUE
                Using frm As New frmBCheque
                    frm.Titulo = Cuenta.Titulo
                    frm.PrepararDocumento(Cuenta.ID, Documento.Tipo, Documento.Ciclo, Documento.Numero)
                    frm.CargarReporte()
                    frm.ShowDialog()
                End Using
            Else
                Dim ClsReportes As New clsReportes
                ClsReportes.impresion_Notas_NC_ND(Documento.Tipo, Documento.Ciclo, Documento.Numero, Documento.CeldaDocumento.Text)

            End If

        End If
    End Sub

#End Region

End Class