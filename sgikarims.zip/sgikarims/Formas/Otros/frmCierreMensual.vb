﻿Imports System.ComponentModel

Public Class frmCierreMensual
#Region "Miembros"
    Dim strKey As String = STR_VACIO
    Dim logInsertar As Boolean = False
    Dim logConsultar As Boolean = False
    Dim logEditar As Boolean = False
    Dim LogBorrar As Boolean = False
    Dim cfun As New clsFunciones
#End Region

#Region "Propiedades"
    Public Property Key As String
        Get
            Return strKey
        End Get
        Set(value As String)
            strKey = value
        End Set
    End Property


#End Region

#Region "Procedimientos "

    Private Sub Accessos()
        Dim cAccesos As New clsAccesos
        Try
            If cAccesos.Accesos(strKey) = True Then
                logInsertar = cAccesos.Insertar
                logConsultar = cAccesos.Consultar
                logEditar = cAccesos.Editar
                LogBorrar = cAccesos.Borrar
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub
    Private Function SQLVerificarExistenciaDeCierre(ByVal fecha As Date) As Integer
        Dim strSQL As String = STR_VACIO
        Dim COM As MySqlCommand
        Dim intExiste As Integer = NO_FILA
        Dim intAnio As Integer = 0
        Dim dtFechaInicial As Date
        Dim dtFechaFinal As Date

        Try

            intAnio = Year(fecha)
            dtFechaInicial = DateSerial(Year(fecha), 1, 1)
            dtFechaFinal = DateSerial(Year(fecha), Month(fecha) + 1, 0)

            strSQL = " SELECT e.CE_Numero existe "
            strSQL &= "    From Cierre_Encabezado e "
            strSQL &= "    WHERE e.CE_Empresa = {emp} AND e.CE_Anio = {anio} AND e.CE_Fecha_Inicial = '{finicial}' AND e.CE_Fecha_Final = '{ffinal}' "

            strSQL = Replace(strSQL, "{emp}", Sesion.IdEmpresa)
            strSQL = Replace(strSQL, "{anio}", intAnio)
            strSQL = Replace(strSQL, "{finicial}", dtFechaInicial.ToString(FORMATO_MYSQL))
            strSQL = Replace(strSQL, "{ffinal}", dtFechaFinal.ToString(FORMATO_MYSQL))

            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSQL, CON)
            intExiste = COM.ExecuteScalar

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try

        Return intExiste
    End Function

    Private Function SQLVerificaElEstadoDelCierre(ByVal fecha As Date)
        Dim strSQL As String = STR_VACIO
        Dim COM As MySqlCommand
        Dim intEstado As Integer = NO_FILA
        Dim intAnio As Integer = 0
        Dim dtFechaInicial As Date
        Dim dtFechaFinal As Date

        Try

            intAnio = Year(fecha)
            dtFechaInicial = DateSerial(Year(fecha), 1, 1)
            dtFechaFinal = DateSerial(Year(fecha), Month(fecha) + 1, 0)

            strSQL = "SELECT e.CE_Estado estado "
            strSQL &= "    From Cierre_Encabezado e "
            strSQL &= "    WHERE e.CE_Empresa = {emp} AND e.CE_Anio = {anio} AND e.CE_Fecha_Inicial = '{finicial}' AND e.CE_Fecha_Final = '{ffinal}' "

            strSQL = Replace(strSQL, "{emp}", Sesion.IdEmpresa)
            strSQL = Replace(strSQL, "{anio}", intAnio)
            strSQL = Replace(strSQL, "{finicial}", dtFechaInicial.ToString(FORMATO_MYSQL))
            strSQL = Replace(strSQL, "{ffinal}", dtFechaFinal.ToString(FORMATO_MYSQL))

            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSQL, CON)
            intEstado = COM.ExecuteScalar

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try

        Return intEstado
    End Function

    Private Function NuevoIdCierre(ByVal fecha As Date) As Integer
        Dim strSQL As String = STR_VACIO
        Dim COM As MySqlCommand
        Dim intNum As Integer = 0

        Try
            strSQL = " Select IFNULL(MAX(CE_Numero),0) +1 id "
            strSQL &= "    From Cierre_Encabezado c "
            strSQL &= "    Where c.CE_Empresa = {emp} And c.CE_Anio = {anio} "

            strSQL = Replace(strSQL, "{emp}", Sesion.IdEmpresa)
            strSQL = Replace(strSQL, "{anio}", Year(fecha.ToString(FORMATO_MYSQL)))

            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSQL, CON)
            intNum = COM.ExecuteScalar

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        Return intNum
    End Function

    Public Sub InsertEncabezadoCierre(ByVal fecha As Date, ByVal id As Integer)
        Dim strSql As String = STR_VACIO
        Dim dtFechaInicial As Date
        Dim dtFechaFinal As Date
        Dim COM As MySqlCommand

        Try

            dtFechaInicial = DateSerial(Year(fecha), 1, 1)
            dtFechaFinal = DateSerial(Year(fecha), Month(fecha) + 1, 0)

            strSql = " Insert Into Cierre_Encabezado VALUES({emp},{anio}, {num}, '{creacion}','{desc}','{inicial}','{final}','{user}',0) "
            strSql = Replace(strSql, "{emp}", Sesion.IdEmpresa)
            strSql = Replace(strSql, "{anio}", Year(fecha.ToString(FORMATO_MYSQL)))
            strSql = Replace(strSql, "{num}", id)
            strSql = Replace(strSql, "{creacion}", cFunciones.HoyMySQL.ToString(FORMATO_MYSQL))
            strSql = Replace(strSql, "{desc}", "Cierre del mes de " & cFunciones.MesALetras(Month(fecha.ToString(FORMATO_MYSQL))))
            strSql = Replace(strSql, "{inicial}", dtFechaInicial.ToString(FORMATO_MYSQL))
            strSql = Replace(strSql, "{final}", dtFechaFinal.ToString(FORMATO_MYSQL))
            strSql = Replace(strSql, "{user}", Sesion.Usuario)

            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSql, CON)
            COM.ExecuteNonQuery()

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try

    End Sub

    Public Sub InsertDetalleCierre(ByVal fecha As Date, ByVal id As Integer)
        Dim strSql As String = STR_VACIO
        Dim dtFechaInicial As Date
        Dim dtFechaFinal As Date
        Dim COM As MySqlCommand

        Try
            dtFechaInicial = DateSerial(Year(fecha), 1, 1)
            dtFechaFinal = DateSerial(Year(fecha), Month(fecha) + 1, 0)

            strSql = " Insert Into Cierre_Detalle ( "
            strSql &= "     SELECT {emp}, {anio} anio, {num} numero, @rownum:=@rownum +1 linea,IFNULL(d.cuenta,'') cuenta, SUM(IF(d.operacion = 'C', d.importe,0)) cargo, SUM(IF (d.operacion = 'A',d.importe,0)) abono "
            strSql &= "    FROM ( "
            strSql &= "    Select @rownum:=0)a, {conta}.polizas p "
            strSql &= "    Left JOIN {conta}.detalle_polizas d ON d.empresa = p.empresa AND d.ejercicio = p.ejercicio AND d.poliza = p.poliza "
            strSql &= "        WHERE p.empresa = {emp} AND (p.tipo NOT IN(4,5)) AND p.fecha BETWEEN '{inicial}' AND '{final}' "
            strSql &= "        GROUP BY d.cuenta ORDER BY d.cuenta) "

            strSql = Replace(strSql, "{emp}", Sesion.IdEmpresa)
            strSql = Replace(strSql, "{anio}", Year(fecha.ToString(FORMATO_MYSQL)))
            strSql = Replace(strSql, "{num}", id)
            strSql = Replace(strSql, "{inicial}", dtFechaInicial.ToString(FORMATO_MYSQL))
            strSql = Replace(strSql, "{final}", dtFechaFinal.ToString(FORMATO_MYSQL))
            strSql = Replace(strSql, "{conta}", cFunciones.ContaEmpresa)

            MyCnn.CONECTAR = strConexion & ";Allow User Variables=True"
            COM = New MySqlCommand(strSql, CON)
            COM.ExecuteNonQuery()

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Public Sub BorrarEncabezadoCierre(ByVal fecha As Date, ByVal numero As Integer)
        Dim strSQL As String = STR_VACIO
        Dim COM As MySqlCommand

        Try
            strSQL = " Delete From Cierre_Encabezado Where CE_Empresa = {emp} AND CE_Anio = {anio} AND CE_Numero = {num} "
            strSQL = Replace(strSQL, "{emp}", Sesion.IdEmpresa)
            strSQL = Replace(strSQL, "{anio}", Year(fecha.ToString(FORMATO_MYSQL)))
            strSQL = Replace(strSQL, "{num}", numero)

            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSQL, CON)
            COM.ExecuteNonQuery()

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Public Sub BorrarDetalleCierre(ByVal fecha As Date, ByVal numero As Integer)
        Dim strSQL As String = STR_VACIO
        Dim COM As MySqlCommand

        Try
            strSQL = " Delete From Cierre_Detalle Where CD_Empresa = {emp} AND CD_Anio = {anio} AND CD_Numero = {num} "
            strSQL = Replace(strSQL, "{emp}", Sesion.IdEmpresa)
            strSQL = Replace(strSQL, "{anio}", Year(fecha.ToString(FORMATO_MYSQL)))
            strSQL = Replace(strSQL, "{num}", numero)

            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSQL, CON)
            COM.ExecuteNonQuery()

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Function SQLCargarListaPrincipal()
        Dim strSQL As String = STR_VACIO

        strSQL = " SELECT e.CE_Numero numero, e.CE_Anio anio, e.CE_Descripcion Descripcion, IF(e.CE_Estado= 1,'Cerrado', '') estado "
        strSQL &= "    From Cierre_Encabezado e "
        strSQL &= "    WHERE e.CE_Empresa = {emp} "
        strSQL &= "    ORDER BY e.CE_Fecha_Final DESC "

        strSQL = Replace(strSQL, "{emp}", Sesion.IdEmpresa)

        Return strSQL
    End Function

    Public Sub CargarListaPrincipal()
        Dim strSQL As String = STR_VACIO
        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader
        Dim strFila As String = STR_VACIO

        Try
            strSQL = SQLCargarListaPrincipal()

            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSQL, CON)
            REA = COM.ExecuteReader
            dgLista.Rows.Clear()

            If REA.HasRows Then

                Do While REA.Read
                    strFila = REA.GetInt32("numero") & "|"
                    strFila &= REA.GetInt32("anio") & "|"
                    strFila &= REA.GetString("Descripcion") & "|"
                    strFila &= REA.GetString("estado")

                    cFunciones.AgregarFila(dgLista, strFila)
                Loop

            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

#End Region


#Region "Eventos"
    Private Sub Encabezado1_ClickNuevo(sender As Object, click As Boolean) Handles Encabezado1.ClickNuevo
        Dim dtp As New frmDateTimePicker
        Dim idCierre As Integer = 0
        Dim intNumeroCierreExistente As Integer = 0
        dtp.DateTimePicker1.Value = cFunciones.HoyMySQL
        dtp.ShowDialog(Me)

        Try
            intNumeroCierreExistente = SQLVerificarExistenciaDeCierre(dtp.DateTimePicker1.Value.ToString(FORMATO_MYSQL))

            If dtp.DialogResult = System.Windows.Forms.DialogResult.OK Then
                If intNumeroCierreExistente > 0 Then
                    If SQLVerificaElEstadoDelCierre(dtp.DateTimePicker1.Value.ToString(FORMATO_MYSQL)) = 1 Then
                        MsgBox("No se puede modificar el Cierre", vbInformation + vbCritical)
                        Exit Sub
                    Else
                        If MsgBox("El Cierre del mes de " & cFunciones.MesALetras(Month(dtp.DateTimePicker1.Value.ToString(FORMATO_MYSQL))) & " ya existe, desea reemplazar los datos?", vbQuestion + vbYesNo) = vbYes Then
                            ' Borra Datos
                            BorrarEncabezadoCierre(dtp.DateTimePicker1.Value.ToString(FORMATO_MYSQL), intNumeroCierreExistente)
                            BorrarDetalleCierre(dtp.DateTimePicker1.Value.ToString(FORMATO_MYSQL), intNumeroCierreExistente)
                            cfun.EscribirRegistro("Cierre", clsFunciones.AccEnum.acDelete, intNumeroCierreExistente, 1, Year(dtp.DateTimePicker1.Value.ToString(FORMATO_MYSQL)), intNumeroCierreExistente, "Reemplazó datos")
                            'Inserta Datos
                            idCierre = NuevoIdCierre(dtp.DateTimePicker1.Value.ToString(FORMATO_MYSQL))
                            InsertEncabezadoCierre(dtp.DateTimePicker1.Value.ToString(FORMATO_MYSQL), idCierre)
                            InsertDetalleCierre(dtp.DateTimePicker1.Value.ToString(FORMATO_MYSQL), idCierre)
                            cfun.EscribirRegistro("Cierre", clsFunciones.AccEnum.acAdd, idCierre, 1, Year(dtp.DateTimePicker1.Value.ToString(FORMATO_MYSQL)), idCierre)
                            MsgBox("Datos Reemplazados", vbInformation)
                            CargarListaPrincipal()
                        Else
                            Exit Sub
                        End If
                    End If
                Else
                    'Iserta Datos
                    idCierre = NuevoIdCierre(dtp.DateTimePicker1.Value.ToString(FORMATO_MYSQL))
                    InsertEncabezadoCierre(dtp.DateTimePicker1.Value.ToString(FORMATO_MYSQL), idCierre)
                    InsertDetalleCierre(dtp.DateTimePicker1.Value.ToString(FORMATO_MYSQL), idCierre)
                    cfun.EscribirRegistro("Cierre", clsFunciones.AccEnum.acAdd, idCierre, 1, Year(dtp.DateTimePicker1.Value.ToString(FORMATO_MYSQL)), idCierre)
                    CargarListaPrincipal()
                End If
                If MsgBox("Desea imprimir los saldos?", vbQuestion + vbYesNo, "?") = vbYes Then
                    ImprimirCierre()
                End If
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub frmCierreMensual_Load(sender As Object, e As EventArgs) Handles Me.Load
        Accessos()
        Encabezado1.botonGuardar.Enabled = False
        CargarListaPrincipal()
    End Sub

    Private Sub Encabezado1_ClickCerrar(sender As Object, click As Boolean) Handles Encabezado1.ClickCerrar
        Me.Close()
    End Sub

    Private Sub frmCierreMensual_Closing(sender As Object, e As CancelEventArgs) Handles Me.Closing
        Fprincipal.BarraDeTareas1.QuitarFormulario(Key)
    End Sub

    Private Sub dgLista_DoubleClick(sender As Object, e As EventArgs) Handles dgLista.DoubleClick
        Dim strSql As String = STR_VACIO
        Dim COM As MySqlCommand

        If logConsultar = True Then

            Select Case dgLista.CurrentCell.ColumnIndex
                    Case 3
                        If dgLista.CurrentRow.Cells("colEstado").Value = STR_VACIO Then
                            strSql = " Update Cierre_Encabezado SET CE_Estado = 1 Where CE_Empresa = {emp} AND CE_Anio = {anio} AND CE_Numero = {num} "
                            strSql = Replace(strSql, "{emp}", Sesion.IdEmpresa)
                            strSql = Replace(strSql, "{anio}", dgLista.CurrentRow.Cells("colAnio").Value)
                            strSql = Replace(strSql, "{num}", dgLista.CurrentRow.Cells("colIdMes").Value)
                            MyCnn.CONECTAR = strConexion
                            COM = New MySqlCommand(strSql, CON)
                            COM.ExecuteNonQuery()
                            cfun.EscribirRegistro("Cierre", clsFunciones.AccEnum.acConfirm, dgLista.CurrentRow.Cells("colIdMes").Value, 1, dgLista.CurrentRow.Cells("colAnio").Value, dgLista.CurrentRow.Cells("colIdMes").Value, "Cerró el mes")
                            CargarListaPrincipal()
                        Else
                            MsgBox("El mes seleccionado se encuentra cerrado", vbCritical)
                        End If
                End Select

            End If

    End Sub

    Private Sub Encabezado1_ClickBorrar(sender As Object, click As Boolean) Handles Encabezado1.ClickBorrar
        Dim strSQL As String = STR_VACIO
        Dim COM As MySqlCommand
        Dim dtFecha As Date

        Try
            If LogBorrar = True Then
                If MsgBox("Desea Eliminar el Cierre del mes Seleccionado ", vbQuestion + vbYesNo) = vbYes Then
                    strSQL = " SELECT CE_Fecha_Inicial fecha "
                    strSQL &= "    From Cierre_Encabezado e "
                    strSQL &= "    WHERE e.CE_Empresa = {emp} AND e.CE_Anio = {anio} AND e.CE_Numero = {num} "

                    strSQL = Replace(strSQL, "{emp}", Sesion.IdEmpresa)
                    strSQL = Replace(strSQL, "{anio}", dgLista.CurrentRow.Cells("colAnio").Value)
                    strSQL = Replace(strSQL, "{num}", dgLista.CurrentRow.Cells("colIdMes").Value)

                    MyCnn.CONECTAR = strConexion
                    COM = New MySqlCommand(strSQL, CON)
                    dtFecha = COM.ExecuteScalar

                    BorrarEncabezadoCierre(dtFecha.ToString(FORMATO_MYSQL), dgLista.CurrentRow.Cells("colIdMes").Value)
                    BorrarDetalleCierre(dtFecha.ToString(FORMATO_MYSQL), dgLista.CurrentRow.Cells("colIdMes").Value)
                    cfun.EscribirRegistro("Cierre", clsFunciones.AccEnum.acDelete, dgLista.CurrentRow.Cells("colIdMes").Value, 1, dgLista.CurrentRow.Cells("colAnio").Value, dgLista.CurrentRow.Cells("colIdMes").Value)
                    MsgBox("Los Datos han sido eliminados", vbInformation)
                    CargarListaPrincipal()

                End If

            Else
                    MsgBox("Usted no cuenta con la autorización para realizar dicha accion", vbInformation)
            End If

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Public Sub ImprimirCierre()
        Dim strSQL As String = STR_VACIO
        Dim COM As MySqlCommand
        Dim cls As New clsReportes
        Dim dtFecha As Date

        Try
            strSQL = " SELECT CE_Fecha_Final fecha "
            strSQL &= "    From Cierre_Encabezado e "
            strSQL &= "    WHERE e.CE_Empresa = {emp} AND e.CE_Anio = {anio} AND e.CE_Numero = {num} "

            strSQL = Replace(strSQL, "{emp}", Sesion.IdEmpresa)
            strSQL = Replace(strSQL, "{anio}", dgLista.CurrentRow.Cells("colAnio").Value)
            strSQL = Replace(strSQL, "{num}", dgLista.CurrentRow.Cells("colIdMes").Value)

            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSQL, CON)
            dtFecha = COM.ExecuteScalar

            cls.ReporteCierreMensual(dtFecha.ToString(FORMATO_MYSQL), dgLista.CurrentRow.Cells("colAnio").Value, dgLista.CurrentRow.Cells("colIdMes").Value)

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try

    End Sub
    Private Sub botonImprimir_Click(sender As Object, e As EventArgs) Handles botonImprimir.Click
        ImprimirCierre()
    End Sub

    Private Sub dgLista_KeyDown(sender As Object, e As KeyEventArgs) Handles dgLista.KeyDown
        Try
            If e.KeyCode = Keys.F3 Then
                cFunciones.BuscarenLista(dgLista)
                e.Handled = True
                e.SuppressKeyPress = True
            ElseIf e.KeyCode = Keys.F7 Then
                Dim rpt As New clsReportes
                rpt.Historial(dgLista.CurrentRow.Cells("colIdMes").Value, dgLista.CurrentRow.Cells("colAnio").Value, 1, "Cierre", dgLista.CurrentRow.Cells("colIdMes").Value)
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

#End Region
End Class
