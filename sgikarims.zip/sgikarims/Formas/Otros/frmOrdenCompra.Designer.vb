﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmOrdenCompra
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim DataGridViewCellStyle1 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle5 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle6 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle2 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle3 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle4 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmOrdenCompra))
        Dim DataGridViewCellStyle7 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle8 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle9 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Me.panelDocumento = New System.Windows.Forms.Panel()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.dtDetalle = New System.Windows.Forms.DataGridView()
        Me.colCodigo = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colDescripcion = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colUM = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colCantidad = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colPrecio = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.col_medida = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.col_id = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colTotal = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.col_centro = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.col_id3 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.col_Requeride = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.col_IdRequeride = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colCatalogo = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colAño = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colNumero = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colLinea = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.col_catalogo = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.col_año = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.col_numero = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.col_linea = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colComentario = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colExoneracion = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colidExoneracion = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colIdRubro = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colRubro = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colEstado1 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colCantidadRecibida = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colIdCosto = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colCosto = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colIdCenterCost = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colCentroCosto = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colPercentage = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colDiscounts = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colCancelado = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Panel2 = New System.Windows.Forms.Panel()
        Me.botonQuitar = New System.Windows.Forms.Button()
        Me.botonAgregar = New System.Windows.Forms.Button()
        Me.panelProveedor = New System.Windows.Forms.Panel()
        Me.Label14 = New System.Windows.Forms.Label()
        Me.celdaOCE = New System.Windows.Forms.TextBox()
        Me.PanelDelivery = New System.Windows.Forms.Panel()
        Me.celdaDelivery = New System.Windows.Forms.TextBox()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.gbCamposAdicionales = New System.Windows.Forms.GroupBox()
        Me.celdaTexto4 = New System.Windows.Forms.TextBox()
        Me.txtTEXT4 = New System.Windows.Forms.TextBox()
        Me.txtTEXT3 = New System.Windows.Forms.TextBox()
        Me.txtTEXT2 = New System.Windows.Forms.TextBox()
        Me.txtTEXT1 = New System.Windows.Forms.TextBox()
        Me.celdaTexto2 = New System.Windows.Forms.TextBox()
        Me.celdaTexto1 = New System.Windows.Forms.TextBox()
        Me.celdaTexto3 = New System.Windows.Forms.TextBox()
        Me.lblPacking = New System.Windows.Forms.Label()
        Me.panelDeliveryDate = New System.Windows.Forms.Panel()
        Me.dtpDeliveryDate = New System.Windows.Forms.DateTimePicker()
        Me.lblDeliveryDate = New System.Windows.Forms.Label()
        Me.panelApprovalDate = New System.Windows.Forms.Panel()
        Me.dtpFechaAprobacion = New System.Windows.Forms.DateTimePicker()
        Me.lblApprovalDate = New System.Windows.Forms.Label()
        Me.checkFechaAprobacion = New System.Windows.Forms.CheckBox()
        Me.PanelRequisicion = New System.Windows.Forms.Panel()
        Me.celdaRequisicion = New System.Windows.Forms.TextBox()
        Me.lblRequisicion = New System.Windows.Forms.Label()
        Me.panelRequerido = New System.Windows.Forms.Panel()
        Me.celdaRequerido = New System.Windows.Forms.TextBox()
        Me.lblRequerido = New System.Windows.Forms.Label()
        Me.panelResolucion = New System.Windows.Forms.Panel()
        Me.celdaIdResolución = New System.Windows.Forms.TextBox()
        Me.botonResolción = New System.Windows.Forms.Button()
        Me.celdaResolucion = New System.Windows.Forms.TextBox()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.panelDiasCredito = New System.Windows.Forms.Panel()
        Me.celdaDiasCredito = New System.Windows.Forms.TextBox()
        Me.Label23 = New System.Windows.Forms.Label()
        Me.rbContado = New System.Windows.Forms.RadioButton()
        Me.rbCredito = New System.Windows.Forms.RadioButton()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.celdaNumeroSerie = New System.Windows.Forms.TextBox()
        Me.etiquetaSerie = New System.Windows.Forms.Label()
        Me.celdaSerie = New System.Windows.Forms.TextBox()
        Me.botonSerie = New System.Windows.Forms.Button()
        Me.botonMoneda = New System.Windows.Forms.Button()
        Me.celdaidMoneda = New System.Windows.Forms.TextBox()
        Me.celdaObservaciones = New System.Windows.Forms.TextBox()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.celdaIDCosto = New System.Windows.Forms.Label()
        Me.celdaTotal = New System.Windows.Forms.TextBox()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.celdaMoneda = New System.Windows.Forms.Label()
        Me.botonCCostos = New System.Windows.Forms.Button()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.celdaCostos = New System.Windows.Forms.TextBox()
        Me.celdaTasa = New System.Windows.Forms.TextBox()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.celdaDireccion = New System.Windows.Forms.TextBox()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.checkActivo = New System.Windows.Forms.CheckBox()
        Me.dtpFecha = New System.Windows.Forms.DateTimePicker()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.celdaAño = New System.Windows.Forms.TextBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.celdaID = New System.Windows.Forms.TextBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.celdaIdProveedor = New System.Windows.Forms.Label()
        Me.botonProveedor = New System.Windows.Forms.Button()
        Me.celdaProveedor = New System.Windows.Forms.TextBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.panelLIsta = New System.Windows.Forms.Panel()
        Me.dgLista = New System.Windows.Forms.DataGridView()
        Me.colOrdenCompra = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colAnio = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colFecha = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colNombre = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colSerie = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.col_total = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.col_estado = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.panelFiltro = New System.Windows.Forms.Panel()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.botonFiltrar = New System.Windows.Forms.Button()
        Me.dtpFin = New System.Windows.Forms.DateTimePicker()
        Me.dtpInicio = New System.Windows.Forms.DateTimePicker()
        Me.checkFechas = New System.Windows.Forms.CheckBox()
        Me.botonInprimir = New System.Windows.Forms.Button()
        Me.BarraTitulo1 = New KARIMs_SGI.BarraTitulo()
        Me.Encabezado1 = New KARIMs_SGI.encabezado()
        Me.panelDocumento.SuspendLayout()
        Me.Panel1.SuspendLayout()
        CType(Me.dtDetalle, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Panel2.SuspendLayout()
        Me.panelProveedor.SuspendLayout()
        Me.PanelDelivery.SuspendLayout()
        Me.gbCamposAdicionales.SuspendLayout()
        Me.panelDeliveryDate.SuspendLayout()
        Me.panelApprovalDate.SuspendLayout()
        Me.PanelRequisicion.SuspendLayout()
        Me.panelRequerido.SuspendLayout()
        Me.panelResolucion.SuspendLayout()
        Me.panelDiasCredito.SuspendLayout()
        Me.panelLIsta.SuspendLayout()
        CType(Me.dgLista, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.panelFiltro.SuspendLayout()
        Me.GroupBox1.SuspendLayout()
        Me.SuspendLayout()
        '
        'panelDocumento
        '
        Me.panelDocumento.Controls.Add(Me.Panel1)
        Me.panelDocumento.Controls.Add(Me.panelProveedor)
        Me.panelDocumento.Location = New System.Drawing.Point(24, 107)
        Me.panelDocumento.Name = "panelDocumento"
        Me.panelDocumento.Size = New System.Drawing.Size(859, 487)
        Me.panelDocumento.TabIndex = 2
        '
        'Panel1
        '
        Me.Panel1.Controls.Add(Me.dtDetalle)
        Me.Panel1.Controls.Add(Me.Panel2)
        Me.Panel1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Panel1.Location = New System.Drawing.Point(0, 290)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(859, 197)
        Me.Panel1.TabIndex = 2
        '
        'dtDetalle
        '
        Me.dtDetalle.AllowUserToAddRows = False
        Me.dtDetalle.AllowUserToDeleteRows = False
        Me.dtDetalle.AllowUserToOrderColumns = True
        Me.dtDetalle.BackgroundColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle1.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!)
        DataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.dtDetalle.ColumnHeadersDefaultCellStyle = DataGridViewCellStyle1
        Me.dtDetalle.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dtDetalle.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.colCodigo, Me.colDescripcion, Me.colUM, Me.colCantidad, Me.colPrecio, Me.col_medida, Me.col_id, Me.colTotal, Me.col_centro, Me.col_id3, Me.col_Requeride, Me.col_IdRequeride, Me.colCatalogo, Me.colAño, Me.colNumero, Me.colLinea, Me.col_catalogo, Me.col_año, Me.col_numero, Me.col_linea, Me.colComentario, Me.colExoneracion, Me.colidExoneracion, Me.colIdRubro, Me.colRubro, Me.colEstado1, Me.colCantidadRecibida, Me.colIdCosto, Me.colCosto, Me.colIdCenterCost, Me.colCentroCosto, Me.colPercentage, Me.colDiscounts, Me.colCancelado})
        DataGridViewCellStyle5.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle5.BackColor = System.Drawing.SystemColors.Window
        DataGridViewCellStyle5.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!)
        DataGridViewCellStyle5.ForeColor = System.Drawing.SystemColors.ControlText
        DataGridViewCellStyle5.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle5.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle5.WrapMode = System.Windows.Forms.DataGridViewTriState.[False]
        Me.dtDetalle.DefaultCellStyle = DataGridViewCellStyle5
        Me.dtDetalle.Dock = System.Windows.Forms.DockStyle.Fill
        Me.dtDetalle.Location = New System.Drawing.Point(0, 0)
        Me.dtDetalle.MultiSelect = False
        Me.dtDetalle.Name = "dtDetalle"
        DataGridViewCellStyle6.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle6.BackColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle6.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!)
        DataGridViewCellStyle6.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle6.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle6.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle6.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.dtDetalle.RowHeadersDefaultCellStyle = DataGridViewCellStyle6
        Me.dtDetalle.RowHeadersWidth = 51
        Me.dtDetalle.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.dtDetalle.Size = New System.Drawing.Size(785, 197)
        Me.dtDetalle.TabIndex = 1
        '
        'colCodigo
        '
        Me.colCodigo.HeaderText = "Code"
        Me.colCodigo.MinimumWidth = 6
        Me.colCodigo.Name = "colCodigo"
        Me.colCodigo.ReadOnly = True
        Me.colCodigo.Width = 66
        '
        'colDescripcion
        '
        Me.colDescripcion.HeaderText = "Description"
        Me.colDescripcion.MinimumWidth = 6
        Me.colDescripcion.Name = "colDescripcion"
        Me.colDescripcion.ReadOnly = True
        Me.colDescripcion.Width = 101
        '
        'colUM
        '
        Me.colUM.HeaderText = "UM"
        Me.colUM.MinimumWidth = 6
        Me.colUM.Name = "colUM"
        Me.colUM.ReadOnly = True
        Me.colUM.Width = 125
        '
        'colCantidad
        '
        DataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        DataGridViewCellStyle2.BackColor = System.Drawing.SystemColors.Info
        Me.colCantidad.DefaultCellStyle = DataGridViewCellStyle2
        Me.colCantidad.HeaderText = "Quantity"
        Me.colCantidad.MinimumWidth = 6
        Me.colCantidad.Name = "colCantidad"
        Me.colCantidad.Width = 81
        '
        'colPrecio
        '
        DataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        DataGridViewCellStyle3.BackColor = System.Drawing.SystemColors.Info
        DataGridViewCellStyle3.Format = "N2"
        DataGridViewCellStyle3.NullValue = "0"
        Me.colPrecio.DefaultCellStyle = DataGridViewCellStyle3
        Me.colPrecio.HeaderText = "Price"
        Me.colPrecio.MinimumWidth = 6
        Me.colPrecio.Name = "colPrecio"
        Me.colPrecio.Width = 64
        '
        'col_medida
        '
        Me.col_medida.HeaderText = "Measure"
        Me.col_medida.MinimumWidth = 6
        Me.col_medida.Name = "col_medida"
        Me.col_medida.ReadOnly = True
        Me.col_medida.Visible = False
        Me.col_medida.Width = 86
        '
        'col_id
        '
        Me.col_id.HeaderText = "id"
        Me.col_id.MinimumWidth = 6
        Me.col_id.Name = "col_id"
        Me.col_id.Visible = False
        Me.col_id.Width = 44
        '
        'colTotal
        '
        DataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        DataGridViewCellStyle4.Format = "N2"
        DataGridViewCellStyle4.NullValue = Nothing
        Me.colTotal.DefaultCellStyle = DataGridViewCellStyle4
        Me.colTotal.HeaderText = "Total"
        Me.colTotal.MinimumWidth = 6
        Me.colTotal.Name = "colTotal"
        Me.colTotal.ReadOnly = True
        Me.colTotal.Width = 64
        '
        'col_centro
        '
        Me.col_centro.HeaderText = "Cost Center"
        Me.col_centro.MinimumWidth = 6
        Me.col_centro.Name = "col_centro"
        Me.col_centro.ReadOnly = True
        Me.col_centro.Width = 94
        '
        'col_id3
        '
        Me.col_id3.HeaderText = "id"
        Me.col_id3.MinimumWidth = 6
        Me.col_id3.Name = "col_id3"
        Me.col_id3.Visible = False
        Me.col_id3.Width = 44
        '
        'col_Requeride
        '
        Me.col_Requeride.HeaderText = "Required By"
        Me.col_Requeride.MinimumWidth = 6
        Me.col_Requeride.Name = "col_Requeride"
        Me.col_Requeride.Width = 99
        '
        'col_IdRequeride
        '
        Me.col_IdRequeride.HeaderText = "IdRequerido"
        Me.col_IdRequeride.MinimumWidth = 6
        Me.col_IdRequeride.Name = "col_IdRequeride"
        Me.col_IdRequeride.Visible = False
        Me.col_IdRequeride.Width = 108
        '
        'colCatalogo
        '
        Me.colCatalogo.HeaderText = "catalogo"
        Me.colCatalogo.MinimumWidth = 6
        Me.colCatalogo.Name = "colCatalogo"
        Me.colCatalogo.Visible = False
        Me.colCatalogo.Width = 86
        '
        'colAño
        '
        Me.colAño.HeaderText = "año"
        Me.colAño.MinimumWidth = 6
        Me.colAño.Name = "colAño"
        Me.colAño.Visible = False
        Me.colAño.Width = 56
        '
        'colNumero
        '
        Me.colNumero.HeaderText = "numero"
        Me.colNumero.MinimumWidth = 6
        Me.colNumero.Name = "colNumero"
        Me.colNumero.Visible = False
        Me.colNumero.Width = 78
        '
        'colLinea
        '
        Me.colLinea.HeaderText = "linea"
        Me.colLinea.MinimumWidth = 6
        Me.colLinea.Name = "colLinea"
        Me.colLinea.Visible = False
        Me.colLinea.Width = 62
        '
        'col_catalogo
        '
        Me.col_catalogo.HeaderText = "catalogo2"
        Me.col_catalogo.MinimumWidth = 6
        Me.col_catalogo.Name = "col_catalogo"
        Me.col_catalogo.Visible = False
        Me.col_catalogo.Width = 93
        '
        'col_año
        '
        Me.col_año.HeaderText = "año2"
        Me.col_año.MinimumWidth = 6
        Me.col_año.Name = "col_año"
        Me.col_año.Visible = False
        Me.col_año.Width = 63
        '
        'col_numero
        '
        Me.col_numero.HeaderText = "numero2"
        Me.col_numero.MinimumWidth = 6
        Me.col_numero.Name = "col_numero"
        Me.col_numero.Visible = False
        Me.col_numero.Width = 85
        '
        'col_linea
        '
        Me.col_linea.HeaderText = "linea2"
        Me.col_linea.MinimumWidth = 6
        Me.col_linea.Name = "col_linea"
        Me.col_linea.Visible = False
        Me.col_linea.Width = 69
        '
        'colComentario
        '
        Me.colComentario.HeaderText = "Comment"
        Me.colComentario.MinimumWidth = 6
        Me.colComentario.Name = "colComentario"
        Me.colComentario.Width = 90
        '
        'colExoneracion
        '
        Me.colExoneracion.HeaderText = "Chapter to exonerate"
        Me.colExoneracion.MinimumWidth = 6
        Me.colExoneracion.Name = "colExoneracion"
        Me.colExoneracion.ReadOnly = True
        Me.colExoneracion.Width = 157
        '
        'colidExoneracion
        '
        Me.colidExoneracion.HeaderText = "ID"
        Me.colidExoneracion.MinimumWidth = 6
        Me.colidExoneracion.Name = "colidExoneracion"
        Me.colidExoneracion.ReadOnly = True
        Me.colidExoneracion.Visible = False
        Me.colidExoneracion.Width = 46
        '
        'colIdRubro
        '
        Me.colIdRubro.HeaderText = "Id Rubro"
        Me.colIdRubro.MinimumWidth = 6
        Me.colIdRubro.Name = "colIdRubro"
        Me.colIdRubro.ReadOnly = True
        Me.colIdRubro.Visible = False
        Me.colIdRubro.Width = 84
        '
        'colRubro
        '
        Me.colRubro.HeaderText = "Item to exonerate"
        Me.colRubro.MinimumWidth = 6
        Me.colRubro.Name = "colRubro"
        Me.colRubro.ReadOnly = True
        Me.colRubro.Width = 123
        '
        'colEstado1
        '
        Me.colEstado1.HeaderText = "Estado"
        Me.colEstado1.MinimumWidth = 6
        Me.colEstado1.Name = "colEstado1"
        Me.colEstado1.Visible = False
        Me.colEstado1.Width = 76
        '
        'colCantidadRecibida
        '
        Me.colCantidadRecibida.HeaderText = "Received Quantity"
        Me.colCantidadRecibida.MinimumWidth = 6
        Me.colCantidadRecibida.Name = "colCantidadRecibida"
        Me.colCantidadRecibida.Width = 125
        '
        'colIdCosto
        '
        Me.colIdCosto.HeaderText = "idCuentaNom"
        Me.colIdCosto.MinimumWidth = 6
        Me.colIdCosto.Name = "colIdCosto"
        Me.colIdCosto.Visible = False
        Me.colIdCosto.Width = 125
        '
        'colCosto
        '
        Me.colCosto.HeaderText = "Category"
        Me.colCosto.MinimumWidth = 6
        Me.colCosto.Name = "colCosto"
        Me.colCosto.ReadOnly = True
        Me.colCosto.Visible = False
        Me.colCosto.Width = 125
        '
        'colIdCenterCost
        '
        Me.colIdCenterCost.HeaderText = "idrubro"
        Me.colIdCenterCost.MinimumWidth = 6
        Me.colIdCenterCost.Name = "colIdCenterCost"
        Me.colIdCenterCost.Visible = False
        Me.colIdCenterCost.Width = 125
        '
        'colCentroCosto
        '
        Me.colCentroCosto.HeaderText = "Account"
        Me.colCentroCosto.MinimumWidth = 6
        Me.colCentroCosto.Name = "colCentroCosto"
        Me.colCentroCosto.ReadOnly = True
        Me.colCentroCosto.Visible = False
        Me.colCentroCosto.Width = 125
        '
        'colPercentage
        '
        Me.colPercentage.HeaderText = "Percentage %"
        Me.colPercentage.Name = "colPercentage"
        '
        'colDiscounts
        '
        Me.colDiscounts.HeaderText = "Discounts"
        Me.colDiscounts.Name = "colDiscounts"
        Me.colDiscounts.ReadOnly = True
        '
        'colCancelado
        '
        Me.colCancelado.HeaderText = "Canceled"
        Me.colCancelado.MinimumWidth = 6
        Me.colCancelado.Name = "colCancelado"
        Me.colCancelado.ReadOnly = True
        Me.colCancelado.Width = 91
        '
        'Panel2
        '
        Me.Panel2.Controls.Add(Me.botonQuitar)
        Me.Panel2.Controls.Add(Me.botonAgregar)
        Me.Panel2.Dock = System.Windows.Forms.DockStyle.Right
        Me.Panel2.Location = New System.Drawing.Point(785, 0)
        Me.Panel2.Name = "Panel2"
        Me.Panel2.Size = New System.Drawing.Size(74, 197)
        Me.Panel2.TabIndex = 2
        '
        'botonQuitar
        '
        Me.botonQuitar.Image = CType(resources.GetObject("botonQuitar.Image"), System.Drawing.Image)
        Me.botonQuitar.Location = New System.Drawing.Point(13, 51)
        Me.botonQuitar.Name = "botonQuitar"
        Me.botonQuitar.Size = New System.Drawing.Size(26, 24)
        Me.botonQuitar.TabIndex = 0
        Me.botonQuitar.UseVisualStyleBackColor = True
        '
        'botonAgregar
        '
        Me.botonAgregar.Image = CType(resources.GetObject("botonAgregar.Image"), System.Drawing.Image)
        Me.botonAgregar.Location = New System.Drawing.Point(13, 21)
        Me.botonAgregar.Name = "botonAgregar"
        Me.botonAgregar.Size = New System.Drawing.Size(26, 24)
        Me.botonAgregar.TabIndex = 0
        Me.botonAgregar.UseVisualStyleBackColor = True
        '
        'panelProveedor
        '
        Me.panelProveedor.Controls.Add(Me.Label14)
        Me.panelProveedor.Controls.Add(Me.celdaOCE)
        Me.panelProveedor.Controls.Add(Me.PanelDelivery)
        Me.panelProveedor.Controls.Add(Me.gbCamposAdicionales)
        Me.panelProveedor.Controls.Add(Me.panelDeliveryDate)
        Me.panelProveedor.Controls.Add(Me.panelApprovalDate)
        Me.panelProveedor.Controls.Add(Me.checkFechaAprobacion)
        Me.panelProveedor.Controls.Add(Me.PanelRequisicion)
        Me.panelProveedor.Controls.Add(Me.panelRequerido)
        Me.panelProveedor.Controls.Add(Me.panelResolucion)
        Me.panelProveedor.Controls.Add(Me.panelDiasCredito)
        Me.panelProveedor.Controls.Add(Me.rbContado)
        Me.panelProveedor.Controls.Add(Me.rbCredito)
        Me.panelProveedor.Controls.Add(Me.Label11)
        Me.panelProveedor.Controls.Add(Me.celdaNumeroSerie)
        Me.panelProveedor.Controls.Add(Me.etiquetaSerie)
        Me.panelProveedor.Controls.Add(Me.celdaSerie)
        Me.panelProveedor.Controls.Add(Me.botonSerie)
        Me.panelProveedor.Controls.Add(Me.botonMoneda)
        Me.panelProveedor.Controls.Add(Me.celdaidMoneda)
        Me.panelProveedor.Controls.Add(Me.celdaObservaciones)
        Me.panelProveedor.Controls.Add(Me.Label10)
        Me.panelProveedor.Controls.Add(Me.celdaIDCosto)
        Me.panelProveedor.Controls.Add(Me.celdaTotal)
        Me.panelProveedor.Controls.Add(Me.Label9)
        Me.panelProveedor.Controls.Add(Me.celdaMoneda)
        Me.panelProveedor.Controls.Add(Me.botonCCostos)
        Me.panelProveedor.Controls.Add(Me.Label8)
        Me.panelProveedor.Controls.Add(Me.celdaCostos)
        Me.panelProveedor.Controls.Add(Me.celdaTasa)
        Me.panelProveedor.Controls.Add(Me.Label7)
        Me.panelProveedor.Controls.Add(Me.Label6)
        Me.panelProveedor.Controls.Add(Me.celdaDireccion)
        Me.panelProveedor.Controls.Add(Me.Label5)
        Me.panelProveedor.Controls.Add(Me.checkActivo)
        Me.panelProveedor.Controls.Add(Me.dtpFecha)
        Me.panelProveedor.Controls.Add(Me.Label4)
        Me.panelProveedor.Controls.Add(Me.celdaAño)
        Me.panelProveedor.Controls.Add(Me.Label3)
        Me.panelProveedor.Controls.Add(Me.celdaID)
        Me.panelProveedor.Controls.Add(Me.Label2)
        Me.panelProveedor.Controls.Add(Me.celdaIdProveedor)
        Me.panelProveedor.Controls.Add(Me.botonProveedor)
        Me.panelProveedor.Controls.Add(Me.celdaProveedor)
        Me.panelProveedor.Controls.Add(Me.Label1)
        Me.panelProveedor.Dock = System.Windows.Forms.DockStyle.Top
        Me.panelProveedor.Location = New System.Drawing.Point(0, 0)
        Me.panelProveedor.Name = "panelProveedor"
        Me.panelProveedor.Size = New System.Drawing.Size(859, 290)
        Me.panelProveedor.TabIndex = 0
        '
        'Label14
        '
        Me.Label14.AutoSize = True
        Me.Label14.Location = New System.Drawing.Point(542, 8)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(49, 13)
        Me.Label14.TabIndex = 54
        Me.Label14.Text = "No. OCE"
        '
        'celdaOCE
        '
        Me.celdaOCE.BackColor = System.Drawing.SystemColors.Info
        Me.celdaOCE.Location = New System.Drawing.Point(536, 24)
        Me.celdaOCE.Name = "celdaOCE"
        Me.celdaOCE.Size = New System.Drawing.Size(144, 20)
        Me.celdaOCE.TabIndex = 53
        '
        'PanelDelivery
        '
        Me.PanelDelivery.Controls.Add(Me.celdaDelivery)
        Me.PanelDelivery.Controls.Add(Me.Label13)
        Me.PanelDelivery.Location = New System.Drawing.Point(694, 237)
        Me.PanelDelivery.Margin = New System.Windows.Forms.Padding(2)
        Me.PanelDelivery.Name = "PanelDelivery"
        Me.PanelDelivery.Size = New System.Drawing.Size(275, 53)
        Me.PanelDelivery.TabIndex = 48
        '
        'celdaDelivery
        '
        Me.celdaDelivery.BackColor = System.Drawing.SystemColors.Info
        Me.celdaDelivery.Location = New System.Drawing.Point(94, 7)
        Me.celdaDelivery.Multiline = True
        Me.celdaDelivery.Name = "celdaDelivery"
        Me.celdaDelivery.Size = New System.Drawing.Size(250, 43)
        Me.celdaDelivery.TabIndex = 47
        '
        'Label13
        '
        Me.Label13.AutoSize = True
        Me.Label13.Location = New System.Drawing.Point(2, 7)
        Me.Label13.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(87, 13)
        Me.Label13.TabIndex = 46
        Me.Label13.Text = "Terms of delivery"
        '
        'gbCamposAdicionales
        '
        Me.gbCamposAdicionales.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.gbCamposAdicionales.Controls.Add(Me.celdaTexto4)
        Me.gbCamposAdicionales.Controls.Add(Me.txtTEXT4)
        Me.gbCamposAdicionales.Controls.Add(Me.txtTEXT3)
        Me.gbCamposAdicionales.Controls.Add(Me.txtTEXT2)
        Me.gbCamposAdicionales.Controls.Add(Me.txtTEXT1)
        Me.gbCamposAdicionales.Controls.Add(Me.celdaTexto2)
        Me.gbCamposAdicionales.Controls.Add(Me.celdaTexto1)
        Me.gbCamposAdicionales.Controls.Add(Me.celdaTexto3)
        Me.gbCamposAdicionales.Controls.Add(Me.lblPacking)
        Me.gbCamposAdicionales.Location = New System.Drawing.Point(27, 231)
        Me.gbCamposAdicionales.Margin = New System.Windows.Forms.Padding(2)
        Me.gbCamposAdicionales.Name = "gbCamposAdicionales"
        Me.gbCamposAdicionales.Padding = New System.Windows.Forms.Padding(2)
        Me.gbCamposAdicionales.Size = New System.Drawing.Size(545, 57)
        Me.gbCamposAdicionales.TabIndex = 21
        Me.gbCamposAdicionales.TabStop = False
        Me.gbCamposAdicionales.Text = "Additional Purchase Order Information"
        Me.gbCamposAdicionales.Visible = False
        '
        'celdaTexto4
        '
        Me.celdaTexto4.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend
        Me.celdaTexto4.Location = New System.Drawing.Point(447, 36)
        Me.celdaTexto4.Margin = New System.Windows.Forms.Padding(2)
        Me.celdaTexto4.Name = "celdaTexto4"
        Me.celdaTexto4.ReadOnly = True
        Me.celdaTexto4.Size = New System.Drawing.Size(138, 20)
        Me.celdaTexto4.TabIndex = 10
        '
        'txtTEXT4
        '
        Me.txtTEXT4.BackColor = System.Drawing.SystemColors.ScrollBar
        Me.txtTEXT4.Location = New System.Drawing.Point(447, 19)
        Me.txtTEXT4.Margin = New System.Windows.Forms.Padding(2)
        Me.txtTEXT4.Name = "txtTEXT4"
        Me.txtTEXT4.Size = New System.Drawing.Size(138, 20)
        Me.txtTEXT4.TabIndex = 9
        Me.txtTEXT4.Text = "Total Discounts"
        '
        'txtTEXT3
        '
        Me.txtTEXT3.BackColor = System.Drawing.SystemColors.ScrollBar
        Me.txtTEXT3.Location = New System.Drawing.Point(289, 17)
        Me.txtTEXT3.Margin = New System.Windows.Forms.Padding(2)
        Me.txtTEXT3.Name = "txtTEXT3"
        Me.txtTEXT3.Size = New System.Drawing.Size(138, 20)
        Me.txtTEXT3.TabIndex = 8
        Me.txtTEXT3.Text = "Total "
        '
        'txtTEXT2
        '
        Me.txtTEXT2.BackColor = System.Drawing.SystemColors.ScrollBar
        Me.txtTEXT2.Location = New System.Drawing.Point(148, 17)
        Me.txtTEXT2.Margin = New System.Windows.Forms.Padding(2)
        Me.txtTEXT2.Name = "txtTEXT2"
        Me.txtTEXT2.Size = New System.Drawing.Size(128, 20)
        Me.txtTEXT2.TabIndex = 7
        '
        'txtTEXT1
        '
        Me.txtTEXT1.BackColor = System.Drawing.SystemColors.ScrollBar
        Me.txtTEXT1.Location = New System.Drawing.Point(4, 17)
        Me.txtTEXT1.Margin = New System.Windows.Forms.Padding(2)
        Me.txtTEXT1.Name = "txtTEXT1"
        Me.txtTEXT1.Size = New System.Drawing.Size(131, 20)
        Me.txtTEXT1.TabIndex = 6
        '
        'celdaTexto2
        '
        Me.celdaTexto2.Location = New System.Drawing.Point(148, 36)
        Me.celdaTexto2.Margin = New System.Windows.Forms.Padding(2)
        Me.celdaTexto2.Name = "celdaTexto2"
        Me.celdaTexto2.Size = New System.Drawing.Size(128, 20)
        Me.celdaTexto2.TabIndex = 5
        '
        'celdaTexto1
        '
        Me.celdaTexto1.Location = New System.Drawing.Point(4, 36)
        Me.celdaTexto1.Margin = New System.Windows.Forms.Padding(2)
        Me.celdaTexto1.Name = "celdaTexto1"
        Me.celdaTexto1.Size = New System.Drawing.Size(131, 20)
        Me.celdaTexto1.TabIndex = 4
        '
        'celdaTexto3
        '
        Me.celdaTexto3.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend
        Me.celdaTexto3.Location = New System.Drawing.Point(289, 36)
        Me.celdaTexto3.Margin = New System.Windows.Forms.Padding(2)
        Me.celdaTexto3.Name = "celdaTexto3"
        Me.celdaTexto3.ReadOnly = True
        Me.celdaTexto3.Size = New System.Drawing.Size(138, 20)
        Me.celdaTexto3.TabIndex = 3
        '
        'lblPacking
        '
        Me.lblPacking.AutoSize = True
        Me.lblPacking.Location = New System.Drawing.Point(19, 22)
        Me.lblPacking.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lblPacking.Name = "lblPacking"
        Me.lblPacking.Size = New System.Drawing.Size(0, 13)
        Me.lblPacking.TabIndex = 1
        '
        'panelDeliveryDate
        '
        Me.panelDeliveryDate.Controls.Add(Me.dtpDeliveryDate)
        Me.panelDeliveryDate.Controls.Add(Me.lblDeliveryDate)
        Me.panelDeliveryDate.Location = New System.Drawing.Point(169, 62)
        Me.panelDeliveryDate.Margin = New System.Windows.Forms.Padding(2)
        Me.panelDeliveryDate.Name = "panelDeliveryDate"
        Me.panelDeliveryDate.Size = New System.Drawing.Size(134, 42)
        Me.panelDeliveryDate.TabIndex = 52
        Me.panelDeliveryDate.Visible = False
        '
        'dtpDeliveryDate
        '
        Me.dtpDeliveryDate.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.dtpDeliveryDate.Location = New System.Drawing.Point(10, 18)
        Me.dtpDeliveryDate.Name = "dtpDeliveryDate"
        Me.dtpDeliveryDate.Size = New System.Drawing.Size(114, 20)
        Me.dtpDeliveryDate.TabIndex = 11
        '
        'lblDeliveryDate
        '
        Me.lblDeliveryDate.AutoSize = True
        Me.lblDeliveryDate.Location = New System.Drawing.Point(4, 2)
        Me.lblDeliveryDate.Name = "lblDeliveryDate"
        Me.lblDeliveryDate.Size = New System.Drawing.Size(71, 13)
        Me.lblDeliveryDate.TabIndex = 10
        Me.lblDeliveryDate.Text = "Delivery Date"
        '
        'panelApprovalDate
        '
        Me.panelApprovalDate.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.panelApprovalDate.Controls.Add(Me.dtpFechaAprobacion)
        Me.panelApprovalDate.Controls.Add(Me.lblApprovalDate)
        Me.panelApprovalDate.Location = New System.Drawing.Point(394, 22)
        Me.panelApprovalDate.Margin = New System.Windows.Forms.Padding(2)
        Me.panelApprovalDate.Name = "panelApprovalDate"
        Me.panelApprovalDate.Size = New System.Drawing.Size(136, 42)
        Me.panelApprovalDate.TabIndex = 51
        Me.panelApprovalDate.Visible = False
        '
        'dtpFechaAprobacion
        '
        Me.dtpFechaAprobacion.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.dtpFechaAprobacion.Location = New System.Drawing.Point(6, 18)
        Me.dtpFechaAprobacion.Name = "dtpFechaAprobacion"
        Me.dtpFechaAprobacion.Size = New System.Drawing.Size(114, 20)
        Me.dtpFechaAprobacion.TabIndex = 11
        '
        'lblApprovalDate
        '
        Me.lblApprovalDate.AutoSize = True
        Me.lblApprovalDate.Location = New System.Drawing.Point(3, 2)
        Me.lblApprovalDate.Name = "lblApprovalDate"
        Me.lblApprovalDate.Size = New System.Drawing.Size(75, 13)
        Me.lblApprovalDate.TabIndex = 10
        Me.lblApprovalDate.Text = "Approval Date"
        '
        'checkFechaAprobacion
        '
        Me.checkFechaAprobacion.AutoSize = True
        Me.checkFechaAprobacion.Location = New System.Drawing.Point(401, 8)
        Me.checkFechaAprobacion.Margin = New System.Windows.Forms.Padding(2)
        Me.checkFechaAprobacion.Name = "checkFechaAprobacion"
        Me.checkFechaAprobacion.Size = New System.Drawing.Size(94, 17)
        Me.checkFechaAprobacion.TabIndex = 50
        Me.checkFechaAprobacion.Text = "Approval Date"
        Me.checkFechaAprobacion.UseVisualStyleBackColor = True
        '
        'PanelRequisicion
        '
        Me.PanelRequisicion.Controls.Add(Me.celdaRequisicion)
        Me.PanelRequisicion.Controls.Add(Me.lblRequisicion)
        Me.PanelRequisicion.Location = New System.Drawing.Point(691, 79)
        Me.PanelRequisicion.Margin = New System.Windows.Forms.Padding(2)
        Me.PanelRequisicion.Name = "PanelRequisicion"
        Me.PanelRequisicion.Size = New System.Drawing.Size(170, 46)
        Me.PanelRequisicion.TabIndex = 49
        Me.PanelRequisicion.Visible = False
        '
        'celdaRequisicion
        '
        Me.celdaRequisicion.BackColor = System.Drawing.SystemColors.Info
        Me.celdaRequisicion.Location = New System.Drawing.Point(3, 24)
        Me.celdaRequisicion.Name = "celdaRequisicion"
        Me.celdaRequisicion.Size = New System.Drawing.Size(145, 20)
        Me.celdaRequisicion.TabIndex = 45
        '
        'lblRequisicion
        '
        Me.lblRequisicion.AutoSize = True
        Me.lblRequisicion.Location = New System.Drawing.Point(2, 6)
        Me.lblRequisicion.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lblRequisicion.Name = "lblRequisicion"
        Me.lblRequisicion.Size = New System.Drawing.Size(59, 13)
        Me.lblRequisicion.TabIndex = 43
        Me.lblRequisicion.Text = "Requisition"
        '
        'panelRequerido
        '
        Me.panelRequerido.Controls.Add(Me.celdaRequerido)
        Me.panelRequerido.Controls.Add(Me.lblRequerido)
        Me.panelRequerido.Location = New System.Drawing.Point(688, 185)
        Me.panelRequerido.Margin = New System.Windows.Forms.Padding(2)
        Me.panelRequerido.Name = "panelRequerido"
        Me.panelRequerido.Size = New System.Drawing.Size(168, 46)
        Me.panelRequerido.TabIndex = 47
        Me.panelRequerido.Visible = False
        '
        'celdaRequerido
        '
        Me.celdaRequerido.BackColor = System.Drawing.SystemColors.Info
        Me.celdaRequerido.Location = New System.Drawing.Point(3, 24)
        Me.celdaRequerido.Name = "celdaRequerido"
        Me.celdaRequerido.Size = New System.Drawing.Size(162, 20)
        Me.celdaRequerido.TabIndex = 47
        '
        'lblRequerido
        '
        Me.lblRequerido.AutoSize = True
        Me.lblRequerido.Location = New System.Drawing.Point(2, 7)
        Me.lblRequerido.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lblRequerido.Name = "lblRequerido"
        Me.lblRequerido.Size = New System.Drawing.Size(50, 13)
        Me.lblRequerido.TabIndex = 46
        Me.lblRequerido.Text = "Required"
        '
        'panelResolucion
        '
        Me.panelResolucion.Controls.Add(Me.celdaIdResolución)
        Me.panelResolucion.Controls.Add(Me.botonResolción)
        Me.panelResolucion.Controls.Add(Me.celdaResolucion)
        Me.panelResolucion.Controls.Add(Me.Label12)
        Me.panelResolucion.Location = New System.Drawing.Point(500, 137)
        Me.panelResolucion.Margin = New System.Windows.Forms.Padding(2)
        Me.panelResolucion.Name = "panelResolucion"
        Me.panelResolucion.Size = New System.Drawing.Size(256, 46)
        Me.panelResolucion.TabIndex = 46
        Me.panelResolucion.Visible = False
        '
        'celdaIdResolución
        '
        Me.celdaIdResolución.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.celdaIdResolución.BackColor = System.Drawing.SystemColors.Info
        Me.celdaIdResolución.Location = New System.Drawing.Point(98, 3)
        Me.celdaIdResolución.Name = "celdaIdResolución"
        Me.celdaIdResolución.ReadOnly = True
        Me.celdaIdResolución.Size = New System.Drawing.Size(54, 20)
        Me.celdaIdResolución.TabIndex = 48
        Me.celdaIdResolución.Visible = False
        '
        'botonResolción
        '
        Me.botonResolción.Location = New System.Drawing.Point(224, 23)
        Me.botonResolción.Margin = New System.Windows.Forms.Padding(2)
        Me.botonResolción.Name = "botonResolción"
        Me.botonResolción.Size = New System.Drawing.Size(28, 19)
        Me.botonResolción.TabIndex = 47
        Me.botonResolción.Text = "..."
        Me.botonResolción.UseVisualStyleBackColor = True
        '
        'celdaResolucion
        '
        Me.celdaResolucion.BackColor = System.Drawing.SystemColors.Info
        Me.celdaResolucion.Location = New System.Drawing.Point(3, 23)
        Me.celdaResolucion.Name = "celdaResolucion"
        Me.celdaResolucion.ReadOnly = True
        Me.celdaResolucion.Size = New System.Drawing.Size(220, 20)
        Me.celdaResolucion.TabIndex = 45
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.Location = New System.Drawing.Point(2, 6)
        Me.Label12.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(57, 13)
        Me.Label12.TabIndex = 43
        Me.Label12.Text = "Resolution"
        '
        'panelDiasCredito
        '
        Me.panelDiasCredito.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.panelDiasCredito.Controls.Add(Me.celdaDiasCredito)
        Me.panelDiasCredito.Controls.Add(Me.Label23)
        Me.panelDiasCredito.Location = New System.Drawing.Point(380, 62)
        Me.panelDiasCredito.Margin = New System.Windows.Forms.Padding(2)
        Me.panelDiasCredito.Name = "panelDiasCredito"
        Me.panelDiasCredito.Size = New System.Drawing.Size(404, 48)
        Me.panelDiasCredito.TabIndex = 45
        Me.panelDiasCredito.Visible = False
        '
        'celdaDiasCredito
        '
        Me.celdaDiasCredito.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.celdaDiasCredito.Location = New System.Drawing.Point(21, 23)
        Me.celdaDiasCredito.Name = "celdaDiasCredito"
        Me.celdaDiasCredito.Size = New System.Drawing.Size(384, 20)
        Me.celdaDiasCredito.TabIndex = 45
        '
        'Label23
        '
        Me.Label23.AutoSize = True
        Me.Label23.Location = New System.Drawing.Point(19, 6)
        Me.Label23.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label23.Name = "Label23"
        Me.Label23.Size = New System.Drawing.Size(59, 13)
        Me.Label23.TabIndex = 43
        Me.Label23.Text = "Credit days"
        '
        'rbContado
        '
        Me.rbContado.AutoSize = True
        Me.rbContado.Location = New System.Drawing.Point(376, 92)
        Me.rbContado.Name = "rbContado"
        Me.rbContado.Size = New System.Drawing.Size(49, 17)
        Me.rbContado.TabIndex = 34
        Me.rbContado.TabStop = True
        Me.rbContado.Text = "Cash"
        Me.rbContado.UseVisualStyleBackColor = True
        Me.rbContado.Visible = False
        '
        'rbCredito
        '
        Me.rbCredito.AutoSize = True
        Me.rbCredito.Location = New System.Drawing.Point(376, 65)
        Me.rbCredito.Name = "rbCredito"
        Me.rbCredito.Size = New System.Drawing.Size(52, 17)
        Me.rbCredito.TabIndex = 33
        Me.rbCredito.TabStop = True
        Me.rbCredito.Text = "Credit"
        Me.rbCredito.UseVisualStyleBackColor = True
        Me.rbCredito.Visible = False
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.Location = New System.Drawing.Point(148, 11)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(76, 13)
        Me.Label11.TabIndex = 32
        Me.Label11.Text = "No. Sequence" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10)
        '
        'celdaNumeroSerie
        '
        Me.celdaNumeroSerie.BackColor = System.Drawing.SystemColors.Info
        Me.celdaNumeroSerie.Location = New System.Drawing.Point(169, 28)
        Me.celdaNumeroSerie.Name = "celdaNumeroSerie"
        Me.celdaNumeroSerie.ReadOnly = True
        Me.celdaNumeroSerie.Size = New System.Drawing.Size(44, 20)
        Me.celdaNumeroSerie.TabIndex = 31
        '
        'etiquetaSerie
        '
        Me.etiquetaSerie.AutoSize = True
        Me.etiquetaSerie.Location = New System.Drawing.Point(236, 11)
        Me.etiquetaSerie.Name = "etiquetaSerie"
        Me.etiquetaSerie.Size = New System.Drawing.Size(56, 13)
        Me.etiquetaSerie.TabIndex = 30
        Me.etiquetaSerie.Text = "Sequence"
        '
        'celdaSerie
        '
        Me.celdaSerie.BackColor = System.Drawing.SystemColors.Info
        Me.celdaSerie.Location = New System.Drawing.Point(230, 28)
        Me.celdaSerie.Name = "celdaSerie"
        Me.celdaSerie.ReadOnly = True
        Me.celdaSerie.Size = New System.Drawing.Size(87, 20)
        Me.celdaSerie.TabIndex = 29
        '
        'botonSerie
        '
        Me.botonSerie.Location = New System.Drawing.Point(322, 27)
        Me.botonSerie.Margin = New System.Windows.Forms.Padding(2)
        Me.botonSerie.Name = "botonSerie"
        Me.botonSerie.Size = New System.Drawing.Size(33, 19)
        Me.botonSerie.TabIndex = 28
        Me.botonSerie.Text = "..."
        Me.botonSerie.UseVisualStyleBackColor = True
        '
        'botonMoneda
        '
        Me.botonMoneda.Location = New System.Drawing.Point(97, 201)
        Me.botonMoneda.Margin = New System.Windows.Forms.Padding(2)
        Me.botonMoneda.Name = "botonMoneda"
        Me.botonMoneda.Size = New System.Drawing.Size(37, 19)
        Me.botonMoneda.TabIndex = 27
        Me.botonMoneda.Text = "..."
        Me.botonMoneda.UseVisualStyleBackColor = True
        '
        'celdaidMoneda
        '
        Me.celdaidMoneda.Location = New System.Drawing.Point(27, 200)
        Me.celdaidMoneda.Margin = New System.Windows.Forms.Padding(2)
        Me.celdaidMoneda.Name = "celdaidMoneda"
        Me.celdaidMoneda.ReadOnly = True
        Me.celdaidMoneda.Size = New System.Drawing.Size(66, 20)
        Me.celdaidMoneda.TabIndex = 26
        '
        'celdaObservaciones
        '
        Me.celdaObservaciones.Anchor = CType(((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.celdaObservaciones.Location = New System.Drawing.Point(401, 188)
        Me.celdaObservaciones.Multiline = True
        Me.celdaObservaciones.Name = "celdaObservaciones"
        Me.celdaObservaciones.Size = New System.Drawing.Size(384, 36)
        Me.celdaObservaciones.TabIndex = 25
        Me.celdaObservaciones.Text = "..."
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Location = New System.Drawing.Point(310, 203)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(69, 13)
        Me.Label10.TabIndex = 24
        Me.Label10.Text = "Observations"
        '
        'celdaIDCosto
        '
        Me.celdaIDCosto.AutoSize = True
        Me.celdaIDCosto.Location = New System.Drawing.Point(391, 99)
        Me.celdaIDCosto.Name = "celdaIDCosto"
        Me.celdaIDCosto.Size = New System.Drawing.Size(16, 13)
        Me.celdaIDCosto.TabIndex = 23
        Me.celdaIDCosto.Text = "-1"
        Me.celdaIDCosto.Visible = False
        '
        'celdaTotal
        '
        Me.celdaTotal.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.celdaTotal.BackColor = System.Drawing.SystemColors.Info
        Me.celdaTotal.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.celdaTotal.Location = New System.Drawing.Point(680, 22)
        Me.celdaTotal.Name = "celdaTotal"
        Me.celdaTotal.Size = New System.Drawing.Size(100, 22)
        Me.celdaTotal.TabIndex = 22
        '
        'Label9
        '
        Me.Label9.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label9.AutoSize = True
        Me.Label9.Location = New System.Drawing.Point(722, 5)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(31, 13)
        Me.Label9.TabIndex = 21
        Me.Label9.Text = "Total"
        '
        'celdaMoneda
        '
        Me.celdaMoneda.AutoSize = True
        Me.celdaMoneda.Location = New System.Drawing.Point(391, 79)
        Me.celdaMoneda.Name = "celdaMoneda"
        Me.celdaMoneda.Size = New System.Drawing.Size(16, 13)
        Me.celdaMoneda.TabIndex = 20
        Me.celdaMoneda.Text = "-1"
        Me.celdaMoneda.Visible = False
        '
        'botonCCostos
        '
        Me.botonCCostos.Location = New System.Drawing.Point(344, 75)
        Me.botonCCostos.Name = "botonCCostos"
        Me.botonCCostos.Size = New System.Drawing.Size(25, 22)
        Me.botonCCostos.TabIndex = 19
        Me.botonCCostos.Text = "..."
        Me.botonCCostos.UseVisualStyleBackColor = True
        Me.botonCCostos.Visible = False
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Location = New System.Drawing.Point(207, 53)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(88, 13)
        Me.Label8.TabIndex = 18
        Me.Label8.Text = "Centro de Costos"
        Me.Label8.Visible = False
        '
        'celdaCostos
        '
        Me.celdaCostos.Location = New System.Drawing.Point(169, 134)
        Me.celdaCostos.Name = "celdaCostos"
        Me.celdaCostos.ReadOnly = True
        Me.celdaCostos.Size = New System.Drawing.Size(143, 20)
        Me.celdaCostos.TabIndex = 17
        Me.celdaCostos.Visible = False
        '
        'celdaTasa
        '
        Me.celdaTasa.Location = New System.Drawing.Point(203, 200)
        Me.celdaTasa.Name = "celdaTasa"
        Me.celdaTasa.ReadOnly = True
        Me.celdaTasa.Size = New System.Drawing.Size(100, 20)
        Me.celdaTasa.TabIndex = 16
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(200, 183)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(81, 13)
        Me.Label7.TabIndex = 14
        Me.Label7.Text = "Exchange Rate"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(24, 183)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(49, 13)
        Me.Label6.TabIndex = 13
        Me.Label6.Text = "Currency"
        '
        'celdaDireccion
        '
        Me.celdaDireccion.Location = New System.Drawing.Point(27, 160)
        Me.celdaDireccion.Name = "celdaDireccion"
        Me.celdaDireccion.ReadOnly = True
        Me.celdaDireccion.Size = New System.Drawing.Size(469, 20)
        Me.celdaDireccion.TabIndex = 12
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(24, 144)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(45, 13)
        Me.Label5.TabIndex = 11
        Me.Label5.Text = "Address" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10)
        '
        'checkActivo
        '
        Me.checkActivo.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.checkActivo.AutoSize = True
        Me.checkActivo.Checked = True
        Me.checkActivo.CheckState = System.Windows.Forms.CheckState.Checked
        Me.checkActivo.Location = New System.Drawing.Point(784, 25)
        Me.checkActivo.Name = "checkActivo"
        Me.checkActivo.Size = New System.Drawing.Size(64, 17)
        Me.checkActivo.TabIndex = 10
        Me.checkActivo.Text = "ACTIVE"
        Me.checkActivo.UseVisualStyleBackColor = True
        '
        'dtpFecha
        '
        Me.dtpFecha.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.dtpFecha.Location = New System.Drawing.Point(26, 79)
        Me.dtpFecha.Name = "dtpFecha"
        Me.dtpFecha.Size = New System.Drawing.Size(114, 20)
        Me.dtpFecha.TabIndex = 9
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(23, 62)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(30, 13)
        Me.Label4.TabIndex = 8
        Me.Label4.Text = "Date"
        '
        'celdaAño
        '
        Me.celdaAño.BackColor = System.Drawing.SystemColors.Info
        Me.celdaAño.Location = New System.Drawing.Point(83, 28)
        Me.celdaAño.Name = "celdaAño"
        Me.celdaAño.ReadOnly = True
        Me.celdaAño.Size = New System.Drawing.Size(57, 20)
        Me.celdaAño.TabIndex = 7
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(94, 13)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(29, 13)
        Me.Label3.TabIndex = 6
        Me.Label3.Text = "Year"
        '
        'celdaID
        '
        Me.celdaID.BackColor = System.Drawing.SystemColors.Info
        Me.celdaID.Location = New System.Drawing.Point(26, 28)
        Me.celdaID.Name = "celdaID"
        Me.celdaID.ReadOnly = True
        Me.celdaID.Size = New System.Drawing.Size(57, 20)
        Me.celdaID.TabIndex = 5
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(28, 13)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(53, 13)
        Me.Label2.TabIndex = 4
        Me.Label2.Text = "No. Order" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10)
        '
        'celdaIdProveedor
        '
        Me.celdaIdProveedor.AutoSize = True
        Me.celdaIdProveedor.Location = New System.Drawing.Point(86, 99)
        Me.celdaIdProveedor.Name = "celdaIdProveedor"
        Me.celdaIdProveedor.Size = New System.Drawing.Size(16, 13)
        Me.celdaIdProveedor.TabIndex = 3
        Me.celdaIdProveedor.Text = "-1"
        Me.celdaIdProveedor.Visible = False
        '
        'botonProveedor
        '
        Me.botonProveedor.Location = New System.Drawing.Point(501, 114)
        Me.botonProveedor.Name = "botonProveedor"
        Me.botonProveedor.Size = New System.Drawing.Size(29, 20)
        Me.botonProveedor.TabIndex = 2
        Me.botonProveedor.Text = "..."
        Me.botonProveedor.UseVisualStyleBackColor = True
        '
        'celdaProveedor
        '
        Me.celdaProveedor.Location = New System.Drawing.Point(27, 115)
        Me.celdaProveedor.Name = "celdaProveedor"
        Me.celdaProveedor.ReadOnly = True
        Me.celdaProveedor.Size = New System.Drawing.Size(469, 20)
        Me.celdaProveedor.TabIndex = 1
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(24, 99)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(46, 13)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "Provider"
        '
        'panelLIsta
        '
        Me.panelLIsta.Controls.Add(Me.dgLista)
        Me.panelLIsta.Controls.Add(Me.panelFiltro)
        Me.panelLIsta.Location = New System.Drawing.Point(788, 115)
        Me.panelLIsta.Name = "panelLIsta"
        Me.panelLIsta.Size = New System.Drawing.Size(299, 231)
        Me.panelLIsta.TabIndex = 3
        '
        'dgLista
        '
        Me.dgLista.AllowUserToAddRows = False
        Me.dgLista.AllowUserToDeleteRows = False
        DataGridViewCellStyle7.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle7.BackColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle7.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!)
        DataGridViewCellStyle7.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle7.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle7.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle7.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.dgLista.ColumnHeadersDefaultCellStyle = DataGridViewCellStyle7
        Me.dgLista.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgLista.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.colOrdenCompra, Me.colAnio, Me.colFecha, Me.colNombre, Me.colSerie, Me.col_total, Me.col_estado})
        DataGridViewCellStyle8.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle8.BackColor = System.Drawing.SystemColors.Window
        DataGridViewCellStyle8.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!)
        DataGridViewCellStyle8.ForeColor = System.Drawing.SystemColors.ControlText
        DataGridViewCellStyle8.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle8.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle8.WrapMode = System.Windows.Forms.DataGridViewTriState.[False]
        Me.dgLista.DefaultCellStyle = DataGridViewCellStyle8
        Me.dgLista.Dock = System.Windows.Forms.DockStyle.Fill
        Me.dgLista.Location = New System.Drawing.Point(0, 82)
        Me.dgLista.MultiSelect = False
        Me.dgLista.Name = "dgLista"
        Me.dgLista.ReadOnly = True
        DataGridViewCellStyle9.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle9.BackColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle9.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!)
        DataGridViewCellStyle9.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle9.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle9.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle9.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.dgLista.RowHeadersDefaultCellStyle = DataGridViewCellStyle9
        Me.dgLista.RowHeadersWidth = 51
        Me.dgLista.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.dgLista.Size = New System.Drawing.Size(299, 149)
        Me.dgLista.TabIndex = 1
        '
        'colOrdenCompra
        '
        Me.colOrdenCompra.HeaderText = "Code"
        Me.colOrdenCompra.MinimumWidth = 6
        Me.colOrdenCompra.Name = "colOrdenCompra"
        Me.colOrdenCompra.ReadOnly = True
        Me.colOrdenCompra.Width = 125
        '
        'colAnio
        '
        Me.colAnio.HeaderText = "Year"
        Me.colAnio.MinimumWidth = 6
        Me.colAnio.Name = "colAnio"
        Me.colAnio.ReadOnly = True
        Me.colAnio.Visible = False
        Me.colAnio.Width = 125
        '
        'colFecha
        '
        Me.colFecha.HeaderText = "Date"
        Me.colFecha.MinimumWidth = 6
        Me.colFecha.Name = "colFecha"
        Me.colFecha.ReadOnly = True
        Me.colFecha.Width = 125
        '
        'colNombre
        '
        Me.colNombre.HeaderText = "Name"
        Me.colNombre.MinimumWidth = 6
        Me.colNombre.Name = "colNombre"
        Me.colNombre.ReadOnly = True
        Me.colNombre.Width = 125
        '
        'colSerie
        '
        Me.colSerie.HeaderText = "Sequence"
        Me.colSerie.MinimumWidth = 6
        Me.colSerie.Name = "colSerie"
        Me.colSerie.ReadOnly = True
        Me.colSerie.Width = 125
        '
        'col_total
        '
        Me.col_total.HeaderText = "Total"
        Me.col_total.MinimumWidth = 6
        Me.col_total.Name = "col_total"
        Me.col_total.ReadOnly = True
        Me.col_total.Width = 125
        '
        'col_estado
        '
        Me.col_estado.HeaderText = "Status"
        Me.col_estado.MinimumWidth = 6
        Me.col_estado.Name = "col_estado"
        Me.col_estado.ReadOnly = True
        Me.col_estado.Width = 125
        '
        'panelFiltro
        '
        Me.panelFiltro.Controls.Add(Me.GroupBox1)
        Me.panelFiltro.Dock = System.Windows.Forms.DockStyle.Top
        Me.panelFiltro.Location = New System.Drawing.Point(0, 0)
        Me.panelFiltro.Name = "panelFiltro"
        Me.panelFiltro.Size = New System.Drawing.Size(299, 82)
        Me.panelFiltro.TabIndex = 0
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.botonFiltrar)
        Me.GroupBox1.Controls.Add(Me.dtpFin)
        Me.GroupBox1.Controls.Add(Me.dtpInicio)
        Me.GroupBox1.Controls.Add(Me.checkFechas)
        Me.GroupBox1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.GroupBox1.Location = New System.Drawing.Point(0, 0)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(299, 82)
        Me.GroupBox1.TabIndex = 0
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Filter By:"
        '
        'botonFiltrar
        '
        Me.botonFiltrar.Location = New System.Drawing.Point(221, 48)
        Me.botonFiltrar.Name = "botonFiltrar"
        Me.botonFiltrar.Size = New System.Drawing.Size(75, 23)
        Me.botonFiltrar.TabIndex = 3
        Me.botonFiltrar.Text = "Filtered"
        Me.botonFiltrar.UseVisualStyleBackColor = True
        '
        'dtpFin
        '
        Me.dtpFin.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.dtpFin.Location = New System.Drawing.Point(118, 48)
        Me.dtpFin.Name = "dtpFin"
        Me.dtpFin.Size = New System.Drawing.Size(97, 20)
        Me.dtpFin.TabIndex = 2
        '
        'dtpInicio
        '
        Me.dtpInicio.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.dtpInicio.Location = New System.Drawing.Point(15, 48)
        Me.dtpInicio.Name = "dtpInicio"
        Me.dtpInicio.Size = New System.Drawing.Size(97, 20)
        Me.dtpInicio.TabIndex = 1
        '
        'checkFechas
        '
        Me.checkFechas.AutoSize = True
        Me.checkFechas.Checked = True
        Me.checkFechas.CheckState = System.Windows.Forms.CheckState.Checked
        Me.checkFechas.Location = New System.Drawing.Point(15, 25)
        Me.checkFechas.Name = "checkFechas"
        Me.checkFechas.Size = New System.Drawing.Size(84, 17)
        Me.checkFechas.TabIndex = 0
        Me.checkFechas.Text = "Date Range" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10)
        Me.checkFechas.UseVisualStyleBackColor = True
        '
        'botonInprimir
        '
        Me.botonInprimir.Image = CType(resources.GetObject("botonInprimir.Image"), System.Drawing.Image)
        Me.botonInprimir.Location = New System.Drawing.Point(210, 11)
        Me.botonInprimir.Name = "botonInprimir"
        Me.botonInprimir.Size = New System.Drawing.Size(59, 45)
        Me.botonInprimir.TabIndex = 19
        Me.botonInprimir.Text = "Print"
        Me.botonInprimir.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.botonInprimir.UseVisualStyleBackColor = True
        '
        'BarraTitulo1
        '
        Me.BarraTitulo1.BackColor = System.Drawing.Color.WhiteSmoke
        Me.BarraTitulo1.Dock = System.Windows.Forms.DockStyle.Top
        Me.BarraTitulo1.Location = New System.Drawing.Point(0, 68)
        Me.BarraTitulo1.Margin = New System.Windows.Forms.Padding(4)
        Me.BarraTitulo1.Name = "BarraTitulo1"
        Me.BarraTitulo1.Size = New System.Drawing.Size(992, 30)
        Me.BarraTitulo1.TabIndex = 1
        '
        'Encabezado1
        '
        Me.Encabezado1.Dock = System.Windows.Forms.DockStyle.Top
        Me.Encabezado1.Location = New System.Drawing.Point(0, 0)
        Me.Encabezado1.Margin = New System.Windows.Forms.Padding(4)
        Me.Encabezado1.Name = "Encabezado1"
        Me.Encabezado1.Size = New System.Drawing.Size(992, 68)
        Me.Encabezado1.TabIndex = 0
        '
        'frmOrdenCompra
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(992, 630)
        Me.Controls.Add(Me.botonInprimir)
        Me.Controls.Add(Me.panelLIsta)
        Me.Controls.Add(Me.panelDocumento)
        Me.Controls.Add(Me.BarraTitulo1)
        Me.Controls.Add(Me.Encabezado1)
        Me.Name = "frmOrdenCompra"
        Me.Text = " "
        Me.WindowState = System.Windows.Forms.FormWindowState.Maximized
        Me.panelDocumento.ResumeLayout(False)
        Me.Panel1.ResumeLayout(False)
        CType(Me.dtDetalle, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Panel2.ResumeLayout(False)
        Me.panelProveedor.ResumeLayout(False)
        Me.panelProveedor.PerformLayout()
        Me.PanelDelivery.ResumeLayout(False)
        Me.PanelDelivery.PerformLayout()
        Me.gbCamposAdicionales.ResumeLayout(False)
        Me.gbCamposAdicionales.PerformLayout()
        Me.panelDeliveryDate.ResumeLayout(False)
        Me.panelDeliveryDate.PerformLayout()
        Me.panelApprovalDate.ResumeLayout(False)
        Me.panelApprovalDate.PerformLayout()
        Me.PanelRequisicion.ResumeLayout(False)
        Me.PanelRequisicion.PerformLayout()
        Me.panelRequerido.ResumeLayout(False)
        Me.panelRequerido.PerformLayout()
        Me.panelResolucion.ResumeLayout(False)
        Me.panelResolucion.PerformLayout()
        Me.panelDiasCredito.ResumeLayout(False)
        Me.panelDiasCredito.PerformLayout()
        Me.panelLIsta.ResumeLayout(False)
        CType(Me.dgLista, System.ComponentModel.ISupportInitialize).EndInit()
        Me.panelFiltro.ResumeLayout(False)
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents Encabezado1 As KARIMs_SGI.encabezado
    Friend WithEvents BarraTitulo1 As KARIMs_SGI.BarraTitulo
    Friend WithEvents panelDocumento As System.Windows.Forms.Panel
    Friend WithEvents panelLIsta As System.Windows.Forms.Panel
    Friend WithEvents panelFiltro As System.Windows.Forms.Panel
    Friend WithEvents dtDetalle As System.Windows.Forms.DataGridView
    Friend WithEvents panelProveedor As System.Windows.Forms.Panel
    Friend WithEvents celdaTasa As System.Windows.Forms.TextBox
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents celdaDireccion As System.Windows.Forms.TextBox
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents checkActivo As System.Windows.Forms.CheckBox
    Friend WithEvents dtpFecha As System.Windows.Forms.DateTimePicker
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents celdaAño As System.Windows.Forms.TextBox
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents celdaID As System.Windows.Forms.TextBox
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents celdaIdProveedor As System.Windows.Forms.Label
    Friend WithEvents botonProveedor As System.Windows.Forms.Button
    Friend WithEvents celdaProveedor As System.Windows.Forms.TextBox
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents botonCCostos As System.Windows.Forms.Button
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents celdaCostos As System.Windows.Forms.TextBox
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents checkFechas As System.Windows.Forms.CheckBox
    Friend WithEvents botonFiltrar As System.Windows.Forms.Button
    Friend WithEvents dtpFin As System.Windows.Forms.DateTimePicker
    Friend WithEvents dtpInicio As System.Windows.Forms.DateTimePicker
    Friend WithEvents celdaMoneda As System.Windows.Forms.Label
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
    Friend WithEvents Panel2 As System.Windows.Forms.Panel
    Friend WithEvents botonQuitar As System.Windows.Forms.Button
    Friend WithEvents botonAgregar As System.Windows.Forms.Button
    Friend WithEvents botonInprimir As System.Windows.Forms.Button
    Friend WithEvents celdaTotal As System.Windows.Forms.TextBox
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents celdaObservaciones As System.Windows.Forms.TextBox
    Friend WithEvents Label10 As System.Windows.Forms.Label
    Friend WithEvents celdaIDCosto As System.Windows.Forms.Label
    Friend WithEvents dgLista As System.Windows.Forms.DataGridView
    Friend WithEvents botonMoneda As Button
    Friend WithEvents celdaidMoneda As TextBox
    Friend WithEvents etiquetaSerie As Label
    Friend WithEvents celdaSerie As TextBox
    Friend WithEvents botonSerie As Button
    Friend WithEvents Label11 As Label
    Friend WithEvents celdaNumeroSerie As TextBox
    Friend WithEvents colOrdenCompra As DataGridViewTextBoxColumn
    Friend WithEvents colAnio As DataGridViewTextBoxColumn
    Friend WithEvents colFecha As DataGridViewTextBoxColumn
    Friend WithEvents colNombre As DataGridViewTextBoxColumn
    Friend WithEvents colSerie As DataGridViewTextBoxColumn
    Friend WithEvents col_total As DataGridViewTextBoxColumn
    Friend WithEvents col_estado As DataGridViewTextBoxColumn
    Friend WithEvents rbContado As RadioButton
    Friend WithEvents rbCredito As RadioButton
    Friend WithEvents panelDiasCredito As Panel
    Friend WithEvents celdaDiasCredito As TextBox
    Friend WithEvents Label23 As Label
    Friend WithEvents panelResolucion As Panel
    Friend WithEvents celdaIdResolución As TextBox
    Friend WithEvents celdaResolucion As TextBox
    Friend WithEvents Label12 As Label
    Friend WithEvents botonResolción As Button
    Friend WithEvents PanelRequisicion As Panel
    Friend WithEvents celdaRequisicion As TextBox
    Friend WithEvents lblRequisicion As Label
    Friend WithEvents panelRequerido As Panel
    Friend WithEvents celdaRequerido As TextBox
    Friend WithEvents lblRequerido As Label
    Friend WithEvents panelApprovalDate As Panel
    Friend WithEvents lblApprovalDate As Label
    Friend WithEvents checkFechaAprobacion As System.Windows.Forms.CheckBox
    Friend WithEvents dtpFechaAprobacion As System.Windows.Forms.DateTimePicker
    Friend WithEvents panelDeliveryDate As Panel
    Friend WithEvents dtpDeliveryDate As DateTimePicker
    Friend WithEvents lblDeliveryDate As Label
    Friend WithEvents gbCamposAdicionales As GroupBox
    Friend WithEvents celdaTexto2 As TextBox
    Friend WithEvents celdaTexto1 As TextBox
    Friend WithEvents celdaTexto3 As TextBox
    Friend WithEvents lblPacking As Label
    Friend WithEvents txtTEXT3 As TextBox
    Friend WithEvents txtTEXT2 As TextBox
    Friend WithEvents txtTEXT1 As TextBox
    Friend WithEvents PanelDelivery As Panel
    Friend WithEvents celdaDelivery As TextBox
    Friend WithEvents Label13 As Label
    Friend WithEvents Label14 As Label
    Friend WithEvents celdaOCE As TextBox
    Friend WithEvents celdaTexto4 As TextBox
    Friend WithEvents txtTEXT4 As TextBox
    Friend WithEvents colCodigo As DataGridViewTextBoxColumn
    Friend WithEvents colDescripcion As DataGridViewTextBoxColumn
    Friend WithEvents colUM As DataGridViewTextBoxColumn
    Friend WithEvents colCantidad As DataGridViewTextBoxColumn
    Friend WithEvents colPrecio As DataGridViewTextBoxColumn
    Friend WithEvents col_medida As DataGridViewTextBoxColumn
    Friend WithEvents col_id As DataGridViewTextBoxColumn
    Friend WithEvents colTotal As DataGridViewTextBoxColumn
    Friend WithEvents col_centro As DataGridViewTextBoxColumn
    Friend WithEvents col_id3 As DataGridViewTextBoxColumn
    Friend WithEvents col_Requeride As DataGridViewTextBoxColumn
    Friend WithEvents col_IdRequeride As DataGridViewTextBoxColumn
    Friend WithEvents colCatalogo As DataGridViewTextBoxColumn
    Friend WithEvents colAño As DataGridViewTextBoxColumn
    Friend WithEvents colNumero As DataGridViewTextBoxColumn
    Friend WithEvents colLinea As DataGridViewTextBoxColumn
    Friend WithEvents col_catalogo As DataGridViewTextBoxColumn
    Friend WithEvents col_año As DataGridViewTextBoxColumn
    Friend WithEvents col_numero As DataGridViewTextBoxColumn
    Friend WithEvents col_linea As DataGridViewTextBoxColumn
    Friend WithEvents colComentario As DataGridViewTextBoxColumn
    Friend WithEvents colExoneracion As DataGridViewTextBoxColumn
    Friend WithEvents colidExoneracion As DataGridViewTextBoxColumn
    Friend WithEvents colIdRubro As DataGridViewTextBoxColumn
    Friend WithEvents colRubro As DataGridViewTextBoxColumn
    Friend WithEvents colEstado1 As DataGridViewTextBoxColumn
    Friend WithEvents colCantidadRecibida As DataGridViewTextBoxColumn
    Friend WithEvents colIdCosto As DataGridViewTextBoxColumn
    Friend WithEvents colCosto As DataGridViewTextBoxColumn
    Friend WithEvents colIdCenterCost As DataGridViewTextBoxColumn
    Friend WithEvents colCentroCosto As DataGridViewTextBoxColumn
    Friend WithEvents colPercentage As DataGridViewTextBoxColumn
    Friend WithEvents colDiscounts As DataGridViewTextBoxColumn
    Friend WithEvents colCancelado As DataGridViewTextBoxColumn
End Class
