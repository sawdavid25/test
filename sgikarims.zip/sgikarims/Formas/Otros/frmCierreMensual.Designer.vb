﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmCierreMensual
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.panelLista = New System.Windows.Forms.Panel()
        Me.dgLista = New System.Windows.Forms.DataGridView()
        Me.botonImprimir = New System.Windows.Forms.Button()
        Me.Encabezado1 = New KARIMs_SGI.encabezado()
        Me.colIdMes = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colAnio = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colMes = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colEstado = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.panelLista.SuspendLayout()
        CType(Me.dgLista, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'panelLista
        '
        Me.panelLista.Controls.Add(Me.dgLista)
        Me.panelLista.Dock = System.Windows.Forms.DockStyle.Fill
        Me.panelLista.Location = New System.Drawing.Point(0, 76)
        Me.panelLista.Name = "panelLista"
        Me.panelLista.Size = New System.Drawing.Size(625, 348)
        Me.panelLista.TabIndex = 1
        '
        'dgLista
        '
        Me.dgLista.AllowUserToAddRows = False
        Me.dgLista.AllowUserToDeleteRows = False
        Me.dgLista.AllowUserToResizeColumns = False
        Me.dgLista.BackgroundColor = System.Drawing.SystemColors.Control
        Me.dgLista.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgLista.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.colIdMes, Me.colAnio, Me.colMes, Me.colEstado})
        Me.dgLista.Dock = System.Windows.Forms.DockStyle.Fill
        Me.dgLista.Location = New System.Drawing.Point(0, 0)
        Me.dgLista.Name = "dgLista"
        Me.dgLista.ReadOnly = True
        Me.dgLista.RowTemplate.Height = 24
        Me.dgLista.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.dgLista.Size = New System.Drawing.Size(625, 348)
        Me.dgLista.TabIndex = 0
        '
        'botonImprimir
        '
        Me.botonImprimir.Image = Global.KARIMs_SGI.My.Resources.Resources.print
        Me.botonImprimir.Location = New System.Drawing.Point(273, 11)
        Me.botonImprimir.Name = "botonImprimir"
        Me.botonImprimir.Size = New System.Drawing.Size(75, 55)
        Me.botonImprimir.TabIndex = 2
        Me.botonImprimir.Text = "Print"
        Me.botonImprimir.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.botonImprimir.UseVisualStyleBackColor = True
        '
        'Encabezado1
        '
        Me.Encabezado1.Dock = System.Windows.Forms.DockStyle.Top
        Me.Encabezado1.Location = New System.Drawing.Point(0, 0)
        Me.Encabezado1.Margin = New System.Windows.Forms.Padding(4)
        Me.Encabezado1.Name = "Encabezado1"
        Me.Encabezado1.Size = New System.Drawing.Size(625, 76)
        Me.Encabezado1.TabIndex = 0
        '
        'colIdMes
        '
        Me.colIdMes.HeaderText = "Numero"
        Me.colIdMes.Name = "colIdMes"
        Me.colIdMes.ReadOnly = True
        '
        'colAnio
        '
        Me.colAnio.HeaderText = "Año"
        Me.colAnio.Name = "colAnio"
        Me.colAnio.ReadOnly = True
        '
        'colMes
        '
        Me.colMes.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.colMes.HeaderText = "Descripción"
        Me.colMes.Name = "colMes"
        Me.colMes.ReadOnly = True
        Me.colMes.Width = 111
        '
        'colEstado
        '
        Me.colEstado.HeaderText = "Estado"
        Me.colEstado.Name = "colEstado"
        Me.colEstado.ReadOnly = True
        '
        'frmCierreMensual
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(625, 424)
        Me.Controls.Add(Me.botonImprimir)
        Me.Controls.Add(Me.panelLista)
        Me.Controls.Add(Me.Encabezado1)
        Me.Name = "frmCierreMensual"
        Me.Text = "Cierre Mensual"
        Me.panelLista.ResumeLayout(False)
        CType(Me.dgLista, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents Encabezado1 As encabezado
    Friend WithEvents panelLista As Panel
    Friend WithEvents dgLista As DataGridView
    Friend WithEvents botonImprimir As Button
    Friend WithEvents colIdMes As DataGridViewTextBoxColumn
    Friend WithEvents colAnio As DataGridViewTextBoxColumn
    Friend WithEvents colMes As DataGridViewTextBoxColumn
    Friend WithEvents colEstado As DataGridViewTextBoxColumn
End Class
