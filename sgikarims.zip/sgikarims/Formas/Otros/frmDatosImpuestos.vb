﻿Public Class frmDatosImpuestos

#Region "Miembros"

    Dim strKey As String = STR_VACIO
    Dim logInsertar As Boolean = False
    Dim logConsultar As Boolean = False
    Dim logEditar As Boolean = False
    Dim LogBorrar As Boolean = False
    Const CAT_ORD As Integer = 777
    Dim cfun As New clsFunciones
    Dim intCurDoc As Integer
    Dim clic As Boolean = False
    Dim intmodo As String
    Dim ContarFilas As Integer
    Dim msj As String
    Dim strDato1 As String = STR_VACIO
    Dim strDato2 As String = STR_VACIO
    Dim strDato3 As String = STR_VACIO
    Dim strDato4 As String = STR_VACIO
    Dim strDato5 As String = STR_VACIO


#End Region


#Region "Propiedades"
    Public Property Key As String
        Get
            Return strKey
        End Get
        Set(value As String)
            strKey = value
        End Set
    End Property
    Public Property Dato1 As String
        Get
            Return strDato1
        End Get
        Set(value As String)
            strDato1 = value
        End Set
    End Property

    Public Property Dato2 As String
        Get
            Return strDato2
        End Get
        Set(value As String)
            strDato2 = value
        End Set
    End Property

    Public Property Dato3 As String
        Get
            Return strDato3
        End Get
        Set(value As String)
            strDato3 = value
        End Set
    End Property

    Public Property Dato4 As String
        Get
            Return strDato4
        End Get
        Set(value As String)
            strDato4 = value
        End Set
    End Property

    Public Property Dato5 As String
        Get
            Return strDato4
        End Get
        Set(value As String)
            strDato5 = value
        End Set
    End Property
#End Region


#Region "Procedimientos"
    Private Sub Accesos()
        Dim cAcesos As New clsAccesos

        Try
            If cAcesos.Accesos(strKey) = True Then
                logInsertar = cAcesos.Insertar
                logEditar = cAcesos.Editar
                LogBorrar = cAcesos.Borrar
                logConsultar = cAcesos.Consultar

            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub Aceptar()
        Try
            Dato1 = celdaDescripcion.Text
            Dato2 = celdaFactor.Text
            Dato3 = celdaCantidad.Text
            If checkMonto.Checked = False Then
                Dato4 = celdaTotal.Text
            Else
                Dato4 = celdaTotalOpcional.Text
            End If


        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try

        Me.DialogResult = System.Windows.Forms.DialogResult.OK

    End Sub
#End Region








#Region "Eventos"

    Private Sub botonAceptar_Click(sender As Object, e As EventArgs) Handles botonAceptar.Click
        Me.DialogResult = System.Windows.Forms.DialogResult.OK
        Aceptar()
    End Sub

    Private Sub checkMonto_Click(sender As Object, e As EventArgs) Handles checkMonto.Click
        If checkMonto.Checked = True Then
            celdaTotalOpcional.Enabled = True
            celdaTotal.Enabled = False
        Else
            celdaTotalOpcional.Enabled = False
            celdaTotal.Enabled = True

        End If
    End Sub

    Private Sub celdaCantidad_TextChanged(sender As Object, e As EventArgs) Handles celdaCantidad.TextChanged

        If celdaCantidad.Text.Length > 0 Then
            celdaTotal.Text = Math.Round((celdaFactor.Text * celdaCantidad.Text), 2).ToString(FORMATO_MONEDA)

        Else
            celdaTotal.Text = 0
        End If
    End Sub



#End Region
    Private Sub botonDescripcion_Click(sender As Object, e As EventArgs) Handles botonDescripcion.Click
        Dim strRemplazo As String = STR_VACIO
        Dim strfila As String = STR_VACIO

        Dim frm As New frmSeleccionar

        strRemplazo = "cat_sisemp = {empresa}"
        strRemplazo = Replace(strRemplazo, "{empresa}", Sesion.IdEmpresa)

        Try

            frm.Titulo = "Other Taxes"
            frm.Campos = "cat_desc Descripcion, cat_sist Impuesto"
            frm.Tabla = " Catalogos"
            frm.FiltroText = "Enter the other taxes to filter"
            frm.Filtro = "Descripcion"
            frm.Ordenamiento = "cat_num"
            frm.TipoOrdenamiento = ""
            frm.Condicion = strRemplazo & " AND cat_clase='IMP_DC'"

            frm.ShowDialog(Me)

            If frm.DialogResult = System.Windows.Forms.DialogResult.OK Then
                celdaDescripcion.Text = frm.LLave
                celdaFactor.Text = frm.Dato

            End If


        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try

    End Sub

    Private Sub botonCancelar_Click(sender As Object, e As EventArgs) Handles botonCancelar.Click
        Me.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.Close()
    End Sub

    Public Sub CargarDatos()
        celdaDescripcion.Text = Dato1
        celdaFactor.Text = Dato2
        celdaCantidad.Text = Dato3
        celdaTotal.Text = Dato4
    End Sub

End Class