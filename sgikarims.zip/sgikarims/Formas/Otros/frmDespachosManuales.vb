﻿Public Class frmDespachosManuales

#Region "Miembros"

    Dim strKey As String = STR_VACIO
    Dim logInsertar As Boolean = False
    Dim logConsultar As Boolean = False
    Dim logEditar As Boolean = False
    Dim LogBorrar As Boolean = False
    Private intCurDoc As Integer

#End Region

#Region "Propiedades"
    Public Property Key As String
        Get
            Return strKey
        End Get
        Set(value As String)
            strKey = value
        End Set
    End Property

#End Region

    Private Sub Accept_Click(sender As Object, e As EventArgs) Handles Accept.Click

    End Sub

    Private Sub botonCancelar_Click(sender As Object, e As EventArgs) Handles botonCancelar.Click

        Me.Close()

    End Sub

End Class