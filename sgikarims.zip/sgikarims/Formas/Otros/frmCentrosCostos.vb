﻿Public Class frmCentrosCostos
#Region "variables"
    Dim strKey As String = STR_VACIO
    Dim logInsertar As Boolean = False
    Dim logConsultar As Boolean = False
    Dim logEditar As Boolean = False
    Dim LogBorrar As Boolean = False
    Const INSERTAR = 1
    Const ACTUALIZAR = 2
    Const BORRAR = 3
    Const CONSULTAR = 4
    Dim dicRequisitos As New Dictionary(Of Integer, Integer)
    Dim dicAccesos As New Dictionary(Of Integer, Integer)
#End Region
#Region "propiedades"
    Public Property Key As String
        Get
            Return strKey
        End Get
        Set(value As String)
            strKey = value
        End Set
    End Property
#End Region

#Region "funciones"
    Private Sub MostrarLista(Optional ByVal logMostrar As Boolean = True, Optional logInsert As Boolean = False)
        Dim cfun As New clsFunciones
        If logMostrar = True Then
            'ocultar panel de documento
            paneldocumento.Dock = DockStyle.None
            paneldocumento.Visible = False
            'actualizar Titulo
            BarraTitulo1.CambiarTitulo("Centros de Costo")
            'Cargar Datos
            ' cfun.CargarLista(dgLista, SQLLista, False)
            CargarLista()
            'Mostrar Panel Filtro
            panelLista.Visible = True
            panelLista.Dock = DockStyle.Fill
            BloquearBotones()
            Me.Tag = "Nuevo"
        Else
            BloquearBotones(True)
            panelLista.Visible = False
            panelLista.Dock = DockStyle.None
            paneldocumento.Dock = DockStyle.Fill
            paneldocumento.Visible = True
            If logInsert = False Then
                Me.Tag = "Mod"
                BarraTitulo1.CambiarTitulo("Modificar Registro")
                BloquearBotones(False, True)
            Else
                Me.Tag = "Nuevo"

                BarraTitulo1.CambiarTitulo("Nuevo Registro")
                BloquearBotones(False)
            End If
            dglista.DataSource = Nothing
        End If
    End Sub
    Private Function sqlcargarcosto(ByVal intcodigo As Integer) As String
        Dim str_sql As String
        str_sql = " select cost_num, cost_nombre, cost_desc, cost_sist "
        str_sql &= "     from {conta}.costos"
        str_sql &= "        WHERE cost_num = {codigo}  "
        str_sql = Replace(str_sql, "{conta}", intcodigo)
        str_sql = Replace(str_sql, "{conta}", cFunciones.ContaEmpresa)
        Return str_sql
    End Function

    Private Sub CargarLista()
        Dim str_sql As String = STR_VACIO
        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader
        Dim strFila As String = STR_VACIO
        Try
            str_sql = sqlccosto()
            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(str_sql, CON)
            REA = COM.ExecuteReader
            If REA.HasRows Then
                dglista.Rows.Clear()
                Do While REA.Read
                    strFila = REA.GetInt32("cost_num") & "|"
                    strFila &= REA.GetString("cost_nombre") & "|"
                    strFila &= REA.GetString("cost_desc")
                    cFunciones.AgregarFila(dglista, strFila)
                Loop
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub frmCentrosCostos_Load(sender As Object, e As EventArgs) Handles Me.Load
        Accesos()
        MostrarLista()
    End Sub
    Private Function ComprobarDatos() As Boolean
        Dim logResultado As Boolean = False
        Try
            If celdanombre.Text.Length > 0 Then
                logResultado = True
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        Return logResultado
    End Function
    Private Function sqlccosto() As String
        Dim str_sql As String
        str_sql = " select cost_num, cost_nombre, cost_desc, cost_sist "
        str_sql &= "     from {conta}.costos"
        str_sql &= "        WHERE cost_num  >=0"
        str_sql = Replace(str_sql, "{conta}", cFunciones.ContaEmpresa)
        Return str_sql
    End Function

    Private Sub BloquearBotones(Optional ByVal logBloquear As Boolean = True, Optional logBorrar As Boolean = False)
        If logBloquear = True Then
            Encabezado1.botonGuardar.Enabled = False
            Encabezado1.botonBorrar.Enabled = False
        Else
            Encabezado1.botonGuardar.Enabled = True
            Encabezado1.botonBorrar.Enabled = True

        End If
    End Sub
    Private Sub Accesos()
        Dim cAccesos As New clsAccesos
        Try
            If cAccesos.Accesos(strKey) = True Then
                logInsertar = cAccesos.Insertar
                logConsultar = cAccesos.Consultar
                logEditar = cAccesos.Editar
                LogBorrar = cAccesos.Borrar
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub
    Private Function TieneAcceso(ByVal intOperacion As Integer) As Boolean
        Dim logResultado As Boolean = False
        Try
            If (dicRequisitos.Item(intOperacion) >= dicAccesos.Item(intOperacion)) Then
                logResultado = True
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        Return logResultado
    End Function
    Private Function Nuevo() As Integer
        Dim intResultado As Integer = NO_FILA
        Dim str_sql As String = STR_VACIO
        Dim COM As MySqlCommand

        Try
            str_sql = " select max(cost_num)+1 from {conta}.costos  "
            str_sql = Replace(str_sql, "{conta}", cFunciones.ContaEmpresa)
            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(str_sql, CON)
            intResultado = COM.ExecuteScalar
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try

        Return intResultado
    End Function
    Private Function SQLENCABEZADO(ByVal codigo As Integer) As String
        Dim str_sql As String = STR_VACIO

        str_sql = "  select cost_num, cost_nombre, cost_desc "
        str_sql &= "     from {conta}.costos"
        str_sql &= "     WHERE cost_num = {codigo}"
        str_sql = Replace(str_sql, "{codigo}", codigo)
        str_sql = Replace(str_sql, "{conta}", cFunciones.ContaEmpresa)
        Return str_sql
    End Function

    Public Sub CargarEncabezado(ByVal Codigo As Integer)
        Dim strSQL As String = STR_VACIO
        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader
        Dim strFila As String = STR_VACIO
        Try
            strSQL = SQLENCABEZADO(Codigo)
            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSQL, CON)
            REA = COM.ExecuteReader
            If REA.HasRows Then
                Do While REA.Read
                    celdacodigo.Text = REA.GetInt32("cost_num")
                    celdanombre.Text = REA.GetString("cost_nombre")
                    celdadescripcion.Text = REA.GetString("cost_desc")
                Loop
            End If

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Function guardarccosto() As Boolean
        Dim logresultado As Boolean
        Dim costo As New Tablas.TCOSTOS

        Try
            costo.CONEXION = strConexion
            costo.COST_NOMBRE = celdanombre.Text
            costo.COST_DESC = celdadescripcion.Text

            If Me.Tag = "Nuevo" Then
                costo.COST_NUM = Nuevo()

                If costo.PINSERT = False Then
                    MsgBox(costo.MERROR.ToString & "Could not save this document")
                    logresultado = False
                Else
                    logresultado = True
                    cFunciones.EscribirRegistro("Costos", clsFunciones.AccEnum.acAdd, celdacodigo.Text, 0, cFunciones.AñoMySQL, celdacodigo.Text, celdanombre.Text)
                End If
            ElseIf Me.Tag = "mod" Then
                costo.COST_NUM = celdacodigo.Text
                cFunciones.EscribirRegistro("Costos", clsFunciones.AccEnum.acUpdate, celdacodigo.Text, 0, cFunciones.AñoMySQL, celdacodigo.Text, celdanombre.Text)
                If costo.PUPDATE = False Then
                    MsgBox(costo.MERROR.ToString)
                    logresultado = False
                Else
                    logresultado = True
                End If
            End If

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try

        Return logresultado
    End Function

    Private Function borrarcosto() As Boolean
        Dim logresultado As Boolean = False
        Dim cost As New Tablas.TCOSTOS
        'Puede o no mandar Condicion. SI NO MANDA... mandar llaves de tabla.
        Dim strCondicion As String = STR_VACIO
        strCondicion = "  cost_num = {celdacodigo} "
        strCondicion = Replace(strCondicion, "{celdacodigo}", celdacodigo.Text)

        cFunciones.EscribirRegistro("Costos", clsFunciones.AccEnum.acDelete, celdacodigo.Text, 0, cFunciones.AñoMySQL, celdacodigo.Text, celdanombre.Text)

        Try
            cost.CONEXION = strConexion
            'pro.PRO_CODIGO = celdaCodigo.Text
            If cost.PDELETE(strCondicion) = True Then
                logresultado = True
                MsgBox("The record has been successfully deleted.", MsgBoxStyle.Information, "Deletion Successful")
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try

        Return logresultado

    End Function
    Public Sub reset()
        celdacodigo.Text = INT_CERO
        celdanombre.Text = ""
        celdadescripcion.Text = ""
    End Sub
#End Region

#Region "Eventos"
    Private Sub frmCcosto_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Accesos()
        MostrarLista()
        Me.Tag = "Nuevo"
    End Sub

    Private Sub dglista_DoubleClick(sender As Object, e As EventArgs) Handles dglista.DoubleClick
        Dim int_codigo As Integer
        If dglista.SelectedRows.Count = INT_CERO Then Exit Sub
        int_codigo = dglista.SelectedCells(0).Value
        reset()
        Me.Tag = "Mod"
        Encabezado1.botonGuardar.Enabled = False
        Encabezado1.botonBorrar.Enabled = True
        MostrarLista(0)
        CargarEncabezado(int_codigo)
    End Sub

    Private Sub Encabezado1_ClickGuardar(sender As Object, click As Boolean) Handles Encabezado1.ClickGuardar
        If ComprobarDatos() = True Then

            If guardarccosto() = True Then

                MostrarLista(True)
            End If
        Else
            MsgBox("Ingrese los datos")
        End If
        If ComprobarDatos() = True Then

            MostrarLista(True)
        End If
    End Sub

    Private Sub Encabezado1_ClickCerrar(sender As Object, click As Boolean) Handles Encabezado1.ClickCerrar
        If paneldocumento.Visible = True Then
            MostrarLista()
        Else
            Me.Close()
        End If
    End Sub

    Private Sub Encabezado1_ClickNuevo(sender As Object, click As Boolean) Handles Encabezado1.ClickNuevo
        MostrarLista(False, True)
        BloquearBotones(False)
        reset()
    End Sub

    Private Sub Encabezado1_ClickBorrar(sender As Object, click As Boolean) Handles Encabezado1.ClickBorrar

        If MsgBox("Esta seguro que desea eliminar", vbQuestion + vbYesNo, "Verificacion") = vbYes Then
            If borrarcosto() = True Then
                MostrarLista(True)
            End If
        Else
        End If

    End Sub

    Private Sub dglista_KeyDown(sender As Object, e As KeyEventArgs) Handles dglista.KeyDown
        Try
            If e.KeyCode = Keys.F3 Then
                cFunciones.BuscarenLista(dglista)
                e.Handled = True
                e.SuppressKeyPress = True
            ElseIf e.KeyCode = Keys.F7 Then
                Dim rpt As New clsReportes
                rpt.Historial(dglista.SelectedCells(0).Value, 0, 0)
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub frmCentrosCostos_FormClosing(sender As Object, e As FormClosingEventArgs) Handles Me.FormClosing
        Fprincipal.BarraDeTareas1.QuitarFormulario(strKey)
    End Sub
#End Region
End Class