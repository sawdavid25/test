﻿
Public Class clsDetalleTransferencia

    Public intEmpresa As Integer
    Public intCorrelativo As Integer
    Public Fecha As Date
    Public intCodigoInventario As Integer
    Public intCodigoProveedor As Integer
    Public strNumeroPartida As String
    Public intLugarFabricacion As Integer
    Public intProductoAno As Integer
    Public intProductoSem As Integer




End Class
