﻿Public Class clsAccesos

#Region "Miembros"
    Dim logInsertar As Boolean = False
    Dim logConsultar As Boolean = False
    Dim logEditar As Boolean = False
    Dim LogBorrar As Boolean = False
#End Region

#Region "Propiedades"

    Public ReadOnly Property Insertar As Boolean
        Get
            Return logInsertar
        End Get
    End Property

    Public ReadOnly Property Consultar As Boolean
        Get
            Return logConsultar
        End Get
    End Property

    Public ReadOnly Property Editar As Boolean
        Get
            Return logEditar
        End Get
    End Property

    Public ReadOnly Property Borrar As Boolean
        Get
            Return LogBorrar
        End Get
    End Property

#End Region

#Region "Funciones y Procedimientos"

    Public Sub New()
        logInsertar = False
        logConsultar = False
        logEditar = False
        LogBorrar = False
    End Sub

    Public Function Accesos(ByVal strKey As String) As Boolean
        Accesos = False
        Dim strSQL As String = STR_VACIO
        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader
        strSQL = "select seg_insertar, seg_editar, seg_borrar, seg_buscar  from Accesos a" & _
            " left join Programas p on a.seg_programa = p.pro_codigo " & _
            " where a.seg_sisemp = {empresa} and a.seg_usuario ='" & Sesion.Usuario & "' and p.pro_forma= '" & strKey & "'" & _
            " limit 1"
        strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
        Try
            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSQL, CON)
            REA = COM.ExecuteReader
            If REA.HasRows = True Then
                REA.Read()
                If REA.GetString("seg_insertar") = "SI" Then
                    logInsertar = True
                End If
                If REA.GetString("seg_buscar") = "SI" Then
                    logConsultar = True
                End If
                If REA.GetString("seg_editar") = "SI" Then
                    logEditar = True
                End If
                If REA.GetString("seg_borrar") = "SI" Then
                    LogBorrar = True
                End If
                Accesos = True
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Function

#End Region

End Class
