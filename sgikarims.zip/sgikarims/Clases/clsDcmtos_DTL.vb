Public Class clsDcmtos_DTL

#Region "Miembros"

    Public Enum TipoReset
        Full = 1
        Data = 2
    End Enum

    Private STR_CAMPOS As String = STR_VACIO
    Private m_int_DDoc_Sis_Emp As Integer
    Private m_dt_DDoc_Doc_Fec As MySqlDateTime
    Private m_int_DDoc_Doc_Cat As Integer
    Private m_int_DDoc_Doc_Ano As Integer
    Private m_int_DDoc_Doc_Num As Integer
    Private m_int_DDoc_Doc_Lin As Integer
    Private m_lng_DDoc_Prd_Cod As Long
    Private m_str_DDoc_Prd_PNr As String
    Private m_str_DDoc_Prd_Des As String
    Private m_int_DDoc_Prd_UM As Integer
    Private m_dec_DDoc_Prd_PUQ As Double
    Private m_dec_DDoc_Prd_DSP As Double
    Private m_dec_DDoc_Prd_DSQ As Double
    Private m_dec_DDoc_Prd_NET As Double
    Private m_dec_DDoc_Prd_QTY As Double
    Private m_int_DDoc_RF1_Num As Integer
    Private m_str_DDoc_RF1_Cod As String
    Private m_obj_DDoc_RF1_Txt As String
    Private m_dt_DDoc_RF1_Fec As MySqlDateTime
    Private m_dec_DDoc_RF1_Dbl As Double
    Private m_int_DDoc_RF2_Num As Integer
    Private m_str_DDoc_RF2_Cod As String
    Private m_obj_DDoc_RF2_Txt As String
    Private m_dt_DDoc_RF2_Fec As MySqlDateTime
    Private m_dec_DDoc_RF2_Dbl As Double
    Private m_int_DDoc_RF3_Num As Integer
    Private m_obj_DDoc_RF3_Txt As String
    Private m_dt_DDoc_RF3_Fec As MySqlDateTime
    Private m_dec_DDoc_RF3_Dbl As Double
    Private m_dec_DDoc_Prd_Fob As Double
    Private m_dec_DDoc_Prd_Cif As Double
    Private m_str_DDoc_Prd_Ref As String
    Private MENSAJE As String
    Private Cantidad_de_la_Clase As Integer = 0
    Private TRA As MySqlTransaction
    Private REA As MySqlDataReader
    Private CONstr As String
#End Region

#Region "Propiedades"

    Public Property DDOC_SIS_EMP() As Integer
        Get
            Return m_int_DDoc_Sis_Emp
        End Get
        Set(ByVal Value As Integer)
            m_int_DDoc_Sis_Emp = Value
        End Set
    End Property

    Public Property DDOC_DOC_CAT() As Integer
        Get
            Return m_int_DDoc_Doc_Cat
        End Get
        Set(ByVal Value As Integer)
            m_int_DDoc_Doc_Cat = Value
        End Set
    End Property

    Public Property DDOC_DOC_ANO() As Integer
        Get
            Return m_int_DDoc_Doc_Ano
        End Get
        Set(ByVal Value As Integer)
            m_int_DDoc_Doc_Ano = Value
        End Set
    End Property

    Public Property DDOC_DOC_NUM() As Integer
        Get
            Return m_int_DDoc_Doc_Num
        End Get
        Set(ByVal Value As Integer)
            m_int_DDoc_Doc_Num = Value
        End Set
    End Property

    Public Property DDOC_DOC_LIN() As Integer
        Get
            Return m_int_DDoc_Doc_Lin
        End Get
        Set(ByVal Value As Integer)
            m_int_DDoc_Doc_Lin = Value
        End Set
    End Property

    Public Property DDOC_DOC_FEC() As MySqlDateTime
        Get
            Return m_dt_DDoc_Doc_Fec
        End Get
        Set(value As MySqlDateTime)
            m_dt_DDoc_Doc_Fec = value
        End Set
    End Property

    Public WriteOnly Property DDoc_Doc_Fec_NET() As DateTime
        Set(value As DateTime)
            m_dt_DDoc_Doc_Fec = New MySqlDateTime(value.Year, value.Month, value.Day, value.Hour, value.Minute, value.Second)
        End Set
    End Property

    Public Property DDOC_PRD_COD() As Long
        Get
            Return m_lng_DDoc_Prd_Cod
        End Get
        Set(ByVal Value As Long)
            m_lng_DDoc_Prd_Cod = Value
        End Set
    End Property

    Public Property DDOC_PRD_PNR() As String
        Get
            Return m_str_DDoc_Prd_PNr.Trim()
        End Get
        Set(ByVal Value As String)
            m_str_DDoc_Prd_PNr = Value
        End Set
    End Property

    Public Property DDOC_PRD_DES() As String
        Get
            Return m_str_DDoc_Prd_Des.Trim()
        End Get
        Set(ByVal Value As String)
            m_str_DDoc_Prd_Des = Value
        End Set
    End Property

    Public Property DDOC_PRD_UM() As Integer
        Get
            Return m_int_DDoc_Prd_UM
        End Get
        Set(ByVal Value As Integer)
            m_int_DDoc_Prd_UM = Value
        End Set
    End Property

    Public Property DDOC_PRD_PUQ() As Double
        Get
            Return m_dec_DDoc_Prd_PUQ
        End Get
        Set(ByVal Value As Double)
            m_dec_DDoc_Prd_PUQ = Value
        End Set
    End Property

    Public Property DDOC_PRD_DSP() As Double
        Get
            Return m_dec_DDoc_Prd_DSP
        End Get
        Set(ByVal Value As Double)
            m_dec_DDoc_Prd_DSP = Value
        End Set
    End Property

    Public Property DDOC_PRD_DSQ() As Double
        Get
            Return m_dec_DDoc_Prd_DSQ
        End Get
        Set(ByVal Value As Double)
            m_dec_DDoc_Prd_DSQ = Value
        End Set
    End Property

    Public Property DDOC_PRD_NET() As Double
        Get
            Return m_dec_DDoc_Prd_NET
        End Get
        Set(ByVal Value As Double)
            m_dec_DDoc_Prd_NET = Value
        End Set
    End Property

    Public Property DDOC_PRD_QTY() As Double
        Get
            Return m_dec_DDoc_Prd_QTY
        End Get
        Set(ByVal Value As Double)
            m_dec_DDoc_Prd_QTY = Value
        End Set
    End Property

    Public Property DDOC_RF1_NUM() As Integer
        Get
            Return m_int_DDoc_RF1_Num
        End Get
        Set(ByVal Value As Integer)
            m_int_DDoc_RF1_Num = Value
        End Set
    End Property

    Public Property DDOC_RF1_COD() As String
        Get
            Return m_str_DDoc_RF1_Cod.Trim()
        End Get
        Set(ByVal Value As String)
            m_str_DDoc_RF1_Cod = Value
        End Set
    End Property

    Public Property DDOC_RF1_TXT() As String
        Get
            Return m_obj_DDoc_RF1_Txt
        End Get
        Set(ByVal Value As String)
            m_obj_DDoc_RF1_Txt = Value
        End Set
    End Property

    Public Property DDOC_RF1_FEC() As MySqlDateTime
        Get
            Return m_dt_DDoc_RF1_Fec
        End Get
        Set(ByVal Value As MySqlDateTime)
            m_dt_DDoc_RF1_Fec = Value
        End Set
    End Property

    Public WriteOnly Property DDoc_RF1_Fec_NET() As DateTime
        Set(ByVal Value As DateTime)
            m_dt_DDoc_RF1_Fec = New MySqlDateTime(Value.Year, Value.Month, Value.Day, Value.Hour, Value.Minute, Value.Second)
        End Set
    End Property

    Public Property DDOC_RF1_DBL() As Double
        Get
            Return m_dec_DDoc_RF1_Dbl
        End Get
        Set(ByVal Value As Double)
            m_dec_DDoc_RF1_Dbl = Value
        End Set
    End Property

    Public Property DDOC_RF2_NUM() As Integer
        Get
            Return m_int_DDoc_RF2_Num
        End Get
        Set(ByVal Value As Integer)
            m_int_DDoc_RF2_Num = Value
        End Set
    End Property

    Public Property DDOC_RF2_COD() As String
        Get
            Return m_str_DDoc_RF2_Cod.Trim()
        End Get
        Set(ByVal Value As String)
            m_str_DDoc_RF2_Cod = Value
        End Set
    End Property

    Public Property DDOC_RF2_TXT() As String
        Get
            Return m_obj_DDoc_RF2_Txt
        End Get
        Set(ByVal Value As String)
            m_obj_DDoc_RF2_Txt = Value
        End Set
    End Property

    Public Property DDOC_RF2_FEC() As MySqlDateTime
        Get
            Return m_dt_DDoc_RF2_Fec
        End Get
        Set(ByVal Value As MySqlDateTime)
            m_dt_DDoc_RF2_Fec = Value
        End Set
    End Property

    Public WriteOnly Property DDoc_RF2_Fec_NET() As DateTime
        Set(ByVal Value As DateTime)
            m_dt_DDoc_RF2_Fec = New MySqlDateTime(Value.Year, Value.Month, Value.Day, Value.Hour, Value.Minute, Value.Second)
        End Set
    End Property

    Public Property DDOC_RF2_DBL() As Double
        Get
            Return m_dec_DDoc_RF2_Dbl
        End Get
        Set(ByVal Value As Double)
            m_dec_DDoc_RF2_Dbl = Value
        End Set
    End Property

    Public Property DDOC_RF3_NUM() As Integer
        Get
            Return m_int_DDoc_RF3_Num
        End Get
        Set(ByVal Value As Integer)
            m_int_DDoc_RF3_Num = Value
        End Set
    End Property

    Public Property DDOC_RF3_TXT() As String
        Get
            Return m_obj_DDoc_RF3_Txt
        End Get
        Set(ByVal Value As String)
            m_obj_DDoc_RF3_Txt = Value
        End Set
    End Property

    Public Property DDOC_RF3_FEC() As MySqlDateTime
        Get
            Return m_dt_DDoc_RF3_Fec
        End Get
        Set(ByVal Value As MySqlDateTime)
            m_dt_DDoc_RF3_Fec = Value
        End Set
    End Property

    Public WriteOnly Property DDoc_RF3_Fec_NET() As DateTime
        Set(ByVal Value As DateTime)
            m_dt_DDoc_RF3_Fec = New MySqlDateTime(Value.Year, Value.Month, Value.Day, Value.Hour, Value.Minute, Value.Second)
        End Set
    End Property

    Public Property DDOC_RF3_DBL() As Double
        Get
            Return m_dec_DDoc_RF3_Dbl
        End Get
        Set(ByVal Value As Double)
            m_dec_DDoc_RF3_Dbl = Value
        End Set
    End Property

    Public Property DDOC_PRD_FOB() As Double
        Get
            Return m_dec_DDoc_Prd_Fob
        End Get
        Set(ByVal Value As Double)
            m_dec_DDoc_Prd_Fob = Value
        End Set
    End Property

    Public Property DDOC_PRD_CIF() As Double
        Get
            Return m_dec_DDoc_Prd_Cif
        End Get
        Set(ByVal Value As Double)
            m_dec_DDoc_Prd_Cif = Value
        End Set
    End Property

    Public Property DDOC_PRD_REF() As String
        Get
            Return m_str_DDoc_Prd_Ref.Trim()
        End Get
        Set(ByVal Value As String)
            m_str_DDoc_Prd_Ref = Value
        End Set
    End Property

    Public ReadOnly Property CantRecorSet() As Integer
        Get
            Return Cantidad_de_la_Clase
        End Get
    End Property

    Public Property CONEXION() As String
        Set(ByVal VALUE As String)
            CONstr = VALUE
            Try
                MENSAJE = ""
                If IsNothing(CON) = True Then
                    CON = New MySqlConnection
                End If
                If CON.State = ConnectionState.Open Then
                    CON.Close()
                End If
                CON.ConnectionString = CONstr
                CON.Open()
            Catch MyEX As MySqlException
                MENSAJE = "BiblioTABLAS - TDCMTOS_DTL - CONEXION MyError=" & MyEX.ToString
            Catch EX As Exception
                MENSAJE = "BiblioTABLAS - TDCMTOS_DTL - CONEXION Error=" & EX.ToString
            End Try
        End Set
        Get
            Return CONstr
        End Get
    End Property

    Public WriteOnly Property TRANSACCION() As MySqlTransaction
        Set(ByVal VALUE As MySqlTransaction)
            TRA = VALUE
        End Set
    End Property

    Public ReadOnly Property MERROR() As String
        Get
            Return MENSAJE
        End Get
    End Property

#End Region

#Region "Funciones Publicas"

    Public Sub New()
        DDOC_SIS_EMP = INT_CERO
        DDOC_DOC_CAT = INT_CERO
        DDOC_DOC_ANO = INT_CERO
        DDOC_DOC_NUM = INT_CERO
        DDOC_DOC_LIN = INT_CERO
        DDOC_PRD_COD = INT_CERO
        DDOC_PRD_PNR = STR_VACIO
        DDOC_PRD_DES = STR_VACIO
        DDOC_PRD_UM = INT_CERO
        DDOC_PRD_PUQ = INT_CERO
        DDOC_PRD_DSP = INT_CERO
        DDOC_PRD_DSQ = INT_CERO
        DDOC_PRD_NET = INT_CERO
        DDOC_PRD_QTY = INT_CERO
        DDOC_RF1_NUM = INT_CERO
        DDOC_RF1_COD = STR_VACIO
        DDOC_RF1_TXT = STR_VACIO
        DDOC_RF1_FEC = New MySqlDateTime(INT_CERO, INT_CERO, INT_CERO, INT_CERO, INT_CERO, INT_CERO)
        DDOC_RF1_DBL = INT_CERO
        DDOC_RF2_NUM = INT_CERO
        DDOC_RF2_COD = STR_VACIO
        DDOC_RF2_TXT = STR_VACIO
        DDOC_RF2_FEC = New MySqlDateTime(INT_CERO, INT_CERO, INT_CERO, INT_CERO, INT_CERO, INT_CERO)
        DDOC_RF2_DBL = INT_CERO
        DDOC_RF3_NUM = INT_CERO
        DDOC_RF3_TXT = STR_VACIO
        DDOC_RF3_FEC = New MySqlDateTime(INT_CERO, INT_CERO, INT_CERO, INT_CERO, INT_CERO, INT_CERO)
        DDOC_RF3_DBL = INT_CERO
        DDOC_PRD_FOB = INT_CERO
        DDOC_PRD_CIF = INT_CERO
        DDOC_PRD_REF = STR_VACIO
    End Sub

    Public Sub Reset(Optional ByVal Tipo As TipoReset = TipoReset.Data)
        Try
            INIT_LLAVE()
            INIT()
            If Tipo = clsDcmtos_DTL.TipoReset.Full Then
                Dispose()
            End If
        Catch Ex As Exception
            MENSAJE = "BiblioTABLAS - TDCMTOS_DTL - RESET No se podo hacer el Reset de la Clase" & Ex.ToString
        End Try
    End Sub

    Public Sub Dispose()
        Try
            If IsNothing(REA) = False Then
                REA.Close()
            End If
            If IsNothing(CON) = False Then
                If CON.State = ConnectionState.Open Then
                    CON.Close()
                End If
            End If
            CON = Nothing
            REA = Nothing
        Catch EX As Exception
        End Try
    End Sub

    Private Sub INIT()
        DDOC_PRD_COD = INT_CERO
        DDOC_PRD_PNR = STR_VACIO
        DDOC_PRD_DES = STR_VACIO
        DDOC_PRD_UM = INT_CERO
        DDOC_PRD_PUQ = INT_CERO
        DDOC_PRD_DSP = INT_CERO
        DDOC_PRD_DSQ = INT_CERO
        DDOC_PRD_NET = INT_CERO
        DDOC_PRD_QTY = INT_CERO
        DDOC_RF1_NUM = INT_CERO
        DDOC_RF1_COD = STR_VACIO
        DDOC_RF1_TXT = STR_VACIO
        DDOC_RF1_FEC = New MySqlDateTime(INT_CERO, INT_CERO, INT_CERO, INT_CERO, INT_CERO, INT_CERO)
        DDOC_RF1_DBL = INT_CERO
        DDOC_RF2_NUM = INT_CERO
        DDOC_RF2_COD = STR_VACIO
        DDOC_RF2_TXT = STR_VACIO
        DDOC_RF2_FEC = New MySqlDateTime(INT_CERO, INT_CERO, INT_CERO, INT_CERO, INT_CERO, INT_CERO)
        DDOC_RF2_DBL = INT_CERO
        DDOC_RF3_NUM = INT_CERO
        DDOC_RF3_TXT = STR_VACIO
        DDOC_RF3_FEC = New MySqlDateTime(INT_CERO, INT_CERO, INT_CERO, INT_CERO, INT_CERO, INT_CERO)
        DDOC_RF3_DBL = INT_CERO
        DDOC_PRD_FOB = INT_CERO
        DDOC_PRD_CIF = INT_CERO
        DDOC_PRD_REF = STR_VACIO
        Cantidad_de_la_Clase = INT_CERO
    End Sub

    Private Sub INIT_LLAVE()
        DDOC_SIS_EMP = 0
        DDOC_DOC_CAT = 0
        DDOC_DOC_ANO = 0
        DDOC_DOC_NUM = 0
        DDOC_DOC_LIN = 0
    End Sub

    Public Function SiguienteRegistro() As Boolean

        SiguienteRegistro = False
        Dim arrayCampos() As String
        INIT()
        INIT_LLAVE()
        If IsNothing(REA) = True Then
            MENSAJE = "BiblioTABLAS - TDCMTOS_DTL - PMOVE_NEXT Conexi�n no definida"
            Exit Function
        End If
        Try
            If REA.Read = True Then
                arrayCampos = STR_CAMPOS.Split(",".ToCharArray)
                For i As Integer = 0 To arrayCampos.Length - 1
                    Select Case Trim(arrayCampos(i))
                        Case ("DDoc_Sis_Emp")
                            If REA.IsDBNull(REA.GetOrdinal("DDoc_Sis_Emp")) = False Then
                                m_int_DDoc_Sis_Emp = REA.GetInt32("DDoc_Sis_Emp")
                            Else
                                m_int_DDoc_Sis_Emp = NO_FILA
                            End If
                        Case ("DDoc_Doc_Cat")
                            If REA.IsDBNull(REA.GetOrdinal("DDoc_Doc_Cat")) = False Then
                                m_int_DDoc_Doc_Cat = REA.GetInt32("DDoc_Doc_Cat")
                            Else
                                m_int_DDoc_Doc_Cat = NO_FILA
                            End If
                        Case ("DDoc_Doc_Ano")
                            If REA.IsDBNull(REA.GetOrdinal("DDoc_Doc_Ano")) = False Then
                                m_int_DDoc_Doc_Ano = REA.GetInt32("DDoc_Doc_Ano")
                            Else
                                m_int_DDoc_Doc_Ano = NO_FILA
                            End If
                        Case ("DDoc_Doc_Num")
                            If REA.IsDBNull(REA.GetOrdinal("DDoc_Doc_Num")) = False Then
                                m_int_DDoc_Doc_Num = REA.GetInt32("DDoc_Doc_Num")
                            Else
                                m_int_DDoc_Doc_Num = NO_FILA
                            End If
                        Case ("DDoc_Doc_Lin")
                            If REA.IsDBNull(REA.GetOrdinal("DDoc_Doc_Lin")) = False Then
                                m_int_DDoc_Doc_Lin = REA.GetInt32("DDoc_Doc_Lin")
                            Else
                                m_int_DDoc_Doc_Lin = NO_FILA
                            End If
                        Case ("DDoc_Prd_Cod")
                            If REA.IsDBNull(REA.GetOrdinal("DDoc_Prd_Cod")) = False Then
                                m_lng_DDoc_Prd_Cod = REA.GetString("DDoc_Prd_Cod")
                            End If
                        Case ("DDoc_Prd_PNr")
                            If REA.IsDBNull(REA.GetOrdinal("DDoc_Prd_PNr")) = False Then
                                m_str_DDoc_Prd_PNr = REA.GetString("DDoc_Prd_PNr")
                            Else
                                m_str_DDoc_Prd_PNr = "NULL"
                            End If
                        Case ("DDoc_Prd_Des")
                            If REA.IsDBNull(REA.GetOrdinal("DDoc_Prd_Des")) = False Then
                                m_str_DDoc_Prd_Des = REA.GetString("DDoc_Prd_Des")
                            Else
                                m_str_DDoc_Prd_Des = "NULL"
                            End If
                        Case ("DDoc_Prd_UM")
                            If REA.IsDBNull(REA.GetOrdinal("DDoc_Prd_UM")) = False Then
                                m_int_DDoc_Prd_UM = REA.GetInt32("DDoc_Prd_UM")
                            Else
                                m_int_DDoc_Prd_UM = NO_FILA
                            End If
                        Case ("DDoc_Prd_PUQ")
                            If REA.IsDBNull(REA.GetOrdinal("DDoc_Prd_PUQ")) = False Then
                                m_dec_DDoc_Prd_PUQ = REA.GetDecimal("DDoc_Prd_PUQ")
                            End If
                        Case ("DDoc_Prd_DSP")
                            If REA.IsDBNull(REA.GetOrdinal("DDoc_Prd_DSP")) = False Then
                                m_dec_DDoc_Prd_DSP = REA.GetDecimal("DDoc_Prd_DSP")
                            End If
                        Case ("DDoc_Prd_DSQ")
                            If REA.IsDBNull(REA.GetOrdinal("DDoc_Prd_DSQ")) = False Then
                                m_dec_DDoc_Prd_DSQ = REA.GetDecimal("DDoc_Prd_DSQ")
                            End If
                        Case ("DDoc_Prd_NET")
                            If REA.IsDBNull(REA.GetOrdinal("DDoc_Prd_NET")) = False Then
                                m_dec_DDoc_Prd_NET = REA.GetDecimal("DDoc_Prd_NET")
                            End If
                        Case ("DDoc_Prd_QTY")
                            If REA.IsDBNull(REA.GetOrdinal("DDoc_Prd_QTY")) = False Then
                                m_dec_DDoc_Prd_QTY = REA.GetDecimal("DDoc_Prd_QTY")
                            End If
                        Case ("DDoc_RF1_Num")
                            If REA.IsDBNull(REA.GetOrdinal("DDoc_RF1_Num")) = False Then
                                m_int_DDoc_RF1_Num = REA.GetInt32("DDoc_RF1_Num")
                            Else
                                m_int_DDoc_RF1_Num = NO_FILA
                            End If
                        Case ("DDoc_RF1_Cod")
                            If REA.IsDBNull(REA.GetOrdinal("DDoc_RF1_Cod")) = False Then
                                m_str_DDoc_RF1_Cod = REA.GetString("DDoc_RF1_Cod")
                            Else
                                m_str_DDoc_RF1_Cod = "NULL"
                            End If
                        Case ("DDoc_RF1_Txt")
                            If REA.IsDBNull(REA.GetOrdinal("DDoc_RF1_Txt")) = False Then
                                m_obj_DDoc_RF1_Txt = REA.GetString("DDoc_RF1_Txt")
                            End If
                        Case ("DDoc_RF1_Fec")
                            If REA.IsDBNull(REA.GetOrdinal("DDoc_RF1_Fec")) = False Then
                                m_dt_DDoc_RF1_Fec = REA.GetMySqlDateTime("DDoc_RF1_Fec")
                            End If
                        Case ("DDoc_RF1_Dbl")
                            If REA.IsDBNull(REA.GetOrdinal("DDoc_RF1_Dbl")) = False Then
                                m_dec_DDoc_RF1_Dbl = REA.GetDecimal("DDoc_RF1_Dbl")
                            End If
                        Case ("DDoc_RF2_Num")
                            If REA.IsDBNull(REA.GetOrdinal("DDoc_RF2_Num")) = False Then
                                m_int_DDoc_RF2_Num = REA.GetInt32("DDoc_RF2_Num")
                            Else
                                m_int_DDoc_RF2_Num = NO_FILA
                            End If
                        Case ("DDoc_RF2_Cod")
                            If REA.IsDBNull(REA.GetOrdinal("DDoc_RF2_Cod")) = False Then
                                m_str_DDoc_RF2_Cod = REA.GetString("DDoc_RF2_Cod")
                            Else
                                m_str_DDoc_RF2_Cod = "NULL"
                            End If
                        Case ("DDoc_RF2_Txt")
                            If REA.IsDBNull(REA.GetOrdinal("DDoc_RF2_Txt")) = False Then
                                m_obj_DDoc_RF2_Txt = REA.GetString("DDoc_RF2_Txt")
                            End If
                        Case ("DDoc_RF2_Fec")
                            If REA.IsDBNull(REA.GetOrdinal("DDoc_RF2_Fec")) = False Then
                                m_dt_DDoc_RF2_Fec = REA.GetMySqlDateTime("DDoc_RF2_Fec")
                            End If
                        Case ("DDoc_RF2_Dbl")
                            If REA.IsDBNull(REA.GetOrdinal("DDoc_RF2_Dbl")) = False Then
                                m_dec_DDoc_RF2_Dbl = REA.GetDecimal("DDoc_RF2_Dbl")
                            End If
                        Case ("DDoc_RF3_Num")
                            If REA.IsDBNull(REA.GetOrdinal("DDoc_RF3_Num")) = False Then
                                m_int_DDoc_RF3_Num = REA.GetInt32("DDoc_RF3_Num")
                            Else
                                m_int_DDoc_RF3_Num = NO_FILA
                            End If
                        Case ("DDoc_RF3_Txt")
                            If REA.IsDBNull(REA.GetOrdinal("DDoc_RF3_Txt")) = False Then
                                m_obj_DDoc_RF3_Txt = REA.GetString("DDoc_RF3_Txt")
                            End If
                        Case ("DDoc_RF3_Fec")
                            If REA.IsDBNull(REA.GetOrdinal("DDoc_RF3_Fec")) = False Then
                                m_dt_DDoc_RF3_Fec = REA.GetMySqlDateTime("DDoc_RF3_Fec")
                            End If
                        Case ("DDoc_RF3_Dbl")
                            If REA.IsDBNull(REA.GetOrdinal("DDoc_RF3_Dbl")) = False Then
                                m_dec_DDoc_RF3_Dbl = REA.GetDecimal("DDoc_RF3_Dbl")
                            End If
                        Case ("DDoc_Prd_Fob")
                            If REA.IsDBNull(REA.GetOrdinal("DDoc_Prd_Fob")) = False Then
                                m_dec_DDoc_Prd_Fob = REA.GetDecimal("DDoc_Prd_Fob")
                            End If
                        Case ("DDoc_Prd_Cif")
                            If REA.IsDBNull(REA.GetOrdinal("DDoc_Prd_Cif")) = False Then
                                m_dec_DDoc_Prd_Cif = REA.GetDecimal("DDoc_Prd_Cif")
                            End If
                        Case ("DDoc_Prd_Ref")
                            If REA.IsDBNull(REA.GetOrdinal("DDoc_Prd_Ref")) = False Then
                                m_str_DDoc_Prd_Ref = REA.GetString("DDoc_Prd_Ref")
                            Else
                                m_str_DDoc_Prd_Ref = "NULL"
                            End If
                    End Select
                Next
                SiguienteRegistro = True
            Else
                REA.Close()
                REA = Nothing
            End If
        Catch MYEX As MySqlException
            MENSAJE = "BiblioTABLAS - TDCMTOS_DTL - PMOVE_NEXT Error=" & MYEX.ToString
        Catch EX As Exception
            MENSAJE = "BiblioTABLAS - TDCMTOS_DTL - PMOVE_NEXT Error=" & EX.ToString
        End Try
    End Function

    Public Function SeleccionarLista(Optional ByVal CONDICION As String = "", Optional ByVal CAMPOS As String = STR_ASTERISCO, Optional ByVal LIMITE As Integer = INT_CERO, Optional ByVal ORDENAMIENTO As String = STR_VACIO) As Boolean
        Dim COM As MySqlCommand
        Dim SQL As String
        Dim SQL1 As String

        SeleccionarLista = False
        If IsNothing(REA) = False Then
            REA.Close()
            REA = Nothing
        End If
        If IsNothing(CON) = True Then
            MENSAJE = "BiblioTABLAS - TDCMTOS_DTL - PSELECT_RECORDSET Conexi�n no definida"
            Exit Function
        End If
        If CON.State = ConnectionState.Closed Or CON.State = ConnectionState.Broken Then
            If CON.ConnectionString.Length <> 0 Then
                Try
                    CON.Open()
                Catch MYEX As MySqlException
                    MENSAJE = "BiblioTABLAS - TTDCMTOS_DTL - PSELECT_RECORDSET Error#=" & MYEX.Number & " " & MYEX.ToString
                    Exit Function
                Catch EX As Exception
                    MENSAJE = "BiblioTABLAS - TTDCMTOS_DTL - PSELECT_RECORDSET Error=" & EX.ToString
                    Exit Function
                End Try
            Else
                MENSAJE = "BiblioTABLAS - TTDCMTOS_DTL - PSELECT_RECORDSET String de Conexi�n no definido"
                Exit Function
            End If
        End If
        If CAMPOS = STR_ASTERISCO Then
            CAMPOS = "DDoc_Sis_Emp,DDoc_Doc_Cat,DDoc_Doc_Ano,DDoc_Doc_Num,DDoc_Doc_Lin,DDoc_Prd_Cod," & _
                "DDoc_Prd_PNr,DDoc_Prd_Des,DDoc_Prd_UM,DDoc_Prd_PUQ,DDoc_Prd_DSP,DDoc_Prd_DSQ, " & _
                "DDoc_Prd_NET,DDoc_Prd_QTY,DDoc_RF1_Num,DDoc_RF1_Cod,DDoc_RF1_Txt,DDoc_RF1_Fec, " & _
                "DDoc_RF1_Dbl,DDoc_RF2_Num,DDoc_RF2_Cod,DDoc_RF2_Txt,DDoc_RF2_Fec,DDoc_RF2_Dbl," & _
                "DDoc_RF3_Num,DDoc_RF3_Txt,DDoc_RF3_Fec,DDoc_RF3_Dbl,DDoc_Prd_Fob,DDoc_Prd_Cif,DDoc_Prd_Ref"
        End If
        COM = Nothing
        SQL = "Select " & CAMPOS & " from Dcmtos_DTL"
        If CONDICION.Length <> 0 Then
            SQL &= " Where " & CONDICION
        End If
        If ORDENAMIENTO.Length <> 0 Then
            SQL &= " Order By " & ORDENAMIENTO
        End If
        SQL1 = "Select Count(*) as Cuenta from Dcmtos_DTL"
        If CONDICION.Length <> 0 Then
            SQL1 &= " Where " & CONDICION
        End If
        If LIMITE > 0 Then
            SQL &= " LIMIT " & LIMITE
            SQL1 &= " LIMIT " & LIMITE
        End If
        STR_CAMPOS = CAMPOS
        Try
            INIT()
            INIT_LLAVE()

            COM = New MySqlCommand(SQL1, CON)
            Cantidad_de_la_Clase = CInt(COM.ExecuteScalar())
            COM.Dispose()
            COM = Nothing

            COM = New MySqlCommand(SQL, CON)
            COM.CommandType = CommandType.Text
            REA = COM.ExecuteReader
            SeleccionarLista = True
        Catch MYEX As MySqlException
            MENSAJE = "BiblioTABLAS - TDCMTOS_DTL - PSELECT_RECORDSET MyError#=" & MYEX.Number & " MyError=" & MYEX.ToString
        Catch EX As Exception
            MENSAJE = "BiblioTABLAS - TDCMTOS_DTL - PSELECT_RECORDSET Error=" & EX.ToString
        Finally
            If IsNothing(COM) = False Then
                COM.Dispose()
                COM = Nothing
            End If
        End Try
    End Function

    Public Function Seleccionar(ByVal CONDICION As String, Optional ByVal CAMPOS As String = STR_ASTERISCO) As Boolean

        Dim READER As MySqlDataReader
        Dim COM As MySqlCommand
        Dim SQL As String
        Dim arrayCampos() As String

        MENSAJE = ""
        Seleccionar = False
        If IsNothing(CON) = True Then
            MENSAJE = "BiblioTABLAS - TDCMTOS_DTL - PSELECT_CONDICION Conexi�n no definida"
            Exit Function
        End If
        If CON.State = ConnectionState.Closed Or CON.State = ConnectionState.Broken Then
            If CON.ConnectionString.Length <> 0 Then
                Try
                    CON.Open()
                Catch MYEX As MySqlException
                    MENSAJE = "BiblioTABLAS - TTDCMTOS_DTL - PSELECT_CONDICION Error#=" & MYEX.Number & " " & MYEX.ToString
                    Exit Function
                Catch EX As Exception
                    MENSAJE = "BiblioTABLAS - TTDCMTOS_DTL - PSELECT_CONDICION Error=" & EX.ToString
                    Exit Function
                End Try
            Else
                MENSAJE = "BiblioTABLAS - TTDCMTOS_DTL - PSELECT_CONDICION String de Conexi�n no definido"
                Exit Function
            End If
        End If
        If CAMPOS = STR_ASTERISCO Then
            CAMPOS = "DDoc_Sis_Emp,DDoc_Doc_Cat,DDoc_Doc_Ano,DDoc_Doc_Num,DDoc_Doc_Lin,DDoc_Prd_Cod," & _
                "DDoc_Prd_PNr,DDoc_Prd_Des,DDoc_Prd_UM,DDoc_Prd_PUQ,DDoc_Prd_DSP,DDoc_Prd_DSQ," & _
                "DDoc_Prd_NET,DDoc_Prd_QTY,DDoc_RF1_Num,DDoc_RF1_Cod,DDoc_RF1_Txt,DDoc_RF1_Fec," & _
                "DDoc_RF1_Dbl,DDoc_RF2_Num,DDoc_RF2_Cod,DDoc_RF2_Txt,DDoc_RF2_Fec,DDoc_RF2_Dbl," & _
                "DDoc_RF3_Num,DDoc_RF3_Txt,DDoc_RF3_Fec,DDoc_RF3_Dbl,DDoc_Prd_Fob,DDoc_Prd_Cif,DDoc_Prd_Ref"
        End If
        SQL = "SELECT " & CAMPOS & " FROM Dcmtos_DTL WHERE " & CONDICION
        READER = Nothing
        COM = Nothing
        Try
            INIT()
            COM = New MySqlCommand(SQL, CON)
            COM.CommandType = CommandType.Text
            READER = COM.ExecuteReader(CommandBehavior.SingleRow)
            READER.Read()
            If READER.HasRows = True Then
                arrayCampos = CAMPOS.Split(",".ToCharArray)
                For i As Integer = 0 To arrayCampos.Length - 1
                    Select Case Trim(arrayCampos(i))
                        Case ("DDoc_Sis_Emp")
                            If READER.IsDBNull(READER.GetOrdinal("DDoc_Sis_Emp")) = False Then
                                m_int_DDoc_Sis_Emp = READER.GetInt32("DDoc_Sis_Emp")
                            Else
                                m_int_DDoc_Sis_Emp = -1
                            End If
                        Case ("DDoc_Doc_Cat")
                            If READER.IsDBNull(READER.GetOrdinal("DDoc_Doc_Cat")) = False Then
                                m_int_DDoc_Doc_Cat = READER.GetInt32("DDoc_Doc_Cat")
                            Else
                                m_int_DDoc_Doc_Cat = -1
                            End If
                        Case ("DDoc_Doc_Ano")
                            If READER.IsDBNull(READER.GetOrdinal("DDoc_Doc_Ano")) = False Then
                                m_int_DDoc_Doc_Ano = READER.GetInt32("DDoc_Doc_Ano")
                            Else
                                m_int_DDoc_Doc_Ano = -1
                            End If
                        Case ("DDoc_Doc_Num")
                            If READER.IsDBNull(READER.GetOrdinal("DDoc_Doc_Num")) = False Then
                                m_int_DDoc_Doc_Num = READER.GetInt32("DDoc_Doc_Num")
                            Else
                                m_int_DDoc_Doc_Num = -1
                            End If
                        Case ("DDoc_Doc_Lin")
                            If READER.IsDBNull(READER.GetOrdinal("DDoc_Doc_Lin")) = False Then
                                m_int_DDoc_Doc_Lin = READER.GetInt32("DDoc_Doc_Lin")
                            Else
                                m_int_DDoc_Doc_Lin = -1
                            End If
                        Case ("DDoc_Prd_Cod")
                            If READER.IsDBNull(READER.GetOrdinal("DDoc_Prd_Cod")) = False Then
                                m_lng_DDoc_Prd_Cod = READER.GetString("DDoc_Prd_Cod")
                            End If
                        Case ("DDoc_Prd_PNr")
                            If READER.IsDBNull(READER.GetOrdinal("DDoc_Prd_PNr")) = False Then
                                m_str_DDoc_Prd_PNr = READER.GetString("DDoc_Prd_PNr")
                            Else
                                m_str_DDoc_Prd_PNr = "NULL"
                            End If
                        Case ("DDoc_Prd_Des")
                            If READER.IsDBNull(READER.GetOrdinal("DDoc_Prd_Des")) = False Then
                                m_str_DDoc_Prd_Des = READER.GetString("DDoc_Prd_Des")
                            Else
                                m_str_DDoc_Prd_Des = "NULL"
                            End If
                        Case ("DDoc_Prd_UM")
                            If READER.IsDBNull(READER.GetOrdinal("DDoc_Prd_UM")) = False Then
                                m_int_DDoc_Prd_UM = READER.GetInt32("DDoc_Prd_UM")
                            Else
                                m_int_DDoc_Prd_UM = -1
                            End If
                        Case ("DDoc_Prd_PUQ")
                            If READER.IsDBNull(READER.GetOrdinal("DDoc_Prd_PUQ")) = False Then
                                m_dec_DDoc_Prd_PUQ = READER.GetDecimal("DDoc_Prd_PUQ")
                            End If
                        Case ("DDoc_Prd_DSP")
                            If READER.IsDBNull(READER.GetOrdinal("DDoc_Prd_DSP")) = False Then
                                m_dec_DDoc_Prd_DSP = READER.GetDecimal("DDoc_Prd_DSP")
                            End If
                        Case ("DDoc_Prd_DSQ")
                            If READER.IsDBNull(READER.GetOrdinal("DDoc_Prd_DSQ")) = False Then
                                m_dec_DDoc_Prd_DSQ = READER.GetDecimal("DDoc_Prd_DSQ")
                            End If
                        Case ("DDoc_Prd_NET")
                            If READER.IsDBNull(READER.GetOrdinal("DDoc_Prd_NET")) = False Then
                                m_dec_DDoc_Prd_NET = READER.GetDecimal("DDoc_Prd_NET")
                            End If
                        Case ("DDoc_Prd_QTY")
                            If READER.IsDBNull(READER.GetOrdinal("DDoc_Prd_QTY")) = False Then
                                m_dec_DDoc_Prd_QTY = READER.GetDecimal("DDoc_Prd_QTY")
                            End If
                        Case ("DDoc_RF1_Num")
                            If READER.IsDBNull(READER.GetOrdinal("DDoc_RF1_Num")) = False Then
                                m_int_DDoc_RF1_Num = READER.GetInt32("DDoc_RF1_Num")
                            Else
                                m_int_DDoc_RF1_Num = -1
                            End If
                        Case ("DDoc_RF1_Cod")
                            If READER.IsDBNull(READER.GetOrdinal("DDoc_RF1_Cod")) = False Then
                                m_str_DDoc_RF1_Cod = READER.GetString("DDoc_RF1_Cod")
                            Else
                                m_str_DDoc_RF1_Cod = "NULL"
                            End If
                        Case ("DDoc_RF1_Txt")
                            If READER.IsDBNull(READER.GetOrdinal("DDoc_RF1_Txt")) = False Then
                                m_obj_DDoc_RF1_Txt = READER.GetString("DDoc_RF1_Txt")
                            End If
                        Case ("DDoc_RF1_Fec")
                            If READER.IsDBNull(READER.GetOrdinal("DDoc_RF1_Fec")) = False Then
                                m_dt_DDoc_RF1_Fec = READER.GetMySqlDateTime("DDoc_RF1_Fec")
                            End If
                        Case ("DDoc_RF1_Dbl")
                            If READER.IsDBNull(READER.GetOrdinal("DDoc_RF1_Dbl")) = False Then
                                m_dec_DDoc_RF1_Dbl = READER.GetDecimal("DDoc_RF1_Dbl")
                            End If
                        Case ("DDoc_RF2_Num")
                            If READER.IsDBNull(READER.GetOrdinal("DDoc_RF2_Num")) = False Then
                                m_int_DDoc_RF2_Num = READER.GetInt32("DDoc_RF2_Num")
                            Else
                                m_int_DDoc_RF2_Num = -1
                            End If
                        Case ("DDoc_RF2_Cod")
                            If READER.IsDBNull(READER.GetOrdinal("DDoc_RF2_Cod")) = False Then
                                m_str_DDoc_RF2_Cod = READER.GetString("DDoc_RF2_Cod")
                            Else
                                m_str_DDoc_RF2_Cod = "NULL"
                            End If
                        Case ("DDoc_RF2_Txt")
                            If READER.IsDBNull(READER.GetOrdinal("DDoc_RF2_Txt")) = False Then
                                m_obj_DDoc_RF2_Txt = READER.GetString("DDoc_RF2_Txt")
                            End If
                        Case ("DDoc_RF2_Fec")
                            If READER.IsDBNull(READER.GetOrdinal("DDoc_RF2_Fec")) = False Then
                                m_dt_DDoc_RF2_Fec = READER.GetMySqlDateTime("DDoc_RF2_Fec")
                            End If
                        Case ("DDoc_RF2_Dbl")
                            If READER.IsDBNull(READER.GetOrdinal("DDoc_RF2_Dbl")) = False Then
                                m_dec_DDoc_RF2_Dbl = READER.GetDecimal("DDoc_RF2_Dbl")
                            End If
                        Case ("DDoc_RF3_Num")
                            If READER.IsDBNull(READER.GetOrdinal("DDoc_RF3_Num")) = False Then
                                m_int_DDoc_RF3_Num = READER.GetInt32("DDoc_RF3_Num")
                            Else
                                m_int_DDoc_RF3_Num = -1
                            End If
                        Case ("DDoc_RF3_Txt")
                            If READER.IsDBNull(READER.GetOrdinal("DDoc_RF3_Txt")) = False Then
                                m_obj_DDoc_RF3_Txt = READER.GetString("DDoc_RF3_Txt")
                            End If
                        Case ("DDoc_RF3_Fec")
                            If READER.IsDBNull(READER.GetOrdinal("DDoc_RF3_Fec")) = False Then
                                m_dt_DDoc_RF3_Fec = READER.GetMySqlDateTime("DDoc_RF3_Fec")
                            End If
                        Case ("DDoc_RF3_Dbl")
                            If READER.IsDBNull(READER.GetOrdinal("DDoc_RF3_Dbl")) = False Then
                                m_dec_DDoc_RF3_Dbl = READER.GetDecimal("DDoc_RF3_Dbl")
                            End If
                        Case ("DDoc_Prd_Fob")
                            If READER.IsDBNull(READER.GetOrdinal("DDoc_Prd_Fob")) = False Then
                                m_dec_DDoc_Prd_Fob = READER.GetDecimal("DDoc_Prd_Fob")
                            End If
                        Case ("DDoc_Prd_Cif")
                            If READER.IsDBNull(READER.GetOrdinal("DDoc_Prd_Cif")) = False Then
                                m_dec_DDoc_Prd_Cif = READER.GetDecimal("DDoc_Prd_Cif")
                            End If
                        Case ("DDoc_Prd_Ref")
                            If READER.IsDBNull(READER.GetOrdinal("DDoc_Prd_Ref")) = False Then
                                m_str_DDoc_Prd_Ref = READER.GetString("DDoc_Prd_Ref")
                            Else
                                m_str_DDoc_Prd_Ref = "NULL"
                            End If
                    End Select
                Next
                Seleccionar = True
            Else
                MENSAJE = ""
                Exit Function
            End If
            READER.Close()
            COM.Dispose()
            READER = Nothing
            COM = Nothing
            Seleccionar = True
        Catch MYEX As MySqlException
            MENSAJE = "BiblioTABLAS - TDCMTOS_DTL - PSELECT_CONDICION MyError#=" & MYEX.Number & " MyError=" & MYEX.ToString
        Catch EX As Exception
            MENSAJE = "BiblioTABLAS - TDCMTOS_DTL - PSELECT_CONDICION Error=" & EX.ToString
        Finally
            If IsNothing(READER) = False Then
                READER.Close()
                READER = Nothing
            End If
            If IsNothing(COM) = False Then
                COM.Dispose()
                COM = Nothing
            End If
        End Try
    End Function

    Public Function Guardar() As Boolean
        Dim COM As MySqlCommand
        Dim SQL As String

        MENSAJE = ""
        Guardar = False
        If IsNothing(CON) = True Then
            MENSAJE = "BiblioTABLAS - TDCMTOS_DTL - PINSERT Conexi�n no definida"
            Exit Function
        End If
        If CON.State = ConnectionState.Closed Or CON.State = ConnectionState.Broken Then
            If CON.ConnectionString.Length <> 0 Then
                Try
                    CON.Open()
                Catch MYEX As MySqlException
                    MENSAJE = "BiblioTABLAS - TTDCMTOS_DTL - PINSERT Error#=" & MYEX.Number & " " & MYEX.ToString
                    Exit Function
                Catch EX As Exception
                    MENSAJE = "BiblioTABLAS - TTDCMTOS_DTL - PINSERT Error=" & EX.ToString
                    Exit Function
                End Try
            Else
                MENSAJE = "BiblioTABLAS - TTDCMTOS_DTL - PINSERT String de Conexi�n no definido"
                Exit Function
            End If
        End If

        COM = Nothing
        Try
            SQL = "INSERT INTO Dcmtos_DTL (DDoc_Sis_Emp,DDoc_Doc_Cat,DDoc_Doc_Ano,DDoc_Doc_Num," & _
                "DDoc_Doc_Lin,DDoc_Prd_Cod,DDoc_Prd_PNr,DDoc_Prd_Des,DDoc_Prd_UM,DDoc_Prd_PUQ," & _
                "DDoc_Prd_DSP,DDoc_Prd_DSQ,DDoc_Prd_NET,DDoc_Prd_QTY,DDoc_RF1_Num,DDoc_RF1_Cod," & _
                "DDoc_RF1_Txt,DDoc_RF1_Fec,DDoc_RF1_Dbl,DDoc_RF2_Num,DDoc_RF2_Cod,DDoc_RF2_Txt," & _
                "DDoc_RF2_Fec,DDoc_RF2_Dbl,DDoc_RF3_Num,DDoc_RF3_Txt,DDoc_RF3_Fec,DDoc_RF3_Dbl," & _
                "DDoc_Prd_Fob,DDoc_Prd_Cif,DDoc_Prd_Ref) " & _
                "VALUES(?P1,?P2," & MYSQL_A�O & ",?P4,?P5,?P6,?P7,?P8,?P9,?P10,?P11,?P12,?P13,?P14,?P15," & _
                "?P16,?P17,?P18,?P19,?P20,?P21,?P22,?P23,?P24,?P25,?P26,?P27,?P28,?P29,?P30,?P31)"
            If IsNothing(TRA) = False Then
                COM = New MySqlCommand(SQL, TRA.Connection, TRA)
            Else
                COM = New MySqlCommand(SQL, CON)
            End If
            COM.CommandType = CommandType.Text
            If m_int_DDoc_Sis_Emp = -1 Then
                COM.Parameters.AddWithValue("?P1", DBNull.Value)
            Else
                COM.Parameters.AddWithValue("?P1", m_int_DDoc_Sis_Emp)
            End If
            If m_int_DDoc_Doc_Cat = -1 Then
                COM.Parameters.AddWithValue("?P2", DBNull.Value)
            Else
                COM.Parameters.AddWithValue("?P2", m_int_DDoc_Doc_Cat)
            End If
            'COM.Parameters.AddWithValue("?P3", MYSQL_A�O)
            If m_int_DDoc_Doc_Num = -1 Then
                COM.Parameters.AddWithValue("?P4", DBNull.Value)
            Else
                COM.Parameters.AddWithValue("?P4", m_int_DDoc_Doc_Num)
            End If
            If m_int_DDoc_Doc_Lin = -1 Then
                COM.Parameters.AddWithValue("?P5", DBNull.Value)
            Else
                COM.Parameters.AddWithValue("?P5", m_int_DDoc_Doc_Lin)
            End If
            COM.Parameters.AddWithValue("?P6", m_lng_DDoc_Prd_Cod)
            If m_str_DDoc_Prd_PNr.ToUpper = "NULL" Then
                COM.Parameters.AddWithValue("?P7", DBNull.Value)
            Else
                COM.Parameters.AddWithValue("?P7", m_str_DDoc_Prd_PNr)
            End If
            If m_str_DDoc_Prd_Des.ToUpper = "NULL" Then
                COM.Parameters.AddWithValue("?P8", DBNull.Value)
            Else
                COM.Parameters.AddWithValue("?P8", m_str_DDoc_Prd_Des)
            End If
            If m_int_DDoc_Prd_UM = -1 Then
                COM.Parameters.AddWithValue("?P9", DBNull.Value)
            Else
                COM.Parameters.AddWithValue("?P9", m_int_DDoc_Prd_UM)
            End If
            COM.Parameters.AddWithValue("?P10", m_dec_DDoc_Prd_PUQ)
            COM.Parameters.AddWithValue("?P11", m_dec_DDoc_Prd_DSP)
            COM.Parameters.AddWithValue("?P12", m_dec_DDoc_Prd_DSQ)
            COM.Parameters.AddWithValue("?P13", m_dec_DDoc_Prd_NET)
            COM.Parameters.AddWithValue("?P14", m_dec_DDoc_Prd_QTY)
            If m_int_DDoc_RF1_Num = -1 Then
                COM.Parameters.AddWithValue("?P15", DBNull.Value)
            Else
                COM.Parameters.AddWithValue("?P15", m_int_DDoc_RF1_Num)
            End If
            If m_str_DDoc_RF1_Cod.ToUpper = "NULL" Then
                COM.Parameters.AddWithValue("?P16", DBNull.Value)
            Else
                COM.Parameters.AddWithValue("?P16", m_str_DDoc_RF1_Cod)
            End If
            COM.Parameters.AddWithValue("?P17", m_obj_DDoc_RF1_Txt)
            If m_dt_DDoc_RF1_Fec.IsValidDateTime = False Then
                COM.Parameters.AddWithValue("?P18", DBNull.Value)
            Else
                COM.Parameters.AddWithValue("?P18", m_dt_DDoc_RF1_Fec.Value)
            End If
            COM.Parameters.AddWithValue("?P19", m_dec_DDoc_RF1_Dbl)
            If m_int_DDoc_RF2_Num = -1 Then
                COM.Parameters.AddWithValue("?P20", DBNull.Value)
            Else
                COM.Parameters.AddWithValue("?P20", m_int_DDoc_RF2_Num)
            End If
            If m_str_DDoc_RF2_Cod.ToUpper = "NULL" Then
                COM.Parameters.AddWithValue("?P21", DBNull.Value)
            Else
                COM.Parameters.AddWithValue("?P21", m_str_DDoc_RF2_Cod)
            End If
            COM.Parameters.AddWithValue("?P22", m_obj_DDoc_RF2_Txt)
            If m_dt_DDoc_RF2_Fec.IsValidDateTime = False Then
                COM.Parameters.AddWithValue("?P23", DBNull.Value)
            Else
                COM.Parameters.AddWithValue("?P23", m_dt_DDoc_RF2_Fec.Value)
            End If
            COM.Parameters.AddWithValue("?P24", m_dec_DDoc_RF2_Dbl)
            If m_int_DDoc_RF3_Num = -1 Then
                COM.Parameters.AddWithValue("?P25", DBNull.Value)
            Else
                COM.Parameters.AddWithValue("?P25", m_int_DDoc_RF3_Num)
            End If
            COM.Parameters.AddWithValue("?P26", m_obj_DDoc_RF3_Txt)
            If m_dt_DDoc_RF3_Fec.IsValidDateTime = False Then
                COM.Parameters.AddWithValue("?P27", DBNull.Value)
            Else
                COM.Parameters.AddWithValue("?P27", m_dt_DDoc_RF3_Fec.Value)
            End If
            COM.Parameters.AddWithValue("?P28", m_dec_DDoc_RF3_Dbl)
            COM.Parameters.AddWithValue("?P29", m_dec_DDoc_Prd_Fob)
            COM.Parameters.AddWithValue("?P30", m_dec_DDoc_Prd_Cif)
            If m_str_DDoc_Prd_Ref.ToUpper = "NULL" Then
                COM.Parameters.AddWithValue("?P31", DBNull.Value)
            Else
                COM.Parameters.AddWithValue("?P31", m_str_DDoc_Prd_Ref)
            End If
            COM.ExecuteNonQuery()
            COM.Dispose()
            COM = Nothing
            Guardar = True
        Catch MYEX As MySqlException
            MENSAJE = "BiblioTABLAS - TDCMTOS_DTL - PINSERT MyError#=" & MYEX.Number & " MyError=" & MYEX.ToString
        Catch ex As Exception
            MENSAJE = "BiblioTABLAS - TDCMTOS_DTL - PINSERT Error=" & ex.ToString
        Finally
            If IsNothing(COM) = False Then
                COM.Dispose()
                COM = Nothing
            End If
        End Try
    End Function

    Public Function GuardarDetalleTransferencia(ByVal Conexion As String, ByVal empresa As Integer) As Boolean
        Dim COM As MySqlCommand
        Dim SQL As String

        MENSAJE = ""
        GuardarDetalleTransferencia = False
        'If IsNothing(CON) = True Then
        '    MENSAJE = "BiblioTABLAS - TDCMTOS_DTL - PINSERT Conexi�n no definida"
        '    Exit Function
        'End If
        'If CON.State = ConnectionState.Closed Or CON.State = ConnectionState.Broken Then
        '    If CON.ConnectionString.Length <> 0 Then
        '        Try
        '            CON.Open()
        '        Catch MYEX As MySqlException
        '            MENSAJE = "BiblioTABLAS - TTDCMTOS_DTL - PINSERT Error#=" & MYEX.Number & " " & MYEX.ToString
        '            Exit Function
        '        Catch EX As Exception
        '            MENSAJE = "BiblioTABLAS - TTDCMTOS_DTL - PINSERT Error=" & EX.ToString
        '            Exit Function
        '        End Try
        '    Else
        '        MENSAJE = "BiblioTABLAS - TTDCMTOS_DTL - PINSERT String de Conexi�n no definido"
        '        Exit Function
        '    End If
        'End If



        'COM = Nothing

        CON = New MySqlConnection(Conexion)
        CON.Open()

        Try
            SQL = "INSERT INTO Dcmtos_DTL (DDoc_Sis_Emp,DDoc_Doc_Cat,DDoc_Doc_Ano,DDoc_Doc_Num," & _
                "DDoc_Doc_Lin,DDoc_Prd_Cod,DDoc_Prd_PNr,DDoc_Prd_Des,DDoc_Prd_UM,DDoc_Prd_PUQ," & _
                "DDoc_Prd_DSP,DDoc_Prd_DSQ,DDoc_Prd_NET,DDoc_Prd_QTY,DDoc_RF1_Num,DDoc_RF1_Cod," & _
                "DDoc_RF1_Txt,DDoc_RF1_Fec,DDoc_RF1_Dbl,DDoc_RF2_Num,DDoc_RF2_Cod,DDoc_RF2_Txt," & _
                "DDoc_RF2_Fec,DDoc_RF2_Dbl,DDoc_RF3_Num,DDoc_RF3_Txt,DDoc_RF3_Fec,DDoc_RF3_Dbl," & _
                "DDoc_Prd_Fob,DDoc_Prd_Cif,DDoc_Prd_Ref) " & _
                "VALUES(?P1,?P2," & MYSQL_A�O & ",?P4,?P5,?P6,?P7,?P8,?P9,?P10,?P11,?P12,?P13,?P14,?P15," & _
                "?P16,?P17,?P18,?P19,?P20,?P21,?P22,?P23,?P24,?P25,?P26,?P27,?P28,?P29,?P30,?P31)"
            If IsNothing(TRA) = False Then
                COM = New MySqlCommand(SQL, TRA.Connection, TRA)
            Else
                COM = New MySqlCommand(SQL, CON)
            End If
            COM.CommandType = CommandType.Text
            If m_int_DDoc_Sis_Emp = -1 Then
                COM.Parameters.AddWithValue("?P1", DBNull.Value)
            Else
                COM.Parameters.AddWithValue("?P1", empresa)
            End If
            If m_int_DDoc_Doc_Cat = -1 Then
                COM.Parameters.AddWithValue("?P2", DBNull.Value)
            Else
                COM.Parameters.AddWithValue("?P2", m_int_DDoc_Doc_Cat)
            End If
            'COM.Parameters.AddWithValue("?P3", MYSQL_A�O)
            If m_int_DDoc_Doc_Num = -1 Then
                COM.Parameters.AddWithValue("?P4", DBNull.Value)
            Else
                COM.Parameters.AddWithValue("?P4", m_int_DDoc_Doc_Num)
            End If
            If m_int_DDoc_Doc_Lin = -1 Then
                COM.Parameters.AddWithValue("?P5", DBNull.Value)
            Else
                COM.Parameters.AddWithValue("?P5", m_int_DDoc_Doc_Lin)
            End If
            COM.Parameters.AddWithValue("?P6", m_lng_DDoc_Prd_Cod)
            If m_str_DDoc_Prd_PNr.ToUpper = "NULL" Then
                COM.Parameters.AddWithValue("?P7", DBNull.Value)
            Else
                COM.Parameters.AddWithValue("?P7", m_str_DDoc_Prd_PNr)
            End If
            If m_str_DDoc_Prd_Des.ToUpper = "NULL" Then
                COM.Parameters.AddWithValue("?P8", DBNull.Value)
            Else
                COM.Parameters.AddWithValue("?P8", m_str_DDoc_Prd_Des)
            End If
            If m_int_DDoc_Prd_UM = -1 Then
                COM.Parameters.AddWithValue("?P9", DBNull.Value)
            Else
                COM.Parameters.AddWithValue("?P9", m_int_DDoc_Prd_UM)
            End If
            COM.Parameters.AddWithValue("?P10", m_dec_DDoc_Prd_PUQ)
            COM.Parameters.AddWithValue("?P11", m_dec_DDoc_Prd_DSP)
            COM.Parameters.AddWithValue("?P12", m_dec_DDoc_Prd_DSQ)
            COM.Parameters.AddWithValue("?P13", m_dec_DDoc_Prd_NET)
            COM.Parameters.AddWithValue("?P14", m_dec_DDoc_Prd_QTY)
            If m_int_DDoc_RF1_Num = -1 Then
                COM.Parameters.AddWithValue("?P15", DBNull.Value)
            Else
                COM.Parameters.AddWithValue("?P15", m_int_DDoc_RF1_Num)
            End If
            If m_str_DDoc_RF1_Cod.ToUpper = "NULL" Then
                COM.Parameters.AddWithValue("?P16", DBNull.Value)
            Else
                COM.Parameters.AddWithValue("?P16", m_str_DDoc_RF1_Cod)
            End If
            COM.Parameters.AddWithValue("?P17", m_obj_DDoc_RF1_Txt)
            If m_dt_DDoc_RF1_Fec.IsValidDateTime = False Then
                COM.Parameters.AddWithValue("?P18", DBNull.Value)
            Else
                COM.Parameters.AddWithValue("?P18", m_dt_DDoc_RF1_Fec.Value)
            End If
            COM.Parameters.AddWithValue("?P19", m_dec_DDoc_RF1_Dbl)
            If m_int_DDoc_RF2_Num = -1 Then
                COM.Parameters.AddWithValue("?P20", DBNull.Value)
            Else
                COM.Parameters.AddWithValue("?P20", m_int_DDoc_RF2_Num)
            End If
            If m_str_DDoc_RF2_Cod.ToUpper = "NULL" Then
                COM.Parameters.AddWithValue("?P21", DBNull.Value)
            Else
                COM.Parameters.AddWithValue("?P21", m_str_DDoc_RF2_Cod)
            End If
            COM.Parameters.AddWithValue("?P22", m_obj_DDoc_RF2_Txt)
            If m_dt_DDoc_RF2_Fec.IsValidDateTime = False Then
                COM.Parameters.AddWithValue("?P23", DBNull.Value)
            Else
                COM.Parameters.AddWithValue("?P23", m_dt_DDoc_RF2_Fec.Value)
            End If
            COM.Parameters.AddWithValue("?P24", m_dec_DDoc_RF2_Dbl)
            If m_int_DDoc_RF3_Num = -1 Then
                COM.Parameters.AddWithValue("?P25", DBNull.Value)
            Else
                COM.Parameters.AddWithValue("?P25", m_int_DDoc_RF3_Num)
            End If
            COM.Parameters.AddWithValue("?P26", m_obj_DDoc_RF3_Txt)
            If m_dt_DDoc_RF3_Fec.IsValidDateTime = False Then
                COM.Parameters.AddWithValue("?P27", DBNull.Value)
            Else
                COM.Parameters.AddWithValue("?P27", m_dt_DDoc_RF3_Fec.Value)
            End If
            COM.Parameters.AddWithValue("?P28", m_dec_DDoc_RF3_Dbl)
            COM.Parameters.AddWithValue("?P29", m_dec_DDoc_Prd_Fob)
            COM.Parameters.AddWithValue("?P30", m_dec_DDoc_Prd_Cif)
            If m_str_DDoc_Prd_Ref.ToUpper = "NULL" Then
                COM.Parameters.AddWithValue("?P31", DBNull.Value)
            Else
                COM.Parameters.AddWithValue("?P31", m_str_DDoc_Prd_Ref)
            End If
            COM.ExecuteNonQuery()
            COM.Dispose()
            COM = Nothing
            GuardarDetalleTransferencia = True
        Catch MYEX As MySqlException
            MENSAJE = "BiblioTABLAS - TDCMTOS_DTL - PINSERT MyError#=" & MYEX.Number & " MyError=" & MYEX.ToString
        Catch ex As Exception
            MENSAJE = "BiblioTABLAS - TDCMTOS_DTL - PINSERT Error=" & ex.ToString
        Finally
            If IsNothing(COM) = False Then
                COM.Dispose()
                COM = Nothing
            End If
        End Try

    End Function

    Public Function Borrar(Optional ByVal Condicion As String = "") As Boolean

        Dim COM As MySqlCommand
        Dim SQL As String

        MENSAJE = ""
        Borrar = False
        If IsNothing(CON) = True Then
            MENSAJE = "BiblioTABLAS - TDCMTOS_DTL - PDELETE Conexi�n no definida"
            Exit Function
        End If
        If CON.State = ConnectionState.Closed Or CON.State = ConnectionState.Broken Then
            If CON.ConnectionString.Length <> 0 Then
                Try
                    CON.Open()
                Catch MYEX As MySqlException
                    MENSAJE = "BiblioTABLAS - TTDCMTOS_DTL - PDELETE Error#=" & MYEX.Number & " " & MYEX.ToString
                    Exit Function
                Catch EX As Exception
                    MENSAJE = "BiblioTABLAS - TTDCMTOS_DTL - PDELETE Error=" & EX.ToString
                    Exit Function
                End Try
            Else
                MENSAJE = "BiblioTABLAS - TTDCMTOS_DTL - PDELETE String de Conexi�n no definido"
                Exit Function
            End If
        End If

        COM = Nothing
        Try
            If Condicion.Length <> 0 Then
                SQL = "DELETE FROM Dcmtos_DTL WHERE " & Condicion
                If IsNothing(TRA) = False Then
                    COM = New MySqlCommand(SQL, TRA.Connection, TRA)
                Else
                    COM = New MySqlCommand(SQL, CON)
                End If
                COM.CommandType = CommandType.Text
            Else
                SQL = "DELETE FROM Dcmtos_DTL WHERE DDoc_Sis_Emp = ?P1  AND DDoc_Doc_Cat = ?P2  AND DDoc_Doc_Ano = ?P3  AND DDoc_Doc_Num = ?P4  AND DDoc_Doc_Lin = ?P5 "
                If IsNothing(TRA) = False Then
                    COM = New MySqlCommand(SQL, TRA.Connection, TRA)
                Else
                    COM = New MySqlCommand(SQL, CON)
                End If
                COM.CommandType = CommandType.Text
                COM.Parameters.AddWithValue("?P1", m_int_DDoc_Sis_Emp)
                COM.Parameters.AddWithValue("?P2", m_int_DDoc_Doc_Cat)
                COM.Parameters.AddWithValue("?P3", m_int_DDoc_Doc_Ano)
                COM.Parameters.AddWithValue("?P4", m_int_DDoc_Doc_Num)
                COM.Parameters.AddWithValue("?P5", m_int_DDoc_Doc_Lin)
            End If
            COM.ExecuteNonQuery()
            COM.Dispose()
            COM = Nothing
            Borrar = True
        Catch MYEX As MySqlException
            MENSAJE = "BiblioTABLAS - TDCMTOS_DTL - PDELETE MyError#=" & MYEX.Number & " MyError=" & MYEX.ToString
        Catch ex As Exception
            MENSAJE = "BiblioTABLAS - TDCMTOS_DTL - PDELETE Error=" & ex.ToString
        Finally
            If IsNothing(COM) = False Then
                COM.Dispose()
                COM = Nothing
            End If
        End Try
    End Function

    Public Function Actualizar() As Boolean

        Dim COM As MySqlCommand
        Dim SQL As String

        MENSAJE = ""
        Actualizar = False
        If IsNothing(CON) = True Then
            MENSAJE = "BiblioTABLAS - TDCMTOS_DTL - PUPDATE Conexi�n no definida"
            Exit Function
        End If
        If CON.State = ConnectionState.Closed Or CON.State = ConnectionState.Broken Then
            If CON.ConnectionString.Length <> 0 Then
                Try
                    CON.Open()
                Catch MYEX As MySqlException
                    MENSAJE = "BiblioTABLAS - TTDCMTOS_DTL - PUPDATE Error#=" & MYEX.Number & " " & MYEX.ToString
                    Exit Function
                Catch EX As Exception
                    MENSAJE = "BiblioTABLAS - TTDCMTOS_DTL - PUPDATE Error=" & EX.ToString
                    Exit Function
                End Try
            Else
                MENSAJE = "BiblioTABLAS - TTDCMTOS_DTL - PUPDATE String de Conexi�n no definido"
                Exit Function
            End If
        End If

        COM = Nothing
        Try
            SQL = "UPDATE Dcmtos_DTL SET DDoc_Prd_Cod = ?P6, DDoc_Prd_PNr = ?P7, DDoc_Prd_Des = ?P8," & _
                " DDoc_Prd_UM = ?P9, DDoc_Prd_PUQ = ?P10, DDoc_Prd_DSP = ?P11, DDoc_Prd_DSQ = ?P12," & _
                " DDoc_Prd_NET = ?P13, DDoc_Prd_QTY = ?P14, DDoc_RF1_Num = ?P15, DDoc_RF1_Cod = ?P16," & _
                " DDoc_RF1_Txt = ?P17, DDoc_RF1_Fec = ?P18, DDoc_RF1_Dbl = ?P19, DDoc_RF2_Num = ?P20," & _
                " DDoc_RF2_Cod = ?P21, DDoc_RF2_Txt = ?P22, DDoc_RF2_Fec = ?P23, DDoc_RF2_Dbl = ?P24," & _
                " DDoc_RF3_Num = ?P25, DDoc_RF3_Txt = ?P26, DDoc_RF3_Fec = ?P27, DDoc_RF3_Dbl = ?P28," & _
                " DDoc_Prd_Fob = ?P29, DDoc_Prd_Cif = ?P30, DDoc_Prd_Ref = ?P31 " & _
                " WHERE DDoc_Sis_Emp = ?P1 AND DDoc_Doc_Cat = ?P2 AND DDoc_Doc_Ano = ?P3 AND " & _
                " DDoc_Doc_Num = ?P4 AND DDoc_Doc_Lin = ?P5"
            If IsNothing(TRA) = False Then
                COM = New MySqlCommand(SQL, TRA.Connection, TRA)
            Else
                COM = New MySqlCommand(SQL, CON)
            End If
            COM.CommandType = CommandType.Text
            COM.Parameters.AddWithValue("?P6", m_lng_DDoc_Prd_Cod)
            If m_str_DDoc_Prd_PNr.ToUpper = "NULL" Then
                COM.Parameters.AddWithValue("?P7", DBNull.Value)
            Else
                COM.Parameters.AddWithValue("?P7", m_str_DDoc_Prd_PNr)
            End If
            If m_str_DDoc_Prd_Des.ToUpper = "NULL" Then
                COM.Parameters.AddWithValue("?P8", DBNull.Value)
            Else
                COM.Parameters.AddWithValue("?P8", m_str_DDoc_Prd_Des)
            End If
            If m_int_DDoc_Prd_UM = -1 Then
                COM.Parameters.AddWithValue("?P9", DBNull.Value)
            Else
                COM.Parameters.AddWithValue("?P9", m_int_DDoc_Prd_UM)
            End If
            COM.Parameters.AddWithValue("?P10", m_dec_DDoc_Prd_PUQ)
            COM.Parameters.AddWithValue("?P11", m_dec_DDoc_Prd_DSP)
            COM.Parameters.AddWithValue("?P12", m_dec_DDoc_Prd_DSQ)
            COM.Parameters.AddWithValue("?P13", m_dec_DDoc_Prd_NET)
            COM.Parameters.AddWithValue("?P14", m_dec_DDoc_Prd_QTY)
            If m_int_DDoc_RF1_Num = -1 Then
                COM.Parameters.AddWithValue("?P15", DBNull.Value)
            Else
                COM.Parameters.AddWithValue("?P15", m_int_DDoc_RF1_Num)
            End If
            If m_str_DDoc_RF1_Cod.ToUpper = "NULL" Then
                COM.Parameters.AddWithValue("?P16", DBNull.Value)
            Else
                COM.Parameters.AddWithValue("?P16", m_str_DDoc_RF1_Cod)
            End If
            COM.Parameters.AddWithValue("?P17", m_obj_DDoc_RF1_Txt)
            If m_dt_DDoc_RF1_Fec.IsValidDateTime = False Then
                COM.Parameters.AddWithValue("?P18", DBNull.Value)
            Else
                COM.Parameters.AddWithValue("?P18", m_dt_DDoc_RF1_Fec.Value)
            End If
            COM.Parameters.AddWithValue("?P19", m_dec_DDoc_RF1_Dbl)
            If m_int_DDoc_RF2_Num = -1 Then
                COM.Parameters.AddWithValue("?P20", DBNull.Value)
            Else
                COM.Parameters.AddWithValue("?P20", m_int_DDoc_RF2_Num)
            End If
            If m_str_DDoc_RF2_Cod.ToUpper = "NULL" Then
                COM.Parameters.AddWithValue("?P21", DBNull.Value)
            Else
                COM.Parameters.AddWithValue("?P21", m_str_DDoc_RF2_Cod)
            End If
            COM.Parameters.AddWithValue("?P22", m_obj_DDoc_RF2_Txt)
            If m_dt_DDoc_RF2_Fec.IsValidDateTime = False Then
                COM.Parameters.AddWithValue("?P23", DBNull.Value)
            Else
                COM.Parameters.AddWithValue("?P23", m_dt_DDoc_RF2_Fec.Value)
            End If
            COM.Parameters.AddWithValue("?P24", m_dec_DDoc_RF2_Dbl)
            If m_int_DDoc_RF3_Num = -1 Then
                COM.Parameters.AddWithValue("?P25", DBNull.Value)
            Else
                COM.Parameters.AddWithValue("?P25", m_int_DDoc_RF3_Num)
            End If
            COM.Parameters.AddWithValue("?P26", m_obj_DDoc_RF3_Txt)
            If m_dt_DDoc_RF3_Fec.IsValidDateTime = False Then
                COM.Parameters.AddWithValue("?P27", DBNull.Value)
            Else
                COM.Parameters.AddWithValue("?P27", m_dt_DDoc_RF3_Fec.Value)
            End If
            COM.Parameters.AddWithValue("?P28", m_dec_DDoc_RF3_Dbl)
            COM.Parameters.AddWithValue("?P29", m_dec_DDoc_Prd_Fob)
            COM.Parameters.AddWithValue("?P30", m_dec_DDoc_Prd_Cif)
            If m_str_DDoc_Prd_Ref.ToUpper = "NULL" Then
                COM.Parameters.AddWithValue("?P31", DBNull.Value)
            Else
                COM.Parameters.AddWithValue("?P31", m_str_DDoc_Prd_Ref)
            End If
            COM.Parameters.AddWithValue("?P1", m_int_DDoc_Sis_Emp)
            COM.Parameters.AddWithValue("?P2", m_int_DDoc_Doc_Cat)
            COM.Parameters.AddWithValue("?P3", m_int_DDoc_Doc_Ano)
            COM.Parameters.AddWithValue("?P4", m_int_DDoc_Doc_Num)
            COM.Parameters.AddWithValue("?P5", m_int_DDoc_Doc_Lin)
            COM.ExecuteNonQuery()
            COM.Dispose()
            COM = Nothing
            Actualizar = True
        Catch MYEX As MySqlException
            MENSAJE = "BiblioTABLAS - TDCMTOS_DTL - PUPDATE MyError#=" & MYEX.Number & " MyError=" & MYEX.ToString
        Catch ex As Exception
            MENSAJE = "BiblioTABLAS - TDCMTOS_DTL - PUPDATE Error=" & ex.ToString
        Finally
            If IsNothing(COM) = False Then
                COM.Dispose()
                COM = Nothing
            End If
        End Try
    End Function

#End Region

End Class