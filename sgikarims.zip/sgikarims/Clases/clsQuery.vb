﻿Public Class clsQuery
    Implements IDisposable

    Public Enum Mode
        None = 0
        Insert = 1
        Update = 2
    End Enum

    Public Property Name As String = ""
    Public Property Kind As Mode = Mode.None
    Public Property ApplyToAll As Boolean = False

    Private lst As New Dictionary(Of String, String)
    Private logDisposed As Boolean = False

    'Agrega un campo
    Public Sub Add(ByVal Key As String, ByVal Value As String)
        If lst.ContainsKey(Key) Then
            lst.Remove(Key)
        End If
        lst.Add(Key, Value)
    End Sub

    'Elimina un campo
    Public Sub Remove(ByVal Key As String)
        If lst.ContainsKey(Key) Then
            lst.Remove(Key)
        End If
    End Sub

    'Cantidad de items
    Public Function Count() As Integer
        Return lst.Count
    End Function

    'Devuelve la instruccion SQL formada
    Public Function SQLString() As String
        Dim strSQL As String = ""
        Dim strData As String = ""
        Dim strFields As String = ""

        If lst.Count > 0 Then
            If Not (Name = "") Or Kind = Mode.None Then
                For Each k As String In lst.Keys
                    Dim v As String = lst(k)
                    If Kind = Mode.Insert Then
                        If Not (strFields = "") Then
                            strFields += ","
                            strData += ","
                        End If
                        strFields += k
                        strData += v
                    Else
                        If Not (strData = "") Then
                            strData += ","
                        End If
                        strData += " " & k & "=" & v
                    End If
                Next
                Select Case Kind
                    Case Mode.None
                        strSQL = strData
                    Case Mode.Insert
                        strSQL = "INSERT INTO " & Name & " (" & strFields & ") VALUES (" & strData & ")"
                    Case Mode.Update
                        strSQL = "UPDATE " & Name & " SET " & strData
                        If Not (ApplyToAll) Then
                            strSQL = strSQL & " WHERE "
                        End If
                End Select
            End If
        End If
        Return strSQL
    End Function

    'Ejecuta la instruccion indicada
    Public Shared Function Execute(ByVal SQL As String) As Boolean
        Dim logEx As Boolean = False
        Using cmd As New MySqlCommand(SQL, CON)
            Try
                cmd.ExecuteNonQuery()
                logEx = True
            Catch ex As Exception
                MessageBox.Show(ex.Message, ex.Source, MessageBoxButtons.OK, MessageBoxIcon.Error)
            End Try
        End Using
        Return logEx
    End Function

    Protected Overridable Sub Dispose(disposing As Boolean)
        If Not logDisposed Then
            If disposing Then
                ' TODO: dispose managed state (managed objects).
            End If
            lst.Clear()
        End If
        logDisposed = True
    End Sub

    Public Sub Dispose() Implements IDisposable.Dispose
        Dispose(True)
        GC.SuppressFinalize(Me)
    End Sub

End Class
