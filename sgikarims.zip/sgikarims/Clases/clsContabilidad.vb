﻿
Public Class clsContabilidad

#Region "Variables globales y Constantes"

    Const EJERCICIO_ACTIVO = "A"

    Const CUENTA_DEUDORES As String = "04"
    Const CUENTA_ACREEDORES As String = "05"
    Const CUENTA_DEUDORES_SV As String = "4"
    Const CUENTA_ACREEDORES_SV As String = "5"
    Const CUENTA_ACREEDORES_SV2 As String = "6"
    Const CUENTA_ACREEDORES_SV3 As String = "7"
    Const TIPO_ACREEDOR As Integer = 1
    Const TIPO_DEUDOR As Integer = 0

    Dim EJERCICIO As Integer = INT_CERO

    Private intNiveles As Integer
    Dim strMascara As String

    Private Structure Ejercicios
        Dim EjercicioActual As Integer
        Dim EjercicioAnterior As Integer
        Dim Descripcion As String
        Dim FechaInicio As Date
        Dim FechaFin As Date
    End Structure

    Private Structure Cierre
        Dim Actual As Ejercicios
        Dim Siguiente As Ejercicios
    End Structure
    Dim Cierres As New Cierre

    Dim CierreAno(4) As Integer
    Dim CierrePoliza(4) As Long

#End Region

#Region "Funciones Generales"

    Private Function DocActivo(ByVal cat As Integer, ByVal ano As Integer, ByVal num As Integer) As Boolean
        Dim logResultado As Boolean = False
        Dim strSQL As String = STR_VACIO
        Dim COM As MySqlCommand
        Dim intEstado As Integer = NO_FILA

        'verificar si el documento esta activo
        strSQL = strSQL & "SELECT HDoc_Doc_Status Estado FROM Dcmtos_HDR WHERE HDoc_Sis_Emp = " & Sesion.IdEmpresa & " AND HDoc_Doc_Cat = " & cat & " AND HDoc_Doc_Num = " & num & " AND HDoc_Doc_Ano = " & ano

        Try
            MyCnn.CONECTAR = strConexion

            COM = New MySqlCommand(strSQL, CON)
            intEstado = COM.ExecuteScalar
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try

        If intEstado = vbEmpty Then
            If (cat = 47) Or (cat = 51 Or cat = 52 Or cat = 53 Or cat = 54 Or cat = 220 Or cat = 733) Then      'Ingreso a Bodega, Bancos
                logResultado = True
            Else
                logResultado = False
            End If
        ElseIf intEstado = 3 And (cat = 51 Or cat = 52 Or cat = 53 Or cat = 54) Then
            logResultado = False
        Else
            logResultado = True
        End If

        If cat = 160 Then ' depreciaciones no tienen documento en el auxiliar por lo tanto siempres retornara true
            logResultado = True
        End If

        Return logResultado
    End Function

    Private Function EjercicioActivo(ByVal cat As Integer, ByVal ano As Integer, ByVal num As Integer, Optional ByVal fecha As Date = Nothing) As Boolean
        Dim LogResultado As Boolean = False
        Dim strSQl As String = STR_VACIO
        Dim COM As MySqlCommand

        If cat = 160 Then ' Depreciaciones no tiene documento auxiliar por lo tanto no puede verficar el ejercicio de la manera convencional
            strSQl = " SELECT ifnull(ej.estado,'X') ESTADO from {conta}.ejercicios e
	                    LEFT JOIN {conta}.ejercicio_empresa ej ON ej.ejercicio = e.ejercicio AND ej.empresa = {empresa}
                       WHERE '{fecha}' BETWEEN  e.inicio AND e.fin  "
        Else
            strSQl = " SELECT ifnull(ej.estado,'X') ESTADO FROM Dcmtos_HDR  "
            strSQl &= "  LEFT  JOIN {conta}.ejercicios e on  HDoc_Doc_Fec between e.inicio and e.fin "
            strSQl &= "  LEFT JOIN {conta}.ejercicio_empresa ej on ej.ejercicio = e.ejercicio and ej.empresa =HDoc_Sis_Emp  "
            strSQl &= " WHERE HDoc_Sis_Emp = {empresa}  AND   HDoc_Doc_Cat =  {catalogo}  AND   HDoc_Doc_Ano = {ano} AND   HDoc_Doc_Num = {numero}  "
        End If

        strSQl = Replace(strSQl, "{empresa}", Sesion.IdEmpresa)
        strSQl = Replace(strSQl, "{catalogo}", cat)
        strSQl = Replace(strSQl, "{ano}", ano)
        strSQl = Replace(strSQl, "{numero}", num)
        strSQl = Replace(strSQl, "{conta}", cFunciones.ContaEmpresa)
        strSQl = Replace(strSQl, "{fecha}", fecha.ToString(FORMATO_MYSQL))

        Try
            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSQl, CON)

            If COM.ExecuteScalar = "A" Then

                MyCnn.CONECTAR = strConexion
                COM = New MySqlCommand(Replace(strSQl, "ifnull(ej.estado,'X') ESTADO", "ifnull(e.ejercicio,-1) ejercicio"), CON)
                EJERCICIO = COM.ExecuteScalar ' toma el valor del ejercicio
                LogResultado = True
            End If

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try

        Return LogResultado
    End Function

    Private Function VerificarPoliza(ByVal cat As Integer, ByVal ano As Integer, ByVal num As Integer) As Boolean
        Dim logResultado As Boolean = False
        Dim strSQL As String
        Dim COM As MySqlCommand
        Dim intResultado As Integer = NO_FILA

        strSQL = "SELECT COUNT(*) FROM {conta}.polizas WHERE empresa = " & Sesion.IdEmpresa & " AND ejercicio = " & "'" & EJERCICIO & "'" & " AND ref_tipo = " & cat & " AND ref_ciclo = " & ano & " AND ref_numero = " & num
        strSQL = Replace(strSQL, "{conta}", Sesion.BaseConta)
        Try
            COM = New MySqlCommand(strSQL, CON)
            intResultado = COM.ExecuteScalar
            If intResultado > 0 Then
                logResultado = True
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try

        Return logResultado
    End Function

    Private Function BorraPoliza(ByVal cat As Integer, ByVal ano As Integer, ByVal num As Integer) As Boolean
        Dim logResultado As Boolean = False
        Dim strSQL As String = STR_VACIO
        Dim COM As MySqlCommand

        strSQL = " DELETE FROM {conta}.polizas  "
        strSQL &= "  WHERE empresa = {empresa} and ejercicio = {ejercicio} and ref_tipo = {cat} and ref_ciclo = {ano} and ref_numero = {num};"
        If Sesion.IdEmpresa = 18 Then
            strSQL &= " DELETE FROM contapdm.polizas  "
            strSQL &= "  WHERE empresa = {empresa} and ejercicio = {ejercicio} and ref_tipo = {cat} and ref_ciclo = {ano} and ref_numero = {num};"
        End If
        strSQL = Replace(strSQL, "{conta}", Sesion.BaseConta)
        strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
        strSQL = Replace(strSQL, "{cat}", cat)
        strSQL = Replace(strSQL, "{num}", num)
        strSQL = Replace(strSQL, "{ano}", ano)
        strSQL = Replace(strSQL, "{ejercicio}", EJERCICIO)

        'borrar encabezado
        Try
            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSQL, CON)
            COM.ExecuteNonQuery()
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        strSQL = STR_VACIO


        strSQL = " DELETE FROM {conta}.detalle_polizas   "
        strSQL &= "  WHERE empresa = {empresa} and ejercicio = {ejercicio} and ref_tipo = {cat} and ref_ciclo = {ano} and ref_numero = {num};"
        If Sesion.IdEmpresa = 18 Then
            strSQL &= " DELETE FROM contapdm.detalle_polizas   "
            strSQL &= "  WHERE empresa = {empresa} and ejercicio = {ejercicio} and ref_tipo = {cat} and ref_ciclo = {ano} and ref_numero = {num}"
        End If
        strSQL = Replace(strSQL, "{conta}", Sesion.BaseConta)
        strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
        strSQL = Replace(strSQL, "{cat}", cat)
        strSQL = Replace(strSQL, "{num}", num)
        strSQL = Replace(strSQL, "{ano}", ano)
        strSQL = Replace(strSQL, "{ejercicio}", EJERCICIO)
        'borra detalles
        Try
            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSQL, CON)
            COM.ExecuteNonQuery()
            logResultado = True
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try

        Return logResultado
    End Function

    Private Sub UltimaPoliza(ByVal Poliza As Long, ByVal Ejercicio As Integer)

        Dim strSQL As String = STR_VACIO
        Dim COM As New MySqlCommand

        strSQL = strSQL & "UPDATE {conta}.ejercicio_empresa SET ult_poliza = " & Poliza & " WHERE empresa = " & Sesion.IdEmpresa & " AND ejercicio = " & Ejercicio
        If Sesion.IdEmpresa = 18 Then
            strSQL = strSQL & ";UPDATE contapdm.ejercicio_empresa SET ult_poliza = " & Poliza & " WHERE empresa = " & Sesion.IdEmpresa & " AND ejercicio = " & Ejercicio
        End If
        strSQL = Replace(strSQL, "{conta}", cFunciones.ContaEmpresa)
        Try
            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSQL, CON)
            COM.ExecuteNonQuery()
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try

    End Sub

    Private Function NuevaPoliza() As Long
        Dim longPoliza As Long = NO_FILA
        Dim strSQL As String = STR_VACIO
        Dim COM As MySqlCommand

        strSQL = " SELECT ifnull(MAX(p.poliza),1)+1 from {conta}.polizas p "
        strSQL &= " WHERE p.empresa = {empresa} and p.ejercicio = '{ejercicio}' "

        strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
        strSQL = Replace(strSQL, "{ejercicio}", EJERCICIO)
        strSQL = Replace(strSQL, "{conta}", Sesion.BaseConta)

        Try
            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSQL, CON)
            longPoliza = COM.ExecuteScalar

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try

        Return longPoliza
    End Function

    Private Function Generar(ByVal cat As Integer, ByVal ano As Integer, ByVal num As Integer, Optional ByVal fecha As Date = Nothing, Optional ByVal IngresoTraslado As Integer = 0) As Boolean
        Dim logResultado As Boolean = False
        Dim strSQL As String = STR_VACIO
        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader
        Dim fn As New clsFunciones
        Dim conta As New clsContabilidad
        Select Case cat
            Case 51 'cheque
                If EncabezadoCheque(cat, ano, num) Then
                    logResultado = True
                End If
            Case 52 'Nota de Debito

            Case 31 'Nota de Credito
                PolizaNCredit(cat, ano, num, fecha)
            Case 32 'Nota de Debito 
                PolizaNDebito(cat, ano, num, fecha)
            Case 39 ' Nota de Credito Proveedor 
                PolizaNCreditoProveedor(cat, ano, num, fecha)
            Case 54 'Deposito

            Case 36 'Factura de venta
                Dim tipoFact As Integer = NO_FILA
                Dim tipoProducto As String = STR_VACIO

                strSQL = " SELECT h.HDoc_RF3_Dbl  
                            FROM Dcmtos_HDR h
                                WHERE h.HDoc_Sis_Emp = {empresa} AND h.HDoc_Doc_Cat = {cat} AND h.HDoc_Doc_Ano ={anio} AND h.HDoc_Doc_Num = {num} "
                strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
                strSQL = Replace(strSQL, "{cat}", cat)
                strSQL = Replace(strSQL, "{anio}", ano)
                strSQL = Replace(strSQL, "{num}", num)
                MyCnn.CONECTAR = strConexion
                COM = New MySqlCommand(strSQL, CON)
                tipoFact = COM.ExecuteScalar
                strSQL = STR_VACIO
                COM.Dispose()
                COM = Nothing
                CON.Close()
                CON.Dispose()
                CON = Nothing


                '*********************************
                '**********************************
                If tipoFact = 2 Then
                Else
                    PolizaVenta(cat, ano, num, fecha, tipoFact)

                    If tipoFact = 1 Then
                    Else
                        strSQL = " SELECT c.cat_ext
                            FROM Dcmtos_DTL d
                            LEFT JOIN Inventarios i ON i.inv_sisemp = d.DDoc_Sis_Emp AND i.inv_numero = d.DDoc_Prd_Cod
                            LEFT JOIN Articulos a ON a.art_sisemp = i.inv_sisemp AND a.art_codigo = i.inv_artcodigo
                            LEFT JOIN Catalogos c ON c.cat_num = a.art_clase
                                WHERE d.DDoc_Sis_Emp = {empresa} AND d.DDoc_Doc_Cat = {cat} AND d.DDoc_Doc_Ano = {anio} AND d.DDoc_Doc_Num = {num}
                                LIMIT 1 "
                        strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
                        strSQL = Replace(strSQL, "{cat}", cat)
                        strSQL = Replace(strSQL, "{anio}", ano)
                        strSQL = Replace(strSQL, "{num}", num)
                        MyCnn.CONECTAR = strConexion
                        COM = New MySqlCommand(strSQL, CON)
                        tipoProducto = COM.ExecuteScalar
                        PolizaCostoVenta(cat, ano, num, fecha, tipoProducto)
                    End If
                End If

            Case 44 'Factura de compra
                PolizaDeFacturaDeCompra(ano, num, fecha, IngresoTraslado)
            Case 209 ' RECIBO                                                '''''''''''ESTAMOS VALIDANDO EL COMO SE GUARDA.
                PolizaRecibo(ano, num, fecha)
                logResultado = True
            Case 246 'Poliza de liquidacion Caja Chica  
                'PolizaLiquidacacionCajaC(cat, ano, num, fecha)
            Case 296 ' Factura de Cobro/Credito Fiscal (El Salvador)/ Simple

                Dim complementoCtaAjena As Integer

                strSQL = "SELECT COUNT(*)
                        FROM Dcmtos_HDR h
                        LEFT JOIN Dcmtos_HDR h303 ON h303.HDoc_Sis_Emp = h.HDoc_Sis_Emp AND h303.HDoc_Pro_DCat = h.HDoc_Doc_Cat AND h303.HDoc_Pro_DAno = h.HDoc_Doc_Ano AND h303.HDoc_Pro_DNum = h.HDoc_Doc_Num 
                        LEFT JOIN Dcmtos_DTL d303 ON d303.DDoc_Sis_Emp = h303.HDoc_Sis_Emp AND d303.DDoc_Doc_Cat = h303.HDoc_Doc_Cat AND d303.DDoc_Doc_Ano = h303.HDoc_Doc_Ano AND d303.DDoc_Doc_Num = h303.HDoc_Doc_Num 
                        LEFT JOIN Dcmtos_DTL d ON d.DDoc_Sis_Emp = h.HDoc_Sis_Emp AND d.DDoc_Doc_Cat = h.HDoc_Doc_Cat AND d.DDoc_Doc_Ano = h.HDoc_Doc_Ano AND d.DDoc_Doc_Num = h.HDoc_Doc_Num
                        WHERE h.HDoc_Sis_Emp = {empresa} AND h.HDoc_Doc_Cat = 296 AND h.HDoc_Doc_Ano = {anio} AND h.HDoc_Doc_Num = {num} AND (d.DDoc_Prd_Ref='comp' OR d303.DDoc_Prd_Ref='comp')"
                ' WHERE h.HDoc_Sis_Emp = {empresa} AND h.HDoc_Pro_DCat = 296 AND h.HDoc_Pro_DAno = {anio} AND h.HDoc_Pro_DNum = {num} AND d.DDoc_Prd_Ref='comp'"

                strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
                strSQL = Replace(strSQL, "{anio}", ano)
                strSQL = Replace(strSQL, "{num}", num)
                MyCnn.CONECTAR = strConexion
                COM = New MySqlCommand(strSQL, CON)
                complementoCtaAjena = COM.ExecuteScalar

                PolizaVenta296(ano, num, complementoCtaAjena)
            Case 127 'Confiramación de Embarque
                PolizaDeConfirmación(cat, ano, num)

            Case 47 ' ingreso a bodega
                Dim tipoIngreso As Integer
                Dim tipoIngresoAnterior As Integer


                strSQL = " SELECT h.HDoc_DR1_Cat tipoIngreso, IFNULL(t.HDoc_DR1_Cat,0) tipoIngresoAnterior
                            FROM Dcmtos_HDR h
                                LEFT JOIN Dcmtos_DTL_Pro p ON p.PDoc_Sis_Emp = h.HDoc_Sis_Emp AND p.PDoc_Chi_Cat = h.HDoc_Doc_Cat AND p.PDoc_Chi_Ano = h.HDoc_Doc_Ano AND p.PDoc_Chi_Num = h.HDoc_Doc_Num
                                LEFT JOIN Dcmtos_HDR t ON t.HDoc_Sis_Emp = p.PDoc_Sis_Emp AND t.HDoc_Doc_Cat = p.PDoc_Par_Cat AND t.HDoc_Doc_Ano = p.PDoc_Par_Ano AND t.HDoc_Doc_Num = p.PDoc_Par_Num "
                strSQL &= "        WHERE h.HDoc_Sis_Emp = {empresa} AND h.HDoc_Doc_Cat = {cat} AND h.HDoc_Doc_Ano = {anio} AND h.HDoc_Doc_Num = {num} "

                strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
                strSQL = Replace(strSQL, "{cat}", cat)
                strSQL = Replace(strSQL, "{anio}", ano)
                strSQL = Replace(strSQL, "{num}", num)
                MyCnn.CONECTAR = strConexion
                COM = New MySqlCommand(strSQL, CON)
                REA = COM.ExecuteReader

                If REA.HasRows Then
                    REA.Read()
                    tipoIngreso = REA.GetInt32("tipoIngreso")
                    tipoIngresoAnterior = REA.GetInt32("tipoIngresoAnterior")
                End If

                If (Sesion.idGiro = 2 And tipoIngreso = 2) Then
                    'Poliza Producto terminado (tipo poliza contable =30) -- para NT es póliza de Greige
                    PolizaInventarioTerminado(cat, ano, num, 30)
                ElseIf (Sesion.idGiro = 2 And tipoIngreso = 4) Then
                    'Poliza Producto terminado Desperdicio e Invisible (tipo poliza contable =31)
                    PolizaInventarioTerminado(cat, ano, num, 31)
                    ' poliza materia prima
                    ' PolizaIngresoMateriaPrima(cat, ano, num)
                    ' ElseIf tipoIngreso = 1 Or tipoIngreso = 2 Then ' 1 = Poliza de Producto Terminado, 2 = Poliza de Desperdicio
                    '  PolizaInventarioProductoTerminado(cat, ano, num, tipoIngreso)
                    ' End If
                ElseIf (Sesion.idGiro = 2 And tipoIngreso = 5) Then
                    PolizaInventarioTerminado(cat, ano, num, 34)
                ElseIf (Sesion.idGiro = 2 And tipoIngreso = 6) Then ' Producto en proceso - no debe llevar póliza
                    ' PolizaInventarioTerminado(cat, ano, num, 35)
                ElseIf (Sesion.idGiro = 2 And tipoIngreso = 3) Then
                    PolizaDeConsumibles(cat, ano, num, fecha)
                ElseIf Sesion.idGiro = 1 And tipoIngreso = 6 Then
                    ' PolizaInventarioTerminado(cat, ano, num, 35) ' ramplas no deben de llevar póliza contable
                ElseIf Sesion.idGiro = 2 And (tipoIngreso > 6 And tipoIngreso < 12) Then ' Otros Ingresos
                    PolizaDeOtrosIngresos(cat, ano, num, fecha, tipoIngreso)
                ElseIf Sesion.idGiro = 2 And tipoIngreso = 12 Then
                    ' no genera póliza contable
                ElseIf Sesion.idGiro = 2 And tipoIngreso = 13 Then
                    ' no genera póliza contable
                ElseIf Sesion.idGiro = 2 And tipoIngreso = 14 Then ' 14 es tipo Dyeing (NT)
                    PolizaInventarioProductivoNT(cat, ano, num, 38, tipoIngresoAnterior)
                ElseIf Sesion.idGiro = 2 And tipoIngreso = 15 Then ' 15 es tipo Finishing (NT)
                    PolizaInventarioProductivoNT(cat, ano, num, 39, tipoIngresoAnterior)
                ElseIf Sesion.idGiro = 2 And tipoIngreso = 16 Then ' 16 es tipo Rolling (NT)
                    PolizaInventarioProductivoNT(cat, ano, num, 40, tipoIngresoAnterior)
                ElseIf Sesion.idGiro = 2 And tipoIngreso = 17 Then ' 17 es tipo Finish good (NT)
                    PolizaInventarioProductivoNT(cat, ano, num, 41, tipoIngresoAnterior)
                Else
                    PolizaIngresoABodega(cat, ano, num, fecha)
                End If


            Case 952 'Poliza para producto en Proceso (inventario en proceso)
                PolizaInventarioEnProceso(cat, ano, num)

            Case 220
                ' Verifica si la factura anclada, es de caja chica o no
                ' Si es de caja chica devuleve la cuenta contable, de lo contrario devuelve N/A
                Dim ctaCaja As String = STR_VACIO
                strSQL = " SELECT IFNULL(b.BCta_Cuenta,'N/A') cuenta
                                FROM Dcmtos_HDR h
                                LEFT JOIN Dcmtos_HDR d ON d.HDoc_Sis_Emp = h.HDoc_Sis_Emp AND d.HDoc_Doc_Cat = h.HDoc_Pro_DCat AND d.HDoc_Doc_Ano = h.HDoc_Pro_DAno AND d.HDoc_Doc_Num = h.HDoc_Pro_DNum
                                LEFT JOIN CtasBcos b ON b.BCta_Sis_Emp = d.HDoc_Sis_Emp AND b.BCta_Num = d.HDoc_DR1_Cat
                            WHERE h.HDoc_Sis_Emp = {emp} AND h.HDoc_Doc_Cat = {cat} AND h.HDoc_Doc_Ano = {anio} AND h.HDoc_Doc_Num = {num}"
                strSQL = strSQL.Replace("{emp}", Sesion.IdEmpresa)
                strSQL = strSQL.Replace("{cat}", cat)
                strSQL = strSQL.Replace("{anio}", ano)
                strSQL = strSQL.Replace("{num}", num)
                MyCnn.CONECTAR = strConexion
                COM = New MySqlCommand(strSQL, CON)
                ctaCaja = COM.ExecuteScalar

                COM.Dispose()
                COM = Nothing
                CON.Close()
                CON.Dispose()
                CON = Nothing

                'Poliza de retención
                PolizaDeRetencion(cat, ano, num, fecha, ctaCaja)

            Case 160 'Depreciaciones 
                If PolizaDepeciacion(cat, ano, num, fecha:=fecha) = True Then
                    logResultado = True
                End If

            Case 326 'Retencion IVA cliente
                PolizaDeRetencionIVACMC(cat, ano, num, fecha)
            Case 733 'Retencion ISR cliente
                PolizaDeRetencionISRCMC(cat, ano, num, fecha)
            Case 691
                PólizaCostoConsumibles(cat, ano, num, fecha)
            Case 689
                PolizaAnticipoCompra(cat, ano, num, fecha)
            Case 950
                PolizaAnticipoVenta(cat, ano, num, fecha)
            Case 48
                PolizaInstruccionDespacho(cat, ano, num, fecha)
        End Select
        Return logResultado
    End Function

    Public Sub EnviarCorreoAlCancelar(ByVal cat As Integer, ByVal ano As Integer, ByVal num As Integer)
        Dim ArrayServer() As String
        Dim ArrayAuxiliar() As String
        Dim strConexion2 As String = STR_VACIO
        Dim strInsert As String = STR_VACIO
        Dim COMM As MySqlCommand
        Dim LLave As String = STR_VACIO
        Dim conec2 As MySqlConnection

        ArrayServer = strConexion.Split(";".ToCharArray)

        strConexion2 = "server={server};port={puerto};uid={user};password={password};database={database} ;Allow User Variables=True"
        ArrayAuxiliar = ArrayServer(INT_CERO).Split("=".ToCharArray)

        If ArrayAuxiliar(INT_UNO) = "192.168.4.9" Then
            strConexion2 = Replace(strConexion2, "{server}", MAIL_HOST)
            strConexion2 = Replace(strConexion2, "port={puerto};", vbNullString)
        Else
            strConexion2 = Replace(strConexion2, "{server}", MAIL_HOST_REMOTO)
            strConexion2 = Replace(strConexion2, "{puerto}", "3308")
        End If

        strConexion2 = Replace(strConexion2, "{user}", MAIL_USER)
        strConexion2 = Replace(strConexion2, "{password}", MAIL_PASS)
        strConexion2 = Replace(strConexion2, "{database}", MAIL_BASE)

        LLave = cat & "-" & ano & "-" & num & " --> " & Sesion.Usuario
        strInsert &= ("INSERT INTO MailServer.Correo (idCorreo,Destinatario,Asunto,Contenido,Estado) Values(0,'" & "tisoportegt@grupokarims.com, delia.ramirez@grupokarims.com'" & "," & "'Alteración de Póliza'" & ",'" & LLave & "',0)")

        conec2 = New MySqlConnection(strConexion2)
        conec2.Open()
        Using conec2
            COMM = New MySqlCommand(strInsert, conec2)
            COMM.ExecuteNonQuery()
            COMM.Dispose()
            System.GC.Collect()

            COMM.Dispose()
            COMM = Nothing
            conec2.Close()
            conec2.Dispose()
            conec2 = Nothing
            System.GC.Collect()
        End Using
    End Sub

    Public Function GenerarPoliza(ByVal cat As Integer, ByVal ano As Integer, ByVal num As Integer, Optional ByVal fecha As Date = Nothing, Optional Finicio As Date = Nothing, Optional Ffinal As Date = Nothing, Optional TrasladoTendido As Integer = 0) As Boolean
        Dim logResultado As Boolean = False
        Dim strSQL As String = STR_VACIO
        Dim cfun As New clsFunciones
        Dim COMAN As MySqlCommand
        Dim ESC As MySqlDataReader
        Dim conecC As MySqlConnection

        If Finicio = Nothing Or Ffinal = Nothing Then ' entra aqui si es por documento
            If EjercicioActivo(cat, ano, num, fecha:=fecha) = True Then 'VERIFICAR SI EL EJERCICIO ESTA ABIERTO
                If DocActivo(cat, ano, num) = True Then ' solo documentos activos
                    If VerificarPoliza(cat, ano, num) = True Then 'verificar si el documento ya tiene poliza
                        If BorraPoliza(cat, ano, num) Then ' Si ya tiene poliza la borra
                            If Generar(cat, ano, num, fecha:=fecha, IngresoTraslado:=TrasladoTendido) Then 'si ya tiene poliza aplicar update
                                logResultado = True
                            End If
                        End If
                    Else
                        If Generar(cat, ano, num, fecha:=fecha, IngresoTraslado:=TrasladoTendido) Then 'si no tiene poliza aplicar insert
                            logResultado = True
                        End If
                    End If
                Else
                    BorraPoliza(cat, ano, num)
                End If

            Else
                MsgBox("The document won't  be recorded in the accounts." & vbNewLine & " Possible causes accounting period is closed or doesn't exist.")
            End If

        Else ' si viene por rangos de fecha ingresa aqui
            strSQL = " SELECT h.HDoc_Doc_Ano anio, h.HDoc_Doc_Num numero, h.HDoc_Doc_Fec fecha"
            strSQL &= "    From Dcmtos_HDR h "
            strSQL &= "     WHERE h.HDoc_Sis_Emp = {emp} AND h.HDoc_Doc_Cat = {cat} AND NOT (h.HDoc_RF1_Cod = 0 AND h.HDoc_DR1_Emp = 3) AND h.HDoc_Doc_Fec BETWEEN '{inicio}' AND '{fin}' {import} "

            If cat = 44 Then
                strSQL = Replace(strSQL, "{import}", " AND NOT (h.HDoc_DR1_Emp = -1 OR h.HDoc_DR1_Emp IS null)  ")
            Else
                strSQL = Replace(strSQL, "{import}", " ")
            End If
            strSQL = Replace(strSQL, "{emp}", Sesion.IdEmpresa)
            strSQL = Replace(strSQL, "{inicio}", Finicio.ToString(FORMATO_MYSQL))
            strSQL = Replace(strSQL, "{fin}", Ffinal.ToString(FORMATO_MYSQL))
            strSQL = Replace(strSQL, "{cat}", cat)

            conecC = New MySqlConnection(strConexion)
            conecC.Open()

            COMAN = New MySqlCommand(strSQL, conecC)
            ESC = COMAN.ExecuteReader
            If ESC.HasRows Then
                Do While ESC.Read()
                    ano = ESC.GetInt32("anio")
                    num = ESC.GetInt32("numero")
                    fecha = cfun.SQLValidarFechaContable(cat, ano, num)

                    If EjercicioActivo(cat, ano, num, fecha:=fecha) = True Then 'VERIFICAR SI EL EJERCICIO ESTA ABIERTO
                        If DocActivo(cat, ano, num) = True Then ' solo documentos activos
                            If VerificarPoliza(cat, ano, num) = True Then 'verificar si el documento ya tiene poliza
                                If BorraPoliza(cat, ano, num) Then ' Si ya tiene poliza la borra
                                    If Generar(cat, ano, num, fecha:=fecha, IngresoTraslado:=TrasladoTendido) Then 'si ya tiene poliza aplicar update
                                        logResultado = True
                                    End If
                                End If
                            Else
                                If Generar(cat, ano, num, fecha:=fecha, IngresoTraslado:=TrasladoTendido) Then 'si no tiene poliza aplicar insert
                                    logResultado = True
                                End If
                            End If
                        Else
                            BorraPoliza(cat, ano, num)
                        End If

                    Else
                        MsgBox("The document won't  be recorded in the accounts." & vbNewLine & " Possible causes accounting period is closed or doesn't exist.")
                    End If
                Loop
                conecC.Close()
                conecC.Dispose()
                conecC = Nothing
                System.GC.Collect()
            End If
        End If

        Return logResultado
    End Function

    Private Function Regimen(ByVal cat As Integer, ByVal ano As Integer, ByVal num As Integer) As Byte
        Dim strSQL As String
        Dim COM As MySqlCommand
        MyCnn.CONECTAR = strConexion
        'Factura 36 Nacionalizacion o Exportacion
        '0 - Nacionalizacion (Factura)
        '1 - Exportacion (Factura)

        '0 Diferencia Precio (Nota Credito)
        '1 Devolucion (Nota Credito)
        '2 Otros (Nota Credito)

        '0 Proveedor (Cheque)
        '1 Caja Chica (Cheque)

        strSQL = vbNullString
        strSQL = strSQL & "SELECT HDoc_DR1_Cat FROM Dcmtos_HDR WHERE HDoc_Sis_Emp = " & Sesion.IdEmpresa & " AND HDoc_Doc_Cat = " & cat & " AND HDoc_Doc_Num = " & num & " AND HDoc_Doc_Ano = " & ano
        COM = New MySqlCommand(strSQL, CON)
        Regimen = COM.ExecuteScalar
    End Function

    Public Function UltimoNivle(ByVal Cuenta As String) As String
        Dim strSQL As String
        Dim conec As MySqlConnection
        Dim COM As MySqlCommand
        Dim strCuenta As String

        strSQL = " SELECT id_cuenta "
        strSQL &= " FROM " & cFunciones.ContaEmpresa & ".cuentas "
        strSQL &= " WHERE empresa = 12 AND pid = '{cuenta}'"
        strSQL = Replace(strSQL, "{cuenta}", Cuenta)

        conec = New MySqlConnection(strConexion)
        conec.Open()
        COM = New MySqlCommand(strSQL, conec)
        strCuenta = COM.ExecuteScalar
        conec.Close()
        conec.Dispose()
        conec = Nothing
        System.GC.Collect()
        Return strCuenta
    End Function

    Public Function FormatoDeCuenta(ByVal Dato As String, Optional Mascara As Boolean = True) As String
        Dim i As Integer
        Dim j As Integer
        Dim logLetra As Boolean = False
        Dim strLetra As String = ""
        Dim strTexto As String = ""

        'Quita espacios
        Dato = UCase(Replace(Dato, Space(1), vbNullString))
        logLetra = False
        For i = 1 To Len(Dato)
            strLetra = Mid(Dato, i, 1)
            Select Case strLetra
                Case "A" To "Z", 0 To 9
                    'Es una letra o un número
                    strLetra = IIf(Mascara, "X", strLetra)
                    logLetra = True
                    j = j + 1
                Case Else
                    'No permite más de un carácter como separador,
                    'tampoco que el separador esté al inicio
                    If logLetra Then
                        strLetra = "-"
                    Else
                        strLetra = vbNullString
                    End If
                    logLetra = False
            End Select
            strTexto = strTexto & strLetra
        Next
        'Si la cuenta no termina con una letra quita el último carácter
        If Not logLetra And (j > vbEmpty) Then
            strTexto = Microsoft.VisualBasic.Left(strTexto, Len(strTexto) - 1)
        End If
        FormatoDeCuenta = strTexto
    End Function

    Public Function AplicarFormatoDeCuenta(ByVal Dato As String, ByVal Formato As String) As String
        Dim i As Integer
        Dim intNivel As Integer
        Dim strDato As String
        Dim strFormato As String
        Dim strTexto As String
        Dim strParte As String
        Dim varParte As Object

        strDato = ExtraerNumeroDeCuenta(Dato)
        strFormato = FormatoDeCuenta(Formato)
        If Not ((strDato = vbNullString) Or (strFormato = vbNullString)) Then
            If InStr(1, strFormato, "-") = vbEmpty Then
                'No se encontró ningún separador
                strTexto = strDato
            Else
                varParte = Split(strFormato, "-")
                For i = vbEmpty To UBound(varParte)
                    If Not (strDato = vbNullString) Then
                        'Aun se tienen datos
                        If Not (strTexto = vbNullString) Then
                            'Agrega un separador al resultado
                            strTexto = strTexto & "-"
                        End If
                        If (Len(varParte(i)) > Len(strDato)) Then
                            'Es la última parte
                            strParte = strDato
                            strDato = vbNullString
                        Else
                            'Quita la parte correspondiente al nivel
                            strParte = Microsoft.VisualBasic.Left(strDato, Len(varParte(i)))
                            strDato = Microsoft.VisualBasic.Right(strDato, Len(strDato) - Len(strParte))
                        End If
                        'Agrega la parte correspondiente al resultado
                        strTexto = strTexto & strParte
                    End If
                Next
                If Not (strDato = vbNullString) Then
                    'La longitud del dato es mayor que la máscara
                    strTexto = vbNullString
                End If
            End If
            If Not (strTexto = vbNullString) Then
                intNivel = NivelesDeCuenta(strTexto)
                strParte = ExtraerDeCuenta(strFormato, intNivel)

                If Not (FormatoDeCuenta(strTexto) = strParte) Then
                    'No coincide con el formato de la cuenta para el nivel indicado
                    strTexto = vbNullString
                End If
            End If
        End If
        'Devuelve el resultado
        AplicarFormatoDeCuenta = strTexto
    End Function

    Public Function ExtraerNumeroDeCuenta(ByVal Dato As String) As String
        Dim i As Integer
        Dim strDato As String
        Dim strLetra As String
        Dim strTexto As String = STR_VACIO

        'Cambia a mayúsculas (para efectos de comparación) y quita los espacios
        strDato = Replace(UCase(Dato), Space(1), vbNullString)
        If Not (strDato = vbNullString) Then
            For i = 1 To Len(strDato)
                strLetra = Mid(strDato, i, 1)
                Select Case strLetra
                    Case "A" To "Z", 0 To 9
                        'Es una letra o número
                        strTexto = strTexto & strLetra
                End Select
            Next
        End If

        'Devuelve el resultado
        ExtraerNumeroDeCuenta = strTexto
    End Function

    Public Function ExtraerDeCuenta(ByVal Formato As String, Optional Niveles As Integer = (-1)) As String
        Dim strFormato As String
        Dim strTexto As String
        Dim strLetra As String
        Dim n As Integer
        Dim i As Integer
        Dim j As Integer
        Dim k As Integer

        'Inicializar
        strTexto = vbNullString
        strFormato = FormatoDeCuenta(Formato, False)

        If Not (strFormato = vbNullString) Then
            n = NivelesDeCuenta(strFormato)
            If (Niveles <= vbEmpty) Then
                j = (n - (Niveles * (-1)))
            Else
                j = Niveles
            End If
            If (j > vbEmpty) And (j <= n) Then
                'Niveles es mayor que cero y menor o igual al máximo
                If j = n Then
                    strTexto = strFormato
                ElseIf Not (strFormato = vbNullString) Then
                    'Si es un formato válido, continuar con la extracción
                    k = 1
                    For i = 1 To Len(strFormato)
                        strLetra = Mid(strFormato, i, 1)
                        If (strLetra = "-") Then
                            k = k + 1
                        End If
                        If Not (k > j) Then
                            strTexto = strTexto & strLetra
                        Else
                            'Se ha llegado a los niveles solicitados
                            Exit For
                        End If
                    Next
                End If
            End If
        End If
        ExtraerDeCuenta = strTexto
    End Function

    Public Function NivelesDeCuenta(ByVal Dato As String) As Integer
        Dim strTexto As String
        Dim strLetra As String
        Dim i As Integer
        Dim n As Integer
        'Da formato al texto recibido
        strTexto = FormatoDeCuenta(Dato)
        n = vbEmpty
        If Not (strTexto = vbNullString) Then
            'Si el texto no está vacío tiene al menos un nivel
            n = n + 1
            For i = 1 To Len(strTexto)
                strLetra = Mid(strTexto, i, 1)
                If (strLetra = "-") Then
                    'Si es un separador incementa el contador
                    n = n + 1
                End If
            Next
        End If
        'Devuelve el resultado

        NivelesDeCuenta = n
    End Function

    Public Function MascaraDeNivel(ByVal Formato As String, Nivel As Integer, Optional ByVal Letra As String = "X") As String
        Dim varDato As Object
        Dim strDato As String

        If InStr(1, Formato, "-") > vbEmpty Then
            varDato = Split(Formato, "-")
            If UBound(varDato) >= (Nivel - 1) Then
                strDato = varDato(Nivel - 1)
                If Not (Letra = "X") Then
                    strDato = Replace(strDato, "X", Letra)
                End If
            End If
        End If
        MascaraDeNivel = strDato
    End Function

    Public Function CuentaHijaSuperior(ByVal Dato As String) As String
        Dim strDato As String
        Dim i As Integer


        i = NivelesDeCuenta(AplicarFormatoDeCuenta(Dato, strMascara))

        strDato = MascaraDeNivel(strMascara, i + 1, "9")
        CuentaHijaSuperior = Dato & strDato
    End Function

    'Genera el codigo Contable para Clientes, Proveedores, Bancos y Articulos
    Public Function CodigoConta(ByVal Tabla As String, ByVal Operacion As String, Optional Codigo As String = STR_VACIO, Optional Nombre As String = STR_VACIO, Optional NIT As String = STR_VACIO, Optional ID As Integer = NO_FILA, Optional Tipo As Integer = INT_CERO, Optional padre As Integer = NO_FILA, Optional ctaNomenclatura As String = "0") As String
        Dim strSQL As String = STR_VACIO
        Const proCuenta As Byte = vbEmpty
        Dim Cuenta As String
        Dim Empresa As String
        Dim Valor As String
        Dim Valor2 As String
        Dim Parametro As Integer
        Dim Tipo_Saldo As String = STR_VACIO
        Dim Tipo_Cuenta As Integer
        Dim Titulo As String
        Dim x2 As String
        Dim strCuentaContable As String = STR_VACIO
        Dim Ident As String
        Dim strMax As String = STR_VACIO
        Dim i As Integer
        Dim SubMascara As String = STR_VACIO
        Dim conec As MySqlConnection
        Dim COM As MySqlCommand
        Dim COM1 As MySqlCommand

        Select Case Tabla
            Case "Clientes"
                Cuenta = "cli_cuenta"
                Empresa = "cli_sisemp"
                Parametro = 23
                Tipo_Saldo = "D"
                Tipo_Cuenta = 1
                Titulo = "Cliente"
                Ident = "cli_codigo"
            Case "Proveedores"
                Select Case Tipo
                    Case proCuenta
                        Cuenta = "pro_cuenta"
                        Empresa = "pro_sisemp"
                        If (Sesion.IdEmpresa = 12) Or (Sesion.IdEmpresa = 14) Then
                            If padre = 0 Then
                                Parametro = 24
                            Else
                                Parametro = 51
                            End If
                        Else
                            If padre = 1 Then
                                Parametro = 24
                            Else
                                Parametro = 51
                            End If
                        End If
                        Tipo_Saldo = "A"
                        Tipo_Cuenta = 3
                        Titulo = "Proveedor"
                        Ident = "pro_codigo"
                End Select
        End Select
        If (Operacion = "Nuevo") Or (Codigo = vbNullString) Then
            ' Cuenta Padre 

            strSQL = "SELECT valor FROM {conta}.parametros_empresa WHERE empresa={empresa} AND parametro={parametro}"
            strSQL = Replace(strSQL, "{conta}", cFunciones.ContaEmpresa)
            strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
            strSQL = Replace(strSQL, "{parametro}", 2)

            conec = New MySqlConnection(strConexion)
            conec.Open()
            COM = New MySqlCommand(strSQL, conec)
            SubMascara = COM.ExecuteScalar
            conec.Close()
            conec.Dispose()
            conec = Nothing
            System.GC.Collect()


            strMascara = FormatoDeCuenta(SubMascara)
            intNiveles = NivelesDeCuenta(strMascara)


            strSQL = "SELECT valor FROM {conta}.parametros_empresa WHERE empresa={empresa} AND parametro={parametro}"
            strSQL = Replace(strSQL, "{conta}", cFunciones.ContaEmpresa)
            strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
            strSQL = Replace(strSQL, "{parametro}", Parametro)

            conec = New MySqlConnection(strConexion)
            conec.Open()
            COM = New MySqlCommand(strSQL, conec)
            Valor = COM.ExecuteScalar
            conec.Close()
            conec.Dispose()
            conec = Nothing
            System.GC.Collect()
            If Not (Valor = vbNullString) Then
                strMax = CuentaHijaSuperior(Valor)
            End If
            If Sesion.IdEmpresa = 11 Or Sesion.IdEmpresa = 14 Then
                strSQL = "SELECT IFNULL(MAX(a.id_cuenta),0) FROM {conta}.cuentas a LEFT JOIN {conta}.cuentas b ON b.empresa=a.empresa AND b.id_cuenta=LPAD((a.id_cuenta+1)," & 13 & ",'0') WHERE a.empresa = " & Sesion.IdEmpresa & " AND a.pid = " & "'" & (Valor) & "'" & " AND LENGTH(a.id_cuenta)=" & 13 & " AND ISNULL(b.id_cuenta)"
            Else
                strSQL = "SELECT IFNULL(MAX(a.id_cuenta),0) FROM {conta}.cuentas a LEFT JOIN {conta}.cuentas b ON b.empresa=a.empresa AND b.id_cuenta=LPAD((a.id_cuenta+1)," & Len(strMax) & ",'0') WHERE a.empresa = " & Sesion.IdEmpresa & " AND a.pid = " & "'" & (Valor) & "'" & " AND LENGTH(a.id_cuenta)=" & Len(strMax) & " AND ISNULL(b.id_cuenta)"
            End If

            strSQL = Replace(strSQL, "{conta}", cFunciones.ContaEmpresa)
            conec = New MySqlConnection(strConexion)
            conec.Open()
            COM1 = New MySqlCommand(strSQL, conec)
            x2 = COM1.ExecuteScalar
            conec.Close()
            conec.Dispose()
            conec = Nothing
            System.GC.Collect()
            If x2 = 0 Then
                CodigoConta = Valor & "001"
            Else
                CodigoConta = "0" & (x2 + 1)
            End If

        ElseIf Operacion = "Guardar" Then


            strSQL = "SELECT valor FROM {conta}.parametros_empresa WHERE empresa={empresa} AND parametro={parametro}"
            strSQL = Replace(strSQL, "{conta}", cFunciones.ContaEmpresa)
            strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
            strSQL = Replace(strSQL, "{parametro}", Parametro)

            conec = New MySqlConnection(strConexion)
            conec.Open()
            COM = New MySqlCommand(strSQL, conec)
            Valor2 = COM.ExecuteScalar
            conec.Close()
            conec.Dispose()
            conec = Nothing
            System.GC.Collect()

            strSQL = "SELECT valor FROM {conta}.parametros_empresa WHERE empresa={empresa} AND parametro={parametro}"
            strSQL = Replace(strSQL, "{conta}", cFunciones.ContaEmpresa)
            strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
            strSQL = Replace(strSQL, "{parametro}", 2)

            conec = New MySqlConnection(strConexion)
            conec.Open()
            COM = New MySqlCommand(strSQL, conec)
            SubMascara = COM.ExecuteScalar
            conec.Close()
            conec.Dispose()
            conec = Nothing
            System.GC.Collect()

            strMascara = FormatoDeCuenta(SubMascara)
            intNiveles = NivelesDeCuenta(strMascara)

            i = NivelesDeCuenta(AplicarFormatoDeCuenta(Codigo, SubMascara))
            i = Len(ExtraerNumeroDeCuenta(ExtraerDeCuenta(SubMascara, i - 1)))
            Valor = Left(Codigo, i)

            strSQL = " SELECT id_cuenta FROM {conta}.cuentas "
            strSQL &= " WHERE empresa = {empresa} AND pid = {valor} AND id_cuenta = {codigo}"
            strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
            strSQL = Replace(strSQL, "{conta}", cFunciones.ContaEmpresa)
            strSQL = Replace(strSQL, "{valor}", "'" & Valor2 & "'")
            strSQL = Replace(strSQL, "{codigo}", "'" & Codigo & "'")

            conec = New MySqlConnection(strConexion)
            conec.Open()
            COM = New MySqlCommand(strSQL, conec)
            strCuentaContable = COM.ExecuteScalar
            conec.Close()
            conec.Dispose()
            conec = Nothing
            System.GC.Collect()

            If strCuentaContable <> vbNullString Then
                Exit Function
            Else
                GuardarCuenta("Nuevo", Codigo, Nombre, Tipo_Saldo, Valor2, Tipo_Cuenta, NIT, ID, ctaNomenclatura)
            End If

        End If
        Return CodigoConta
    End Function

    Public Function GuardarCuenta(ByVal Operacion As String, ByVal CodigoCuenta As String, ByVal Nombre As String, ByVal TipoSaldo As String, ByVal Valor As String, ByVal TipoCuenta As Integer, ByVal NIT As String, ByVal ID As Integer, ByVal cta As String) As Boolean
        Dim cuenta As New Tablas.TCUENTAS
        Dim logResultado As Boolean = True
        cuenta.CONEXION = strConexion

        Try
            cuenta.ID_CUENTA = CodigoCuenta
            cuenta.EMPRESA = Sesion.IdEmpresa
            cuenta.EJERCICIO = 0
            cuenta.NOMBRE = Nombre
            cuenta.DESCRIPCION = STR_VACIO
            cuenta.TIPO_SALDO = TipoSaldo
            cuenta.AGRUP_NODEDUC = 0
            cuenta.PID = Valor
            cuenta.PEM = 1
            cuenta.TIPO_CUENTA = TipoCuenta
            cuenta.CONT_NIT = NIT
            cuenta.CODIGO = ID
            If cta = vbNullString Then
                cuenta.ID_NOMENCLATURA = "0"
            Else
                cuenta.ID_NOMENCLATURA = cta
            End If

            If Operacion = "Nuevo" Then
                If cuenta.PINSERT = False Then
                    MsgBox(cuenta.MERROR.ToString & "Could not save this document", MsgBoxStyle.Critical)
                    Return False
                    Exit Function
                Else
                    logResultado = True
                End If
            ElseIf Operacion = "Actualizar" Then
                If cuenta.PUPDATE = False Then
                    MsgBox(cuenta.MERROR.ToString & "Could not modify this document", MsgBoxStyle.Critical)
                    Return False
                    Exit Function
                Else
                    logResultado = True
                End If
            End If

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        Return logResultado
    End Function

#End Region

#Region "variables y costantes Bancos"
    Const NO_EXISTE_G = 7
    Const NO_EXISTE_SG = 10
    Dim Grupo As Integer = NO_EXISTE_G
    Dim SubGrupo As Integer = NO_EXISTE_SG
#End Region

#Region "bancos"

    Private Function ConceptoBancos(ByVal cat As Integer, ByVal ano As Integer, ByVal num As Integer) As String
        Dim strConcepto As String = STR_VACIO
        Dim strSQL As String
        Dim REA As MySqlDataReader
        Dim COM As MySqlCommand



        strSQL = vbNullString & "SELECT c.cat_desc Documento, h.HDoc_DR1_Num Numero, h.HDoc_Doc_Fec Fecha, IF(h.HDoc_Emp_Nom='', h.HDoc_Emp_Per, h.HDoc_Emp_Nom) Beneficiario "
        strSQL = strSQL & "         FROM Dcmtos_HDR h "
        strSQL = strSQL & "         LEFT JOIN Catalogos c ON c.cat_num = h.HDoc_Doc_Cat "
        strSQL = strSQL & "      WHERE h.HDoc_Sis_Emp = " & Sesion.IdEmpresa & " AND h.HDoc_Doc_Cat = " & cat & " AND h.HDoc_Doc_Ano = " & ano & " AND h.HDoc_Doc_Num = " & num

        Try
            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSQL, CON)
            REA = COM.ExecuteReader
            If REA.HasRows Then
                REA.Read()

                Select Case Grupo
                    Case 0 ' gGrupos.Proveedores
                        Select Case SubGrupo
                            Case 0 'sgProveedores.Pago : 
                                strConcepto = REA.GetString("Documento") & " #" & REA.GetString("Numero") & " Fecha: " & REA.GetMySqlDateTime("Fecha").ToString & " - " & REA.GetString("Beneficiario") & " (Pago)"
                            Case 1 'sgProveedores.Impuesto : 
                                strConcepto = REA.GetString("Documento") & " #" & REA.GetString("Numero") & " Fecha: " & REA.GetMySqlDateTime("Fecha").ToString & " - " & REA.GetString("Beneficiario") & "  (Impuesto)"
                            Case 2 ' sgProveedores.Anticipo : 
                                strConcepto = REA.GetString("Documento") & " #" & REA.GetString("Numero") & " Fecha: " & REA.GetMySqlDateTime("Fecha").ToString & " - " & REA.GetString("Beneficiario") & "  (Anticipo sobre Compras)"
                            Case 3  'sgProveedores.Gasto: 
                                strConcepto = REA.GetString("Documento") & " #" & REA.GetString("Numero") & " Fecha: " & REA.GetMySqlDateTime("Fecha").ToString & " - " & REA.GetString("Beneficiario") & "  (Gastos)"
                        End Select
                        'Case gGrupos.Caja
                        '    Select Case SubGrupo
                        '        Case sgCaja.Liquidacion : strConcepto = yRst!Documento & " #" & yRst!Numero & " Fecha: " & yRst!Fecha & " - " & yRst!Beneficiario & " (Liquidacion Caja)"
                        '        Case sgCaja.Apertura : strConcepto = yRst!Documento & " #" & yRst!Numero & " Fecha: " & yRst!Fecha & " - " & yRst!Beneficiario & " (Apertura Caja)"
                        '        Case sgCaja.Anticipo : strConcepto = yRst!Documento & " #" & yRst!Numero & " Fecha: " & yRst!Fecha & " - " & yRst!Beneficiario & " (Anticipo Caja)"
                        '        Case sgCaja.Cierre : strConcepto = yRst!Documento & " #" & yRst!Numero & " Fecha: " & yRst!Fecha & " - " & yRst!Beneficiario & " (Cierre Caja)"
                        '    End Select
                        'Case gGrupos.Clientes
                        '    Select Case SubGrupo
                        '        Case sgClientes.Descuento : strConcepto = yRst!Documento & " #" & yRst!Numero & " Fecha: " & yRst!Fecha & " - " & yRst!Beneficiario & " (Dscto Sobre Vntas)"
                        '        Case sgClientes.Cobro : strConcepto = yRst!Documento & " #" & yRst!Numero & " Fecha: " & yRst!Fecha & " - " & yRst!Beneficiario & " (Cobro)"
                        '    End Select
                        'Case gGrupos.Empleados
                        '    Select Case SubGrupo
                        '        Case sgEmpleados.Salario : strConcepto = yRst!Documento & " #" & yRst!Numero & " Fecha: " & yRst!Fecha & " - " & yRst!Beneficiario & " (Salario)"
                        '        Case sgEmpleados.Aguinaldo : strConcepto = yRst!Documento & " #" & yRst!Numero & " Fecha: " & yRst!Fecha & " - " & yRst!Beneficiario & " (Aguinaldo)"
                        '        Case sgEmpleados.Bono14 : strConcepto = yRst!Documento & " #" & yRst!Numero & " Fecha: " & yRst!Fecha & " - " & yRst!Beneficiario & " (Bono 14)"
                        '        Case sgEmpleados.Anticipo : strConcepto = yRst!Documento & " #" & yRst!Numero & " Fecha: " & yRst!Fecha & " - " & yRst!Beneficiario & " (Anticipo/Prestamo)"
                        '            'Case sgEmpleados.Prestamo: strConcepto = yRst!Documento & " #" & yRst!Numero & " Fecha: " & yRst!Fecha & " - " & yRst!Beneficiario & " (Prestamo)"
                        '        Case sgEmpleados.Devolucion : strConcepto = yRst!Documento & " #" & yRst!Numero & " Fecha: " & yRst!Fecha & " - " & yRst!Beneficiario & " (Devolucion Anticipo/Prestamo)"
                        '        Case sgEmpleados.Liquidacion : strConcepto = yRst!Documento & " #" & yRst!Numero & " Fecha: " & yRst!Fecha & " - " & yRst!Beneficiario & " (Liquidacion)"
                        '        Case sgEmpleados.Bonificacion : strConcepto = yRst!Documento & " #" & yRst!Numero & " Fecha: " & yRst!Fecha & " - " & yRst!Beneficiario & " (Bonificacion)"
                        '        Case sgEmpleados.Vacaciones : strConcepto = yRst!Documento & " #" & yRst!Numero & " Fecha: " & yRst!Fecha & " - " & yRst!Beneficiario & " (Vacaciones)"
                        '        Case sgEmpleados.Indemnizacion : strConcepto = yRst!Documento & " #" & yRst!Numero & " Fecha: " & yRst!Fecha & " - " & yRst!Beneficiario & " (Indemnización)"
                        '        Case sgEmpleados.ISR : strConcepto = yRst!Documento & " #" & yRst!Numero & " Fecha: " & yRst!Fecha & " - " & yRst!Beneficiario & " (Pago ISR)"
                        '    End Select
                        'Case gGrupos.Planilla
                        '    Select Case SubGrupo
                        '        Case sgPlanilla.Pago : strConcepto = yRst!Documento & " #" & yRst!Numero & " Fecha: " & yRst!Fecha & " - " & yRst!Beneficiario & " (Pago Planilla)"
                        '    End Select
                        'Case gGrupos.Transferencia
                        '    Select Case SubGrupo
                        '        Case sgTransferencia.Depositos : strConcepto = yRst!Documento & " #" & yRst!Numero & " Fecha: " & yRst!Fecha & " - (En tránsito)"
                        '        Case sgTransferencia.Gasto : strConcepto = yRst!Documento & " #" & yRst!Numero & " Fecha: " & yRst!Fecha & " - (Transferencia Contra Cuenta)"
                        '    End Select
                        'Case gGrupos.Impuestos
                        '    'TODO ISR
                        '    Select Case SubGrupo
                        '        Case sgImpuestos.IVAxPagar : strConcepto = yRst!Documento & " #" & yRst!Numero & " Fecha: " & yRst!Fecha & " - " & yRst!Beneficiario & " (Pago Iva)"
                        '        Case sgImpuestos.ISR_Asalariados : strConcepto = yRst!Documento & " #" & yRst!Numero & " Fecha: " & yRst!Fecha & " - " & yRst!Beneficiario & " (Pago ISR Asalariados)"
                        '        Case sgImpuestos.ISR_Retenciones : strConcepto = yRst!Documento & " #" & yRst!Numero & " Fecha: " & yRst!Fecha & " - " & yRst!Beneficiario & " (Pago ISR Retenciones)"
                        '        Case sgImpuestos.ISR_Mensual : strConcepto = yRst!Documento & " #" & yRst!Numero & " Fecha: " & yRst!Fecha & " - " & yRst!Beneficiario & " (Pago ISR Retenciones)"
                        '    End Select
                End Select

            End If

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try

        Return strConcepto
    End Function

    Private Sub ObtenerGrupos(ByVal cat As Integer, ByVal ano As Integer, ByVal num As Integer)
        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader
        Dim strSQL As String = STR_VACIO


        strSQL = " SELECT IFNULL(HDoc_DR1_Cat," & NO_EXISTE_G & ") Grupo , IFNULL(HDoc_DR2_Cat," & NO_EXISTE_SG & ") SubGrupo FROM Dcmtos_HDR  "
        strSQL &= " WHERE HDoc_Sis_Emp = " & Sesion.IdEmpresa & " AND HDoc_Doc_Cat = " & cat & " AND HDoc_Doc_Ano = " & ano & " AND HDoc_Doc_Num = " & num
        Try
            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSQL, CON)
            REA = COM.ExecuteReader
            If REA.HasRows Then
                REA.Read()
                Grupo = REA.GetInt32("Grupo")
                SubGrupo = REA.GetInt32("SubGrupo")
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Function SqlProveedores(ByVal num As Integer, ByVal cat As Integer, ByVal ano As Integer) As String
        Dim strSQL As String

        strSQL = vbNullString

        Select Case SubGrupo
            Case 0 'pago
                strSQL = strSQL & " SELECT b.BCta_Mon MonedaBanco, b.BCta_Cuenta CuentaBanco, ROUND(h.HDoc_Doc_TC, 5) TasaBanco, ROUND(IF(h.HDoc_Doc_Mon = " & Divisa.Local.id & ", ROUND(h.HDoc_RF1_Dbl, 2), (ROUND(h.HDoc_Doc_TC, 5) * ROUND(h.HDoc_RF1_Dbl, 2))), 2) MontoTotalBanco, ROUND(d.DDoc_RF1_Dbl, 2) MontoParcialBanco, "
                strSQL = strSQL & "        h.HDoc_Emp_Cod idBeneficiario, p.pro_cuenta CuentaBeneficiario, IFNULL(h.HDoc_DR1_Emp, 0)  Multiple, "
                strSQL = strSQL & "        d.DDoc_Prd_Ref GastoBeneficiario, "
                strSQL = strSQL & "        IFNULL(f.HDoc_Emp_Cod, 0) idProveedor, IFNULL(z.pro_cuenta, d.DDoc_Prd_Ref) CuentaProveedor, f.HDoc_Doc_Num NumeroDocumento, IFNULL((ROUND(f.HDoc_Doc_TC, 5)),0) TasaDocumento, IFNULL(f.HDoc_Doc_Mon, 0) MonedaDocumento, ROUND(f.HDoc_RF1_Dbl, 2) MontoDocumento, "
                strSQL = strSQL & "        h.HDoc_Doc_Fec FechaDocumento, h.HDoc_Usuario UsuarioDocumento, IFNULL(h.HDoc_Emp_NIT,'') Presupuesto, h.HDoc_Ant_Com Anticipo "
                strSQL = strSQL & "     FROM Dcmtos_HDR h "
                strSQL = strSQL & "         LEFT JOIN Dcmtos_DTL d  ON d.DDoc_Sis_Emp = h.HDoc_Sis_Emp AND d.DDoc_Doc_Cat = h.HDoc_Doc_Cat AND d.DDoc_Doc_Ano = h.HDoc_Doc_Ano AND d.DDoc_Doc_Num = h.HDoc_Doc_Num "
                strSQL = strSQL & "         LEFT JOIN Dcmtos_HDR f  ON f.HDoc_Sis_Emp = d.DDoc_Sis_Emp AND f.HDoc_Doc_Cat = d.DDoc_RF1_Num AND f.HDoc_Doc_Ano = d.DDoc_RF2_Num AND f.HDoc_Doc_Num = d.DDoc_RF3_Num "
                strSQL = strSQL & "         LEFT JOIN CtasBcos b    ON b.BCta_Sis_Emp = h.HDoc_Sis_Emp AND b.BCta_Num = h.HDoc_RF1_Num "
                strSQL = strSQL & "         LEFT JOIN Proveedores p ON p.pro_sisemp = h.HDoc_Sis_Emp AND p.pro_codigo = h.HDoc_Emp_Cod "
                strSQL = strSQL & "         LEFT JOIN Proveedores z ON z.pro_sisemp = f.HDoc_Sis_Emp AND z.pro_codigo = f.HDoc_Emp_Cod "
            Case 1 ' sgProveedores.Impuesto
                strSQL = strSQL & " SELECT h.HDoc_Doc_Fec FechaDocumento, ROUND(h.HDoc_Doc_TC, 4) TasaBanco, ROUND(IF(h.HDoc_Doc_Mon = " & Divisa.Local.id & ", ROUND(h.HDoc_RF1_Dbl, 2), (ROUND(h.HDoc_Doc_TC, 4) * ROUND(h.HDoc_RF1_Dbl, 2))), 2) Total, h.HDoc_Usuario UsuarioDocumento, IFNULL(h.HDoc_DR1_Emp, 0)  Multiple, IFNULL(h.HDoc_Emp_NIT,'') Presupuesto "
                strSQL = strSQL & "     FROM Dcmtos_HDR h "
            Case 2 'sgProveedores.Anticipo
                strSQL = strSQL & " SELECT h.HDoc_Doc_Fec FechaDocumento, ROUND(h.HDoc_Doc_TC, 4) TasaBanco, ROUND(IF(h.HDoc_Doc_Mon = " & Divisa.Local.id & ", ROUND(h.HDoc_RF1_Dbl, 2), "
                strSQL = strSQL & "        (ROUND(h.HDoc_Doc_TC, 4) * ROUND(h.HDoc_RF1_Dbl, 2))), 2) Total, h.HDoc_Usuario UsuarioDocumento, IFNULL(h.HDoc_DR1_Emp, 0)  Multiple, p.pro_anticipos Cuenta, IFNULL(h.HDoc_Emp_NIT,'') Presupuesto "
                strSQL = strSQL & "     FROM Dcmtos_HDR h "
                strSQL = strSQL & "         LEFT JOIN Proveedores p ON p.pro_sisemp = h.HDoc_Sis_Emp AND p.pro_codigo = h.HDoc_Emp_Cod "
            Case 3 'sgProveedores.Gasto
                strSQL = strSQL & " SELECT h.HDoc_Doc_Fec FechaDocumento, ROUND(h.HDoc_Doc_TC, 4) TasaBanco, ROUND(IF(h.HDoc_Doc_Mon = " & Divisa.Local.id & ", ROUND(d.DDoc_RF1_Dbl, 2), "
                strSQL = strSQL & "        (ROUND(h.HDoc_Doc_TC, 4) * ROUND(d.DDoc_RF1_Dbl, 2))), 2) Total, h.HDoc_Usuario UsuarioDocumento, IFNULL(h.HDoc_DR1_Emp, 0)  Multiple, IFNULL(d.DDoc_Prd_Ref,0) Cuenta, IFNULL(h.HDoc_Emp_NIT,'') Presupuesto "
                strSQL = strSQL & "     FROM Dcmtos_HDR h "
                strSQL = strSQL & "         LEFT JOIN Dcmtos_DTL d ON d.DDoc_Sis_Emp = h.HDoc_Sis_Emp AND d.DDoc_Doc_Cat = h.HDoc_Doc_Cat AND d.DDoc_Doc_Ano = h.HDoc_Doc_Ano AND d.DDoc_Doc_Num = h.HDoc_Doc_Num "
            Case 4 ' sgProveedores.Pendiente
        End Select
        If Not (strSQL = vbNullString) Then strSQL = strSQL & " WHERE h.HDoc_Sis_Emp = " & Sesion.IdEmpresa & " AND h.HDoc_Doc_Cat = " & cat & " AND h.HDoc_Doc_Num = " & num & " AND h.HDoc_Doc_Ano = " & ano

        SqlProveedores = strSQL
    End Function

    Private Function EncabezadoCheque(ByVal cat As Integer, ByVal ano As Integer, ByVal num As Integer) As Boolean
        Dim logResultado As Boolean = False
        Dim longPoliza As Long = NuevaPoliza()
        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader
        Dim strSQl As String = STR_VACIO
        Dim cpo As New TPOLIZAS
        UltimaPoliza(longPoliza, EJERCICIO)
        ObtenerGrupos(cat, ano, num)
        strSQl = SqlProveedores(num, cat, ano)
        Try
            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSQl, CON)
            REA = COM.ExecuteReader
            If REA.HasRows Then
                REA.Read()
                cpo.EMPRESA = Sesion.IdEmpresa
                cpo.EJERCICIO = EJERCICIO
                cpo.POLIZA = longPoliza
                cpo.FECHA = REA.GetMySqlDateTime("FechaDocumento")
                cpo.TIPO = 14
                cpo.TIPO_CAMBIO = REA.GetDouble("TasaBanco")
                cpo.OBSERVACIONES = STR_VACIO
                cpo.OPERADOR = REA.GetString("UsuarioDocumento")
                cpo.ESTADO = 2
                cpo.MODO = 14
                cpo.TASA = REA.GetDouble("TasaBanco")
                cpo.REF_CICLO = ano
                cpo.REF_NUMERO = num
                cpo.REF_TIPO = cat
                cpo.CONCEPTO = ConceptoBancos(cat, ano, num)
                cpo.CONEXION = strConexion
                If cpo.Guardar = True Then
                    If ChequeClasificarDetalle(cat, ano, num, longPoliza) Then
                        logResultado = True
                    End If

                Else
                    MsgBox(cpo.MERROR.ToString)
                End If
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try

        Return logResultado
    End Function

    Private Sub LineaDelBanco(ByVal cat As Integer, ByVal ano As Integer, ByVal num As Integer, ByVal poliza As Long)
        Dim strsql As String = STR_VACIO
        Dim COM As MySqlCommand

        strsql = " INSERT INTO {conta}.detalle_polizas  "
        strsql &= " SELECT  "
        strsql &= "   0 transaccion, {empresa} empresa, {ejercicio} ejercicio, {poliza} poliza, 1 item, b.BCta_Cuenta Cuenta, 1 parametro_cuenta,    "
        strsql &= "   ROUND(IF(h.HDoc_Doc_Mon = {ext}, (ROUND(h.HDoc_RF1_Dbl, 2) * ROUND(h.HDoc_Doc_TC, 5)), ROUND(h.HDoc_RF1_Dbl, 2)),2) importe,   "
        strsql &= "   '' centro_costos, IFNULL(h.HDoc_Emp_NIT, '') partida_presupuestal, '{operacion}' operacion, h.HDoc_Doc_Fec  fecha, '' clase, {modo} modo,    "
        strsql &= "   h.HDoc_Doc_Cat ref_tipo, h.HDoc_Doc_Ano ref_ciclo, h.HDoc_Doc_Num ref_numero, 0 ref_id   "
        strsql &= " FROM Dcmtos_HDR h     "
        strsql &= "  LEFT JOIN CtasBcos b ON b.BCta_Sis_Emp = h.HDoc_Sis_Emp AND b.BCta_Num = h.HDoc_RF1_Num    "
        strsql &= " WHERE h.HDoc_Sis_Emp = {empresa} AND h.HDoc_Doc_Cat = {cat} AND h.HDoc_Doc_Num = {num} AND h.HDoc_Doc_Ano = {ano} "

        If Sesion.IdEmpresa = 18 Then
            strsql &= ";INSERT INTO contapdm.detalle_polizas  "
            strsql &= " SELECT  "
            strsql &= "   0 transaccion, {empresa} empresa, {ejercicio} ejercicio, {poliza} poliza, 1 item, b.BCta_Cuenta Cuenta, 1 parametro_cuenta,    "
            strsql &= "   ROUND(IF(h.HDoc_Doc_Mon = {ext}, (ROUND(h.HDoc_RF1_Dbl, 2) * ROUND(h.HDoc_Doc_TC, 5)), ROUND(h.HDoc_RF1_Dbl, 2)),2) importe,   "
            strsql &= "   '' centro_costos, IFNULL(h.HDoc_Emp_NIT, '') partida_presupuestal, '{operacion}' operacion, h.HDoc_Doc_Fec  fecha, '' clase, {modo} modo,    "
            strsql &= "   h.HDoc_Doc_Cat ref_tipo, h.HDoc_Doc_Ano ref_ciclo, h.HDoc_Doc_Num ref_numero, 0 ref_id   "
            strsql &= " FROM PDM.Dcmtos_HDR h     "
            strsql &= "  LEFT JOIN PDM.CtasBcos b ON b.BCta_Sis_Emp = h.HDoc_Sis_Emp AND b.BCta_Num = h.HDoc_RF1_Num    "
            strsql &= " WHERE h.HDoc_Sis_Emp = {empresa} AND h.HDoc_Doc_Cat = {cat} AND h.HDoc_Doc_Num = {num} AND h.HDoc_Doc_Ano = {ano} "
        End If
        strsql = Replace(strsql, "{conta}", Sesion.BaseConta)
        strsql = Replace(strsql, "{ext}", Divisa.Externa.id)
        strsql = Replace(strsql, "{empresa}", Sesion.IdEmpresa)
        strsql = Replace(strsql, "{cat}", cat)
        strsql = Replace(strsql, "{num}", num)
        strsql = Replace(strsql, "{ano}", ano)
        strsql = Replace(strsql, "{ejercicio}", EJERCICIO)
        strsql = Replace(strsql, "{poliza}", poliza)
        strsql = Replace(strsql, "{operacion}", IIf(cat = 51 Or cat = 52, "A", "C"))
        strsql = Replace(strsql, "{modo}", IIf(cat = 51, 14, IIf(cat = 52, 15, IIf(cat = 53, 16, 17))))

        Try
            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strsql, CON)
            COM.ExecuteNonQuery()
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Function DetalleGasto(ByVal db As String, ByVal conta As String, ByVal cat As Integer, ByVal ano As Integer, ByVal num As Integer, ByVal poliza As Long) As Boolean
        Dim logResultado As Boolean = False

        Dim strsql As String = STR_VACIO
        Dim COM As MySqlCommand

        strsql = "  SET @c:=0; INSERT INTO {conta}.detalle_polizas  "
        strsql &= "  SELECT 0 transaccion, {empresa} empresa, {ejercicio} ejercicio, {poliza} poliza, (@c:=@c+1)item ,  IFNULL(d.DDoc_Prd_Ref,0) Cuenta, 1 parametro_cuenta,  "
        strsql &= "   ROUND(IF(h.HDoc_Doc_Mon = {loc}, ROUND(d.DDoc_RF1_Dbl, 2), (ROUND(h.HDoc_Doc_TC, 7) * ROUND(d.DDoc_RF1_Dbl, 2))), 2) importe, d.DDoc_Prd_PNr centro_costos, null , '{operacion}', h.HDoc_Doc_Fec fecha,    "
        strsql &= "   '' clase, {modo} modo, h.HDoc_Doc_Cat ref_tipo , h.HDoc_Doc_Ano ref_ciclo, h.HDoc_Doc_Num ref_numero , d.DDoc_Doc_Lin ref_id   "
        strsql &= " FROM {db}Dcmtos_HDR h      "
        strsql &= "   JOIN (SELECT @c:= (IFNULL((  "
        strsql &= "  SELECT MAX(item)    "
        strsql &= "  FROM {conta}.detalle_polizas dd    "
        strsql &= "  	WHERE dd.ref_tipo = {cat} AND dd.empresa = {empresa} AND dd.ref_ciclo = {ano} and dd.ref_numero = {num} ),0))  ) T"
        strsql &= " LEFT JOIN {db}Dcmtos_DTL d ON d.DDoc_Sis_Emp = h.HDoc_Sis_Emp AND d.DDoc_Doc_Cat = h.HDoc_Doc_Cat AND d.DDoc_Doc_Ano = h.HDoc_Doc_Ano AND d.DDoc_Doc_Num = h.HDoc_Doc_Num "
        strsql &= " WHERE h.HDoc_Sis_Emp = {empresa} AND h.HDoc_Doc_Cat = {cat} AND h.HDoc_Doc_Num = {num} AND h.HDoc_Doc_Ano = {ano} "

        strsql = Replace(strsql, "{loc}", Divisa.Local.id)
        strsql = Replace(strsql, "{conta}", conta)
        strsql = Replace(strsql, "{db}", db)
        strsql = Replace(strsql, "{empresa}", Sesion.IdEmpresa)
        strsql = Replace(strsql, "{cat}", cat)
        strsql = Replace(strsql, "{num}", num)
        strsql = Replace(strsql, "{ano}", ano)
        strsql = Replace(strsql, "{ejercicio}", EJERCICIO)
        strsql = Replace(strsql, "{poliza}", poliza)
        strsql = Replace(strsql, "{operacion}", IIf(cat = 51 Or cat = 52, "C", "A"))
        strsql = Replace(strsql, "{modo}", IIf(cat = 51, 14, IIf(cat = 52, 15, IIf(cat = 53, 16, 17))))

        Try
            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strsql, CON)
            COM.ExecuteNonQuery()
            logResultado = True
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try

        Return logResultado
    End Function

    Private Function DetalleGasto(ByVal cat As Integer, ByVal ano As Integer, ByVal num As Integer, ByVal poliza As Long) As Boolean
        Dim logResultado As Boolean = False
        Try
            If DetalleGasto(STR_VACIO, Sesion.BaseConta, cat, ano, num, poliza) Then
                If Sesion.IdEmpresa = 18 Then
                    DetalleGasto("PDM.", "contapdm", cat, ano, num, poliza)
                End If
            End If
            logResultado = True
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try

        Return logResultado
    End Function

    Private Function ChequeClasificarDetalle(ByVal cat As Integer, ByVal ano As Integer, ByVal num As Integer, ByVal poliza As Integer) As Boolean
        Dim logResultado As Boolean = False

        LineaDelBanco(cat, ano, num, poliza)
        Select Case Grupo
            Case 0 'proveedor
                Select Case SubGrupo
                    Case 0 'pago
                    Case 1 'impuesto
                    Case 2 'anticipo
                    Case 3 'gasto
                        If DetalleGasto(cat, ano, num, poliza) = True Then
                            logResultado = True
                        End If
                    Case NO_EXISTE_SG
                        Return logResultado
                        Exit Function


                End Select
            Case 1
            Case 2
            Case 3

        End Select












        Return logResultado
    End Function

#End Region

#Region "Facturas de Venta"

    Private Function FacturaImpresa(ByVal cat As Integer, ByVal ano As Integer, ByVal num As Integer) As Boolean
        Dim strSQL As String
        Dim COM As MySqlCommand
        strSQL = "SELECT HDoc_DR2_Cat FROM Dcmtos_HDR WHERE HDoc_Sis_Emp = " & Sesion.IdEmpresa & " AND HDoc_Doc_Cat = " & cat & " AND HDoc_Doc_Num = " & num & " AND HDoc_Doc_Ano = " & ano
        Try
            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSQL, CON)
            If COM.ExecuteScalar() > INT_CERO Then
                Return True
                Exit Function
            Else
                Return False
                Exit Function
            End If

        Catch ex As Exception
            MsgBox(ex.ToString)
            Return False
        End Try
    End Function

    Private Function sqlVentaEncabezado(ByVal cat As Integer, ByVal ano As Integer, ByVal num As Integer, ByVal poliza As Long, ByVal ejercicio As Integer, ByVal fec As Date)
        Dim strsql As String = STR_VACIO
        Dim intRegimen As Integer = INT_CERO
        Dim strConcepto As String = STR_VACIO

        'verfica si es nacionalizacion o exportacion
        intRegimen = Regimen(cat, ano, num)
        If intRegimen = INT_CERO Then ' nacionalizacion

            If Sesion.IdEmpresa = 12 Then
                strConcepto = " Para registrar ventas locales según factura: " & num & ", de Fecha:"
            Else
                strConcepto = " Para registrar ventas locales según factura:', " & "h.HDoc_DR1_Dbl" & ",', de Fecha: "
            End If

            'If (Sesion.IdEmpresa = 14) Or (Sesion.IdEmpresa = 15) Or (Sesion.IdEmpresa = 16) Or (Sesion.IdEmpresa = 18) Or (Sesion.IdEmpresa = 19) Or (Sesion.IdEmpresa = 20) Or (Sesion.IdEmpresa = 21) Then
            '    strConcepto = " Para registrar ventas locales según factura:', " & "h.HDoc_DR1_Dbl" & ",', de Fecha: "
            'Else
            '    strConcepto = " Para registrar ventas locales según factura: " & num & ", de Fecha:"
            'End If

            'strCliente = " Cliente Local "
        ElseIf intRegimen = INT_UNO Then ' exportacion

            If Sesion.IdEmpresa = 12 Then
                strConcepto = " Para registrar venta internacional, según factura: " & num & ", de Fecha: "
            Else
                strConcepto = " Para registrar venta internacional, según factura:', " & "h.HDoc_DR1_Dbl" & ", ', de Fecha:  "
            End If

            'If (Sesion.IdEmpresa = 14) Or (Sesion.IdEmpresa = 15) Or (Sesion.IdEmpresa = 16) Or (Sesion.IdEmpresa = 18) Or (Sesion.IdEmpresa = 19) Or (Sesion.IdEmpresa = 20) Or (Sesion.IdEmpresa = 21) Then
            '    strConcepto = " Para registrar venta internacional, según factura:', " & "h.HDoc_DR1_Dbl" & ", ', de Fecha:  "
            'Else
            '    strConcepto = " Para registrar venta internacional, según factura: " & num & ", de Fecha: "
            'End If

            'strCliente = "Cliente Exterior"
        End If
        strsql = " INSERT INTO {conta}.polizas  "
        strsql &= "     SELECT h.HDoc_Sis_Emp , {ejercicio}, {poliza}, '{fec}' , CONCAT('{concepto}',' ',h.HDoc_Doc_Fec ), 9, h.HDoc_Doc_TC , '', h.HDoc_Usuario , 'C', now(), '', 9,h.HDoc_Doc_Cat, h.HDoc_Doc_Ano , "


        strsql &= " h.HDoc_Doc_Num "

        strsql &= " , null, h.HDoc_Doc_TC , 0, null,null "

        strsql &= "         FROM Dcmtos_HDR h "
        strsql &= " WHERE h.HDoc_Sis_Emp = {empresa} and h.HDoc_Doc_Cat = {cat} and h.HDoc_Doc_Ano = {ano} and h.HDoc_Doc_Num = {num}; "

        If Sesion.IdEmpresa = 18 Then
            strsql &= " INSERT INTO contapdm.polizas  "
            strsql &= "     SELECT h.HDoc_Sis_Emp , {ejercicio}, {poliza}, '{fec}' , CONCAT('{concepto}',' ',h.HDoc_Doc_Fec ), 9, h.HDoc_Doc_TC , '', h.HDoc_Usuario , 'C', now(), '', 9,h.HDoc_Doc_Cat, h.HDoc_Doc_Ano , "


            strsql &= " h.HDoc_Doc_Num "

            strsql &= " , null, h.HDoc_Doc_TC , 0, null,null "

            strsql &= "         FROM PDM.Dcmtos_HDR h "
            strsql &= " WHERE h.HDoc_Sis_Emp = {empresa} and h.HDoc_Doc_Cat = {cat} and h.HDoc_Doc_Ano = {ano} and h.HDoc_Doc_Num = {num}; "
        End If


        strsql = Replace(strsql, "{conta}", cFunciones.ContaEmpresa)
        strsql = Replace(strsql, "{poliza}", poliza)
        strsql = Replace(strsql, "{ejercicio}", ejercicio)
        strsql = Replace(strsql, "{concepto}", strConcepto)
        strsql = Replace(strsql, "{empresa}", Sesion.IdEmpresa)
        strsql = Replace(strsql, "{cat}", cat)
        strsql = Replace(strsql, "{ano}", ano)
        strsql = Replace(strsql, "{num}", num)
        strsql = Replace(strsql, "{fec}", fec.ToString(FORMATO_MYSQL))
        Return strsql
    End Function

    Private Function sqlVentaDetalle(ByVal db As String, ByVal conta As String, ByVal cat As Integer, ByVal ano As Integer, ByVal num As Integer, ByVal poliza As Integer, ByVal ejercicio As Integer, ByVal dblDesc As Double)
        Dim strSQl As String = STR_VACIO
        Dim item As Integer = 1

        strSQl = "   INSERT INTO {conta}.detalle_polizas "

        strSQl &= "  SELECT 0,h.HDoc_Sis_Emp, {ejercicio}, {poliza}, {id},c.cli_cuenta, h.HDoc_DR1_Cat, ROUND(SUM(d.DDoc_Prd_QTY * d.DDoc_Prd_NET * h.HDoc_Doc_TC)-(ROUND((SUM(d.DDoc_Prd_DSQ * h.HDoc_Doc_TC)),2)),2) monto,
                     '' centroCosto, '' Partida_Pres, 'C', CAST(CURDATE() AS CHAR) fecha, IF(h.HDoc_DR1_Cat = 1,'Cliente Exterior', 'Cliente Local') clase, 9, h.HDoc_Doc_Cat, h.HDoc_Doc_Ano, h.HDoc_Doc_Num, 0 ref_id "
        strSQl &= "    From {db}Dcmtos_HDR h "
        strSQl &= "        Left JOIN {db}Clientes c ON c.cli_sisemp= h.HDoc_Sis_Emp AND c.cli_codigo = h.HDoc_Emp_Cod "
        strSQl &= "            Left JOIN {db}Dcmtos_DTL d ON d.DDoc_Sis_Emp = h.HDoc_Sis_Emp AND d.DDoc_Doc_Cat = h.HDoc_Doc_Cat AND d.DDoc_Doc_Ano = h.HDoc_Doc_Ano AND d.DDoc_Doc_Num = h.HDoc_Doc_Num "
        strSQl &= "                WHERE h.HDoc_Sis_Emp = {empresa} AND h.HDoc_Doc_Cat = {catalogo} AND h.HDoc_Doc_Ano = {ano} AND h.HDoc_Doc_Num ={numero} "



        strSQl = Replace(strSQl, "{id}", item)
        If dblDesc > 0 Then
            item = item + 1
            strSQl &= "                    UNION "
            strSQl &= "                        Select 0, h.HDoc_Sis_Emp empresa, {ejercicio}, {poliza},{id} item, IF(a.art_clase = 2306, '41010307',if(a.art_clase = 2906, '0501010', IFNULL(v.descuento,d.DDoc_Prd_Ref))) cuenta,0 parametroCuenta, 
        ROUND(SUM(d.DDoc_Prd_DSQ * h.HDoc_Doc_TC),2) importe, {centroCosto} centroCosto, '' partidaPresupuestal, 'C' operacion, CAST(CURDATE() AS CHAR) Fecha,0 clase, 9 modo, h.HDoc_Doc_Cat refTipo, h.HDoc_Doc_Ano refCiclo, h.HDoc_Doc_Num refNumero, 0 id "
            strSQl &= "                            From {db}Dcmtos_HDR h "
            strSQl &= "                            Left JOIN {db}Dcmtos_DTL d ON d.DDoc_Sis_Emp = h.HDoc_Sis_Emp AND d.DDoc_Doc_Ano= h.HDoc_Doc_Ano AND d.DDoc_Doc_Cat = h.HDoc_Doc_Cat AND d.DDoc_Doc_Num = h.HDoc_Doc_Num "
            strSQl &= "                            LEFT JOIN {db}Inventarios i ON i.inv_sisemp = d.DDoc_Sis_Emp AND i.inv_numero = d.DDoc_Prd_Cod "
            strSQl &= "                            LEFT JOIN {db}Articulos a ON a.art_sisemp = i.inv_sisemp AND a.art_codigo = i.inv_artcodigo "
            If Sesion.idGiro = 2 Then
                strSQl &= "                            LEFT JOIN {conta}.inventario_codigos v ON v.clase = a.art_clase AND v.empresa = a.art_sisemp AND (v.ejercicio = 0 OR v.ejercicio = 1) "
            Else
                strSQl &= "                             LEFT JOIN {db}Catalogos c ON c.cat_num = i.inv_lugarfab AND c.cat_clase ='Paises'"
                strSQl &= "                            Left JOIN {conta}.inventario_codigos v ON v.clase = c.cat_sisemp "
            End If
            strSQl &= "                                        WHERE h.HDoc_Sis_Emp = {empresa} AND h.HDoc_Doc_Cat = {catalogo} AND h.HDoc_Doc_Ano = {ano} AND h.HDoc_Doc_Num = {numero} "
            strSQl = Replace(strSQl, "{id}", item)
        End If

        If Sesion.IdEmpresa = 11 Then
            strSQl = Replace(strSQl, "{centroCosto}", " case when IFNULL(v.descuento,d.DDoc_Prd_Ref)='0402001014' then '12' when IFNULL(v.descuento,d.DDoc_Prd_Ref)='0402001015' then '12' when IFNULL(v.descuento,d.DDoc_Prd_Ref) ='0402002013 ' then '12' end ")
        ElseIf Sesion.IdEmpresa = 16 Then
            strSQl = Replace(strSQl, "{centroCosto}", " case when IFNULL(v.descuento,d.DDoc_Prd_Ref)='41010312' then '12' when IFNULL(v.descuento,d.DDoc_Prd_Ref)='41010313' then '12' when IFNULL(v.descuento,d.DDoc_Prd_Ref) ='41010402' then '12' end ")
        Else
            strSQl = Replace(strSQl, "{centroCosto}", "''")
        End If

        item = item + 1
        strSQl &= "                                            UNION "
        If Sesion.idGiro = 2 Then
            strSQl &= "                                                Select 0 transaccion,h.HDoc_Sis_Emp empresa, {ejercicio} ejercicio, {poliza} poliza, 2, IFNULL(v.VentaExport,d.DDoc_Prd_Ref) cuenta, h.HDoc_DR1_Cat parametro_cuenta, ROUND(SUM(d.DDoc_Prd_QTY * d.DDoc_Prd_NET * h.HDoc_Doc_TC),2) importe,'' centro_costos, '' partida_presupuestal, 'A' operacion, CAST(CURDATE() AS CHAR) fecha, a.art_clase clase, 9 modo, h.HDoc_Doc_Cat ref_tipo, h.HDoc_Doc_Ano ref_ciclo, h.HDoc_Doc_Num ref_numero, d.DDoc_Prd_Cod ref_id "
        Else
            strSQl &= "                                                Select 0 transaccion,h.HDoc_Sis_Emp empresa, {ejercicio} ejercicio, {poliza} poliza, 2, {contabilidad} cuenta, h.HDoc_DR1_Cat parametro_cuenta, ROUND(SUM(d.DDoc_Prd_QTY * d.DDoc_Prd_NET * h.HDoc_Doc_TC),2) importe,12 centro_costos, '' partida_presupuestal, 'A' operacion, CAST(CURDATE() AS CHAR) fecha, a.art_clase clase, 9 modo, h.HDoc_Doc_Cat ref_tipo, h.HDoc_Doc_Ano ref_ciclo, h.HDoc_Doc_Num ref_numero, d.DDoc_Prd_Cod ref_id "
        End If
        strSQl &= "                                                    From {db}Dcmtos_HDR h "
        strSQl &= "                                                Left JOIN {db}Dcmtos_DTL d ON d.DDoc_Sis_Emp = h.HDoc_Sis_Emp AND d.DDoc_Doc_Cat = h.HDoc_Doc_Cat AND d.DDoc_Doc_Ano = h.HDoc_Doc_Ano AND d.DDoc_Doc_Num = h.HDoc_Doc_Num "
        strSQl &= "                                            Left JOIN {db}Inventarios i ON i.inv_sisemp = d.DDoc_Sis_Emp AND i.inv_numero = d.DDoc_Prd_Cod "
        strSQl &= "                                        Left JOIN {db}Articulos a ON a.art_sisemp = i.inv_sisemp AND a.art_codigo = i.inv_artcodigo "
        If Sesion.idGiro = 2 Then
            strSQl &= "                            LEFT JOIN {conta}.inventario_codigos v ON v.clase = a.art_clase AND v.empresa = a.art_sisemp AND (v.ejercicio = 0 OR v.ejercicio = 1)"
        Else
            strSQl &= "                             LEFT JOIN {db}Catalogos c ON c.cat_num = i.inv_lugarfab AND c.cat_clase ='Paises'"
            strSQl &= "                            Left JOIN {conta}.inventario_codigos v ON v.clase = c.cat_sisemp "
            If Sesion.IdEmpresa = 14 Then
                strSQl = Replace(strSQl, "{contabilidad}", " IF( d.DDoc_Prd_Cod =0, '0403005' , IF(a.art_clase = 330, '41010401',IF(a.art_clase = 416, '0401008',v.venta))) ")
            Else
                strSQl = Replace(strSQl, "{contabilidad}", " IF(a.art_clase = 330, '41010401',IF(a.art_clase = 2306, '41010309',IF(a.art_clase = 416, '0401008',if(a.art_clase = 2906, '0401017', v.venta)))) ")
            End If

        End If
        strSQl &= "                                WHERE h.HDoc_Sis_Emp = {empresa} AND h.HDoc_Doc_Cat = {catalogo} AND h.HDoc_Doc_Ano = {ano} AND h.HDoc_Doc_Num ={numero} "
        strSQl &= "                             GROUP BY a.art_clase;"

        strSQl = Replace(strSQl, "{empresa}", Sesion.IdEmpresa)
        strSQl = Replace(strSQl, "{catalogo}", cat)
        strSQl = Replace(strSQl, "{ano}", ano)
        strSQl = Replace(strSQl, "{numero}", num)
        strSQl = Replace(strSQl, "{ejercicio}", ejercicio)
        strSQl = Replace(strSQl, "{poliza}", poliza)
        strSQl = Replace(strSQl, "{conta}", conta)
        strSQl = Replace(strSQl, "{db}", db)
        strSQl = Replace(strSQl, "{id}", item)

        Return strSQl

    End Function

    Private Function sqlVentaDetalle(ByVal cat As Integer, ByVal ano As Integer, ByVal num As Integer, ByVal poliza As Integer, ByVal ejercicio As Integer, ByVal dblDesc As Double)
        Dim strSQl As String = sqlVentaDetalle(STR_VACIO, cFunciones.ContaEmpresa, cat, ano, num, poliza, ejercicio, dblDesc)
        If Sesion.IdEmpresa = 18 Then
            strSQl = String.Concat(strSQl, sqlVentaDetalle("PDM.", "contapdm", cat, ano, num, poliza, ejercicio, dblDesc))
        End If
        Return strSQl
    End Function

    Private Function sqlVentaDetalleServi(ByVal db As String, ByVal conta As String, ByVal cat As Integer, ByVal ano As Integer, ByVal num As Integer, ByVal poliza As Integer, ByVal ejercicio As Integer, ByVal dblDesc As Double, ByVal tipoFact As Integer)
        Dim strSQl As String = STR_VACIO
        Dim item As Integer = 1

        strSQl = "   INSERT INTO {conta}.detalle_polizas "

        strSQl &= "  SELECT 0,h.HDoc_Sis_Emp, {ejercicio}, {poliza}, {id},c.cli_cuenta, h.HDoc_DR1_Cat, ROUND(SUM(d.DDoc_Prd_QTY * d.DDoc_Prd_NET * h.HDoc_Doc_TC)-(ROUND((SUM(d.DDoc_Prd_DSQ * h.HDoc_Doc_TC)),2)),2) monto,'' centroCosto, '' Partida_Pres, 'C', CAST(CURDATE() AS CHAR) fecha, IF(h.HDoc_DR1_Cat = 1,'Cliente Exterior', 'Cliente Local') clase, 9, h.HDoc_Doc_Cat, h.HDoc_Doc_Ano, h.HDoc_Doc_Num, 0 ref_id "
        strSQl &= "    From {db}Dcmtos_HDR h "
        strSQl &= "        Left JOIN {db}Clientes c ON c.cli_sisemp= h.HDoc_Sis_Emp AND c.cli_codigo = h.HDoc_Emp_Cod "
        strSQl &= "            Left JOIN {db}Dcmtos_DTL d ON d.DDoc_Sis_Emp = h.HDoc_Sis_Emp AND d.DDoc_Doc_Cat = h.HDoc_Doc_Cat AND d.DDoc_Doc_Ano = h.HDoc_Doc_Ano AND d.DDoc_Doc_Num = h.HDoc_Doc_Num "
        strSQl &= "                WHERE h.HDoc_Sis_Emp = {empresa} AND h.HDoc_Doc_Cat = {catalogo} AND h.HDoc_Doc_Ano = {ano} AND h.HDoc_Doc_Num ={numero} "

        strSQl = Replace(strSQl, "{id}", item)
        item = item + 1
        strSQl &= "                        UNION " ' SEGUNDA LINEA QUE MUESTRA LA CUENTA DE IVA
        strSQl &= "                            Select 0,'{empresa}',{ejercicio},{poliza}," & item & " item, e.valor cuenta, 1 parametro_cuenta, ROUND((d.DDoc_Prd_Net * DDoc_Prd_QTY * h.HDoc_Doc_TC) - ((d.DDoc_Prd_Net * DDoc_Prd_QTY * h.HDoc_Doc_TC) {iva}),2) importe, '' centro_Costo, NULL partida_Presupuestal, 'A' operacion, h.HDoc_Doc_Fec, 0 clase, 9 modo, h.HDoc_Doc_Cat tipo, h.HDoc_Doc_Ano cilco, h.HDoc_Doc_Num num,0 id "
        strSQl &= "                                From {db}Dcmtos_HDR h "
        strSQl &= "                                    Left JOIN {db}Dcmtos_DTL d ON d.DDoc_Sis_Emp = h.HDoc_Sis_Emp AND d.DDoc_Doc_Cat = h.HDoc_Doc_Cat AND d.DDoc_Doc_Ano = h.HDoc_Doc_Ano AND d.DDoc_Doc_Num = h.HDoc_Doc_Num "
        'strSQl &= "                                        Left JOIN Dcmtos_IMP p ON p.MDoc_Sis_Emp = d.DDoc_Sis_Emp AND p.MDoc_Doc_Cat = d.DDoc_Doc_Cat AND p.MDoc_Doc_Ano = d.DDoc_Doc_Ano AND p.MDoc_Doc_Num = d.DDoc_Doc_Num "
        strSQl &= "                                            Left JOIN {conta}.parametros_empresa e ON e.empresa = d.DDoc_Sis_Emp AND e.parametro = 50"
        strSQl &= "                                                 WHERE h.HDoc_Sis_Emp = {empresa} AND h.HDoc_Doc_Cat = {catalogo} AND h.HDoc_Doc_Ano = {ano} AND h.HDoc_Doc_Num = {numero} "

        item = item + 1
        strSQl &= "                                            UNION "
        strSQl &= "                                                Select 0 transaccion,h.HDoc_Sis_Emp empresa, {ejercicio} ejercicio, {poliza} poliza, " & item & ", {cta} cuenta, h.HDoc_DR1_Cat parametro_cuenta, ROUND(SUM(d.DDoc_Prd_QTY * d.DDoc_Prd_NET * h.HDoc_Doc_TC) {iva},2) importe,'' centro_costos, '' partida_presupuestal, 'A' operacion, CAST(CURDATE() AS CHAR) fecha, {class} clase, 9 modo, h.HDoc_Doc_Cat ref_tipo, h.HDoc_Doc_Ano ref_ciclo, h.HDoc_Doc_Num ref_numero, d.DDoc_Prd_Cod ref_id "
        strSQl &= "                                                    From {db}Dcmtos_HDR h "
        strSQl &= "                                                Left JOIN {db}Dcmtos_DTL d ON d.DDoc_Sis_Emp = h.HDoc_Sis_Emp AND d.DDoc_Doc_Cat = h.HDoc_Doc_Cat AND d.DDoc_Doc_Ano = h.HDoc_Doc_Ano AND d.DDoc_Doc_Num = h.HDoc_Doc_Num "
        If tipoFact = 0 Then
            strSQl &= "                                            Left JOIN {db}Inventarios i ON i.inv_sisemp = d.DDoc_Sis_Emp AND i.inv_numero = d.DDoc_Prd_Cod "
            strSQl &= "                                        Left JOIN {db}Articulos a ON a.art_sisemp = i.inv_sisemp AND a.art_codigo = i.inv_artcodigo "
            strSQl &= "                                    Left JOIN {conta}.inventario_codigos v ON v.clase = a.art_clase AND v.empresa = a.art_sisemp "

            strSQl = Replace(strSQl, "{cta}", "v.venta")
            strSQl = Replace(strSQl, "{class}", "a.art_clase")
        Else
            strSQl &= "                             LEFT JOIN {conta}.parametros_empresa p ON p.empresa = h.HDoc_Sis_Emp AND p.parametro = 17 "
            strSQl = Replace(strSQl, "{cta}", "p.valor")
            strSQl = Replace(strSQl, "{class}", 0)
        End If
        strSQl &= "                                WHERE h.HDoc_Sis_Emp = {empresa} AND h.HDoc_Doc_Cat = {catalogo} AND h.HDoc_Doc_Ano = {ano} AND h.HDoc_Doc_Num ={numero} "
        If tipoFact = 0 Then
            strSQl &= "                             GROUP BY a.art_clase;"
        End If
        strSQl = Replace(strSQl, "{iva}", " / (((SELECT cat_sist IVA FROM {db}Catalogos c WHERE c.cat_clase = 'Impuestos' AND c.cat_clave ='IVA' AND c.cat_sisemp = {empresa})/100)+1) ")
        strSQl = Replace(strSQl, "{empresa}", Sesion.IdEmpresa)
        strSQl = Replace(strSQl, "{catalogo}", cat)
        strSQl = Replace(strSQl, "{ano}", ano)
        strSQl = Replace(strSQl, "{numero}", num)
        strSQl = Replace(strSQl, "{ejercicio}", ejercicio)
        strSQl = Replace(strSQl, "{poliza}", poliza)
        strSQl = Replace(strSQl, "{conta}", conta)
        strSQl = Replace(strSQl, "{db}", db)
        strSQl = Replace(strSQl, "{id}", item)

        Return strSQl

    End Function
    Private Function sqlVentaDetalleServi(ByVal cat As Integer, ByVal ano As Integer, ByVal num As Integer, ByVal poliza As Integer, ByVal ejercicio As Integer, ByVal dblDesc As Double, ByVal tipoFact As Integer)
        Dim strSQl As String = sqlVentaDetalleServi(STR_VACIO, cFunciones.ContaEmpresa, cat, ano, num, poliza, ejercicio, dblDesc, tipoFact)
        If Sesion.IdEmpresa = 18 Then
            strSQl = String.Concat(strSQl, sqlVentaDetalleServi("PDM.", "contapdm", cat, ano, num, poliza, ejercicio, dblDesc, tipoFact))
        End If
        Return strSQl
    End Function

    Private Function sqlVentaCostoEncabezado(ByVal cat As Integer, ByVal ano As Integer, ByVal num As Integer, ByVal poliza As Integer, ByVal ejercicio As Integer, ByVal fec As Date) As String
        Dim strsql As String = STR_VACIO
        Dim intRegimen As Integer = INT_CERO
        Dim strConcepto As String = STR_VACIO

        'verfica si es nacionalizacion o exportacion
        intRegimen = Regimen(cat, ano, num)
        If intRegimen = INT_CERO Then ' nacionalizacion

            If Sesion.IdEmpresa = 12 Then
                strConcepto = " Para registrar costo local según factura: " & num & ", de Fecha:"
            Else
                strConcepto = " Para registrar costo local según factura:', " & "h.HDoc_DR1_Dbl" & ",', de Fecha: "
            End If
            'If (Sesion.IdEmpresa = 14) Or (Sesion.IdEmpresa = 15) Or (Sesion.IdEmpresa = 16) Or (Sesion.IdEmpresa = 18) Or (Sesion.IdEmpresa = 19) Or (Sesion.IdEmpresa = 20) Or (Sesion.IdEmpresa = 21) Then
            '    strConcepto = " Para registrar costo local según factura:', " & "h.HDoc_DR1_Dbl" & ",', de Fecha: "
            'Else
            '    strConcepto = " Para registrar costo local según factura: " & num & ", de Fecha:"
            'End If
            'strCliente = " Cliente Local "
        ElseIf intRegimen = INT_UNO Then ' exportacion
            If Sesion.IdEmpresa = 12 Then
                strConcepto = " Para registrar costo internacional según factura: " & num & ", de Fecha:"
            Else
                strConcepto = " Para registrar costo internacional según factura:', " & "h.HDoc_DR1_Dbl" & ",', de Fecha: "
            End If
            'If (Sesion.IdEmpresa = 14) Or (Sesion.IdEmpresa = 15) Or (Sesion.IdEmpresa = 16) Or (Sesion.IdEmpresa = 18) Or (Sesion.IdEmpresa = 19) Or (Sesion.IdEmpresa = 20) Or (Sesion.IdEmpresa = 21) Then
            '    strConcepto = " Para registrar costo internacional según factura:', " & "h.HDoc_DR1_Dbl" & ",', de Fecha: "
            'Else
            '    strConcepto = " Para registrar costo internacional según factura: " & num & ", de Fecha:"
            'End If

            'strCliente = "Cliente Exterior"
        End If
        strsql = " INSERT INTO {conta}.polizas  "
        strsql &= "     SELECT h.HDoc_Sis_Emp , {ejercicio}, {poliza}, '{fec}' , CONCAT('{concepto}',h.HDoc_Doc_Fec),10, h.HDoc_Doc_TC , '', h.HDoc_Usuario , 'C', now(), '', 10,h.HDoc_Doc_Cat, h.HDoc_Doc_Ano , "
        strsql &= " h.HDoc_Doc_Num "

        strsql &= " ,null, h.HDoc_Doc_TC , 0, null,null "
        strsql &= "         FROM Dcmtos_HDR h "
        strsql &= " WHERE h.HDoc_Sis_Emp = {empresa} and h.HDoc_Doc_Cat = {cat} and h.HDoc_Doc_Ano = {ano} and h.HDoc_Doc_Num = {num} "

        If Sesion.IdEmpresa = 18 Then
            strsql &= "; INSERT INTO contapdm.polizas  "
            strsql &= "     SELECT h.HDoc_Sis_Emp , {ejercicio}, {poliza}, '{fec}' , CONCAT('{concepto}',h.HDoc_Doc_Fec),10, h.HDoc_Doc_TC , '', h.HDoc_Usuario , 'C', now(), '', 10,h.HDoc_Doc_Cat, h.HDoc_Doc_Ano , "
            strsql &= " h.HDoc_Doc_Num "

            strsql &= " ,null, h.HDoc_Doc_TC , 0, null,null "
            strsql &= "         FROM PDM.Dcmtos_HDR h "
            strsql &= " WHERE h.HDoc_Sis_Emp = {empresa} and h.HDoc_Doc_Cat = {cat} and h.HDoc_Doc_Ano = {ano} and h.HDoc_Doc_Num = {num} "

        End If

        strsql = Replace(strsql, "{conta}", cFunciones.ContaEmpresa)
        strsql = Replace(strsql, "{poliza}", poliza)
        strsql = Replace(strsql, "{ejercicio}", ejercicio)
        strsql = Replace(strsql, "{concepto}", strConcepto)
        strsql = Replace(strsql, "{empresa}", Sesion.IdEmpresa)
        strsql = Replace(strsql, "{cat}", cat)
        strsql = Replace(strsql, "{ano}", ano)
        strsql = Replace(strsql, "{num}", num)
        strsql = Replace(strsql, "{fec}", fec.ToString(FORMATO_MYSQL))
        Return strsql
    End Function
    Private Function sqlVentaCostoDetalle(ByVal db As String, ByVal conta As String, ByVal cat As Integer, ByVal ano As Integer, ByVal num As Integer, ByVal poliza As Integer, ByVal ejercicio As Integer, ByVal tipoproducto As String, Optional tendido As Integer = 0) As String
        Dim strSQL As String = STR_VACIO

        If tendido = 0 Then
            strSQL = " SET @REG:=0; INSERT INTO {conta}.detalle_polizas "
            strSQL &= " SELECT  l1.transac,  l1.empresa, l1.ejercicio, l1.poliza, (@REG := @REG + 1) item, IFNULL(l1.cuenta,''), l1.parametro_cuenta, {importe} importe, l1.centro_costos, IFNULL(l1.partida_presupuestal,''), l1.operacion, l1.fecha, l1.clase, l1.modo , l1.tipo, l1.ciclo, l1.num ,  l1.id "
            strSQL &= "   FROM ( "
            If Sesion.idGiro = 2 Then
                strSQL &= "     SELECT d.DDoc_Doc_Lin,  0 transac, h.HDoc_Sis_Emp empresa, {ejercicio} ejercicio, {poliza} poliza, @REG :=0, v.costoExport cuenta, 1 parametro_cuenta, '' centro_costos, '0' partida_presupuestal, 'C'operacion, h.HDoc_Doc_Fec fecha, a.art_clase clase, 10 modo , h.HDoc_Doc_Cat  tipo, h.HDoc_Doc_Ano ciclo, h.HDoc_Doc_Num num ,  i.inv_numero id, (SELECT IFNULL(dd.DDoc_Prd_QTY ,0)
                                FROM {db}Dcmtos_DTL_Pro p
                                LEFT JOIN {db}Dcmtos_DTL dd ON dd.DDoc_Sis_Emp = p.PDoc_Sis_Emp AND dd.DDoc_Doc_Cat = p.PDoc_Par_Cat AND dd.DDoc_Doc_Ano = p.PDoc_Par_Ano AND dd.DDoc_Doc_Num = p.PDoc_Par_Num AND dd.DDoc_Doc_Lin = p.PDoc_Par_Lin
                                WHERE p.PDoc_Sis_Emp = h.HDoc_Sis_Emp AND p.PDoc_Chi_Cat = h.HDoc_Doc_Cat AND p.PDoc_Chi_Ano = h.HDoc_Doc_Ano AND p.PDoc_Chi_Num = h.HDoc_Doc_Num AND p.PDoc_Chi_Lin = d.DDoc_Doc_Lin) cantidad , "
            Else
                strSQL &= "     SELECT d.DDoc_Doc_Lin,  0 transac, h.HDoc_Sis_Emp empresa, {ejercicio} ejercicio, {poliza} poliza, @REG :=0, {contabilidad} cuenta, 1 parametro_cuenta, 12 centro_costos, '0' partida_presupuestal, 'C'operacion, h.HDoc_Doc_Fec fecha, a.art_clase clase, 10 modo , h.HDoc_Doc_Cat  tipo, h.HDoc_Doc_Ano ciclo, h.HDoc_Doc_Num num ,  i.inv_numero id, d.DDoc_Prd_QTY cantidad , "
            End If
            strSQL &= "        ( SELECT IFNULL(dd.DDoc_Prd_NET,0) FROM {db}Dcmtos_DTL_Pro p"
            strSQL &= "             LEFT JOIN {db}Dcmtos_DTL_Pro t on t.PDoc_Sis_Emp = p.PDoc_Sis_Emp  and t.PDoc_Chi_Cat = p.PDoc_Par_Cat and t.PDoc_Chi_Ano = p.PDoc_Par_Ano and t.PDoc_Chi_Num = p.PDoc_Par_Num and t.PDoc_Chi_Lin = p.PDoc_Par_Lin and t.PDoc_Par_Cat = 47 "
            strSQL &= "                 LEFT JOIN {db}Dcmtos_DTL dd on dd.DDoc_Sis_Emp = t.PDoc_Sis_Emp and dd.DDoc_Doc_Cat = t.PDoc_Par_Cat and dd.DDoc_Doc_Ano = t.PDoc_Par_Ano and dd.DDoc_Doc_Num = t.PDoc_Par_Num and dd.DDoc_Doc_Lin = t.PDoc_Par_Lin  "
            strSQL &= "                      WHERE p.PDoc_Sis_Emp = h.HDoc_Sis_Emp and p.PDoc_Chi_Cat = h.HDoc_Doc_Cat and p.PDoc_Chi_Ano = h.HDoc_Doc_Ano and p.PDoc_Chi_Num = h.HDoc_Doc_Num  and p.PDoc_Chi_Lin = d.DDoc_Doc_Lin  )  costos,    "
            strSQL &= "                         (SELECT IFNULL(hp.HDoc_Doc_TC,0) from Dcmtos_DTL_Pro p  "
            strSQL &= "                              LEFT JOIN {db}Dcmtos_DTL_Pro t on t.PDoc_Sis_Emp = p.PDoc_Sis_Emp  and t.PDoc_Chi_Cat = p.PDoc_Par_Cat and t.PDoc_Chi_Ano = p.PDoc_Par_Ano and t.PDoc_Chi_Num = p.PDoc_Par_Num and t.PDoc_Chi_Lin = p.PDoc_Par_Lin and t.PDoc_Par_Cat = 47 "

            If Sesion.idGiro = 2 Then
                strSQL &= " LEFT JOIN {db}Dcmtos_HDR hp ON hp.HDoc_Sis_Emp = t.PDoc_Sis_Emp AND hp.HDoc_Doc_Cat = t.PDoc_Par_Cat AND hp.HDoc_Doc_Ano = t.PDoc_Par_Ano AND hp.HDoc_Doc_Num = t.PDoc_Par_Num "
            Else
                strSQL &= "                                  LEFT JOIN {db}Dcmtos_DTL_Pro i on i.PDoc_Sis_Emp = t.PDoc_Sis_Emp and i.PDoc_Chi_Cat = t.PDoc_Par_Cat  and i.PDoc_Chi_Ano = t.PDoc_Par_Ano and i.PDoc_Chi_Num = t.PDoc_Par_Num and i.PDoc_Chi_Lin = t.PDoc_Par_Lin  "
                strSQL &= "                                     LEFT JOIN {db}Dcmtos_HDR hp on hp.HDoc_Sis_Emp = i.PDoc_Sis_Emp and hp.HDoc_Doc_Cat = i.PDoc_Par_Cat and hp.HDoc_Doc_Ano = i.PDoc_Par_Ano and hp.HDoc_Doc_Num = i.PDoc_Par_Num  "
            End If
            strSQL &= "                         WHERE p.PDoc_Sis_Emp = h.HDoc_Sis_Emp and p.PDoc_Chi_Cat = h.HDoc_Doc_Cat and p.PDoc_Chi_Ano = h.HDoc_Doc_Ano and p.PDoc_Chi_Num = h.HDoc_Doc_Num and p.PDoc_Chi_Lin = d.DDoc_Doc_Lin  ) tasa "
            strSQL &= "                       FROM {db}Dcmtos_HDR h   "
            strSQL &= "                     LEFT JOIN {db}Dcmtos_DTL d on d.DDoc_Sis_Emp = h.HDoc_Sis_Emp and d.DDoc_Doc_Cat = h.HDoc_Doc_Cat and d.DDoc_Doc_Ano = h.HDoc_Doc_Ano and d.DDoc_Doc_Num = h.HDoc_Doc_Num "
            strSQL &= "                 LEFT JOIN {db}Inventarios i on i.inv_sisemp = d.DDoc_Sis_Emp and i.inv_numero = d.DDoc_Prd_Cod  "
            strSQL &= "             LEFT JOIN {db}Articulos a on a.art_sisemp = i.inv_sisemp and a.art_codigo = i.inv_artcodigo "
            If Sesion.idGiro = 2 Then
                strSQL &= "                            LEFT JOIN {conta}.inventario_codigos v ON v.clase = a.art_clase AND v.empresa = a.art_sisemp "
            Else
                strSQL &= "                             LEFT JOIN {db}Catalogos c ON c.cat_num = i.inv_lugarfab AND c.cat_clase ='Paises'"
                strSQL &= "                            Left JOIN {conta}.inventario_codigos v ON v.clase = c.cat_sisemp "
                strSQL = Replace(strSQL, "{contabilidad}", " IF(a.art_clase = 330, '51010401',IF(a.art_clase = 2306, '51010309',IF(a.art_clase = 416, '0501008', IF(a.art_clase = 3076, '0501013', if(a.art_clase = 2906, '0501010', v.costo))))) ")
            End If
            strSQL &= "      WHERE h.HDoc_Sis_Emp = {empresa} and h.HDoc_Doc_Cat = {catalogo} and h.HDoc_Doc_Ano = {ano} and h.HDoc_Doc_Num ={numero} GROUP BY d.DDoc_Doc_Lin"
            strSQL &= " UNION "
            If Sesion.idGiro = 2 Then
                strSQL &= "     SELECT d.DDoc_Doc_Lin,  0 transac, h.HDoc_Sis_Emp empresa, {ejercicio} ejercicio, {poliza} poliza, @REG :=0, v.inventario  cuenta, 1 parametro_cuenta, '' centro_costos, '0' partida_presupuestal, 'A'operacion, h.HDoc_Doc_Fec fecha, a.art_clase clase, 10 modo , h.HDoc_Doc_Cat  tipo, h.HDoc_Doc_Ano ciclo, h.HDoc_Doc_Num num ,  i.inv_numero id, (SELECT IFNULL(dd.DDoc_Prd_QTY ,0)
                                FROM {db}Dcmtos_DTL_Pro p
                                LEFT JOIN {db}Dcmtos_DTL dd ON dd.DDoc_Sis_Emp = p.PDoc_Sis_Emp AND dd.DDoc_Doc_Cat = p.PDoc_Par_Cat AND dd.DDoc_Doc_Ano = p.PDoc_Par_Ano AND dd.DDoc_Doc_Num = p.PDoc_Par_Num AND dd.DDoc_Doc_Lin = p.PDoc_Par_Lin
                                WHERE p.PDoc_Sis_Emp = h.HDoc_Sis_Emp AND p.PDoc_Chi_Cat = h.HDoc_Doc_Cat AND p.PDoc_Chi_Ano = h.HDoc_Doc_Ano AND p.PDoc_Chi_Num = h.HDoc_Doc_Num AND p.PDoc_Chi_Lin = d.DDoc_Doc_Lin) cantidad , "
            Else
                strSQL &= "     SELECT d.DDoc_Doc_Lin,  0 transac, h.HDoc_Sis_Emp empresa, {ejercicio} ejercicio, {poliza} poliza, 1 item, {contabilidad}   cuenta, 1 parametro_cuenta, '' centro_costos, '0' partida_presupuestal, 'A'operacion, h.HDoc_Doc_Fec fecha, a.art_clase clase, 10 modo , h.HDoc_Doc_Cat  tipo, h.HDoc_Doc_Ano ciclo, h.HDoc_Doc_Num num ,  i.inv_numero id, d.DDoc_Prd_QTY cantidad ,  "
            End If

            strSQL &= "         ( SELECT IFNULL(dd.DDoc_Prd_NET,0) from Dcmtos_DTL_Pro p  "
            strSQL &= "              LEFT JOIN {db}Dcmtos_DTL_Pro t on t.PDoc_Sis_Emp = p.PDoc_Sis_Emp  and t.PDoc_Chi_Cat = p.PDoc_Par_Cat and t.PDoc_Chi_Ano = p.PDoc_Par_Ano and t.PDoc_Chi_Num = p.PDoc_Par_Num and t.PDoc_Chi_Lin = p.PDoc_Par_Lin and t.PDoc_Par_Cat = 47 "
            strSQL &= "                 LEFT JOIN {db}Dcmtos_DTL dd on dd.DDoc_Sis_Emp = t.PDoc_Sis_Emp and dd.DDoc_Doc_Cat = t.PDoc_Par_Cat and dd.DDoc_Doc_Ano = t.PDoc_Par_Ano and dd.DDoc_Doc_Num = t.PDoc_Par_Num and dd.DDoc_Doc_Lin = t.PDoc_Par_Lin   "
            strSQL &= "                     WHERE p.PDoc_Sis_Emp = h.HDoc_Sis_Emp and p.PDoc_Chi_Cat = h.HDoc_Doc_Cat and p.PDoc_Chi_Ano = h.HDoc_Doc_Ano and p.PDoc_Chi_Num = h.HDoc_Doc_Num  and p.PDoc_Chi_Lin = d.DDoc_Doc_Lin  )  costos,  "
            strSQL &= "                         (SELECT IFNULL(hp.HDoc_Doc_TC,0) from Dcmtos_DTL_Pro p    "
            strSQL &= "                             LEFT JOIN {db}Dcmtos_DTL_Pro t on t.PDoc_Sis_Emp = p.PDoc_Sis_Emp  and t.PDoc_Chi_Cat = p.PDoc_Par_Cat and t.PDoc_Chi_Ano = p.PDoc_Par_Ano and t.PDoc_Chi_Num = p.PDoc_Par_Num and t.PDoc_Chi_Lin = p.PDoc_Par_Lin and t.PDoc_Par_Cat = 47 "

            If Sesion.idGiro = 2 Then
                strSQL &= " LEFT JOIN {db}Dcmtos_HDR hp ON hp.HDoc_Sis_Emp = t.PDoc_Sis_Emp AND hp.HDoc_Doc_Cat = t.PDoc_Par_Cat AND hp.HDoc_Doc_Ano = t.PDoc_Par_Ano AND hp.HDoc_Doc_Num = t.PDoc_Par_Num "
            Else
                strSQL &= "                                 LEFT JOIN {db}Dcmtos_DTL_Pro i on i.PDoc_Sis_Emp = t.PDoc_Sis_Emp and i.PDoc_Chi_Cat = t.PDoc_Par_Cat  and i.PDoc_Chi_Ano = t.PDoc_Par_Ano and i.PDoc_Chi_Num = t.PDoc_Par_Num and i.PDoc_Chi_Lin = t.PDoc_Par_Lin  "
                strSQL &= "                                     LEFT JOIN {db}Dcmtos_HDR hp on hp.HDoc_Sis_Emp = i.PDoc_Sis_Emp and hp.HDoc_Doc_Cat = i.PDoc_Par_Cat and hp.HDoc_Doc_Ano = i.PDoc_Par_Ano and hp.HDoc_Doc_Num = i.PDoc_Par_Num  "
            End If
            strSQL &= "                                 WHERE p.PDoc_Sis_Emp = h.HDoc_Sis_Emp and p.PDoc_Chi_Cat = h.HDoc_Doc_Cat and p.PDoc_Chi_Ano = h.HDoc_Doc_Ano and p.PDoc_Chi_Num = h.HDoc_Doc_Num and p.PDoc_Chi_Lin = d.DDoc_Doc_Lin  ) tasa  "
            strSQL &= "                             FROM {db}Dcmtos_HDR h    "
            strSQL &= "  	                    LEFT JOIN {db}Dcmtos_DTL d on d.DDoc_Sis_Emp = h.HDoc_Sis_Emp and d.DDoc_Doc_Cat = h.HDoc_Doc_Cat and d.DDoc_Doc_Ano = h.HDoc_Doc_Ano and d.DDoc_Doc_Num = h.HDoc_Doc_Num   "
            strSQL &= "                     LEFT JOIN {db}Inventarios i on i.inv_sisemp = d.DDoc_Sis_Emp and i.inv_numero = d.DDoc_Prd_Cod  "
            strSQL &= "                 LEFT JOIN {db}Articulos a on a.art_sisemp = i.inv_sisemp and a.art_codigo = i.inv_artcodigo  "
            If Sesion.idGiro = 2 Then
                strSQL &= "                            LEFT JOIN {conta}.inventario_codigos v ON v.clase = a.art_clase AND v.empresa = a.art_sisemp "
            Else
                strSQL &= "                             LEFT JOIN {db}Catalogos c ON c.cat_num = i.inv_lugarfab AND c.cat_clase ='Paises'"
                strSQL &= "                            Left JOIN {conta}.inventario_codigos v ON v.clase = c.cat_sisemp "
                strSQL = Replace(strSQL, "{contabilidad}", " IF(a.art_clase = 330, '11050201',IF(a.art_clase = 2306, '11050107',IF(a.art_clase = 416, '0101003008', IF(a.art_clase = 3076, '0101003014', if (a.art_clase = 2906, '0101003010', v.inventario))))) ")
            End If
            strSQL &= "         WHERE h.HDoc_Sis_Emp = {empresa} and h.HDoc_Doc_Cat = {catalogo} and h.HDoc_Doc_Ano = {ano} and h.HDoc_Doc_Num ={numero} GROUP BY d.DDoc_Doc_Lin"
            strSQL &= " ) l1 "
            strSQL &= " GROUP BY l1.cuenta, l1.operacion "

            If tipoproducto = "Waste" Then
                strSQL = Replace(strSQL, "{importe}", "ROUND(SUM(ROUND((0.01 * l1.cantidad),4)),2)")
            Else
                strSQL = Replace(strSQL, "{importe}", "ROUND(SUM(ROUND((l1.costos * l1.cantidad * l1.tasa),4)),2)")
            End If
            strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
            strSQL = Replace(strSQL, "{catalogo}", cat)
            strSQL = Replace(strSQL, "{ano}", ano)
            strSQL = Replace(strSQL, "{numero}", num)
            strSQL = Replace(strSQL, "{conta}", conta)
            strSQL = Replace(strSQL, "{db}", db)
            strSQL = Replace(strSQL, "{poliza}", poliza)
            strSQL = Replace(strSQL, "{ejercicio}", ejercicio)
        ElseIf tendido = 1 Then
            strSQL = " INSERT INTO {conta}.detalle_polizas

                    Select  s1.transaccion, s1.empresa, s1.ejercicio, s1.poliza, (@REG := @REG + 1) item, IFNULL(s1.cuenta,''), s1.parametro_cuenta, s1.importe, centro_costos, IFNULL(s1.partida_presupuestal,''), s1.operacion, s1.fecha, IFNULL(s1.clase,''), s1.modo, s1.ref_tipo, s1.ref_ciclo, s1.ref_numero, s1.ref_id
                        FROM(
                        Select  0 transaccion, h.HDoc_Sis_Emp empresa, {ejercicio} ejercicio, {poliza} poliza, @REG :=0, v.CostoExport cuenta, h.HDoc_DR1_Cat parametro_cuenta, ROUND(SUM((d48.DDoc_Prd_QTY * d47.DDoc_Prd_NET) * h47.HDoc_Doc_TC),2) Importe,0 centro_costos, NULL partida_presupuestal, 'C' operacion, CAST(CURDATE() AS CHAR) fecha, a.art_clase clase, 10 modo, h.HDoc_Doc_Cat ref_tipo, h.HDoc_Doc_Ano ref_ciclo, h.HDoc_Doc_Num ref_numero, d.DDoc_Prd_Cod ref_id
                        From {db}Dcmtos_HDR h
                        LEFT JOIN {db}Dcmtos_DTL d ON d.DDoc_Sis_Emp = h.HDoc_Sis_Emp AND d.DDoc_Doc_Cat = h.HDoc_Doc_Cat AND d.DDoc_Doc_Ano = h.HDoc_Doc_Ano AND d.DDoc_Doc_Num = h.HDoc_Doc_Num
                        LEFT JOIN {db}Dcmtos_DTL_Pro p ON p.PDoc_Sis_Emp = d.DDoc_Sis_Emp AND p.PDoc_Chi_Cat = d.DDoc_Doc_Cat AND p.PDoc_Chi_Ano = d.DDoc_Doc_Ano AND p.PDoc_Chi_Num = d.DDoc_Doc_Num AND p.PDoc_Chi_Lin = d.DDoc_Doc_Lin AND p.PDoc_Par_Cat = 48
                        LEFT JOIN {db}Dcmtos_DTL_Pro p47 ON p47.PDoc_Sis_Emp = p.PDoc_Sis_Emp AND p47.PDoc_Chi_Cat = p.PDoc_Par_Cat AND p47.PDoc_Chi_Ano = p.PDoc_Par_Ano AND p47.PDoc_Chi_Num = p.PDoc_Par_Num AND p47.PDoc_Chi_Lin = p.PDoc_Par_Lin AND p47.PDoc_Par_Cat = 47 -- par 47 
                        LEFT JOIN {db}Dcmtos_DTL d48 ON d48.DDoc_Sis_Emp = p.PDoc_Sis_Emp AND d48.DDoc_Doc_Cat = p.PDoc_Par_Cat AND d48.DDoc_Doc_Ano = p.PDoc_Par_Ano AND d48.DDoc_Doc_Num = p.PDoc_Par_Num AND d48.DDoc_Doc_Lin = p.PDoc_Par_Lin                        
                        LEFT JOIN {db}Dcmtos_DTL d47 ON d47.DDoc_Sis_Emp = p47.PDoc_Sis_Emp AND d47.DDoc_Doc_Cat = p47.PDoc_Par_Cat AND d47.DDoc_Doc_Ano = p47.PDoc_Par_Ano AND d47.DDoc_Doc_Num = p47.PDoc_Par_Num AND d47.DDoc_Doc_Lin = p47.PDoc_Par_Lin
                        LEFT JOIN {db}Dcmtos_HDR h47 ON h47.HDoc_Sis_Emp = d47.DDoc_Sis_Emp AND h47.HDoc_Doc_Cat = d47.DDoc_Doc_Cat and h47.HDoc_Doc_Ano = d47.DDoc_Doc_Ano AND h47.HDoc_Doc_Num = d47.DDoc_Doc_Num                        
                        Left Join {db}Inventarios i ON i.inv_sisemp = d.DDoc_Sis_Emp And i.inv_numero = d.DDoc_Prd_Cod
                        Left Join {db}Articulos a ON a.art_sisemp = i.inv_sisemp And a.art_codigo = i.inv_artcodigo
                        Left Join {conta}.inventario_codigos v ON v.empresa = a.art_sisemp And v.clase = a.art_clase 
                    WHERE h.HDoc_Sis_Emp = {empresa} And h.HDoc_Doc_Cat = {cat} And h.HDoc_Doc_Ano = {anio} And h.HDoc_Doc_Num = {num}
                    GROUP BY a.art_clase
                    UNION

                SELECT 0 transaccion, h.HDoc_Sis_Emp empresa, {ejercicio} ejercicio, {poliza} poliza, @REG :=0, '110507998' cuenta, h.HDoc_DR1_Cat parametro_cuenta, ROUND(SUM((d48.DDoc_Prd_QTY * d47.DDoc_Prd_NET) * h47.HDoc_Doc_TC),2) Importe,0 centro_costos, NULL partida_presupuestal, 'A' operacion, CAST(CURDATE() AS CHAR) fecha, 0 clase, 10 modo, h.HDoc_Doc_Cat ref_tipo, h.HDoc_Doc_Ano ref_ciclo, h.HDoc_Doc_Num ref_numero, d.DDoc_Prd_Cod ref_id
                        From {db}Dcmtos_HDR h
                        LEFT JOIN {db}Dcmtos_DTL d ON d.DDoc_Sis_Emp = h.HDoc_Sis_Emp AND d.DDoc_Doc_Cat = h.HDoc_Doc_Cat AND d.DDoc_Doc_Ano = h.HDoc_Doc_Ano AND d.DDoc_Doc_Num = h.HDoc_Doc_Num
                        LEFT JOIN {db}Dcmtos_DTL_Pro p ON p.PDoc_Sis_Emp = d.DDoc_Sis_Emp AND p.PDoc_Chi_Cat = d.DDoc_Doc_Cat AND p.PDoc_Chi_Ano = d.DDoc_Doc_Ano AND p.PDoc_Chi_Num = d.DDoc_Doc_Num AND p.PDoc_Chi_Lin = d.DDoc_Doc_Lin AND p.PDoc_Par_Cat = 48
                        LEFT JOIN {db}Dcmtos_DTL_Pro p47 ON p47.PDoc_Sis_Emp = p.PDoc_Sis_Emp AND p47.PDoc_Chi_Cat = p.PDoc_Par_Cat AND p47.PDoc_Chi_Ano = p.PDoc_Par_Ano AND p47.PDoc_Chi_Num = p.PDoc_Par_Num AND p47.PDoc_Chi_Lin = p.PDoc_Par_Lin AND p47.PDoc_Par_Cat = 47 -- par 47 
                        LEFT JOIN {db}Dcmtos_DTL d48 ON d48.DDoc_Sis_Emp = p.PDoc_Sis_Emp AND d48.DDoc_Doc_Cat = p.PDoc_Par_Cat AND d48.DDoc_Doc_Ano = p.PDoc_Par_Ano AND d48.DDoc_Doc_Num = p.PDoc_Par_Num AND d48.DDoc_Doc_Lin = p.PDoc_Par_Lin                            
                        LEFT JOIN {db}Dcmtos_DTL d47 ON d47.DDoc_Sis_Emp = p47.PDoc_Sis_Emp AND d47.DDoc_Doc_Cat = p47.PDoc_Par_Cat AND d47.DDoc_Doc_Ano = p47.PDoc_Par_Ano AND d47.DDoc_Doc_Num = p47.PDoc_Par_Num AND d47.DDoc_Doc_Lin = p47.PDoc_Par_Lin
                        LEFT JOIN {db}Dcmtos_HDR h47 ON h47.HDoc_Sis_Emp = d47.DDoc_Sis_Emp AND h47.HDoc_Doc_Cat = d47.DDoc_Doc_Cat and h47.HDoc_Doc_Ano = d47.DDoc_Doc_Ano AND h47.HDoc_Doc_Num = d47.DDoc_Doc_Num
                    WHERE h.HDoc_Sis_Emp = {empresa} And h.HDoc_Doc_Cat = {cat} And h.HDoc_Doc_Ano = {anio} And h.HDoc_Doc_Num = {num})s1 "

            'strSql = Replace(strSql, "{tipoPoliza}", 33)

            strSQL = Replace(strSQL, "{ejercicio}", ejercicio)
            strSQL = Replace(strSQL, "{poliza}", poliza)
            strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
            strSQL = Replace(strSQL, "{cat}", cat)
            strSQL = Replace(strSQL, "{anio}", ano)
            strSQL = Replace(strSQL, "{num}", num)
            strSQL = Replace(strSQL, "{conta}", conta)
            strSQL = Replace(strSQL, "{db}", db)
            strSQL = Replace(strSQL, "{user}", Sesion.Usuario)
        End If

        Return strSQL
    End Function

    Private Sub PolizaVenta(ByVal cat As Integer, ByVal ano As Integer, ByVal num As Integer, ByVal fec As Date, Optional tipoFact As Integer = 0)
        Dim intRegimen As Integer = NO_FILA
        Dim strConcepto As String = STR_VACIO
        Dim strCliente As String = STR_VACIO
        Dim longPoliza As Long = NO_FILA
        Dim strSQl As String = STR_VACIO
        Dim strSQl2 As String = STR_VACIO
        Dim COM As MySqlCommand
        Dim COM2 As MySqlCommand
        Dim conec As MySqlConnection
        Dim dblDesc As Double
        Try

            If FacturaImpresa(cat, ano, num) Then

                'genenerar nueva poliza
                longPoliza = NuevaPoliza()
                UltimaPoliza(longPoliza, EJERCICIO) ' actualiza la ultima poliza

                ' Verifica si la factura tiene descuento
                strSQl = " SELECT SUM(d.DDoc_Prd_DSQ) descuento "
                strSQl &= "    From Dcmtos_DTL d "
                strSQl &= "        WHERE d.DDoc_Sis_Emp = {emp} AND d.DDoc_Doc_Cat = 36 AND d.DDoc_Doc_Ano = {anio} AND d.DDoc_Doc_Num = {num} "

                strSQl = Replace(strSQl, "{emp}", Sesion.IdEmpresa)
                strSQl = Replace(strSQl, "{anio}", ano)
                strSQl = Replace(strSQl, "{num}", num)
                MyCnn.CONECTAR = strConexion
                COM = New MySqlCommand(strSQl, CON)
                dblDesc = COM.ExecuteScalar

                'Genera Encabezado

                strSQl = sqlVentaEncabezado(cat, ano, num, longPoliza, EJERCICIO, fec)
                MyCnn.CONECTAR = strConexion
                COM = New MySqlCommand(strSQl, CON)
                COM.ExecuteNonQuery()

                'GeneraDetalle
                conec = New MySqlConnection(strConexion & ";Allow User Variables=True")
                conec.Open()
                If Sesion.IdEmpresa = 9 Then
                    strSQl2 = sqlVentaDetalleServi(cat, ano, num, longPoliza, EJERCICIO, dblDesc, tipoFact)
                Else
                    strSQl2 = sqlVentaDetalle(cat, ano, num, longPoliza, EJERCICIO, dblDesc)
                End If

                MyCnn.CONECTAR = strConexion
                COM2 = New MySqlCommand(strSQl2, conec)
                'COM2.Parameters.AddWithValue("@REG", 0)
                COM2.ExecuteNonQuery()

            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub PolizaCostoVenta(ByVal cat As Integer, ByVal ano As Integer, ByVal num As Integer, ByVal fec As Date, ByVal tipoProducto As String)
        Dim intRegimen As Integer = NO_FILA
        Dim strConcepto As String = STR_VACIO
        Dim strCliente As String = STR_VACIO
        Dim longPoliza As Long = NO_FILA
        Dim strSQl As String = STR_VACIO
        Dim strSQl2 As String = STR_VACIO
        Dim intTraslado_ As Integer = 0
        Dim COM As MySqlCommand
        Dim COM2 As MySqlCommand
        Dim conec As MySqlConnection

        Try
            If FacturaImpresa(cat, ano, num) Then

                'genenerar nueva poliza
                longPoliza = NuevaPoliza()
                UltimaPoliza(longPoliza, EJERCICIO) ' actualiza la ultima poliza

                'Genera Encabezado
                strSQl = sqlVentaCostoEncabezado(cat, ano, num, longPoliza, EJERCICIO, fec)
                MyCnn.CONECTAR = strConexion
                COM = New MySqlCommand(strSQl, CON)
                COM.ExecuteNonQuery()
                strSQl = STR_VACIO
                COM.Dispose()
                System.GC.Collect()

                strSQl = " SELECT h48.HDoc_RF1_Dbl
                            FROM Dcmtos_HDR h
                            LEFT JOIN Dcmtos_DTL_Pro p ON p.PDoc_Sis_Emp = h.HDoc_Sis_Emp AND p.PDoc_Chi_Cat = h.HDoc_Doc_Cat AND p.PDoc_Chi_Ano = h.HDoc_Doc_Ano AND p.PDoc_Chi_Num = h.HDoc_Doc_Num
                            LEFT JOIN Dcmtos_HDR h48 ON h48.HDoc_Sis_Emp = p.PDoc_Sis_Emp AND h48.HDoc_Doc_Cat = p.PDoc_Par_Cat AND h48.HDoc_Doc_Ano = p.PDoc_Par_Ano AND h48.HDoc_Doc_Num = p.PDoc_Par_Num
                            WHERE h.HDoc_Sis_Emp = {empresa} AND h.HDoc_Doc_Cat = {cat} AND h.HDoc_Doc_Ano = {anio} AND h.HDoc_Doc_Num = {num}"

                strSQl = Replace(strSQl, "{empresa}", Sesion.IdEmpresa)
                strSQl = Replace(strSQl, "{cat}", cat)
                strSQl = Replace(strSQl, "{anio}", ano)
                strSQl = Replace(strSQl, "{num}", num)
                MyCnn.CONECTAR = strConexion
                COM = New MySqlCommand(strSQl, CON)
                intTraslado_ = COM.ExecuteScalar()

                'GeneraDetalle
                conec = New MySqlConnection(strConexion & ";Allow User Variables=True")
                conec.Open()
                strSQl2 = sqlVentaCostoDetalle(STR_VACIO, cFunciones.ContaEmpresa, cat, ano, num, longPoliza, EJERCICIO, tipoProducto, intTraslado_)
                MyCnn.CONECTAR = strConexion
                COM2 = New MySqlCommand(strSQl2, conec)
                COM2.ExecuteNonQuery()
                If Sesion.IdEmpresa = 18 Then
                    'GeneraDetalle solo para replicar en PDM
                    conec = New MySqlConnection(strConexion & ";Allow User Variables=True")
                    conec.Open()
                    strSQl2 = sqlVentaCostoDetalle("PDM.", "contapdm", cat, ano, num, longPoliza, EJERCICIO, tipoProducto, intTraslado_)
                    MyCnn.CONECTAR = strConexion
                    COM2 = New MySqlCommand(strSQl2, conec)
                    COM2.ExecuteNonQuery()
                End If
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub
#End Region

#Region "Nota de Credito"

    Private Function Pais()
        Dim strSQL2 As String
        Dim COM2 As New MySqlCommand
        Dim conec2 As New MySqlConnection
        Dim intPais As Integer = INT_CERO

        strSQL2 = "SELECT e.emp_pais "
        strSQL2 &= "     FROM Empresas e"
        strSQL2 &= "         WHERE e.emp_no = {empresa} "

        strSQL2 = Replace(strSQL2, "{empresa}", Sesion.IdEmpresa)
        conec2 = New MySqlConnection(strConexion)
        conec2.Open()
        COM2 = New MySqlCommand(strSQL2, conec2)
        Using conec2
            intPais = COM2.ExecuteScalar
            COM2.Dispose()
            COM2 = Nothing
            conec2.Close()
            conec2.Dispose()
            conec2 = Nothing
            System.GC.Collect()
        End Using

        Return intPais
    End Function
    Private Function sqlNumNC(ByVal cat As Integer, ByVal ano As Integer, ByVal num As Integer)
        Dim strSQL As String = STR_VACIO
        Dim strCampoNC As String = STR_VACIO
        Dim COM As MySqlCommand
        Dim conec As MySqlConnection
        Dim intNotaCredito As Integer

        strSQL = "SELECT  {CampoNC} "
        strSQL &= "     From Dcmtos_HDR h "
        strSQL &= "              WHERE h.HDoc_Sis_Emp = {empresa} AND h.HDoc_Doc_Cat = {cat} AND h.HDoc_Doc_Ano = {ano} AND h.HDoc_Doc_Num = {num} "

        strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)

        If (Pais() = 310 And Sesion.IdEmpresa = 12) Or (Pais() = 310 And Sesion.IdEmpresa = 16) Or Sesion.IdEmpresa = 11 Then
            strCampoNC = " h.HDoc_DR1_Dbl "
        Else
            strCampoNC = " h.HDoc_Doc_Num"
        End If
        strSQL = Replace(strSQL, "{CampoNC}", strCampoNC)
        strSQL = Replace(strSQL, "{cat}", cat)
        strSQL = Replace(strSQL, "{ano}", ano)
        strSQL = Replace(strSQL, "{num}", num)

        conec = New MySqlConnection(strConexion)
        conec.Open()
        COM = New MySqlCommand(strSQL, conec)
        intNotaCredito = COM.ExecuteScalar
        conec.Close()
        conec.Dispose()
        conec = Nothing
        System.GC.Collect()

        Return intNotaCredito
    End Function

    Private Function SqlFactura(ByVal cat As Integer, ByVal ano As Integer, ByVal num As Integer)
        Dim strSQL As String = STR_VACIO
        Dim strCampoNC As String = STR_VACIO
        Dim COM As MySqlCommand
        Dim conec As MySqlConnection
        Dim intFactura As Integer

        strSQL = "SELECT  {CampoNC} "
        strSQL &= "     FROM ECtaCte e "
        strSQL &= "     LEFT JOIN Dcmtos_HDR h ON h.HDoc_Sis_Emp = e.ECta_Sis_Emp AND h.HDoc_Doc_Cat = e.ECta_Ref_Cat AND h.HDoc_Doc_Ano = e.ECta_Ref_Ano AND h.HDoc_Doc_Num = e.ECta_Ref_Num "
        strSQL &= " WHERE e.ECta_Sis_Emp = {empresa} AND e.ECta_Doc_Cat = {cat} AND e.ECta_Doc_Ano = {ano} AND e.ECta_Doc_Num = {num} "

        strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)

        If (Pais() = 310 And Sesion.IdEmpresa = 12) Or (Pais() = 310 And Sesion.IdEmpresa = 16) Or Sesion.IdEmpresa = 11 Then
            strCampoNC = " IF(e.ECta_Ref_Cat = 36,h.HDoc_DR1_Dbl, h.HDoc_DR2_Cat) fact "
        Else
            strCampoNC = " h.HDoc_Doc_Num "
        End If
        strSQL = Replace(strSQL, "{CampoNC}", strCampoNC)
        strSQL = Replace(strSQL, "{cat}", cat)
        strSQL = Replace(strSQL, "{ano}", ano)
        strSQL = Replace(strSQL, "{num}", num)

        conec = New MySqlConnection(strConexion)
        conec.Open()
        COM = New MySqlCommand(strSQL, conec)
        intFactura = COM.ExecuteScalar
        conec.Close()
        conec.Dispose()
        conec = Nothing
        System.GC.Collect()

        Return intFactura
    End Function

    Private Function sqlEncabezadoNC(ByVal cat As Integer, ByVal ano As Integer, ByVal num As Integer, ByVal poliza As Long, ByVal ejercicio As Integer, ByVal fec As Date)
        Dim strsql As String = STR_VACIO
        Dim intRegimen As Integer = INT_CERO
        Dim strConcepto As String = STR_VACIO
        Dim intFactura As Integer = INT_CERO
        Dim intNumeroNC As Integer = 0

        intFactura = SqlFactura(cat, ano, num)
        intNumeroNC = sqlNumNC(cat, ano, num)



        strsql = " INSERT INTO {conta}.polizas  "
        strsql &= "     SELECT h.HDoc_Sis_Emp , {ejercicio}, {poliza}, '{fec}' , "
        If Sesion.IdEmpresa = 15 Or Sesion.IdEmpresa = 20 Then
            strsql &= "d.DDoc_Prd_Des"
        Else
            strsql &= "CONCAT('" & " Para registrar Nota de Credito " & intNumeroNC & " " & " de Factura #:" & " " & intFactura & ", dated: " & "',h.HDoc_Doc_Fec )"
        End If

        strsql &= ", 13, h.HDoc_Doc_TC , '', h.HDoc_Usuario , 'C', now(), '', 13,h.HDoc_Doc_Cat, h.HDoc_Doc_Ano , h.HDoc_Doc_Num , null, h.HDoc_Doc_TC , 0, null,null "
        strsql &= "         FROM Dcmtos_HDR h "

        If Sesion.IdEmpresa = 15 Or Sesion.IdEmpresa = 20 Then
            strsql &= " LEFT JOIN Dcmtos_DTL d ON h.HDoc_Sis_Emp=d.DDoc_Sis_Emp AND h.HDoc_Doc_Cat=d.DDoc_Doc_Cat AND h.HDoc_Doc_Ano=d.DDoc_Doc_Ano AND h.HDoc_Doc_Num=d.DDoc_Doc_Num"
        End If

        strsql &= " WHERE h.HDoc_Sis_Emp = {empresa} and h.HDoc_Doc_Cat = {cat} and h.HDoc_Doc_Ano = {ano} and h.HDoc_Doc_Num = {num} Limit 1"

        If Sesion.IdEmpresa = 18 Then
            strsql &= "; INSERT INTO contapdm.polizas  "
            strsql &= "     SELECT h.HDoc_Sis_Emp , {ejercicio}, {poliza}, '{fec}' , "
            strsql &= "CONCAT('" & " Para registrar Nota de Credito " & intNumeroNC & " " & " de Factura #:" & " " & intFactura & ", dated: " & "',h.HDoc_Doc_Fec )"

            strsql &= ", 13, h.HDoc_Doc_TC , '', h.HDoc_Usuario , 'C', now(), '', 13,h.HDoc_Doc_Cat, h.HDoc_Doc_Ano , h.HDoc_Doc_Num , null, h.HDoc_Doc_TC , 0, null,null "
            strsql &= "         FROM PDM.Dcmtos_HDR h "

            strsql &= " WHERE h.HDoc_Sis_Emp = {empresa} and h.HDoc_Doc_Cat = {cat} and h.HDoc_Doc_Ano = {ano} and h.HDoc_Doc_Num = {num} Limit 1"
        End If

        strsql = Replace(strsql, "{conta}", cFunciones.ContaEmpresa)
        strsql = Replace(strsql, "{poliza}", poliza)
        strsql = Replace(strsql, "{ejercicio}", ejercicio)
        strsql = Replace(strsql, "{empresa}", Sesion.IdEmpresa)
        strsql = Replace(strsql, "{cat}", cat)
        strsql = Replace(strsql, "{ano}", ano)
        strsql = Replace(strsql, "{num}", num)
        strsql = Replace(strsql, "{fec}", fec.ToString(FORMATO_MYSQL))
        Return strsql
    End Function

    Private Function sqlDetalleNC(ByVal db As String, ByVal conta As String, ByVal cat As Integer, ByVal ano As Integer, ByVal num As Integer, ByVal poliza As Integer, ByVal ejercicio As Integer)
        Dim strSQl As String = STR_VACIO

        Dim COM As MySqlCommand
        Dim tcFactura As Double
        Dim tcNC As Double

        strSQl = " SELECT h.HDoc_RF1_Dbl FROM {db}Dcmtos_HDR h WHERE h.HDoc_Sis_Emp = {emp} AND h.HDoc_Doc_Cat = {cat} AND h.HDoc_Doc_Ano = {anio} AND h.HDoc_Doc_Num ={num}"
        strSQl = Replace(strSQl, "{emp}", Sesion.IdEmpresa)
        strSQl = Replace(strSQl, "{cat}", cat)
        strSQl = Replace(strSQl, "{anio}", ano)
        strSQl = Replace(strSQl, "{num}", num)
        strSQl = Replace(strSQl, "{db}", db)
        MyCnn.CONECTAR = strConexion
        COM = New MySqlCommand(strSQl, CON)
        tcFactura = COM.ExecuteScalar()
        strSQl = " SELECT h.HDoc_Doc_TC FROM {db}Dcmtos_HDR h WHERE h.HDoc_Sis_Emp = {emp} AND h.HDoc_Doc_Cat = {cat} AND h.HDoc_Doc_Ano = {anio} AND h.HDoc_Doc_Num ={num}"
        strSQl = Replace(strSQl, "{emp}", Sesion.IdEmpresa)
        strSQl = Replace(strSQl, "{cat}", cat)
        strSQl = Replace(strSQl, "{anio}", ano)
        strSQl = Replace(strSQl, "{num}", num)
        strSQl = Replace(strSQl, "{db}", db)
        MyCnn.CONECTAR = strConexion
        COM = New MySqlCommand(strSQl, CON)
        tcNC = COM.ExecuteScalar()


        strSQl = "   INSERT INTO {conta}.detalle_polizas "
        strSQl &= "     SELECT s1.transaccion, s1.empresa, s1.ejercicio, s1.poliza, (@REG := @REG + 1) item, IFNULL(s1.cuenta,''), s1.parametro_cuenta, Round(s1.importe +.0000000001,2), s1.centro_costos, IFNULL(s1.partida_presupuestal,''), s1.operacion, s1.fecha, IFNULL(s1.clase,''), s1.modo, s1.ref_tipo, s1.ref_ciclo, s1.ref_numero, s1.ref_id"
        strSQl &= "        FROM (  "
        '    strSQl &= "             SELECT 0 transaccion, h.HDoc_Sis_Emp empresa, {ejercicio} ejercicio, {poliza} poliza, @REG :=0, pe.valor cuenta, h.HDoc_DR1_Cat parametro_cuenta, ROUND(SUM(d.DDoc_Prd_QTY * d.DDoc_Prd_NET * h.HDoc_Doc_TC),2) importe,d.DDoc_Prd_NET centro_costos, NULL partida_presupuestal, 'C' operacion, CAST(CURDATE() AS CHAR) fecha, a.art_clase clase, 13 modo, h.HDoc_Doc_Cat ref_tipo, h.HDoc_Doc_Ano ref_ciclo, h.HDoc_Doc_Num ref_numero, d.DDoc_Prd_Cod ref_id"
        strSQl &= "    SELECT 0 transaccion, h.HDoc_Sis_Emp empresa, {ejercicio} ejercicio, {poliza} poliza, @REG :=0, {contabilidad} cuenta, h.HDoc_DR1_Cat parametro_cuenta, if(h.HDoc_Sis_Emp in(9,10), 
im.MDoc_Lin_Base, {importe} Importe ,{cc} centro_costos, NULL partida_presupuestal, 'C' operacion, CAST(CURDATE() AS CHAR) fecha, a.art_clase clase, 13 modo, h.HDoc_Doc_Cat ref_tipo, h.HDoc_Doc_Ano ref_ciclo, h.HDoc_Doc_Num ref_numero, d.DDoc_Prd_Cod ref_id "
        strSQl &= "                 FROM {db}Dcmtos_HDR h  "
        strSQl &= "                 LEFT JOIN {db}Dcmtos_DTL d ON d.DDoc_Sis_Emp = h.HDoc_Sis_Emp AND d.DDoc_Doc_Cat = h.HDoc_Doc_Cat AND d.DDoc_Doc_Ano = h.HDoc_Doc_Ano AND d.DDoc_Doc_Num = h.HDoc_Doc_Num"
        strSQl &= "                 LEFT JOIN {db}Dcmtos_IMP im ON im.MDoc_Sis_Emp = d.DDoc_Sis_Emp AND im.MDoc_Doc_Cat = d.DDoc_Doc_Cat AND im.MDoc_Doc_Ano = d.DDoc_Doc_Ano AND im.MDoc_Doc_Num = d.DDoc_Doc_Num  "

        If Sesion.idGiro = 2 Or Sesion.IdEmpresa = 10 Or Sesion.IdEmpresa = 9 Or Sesion.IdEmpresa = 3 Then
            strSQl &= "                 LEFT JOIN {db}Inventarios i ON i.inv_sisemp = d.DDoc_Sis_Emp AND i.inv_numero = d.DDoc_Prd_Cod"
            strSQl &= "                 LEFT JOIN {db}Articulos a ON a.art_sisemp = i.inv_sisemp AND a.art_codigo = i.inv_artcodigo"
            strSQl &= "                 LEFT JOIN {conta}.parametros p ON IF(h.HDoc_DR1_Cat in (0,2), p.parametro = 14, p.parametro = 20) AND p.categoria = 'Contables'
                                    LEFT JOIN {conta}.parametros_empresa pe ON pe.empresa = h.HDoc_Sis_Emp AND pe.parametro = p.parametro"

            strSQl = Replace(strSQl, "{contabilidad}", " pe. valor")
            strSQl = Replace(strSQl, "{cc}", 0)
        Else
            strSQl &= "                 LEFT JOIN {db}Dcmtos_DTL t ON t.DDoc_Sis_Emp = d.DDoc_Sis_Emp AND t.DDoc_Doc_Cat = d.DDoc_RF1_Num AND t.DDoc_Doc_Ano = d.DDoc_RF2_Num AND t.DDoc_Doc_Num = d.DDoc_RF3_Num AND t.DDoc_Doc_Lin = d.DDoc_Prd_Cod "
            strSQl &= "                 LEFT JOIN {db}Inventarios i ON i.inv_sisemp = t.DDoc_Sis_Emp AND i.inv_numero = t.DDoc_Prd_Cod"
            strSQl &= "                 LEFT JOIN {db}Articulos a ON a.art_sisemp = i.inv_sisemp AND a.art_codigo = i.inv_artcodigo"
            strSQl &= "                 LEFT JOIN {db}Catalogos c ON c.cat_num = i.inv_lugarfab AND c.cat_clase ='Paises'"
            strSQl &= "                 LEFT JOIN {conta}.inventario_codigos v ON v.clase = c.cat_sisemp"

            strSQl = Replace(strSQl, "{contabilidad}", " IF(h.HDoc_DR1_Cat IN(0,2),IF(a.art_clase = 330, v.descuento_quimico,v.descuento),IF(a.art_clase =330, v.devolucion_quimico,v.devolucion))")
            strSQl = Replace(strSQl, "{cc}", 12)
        End If

        strSQl &= "             WHERE h.HDoc_Sis_Emp = {empresa} AND h.HDoc_Doc_Cat = {catalogo} AND h.HDoc_Doc_Ano = {ano} AND h.HDoc_Doc_Num ={numero} "
        'strSQl &= "             GROUP BY a.art_clase  "


        If Sesion.IdEmpresa = 10 Or Sesion.IdEmpresa = 9 Then
            strSQl &= " UNION "
            strSQl &= " SELECT 0 transaccion, h.HDoc_Sis_Emp empresa, {ejercicio} ejercicio, {poliza} poliza, @REG :=0, pe.valor cuenta, h.HDoc_DR1_Cat parametro_cuenta,+ im.MDoc_Lin_Monto importe, "
            strSQl &= "     d.DDoc_Prd_NET centro_costos, NULL partida_presupuestal, 'C' operacion, CAST(CURDATE() AS CHAR) fecha, a.art_clase clase, 13 modo, h.HDoc_Doc_Cat ref_tipo, "
            strSQl &= "         h.HDoc_Doc_Ano ref_ciclo, h.HDoc_Doc_Num ref_numero, d.DDoc_Prd_Cod ref_id  "
            strSQl &= "             FROM {db}Dcmtos_HDR h "
            strSQl &= "                 LEFT JOIN {db}Dcmtos_DTL d ON d.DDoc_Sis_Emp = h.HDoc_Sis_Emp AND d.DDoc_Doc_Cat = h.HDoc_Doc_Cat AND d.DDoc_Doc_Ano = h.HDoc_Doc_Ano AND d.DDoc_Doc_Num = h.HDoc_Doc_Num "
            strSQl &= "                     LEFT JOIN {db}Dcmtos_IMP im ON im.MDoc_Sis_Emp = d.DDoc_Sis_Emp AND im.MDoc_Doc_Cat = d.DDoc_Doc_Cat AND im.MDoc_Doc_Ano = d.DDoc_Doc_Ano AND im.MDoc_Doc_Num = d.DDoc_Doc_Num  "
            strSQl &= "                         LEFT JOIN {db}Inventarios i ON i.inv_sisemp = d.DDoc_Sis_Emp AND i.inv_numero = d.DDoc_Prd_Cod "
            strSQl &= "                             LEFT JOIN {db}Articulos a ON a.art_sisemp = i.inv_sisemp AND a.art_codigo = i.inv_artcodigo "
            strSQl &= "                                 LEFT JOIN {conta}.parametros p ON IF(h.HDoc_DR1_Cat IN (0,2), p.parametro = 50, p.parametro = 50) AND p.categoria = 'Contables' "
            strSQl &= "                                     LEFT JOIN {conta}.parametros_empresa pe ON pe.empresa = h.HDoc_Sis_Emp AND pe.parametro = p.parametro "
            strSQl &= "                                         WHERE h.HDoc_Sis_Emp = {empresa} AND h.HDoc_Doc_Cat = {catalogo} AND h.HDoc_Doc_Ano = {ano} AND h.HDoc_Doc_Num ={numero} "
            strSQl &= "                                             GROUP BY a.art_clase  "
        End If

        strSQl &= "             UNION "
        strSQl &= "             SELECT 0,h.HDoc_Sis_Emp, {ejercicio}, {poliza}, 1,c.cli_cuenta, h.HDoc_DR1_Cat, (SUM(d.DDoc_Prd_QTY * d.DDoc_Prd_NET * {TC_cliente})) monto,0, NULL, 'A', CAST(CURDATE() AS CHAR), IF(h.HDoc_DR1_Cat = 1,'Cliente Exterior', 'Cliente Local'), 13, h.HDoc_Doc_Cat, h.HDoc_Doc_Ano, h.HDoc_Doc_Num, 0"
        strSQl &= "                 FROM {db}Dcmtos_HDR h "
        strSQl &= "                 LEFT JOIN {db}Clientes c ON c.cli_sisemp= h.HDoc_Sis_Emp AND c.cli_codigo = h.HDoc_Emp_Cod"
        strSQl &= "                 LEFT JOIN {db}Dcmtos_DTL d ON d.DDoc_Sis_Emp = h.HDoc_Sis_Emp AND d.DDoc_Doc_Cat = h.HDoc_Doc_Cat AND d.DDoc_Doc_Ano = h.HDoc_Doc_Ano AND d.DDoc_Doc_Num = h.HDoc_Doc_Num"
        strSQl &= "                 WHERE h.HDoc_Sis_Emp = {empresa} AND h.HDoc_Doc_Cat = 31 AND h.HDoc_Doc_Ano = {ano} AND h.HDoc_Doc_Num ={numero}  "


        If tcFactura <> tcNC And Sesion.IdEmpresa = 12 Then
            If tcFactura < tcNC Then
                strSQl &= "union
                    SELECT 0,h.HDoc_Sis_Emp, {ejercicio}, {poliza}, @REG :=0, pe.valor cuenta, h.HDoc_DR1_Cat parametrocuenta,
                    (SUM(d.DDoc_Prd_QTY * d.DDoc_Prd_NET * (" & tcNC & "-" & tcFactura & "))) as monto,
                    4, NULL, 'A', CAST(CURDATE() AS CHAR), IF(h.HDoc_DR1_Cat = 1,'Cliente Exterior', 'Cliente Local'), 13, h.HDoc_Doc_Cat, h.HDoc_Doc_Ano, h.HDoc_Doc_Num, 0
                    FROM {db}Dcmtos_HDR h
                    LEFT JOIN {db}Dcmtos_DTL d ON d.DDoc_Sis_Emp = h.HDoc_Sis_Emp AND d.DDoc_Doc_Cat = h.HDoc_Doc_Cat AND d.DDoc_Doc_Ano = h.HDoc_Doc_Ano AND d.DDoc_Doc_Num = h.HDoc_Doc_Num
                    LEFT JOIN contahilos.parametros p ON p.categoria='Contables' AND p.parametro =22 -- 21 haber
                    LEFT JOIN contahilos.parametros_empresa pe ON pe.parametro=p.parametro
                    LEFT JOIN contahilos.cuentas c ON c.empresa=pe.empresa AND pe.valor=c.id_cuenta
                    WHERE h.HDoc_Sis_Emp = {empresa} AND h.HDoc_Doc_Cat = 31 AND h.HDoc_Doc_Ano = {ano} AND h.HDoc_Doc_Num ={numero}"
            Else
                strSQl &= "union
                    SELECT 0,h.HDoc_Sis_Emp, {ejercicio}, {poliza}, @REG :=0, pe.valor cuenta, h.HDoc_DR1_Cat parametrocuenta,
                    (SUM(d.DDoc_Prd_QTY * d.DDoc_Prd_NET * (" & tcFactura & "-" & tcNC & "))) as monto,
                    4, NULL, 'C', CAST(CURDATE() AS CHAR), IF(h.HDoc_DR1_Cat = 1,'Cliente Exterior', 'Cliente Local'), 13, h.HDoc_Doc_Cat, h.HDoc_Doc_Ano, h.HDoc_Doc_Num, 0
                    FROM {db}Dcmtos_HDR h
                    LEFT JOIN {db}Dcmtos_DTL d ON d.DDoc_Sis_Emp = h.HDoc_Sis_Emp AND d.DDoc_Doc_Cat = h.HDoc_Doc_Cat AND d.DDoc_Doc_Ano = h.HDoc_Doc_Ano AND d.DDoc_Doc_Num = h.HDoc_Doc_Num
                    LEFT JOIN {conta}.parametros p ON p.categoria='Contables' AND p.parametro =21 -- 20 debe
                    LEFT JOIN {conta}.parametros_empresa pe ON pe.parametro=p.parametro
                    LEFT JOIN {conta}.cuentas c ON c.empresa=pe.empresa AND pe.valor=c.id_cuenta
                    WHERE h.HDoc_Sis_Emp = {empresa} AND h.HDoc_Doc_Cat = 31 AND h.HDoc_Doc_Ano = {ano} AND h.HDoc_Doc_Num ={numero}"
            End If
        End If
        strSQl &= ")s1 "



        strSQl = Replace(strSQl, "{empresa}", Sesion.IdEmpresa)
        strSQl = Replace(strSQl, "{catalogo}", cat)
        strSQl = Replace(strSQl, "{ano}", ano)
        strSQl = Replace(strSQl, "{numero}", num)
        strSQl = Replace(strSQl, "{ejercicio}", ejercicio)
        strSQl = Replace(strSQl, "{poliza}", poliza)
        strSQl = Replace(strSQl, "{conta}", conta)
        strSQl = Replace(strSQl, "{db}", db)
        If Sesion.IdEmpresa = 12 Then
            strSQl = Replace(strSQl, "{importe}", "ROUND(SUM(d.DDoc_Prd_QTY * d.DDoc_Prd_NET * " & tcNC & "),2))")
            strSQl = Replace(strSQl, "{TC_cliente}", "h.HDoc_RF1_Dbl")
        Else
            strSQl = Replace(strSQl, "{importe}", "ROUND(SUM(d.DDoc_Prd_QTY * d.DDoc_Prd_NET * " & tcFactura & "),2))")
            strSQl = Replace(strSQl, "{TC_cliente}", "h.HDoc_Doc_TC")
        End If

        Return strSQl

    End Function

    Private Function sqlDetalleNC(ByVal cat As Integer, ByVal ano As Integer, ByVal num As Integer, ByVal poliza As Integer, ByVal ejercicio As Integer)
        Dim strSQl As String = sqlDetalleNC(STR_VACIO, cFunciones.ContaEmpresa, cat, ano, num, poliza, ejercicio)

        If Sesion.IdEmpresa = 18 Then
            strSQl = String.Concat(strSQl, ";", sqlDetalleNC("PDM.", "contapdm", cat, ano, num, poliza, ejercicio))
        End If

        Return strSQl
    End Function


    Private Sub PolizaNCredit(ByVal cat As Integer, ByVal ano As Integer, ByVal num As Integer, ByVal fec As Date)
        Dim intRegimen As Integer = NO_FILA
        Dim strConcepto As String = STR_VACIO
        Dim strCliente As String = STR_VACIO
        Dim longPoliza As Long = NO_FILA
        Dim tipoNC As Integer = NO_FILA
        Dim strSQl As String = STR_VACIO
        Dim strSQl2 As String = STR_VACIO
        Dim dblImpuesto As Double = NO_FILA
        Dim COM As MySqlCommand
        Dim COM2 As MySqlCommand
        Dim conec As MySqlConnection
        Try
            'Verifica el tipo de NC
            strSQl = " SELECT h.HDoc_Ant_Com "
            strSQl &= " From Dcmtos_HDR h "
            strSQl &= " WHERE h.HDoc_Sis_Emp = {emp} AND h.HDoc_Doc_Cat = {cat} AND h.HDoc_Doc_Ano = {anio} AND h.HDoc_Doc_Num = {num} "

            strSQl = Replace(strSQl, "{emp}", Sesion.IdEmpresa)
            strSQl = Replace(strSQl, "{cat}", cat)
            strSQl = Replace(strSQl, "{anio}", ano)
            strSQl = Replace(strSQl, "{num}", num)
            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSQl, CON)
            tipoNC = COM.ExecuteScalar()

            strSQl = STR_VACIO


            'genenerar nueva poliza
            longPoliza = NuevaPoliza()
            UltimaPoliza(longPoliza, EJERCICIO) ' actualiza la ultima poliza

            'Genera Encabezado
            strSQl = sqlEncabezadoNC(cat, ano, num, longPoliza, EJERCICIO, fec)
            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSQl, CON)
            COM.ExecuteNonQuery()
            'GeneraDetalle
            conec = New MySqlConnection(strConexion & ";Allow User Variables=True")
            conec.Open()

            If tipoNC = 0 Then
                strSQl2 = sqlDetalleNC(cat, ano, num, longPoliza, EJERCICIO)   ''centro de costo quemado. crear proceso de busqueda de catalogo.
            Else
                strSQl = "SELECT h.DDoc_RF3_Dbl Impuesto "
                strSQl &= "    From Dcmtos_DTL h "
                strSQl &= " WHERE h.DDoc_Sis_Emp = {empresa} AND h.DDoc_Doc_Cat = 31 AND h.DDoc_Doc_Ano = {anio} AND h.DDoc_Doc_Num = {num}"

                strSQl = Replace(strSQl, "{empresa}", Sesion.IdEmpresa)
                strSQl = Replace(strSQl, "{anio}", ano)
                strSQl = Replace(strSQl, "{num}", num)
                MyCnn.CONECTAR = strConexion
                COM = New MySqlCommand(strSQl, CON)
                dblImpuesto = COM.ExecuteScalar ' Verifica retiene el impuesto de IVA (>0) o no (0)
                strSQl = STR_VACIO

                strSQl2 = DetalleNotaCreditoFiscal(cat, ano, num, longPoliza, dblImpuesto)

            End If
            MyCnn.CONECTAR = strConexion
            COM2 = New MySqlCommand(strSQl2, conec)
            'COM2.Parameters.AddWithValue("@REG", 0)
            COM2.ExecuteNonQuery()

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub


    Private Function DetalleNotaCreditoFiscal(ByVal cat As Integer, ByVal anio As Integer, ByVal num As Integer, ByVal poliza As Integer, ByVal intImpuesto As Integer)
        Dim strsql As String = STR_VACIO
        Dim item As Integer = 1

        strsql = " INSERT INTO {conta}.detalle_polizas "

        strsql &= "     Select 0, h.HDoc_Sis_Emp empresa, {ejercicio}, {poliza}," & item & " item, {contabilidad} cuenta,1 parametroCuenta, SUM((d.DDoc_Prd_NET *d.DDoc_Prd_QTY) * h.HDoc_Doc_TC) importe,'' centroCosto, '' partidaPresupuestal, 'C' operacion, h.HDoc_Doc_Fec Fecha,0 clase,13 modo, h.HDoc_Doc_Cat refTipo, h.HDoc_Doc_Ano refCiclo, h.HDoc_Doc_Num refNumero, 0 id "
        strsql &= "                 FROM Dcmtos_HDR h  "
        strsql &= "                 LEFT JOIN Dcmtos_DTL d ON d.DDoc_Sis_Emp = h.HDoc_Sis_Emp AND d.DDoc_Doc_Cat = h.HDoc_Doc_Cat AND d.DDoc_Doc_Ano = h.HDoc_Doc_Ano AND d.DDoc_Doc_Num = h.HDoc_Doc_Num"
        strsql &= "                 LEFT JOIN Inventarios i ON i.inv_sisemp = d.DDoc_Sis_Emp AND i.inv_numero = d.DDoc_Prd_Cod"
        If Sesion.IdEmpresa = 15 Or Sesion.IdEmpresa = 18 Or Sesion.IdEmpresa = 19 Then
            strsql &= "             LEFT JOIN {conta}.parametros p ON IF(h.HDoc_DR1_Cat in (0,2), p.parametro = 14, p.parametro = 20) AND p.categoria = 'Contables'
                                    LEFT JOIN {conta}.parametros_empresa pe ON pe.empresa = h.HDoc_Sis_Emp AND pe.parametro = p.parametro"

            strsql = Replace(strsql, "{contabilidad}", " pe. valor")
        Else
            strsql &= "                 LEFT JOIN Dcmtos_DTL t ON t.DDoc_Sis_Emp = d.DDoc_Sis_Emp AND t.DDoc_Doc_Cat = d.DDoc_RF1_Num AND t.DDoc_Doc_Ano = d.DDoc_RF2_Num AND t.DDoc_Doc_Num = d.DDoc_RF3_Num AND t.DDoc_Doc_Lin = d.DDoc_Prd_Cod "
            strsql &= "                 LEFT JOIN Catalogos c ON c.cat_num = i.inv_lugarfab AND c.cat_clase ='Paises'"
            strsql &= "                 LEFT JOIN {conta}.inventario_codigos v ON v.clase = c.cat_sisemp"

            strsql = Replace(strsql, "{contabilidad}", " IF(h.HDoc_DR1_Cat IN(0,2),IF(a.art_clase = 330, v.descuento_quimico,v.descuento),IF(a.art_clase =330, v.devolucion_quimico,v.devolucion))")
        End If
        strsql &= "             WHERE h.HDoc_Sis_Emp = {empresa} AND h.HDoc_Doc_Cat = {cat} AND h.HDoc_Doc_Ano = {anio} AND h.HDoc_Doc_Num ={num} "
        strsql &= "             UNION "

        item = item + 1
        strsql &= " Select 0, h.HDoc_Sis_Emp empresa, {ejercicio}, {poliza}," & item & " item, pc.valor cuenta,1 parametroCuenta, ((SUM((d.DDoc_Prd_NET *d.DDoc_Prd_QTY) * h.HDoc_Doc_TC) * ( "
        strsql &= " Select c.cat_sist "
        strsql &= " From Catalogos c "
        strsql &= " Where c.cat_clase = 'Impuestos' AND c.cat_clave = 'IVA' AND c.cat_sisemp = h.HDoc_Sis_Emp))/100) importe,'' centroCosto, '' partidaPresupuestal, 'C' operacion, h.HDoc_Doc_Fec Fecha,0 clase,13 modo, h.HDoc_Doc_Cat refTipo, h.HDoc_Doc_Ano refCiclo, h.HDoc_Doc_Num refNumero, 0 id "
        strsql &= "     From Dcmtos_HDR h "
        strsql &= "     Left Join Dcmtos_DTL d ON d.DDoc_Sis_Emp = h.HDoc_Sis_Emp And d.DDoc_Doc_Cat = h.HDoc_Doc_Cat And d.DDoc_Doc_Ano = h.HDoc_Doc_Ano And d.DDoc_Doc_Num = h.HDoc_Doc_Num "
        strsql &= "     Left Join {conta}.parametros_empresa pc ON pc.empresa = d.DDoc_Sis_Emp And pc.parametro = {parametro1} "
        strsql &= "         WHERE h.HDoc_Sis_Emp = {empresa} And h.HDoc_Doc_Cat = {cat} And h.HDoc_Doc_Ano = {anio} And h.HDoc_Doc_Num = {num} "

        item = item + 1
        strsql &= " UNION "
        strsql &= "      SELECT 0, h.HDoc_Sis_Emp empresa, '{ejercicio}', '{poliza}'," & item & " item, c.cli_cuenta cuenta,1 parametroCuenta, ((SUM((d.DDoc_Prd_NET *d.DDoc_Prd_QTY) * h.HDoc_Doc_TC) + ((SUM((d.DDoc_Prd_NET *d.DDoc_Prd_QTY) * h.HDoc_Doc_TC) * ( "
        strsql &= "      SELECT c.cat_sist "
        strsql &= "      FROM Catalogos c "
        strsql &= "      WHERE c.cat_clase = 'Impuestos' AND c.cat_clave = 'IVA' AND c.cat_sisemp = h.HDoc_Sis_Emp))/100)) {exento})importe,'' centroCosto, '' partidaPresupuestal, 'A' operacion, h.HDoc_Doc_Fec Fecha,0 clase,13 modo, h.HDoc_Doc_Cat refTipo, h.HDoc_Doc_Ano refCiclo, h.HDoc_Doc_Num refNumero, 0 id "
        strsql &= "          FROM Dcmtos_HDR h "
        strsql &= "          LEFT JOIN Dcmtos_DTL d ON d.DDoc_Sis_Emp = h.HDoc_Sis_Emp AND d.DDoc_Doc_Cat = h.HDoc_Doc_Cat AND d.DDoc_Doc_Ano = h.HDoc_Doc_Ano AND d.DDoc_Doc_Num = h.HDoc_Doc_Num "
        strsql &= "          LEFT JOIN Clientes c ON c.cli_sisemp = h.HDoc_Sis_Emp AND c.cli_codigo = h.HDoc_Emp_Cod "
        strsql &= "              WHERE h.HDoc_Sis_Emp = {empresa} AND h.HDoc_Doc_Cat = {cat} AND h.HDoc_Doc_Ano = {anio} AND h.HDoc_Doc_Num = {num} "

        If intImpuesto > 0 Then
            strsql = Replace(strsql, "{exento}", "- ((SUM((d.DDoc_Prd_NET *d.DDoc_Prd_QTY) * h.HDoc_Doc_TC))/100)")
            item = item + 1
            strsql &= " UNION "
            strsql &= "     Select 0, h.HDoc_Sis_Emp empresa, {ejercicio}, {poliza}," & item & " item, pc.valor cuenta,1 parametroCuenta, ((SUM((d.DDoc_Prd_NET *d.DDoc_Prd_QTY) * h.HDoc_Doc_TC))/100)importe,'' centroCosto, '' partidaPresupuestal, 'A' operacion, h.HDoc_Doc_Fec Fecha,0 clase,13 modo, h.HDoc_Doc_Cat refTipo, h.HDoc_Doc_Ano refCiclo, h.HDoc_Doc_Num refNumero, 0 id "
            strsql &= "     From Dcmtos_HDR h "
            strsql &= "     Left JOIN Dcmtos_DTL d ON d.DDoc_Sis_Emp = h.HDoc_Sis_Emp AND d.DDoc_Doc_Cat = h.HDoc_Doc_Cat AND d.DDoc_Doc_Ano = h.HDoc_Doc_Ano AND d.DDoc_Doc_Num = h.HDoc_Doc_Num "
            strsql &= "     Left JOIN {conta}.parametros_empresa pc ON pc.empresa = d.DDoc_Sis_Emp AND pc.parametro = {parametro2} "
            strsql &= "         WHERE h.HDoc_Sis_Emp = {empresa} AND h.HDoc_Doc_Cat = {cat} AND h.HDoc_Doc_Ano = {anio} AND h.HDoc_Doc_Num = {num} "
        End If

        If Sesion.IdEmpresa = 18 Then
            strsql = "; INSERT INTO contapdm.detalle_polizas "

            strsql &= "     Select 0, h.HDoc_Sis_Emp empresa, {ejercicio}, {poliza}," & item & " item, {contabilidad} cuenta,1 parametroCuenta, SUM((d.DDoc_Prd_NET *d.DDoc_Prd_QTY) * h.HDoc_Doc_TC) importe,'' centroCosto, '' partidaPresupuestal, 'C' operacion, h.HDoc_Doc_Fec Fecha,0 clase,13 modo, h.HDoc_Doc_Cat refTipo, h.HDoc_Doc_Ano refCiclo, h.HDoc_Doc_Num refNumero, 0 id "
            strsql &= "                 FROM PDM.Dcmtos_HDR h  "
            strsql &= "                 LEFT JOIN PDM.Dcmtos_DTL d ON d.DDoc_Sis_Emp = h.HDoc_Sis_Emp AND d.DDoc_Doc_Cat = h.HDoc_Doc_Cat AND d.DDoc_Doc_Ano = h.HDoc_Doc_Ano AND d.DDoc_Doc_Num = h.HDoc_Doc_Num"
            strsql &= "                 LEFT JOIN PDM.Inventarios i ON i.inv_sisemp = d.DDoc_Sis_Emp AND i.inv_numero = d.DDoc_Prd_Cod"
            If Sesion.IdEmpresa = 15 Or Sesion.IdEmpresa = 18 Or Sesion.IdEmpresa = 19 Then
                strsql &= "             LEFT JOIN contapdm.parametros p ON IF(h.HDoc_DR1_Cat in (0,2), p.parametro = 14, p.parametro = 20) AND p.categoria = 'Contables'
                                    LEFT JOIN contapdm.parametros_empresa pe ON pe.empresa = h.HDoc_Sis_Emp AND pe.parametro = p.parametro"

                strsql = Replace(strsql, "{contabilidad}", " pe. valor")
            End If
            strsql &= "             WHERE h.HDoc_Sis_Emp = {empresa} AND h.HDoc_Doc_Cat = {cat} AND h.HDoc_Doc_Ano = {anio} AND h.HDoc_Doc_Num ={num} "
            strsql &= "             UNION "

            item = item + 1
            strsql &= " Select 0, h.HDoc_Sis_Emp empresa, {ejercicio}, {poliza}," & item & " item, pc.valor cuenta,1 parametroCuenta, ((SUM((d.DDoc_Prd_NET *d.DDoc_Prd_QTY) * h.HDoc_Doc_TC) * ( "
            strsql &= " Select c.cat_sist "
            strsql &= " From PDM.Catalogos c "
            strsql &= " Where c.cat_clase = 'Impuestos' AND c.cat_clave = 'IVA' AND c.cat_sisemp = h.HDoc_Sis_Emp))/100) importe,'' centroCosto, '' partidaPresupuestal, 'C' operacion, h.HDoc_Doc_Fec Fecha,0 clase,13 modo, h.HDoc_Doc_Cat refTipo, h.HDoc_Doc_Ano refCiclo, h.HDoc_Doc_Num refNumero, 0 id "
            strsql &= "     From PDM.Dcmtos_HDR h "
            strsql &= "     Left Join PDM.Dcmtos_DTL d ON d.DDoc_Sis_Emp = h.HDoc_Sis_Emp And d.DDoc_Doc_Cat = h.HDoc_Doc_Cat And d.DDoc_Doc_Ano = h.HDoc_Doc_Ano And d.DDoc_Doc_Num = h.HDoc_Doc_Num "
            strsql &= "     Left Join contapdm.parametros_empresa pc ON pc.empresa = d.DDoc_Sis_Emp And pc.parametro = {parametro1} "
            strsql &= "         WHERE h.HDoc_Sis_Emp = {empresa} And h.HDoc_Doc_Cat = {cat} And h.HDoc_Doc_Ano = {anio} And h.HDoc_Doc_Num = {num} "

            item = item + 1
            strsql &= " UNION "
            strsql &= "      SELECT 0, h.HDoc_Sis_Emp empresa, '{ejercicio}', '{poliza}'," & item & " item, c.cli_cuenta cuenta,1 parametroCuenta, ((SUM((d.DDoc_Prd_NET *d.DDoc_Prd_QTY) * h.HDoc_Doc_TC) + ((SUM((d.DDoc_Prd_NET *d.DDoc_Prd_QTY) * h.HDoc_Doc_TC) * ( "
            strsql &= "      SELECT c.cat_sist "
            strsql &= "      FROM PDM.Catalogos c "
            strsql &= "      WHERE c.cat_clase = 'Impuestos' AND c.cat_clave = 'IVA' AND c.cat_sisemp = h.HDoc_Sis_Emp))/100)) {exento})importe,'' centroCosto, '' partidaPresupuestal, 'A' operacion, h.HDoc_Doc_Fec Fecha,0 clase,13 modo, h.HDoc_Doc_Cat refTipo, h.HDoc_Doc_Ano refCiclo, h.HDoc_Doc_Num refNumero, 0 id "
            strsql &= "          FROM PDM.Dcmtos_HDR h "
            strsql &= "          LEFT JOIN PDM.Dcmtos_DTL d ON d.DDoc_Sis_Emp = h.HDoc_Sis_Emp AND d.DDoc_Doc_Cat = h.HDoc_Doc_Cat AND d.DDoc_Doc_Ano = h.HDoc_Doc_Ano AND d.DDoc_Doc_Num = h.HDoc_Doc_Num "
            strsql &= "          LEFT JOIN PDM.Clientes c ON c.cli_sisemp = h.HDoc_Sis_Emp AND c.cli_codigo = h.HDoc_Emp_Cod "
            strsql &= "              WHERE h.HDoc_Sis_Emp = {empresa} AND h.HDoc_Doc_Cat = {cat} AND h.HDoc_Doc_Ano = {anio} AND h.HDoc_Doc_Num = {num} "

            If intImpuesto > 0 Then
                strsql = Replace(strsql, "{exento}", "- ((SUM((d.DDoc_Prd_NET *d.DDoc_Prd_QTY) * h.HDoc_Doc_TC))/100)")
                item = item + 1
                strsql &= " UNION "
                strsql &= "     Select 0, h.HDoc_Sis_Emp empresa, {ejercicio}, {poliza}," & item & " item, pc.valor cuenta,1 parametroCuenta, ((SUM((d.DDoc_Prd_NET *d.DDoc_Prd_QTY) * h.HDoc_Doc_TC))/100)importe,'' centroCosto, '' partidaPresupuestal, 'A' operacion, h.HDoc_Doc_Fec Fecha,0 clase,13 modo, h.HDoc_Doc_Cat refTipo, h.HDoc_Doc_Ano refCiclo, h.HDoc_Doc_Num refNumero, 0 id "
                strsql &= "     From PDM.Dcmtos_HDR h "
                strsql &= "     Left JOIN PDM.Dcmtos_DTL d ON d.DDoc_Sis_Emp = h.HDoc_Sis_Emp AND d.DDoc_Doc_Cat = h.HDoc_Doc_Cat AND d.DDoc_Doc_Ano = h.HDoc_Doc_Ano AND d.DDoc_Doc_Num = h.HDoc_Doc_Num "
                strsql &= "     Left JOIN contapdm.parametros_empresa pc ON pc.empresa = d.DDoc_Sis_Emp AND pc.parametro = {parametro2} "
                strsql &= "         WHERE h.HDoc_Sis_Emp = {empresa} AND h.HDoc_Doc_Cat = {cat} AND h.HDoc_Doc_Ano = {anio} AND h.HDoc_Doc_Num = {num} "
            End If
        End If

        strsql = Replace(strsql, "{ejercicio}", EJERCICIO)
        strsql = Replace(strsql, "{poliza}", poliza)
        strsql = Replace(strsql, "{empresa}", Sesion.IdEmpresa)
        strsql = Replace(strsql, "{anio}", anio)
        strsql = Replace(strsql, "{num}", num)
        strsql = Replace(strsql, "{conta}", Sesion.BaseConta)
        strsql = Replace(strsql, "{exento}", STR_VACIO)
        strsql = Replace(strsql, "{cat}", cat)

        If Sesion.IdEmpresa = 16 Then
            strsql = Replace(strsql, "{parametro1}", 57)
            strsql = Replace(strsql, "{parametro2}", 58)
        Else
            strsql = Replace(strsql, "{parametro1}", 50)
            strsql = Replace(strsql, "{parametro2}", 56)
        End If
        Return strsql

    End Function

#End Region

#Region "Nota de Debito"

    Private Function SQLFacturaNDebito(ByVal Catalogo As Integer, ByVal Anio As Integer, ByVal Numero As Integer) As Integer
        Dim strSQL As String = STR_VACIO
        Dim intFactura As Integer
        Dim conec As MySqlConnection
        Dim COM As MySqlCommand
        strSQL = "  SELECT e.ECta_Ref_Num Factura "
        strSQL &= "     FROM ECtaCte e "
        strSQL &= "         WHERE e.ECta_Sis_Emp =  {empresa} AND e.ECta_Doc_Cat = {catalogo} AND e.ECta_Doc_Ano = {anio} AND e.ECta_Doc_Num = {numero} "
        strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
        strSQL = Replace(strSQL, "{catalogo}", Catalogo)
        strSQL = Replace(strSQL, "{anio}", Anio)
        strSQL = Replace(strSQL, "{numero}", Numero)


        conec = New MySqlConnection(strConexion)
        conec.Open()
        COM = New MySqlCommand(strSQL, conec)
        intFactura = COM.ExecuteScalar
        conec.Close()
        conec.Dispose()
        conec = Nothing
        System.GC.Collect()
        Return intFactura
    End Function
    Private Function SQLEncabezadoNDebito(ByVal Catalogo As Integer, ByVal Anio As Integer, ByVal Numero As Integer, ByVal Ejercicio As Integer, ByVal Poliza As Long, ByVal fec As Date) As String
        Dim strSQL As String
        Dim strConcepto As String = STR_VACIO
        Dim intFactura As Integer = NO_FILA
        intFactura = SQLFacturaNDebito(Catalogo, Anio, Numero)

        strConcepto = " Para Registrar Nota de Debito " & Numero & " " & ", Ref. Factura:" & " " & intFactura & ", de Fecha:" & " "
        strSQL = " INSERT INTO {conta}.polizas  "
        strSQL &= " SELECT h.HDoc_Sis_Emp , {ejercicio} Ejercicio , {poliza} Poliza , '{fecha}' ,CONCAT('{concepto}',h.HDoc_Doc_Fec) Nota  , 20 Tipo , {tc}, '' Observaciones, "
        strSQL &= "     '{user}' , 'C',Now(),'',20,h.HDoc_Doc_Cat tipo , h.HDoc_Doc_Ano Anio , h.HDoc_Doc_Num Numero ,NULL, h.HDoc_Doc_TC Tasa,0,'',NULL  "
        strSQL &= "         FROM  Dcmtos_HDR h "
        strSQL &= "             WHERE  h.HDoc_Sis_Emp = {empresa} AND h.HDoc_Doc_Cat = {catalogo} AND h.HDoc_Doc_Ano = {anio} AND h.HDoc_Doc_Num = {numero} "

        If Sesion.IdEmpresa = 18 Then
            strSQL &= "; INSERT INTO contapdm.polizas  "
            strSQL &= " SELECT h.HDoc_Sis_Emp , {ejercicio} Ejercicio , {poliza} Poliza , '{fecha}' ,CONCAT('{concepto}',h.HDoc_Doc_Fec) Nota  , 20 Tipo , {tc}, '' Observaciones, "
            strSQL &= "     '{user}' , 'C',Now(),'',20,h.HDoc_Doc_Cat tipo , h.HDoc_Doc_Ano Anio , h.HDoc_Doc_Num Numero ,NULL, h.HDoc_Doc_TC Tasa,0,'',NULL  "
            strSQL &= "         FROM PDM.Dcmtos_HDR h "
            strSQL &= "             WHERE  h.HDoc_Sis_Emp = {empresa} AND h.HDoc_Doc_Cat = {catalogo} AND h.HDoc_Doc_Ano = {anio} AND h.HDoc_Doc_Num = {numero} "

        End If

        strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
        strSQL = Replace(strSQL, "{catalogo}", Catalogo)
        strSQL = Replace(strSQL, "{anio}", Anio)
        strSQL = Replace(strSQL, "{numero}", Numero)
        strSQL = Replace(strSQL, "{poliza}", Poliza)
        strSQL = Replace(strSQL, "{ejercicio}", Ejercicio)
        strSQL = Replace(strSQL, "{concepto}", strConcepto)
        strSQL = Replace(strSQL, "{conta}", cFunciones.ContaEmpresa)
        strSQL = Replace(strSQL, "{fecha}", fec.ToString(FORMATO_MYSQL))
        strSQL = Replace(strSQL, "{user}", Sesion.Usuario)
        If Sesion.IdEmpresa = 11 Then
            strSQL = Replace(strSQL, "{tc}", "h.HDoc_RF1_Dbl")
        Else
            strSQL = Replace(strSQL, "{tc}", "h.HDoc_Doc_TC")
        End If
        Return strSQL
    End Function
    Private Function SQLDetalleDebito(ByVal Catalogo As Integer, ByVal Anio As Integer, ByVal Numero As Integer, ByVal Ejercicio As Integer, ByVal Poliza As Long, ByVal Debito As Double) As String
        Dim strSQL As String

        Dim COM As MySqlCommand
        Dim tcFactura As Double
        Dim tcND As Double

        strSQL = " SELECT h.HDoc_RF1_Dbl FROM Dcmtos_HDR h WHERE h.HDoc_Sis_Emp = {emp} AND h.HDoc_Doc_Cat = {cat} AND h.HDoc_Doc_Ano = {anio} AND h.HDoc_Doc_Num ={num}"
        strSQL = Replace(strSQL, "{emp}", Sesion.IdEmpresa)
        strSQL = Replace(strSQL, "{cat}", Catalogo)
        strSQL = Replace(strSQL, "{anio}", Anio)
        strSQL = Replace(strSQL, "{num}", Numero)
        MyCnn.CONECTAR = strConexion
        COM = New MySqlCommand(strSQL, CON)
        tcFactura = COM.ExecuteScalar()
        strSQL = " SELECT h.HDoc_Doc_TC FROM Dcmtos_HDR h WHERE h.HDoc_Sis_Emp = {emp} AND h.HDoc_Doc_Cat = {cat} AND h.HDoc_Doc_Ano = {anio} AND h.HDoc_Doc_Num ={num}"
        strSQL = Replace(strSQL, "{emp}", Sesion.IdEmpresa)
        strSQL = Replace(strSQL, "{cat}", Catalogo)
        strSQL = Replace(strSQL, "{anio}", Anio)
        strSQL = Replace(strSQL, "{num}", Numero)
        MyCnn.CONECTAR = strConexion
        COM = New MySqlCommand(strSQL, CON)
        tcND = COM.ExecuteScalar()



        strSQL = " INSERT INTO {conta}.detalle_polizas"
        strSQL &= "  SELECT 0 Transaccion,h.HDoc_Sis_Emp, {ejercicio},{poliza},1 AS Posicion,c.cli_cuenta, 2 Numero, ROUND(d.DDoc_RF1_Dbl * h.HDoc_RF1_Dbl,2) Monto, "
        strSQL &= "     '','','C',h.HDoc_Doc_Fec Fecha, '2',20, h.HDoc_Doc_Cat,h.HDoc_Doc_Ano,h.HDoc_Doc_Num, 0 "
        strSQL &= "         FROM Dcmtos_HDR h "
        strSQL &= "             LEFT JOIN Clientes c ON c.cli_sisemp = h.HDoc_Sis_Emp AND c.cli_codigo = h.HDoc_Emp_Cod "
        strSQL &= "                 LEFT JOIN Dcmtos_DTL d ON d.DDoc_Sis_Emp = h.HDoc_Sis_Emp AND d.DDoc_Doc_Cat = h.HDoc_Doc_Cat AND d.DDoc_Doc_Ano = h.HDoc_Doc_Ano AND d.DDoc_Doc_Num = h.HDoc_Doc_Num "
        strSQL &= "                     WHERE h.HDoc_Sis_Emp = {empresa} AND h.HDoc_Doc_Cat = {catalogo} AND h.HDoc_Doc_Ano = {anio} AND h.HDoc_Doc_Num = {numero} "
        strSQL &= "                         UNION "

        strSQL &= "                             SELECT 0 Transaccion,h.HDoc_Sis_Emp,{ejercicio},{poliza},2 AS Posicion, {contabilidad}, 2 Numero, ROUND((d.DDoc_RF1_Dbl * {monto}) / {debito} ,2) Monto, "
        If Sesion.IdEmpresa = 12 Then
            strSQL = Replace(strSQL, "{monto}", "h.HDoc_Doc_TC")
        Else
            strSQL = Replace(strSQL, "{monto}", "h.HDoc_RF1_Dbl")
        End If


        strSQL &= "                                 '','','A',h.HDoc_Doc_Fec Fecha, '2',20, h.HDoc_Doc_Cat,h.HDoc_Doc_Ano,h.HDoc_Doc_Num, 0 "
        strSQL &= "                                     FROM Dcmtos_HDR h "
        strSQL &= "                                         LEFT JOIN Clientes c ON c.cli_sisemp = h.HDoc_Sis_Emp AND c.cli_codigo = h.HDoc_Emp_Cod "
        strSQL &= "                                             LEFT JOIN Dcmtos_DTL d ON d.DDoc_Sis_Emp = h.HDoc_Sis_Emp AND d.DDoc_Doc_Cat = h.HDoc_Doc_Cat AND d.DDoc_Doc_Ano = h.HDoc_Doc_Ano AND d.DDoc_Doc_Num = h.HDoc_Doc_Num "
        'If Sesion.IdEmpresa = 15 Or Sesion.IdEmpresa = 18 Or Sesion.IdEmpresa = 19 Then
        strSQL &= "                 LEFT JOIN {conta}.parametros p ON IF(h.HDoc_DR1_Cat in (0), p.parametro = 20, p.parametro = 14) AND p.categoria = 'Contables'
                                    LEFT JOIN {conta}.parametros_empresa pe ON pe.empresa = h.HDoc_Sis_Emp AND pe.parametro = p.parametro"

        strSQL = Replace(strSQL, "{contabilidad}", " pe. valor")
        'Else
        '    strSQL &= "                 LEFT JOIN Dcmtos_DTL t ON t.DDoc_Sis_Emp = d.DDoc_Sis_Emp AND t.DDoc_Doc_Cat = d.DDoc_RF1_Num AND t.DDoc_Doc_Ano = d.DDoc_RF2_Num AND t.DDoc_Doc_Num = d.DDoc_RF3_Num AND t.DDoc_Doc_Lin = d.DDoc_Prd_Cod "
        '    strSQL &= "                 LEFT JOIN Catalogos c ON c.cat_num = i.inv_lugarfab AND c.cat_clase ='Paises'"
        '    strSQL &= "                 LEFT JOIN {conta}.inventario_codigos v ON v.clase = c.cat_sisemp"

        '    strSQL = Replace(strSQL, "{contabilidad}", " IF(h.HDoc_DR1_Cat IN(0,2),v.descuento,v.devolucion)")
        'End If
        strSQL &= "                                                             WHERE h.HDoc_Sis_Emp = {empresa} AND h.HDoc_Doc_Cat = {catalogo} AND h.HDoc_Doc_Ano = {anio} AND h.HDoc_Doc_Num = {numero} "

        If Sesion.IdEmpresa = 10 Then
            strSQL &= "                                                        UNION  "
            strSQL &= "                                                     SELECT 0 Transaccion,h.HDoc_Sis_Emp,{ejercicio},{poliza},3 AS Posicion, pe.valor, 2 Numero, ROUND(imp.MDoc_Lin_Monto,2) Monto, "
            strSQL &= "                                                 '','','A',h.HDoc_Doc_Fec Fecha, '2',20, h.HDoc_Doc_Cat,h.HDoc_Doc_Ano,h.HDoc_Doc_Num, 0 "
            strSQL &= "                                             FROM Dcmtos_HDR h "
            strSQL &= "                                         LEFT JOIN Clientes c ON c.cli_sisemp = h.HDoc_Sis_Emp AND c.cli_codigo = h.HDoc_Emp_Cod "
            strSQL &= "                                     LEFT JOIN Dcmtos_DTL d ON d.DDoc_Sis_Emp = h.HDoc_Sis_Emp AND d.DDoc_Doc_Cat = h.HDoc_Doc_Cat AND d.DDoc_Doc_Ano = h.HDoc_Doc_Ano AND d.DDoc_Doc_Num = h.HDoc_Doc_Num "
            strSQL &= "                                 LEFT JOIN Dcmtos_IMP imp ON imp.MDoc_Sis_Emp = h.HDoc_Sis_Emp AND imp.MDoc_Doc_Cat = h.HDoc_Doc_Cat AND imp.MDoc_Doc_Ano = h.HDoc_Doc_Ano AND imp.MDoc_Doc_Num = h.HDoc_Doc_Num "
            strSQL &= "                             LEFT JOIN {conta}.parametros pa ON IF(h.HDoc_DR1_Cat IN (0,2), pa.parametro = 28, pa.parametro = 28) "
            strSQL &= "                         LEFT JOIN {conta}.parametros_empresa pe ON pe.empresa = h.HDoc_Sis_Emp AND pe.parametro = pa.parametro "
            strSQL &= "                     WHERE h.HDoc_Sis_Emp = {empresa} AND h.HDoc_Doc_Cat = {catalogo} AND h.HDoc_Doc_Ano = {anio} AND h.HDoc_Doc_Num = {numero}   "
        End If

        If tcFactura <> tcND And Sesion.IdEmpresa = 12 Then
            If tcFactura > tcND Then
                strSQL &= "union
                    SELECT 0,h.HDoc_Sis_Emp, {ejercicio}, {poliza},4, pe.valor cuenta, h.HDoc_DR1_Cat parametrocuenta,
                    ROUND(SUM(d.DDoc_Prd_QTY * d.DDoc_Prd_NET * (" & tcFactura & "-" & tcND & ")),2) as monto,
                    4, NULL, 'A', CAST(CURDATE() AS CHAR), IF(h.HDoc_DR1_Cat = 1,'Cliente Exterior', 'Cliente Local'), 20, h.HDoc_Doc_Cat, h.HDoc_Doc_Ano, h.HDoc_Doc_Num, 0
                    FROM Dcmtos_HDR h
                    LEFT JOIN Dcmtos_DTL d ON d.DDoc_Sis_Emp = h.HDoc_Sis_Emp AND d.DDoc_Doc_Cat = h.HDoc_Doc_Cat AND d.DDoc_Doc_Ano = h.HDoc_Doc_Ano AND d.DDoc_Doc_Num = h.HDoc_Doc_Num
                    LEFT JOIN contahilos.parametros p ON p.categoria='Contables' AND p.parametro =22 -- 21 haber
                    LEFT JOIN contahilos.parametros_empresa pe ON pe.parametro=p.parametro
                    LEFT JOIN contahilos.cuentas c ON c.empresa=pe.empresa AND pe.valor=c.id_cuenta
                    WHERE h.HDoc_Sis_Emp = {empresa} AND h.HDoc_Doc_Cat =  {catalogo} AND h.HDoc_Doc_Ano = {anio} AND h.HDoc_Doc_Num ={numero}"
            Else
                strSQL &= "union
                    SELECT 0,h.HDoc_Sis_Emp, {ejercicio}, {poliza},4, pe.valor cuenta, h.HDoc_DR1_Cat parametrocuenta,
                    ROUND(SUM(d.DDoc_Prd_QTY * d.DDoc_Prd_NET * (" & tcND & "-" & tcFactura & ")),2) as monto,
                    4, NULL, 'C', CAST(CURDATE() AS CHAR), IF(h.HDoc_DR1_Cat = 1,'Cliente Exterior', 'Cliente Local'), 20, h.HDoc_Doc_Cat, h.HDoc_Doc_Ano, h.HDoc_Doc_Num, 0
                    FROM Dcmtos_HDR h
                    LEFT JOIN Dcmtos_DTL d ON d.DDoc_Sis_Emp = h.HDoc_Sis_Emp AND d.DDoc_Doc_Cat = h.HDoc_Doc_Cat AND d.DDoc_Doc_Ano = h.HDoc_Doc_Ano AND d.DDoc_Doc_Num = h.HDoc_Doc_Num
                    LEFT JOIN {conta}.parametros p ON p.categoria='Contables' AND p.parametro =21 -- 20 debe
                    LEFT JOIN {conta}.parametros_empresa pe ON pe.parametro=p.parametro
                    LEFT JOIN {conta}.cuentas c ON c.empresa=pe.empresa AND pe.valor=c.id_cuenta
                    WHERE h.HDoc_Sis_Emp = {empresa} AND h.HDoc_Doc_Cat =  {catalogo} AND h.HDoc_Doc_Ano = {anio} AND h.HDoc_Doc_Num ={numero}"
            End If
        End If

        If Sesion.IdEmpresa = 18 Then
            strSQL &= "; INSERT INTO contapdm.detalle_polizas"
            strSQL &= "  SELECT 0 Transaccion,h.HDoc_Sis_Emp, {ejercicio},{poliza},1 AS Posicion,c.cli_cuenta, 2 Numero, ROUND(d.DDoc_RF1_Dbl * h.HDoc_RF1_Dbl,2) Monto, "
            strSQL &= "     '','','C',h.HDoc_Doc_Fec Fecha, '2',20, h.HDoc_Doc_Cat,h.HDoc_Doc_Ano,h.HDoc_Doc_Num, 0 "
            strSQL &= "         FROM PDM.Dcmtos_HDR h "
            strSQL &= "             LEFT JOIN PDM.Clientes c ON c.cli_sisemp = h.HDoc_Sis_Emp AND c.cli_codigo = h.HDoc_Emp_Cod "
            strSQL &= "                 LEFT JOIN PDM.Dcmtos_DTL d ON d.DDoc_Sis_Emp = h.HDoc_Sis_Emp AND d.DDoc_Doc_Cat = h.HDoc_Doc_Cat AND d.DDoc_Doc_Ano = h.HDoc_Doc_Ano AND d.DDoc_Doc_Num = h.HDoc_Doc_Num "
            strSQL &= "                     WHERE h.HDoc_Sis_Emp = {empresa} AND h.HDoc_Doc_Cat = {catalogo} AND h.HDoc_Doc_Ano = {anio} AND h.HDoc_Doc_Num = {numero} "
            strSQL &= "                         UNION "
            strSQL &= "                             SELECT 0 Transaccion,h.HDoc_Sis_Emp,{ejercicio},{poliza},2 AS Posicion, {contabilidad}, 2 Numero, ROUND((d.DDoc_RF1_Dbl * {monto}) / {debito} ,2) Monto, "
            strSQL = Replace(strSQL, "{monto}", "h.HDoc_RF1_Dbl")
            strSQL &= "                                 '','','A',h.HDoc_Doc_Fec Fecha, '2',20, h.HDoc_Doc_Cat,h.HDoc_Doc_Ano,h.HDoc_Doc_Num, 0 "
            strSQL &= "                                     FROM PDM.Dcmtos_HDR h "
            strSQL &= "                                         LEFT JOIN PDM.Clientes c ON c.cli_sisemp = h.HDoc_Sis_Emp AND c.cli_codigo = h.HDoc_Emp_Cod "
            strSQL &= "                                             LEFT JOIN PDM.Dcmtos_DTL d ON d.DDoc_Sis_Emp = h.HDoc_Sis_Emp AND d.DDoc_Doc_Cat = h.HDoc_Doc_Cat AND d.DDoc_Doc_Ano = h.HDoc_Doc_Ano AND d.DDoc_Doc_Num = h.HDoc_Doc_Num "
            strSQL &= "                 LEFT JOIN contapdm.parametros p ON IF(h.HDoc_DR1_Cat in (0), p.parametro = 20, p.parametro = 14) AND p.categoria = 'Contables'
                                    LEFT JOIN contapdm.parametros_empresa pe ON pe.empresa = h.HDoc_Sis_Emp AND pe.parametro = p.parametro"
            strSQL = Replace(strSQL, "{contabilidad}", " pe. valor")
            strSQL &= " WHERE h.HDoc_Sis_Emp = {empresa} AND h.HDoc_Doc_Cat = {catalogo} AND h.HDoc_Doc_Ano = {anio} AND h.HDoc_Doc_Num = {numero} "
        End If

        strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
        strSQL = Replace(strSQL, "{catalogo}", Catalogo)
        strSQL = Replace(strSQL, "{anio}", Anio)
        strSQL = Replace(strSQL, "{numero}", Numero)
        strSQL = Replace(strSQL, "{ejercicio}", Ejercicio)
        strSQL = Replace(strSQL, "{poliza}", Poliza)
        strSQL = Replace(strSQL, "{debito}", Debito)
        strSQL = Replace(strSQL, "{conta}", cFunciones.ContaEmpresa)

        Return strSQL
    End Function
    Private Sub PolizaNDebito(ByVal intCatalgo As Integer, ByVal intAnio As Integer, ByVal intNumero As Integer, ByVal fec As Date)
        Dim longPoliza As Long = NO_FILA
        Dim strSQL As String = STR_VACIO
        Dim dblIva As Double
        Dim COM As MySqlCommand
        Dim COM2 As MySqlCommand
        Try

            longPoliza = NuevaPoliza()
            UltimaPoliza(longPoliza, EJERCICIO) ' actualiza la ultima poliza

            'Genera Encabezado
            strSQL = SQLEncabezadoNDebito(intCatalgo, intAnio, intNumero, EJERCICIO, longPoliza, fec)
            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSQL, CON)
            COM.ExecuteNonQuery()
            strSQL = STR_VACIO

            If Sesion.IdEmpresa = 10 Then
                dblIva = IVA()
                dblIva = (100 + dblIva) / 100
            Else
                dblIva = INT_UNO
            End If


            strSQL = SQLDetalleDebito(intCatalgo, intAnio, intNumero, EJERCICIO, longPoliza, dblIva)
            MyCnn.CONECTAR = strConexion & ";Allow User Variables=True"
            COM2 = New MySqlCommand(strSQL, CON)
            COM2.ExecuteNonQuery()


        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub
#End Region

#Region "Nota de Credito Proveedor"
    Private Function IVA() As String
        Dim strIva As String = STR_VACIO
        Dim strSQL As String = STR_VACIO
        Dim conec As MySqlConnection
        Dim COM As MySqlCommand
        strSQL = " SELECT c.cat_sist IVA "
        strSQL &= "     FROM Catalogos c "
        strSQL &= "       WHERE c.cat_clase = 'Impuestos' AND c.cat_clave = 'IVA' AND c.cat_sisemp = {empresa}  "
        strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)

        conec = New MySqlConnection(strConexion)
        conec.Open()
        COM = New MySqlCommand(strSQL, conec)
        strIva = COM.ExecuteScalar
        conec.Close()
        conec.Dispose()
        conec = Nothing
        System.GC.Collect()


        Return strIva
    End Function

    Private Function SQLEncabezadoNCreditoProveedor(ByVal Catalogo As Integer, ByVal Anio As Integer, ByVal Numero As Integer, ByVal Ejercicio As Integer, ByVal Poliza As Long, ByVal fec As Date) As String
        Dim strSQL As String = STR_VACIO
        Dim strConcepto As String = STR_VACIO

        strConcepto = "PARA REGISTRAR NOTA DE CREDITO PROVEEDOR NO."

        strSQL = "INSERT INTO {conta}.polizas"
        strSQL &= "  SELECT h.HDoc_Sis_Emp , {ejercicio},{poliza}, '{fec}', CONCAT('PARA REGISTRAR NOTA DE CREDITO PROVEEDOR NO.',h.HDoc_Doc_Num,' ','Serie ',h.HDoc_DR2_Num,' / ',h.HDoc_Doc_Fec,' / ',h.HDoc_RF2_Cod,' / ',p.pro_proveedor,' / ',h.HDoc_RF1_Cod) concepto, 26,h.HDoc_Doc_TC,'' Observacion,h.HDoc_Usuario,'C',now(), '' Grupo, "
        strSQL &= "     26,h.HDoc_Doc_Cat, h.HDoc_Doc_Ano , h.HDoc_Doc_Num , null,h.HDoc_Doc_TC,0,null,null "
        strSQL &= "         FROM Dcmtos_HDR h "
        strSQL &= "             Left JOIN Proveedores p ON p.pro_sisemp = h.HDoc_Sis_Emp AND p.pro_codigo = h.HDoc_Emp_Cod  "
        strSQL &= "             WHERE h.HDoc_Sis_Emp = {empresa} AND h.HDoc_Doc_Cat = {catalogo} AND h.HDoc_Doc_Ano = {anio} AND h.HDoc_Doc_Num ={numero} "

        If Sesion.IdEmpresa = 18 Then
            strSQL &= ";INSERT INTO contapdm.polizas"
            strSQL &= "  SELECT h.HDoc_Sis_Emp , {ejercicio},{poliza}, '{fec}', CONCAT('PARA REGISTRAR NOTA DE CREDITO PROVEEDOR NO.',h.HDoc_Doc_Num,' ','Serie ',h.HDoc_DR2_Num,' / ',h.HDoc_Doc_Fec,' / ',h.HDoc_RF2_Cod,' / ',p.pro_proveedor,' / ',h.HDoc_RF1_Cod) concepto, 26,h.HDoc_Doc_TC,'' Observacion,h.HDoc_Usuario,'C',now(), '' Grupo, "
            strSQL &= "     26,h.HDoc_Doc_Cat, h.HDoc_Doc_Ano , h.HDoc_Doc_Num , null,h.HDoc_Doc_TC,0,null,null "
            strSQL &= "         FROM PDM.Dcmtos_HDR h "
            strSQL &= "             Left JOIN PDM.Proveedores p ON p.pro_sisemp = h.HDoc_Sis_Emp AND p.pro_codigo = h.HDoc_Emp_Cod  "
            strSQL &= "             WHERE h.HDoc_Sis_Emp = {empresa} AND h.HDoc_Doc_Cat = {catalogo} AND h.HDoc_Doc_Ano = {anio} AND h.HDoc_Doc_Num ={numero} "
        End If

        strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
        strSQL = Replace(strSQL, "{catalogo}", Catalogo)
        strSQL = Replace(strSQL, "{anio}", Anio)
        strSQL = Replace(strSQL, "{numero}", Numero)
        strSQL = Replace(strSQL, "{poliza}", Poliza)
        strSQL = Replace(strSQL, "{concepto}", strConcepto)
        strSQL = Replace(strSQL, "{conta}", cFunciones.ContaEmpresa)
        strSQL = Replace(strSQL, "{ejercicio}", Ejercicio)
        strSQL = Replace(strSQL, "{fec}", fec.ToString(FORMATO_MYSQL))

        Return strSQL
    End Function

    Private Function DetallePolizaNCreditoProveedor(ByVal db As String, ByVal conta As String, ByVal Catalogo As Integer, ByVal Anio As Integer, ByVal Numero As Integer, ByVal ejercicio As Integer, ByVal poliza As Long, ByVal IVA As Double) As String
        Dim strSQL As String

        strSQL = " INSERT INTO {conta}.detalle_polizas"
        strSQL &= "     SELECT 0 Transaccion,h.HDoc_Sis_Emp , {ejercicio},{poliza},  1  AS `posicion` ,p.pro_cuenta ,0 Numero,ROUND((IF(h.HDoc_RF2_Dbl < 0,(h.HDoc_RF2_Dbl * -1) * h.HDoc_Doc_TC, h.HDoc_RF2_Dbl * h.HDoc_Doc_TC )),2) Base  "
        strSQL &= "         ,'','',IF(h.HDoc_RF2_Dbl < 0,'A','C'),h.HDoc_Doc_Fec,'',26,h.HDoc_Doc_Cat,h.HDoc_Doc_Ano , h.HDoc_Doc_Num,0 "
        strSQL &= "             FROM {db}Dcmtos_HDR h "
        strSQL &= "                 LEFT JOIN {db}Proveedores p ON p.pro_sisemp = h.HDoc_Sis_Emp AND p.pro_codigo = h.HDoc_Emp_Cod "
        strSQL &= "                     LEFT JOIN {db}Dcmtos_IMP imp ON imp.MDoc_Sis_Emp = h.HDoc_Sis_Emp AND imp.MDoc_Doc_Cat = h.HDoc_Doc_Cat AND imp.MDoc_Doc_Ano = h.HDoc_Doc_Ano AND imp.MDoc_Doc_Num = h.HDoc_Doc_Num "
        strSQL &= "                         WHERE h.HDoc_Sis_Emp = {empresa} AND h.HDoc_Doc_Cat = 39 AND h.HDoc_Doc_Ano = {anio} AND h.HDoc_Doc_Num = {numero} "
        strSQL &= "                             UNION  "
        ' Query De Retencion IVA
        If Sesion.idGiro = 2 Then
            If Pais() = 851 Then
                strSQL &= "                                 SELECT  0 Transaccion,h.HDoc_Sis_Emp, {ejercicio},{poliza}, 2 Linea, l.DDoc_RF1_Txt Valor, 0 , "
                strSQL &= "                                     IF(h.HDoc_DR2_Cat IN(1),imp.MDoc_Lin_Monto * h.HDoc_Doc_TC, IF(h.HDoc_DR2_Cat = 0 ,imp.MDoc_Lin_Monto * h.HDoc_Doc_TC,imp.MDoc_Lin_Monto* h.HDoc_Doc_TC)) Base, "
                strSQL &= "                                         '','','A',h.HDoc_Doc_Fec,'',26,h.HDoc_Doc_Cat,h.HDoc_Doc_Ano, h.HDoc_Doc_Num,0 "
                strSQL &= "                                             FROM {db}Dcmtos_HDR h "
                strSQL &= "                                                 LEFT JOIN {db}Proveedores p ON p.pro_sisemp = h.HDoc_Sis_Emp AND p.pro_codigo = h.HDoc_Emp_Cod "
                strSQL &= "                                                     LEFT JOIN {db}Dcmtos_IMP imp ON imp.MDoc_Sis_Emp = h.HDoc_Sis_Emp AND imp.MDoc_Doc_Cat = h.HDoc_Doc_Cat AND imp.MDoc_Doc_Ano = h.HDoc_Doc_Ano AND imp.MDoc_Doc_Num = h.HDoc_Doc_Num "
                strSQL &= "                                                         LEFT JOIN {db}ECtaCte e ON e.ECta_Sis_Emp = h.HDoc_Sis_Emp AND e.ECta_Doc_Cat = h.HDoc_Doc_Cat AND e.ECta_Doc_Ano = h.HDoc_Doc_Ano AND e.ECta_Doc_Num = h.HDoc_Doc_Num "
                strSQL &= "                                                             LEFT JOIN {db}Dcmtos_HDR d ON d.HDoc_Sis_Emp = e.ECta_Sis_Emp AND d.HDoc_Doc_Cat = e.ECta_Ref_Cat AND d.HDoc_Doc_Ano = e.ECta_Ref_Ano AND d.HDoc_Doc_Num = e.ECta_Ref_Num "
                strSQL &= "                                                             LEFT JOIN {db}Dcmtos_DTL l ON l.DDoc_Sis_Emp = d.HDoc_Sis_Emp AND l.DDoc_Doc_Cat = d.HDoc_Doc_Cat AND l.DDoc_Doc_Ano = d.HDoc_Doc_Ano AND l.DDoc_Doc_Num = d.HDoc_Doc_Num "
                strSQL &= "                                                                 LEFT JOIN {conta}.parametros pa ON IF(h.HDoc_DR2_Cat = 1 , pa.parametro = 53, IF(h.HDoc_DR2_Cat=0,pa.parametro =28,pa.parametro = 28)) AND pa.categoria = 'Contables' "
                strSQL &= "                                                                     LEFT JOIN {conta}.parametros_empresa pe ON pe.empresa = h.HDoc_Sis_Emp AND pe.parametro = pa.parametro "
                strSQL &= "                                                                         WHERE h.HDoc_Sis_Emp = {empresa} AND h.HDoc_Doc_Cat = 39 AND h.HDoc_Doc_Ano = {anio} AND h.HDoc_Doc_Num = {numero} AND LENGTH(l.DDoc_RF1_Txt)>0 GROUP BY l.DDoc_RF1_Txt "
                strSQL &= "                                                                     UNION "
            End If
        Else
            strSQL &= "                                 SELECT  0 Transaccion,h.HDoc_Sis_Emp, {ejercicio},{poliza}, 2 Linea, IF(h.HDoc_DR2_Cat IN(1),pe.valor, IF(h.HDoc_DR2_Cat = 0,pe.valor,pe.valor)) Valor, 0 , "
            strSQL &= "                                     IF(imp.MDoc_Lin_Monto < 0, 
                                                        IF(h.HDoc_DR2_Cat IN(1),imp.MDoc_Lin_Monto * h.HDoc_Doc_TC, IF(h.HDoc_DR2_Cat = 0,imp.MDoc_Lin_Monto * h.HDoc_Doc_TC,imp.MDoc_Lin_Monto* h.HDoc_Doc_TC)) * -1, IF(h.HDoc_DR2_Cat IN(1),imp.MDoc_Lin_Monto * h.HDoc_Doc_TC, IF(h.HDoc_DR2_Cat = 0,imp.MDoc_Lin_Monto * h.HDoc_Doc_TC,imp.MDoc_Lin_Monto* h.HDoc_Doc_TC))) Base, "
            strSQL &= "                                         '','',if(imp.MDoc_Lin_Monto < 0, 'C','A'),h.HDoc_Doc_Fec,'',26,h.HDoc_Doc_Cat,h.HDoc_Doc_Ano, h.HDoc_Doc_Num,0 "
            strSQL &= "                                             FROM {db}Dcmtos_HDR h "
            strSQL &= "                                                 LEFT JOIN {db}Proveedores p ON p.pro_sisemp = h.HDoc_Sis_Emp AND p.pro_codigo = h.HDoc_Emp_Cod "
            strSQL &= "                                                     LEFT JOIN {db}Dcmtos_IMP imp ON imp.MDoc_Sis_Emp = h.HDoc_Sis_Emp AND imp.MDoc_Doc_Cat = h.HDoc_Doc_Cat AND imp.MDoc_Doc_Ano = h.HDoc_Doc_Ano AND imp.MDoc_Doc_Num = h.HDoc_Doc_Num "
            strSQL &= "                                                         LEFT JOIN {db}ECtaCte e ON e.ECta_Sis_Emp = h.HDoc_Sis_Emp AND e.ECta_Doc_Cat = h.HDoc_Doc_Cat AND e.ECta_Doc_Ano = h.HDoc_Doc_Ano AND e.ECta_Doc_Num = h.HDoc_Doc_Num "
            strSQL &= "                                                             LEFT JOIN {db}Dcmtos_HDR d ON d.HDoc_Sis_Emp = e.ECta_Sis_Emp AND d.HDoc_Doc_Cat = e.ECta_Ref_Cat AND d.HDoc_Doc_Ano = e.ECta_Ref_Ano AND d.HDoc_Doc_Num = e.ECta_Ref_Num "
            strSQL &= "                                                                 LEFT JOIN {conta}.parametros pa ON IF(h.HDoc_DR2_Cat = 1 , pa.parametro = 53, IF(h.HDoc_DR2_Cat=0,pa.parametro =28,pa.parametro = 28)) AND pa.categoria = 'Contables' "
            strSQL &= "                                                                     LEFT JOIN {conta}.parametros_empresa pe ON pe.empresa = h.HDoc_Sis_Emp AND pe.parametro = pa.parametro "
            strSQL &= "                                                                         WHERE h.HDoc_Sis_Emp = {empresa} AND h.HDoc_Doc_Cat = 39 AND h.HDoc_Doc_Ano = {anio} AND h.HDoc_Doc_Num = {numero} AND d.HDoc_DR1_Emp != -1 AND d.HDoc_DR1_Emp != 2 "
            strSQL &= "                                                                     UNION "
        End If

        ' Query de Gastos 
        strSQL &= "             SELECT Transaccion,HDoc_Sis_Emp,ejercicio,poliza,Linea,Cuenta,0,SUM(base2) as base ,DDoc_RF3_Num,vacio,movimiento,fecha,vacio2,26,HDoc_Doc_Cat,HDoc_Doc_Ano,HDoc_Doc_Num,00
                                FROM (
                                    SELECT 0 Transaccion,h.HDoc_Sis_Emp , {ejercicio} as ejercicio,{poliza} as poliza, @rownum:=@rownum +1 Linea  ,IFNULL(dt.DDoc_RF1_Cod,'') Cuenta ,0 as '0', "
        If Sesion.idGiro = 1 Then
            strSQL &= " IF(dt.DDoc_Prd_NET < 0, (ROUND(IF(IFNULL(d.HDoc_DR1_Emp,-1) IN(-1,2),(dt.DDoc_Prd_NET * h.HDoc_Doc_TC), (dt.DDoc_Prd_NET * h.HDoc_Doc_TC) / {iva}),2) * -1),  ROUND(IF(IFNULL(d.HDoc_DR1_Emp,-1) IN(-1,2),(dt.DDoc_Prd_NET * h.HDoc_Doc_TC), (dt.DDoc_Prd_NET * h.HDoc_Doc_TC) / {iva}),2))Base2,"
        Else
            strSQL &= " IF(LENGTH(tl.DDoc_RF1_Txt)>0,ROUND(IF(IFNULL(d.HDoc_DR1_Emp,-1) IN(-1,2),h.HDoc_RF2_Dbl * h.HDoc_Doc_TC ,IF(d.HDoc_DR2_Cat IN(1),(h.HDoc_RF2_Dbl * h.HDoc_Doc_TC )/ {iva},IF(d.HDoc_DR2_Cat = 0,h.HDoc_RF2_Dbl * h.HDoc_Doc_TC / {iva} ,h.HDoc_RF2_Dbl * h.HDoc_Doc_TC  / {iva} ))),2), h.HDoc_RF2_Dbl * h.HDoc_Doc_TC) Base2, "
        End If

        strSQL &= "                                                         dt.DDoc_RF3_Num,'' as vacio,IF(dt.DDoc_Prd_NET < 0, 'C','A') as movimiento,h.HDoc_Doc_Fec fecha,'' as vacio2,26 as '26',h.HDoc_Doc_Cat,h.HDoc_Doc_Ano , h.HDoc_Doc_Num,0 as '00' "
        strSQL &= "                                                     FROM (SELECT @rownum:= 2) r ,  {db}Dcmtos_HDR AS  h "
        strSQL &= "                                                 LEFT JOIN {db}Proveedores p ON p.pro_sisemp = h.HDoc_Sis_Emp AND p.pro_codigo = h.HDoc_Emp_Cod "
        strSQL &= "                                             LEFT JOIN {db}Dcmtos_IMP imp ON imp.MDoc_Sis_Emp = h.HDoc_Sis_Emp AND imp.MDoc_Doc_Cat = h.HDoc_Doc_Cat AND imp.MDoc_Doc_Ano = h.HDoc_Doc_Ano AND imp.MDoc_Doc_Num = h.HDoc_Doc_Num "
        strSQL &= "                                         LEFT JOIN {db}ECtaCte e ON e.ECta_Sis_Emp = h.HDoc_Sis_Emp AND e.ECta_Doc_Cat = h.HDoc_Doc_Cat AND e.ECta_Doc_Ano = h.HDoc_Doc_Ano AND e.ECta_Doc_Num = h.HDoc_Doc_Num "
        strSQL &= "                                     LEFT JOIN {db}Dcmtos_HDR d ON d.HDoc_Sis_Emp = e.ECta_Sis_Emp AND d.HDoc_Doc_Cat = e.ECta_Ref_Cat AND d.HDoc_Doc_Ano = e.ECta_Ref_Ano AND d.HDoc_Doc_Num = e.ECta_Ref_Num "
        strSQL &= "                                 LEFT JOIN {db}Dcmtos_DTL dt ON dt.DDoc_Sis_Emp =h.HDoc_Sis_Emp AND dt.DDoc_Doc_Cat = h.HDoc_Doc_Cat AND dt.DDoc_Doc_Ano = h.HDoc_Doc_Ano AND dt.DDoc_Doc_Num = h.HDoc_Doc_Num "
        strSQL &= "                                 LEFT JOIN {db}Dcmtos_DTL tl ON tl.DDoc_Sis_Emp = e.ECta_Sis_Emp AND tl.DDoc_Doc_Cat = e.ECta_Ref_Cat AND tl.DDoc_Doc_Ano = e.ECta_Ref_Ano AND tl.DDoc_Doc_Num = e.ECta_Ref_Num "
        strSQL &= "                              LEFT JOIN {conta}.parametros pa ON IF(d.HDoc_DR1_Emp IN(-1,2),pa.parametro = 53, IF(d.HDoc_DR2_Cat IN(0),pa.parametro = 52,pa.parametro = 52 ))  AND pa.categoria = 'Contables' "
        strSQL &= "                          LEFT JOIN {conta}.parametros_empresa pe ON pe.empresa = h.HDoc_Sis_Emp AND pe.parametro = pa.parametro "
        strSQL &= "                     WHERE h.HDoc_Sis_Emp = {empresa} AND h.HDoc_Doc_Cat = 39 AND h.HDoc_Doc_Ano = {anio} AND h.HDoc_Doc_Num = {numero} "
        ' <<<<<<< Updated upstream
        strSQL &= "                 GROUP BY h.HDoc_Doc_Cat,h.HDoc_Doc_Ano,h.HDoc_Doc_Num, dt.DDoc_Doc_Lin, dt.DDoc_RF1_Cod 
                                ) A"

        strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
        strSQL = Replace(strSQL, "{anio}", Anio)
        strSQL = Replace(strSQL, "{numero}", Numero)
        strSQL = Replace(strSQL, "{ejercicio}", ejercicio)
        strSQL = Replace(strSQL, "{poliza}", poliza)
        strSQL = Replace(strSQL, "{conta}", conta)
        strSQL = Replace(strSQL, "{db}", db)
        If Not Sesion.IdEmpresa = 11 Then
            strSQL = Replace(strSQL, "{iva}", IVA)
        Else
            strSQL = Replace(strSQL, "{iva}", 1)
        End If

        Return strSQL
    End Function

    Private Function DetallePolizaNCreditoProveedor(ByVal Catalogo As Integer, ByVal Anio As Integer, ByVal Numero As Integer, ByVal ejercicio As Integer, ByVal poliza As Long, ByVal IVA As Double) As String
        Dim strSQL As String = DetallePolizaNCreditoProveedor(STR_VACIO, cFunciones.ContaEmpresa, Catalogo, Anio, Numero, ejercicio, poliza, IVA)
        If Sesion.IdEmpresa = 18 Then
            strSQL = String.Concat(strSQL, ";", DetallePolizaNCreditoProveedor("PDM.", "contapdm", Catalogo, Anio, Numero, ejercicio, poliza, IVA))
        End If

        Return strSQL
    End Function

    Private Sub PolizaNCreditoProveedor(ByVal intCatalgo As Integer, ByVal intAnio As Integer, ByVal intNumero As Integer, ByVal fec As Date)
        Dim longPoliza As Long = NO_FILA
        Dim strSQL As String = STR_VACIO
        Dim dblIva As Double
        Dim COM As MySqlCommand
        Dim COM2 As MySqlCommand
        Try

            longPoliza = NuevaPoliza()
            UltimaPoliza(longPoliza, EJERCICIO) ' actualiza la ultima poliza

            'Genera Encabezado
            strSQL = SQLEncabezadoNCreditoProveedor(intCatalgo, intAnio, intNumero, EJERCICIO, longPoliza, fec)
            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSQL, CON)
            COM.ExecuteNonQuery()
            strSQL = STR_VACIO

            dblIva = IVA()
            dblIva = (100 + dblIva) / 100

            strSQL = DetallePolizaNCreditoProveedor(intCatalgo, intAnio, intNumero, EJERCICIO, longPoliza, dblIva)
            MyCnn.CONECTAR = strConexion & ";Allow User Variables=True"
            COM2 = New MySqlCommand(strSQL, CON)
            COM2.ExecuteNonQuery()


        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

#End Region

#Region "Poliza de Liquidación Caja Chica"
    Private Function SQLEncabezadoLiquidacionCajaC(ByVal intCatalogo As Integer, ByVal intAnio As Integer, ByVal intNumero As Integer, ByVal intEjercicio As Integer, ByVal intPoliza As Long, ByVal fec As Date) As String
        Dim strSQL As String = STR_VACIO

        strSQL = " INSERT INTO {conta}.polizas"
        strSQL &= "  SELECT h.HDoc_Sis_Emp Empresa,{ejercicio} AS ejercicio ,{poliza} AS poliza , '{fecha}', CONCAT('Poliza de Liquidación Nº ', h.HDoc_DR1_Num ,' ',c.BCta_Des_Cue,' ',c.BCta_Nom_Cue, "
        strSQL &= "     ' de Fecha ',h.HDoc_Doc_Fec) AS  Concepto , 22 AS tipo , h.HDoc_Doc_TC as Tasa , '' as Observacion  , '{usuario}' AS Usuario,'C' As Estado , now(), "
        strSQL &= "         2 , 22, h.HDoc_Doc_Cat Categoria , h.HDoc_Doc_Ano Anio, h.HDoc_Doc_Num Numero,null,h.HDoc_Doc_TC,0,null,null "
        strSQL &= "             FROM Dcmtos_HDR h "
        strSQL &= "                 INNER JOIN CtasBcos c ON c.BCta_Sis_Emp = h.HDoc_Sis_Emp AND c.BCta_Num = h.HDoc_DR1_Cat "
        strSQL &= "                     WHERE h.HDoc_Sis_Emp = {empresa} AND h.HDoc_Doc_Cat = {catalogo} AND h.HDoc_Doc_Ano = {anio} AND h.HDoc_Doc_Num = {numero} "
        If Sesion.IdEmpresa = 18 Then
            strSQL &= "; INSERT INTO contapdm.polizas"
            strSQL &= "  SELECT h.HDoc_Sis_Emp Empresa,{ejercicio} AS ejercicio ,{poliza} AS poliza , '{fecha}', CONCAT('Poliza de Liquidación Nº ', h.HDoc_DR1_Num ,' ',c.BCta_Des_Cue,' ',c.BCta_Nom_Cue, "
            strSQL &= "     ' de Fecha ',h.HDoc_Doc_Fec) AS  Concepto , 22 AS tipo , h.HDoc_Doc_TC as Tasa , '' as Observacion  , '{usuario}' AS Usuario,'C' As Estado , now(), "
            strSQL &= "         2 , 22, h.HDoc_Doc_Cat Categoria , h.HDoc_Doc_Ano Anio, h.HDoc_Doc_Num Numero,null,h.HDoc_Doc_TC,0,null,null "
            strSQL &= "             FROM PDM.Dcmtos_HDR h "
            strSQL &= "                 INNER JOIN PDM.CtasBcos c ON c.BCta_Sis_Emp = h.HDoc_Sis_Emp AND c.BCta_Num = h.HDoc_DR1_Cat "
            strSQL &= "                     WHERE h.HDoc_Sis_Emp = {empresa} AND h.HDoc_Doc_Cat = {catalogo} AND h.HDoc_Doc_Ano = {anio} AND h.HDoc_Doc_Num = {numero} "
        End If
        strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
        strSQL = Replace(strSQL, "{catalogo}", intCatalogo)
        strSQL = Replace(strSQL, "{anio}", intAnio)
        strSQL = Replace(strSQL, "{numero}", intNumero)
        strSQL = Replace(strSQL, "{ejercicio}", intEjercicio)
        strSQL = Replace(strSQL, "{poliza}", intPoliza)
        strSQL = Replace(strSQL, "{usuario}", Sesion.Usuario)
        strSQL = Replace(strSQL, "{conta}", Sesion.BaseConta)
        strSQL = Replace(strSQL, "{fecha}", fec.ToString(FORMATO_MYSQL))
        Return strSQL
    End Function

    Private Function SQLDetalleLiquidacionCajaC(ByVal intCatalogo As Integer, ByVal intAnio As Integer, ByVal intNumero As Integer, ByVal intEjercicio As Integer, ByVal intPoliza As Long)
        Dim strSQL As String = STR_VACIO

        strSQL = " SET @REG:=0; INSERT INTO {conta}.detalle_polizas "
        strSQL &= " SELECT s1.transaccion,s1.empresa,s1.ejercicio,s1.poliza,(@REG := @REG + 1) item, IFNULL(s1.cuenta,''),s1.parametroCuenta,s1.importe,s1.centroCosto,s1.partidaPresupuestal,s1.operacion,s1.Fecha,s1.clase,s1.modo,s1.refTipo,s1.refCiclo,s1.refNumero,s1.id "
        strSQL &= " FROM ( "
        strSQL &= "    SELECT 0 transaccion, h.HDoc_Sis_Emp empresa, '{ejercicio}' ejercicio, '{poliza}' poliza,@REG :=0, t.DDoc_RF1_Cod cuenta, 1 parametroCuenta, ROUND(SUM(t.DDoc_RF1_Dbl * r.HDoc_Doc_TC),2) importe,t.DDoc_RF3_Num centroCosto, '' partidaPresupuestal, 'C' operacion, h.HDoc_Doc_Fec Fecha,0 clase, 22 modo, h.HDoc_Doc_Cat refTipo, h.HDoc_Doc_Ano refCiclo, h.HDoc_Doc_Num refNumero, 0 id, CONCAT(r.HDoc_Doc_Cat,r.HDoc_Doc_Ano,r.HDoc_Doc_Num) recibo "
        strSQL &= "      FROM Dcmtos_HDR h "
        strSQL &= "      Left JOIN Dcmtos_DTL d ON d.DDoc_Sis_Emp = h.HDoc_Sis_Emp AND d.DDoc_Doc_Cat = h.HDoc_Doc_Cat AND d.DDoc_Doc_Ano = h.HDoc_Doc_Ano AND d.DDoc_Doc_Num = h.HDoc_Doc_Num AND d.DDoc_Prd_Cod = 209 "
        strSQL &= "      Left JOIN Dcmtos_HDR r ON r.HDoc_Sis_Emp = d.DDoc_Sis_Emp AND r.HDoc_Doc_Cat = d.DDoc_Prd_Cod AND r.HDoc_Doc_Ano = d.DDoc_RF1_Num AND r.HDoc_Doc_Num = d.DDoc_Prd_UM "
        strSQL &= "      Left JOIN Dcmtos_DTL t ON t.DDoc_Sis_Emp = r.HDoc_Sis_Emp AND t.DDoc_Doc_Cat = r.HDoc_Doc_Cat AND t.DDoc_Doc_Ano = r.HDoc_Doc_Ano AND t.DDoc_Doc_Num = r.HDoc_Doc_Num "
        strSQL &= "          WHERE h.HDoc_Sis_Emp = {empresa} AND h.HDoc_Doc_Cat = 246 AND h.HDoc_Doc_Ano = {anio} AND h.HDoc_Doc_Num = {numero} "
        strSQL &= "          GROUP BY t.DDoc_RF1_Cod,t.DDoc_RF3_Num UNION " 'Finalizan los cargos
        strSQL &= "    Select  0,{empresa},{ejercicio},{poliza},@REG :=0 item, b.BCta_Cuenta cuenta, 1 parametro_cuenta, ( "
        strSQL &= "    Select ROUND(SUM(d.DDoc_RF1_Dbl * r.HDoc_Doc_TC),2) importe "
        strSQL &= "        From Dcmtos_DTL d "
        strSQL &= "        Left JOIN Dcmtos_HDR r ON r.HDoc_Sis_Emp = d.DDoc_Sis_Emp AND r.HDoc_Doc_Cat = d.DDoc_Prd_Cod AND r.HDoc_Doc_Ano = d.DDoc_RF1_Num AND r.HDoc_Doc_Num = d.DDoc_Prd_UM "
        strSQL &= "        WHERE d.DDoc_Sis_Emp = h.HDoc_Sis_Emp AND d.DDoc_Doc_Cat = h.HDoc_Doc_Cat AND d.DDoc_Doc_Ano = h.HDoc_Doc_Ano AND d.DDoc_Doc_Num = h.HDoc_Doc_Num AND d.DDoc_Prd_Cod = 209 "
        strSQL &= "        ) importe, '' centro_Costo, '' partida_Presupuestal, 'A' operacion, h.HDoc_Doc_Fec, 0 clase,8 modo, h.HDoc_Doc_Cat tipo, h.HDoc_Doc_Ano cilco, h.HDoc_Doc_Num num,0 id, 0 a "
        strSQL &= "        From Dcmtos_HDR h "
        strSQL &= "        Left JOIN CtasBcos b ON b.BCta_Sis_Emp = h.HDoc_Sis_Emp And b.BCta_Num = h.HDoc_DR1_Cat "
        strSQL &= "        WHERE h.HDoc_Sis_Emp = {empresa} And h.HDoc_Doc_Cat = 246 And h.HDoc_Doc_Ano = {anio} And h.HDoc_Doc_Num = {numero})s1 "

        If Sesion.IdEmpresa = 18 Then
            strSQL &= "; SET @REG:=0; INSERT INTO contapdm.detalle_polizas "
            strSQL &= " SELECT s1.transaccion,s1.empresa,s1.ejercicio,s1.poliza,(@REG := @REG + 1) item, IFNULL(s1.cuenta,''),s1.parametroCuenta,s1.importe,s1.centroCosto,s1.partidaPresupuestal,s1.operacion,s1.Fecha,s1.clase,s1.modo,s1.refTipo,s1.refCiclo,s1.refNumero,s1.id "
            strSQL &= " FROM ( "
            strSQL &= "    SELECT 0 transaccion, h.HDoc_Sis_Emp empresa, '{ejercicio}' ejercicio, '{poliza}' poliza,@REG :=0, t.DDoc_RF1_Cod cuenta, 1 parametroCuenta, ROUND(SUM(t.DDoc_RF1_Dbl * r.HDoc_Doc_TC),2) importe,t.DDoc_RF3_Num centroCosto, '' partidaPresupuestal, 'C' operacion, h.HDoc_Doc_Fec Fecha,0 clase, 22 modo, h.HDoc_Doc_Cat refTipo, h.HDoc_Doc_Ano refCiclo, h.HDoc_Doc_Num refNumero, 0 id, CONCAT(r.HDoc_Doc_Cat,r.HDoc_Doc_Ano,r.HDoc_Doc_Num) recibo "
            strSQL &= "      FROM PDM.Dcmtos_HDR h "
            strSQL &= "      Left JOIN PDM.Dcmtos_DTL d ON d.DDoc_Sis_Emp = h.HDoc_Sis_Emp AND d.DDoc_Doc_Cat = h.HDoc_Doc_Cat AND d.DDoc_Doc_Ano = h.HDoc_Doc_Ano AND d.DDoc_Doc_Num = h.HDoc_Doc_Num AND d.DDoc_Prd_Cod = 209 "
            strSQL &= "      Left JOIN PDM.Dcmtos_HDR r ON r.HDoc_Sis_Emp = d.DDoc_Sis_Emp AND r.HDoc_Doc_Cat = d.DDoc_Prd_Cod AND r.HDoc_Doc_Ano = d.DDoc_RF1_Num AND r.HDoc_Doc_Num = d.DDoc_Prd_UM "
            strSQL &= "      Left JOIN PDM.Dcmtos_DTL t ON t.DDoc_Sis_Emp = r.HDoc_Sis_Emp AND t.DDoc_Doc_Cat = r.HDoc_Doc_Cat AND t.DDoc_Doc_Ano = r.HDoc_Doc_Ano AND t.DDoc_Doc_Num = r.HDoc_Doc_Num "
            strSQL &= "          WHERE h.HDoc_Sis_Emp = {empresa} AND h.HDoc_Doc_Cat = 246 AND h.HDoc_Doc_Ano = {anio} AND h.HDoc_Doc_Num = {numero} "
            strSQL &= "          GROUP BY t.DDoc_RF1_Cod,t.DDoc_RF3_Num UNION " 'Finalizan los cargos
            strSQL &= "    Select  0,{empresa},{ejercicio},{poliza},@REG :=0 item, b.BCta_Cuenta cuenta, 1 parametro_cuenta, ( "
            strSQL &= "    Select ROUND(SUM(d.DDoc_RF1_Dbl * r.HDoc_Doc_TC),2) importe "
            strSQL &= "        From PDM.Dcmtos_DTL d "
            strSQL &= "        Left JOIN PDM.Dcmtos_HDR r ON r.HDoc_Sis_Emp = d.DDoc_Sis_Emp AND r.HDoc_Doc_Cat = d.DDoc_Prd_Cod AND r.HDoc_Doc_Ano = d.DDoc_RF1_Num AND r.HDoc_Doc_Num = d.DDoc_Prd_UM "
            strSQL &= "        WHERE d.DDoc_Sis_Emp = h.HDoc_Sis_Emp AND d.DDoc_Doc_Cat = h.HDoc_Doc_Cat AND d.DDoc_Doc_Ano = h.HDoc_Doc_Ano AND d.DDoc_Doc_Num = h.HDoc_Doc_Num AND d.DDoc_Prd_Cod = 209 "
            strSQL &= "        ) importe, '' centro_Costo, '' partida_Presupuestal, 'A' operacion, h.HDoc_Doc_Fec, 0 clase,8 modo, h.HDoc_Doc_Cat tipo, h.HDoc_Doc_Ano cilco, h.HDoc_Doc_Num num,0 id, 0 a "
            strSQL &= "        From PDM.Dcmtos_HDR h "
            strSQL &= "        Left JOIN PDM.CtasBcos b ON b.BCta_Sis_Emp = h.HDoc_Sis_Emp And b.BCta_Num = h.HDoc_DR1_Cat "
            strSQL &= "        WHERE h.HDoc_Sis_Emp = {empresa} And h.HDoc_Doc_Cat = 246 And h.HDoc_Doc_Ano = {anio} And h.HDoc_Doc_Num = {numero})s1 "
        End If

        strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
        strSQL = Replace(strSQL, "{catalogo}", intCatalogo)
        strSQL = Replace(strSQL, "{anio}", intAnio)
        strSQL = Replace(strSQL, "{numero}", intNumero)
        strSQL = Replace(strSQL, "{ejercicio}", intEjercicio)
        strSQL = Replace(strSQL, "{poliza}", intPoliza)
        strSQL = Replace(strSQL, "{conta}", Sesion.BaseConta)


        Return strSQL
    End Function
    Private Sub PolizaLiquidacacionCajaC(ByVal intCatalogo As Integer, ByVal intAnio As Integer, ByVal intNumero As Integer, ByVal fec As Date)
        Dim longPoliza As Long = NO_FILA
        Dim strSQL As String = STR_VACIO
        Dim intCuentaRecibos As Integer = NO_FILA


        Dim COM As MySqlCommand
        Dim conec As MySqlConnection

        Try
            strSQL = " SELECT COUNT(*) FROM Dcmtos_DTL d "
            strSQL &= "    WHERE d.DDoc_Sis_Emp = {empresa} AND d.DDoc_Doc_Cat = {cat} AND d.DDoc_Doc_Ano = {anio} AND d.DDoc_Doc_Num = {num} AND d.DDoc_Prd_Cod = 209 "

            strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
            strSQL = Replace(strSQL, "{cat}", intCatalogo)
            strSQL = Replace(strSQL, "{anio}", intAnio)
            strSQL = Replace(strSQL, "{num}", intNumero)
            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSQL, CON)
            intCuentaRecibos = COM.ExecuteScalar

            If intCuentaRecibos > 0 Then
                strSQL = STR_VACIO
                longPoliza = NuevaPoliza()
                UltimaPoliza(longPoliza, EJERCICIO) ' actualiza la ultima poliza

                strSQL = SQLEncabezadoLiquidacionCajaC(intCatalogo, intAnio, intNumero, EJERCICIO, longPoliza, fec)
                MyCnn.CONECTAR = strConexion
                COM = New MySqlCommand(strSQL, CON)
                COM.ExecuteNonQuery()
                strSQL = STR_VACIO
                'GeneraDetalle
                conec = New MySqlConnection(strConexion & ";Allow User Variables=True")
                conec.Open()
                strSQL = SQLDetalleLiquidacionCajaC(intCatalogo, intAnio, intNumero, EJERCICIO, longPoliza)
                COM = New MySqlCommand(strSQL, conec)
                COM.ExecuteNonQuery()
                conec.Close()
                conec.Dispose()
                conec = Nothing
                strSQL = STR_VACIO
            End If

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub
#End Region

#Region " Factura 296"
    Private Function TipoFactura(ByVal ano As Integer, ByVal num As Integer) As Integer
        Dim intTipo As Integer = NO_FILA
        Dim strSQL As String = STR_VACIO
        Dim COM As MySqlCommand
        Try
            strSQL = "  Select ifnull(HDoc_DR1_Cat,0) from Dcmtos_HDR h "
            strSQL &= "  where  h.HDoc_Sis_Emp = {empresa} and h.HDoc_Doc_Cat = 296 and h.HDoc_Doc_Ano = {ano} and h.HDoc_Doc_Num = {num}"

            strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
            strSQL = Replace(strSQL, "{ano}", ano)
            strSQL = Replace(strSQL, "{num}", num)

            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSQL, CON)
            intTipo = COM.ExecuteScalar


        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        Return intTipo
    End Function

    Private Function PolizaVenta296(ByVal ano As Integer, ByVal num As Integer, ByVal comp As Integer) As Boolean
        Dim logResultado As Boolean = False
        Dim longPoliza As Long = NO_FILA
        Dim COM As MySqlCommand
        Dim strSQL As String = STR_VACIO
        Dim TipoFac As Integer
        Try

            TipoFac = TipoFactura(ano, num)
            Select Case TipoFac
                Case INT_CERO, 2 ' factura de cobro y Factura Simple

                    'genenerar nueva poliza
                    longPoliza = NuevaPoliza()
                    UltimaPoliza(longPoliza, EJERCICIO) ' actualiza la ultima poliza
                    strSQL = SqlEncabezado296()

                    strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
                    strSQL = Replace(strSQL, "{ejercicio}", EJERCICIO)
                    strSQL = Replace(strSQL, "{poliza}", longPoliza)
                    strSQL = Replace(strSQL, "{usuario}", Sesion.Usuario)
                    strSQL = Replace(strSQL, "{ano}", ano)
                    strSQL = Replace(strSQL, "{numero}", num)
                    strSQL = Replace(strSQL, "{conta}", Sesion.BaseConta)
                    'inserta encabezado de la poliza
                    MyCnn.CONECTAR = strConexion
                    COM = New MySqlCommand(strSQL, CON)
                    COM.ExecuteNonQuery()
                    strSQL = STR_VACIO

                    strSQL = SqlDetalle296(STR_VACIO, TipoFac, comp)
                    strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
                    strSQL = Replace(strSQL, "{ejercicio}", EJERCICIO)
                    strSQL = Replace(strSQL, "{poliza}", longPoliza)
                    strSQL = Replace(strSQL, "{ano}", ano)
                    strSQL = Replace(strSQL, "{num}", num)
                    strSQL = Replace(strSQL, "{conta}", Sesion.BaseConta)
                    If Sesion.IdEmpresa = 18 Then
                        strSQL &= SqlDetalle296("PDM.", TipoFac, comp)
                        strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
                        strSQL = Replace(strSQL, "{ejercicio}", EJERCICIO)
                        strSQL = Replace(strSQL, "{poliza}", longPoliza)
                        strSQL = Replace(strSQL, "{ano}", ano)
                        strSQL = Replace(strSQL, "{num}", num)
                        strSQL = Replace(strSQL, "{conta}", "contapdm")
                    End If
                    'guardar Detalle
                    MyCnn.CONECTAR = strConexion
                    COM = New MySqlCommand(strSQL, CON)
                    COM.ExecuteNonQuery()


                Case INT_UNO ' factura credito fiscal (El Salvador)
                    'FacturaDeCostoCreditoFiscal(ano, num)
                    FacturaDeVentaCreditoFiscal(ano, num)

                    'Case 2 'Factura simple
            End Select
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try

        Return logResultado
    End Function

    Private Function SqlEncabezado296() As String
        Dim strSql As String = STR_VACIO

        strSql = " insert into {conta}.polizas "
        strSql &= " select {empresa},{ejercicio},{poliza}, h.HDoc_Doc_Fec , concat('Poliza de servicios aduanales No.', h.HDoc_Doc_Num , ' de fecha ', h.HDoc_Doc_Fec,' - ', h.HDoc_Emp_Nom ) , 9, h.HDoc_Doc_TC , 'observaciones', '{usuario}' , 'C', now(),'' , 9,  h.HDoc_Doc_Cat , h.HDoc_Doc_Ano , h.HDoc_Doc_Num , null,  h.HDoc_Doc_TC, 0, '', null "
        strSql &= "    from Dcmtos_HDR h "
        strSql &= " where h.HDoc_Sis_Emp = {empresa} and h.HDoc_Doc_Cat = 296 and h.HDoc_Doc_Ano = {ano} and h.HDoc_Doc_Num =  {numero} "

        If Sesion.IdEmpresa = 18 Then
            strSql &= "; insert into contapdm.polizas "
            strSql &= " select {empresa},{ejercicio},{poliza}, h.HDoc_Doc_Fec , concat('Poliza de servicios aduanales No.', h.HDoc_Doc_Num , ' de fecha ', h.HDoc_Doc_Fec,' - ', h.HDoc_Emp_Nom ) , 9, h.HDoc_Doc_TC , 'observaciones', '{usuario}' , 'C', now(),'' , 9,  h.HDoc_Doc_Cat , h.HDoc_Doc_Ano , h.HDoc_Doc_Num , null,  h.HDoc_Doc_TC, 0, '', null "
            strSql &= "    from PDM.Dcmtos_HDR h "
            strSql &= " where h.HDoc_Sis_Emp = {empresa} and h.HDoc_Doc_Cat = 296 and h.HDoc_Doc_Ano = {ano} and h.HDoc_Doc_Num =  {numero} "

        End If

        Return strSql

    End Function

    Private Function SqlDetalle296(ByVal db As String, ByVal tipoFact As Integer, ByVal comp As Integer) As String
        Dim strSQL As String = STR_VACIO

        strSQL = " insert into {conta}.detalle_polizas "
        '---------------------Linea del Cliente -------------------------------------------------------------------------------------------------------
        strSQL &= " SELECT 0,{empresa},{ejercicio},{poliza},1, c.cli_cuenta , 1, 
                    SUM(if(d.DDoc_Prd_Ref='comp',0,d.DDoc_RF1_Dbl) + if(d.DDoc_Prd_Ref='comp',0,d.DDoc_RF2_Dbl) + if(d.DDoc_Prd_Ref='comp',0,d.DDoc_RF3_Dbl) + if(d.DDoc_Prd_Ref='comp',d.DDoc_RF4_Dbl,0)) importe,
                    '' ,null, 'C', h.HDoc_Doc_Fec , 0,9,h.HDoc_Doc_Cat , h.HDoc_Doc_Ano , h.HDoc_Doc_Num ,0 "
        strSQL &= "    from Dcmtos_HDR h "
        If tipoFact = 0 Then
            strSQL &= "     LEFT JOIN {db}Dcmtos_HDR hh ON hh.HDoc_Sis_Emp =h.HDoc_Sis_Emp AND hh.HDoc_Pro_DCat = h.HDoc_Doc_Cat AND hh.HDoc_Pro_DAno = h.HDoc_Doc_Ano AND hh.HDoc_Pro_DNum = h.HDoc_Doc_Num  "
            strSQL &= "     LEFT JOIN {db}Dcmtos_DTL d ON d.DDoc_Sis_Emp = hh.HDoc_Sis_Emp AND d.DDoc_Doc_Cat = hh.HDoc_Doc_Cat AND d.DDoc_Doc_Ano = hh.HDoc_Doc_Ano AND d.DDoc_Doc_Num = hh.HDoc_Doc_Num "
        Else
            strSQL &= "  LEFT JOIN {db}Dcmtos_DTL d ON d.DDoc_Sis_Emp = h.HDoc_Sis_Emp AND d.DDoc_Doc_Cat = h.HDoc_Doc_Cat AND d.DDoc_Doc_Ano = h.HDoc_Doc_Ano AND "
            strSQL &= "  d.DDoc_Doc_Num = h.HDoc_Doc_Num "
        End If
        strSQL &= "     left join {db}Clientes c On c.cli_sisemp = h.HDoc_Sis_Emp  And c.cli_codigo = h.HDoc_Emp_Cod  "
        strSQL &= " where h.HDoc_Sis_Emp = {empresa} And h.HDoc_Doc_Cat = 296 And h.HDoc_Doc_Ano = {ano} And h.HDoc_Doc_Num =  {num} "

        '---------------------Linea del IVA--------------------------------------------------------------------------------------------------------------
        strSQL &= " union "
        strSQL &= " Select 0,{empresa},{ejercicio},{poliza},2, p.valor  , 1,  sum(i.MDoc_Lin_Monto  ) importe , '' ,null, 'A', h.HDoc_Doc_Fec , 0,9,h.HDoc_Doc_Cat , h.HDoc_Doc_Ano , h.HDoc_Doc_Num ,0 "
        strSQL &= "   from {db}Dcmtos_HDR h "
        If tipoFact = 0 Then
            strSQL &= "     LEFT JOIN {db}Dcmtos_HDR hh ON hh.HDoc_Sis_Emp =h.HDoc_Sis_Emp AND hh.HDoc_Pro_DCat = h.HDoc_Doc_Cat AND hh.HDoc_Pro_DAno = h.HDoc_Doc_Ano AND hh.HDoc_Pro_DNum = h.HDoc_Doc_Num  "
            strSQL &= "     LEFT JOIN {db}Dcmtos_DTL d ON d.DDoc_Sis_Emp = hh.HDoc_Sis_Emp AND d.DDoc_Doc_Cat = hh.HDoc_Doc_Cat AND d.DDoc_Doc_Ano = hh.HDoc_Doc_Ano AND d.DDoc_Doc_Num = hh.HDoc_Doc_Num "
        Else
            strSQL &= "  LEFT JOIN {db}Dcmtos_DTL d ON d.DDoc_Sis_Emp = h.HDoc_Sis_Emp AND d.DDoc_Doc_Cat = h.HDoc_Doc_Cat AND d.DDoc_Doc_Ano = h.HDoc_Doc_Ano AND "
            strSQL &= "  d.DDoc_Doc_Num = h.HDoc_Doc_Num "
        End If
        'strSQL &= "   LEFT JOIN Dcmtos_DTL d ON d.DDoc_Sis_Emp = h.HDoc_Sis_Emp AND d.DDoc_Doc_Cat = h.HDoc_Doc_Cat AND d.DDoc_Doc_Ano = h.HDoc_Doc_Ano AND d.DDoc_Doc_Num = h.HDoc_Doc_Num AND d.DDoc_Prd_Ref<>'comp' "
        strSQL &= "    LEFT JOIN {conta}.parametros_empresa p on p.empresa = h.HDoc_Sis_Emp and p.parametro = 50"
        strSQL &= "    LEFT JOIN {db}Dcmtos_IMP i on i.MDoc_Sis_Emp = h.HDoc_Sis_Emp and i.MDoc_Doc_Cat =  h.HDoc_Doc_Cat and i.MDoc_Doc_Ano = h.HDoc_Doc_Ano and i.MDoc_Doc_Num = h.HDoc_Doc_Num  AND d.DDoc_Doc_Lin=i.MDoc_Doc_Lin "
        strSQL &= " where h.HDoc_Sis_Emp = {empresa} and h.HDoc_Doc_Cat = 296 and h.HDoc_Doc_Ano = {ano} and h.HDoc_Doc_Num =  {num}  "

        '---------------------Linea del Gasto-------------------------------------------------------------------------------------------------------------
        strSQL &= "   union "
        strSQL &= " select 0,{empresa},{ejercicio},{poliza},2, p.valor  , 1,  sum(i.MDoc_Lin_Base) importe , '' ,null, 'A', h.HDoc_Doc_Fec , 0,9,h.HDoc_Doc_Cat , h.HDoc_Doc_Ano , h.HDoc_Doc_Num ,0 "
        strSQL &= "   from {db}Dcmtos_HDR h "
        If tipoFact = 0 Then
            strSQL &= "     LEFT JOIN {db}Dcmtos_HDR hh ON hh.HDoc_Sis_Emp =h.HDoc_Sis_Emp AND hh.HDoc_Pro_DCat = h.HDoc_Doc_Cat AND hh.HDoc_Pro_DAno = h.HDoc_Doc_Ano AND hh.HDoc_Pro_DNum = h.HDoc_Doc_Num  "
            strSQL &= "     LEFT JOIN {db}Dcmtos_DTL d ON d.DDoc_Sis_Emp = hh.HDoc_Sis_Emp AND d.DDoc_Doc_Cat = hh.HDoc_Doc_Cat AND d.DDoc_Doc_Ano = hh.HDoc_Doc_Ano AND d.DDoc_Doc_Num = hh.HDoc_Doc_Num "
        Else
            strSQL &= "  LEFT JOIN {db}Dcmtos_DTL d ON d.DDoc_Sis_Emp = h.HDoc_Sis_Emp AND d.DDoc_Doc_Cat = h.HDoc_Doc_Cat AND d.DDoc_Doc_Ano = h.HDoc_Doc_Ano AND "
            strSQL &= "  d.DDoc_Doc_Num = h.HDoc_Doc_Num "
        End If
        'strSQL &= "   LEFT JOIN Dcmtos_DTL d ON d.DDoc_Sis_Emp = h.HDoc_Sis_Emp AND d.DDoc_Doc_Cat = h.HDoc_Doc_Cat AND d.DDoc_Doc_Ano = h.HDoc_Doc_Ano AND d.DDoc_Doc_Num = h.HDoc_Doc_Num AND d.DDoc_Prd_Ref<>'comp' "
        strSQL &= "    left join {conta}.parametros_empresa p on p.empresa = h.HDoc_Sis_Emp and p.parametro = 17 "
        strSQL &= "    left join {db}Dcmtos_IMP i on i.MDoc_Sis_Emp = h.HDoc_Sis_Emp and i.MDoc_Doc_Cat =  h.HDoc_Doc_Cat  and i.MDoc_Doc_Ano = h.HDoc_Doc_Ano and i.MDoc_Doc_Num = h.HDoc_Doc_Num  AND d.DDoc_Doc_Lin=i.MDoc_Doc_Lin"
        strSQL &= " where h.HDoc_Sis_Emp = {empresa} and h.HDoc_Doc_Cat = 296 and h.HDoc_Doc_Ano = {ano} and h.HDoc_Doc_Num =  {num}  "

        '---------------------Linea Complemento Cuenta Ajena -------------------------------------------------------------------------------------------------------------
        If comp > 0 Then
            strSQL &= " union
                    SELECT 0,{empresa},{ejercicio},{poliza},4, p.valor  , 1, SUM(IFNULL(d.DDoc_RF4_Dbl, d303.DDoc_RF4_Dbl)) importe, '' ,null, 'A', h.HDoc_Doc_Fec , 0,9, 296 , {ano}, {num},0
                    FROM {db}Dcmtos_HDR h
                    LEFT JOIN {db}Dcmtos_HDR h303 ON h303.HDoc_Sis_Emp = h.HDoc_Sis_Emp AND h303.HDoc_Pro_DCat = h.HDoc_Doc_Cat AND h303.HDoc_Pro_DAno = h.HDoc_Doc_Ano AND h303.HDoc_Pro_DNum = h.HDoc_Doc_Num
                    LEFT JOIN {db}Dcmtos_DTL d303 ON d303.DDoc_Sis_Emp = h303.HDoc_Sis_Emp AND d303.DDoc_Doc_Cat = h303.HDoc_Doc_Cat AND d303.DDoc_Doc_Ano = h303.HDoc_Doc_Ano AND d303.DDoc_Doc_Num = h303.HDoc_Doc_Num
                    LEFT JOIN {db}Dcmtos_DTL d ON d.DDoc_Sis_Emp = h.HDoc_Sis_Emp AND d.DDoc_Doc_Cat = h.HDoc_Doc_Cat AND d.DDoc_Doc_Ano = h.HDoc_Doc_Ano AND d.DDoc_Doc_Num = h.HDoc_Doc_Num
                    left join {conta}.parametros_empresa p on p.empresa = h.HDoc_Sis_Emp and p.parametro = 61
                    WHERE h.HDoc_Sis_Emp = {empresa} AND h.HDoc_Doc_Cat = 296 AND h.HDoc_Doc_Ano =  {ano} AND h.HDoc_Doc_Num = {num} AND (d.DDoc_Prd_Ref='comp' OR d303.DDoc_Prd_Ref='comp');"
            '   WHERE h.HDoc_Sis_Emp = {empresa} AND h.HDoc_Pro_DCat = 296 AND h.HDoc_Pro_DAno =  {ano} AND h.HDoc_Pro_DNum = {num} AND d.DDoc_Prd_Ref='comp'"
        End If
        strSQL = Replace(strSQL, "{db}", db)
        Return strSQL
    End Function

    Private Sub FacturaDeCostoCreditoFiscal(ByVal anio As Integer, ByVal num As Integer)
        Dim longPoliza As Long = NO_FILA
        Dim COM As MySqlCommand
        Dim strSQL As String = STR_VACIO

        Try

            'genenerar nueva poliza
            longPoliza = NuevaPoliza()
            UltimaPoliza(longPoliza, EJERCICIO) ' actualiza la ultima poliza

            strSQL = EncabezadoCostoCreditoFiscal(anio, num, longPoliza)
            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSQL, CON)
            COM.ExecuteNonQuery()
            strSQL = STR_VACIO

            strSQL = DetalleCostoCreditoFiscal(anio, num, longPoliza)
            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSQL, CON)
            COM.ExecuteNonQuery()
            strSQL = STR_VACIO

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try

    End Sub

    Private Function EncabezadoCostoCreditoFiscal(ByVal anio As Integer, ByVal num As Integer, ByVal poliza As Integer)
        Dim strsql As String = STR_VACIO

        strsql = " INSERT INTO {conta}.polizas"
        strsql &= "   SELECT h.HDoc_Sis_Emp empresa, {ejercicio} ejercicio, {poliza} poliza, h.HDoc_Doc_Fec fecha, CONCAT('Para registrar Costo de Venta segon Factura: ', h.HDoc_DR2_Cat) concepto, 10 tipo, h.HDoc_Doc_TC TC, '' observacion, '{usuario}' operador, 'C' estado, NOW() marca,'' grupo, 10 modo, h.HDoc_Doc_Cat refTipo, h.HDoc_Doc_Ano refCiclo, h.HDoc_Doc_Num refNumero, NULL divisa, h.HDoc_Doc_TC Tasa,0 revisado,'' usuarioRev, NULL ultRev "
        strsql &= "      FROM Dcmtos_HDR h "
        strsql &= "         WHERE h.HDoc_Sis_Emp = {empresa} AND h.HDoc_Doc_Cat = 296 AND h.HDoc_Doc_Ano = {anio} AND h.HDoc_Doc_Num = {num} "
        If Sesion.IdEmpresa = 18 Then
            strsql &= "; INSERT INTO contapdm.polizas"
            strsql &= "   SELECT h.HDoc_Sis_Emp empresa, {ejercicio} ejercicio, {poliza} poliza, h.HDoc_Doc_Fec fecha, CONCAT('Para registrar Costo de Venta segon Factura: ', h.HDoc_DR2_Cat) concepto, 10 tipo, h.HDoc_Doc_TC TC, '' observacion, '{usuario}' operador, 'C' estado, NOW() marca,'' grupo, 10 modo, h.HDoc_Doc_Cat refTipo, h.HDoc_Doc_Ano refCiclo, h.HDoc_Doc_Num refNumero, NULL divisa, h.HDoc_Doc_TC Tasa,0 revisado,'' usuarioRev, NULL ultRev "
            strsql &= "      FROM PDM.Dcmtos_HDR h "
            strsql &= "         WHERE h.HDoc_Sis_Emp = {empresa} AND h.HDoc_Doc_Cat = 296 AND h.HDoc_Doc_Ano = {anio} AND h.HDoc_Doc_Num = {num} "
        End If
        strsql = Replace(strsql, "{ejercicio}", EJERCICIO)
        strsql = Replace(strsql, "{poliza}", poliza)
        strsql = Replace(strsql, "{empresa}", Sesion.IdEmpresa)
        strsql = Replace(strsql, "{anio}", anio)
        strsql = Replace(strsql, "{num}", num)
        strsql = Replace(strsql, "{conta}", Sesion.BaseConta)
        strsql = Replace(strsql, "{usuario}", Sesion.Usuario)

        Return strsql
    End Function

    Private Function DetalleCostoCreditoFiscal(ByVal anio As Integer, ByVal num As Integer, ByVal poliza As Integer)
        Dim strsql As String = STR_VACIO

        strsql = " INSERT INTO {conta}.detalle_polizas "
        strsql &= "   SELECT 0, h.HDoc_Sis_Emp empresa, {ejercicio}, {poliza},1 item, ic.costo cuenta,1 parametroCuenta, (SUM(( "
        strsql &= "        Select di.DDoc_Prd_NET "
        strsql &= "            From Dcmtos_DTL_Pro chi296 "
        '       -- par 48 - chi 36
        strsql &= "                Left JOIN Dcmtos_DTL_Pro par48 ON par48.PDoc_Sis_Emp = chi296.PDoc_Sis_Emp AND par48.PDoc_Chi_Cat = chi296.PDoc_Par_Cat AND par48.PDoc_Chi_Ano = chi296.PDoc_Par_Ano AND par48.PDoc_Chi_Num = chi296.PDoc_Par_Num AND par48.PDoc_Chi_Lin = chi296.PDoc_Par_Lin "
        '       -- par 47 - chi 48
        strsql &= "                    Left JOIN Dcmtos_DTL_Pro par47 ON par47.PDoc_Sis_Emp = par48.PDoc_Sis_Emp AND par47.PDoc_Chi_Cat = par48.PDoc_Par_Cat AND par47.PDoc_Chi_Ano = par48.PDoc_Par_Ano AND par47.PDoc_Chi_Num = par48.PDoc_Par_Num AND par47.PDoc_Chi_Lin = par48.PDoc_Par_Lin AND par47.PDoc_Par_Cat = 47 "
        '       -- DTL de ingreso a Bodega
        strsql &= "                        Left JOIN Dcmtos_DTL di ON di.DDoc_Sis_Emp = par47.PDoc_Sis_Emp AND di.DDoc_Doc_Cat = par47.PDoc_Par_Cat AND di.DDoc_Doc_Ano = par47.PDoc_Par_Ano AND di.DDoc_Doc_Num = par47.PDoc_Par_Num AND di.DDoc_Doc_Lin = par47.PDoc_Par_Lin "
        strsql &= "                            WHERE chi296.PDoc_Sis_Emp = d.DDoc_Sis_Emp AND chi296.PDoc_Chi_Cat = d.DDoc_Doc_Cat AND chi296.PDoc_Chi_Ano = d.DDoc_Doc_Ano AND chi296.PDoc_Chi_Num = d.DDoc_Doc_Num AND chi296.PDoc_Chi_Lin = d.DDoc_Doc_Lin  "
        strsql &= "                              ) * d.DDoc_Prd_QTY * h.HDoc_Doc_TC))importe,'' centroCosto, '' partidaPresupuestal, 'C' operacion, h.HDoc_Doc_Fec Fecha,0 clase,10 modo, h.HDoc_Doc_Cat refTipo, h.HDoc_Doc_Ano refCiclo, h.HDoc_Doc_Num refNumero, 0 id "
        strsql &= "                                    From Dcmtos_HDR h "
        strsql &= "                                        Left JOIN Dcmtos_DTL d ON d.DDoc_Sis_Emp = h.HDoc_Sis_Emp AND d.DDoc_Doc_Cat = h.HDoc_Doc_Cat AND d.DDoc_Doc_Ano = h.HDoc_Doc_Ano AND d.DDoc_Doc_Num = h.HDoc_Doc_Num "
        strsql &= "                                            Left JOIN Inventarios i ON i.inv_sisemp = d.DDoc_Sis_Emp AND i.inv_numero = d.DDoc_Prd_Cod "
        strsql &= "                                                Left JOIN Articulos a ON a.art_sisemp = i.inv_sisemp AND a.art_codigo = i.inv_artcodigo "
        strsql &= "                                                    Left JOIN {conta}.inventario_codigos ic ON ic.empresa = a.art_sisemp AND ic.clase = a.art_clase "
        strsql &= "                                                        WHERE h.HDoc_Sis_Emp = {empresa} AND h.HDoc_Doc_Cat = 296 AND h.HDoc_Doc_Ano = {anio} AND h.HDoc_Doc_Num = {num}  "
        strsql &= "                                                            UNION "
        strsql &= "                                                                Select 0, h.HDoc_Sis_Emp empresa, {ejercicio}, {poliza},1 item, ic.inventario cuenta,1 parametroCuenta, (SUM(( "
        strsql &= "                                                                Select di.DDoc_Prd_NET "
        strsql &= "                                                           From Dcmtos_DTL_Pro chi296 "
        '       -- par 48 - chi 36
        strsql &= "                                                        Left JOIN Dcmtos_DTL_Pro par48 ON par48.PDoc_Sis_Emp = chi296.PDoc_Sis_Emp AND par48.PDoc_Chi_Cat = chi296.PDoc_Par_Cat AND par48.PDoc_Chi_Ano = chi296.PDoc_Par_Ano AND par48.PDoc_Chi_Num = chi296.PDoc_Par_Num AND par48.PDoc_Chi_Lin = chi296.PDoc_Par_Lin "
        '       -- par 47 - chi 48
        strsql &= "                                                    Left JOIN Dcmtos_DTL_Pro par47 ON par47.PDoc_Sis_Emp = par48.PDoc_Sis_Emp AND par47.PDoc_Chi_Cat = par48.PDoc_Par_Cat AND par47.PDoc_Chi_Ano = par48.PDoc_Par_Ano AND par47.PDoc_Chi_Num = par48.PDoc_Par_Num AND par47.PDoc_Chi_Lin = par48.PDoc_Par_Lin AND par47.PDoc_Par_Cat = 47 "
        '       -- DTL de ingreso a Bodega
        strsql &= "                                                Left JOIN Dcmtos_DTL di ON di.DDoc_Sis_Emp = par47.PDoc_Sis_Emp AND di.DDoc_Doc_Cat = par47.PDoc_Par_Cat AND di.DDoc_Doc_Ano = par47.PDoc_Par_Ano AND di.DDoc_Doc_Num = par47.PDoc_Par_Num AND di.DDoc_Doc_Lin = par47.PDoc_Par_Lin "
        strsql &= "                                            WHERE chi296.PDoc_Sis_Emp = d.DDoc_Sis_Emp AND chi296.PDoc_Chi_Cat = d.DDoc_Doc_Cat AND chi296.PDoc_Chi_Ano = d.DDoc_Doc_Ano AND chi296.PDoc_Chi_Num = d.DDoc_Doc_Num AND chi296.PDoc_Chi_Lin = d.DDoc_Doc_Lin "
        strsql &= "                                           ) * d.DDoc_Prd_QTY * h.HDoc_Doc_TC))importe,'' centroCosto, '' partidaPresupuestal, 'A' operacion, h.HDoc_Doc_Fec Fecha,0 clase,10 modo, h.HDoc_Doc_Cat refTipo, h.HDoc_Doc_Ano refCiclo, h.HDoc_Doc_Num refNumero, 0 id "
        strsql &= "                                        From Dcmtos_HDR h "
        strsql &= "                                    Left JOIN Dcmtos_DTL d ON d.DDoc_Sis_Emp = h.HDoc_Sis_Emp AND d.DDoc_Doc_Cat = h.HDoc_Doc_Cat AND d.DDoc_Doc_Ano = h.HDoc_Doc_Ano AND d.DDoc_Doc_Num = h.HDoc_Doc_Num "
        strsql &= "                                Left JOIN Inventarios i ON i.inv_sisemp = d.DDoc_Sis_Emp AND i.inv_numero = d.DDoc_Prd_Cod "
        strsql &= "                            Left JOIN Articulos a ON a.art_sisemp = i.inv_sisemp AND a.art_codigo = i.inv_artcodigo "
        strsql &= "                        Left JOIN {conta}.inventario_codigos ic ON ic.empresa = a.art_sisemp And ic.clase = a.art_clase "
        strsql &= "                    WHERE h.HDoc_Sis_Emp = {empresa} And h.HDoc_Doc_Cat = 296 And h.HDoc_Doc_Ano = {anio} And h.HDoc_Doc_Num = {num} "

        If Sesion.IdEmpresa = 18 Then
            strsql &= "; INSERT INTO contapdm.detalle_polizas "
            strsql &= "   SELECT 0, h.HDoc_Sis_Emp empresa, {ejercicio}, {poliza},1 item, ic.costo cuenta,1 parametroCuenta, (SUM(( "
            strsql &= "        Select di.DDoc_Prd_NET "
            strsql &= "            From PDM.Dcmtos_DTL_Pro chi296 "
            '       -- par 48 - chi 36
            strsql &= "                Left JOIN PDM.Dcmtos_DTL_Pro par48 ON par48.PDoc_Sis_Emp = chi296.PDoc_Sis_Emp AND par48.PDoc_Chi_Cat = chi296.PDoc_Par_Cat AND par48.PDoc_Chi_Ano = chi296.PDoc_Par_Ano AND par48.PDoc_Chi_Num = chi296.PDoc_Par_Num AND par48.PDoc_Chi_Lin = chi296.PDoc_Par_Lin "
            '       -- par 47 - chi 48
            strsql &= "                    Left JOIN PDM.Dcmtos_DTL_Pro par47 ON par47.PDoc_Sis_Emp = par48.PDoc_Sis_Emp AND par47.PDoc_Chi_Cat = par48.PDoc_Par_Cat AND par47.PDoc_Chi_Ano = par48.PDoc_Par_Ano AND par47.PDoc_Chi_Num = par48.PDoc_Par_Num AND par47.PDoc_Chi_Lin = par48.PDoc_Par_Lin AND par47.PDoc_Par_Cat = 47 "
            '       -- DTL de ingreso a Bodega
            strsql &= "                        Left JOIN PDM.Dcmtos_DTL di ON di.DDoc_Sis_Emp = par47.PDoc_Sis_Emp AND di.DDoc_Doc_Cat = par47.PDoc_Par_Cat AND di.DDoc_Doc_Ano = par47.PDoc_Par_Ano AND di.DDoc_Doc_Num = par47.PDoc_Par_Num AND di.DDoc_Doc_Lin = par47.PDoc_Par_Lin "
            strsql &= "                            WHERE chi296.PDoc_Sis_Emp = d.DDoc_Sis_Emp AND chi296.PDoc_Chi_Cat = d.DDoc_Doc_Cat AND chi296.PDoc_Chi_Ano = d.DDoc_Doc_Ano AND chi296.PDoc_Chi_Num = d.DDoc_Doc_Num AND chi296.PDoc_Chi_Lin = d.DDoc_Doc_Lin  "
            strsql &= "                              ) * d.DDoc_Prd_QTY * h.HDoc_Doc_TC))importe,'' centroCosto, '' partidaPresupuestal, 'C' operacion, h.HDoc_Doc_Fec Fecha,0 clase,10 modo, h.HDoc_Doc_Cat refTipo, h.HDoc_Doc_Ano refCiclo, h.HDoc_Doc_Num refNumero, 0 id "
            strsql &= "                                    From PDM.Dcmtos_HDR h "
            strsql &= "                                        Left JOIN PDM.Dcmtos_DTL d ON d.DDoc_Sis_Emp = h.HDoc_Sis_Emp AND d.DDoc_Doc_Cat = h.HDoc_Doc_Cat AND d.DDoc_Doc_Ano = h.HDoc_Doc_Ano AND d.DDoc_Doc_Num = h.HDoc_Doc_Num "
            strsql &= "                                            Left JOIN PDM.Inventarios i ON i.inv_sisemp = d.DDoc_Sis_Emp AND i.inv_numero = d.DDoc_Prd_Cod "
            strsql &= "                                                Left JOIN PDM.Articulos a ON a.art_sisemp = i.inv_sisemp AND a.art_codigo = i.inv_artcodigo "
            strsql &= "                                                    Left JOIN contapdm.inventario_codigos ic ON ic.empresa = a.art_sisemp AND ic.clase = a.art_clase "
            strsql &= "                                                        WHERE h.HDoc_Sis_Emp = {empresa} AND h.HDoc_Doc_Cat = 296 AND h.HDoc_Doc_Ano = {anio} AND h.HDoc_Doc_Num = {num}  "
            strsql &= "                                                            UNION "
            strsql &= "                                                                Select 0, h.HDoc_Sis_Emp empresa, {ejercicio}, {poliza},1 item, ic.inventario cuenta,1 parametroCuenta, (SUM(( "
            strsql &= "                                                                Select di.DDoc_Prd_NET "
            strsql &= "                                                           From PDM.Dcmtos_DTL_Pro chi296 "
            '       -- par 48 - chi 36
            strsql &= "                                                        Left JOIN PDM.Dcmtos_DTL_Pro par48 ON par48.PDoc_Sis_Emp = chi296.PDoc_Sis_Emp AND par48.PDoc_Chi_Cat = chi296.PDoc_Par_Cat AND par48.PDoc_Chi_Ano = chi296.PDoc_Par_Ano AND par48.PDoc_Chi_Num = chi296.PDoc_Par_Num AND par48.PDoc_Chi_Lin = chi296.PDoc_Par_Lin "
            '       -- par 47 - chi 48
            strsql &= "                                                    Left JOIN PDM.Dcmtos_DTL_Pro par47 ON par47.PDoc_Sis_Emp = par48.PDoc_Sis_Emp AND par47.PDoc_Chi_Cat = par48.PDoc_Par_Cat AND par47.PDoc_Chi_Ano = par48.PDoc_Par_Ano AND par47.PDoc_Chi_Num = par48.PDoc_Par_Num AND par47.PDoc_Chi_Lin = par48.PDoc_Par_Lin AND par47.PDoc_Par_Cat = 47 "
            '       -- DTL de ingreso a Bodega
            strsql &= "                                                Left JOIN PDM.Dcmtos_DTL di ON di.DDoc_Sis_Emp = par47.PDoc_Sis_Emp AND di.DDoc_Doc_Cat = par47.PDoc_Par_Cat AND di.DDoc_Doc_Ano = par47.PDoc_Par_Ano AND di.DDoc_Doc_Num = par47.PDoc_Par_Num AND di.DDoc_Doc_Lin = par47.PDoc_Par_Lin "
            strsql &= "                                            WHERE chi296.PDoc_Sis_Emp = d.DDoc_Sis_Emp AND chi296.PDoc_Chi_Cat = d.DDoc_Doc_Cat AND chi296.PDoc_Chi_Ano = d.DDoc_Doc_Ano AND chi296.PDoc_Chi_Num = d.DDoc_Doc_Num AND chi296.PDoc_Chi_Lin = d.DDoc_Doc_Lin "
            strsql &= "                                           ) * d.DDoc_Prd_QTY * h.HDoc_Doc_TC))importe,'' centroCosto, '' partidaPresupuestal, 'A' operacion, h.HDoc_Doc_Fec Fecha,0 clase,10 modo, h.HDoc_Doc_Cat refTipo, h.HDoc_Doc_Ano refCiclo, h.HDoc_Doc_Num refNumero, 0 id "
            strsql &= "                                        From PDM.Dcmtos_HDR h "
            strsql &= "                                    Left JOIN PDM.Dcmtos_DTL d ON d.DDoc_Sis_Emp = h.HDoc_Sis_Emp AND d.DDoc_Doc_Cat = h.HDoc_Doc_Cat AND d.DDoc_Doc_Ano = h.HDoc_Doc_Ano AND d.DDoc_Doc_Num = h.HDoc_Doc_Num "
            strsql &= "                                Left JOIN PDM.Inventarios i ON i.inv_sisemp = d.DDoc_Sis_Emp AND i.inv_numero = d.DDoc_Prd_Cod "
            strsql &= "                            Left JOIN PDM.Articulos a ON a.art_sisemp = i.inv_sisemp AND a.art_codigo = i.inv_artcodigo "
            strsql &= "                        Left JOIN contapdm.inventario_codigos ic ON ic.empresa = a.art_sisemp And ic.clase = a.art_clase "
            strsql &= "                    WHERE h.HDoc_Sis_Emp = {empresa} And h.HDoc_Doc_Cat = 296 And h.HDoc_Doc_Ano = {anio} And h.HDoc_Doc_Num = {num} "

        End If

        strsql = Replace(strsql, "{empresa}", Sesion.IdEmpresa)
        strsql = Replace(strsql, "{anio}", anio)
        strsql = Replace(strsql, "{num}", num)
        strsql = Replace(strsql, "{poliza}", poliza)
        strsql = Replace(strsql, "{ejercicio}", EJERCICIO)
        strsql = Replace(strsql, "{conta}", Sesion.BaseConta)

        Return strsql
    End Function


    Private Sub FacturaDeVentaCreditoFiscal(ByVal anio As Integer, ByVal num As Integer)
        Dim longPoliza As Long = NO_FILA
        Dim COM As MySqlCommand
        Dim strSQL As String = STR_VACIO
        Dim intImpuesto As Integer = NO_FILA

        Try

            strSQL = "SELECT h.HDoc_Ant_Com Impuesto "
            strSQL &= "    From Dcmtos_HDR h "
            strSQL &= " WHERE h.HDoc_Sis_Emp = {empresa} AND h.HDoc_Doc_Cat = 296 AND h.HDoc_Doc_Ano = {anio} AND h.HDoc_Doc_Num = {num}"

            strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
            strSQL = Replace(strSQL, "{anio}", anio)
            strSQL = Replace(strSQL, "{num}", num)

            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSQL, CON)
            intImpuesto = COM.ExecuteScalar ' Verifica retiene el impuesto de IVA (1) o no (0)
            strSQL = STR_VACIO


            'genenerar nueva poliza
            longPoliza = NuevaPoliza()
            UltimaPoliza(longPoliza, EJERCICIO) ' actualiza la ultima poliza

            strSQL = EncabezadoVentaCreditoFiscal(anio, num, longPoliza)
            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSQL, CON)
            COM.ExecuteNonQuery()
            strSQL = STR_VACIO

            strSQL = DetalleVentaCreditoFiscal(anio, num, longPoliza, intImpuesto)
            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSQL, CON)
            COM.ExecuteNonQuery()
            strSQL = STR_VACIO

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try

    End Sub

    Private Function EncabezadoVentaCreditoFiscal(ByVal anio As Integer, ByVal num As Integer, ByVal poliza As Integer)
        Dim strsql As String = STR_VACIO
        strsql = " INSERT INTO {conta}.polizas"
        strsql &= "   SELECT h.HDoc_Sis_Emp empresa, {ejercicio} ejercicio, {poliza} poliza, h.HDoc_Doc_Fec fecha, CONCAT('Para registrar Venta segon Factura: ', h.HDoc_DR2_Cat) concepto, 9 tipo, h.HDoc_Doc_TC TC, '' observacion, h.HDoc_Usuario operador, 'C' estado, NOW() marca,'' grupo, 9 modo, h.HDoc_Doc_Cat refTipo, h.HDoc_Doc_Ano refCiclo, h.HDoc_Doc_Num refNumero, NULL divisa, h.HDoc_Doc_TC Tasa,0 revisado,'' usuarioRev, NULL ultRev "
        strsql &= "      FROM Dcmtos_HDR h "
        strsql &= "         WHERE h.HDoc_Sis_Emp = {empresa} AND h.HDoc_Doc_Cat = 296 AND h.HDoc_Doc_Ano = {anio} AND h.HDoc_Doc_Num = {num} "

        If Sesion.IdEmpresa = 18 Then
            strsql &= "; INSERT INTO contapdm.polizas"
            strsql &= "   SELECT h.HDoc_Sis_Emp empresa, {ejercicio} ejercicio, {poliza} poliza, h.HDoc_Doc_Fec fecha, CONCAT('Para registrar Venta segon Factura: ', h.HDoc_DR2_Cat) concepto, 9 tipo, h.HDoc_Doc_TC TC, '' observacion, h.HDoc_Usuario operador, 'C' estado, NOW() marca,'' grupo, 9 modo, h.HDoc_Doc_Cat refTipo, h.HDoc_Doc_Ano refCiclo, h.HDoc_Doc_Num refNumero, NULL divisa, h.HDoc_Doc_TC Tasa,0 revisado,'' usuarioRev, NULL ultRev "
            strsql &= "      FROM PDM.Dcmtos_HDR h "
            strsql &= "         WHERE h.HDoc_Sis_Emp = {empresa} AND h.HDoc_Doc_Cat = 296 AND h.HDoc_Doc_Ano = {anio} AND h.HDoc_Doc_Num = {num} "

        End If

        strsql = Replace(strsql, "{ejercicio}", EJERCICIO)
        strsql = Replace(strsql, "{poliza}", poliza)
        strsql = Replace(strsql, "{empresa}", Sesion.IdEmpresa)
        strsql = Replace(strsql, "{anio}", anio)
        strsql = Replace(strsql, "{num}", num)
        strsql = Replace(strsql, "{conta}", Sesion.BaseConta)
        Return strsql
    End Function

    Private Function DetalleVentaCreditoFiscal(ByVal anio As Integer, ByVal num As Integer, ByVal poliza As Integer, ByVal intImpuesto As Integer)
        Dim strsql As String = STR_VACIO
        Dim item As Integer = 1

        strsql = " INSERT INTO {conta}.detalle_polizas "
        strsql &= "      SELECT 0, h.HDoc_Sis_Emp empresa, '{ejercicio}', '{poliza}',1 item, c.cli_cuenta cuenta,1 parametroCuenta, ((SUM((d.DDoc_Prd_NET *d.DDoc_Prd_QTY) * h.HDoc_Doc_TC) + ((SUM((d.DDoc_Prd_NET *d.DDoc_Prd_QTY) * h.HDoc_Doc_TC) * ( "
        strsql &= "        SELECT c.cat_sist "
        strsql &= "            FROM Catalogos c "
        strsql &= "                WHERE c.cat_clase = 'Impuestos' AND c.cat_clave = 'IVA' AND c.cat_sisemp = h.HDoc_Sis_Emp))/100)) {exento})importe,'' centroCosto, '' partidaPresupuestal, 'C' operacion, h.HDoc_Doc_Fec Fecha,0 clase,9 modo, h.HDoc_Doc_Cat refTipo, h.HDoc_Doc_Ano refCiclo, h.HDoc_Doc_Num refNumero, 0 id "
        strsql &= "                    FROM Dcmtos_HDR h "
        strsql &= "                        LEFT JOIN Dcmtos_DTL d ON d.DDoc_Sis_Emp = h.HDoc_Sis_Emp AND d.DDoc_Doc_Cat = h.HDoc_Doc_Cat AND d.DDoc_Doc_Ano = h.HDoc_Doc_Ano AND d.DDoc_Doc_Num = h.HDoc_Doc_Num "
        strsql &= "                            LEFT JOIN Clientes c ON c.cli_sisemp = h.HDoc_Sis_Emp AND c.cli_codigo = h.HDoc_Emp_Cod "
        strsql &= "                                        WHERE h.HDoc_Sis_Emp = {empresa} AND h.HDoc_Doc_Cat = 296 AND h.HDoc_Doc_Ano = {anio} AND h.HDoc_Doc_Num = {num} "

        If intImpuesto = 1 Then
            strsql = Replace(strsql, "{exento}", "- ((SUM((d.DDoc_Prd_NET *d.DDoc_Prd_QTY) * h.HDoc_Doc_TC))/100)")
            item = item + 1
            strsql &= "                                            UNION "
            strsql &= "                                                Select 0, h.HDoc_Sis_Emp empresa, {ejercicio}, {poliza}," & item & " item, pc.valor cuenta,1 parametroCuenta, ((SUM((d.DDoc_Prd_NET *d.DDoc_Prd_QTY) * h.HDoc_Doc_TC))/100)importe,'' centroCosto, '' partidaPresupuestal, 'C' operacion, h.HDoc_Doc_Fec Fecha,0 clase,9 modo, h.HDoc_Doc_Cat refTipo, h.HDoc_Doc_Ano refCiclo, h.HDoc_Doc_Num refNumero, 0 id "
            strsql &= "                                                    From Dcmtos_HDR h "
            strsql &= "                                                        Left JOIN Dcmtos_DTL d ON d.DDoc_Sis_Emp = h.HDoc_Sis_Emp AND d.DDoc_Doc_Cat = h.HDoc_Doc_Cat AND d.DDoc_Doc_Ano = h.HDoc_Doc_Ano AND d.DDoc_Doc_Num = h.HDoc_Doc_Num "
            strsql &= "                                                            Left JOIN Inventarios i ON i.inv_sisemp = d.DDoc_Sis_Emp AND i.inv_numero = d.DDoc_Prd_Cod "
            strsql &= "                                                                Left JOIN Articulos a ON a.art_sisemp = i.inv_sisemp AND a.art_codigo = i.inv_artcodigo "
            strsql &= "                                                                    Left JOIN {conta}.parametros_empresa pc ON pc.empresa = a.art_sisemp AND pc.parametro = {parametro2} "
            strsql &= "                                                                        WHERE h.HDoc_Sis_Emp = {empresa} AND h.HDoc_Doc_Cat = 296 AND h.HDoc_Doc_Ano = {anio} AND h.HDoc_Doc_Num = {num} "
        End If

        item = item + 1

        strsql &= "                                                                            UNION "
        strsql &= "                                                                              Select 0, h.HDoc_Sis_Emp empresa, {ejercicio}, {poliza}," & item & " item, ic.venta cuenta,1 parametroCuenta, SUM((d.DDoc_Prd_NET *d.DDoc_Prd_QTY) * h.HDoc_Doc_TC) importe,'' centroCosto, '' partidaPresupuestal, 'A' operacion, h.HDoc_Doc_Fec Fecha,0 clase,9 modo, h.HDoc_Doc_Cat refTipo, h.HDoc_Doc_Ano refCiclo, h.HDoc_Doc_Num refNumero, 0 id "
        strsql &= "                                                                                  From Dcmtos_HDR h "
        strsql &= "                                                                                     Left JOIN Dcmtos_DTL d ON d.DDoc_Sis_Emp = h.HDoc_Sis_Emp AND d.DDoc_Doc_Cat = h.HDoc_Doc_Cat AND d.DDoc_Doc_Ano = h.HDoc_Doc_Ano AND d.DDoc_Doc_Num = h.HDoc_Doc_Num "
        strsql &= "                                                                                        Left JOIN Inventarios i ON i.inv_sisemp = d.DDoc_Sis_Emp AND i.inv_numero = d.DDoc_Prd_Cod "
        strsql &= "                                                                                   Left JOIN Articulos a ON a.art_sisemp = i.inv_sisemp AND a.art_codigo = i.inv_artcodigo "
        strsql &= "                                                                               Left Join {conta}.inventario_codigos ic ON ic.empresa = a.art_sisemp And ic.clase = a.art_clase "
        strsql &= "                                                                           WHERE h.HDoc_Sis_Emp = {empresa} And h.HDoc_Doc_Cat = 296 And h.HDoc_Doc_Ano = {anio} And h.HDoc_Doc_Num = {num} "
        strsql &= "                                                                     UNION "

        item = item + 1
        strsql &= "                                                                Select 0, h.HDoc_Sis_Emp empresa, {ejercicio}, {poliza}," & item & " item, pc.valor cuenta,1 parametroCuenta, ((SUM((d.DDoc_Prd_NET *d.DDoc_Prd_QTY) * h.HDoc_Doc_TC) * ( "
        strsql &= "                                                            Select c.cat_sist "
        strsql &= "                                                       From Catalogos c "
        strsql &= "                                                  Where c.cat_clase = 'Impuestos' AND c.cat_clave = 'IVA' AND c.cat_sisemp = h.HDoc_Sis_Emp))/100) importe,'' centroCosto, '' partidaPresupuestal, 'A' operacion, h.HDoc_Doc_Fec Fecha,0 clase,9 modo, h.HDoc_Doc_Cat refTipo, h.HDoc_Doc_Ano refCiclo, h.HDoc_Doc_Num refNumero, 0 id "
        strsql &= "                                             From Dcmtos_HDR h "
        strsql &= "                                         Left Join Dcmtos_DTL d ON d.DDoc_Sis_Emp = h.HDoc_Sis_Emp And d.DDoc_Doc_Cat = h.HDoc_Doc_Cat And d.DDoc_Doc_Ano = h.HDoc_Doc_Ano And d.DDoc_Doc_Num = h.HDoc_Doc_Num "
        strsql &= "                                     Left Join Inventarios i ON i.inv_sisemp = d.DDoc_Sis_Emp And i.inv_numero = d.DDoc_Prd_Cod "
        strsql &= "                                 Left Join Articulos a ON a.art_sisemp = i.inv_sisemp And a.art_codigo = i.inv_artcodigo "
        strsql &= "                             Left Join {conta}.parametros_empresa pc ON pc.empresa = a.art_sisemp And pc.parametro = {parametro1} "
        strsql &= "                         WHERE h.HDoc_Sis_Emp = {empresa} And h.HDoc_Doc_Cat = 296 And h.HDoc_Doc_Ano = {anio} And h.HDoc_Doc_Num = {num} "

        If Sesion.IdEmpresa = 18 Then
            item = 1
            strsql &= "; INSERT INTO contapdm.detalle_polizas "
            strsql &= "      SELECT 0, h.HDoc_Sis_Emp empresa, '{ejercicio}', '{poliza}',1 item, c.cli_cuenta cuenta,1 parametroCuenta, ((SUM((d.DDoc_Prd_NET *d.DDoc_Prd_QTY) * h.HDoc_Doc_TC) + ((SUM((d.DDoc_Prd_NET *d.DDoc_Prd_QTY) * h.HDoc_Doc_TC) * ( "
            strsql &= "        SELECT c.cat_sist "
            strsql &= "            FROM PDM.Catalogos c "
            strsql &= "                WHERE c.cat_clase = 'Impuestos' AND c.cat_clave = 'IVA' AND c.cat_sisemp = h.HDoc_Sis_Emp))/100)) {exento})importe,'' centroCosto, '' partidaPresupuestal, 'C' operacion, h.HDoc_Doc_Fec Fecha,0 clase,9 modo, h.HDoc_Doc_Cat refTipo, h.HDoc_Doc_Ano refCiclo, h.HDoc_Doc_Num refNumero, 0 id "
            strsql &= "                    FROM PDM.Dcmtos_HDR h "
            strsql &= "                        LEFT JOIN PDM.Dcmtos_DTL d ON d.DDoc_Sis_Emp = h.HDoc_Sis_Emp AND d.DDoc_Doc_Cat = h.HDoc_Doc_Cat AND d.DDoc_Doc_Ano = h.HDoc_Doc_Ano AND d.DDoc_Doc_Num = h.HDoc_Doc_Num "
            strsql &= "                            LEFT JOIN PDM.Clientes c ON c.cli_sisemp = h.HDoc_Sis_Emp AND c.cli_codigo = h.HDoc_Emp_Cod "
            strsql &= "                                        WHERE h.HDoc_Sis_Emp = {empresa} AND h.HDoc_Doc_Cat = 296 AND h.HDoc_Doc_Ano = {anio} AND h.HDoc_Doc_Num = {num} "

            If intImpuesto = 1 Then
                strsql = Replace(strsql, "{exento}", "- ((SUM((d.DDoc_Prd_NET *d.DDoc_Prd_QTY) * h.HDoc_Doc_TC))/100)")
                item = item + 1
                strsql &= "                                            UNION "
                strsql &= "                                                Select 0, h.HDoc_Sis_Emp empresa, {ejercicio}, {poliza}," & item & " item, pc.valor cuenta,1 parametroCuenta, ((SUM((d.DDoc_Prd_NET *d.DDoc_Prd_QTY) * h.HDoc_Doc_TC))/100)importe,'' centroCosto, '' partidaPresupuestal, 'C' operacion, h.HDoc_Doc_Fec Fecha,0 clase,9 modo, h.HDoc_Doc_Cat refTipo, h.HDoc_Doc_Ano refCiclo, h.HDoc_Doc_Num refNumero, 0 id "
                strsql &= "                                                    From PDM.Dcmtos_HDR h "
                strsql &= "                                                        Left JOIN PDM.Dcmtos_DTL d ON d.DDoc_Sis_Emp = h.HDoc_Sis_Emp AND d.DDoc_Doc_Cat = h.HDoc_Doc_Cat AND d.DDoc_Doc_Ano = h.HDoc_Doc_Ano AND d.DDoc_Doc_Num = h.HDoc_Doc_Num "
                strsql &= "                                                            Left JOIN PDM.Inventarios i ON i.inv_sisemp = d.DDoc_Sis_Emp AND i.inv_numero = d.DDoc_Prd_Cod "
                strsql &= "                                                                Left JOIN PDM.Articulos a ON a.art_sisemp = i.inv_sisemp AND a.art_codigo = i.inv_artcodigo "
                strsql &= "                                                                    Left JOIN contapdm.parametros_empresa pc ON pc.empresa = a.art_sisemp AND pc.parametro = {parametro2} "
                strsql &= "                                                                        WHERE h.HDoc_Sis_Emp = {empresa} AND h.HDoc_Doc_Cat = 296 AND h.HDoc_Doc_Ano = {anio} AND h.HDoc_Doc_Num = {num} "
            End If

            item = item + 1

            strsql &= "                                                                            UNION "
            strsql &= "                                                                              Select 0, h.HDoc_Sis_Emp empresa, {ejercicio}, {poliza}," & item & " item, ic.venta cuenta,1 parametroCuenta, SUM((d.DDoc_Prd_NET *d.DDoc_Prd_QTY) * h.HDoc_Doc_TC) importe,'' centroCosto, '' partidaPresupuestal, 'A' operacion, h.HDoc_Doc_Fec Fecha,0 clase,9 modo, h.HDoc_Doc_Cat refTipo, h.HDoc_Doc_Ano refCiclo, h.HDoc_Doc_Num refNumero, 0 id "
            strsql &= "                                                                                  From PDM.Dcmtos_HDR h "
            strsql &= "                                                                                     Left JOIN PDM.Dcmtos_DTL d ON d.DDoc_Sis_Emp = h.HDoc_Sis_Emp AND d.DDoc_Doc_Cat = h.HDoc_Doc_Cat AND d.DDoc_Doc_Ano = h.HDoc_Doc_Ano AND d.DDoc_Doc_Num = h.HDoc_Doc_Num "
            strsql &= "                                                                                        Left JOIN PDM.Inventarios i ON i.inv_sisemp = d.DDoc_Sis_Emp AND i.inv_numero = d.DDoc_Prd_Cod "
            strsql &= "                                                                                   Left JOIN PDM.Articulos a ON a.art_sisemp = i.inv_sisemp AND a.art_codigo = i.inv_artcodigo "
            strsql &= "                                                                               Left Join contapdm.inventario_codigos ic ON ic.empresa = a.art_sisemp And ic.clase = a.art_clase "
            strsql &= "                                                                           WHERE h.HDoc_Sis_Emp = {empresa} And h.HDoc_Doc_Cat = 296 And h.HDoc_Doc_Ano = {anio} And h.HDoc_Doc_Num = {num} "
            strsql &= "                                                                     UNION "

            item = item + 1
            strsql &= "                                                                Select 0, h.HDoc_Sis_Emp empresa, {ejercicio}, {poliza}," & item & " item, pc.valor cuenta,1 parametroCuenta, ((SUM((d.DDoc_Prd_NET *d.DDoc_Prd_QTY) * h.HDoc_Doc_TC) * ( "
            strsql &= "                                                            Select c.cat_sist "
            strsql &= "                                                       From PDM.Catalogos c "
            strsql &= "                                                  Where c.cat_clase = 'Impuestos' AND c.cat_clave = 'IVA' AND c.cat_sisemp = h.HDoc_Sis_Emp))/100) importe,'' centroCosto, '' partidaPresupuestal, 'A' operacion, h.HDoc_Doc_Fec Fecha,0 clase,9 modo, h.HDoc_Doc_Cat refTipo, h.HDoc_Doc_Ano refCiclo, h.HDoc_Doc_Num refNumero, 0 id "
            strsql &= "                                             From PDM.Dcmtos_HDR h "
            strsql &= "                                         Left Join PDM.Dcmtos_DTL d ON d.DDoc_Sis_Emp = h.HDoc_Sis_Emp And d.DDoc_Doc_Cat = h.HDoc_Doc_Cat And d.DDoc_Doc_Ano = h.HDoc_Doc_Ano And d.DDoc_Doc_Num = h.HDoc_Doc_Num "
            strsql &= "                                     Left Join PDM.Inventarios i ON i.inv_sisemp = d.DDoc_Sis_Emp And i.inv_numero = d.DDoc_Prd_Cod "
            strsql &= "                                 Left Join PDM.Articulos a ON a.art_sisemp = i.inv_sisemp And a.art_codigo = i.inv_artcodigo "
            strsql &= "                             Left Join contapdm.parametros_empresa pc ON pc.empresa = a.art_sisemp And pc.parametro = {parametro1} "
            strsql &= "                         WHERE h.HDoc_Sis_Emp = {empresa} And h.HDoc_Doc_Cat = 296 And h.HDoc_Doc_Ano = {anio} And h.HDoc_Doc_Num = {num} "
        End If


        strsql = Replace(strsql, "{ejercicio}", EJERCICIO)
        strsql = Replace(strsql, "{poliza}", poliza)
        strsql = Replace(strsql, "{empresa}", Sesion.IdEmpresa)
        strsql = Replace(strsql, "{anio}", anio)
        strsql = Replace(strsql, "{num}", num)
        strsql = Replace(strsql, "{conta}", Sesion.BaseConta)
        strsql = Replace(strsql, "{exento}", STR_VACIO)

        If Sesion.IdEmpresa = 16 Then
            strsql = Replace(strsql, "{parametro1}", 57)
            strsql = Replace(strsql, "{parametro2}", 58)
        Else
            strsql = Replace(strsql, "{parametro1}", 50)
            strsql = Replace(strsql, "{parametro2}", 56)
        End If
        Return strsql

    End Function
#End Region

#Region "Inventario en Transito - Comfirmacion"
    Private Sub PolizaDeConfirmación(ByVal cat As Integer, ByVal anio As Integer, ByVal num As Integer)

        ' *******************************************
        ' INGRESO DE INVENTARIO EN TRANSITO
        ' *******************************************
        Dim longPolizas As Long = NO_FILA
        Dim COM As MySqlCommand
        Dim strSQL As String = STR_VACIO

        Try
            longPolizas = NuevaPoliza()
            UltimaPoliza(longPolizas, EJERCICIO) ' actualiza la ultima poliza

            strSQL = SQLEncabezadoPolizaConfirmacion(longPolizas, cat, anio, num)

            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSQL, CON)
            COM.ExecuteNonQuery()
            strSQL = STR_VACIO

            strSQL = SQLDetallePolizaConfirmacion(longPolizas, cat, anio, num)

            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSQL, CON)
            COM.ExecuteNonQuery()
            strSQL = STR_VACIO
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try

    End Sub

    Private Function SQLEncabezadoPolizaConfirmacion(ByVal poliza As Integer, ByVal cat As Integer, ByVal anio As Integer, ByVal num As Integer)
        Dim strsql As String = STR_VACIO

        strsql = " INSERT INTO {conta}.polizas"
        strsql &= "   SELECT h.HDoc_Sis_Emp empresa, {ejercicio} ejercicio, {poliza} poliza, h.HDoc_Doc_Fec fecha, CONCAT('Poliza de Inventario en Transito, Segun Factura No. ', h.HDoc_DR1_Num, ' -> ', h.HDoc_Doc_Num) concepto, 28 tipo, h.HDoc_Doc_TC TC, '' observacion, h.HDoc_Usuario operador, 'C' estado, NOW() marca,'' grupo, 28 modo, h.HDoc_Doc_Cat refTipo, h.HDoc_Doc_Ano refCiclo, h.HDoc_Doc_Num refNumero, NULL divisa, h.HDoc_Doc_TC Tasa,0 revisado,'' usuarioRev, NULL ultRev "
        strsql &= "      FROM Dcmtos_HDR h "
        strsql &= "         WHERE h.HDoc_Sis_Emp = {empresa} AND h.HDoc_Doc_Cat = {cat} AND h.HDoc_Doc_Ano = {anio} AND h.HDoc_Doc_Num = {num} "

        If Sesion.IdEmpresa = 18 Then
            strsql &= "; INSERT INTO contapdm.polizas"
            strsql &= "   SELECT h.HDoc_Sis_Emp empresa, {ejercicio} ejercicio, {poliza} poliza, h.HDoc_Doc_Fec fecha, CONCAT('Poliza de Inventario en Transito, Segun Factura No. ', h.HDoc_DR1_Num, ' -> ', h.HDoc_Doc_Num) concepto, 28 tipo, h.HDoc_Doc_TC TC, '' observacion, h.HDoc_Usuario operador, 'C' estado, NOW() marca,'' grupo, 28 modo, h.HDoc_Doc_Cat refTipo, h.HDoc_Doc_Ano refCiclo, h.HDoc_Doc_Num refNumero, NULL divisa, h.HDoc_Doc_TC Tasa,0 revisado,'' usuarioRev, NULL ultRev "
            strsql &= "      FROM PDM.Dcmtos_HDR h "
            strsql &= "         WHERE h.HDoc_Sis_Emp = {empresa} AND h.HDoc_Doc_Cat = {cat} AND h.HDoc_Doc_Ano = {anio} AND h.HDoc_Doc_Num = {num} "
        End If

        strsql = Replace(strsql, "{ejercicio}", EJERCICIO)
        strsql = Replace(strsql, "{poliza}", poliza)
        strsql = Replace(strsql, "{empresa}", Sesion.IdEmpresa)
        strsql = Replace(strsql, "{cat}", cat)
        strsql = Replace(strsql, "{anio}", anio)
        strsql = Replace(strsql, "{num}", num)
        strsql = Replace(strsql, "{conta}", Sesion.BaseConta)

        Return strsql

    End Function

    Private Function SQLDetallePolizaConfirmacion(ByVal poliza As Integer, ByVal cat As Integer, ByVal anio As Integer, ByVal num As Integer)
        Dim strsql As String = STR_VACIO

        strsql = " INSERT INTO {conta}.detalle_polizas "
        ' *** Linea de inventario
        strsql &= "   SELECT 0, h.HDoc_Sis_Emp empresa, {ejercico}, {poliza},1 item, ic.transito cuenta,1 parametroCuenta, SUM((d.DDoc_Prd_NET * d.DDoc_Prd_QTY) * h.HDoc_Doc_TC) importe,'' centroCosto, '' partidaPresupuestal, 'C' operacion, h.HDoc_Doc_Fec Fecha,0 clase, 28 modo, h.HDoc_Doc_Cat refTipo, h.HDoc_Doc_Ano refCiclo, h.HDoc_Doc_Num refNumero, 0 id "
        strsql &= "       FROM Dcmtos_HDR h "
        strsql &= "        Left JOIN Dcmtos_DTL d ON d.DDoc_Sis_Emp = h.HDoc_Sis_Emp AND d.DDoc_Doc_Cat = h.HDoc_Doc_Cat AND d.DDoc_Doc_Ano = h.HDoc_Doc_Ano AND d.DDoc_Doc_Num = h.HDoc_Doc_Num "
        strsql &= "            LEFT JOIN Inventarios i ON i.inv_sisemp = d.DDoc_Sis_Emp AND i.inv_numero = d.DDoc_Prd_Cod "
        strsql &= "              LEFT JOIN Articulos a ON a.art_sisemp = i.inv_sisemp AND a.art_codigo = i.inv_artcodigo "
        strsql &= "                  LEFT JOIN {conta}.inventario_codigos ic ON ic.empresa = a.art_sisemp AND ic.clase = a.art_clase "
        strsql &= "                     WHERE h.HDoc_Sis_Emp = {empresa} AND h.HDoc_Doc_Cat = 127 AND h.HDoc_Doc_Ano = {anio} AND h.HDoc_Doc_Num = {numero} "
        strsql &= "                        UNION "
        ' ***** Linea de Proveedor
        strsql &= "                        Select 0 Transaccion, h.HDoc_Sis_Emp empresa, {ejercico} ejercicio, {poliza},1 item, p.pro_cuenta cuenta, 1 parametroCuenta, SUM((d.DDoc_Prd_NET * d.DDoc_Prd_QTY) * h.HDoc_Doc_TC) importe, '' centroCosto, '' partidaPresupuestal, 'A' operacion, h.HDoc_Doc_Fec Fecha,0 clase, 28 modo, h.HDoc_Doc_Cat refTipo, h.HDoc_Doc_Ano refCiclo, h.HDoc_Doc_Num refNumero, 0 id "
        strsql &= "                    From Dcmtos_HDR h "
        strsql &= "                Left JOIN Dcmtos_DTL d ON d.DDoc_Sis_Emp= h.HDoc_Sis_Emp AND d.DDoc_Doc_Cat = h.HDoc_Doc_Cat AND d.DDoc_Doc_Ano = h.HDoc_Doc_Ano AND d.DDoc_Doc_Num = h.HDoc_Doc_Num "
        strsql &= "            Left JOIN Proveedores p ON p.pro_sisemp = h.HDoc_Sis_Emp And p.pro_codigo = h.HDoc_Emp_Cod "
        strsql &= "        WHERE h.HDoc_Sis_Emp = {empresa} And h.HDoc_Doc_Cat = 127 And h.HDoc_Doc_Ano = {anio} And h.HDoc_Doc_Num = {numero} "
        If Sesion.IdEmpresa = 18 Then
            strsql &= "; INSERT INTO contapdm.detalle_polizas "
            ' *** Linea de inventario
            strsql &= "   SELECT 0, h.HDoc_Sis_Emp empresa, {ejercico}, {poliza},1 item, ic.transito cuenta,1 parametroCuenta, SUM((d.DDoc_Prd_NET * d.DDoc_Prd_QTY) * h.HDoc_Doc_TC) importe,'' centroCosto, '' partidaPresupuestal, 'C' operacion, h.HDoc_Doc_Fec Fecha,0 clase, 28 modo, h.HDoc_Doc_Cat refTipo, h.HDoc_Doc_Ano refCiclo, h.HDoc_Doc_Num refNumero, 0 id "
            strsql &= "       FROM PDM.Dcmtos_HDR h "
            strsql &= "        Left JOIN PDM.Dcmtos_DTL d ON d.DDoc_Sis_Emp = h.HDoc_Sis_Emp AND d.DDoc_Doc_Cat = h.HDoc_Doc_Cat AND d.DDoc_Doc_Ano = h.HDoc_Doc_Ano AND d.DDoc_Doc_Num = h.HDoc_Doc_Num "
            strsql &= "            LEFT JOIN PDM.Inventarios i ON i.inv_sisemp = d.DDoc_Sis_Emp AND i.inv_numero = d.DDoc_Prd_Cod "
            strsql &= "              LEFT JOIN PDM.Articulos a ON a.art_sisemp = i.inv_sisemp AND a.art_codigo = i.inv_artcodigo "
            strsql &= "                  LEFT JOIN contapdm.inventario_codigos ic ON ic.empresa = a.art_sisemp AND ic.clase = a.art_clase "
            strsql &= "                     WHERE h.HDoc_Sis_Emp = {empresa} AND h.HDoc_Doc_Cat = 127 AND h.HDoc_Doc_Ano = {anio} AND h.HDoc_Doc_Num = {numero} "
            strsql &= "                        UNION "
            ' ***** Linea de Proveedor
            strsql &= "                        Select 0 Transaccion, h.HDoc_Sis_Emp empresa, {ejercico} ejercicio, {poliza},1 item, p.pro_cuenta cuenta, 1 parametroCuenta, SUM((d.DDoc_Prd_NET * d.DDoc_Prd_QTY) * h.HDoc_Doc_TC) importe, '' centroCosto, '' partidaPresupuestal, 'A' operacion, h.HDoc_Doc_Fec Fecha,0 clase, 28 modo, h.HDoc_Doc_Cat refTipo, h.HDoc_Doc_Ano refCiclo, h.HDoc_Doc_Num refNumero, 0 id "
            strsql &= "                    From PDM.Dcmtos_HDR h "
            strsql &= "                Left JOIN PDM.Dcmtos_DTL d ON d.DDoc_Sis_Emp= h.HDoc_Sis_Emp AND d.DDoc_Doc_Cat = h.HDoc_Doc_Cat AND d.DDoc_Doc_Ano = h.HDoc_Doc_Ano AND d.DDoc_Doc_Num = h.HDoc_Doc_Num "
            strsql &= "            Left JOIN PDM.Proveedores p ON p.pro_sisemp = h.HDoc_Sis_Emp And p.pro_codigo = h.HDoc_Emp_Cod "
            strsql &= "        WHERE h.HDoc_Sis_Emp = {empresa} And h.HDoc_Doc_Cat = 127 And h.HDoc_Doc_Ano = {anio} And h.HDoc_Doc_Num = {numero} "

        End If
        strsql = Replace(strsql, "{empresa}", Sesion.IdEmpresa)
        strsql = Replace(strsql, "{anio}", anio)
        strsql = Replace(strsql, "{numero}", num)
        strsql = Replace(strsql, "{ejercico}", EJERCICIO)
        strsql = Replace(strsql, "{poliza}", poliza)
        strsql = Replace(strsql, "{conta}", Sesion.BaseConta)

        Return strsql
    End Function
#End Region

#Region "Inventario Materia Prima - Ingreso a Bodega"
    Private Sub PolizaIngresoMateriaPrima(ByVal cat As Integer, ByVal anio As Integer, ByVal num As Integer)
        Dim longPolizas As Long = NO_FILA
        Dim COM As MySqlCommand
        Dim strSQL As String = STR_VACIO
        Dim DiferencialTC As Double

        Try
            longPolizas = NuevaPoliza()
            UltimaPoliza(longPolizas, EJERCICIO) ' actualiza la ultima poliza

            DiferencialTC = DiferencialIngresoMateriaPrima(cat, anio, num)
            DiferencialTC = Math.Round(CDbl(DiferencialTC) + CDbl(0.001), 2)

            strSQL = SQLEncabezadoIngresoMateriaPrima(cat, anio, num, longPolizas) ' Encabezado
            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSQL, CON)
            COM.ExecuteNonQuery()

            strSQL = STR_VACIO

            strSQL = SQLDetalleIngresoMateriaPrima(cat, anio, num, longPolizas, DiferencialTC) ' Detelle
            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSQL, CON)
            COM.ExecuteNonQuery()

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try

    End Sub

    Private Function DiferencialIngresoMateriaPrima(ByVal cat As Integer, ByVal anio As Integer, ByVal num As Integer) As Double
        Dim strsql As String = STR_VACIO
        Dim COM As MySqlCommand
        Dim Diferencial As Double = 0

        strsql = " SELECT (( "
        strsql &= "    Select SUM((d.DDoc_Prd_NET * d.DDoc_Prd_QTY) * hd.HDoc_Doc_TC) importe "
        strsql &= "        From Dcmtos_HDR h "
        strsql &= "            Left JOIN Dcmtos_DTL_Pro p ON p.PDoc_Sis_Emp = h.HDoc_Sis_Emp AND p.PDoc_Chi_Cat = h.HDoc_Doc_Cat AND p.PDoc_Chi_Ano = h.HDoc_Doc_Ano AND p.PDoc_Chi_Num = h.HDoc_Doc_Num "
        strsql &= "                Left JOIN Dcmtos_HDR hd ON hd.HDoc_Sis_Emp = p.PDoc_Sis_Emp AND hd.HDoc_Doc_Cat = p.PDoc_Par_Cat AND hd.HDoc_Doc_Ano = p.PDoc_Par_Ano AND hd.HDoc_Doc_Num = p.PDoc_Par_Num "
        strsql &= "                    Left JOIN Dcmtos_DTL d ON d.DDoc_Sis_Emp = p.PDoc_Sis_Emp AND d.DDoc_Doc_Cat = p.PDoc_Chi_Cat AND d.DDoc_Doc_Ano = p.PDoc_Chi_Ano AND d.DDoc_Doc_Num = p.PDoc_Chi_Num AND d.DDoc_Doc_Lin = p.PDoc_Chi_Lin "
        strsql &= "                        Left JOIN Inventarios i ON i.inv_sisemp = d.DDoc_Sis_Emp AND i.inv_numero = d.DDoc_Prd_Cod "
        strsql &= "                            Left JOIN Articulos a ON a.art_sisemp = i.inv_sisemp AND a.art_codigo = i.inv_artcodigo "
        strsql &= "                                Left JOIN {conta}.inventario_codigos ic ON ic.empresa = a.art_sisemp AND ic.clase = a.art_clase "
        strsql &= "                                    WHERE h.HDoc_Sis_Emp = {empresa} AND h.HDoc_Doc_Cat = {cat} AND h.HDoc_Doc_Ano = {anio} AND h.HDoc_Doc_Num = {num})- "
        strsql &= "                                        (Select SUM((d.DDoc_Prd_NET * d.DDoc_Prd_QTY) * hd.HDoc_Doc_TC) importe "
        strsql &= "                                            From Dcmtos_HDR h "
        strsql &= "                                                Left JOIN Dcmtos_DTL_Pro p ON p.PDoc_Sis_Emp = h.HDoc_Sis_Emp AND p.PDoc_Chi_Cat = h.HDoc_Doc_Cat AND p.PDoc_Chi_Ano = h.HDoc_Doc_Ano AND p.PDoc_Chi_Num = h.HDoc_Doc_Num /* Pro de ingreso a bodega a poliza 180 <-- 47 */ "
        strsql &= "                                                Left JOIN Dcmtos_DTL_Pro pdp ON pdp.PDoc_Sis_Emp = p.PDoc_Sis_Emp AND pdp.PDoc_Chi_Cat = p.PDoc_Par_Cat AND pdp.PDoc_Chi_Ano = p.PDoc_Par_Ano AND pdp.PDoc_Chi_Num = p.PDoc_Par_Num AND pdp.PDoc_Chi_Lin = p.PDoc_Par_Lin "
        '/* Pro de Poliza a  datos para poliza 55 <-- 180  */
        strsql &= "                                            Left JOIN Dcmtos_DTL_Pro pc ON pc.PDoc_Sis_Emp = pdp.PDoc_Sis_Emp AND pc.PDoc_Chi_Cat = pdp.PDoc_Par_Cat AND pc.PDoc_Chi_Ano = pdp.PDoc_Par_Ano AND pc.PDoc_Chi_Num = pdp.PDoc_Par_Num AND pc.PDoc_Chi_Lin = pdp.PDoc_Par_Lin  "
        '/* Pro de datos para Poliza a Confirmacion 127 <-- 55  */
        strsql &= "                                        Left JOIN Dcmtos_HDR hd ON hd.HDoc_Sis_Emp = pc.PDoc_Sis_Emp AND hd.HDoc_Doc_Cat = pc.PDoc_Par_Cat AND hd.HDoc_Doc_Ano = pc.PDoc_Par_Ano AND hd.HDoc_Doc_Num = pc.PDoc_Par_Num  "
        strsql &= "                                    Left JOIN Dcmtos_DTL d ON d.DDoc_Sis_Emp = p.PDoc_Sis_Emp AND d.DDoc_Doc_Cat = p.PDoc_Chi_Cat AND d.DDoc_Doc_Ano = p.PDoc_Chi_Ano AND d.DDoc_Doc_Num = p.PDoc_Chi_Num AND d.DDoc_Doc_Lin = p.PDoc_Chi_Lin "
        strsql &= "                                Left JOIN Inventarios i ON i.inv_sisemp = d.DDoc_Sis_Emp AND i.inv_numero = d.DDoc_Prd_Cod "
        strsql &= "                            Left JOIN Articulos a ON a.art_sisemp = i.inv_sisemp AND a.art_codigo = i.inv_artcodigo "
        strsql &= "                        Left JOIN {conta}.inventario_codigos ic ON ic.empresa = a.art_sisemp And ic.clase = a.art_clase "
        strsql &= "                    WHERE h.HDoc_Sis_Emp = {empresa} And h.HDoc_Doc_Cat = {cat} And h.HDoc_Doc_Ano = {anio} And h.HDoc_Doc_Num = {num})) diferencial "

        strsql = Replace(strsql, "{empresa}", Sesion.IdEmpresa)
        strsql = Replace(strsql, "{cat}", cat)
        strsql = Replace(strsql, "{anio}", anio)
        strsql = Replace(strsql, "{num}", num)
        strsql = Replace(strsql, "{conta}", Sesion.BaseConta)
        strsql = Replace(strsql, "{ejer}", EJERCICIO)

        MyCnn.CONECTAR = strConexion
        COM = New MySqlCommand(strsql, CON)
        Diferencial = COM.ExecuteScalar

        Return Diferencial
    End Function

    Private Function SQLEncabezadoIngresoMateriaPrima(ByVal cat As Integer, ByVal anio As Integer, ByVal num As Integer, ByVal poliza As Integer)
        Dim strsql As String = STR_VACIO

        strsql = " INSERT INTO {conta}.polizas"
        strsql &= "   SELECT h.HDoc_Sis_Emp empresa, {ejercicio} ejercicio, {poliza} poliza, h.HDoc_Doc_Fec fecha, CONCAT('Poliza de Inventario de Materia Prima, Segun Factura No. ', h.HDoc_DR1_Num, ' -> ', h.HDoc_Doc_Num) concepto, 11 tipo, h.HDoc_Doc_TC TC, '' observacion, h.HDoc_Usuario operador, 'C' estado, NOW() marca,'' grupo, 11 modo, h.HDoc_Doc_Cat refTipo, h.HDoc_Doc_Ano refCiclo, h.HDoc_Doc_Num refNumero, NULL divisa, h.HDoc_Doc_TC Tasa,0 revisado,'' usuarioRev, NULL ultRev "
        strsql &= "      FROM Dcmtos_HDR h "
        strsql &= "         WHERE h.HDoc_Sis_Emp = {empresa} AND h.HDoc_Doc_Cat = {cat} AND h.HDoc_Doc_Ano = {anio} AND h.HDoc_Doc_Num = {num} "
        If Sesion.IdEmpresa = 18 Then
            strsql &= "; INSERT INTO contapdm.polizas"
            strsql &= "   SELECT h.HDoc_Sis_Emp empresa, {ejercicio} ejercicio, {poliza} poliza, h.HDoc_Doc_Fec fecha, CONCAT('Poliza de Inventario de Materia Prima, Segun Factura No. ', h.HDoc_DR1_Num, ' -> ', h.HDoc_Doc_Num) concepto, 11 tipo, h.HDoc_Doc_TC TC, '' observacion, h.HDoc_Usuario operador, 'C' estado, NOW() marca,'' grupo, 11 modo, h.HDoc_Doc_Cat refTipo, h.HDoc_Doc_Ano refCiclo, h.HDoc_Doc_Num refNumero, NULL divisa, h.HDoc_Doc_TC Tasa,0 revisado,'' usuarioRev, NULL ultRev "
            strsql &= "      FROM PDM.Dcmtos_HDR h "
            strsql &= "         WHERE h.HDoc_Sis_Emp = {empresa} AND h.HDoc_Doc_Cat = {cat} AND h.HDoc_Doc_Ano = {anio} AND h.HDoc_Doc_Num = {num} "

        End If
        strsql = Replace(strsql, "{ejercicio}", EJERCICIO)
        strsql = Replace(strsql, "{poliza}", poliza)
        strsql = Replace(strsql, "{empresa}", Sesion.IdEmpresa)
        strsql = Replace(strsql, "{cat}", cat)
        strsql = Replace(strsql, "{anio}", anio)
        strsql = Replace(strsql, "{num}", num)
        strsql = Replace(strsql, "{conta}", Sesion.BaseConta)

        Return strsql
    End Function

    Private Function SQLDetalleIngresoMateriaPrima(ByVal cat As Integer, ByVal anio As Integer, ByVal num As Integer, ByVal poliza As Integer, ByVal diferencia As Double)
        Dim strsql As String = STR_VACIO

        strsql = " INSERT INTO {conta}.detalle_polizas "
        strsql &= " SELECT 0, h.HDoc_Sis_Emp empresa, {ejercicio}, {poliza},1 item, ic.transito cuenta,1 parametroCuenta, SUM((d.DDoc_Prd_NET * d.DDoc_Prd_QTY) * hd.HDoc_Doc_TC) importe,'' centroCosto, '' partidaPresupuestal, 'A' operacion, h.HDoc_Doc_Fec Fecha,0 clase, 11 modo, h.HDoc_Doc_Cat refTipo, h.HDoc_Doc_Ano refCiclo, h.HDoc_Doc_Num refNumero, 0 id "
        strsql &= "    FROM Dcmtos_HDR h "
        strsql &= "        Left JOIN Dcmtos_DTL_Pro p ON p.PDoc_Sis_Emp = h.HDoc_Sis_Emp AND p.PDoc_Chi_Cat = h.HDoc_Doc_Cat AND p.PDoc_Chi_Ano = h.HDoc_Doc_Ano AND p.PDoc_Chi_Num = h.HDoc_Doc_Num  "
        strsql &= "            Left JOIN Dcmtos_HDR hd ON hd.HDoc_Sis_Emp = p.PDoc_Sis_Emp AND hd.HDoc_Doc_Cat = p.PDoc_Par_Cat AND hd.HDoc_Doc_Ano = p.PDoc_Par_Ano AND hd.HDoc_Doc_Num = p.PDoc_Par_Num "
        strsql &= "                Left JOIN Dcmtos_DTL d ON d.DDoc_Sis_Emp = p.PDoc_Sis_Emp AND d.DDoc_Doc_Cat = p.PDoc_Chi_Cat AND d.DDoc_Doc_Ano = p.PDoc_Chi_Ano AND d.DDoc_Doc_Num = p.PDoc_Chi_Num AND d.DDoc_Doc_Lin = p.PDoc_Chi_Lin "
        strsql &= "                    Left JOIN Inventarios i ON i.inv_sisemp = d.DDoc_Sis_Emp AND i.inv_numero = d.DDoc_Prd_Cod "
        strsql &= "                        Left JOIN Articulos a ON a.art_sisemp = i.inv_sisemp AND a.art_codigo = i.inv_artcodigo "
        strsql &= "                            Left JOIN {conta}.inventario_codigos ic ON ic.empresa = a.art_sisemp AND ic.clase = a.art_clase "
        strsql &= "                                WHERE h.HDoc_Sis_Emp = {empresa} AND h.HDoc_Doc_Cat = {cat} AND h.HDoc_Doc_Ano = {anio} AND h.HDoc_Doc_Num = {num} "

        If diferencia > 0 Then
            strsql &= " UNION "
            strsql &= " SELECT 0 Transaccion, h.HDoc_Sis_Emp empresa, {ejercicio}, {poliza},1 item, p.pro_cuenta cuenta, 1 parametroCuenta, {dif} diferencia, '' centroCosto, '' partidaPresupuestal, 'C' operacion, h.HDoc_Doc_Fec Fecha,0 clase, 11 modo, h.HDoc_Doc_Cat refTipo, h.HDoc_Doc_Ano refCiclo, h.HDoc_Doc_Num refNumero, 0 id "
            strsql &= " From Dcmtos_HDR h "
            strsql &= " Left JOIN Dcmtos_DTL d ON d.DDoc_Sis_Emp= h.HDoc_Sis_Emp AND d.DDoc_Doc_Cat = h.HDoc_Doc_Cat AND d.DDoc_Doc_Ano = h.HDoc_Doc_Ano AND d.DDoc_Doc_Num = h.HDoc_Doc_Num "
            strsql &= " Left JOIN Proveedores p ON p.pro_sisemp = h.HDoc_Sis_Emp AND p.pro_codigo = h.HDoc_Emp_Cod "
            strsql &= " WHERE h.HDoc_Sis_Emp = {empresa} AND h.HDoc_Doc_Cat = {cat} AND h.HDoc_Doc_Ano = {anio} AND h.HDoc_Doc_Num = {num} "

        ElseIf diferencia < 0 Then
            diferencia = diferencia * (-1)
            strsql &= " UNION "
            strsql &= " SELECT 0 Transaccion, h.HDoc_Sis_Emp empresa, {ejercicio}, {poliza},1 item, p.pro_cuenta cuenta, 1 parametroCuenta, {dif} diferencia, '' centroCosto, '' partidaPresupuestal, 'A' operacion, h.HDoc_Doc_Fec Fecha,0 clase, 11 modo, h.HDoc_Doc_Cat refTipo, h.HDoc_Doc_Ano refCiclo, h.HDoc_Doc_Num refNumero, 0 id "
            strsql &= " From Dcmtos_HDR h "
            strsql &= " Left JOIN Dcmtos_DTL d ON d.DDoc_Sis_Emp= h.HDoc_Sis_Emp AND d.DDoc_Doc_Cat = h.HDoc_Doc_Cat AND d.DDoc_Doc_Ano = h.HDoc_Doc_Ano AND d.DDoc_Doc_Num = h.HDoc_Doc_Num "
            strsql &= " Left JOIN Proveedores p ON p.pro_sisemp = h.HDoc_Sis_Emp AND p.pro_codigo = h.HDoc_Emp_Cod "
            strsql &= " WHERE h.HDoc_Sis_Emp = {empresa} AND h.HDoc_Doc_Cat = {cat} AND h.HDoc_Doc_Ano = {anio} AND h.HDoc_Doc_Num = {num} "

        End If


        strsql &= "                                    UNION "
        strsql &= "                                        Select 0, h.HDoc_Sis_Emp empresa, {ejercicio}, {poliza},1 item, ic.inventario cuenta,1 parametroCuenta, SUM((d.DDoc_Prd_NET * d.DDoc_Prd_QTY) * hd.HDoc_Doc_TC) importe,'' centroCosto, '' partidaPresupuestal, 'C' operacion, h.HDoc_Doc_Fec Fecha,0 clase, 11 modo, h.HDoc_Doc_Cat refTipo, h.HDoc_Doc_Ano refCiclo, h.HDoc_Doc_Num refNumero, 0 id "
        strsql &= "                                            From Dcmtos_HDR h "
        strsql &= "                                                Left JOIN Dcmtos_DTL_Pro p ON p.PDoc_Sis_Emp = h.HDoc_Sis_Emp AND p.PDoc_Chi_Cat = h.HDoc_Doc_Cat AND p.PDoc_Chi_Ano = h.HDoc_Doc_Ano AND p.PDoc_Chi_Num = h.HDoc_Doc_Num /* Pro de ingreso a bodega a poliza 180 <-- 47 */ "
        strsql &= "                                                Left JOIN Dcmtos_DTL_Pro pdp ON pdp.PDoc_Sis_Emp = p.PDoc_Sis_Emp AND pdp.PDoc_Chi_Cat = p.PDoc_Par_Cat AND pdp.PDoc_Chi_Ano = p.PDoc_Par_Ano AND pdp.PDoc_Chi_Num = p.PDoc_Par_Num AND pdp.PDoc_Chi_Lin = p.PDoc_Par_Lin "
        '/* Pro de Poliza a  datos para poliza 55 <-- 180  */
        strsql &= "                                            Left JOIN Dcmtos_DTL_Pro pc ON pc.PDoc_Sis_Emp = pdp.PDoc_Sis_Emp AND pc.PDoc_Chi_Cat = pdp.PDoc_Par_Cat AND pc.PDoc_Chi_Ano = pdp.PDoc_Par_Ano AND pc.PDoc_Chi_Num = pdp.PDoc_Par_Num AND pc.PDoc_Chi_Lin = pdp.PDoc_Par_Lin "
        '/* Pro de datos para Poliza a Confirmacion 127 <-- 55  */
        strsql &= "                                        Left JOIN Dcmtos_HDR hd ON hd.HDoc_Sis_Emp = pc.PDoc_Sis_Emp AND hd.HDoc_Doc_Cat = pc.PDoc_Par_Cat AND hd.HDoc_Doc_Ano = pc.PDoc_Par_Ano AND hd.HDoc_Doc_Num = pc.PDoc_Par_Num "
        strsql &= "                                    Left JOIN Dcmtos_DTL d ON d.DDoc_Sis_Emp = p.PDoc_Sis_Emp AND d.DDoc_Doc_Cat = p.PDoc_Chi_Cat AND d.DDoc_Doc_Ano = p.PDoc_Chi_Ano AND d.DDoc_Doc_Num = p.PDoc_Chi_Num AND d.DDoc_Doc_Lin = p.PDoc_Chi_Lin  "
        strsql &= "                                Left JOIN Inventarios i ON i.inv_sisemp = d.DDoc_Sis_Emp AND i.inv_numero = d.DDoc_Prd_Cod "
        strsql &= "                            Left JOIN Articulos a ON a.art_sisemp = i.inv_sisemp AND a.art_codigo = i.inv_artcodigo "
        strsql &= "                        Left JOIN {conta}.inventario_codigos ic ON ic.empresa = a.art_sisemp And ic.clase = a.art_clase "
        strsql &= "                    WHERE h.HDoc_Sis_Emp = {empresa} And h.HDoc_Doc_Cat = {cat} And h.HDoc_Doc_Ano = {anio} And h.HDoc_Doc_Num = {num} "
        If Sesion.IdEmpresa = 18 Then
            strsql &= "; INSERT INTO contapdm.detalle_polizas "
            strsql &= " SELECT 0, h.HDoc_Sis_Emp empresa, {ejercicio}, {poliza},1 item, ic.transito cuenta,1 parametroCuenta, SUM((d.DDoc_Prd_NET * d.DDoc_Prd_QTY) * hd.HDoc_Doc_TC) importe,'' centroCosto, '' partidaPresupuestal, 'A' operacion, h.HDoc_Doc_Fec Fecha,0 clase, 11 modo, h.HDoc_Doc_Cat refTipo, h.HDoc_Doc_Ano refCiclo, h.HDoc_Doc_Num refNumero, 0 id "
            strsql &= "    FROM PDM.Dcmtos_HDR h "
            strsql &= "        Left JOIN PDM.Dcmtos_DTL_Pro p ON p.PDoc_Sis_Emp = h.HDoc_Sis_Emp AND p.PDoc_Chi_Cat = h.HDoc_Doc_Cat AND p.PDoc_Chi_Ano = h.HDoc_Doc_Ano AND p.PDoc_Chi_Num = h.HDoc_Doc_Num  "
            strsql &= "            Left JOIN PDM.Dcmtos_HDR hd ON hd.HDoc_Sis_Emp = p.PDoc_Sis_Emp AND hd.HDoc_Doc_Cat = p.PDoc_Par_Cat AND hd.HDoc_Doc_Ano = p.PDoc_Par_Ano AND hd.HDoc_Doc_Num = p.PDoc_Par_Num "
            strsql &= "                Left JOIN PDM.Dcmtos_DTL d ON d.DDoc_Sis_Emp = p.PDoc_Sis_Emp AND d.DDoc_Doc_Cat = p.PDoc_Chi_Cat AND d.DDoc_Doc_Ano = p.PDoc_Chi_Ano AND d.DDoc_Doc_Num = p.PDoc_Chi_Num AND d.DDoc_Doc_Lin = p.PDoc_Chi_Lin "
            strsql &= "                    Left JOIN PDM.Inventarios i ON i.inv_sisemp = d.DDoc_Sis_Emp AND i.inv_numero = d.DDoc_Prd_Cod "
            strsql &= "                        Left JOIN PDM.Articulos a ON a.art_sisemp = i.inv_sisemp AND a.art_codigo = i.inv_artcodigo "
            strsql &= "                            Left JOIN contapdm.inventario_codigos ic ON ic.empresa = a.art_sisemp AND ic.clase = a.art_clase "
            strsql &= "                                WHERE h.HDoc_Sis_Emp = {empresa} AND h.HDoc_Doc_Cat = {cat} AND h.HDoc_Doc_Ano = {anio} AND h.HDoc_Doc_Num = {num} "

            If diferencia > 0 Then
                strsql &= " UNION "
                strsql &= " SELECT 0 Transaccion, h.HDoc_Sis_Emp empresa, {ejercicio}, {poliza},1 item, p.pro_cuenta cuenta, 1 parametroCuenta, {dif} diferencia, '' centroCosto, '' partidaPresupuestal, 'C' operacion, h.HDoc_Doc_Fec Fecha,0 clase, 11 modo, h.HDoc_Doc_Cat refTipo, h.HDoc_Doc_Ano refCiclo, h.HDoc_Doc_Num refNumero, 0 id "
                strsql &= " From PDM.Dcmtos_HDR h "
                strsql &= " Left JOIN PDM.Dcmtos_DTL d ON d.DDoc_Sis_Emp= h.HDoc_Sis_Emp AND d.DDoc_Doc_Cat = h.HDoc_Doc_Cat AND d.DDoc_Doc_Ano = h.HDoc_Doc_Ano AND d.DDoc_Doc_Num = h.HDoc_Doc_Num "
                strsql &= " Left JOIN PDM.Proveedores p ON p.pro_sisemp = h.HDoc_Sis_Emp AND p.pro_codigo = h.HDoc_Emp_Cod "
                strsql &= " WHERE h.HDoc_Sis_Emp = {empresa} AND h.HDoc_Doc_Cat = {cat} AND h.HDoc_Doc_Ano = {anio} AND h.HDoc_Doc_Num = {num} "

            ElseIf diferencia < 0 Then
                diferencia = diferencia * (-1)
                strsql &= " UNION "
                strsql &= " SELECT 0 Transaccion, h.HDoc_Sis_Emp empresa, {ejercicio}, {poliza},1 item, p.pro_cuenta cuenta, 1 parametroCuenta, {dif} diferencia, '' centroCosto, '' partidaPresupuestal, 'A' operacion, h.HDoc_Doc_Fec Fecha,0 clase, 11 modo, h.HDoc_Doc_Cat refTipo, h.HDoc_Doc_Ano refCiclo, h.HDoc_Doc_Num refNumero, 0 id "
                strsql &= " From PDM.Dcmtos_HDR h "
                strsql &= " Left JOIN PDM.Dcmtos_DTL d ON d.DDoc_Sis_Emp= h.HDoc_Sis_Emp AND d.DDoc_Doc_Cat = h.HDoc_Doc_Cat AND d.DDoc_Doc_Ano = h.HDoc_Doc_Ano AND d.DDoc_Doc_Num = h.HDoc_Doc_Num "
                strsql &= " Left JOIN PDM.Proveedores p ON p.pro_sisemp = h.HDoc_Sis_Emp AND p.pro_codigo = h.HDoc_Emp_Cod "
                strsql &= " WHERE h.HDoc_Sis_Emp = {empresa} AND h.HDoc_Doc_Cat = {cat} AND h.HDoc_Doc_Ano = {anio} AND h.HDoc_Doc_Num = {num} "

            End If


            strsql &= "                                    UNION "
            strsql &= "                                        Select 0, h.HDoc_Sis_Emp empresa, {ejercicio}, {poliza},1 item, ic.inventario cuenta,1 parametroCuenta, SUM((d.DDoc_Prd_NET * d.DDoc_Prd_QTY) * hd.HDoc_Doc_TC) importe,'' centroCosto, '' partidaPresupuestal, 'C' operacion, h.HDoc_Doc_Fec Fecha,0 clase, 11 modo, h.HDoc_Doc_Cat refTipo, h.HDoc_Doc_Ano refCiclo, h.HDoc_Doc_Num refNumero, 0 id "
            strsql &= "                                            From PDM.Dcmtos_HDR h "
            strsql &= "                                                Left JOIN PDM.Dcmtos_DTL_Pro p ON p.PDoc_Sis_Emp = h.HDoc_Sis_Emp AND p.PDoc_Chi_Cat = h.HDoc_Doc_Cat AND p.PDoc_Chi_Ano = h.HDoc_Doc_Ano AND p.PDoc_Chi_Num = h.HDoc_Doc_Num /* Pro de ingreso a bodega a poliza 180 <-- 47 */ "
            strsql &= "                                                Left JOIN PDM.Dcmtos_DTL_Pro pdp ON pdp.PDoc_Sis_Emp = p.PDoc_Sis_Emp AND pdp.PDoc_Chi_Cat = p.PDoc_Par_Cat AND pdp.PDoc_Chi_Ano = p.PDoc_Par_Ano AND pdp.PDoc_Chi_Num = p.PDoc_Par_Num AND pdp.PDoc_Chi_Lin = p.PDoc_Par_Lin "
            '/* Pro de Poliza a  datos para poliza 55 <-- 180  */
            strsql &= "                                            Left JOIN PDM.Dcmtos_DTL_Pro pc ON pc.PDoc_Sis_Emp = pdp.PDoc_Sis_Emp AND pc.PDoc_Chi_Cat = pdp.PDoc_Par_Cat AND pc.PDoc_Chi_Ano = pdp.PDoc_Par_Ano AND pc.PDoc_Chi_Num = pdp.PDoc_Par_Num AND pc.PDoc_Chi_Lin = pdp.PDoc_Par_Lin "
            '/* Pro de datos para Poliza a Confirmacion 127 <-- 55  */
            strsql &= "                                        Left JOIN PDM.Dcmtos_HDR hd ON hd.HDoc_Sis_Emp = pc.PDoc_Sis_Emp AND hd.HDoc_Doc_Cat = pc.PDoc_Par_Cat AND hd.HDoc_Doc_Ano = pc.PDoc_Par_Ano AND hd.HDoc_Doc_Num = pc.PDoc_Par_Num "
            strsql &= "                                    Left JOIN PDM.Dcmtos_DTL d ON d.DDoc_Sis_Emp = p.PDoc_Sis_Emp AND d.DDoc_Doc_Cat = p.PDoc_Chi_Cat AND d.DDoc_Doc_Ano = p.PDoc_Chi_Ano AND d.DDoc_Doc_Num = p.PDoc_Chi_Num AND d.DDoc_Doc_Lin = p.PDoc_Chi_Lin  "
            strsql &= "                                Left JOIN PDM.Inventarios i ON i.inv_sisemp = d.DDoc_Sis_Emp AND i.inv_numero = d.DDoc_Prd_Cod "
            strsql &= "                            Left JOIN PDM.Articulos a ON a.art_sisemp = i.inv_sisemp AND a.art_codigo = i.inv_artcodigo "
            strsql &= "                        Left JOIN contapdm.inventario_codigos ic ON ic.empresa = a.art_sisemp And ic.clase = a.art_clase "
            strsql &= "                    WHERE h.HDoc_Sis_Emp = {empresa} And h.HDoc_Doc_Cat = {cat} And h.HDoc_Doc_Ano = {anio} And h.HDoc_Doc_Num = {num} "
        End If
        strsql = Replace(strsql, "{cat}", cat)
        strsql = Replace(strsql, "{anio}", anio)
        strsql = Replace(strsql, "{num}", num)
        strsql = Replace(strsql, "{poliza}", poliza)
        strsql = Replace(strsql, "{ejercicio}", EJERCICIO)
        strsql = Replace(strsql, "{conta}", Sesion.BaseConta)
        strsql = Replace(strsql, "{empresa}", Sesion.IdEmpresa)
        strsql = Replace(strsql, "{dif}", diferencia)

        Return strsql
    End Function
#End Region

#Region "Inventario Producto en Proceso - (Produccion)"
    Private Sub PolizaInventarioEnProceso(ByVal cat As Integer, ByVal anio As Integer, ByVal num As Integer)

        Dim longPolizas As Long = NO_FILA
        Dim COM As MySqlCommand
        Dim strSQL As String = STR_VACIO

        Try
            longPolizas = NuevaPoliza()
            UltimaPoliza(longPolizas, EJERCICIO) ' actualiza la ultima poliza

            strSQL = SQLEncabezadoPolizaDeProduccion(cat, anio, num, longPolizas)
            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSQL, CON)
            COM.ExecuteNonQuery()

            strSQL = STR_VACIO
            If Sesion.IdEmpresa = 22 Then
                strSQL = SQLDetallePolizaDeKnitting(cat, anio, num, longPolizas)
            Else
                strSQL = SQLDetallePolizaDeProduccion(cat, anio, num, longPolizas)
            End If

            MyCnn.CONECTAR = strConexion & ";Allow User Variables=True"
            COM = New MySqlCommand(strSQL, CON)
            COM.ExecuteNonQuery()
            strSQL = STR_VACIO

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Function SQLEncabezadoPolizaDeProduccion(ByVal cat As Integer, ByVal anio As Integer, ByVal num As Integer, ByVal poliza As Integer)
        Dim strSQL As String = STR_VACIO

        strSQL = " INSERT INTO {conta}.polizas"
        strSQL &= "   SELECT h.HDoc_Sis_Emp empresa, {ejercicio} ejercicio, {poliza} poliza, h.HDoc_Doc_Fec fecha, CONCAT('Poliza de Inventario en Proceso ',h.HDoc_DR1_Num ,' Segun Documento de tendido No. ',h.HDoc_Doc_Num) concepto, 29 tipo, h.HDoc_Doc_TC TC, '' observacion, h.HDoc_Usuario operador, 'C' estado, NOW() marca,'' grupo, 29 modo, h.HDoc_Doc_Cat refTipo, h.HDoc_Doc_Ano refCiclo, h.HDoc_Doc_Num refNumero, NULL divisa, h.HDoc_Doc_TC Tasa,0 revisado,'' usuarioRev, NULL ultRev "
        strSQL &= "      FROM Dcmtos_HDR h "
        strSQL &= "         WHERE h.HDoc_Sis_Emp = {empresa} AND h.HDoc_Doc_Cat = {cat} AND h.HDoc_Doc_Ano = {anio} AND h.HDoc_Doc_Num = {num} "

        If Sesion.IdEmpresa = 18 Then
            strSQL &= "; INSERT INTO contapdm.polizas"
            strSQL &= "   SELECT h.HDoc_Sis_Emp empresa, {ejercicio} ejercicio, {poliza} poliza, h.HDoc_Doc_Fec fecha, CONCAT('Poliza de Inventario en Proceso ',h.HDoc_DR1_Num ,' Segun Documento de tendido No. ',h.HDoc_Doc_Num) concepto, 29 tipo, h.HDoc_Doc_TC TC, '' observacion, h.HDoc_Usuario operador, 'C' estado, NOW() marca,'' grupo, 29 modo, h.HDoc_Doc_Cat refTipo, h.HDoc_Doc_Ano refCiclo, h.HDoc_Doc_Num refNumero, NULL divisa, h.HDoc_Doc_TC Tasa,0 revisado,'' usuarioRev, NULL ultRev "
            strSQL &= "      FROM PDM.Dcmtos_HDR h "
            strSQL &= "         WHERE h.HDoc_Sis_Emp = {empresa} AND h.HDoc_Doc_Cat = {cat} AND h.HDoc_Doc_Ano = {anio} AND h.HDoc_Doc_Num = {num} "
        End If

        strSQL = Replace(strSQL, "{ejercicio}", EJERCICIO)
        strSQL = Replace(strSQL, "{poliza}", poliza)
        strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
        strSQL = Replace(strSQL, "{cat}", cat)
        strSQL = Replace(strSQL, "{anio}", anio)
        strSQL = Replace(strSQL, "{num}", num)
        strSQL = Replace(strSQL, "{conta}", Sesion.BaseConta)

        Return strSQL
    End Function

    Private Function SQLDetallePolizaDeProduccion(ByVal cat As Integer, ByVal anio As Integer, ByVal num As Integer, ByVal poliza As Integer)
        Dim strSQL As String = STR_VACIO

        strSQL = " SET @numero=1;  "

        strSQL &= " INSERT INTO {conta}.detalle_polizas "
        strSQL &= "   SELECT l1.Transaccion,l1.Empresa,l1.ejercicio,l1.poliza, l1.item,l1.cuenta,l1.parametroCuenta,ROUND(SUM(importe_),2)  Importe,l1.centroCosto,l1.partidaPresupuestal,l1.operacion,"
        strSQL &= "       l1.Fecha, l1.clase, l1.modo, l1.refTipo, l1.refCiclo, l1.refNumero,l1.id"
        strSQL &= "         FROM (  "
        strSQL &= "             SELECT 0 Transaccion,d.DDoc_Sis_Emp Empresa,{ejercicio} ejercicio,{poliza} poliza,1 item, ic.inventario cuenta,1 parametroCuenta,'' centroCosto, '' partidaPresupuestal, 'C' operacion,h.HDoc_Doc_Fec Fecha,0 clase, 29 modo, h.HDoc_Doc_Cat refTipo, h.HDoc_Doc_Ano refCiclo, h.HDoc_Doc_Num refNumero, 0 id,(d.DDoc_Prd_QTY * d.DDoc_Prd_Net * d.DDoc_RF2_Dbl) importe_ "
        strSQL &= "                 FROM Dcmtos_DTL d "
        strSQL &= "             LEFT JOIN Dcmtos_HDR h ON h.HDoc_Sis_Emp = d.DDoc_Sis_Emp AND h.HDoc_Doc_Cat = d.DDoc_Doc_Cat AND h.HDoc_Doc_Ano = d.DDoc_Doc_Ano AND h.HDoc_Doc_Num = d.DDoc_Doc_Num "
        strSQL &= "         LEFT JOIN Inventarios i ON i.inv_sisemp = d.DDoc_Sis_Emp AND i.inv_numero = d.DDoc_Prd_Cod "
        strSQL &= "       LEFT JOIN Articulos a ON a.art_sisemp = i.inv_sisemp AND a.art_codigo = i.inv_numero "
        strSQL &= "     LEFT JOIN {conta}.inventario_codigos ic ON IF(h.HDoc_DR1_Cat = 0 , ic.clase = 2306 ,IF(h.HDoc_DR1_Cat = 1 ,ic.clase = 105, IF(h.HDoc_DR1_Cat = 2, ic.clase = 107 ,  "
        strSQL &= "   IF(h.HDoc_DR1_Cat = 3 , ic.clase = 330 , IF(h.HDoc_DR1_Cat = 4 , ic.clase = 898, ic.clase = 898))))) "
        strSQL &= " WHERE d.DDoc_Sis_Emp = {empresa} AND d.DDoc_Doc_Cat = 952 AND d.DDoc_Doc_Ano = {anio} AND  d.DDoc_Doc_Num = {num}  "
        strSQL &= "ORDER  BY  d.DDoc_Sis_Emp DESC )l1  "

        strSQL &= "      UNION "

        strSQL &= "      SELECT 0,d.DDoc_Sis_Emp Empresa,{ejercicio} ejercicio,{poliza} poliza,@numero:=@numero+1 item, ic.inventario cuenta,1 parametroCuenta,ROUND(((SUM(d.DDoc_Prd_NET * d.DDoc_Prd_QTY * d.DDoc_RF2_Dbl)) ), 2) importe,'' centroCosto, '' partidaPresupuestal, 'A' operacion,h.HDoc_Doc_Fec Fecha,0 clase, 29 modo, h.HDoc_Doc_Cat refTipo, h.HDoc_Doc_Ano refCiclo, h.HDoc_Doc_Num refNumero, 0 id"
        strSQL &= "         FROM Dcmtos_DTL d"
        strSQL &= "           LEFT JOIN Dcmtos_HDR h ON h.HDoc_Sis_Emp = d.DDoc_Sis_Emp AND h.HDoc_Doc_Cat = d.DDoc_Doc_Cat AND h.HDoc_Doc_Ano = d.DDoc_Doc_Ano AND h.HDoc_Doc_Num = d.DDoc_Doc_Num "
        strSQL &= "              LEFT JOIN Inventarios i ON i.inv_sisemp = d.DDoc_Sis_Emp AND i.inv_numero = d.DDoc_Prd_Cod "
        strSQL &= "                 LEFT JOIN Articulos a ON a.art_sisemp = i.inv_sisemp AND a.art_codigo = i.inv_artcodigo "
        strSQL &= "                    Left JOIN {conta}.inventario_codigos ic ON ic.empresa = a.art_sisemp And ic.clase = a.art_clase "
        strSQL &= "                   WHERE d.DDoc_Sis_Emp = {empresa} AND d.DDoc_Doc_Cat = 952 AND d.DDoc_Doc_Ano = {anio} AND  d.DDoc_Doc_Num = {num} "
        strSQL &= "                GROUP BY ic.inventario"

        'strSQL &= "         UNION "

        'strSQL &= "              SELECT l1.Transaccion,l1.Empresa,l1.ejercicio,l1.poliza, l1.item,l1.cuenta,l1.parametroCuenta,ROUND(SUM(((l1.Cantidad * l1.MO))* l1.Tasa),2) importe,l1.centroCosto,l1.partidaPresupuestal,l1.operacion, "
        'strSQL &= "                 l1.Fecha, l1.clase, l1.modo, l1.refTipo, l1.refCiclo, l1.refNumero, l1.id "
        'strSQL &= "                     FROM ( "
        'strSQL &= "                         SELECT 0 Transaccion,d.DDoc_Sis_Emp Empresa,14 ejercicio,31 poliza,@numero:=@numero+1 item, '51020199' cuenta,1 parametroCuenta,'' centroCosto, '' partidaPresupuestal, 'A' operacion,h.HDoc_Doc_Fec Fecha,0 clase, 29 modo, h.HDoc_Doc_Cat refTipo, h.HDoc_Doc_Ano refCiclo, h.HDoc_Doc_Num refNumero, 0 id,d.DDoc_Prd_QTY Cantidad,h.HDoc_Doc_TC Tasa,IFNULL(( "
        'strSQL &= "                             SELECT ROUND((g.Promedio + g.Total1 + g.Total2),2) Total "
        'strSQL &= "                                 FROM Gastos_Produccion g "
        'strSQL &= "                                     LEFT JOIN Catalogos c ON c.cat_num = g.idMoneda AND c.cat_clase = 'Monedas' "
        'strSQL &= "                                         LEFT JOIN Catalogos gp ON gp.cat_num = g.Gasto AND gp.cat_clase = 'GastoP' "
        'strSQL &= "                                             WHERE g.idEmpresa = {empresa} AND gp.cat_desc = 'Mano de Obra' "
        'strSQL &= "                                                 ORDER BY g.idGastoProduccion DESC   "
        'strSQL &= "                                                     LIMIT 1 ), 0) MO "
        'strSQL &= "                                                 FROM Dcmtos_DTL d "
        'strSQL &= "                                             LEFT JOIN Dcmtos_HDR h ON h.HDoc_Sis_Emp = d.DDoc_Sis_Emp AND h.HDoc_Doc_Cat = d.DDoc_Doc_Cat AND h.HDoc_Doc_Ano = d.DDoc_Doc_Ano AND h.HDoc_Doc_Num = d.DDoc_Doc_Num  "
        'strSQL &= "                                         WHERE d.DDoc_Sis_Emp = {empresa} AND d.DDoc_Doc_Cat = 952 AND d.DDoc_Doc_Ano = {anio} AND d.DDoc_Doc_Num = {num} )l1"

        'strSQL &= "                     UNION "

        'strSQL &= "                         SELECT l1.Transaccion,l1.Empresa,l1.ejercicio,l1.poliza, l1.item,l1.cuenta,l1.parametroCuenta,ROUND(SUM(((l1.Cantidad * l1.MO))* l1.Tasa),2) importe,l1.centroCosto,l1.partidaPresupuestal,l1.operacion, "
        'strSQL &= "                             l1.Fecha, l1.clase, l1.modo, l1.refTipo, l1.refCiclo, l1.refNumero, l1.id "
        'strSQL &= "                                 FROM ( "
        'strSQL &= "                                     SELECT 0 Transaccion,d.DDoc_Sis_Emp Empresa,14 ejercicio,31 poliza,@numero:=@numero+1 item, '51020299' cuenta,1 parametroCuenta,'' centroCosto, '' partidaPresupuestal, 'A' operacion,h.HDoc_Doc_Fec Fecha,0 clase, 29 modo, h.HDoc_Doc_Cat refTipo, h.HDoc_Doc_Ano refCiclo, h.HDoc_Doc_Num refNumero, 0 id,d.DDoc_Prd_QTY Cantidad,h.HDoc_Doc_TC Tasa, IFNULL(( "
        'strSQL &= "                                         SELECT ROUND((g.Promedio + g.Total1 + g.Total2),2) Total "
        'strSQL &= "                                             FROM Gastos_Produccion g "
        'strSQL &= "                                                 LEFT JOIN Catalogos c ON c.cat_num = g.idMoneda AND c.cat_clase = 'Monedas' "
        'strSQL &= "                                                     LEFT JOIN Catalogos gp ON gp.cat_num = g.Gasto AND gp.cat_clase = 'GastoP' "
        'strSQL &= "                                                 WHERE g.idEmpresa = {empresa} AND gp.cat_desc = 'Gastos de fabricación'"
        'strSQL &= "                                             ORDER BY g.idGastoProduccion DESC   "
        'strSQL &= "                                         LIMIT 1 ), 0) MO "
        'strSQL &= "                                     FROM Dcmtos_DTL d "
        'strSQL &= "                                 LEFT JOIN Dcmtos_HDR h ON h.HDoc_Sis_Emp = d.DDoc_Sis_Emp AND h.HDoc_Doc_Cat = d.DDoc_Doc_Cat AND h.HDoc_Doc_Ano = d.DDoc_Doc_Ano AND h.HDoc_Doc_Num = d.DDoc_Doc_Num  "
        'strSQL &= "                             WHERE d.DDoc_Sis_Emp = {empresa} AND d.DDoc_Doc_Cat = 952 AND d.DDoc_Doc_Ano = {anio} AND d.DDoc_Doc_Num = {num} )l1 "

        If Sesion.IdEmpresa = 18 Then
            strSQL &= "; SET @numero=1;  "

            strSQL &= " INSERT INTO contapdm.detalle_polizas "
            strSQL &= "   SELECT l1.Transaccion,l1.Empresa,l1.ejercicio,l1.poliza, l1.item,l1.cuenta,l1.parametroCuenta,ROUND(SUM(importe_),2)  Importe,l1.centroCosto,l1.partidaPresupuestal,l1.operacion,"
            strSQL &= "       l1.Fecha, l1.clase, l1.modo, l1.refTipo, l1.refCiclo, l1.refNumero,l1.id"
            strSQL &= "         FROM (  "
            strSQL &= "             SELECT 0 Transaccion,d.DDoc_Sis_Emp Empresa,{ejercicio} ejercicio,{poliza} poliza,1 item, ic.inventario cuenta,1 parametroCuenta,'' centroCosto, '' partidaPresupuestal, 'C' operacion,h.HDoc_Doc_Fec Fecha,0 clase, 29 modo, h.HDoc_Doc_Cat refTipo, h.HDoc_Doc_Ano refCiclo, h.HDoc_Doc_Num refNumero, 0 id,(d.DDoc_Prd_QTY * d.DDoc_Prd_Net * d.DDoc_RF2_Dbl) importe_ "
            strSQL &= "                 FROM PDM.Dcmtos_DTL d "
            strSQL &= "             LEFT JOIN PDM.Dcmtos_HDR h ON h.HDoc_Sis_Emp = d.DDoc_Sis_Emp AND h.HDoc_Doc_Cat = d.DDoc_Doc_Cat AND h.HDoc_Doc_Ano = d.DDoc_Doc_Ano AND h.HDoc_Doc_Num = d.DDoc_Doc_Num "
            strSQL &= "         LEFT JOIN PDM.Inventarios i ON i.inv_sisemp = d.DDoc_Sis_Emp AND i.inv_numero = d.DDoc_Prd_Cod "
            strSQL &= "       LEFT JOIN PDM.Articulos a ON a.art_sisemp = i.inv_sisemp AND a.art_codigo = i.inv_numero "
            strSQL &= "     LEFT JOIN contapdm.inventario_codigos ic ON IF(h.HDoc_DR1_Cat = 0 , ic.clase = 2306 ,IF(h.HDoc_DR1_Cat = 1 ,ic.clase = 105, IF(h.HDoc_DR1_Cat = 2, ic.clase = 107 ,  "
            strSQL &= "   IF(h.HDoc_DR1_Cat = 3 , ic.clase = 330 , IF(h.HDoc_DR1_Cat = 4 , ic.clase = 898, ic.clase = 898))))) "
            strSQL &= " WHERE d.DDoc_Sis_Emp = {empresa} AND d.DDoc_Doc_Cat = 952 AND d.DDoc_Doc_Ano = {anio} AND  d.DDoc_Doc_Num = {num}  "
            strSQL &= "ORDER  BY  d.DDoc_Sis_Emp DESC )l1  "

            strSQL &= "      UNION "

            strSQL &= "      SELECT 0,d.DDoc_Sis_Emp Empresa,{ejercicio} ejercicio,{poliza} poliza,@numero:=@numero+1 item, ic.inventario cuenta,1 parametroCuenta,ROUND(((SUM(d.DDoc_Prd_NET * d.DDoc_Prd_QTY * d.DDoc_RF2_Dbl)) ), 2) importe,'' centroCosto, '' partidaPresupuestal, 'A' operacion,h.HDoc_Doc_Fec Fecha,0 clase, 29 modo, h.HDoc_Doc_Cat refTipo, h.HDoc_Doc_Ano refCiclo, h.HDoc_Doc_Num refNumero, 0 id"
            strSQL &= "         FROM PDM.Dcmtos_DTL d"
            strSQL &= "           LEFT JOIN PDM.Dcmtos_HDR h ON h.HDoc_Sis_Emp = d.DDoc_Sis_Emp AND h.HDoc_Doc_Cat = d.DDoc_Doc_Cat AND h.HDoc_Doc_Ano = d.DDoc_Doc_Ano AND h.HDoc_Doc_Num = d.DDoc_Doc_Num "
            strSQL &= "              LEFT JOIN PDM.Inventarios i ON i.inv_sisemp = d.DDoc_Sis_Emp AND i.inv_numero = d.DDoc_Prd_Cod "
            strSQL &= "                 LEFT JOIN PDM.Articulos a ON a.art_sisemp = i.inv_sisemp AND a.art_codigo = i.inv_artcodigo "
            strSQL &= "                    Left JOIN contapdm.inventario_codigos ic ON ic.empresa = a.art_sisemp And ic.clase = a.art_clase "
            strSQL &= "                   WHERE d.DDoc_Sis_Emp = {empresa} AND d.DDoc_Doc_Cat = 952 AND d.DDoc_Doc_Ano = {anio} AND  d.DDoc_Doc_Num = {num} "
            strSQL &= "                GROUP BY ic.inventario"
        End If

        strSQL = Replace(strSQL, "{poliza}", poliza)
        strSQL = Replace(strSQL, "{ejercicio}", EJERCICIO)
        strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
        strSQL = Replace(strSQL, "{anio}", anio)
        strSQL = Replace(strSQL, "{num}", num)
        strSQL = Replace(strSQL, "{conta}", Sesion.BaseConta)

        Return strSQL
    End Function

    Private Function SQLDetallePolizaDeKnitting(ByVal cat As Integer, ByVal anio As Integer, ByVal num As Integer, ByVal poliza As Integer)
        Dim strSQL As String = STR_VACIO

        strSQL = " SET @numero=1;  "

        strSQL &= " INSERT INTO {conta}.detalle_polizas "
        strSQL &= "   SELECT l1.Transaccion,l1.Empresa,l1.ejercicio,l1.poliza, l1.item,'110504001',l1.parametroCuenta,ROUND(SUM(importe_),2)  Importe,l1.centroCosto,l1.partidaPresupuestal,l1.operacion,"
        strSQL &= "       l1.Fecha, l1.clase, l1.modo, l1.refTipo, l1.refCiclo, l1.refNumero,l1.id"
        strSQL &= "         FROM (  "
        strSQL &= "             SELECT 0 Transaccion,d.DDoc_Sis_Emp Empresa,{ejercicio} ejercicio,{poliza} poliza,1 item, ic.inventario cuenta,1 parametroCuenta,'' centroCosto, '' partidaPresupuestal, 'A' operacion,h.HDoc_Doc_Fec Fecha,0 clase, 29 modo, h.HDoc_Doc_Cat refTipo, h.HDoc_Doc_Ano refCiclo, h.HDoc_Doc_Num refNumero, 0 id,(d.DDoc_Prd_QTY * d.DDoc_Prd_Net * d.DDoc_RF2_Dbl) importe_ "
        strSQL &= "                 FROM Dcmtos_DTL d "
        strSQL &= "             LEFT JOIN Dcmtos_HDR h ON h.HDoc_Sis_Emp = d.DDoc_Sis_Emp AND h.HDoc_Doc_Cat = d.DDoc_Doc_Cat AND h.HDoc_Doc_Ano = d.DDoc_Doc_Ano AND h.HDoc_Doc_Num = d.DDoc_Doc_Num "
        strSQL &= "         LEFT JOIN Inventarios i ON i.inv_sisemp = d.DDoc_Sis_Emp AND i.inv_numero = d.DDoc_Prd_Cod "
        strSQL &= "       LEFT JOIN Articulos a ON a.art_sisemp = i.inv_sisemp AND a.art_codigo = i.inv_numero "
        strSQL &= "     LEFT JOIN {conta}.inventario_codigos ic ON IF(h.HDoc_DR1_Cat = 0 , ic.clase = 2306 ,IF(h.HDoc_DR1_Cat = 1 ,ic.clase = 105, IF(h.HDoc_DR1_Cat = 2, ic.clase = 107 ,  "
        strSQL &= "   IF(h.HDoc_DR1_Cat = 3 , ic.clase = 330 , IF(h.HDoc_DR1_Cat = 4 , ic.clase = 898, ic.clase = 898))))) "
        strSQL &= " WHERE d.DDoc_Sis_Emp = {empresa} AND d.DDoc_Doc_Cat = 952 AND d.DDoc_Doc_Ano = {anio} AND  d.DDoc_Doc_Num = {num}  "
        strSQL &= "ORDER  BY  d.DDoc_Sis_Emp DESC )l1  "

        strSQL &= "      UNION "

        strSQL &= "      SELECT 0,d.DDoc_Sis_Emp Empresa,{ejercicio} ejercicio,{poliza} poliza,@numero:=@numero+1 item, '110503001' cuenta,1 parametroCuenta,ROUND(((SUM(d.DDoc_Prd_NET * d.DDoc_Prd_QTY * d.DDoc_RF2_Dbl)) ), 2) importe,'' centroCosto, '' partidaPresupuestal, 'C' operacion,h.HDoc_Doc_Fec Fecha,0 clase, 29 modo, h.HDoc_Doc_Cat refTipo, h.HDoc_Doc_Ano refCiclo, h.HDoc_Doc_Num refNumero, 0 id"
        strSQL &= "         FROM Dcmtos_DTL d"
        strSQL &= "           LEFT JOIN Dcmtos_HDR h ON h.HDoc_Sis_Emp = d.DDoc_Sis_Emp AND h.HDoc_Doc_Cat = d.DDoc_Doc_Cat AND h.HDoc_Doc_Ano = d.DDoc_Doc_Ano AND h.HDoc_Doc_Num = d.DDoc_Doc_Num "
        strSQL &= "              LEFT JOIN Inventarios i ON i.inv_sisemp = d.DDoc_Sis_Emp AND i.inv_numero = d.DDoc_Prd_Cod "
        strSQL &= "                 LEFT JOIN Articulos a ON a.art_sisemp = i.inv_sisemp AND a.art_codigo = i.inv_artcodigo "
        ' strSQL &= "                    Left JOIN {conta}.inventario_codigos ic ON ic.empresa = a.art_sisemp And ic.clase = a.art_clase "
        strSQL &= "                   WHERE d.DDoc_Sis_Emp = {empresa} AND d.DDoc_Doc_Cat = 952 AND d.DDoc_Doc_Ano = {anio} AND  d.DDoc_Doc_Num = {num} "
        ' strSQL &= "                GROUP BY ic.clase"

        If Sesion.IdEmpresa = 18 Then
            strSQL &= "; SET @numero=1;  "

            strSQL &= " INSERT INTO contapdm.detalle_polizas "
            strSQL &= "   SELECT l1.Transaccion,l1.Empresa,l1.ejercicio,l1.poliza, l1.item,'110504001',l1.parametroCuenta,ROUND(SUM(importe_),2)  Importe,l1.centroCosto,l1.partidaPresupuestal,l1.operacion,"
            strSQL &= "       l1.Fecha, l1.clase, l1.modo, l1.refTipo, l1.refCiclo, l1.refNumero,l1.id"
            strSQL &= "         FROM (  "
            strSQL &= "             SELECT 0 Transaccion,d.DDoc_Sis_Emp Empresa,{ejercicio} ejercicio,{poliza} poliza,1 item, ic.inventario cuenta,1 parametroCuenta,'' centroCosto, '' partidaPresupuestal, 'A' operacion,h.HDoc_Doc_Fec Fecha,0 clase, 29 modo, h.HDoc_Doc_Cat refTipo, h.HDoc_Doc_Ano refCiclo, h.HDoc_Doc_Num refNumero, 0 id,(d.DDoc_Prd_QTY * d.DDoc_Prd_Net * d.DDoc_RF2_Dbl) importe_ "
            strSQL &= "                 FROM PDM.Dcmtos_DTL d "
            strSQL &= "             LEFT JOIN PDM.Dcmtos_HDR h ON h.HDoc_Sis_Emp = d.DDoc_Sis_Emp AND h.HDoc_Doc_Cat = d.DDoc_Doc_Cat AND h.HDoc_Doc_Ano = d.DDoc_Doc_Ano AND h.HDoc_Doc_Num = d.DDoc_Doc_Num "
            strSQL &= "         LEFT JOIN PDM.Inventarios i ON i.inv_sisemp = d.DDoc_Sis_Emp AND i.inv_numero = d.DDoc_Prd_Cod "
            strSQL &= "       LEFT JOIN PDM.Articulos a ON a.art_sisemp = i.inv_sisemp AND a.art_codigo = i.inv_numero "
            strSQL &= "     LEFT JOIN contapdm.inventario_codigos ic ON IF(h.HDoc_DR1_Cat = 0 , ic.clase = 2306 ,IF(h.HDoc_DR1_Cat = 1 ,ic.clase = 105, IF(h.HDoc_DR1_Cat = 2, ic.clase = 107 ,  "
            strSQL &= "   IF(h.HDoc_DR1_Cat = 3 , ic.clase = 330 , IF(h.HDoc_DR1_Cat = 4 , ic.clase = 898, ic.clase = 898))))) "
            strSQL &= " WHERE d.DDoc_Sis_Emp = {empresa} AND d.DDoc_Doc_Cat = 952 AND d.DDoc_Doc_Ano = {anio} AND  d.DDoc_Doc_Num = {num}  "
            strSQL &= "ORDER  BY  d.DDoc_Sis_Emp DESC )l1  "

            strSQL &= "      UNION "

            strSQL &= "      SELECT 0,d.DDoc_Sis_Emp Empresa,{ejercicio} ejercicio,{poliza} poliza,@numero:=@numero+1 item, '110503001' cuenta,1 parametroCuenta,ROUND(((SUM(d.DDoc_Prd_NET * d.DDoc_Prd_QTY * d.DDoc_RF2_Dbl)) ), 2) importe,'' centroCosto, '' partidaPresupuestal, 'C' operacion,h.HDoc_Doc_Fec Fecha,0 clase, 29 modo, h.HDoc_Doc_Cat refTipo, h.HDoc_Doc_Ano refCiclo, h.HDoc_Doc_Num refNumero, 0 id"
            strSQL &= "         FROM PDM.Dcmtos_DTL d"
            strSQL &= "           LEFT JOIN PDM.Dcmtos_HDR h ON h.HDoc_Sis_Emp = d.DDoc_Sis_Emp AND h.HDoc_Doc_Cat = d.DDoc_Doc_Cat AND h.HDoc_Doc_Ano = d.DDoc_Doc_Ano AND h.HDoc_Doc_Num = d.DDoc_Doc_Num "
            strSQL &= "              LEFT JOIN PDM.Inventarios i ON i.inv_sisemp = d.DDoc_Sis_Emp AND i.inv_numero = d.DDoc_Prd_Cod "
            strSQL &= "                 LEFT JOIN PDM.Articulos a ON a.art_sisemp = i.inv_sisemp AND a.art_codigo = i.inv_artcodigo "
            strSQL &= "                   WHERE d.DDoc_Sis_Emp = {empresa} AND d.DDoc_Doc_Cat = 952 AND d.DDoc_Doc_Ano = {anio} AND  d.DDoc_Doc_Num = {num} "
        End If

        strSQL = Replace(strSQL, "{poliza}", poliza)
        strSQL = Replace(strSQL, "{ejercicio}", EJERCICIO)
        strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
        strSQL = Replace(strSQL, "{anio}", anio)
        strSQL = Replace(strSQL, "{num}", num)
        strSQL = Replace(strSQL, "{conta}", Sesion.BaseConta)

        Return strSQL
    End Function


#End Region
#Region "Inventario Producto terminado - (Ingreso)"
    Private Function SQLEncabezadoPolizaTerminado(ByVal cat As Integer, ByVal anio As Integer, ByVal num As Integer, ByVal poliza As Integer, ByVal tipoingreso As Integer)
        Dim strSQL As String = STR_VACIO

        strSQL = " INSERT INTO {conta}.polizas"
        strSQL &= "   SELECT h.HDoc_Sis_Emp empresa, {ejercicio} ejercicio, {poliza} poliza, h.HDoc_Doc_Fec fecha, CONCAT('Para Registrar Ingreso a Bodega de producto {tipoIngresoNombre}: ', h.HDoc_Doc_Num, ' de fecha ', h.HDoc_Doc_Fec) concepto, {tipoingreso} tipo, h.HDoc_Doc_TC TC, 
'' observacion, h.HDoc_Usuario operador, 'C' estado, NOW() marca,'' grupo, {tipoingreso} modo, h.HDoc_Doc_Cat refTipo, h.HDoc_Doc_Ano refCiclo, h.HDoc_Doc_Num refNumero, NULL divisa, h.HDoc_Doc_TC Tasa,0 revisado,'' usuarioRev, NULL ultRev "
        strSQL &= "      FROM Dcmtos_HDR h "
        strSQL &= "         WHERE h.HDoc_Sis_Emp = {empresa} AND h.HDoc_Doc_Cat = {cat} AND h.HDoc_Doc_Ano = {anio} AND h.HDoc_Doc_Num = {num} "

        If Sesion.IdEmpresa = 18 Then
            strSQL &= "; INSERT INTO contapdm.polizas"
            strSQL &= "   SELECT h.HDoc_Sis_Emp empresa, {ejercicio} ejercicio, {poliza} poliza, h.HDoc_Doc_Fec fecha, CONCAT('Para Registrar Ingreso a Bodega de producto {tipoIngresoNombre}: ', h.HDoc_Doc_Num, ' de fecha ', h.HDoc_Doc_Fec) concepto, {tipoingreso} tipo, h.HDoc_Doc_TC TC, 
'' observacion, h.HDoc_Usuario operador, 'C' estado, NOW() marca,'' grupo, {tipoingreso} modo, h.HDoc_Doc_Cat refTipo, h.HDoc_Doc_Ano refCiclo, h.HDoc_Doc_Num refNumero, NULL divisa, h.HDoc_Doc_TC Tasa,0 revisado,'' usuarioRev, NULL ultRev "
            strSQL &= "      FROM PDM.Dcmtos_HDR h "
            strSQL &= "         WHERE h.HDoc_Sis_Emp = {empresa} AND h.HDoc_Doc_Cat = {cat} AND h.HDoc_Doc_Ano = {anio} AND h.HDoc_Doc_Num = {num} "

        End If
        strSQL = Replace(strSQL, "{ejercicio}", EJERCICIO)
        strSQL = Replace(strSQL, "{poliza}", poliza)
        strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
        strSQL = Replace(strSQL, "{cat}", cat)
        strSQL = Replace(strSQL, "{anio}", anio)
        strSQL = Replace(strSQL, "{num}", num)
        strSQL = Replace(strSQL, "{tipoingreso}", tipoingreso)
        If Sesion.IdEmpresa = 22 Then
            strSQL = Replace(strSQL, "{tipoingresoNombre}", " Greige ")
        Else
            If tipoingreso = 31 Then
                strSQL = Replace(strSQL, "{tipoingresoNombre}", " terminado (Desperdicio)")
            ElseIf tipoingreso = 34 Then
                strSQL = Replace(strSQL, "{tipoingresoNombre}", " terminado (Invisible)")
            ElseIf tipoingreso = 35 Then
                strSQL = Replace(strSQL, "{tipoingresoNombre}", " (en proceso)")
            Else
                strSQL = Replace(strSQL, "{tipoingresoNombre}", " terminado ")
            End If
        End If
        strSQL = Replace(strSQL, "{conta}", Sesion.BaseConta)
        Return strSQL
    End Function
    Private Function SQLDetallePolizaDeProductoTerminado(ByVal conta As String, ByVal cat As Integer, ByVal anio As Integer, ByVal num As Integer, ByVal poliza As Integer, ByVal tipopoliza As Integer)
        Dim strSQL As String = STR_VACIO

        strSQL = " SET @numero=0;  "
        strSQL &= " INSERT INTO {conta}.detalle_polizas "

        If tipopoliza = 31 Then
            strSQL &= "   SELECT l1.Transaccion,l1.Empresa,l1.ejercicio,l1.poliza, l1.item,l1.cuenta,l1.parametroCuenta,ROUND(SUM((WI)),2)  Importe,l1.centroCosto,l1.partidaPresupuestal,l1.operacion ,"
            strSQL &= "       l1.Fecha, l1.clase, l1.modo, l1.refTipo, l1.refCiclo, l1.refNumero,l1.id"
            strSQL &= "         FROM( "
            strSQL &= "             SELECT 0 Transaccion,d.DDoc_Sis_Emp Empresa,{ejercicio} ejercicio,{poliza} poliza,@numero:=@numero+1 item, ic.inventario cuenta,1 parametroCuenta,'' centroCosto, '' partidaPresupuestal, "
            strSQL &= "             'C' operacion,h.HDoc_Doc_Fec Fecha,0 clase, {tipoPoliza} modo, h.HDoc_Doc_Cat refTipo, h.HDoc_Doc_Ano refCiclo, h.HDoc_Doc_Num refNumero, 0 id,ROUND(d.DDoc_Prd_QTY  * d.DDoc_Prd_Net,5) Precio,h.HDoc_Doc_TC Tasa, IFNULL(( "
            strSQL &= "                 SELECT ROUND((g.Promedio + g.Total1 + g.Total2),2) Total "
            strSQL &= "                     FROM Gastos_Produccion g	"
            strSQL &= "                         LEFT JOIN Catalogos c ON c.cat_num = g.idMoneda AND c.cat_clase = 'Monedas' "
            strSQL &= "                             LEFT JOIN Catalogos gp ON gp.cat_num = g.Gasto AND gp.cat_clase = 'GastoP' "
            strSQL &= "                                 WHERE g.idEmpresa = {empresa} AND gp.cat_desc = 'Mano de Obra' AND g.Fecha <= h.HDoc_Doc_Fec"
            strSQL &= "                                     ORDER BY g.Fecha DESC   "
            strSQL &= "                                          LIMIT 1 ), 0) MO, IFNULL(("
            strSQL &= "                                             SELECT ROUND((g.Promedio + g.Total1 + g.Total2),2) Total "
            strSQL &= "                                         FROM Gastos_Produccion g "
            strSQL &= "                                     LEFT JOIN Catalogos c ON c.cat_num = g.idMoneda AND c.cat_clase = 'Monedas' "
            strSQL &= "                                 LEFT JOIN Catalogos gp ON gp.cat_num = g.Gasto AND gp.cat_clase = 'GastoP' "
            strSQL &= "                             WHERE g.idEmpresa = {empresa} AND gp.cat_desc = 'Gastos de fabricación' AND g.Fecha <= h.HDoc_Doc_Fec"
            strSQL &= "                         ORDER BY g.idGastoProduccion DESC   "
            strSQL &= "                     LIMIT 1 ), 0) GF, (d.DDoc_Prd_QTY * .01) WI "
            strSQL &= "                 FROM Dcmtos_DTL d "
            strSQL &= "             LEFT JOIN Dcmtos_HDR h ON h.HDoc_Sis_Emp = d.DDoc_Sis_Emp AND h.HDoc_Doc_Cat = d.DDoc_Doc_Cat AND h.HDoc_Doc_Ano = d.DDoc_Doc_Ano AND h.HDoc_Doc_Num = d.DDoc_Doc_Num "
            strSQL &= "         LEFT JOIN Inventarios i ON i.inv_sisemp = d.DDoc_Sis_Emp AND i.inv_numero = d.DDoc_Prd_Cod "
            strSQL &= "       LEFT JOIN Articulos a ON a.art_sisemp = i.inv_sisemp AND a.art_codigo = i.inv_artcodigo"
            strSQL &= "     LEFT JOIN {conta}.inventario_codigos ic ON ic.empresa = a.art_sisemp And ic.clase = a.art_clase "
            strSQL &= " WHERE d.DDoc_Sis_Emp = {empresa} AND d.DDoc_Doc_Cat = {cat} AND d.DDoc_Doc_Ano = {anio} AND  d.DDoc_Doc_Num = {num}  "
            strSQL &= ")l1   GROUP BY l1.cuenta "

            strSQL &= "      UNION "

            strSQL &= "   SELECT l1.Transaccion,l1.Empresa,l1.ejercicio,l1.poliza, l1.item,l1.cuenta,l1.parametroCuenta,ROUND(SUM((l1.Precio * l1.Tasa)- (WI)),2)  Importe,l1.centroCosto,l1.partidaPresupuestal,l1.operacion ,"
            strSQL &= "       l1.Fecha, l1.clase, l1.modo, l1.refTipo, l1.refCiclo, l1.refNumero,l1.id"
            strSQL &= "         FROM( "
            strSQL &= "             SELECT 0 Transaccion,d.DDoc_Sis_Emp Empresa,{ejercicio} ejercicio,{poliza} poliza,@numero:=@numero+1 item, ic.costo cuenta,1 parametroCuenta,'' centroCosto, '' partidaPresupuestal, "
            strSQL &= "             'C' operacion,h.HDoc_Doc_Fec Fecha,0 clase, {tipoPoliza} modo, h.HDoc_Doc_Cat refTipo, h.HDoc_Doc_Ano refCiclo, h.HDoc_Doc_Num refNumero, 0 id,ROUND(d.DDoc_Prd_QTY  * d.DDoc_Prd_Net,5) Precio,h.HDoc_Doc_TC Tasa, IFNULL(( "
            strSQL &= "                 SELECT ROUND((g.Promedio + g.Total1 + g.Total2),2) Total "
            strSQL &= "                     FROM Gastos_Produccion g	"
            strSQL &= "                         LEFT JOIN Catalogos c ON c.cat_num = g.idMoneda AND c.cat_clase = 'Monedas' "
            strSQL &= "                             LEFT JOIN Catalogos gp ON gp.cat_num = g.Gasto AND gp.cat_clase = 'GastoP' "
            strSQL &= "                                 WHERE g.idEmpresa = {empresa} AND gp.cat_desc = 'Mano de Obra' AND g.Fecha <= h.HDoc_Doc_Fec"
            strSQL &= "                                     ORDER BY g.Fecha DESC   "
            strSQL &= "                                          LIMIT 1 ), 0) MO, IFNULL(("
            strSQL &= "                                             SELECT ROUND((g.Promedio + g.Total1 + g.Total2),2) Total "
            strSQL &= "                                         FROM Gastos_Produccion g "
            strSQL &= "                                     LEFT JOIN Catalogos c ON c.cat_num = g.idMoneda AND c.cat_clase = 'Monedas' "
            strSQL &= "                                 LEFT JOIN Catalogos gp ON gp.cat_num = g.Gasto AND gp.cat_clase = 'GastoP' "
            strSQL &= "                             WHERE g.idEmpresa = {empresa} AND gp.cat_desc = 'Gastos de fabricación' AND g.Fecha <= h.HDoc_Doc_Fec"
            strSQL &= "                         ORDER BY g.idGastoProduccion DESC   "
            strSQL &= "                     LIMIT 1 ), 0) GF, (d.DDoc_Prd_QTY * .01) WI "
            strSQL &= "                 FROM Dcmtos_DTL d "
            strSQL &= "             LEFT JOIN Dcmtos_HDR h ON h.HDoc_Sis_Emp = d.DDoc_Sis_Emp AND h.HDoc_Doc_Cat = d.DDoc_Doc_Cat AND h.HDoc_Doc_Ano = d.DDoc_Doc_Ano AND h.HDoc_Doc_Num = d.DDoc_Doc_Num "
            strSQL &= "         LEFT JOIN Inventarios i ON i.inv_sisemp = d.DDoc_Sis_Emp AND i.inv_numero = d.DDoc_Prd_Cod "
            strSQL &= "       LEFT JOIN Articulos a ON a.art_sisemp = i.inv_sisemp AND a.art_codigo = i.inv_artcodigo"
            strSQL &= "     LEFT JOIN {conta}.inventario_codigos ic ON ic.empresa = a.art_sisemp And ic.clase = a.art_clase "
            strSQL &= " WHERE d.DDoc_Sis_Emp = {empresa} AND d.DDoc_Doc_Cat = {cat} AND d.DDoc_Doc_Ano = {anio} AND  d.DDoc_Doc_Num = {num}  "
            strSQL &= ")l1   GROUP BY l1.cuenta "
        ElseIf tipopoliza = 34 Then
            strSQL &= "   SELECT l1.Transaccion,l1.Empresa,l1.ejercicio,l1.poliza, l1.item,l1.cuenta,l1.parametroCuenta,ROUND(SUM((l1.Precio * l1.Tasa)),2)  Importe,l1.centroCosto,l1.partidaPresupuestal,l1.operacion ,"
            strSQL &= "       l1.Fecha, l1.clase, l1.modo, l1.refTipo, l1.refCiclo, l1.refNumero,l1.id"
            strSQL &= "         FROM( "
            strSQL &= "             SELECT 0 Transaccion,d.DDoc_Sis_Emp Empresa,{ejercicio} ejercicio,{poliza} poliza,@numero:=@numero+1 item, ic.inventario cuenta,1 parametroCuenta,'' centroCosto, '' partidaPresupuestal, "
            strSQL &= "             'C' operacion,h.HDoc_Doc_Fec Fecha,0 clase, {tipoPoliza} modo, h.HDoc_Doc_Cat refTipo, h.HDoc_Doc_Ano refCiclo, h.HDoc_Doc_Num refNumero, 0 id,ROUND(d.DDoc_Prd_QTY  * d.DDoc_Prd_Net,5) Precio,h.HDoc_Doc_TC Tasa, IFNULL(( "
            strSQL &= "                 SELECT ROUND((g.Promedio + g.Total1 + g.Total2),2) Total "
            strSQL &= "                     FROM Gastos_Produccion g	"
            strSQL &= "                         LEFT JOIN Catalogos c ON c.cat_num = g.idMoneda AND c.cat_clase = 'Monedas' "
            strSQL &= "                             LEFT JOIN Catalogos gp ON gp.cat_num = g.Gasto AND gp.cat_clase = 'GastoP' "
            strSQL &= "                                 WHERE g.idEmpresa = {empresa} AND gp.cat_desc = 'Mano de Obra' AND g.Fecha <= h.HDoc_Doc_Fec"
            strSQL &= "                                     ORDER BY g.Fecha DESC   "
            strSQL &= "                                          LIMIT 1 ), 0) MO, IFNULL(("
            strSQL &= "                                             SELECT ROUND((g.Promedio + g.Total1 + g.Total2),2) Total "
            strSQL &= "                                         FROM Gastos_Produccion g "
            strSQL &= "                                     LEFT JOIN Catalogos c ON c.cat_num = g.idMoneda AND c.cat_clase = 'Monedas' "
            strSQL &= "                                 LEFT JOIN Catalogos gp ON gp.cat_num = g.Gasto AND gp.cat_clase = 'GastoP' "
            strSQL &= "                             WHERE g.idEmpresa = {empresa} AND gp.cat_desc = 'Gastos de fabricación' AND g.Fecha <= h.HDoc_Doc_Fec"
            strSQL &= "                         ORDER BY g.idGastoProduccion DESC   "
            strSQL &= "                     LIMIT 1 ), 0) GF, (d.DDoc_Prd_QTY * .01) WI "
            strSQL &= "                 FROM Dcmtos_DTL d "
            strSQL &= "             LEFT JOIN Dcmtos_HDR h ON h.HDoc_Sis_Emp = d.DDoc_Sis_Emp AND h.HDoc_Doc_Cat = d.DDoc_Doc_Cat AND h.HDoc_Doc_Ano = d.DDoc_Doc_Ano AND h.HDoc_Doc_Num = d.DDoc_Doc_Num "
            strSQL &= "         LEFT JOIN Inventarios i ON i.inv_sisemp = d.DDoc_Sis_Emp AND i.inv_numero = d.DDoc_Prd_Cod "
            strSQL &= "       LEFT JOIN Articulos a ON a.art_sisemp = i.inv_sisemp AND a.art_codigo = i.inv_artcodigo"
            strSQL &= "     LEFT JOIN {conta}.inventario_codigos ic ON ic.empresa = a.art_sisemp And ic.clase = a.art_clase "
            strSQL &= " WHERE d.DDoc_Sis_Emp = {empresa} AND d.DDoc_Doc_Cat = {cat} AND d.DDoc_Doc_Ano = {anio} AND  d.DDoc_Doc_Num = {num}  "
            strSQL &= ")l1   GROUP BY l1.cuenta "
        Else
            strSQL &= "   SELECT l1.Transaccion,l1.Empresa,l1.ejercicio,l1.poliza, l1.item,l1.cuenta,l1.parametroCuenta,ROUND(SUM(( l1.Precio * l1.Tasa)),2)  Importe,l1.centroCosto,l1.partidaPresupuestal,l1.operacion ,"
            strSQL &= "       l1.Fecha, l1.clase, l1.modo, l1.refTipo, l1.refCiclo, l1.refNumero,l1.id"
            strSQL &= "         FROM( "
            strSQL &= "             SELECT 0 Transaccion,d.DDoc_Sis_Emp Empresa,{ejercicio} ejercicio,{poliza} poliza,@numero:=@numero+1 item, ic.inventario cuenta,1 parametroCuenta,'' centroCosto, '' partidaPresupuestal, "
            strSQL &= "             'C' operacion,h.HDoc_Doc_Fec Fecha,0 clase, {tipoPoliza} modo, h.HDoc_Doc_Cat refTipo, h.HDoc_Doc_Ano refCiclo, h.HDoc_Doc_Num refNumero, 0 id,ROUND(d.DDoc_Prd_QTY  * d.DDoc_Prd_Net,5) Precio,h.HDoc_Doc_TC Tasa, IFNULL(( "
            strSQL &= "                 SELECT ROUND((g.Promedio + g.Total1 + g.Total2),2) Total "
            strSQL &= "                     FROM Gastos_Produccion g	"
            strSQL &= "                         LEFT JOIN Catalogos c ON c.cat_num = g.idMoneda AND c.cat_clase = 'Monedas' "
            strSQL &= "                             LEFT JOIN Catalogos gp ON gp.cat_num = g.Gasto AND gp.cat_clase = 'GastoP' "
            strSQL &= "                                 WHERE g.idEmpresa = {empresa} AND gp.cat_desc = 'Mano de Obra' AND g.Fecha <= h.HDoc_Doc_Fec"
            strSQL &= "                                     ORDER BY g.Fecha DESC   "
            strSQL &= "                                          LIMIT 1 ), 0) MO, IFNULL(("
            strSQL &= "                                             SELECT ROUND((g.Promedio + g.Total1 + g.Total2),2) Total "
            strSQL &= "                                         FROM Gastos_Produccion g "
            strSQL &= "                                     LEFT JOIN Catalogos c ON c.cat_num = g.idMoneda AND c.cat_clase = 'Monedas' "
            strSQL &= "                                 LEFT JOIN Catalogos gp ON gp.cat_num = g.Gasto AND gp.cat_clase = 'GastoP' "
            strSQL &= "                             WHERE g.idEmpresa = {empresa} AND gp.cat_desc = 'Gastos de fabricación' AND g.Fecha <= h.HDoc_Doc_Fec"
            strSQL &= "                         ORDER BY g.idGastoProduccion DESC   "
            strSQL &= "                     LIMIT 1 ), 0)  GF "
            strSQL &= "                 FROM Dcmtos_DTL d "
            strSQL &= "             LEFT JOIN Dcmtos_HDR h ON h.HDoc_Sis_Emp = d.DDoc_Sis_Emp AND h.HDoc_Doc_Cat = d.DDoc_Doc_Cat AND h.HDoc_Doc_Ano = d.DDoc_Doc_Ano AND h.HDoc_Doc_Num = d.DDoc_Doc_Num "
            strSQL &= "         LEFT JOIN Inventarios i ON i.inv_sisemp = d.DDoc_Sis_Emp AND i.inv_numero = d.DDoc_Prd_Cod "
            strSQL &= "       LEFT JOIN Articulos a ON a.art_sisemp = i.inv_sisemp AND a.art_codigo = i.inv_artcodigo"
            strSQL &= "     LEFT JOIN {conta}.inventario_codigos ic ON ic.empresa = a.art_sisemp And ic.clase = a.art_clase {filtroNT} "
            strSQL &= " WHERE d.DDoc_Sis_Emp = {empresa} AND d.DDoc_Doc_Cat = {cat} AND d.DDoc_Doc_Ano = {anio} AND  d.DDoc_Doc_Num = {num}  "
            strSQL &= ")l1   GROUP BY l1.cuenta "
        End If

        strSQL &= "      UNION "

        strSQL &= "    SELECT l1.Transaccion,l1.Empresa,l1.ejercicio,l1.poliza, l1.item,l1.cuenta,l1.parametroCuenta,
                        {monto}
                        -- ROUND(SUM((l1.Precio * l1.Tasa)),2)Importe , 
                        -- ROUND(SUM(((l1.Precio-l1.MO-l1.GF) * l1.Tasa)),2) Importe, -- l1.Precio,
                        -- l1.tasa,
                        l1.centroCosto,l1.partidaPresupuestal,l1.operacion, l1.Fecha, l1.clase, l1.modo, l1.refTipo, l1.refCiclo, l1.refNumero,l1.id
                        FROM(
	                        SELECT 0 Transaccion,d.DDoc_Sis_Emp Empresa,{ejercicio} ejercicio,{poliza} poliza,@numero:=@numero+1 item, {cuenta_} cuenta,1 parametroCuenta,'' centroCosto, '' partidaPresupuestal, 
	                        'A' operacion,h.HDoc_Doc_Fec Fecha,0 clase, {tipoPoliza} modo, h.HDoc_Doc_Cat refTipo, h.HDoc_Doc_Ano refCiclo, h.HDoc_Doc_Num refNumero, 0 id, ROUND(d.DDoc_Prd_QTY * d.DDoc_Prd_Net,5) Precio, h.HDoc_Doc_TC Tasa, 
	
	                        (IFNULL((SELECT (g.Promedio + g.Total1 + g.Total2) Total FROM Gastos_Produccion g LEFT JOIN Catalogos c ON c.cat_num = g.idMoneda AND c.cat_clase = 'Monedas'
	                        LEFT JOIN Catalogos gp ON gp.cat_num = g.Gasto AND gp.cat_clase = 'GastoP' WHERE g.idEmpresa =  d.DDoc_Sis_Emp AND gp.cat_desc = 'Mano de Obra' 				AND g.Fecha <= h.HDoc_Doc_Fec 
	                        ORDER BY g.Fecha DESC LIMIT 1), 0)*d.DDoc_Prd_QTY) MO, 
	
	                        (IFNULL((SELECT (g.Promedio + g.Total1 + g.Total2) Total FROM Gastos_Produccion g LEFT JOIN Catalogos c ON c.cat_num = g.idMoneda AND c.cat_clase = 'Monedas'
	                        LEFT JOIN Catalogos gp ON gp.cat_num = g.Gasto AND gp.cat_clase = 'GastoP' WHERE g.idEmpresa = d.DDoc_Sis_Emp AND gp.cat_desc = 'Gastos de fabricación' 	AND g.Fecha <= h.HDoc_Doc_Fec 
	                        ORDER BY g.Fecha DESC LIMIT 1), 0)*d.DDoc_Prd_QTY) GF,

                            (IFNULL((SELECT (g.Promedio + g.Total1 + g.Total2) Total FROM Gastos_Produccion g LEFT JOIN Catalogos c ON c.cat_num = g.idMoneda AND c.cat_clase = 'Monedas'
	                        LEFT JOIN Catalogos gp ON gp.cat_num = g.Gasto AND gp.cat_clase = 'GastoP' WHERE g.idEmpresa = d.DDoc_Sis_Emp AND gp.cat_desc = 'Waste & invisible' 	AND g.Fecha <= h.HDoc_Doc_Fec 
	                        ORDER BY g.Fecha DESC LIMIT 1), 0)*d.DDoc_Prd_QTY) WI,

                            (IFNULL((
                            SELECT (SUM(g.Promedio + g.Total1 + g.Total2)) Total
                            FROM Gastos_Produccion g
                            LEFT JOIN Catalogos gp ON gp.cat_num = g.Gasto AND gp.cat_clase = 'GastoP'
                            WHERE g.idEmpresa = h.HDoc_Sis_Emp AND gp.cat_desc = 'Factor' AND gp.cat_pid = 1 AND g.Fecha =(
                            SELECT MAX(Fecha)
                            FROM Gastos_Produccion
                            WHERE Fecha <= h.HDoc_Doc_Fec)
                            ORDER BY g.Fecha DESC 
                            ), 0)*d.DDoc_Prd_QTY) Factor_MP
	
	                        FROM Dcmtos_DTL d
	                        LEFT JOIN Dcmtos_HDR h ON h.HDoc_Sis_Emp = d.DDoc_Sis_Emp AND h.HDoc_Doc_Cat = d.DDoc_Doc_Cat AND h.HDoc_Doc_Ano = d.DDoc_Doc_Ano AND h.HDoc_Doc_Num = d.DDoc_Doc_Num
	                        LEFT JOIN Inventarios i ON i.inv_sisemp = d.DDoc_Sis_Emp AND i.inv_numero = d.DDoc_Prd_Cod
                        LEFT JOIN Dcmtos_DTL_Pro e ON e.PDoc_Sis_Emp = d.DDoc_Sis_Emp AND e.PDoc_Chi_Cat = d.DDoc_Doc_Cat AND e.PDoc_Chi_Ano = d.DDoc_Doc_Ano AND e.PDoc_Chi_Num = d.DDoc_Doc_Num AND e.PDoc_Chi_Lin = d.DDoc_Doc_Lin AND e.PDoc_Par_Cat = 980
                        LEFT JOIN Dcmtos_DTL_Pro b ON b.PDoc_Sis_Emp = e.PDoc_Sis_Emp AND b.PDoc_Chi_Cat = e.PDoc_Par_Cat AND b.PDoc_Chi_Ano = e.PDoc_Par_Ano AND b.PDoc_Chi_Num = e.PDoc_Par_Num AND b.PDoc_Chi_Lin = e.PDoc_Par_Lin AND b.PDoc_Par_Cat = 952
                        LEFT JOIN Dcmtos_HDR h952 ON h952.HDoc_Sis_Emp = b.PDoc_Sis_Emp AND h952.HDoc_Doc_Cat = b.PDoc_Par_Cat AND h952.HDoc_Doc_Ano = b.PDoc_Par_Ano AND h952.HDoc_Doc_Num = b.PDoc_Par_Num "
        If Sesion.IdEmpresa = 22 Then
            strSQL &= " LEFT JOIN Articulos a ON a.art_sisemp = i.inv_sisemp AND a.art_codigo = i.inv_artcodigo
                        LEFT JOIN  {conta}.inventario_codigos ic ON  ic.empresa = a.art_sisemp AND ic.clase = a.art_clase AND ic.ejercicio = 1 "
            strSQL = Replace(strSQL, "{cuenta_}", " '110503001' ")
        Else
            strSQL &= " LEFT JOIN 
                        {conta}.inventario_codigos ic ON 
	                        IF(h952.HDoc_DR1_Cat = 0, ic.clase = 2306, 
		                        IF(h952.HDoc_DR1_Cat = 1,ic.clase = 105, 
			                        IF(h952.HDoc_DR1_Cat = 2, ic.clase = 107, 
				                        IF(h952.HDoc_DR1_Cat = 3, ic.clase = 330, 
					                        IF(h952.HDoc_DR1_Cat = 4, ic.clase = 898, 
						                        ic.clase = 898
					                        )
				                        )
			                        )
		                        )
	                        )"
            strSQL = Replace(strSQL, "{cuenta_}", "ic.inventario")
        End If
        strSQL &= " WHERE d.DDoc_Sis_Emp = {empresa} AND d.DDoc_Doc_Cat =  {cat} AND d.DDoc_Doc_Ano = {anio} AND d.DDoc_Doc_Num =  {num}
                        )l1 GROUP BY l1.cuenta "
        If tipopoliza = 30 Then
            If Not Sesion.IdEmpresa = 22 Then
                strSQL &= "         UNION "

                strSQL &= "              SELECT l1.Transaccion,l1.Empresa,l1.ejercicio,l1.poliza, l1.item,l1.cuenta,l1.parametroCuenta,ROUND(SUM(((l1.Cantidad * l1.MO))* l1.Tasa),2) importe,l1.centroCosto,l1.partidaPresupuestal,l1.operacion, "
                strSQL &= "                 l1.Fecha, l1.clase, l1.modo, l1.refTipo, l1.refCiclo, l1.refNumero, l1.id "
                strSQL &= "                     FROM ( "
                strSQL &= "                         SELECT 0 Transaccion,d.DDoc_Sis_Emp Empresa,{ejercicio} ejercicio,{poliza} poliza,@numero:=@numero+1 item, '510201099' cuenta,1 parametroCuenta,'' centroCosto, '' partidaPresupuestal, 'A' operacion,h.HDoc_Doc_Fec Fecha,0 clase, {tipoPoliza} modo, h.HDoc_Doc_Cat refTipo, h.HDoc_Doc_Ano refCiclo, h.HDoc_Doc_Num refNumero, 0 id,d.DDoc_Prd_QTY Cantidad,h.HDoc_Doc_TC Tasa,IFNULL(( "
                strSQL &= "                             SELECT (g.Promedio + g.Total1 + g.Total2) Total "
                strSQL &= "                                 FROM Gastos_Produccion g "
                strSQL &= "                                     LEFT JOIN Catalogos c ON c.cat_num = g.idMoneda AND c.cat_clase = 'Monedas' "
                strSQL &= "                                         LEFT JOIN Catalogos gp ON gp.cat_num = g.Gasto AND gp.cat_clase = 'GastoP' "
                strSQL &= "                                             WHERE g.idEmpresa = {empresa} AND gp.cat_desc = 'Mano de Obra' AND g.Fecha <= h.HDoc_Doc_Fec"
                strSQL &= "                                                 ORDER BY g.Fecha DESC   "
                strSQL &= "                                                     LIMIT 1 ), 0) MO "
                strSQL &= "                                                 FROM Dcmtos_DTL d "
                strSQL &= "                                             LEFT JOIN Dcmtos_HDR h ON h.HDoc_Sis_Emp = d.DDoc_Sis_Emp AND h.HDoc_Doc_Cat = d.DDoc_Doc_Cat AND h.HDoc_Doc_Ano = d.DDoc_Doc_Ano AND h.HDoc_Doc_Num = d.DDoc_Doc_Num  "
                strSQL &= "                                         WHERE d.DDoc_Sis_Emp = {empresa} AND d.DDoc_Doc_Cat = {cat} AND d.DDoc_Doc_Ano = {anio} AND d.DDoc_Doc_Num = {num} )l1"

                strSQL &= "                     UNION "

                strSQL &= "                         SELECT l1.Transaccion,l1.Empresa,l1.ejercicio,l1.poliza, l1.item,l1.cuenta,l1.parametroCuenta,ROUND(SUM(((l1.Cantidad * l1.MO))* l1.Tasa),2) importe,l1.centroCosto,l1.partidaPresupuestal,l1.operacion, "
                strSQL &= "                             l1.Fecha, l1.clase, l1.modo, l1.refTipo, l1.refCiclo, l1.refNumero, l1.id "
                strSQL &= "                                 FROM ( "
                strSQL &= "                                     SELECT 0 Transaccion,d.DDoc_Sis_Emp Empresa,{ejercicio} ejercicio,{poliza} poliza,@numero:=@numero+1 item, '510202099' cuenta,1 parametroCuenta,'' centroCosto, '' partidaPresupuestal, 'A' operacion,h.HDoc_Doc_Fec Fecha,0 clase, {tipoPoliza} modo, h.HDoc_Doc_Cat refTipo, h.HDoc_Doc_Ano refCiclo, h.HDoc_Doc_Num refNumero, 0 id,d.DDoc_Prd_QTY Cantidad,h.HDoc_Doc_TC Tasa, IFNULL(( "
                strSQL &= "                                         SELECT (g.Promedio + g.Total1 + g.Total2) Total "
                strSQL &= "                                             FROM Gastos_Produccion g "
                strSQL &= "                                                 LEFT JOIN Catalogos c ON c.cat_num = g.idMoneda AND c.cat_clase = 'Monedas' "
                strSQL &= "                                                     LEFT JOIN Catalogos gp ON gp.cat_num = g.Gasto AND gp.cat_clase = 'GastoP' "
                strSQL &= "                                                 WHERE g.idEmpresa = {empresa} AND gp.cat_desc = 'Gastos de fabricación' AND g.Fecha <= h.HDoc_Doc_Fec"
                strSQL &= "                                             ORDER BY g.Fecha DESC   "
                strSQL &= "                                         LIMIT 1 ), 0) MO "
                strSQL &= "                                     FROM Dcmtos_DTL d "
                strSQL &= "                                 LEFT JOIN Dcmtos_HDR h ON h.HDoc_Sis_Emp = d.DDoc_Sis_Emp AND h.HDoc_Doc_Cat = d.DDoc_Doc_Cat AND h.HDoc_Doc_Ano = d.DDoc_Doc_Ano AND h.HDoc_Doc_Num = d.DDoc_Doc_Num  "
                strSQL &= "                             WHERE d.DDoc_Sis_Emp = {empresa} AND d.DDoc_Doc_Cat = {cat} AND d.DDoc_Doc_Ano = {anio} AND d.DDoc_Doc_Num = {num} )l1 "

                strSQL &= "                     UNION "

                strSQL &= "                         SELECT l1.Transaccion,l1.Empresa,l1.ejercicio,l1.poliza, l1.item,l1.cuenta,l1.parametroCuenta,ROUND(SUM(((l1.Cantidad * l1.MO))* l1.Tasa),2) importe,l1.centroCosto,l1.partidaPresupuestal,l1.operacion, "
                strSQL &= "                             l1.Fecha, l1.clase, l1.modo, l1.refTipo, l1.refCiclo, l1.refNumero, l1.id "
                strSQL &= "                                 FROM ( "
                strSQL &= "                                     SELECT 0 Transaccion,d.DDoc_Sis_Emp Empresa,{ejercicio} ejercicio,{poliza} poliza,@numero:=@numero+1 item, '{ctaPT}' cuenta,1 parametroCuenta,'' centroCosto, '' partidaPresupuestal, 'A' operacion,h.HDoc_Doc_Fec Fecha,0 clase, {tipoPoliza} modo, h.HDoc_Doc_Cat refTipo, h.HDoc_Doc_Ano refCiclo, h.HDoc_Doc_Num refNumero, 0 id,d.DDoc_Prd_QTY Cantidad,h.HDoc_Doc_TC Tasa, IFNULL(( "
                strSQL &= "                                         SELECT (g.Promedio + g.Total1 + g.Total2) Total "
                strSQL &= "                                             FROM Gastos_Produccion g "
                strSQL &= "                                                 LEFT JOIN Catalogos c ON c.cat_num = g.idMoneda AND c.cat_clase = 'Monedas' "
                strSQL &= "                                                     LEFT JOIN Catalogos gp ON gp.cat_num = g.Gasto AND gp.cat_clase = 'GastoP' "
                strSQL &= "                                                 WHERE g.idEmpresa = {empresa} AND gp.cat_desc = 'Waste & invisible' AND g.Fecha <= h.HDoc_Doc_Fec"
                strSQL &= "                                             ORDER BY g.Fecha DESC   "
                strSQL &= "                                         LIMIT 1 ), 0) MO "
                strSQL &= "                                     FROM Dcmtos_DTL d "
                strSQL &= "                                 LEFT JOIN Dcmtos_HDR h ON h.HDoc_Sis_Emp = d.DDoc_Sis_Emp AND h.HDoc_Doc_Cat = d.DDoc_Doc_Cat AND h.HDoc_Doc_Ano = d.DDoc_Doc_Ano AND h.HDoc_Doc_Num = d.DDoc_Doc_Num  "
                strSQL &= "                             WHERE d.DDoc_Sis_Emp = {empresa} AND d.DDoc_Doc_Cat = {cat} AND d.DDoc_Doc_Ano = {anio} AND d.DDoc_Doc_Num = {num} )l1 "

                strSQL &= "                     UNION "

                strSQL &= "                     SELECT l1.Transaccion,l1.Empresa,l1.ejercicio,l1.poliza, l1.item,l1.cuenta,l1.parametroCuenta, (ROUND((((l1.Cantidad * l1.MO))* l1.Tasa),2)) importe,l1.centroCosto,l1.partidaPresupuestal,l1.operacion, l1.Fecha, l1.clase, l1.modo, l1.refTipo, l1.refCiclo, l1.refNumero, l1.id
                                                FROM (
                                                SELECT 0 Transaccion,d.DDoc_Sis_Emp Empresa,{ejercicio} ejercicio,{poliza} poliza,@numero:=@numero+1 item,gp.cat_dato cuenta,1 parametroCuenta,'' centroCosto, '' partidaPresupuestal, 'A' operacion,h.HDoc_Doc_Fec Fecha,0 clase, 30 modo, h.HDoc_Doc_Cat refTipo, h.HDoc_Doc_Ano refCiclo, h.HDoc_Doc_Num refNumero, 0 id,d.DDoc_Prd_QTY Cantidad,h.HDoc_Doc_TC Tasa, (g.Promedio + g.Total1 + g.Total2) MO, g.Fecha FechaG
                                                FROM Dcmtos_DTL d
                                                LEFT JOIN Dcmtos_HDR h ON h.HDoc_Sis_Emp = d.DDoc_Sis_Emp AND h.HDoc_Doc_Cat = d.DDoc_Doc_Cat AND h.HDoc_Doc_Ano = d.DDoc_Doc_Ano AND h.HDoc_Doc_Num = d.DDoc_Doc_Num
                                                LEFT JOIN (
                                                        SELECT idEmpresa, Anio, idGastoProduccion, Linea, Fecha, Tasa, Gasto, Promedio, Total1, Total2, idMoneda
                                                        FROM Gastos_Produccion
                                                        WHERE (idEmpresa, Anio, idGastoProduccion) IN (
                                                            SELECT  idEmpresa, Anio, max(idGastoProduccion) idGastoProduccion
                                                            FROM Gastos_Produccion
                                                            GROUP BY idEmpresa, Anio
				                                                ORDER BY idEmpresa desc, Anio desc, idGastoProduccion desc
                                                        ) 
                                                    ) g ON g.idEmpresa = h.HDoc_Sis_Emp
                                                        AND g.Fecha <=  h.HDoc_Doc_Fec
                                                LEFT JOIN Catalogos c ON c.cat_num = g.idMoneda AND c.cat_clase = 'Monedas'
                                                LEFT JOIN Catalogos gp ON gp.cat_num = g.Gasto AND gp.cat_clase = 'GastoP' AND gp.cat_pid = 1
                                            WHERE d.DDoc_Sis_Emp = {empresa} AND d.DDoc_Doc_Cat = {cat} AND d.DDoc_Doc_Ano = {anio} AND d.DDoc_Doc_Num = {num} AND gp.cat_desc = 'Factor' ORDER by FechaG Desc)l1 GROUP BY l1.cuenta "               ' strSQL &= "                             WHERE d.DDoc_Sis_Emp = {empresa} AND d.DDoc_Doc_Cat = {cat} AND d.DDoc_Doc_Ano = {anio} AND d.DDoc_Doc_Num = {num} )l1 "


            Else
                strSQL &= "                     UNION "

                strSQL &= "                     SELECT l1.Transaccion,l1.Empresa,l1.ejercicio,l1.poliza, l1.item,l1.cuenta,l1.parametroCuenta, (ROUND((((l1.Cantidad * l1.MO))* l1.Tasa),2)) importe,l1.centroCosto,l1.partidaPresupuestal,l1.operacion, l1.Fecha, l1.clase, l1.modo, l1.refTipo, l1.refCiclo, l1.refNumero, l1.id
                                                FROM (
                                                SELECT 0 Transaccion,d.DDoc_Sis_Emp Empresa,{ejercicio} ejercicio,{poliza} poliza,@numero:=@numero+1 item,gp.cat_dato cuenta,1 parametroCuenta,'' centroCosto, '' partidaPresupuestal, 'A' operacion,h.HDoc_Doc_Fec Fecha,0 clase, 30 modo, h.HDoc_Doc_Cat refTipo, h.HDoc_Doc_Ano refCiclo, h.HDoc_Doc_Num refNumero, 0 id,d.DDoc_Prd_QTY Cantidad,h.HDoc_Doc_TC Tasa, (g.Promedio + g.Total1 + g.Total2) MO
                                                FROM Dcmtos_DTL d
                                                LEFT JOIN Dcmtos_HDR h ON h.HDoc_Sis_Emp = d.DDoc_Sis_Emp AND h.HDoc_Doc_Cat = d.DDoc_Doc_Cat AND h.HDoc_Doc_Ano = d.DDoc_Doc_Ano AND h.HDoc_Doc_Num = d.DDoc_Doc_Num
                                                LEFT JOIN (
                                                        SELECT idEmpresa, Anio, idGastoProduccion, Linea, Fecha, Tasa, Gasto, Promedio, Total1, Total2, idMoneda
                                                        FROM Gastos_Produccion
                                                        WHERE Estado = 1
                                                    ) g ON g.idEmpresa = h.HDoc_Sis_Emp
                                                        AND g.Fecha <=  h.HDoc_Doc_Fec
                                                LEFT JOIN Catalogos c ON c.cat_num = g.idMoneda AND c.cat_clase = 'Monedas'
                                                LEFT JOIN Catalogos gp ON gp.cat_num = g.Gasto AND gp.cat_clase = 'GastoP' AND gp.cat_pid = 1
                                            WHERE d.DDoc_Sis_Emp = {empresa} AND d.DDoc_Doc_Cat = {cat} AND d.DDoc_Doc_Ano = {anio} AND d.DDoc_Doc_Num = {num} AND gp.cat_desc = 'Factor')l1 GROUP BY l1.cuenta "               ' strSQL &= "                             WHERE d.DDoc_Sis_Emp = {empresa} AND d.DDoc_Doc_Cat = {cat} AND d.DDoc_Doc_Ano = {anio} AND d.DDoc_Doc_Num = {num} )l1 "
            End If
        End If

        strSQL = Replace(strSQL, "{poliza}", poliza)
        strSQL = Replace(strSQL, "{ejercicio}", EJERCICIO)
        strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
        strSQL = Replace(strSQL, "{cat}", cat)
        strSQL = Replace(strSQL, "{anio}", anio)
        strSQL = Replace(strSQL, "{num}", num)
        strSQL = Replace(strSQL, "{tipoPoliza}", tipopoliza)
        strSQL = Replace(strSQL, "{conta}", conta)
        If Sesion.IdEmpresa = 15 Or Sesion.idGiro = 20 Then
            strSQL = Replace(strSQL, "{ctaPT}", "510103097")
        Else
            strSQL = Replace(strSQL, "{ctaPT}", "510103099")
        End If
        If tipopoliza = 30 Then ' Producto Terminado
            strSQL = Replace(strSQL, "{monto}", " ROUND(SUM(((l1.Precio-l1.MO-l1.GF-l1.WI-Factor_MP) * l1.Tasa)),2) Importe, ")
        Else
            strSQL = Replace(strSQL, "{monto}", "ROUND(SUM((l1.Precio * l1.Tasa)),2)Importe,")
        End If
        If Sesion.IdEmpresa = 22 Then
            strSQL = Replace(strSQL, "{filtroNT}", " AND ic.ejercicio = 1")
        Else
            strSQL = Replace(strSQL, "{filtroNT}", " ")
        End If
        strSQL &= ";"
        Return strSQL
    End Function
    Private Sub PolizaInventarioTerminado(ByVal cat As Integer, ByVal anio As Integer, ByVal num As Integer, ByVal tipoingreso As Integer)

        Dim longPolizas As Long = NO_FILA
        Dim COM As MySqlCommand
        Dim strSQL As String = STR_VACIO

        Try
            longPolizas = NuevaPoliza()
            UltimaPoliza(longPolizas, EJERCICIO) ' actualiza la ultima poliza

            strSQL = SQLEncabezadoPolizaTerminado(cat, anio, num, longPolizas, tipoingreso)
            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSQL, CON)
            COM.ExecuteNonQuery()

            strSQL = STR_VACIO

            strSQL = SQLDetallePolizaDeProductoTerminado(Sesion.BaseConta, cat, anio, num, longPolizas, tipoingreso)
            If Sesion.IdEmpresa = 18 Then
                strSQL &= SQLDetallePolizaDeProductoTerminado("contapdm", cat, anio, num, longPolizas, tipoingreso)
            End If
            MyCnn.CONECTAR = strConexion & ";Allow User Variables=True"
            COM = New MySqlCommand(strSQL, CON)
            COM.ExecuteNonQuery()
            strSQL = STR_VACIO

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub
#End Region
#Region " Inventario Consumibles"
    Private Sub PolizaDeConsumibles(ByVal cat As Integer, ByVal anio As Integer, ByVal num As Integer, ByVal fec As Date)
        ' Verifica si es Factura Extemporanea
        Dim strsql As String = STR_VACIO
        Dim COM As MySqlCommand
        'Dim REA As MySqlDataReader
        Dim extemporaneo As Integer = NO_FILA
        Dim intIVA As Integer = NO_FILA
        Dim intTipoFact As Integer = NO_FILA
        'Dim dtFecha As String
        Dim strFecha As String = STR_VACIO
        ' Dim intStatus As Integer
        Dim longPolizas As Long = NO_FILA
        Dim intCaja As Integer = 0
        Try
            longPolizas = NuevaPoliza() ' verifica el ultimo numero de poliza
            UltimaPoliza(longPolizas, EJERCICIO) ' actualiza la ultima poliza

            'ENCABEZADO DE POLIZA
            strsql = SQLEncabezadoConsumible()
            strsql = Replace(strsql, "{ejercicio}", EJERCICIO)
            strsql = Replace(strsql, "{poliza}", longPolizas)
            strsql = Replace(strsql, "{empresa}", Sesion.IdEmpresa)
            strsql = Replace(strsql, "{anio}", anio)
            strsql = Replace(strsql, "{cat}", cat)
            strsql = Replace(strsql, "{num}", num)
            strsql = Replace(strsql, "{conta}", Sesion.BaseConta)
            strsql = Replace(strsql, "{usuario}", Sesion.Usuario)
            strsql = Replace(strsql, "{fecha}", fec.ToString(FORMATO_MYSQL))
            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strsql, CON)
            COM.ExecuteNonQuery()
            strsql = STR_VACIO

            ' DETALLE DE POLIZA
            strsql = SQLDetalleConsumibles()
            strsql = Replace(strsql, "{ejercicio}", EJERCICIO)
            strsql = Replace(strsql, "{poliza}", longPolizas)
            strsql = Replace(strsql, "{empresa}", Sesion.IdEmpresa)
            strsql = Replace(strsql, "{anio}", anio)
            strsql = Replace(strsql, "{numero}", num)
            strsql = Replace(strsql, "{cat}", cat)
            strsql = Replace(strsql, "{conta}", Sesion.BaseConta)
            If Year(fec.ToString(FORMATO_MYSQL)) <> Year(Now) Then
                If Month(fec.ToString(FORMATO_MYSQL)) = 12 Then
                    strsql = Replace(strsql, "{fecha}", fec.ToString(FORMATO_MYSQL))
                Else
                    strsql = Replace(strsql, "{fecha}", fec.ToString(FORMATO_MYSQL))
                End If

            End If
            MyCnn.CONECTAR = strConexion & ";Allow User Variables=True"
            COM = New MySqlCommand(strsql, CON)
            COM.ExecuteNonQuery()
            strsql = STR_VACIO

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try

    End Sub
    Private Function SQLEncabezadoConsumible()
        Dim strSQL As String = STR_VACIO

        strSQL = " INSERT INTO {conta}.polizas"
        strSQL &= "   SELECT h.HDoc_Sis_Emp empresa, {ejercicio} ejercicio, {poliza} poliza, '{fecha}', CONCAT('Poliza de Inventario, Consumibles: ', h.HDoc_DR1_Num, ' ', h.HDoc_DR2_Num, ' de fecha ', h.HDoc_Doc_Fec) concepto, 32 tipo, h.HDoc_Doc_TC TC, '' observacion, '{usuario}' operador, 'C' estado, NOW() marca,'' grupo, 32 modo, h.HDoc_Doc_Cat refTipo, h.HDoc_Doc_Ano refCiclo, h.HDoc_Doc_Num refNumero, NULL divisa, h.HDoc_Doc_TC Tasa,0 revisado,'' usuarioRev, NULL ultRev "
        strSQL &= "      FROM Dcmtos_HDR h "
        strSQL &= "         WHERE h.HDoc_Sis_Emp = {empresa} AND h.HDoc_Doc_Cat = {cat} AND h.HDoc_Doc_Ano = {anio} AND h.HDoc_Doc_Num = {num} "

        If Sesion.IdEmpresa = 18 Then
            strSQL &= "; INSERT INTO contapdm.polizas"
            strSQL &= "   SELECT h.HDoc_Sis_Emp empresa, {ejercicio} ejercicio, {poliza} poliza, '{fecha}', CONCAT('Poliza de Inventario, Consumibles: ', h.HDoc_DR1_Num, ' ', h.HDoc_DR2_Num, ' de fecha ', h.HDoc_Doc_Fec) concepto, 32 tipo, h.HDoc_Doc_TC TC, '' observacion, '{usuario}' operador, 'C' estado, NOW() marca,'' grupo, 32 modo, h.HDoc_Doc_Cat refTipo, h.HDoc_Doc_Ano refCiclo, h.HDoc_Doc_Num refNumero, NULL divisa, h.HDoc_Doc_TC Tasa,0 revisado,'' usuarioRev, NULL ultRev "
            strSQL &= "      FROM PDM.Dcmtos_HDR h "
            strSQL &= "         WHERE h.HDoc_Sis_Emp = {empresa} AND h.HDoc_Doc_Cat = {cat} AND h.HDoc_Doc_Ano = {anio} AND h.HDoc_Doc_Num = {num} "
        End If

        Return strSQL
    End Function
    Private Function SQLDetalleConsumibles()
        Dim strSQL As String = STR_VACIO
        Dim item As Integer = 0
        ' IntIVA: 1 Retiene IVA, 0 no Retiene IVA
        ' 0 no extemporanea - 1 Extemporanea
        Try
            strSQL = " SET @numero=1; "
            strSQL &= " INSERT INTO {conta}.detalle_polizas "
            strSQL &= "     SELECT 0,'{empresa}',{ejercicio},{poliza},1 item, ic.inventario cuenta, 1 parametro_cuenta,ROUND(SUM(((IF(d.DDoc_RF3_Dbl = 0, d.DDoc_Prd_NET,d.DDoc_RF3_Dbl) * d.DDoc_Prd_QTY)* h.HDoc_Doc_TC) - ( "
            strSQL &= "         SELECT IFNULL(SUM(p.MDoc_Lin_Monto),0) impuesto "
            strSQL &= "             FROM Dcmtos_IMP p "
            strSQL &= "                 WHERE p.MDoc_Sis_Emp = d.DDoc_Sis_Emp AND p.MDoc_Doc_Cat = d.DDoc_Doc_Cat AND p.MDoc_Doc_Ano = d.DDoc_Doc_Ano AND p.MDoc_Doc_Num = d.DDoc_Doc_Num AND p.MDoc_Lin_Codigo = 'IMP_DC')),2) importe, d.DDoc_RF3_Num centro_Costo, NULL partida_Presupuestal, 'C' operacion, h.HDoc_Doc_Fec, 0 clase, 32 modo, h.HDoc_Doc_Cat tipo, h.HDoc_Doc_Ano cilco, h.HDoc_Doc_Num num,0 id "
            strSQL &= "                     FROM Dcmtos_HDR h "
            strSQL &= "                         LEFT JOIN Dcmtos_DTL_Pro e ON e.PDoc_Sis_Emp = h.HDoc_Sis_Emp AND e.PDoc_Chi_Cat = h.HDoc_Doc_Cat AND e.PDoc_Chi_Ano = h.HDoc_Doc_Ano AND e.PDoc_Chi_Num = h.HDoc_Doc_Num AND e.PDoc_Par_Cat = 44 "
            strSQL &= "                             LEFT JOIN Dcmtos_DTL d ON d.DDoc_Sis_Emp = e.PDoc_Sis_Emp AND d.DDoc_Doc_Cat = e.PDoc_Par_Cat AND d.DDoc_Doc_Ano= e.PDoc_Par_Ano AND d.DDoc_Doc_Num = e.PDoc_Par_Num AND d.DDoc_Doc_Lin = e.PDoc_Par_Lin "
            strSQL &= "                                 LEFT JOIN Inventarios i ON i.inv_sisemp = d.DDoc_Sis_Emp AND i.inv_numero = d.DDoc_Prd_Cod "
            strSQL &= "                                     LEFT JOIN Articulos a ON a.art_sisemp = i.inv_sisemp AND a.art_codigo = i.inv_artcodigo "
            strSQL &= "                                 LEFT JOIN {conta}.inventario_codigos ic ON ic.clase = a.art_clase AND ic.ejercicio = 1 "
            strSQL &= "                             WHERE h.HDoc_Sis_Emp = {empresa} AND h.HDoc_Doc_Cat = {cat} AND h.HDoc_Doc_Ano = {anio} AND h.HDoc_Doc_Num = {numero} "
            strSQL &= "                         GROUP BY a.art_clase "

            strSQL &= "     UNION  "
            strSQL &= "         SELECT 0,'{empresa}',{ejercicio},{poliza},@numero:=@numero+1 item, d.DDoc_RF1_Txt cuenta, 1 parametro_cuenta,ROUND(SUM(((d.DDoc_Prd_NET - d.DDoc_RF3_Dbl) * d.DDoc_Prd_QTY)* h.HDoc_Doc_TC),2) importe, '' centro_Costo, NULL "
            strSQL &= "             partida_Presupuestal, 'C' operacion, h.HDoc_Doc_Fec, 0 clase, 32 modo, h.HDoc_Doc_Cat tipo, h.HDoc_Doc_Ano cilco, h.HDoc_Doc_Num num,0 id "
            strSQL &= "                 FROM Dcmtos_HDR h "
            strSQL &= "                     LEFT JOIN Dcmtos_DTL_Pro e ON e.PDoc_Sis_Emp = h.HDoc_Sis_Emp AND e.PDoc_Chi_Cat = h.HDoc_Doc_Cat AND e.PDoc_Chi_Ano = h.HDoc_Doc_Ano AND e.PDoc_Chi_Num = h.HDoc_Doc_Num AND e.PDoc_Par_Cat = 44 "
            strSQL &= "                         LEFT JOIN Dcmtos_DTL d ON d.DDoc_Sis_Emp = e.PDoc_Sis_Emp AND d.DDoc_Doc_Cat = e.PDoc_Par_Cat AND d.DDoc_Doc_Ano= e.PDoc_Par_Ano AND d.DDoc_Doc_Num = e.PDoc_Par_Num AND d.DDoc_Doc_Lin = e.PDoc_Par_Lin "
            strSQL &= "                             WHERE h.HDoc_Sis_Emp = {empresa} AND h.HDoc_Doc_Cat = {cat} AND h.HDoc_Doc_Ano = {anio} AND h.HDoc_Doc_Num = {numero} AND LENGTH(d.DDoc_RF1_Txt)>0 "
            strSQL &= "                                 GROUP BY d.DDoc_RF1_Txt  "
            strSQL &= "         UNION "

            strSQL &= "             SELECT 0,'{empresa}',{ejercicio},{poliza},@numero:=@numero+1 item, p.pro_cuenta cuenta, 1 parametro_cuenta, SUM((d.DDoc_Prd_NET * d.DDoc_Prd_QTY)* h.HDoc_Doc_TC) importe, '' centro_Costo, NULL partida_Presupuestal, 'A' operacion, h.HDoc_Doc_Fec, 0 clase,32 modo, h.HDoc_Doc_Cat tipo, h.HDoc_Doc_Ano cilco, h.HDoc_Doc_Num num,0 id "
            strSQL &= "                 FROM Dcmtos_HDR h "
            strSQL &= "                     LEFT JOIN Dcmtos_DTL_Pro e ON e.PDoc_Sis_Emp = h.HDoc_Sis_Emp AND e.PDoc_Chi_Cat = h.HDoc_Doc_Cat AND e.PDoc_Chi_Ano = h.HDoc_Doc_Ano AND e.PDoc_Chi_Num = h.HDoc_Doc_Num AND e.PDoc_Par_Cat = 44 "
            strSQL &= "                         LEFT JOIN Dcmtos_DTL d ON d.DDoc_Sis_Emp = e.PDoc_Sis_Emp AND d.DDoc_Doc_Cat = e.PDoc_Par_Cat AND d.DDoc_Doc_Ano= e.PDoc_Par_Ano AND d.DDoc_Doc_Num = e.PDoc_Par_Num AND d.DDoc_Doc_Lin = e.PDoc_Par_Lin "
            strSQL &= "                             LEFT JOIN Proveedores p ON p.pro_sisemp = h.HDoc_Sis_Emp AND p.pro_codigo = h.HDoc_Emp_Cod "
            strSQL &= "                                 WHERE h.HDoc_Sis_Emp = {empresa} AND h.HDoc_Doc_Cat = {cat} AND h.HDoc_Doc_Ano = {anio} AND h.HDoc_Doc_Num = {numero} "

            If Sesion.IdEmpresa = 18 Then
                strSQL &= "; SET @numero=1; "
                strSQL &= " INSERT INTO contapdm.detalle_polizas "
                strSQL &= "     SELECT 0,'{empresa}',{ejercicio},{poliza},1 item, ic.inventario cuenta, 1 parametro_cuenta,ROUND(SUM(((IF(d.DDoc_RF3_Dbl = 0, d.DDoc_Prd_NET,d.DDoc_RF3_Dbl) * d.DDoc_Prd_QTY)* h.HDoc_Doc_TC) - ( "
                strSQL &= "         SELECT IFNULL(SUM(p.MDoc_Lin_Monto),0) impuesto "
                strSQL &= "             FROM PDM.Dcmtos_IMP p "
                strSQL &= "                 WHERE p.MDoc_Sis_Emp = d.DDoc_Sis_Emp AND p.MDoc_Doc_Cat = d.DDoc_Doc_Cat AND p.MDoc_Doc_Ano = d.DDoc_Doc_Ano AND p.MDoc_Doc_Num = d.DDoc_Doc_Num AND p.MDoc_Lin_Codigo = 'IMP_DC')),2) importe, d.DDoc_RF3_Num centro_Costo, NULL partida_Presupuestal, 'C' operacion, h.HDoc_Doc_Fec, 0 clase, 32 modo, h.HDoc_Doc_Cat tipo, h.HDoc_Doc_Ano cilco, h.HDoc_Doc_Num num,0 id "
                strSQL &= "                     FROM PDM.Dcmtos_HDR h "
                strSQL &= "                         LEFT JOIN PDM.Dcmtos_DTL_Pro e ON e.PDoc_Sis_Emp = h.HDoc_Sis_Emp AND e.PDoc_Chi_Cat = h.HDoc_Doc_Cat AND e.PDoc_Chi_Ano = h.HDoc_Doc_Ano AND e.PDoc_Chi_Num = h.HDoc_Doc_Num AND e.PDoc_Par_Cat = 44 "
                strSQL &= "                             LEFT JOIN PDM.Dcmtos_DTL d ON d.DDoc_Sis_Emp = e.PDoc_Sis_Emp AND d.DDoc_Doc_Cat = e.PDoc_Par_Cat AND d.DDoc_Doc_Ano= e.PDoc_Par_Ano AND d.DDoc_Doc_Num = e.PDoc_Par_Num AND d.DDoc_Doc_Lin = e.PDoc_Par_Lin "
                strSQL &= "                                 LEFT JOIN PDM.Inventarios i ON i.inv_sisemp = d.DDoc_Sis_Emp AND i.inv_numero = d.DDoc_Prd_Cod "
                strSQL &= "                                     LEFT JOIN PDM.Articulos a ON a.art_sisemp = i.inv_sisemp AND a.art_codigo = i.inv_artcodigo "
                strSQL &= "                                 LEFT JOIN contapdm.inventario_codigos ic ON ic.clase = a.art_clase AND ic.ejercicio = 1 "
                strSQL &= "                             WHERE h.HDoc_Sis_Emp = {empresa} AND h.HDoc_Doc_Cat = {cat} AND h.HDoc_Doc_Ano = {anio} AND h.HDoc_Doc_Num = {numero} "
                strSQL &= "                         GROUP BY a.art_clase "

                strSQL &= "     UNION  "
                strSQL &= "         SELECT 0,'{empresa}',{ejercicio},{poliza},@numero:=@numero+1 item, d.DDoc_RF1_Txt cuenta, 1 parametro_cuenta,ROUND(SUM(((d.DDoc_Prd_NET - d.DDoc_RF3_Dbl) * d.DDoc_Prd_QTY)* h.HDoc_Doc_TC),2) importe, '' centro_Costo, NULL "
                strSQL &= "             partida_Presupuestal, 'C' operacion, h.HDoc_Doc_Fec, 0 clase, 32 modo, h.HDoc_Doc_Cat tipo, h.HDoc_Doc_Ano cilco, h.HDoc_Doc_Num num,0 id "
                strSQL &= "                 FROM PDM.Dcmtos_HDR h "
                strSQL &= "                     LEFT JOIN PDM.Dcmtos_DTL_Pro e ON e.PDoc_Sis_Emp = h.HDoc_Sis_Emp AND e.PDoc_Chi_Cat = h.HDoc_Doc_Cat AND e.PDoc_Chi_Ano = h.HDoc_Doc_Ano AND e.PDoc_Chi_Num = h.HDoc_Doc_Num AND e.PDoc_Par_Cat = 44 "
                strSQL &= "                         LEFT JOIN PDM.Dcmtos_DTL d ON d.DDoc_Sis_Emp = e.PDoc_Sis_Emp AND d.DDoc_Doc_Cat = e.PDoc_Par_Cat AND d.DDoc_Doc_Ano= e.PDoc_Par_Ano AND d.DDoc_Doc_Num = e.PDoc_Par_Num AND d.DDoc_Doc_Lin = e.PDoc_Par_Lin "
                strSQL &= "                             WHERE h.HDoc_Sis_Emp = {empresa} AND h.HDoc_Doc_Cat = {cat} AND h.HDoc_Doc_Ano = {anio} AND h.HDoc_Doc_Num = {numero} AND LENGTH(d.DDoc_RF1_Txt)>0 "
                strSQL &= "                                 GROUP BY d.DDoc_RF1_Txt  "
                strSQL &= "         UNION "

                strSQL &= "             SELECT 0,'{empresa}',{ejercicio},{poliza},@numero:=@numero+1 item, p.pro_cuenta cuenta, 1 parametro_cuenta, SUM((d.DDoc_Prd_NET * d.DDoc_Prd_QTY)* h.HDoc_Doc_TC) importe, '' centro_Costo, NULL partida_Presupuestal, 'A' operacion, h.HDoc_Doc_Fec, 0 clase,32 modo, h.HDoc_Doc_Cat tipo, h.HDoc_Doc_Ano cilco, h.HDoc_Doc_Num num,0 id "
                strSQL &= "                 FROM PDM.Dcmtos_HDR h "
                strSQL &= "                     LEFT JOIN PDM.Dcmtos_DTL_Pro e ON e.PDoc_Sis_Emp = h.HDoc_Sis_Emp AND e.PDoc_Chi_Cat = h.HDoc_Doc_Cat AND e.PDoc_Chi_Ano = h.HDoc_Doc_Ano AND e.PDoc_Chi_Num = h.HDoc_Doc_Num AND e.PDoc_Par_Cat = 44 "
                strSQL &= "                         LEFT JOIN PDM.Dcmtos_DTL d ON d.DDoc_Sis_Emp = e.PDoc_Sis_Emp AND d.DDoc_Doc_Cat = e.PDoc_Par_Cat AND d.DDoc_Doc_Ano= e.PDoc_Par_Ano AND d.DDoc_Doc_Num = e.PDoc_Par_Num AND d.DDoc_Doc_Lin = e.PDoc_Par_Lin "
                strSQL &= "                             LEFT JOIN PDM.Proveedores p ON p.pro_sisemp = h.HDoc_Sis_Emp AND p.pro_codigo = h.HDoc_Emp_Cod "
                strSQL &= "                                 WHERE h.HDoc_Sis_Emp = {empresa} AND h.HDoc_Doc_Cat = {cat} AND h.HDoc_Doc_Ano = {anio} AND h.HDoc_Doc_Num = {numero} "

            End If

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try

        Return strSQL
    End Function
#End Region
#Region "Inventario de Producto Terminado y Desperdicio "

    Private Sub PolizaInventarioProductoTerminado(ByVal cat As Integer, ByVal anio As Integer, ByVal num As Integer, ByVal tipoIngreso As Integer)
        Dim longPolizas As Long = NO_FILA
        Dim strSQL As String = STR_VACIO
        Dim COM As MySqlCommand

        Try
            longPolizas = NuevaPoliza() ' verifica el ultimo numero de poliza
            UltimaPoliza(longPolizas, EJERCICIO) ' actualiza la ultima poliza

            strSQL = SQLEncabezadoPolizaDeEmpaque(cat, anio, num, longPolizas, tipoIngreso)
            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSQL, CON)
            COM.ExecuteNonQuery()

            strSQL = STR_VACIO

            strSQL = SQLDetallePolizaDeEmpaque(cat, anio, num, longPolizas, tipoIngreso)
            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSQL, CON)
            COM.ExecuteNonQuery()

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Function SQLEncabezadoPolizaDeEmpaque(ByVal cat As Integer, ByVal anio As Integer, ByVal num As Integer, ByVal poliza As Integer, ByVal Ingreso As Integer)
        Dim strSQL As String = STR_VACIO
        Dim DescripcionPoliza As String = STR_VACIO

        strSQL = " INSERT INTO {conta}.polizas"
        strSQL &= "   SELECT h.HDoc_Sis_Emp empresa, {ejercicio} ejercicio, {poliza} poliza, h.HDoc_Doc_Fec fecha, {desc} concepto, {ingreso} tipo, h.HDoc_Doc_TC TC, '' observacion, h.HDoc_Usuario operador, 'C' estado, NOW() marca,'' grupo, {ingreso} modo, h.HDoc_Doc_Cat refTipo, h.HDoc_Doc_Ano refCiclo, h.HDoc_Doc_Num refNumero, NULL divisa, h.HDoc_Doc_TC Tasa,0 revisado,'' usuarioRev, NULL ultRev "
        strSQL &= "      FROM Dcmtos_HDR h "
        strSQL &= "         WHERE h.HDoc_Sis_Emp = {empresa} AND h.HDoc_Doc_Cat = {cat} AND h.HDoc_Doc_Ano = {anio} AND h.HDoc_Doc_Num = {num} "
        If Sesion.IdEmpresa = 18 Then
            strSQL &= "; INSERT INTO contapdm.polizas"
            strSQL &= "   SELECT h.HDoc_Sis_Emp empresa, {ejercicio} ejercicio, {poliza} poliza, h.HDoc_Doc_Fec fecha, {desc} concepto, {ingreso} tipo, h.HDoc_Doc_TC TC, '' observacion, h.HDoc_Usuario operador, 'C' estado, NOW() marca,'' grupo, {ingreso} modo, h.HDoc_Doc_Cat refTipo, h.HDoc_Doc_Ano refCiclo, h.HDoc_Doc_Num refNumero, NULL divisa, h.HDoc_Doc_TC Tasa,0 revisado,'' usuarioRev, NULL ultRev "
            strSQL &= "      FROM PDM.Dcmtos_HDR h "
            strSQL &= "         WHERE h.HDoc_Sis_Emp = {empresa} AND h.HDoc_Doc_Cat = {cat} AND h.HDoc_Doc_Ano = {anio} AND h.HDoc_Doc_Num = {num} "
        End If
        strSQL = Replace(strSQL, "{ejercicio}", EJERCICIO)
        strSQL = Replace(strSQL, "{poliza}", poliza)
        strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
        strSQL = Replace(strSQL, "{cat}", cat)
        strSQL = Replace(strSQL, "{anio}", anio)
        strSQL = Replace(strSQL, "{num}", num)
        strSQL = Replace(strSQL, "{conta}", Sesion.BaseConta)
        strSQL = Replace(strSQL, "{ingreso}", Ingreso)
        If Ingreso = 1 Then
            DescripcionPoliza = "  CONCAT('Poliza de Inventario de Producto Terminado, segun Documento No. ', h.HDoc_Doc_Num ) "
        ElseIf Ingreso = 2 Then
            DescripcionPoliza = "  CONCAT('Poliza de Inventario de Desperdicio, segun Documento No. ', h.HDoc_Doc_Num ) "
        End If
        strSQL = Replace(strSQL, "{desc}", DescripcionPoliza)

        Return strSQL
    End Function

    Private Function SQLDetallePolizaDeEmpaque(ByVal cat As Integer, ByVal anio As Integer, ByVal num As Integer, ByVal poliza As Integer, ByVal Ingreso As Integer)
        Dim strSQL As String = STR_VACIO

        strSQL = " INSERT INTO {conta}.detalle_polizas"
        strSQL &= "    SELECT 0, h.HDoc_Sis_Emp empresa, {ejercicio}, {poliza},1 item, ic.inventario cuenta,1 parametroCuenta, SUM((d.DDoc_Prd_PUQ * d.DDoc_Prd_QTY) * h.HDoc_Doc_TC) importe,'' centroCosto, '' partidaPresupuestal, 'C' operacion, h.HDoc_Doc_Fec Fecha,0 clase, {tipo} modo, h.HDoc_Doc_Cat refTipo, h.HDoc_Doc_Ano refCiclo, h.HDoc_Doc_Num refNumero, 0 id "
        strSQL &= "       FROM Dcmtos_HDR h "
        strSQL &= "           LEFT JOIN Dcmtos_DTL d ON d.DDoc_Sis_Emp = h.HDoc_Sis_Emp AND d.DDoc_Doc_Cat = h.HDoc_Doc_Cat AND d.DDoc_Doc_Ano = h.HDoc_Doc_Ano AND d.DDoc_Doc_Num = h.HDoc_Doc_Num "
        strSQL &= "                Left JOIN Inventarios i ON i.inv_sisemp = d.DDoc_Sis_Emp AND i.inv_numero = d.DDoc_Prd_Cod "
        strSQL &= "                    Left JOIN Articulos a ON a.art_sisemp = i.inv_sisemp AND a.art_codigo = i.inv_artcodigo "
        strSQL &= "                        Left JOIN {conta}.inventario_codigos ic ON ic.empresa = a.art_sisemp AND ic.clase = a.art_clase "
        strSQL &= "                            WHERE h.HDoc_Sis_Emp = {empresa} AND h.HDoc_Doc_Cat = {cat} AND h.HDoc_Doc_Ano = {anio} AND h.HDoc_Doc_Num = {num} "

        strSQL &= "                            UNION  "

        strSQL &= "                        Select 0, h.HDoc_Sis_Emp empresa, {ejercicio}, {poliza},1 item, p.valor cuenta,1 parametroCuenta, SUM((d.DDoc_Prd_PUQ * d.DDoc_Prd_QTY) * h.HDoc_Doc_TC) importe,'' centroCosto, '' partidaPresupuestal, 'A' operacion, h.HDoc_Doc_Fec Fecha,0 clase, {tipo} modo, h.HDoc_Doc_Cat refTipo, h.HDoc_Doc_Ano refCiclo, h.HDoc_Doc_Num refNumero, 0 id "
        strSQL &= "                    From Dcmtos_HDR h "
        strSQL &= "                Left JOIN Dcmtos_DTL d ON d.DDoc_Sis_Emp = h.HDoc_Sis_Emp AND d.DDoc_Doc_Cat = h.HDoc_Doc_Cat AND d.DDoc_Doc_Ano = h.HDoc_Doc_Ano AND d.DDoc_Doc_Num = h.HDoc_Doc_Num "
        strSQL &= "            Left JOIN {conta}.parametros_empresa p ON p.empresa = d.DDoc_Sis_Emp And p.parametro = 55 "
        strSQL &= "        WHERE h.HDoc_Sis_Emp = {empresa} And h.HDoc_Doc_Cat = {cat} And h.HDoc_Doc_Ano = {anio} And h.HDoc_Doc_Num = {num} "
        If Sesion.IdEmpresa = 18 Then
            strSQL &= "; INSERT INTO contapdm.detalle_polizas"
            strSQL &= "    SELECT 0, h.HDoc_Sis_Emp empresa, {ejercicio}, {poliza},1 item, ic.inventario cuenta,1 parametroCuenta, SUM((d.DDoc_Prd_PUQ * d.DDoc_Prd_QTY) * h.HDoc_Doc_TC) importe,'' centroCosto, '' partidaPresupuestal, 'C' operacion, h.HDoc_Doc_Fec Fecha,0 clase, {tipo} modo, h.HDoc_Doc_Cat refTipo, h.HDoc_Doc_Ano refCiclo, h.HDoc_Doc_Num refNumero, 0 id "
            strSQL &= "       FROM PDM.Dcmtos_HDR h "
            strSQL &= "           LEFT JOIN PDM.Dcmtos_DTL d ON d.DDoc_Sis_Emp = h.HDoc_Sis_Emp AND d.DDoc_Doc_Cat = h.HDoc_Doc_Cat AND d.DDoc_Doc_Ano = h.HDoc_Doc_Ano AND d.DDoc_Doc_Num = h.HDoc_Doc_Num "
            strSQL &= "                Left JOIN PDM.Inventarios i ON i.inv_sisemp = d.DDoc_Sis_Emp AND i.inv_numero = d.DDoc_Prd_Cod "
            strSQL &= "                    Left JOIN PDM.Articulos a ON a.art_sisemp = i.inv_sisemp AND a.art_codigo = i.inv_artcodigo "
            strSQL &= "                        Left JOIN contapdm.inventario_codigos ic ON ic.empresa = a.art_sisemp AND ic.clase = a.art_clase "
            strSQL &= "                            WHERE h.HDoc_Sis_Emp = {empresa} AND h.HDoc_Doc_Cat = {cat} AND h.HDoc_Doc_Ano = {anio} AND h.HDoc_Doc_Num = {num} "

            strSQL &= "                            UNION  "

            strSQL &= "                        Select 0, h.HDoc_Sis_Emp empresa, {ejercicio}, {poliza},1 item, p.valor cuenta,1 parametroCuenta, SUM((d.DDoc_Prd_PUQ * d.DDoc_Prd_QTY) * h.HDoc_Doc_TC) importe,'' centroCosto, '' partidaPresupuestal, 'A' operacion, h.HDoc_Doc_Fec Fecha,0 clase, {tipo} modo, h.HDoc_Doc_Cat refTipo, h.HDoc_Doc_Ano refCiclo, h.HDoc_Doc_Num refNumero, 0 id "
            strSQL &= "                    From PDM.Dcmtos_HDR h "
            strSQL &= "                Left JOIN PDM.Dcmtos_DTL d ON d.DDoc_Sis_Emp = h.HDoc_Sis_Emp AND d.DDoc_Doc_Cat = h.HDoc_Doc_Cat AND d.DDoc_Doc_Ano = h.HDoc_Doc_Ano AND d.DDoc_Doc_Num = h.HDoc_Doc_Num "
            strSQL &= "            Left JOIN contapdm.parametros_empresa p ON p.empresa = d.DDoc_Sis_Emp And p.parametro = 55 "
            strSQL &= "        WHERE h.HDoc_Sis_Emp = {empresa} And h.HDoc_Doc_Cat = {cat} And h.HDoc_Doc_Ano = {anio} And h.HDoc_Doc_Num = {num} "
        End If
        strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
        strSQL = Replace(strSQL, "{conta}", Sesion.BaseConta)
        strSQL = Replace(strSQL, "{ejercicio}", EJERCICIO)
        strSQL = Replace(strSQL, "{poliza}", poliza)
        strSQL = Replace(strSQL, "{cat}", cat)
        strSQL = Replace(strSQL, "{anio}", anio)
        strSQL = Replace(strSQL, "{num}", num)
        strSQL = Replace(strSQL, "{tipo}", Ingreso)

        Return strSQL
    End Function



#End Region
#Region "Factura de Compra"
    Private Sub PolizaDeFacturaDeCompra(ByVal anio As Integer, ByVal num As Integer, ByVal fec As Date, Optional ingresoTraslado As Integer = 0)
        ' Verifica si es Factura Extemporanea
        Dim strsql As String = STR_VACIO
        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader
        Dim extemporaneo As Integer = NO_FILA
        Dim intIVA As Integer = NO_FILA
        Dim intTipoFact As Integer = NO_FILA
        Dim intFactConsumible As Integer = NO_FILA
        Dim dtFecha As String = STR_VACIO
        Dim strFecha As String = STR_VACIO
        Dim intStatus As Integer
        Dim longPolizas As Long = NO_FILA
        Dim intCaja As Integer = 0
        Try
            '***********************************
            'VERIFICA SI ES EXTEMPORANEA O NO, SI RETIENE IVA O NO Y TIPO DE FACTURA
            strsql = " SELECT h.HDoc_DR2_Cat extemporaneo, IFNULL(h.HDoc_DR1_Emp,-1) tipoFact, h.HDoc_DR2_Emp Iva, CONCAT(MONTH(h.HDoc_Doc_Fec), YEAR(h.HDoc_Doc_Fec)) fecha, IFNULL(h.HDoc_RF1_Cod,0) consumible "
            strsql &= "    From Dcmtos_HDR h "
            strsql &= "        Where h.HDoc_Sis_Emp = {empresa} And h.HDoc_Doc_Cat = 44 And h.HDoc_Doc_Ano = {anio} And h.HDoc_Doc_Num = {num} "

            strsql = Replace(strsql, "{empresa}", Sesion.IdEmpresa)
            strsql = Replace(strsql, "{anio}", anio)
            strsql = Replace(strsql, "{num}", num)

            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strsql, CON)
            REA = COM.ExecuteReader
            If REA.HasRows Then
                While REA.Read
                    extemporaneo = REA.GetInt32("extemporaneo") ' 0 no extemporanea - 1 Extemporanea
                    intIVA = REA.GetInt32("Iva") ' 1 Retiene IVA, 0 No retiene IVA
                    intTipoFact = REA.GetInt32("tipoFact") ' -1 Importacion, 1 Factura Electronica, 2 Pequeño Contribuyente
                    If intTipoFact = 3 Then
                        intFactConsumible = IIf((REA.GetInt32("consumible").ToString = ""), 0, REA.GetInt32("consumible")) '0 consumible, 1 servicios
                    Else
                        intFactConsumible = 0
                    End If

                    dtFecha = REA.GetString("fecha")
                End While
            End If

            strsql = STR_VACIO


            '********************************
            'VERIFICA QUE EXISTA LIBRO DE COMPRAS Y SI ESTA CERRADO O NO
            strsql = " SELECT h.HDoc_Doc_Status status "
            strsql &= "    From Dcmtos_HDR h "
            strsql &= "        Where h.HDoc_Sis_Emp = {empresa} And h.HDoc_Doc_Cat = 286 And h.HDoc_Doc_Ano = {anio} AND CONCAT(MONTH(h.HDoc_Doc_Fec), YEAR(h.HDoc_Doc_Fec)) = '{fecha}' "

            strsql = Replace(strsql, "{empresa}", Sesion.IdEmpresa)
            strsql = Replace(strsql, "{anio}", anio)
            strsql = Replace(strsql, "{fecha}", dtFecha)

            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strsql, CON)
            intStatus = COM.ExecuteScalar ' Verifica si existe libro de compras y si esta abierto = 0 o cerrado = 1
            strsql = STR_VACIO

            ' VERIFICA SI ES FACTURA DE CAJA CHICA O NO
            strsql = " SELECT h.HDoc_DR1_Cat caja "
            strsql &= "    From Dcmtos_HDR h "
            strsql &= "    WHERE h.HDoc_Sis_Emp = {empresa} AND h.HDoc_Doc_Cat = 44 AND h.HDoc_Doc_Ano = {anio} AND h.HDoc_Doc_Num = {num} "

            strsql = Replace(strsql, "{empresa}", Sesion.IdEmpresa)
            strsql = Replace(strsql, "{anio}", anio)
            strsql = Replace(strsql, "{num}", num)

            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strsql, CON)
            intCaja = COM.ExecuteScalar ' Verifica si es de caja chica > 0 o no = 0
            strsql = STR_VACIO

            longPolizas = NuevaPoliza() ' verifica el ultimo numero de poliza
            UltimaPoliza(longPolizas, EJERCICIO) ' actualiza la ultima poliza

            'ENCABEZADO DE POLIZA
            strsql = SQLEncabezadoFacturaCompra()
            strsql = Replace(strsql, "{ejercicio}", EJERCICIO)
            strsql = Replace(strsql, "{poliza}", longPolizas)
            strsql = Replace(strsql, "{empresa}", Sesion.IdEmpresa)
            strsql = Replace(strsql, "{anio}", anio)
            strsql = Replace(strsql, "{num}", num)
            strsql = Replace(strsql, "{conta}", Sesion.BaseConta)
            strsql = Replace(strsql, "{usuario}", Sesion.Usuario)
            If ingresoTraslado = 1 Then
                strsql = Replace(strsql, "{condicion}", "")
            Else
                strsql = Replace(strsql, "{condicion}", "AND NOT (h.HDoc_RF1_Cod=0 AND h.HDoc_DR1_Emp=3)")
            End If

            If Year(fec.ToString(FORMATO_MYSQL)) <> Year(Now) Then
                If Month(fec.ToString(FORMATO_MYSQL)) = 12 Then
                    strsql = Replace(strsql, "{fecha}", fec.ToString(FORMATO_MYSQL))
                Else
                    'strsql = Replace(strsql, "{fecha}", (DateSerial(Year(fec.ToString(FORMATO_MYSQL)), 12, 1).ToString(FORMATO_MYSQL)))
                    strsql = Replace(strsql, "{fecha}", fec.ToString(FORMATO_MYSQL))
                End If
            Else
                If extemporaneo = 1 Then
                    'strsql = Replace(strsql, "{fecha}", (DateSerial(Year(Date.Now), Month(Date.Now), 1).ToString(FORMATO_MYSQL)))
                    strsql = Replace(strsql, "{fecha}", fec.ToString(FORMATO_MYSQL))
                Else
                    If intStatus = 1 Then
                        'strsql = Replace(strsql, "{fecha}", (DateSerial(Year(Date.Now), Month(Date.Now), 1).ToString(FORMATO_MYSQL)))
                        strsql = Replace(strsql, "{fecha}", fec.ToString(FORMATO_MYSQL))
                    Else
                        strsql = Replace(strsql, "{fecha}", fec.ToString(FORMATO_MYSQL))
                    End If
                End If
            End If


            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strsql, CON)
            COM.ExecuteNonQuery()
            strsql = STR_VACIO
            COM.Dispose()

            If ingresoTraslado = 1 Then
                strsql = SQLDetalleFacturaImportacionTendido()
                strsql = Replace(strsql, "{ejercicio}", EJERCICIO)
                strsql = Replace(strsql, "{poliza}", longPolizas)
                strsql = Replace(strsql, "{empresa}", Sesion.IdEmpresa)
                strsql = Replace(strsql, "{anio}", anio)
                strsql = Replace(strsql, "{num}", num)
                strsql = Replace(strsql, "{conta}", Sesion.BaseConta)
            Else
                ' DETALLE DE POLIZA
                strsql = SQLDetalleFacturaCompra(intIVA, intTipoFact, extemporaneo, intCaja, intFactConsumible)
                strsql = Replace(strsql, "{ejercicio}", EJERCICIO)
                strsql = Replace(strsql, "{poliza}", longPolizas)
                strsql = Replace(strsql, "{empresa}", Sesion.IdEmpresa)
                strsql = Replace(strsql, "{anio}", anio)
                strsql = Replace(strsql, "{num}", num)
                strsql = Replace(strsql, "{conta}", Sesion.BaseConta)
            End If

            MyCnn.CONECTAR = strConexion & " Allow User Variables=True"
            COM = New MySqlCommand(strsql, CON)
            COM.ExecuteNonQuery()
            strsql = STR_VACIO

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try

    End Sub

    Private Function SQLEncabezadoFacturaCompra()
        Dim strSQL As String = STR_VACIO

        strSQL = " INSERT INTO {conta}.polizas"
        strSQL &= "   SELECT h.HDoc_Sis_Emp empresa, {ejercicio} ejercicio, {poliza} poliza, '{fecha}', CONCAT('Poliza de Compra, Factura: ', h.HDoc_DR1_Num, ' ', h.HDoc_DR2_Num, ' de fecha ', h.HDoc_Doc_Fec) concepto, 8 tipo, h.HDoc_Doc_TC TC, '' observacion, '{usuario}' operador, 'C' estado, NOW() marca,'' grupo, 8 modo, h.HDoc_Doc_Cat refTipo, h.HDoc_Doc_Ano refCiclo, h.HDoc_Doc_Num refNumero, NULL divisa, h.HDoc_Doc_TC Tasa,0 revisado,'' usuarioRev, NULL ultRev "
        strSQL &= "      FROM Dcmtos_HDR h "
        strSQL &= "         WHERE h.HDoc_Sis_Emp = {empresa} AND h.HDoc_Doc_Cat = 44  {condicion}  AND h.HDoc_Doc_Ano = {anio} AND h.HDoc_Doc_Num = {num} "
        If Sesion.IdEmpresa = 18 Then
            strSQL &= "; INSERT INTO contapdm.polizas"
            strSQL &= "   SELECT h.HDoc_Sis_Emp empresa, {ejercicio} ejercicio, {poliza} poliza, '{fecha}', CONCAT('Poliza de Compra, Factura: ', h.HDoc_DR1_Num, ' ', h.HDoc_DR2_Num, ' de fecha ', h.HDoc_Doc_Fec) concepto, 8 tipo, h.HDoc_Doc_TC TC, '' observacion, '{usuario}' operador, 'C' estado, NOW() marca,'' grupo, 8 modo, h.HDoc_Doc_Cat refTipo, h.HDoc_Doc_Ano refCiclo, h.HDoc_Doc_Num refNumero, NULL divisa, h.HDoc_Doc_TC Tasa,0 revisado,'' usuarioRev, NULL ultRev "
            strSQL &= "      FROM PDM.Dcmtos_HDR h "
            strSQL &= "         WHERE h.HDoc_Sis_Emp = {empresa} AND h.HDoc_Doc_Cat = 44  {condicion}  AND h.HDoc_Doc_Ano = {anio} AND h.HDoc_Doc_Num = {num} "
        End If
        Return strSQL
    End Function

    Private Function SQLDetalleFacturaImportacionTendido()
        Dim strSQL As String = STR_VACIO
        Dim item As Integer = 0

        Try
            strSQL = " INSERT INTO {conta}.detalle_polizas
                    SELECT s1.transaccion, s1.empresa, s1.ejercicio, s1.poliza, (@REG := @REG + 1) item, IFNULL(s1.cuenta,''), s1.parametro_cuenta, s1.importe, centro_costos, IFNULL(s1.partida_presupuestal,''), s1.operacion, s1.fecha, IFNULL(s1.clase,''), s1.modo, s1.ref_tipo, s1.ref_ciclo, s1.ref_numero, s1.ref_id
                    FROM(
                    SELECT 0 transaccion, h.HDoc_Sis_Emp empresa, {ejercicio} ejercicio, {poliza} poliza, @REG :=0, '210201098' cuenta, h.HDoc_DR1_Cat parametro_cuenta, ROUND(SUM((d.DDoc_Prd_QTY * d.DDoc_Prd_NET) * h.HDoc_Doc_TC),2) Importe,0 centro_costos, NULL partida_presupuestal, 'C' operacion, CAST(CURDATE() AS CHAR) fecha, 0 clase, 8 modo, h.HDoc_Doc_Cat ref_tipo, h.HDoc_Doc_Ano ref_ciclo, h.HDoc_Doc_Num ref_numero, d.DDoc_Prd_Cod ref_id
                    FROM Dcmtos_HDR h
                    LEFT JOIN Dcmtos_DTL d ON d.DDoc_Sis_Emp = h.HDoc_Sis_Emp AND d.DDoc_Doc_Cat = h.HDoc_Doc_Cat AND d.DDoc_Doc_Ano = h.HDoc_Doc_Ano AND d.DDoc_Doc_Num = h.HDoc_Doc_Num
                    WHERE h.HDoc_Sis_Emp = {empresa} AND h.HDoc_Doc_Cat = 44 AND h.HDoc_Doc_Ano = {anio} AND h.HDoc_Doc_Num = {num} 
                UNION
                    SELECT 0 transaccion, h.HDoc_Sis_Emp empresa, {ejercicio} ejercicio, {poliza} poliza, @REG :=0, p.pro_cuenta cuenta, h.HDoc_DR1_Cat parametro_cuenta, ROUND(SUM((d.DDoc_Prd_QTY * d.DDoc_Prd_NET) * h.HDoc_Doc_TC),2) Importe,0 centro_costos, NULL partida_presupuestal, 'A' operacion, CAST(CURDATE() AS CHAR) fecha, 0 clase, 8 modo, h.HDoc_Doc_Cat ref_tipo, h.HDoc_Doc_Ano ref_ciclo, h.HDoc_Doc_Num ref_numero, d.DDoc_Prd_Cod ref_id
                    FROM Dcmtos_HDR h
                    LEFT JOIN Dcmtos_DTL d ON d.DDoc_Sis_Emp = h.HDoc_Sis_Emp AND d.DDoc_Doc_Cat = h.HDoc_Doc_Cat AND d.DDoc_Doc_Ano = h.HDoc_Doc_Ano AND d.DDoc_Doc_Num = h.HDoc_Doc_Num
                    LEFT JOIN Proveedores p ON p.pro_sisemp = h.HDoc_Sis_Emp AND p.pro_codigo = h.HDoc_Emp_Cod
                    WHERE h.HDoc_Sis_Emp = {empresa} AND h.HDoc_Doc_Cat = 44 AND h.HDoc_Doc_Ano = {anio} AND h.HDoc_Doc_Num = {num})s1"
            If Sesion.IdEmpresa = 18 Then
                strSQL &= "; INSERT INTO contapdm.detalle_polizas
                    SELECT s1.transaccion, s1.empresa, s1.ejercicio, s1.poliza, (@REG := @REG + 1) item, IFNULL(s1.cuenta,''), s1.parametro_cuenta, s1.importe, centro_costos, IFNULL(s1.partida_presupuestal,''), s1.operacion, s1.fecha, IFNULL(s1.clase,''), s1.modo, s1.ref_tipo, s1.ref_ciclo, s1.ref_numero, s1.ref_id
                    FROM(
                    SELECT 0 transaccion, h.HDoc_Sis_Emp empresa, {ejercicio} ejercicio, {poliza} poliza, @REG :=0, '210201098' cuenta, h.HDoc_DR1_Cat parametro_cuenta, ROUND(SUM((d.DDoc_Prd_QTY * d.DDoc_Prd_NET) * h.HDoc_Doc_TC),2) Importe,0 centro_costos, NULL partida_presupuestal, 'C' operacion, CAST(CURDATE() AS CHAR) fecha, 0 clase, 8 modo, h.HDoc_Doc_Cat ref_tipo, h.HDoc_Doc_Ano ref_ciclo, h.HDoc_Doc_Num ref_numero, d.DDoc_Prd_Cod ref_id
                    FROM PDM.Dcmtos_HDR h
                    LEFT JOIN PDM.Dcmtos_DTL d ON d.DDoc_Sis_Emp = h.HDoc_Sis_Emp AND d.DDoc_Doc_Cat = h.HDoc_Doc_Cat AND d.DDoc_Doc_Ano = h.HDoc_Doc_Ano AND d.DDoc_Doc_Num = h.HDoc_Doc_Num
                    WHERE h.HDoc_Sis_Emp = {empresa} AND h.HDoc_Doc_Cat = 44 AND h.HDoc_Doc_Ano = {anio} AND h.HDoc_Doc_Num = {num} 
                UNION
                    SELECT 0 transaccion, h.HDoc_Sis_Emp empresa, {ejercicio} ejercicio, {poliza} poliza, @REG :=0, p.pro_cuenta cuenta, h.HDoc_DR1_Cat parametro_cuenta, ROUND(SUM((d.DDoc_Prd_QTY * d.DDoc_Prd_NET) * h.HDoc_Doc_TC),2) Importe,0 centro_costos, NULL partida_presupuestal, 'A' operacion, CAST(CURDATE() AS CHAR) fecha, 0 clase, 8 modo, h.HDoc_Doc_Cat ref_tipo, h.HDoc_Doc_Ano ref_ciclo, h.HDoc_Doc_Num ref_numero, d.DDoc_Prd_Cod ref_id
                    FROM PDM.Dcmtos_HDR h
                    LEFT JOIN PDM.Dcmtos_DTL d ON d.DDoc_Sis_Emp = h.HDoc_Sis_Emp AND d.DDoc_Doc_Cat = h.HDoc_Doc_Cat AND d.DDoc_Doc_Ano = h.HDoc_Doc_Ano AND d.DDoc_Doc_Num = h.HDoc_Doc_Num
                    LEFT JOIN PDM.Proveedores p ON p.pro_sisemp = h.HDoc_Sis_Emp AND p.pro_codigo = h.HDoc_Emp_Cod
                    WHERE h.HDoc_Sis_Emp = {empresa} AND h.HDoc_Doc_Cat = 44 AND h.HDoc_Doc_Ano = {anio} AND h.HDoc_Doc_Num = {num})s1"
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try

        Return strSQL

    End Function

    Private Function SQLDetalleFacturaCompra(ByVal db As String, ByVal conta As String, ByVal intIva As Integer, ByVal intTipoFact As Integer, ByVal Extemporaneo As Integer, Optional ByVal caja As Integer = 0, Optional ByVal intFactConsumible As Integer = 0) 'IntTipoFact: -1 Importacion, 1 Factura Electronica, 2 Pequeño Contribuyente, si es de caja chica CAJA = 1 si no = 0    intFactConsumible: 0 consumible, 1 servicios
        Dim strSQL As String = STR_VACIO
        Dim item As Integer = 0
        ' IntIVA: 1 Retiene IVA, 0 no Retiene IVA
        ' 0 no extemporanea - 1 Extemporanea
        Try

            item = item + 1
            strSQL = " INSERT INTO {conta}.detalle_polizas"
            strSQL &= "   SELECT 0,'{empresa}',{ejercicio},{poliza}," & item & " item, d.DDoc_RF1_Cod cuenta, 1 parametro_cuenta, (SUM((({price} * d.DDoc_Prd_QTY)* h.HDoc_Doc_TC) {combustible} {iva}) importe, d.DDoc_RF3_Num centro_Costo, NULL partida_Presupuestal, 'C' operacion, h.HDoc_Doc_Fec, 0 clase, 8 modo, h.HDoc_Doc_Cat tipo, h.HDoc_Doc_Ano cilco, h.HDoc_Doc_Num num,0 id "
            strSQL &= "        From {db}Dcmtos_HDR h "
            strSQL &= "            Left JOIN {db}Dcmtos_DTL d ON d.DDoc_Sis_Emp = h.HDoc_Sis_Emp AND d.DDoc_Doc_Cat = h.HDoc_Doc_Cat AND d.DDoc_Doc_Ano= h.HDoc_Doc_Ano AND d.DDoc_Doc_Num = h.HDoc_Doc_Num "
            strSQL &= "                WHERE h.HDoc_Sis_Emp = {empresa} AND h.HDoc_Doc_Cat = 44 AND NOT (h.HDoc_RF1_Cod=0 AND h.HDoc_DR1_Emp=3) AND h.HDoc_Doc_Ano = {anio} AND h.HDoc_Doc_Num = {num} "
            strSQL &= "                     Group By d.DDoc_RF1_Cod, d.DDoc_RF3_Num "

            If Sesion.IdEmpresa = 18 Or Sesion.IdEmpresa = 19 Or Sesion.IdEmpresa = 21 Then
                strSQL = Replace(strSQL, "{price}", " d.DDoc_RF3_Dbl ")
            Else
                strSQL = Replace(strSQL, "{price}", " d.DDoc_Prd_NET ")
            End If

            If Extemporaneo = 0 Then
                If intTipoFact = 2 Then
                    strSQL = Replace(strSQL, "{iva}", STR_VACIO)
                ElseIf (intTipoFact = 3 And intFactConsumible = 0) Then
                    strSQL = "select 1"
                    Return strSQL
                    Exit Function
                Else

                    If intIva = 1 Then
                        item = item + 1
                        If Sesion.idGiro = 2 Then
                            strSQL &= "                        UNION " ' SEGUNDA LINEA QUE MUESTRA LA CUENTA DE IVA
                            strSQL &= "                            Select 0,'{empresa}',{ejercicio},{poliza}," & item & " item, d.DDoc_RF1_Txt cuenta, 1 parametro_cuenta, ROUND(SUM((d.DDoc_Prd_NET - d.DDoc_RF3_Dbl) * d.DDoc_Prd_QTY) * h.HDoc_Doc_TC ,2) importe, '' centro_Costo, NULL partida_Presupuestal, 'C' operacion, h.HDoc_Doc_Fec, 0 clase, 8 modo, h.HDoc_Doc_Cat tipo, h.HDoc_Doc_Ano cilco, h.HDoc_Doc_Num num,0 id "
                            strSQL &= "                                From {db}Dcmtos_HDR h "
                            strSQL &= "                                    Left JOIN {db}Dcmtos_DTL d ON d.DDoc_Sis_Emp = h.HDoc_Sis_Emp AND d.DDoc_Doc_Cat = h.HDoc_Doc_Cat AND d.DDoc_Doc_Ano = h.HDoc_Doc_Ano AND d.DDoc_Doc_Num = h.HDoc_Doc_Num "
                            strSQL &= "                         WHERE h.HDoc_Sis_Emp = {empresa} AND h.HDoc_Doc_Cat = 44 AND NOT (h.HDoc_RF1_Cod=0 AND h.HDoc_DR1_Emp=3) AND h.HDoc_Doc_Ano = {anio} AND h.HDoc_Doc_Num = {num} AND LENGTH(d.DDoc_RF1_Txt)>0
                                                                GROUP BY d.DDoc_RF1_Txt"

                            strSQL = Replace(strSQL, "{iva}", STR_VACIO)
                        Else
                            strSQL &= "                        UNION " ' SEGUNDA LINEA QUE MUESTRA LA CUENTA DE IVA
                            strSQL &= "                            Select 0,'{empresa}',{ejercicio},{poliza}," & item & " item, e.valor cuenta, 1 parametro_cuenta, p.MDoc_Lin_Monto importe, '' centro_Costo, NULL partida_Presupuestal, 'C' operacion, h.HDoc_Doc_Fec, 0 clase, 8 modo, h.HDoc_Doc_Cat tipo, h.HDoc_Doc_Ano cilco, h.HDoc_Doc_Num num,0 id "
                            strSQL &= "                                From {db}Dcmtos_HDR h "
                            strSQL &= "                                    Left JOIN {db}Dcmtos_DTL d ON d.DDoc_Sis_Emp = h.HDoc_Sis_Emp AND d.DDoc_Doc_Cat = h.HDoc_Doc_Cat AND d.DDoc_Doc_Ano = h.HDoc_Doc_Ano AND d.DDoc_Doc_Num = h.HDoc_Doc_Num "
                            strSQL &= "                                        Left JOIN {db}Dcmtos_IMP p ON p.MDoc_Sis_Emp = d.DDoc_Sis_Emp AND p.MDoc_Doc_Cat = d.DDoc_Doc_Cat AND p.MDoc_Doc_Ano = d.DDoc_Doc_Ano AND p.MDoc_Doc_Num = d.DDoc_Doc_Num "
                            strSQL &= "                                            Left JOIN {conta}.parametros_empresa e ON e.empresa = p.MDoc_Sis_Emp AND e.parametro = 28"
                            strSQL &= "                                                 WHERE h.HDoc_Sis_Emp = {empresa} AND h.HDoc_Doc_Cat = 44 AND h.HDoc_Doc_Ano = {anio} AND h.HDoc_Doc_Num = {num} AND p.MDoc_Lin_Codigo = 'IVA' AND p.MDoc_Lin_Monto >0 "

                            strSQL = Replace(strSQL, "{iva}", " / (((SELECT cat_sist IVA FROM {db}Catalogos c WHERE c.cat_clase = 'Impuestos' AND c.cat_clave ='IVA' AND c.cat_sisemp = {empresa})/100)+1) ")
                        End If

                        item = item + 1
                        strSQL &= "                        UNION " ' LINEA QUE MUESTRA LA CUENTA DE COMBUSTIBLE SI APLICARA
                        strSQL &= "                            Select 0,'{empresa}',{ejercicio},{poliza}," & item & " item, e.valor cuenta, 1 parametro_cuenta, p.MDoc_Lin_Monto importe, d.DDoc_RF3_Num centro_Costo, NULL partida_Presupuestal, 'C' operacion, h.HDoc_Doc_Fec, 0 clase, 8 modo, h.HDoc_Doc_Cat tipo, h.HDoc_Doc_Ano cilco, h.HDoc_Doc_Num num,0 id "
                        strSQL &= "                                From {db}Dcmtos_HDR h "
                        strSQL &= "                                    Left JOIN {db}Dcmtos_DTL d ON d.DDoc_Sis_Emp = h.HDoc_Sis_Emp AND d.DDoc_Doc_Cat = h.HDoc_Doc_Cat AND d.DDoc_Doc_Ano = h.HDoc_Doc_Ano AND d.DDoc_Doc_Num = h.HDoc_Doc_Num "
                        strSQL &= "                                        Left JOIN {db}Dcmtos_IMP p ON p.MDoc_Sis_Emp = d.DDoc_Sis_Emp AND p.MDoc_Doc_Cat = d.DDoc_Doc_Cat AND p.MDoc_Doc_Ano = d.DDoc_Doc_Ano AND p.MDoc_Doc_Num = d.DDoc_Doc_Num "
                        strSQL &= "                                            Left JOIN {conta}.parametros_empresa e ON e.empresa = p.MDoc_Sis_Emp AND e.parametro = 29"
                        strSQL &= "                                                 WHERE h.HDoc_Sis_Emp = {empresa} AND h.HDoc_Doc_Cat = 44 AND NOT (h.HDoc_RF1_Cod=0 AND h.HDoc_DR1_Emp=3) AND h.HDoc_Doc_Ano = {anio} AND h.HDoc_Doc_Num = {num} AND p.MDoc_Lin_Codigo = 'IMP_DC' AND p.MDoc_Lin_Monto >0 "
                    Else
                        strSQL = Replace(strSQL, "{iva}", STR_VACIO)

                    End If
                End If

            Else
                strSQL = Replace(strSQL, "{iva}", STR_VACIO)
            End If

            item = item + 1
            strSQL = Replace(strSQL, "{combustible}", " - (SELECT IFNULL(SUM(p.MDoc_Lin_Monto),0) impuesto FROM Dcmtos_IMP p WHERE p.MDoc_Sis_Emp = d.DDoc_Sis_Emp AND p.MDoc_Doc_Cat = d.DDoc_Doc_Cat AND p.MDoc_Doc_Ano = d.DDoc_Doc_Ano AND p.MDoc_Doc_Num = d.DDoc_Doc_Num AND p.MDoc_Lin_Codigo = 'IMP_DC')) ")
            If caja > 0 Then

                strSQL &= " UNION " ' Tercer Linea, siempre y cuando sea de caja Chica
                strSQL &= "     SELECT 0,{empresa},{ejercicio},{poliza}, " & item & " item, b.BCta_Cuenta cuenta, 1 parametro_cuenta, SUM((d.DDoc_Prd_NET * d.DDoc_Prd_QTY)* h.HDoc_Doc_TC) importe, '' centro_Costo, NULL partida_Presupuestal, 'A' operacion, h.HDoc_Doc_Fec, 0 clase,8 modo, h.HDoc_Doc_Cat tipo, h.HDoc_Doc_Ano cilco, h.HDoc_Doc_Num num,0 id "
                strSQL &= "     FROM {db}Dcmtos_HDR h "
                strSQL &= "      LEFT JOIN {db}Dcmtos_DTL d ON d.DDoc_Sis_Emp = h.HDoc_Sis_Emp AND d.DDoc_Doc_Cat = h.HDoc_Doc_Cat AND d.DDoc_Doc_Ano = h.HDoc_Doc_Ano AND d.DDoc_Doc_Num = h.HDoc_Doc_Num "
                strSQL &= "      LEFT JOIN {db}CtasBcos b ON b.BCta_Sis_Emp = h.HDoc_Sis_Emp AND b.BCta_Num = h.HDoc_DR1_Cat "
                strSQL &= "      WHERE h.HDoc_Sis_Emp = {empresa} AND h.HDoc_Doc_Cat = 44 AND h.HDoc_Doc_Ano = {anio} AND h.HDoc_Doc_Num = {num}"

            Else
                strSQL = Replace(strSQL, "{combustible}", ")")
                strSQL &= "                                        UNION " ' Linea.. la que abona
                strSQL &= "                                    Select 0,'{empresa}',{ejercicio},{poliza}," & item & " item, p.pro_cuenta cuenta, 1 parametro_cuenta, SUM((d.DDoc_Prd_NET * d.DDoc_Prd_QTY)* h.HDoc_Doc_TC) importe, '' centro_Costo, NULL partida_Presupuestal, 'A' operacion, h.HDoc_Doc_Fec, 0 clase,8 modo, h.HDoc_Doc_Cat tipo, h.HDoc_Doc_Ano cilco, h.HDoc_Doc_Num num,0 id "
                strSQL &= "                              From {db}Dcmtos_HDR h "
                strSQL &= "                            Left JOIN {db}Dcmtos_DTL d ON d.DDoc_Sis_Emp = h.HDoc_Sis_Emp AND d.DDoc_Doc_Cat = h.HDoc_Doc_Cat AND d.DDoc_Doc_Ano = h.HDoc_Doc_Ano AND d.DDoc_Doc_Num = h.HDoc_Doc_Num "
                strSQL &= "                    Left JOIN {db}Proveedores p ON p.pro_sisemp = h.HDoc_Sis_Emp AND p.pro_codigo = h.HDoc_Emp_Cod "
                strSQL &= "                WHERE h.HDoc_Sis_Emp = {empresa} AND h.HDoc_Doc_Cat = 44 AND NOT (h.HDoc_RF1_Cod=0 AND h.HDoc_DR1_Emp=3) AND h.HDoc_Doc_Ano = {anio} AND h.HDoc_Doc_Num = {num} "
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        strSQL = Replace(strSQL, "{db}", db)
        If conta <> STR_VACIO Then
            strSQL = Replace(strSQL, "{conta}", conta)
        End If

        Return strSQL
    End Function

    Private Function SQLDetalleFacturaCompra(ByVal intIva As Integer, ByVal intTipoFact As Integer, ByVal Extemporaneo As Integer, Optional ByVal caja As Integer = 0, Optional ByVal intFactConsumible As Integer = 0) 'IntTipoFact: -1 Importacion, 1 Factura Electronica, 2 Pequeño Contribuyente, si es de caja chica CAJA = 1 si no = 0    intFactConsumible: 0 consumible, 1 servicios
        Dim strSQL As String = SQLDetalleFacturaCompra(STR_VACIO, STR_VACIO, intIva, intTipoFact, Extemporaneo, caja, intFactConsumible)
        If Sesion.IdEmpresa = 18 Then
            strSQL = String.Concat(strSQL, ";", SQLDetalleFacturaCompra("PDM.", "contapdm", intIva, intTipoFact, Extemporaneo, caja, intFactConsumible))
        End If

        Return strSQL
    End Function

#End Region

#Region "Retenciones"
    Private Sub PolizaDeRetencion(ByVal cat As Integer, ByVal anio As Integer, ByVal num As Integer, ByVal fec As Date, ByVal ctaCaja As String)
        Dim longPolizas As Long = NO_FILA
        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader
        Dim strSQL As String = STR_VACIO
        Dim FacturaTipo As Integer
        Dim TipoReten As Integer
        Dim vporcentaje As Double = INT_CERO
        Dim intControl As Integer = INT_CERO
        Try
            strSQL = VerificarRetencion(cat, anio, num)
            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSQL, CON)
            REA = COM.ExecuteReader()

            If REA.HasRows Then
                Do While REA.Read
                    FacturaTipo = REA.GetInt32("FactEspecial")
                    TipoReten = REA.GetInt32("TipoReten")
                Loop

            End If

            strSQL = STR_VACIO

            longPolizas = NuevaPoliza()
            UltimaPoliza(longPolizas, EJERCICIO) ' actualiza la ultima poliza
            strSQL = SQLEncabezadoRetencion(longPolizas, cat, anio, num, TipoReten, fec.ToString(FORMATO_MYSQL))

            ''''recuperar el porcentaje de la retencion

            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSQL, CON)
            COM.ExecuteNonQuery()
            strSQL = STR_VACIO

            strSQL = "Select h.HDoc_RF2_Dbl porcentaje, h.HDoc_RF3_Dbl control FROM Dcmtos_HDR h WHERE h.HDoc_Sis_Emp = " & Sesion.IdEmpresa & " And h.HDoc_Doc_Cat = " & cat & " And h.HDoc_Doc_Ano = " & anio & " And h.HDoc_Doc_Num = " & num
            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSQL, CON)
            REA = COM.ExecuteReader()

            If REA.HasRows Then
                Do While REA.Read
                    vporcentaje = REA.GetDouble("porcentaje")
                    intControl = REA.GetInt32("control")
                Loop

            End If

            strSQL = SQLDetalleRetencion(longPolizas, cat, anio, num, TipoReten, FacturaTipo, ctaCaja, vporcentaje, intControl)
            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSQL, CON)
            COM.ExecuteNonQuery()
            strSQL = STR_VACIO

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try

    End Sub

    Private Function VerificarRetencion(ByVal cat As Integer, ByVal anio As Integer, ByVal num As Integer)
        Dim strsql As String = STR_VACIO

        strsql = "   SELECT h.HDoc_Ant_Com TipoReten, h.HDoc_DR1_Cat FactEspecial "
        strsql &= "        From Dcmtos_HDR h"
        strsql &= "            WHERE h.HDoc_Sis_Emp = {empresa} AND h.HDoc_Doc_Cat = {cat} AND h.HDoc_Doc_Ano= {anio} AND h.HDoc_Doc_Num = {num} "

        strsql = Replace(strsql, "{empresa}", Sesion.IdEmpresa)
        strsql = Replace(strsql, "{anio}", anio)
        strsql = Replace(strsql, "{num}", num)
        strsql = Replace(strsql, "{cat}", cat)

        Return strsql
    End Function
    Private Function SQLEncabezadoRetencion(ByVal poliza As Integer, ByVal cat As Integer, ByVal anio As Integer, ByVal num As Integer, ByVal TipoReten As Integer, ByVal fec As Date)
        Dim strsql As String = STR_VACIO

        strsql = " INSERT INTO {conta}.polizas"
        strsql &= "   SELECT h.HDoc_Sis_Emp empresa, {ejercicio} ejercicio, {poliza} poliza, '{fec}' fecha, CONCAT('Retencion #', h.HDoc_DR1_Num, ' Segun Factura #', h.HDoc_DR2_Num, ' A fecha ', h.HDoc_Doc_Fec) concepto, {tipo} tipo, h.HDoc_Doc_TC TC, '' observacion, h.HDoc_Usuario operador, 'C' estado, NOW() marca,'' grupo, {tipo} modo, h.HDoc_Doc_Cat refTipo, h.HDoc_Doc_Ano refCiclo, h.HDoc_Doc_Num refNumero, NULL divisa, h.HDoc_Doc_TC Tasa,0 revisado,'' usuarioRev, NULL ultRev "
        strsql &= "      FROM Dcmtos_HDR h "
        strsql &= "         WHERE h.HDoc_Sis_Emp = {empresa} AND h.HDoc_Doc_Cat = {cat} AND h.HDoc_Doc_Ano = {anio} AND h.HDoc_Doc_Num = {num} "
        If Sesion.IdEmpresa = 18 Then
            strsql &= "; INSERT INTO contapdm.polizas"
            strsql &= "   SELECT h.HDoc_Sis_Emp empresa, {ejercicio} ejercicio, {poliza} poliza, '{fec}' fecha, CONCAT('Retencion #', h.HDoc_DR1_Num, ' Segun Factura #', h.HDoc_DR2_Num, ' A fecha ', h.HDoc_Doc_Fec) concepto, {tipo} tipo, h.HDoc_Doc_TC TC, '' observacion, h.HDoc_Usuario operador, 'C' estado, NOW() marca,'' grupo, {tipo} modo, h.HDoc_Doc_Cat refTipo, h.HDoc_Doc_Ano refCiclo, h.HDoc_Doc_Num refNumero, NULL divisa, h.HDoc_Doc_TC Tasa,0 revisado,'' usuarioRev, NULL ultRev "
            strsql &= "      FROM PDM.Dcmtos_HDR h "
            strsql &= "         WHERE h.HDoc_Sis_Emp = {empresa} AND h.HDoc_Doc_Cat = {cat} AND h.HDoc_Doc_Ano = {anio} AND h.HDoc_Doc_Num = {num} "
        End If
        strsql = Replace(strsql, "{ejercicio}", EJERCICIO)
        strsql = Replace(strsql, "{poliza}", poliza)
        strsql = Replace(strsql, "{empresa}", Sesion.IdEmpresa)
        strsql = Replace(strsql, "{cat}", cat)
        strsql = Replace(strsql, "{anio}", anio)
        strsql = Replace(strsql, "{num}", num)
        strsql = Replace(strsql, "{conta}", Sesion.BaseConta)
        strsql = Replace(strsql, "{fec}", fec.ToString(FORMATO_MYSQL))
        If TipoReten = 1 Then ' Reten Iva
            strsql = Replace(strsql, "{tipo}", 25)
        Else
            strsql = Replace(strsql, "{tipo}", 24)
        End If

        Return strsql

    End Function

    Private Function SQLDetalleRetencion(ByVal poliza As Integer, ByVal cat As Integer, ByVal anio As Integer, ByVal num As Integer, ByVal TipoReten As Integer, ByVal TipoFact As Integer, ByVal ctaCaja As String, Optional ByVal porcentaje As Double = 0, Optional ByVal intControl As Integer = 0)
        Dim strsql As String

        strsql = " INSERT INTO {conta}.detalle_polizas"
        strsql &= "   SELECT 0 Transaccion, h.HDoc_Sis_Emp empresa, {ejercicio} ejercicio, {poliza},1 item, {ctaContable} cuenta, 1 parametroCuenta, h.HDoc_RF1_Dbl importe, '' centroCosto, '' partidaPresupuestal, 'C' operacion, h.HDoc_Doc_Fec Fecha,0 clase, {tipo} modo, h.HDoc_Doc_Cat refTipo, h.HDoc_Doc_Ano refCiclo, h.HDoc_Doc_Num refNumero, 0 id "
        strsql &= "        From Dcmtos_HDR h "
        strsql &= "            Left JOIN Proveedores p ON p.pro_sisemp = h.HDoc_Sis_Emp AND p.pro_codigo = h.HDoc_Emp_Cod "
        strsql &= "                WHERE h.HDoc_Sis_Emp = {empresa} AND h.HDoc_Doc_Cat = {cat} AND h.HDoc_Doc_Ano = {anio} AND h.HDoc_Doc_Num = {num}  "
        strsql &= "                    UNION "
        'If Sesion.IdEmpresa = 18 Then
        '    strsql &= "                        Select 0, h.HDoc_Sis_Emp empresa, '{ejercicio}', '{poliza}',2 item, p.id_cuenta cuenta,1 parametroCuenta, h.HDoc_RF1_Dbl importe,'' centroCosto, '' partidaPresupuestal, 'A' operacion, h.HDoc_Doc_Fec Fecha,0 clase, {tipo} modo, h.HDoc_Doc_Cat refTipo, h.HDoc_Doc_Ano refCiclo, h.HDoc_Doc_Num refNumero, 0 id "
        'Else
        strsql &= "                        Select 0, h.HDoc_Sis_Emp empresa, '{ejercicio}', '{poliza}',2 item, p.valor cuenta,1 parametroCuenta, h.HDoc_RF1_Dbl importe,'' centroCosto, '' partidaPresupuestal, 'A' operacion, h.HDoc_Doc_Fec Fecha,0 clase, {tipo} modo, h.HDoc_Doc_Cat refTipo, h.HDoc_Doc_Ano refCiclo, h.HDoc_Doc_Num refNumero, 0 id "
        'End If
        strsql &= "                    From Dcmtos_HDR h "
        'If Sesion.IdEmpresa = 18 Then
        '    strsql &= "                  LEFT JOIN {conta}.cuentas p ON p.empresa = h.HDoc_Sis_Emp AND IF(h.HDoc_RF2_Dbl = 2, p.id_cuenta = '210602001',IF(h.HDoc_RF2_Dbl = 10,p.id_cuenta='210602002',IF(h.HDoc_RF2_Dbl =3,p.id_cuenta='210602003',IF(h.HDoc_RF2_Dbl = 15,p.id_cuenta='210602004',IF(h.HDoc_RF2_Dbl=13,p.id_cuenta='210602005',0)))))"
        'Else
        strsql &= "                Left JOIN {conta}.parametros_empresa p ON p.empresa = h.HDoc_Sis_Emp AND p.parametro = {fact} "
        'End If
        strsql &= "            WHERE h.HDoc_Sis_Emp = {empresa} AND h.HDoc_Doc_Cat = {cat} AND h.HDoc_Doc_Ano = {anio} AND h.HDoc_Doc_Num = {num} "

        If Sesion.IdEmpresa = 18 Then
            strsql &= "; INSERT INTO contapdm.detalle_polizas"
            strsql &= "   SELECT 0 Transaccion, h.HDoc_Sis_Emp empresa, {ejercicio} ejercicio, {poliza},1 item, {ctaContable} cuenta, 1 parametroCuenta, h.HDoc_RF1_Dbl importe, '' centroCosto, '' partidaPresupuestal, 'C' operacion, h.HDoc_Doc_Fec Fecha,0 clase, {tipo} modo, h.HDoc_Doc_Cat refTipo, h.HDoc_Doc_Ano refCiclo, h.HDoc_Doc_Num refNumero, 0 id "
            strsql &= "        From PDM.Dcmtos_HDR h "
            strsql &= "            Left JOIN PDM.Proveedores p ON p.pro_sisemp = h.HDoc_Sis_Emp AND p.pro_codigo = h.HDoc_Emp_Cod "
            strsql &= "                WHERE h.HDoc_Sis_Emp = {empresa} AND h.HDoc_Doc_Cat = {cat} AND h.HDoc_Doc_Ano = {anio} AND h.HDoc_Doc_Num = {num}  "
            strsql &= "                    UNION "
            strsql &= "                        Select 0, h.HDoc_Sis_Emp empresa, '{ejercicio}', '{poliza}',2 item, p.valor cuenta,1 parametroCuenta, h.HDoc_RF1_Dbl importe,'' centroCosto, '' partidaPresupuestal, 'A' operacion, h.HDoc_Doc_Fec Fecha,0 clase, {tipo} modo, h.HDoc_Doc_Cat refTipo, h.HDoc_Doc_Ano refCiclo, h.HDoc_Doc_Num refNumero, 0 id "
            strsql &= "                    From PDM.Dcmtos_HDR h "
            strsql &= "                Left JOIN contapdm.parametros_empresa p ON p.empresa = h.HDoc_Sis_Emp AND p.parametro = {fact} "
            strsql &= "            WHERE h.HDoc_Sis_Emp = {empresa} AND h.HDoc_Doc_Cat = {cat} AND h.HDoc_Doc_Ano = {anio} AND h.HDoc_Doc_Num = {num} "
        End If

        If ctaCaja = "N/A" Then
            strsql = Replace(strsql, "{ctaContable}", " p.pro_cuenta ")
        Else
            strsql = Replace(strsql, "{ctaContable}", "'" & ctaCaja & "'")
        End If

        strsql = Replace(strsql, "{empresa}", Sesion.IdEmpresa)
        strsql = Replace(strsql, "{cat}", cat)
        strsql = Replace(strsql, "{anio}", anio)
        strsql = Replace(strsql, "{num}", num)
        strsql = Replace(strsql, "{ejercicio}", EJERCICIO)
        strsql = Replace(strsql, "{poliza}", poliza)
        strsql = Replace(strsql, "{conta}", Sesion.BaseConta)
        If TipoReten = 1 Then ' 1 Reten Iva, 0 Reten ISR
            strsql = Replace(strsql, "{tipo}", 25)
            If TipoFact = 1 Then ' 1- Factura Especial, 0- Factura Normal
                strsql = Replace(strsql, "{fact}", 54)
            Else
                strsql = Replace(strsql, "{fact}", 55)
            End If
        Else
            strsql = Replace(strsql, "{tipo}", 24)
            If Sesion.IdEmpresa = 15 Or Sesion.IdEmpresa = 20 Then
                If porcentaje = 1 Then
                    strsql = Replace(strsql, "{fact}", 36)
                ElseIf porcentaje = 12.5 Then
                    strsql = Replace(strsql, "{fact}", 61)
                ElseIf porcentaje = 10 Then
                    strsql = Replace(strsql, "{fact}", 62)
                ElseIf porcentaje = 25 Then
                    strsql = Replace(strsql, "{fact}", 63)
                ElseIf porcentaje = 15 Then
                    strsql = Replace(strsql, "{fact}", 65)

                End If
            ElseIf Sesion.IdEmpresa = 18 Or Sesion.IdEmpresa = 19 Or Sesion.IdEmpresa = 21 Then
                If porcentaje = 2 Then
                    strsql = Replace(strsql, "{fact}", 36)
                ElseIf porcentaje = 10 Then
                    strsql = Replace(strsql, "{fact}", 62)
                ElseIf porcentaje = 3 Then
                    strsql = Replace(strsql, "{fact}", 61)
                ElseIf porcentaje = 15 And intControl = 1 Then
                    strsql = Replace(strsql, "{fact}", 64)
                ElseIf porcentaje = 15 Then
                    strsql = Replace(strsql, "{fact}", 63)
                ElseIf porcentaje = 20 Then
                    strsql = Replace(strsql, "{fact}", 65)
                End If
            Else
                If TipoFact = 1 Then ' 1- Factura Especial, 0- Factura Normal
                    strsql = Replace(strsql, "{fact}", 52)
                Else
                    strsql = Replace(strsql, "{fact}", 36)
                End If
            End If

        End If

        Return strsql
    End Function
#End Region

#Region "Retención IVA Cliente CMC"

    Private Function SQLEncabezadoRetencionIVACMC(ByVal poliza As Integer, ByVal cat As Integer, ByVal anio As Integer, ByVal num As Integer, ByVal fec As Date) ', ByVal TipoReten As Integer)
        Dim strsql As String = STR_VACIO

        strsql = " INSERT INTO {conta}.polizas"
        strsql &= "   SELECT h.HDoc_Sis_Emp empresa, {ejercicio} ejercicio, {poliza} poliza, '{fec}' fecha, CONCAT('REG. RETENCION DE IVA No. ', h.HDoc_DR1_Num, ' DEL DIA ', h.HDoc_Doc_Fec, ' CLIENTE ', h.HDoc_Emp_Nom, ' FACT. ', h.HDoc_RF1_Cod{FelCMC}) concepto, {tipo} tipo, h.HDoc_Doc_TC TC, '' observacion, h.HDoc_Usuario operador, 'C' estado, NOW() marca,'' grupo, {tipo} modo, h.HDoc_Doc_Cat refTipo, h.HDoc_Doc_Ano refCiclo, h.HDoc_Doc_Num refNumero, NULL divisa, h.HDoc_Doc_TC Tasa,0 revisado,'' usuarioRev, NULL ultRev "
        strsql &= "      FROM Dcmtos_HDR h "
        If Sesion.IdEmpresa = 10 Then
            strsql &= "      LEFT JOIN Fel f ON f.Empresa = h.HDoc_Sis_Emp AND f.Anio = h.HDoc_Doc_Ano AND f.Numero = h.HDoc_RF1_Cod AND f.Catalogo = 296 "
        End If
        strsql &= "         WHERE h.HDoc_Sis_Emp = {empresa} AND h.HDoc_Doc_Cat = {cat} AND h.HDoc_Doc_Ano = {anio} AND h.HDoc_Doc_Num = {num} "

        If Sesion.IdEmpresa = 18 Then
            strsql &= "; INSERT INTO contapdm.polizas"
            strsql &= "   SELECT h.HDoc_Sis_Emp empresa, {ejercicio} ejercicio, {poliza} poliza, '{fec}' fecha, CONCAT('REG. RETENCION DE IVA No. ', h.HDoc_DR1_Num, ' DEL DIA ', h.HDoc_Doc_Fec, ' CLIENTE ', h.HDoc_Emp_Nom, ' FACT. ', h.HDoc_RF1_Cod{FelCMC}) concepto, {tipo} tipo, h.HDoc_Doc_TC TC, '' observacion, h.HDoc_Usuario operador, 'C' estado, NOW() marca,'' grupo, {tipo} modo, h.HDoc_Doc_Cat refTipo, h.HDoc_Doc_Ano refCiclo, h.HDoc_Doc_Num refNumero, NULL divisa, h.HDoc_Doc_TC Tasa,0 revisado,'' usuarioRev, NULL ultRev "
            strsql &= "      FROM PDM.Dcmtos_HDR h "
            strsql &= "         WHERE h.HDoc_Sis_Emp = {empresa} AND h.HDoc_Doc_Cat = {cat} AND h.HDoc_Doc_Ano = {anio} AND h.HDoc_Doc_Num = {num} "
        End If

        strsql = Replace(strsql, "{ejercicio}", EJERCICIO)
        strsql = Replace(strsql, "{poliza}", poliza)
        strsql = Replace(strsql, "{empresa}", Sesion.IdEmpresa)
        strsql = Replace(strsql, "{cat}", cat)
        strsql = Replace(strsql, "{anio}", anio)
        strsql = Replace(strsql, "{num}", num)
        strsql = Replace(strsql, "{conta}", Sesion.BaseConta)
        strsql = Replace(strsql, "{tipo}", 27)
        strsql = Replace(strsql, "{fec}", fec.ToString(FORMATO_MYSQL))
        If Sesion.IdEmpresa = 10 Then
            strsql = Replace(strsql, "{FelCMC}", ",' FEL. ',f.NumeroAutorizacion")
        Else
            strsql = Replace(strsql, "{FelCMC}", "")
        End If


        Return strsql

    End Function

    Private Function SQLDetalleRetencionIVACMC(ByVal poliza As Integer, ByVal cat As Integer, ByVal anio As Integer, ByVal num As Integer, ByVal TipoReten As Integer, ByVal TipoFact As Integer)
        Dim strsql As String

        strsql = " INSERT INTO {conta}.detalle_polizas"
        strsql &= "     Select 0, h.HDoc_Sis_Emp empresa, '{ejercicio}', '{poliza}',1 item, p.valor cuenta,1 parametroCuenta, h.HDoc_RF1_Dbl importe,'' centroCosto, '' partidaPresupuestal, 'C' operacion, h.HDoc_Doc_Fec Fecha,0 clase, {tipo} modo, h.HDoc_Doc_Cat refTipo, h.HDoc_Doc_Ano refCiclo, h.HDoc_Doc_Num refNumero, 0 id "
        strsql &= "     From Dcmtos_HDR h "
        strsql &= "     Left JOIN {conta}.parametros_empresa p ON p.empresa = h.HDoc_Sis_Emp AND p.parametro = 28 "
        strsql &= "     WHERE h.HDoc_Sis_Emp = {empresa} AND h.HDoc_Doc_Cat = {cat} AND h.HDoc_Doc_Ano = {anio} AND h.HDoc_Doc_Num = {num} "
        strsql &= "         UNION "
        strsql &= "              SELECT 0 Transaccion, h.HDoc_Sis_Emp empresa, {ejercicio} ejercicio, {poliza},2 item, c.cli_cuenta cuenta, 1 parametroCuenta, h.HDoc_RF1_Dbl importe, '' centroCosto, '' partidaPresupuestal, 'A' operacion, h.HDoc_Doc_Fec Fecha,0 clase, {tipo} modo, h.HDoc_Doc_Cat refTipo, h.HDoc_Doc_Ano refCiclo, h.HDoc_Doc_Num refNumero, 0 id "
        strsql &= "              From Dcmtos_HDR h "
        strsql &= "              LEFT JOIN Clientes c ON c.cli_sisemp = h.HDoc_Sis_Emp AND c.cli_codigo = h.HDoc_Emp_Cod "
        strsql &= "              WHERE h.HDoc_Sis_Emp = {empresa} AND h.HDoc_Doc_Cat = {cat} AND h.HDoc_Doc_Ano = {anio} AND h.HDoc_Doc_Num = {num}  "

        If Sesion.IdEmpresa = 18 Then
            strsql &= "; INSERT INTO contapdm.detalle_polizas"
            strsql &= "     Select 0, h.HDoc_Sis_Emp empresa, '{ejercicio}', '{poliza}',1 item, p.valor cuenta,1 parametroCuenta, h.HDoc_RF1_Dbl importe,'' centroCosto, '' partidaPresupuestal, 'C' operacion, h.HDoc_Doc_Fec Fecha,0 clase, {tipo} modo, h.HDoc_Doc_Cat refTipo, h.HDoc_Doc_Ano refCiclo, h.HDoc_Doc_Num refNumero, 0 id "
            strsql &= "     From PDM.Dcmtos_HDR h "
            strsql &= "     Left JOIN contapdm.parametros_empresa p ON p.empresa = h.HDoc_Sis_Emp AND p.parametro = 28 "
            strsql &= "     WHERE h.HDoc_Sis_Emp = {empresa} AND h.HDoc_Doc_Cat = {cat} AND h.HDoc_Doc_Ano = {anio} AND h.HDoc_Doc_Num = {num} "
            strsql &= "         UNION "
            strsql &= "              SELECT 0 Transaccion, h.HDoc_Sis_Emp empresa, {ejercicio} ejercicio, {poliza},2 item, c.cli_cuenta cuenta, 1 parametroCuenta, h.HDoc_RF1_Dbl importe, '' centroCosto, '' partidaPresupuestal, 'A' operacion, h.HDoc_Doc_Fec Fecha,0 clase, {tipo} modo, h.HDoc_Doc_Cat refTipo, h.HDoc_Doc_Ano refCiclo, h.HDoc_Doc_Num refNumero, 0 id "
            strsql &= "              From PDM.Dcmtos_HDR h "
            strsql &= "              LEFT JOIN PDM.Clientes c ON c.cli_sisemp = h.HDoc_Sis_Emp AND c.cli_codigo = h.HDoc_Emp_Cod "
            strsql &= "              WHERE h.HDoc_Sis_Emp = {empresa} AND h.HDoc_Doc_Cat = {cat} AND h.HDoc_Doc_Ano = {anio} AND h.HDoc_Doc_Num = {num}  "
        End If

        strsql = Replace(strsql, "{empresa}", Sesion.IdEmpresa)
        strsql = Replace(strsql, "{cat}", cat)
        strsql = Replace(strsql, "{anio}", anio)
        strsql = Replace(strsql, "{num}", num)
        strsql = Replace(strsql, "{ejercicio}", EJERCICIO)
        strsql = Replace(strsql, "{poliza}", poliza)
        strsql = Replace(strsql, "{conta}", Sesion.BaseConta)
        strsql = Replace(strsql, "{tipo}", 27)

        Return strsql
    End Function

    Private Sub PolizaDeRetencionIVACMC(ByVal cat As Integer, ByVal anio As Integer, ByVal num As Integer, ByVal fec As Date)
        Dim longPolizas As Long = NO_FILA
        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader
        Dim strSQL As String = STR_VACIO
        Dim FacturaTipo As Integer
        Dim TipoReten As Integer

        Try
            strSQL = VerificarRetencion(cat, anio, num)
            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSQL, CON)
            REA = COM.ExecuteReader()

            If REA.HasRows Then
                Do While REA.Read
                    FacturaTipo = REA.GetInt32("FactEspecial")
                    TipoReten = REA.GetInt32("TipoReten")
                Loop

            End If

            strSQL = STR_VACIO

            longPolizas = NuevaPoliza()
            UltimaPoliza(longPolizas, EJERCICIO) ' actualiza la ultima poliza
            strSQL = SQLEncabezadoRetencionIVACMC(longPolizas, cat, anio, num, fec.ToString(FORMATO_MYSQL)) ', TipoReten)

            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSQL, CON)
            COM.ExecuteNonQuery()
            strSQL = STR_VACIO

            strSQL = SQLDetalleRetencionIVACMC(longPolizas, cat, anio, num, TipoReten, FacturaTipo)
            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSQL, CON)
            COM.ExecuteNonQuery()
            strSQL = STR_VACIO

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try

    End Sub
#End Region

#Region "Retención ISR Cliente CMC"

    Private Function SQLEncabezadoRetencionISRCMC(ByVal poliza As Integer, ByVal cat As Integer, ByVal anio As Integer, ByVal num As Integer, ByVal fec As Date) ', ByVal TipoReten As Integer)
        Dim strsql As String = STR_VACIO

        strsql = " INSERT INTO {conta}.polizas"
        strsql &= "   SELECT h.HDoc_Sis_Emp empresa, {ejercicio} ejercicio, {poliza} poliza, '{fec}' fecha, CONCAT('REG. RETENCION DE ISR No. ', h.HDoc_DR1_Num, ' DEL DIA ', h.HDoc_Doc_Fec, ' CLIENTE ', h.HDoc_Emp_Nom, ' FACT. ', h.HDoc_DR2_Num) concepto, {tipo} tipo, h.HDoc_Doc_TC TC, '' observacion, h.HDoc_Usuario operador, 'C' estado, NOW() marca,'' grupo, {tipo} modo, h.HDoc_Doc_Cat refTipo, h.HDoc_Doc_Ano refCiclo, h.HDoc_Doc_Num refNumero, NULL divisa, h.HDoc_Doc_TC Tasa,0 revisado,'' usuarioRev, NULL ultRev "
        strsql &= "      FROM Dcmtos_HDR h "
        strsql &= "         WHERE h.HDoc_Sis_Emp = {empresa} AND h.HDoc_Doc_Cat = {cat} AND h.HDoc_Doc_Ano = {anio} AND h.HDoc_Doc_Num = {num} "

        If Sesion.IdEmpresa = 18 Then
            strsql &= "; INSERT INTO contapdm.polizas"
            strsql &= "   SELECT h.HDoc_Sis_Emp empresa, {ejercicio} ejercicio, {poliza} poliza, '{fec}' fecha, CONCAT('REG. RETENCION DE ISR No. ', h.HDoc_DR1_Num, ' DEL DIA ', h.HDoc_Doc_Fec, ' CLIENTE ', h.HDoc_Emp_Nom, ' FACT. ', h.HDoc_DR2_Num) concepto, {tipo} tipo, h.HDoc_Doc_TC TC, '' observacion, h.HDoc_Usuario operador, 'C' estado, NOW() marca,'' grupo, {tipo} modo, h.HDoc_Doc_Cat refTipo, h.HDoc_Doc_Ano refCiclo, h.HDoc_Doc_Num refNumero, NULL divisa, h.HDoc_Doc_TC Tasa,0 revisado,'' usuarioRev, NULL ultRev "
            strsql &= "      FROM PDM.Dcmtos_HDR h "
            strsql &= "         WHERE h.HDoc_Sis_Emp = {empresa} AND h.HDoc_Doc_Cat = {cat} AND h.HDoc_Doc_Ano = {anio} AND h.HDoc_Doc_Num = {num} "
        End If

        strsql = Replace(strsql, "{ejercicio}", EJERCICIO)
        strsql = Replace(strsql, "{poliza}", poliza)
        strsql = Replace(strsql, "{empresa}", Sesion.IdEmpresa)
        strsql = Replace(strsql, "{cat}", cat)
        strsql = Replace(strsql, "{anio}", anio)
        strsql = Replace(strsql, "{num}", num)
        strsql = Replace(strsql, "{conta}", Sesion.BaseConta)
        strsql = Replace(strsql, "{tipo}", 28)
        strsql = Replace(strsql, "{fec}", fec.ToString(FORMATO_MYSQL))

        Return strsql

    End Function

    Private Function SQLDetalleRetencionISRCMC(ByVal poliza As Integer, ByVal cat As Integer, ByVal anio As Integer, ByVal num As Integer, ByVal TipoReten As Integer, ByVal TipoFact As Integer)
        Dim strsql As String

        strsql = " INSERT INTO {conta}.detalle_polizas"
        strsql &= "     Select 0, h.HDoc_Sis_Emp empresa, '{ejercicio}', '{poliza}',1 item, p.valor cuenta,1 parametroCuenta, h.HDoc_RF1_Dbl importe,'' centroCosto, '' partidaPresupuestal, 'C' operacion, h.HDoc_Doc_Fec Fecha,0 clase, {tipo} modo, h.HDoc_Doc_Cat refTipo, h.HDoc_Doc_Ano refCiclo, h.HDoc_Doc_Num refNumero, 0 id "
        strsql &= "     From Dcmtos_HDR h "
        strsql &= "     Left JOIN {conta}.parametros_empresa p ON p.empresa = h.HDoc_Sis_Emp AND p.parametro = 59 "
        strsql &= "     WHERE h.HDoc_Sis_Emp = {empresa} AND h.HDoc_Doc_Cat = {cat} AND h.HDoc_Doc_Ano = {anio} AND h.HDoc_Doc_Num = {num} "
        strsql &= "         UNION "
        strsql &= "              SELECT 0 Transaccion, h.HDoc_Sis_Emp empresa, {ejercicio} ejercicio, {poliza},2 item, c.cli_cuenta cuenta, 1 parametroCuenta, h.HDoc_RF1_Dbl importe, '' centroCosto, '' partidaPresupuestal, 'A' operacion, h.HDoc_Doc_Fec Fecha,0 clase, {tipo} modo, h.HDoc_Doc_Cat refTipo, h.HDoc_Doc_Ano refCiclo, h.HDoc_Doc_Num refNumero, 0 id "
        strsql &= "              From Dcmtos_HDR h "
        strsql &= "              LEFT JOIN Clientes c ON c.cli_sisemp = h.HDoc_Sis_Emp AND c.cli_codigo = h.HDoc_Emp_Cod "
        strsql &= "              WHERE h.HDoc_Sis_Emp = {empresa} AND h.HDoc_Doc_Cat = {cat} AND h.HDoc_Doc_Ano = {anio} AND h.HDoc_Doc_Num = {num}  "

        If Sesion.IdEmpresa = 18 Then
            strsql &= "; INSERT INTO contapdm.detalle_polizas"
            strsql &= "     Select 0, h.HDoc_Sis_Emp empresa, '{ejercicio}', '{poliza}',1 item, p.valor cuenta,1 parametroCuenta, h.HDoc_RF1_Dbl importe,'' centroCosto, '' partidaPresupuestal, 'C' operacion, h.HDoc_Doc_Fec Fecha,0 clase, {tipo} modo, h.HDoc_Doc_Cat refTipo, h.HDoc_Doc_Ano refCiclo, h.HDoc_Doc_Num refNumero, 0 id "
            strsql &= "     From PDM.Dcmtos_HDR h "
            strsql &= "     Left JOIN contapdm.parametros_empresa p ON p.empresa = h.HDoc_Sis_Emp AND p.parametro = 59 "
            strsql &= "     WHERE h.HDoc_Sis_Emp = {empresa} AND h.HDoc_Doc_Cat = {cat} AND h.HDoc_Doc_Ano = {anio} AND h.HDoc_Doc_Num = {num} "
            strsql &= "         UNION "
            strsql &= "              SELECT 0 Transaccion, h.HDoc_Sis_Emp empresa, {ejercicio} ejercicio, {poliza},2 item, c.cli_cuenta cuenta, 1 parametroCuenta, h.HDoc_RF1_Dbl importe, '' centroCosto, '' partidaPresupuestal, 'A' operacion, h.HDoc_Doc_Fec Fecha,0 clase, {tipo} modo, h.HDoc_Doc_Cat refTipo, h.HDoc_Doc_Ano refCiclo, h.HDoc_Doc_Num refNumero, 0 id "
            strsql &= "              From PDM.Dcmtos_HDR h "
            strsql &= "              LEFT JOIN PDM.Clientes c ON c.cli_sisemp = h.HDoc_Sis_Emp AND c.cli_codigo = h.HDoc_Emp_Cod "
            strsql &= "              WHERE h.HDoc_Sis_Emp = {empresa} AND h.HDoc_Doc_Cat = {cat} AND h.HDoc_Doc_Ano = {anio} AND h.HDoc_Doc_Num = {num}  "
        End If

        strsql = Replace(strsql, "{empresa}", Sesion.IdEmpresa)
        strsql = Replace(strsql, "{cat}", cat)
        strsql = Replace(strsql, "{anio}", anio)
        strsql = Replace(strsql, "{num}", num)
        strsql = Replace(strsql, "{ejercicio}", EJERCICIO)
        strsql = Replace(strsql, "{poliza}", poliza)
        strsql = Replace(strsql, "{conta}", Sesion.BaseConta)
        strsql = Replace(strsql, "{tipo}", 28)

        Return strsql
    End Function

    Private Sub PolizaDeRetencionISRCMC(ByVal cat As Integer, ByVal anio As Integer, ByVal num As Integer, ByVal fec As Date)
        Dim longPolizas As Long = NO_FILA
        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader
        Dim strSQL As String = STR_VACIO
        Dim FacturaTipo As Integer
        Dim TipoReten As Integer

        Try
            strSQL = VerificarRetencion(cat, anio, num)
            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSQL, CON)
            REA = COM.ExecuteReader()

            If REA.HasRows Then
                Do While REA.Read
                    FacturaTipo = REA.GetInt32("FactEspecial")
                    TipoReten = REA.GetInt32("TipoReten")
                Loop

            End If

            strSQL = STR_VACIO

            longPolizas = NuevaPoliza()
            UltimaPoliza(longPolizas, EJERCICIO) ' actualiza la ultima poliza
            strSQL = SQLEncabezadoRetencionISRCMC(longPolizas, cat, anio, num, fec.ToString(FORMATO_MYSQL)) ', TipoReten)

            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSQL, CON)
            COM.ExecuteNonQuery()
            strSQL = STR_VACIO

            strSQL = SQLDetalleRetencionISRCMC(longPolizas, cat, anio, num, TipoReten, FacturaTipo)
            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSQL, CON)
            COM.ExecuteNonQuery()
            strSQL = STR_VACIO

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try

    End Sub
#End Region

#Region "Poliza de Ingreso a Bodega"

    Private Sub PolizaIngresoABodega(ByVal cat As Integer, ByVal anio As Integer, ByVal num As Integer, ByVal fecha As Date)
        Dim longPolizas As Long = NO_FILA
        Dim COM As MySqlCommand
        'Dim REA As MySqlDataReader
        Dim strSQL As String = STR_VACIO
        Dim dblTC As Double
        Dim TipoIng As Integer
        Dim intTendidoImport As Integer = 0

        Try
            strSQL = " SELECT HDoc_DR1_Cat tipo FROM Dcmtos_HDR h "
            strSQL &= " WHERE h.HDoc_Sis_Emp = {empresa} And h.HDoc_Doc_Cat = 47 And h.HDoc_Doc_Ano = {anio} And h.HDoc_Doc_Num = {num} And h.HDoc_Doc_Status = 0 "
            strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
            strSQL = Replace(strSQL, "{anio}", anio)
            strSQL = Replace(strSQL, "{num}", num)

            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSQL, CON)
            TipoIng = COM.ExecuteScalar ' 0 Importación, 1 Devolución
            COM.Dispose()
            strSQL = STR_VACIO

            strSQL = " SELECT HDoc_RF1_Dbl tipo FROM Dcmtos_HDR h "
            strSQL &= " WHERE h.HDoc_Sis_Emp = {empresa} And h.HDoc_Doc_Cat = 47 And h.HDoc_Doc_Ano = {anio} And h.HDoc_Doc_Num = {num} And h.HDoc_Doc_Status = 0 "
            strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
            strSQL = Replace(strSQL, "{anio}", anio)
            strSQL = Replace(strSQL, "{num}", num)

            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSQL, CON)
            intTendidoImport = COM.ExecuteScalar ' 0 Importación, 1 Devolución
            COM.Dispose()
            strSQL = STR_VACIO

            If TipoIng > 1 Or intTendidoImport = 1 Then
                strSQL = " SELECT h.HDoc_Doc_TC FROM Dcmtos_HDR h "
            Else
                strSQL = " SELECT d.HDoc_Doc_TC FROM Dcmtos_HDR h "
            End If
            strSQL &= " Left JOIN Dcmtos_DTL_Pro p ON p.PDoc_Sis_Emp = h.HDoc_Sis_Emp AND p.PDoc_Chi_Cat = h.HDoc_Doc_Cat AND p.PDoc_Chi_Ano = h.HDoc_Doc_Ano AND p.PDoc_Chi_Num = h.HDoc_Doc_Num AND p.PDoc_Par_Cat = 180 "
            strSQL &= " Left JOIN Dcmtos_HDR d ON d.HDoc_Sis_Emp = p.PDoc_Sis_Emp AND d.HDoc_Doc_Cat = p.PDoc_Par_Cat AND d.HDoc_Doc_Ano = p.PDoc_Par_Ano AND d.HDoc_Doc_Num = p.PDoc_Par_Num "
            strSQL &= "    WHERE h.HDoc_Sis_Emp = {empresa} AND h.HDoc_Doc_Cat = 47 AND h.HDoc_Doc_Ano = {anio} AND h.HDoc_Doc_Num = {num} "
            strSQL &= "    GROUP BY h.HDoc_Doc_Cat, h.HDoc_Doc_Ano, h.HDoc_Doc_Num "

            strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
            strSQL = Replace(strSQL, "{anio}", anio)
            strSQL = Replace(strSQL, "{num}", num)

            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSQL, CON)
            dblTC = COM.ExecuteScalar
            strSQL = STR_VACIO

            longPolizas = NuevaPoliza()
            UltimaPoliza(longPolizas, EJERCICIO) ' actualiza la ultima poliza

            strSQL = SQLEncabezadoIngresoBodega(longPolizas, cat, anio, num, TipoIng, dblTC, fecha)
            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSQL, CON)
            COM.ExecuteNonQuery()
            strSQL = STR_VACIO

            If Sesion.IdEmpresa = 9 Then
                strSQL = sqlDetalleIngresoABodegaServi(cat, anio, num, longPolizas)
            Else
                strSQL = SQLDetalleIngresoBodega(longPolizas, cat, anio, num, TipoIng, dblTC, intTendidoImport)
            End If

            MyCnn.CONECTAR = strConexion & ";Allow User Variables=True"
            COM = New MySqlCommand(strSQL, CON)
            COM.ExecuteNonQuery()
            strSQL = STR_VACIO

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Function SQLEncabezadoIngresoBodega(ByVal poliza As Integer, ByVal cat As Integer, ByVal anio As Integer, ByVal num As Integer, ByVal TipoIng As Integer, ByVal TC As Double, ByVal fecha As Date)
        Dim strsql As String = STR_VACIO

        strsql = " INSERT INTO {conta}.polizas"
        strsql &= "   SELECT h.HDoc_Sis_Emp empresa, {ejercicio} ejercicio, {poliza} poliza, '{fec}' fecha, CONCAT('Para Registrar Ingreso a Bodega: ', h.HDoc_Doc_Num, ' de fecha ', h.HDoc_Doc_Fec) concepto, {tipoPoliza} tipo, {TC} TC, '' observacion, h.HDoc_Usuario operador, 'C' estado, NOW() marca,'' grupo, {tipoPoliza} modo, h.HDoc_Doc_Cat refTipo, h.HDoc_Doc_Ano refCiclo, h.HDoc_Doc_Num refNumero, NULL divisa, {TC} Tasa,0 revisado,'' usuarioRev, NULL ultRev "
        strsql &= "      FROM Dcmtos_HDR h "
        strsql &= "         WHERE h.HDoc_Sis_Emp = {empresa} AND h.HDoc_Doc_Cat = {cat} AND h.HDoc_Doc_Ano = {anio} AND h.HDoc_Doc_Num = {num} "
        If Sesion.IdEmpresa = 18 Then
            strsql &= "; INSERT INTO contapdm.polizas"
            strsql &= "   SELECT h.HDoc_Sis_Emp empresa, {ejercicio} ejercicio, {poliza} poliza, '{fec}' fecha, CONCAT('Para Registrar Ingreso a Bodega: ', h.HDoc_Doc_Num, ' de fecha ', h.HDoc_Doc_Fec) concepto, {tipoPoliza} tipo, {TC} TC, '' observacion, h.HDoc_Usuario operador, 'C' estado, NOW() marca,'' grupo, {tipoPoliza} modo, h.HDoc_Doc_Cat refTipo, h.HDoc_Doc_Ano refCiclo, h.HDoc_Doc_Num refNumero, NULL divisa, {TC} Tasa,0 revisado,'' usuarioRev, NULL ultRev "
            strsql &= "      FROM PDM.Dcmtos_HDR h "
            strsql &= "         WHERE h.HDoc_Sis_Emp = {empresa} AND h.HDoc_Doc_Cat = {cat} AND h.HDoc_Doc_Ano = {anio} AND h.HDoc_Doc_Num = {num} "
        End If
        If TipoIng = 0 Then
            strsql = Replace(strsql, "{tipoPoliza}", 11)
        Else
            strsql = Replace(strsql, "{tipoPoliza}", 12)
        End If
        strsql = Replace(strsql, "{ejercicio}", EJERCICIO)
        strsql = Replace(strsql, "{poliza}", poliza)
        strsql = Replace(strsql, "{empresa}", Sesion.IdEmpresa)
        strsql = Replace(strsql, "{cat}", cat)
        strsql = Replace(strsql, "{anio}", anio)
        strsql = Replace(strsql, "{num}", num)
        strsql = Replace(strsql, "{conta}", Sesion.BaseConta)
        strsql = Replace(strsql, "{TC}", TC)
        strsql = Replace(strsql, "{fec}", fecha.ToString(FORMATO_MYSQL))

        Return strsql
    End Function

    Private Function SQLDetalleIngresoBodega(ByVal db As String, ByVal conta As String, ByVal poliza As Integer, ByVal cat As Integer, ByVal anio As Integer, ByVal num As Integer, ByVal TipoIng As Integer, ByVal TC As Double, Optional intTendidoImport As Integer = 0)
        Dim strsql As String = STR_VACIO

        strsql = " SET @numero=0;  "
        strsql &= "INSERT INTO {conta}.detalle_polizas "
        strsql &= " SELECT l1.transaccion,l1.empresa,l1.ejercicio,l1.poliza,l1.item,l1.cuenta,l1.parametro_cuenta,l1.importe,l1.centro_costos,l1.partida_presupuestal,l1.operacion,l1.fecha,l1.clase,l1.modo,l1.ref_tipo,l1.ref_ciclo,l1.ref_numero,l1.ref_id
                    FROM ("
        strsql &= " SELECT 0 transaccion,h.HDoc_Sis_Emp empresa, {ejercicio} ejercicio, {poliza} poliza, @numero:=@numero+1 item, {contabilidad} cuenta, h.HDoc_DR1_Cat parametro_cuenta, ROUND(SUM(d.DDoc_Prd_QTY * d.DDoc_Prd_NET * {TC}),2) importe, {centroCosto} centro_costos, '' partida_presupuestal, 'C' operacion, CAST(CURDATE() AS CHAR) fecha, a.art_clase clase, {tipoPoliza} modo, h.HDoc_Doc_Cat ref_tipo, h.HDoc_Doc_Ano ref_ciclo, h.HDoc_Doc_Num ref_numero, 0 ref_id "
        strsql &= "    From {db}Dcmtos_HDR h "
        strsql &= "    Left JOIN {db}Dcmtos_DTL d ON d.DDoc_Sis_Emp = h.HDoc_Sis_Emp AND d.DDoc_Doc_Cat = h.HDoc_Doc_Cat AND d.DDoc_Doc_Ano = h.HDoc_Doc_Ano AND d.DDoc_Doc_Num = h.HDoc_Doc_Num "
        strsql &= "    Left JOIN {db}Inventarios i ON i.inv_sisemp = d.DDoc_Sis_Emp AND i.inv_numero = d.DDoc_Prd_Cod "
        strsql &= "    Left JOIN {db}Articulos a ON a.art_sisemp = i.inv_sisemp AND a.art_codigo = i.inv_artcodigo "
        If Sesion.idGiro = 2 Then
            strsql &= "                            LEFT JOIN {conta}.inventario_codigos v ON v.clase = a.art_clase AND v.empresa = a.art_sisemp AND (v.ejercicio = 0 OR v.ejercicio = 1)  "
        Else
            strsql &= "                             LEFT JOIN {db}Catalogos c ON c.cat_num = i.inv_lugarfab AND c.cat_clase ='Paises'"
            strsql &= "                            Left JOIN {conta}.inventario_codigos v ON v.clase = c.cat_sisemp AND (v.ejercicio = 0 OR v.ejercicio = 1)  "
        End If
        strsql &= "        WHERE h.HDoc_Sis_Emp = {empresa} AND h.HDoc_Doc_Cat = 47 AND h.HDoc_Doc_Ano = {anio} AND h.HDoc_Doc_Num ={num} "
        strsql &= "        GROUP BY a.art_clase, item ) l1
                            WHERE l1.empresa = {empresa} UNION "
        If Sesion.IdEmpresa = 12 Then
            strsql = Replace(strsql, "{contabilidad}", " IF(a.art_clase = 2950, '0101003010',IF(a.art_clase =416,'0101003008',v.inventario)) ")
        ElseIf Sesion.IdEmpresa = 11 Then
            strsql = Replace(strsql, "{contabilidad}", " IF(a.art_clase = 2906, '0101003010',IF(a.art_clase =416,'0101003008',IF(a.art_clase = 3076, '0101003014', v.inventario))) ")
        ElseIf Sesion.IdEmpresa = 14 Then
            strsql = Replace(strsql, "{contabilidad}", " IF(a.art_clase = 2359, '0101003010',IF(a.art_clase =416,'0101003008',v.inventario))  ")
        Else
            strsql = Replace(strsql, "{contabilidad}", " IF(a.art_clase = 330, '11050201',IF(a.art_clase =416,'11050106',IF(a.art_clase = 2306, '11050107',v.inventario))) ")
        End If

        If TipoIng = 0 Then
            strsql = Replace(strsql, "{tipoPoliza}", 11)
            strsql &= " Select 0 Transaccion,h.HDoc_Sis_Emp, {ejercicio},{poliza}, 2 AS `posicion`,{cuentacontable},0 parametro_cuenta, ROUND((SUM(d.DDoc_Prd_NET * d.DDoc_Prd_QTY)* {TC}),2) importe,'' centro_costos, '' partida_presupuestal,'A',h.HDoc_Doc_Fec,'',11 modo,h.HDoc_Doc_Cat,h.HDoc_Doc_Ano, h.HDoc_Doc_Num,0 "
            strsql &= "    From {db}Dcmtos_HDR h "
            strsql &= "    Left JOIN {db}Dcmtos_DTL d ON d.DDoc_Sis_Emp = h.HDoc_Sis_Emp AND d.DDoc_Doc_Cat = h.HDoc_Doc_Cat AND d.DDoc_Doc_Ano = h.HDoc_Doc_Ano AND d.DDoc_Doc_Num = h.HDoc_Doc_Num "
            strsql &= "    Left JOIN {db}Proveedores p ON p.pro_sisemp = h.HDoc_Sis_Emp AND p.pro_codigo = h.HDoc_Emp_Cod "
            strsql &= "        WHERE h.HDoc_Sis_Emp = {empresa} AND h.HDoc_Doc_Cat = 47 AND h.HDoc_Doc_Ano = {anio} AND h.HDoc_Doc_Num = {num} AND h.HDoc_Doc_Status = 0  "
        Else
            'CUENTA DE PARAMETRO PARA INGRESO DE DEVOLUCION
            strsql = Replace(strsql, "{tipoPoliza}", 12)
            strsql &= " SELECT 0 transaccion,h.HDoc_Sis_Emp empresa, {ejercicio} ejercicio, {poliza} poliza, 1 item, {contabilidad} cuenta, h.HDoc_DR1_Cat parametro_cuenta, ROUND(SUM(d.DDoc_Prd_QTY * d.DDoc_Prd_NET * {TC}),2) importe, {centroCosto} centro_costos, '' partida_presupuestal, 'A' operacion, CAST(CURDATE() AS CHAR) fecha, a.art_clase clase, 12 modo, h.HDoc_Doc_Cat ref_tipo, h.HDoc_Doc_Ano ref_ciclo, h.HDoc_Doc_Num ref_numero, 0 ref_id "
            strsql &= "    From {db}Dcmtos_HDR h "
            strsql &= "    Left JOIN {db}Dcmtos_DTL d ON d.DDoc_Sis_Emp = h.HDoc_Sis_Emp AND d.DDoc_Doc_Cat = h.HDoc_Doc_Cat AND d.DDoc_Doc_Ano = h.HDoc_Doc_Ano AND d.DDoc_Doc_Num = h.HDoc_Doc_Num "
            strsql &= "    Left JOIN {db}Inventarios i ON i.inv_sisemp = d.DDoc_Sis_Emp AND i.inv_numero = d.DDoc_Prd_Cod "
            strsql &= "    Left JOIN {db}Articulos a ON a.art_sisemp = i.inv_sisemp AND a.art_codigo = i.inv_artcodigo "
            If Sesion.idGiro = 2 Then
                strsql &= "                            LEFT JOIN {conta}.inventario_codigos v ON v.clase = a.art_clase AND v.empresa = a.art_sisemp AND (v.ejercicio = 0 OR v.ejercicio = 1) "
            Else
                strsql &= "                             LEFT JOIN {db}Catalogos c ON c.cat_num = i.inv_lugarfab AND c.cat_clase ='Paises'"
                strsql &= "                            Left JOIN {conta}.inventario_codigos v ON v.clase = c.cat_sisemp AND (v.ejercicio = 0 OR v.ejercicio = 1) "
            End If
            strsql &= "        WHERE h.HDoc_Sis_Emp = {empresa} AND h.HDoc_Doc_Cat = 47 AND h.HDoc_Doc_Ano = {anio} AND h.HDoc_Doc_Num ={num} "
            strsql &= "        GROUP BY a.art_clase "
            If Sesion.IdEmpresa = 12 Then
                strsql = Replace(strsql, "{contabilidad}", " IF(a.art_clase = 2950, '0501010',IF(a.art_clase =416,'0501008',v.costo)) ")
            ElseIf Sesion.IdEmpresa = 11 Then
                strsql = Replace(strsql, "{contabilidad}", " IF(a.art_clase = 2906, '0501010',IF(a.art_clase =416,'0501008',v.costo)) ")
            ElseIf Sesion.IdEmpresa = 14 Then
                strsql = Replace(strsql, "{contabilidad}", " IF(a.art_clase = 2359, '0501010',IF(a.art_clase =416,'0501008',v.costo))  ")
            Else
                strsql = Replace(strsql, "{contabilidad}", " IF(a.art_clase = 330, '51010201',IF(a.art_clase =416,'51010306',v.costo)) ")
            End If
        End If

        If Sesion.idGiro = 1 Then
            strsql = Replace(strsql, "{centroCosto}", "12")
        Else
            strsql = Replace(strsql, "{centroCosto}", "0")
        End If
        If intTendidoImport = 1 Then
            strsql = Replace(strsql, "{cuentacontable}", "'210201098'")
        Else
            strsql = Replace(strsql, "{cuentacontable}", "p.pro_cuenta")
        End If
        strsql = Replace(strsql, "{empresa}", Sesion.IdEmpresa)
        strsql = Replace(strsql, "{conta}", conta)
        strsql = Replace(strsql, "{ejercicio}", EJERCICIO)
        strsql = Replace(strsql, "{poliza}", poliza)
        strsql = Replace(strsql, "{cat}", cat)
        strsql = Replace(strsql, "{anio}", anio)
        strsql = Replace(strsql, "{num}", num)
        strsql = Replace(strsql, "{TC}", TC)
        strsql = Replace(strsql, "{db}", db)

        Return strsql
    End Function

    Private Function SQLDetalleIngresoBodega(ByVal poliza As Integer, ByVal cat As Integer, ByVal anio As Integer, ByVal num As Integer, ByVal TipoIng As Integer, ByVal TC As Double, Optional intTendidoImport As Integer = 0)
        Dim strsql As String = SQLDetalleIngresoBodega(STR_VACIO, Sesion.BaseConta, poliza, cat, anio, num, TipoIng, TC, intTendidoImport)

        If Sesion.IdEmpresa = 18 Then
            strsql = String.Concat(strsql, ";", SQLDetalleIngresoBodega("PDM.", "contapdm", poliza, cat, anio, num, TipoIng, TC, intTendidoImport))
        End If

        Return strsql
    End Function

    Private Function sqlDetalleIngresoABodegaServi(ByVal cat As Integer, ByVal ano As Integer, ByVal num As Integer, ByVal poliza As Integer)
        Dim strSQl As String = STR_VACIO
        Dim item As Integer = 1

        strSQl = "   INSERT INTO {conta}.detalle_polizas "

        strSQl &= " Select 0 transaccion,h.HDoc_Sis_Emp empresa, {ejercicio} ejercicio, {poliza} poliza, " & item & ", v.inventario cuenta, h.HDoc_DR1_Cat parametro_cuenta, ROUND(SUM(d.DDoc_Prd_QTY * d.DDoc_Prd_NET * h.HDoc_Doc_TC) {iva},2) importe,'' centro_costos, '' partida_presupuestal, 'C' operacion, (CURDATE() ) fecha, a.art_clase clase, 11 modo, h.HDoc_Doc_Cat ref_tipo, h.HDoc_Doc_Ano ref_ciclo, h.HDoc_Doc_Num ref_numero, d.DDoc_Prd_Cod ref_id "
        strSQl &= "     From Dcmtos_HDR h "
        strSQl &= "     Left JOIN Dcmtos_DTL d ON d.DDoc_Sis_Emp = h.HDoc_Sis_Emp AND d.DDoc_Doc_Cat = h.HDoc_Doc_Cat AND d.DDoc_Doc_Ano = h.HDoc_Doc_Ano AND d.DDoc_Doc_Num = h.HDoc_Doc_Num "
        strSQl &= "     Left JOIN Inventarios i ON i.inv_sisemp = d.DDoc_Sis_Emp AND i.inv_numero = d.DDoc_Prd_Cod "
        strSQl &= "     Left JOIN Articulos a ON a.art_sisemp = i.inv_sisemp AND a.art_codigo = i.inv_artcodigo "
        strSQl &= "     Left JOIN {conta}.inventario_codigos v ON v.clase = a.art_clase AND v.empresa = a.art_sisemp "
        strSQl &= "          WHERE h.HDoc_Sis_Emp = {empresa} AND h.HDoc_Doc_Cat = {catalogo} AND h.HDoc_Doc_Ano = {ano} AND h.HDoc_Doc_Num ={numero} "
        strSQl &= "          GROUP BY a.art_clase "

        item = item + 1
        strSQl &= " UNION " ' SEGUNDA LINEA QUE MUESTRA LA CUENTA DE IVA
        strSQl &= " Select 0,'{empresa}',{ejercicio},{poliza}," & item & " item, e.valor cuenta, 1 parametro_cuenta, ROUND((d.DDoc_Prd_Net * DDoc_Prd_QTY * h.HDoc_Doc_TC) - ((d.DDoc_Prd_Net * DDoc_Prd_QTY * h.HDoc_Doc_TC) {iva}),2) importe, '' centro_Costo, NULL partida_Presupuestal, 'C' operacion, h.HDoc_Doc_Fec, 9 clase, 11 modo, h.HDoc_Doc_Cat tipo, h.HDoc_Doc_Ano cilco, h.HDoc_Doc_Num num,0 id "
        strSQl &= "     From Dcmtos_HDR h "
        strSQl &= "     Left JOIN Dcmtos_DTL d ON d.DDoc_Sis_Emp = h.HDoc_Sis_Emp AND d.DDoc_Doc_Cat = h.HDoc_Doc_Cat AND d.DDoc_Doc_Ano = h.HDoc_Doc_Ano AND d.DDoc_Doc_Num = h.HDoc_Doc_Num "
        strSQl &= "     Left JOIN {conta}.parametros_empresa e ON e.empresa = d.DDoc_Sis_Emp AND e.parametro = 28"
        strSQl &= "     WHERE h.HDoc_Sis_Emp = {empresa} AND h.HDoc_Doc_Cat = {catalogo} AND h.HDoc_Doc_Ano = {ano} AND h.HDoc_Doc_Num = {numero} "

        item = item + 1

        strSQl &= " UNION SELECT 0,h.HDoc_Sis_Emp, {ejercicio}, {poliza}, {id},p.pro_cuenta, h.HDoc_DR1_Cat, ROUND(SUM(d.DDoc_Prd_QTY * d.DDoc_Prd_NET * h.HDoc_Doc_TC)-(ROUND((SUM(d.DDoc_Prd_DSQ * h.HDoc_Doc_TC)),2)),2) monto,'' centroCosto, '' Partida_Pres, 'A', CAST(CURDATE() AS CHAR) fecha, 9 clase, 11, h.HDoc_Doc_Cat, h.HDoc_Doc_Ano, h.HDoc_Doc_Num, 0 ref_id "
        strSQl &= "    From Dcmtos_HDR h "
        strSQl &= "        Left JOIN Proveedores p ON p.pro_sisemp= h.HDoc_Sis_Emp AND p.pro_codigo = h.HDoc_Emp_Cod "
        strSQl &= "            Left JOIN Dcmtos_DTL d ON d.DDoc_Sis_Emp = h.HDoc_Sis_Emp AND d.DDoc_Doc_Cat = h.HDoc_Doc_Cat AND d.DDoc_Doc_Ano = h.HDoc_Doc_Ano AND d.DDoc_Doc_Num = h.HDoc_Doc_Num "
        strSQl &= "                WHERE h.HDoc_Sis_Emp = {empresa} AND h.HDoc_Doc_Cat = {catalogo} AND h.HDoc_Doc_Ano = {ano} AND h.HDoc_Doc_Num ={numero} "
        strSQl = Replace(strSQl, "{iva}", " / (((SELECT cat_sist IVA FROM Catalogos c WHERE c.cat_clase = 'Impuestos' AND c.cat_clave ='IVA' AND c.cat_sisemp = {empresa})/100)+1) ")

        If Sesion.IdEmpresa = 18 Then
            item = 1
            strSQl &= ";   INSERT INTO contapdm.detalle_polizas "

            strSQl &= " Select 0 transaccion,h.HDoc_Sis_Emp empresa, {ejercicio} ejercicio, {poliza} poliza, " & item & ", v.inventario cuenta, h.HDoc_DR1_Cat parametro_cuenta, ROUND(SUM(d.DDoc_Prd_QTY * d.DDoc_Prd_NET * h.HDoc_Doc_TC) {iva},2) importe,'' centro_costos, '' partida_presupuestal, 'C' operacion, (CURDATE() ) fecha, a.art_clase clase, 11 modo, h.HDoc_Doc_Cat ref_tipo, h.HDoc_Doc_Ano ref_ciclo, h.HDoc_Doc_Num ref_numero, d.DDoc_Prd_Cod ref_id "
            strSQl &= "     From PDM.Dcmtos_HDR h "
            strSQl &= "     Left JOIN PDM.Dcmtos_DTL d ON d.DDoc_Sis_Emp = h.HDoc_Sis_Emp AND d.DDoc_Doc_Cat = h.HDoc_Doc_Cat AND d.DDoc_Doc_Ano = h.HDoc_Doc_Ano AND d.DDoc_Doc_Num = h.HDoc_Doc_Num "
            strSQl &= "     Left JOIN PDM.Inventarios i ON i.inv_sisemp = d.DDoc_Sis_Emp AND i.inv_numero = d.DDoc_Prd_Cod "
            strSQl &= "     Left JOIN PDM.Articulos a ON a.art_sisemp = i.inv_sisemp AND a.art_codigo = i.inv_artcodigo "
            strSQl &= "     Left JOIN contapdm.inventario_codigos v ON v.clase = a.art_clase AND v.empresa = a.art_sisemp "
            strSQl &= "          WHERE h.HDoc_Sis_Emp = {empresa} AND h.HDoc_Doc_Cat = {catalogo} AND h.HDoc_Doc_Ano = {ano} AND h.HDoc_Doc_Num ={numero} "
            strSQl &= "          GROUP BY a.art_clase "

            item = item + 1
            strSQl &= " UNION " ' SEGUNDA LINEA QUE MUESTRA LA CUENTA DE IVA
            strSQl &= " Select 0,'{empresa}',{ejercicio},{poliza}," & item & " item, e.valor cuenta, 1 parametro_cuenta, ROUND((d.DDoc_Prd_Net * DDoc_Prd_QTY * h.HDoc_Doc_TC) - ((d.DDoc_Prd_Net * DDoc_Prd_QTY * h.HDoc_Doc_TC) {iva}),2) importe, '' centro_Costo, NULL partida_Presupuestal, 'C' operacion, h.HDoc_Doc_Fec, 9 clase, 11 modo, h.HDoc_Doc_Cat tipo, h.HDoc_Doc_Ano cilco, h.HDoc_Doc_Num num,0 id "
            strSQl &= "     From PDM.Dcmtos_HDR h "
            strSQl &= "     Left JOIN PDM.Dcmtos_DTL d ON d.DDoc_Sis_Emp = h.HDoc_Sis_Emp AND d.DDoc_Doc_Cat = h.HDoc_Doc_Cat AND d.DDoc_Doc_Ano = h.HDoc_Doc_Ano AND d.DDoc_Doc_Num = h.HDoc_Doc_Num "
            strSQl &= "     Left JOIN contapdm.parametros_empresa e ON e.empresa = d.DDoc_Sis_Emp AND e.parametro = 28"
            strSQl &= "     WHERE h.HDoc_Sis_Emp = {empresa} AND h.HDoc_Doc_Cat = {catalogo} AND h.HDoc_Doc_Ano = {ano} AND h.HDoc_Doc_Num = {numero} "

            item = item + 1

            strSQl &= " UNION SELECT 0,h.HDoc_Sis_Emp, {ejercicio}, {poliza}, {id},p.pro_cuenta, h.HDoc_DR1_Cat, ROUND(SUM(d.DDoc_Prd_QTY * d.DDoc_Prd_NET * h.HDoc_Doc_TC)-(ROUND((SUM(d.DDoc_Prd_DSQ * h.HDoc_Doc_TC)),2)),2) monto,'' centroCosto, '' Partida_Pres, 'A', CAST(CURDATE() AS CHAR) fecha, 9 clase, 11, h.HDoc_Doc_Cat, h.HDoc_Doc_Ano, h.HDoc_Doc_Num, 0 ref_id "
            strSQl &= "    From PDM.Dcmtos_HDR h "
            strSQl &= "        Left JOIN PDM.Proveedores p ON p.pro_sisemp= h.HDoc_Sis_Emp AND p.pro_codigo = h.HDoc_Emp_Cod "
            strSQl &= "            Left JOIN PDM.Dcmtos_DTL d ON d.DDoc_Sis_Emp = h.HDoc_Sis_Emp AND d.DDoc_Doc_Cat = h.HDoc_Doc_Cat AND d.DDoc_Doc_Ano = h.HDoc_Doc_Ano AND d.DDoc_Doc_Num = h.HDoc_Doc_Num "
            strSQl &= "                WHERE h.HDoc_Sis_Emp = {empresa} AND h.HDoc_Doc_Cat = {catalogo} AND h.HDoc_Doc_Ano = {ano} AND h.HDoc_Doc_Num ={numero} "
            strSQl = Replace(strSQl, "{iva}", " / (((SELECT cat_sist IVA FROM PDM.Catalogos c WHERE c.cat_clase = 'Impuestos' AND c.cat_clave ='IVA' AND c.cat_sisemp = {empresa})/100)+1) ")
        End If

        strSQl = Replace(strSQl, "{empresa}", Sesion.IdEmpresa)
        strSQl = Replace(strSQl, "{catalogo}", cat)
        strSQl = Replace(strSQl, "{ano}", ano)
        strSQl = Replace(strSQl, "{numero}", num)
        strSQl = Replace(strSQl, "{ejercicio}", EJERCICIO)
        strSQl = Replace(strSQl, "{poliza}", poliza)
        strSQl = Replace(strSQl, "{conta}", cFunciones.ContaEmpresa)
        strSQl = Replace(strSQl, "{id}", item)

        Return strSQl

    End Function

#End Region

#Region "Depreciaciones"

    Private Function GuardarEncabezadoDepreciacion(ByVal poliza As Integer, ByVal cat As Integer, ByVal anio As Integer, ByVal num As Integer, ByVal fecha As Date) As Boolean
        Dim logresultado As Boolean = False
        Dim TP As New TPOLIZAS
        Try
            TP.EMPRESA = Sesion.IdEmpresa
            TP.EJERCICIO = EJERCICIO
            TP.POLIZA = poliza
            TP.fecha_NET = fecha
            TP.CONCEPTO = " Poliza de Depreciacion Mes " & cFunciones.MesALetras(fecha.Month) & ", Año " & fecha.Year
            TP.TIPO = 23
            TP.TIPO_CAMBIO = INT_UNO
            TP.OBSERVACIONES = STR_VACIO
            TP.OPERADOR = Sesion.Usuario
            TP.ESTADO = "C"
            TP.marca_NET = Now()
            TP.GRUPO = STR_VACIO
            TP.MODO = 23
            TP.REF_TIPO = cat
            TP.REF_CICLO = anio
            TP.REF_NUMERO = num
            TP.DIVISA = NO_FILA
            TP.TASA = INT_UNO
            TP.REVISADO = INT_CERO
            TP.USUARIO_REV = STR_VACIO

            TP.CONEXION = strConexion
            If TP.Guardar = False Then
                MsgBox(TP.MERROR.ToString)
            Else
                logresultado = True
            End If
            TP.Dispose()
            TP = Nothing

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        Return logresultado
    End Function

    Private Function SqlDetalleDepreciacion(ByVal poliza As Integer, ByVal cat As Integer, ByVal anio As Integer, ByVal num As Integer, ByVal fecha As Date) As String
        Dim strsql As String = STR_VACIO
        Try
            strsql = " insert into {conta}.detalle_polizas
                        SELECT 0,{empresa}, {ejercicio} , {poliza} , (@fila:=@fila+1) as linea , t.Cta_Depreciacion , 1, sum(d.dep_monto), '{centroCosto}' ,
                            NULL, if(d.dep_monto >0 , 'C','A') operacion,  curdate(), 0,23,{cat},{ano},{num},0
                        FROM (SELECT @fila:=0) r, Activos a
                            LEFT JOIN Depreciaciones d ON d.dep_empresa = a.Empresa AND d.dep_codigo = a.Codigo
                            LEFT JOIN Tipos_Activo t ON t.Empresa = a.Empresa AND t.Codigo = a.Id_Tipo
                        WHERE a.Empresa = {empresa} AND (d.dep_fecha <= '{fecha}' AND d.dep_estado = 0)
                        GROUP BY t.Codigo , operacion
                       UNION
                        SELECT 0,{empresa}, {ejercicio} , {poliza} ,  (@fila:=@fila+1) as linea , t.Cta_Acumulada  , 1, sum(d.dep_monto), ' ' , NULL, if(d.dep_monto >0 , 'A','C') operacion,  curdate(), 0,23,{cat},{ano},{num},0
                        FROM (SELECT @fila:=0) r, Activos a
                            LEFT JOIN Depreciaciones d ON d.dep_empresa = a.Empresa AND d.dep_codigo = a.Codigo
                            LEFT JOIN Tipos_Activo t ON t.Empresa = a.Empresa AND t.Codigo = a.Id_Tipo
                        WHERE a.Empresa = {empresa} AND (d.dep_fecha <= '{fecha}' AND d.dep_estado = 0)
                        GROUP BY t.Codigo , operacion "
            If Sesion.IdEmpresa = 18 Then
                strsql &= "; insert into contapdm.detalle_polizas
                        SELECT 0,{empresa}, {ejercicio} , {poliza} , (@fila:=@fila+1) as linea , t.Cta_Depreciacion , 1, sum(d.dep_monto), '{centroCosto}' ,
                            NULL, if(d.dep_monto >0 , 'C','A') operacion,  curdate(), 0,23,{cat},{ano},{num},0
                        FROM (SELECT @fila:=0) r, Activos a
                            LEFT JOIN PDM.Depreciaciones d ON d.dep_empresa = a.Empresa AND d.dep_codigo = a.Codigo
                            LEFT JOIN PDM.Tipos_Activo t ON t.Empresa = a.Empresa AND t.Codigo = a.Id_Tipo
                        WHERE a.Empresa = {empresa} AND (d.dep_fecha <= '{fecha}' AND d.dep_estado = 0)
                        GROUP BY t.Codigo , operacion
                       UNION
                        SELECT 0,{empresa}, {ejercicio} , {poliza} ,  (@fila:=@fila+1) as linea , t.Cta_Acumulada  , 1, sum(d.dep_monto), ' ' , NULL, if(d.dep_monto >0 , 'A','C') operacion,  curdate(), 0,23,{cat},{ano},{num},0
                        FROM (SELECT @fila:=0) r, Activos a
                            LEFT JOIN PDM.Depreciaciones d ON d.dep_empresa = a.Empresa AND d.dep_codigo = a.Codigo
                            LEFT JOIN PDM.Tipos_Activo t ON t.Empresa = a.Empresa AND t.Codigo = a.Id_Tipo
                        WHERE a.Empresa = {empresa} AND (d.dep_fecha <= '{fecha}' AND d.dep_estado = 0)
                        GROUP BY t.Codigo , operacion "
            End If

            strsql = strsql.Replace("{empresa}", Sesion.IdEmpresa)
            strsql = strsql.Replace("{ejercicio}", EJERCICIO)
            strsql = strsql.Replace("{poliza}", poliza)
            strsql = strsql.Replace("{cat}", cat)
            strsql = strsql.Replace("{ano}", anio)
            strsql = strsql.Replace("{num}", num)
            strsql = strsql.Replace("{fecha}", fecha.ToString(FORMATO_MYSQL))
            strsql = Replace(strsql, "{conta}", Sesion.BaseConta)
            If Sesion.idGiro = 1 Then
                strsql = strsql.Replace("{centroCosto}", "4")
            Else
                strsql = strsql.Replace("{centroCosto}", " ")
            End If

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        Return strsql
    End Function

    Private Function PolizaDepeciacion(ByVal cat As Integer, ByVal anio As Integer, ByVal num As Integer, ByVal fecha As Date) As Boolean
        Dim longPolizas As Long = NO_FILA
        Dim logResultado As Boolean = False
        Dim COM As MySqlCommand
        Dim strSQL As String = STR_VACIO
        Try
            strSQL = STR_VACIO

            longPolizas = NuevaPoliza()
            UltimaPoliza(longPolizas, EJERCICIO) ' actualiza la ultima poliza

            If GuardarEncabezadoDepreciacion(longPolizas, cat, anio, num, fecha:=fecha) = True Then
                strSQL = SqlDetalleDepreciacion(longPolizas, cat, anio, num, fecha:=fecha)
                MyCnn.CONECTAR = strConexion & ";Allow User Variables=True"
                COM = New MySqlCommand(strSQL, CON)
                COM.ExecuteNonQuery()
                strSQL = STR_VACIO
                logResultado = True
            End If

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        Return logResultado
    End Function
#End Region

#Region "Cierres y Aperturas"

    Private Function VerificarEjercicioActual() As Boolean
        Dim LogResultado As Boolean = False
        Dim strSQL As String = STR_VACIO
        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader
        Try
            strSQL = "SELECT e.ejercicio Ejercicio, e.descripcion Descripcion, e.inicio Inicio, e.fin Fin, e.anterior Anterior  
                        FROM {conta}.ejercicios e  
                      WHERE e.ejercicio = 
                                (SELECT pe.valor 
                                FROM {conta}.parametros_empresa pe 
                                WHERE pe.empresa = {empresa} AND pe.parametro = 3 LIMIT 1)
                        LIMIT 1  "

            strSQL = strSQL.Replace("{conta}", Sesion.BaseConta)
            strSQL = strSQL.Replace("{empresa}", Sesion.IdEmpresa)
            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSQL, CON)
            REA = COM.ExecuteReader
            If REA.HasRows Then
                Do While REA.Read
                    EJERCICIO = REA.GetInt32("Ejercicio")
                    Cierres.Actual.EjercicioActual = REA.GetInt32("Ejercicio")
                    Cierres.Actual.Descripcion = REA.GetString("Descripcion")
                    Cierres.Actual.EjercicioAnterior = REA.GetInt32("Anterior")
                    Cierres.Actual.FechaInicio = REA.GetMySqlDateTime("Inicio")
                    Cierres.Actual.FechaFin = REA.GetMySqlDateTime("Fin")
                    LogResultado = True
                Loop
            End If

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        Return LogResultado
    End Function

    Private Function VerificarEjercicioSiguiente() As Boolean
        Dim logResultado As Boolean = False
        Dim strSQL As String = STR_VACIO
        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader
        Try
            strSQL = "SELECT e.ejercicio Ejercicio, e.descripcion Descripcion, e.inicio Inicio, e.fin Fin, e.anterior Anterior
                         FROM {conta}.ejercicios e WHERE e.anterior = {Actual}  "

            strSQL = strSQL.Replace("{conta}", Sesion.BaseConta)
            strSQL = strSQL.Replace("{Actual}", Cierres.Actual.EjercicioActual)
            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSQL, CON)
            REA = COM.ExecuteReader
            If REA.HasRows Then
                Do While REA.Read
                    Cierres.Siguiente.EjercicioActual = REA.GetInt32("Ejercicio")
                    Cierres.Siguiente.Descripcion = REA.GetString("Descripcion")
                    Cierres.Siguiente.EjercicioAnterior = REA.GetInt32("Anterior")
                    Cierres.Siguiente.FechaInicio = REA.GetMySqlDateTime("Inicio")
                    Cierres.Siguiente.FechaFin = REA.GetMySqlDateTime("Fin")
                    logResultado = True
                Loop
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        Return logResultado
    End Function

    Private Function VerificarFechaDeCierre() As Boolean
        Dim logResultado As Boolean = True
        Dim Hoy As Date
        Dim strSQL As String = STR_VACIO
        Dim COM As MySqlCommand
        Try
            strSQL = " SELECT CURDATE() "
            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSQL, CON)
            Hoy = COM.ExecuteScalar
            If Hoy < Cierres.Actual.FechaFin Then
                Return False
                Exit Function
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        Return logResultado
    End Function

    Private Function VerificarCuentasNoValidas() As Boolean
        Dim logResultado As Boolean = True
        Dim strSQL As String = STR_VACIO
        Dim strMensaje As String = STR_VACIO
        Dim strPolizas As String = STR_VACIO
        Dim frm As New frmMensaje
        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader
        Try
            frm.Mensaje = " Verificando Cuentas... "
            frm.Show()
            system.Windows.Forms.Application.DoEvents()
            strSQL = " SELECT p.poliza Poliza, p.fecha Fecha, d.cuenta, c.id_cuenta
                        FROM {conta}.polizas p
                            LEFT JOIN {conta}.detalle_polizas d ON p.empresa = d.empresa AND p.ejercicio = d.ejercicio AND p.poliza = d.poliza
                            LEFT JOIN {conta}.cuentas c ON d.empresa = c.empresa AND d.cuenta = c.id_cuenta
                        WHERE p.empresa = {empresa} AND p.ejercicio = {ejercicio} AND (p.fecha BETWEEN '{inicio}' AND '{fin}') AND (p.tipo NOT IN(4,5)) AND ISNULL(c.id_cuenta) AND d.importe != 0 "

            strSQL = strSQL.Replace("{conta}", Sesion.BaseConta)
            strSQL = strSQL.Replace("{empresa}", Sesion.IdEmpresa)
            strSQL = strSQL.Replace("{ejercicio}", Cierres.Actual.EjercicioActual)
            strSQL = strSQL.Replace("{inicio}", Cierres.Actual.FechaInicio.ToString(FORMATO_MYSQL))
            strSQL = strSQL.Replace("{fin}", Cierres.Actual.FechaFin.ToString(FORMATO_MYSQL))

            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSQL, CON)
            REA = COM.ExecuteReader
            If REA.HasRows Then
                Do While REA.Read
                    strPolizas = strPolizas & REA.GetMySqlDateTime("Fecha").ToString & "  |  " & REA.GetInt64("Poliza") & vbNewLine
                Loop
                strMensaje = " Verifique las siguientes pólizas " & vbNewLine
                strMensaje &= " Fecha  | Poliza " & vbNewLine
                strMensaje &= " ------------------ " & vbNewLine
                strMensaje &= strPolizas & vbNewLine

                MsgBox("Se encontraron cuentas no validas o que aun no estan especificadas en la Nomenclatura Contable" & vbNewLine & "El proceso se canceló ", MsgBoxStyle.Critical)
                MsgBox(strMensaje, MsgBoxStyle.Critical)
                frm.Close()
                Return False
                Exit Function
            End If
            frm.Close()
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        Return logResultado
    End Function

    Private Function VerificarSaldos() As Boolean
        Dim logResultado As Boolean = True
        Dim strSQL As String = STR_VACIO
        Dim strMensaje As String = STR_VACIO
        Dim strPolizas As String = STR_VACIO
        Dim dblTotal As Double = INT_CERO
        Dim frm As New frmMensaje
        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader
        Try
            frm.Mensaje = " Verificando Saldos... "
            frm.Show()
            system.Windows.Forms.Application.DoEvents()
            strSQL = " SELECT p.poliza Poliza, p.fecha Fecha, ROUND(SUM(IF(d.operacion = 'C', d.importe,0))- SUM(IF(d.operacion = 'A', d.importe,0)),2) Total
                        FROM {conta}.polizas p
                            LEFT JOIN {conta}.detalle_polizas d ON p.empresa = d.empresa AND p.ejercicio = d.ejercicio AND p.poliza = d.poliza
                        WHERE p.empresa = {empresa} AND p.ejercicio = {ejercicio} AND (p.fecha BETWEEN '{inicio}' AND '{fin}') AND (p.tipo NOT IN(4,5))
                        GROUP BY p.poliza
                        HAVING total != 0 "

            strSQL = strSQL.Replace("{conta}", Sesion.BaseConta)
            strSQL = strSQL.Replace("{empresa}", Sesion.IdEmpresa)
            strSQL = strSQL.Replace("{ejercicio}", Cierres.Actual.EjercicioActual)
            strSQL = strSQL.Replace("{inicio}", Cierres.Actual.FechaInicio.ToString(FORMATO_MYSQL))
            strSQL = strSQL.Replace("{fin}", Cierres.Actual.FechaFin.ToString(FORMATO_MYSQL))

            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSQL, CON)
            REA = COM.ExecuteReader
            If REA.HasRows Then
                Do While REA.Read
                    dblTotal = dblTotal + REA.GetDouble("Total")
                    strPolizas = strPolizas & REA.GetMySqlDateTime("Fecha").ToString & "  |  " & REA.GetInt64("Poliza") & vbNewLine
                Loop
                strMensaje = " Verifique las siguientes pólizas " & vbNewLine
                strMensaje &= " Fecha  | Poliza " & vbNewLine
                strMensaje &= " ------------------ " & vbNewLine
                strMensaje &= strPolizas & vbNewLine

                MsgBox("Existe una diferencia de Total de Saldos de  " & dblTotal.ToString(FORMATO_MONEDA) & vbNewLine & "El proceso se canceló ", MsgBoxStyle.Critical)
                MsgBox(strMensaje, MsgBoxStyle.Critical)
                frm.Close()
                Return False
                Exit Function
            End If
            frm.Close()
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        Return logResultado
    End Function

    Private Function VerificarDatos() As Boolean
        Dim logResultado As Boolean = True
        Dim strMensaje As String = STR_VACIO
        Try
            '<----------- 1) Obtiene los datos del ejercicio actual--------------
            If VerificarEjercicioActual() = False Then
                MsgBox("No se pudo encontar el ejercicio Actual", MsgBoxStyle.Critical)
                Return False
                Exit Function
            End If
            '<----------- 2) Verifica el ejercicio siguiente-----------------
            If VerificarEjercicioSiguiente() = False Then
                MsgBox("No se pudo encontar el ejercicio Siguiente", MsgBoxStyle.Critical)
                Return False
                Exit Function
            End If
            'Verifica que la fecha en que se genera el cierre y apertura
            'sea mayor a la fecha final del ejercicio en curso
            '<----------------------------------------------------------
            If VerificarFechaDeCierre() = False Then
                MsgBox("El cierre debe hacerce posterior al  " & Cierres.Actual.FechaFin & vbNewLine & "El proceso se canceló ", MsgBoxStyle.Critical)
                Return False
                Exit Function
            End If
            strMensaje = " Esta a punto de CERRAR el " & Cierres.Actual.Descripcion & " y APERTURAR el " & Cierres.Siguiente.Descripcion & vbNewLine & "¿Esta seguro que desea continuar? "
            If MsgBox(strMensaje, MsgBoxStyle.YesNo) = MsgBoxResult.Yes Then
                '<---------Verifica que en el detalle de las polizas existan cuentas contables validas----------
                If VerificarCuentasNoValidas() = False Then
                    Return False
                    Exit Function
                End If
                '<---------Verifica que cuadre todo el ejercicio-----
                If VerificarSaldos() = False Then
                    Return False
                    Exit Function
                End If
            Else
                Return False
                Exit Function
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)

        End Try
        Return logResultado
    End Function

    Private Function GenerarSaldos() As Boolean
        Dim logResultado As Boolean = False
        Dim strSQL As String = STR_VACIO
        Dim COM As MySqlCommand

        Try
            strSQL = " INSERT INTO {conta}.saldos (cuenta, empresa, ejercicio, saldo_inicial, cargos, abonos, nombre, tipo_saldo, tipo_cuenta)
                SELECT c.id_cuenta Cuenta, p.empresa Empresa, p.ejercicio Ejercicio, SUM(IF(p.tipo IN(3,6),1,0)* IF(d.operacion = 'C', round(d.importe,2), 0))- SUM(IF(p.tipo IN(3,6),1,0)* IF(d.operacion = 'A', round(d.importe,2), 0)) SaldoInicial, SUM(IF(p.tipo NOT IN(3,6),1,0)* IF(d.operacion='C',round(d.importe,2),0)) Cargos, SUM(IF(p.tipo NOT IN(3,6),1,0)* IF(d.operacion='A',round(d.importe,2),0)) Abonos,
	                 c.nombre Nombre, c.tipo_saldo Tipo_saldo, c.tipo_cuenta Tipo_Cuenta
                FROM {conta}.polizas p
                    LEFT JOIN {conta}.detalle_polizas d ON p.empresa = d.empresa AND p.ejercicio = d.ejercicio AND p.poliza = d.poliza
                    INNER JOIN {conta}.cuentas c ON c.id_cuenta = d.cuenta AND d.empresa = c.empresa
                WHERE p.empresa = {empresa} AND p.ejercicio = {EjerAct} AND p.tipo NOT IN(4,5)
                GROUP BY Cuenta
                ORDER BY Cuenta"
            If Sesion.IdEmpresa = 18 Then
                strSQL &= "; INSERT INTO contapdm.saldos (cuenta, empresa, ejercicio, saldo_inicial, cargos, abonos, nombre, tipo_saldo, tipo_cuenta)
                SELECT c.id_cuenta Cuenta, p.empresa Empresa, p.ejercicio Ejercicio, SUM(IF(p.tipo IN(3,6),1,0)* IF(d.operacion = 'C', round(d.importe,2), 0))- SUM(IF(p.tipo IN(3,6),1,0)* IF(d.operacion = 'A', round(d.importe,2), 0)) SaldoInicial, SUM(IF(p.tipo NOT IN(3,6),1,0)* IF(d.operacion='C',round(d.importe,2),0)) Cargos, SUM(IF(p.tipo NOT IN(3,6),1,0)* IF(d.operacion='A',round(d.importe,2),0)) Abonos,
	                 c.nombre Nombre, c.tipo_saldo Tipo_saldo, c.tipo_cuenta Tipo_Cuenta
                FROM contapdm.polizas p
                    LEFT JOIN contapdm.detalle_polizas d ON p.empresa = d.empresa AND p.ejercicio = d.ejercicio AND p.poliza = d.poliza
                    INNER JOIN contapdm.cuentas c ON c.id_cuenta = d.cuenta AND d.empresa = c.empresa
                WHERE p.empresa = {empresa} AND p.ejercicio = {EjerAct} AND p.tipo NOT IN(4,5)
                GROUP BY Cuenta
                ORDER BY Cuenta"
            End If

            strSQL = strSQL.Replace("{conta}", Sesion.BaseConta)
            strSQL = strSQL.Replace("{empresa}", Sesion.IdEmpresa)
            strSQL = strSQL.Replace("{EjerAct}", Cierres.Actual.EjercicioActual)



            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSQL, CON)
            COM.ExecuteNonQuery()
            logResultado = True
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        Return logResultado

    End Function

    Private Function CuentaEjercicioActual(Optional intParametroCta As Integer = 0) As String
        Dim STRcuenta As String = STR_VACIO
        Dim strSQL As String = STR_VACIO
        Dim COM As MySqlCommand

        Try
            strSQL = "SELECT p.valor E_Actual 
                        FROM {conta}.parametros_empresa p
                    WHERE p.empresa = {empresa} AND p.parametro = {par} "

            If intParametroCta > 0 Then
                strSQL = strSQL.Replace("{par}", intParametroCta)
            Else
                strSQL = strSQL.Replace("{par}", 8)
            End If
            strSQL = strSQL.Replace("{conta}", Sesion.BaseConta)
            strSQL = strSQL.Replace("{empresa}", Sesion.IdEmpresa)
            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSQL, CON)
            STRcuenta = COM.ExecuteScalar
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        Return STRcuenta
    End Function

    Private Function EncabezadoPolizaCierre(ByVal Poliza As Long, ByVal Concepto As String) As Boolean
        Dim logResultado As Boolean = False
        Dim strSQL As String = STR_VACIO
        Dim COM As MySqlCommand

        Try
            strSQL = " INSERT INTO {conta}.polizas(empresa, ejercicio, poliza, fecha, concepto, tipo, modo, estado) 
                        VALUES({empresa}, {ejercicio}, {poliza}, '{fin}', '{concepto}', {tipo}, {modo}, {estado}); "
            If Sesion.IdEmpresa = 18 Then
                strSQL &= " INSERT INTO contapdm.polizas(empresa, ejercicio, poliza, fecha, concepto, tipo, modo, estado) 
                        VALUES({empresa}, {ejercicio}, {poliza}, '{fin}', '{concepto}', {tipo}, {modo}, {estado}); "
            End If

            strSQL = strSQL.Replace("{conta}", Sesion.BaseConta)
            strSQL = strSQL.Replace("{empresa}", Sesion.IdEmpresa)
            strSQL = strSQL.Replace("{ejercicio}", Cierres.Actual.EjercicioActual)
            strSQL = strSQL.Replace("{poliza}", Poliza)
            strSQL = strSQL.Replace("{fin}", Cierres.Actual.FechaFin.ToString(FORMATO_MYSQL))
            strSQL = strSQL.Replace("{concepto}", Concepto)
            strSQL = strSQL.Replace("{tipo}", 5)
            strSQL = strSQL.Replace("{modo}", 5)
            strSQL = strSQL.Replace("{estado}", "'C'")

            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSQL, CON)
            COM.ExecuteNonQuery()
            logResultado = True

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        Return logResultado
    End Function

    Private Function LineaEjercicioActual(ByVal Poliza As Long, ByVal intTipo As Integer) As Boolean
        Dim logResultado As Boolean = False
        Dim COM As MySqlCommand
        Dim strSQL As String = STR_VACIO
        Dim strSelect As String = STR_VACIO
        Dim strCtaEjercicioActual As String = STR_VACIO
        Dim REA As MySqlDataReader
        Dim COM2 As MySqlCommand
        Dim strOperacion As String = STR_VACIO

        Try

            strSelect = " SELECT {empresa} empresa, {ejercicio} ejercicio, {poliza} poliza,1, '{cuenta}' cuenta, IFNULL(if(t.importe<0, t.importe*-1, t.importe),0) importe,  if(t.importe<0, 'A','C') operacion, '{fin}' fecha 
                            FROM (SELECT SUM(IF(d.operacion = 'C', d.importe, 0))- SUM(IF(d.operacion = 'A', d.importe, 0)) importe
                                    FROM {conta}.polizas p
                                        LEFT JOIN {conta}.detalle_polizas d ON p.empresa = d.empresa AND p.ejercicio = d.ejercicio AND p.poliza = d.poliza 
                                        INNER JOIN {conta}.cuentas c ON d.empresa = c.empresa AND d.cuenta = c.id_cuenta
                                    WHERE p.empresa = {empresa} AND p.ejercicio = {ejercicio} AND (p.fecha BETWEEN '{inicio}' AND '{fin}' ) AND (d.cuenta LIKE '{TipoCuenta}%') AND (p.tipo NOT IN(4,5)) )t; "

            strSelect = strSelect.Replace("{empresa}", Sesion.IdEmpresa)
            strSelect = strSelect.Replace("{conta}", Sesion.BaseConta)
            strSelect = strSelect.Replace("{ejercicio}", Cierres.Actual.EjercicioActual)
            strSelect = strSelect.Replace("{poliza}", Poliza)
            strSelect = strSelect.Replace("{inicio}", Cierres.Actual.FechaInicio.ToString(FORMATO_MYSQL))
            strSelect = strSelect.Replace("{fin}", Cierres.Actual.FechaFin.ToString(FORMATO_MYSQL))

            MyCnn.CONECTAR = strConexion
            COM2 = New MySqlCommand(strSelect, CON)
            REA = COM2.ExecuteReader
            If REA.HasRows Then
                REA.Read()
                strOperacion = REA.GetString("operacion")
            End If
            COM2.Dispose()
            COM2 = Nothing
            CON.Close()
            CON.Dispose()
            CON = Nothing
            System.GC.Collect()

            strSQL = " INSERT INTO {conta}.detalle_polizas(empresa, ejercicio, poliza, item, cuenta, importe, operacion, fecha) " & strSelect
            If Sesion.IdEmpresa = 18 Then
                strSQL &= "; INSERT INTO contapdm.detalle_polizas(empresa, ejercicio, poliza, item, cuenta, importe, operacion, fecha) " & strSelect

            End If
            If Sesion.idGiro = 2 Then
                If strOperacion = "A" Then
                    strCtaEjercicioActual = CuentaEjercicioActual(18)
                Else
                    strCtaEjercicioActual = CuentaEjercicioActual(8)
                End If

            Else
                strCtaEjercicioActual = CuentaEjercicioActual()
            End If
            strSQL = strSQL.Replace("{conta}", Sesion.BaseConta)
            strSQL = strSQL.Replace("{empresa}", Sesion.IdEmpresa)
            strSQL = strSQL.Replace("{cuenta}", strCtaEjercicioActual)
            If intTipo = TIPO_ACREEDOR Then
                If Sesion.IdEmpresa = 16 Or Sesion.IdEmpresa = 15 Or Sesion.IdEmpresa >= 18 Then
                    strSQL = strSQL.Replace("{TipoCuenta}", CUENTA_ACREEDORES_SV & "%' OR d.cuenta LIKE '{TipoCuenta2}%' OR d.cuenta LIKE '{TipoCuenta3}")
                    strSQL = strSQL.Replace("{TipoCuenta2}", CUENTA_ACREEDORES_SV2)
                    strSQL = strSQL.Replace("{TipoCuenta3}", CUENTA_ACREEDORES_SV3)
                Else
                    strSQL = strSQL.Replace("{TipoCuenta}", CUENTA_ACREEDORES)
                End If

            Else
                If Sesion.IdEmpresa = 16 Or Sesion.IdEmpresa = 15 Or Sesion.IdEmpresa >= 18 Then
                    strSQL = strSQL.Replace("{TipoCuenta}", CUENTA_DEUDORES_SV)
                Else
                    strSQL = strSQL.Replace("{TipoCuenta}", CUENTA_DEUDORES)
                End If

            End If

            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSQL, CON)
            COM.ExecuteNonQuery()
            logResultado = True

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        Return logResultado
    End Function

    Private Function DetallePolizaCierre(ByVal Poliza As Long, ByVal intTipo As Integer) As Boolean
        Dim logResultado As Boolean = False
        Dim COM As MySqlCommand
        Dim strSQL As String = STR_VACIO
        Dim strTipoCuenta As String = STR_VACIO
        Try

            If intTipo = TIPO_ACREEDOR Then
                If Sesion.IdEmpresa = 16 Or Sesion.IdEmpresa = 15 Or Sesion.IdEmpresa >= 18 Then
                    strTipoCuenta = CUENTA_ACREEDORES_SV
                Else
                    strTipoCuenta = CUENTA_ACREEDORES
                End If

            Else
                If Sesion.IdEmpresa = 16 Or Sesion.IdEmpresa = 15 Or Sesion.IdEmpresa >= 18 Then
                    strTipoCuenta = CUENTA_DEUDORES_SV
                Else
                    strTipoCuenta = CUENTA_DEUDORES
                End If

            End If
            strSQL = " INSERT INTO {conta}.detalle_polizas(item ,empresa, ejercicio, poliza,cuenta, importe, operacion, fecha)
                           SELECT t.linea,   {empresa} empresa, {ejercicio} ejercicio, {poliza} poliza, t.cuenta cuenta, IFNULL(if(t.importe<0, t.importe*-1,t.importe),0) importe, if(t.importe<0, 'C', 'A') operacion, '{fin}' fecha 
                            FROM (SELECT  @fila:=@fila+1 AS linea, d.cuenta cuenta, SUM(IF(d.operacion = 'C', d.importe, 0))- SUM(IF(d.operacion = 'A', d.importe, 0)) importe, d.operacion operacion 
                                   FROM  (SELECT @fila:=1) r , {conta}.polizas p 
                                    LEFT JOIN {conta}.detalle_polizas d ON p.empresa = d.empresa AND p.ejercicio = d.ejercicio AND p.poliza = d.poliza 
                                    INNER JOIN {conta}.cuentas c ON d.empresa = c.empresa AND d.cuenta = c.id_cuenta
                                    WHERE p.empresa = {empresa} AND p.ejercicio = {ejercicio} AND (p.fecha BETWEEN '{inicio}' AND '{fin}' ) AND (d.cuenta LIKE '{TipoCuenta}%') AND (p.tipo NOT IN(4,5)) 
                                    GROUP BY cuenta)t; "
            If Sesion.IdEmpresa = 18 Then
                strSQL &= " INSERT INTO contapdm.detalle_polizas(item ,empresa, ejercicio, poliza,cuenta, importe, operacion, fecha)
                           SELECT t.linea,   {empresa} empresa, {ejercicio} ejercicio, {poliza} poliza, t.cuenta cuenta, IFNULL(if(t.importe<0, t.importe*-1,t.importe),0) importe, if(t.importe<0, 'C', 'A') operacion, '{fin}' fecha 
                            FROM (SELECT  @fila:=@fila+1 AS linea, d.cuenta cuenta, SUM(IF(d.operacion = 'C', d.importe, 0))- SUM(IF(d.operacion = 'A', d.importe, 0)) importe, d.operacion operacion 
                                   FROM  (SELECT @fila:=1) r , contapdm.polizas p 
                                    LEFT JOIN contapdm.detalle_polizas d ON p.empresa = d.empresa AND p.ejercicio = d.ejercicio AND p.poliza = d.poliza 
                                    INNER JOIN contapdm.cuentas c ON d.empresa = c.empresa AND d.cuenta = c.id_cuenta
                                    WHERE p.empresa = {empresa} AND p.ejercicio = {ejercicio} AND (p.fecha BETWEEN '{inicio}' AND '{fin}' ) AND (d.cuenta LIKE '{TipoCuenta}%') AND (p.tipo NOT IN(4,5)) 
                                    GROUP BY cuenta)t; "
            End If

            strSQL = strSQL.Replace("{empresa}", Sesion.IdEmpresa)
            strSQL = strSQL.Replace("{conta}", Sesion.BaseConta)
            strSQL = strSQL.Replace("{ejercicio}", Cierres.Actual.EjercicioActual)
            strSQL = strSQL.Replace("{poliza}", Poliza)
            strSQL = strSQL.Replace("{inicio}", Cierres.Actual.FechaInicio.ToString(FORMATO_MYSQL))
            strSQL = strSQL.Replace("{fin}", Cierres.Actual.FechaFin.ToString(FORMATO_MYSQL))

            If (Sesion.IdEmpresa = 16 And strTipoCuenta = 5) Or (Sesion.IdEmpresa = 15 And strTipoCuenta = 5) Or (Sesion.IdEmpresa >= 18 And strTipoCuenta = 5) Then
                strSQL = strSQL.Replace("{TipoCuenta}", strTipoCuenta & "%' OR d.cuenta LIKE '{TipoCuenta2}%' OR d.cuenta LIKE '{TipoCuenta3}")
                strSQL = strSQL.Replace("{TipoCuenta2}", CUENTA_ACREEDORES_SV2)
                strSQL = strSQL.Replace("{TipoCuenta3}", CUENTA_ACREEDORES_SV3)
            ElseIf (Sesion.IdEmpresa = 16 And strTipoCuenta = 4) Or (Sesion.IdEmpresa = 15 And strTipoCuenta = 4) Or (Sesion.IdEmpresa >= 18 And strTipoCuenta = 4) Then
                strSQL = strSQL.Replace("{TipoCuenta}", strTipoCuenta)
            Else
                strSQL = strSQL.Replace("{TipoCuenta}", strTipoCuenta)
            End If

            MyCnn.CONECTAR = strConexion & " Allow User Variables=True"
            COM = New MySqlCommand(strSQL, CON)
            COM.ExecuteNonQuery()
            logResultado = True
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        Return logResultado
    End Function

    Private Function GenerarPolizaResutaldos(ByVal Tipo As Integer) As Boolean
        Dim longPoliza As Long = INT_CERO
        Dim strSQL As String = STR_VACIO

        Dim logResultado As Boolean = False
        Dim strTipoCuenta As String = STR_VACIO
        Dim strConcepto As String = " Cierre de Cuentas de Resultados {titulo}  "
        Try
            longPoliza = NuevaPoliza()
            If Tipo = TIPO_ACREEDOR Then
                If Sesion.IdEmpresa = 16 Or Sesion.IdEmpresa = 15 Or Sesion.IdEmpresa >= 18 Then
                    strTipoCuenta = CUENTA_ACREEDORES_SV
                Else
                    strTipoCuenta = CUENTA_ACREEDORES
                End If

                strConcepto = strConcepto.Replace("{titulo}", "Acreedores")
                CierreAno(0) = Cierres.Actual.EjercicioActual
                CierrePoliza(0) = longPoliza
            Else
                If Sesion.IdEmpresa = 16 Or Sesion.IdEmpresa = 15 Or Sesion.IdEmpresa >= 18 Then
                    strTipoCuenta = CUENTA_DEUDORES_SV
                Else
                    strTipoCuenta = CUENTA_DEUDORES
                End If

                strConcepto = strConcepto.Replace("{titulo}", "Deudores")
                CierreAno(1) = Cierres.Actual.EjercicioActual
                CierrePoliza(1) = longPoliza
            End If


            'Generar encacbezado de Poliza
            If EncabezadoPolizaCierre(longPoliza, strConcepto) = True Then
                'Generar Detalle
                If LineaEjercicioActual(longPoliza, Tipo) = True Then
                    If DetallePolizaCierre(longPoliza, Tipo) Then
                        logResultado = True
                    End If
                End If
            End If

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        Return logResultado
    End Function

    Private Function NuevaLinea(ByVal ejercicio As Integer, ByVal poliza As Integer) As Integer
        Dim Linea As Integer = NO_FILA
        Dim strSQL As String = STR_VACIO
        Dim COM As MySqlCommand
        Try
            strSQL = " select ifnull(max(item),0) from {conta}.detalle_polizas  where poliza = {poliza} and ejercicio = {ejercicio} and empresa = {empresa} "
            strSQL = strSQL.Replace("{conta}", Sesion.BaseConta)
            strSQL = strSQL.Replace("{empresa}", Sesion.IdEmpresa)
            strSQL = strSQL.Replace("{poliza}", poliza)
            strSQL = strSQL.Replace("{ejercicio}", ejercicio)

            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSQL, CON)
            Linea = COM.ExecuteScalar

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        Return Linea
    End Function

    Private Function GenerarPolizadeCierreyApertura(ByVal Tipo As Integer) As Boolean
        Dim STR_CTA_ACTIVO As String
        Dim STR_CTA_ACTIVO2 As String
        Dim STR_CTA_PASIVO As String
        Dim STR_CTA_PASIVO2 As String
        Dim STR_CTA_RESULTADO As String
        Dim STR_ACREEDORES As String
        Dim STR_DEUDORES As String
        Dim STR_DEUDORES2 As String
        Dim STR_DEUDORES3 As String
        Const INT_TIPO_CIERRE As Integer = 4
        Const INT_TIPO_APERTURA As Integer = 3

        If Sesion.IdEmpresa = 16 Or Sesion.IdEmpresa = 15 Or Sesion.IdEmpresa >= 18 Then
            STR_CTA_ACTIVO = "11"
            STR_CTA_ACTIVO2 = "12"
            STR_CTA_PASIVO = "21"
            STR_CTA_PASIVO2 = "22"
            STR_CTA_RESULTADO = "31"
            STR_ACREEDORES = "4"
            STR_DEUDORES = "5"
            STR_DEUDORES2 = "6"
            STR_DEUDORES3 = "7"
        Else
            STR_CTA_ACTIVO = "010"
            STR_CTA_PASIVO = "020"
            STR_CTA_RESULTADO = "030"
            STR_ACREEDORES = "04"
            STR_DEUDORES = "05"
        End If

        Dim logResultado As Boolean = False
        Dim strConcepto As String = STR_VACIO
        Dim strTipoSaldo As String = STR_VACIO
        Dim intTipoPoliza As Integer = NO_FILA
        Dim intEjercicioPoliza As Integer = NO_FILA
        Dim intParametro As Integer = NO_FILA
        Dim FechaPoliza As Date

        Dim REA As MySqlDataReader
        Dim COMM As MySqlCommand
        Dim strTSaldo As String = STR_VACIO

        Dim strSQL As String = STR_VACIO
        Dim strSQLInsert As String = STR_VACIO
        Dim strSql_Resultados As String = STR_VACIO
        Dim strSQL_Activos As String = STR_VACIO
        Dim strSql_Pasivos As String = STR_VACIO

        Dim longPoliza As Long
        Dim COM As MySqlCommand
        Dim strCuentaEjercicioActual As String = STR_VACIO
        Try
            'Asigna las variables segun sea el caso: Apertura o Balance
            'intOpcion = 1 -> CIERRE DE CUENTAS DE BALANCE
            'intOpcion = 2 -> APERTURA DE CUENTAS DE BALANCE
            If Tipo = INT_CERO Then
                strConcepto = "Cierre de Cuentas del Balance General del Ejercicio: " & Cierres.Actual.FechaFin.Year
                strTipoSaldo = "t.importe<0, 'C','A'"
                intTipoPoliza = 4 ' Tipo de poliza cierre
                intEjercicioPoliza = Cierres.Actual.EjercicioActual
                FechaPoliza = Cierres.Actual.FechaFin
                intParametro = 8
                longPoliza = NuevaPoliza()
                CierreAno(2) = Cierres.Actual.EjercicioActual
                CierrePoliza(2) = longPoliza
                'strCuentaEjercicioActual = CuentaEjercicioActual(8)
            ElseIf Tipo = INT_UNO Then
                strConcepto = "Apertura de cuentas del Balance General  del Ejercicio: " & Cierres.Siguiente.FechaInicio.Year
                strTipoSaldo = "t.importe<0, 'A','C'"
                intTipoPoliza = 3 ' Tipo de poliza apertura
                intEjercicioPoliza = Cierres.Siguiente.EjercicioActual
                FechaPoliza = Cierres.Siguiente.FechaInicio
                intParametro = 9
                longPoliza = INT_UNO
                CierreAno(3) = Cierres.Siguiente.EjercicioActual
                CierrePoliza(3) = INT_UNO
                'strCuentaEjercicioActual = CuentaEjercicioActual(9)
            End If

            ' Encabezado Poliza

            strSQL = " INSERT INTO {conta}.polizas(empresa, ejercicio, poliza, fecha, concepto, tipo, modo, estado)
                       VALUES({empresa}, {ejercicio}, {poliza}, '{FechaEnc}', '{concepto}', {tipo},{modo}, '{estado}'); "
            If Sesion.IdEmpresa = 18 Then
                strSQL &= " INSERT INTO contapdm.polizas(empresa, ejercicio, poliza, fecha, concepto, tipo, modo, estado)
                       VALUES({empresa}, {ejercicio}, {poliza}, '{FechaEnc}', '{concepto}', {tipo},{modo}, '{estado}'); "
            End If

            strSQL = strSQL.Replace("{conta}", Sesion.BaseConta)
            strSQL = strSQL.Replace("{empresa}", Sesion.IdEmpresa)
            strSQL = strSQL.Replace("{ejercicio}", intEjercicioPoliza)
            strSQL = strSQL.Replace("{FechaEnc}", FechaPoliza.ToString(FORMATO_MYSQL))
            strSQL = strSQL.Replace("{poliza}", longPoliza)
            strSQL = strSQL.Replace("{concepto}", strConcepto)
            strSQL = strSQL.Replace("{tipo}", intTipoPoliza)
            strSQL = strSQL.Replace("{modo}", intTipoPoliza)
            strSQL = strSQL.Replace("{estado}", "C")

            MyCnn.CONECTAR = strConexion & " Allow User Variables=True"
            COM = New MySqlCommand(strSQL, CON)
            COM.ExecuteNonQuery()

            'strSQLtipoSaldo = "Select @fila:=@fila+1 linea , {empresa} empresa, {ejercicioEncabezado} ejercicio, {poliza} poliza, t.cuenta cuenta, if(t.importe<0, round(t.importe,2) *-1, round(t.importe,2)) importe, if({TipSaldo}) operacion, '{FechaEnc}' fecha 
            '                    FROM (SELECT @fila:={filainicio}) r, (SELECT {id_cuentas} cuenta, sum(if(d.operacion ='C', d.importe, 0))-sum(if(d.operacion='A',d.importe,0))importe 
            '                            FROM {conta}.polizas p 
            '                            LEFT JOIN {conta}.detalle_polizas d ON p.empresa = d.empresa AND p.poliza = d.poliza AND p.ejercicio = d.ejercicio
            '                            INNER JOIN {conta}.cuentas c ON d.empresa = c.empresa AND d.cuenta = c.id_cuenta
            '                          WHERE p.empresa = {empresa} AND p.ejercicio = {ejercicio} AND (p.fecha between '{inicio}' AND '{fin})' AND ({Cuentas}) AND (p.tipo NOT IN(4,5)))
            '                    {AgruparPorCuentas}
            '                    HAVING ABS(round(importe,2)) >0
            '                   ORDER BY d.cuenta) t; "

            strSQLInsert = " INSERT INTO {conta}.detalle_polizas( item, empresa, ejercicio, poliza, cuenta, importe, operacion, fecha) "
            strSQLInsert = strSQLInsert.Replace("{conta}", Sesion.BaseConta)
            strSQL = " Select @fila:=@fila+1 linea , {empresa} empresa, {ejercicioEncabezado} ejercicio, {poliza} poliza, t.cuenta cuenta, if(t.importe<0, round(t.importe,2) *-1, round(t.importe,2)) importe, if({TipSaldo}) operacion, '{FechaEnc}' fecha 
                                FROM (SELECT @fila:={filainicio}) r, (SELECT {id_cuentas} cuenta, sum(if(d.operacion ='C', d.importe, 0))-sum(if(d.operacion='A',d.importe,0))importe 
                                        FROM {conta}.polizas p 
                                        LEFT JOIN {conta}.detalle_polizas d ON p.empresa = d.empresa AND p.poliza = d.poliza AND p.ejercicio = d.ejercicio
                                        INNER JOIN {conta}.cuentas c ON d.empresa = c.empresa AND d.cuenta = c.id_cuenta
                                      WHERE p.empresa = {empresa} AND p.ejercicio = {ejercicio} AND (p.fecha between '{inicio}' AND '{fin})' AND ({Cuentas}) AND (p.tipo NOT IN(4,5)))
                                {AgruparPorCuentas}
                                HAVING ABS(round(importe,2)) >0
                               ORDER BY d.cuenta) t; "
            If Sesion.IdEmpresa = 18 Then
                strSQL &= " INSERT INTO contapdm.detalle_polizas( item, empresa, ejercicio, poliza, cuenta, importe, operacion, fecha) "
                strSQL &= " Select @fila:=@fila+1 linea , {empresa} empresa, {ejercicioEncabezado} ejercicio, {poliza} poliza, t.cuenta cuenta, if(t.importe<0, round(t.importe,2) *-1, round(t.importe,2)) importe, if({TipSaldo}) operacion, '{FechaEnc}' fecha 
                                FROM (SELECT @fila:={filainicio}) r, (SELECT {id_cuentas} cuenta, sum(if(d.operacion ='C', d.importe, 0))-sum(if(d.operacion='A',d.importe,0))importe 
                                        FROM contapdm.polizas p 
                                        LEFT JOIN contapdm.detalle_polizas d ON p.empresa = d.empresa AND p.poliza = d.poliza AND p.ejercicio = d.ejercicio
                                        INNER JOIN contapdm.cuentas c ON d.empresa = c.empresa AND d.cuenta = c.id_cuenta
                                      WHERE p.empresa = {empresa} AND p.ejercicio = {ejercicio} AND (p.fecha between '{inicio}' AND '{fin})' AND ({Cuentas}) AND (p.tipo NOT IN(4,5)))
                                {AgruparPorCuentas}
                                HAVING ABS(round(importe,2)) >0
                               ORDER BY d.cuenta) t; "
            End If

            strSQL = strSQL.Replace("{conta}", Sesion.BaseConta)
            strSQL = strSQL.Replace("{empresa}", Sesion.IdEmpresa)
            strSQL = strSQL.Replace("{ejercicioEncabezado}", intEjercicioPoliza)
            strSQL = strSQL.Replace("{FechaEnc}", FechaPoliza.ToString(FORMATO_MYSQL))
            strSQL = strSQL.Replace("{ejercicio}", Cierres.Actual.EjercicioActual)
            strSQL = strSQL.Replace("{poliza}", longPoliza)
            strSQL = strSQL.Replace("{TipSaldo}", strTipoSaldo)
            strSQL = strSQL.Replace("{inicio}", Cierres.Actual.FechaInicio.ToString(FORMATO_MYSQL))
            strSQL = strSQL.Replace("{fin}", Cierres.Actual.FechaFin.ToString(FORMATO_MYSQL))

            strSql_Resultados = strSQL
            strSQL = strSQL.Replace("{id_cuentas}", "d.cuenta")

            'Reemplazar valores para Activos
            strSQL_Activos = strSQLInsert & strSQL
            If Sesion.IdEmpresa = 16 Or Sesion.IdEmpresa = 15 Or Sesion.IdEmpresa >= 18 Then
                strSQL_Activos = strSQL_Activos.Replace("{Cuentas}", "d.cuenta LIKE '{CtasActivo}' OR d.cuenta LIKE '{ctaActivo2}'")
                strSQL_Activos = strSQL_Activos.Replace("{CtasActivo}", STR_CTA_ACTIVO & "%")
                strSQL_Activos = strSQL_Activos.Replace("{ctaActivo2}", STR_CTA_ACTIVO2 & "%")
            Else
                strSQL_Activos = strSQL_Activos.Replace("{Cuentas}", "d.cuenta LIKE '{CtasActivo}'")
                strSQL_Activos = strSQL_Activos.Replace("{CtasActivo}", STR_CTA_ACTIVO & "%")
            End If

            strSQL_Activos = strSQL_Activos.Replace("{AgruparPorCuentas}", "GROUP BY d.cuenta")
            strSQL_Activos = strSQL_Activos.Replace("{filainicio}", "0")
            MyCnn.CONECTAR = strConexion & " Allow User Variables=True"
            COM = New MySqlCommand(strSQL_Activos, CON)
            COM.ExecuteNonQuery()

            'Reemplazar valores para Pasivos
            strSql_Pasivos = strSQLInsert & strSQL
            strSql_Pasivos = strSql_Pasivos.Replace("{Cuentas}", "d.cuenta LIKE '{CtasPasivo}' OR d.cuenta LIKE '{CtasPasivo2}' OR d.cuenta LIKE '{CtasPatrimonio}'")
            strSql_Pasivos = strSql_Pasivos.Replace("{CtasPasivo}", STR_CTA_PASIVO & "%")
            strSql_Pasivos = strSql_Pasivos.Replace("{CtasPasivo2}", STR_CTA_PASIVO2 & "%")
            strSql_Pasivos = strSql_Pasivos.Replace("{CtasPatrimonio}", STR_CTA_RESULTADO & "%")
            strSql_Pasivos = strSql_Pasivos.Replace("{AgruparPorCuentas}", "GROUP BY d.cuenta")
            strSql_Pasivos = strSql_Pasivos.Replace("{filainicio}", NuevaLinea(Cierres.Actual.EjercicioActual, longPoliza))

            MyCnn.CONECTAR = strConexion & " Allow User Variables=True"
            COM = New MySqlCommand(strSql_Pasivos, CON)
            COM.ExecuteNonQuery()

            'Reemplazar valores para Resultados del ejercicio
            'strSql_Resultados = strSQL

            If Sesion.IdEmpresa = 16 Or Sesion.IdEmpresa = 15 Or Sesion.IdEmpresa >= 18 Then
                strSql_Resultados = strSql_Resultados.Replace("{Cuentas}", " d.cuenta LIKE '{CtasDeudores}' OR d.cuenta LIKE '{ctaDeudores2}' OR d.cuenta LIKE '{ctaDeudores3}' OR d.cuenta LIKE '{CtasAcreedores}' ")
                strSql_Resultados = strSql_Resultados.Replace("{CtasDeudores}", STR_DEUDORES & "%")
                strSql_Resultados = strSql_Resultados.Replace("{ctaDeudores2}", STR_DEUDORES2 & "%")
                strSql_Resultados = strSql_Resultados.Replace("{ctaDeudores3}", STR_DEUDORES3 & "%")
            Else
                strSql_Resultados = strSql_Resultados.Replace("{Cuentas}", " d.cuenta LIKE '{CtasDeudores}' OR d.cuenta LIKE '{CtasAcreedores}' ")
                strSql_Resultados = strSql_Resultados.Replace("{CtasDeudores}", STR_DEUDORES & "%")
            End If

            strSql_Resultados = strSql_Resultados.Replace("{CtasAcreedores}", STR_ACREEDORES & "%")
            strSql_Resultados = strSql_Resultados.Replace("{AgruparPorCuentas}", STR_VACIO)
            strSql_Resultados = strSql_Resultados.Replace("{filainicio}", NuevaLinea(Cierres.Actual.EjercicioActual, longPoliza))
            strSql_Resultados = strSql_Resultados.Replace("{id_cuentas}", "'xyz'")
            MyCnn.CONECTAR = strConexion & " Allow User Variables=True"
            COMM = New MySqlCommand(strSql_Resultados, CON)
            REA = COMM.ExecuteReader
            If REA.HasRows Then
                REA.Read()
                strTSaldo = REA.GetString("operacion")
            End If

            COMM.Dispose()
            COMM = Nothing
            CON.Close()
            CON.Dispose()
            CON = Nothing
            System.GC.Collect()

            If Sesion.idGiro = 2 Then
                If Tipo = INT_CERO Then
                    If strTSaldo = "A" Then
                        strCuentaEjercicioActual = CuentaEjercicioActual(8)
                    Else
                        strCuentaEjercicioActual = CuentaEjercicioActual(18)
                    End If
                ElseIf Tipo = INT_UNO Then
                    If strTSaldo = "A" Then
                        strCuentaEjercicioActual = CuentaEjercicioActual(9)
                    Else
                        strCuentaEjercicioActual = CuentaEjercicioActual(19)
                    End If
                End If
            Else
                If Tipo = INT_CERO Then
                    strCuentaEjercicioActual = CuentaEjercicioActual(8)
                ElseIf Tipo = INT_UNO Then
                    strCuentaEjercicioActual = CuentaEjercicioActual(9)
                End If
            End If
            strSql_Resultados = strSQLInsert & strSql_Resultados
            strSql_Resultados = strSql_Resultados.Replace("xyz", strCuentaEjercicioActual)

            MyCnn.CONECTAR = strConexion & " Allow User Variables=True"
            COM = New MySqlCommand(strSql_Resultados, CON)
            COM.ExecuteNonQuery()
            logResultado = True
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        Return logResultado
    End Function

    Private Sub CerrarEjercicio()
        Dim strSQl As String = STR_VACIO
        Dim COM As MySqlCommand
        Try
            strSQl = " UPDATE {conta}.parametros_empresa SET valor= {ejerAct}, fecha_actualizacion = CURDATE() 
                       WHERE empresa = {empresa} AND parametro = 7 "
            If Sesion.IdEmpresa = 18 Then
                strSQl &= "; UPDATE contapdm.parametros_empresa SET valor= {ejerAct}, fecha_actualizacion = CURDATE() 
                       WHERE empresa = {empresa} AND parametro = 7 "
            End If

            strSQl = strSQl.Replace("{conta}", Sesion.BaseConta)
            strSQl = strSQl.Replace("{empresa}", Sesion.IdEmpresa)
            strSQl = strSQl.Replace("{ejerAct}", Cierres.Actual.EjercicioActual)

            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSQl, CON)
            COM.ExecuteNonQuery()


            strSQl = " UPDATE {conta}.ejercicio_empresa SET estado = 'C' , fecha_act = CURDATE() 
                      WHERE empresa = {empresa} AND ejercicio = {ejerActual} AND estado = 'A' "
            If Sesion.IdEmpresa = 18 Then
                strSQl &= "; UPDATE contapdm.ejercicio_empresa SET estado = 'C' , fecha_act = CURDATE() 
                      WHERE empresa = {empresa} AND ejercicio = {ejerActual} AND estado = 'A' "
            End If

            strSQl = strSQl.Replace("{conta}", Sesion.BaseConta)
            strSQl = strSQl.Replace("{empresa}", Sesion.IdEmpresa)
            strSQl = strSQl.Replace("{ejerActual}", Cierres.Actual.EjercicioActual)

            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSQl, CON)
            COM.ExecuteNonQuery()

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub AbrirEjercicioSiguiente()
        Dim strSQl As String = STR_VACIO
        Dim COM As MySqlCommand
        Try
            strSQl = " UPDATE {conta}.parametros_empresa SET valor= {ejerAct} , fecha_actualizacion = CURDATE() 
                      WHERE empresa = {empresa} AND parametro = 3; "
            If Sesion.IdEmpresa = 18 Then
                strSQl &= " UPDATE contapdm.parametros_empresa SET valor= {ejerAct}, fecha_actualizacion = CURDATE() 
                       WHERE empresa = {empresa} AND parametro = 3 "
            End If

            strSQl = strSQl.Replace("{conta}", Sesion.BaseConta)
            strSQl = strSQl.Replace("{empresa}", Sesion.IdEmpresa)
            strSQl = strSQl.Replace("{ejerAct}", Cierres.Siguiente.EjercicioActual)

            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSQl, CON)
            COM.ExecuteNonQuery()

            strSQl = " UPDATE {conta}.ejercicio_empresa SET estado = 'A' , fecha_act = CURDATE() 
                      WHERE empresa = {empresa} AND ejercicio = {ejerActual} AND estado = 'C' "
            If Sesion.IdEmpresa = 18 Then
                strSQl &= "; UPDATE contapdm.ejercicio_empresa SET estado = 'A' , fecha_act = CURDATE() 
                      WHERE empresa = {empresa} AND ejercicio = {ejerActual} AND estado = 'C' "
            End If

            strSQl = strSQl.Replace("{conta}", Sesion.BaseConta)
            strSQl = strSQl.Replace("{empresa}", Sesion.IdEmpresa)
            strSQl = strSQl.Replace("{ejerActual}", Cierres.Siguiente.EjercicioActual)

            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSQl, CON)
            COM.ExecuteNonQuery()


        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Public Sub CierresyAperturas()
        Dim frm As New frmMensaje
        Dim crport As New clsReportes
        Try
            If VerificarDatos() = True Then 'Verificar saldos
                frm.Mensaje = " Generando Saldos... "
                frm.Show()
                system.Windows.Forms.Application.DoEvents()
                If GenerarSaldos() = True Then ' Generar Saldos
                    frm.etiquetaMensaje.Text = " Generando Poliza de Dudores... "
                    frm.Show()
                    system.Windows.Forms.Application.DoEvents()
                    'Generar poliza de cierre Deudores
                    If GenerarPolizaResutaldos(TIPO_DEUDOR) = True Then
                        frm.etiquetaMensaje.Text = " Generando Poliza de Acreedores... "
                        frm.Show()
                        system.Windows.Forms.Application.DoEvents()
                        'Generar poliza de cierre Acreedores
                        If GenerarPolizaResutaldos(TIPO_ACREEDOR) Then
                            frm.etiquetaMensaje.Text = " Generando Poliza de Cierre... "
                            frm.Show()
                            system.Windows.Forms.Application.DoEvents()
                            ' Generar poliza de Cierre-------------------------------------------------------------------
                            If GenerarPolizadeCierreyApertura(INT_CERO) Then
                                frm.etiquetaMensaje.Text = " Generando Poliza de Apertura... "
                                frm.Show()
                                system.Windows.Forms.Application.DoEvents()
                                ' Generar poliza de Apertura
                                If GenerarPolizadeCierreyApertura(INT_UNO) Then
                                    frm.Hide()
                                    CerrarEjercicio()
                                    AbrirEjercicioSiguiente()
                                    crport.ImprimirPolizasCierre(CierreAno, CierrePoliza)
                                Else
                                    MsgBox(" No se pude generar la partida de apertura Proceso Cancelado")
                                End If
                            Else
                                MsgBox("No se pude generar la partida de cierre Proceso Cancelado")
                            End If
                        Else
                            MsgBox("No se pudo generar poliza de cierre Acreedores. Proceso Cancelado")
                        End If
                    Else
                        MsgBox("No se pudo generar poliza de cierre Deudores. Proceso Cancelado")
                    End If
                Else
                    MsgBox("No se pudieron generar saldos. Proceso Cancelado")
                End If
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
            frm.Close()
        End Try
    End Sub

#End Region

#Region " Anticipos Compras "

    Private Function GererarPolizaAnticipo(ByVal cat As Integer, ByVal anio As Integer, ByVal num As Integer) As Boolean
        Dim LogResultado As Boolean
        Dim strSQL As String = STR_VACIO
        Dim COM As MySqlCommand
        Try
            strSQL = " SELECT h.HDoc_Ant_Com  
                        FROM Dcmtos_HDR h
                        WHERE h.HDoc_Sis_Emp = {empresa} AND h.HDoc_Doc_Cat = {catalogo} AND h.HDoc_Doc_Ano = {ano} AND  h.HDoc_Doc_Num = {numero} "

            strSQL = strSQL.Replace("{empresa}", Sesion.IdEmpresa)
            strSQL = strSQL.Replace("{catalogo}", cat)
            strSQL = strSQL.Replace("{ano}", anio)
            strSQL = strSQL.Replace("{numero}", num)

            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSQL, CON)
            If COM.ExecuteScalar = INT_UNO Then
                LogResultado = True
            Else
                LogResultado = False
            End If

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        Return LogResultado
    End Function

    Private Sub PolizaAnticipoCompra(ByVal cat As Integer, ByVal anio As Integer, ByVal num As Integer, ByVal fecha As Date)
        Dim longPolizas As Long = NO_FILA
        Dim COM As MySqlCommand
        Dim strSQL As String = STR_VACIO
        Dim TipoIng As Integer
        Dim tipoAnticipo As Integer

        strSQL = " SELECT h.HDoc_Emp_Cod
                        FROM Dcmtos_HDR h
                        WHERE h.HDoc_Sis_Emp = {empresa} AND h.HDoc_Doc_Cat = {catalogo} AND h.HDoc_Doc_Ano = {ano} AND  h.HDoc_Doc_Num = {numero} "

        strSQL = strSQL.Replace("{empresa}", Sesion.IdEmpresa)
        strSQL = strSQL.Replace("{catalogo}", cat)
        strSQL = strSQL.Replace("{ano}", anio)
        strSQL = strSQL.Replace("{numero}", num)

        MyCnn.CONECTAR = strConexion
        COM = New MySqlCommand(strSQL, CON)
        tipoAnticipo = COM.ExecuteScalar()

        Try
            If GererarPolizaAnticipo(cat, anio, num) = True Then

                strSQL = STR_VACIO
                longPolizas = NuevaPoliza()
                UltimaPoliza(longPolizas, EJERCICIO) ' actualiza la ultima poliza

                strSQL = SQLEncabezadoAnticipoCompra(longPolizas, cat, anio, num, fecha)
                MyCnn.CONECTAR = strConexion
                COM = New MySqlCommand(strSQL, CON)
                COM.ExecuteNonQuery()
                strSQL = STR_VACIO

                If tipoAnticipo = 0 Then
                    strSQL = SQLDetalleAnticipoCompra(longPolizas, cat, anio, num, TipoIng)
                ElseIf tipoAnticipo = 1 Then
                    strSQL = SQLDetalleAnticipoCompraLiquidacion(longPolizas, cat, anio, num, TipoIng)
                End If

                MyCnn.CONECTAR = strConexion & " Allow User Variables=True"
                COM = New MySqlCommand(strSQL, CON)
                COM.ExecuteNonQuery()
                strSQL = STR_VACIO

                strSQL = SQLDetalleLineaAnticipo(longPolizas, cat, anio, num, TipoIng)
                MyCnn.CONECTAR = strConexion
                COM = New MySqlCommand(strSQL, CON)
                COM.ExecuteNonQuery()
                strSQL = STR_VACIO
            Else
                cFunciones.BorrarEncabezadoPoliza(num, anio, 689)
                cFunciones.BorrarDetallePoliza(num, anio, 689)
            End If


        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Function SQLEncabezadoAnticipoCompra(ByVal poliza As Integer, ByVal cat As Integer, ByVal anio As Integer, ByVal num As Integer, ByVal fecha As Date)
        Dim strsql As String = STR_VACIO

        strsql = " INSERT INTO {conta}.polizas"
        strsql &= "   SELECT h.HDoc_Sis_Emp empresa, {ejercicio} ejercicio, {poliza} poliza, '{fec}' fecha, h.HDoc_Emp_Dir concepto, {tipoPoliza} tipo, HDoc_Doc_TC TC, '' observacion, '{user}' operador, 'C' estado, NOW() marca,'' grupo, {tipoPoliza} modo, h.HDoc_Doc_Cat refTipo, h.HDoc_Doc_Ano refCiclo, h.HDoc_Doc_Num refNumero, NULL divisa, h.HDoc_Doc_TC Tasa,0 revisado,'' usuarioRev, NULL ultRev "
        strsql &= "      FROM Dcmtos_HDR h "
        strsql &= "         WHERE h.HDoc_Sis_Emp = {empresa} AND h.HDoc_Doc_Cat = {cat} AND h.HDoc_Doc_Ano = {anio} AND h.HDoc_Doc_Num = {num} "
        If Sesion.IdEmpresa = 18 Then
            strsql &= "; INSERT INTO contapdm.polizas"
            strsql &= "   SELECT h.HDoc_Sis_Emp empresa, {ejercicio} ejercicio, {poliza} poliza, '{fec}' fecha, h.HDoc_Emp_Dir concepto, {tipoPoliza} tipo, HDoc_Doc_TC TC, '' observacion, '{user}' operador, 'C' estado, NOW() marca,'' grupo, {tipoPoliza} modo, h.HDoc_Doc_Cat refTipo, h.HDoc_Doc_Ano refCiclo, h.HDoc_Doc_Num refNumero, NULL divisa, h.HDoc_Doc_TC Tasa,0 revisado,'' usuarioRev, NULL ultRev "
            strsql &= "      FROM PDM.Dcmtos_HDR h "
            strsql &= "         WHERE h.HDoc_Sis_Emp = {empresa} AND h.HDoc_Doc_Cat = {cat} AND h.HDoc_Doc_Ano = {anio} AND h.HDoc_Doc_Num = {num} "
        End If

        strsql = Replace(strsql, "{tipoPoliza}", 27)

        strsql = Replace(strsql, "{ejercicio}", EJERCICIO)
        strsql = Replace(strsql, "{poliza}", poliza)
        strsql = Replace(strsql, "{empresa}", Sesion.IdEmpresa)
        strsql = Replace(strsql, "{cat}", cat)
        strsql = Replace(strsql, "{anio}", anio)
        strsql = Replace(strsql, "{num}", num)
        strsql = Replace(strsql, "{conta}", Sesion.BaseConta)
        strsql = Replace(strsql, "{fec}", fecha.ToString(FORMATO_MYSQL))
        strsql = Replace(strsql, "{user}", Sesion.Usuario)

        Return strsql
    End Function

    Private Function SQLDetalleAnticipoCompra(ByVal poliza As Integer, ByVal cat As Integer, ByVal anio As Integer, ByVal num As Integer, ByVal TipoIng As Integer)
        Dim strsql As String = STR_VACIO

        strsql = "INSERT INTO {conta}.detalle_polizas "
        strsql &= " Select 0 Transaccion,h.HDoc_Sis_Emp empresa , {ejercicio},{poliza}, @fila:=@fila+1 AS linea,p.pro_cuenta cuenta,0 parametro_cuenta, sum(d.DDoc_Prd_NET * h.HDoc_Doc_TC)  importe,
                    '' centro_costos, '' partida_presupuestal,'C',h.HDoc_Doc_Fec fecha ,'',27 modo,d.DDoc_Doc_Cat , d.DDoc_Doc_Ano , d.DDoc_Doc_Num ,0
                    FROM (SELECT @fila:=0) r,  Dcmtos_DTL d
                        LEFT JOIN Dcmtos_HDR h ON h.HDoc_Sis_Emp = d.DDoc_Sis_Emp AND h.HDoc_Doc_Cat = d.DDoc_RF1_Num AND h.HDoc_Doc_Ano = d.DDoc_RF2_Num AND h.HDoc_Doc_Num = d.DDoc_RF3_Num
                        LEFT JOIN Proveedores p ON p.pro_sisemp = h.HDoc_Sis_Emp AND p.pro_codigo = h.HDoc_Emp_Cod
                    WHERE d.DDoc_Sis_Emp = {empresa} AND d.DDoc_Doc_Cat = {cat} AND d.DDoc_Doc_Ano = {anio} AND d.DDoc_Doc_Num = {num}
                    GROUP BY p.pro_cuenta "

        If Sesion.IdEmpresa = 18 Then
            strsql &= ";INSERT INTO contapdm.detalle_polizas "
            strsql &= " Select 0 Transaccion,h.HDoc_Sis_Emp empresa , {ejercicio},{poliza}, @fila:=@fila+1 AS linea,p.pro_cuenta cuenta,0 parametro_cuenta, sum(d.DDoc_Prd_NET * h.HDoc_Doc_TC)  importe,
                    '' centro_costos, '' partida_presupuestal,'C',h.HDoc_Doc_Fec fecha ,'',27 modo,d.DDoc_Doc_Cat , d.DDoc_Doc_Ano , d.DDoc_Doc_Num ,0
                    FROM (SELECT @fila:=0) r,  PDM.Dcmtos_DTL d
                        LEFT JOIN PDM.Dcmtos_HDR h ON h.HDoc_Sis_Emp = d.DDoc_Sis_Emp AND h.HDoc_Doc_Cat = d.DDoc_RF1_Num AND h.HDoc_Doc_Ano = d.DDoc_RF2_Num AND h.HDoc_Doc_Num = d.DDoc_RF3_Num
                        LEFT JOIN PDM.Proveedores p ON p.pro_sisemp = h.HDoc_Sis_Emp AND p.pro_codigo = h.HDoc_Emp_Cod
                    WHERE d.DDoc_Sis_Emp = {empresa} AND d.DDoc_Doc_Cat = {cat} AND d.DDoc_Doc_Ano = {anio} AND d.DDoc_Doc_Num = {num}
                    GROUP BY p.pro_cuenta "
        End If

        strsql = Replace(strsql, "{empresa}", Sesion.IdEmpresa)
        strsql = Replace(strsql, "{conta}", Sesion.BaseConta)
        strsql = Replace(strsql, "{ejercicio}", EJERCICIO)
        strsql = Replace(strsql, "{poliza}", poliza)
        strsql = Replace(strsql, "{cat}", cat)
        strsql = Replace(strsql, "{anio}", anio)
        strsql = Replace(strsql, "{num}", num)

        Return strsql
    End Function


    Private Function SQLDetalleAnticipoCompraLiquidacion(ByVal poliza As Integer, ByVal cat As Integer, ByVal anio As Integer, ByVal num As Integer, ByVal TipoIng As Integer)
        Dim strsql As String = STR_VACIO

        strsql = "INSERT INTO {conta}.detalle_polizas "
        strsql &= " Select 0 Transaccion,h.HDoc_Sis_Emp empresa , {ejercicio},{poliza}, @fila:=@fila+1 AS linea,c.BCta_Cuenta cuenta,0 parametro_cuenta, 
                    sum(d.DDoc_Prd_NET * h.HDoc_Doc_TC)  importe,'' centro_costos, '' partida_presupuestal,'C',h.HDoc_Doc_Fec fecha ,'',27 modo,d.DDoc_Doc_Cat , d.DDoc_Doc_Ano , d.DDoc_Doc_Num ,0
                    FROM (SELECT @fila:=0) r,  Dcmtos_DTL d
                        LEFT JOIN Dcmtos_HDR h ON h.HDoc_Sis_Emp = d.DDoc_Sis_Emp AND h.HDoc_Doc_Cat = d.DDoc_RF1_Num AND h.HDoc_Doc_Ano = d.DDoc_RF2_Num AND h.HDoc_Doc_Num = d.DDoc_RF3_Num
                        LEFT JOIN CtasBcos c ON c.BCta_Sis_Emp = d.DDoc_Sis_Emp AND c.BCta_Num = d.DDoc_Prd_UM
                    WHERE d.DDoc_Sis_Emp = {empresa} AND d.DDoc_Doc_Cat = {cat} AND d.DDoc_Doc_Ano = {anio} AND d.DDoc_Doc_Num = {num}
                    GROUP BY c.BCta_Cuenta "
        If Sesion.IdEmpresa = 18 Then
            strsql &= ";INSERT INTO contapdm.detalle_polizas "
            strsql &= " Select 0 Transaccion,h.HDoc_Sis_Emp empresa , {ejercicio},{poliza}, @fila:=@fila+1 AS linea,c.BCta_Cuenta cuenta,0 parametro_cuenta, 
                    sum(d.DDoc_Prd_NET * h.HDoc_Doc_TC)  importe,'' centro_costos, '' partida_presupuestal,'C',h.HDoc_Doc_Fec fecha ,'',27 modo,d.DDoc_Doc_Cat , d.DDoc_Doc_Ano , d.DDoc_Doc_Num ,0
                    FROM (SELECT @fila:=0) r, PDM.Dcmtos_DTL d
                        LEFT JOIN PDM.Dcmtos_HDR h ON h.HDoc_Sis_Emp = d.DDoc_Sis_Emp AND h.HDoc_Doc_Cat = d.DDoc_RF1_Num AND h.HDoc_Doc_Ano = d.DDoc_RF2_Num AND h.HDoc_Doc_Num = d.DDoc_RF3_Num
                        LEFT JOIN PDM.CtasBcos c ON c.BCta_Sis_Emp = d.DDoc_Sis_Emp AND c.BCta_Num = d.DDoc_Prd_UM
                    WHERE d.DDoc_Sis_Emp = {empresa} AND d.DDoc_Doc_Cat = {cat} AND d.DDoc_Doc_Ano = {anio} AND d.DDoc_Doc_Num = {num}
                    GROUP BY c.BCta_Cuenta "
        End If


        strsql = Replace(strsql, "{empresa}", Sesion.IdEmpresa)
        strsql = Replace(strsql, "{conta}", Sesion.BaseConta)
        strsql = Replace(strsql, "{ejercicio}", EJERCICIO)
        strsql = Replace(strsql, "{poliza}", poliza)
        strsql = Replace(strsql, "{cat}", cat)
        strsql = Replace(strsql, "{anio}", anio)
        strsql = Replace(strsql, "{num}", num)


        Return strsql
    End Function

    Private Function SQLDetalleLineaAnticipo(ByVal poliza As Integer, ByVal cat As Integer, ByVal anio As Integer, ByVal num As Integer, ByVal TipoIng As Integer)
        Dim strsql As String = STR_VACIO

        strsql = "INSERT INTO {conta}.detalle_polizas "
        strsql &= " Select 0 Transaccion,h.HDoc_Sis_Emp empresa , {ejercicio},{poliza}, {linea} linea, IF(d.DDoc_Sis_Emp IN(15,20), d.DDoc_RF1_Txt, (SELECT t.valor  
                    FROM {conta}.parametros_empresa   t WHERE t.empresa   = {empresa} AND t.parametro  = 32)) cuenta,0 parametro_cuenta, sum(d.DDoc_Prd_NET * h.HDoc_Doc_TC)  importe,'' centro_costos, 
                    '' partida_presupuestal,'A',h.HDoc_Doc_Fec fecha ,'',27 modo,d.DDoc_Doc_Cat , d.DDoc_Doc_Ano , d.DDoc_Doc_Num ,0
                    FROM Dcmtos_DTL d
                        LEFT JOIN Dcmtos_HDR h ON h.HDoc_Sis_Emp = d.DDoc_Sis_Emp AND h.HDoc_Doc_Cat = d.DDoc_RF1_Num AND h.HDoc_Doc_Ano = d.DDoc_RF2_Num AND h.HDoc_Doc_Num = d.DDoc_RF3_Num
                    WHERE d.DDoc_Sis_Emp = {empresa} AND d.DDoc_Doc_Cat = {cat} AND d.DDoc_Doc_Ano = {anio} AND d.DDoc_Doc_Num = {num} {agrupar} "
        If Sesion.IdEmpresa = 18 Then
            strsql &= ";INSERT INTO contapdm.detalle_polizas "
            strsql &= " Select 0 Transaccion,h.HDoc_Sis_Emp empresa , {ejercicio},{poliza}, {linea} linea, IF(d.DDoc_Sis_Emp IN(15,20), d.DDoc_RF1_Txt, (SELECT t.valor  
                    FROM contapdm.parametros_empresa   t WHERE t.empresa   = {empresa} AND t.parametro  = 32)) cuenta,0 parametro_cuenta, sum(d.DDoc_Prd_NET * h.HDoc_Doc_TC)  importe,'' centro_costos, 
                    '' partida_presupuestal,'A',h.HDoc_Doc_Fec fecha ,'',27 modo,d.DDoc_Doc_Cat , d.DDoc_Doc_Ano , d.DDoc_Doc_Num ,0
                    FROM PDM.Dcmtos_DTL d
                        LEFT JOIN PDM.Dcmtos_HDR h ON h.HDoc_Sis_Emp = d.DDoc_Sis_Emp AND h.HDoc_Doc_Cat = d.DDoc_RF1_Num AND h.HDoc_Doc_Ano = d.DDoc_RF2_Num AND h.HDoc_Doc_Num = d.DDoc_RF3_Num
                    WHERE d.DDoc_Sis_Emp = {empresa} AND d.DDoc_Doc_Cat = {cat} AND d.DDoc_Doc_Ano = {anio} AND d.DDoc_Doc_Num = {num} {agrupar} "
        End If

        If Sesion.IdEmpresa = 15 Or Sesion.IdEmpresa = 20 Then
            strsql = strsql.Replace("{agrupar}", " GROUP BY d.DDoc_RF1_Txt ")
        Else
            strsql = strsql.Replace("{agrupar}", STR_VACIO)
        End If

        strsql = Replace(strsql, "{empresa}", Sesion.IdEmpresa)
        strsql = Replace(strsql, "{conta}", Sesion.BaseConta)
        strsql = Replace(strsql, "{ejercicio}", EJERCICIO)
        strsql = Replace(strsql, "{poliza}", poliza)
        strsql = Replace(strsql, "{cat}", cat)
        strsql = Replace(strsql, "{anio}", anio)
        strsql = Replace(strsql, "{num}", num)
        strsql = Replace(strsql, "{linea}", (NuevaLinea(EJERCICIO, poliza) + 1).ToString)


        Return strsql
    End Function

#End Region
#Region "Poliza de Costo de Consumibles"
    Private Sub PólizaCostoConsumibles(ByVal cat As Integer, ByVal anio As Integer, ByVal num As Integer, ByVal fecha As Date)
        Dim longPolizas As Long = NO_FILA
        Dim COM As MySqlCommand
        Dim strSQL As String = STR_VACIO
        'Dim TipoIng As Integer
        'Dim tipoAnticipo As Integer

        strSQL = STR_VACIO
        longPolizas = NuevaPoliza()
        UltimaPoliza(longPolizas, EJERCICIO) ' actualiza la ultima poliza

        strSQL = SqlEncabezadoCostoConsumibles(longPolizas, cat, anio, num, fecha)
        MyCnn.CONECTAR = strConexion
        COM = New MySqlCommand(strSQL, CON)
        COM.ExecuteNonQuery()
        strSQL = STR_VACIO

        strSQL = SqlDetalleCostoConsumibles(longPolizas, cat, anio, num, fecha)
        MyCnn.CONECTAR = strConexion & " Allow User Variables=True"
        COM = New MySqlCommand(strSQL, CON)
        COM.ExecuteNonQuery()
        strSQL = STR_VACIO
    End Sub
    Private Function SqlEncabezadoCostoConsumibles(ByVal poliza As Integer, ByVal cat As Integer, ByVal anio As Integer, ByVal num As Integer, ByVal fecha As Date)
        Dim strsql As String = STR_VACIO

        strsql = " INSERT INTO {conta}.polizas"
        strsql &= "   SELECT h.HDoc_Sis_Emp empresa, {ejercicio} ejercicio, {poliza} poliza, '{fec}' fecha, CONCAT('Póliza de Costo Consumibles, Registro No. ', h.HDoc_Dr1_Dbl) concepto, {tipoPoliza} tipo, 1 TC, '' observacion, '{user}' operador, 'C' estado, NOW() marca,'' grupo, {tipoPoliza} modo, h.HDoc_Doc_Cat refTipo, h.HDoc_Doc_Ano refCiclo, h.HDoc_Doc_Num refNumero, NULL divisa, 1 Tasa,0 revisado,'' usuarioRev, NULL ultRev "
        strsql &= "      FROM Dcmtos_HDR h "
        'strsql &= "      FROM Dcmtos_DTL d ON d.DDoc_Sis_Emp = h.HDoc_Sis_Emp and d.DDoc_Doc_Cat = h.HDoc_Doc_Cat and d.DDoc_Doc_Ano = h.HDoc_Doc_Ano  and d.DDoc_Doc_Num = h.HDoc_Doc_Num "
        strsql &= "         WHERE h.HDoc_Sis_Emp = {empresa} AND h.HDoc_Doc_Cat = {cat} AND h.HDoc_Doc_Ano = {anio} AND h.HDoc_Doc_Num = {num} "
        If Sesion.IdEmpresa = 18 Then
            strsql &= "; INSERT INTO contapdm.polizas"
            strsql &= "   SELECT h.HDoc_Sis_Emp empresa, {ejercicio} ejercicio, {poliza} poliza, '{fec}' fecha, CONCAT('Póliza de Costo Consumibles, Registro No. ', h.HDoc_Dr1_Dbl) concepto, {tipoPoliza} tipo, 1 TC, '' observacion, '{user}' operador, 'C' estado, NOW() marca,'' grupo, {tipoPoliza} modo, h.HDoc_Doc_Cat refTipo, h.HDoc_Doc_Ano refCiclo, h.HDoc_Doc_Num refNumero, NULL divisa, 1 Tasa,0 revisado,'' usuarioRev, NULL ultRev "
            strsql &= "      FROM PDM.Dcmtos_HDR h "
            strsql &= "         WHERE h.HDoc_Sis_Emp = {empresa} AND h.HDoc_Doc_Cat = {cat} AND h.HDoc_Doc_Ano = {anio} AND h.HDoc_Doc_Num = {num} "
        End If

        strsql = Replace(strsql, "{tipoPoliza}", 33)

        strsql = Replace(strsql, "{ejercicio}", EJERCICIO)
        strsql = Replace(strsql, "{poliza}", poliza)
        strsql = Replace(strsql, "{empresa}", Sesion.IdEmpresa)
        strsql = Replace(strsql, "{cat}", cat)
        strsql = Replace(strsql, "{anio}", anio)
        strsql = Replace(strsql, "{num}", num)
        strsql = Replace(strsql, "{conta}", Sesion.BaseConta)
        strsql = Replace(strsql, "{fec}", fecha.ToString(FORMATO_MYSQL))
        strsql = Replace(strsql, "{user}", Sesion.Usuario)

        Return strsql
    End Function

    Private Function SqlDetalleCostoConsumibles(ByVal poliza As Integer, ByVal cat As Integer, ByVal anio As Integer, ByVal num As Integer, ByVal fecha As Date)
        Dim strSql As String = STR_VACIO

        strSql = " INSERT INTO {conta}.detalle_polizas

                    SELECT s1.transaccion, s1.empresa, s1.ejercicio, s1.poliza, (@REG := @REG + 1) item, IFNULL(s1.cuenta,''), s1.parametro_cuenta, s1.importe, centro_costos, IFNULL(s1.partida_presupuestal,''), s1.operacion, s1.fecha, IFNULL(s1.clase,''), s1.modo, s1.ref_tipo, s1.ref_ciclo, s1.ref_numero, s1.ref_id
                    FROM(                    

                    SELECT 0 transaccion, h.HDoc_Sis_Emp empresa, {ejercicio} ejercicio, {poliza} poliza, @REG :=0, d.DDoc_RF2_Cod cuenta, h.HDoc_DR1_Cat parametro_cuenta, ROUND(SUM(d.DDoc_Prd_QTY * d.DDoc_Prd_NET * d.DDoc_Prd_Cif),2) Importe,c.cost_num centro_costos, NULL partida_presupuestal, 'C' operacion, CAST(CURDATE() AS CHAR) fecha, 0 clase, 33 modo, h.HDoc_Doc_Cat ref_tipo, h.HDoc_Doc_Ano ref_ciclo, h.HDoc_Doc_Num ref_numero, d.DDoc_Prd_Cod ref_id 
                        FROM Dcmtos_HDR h  
                        LEFT JOIN Dcmtos_DTL d ON d.DDoc_Sis_Emp = h.HDoc_Sis_Emp AND d.DDoc_Doc_Cat = h.HDoc_Doc_Cat AND d.DDoc_Doc_Ano = h.HDoc_Doc_Ano AND d.DDoc_Doc_Num = h.HDoc_Doc_Num
                        LEFT JOIN Dcmtos_IMP im ON im.MDoc_Sis_Emp = d.DDoc_Sis_Emp AND im.MDoc_Doc_Cat = d.DDoc_Doc_Cat AND im.MDoc_Doc_Ano = d.DDoc_Doc_Ano AND im.MDoc_Doc_Num = d.DDoc_Doc_Num  
                        LEFT JOIN {conta}.costos c ON c.cost_nombre = h.HDoc_Emp_Dir 
                            WHERE h.HDoc_Sis_Emp = {empresa} AND h.HDoc_Doc_Cat = {cat} AND h.HDoc_Doc_Ano = {anio} AND h.HDoc_Doc_Num = {num} 
                            GROUP BY d.DDoc_RF2_Cod

                        UNION

                    SELECT 0 transaccion, h.HDoc_Sis_Emp empresa, {ejercicio} ejercicio, {poliza} poliza, @REG :=0, v.inventario cuenta, h.HDoc_DR1_Cat parametro_cuenta, ROUND(SUM(d.DDoc_Prd_QTY * d.DDoc_Prd_NET * d.DDoc_Prd_Cif),2) Importe,'' centro_costos, NULL partida_presupuestal, 'A' operacion, CAST(CURDATE() AS CHAR) fecha, a.art_clase clase, 33 modo, h.HDoc_Doc_Cat ref_tipo, h.HDoc_Doc_Ano ref_ciclo, h.HDoc_Doc_Num ref_numero, d.DDoc_Prd_Cod ref_id
                            FROM Dcmtos_HDR h
                            LEFT JOIN Dcmtos_DTL d ON d.DDoc_Sis_Emp = h.HDoc_Sis_Emp AND d.DDoc_Doc_Cat = h.HDoc_Doc_Cat AND d.DDoc_Doc_Ano = h.HDoc_Doc_Ano AND d.DDoc_Doc_Num = h.HDoc_Doc_Num
                            LEFT JOIN Inventarios i ON i.inv_sisemp = d.DDoc_Sis_Emp AND i.inv_numero = d.DDoc_Prd_Cod
                            LEFT JOIN Articulos a ON a.art_sisemp = i.inv_sisemp AND a.art_codigo = i.inv_artcodigo
                            LEFT JOIN {conta}.inventario_codigos v ON v.empresa = a.art_sisemp AND v.clase = a.art_clase AND v.ejercicio = 1
                            LEFT JOIN {conta}.costos c ON c.cost_nombre = h.HDoc_Emp_Dir
                                WHERE h.HDoc_Sis_Emp = {empresa} AND h.HDoc_Doc_Cat = {cat} AND h.HDoc_Doc_Ano = {anio} AND h.HDoc_Doc_Num = {num} 
                                GROUP BY a.art_clase)s1"
        If Sesion.IdEmpresa = 18 Then
            strSql &= "; INSERT INTO contapdm.detalle_polizas

                    SELECT s1.transaccion, s1.empresa, s1.ejercicio, s1.poliza, (@REG := @REG + 1) item, IFNULL(s1.cuenta,''), s1.parametro_cuenta, s1.importe, centro_costos, IFNULL(s1.partida_presupuestal,''), s1.operacion, s1.fecha, IFNULL(s1.clase,''), s1.modo, s1.ref_tipo, s1.ref_ciclo, s1.ref_numero, s1.ref_id
                    FROM(                    

                    SELECT 0 transaccion, h.HDoc_Sis_Emp empresa, {ejercicio} ejercicio, {poliza} poliza, @REG :=0, d.DDoc_RF2_Cod cuenta, h.HDoc_DR1_Cat parametro_cuenta, ROUND(SUM(d.DDoc_Prd_QTY * d.DDoc_Prd_NET * d.DDoc_Prd_Cif),2) Importe,c.cost_num centro_costos, NULL partida_presupuestal, 'C' operacion, CAST(CURDATE() AS CHAR) fecha, 0 clase, 33 modo, h.HDoc_Doc_Cat ref_tipo, h.HDoc_Doc_Ano ref_ciclo, h.HDoc_Doc_Num ref_numero, d.DDoc_Prd_Cod ref_id 
                        FROM PDM.Dcmtos_HDR h  
                        LEFT JOIN PDM.Dcmtos_DTL d ON d.DDoc_Sis_Emp = h.HDoc_Sis_Emp AND d.DDoc_Doc_Cat = h.HDoc_Doc_Cat AND d.DDoc_Doc_Ano = h.HDoc_Doc_Ano AND d.DDoc_Doc_Num = h.HDoc_Doc_Num
                        LEFT JOIN PDM.Dcmtos_IMP im ON im.MDoc_Sis_Emp = d.DDoc_Sis_Emp AND im.MDoc_Doc_Cat = d.DDoc_Doc_Cat AND im.MDoc_Doc_Ano = d.DDoc_Doc_Ano AND im.MDoc_Doc_Num = d.DDoc_Doc_Num  
                        LEFT JOIN contapdm.costos c ON c.cost_nombre = h.HDoc_Emp_Dir 
                            WHERE h.HDoc_Sis_Emp = {empresa} AND h.HDoc_Doc_Cat = {cat} AND h.HDoc_Doc_Ano = {anio} AND h.HDoc_Doc_Num = {num} 
                            GROUP BY d.DDoc_RF2_Cod

                        UNION

                    SELECT 0 transaccion, h.HDoc_Sis_Emp empresa, {ejercicio} ejercicio, {poliza} poliza, @REG :=0, v.inventario cuenta, h.HDoc_DR1_Cat parametro_cuenta, ROUND(SUM(d.DDoc_Prd_QTY * d.DDoc_Prd_NET * d.DDoc_Prd_Cif),2) Importe,'' centro_costos, NULL partida_presupuestal, 'A' operacion, CAST(CURDATE() AS CHAR) fecha, a.art_clase clase, 33 modo, h.HDoc_Doc_Cat ref_tipo, h.HDoc_Doc_Ano ref_ciclo, h.HDoc_Doc_Num ref_numero, d.DDoc_Prd_Cod ref_id
                            FROM PDM.Dcmtos_HDR h
                            LEFT JOIN PDM.Dcmtos_DTL d ON d.DDoc_Sis_Emp = h.HDoc_Sis_Emp AND d.DDoc_Doc_Cat = h.HDoc_Doc_Cat AND d.DDoc_Doc_Ano = h.HDoc_Doc_Ano AND d.DDoc_Doc_Num = h.HDoc_Doc_Num
                            LEFT JOIN PDM.Inventarios i ON i.inv_sisemp = d.DDoc_Sis_Emp AND i.inv_numero = d.DDoc_Prd_Cod
                            LEFT JOIN PDM.Articulos a ON a.art_sisemp = i.inv_sisemp AND a.art_codigo = i.inv_artcodigo
                            LEFT JOIN contapdm.inventario_codigos v ON v.empresa = a.art_sisemp AND v.clase = a.art_clase AND v.ejercicio = 1
                            LEFT JOIN contapdm.costos c ON c.cost_nombre = h.HDoc_Emp_Dir
                                WHERE h.HDoc_Sis_Emp = {empresa} AND h.HDoc_Doc_Cat = {cat} AND h.HDoc_Doc_Ano = {anio} AND h.HDoc_Doc_Num = {num} 
                                GROUP BY a.art_clase)s1"
        End If

        'strSql = Replace(strSql, "{tipoPoliza}", 33)

        strSql = Replace(strSql, "{ejercicio}", EJERCICIO)
        strSql = Replace(strSql, "{poliza}", poliza)
        strSql = Replace(strSql, "{empresa}", Sesion.IdEmpresa)
        strSql = Replace(strSql, "{cat}", cat)
        strSql = Replace(strSql, "{anio}", anio)
        strSql = Replace(strSql, "{num}", num)
        strSql = Replace(strSql, "{conta}", Sesion.BaseConta)
        'strSql = Replace(strSql, "{fec}", fecha.ToString(FORMATO_MYSQL))
        strSql = Replace(strSql, "{user}", Sesion.Usuario)

        Return strSql
    End Function
#End Region
#Region "Anticipos Ventas"
    Private Function GererarPolizaAnticipoVentas(ByVal cat As Integer, ByVal anio As Integer, ByVal num As Integer) As Boolean
        Dim LogResultado As Boolean
        Dim strSQL As String = STR_VACIO
        Dim COM As MySqlCommand
        Try
            strSQL = " SELECT h.HDoc_Ant_Com  
                        FROM Dcmtos_HDR h
                        WHERE h.HDoc_Sis_Emp = {empresa} AND h.HDoc_Doc_Cat = {catalogo} AND h.HDoc_Doc_Ano = {ano} AND  h.HDoc_Doc_Num = {numero} "

            strSQL = strSQL.Replace("{empresa}", Sesion.IdEmpresa)
            strSQL = strSQL.Replace("{catalogo}", cat)
            strSQL = strSQL.Replace("{ano}", anio)
            strSQL = strSQL.Replace("{numero}", num)

            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSQL, CON)
            If COM.ExecuteScalar = INT_UNO Then
                LogResultado = True
            Else
                LogResultado = False
            End If

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        Return LogResultado
    End Function
    Private Sub PolizaAnticipoVenta(ByVal cat As Integer, ByVal anio As Integer, ByVal num As Integer, ByVal fecha As Date)
        Dim longPolizas As Long = NO_FILA
        Dim COM As MySqlCommand
        Dim strSQL As String = STR_VACIO
        Dim TipoIng As Integer

        Try
            If GererarPolizaAnticipoVentas(cat, anio, num) = True Then

                strSQL = STR_VACIO
                longPolizas = NuevaPoliza()
                UltimaPoliza(longPolizas, EJERCICIO) ' actualiza la ultima poliza

                strSQL = SQLEncabezadoAnticipoVenta(longPolizas, cat, anio, num, fecha)
                MyCnn.CONECTAR = strConexion
                COM = New MySqlCommand(strSQL, CON)
                COM.ExecuteNonQuery()
                strSQL = STR_VACIO

                strSQL = SQLDetalleAnticipoVenta(longPolizas, cat, anio, num, TipoIng)
                MyCnn.CONECTAR = strConexion & " Allow User Variables=True"
                COM = New MySqlCommand(strSQL, CON)
                COM.ExecuteNonQuery()
                strSQL = STR_VACIO

                strSQL = SQLDetalleLineaAnticipoVenta(longPolizas, cat, anio, num, TipoIng)
                MyCnn.CONECTAR = strConexion
                COM = New MySqlCommand(strSQL, CON)
                COM.ExecuteNonQuery()
                strSQL = STR_VACIO

                strSQL = SQLDetalleDiferencialCambiarioAnticipoVenta(longPolizas, cat, anio, num, TipoIng)
                MyCnn.CONECTAR = strConexion
                COM = New MySqlCommand(strSQL, CON)
                COM.ExecuteNonQuery()
                strSQL = STR_VACIO

            Else
                cFunciones.BorrarEncabezadoPoliza(num, anio, 950)
                cFunciones.BorrarDetallePoliza(num, anio, 950)
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub
    Private Function SQLEncabezadoAnticipoVenta(ByVal poliza As Integer, ByVal cat As Integer, ByVal anio As Integer, ByVal num As Integer, ByVal fecha As Date)
        Dim strsql As String = STR_VACIO

        strsql = " INSERT INTO {conta}.polizas"
        strsql &= "   SELECT h.HDoc_Sis_Emp empresa, {ejercicio} ejercicio, {poliza} poliza, h.HDoc_Doc_Fec fecha, h.HDoc_Emp_Dir concepto, {tipoPoliza} tipo, HDoc_Doc_TC TC, '' observacion, '{user}' operador, 'C' estado, NOW() marca,'' grupo, {tipoPoliza} modo, h.HDoc_Doc_Cat refTipo, h.HDoc_Doc_Ano refCiclo, h.HDoc_Doc_Num refNumero, NULL divisa, h.HDoc_Doc_TC Tasa,0 revisado,'' usuarioRev, NULL ultRev "
        strsql &= "      FROM Dcmtos_HDR h "
        strsql &= "         WHERE h.HDoc_Sis_Emp = {empresa} AND h.HDoc_Doc_Cat = {cat} AND h.HDoc_Doc_Ano = {anio} AND h.HDoc_Doc_Num = {num} "
        If Sesion.IdEmpresa = 18 Then
            strsql &= "; INSERT INTO contapdm.polizas"
            strsql &= "   SELECT h.HDoc_Sis_Emp empresa, {ejercicio} ejercicio, {poliza} poliza, h.HDoc_Doc_Fec fecha, h.HDoc_Emp_Dir concepto, {tipoPoliza} tipo, HDoc_Doc_TC TC, '' observacion, '{user}' operador, 'C' estado, NOW() marca,'' grupo, {tipoPoliza} modo, h.HDoc_Doc_Cat refTipo, h.HDoc_Doc_Ano refCiclo, h.HDoc_Doc_Num refNumero, NULL divisa, h.HDoc_Doc_TC Tasa,0 revisado,'' usuarioRev, NULL ultRev "
            strsql &= "      FROM PDM.Dcmtos_HDR h "
            strsql &= "         WHERE h.HDoc_Sis_Emp = {empresa} AND h.HDoc_Doc_Cat = {cat} AND h.HDoc_Doc_Ano = {anio} AND h.HDoc_Doc_Num = {num} "
        End If

        strsql = Replace(strsql, "{tipoPoliza}", 28)

        strsql = Replace(strsql, "{ejercicio}", EJERCICIO)
        strsql = Replace(strsql, "{poliza}", poliza)
        strsql = Replace(strsql, "{empresa}", Sesion.IdEmpresa)
        strsql = Replace(strsql, "{cat}", cat)
        strsql = Replace(strsql, "{anio}", anio)
        strsql = Replace(strsql, "{num}", num)
        strsql = Replace(strsql, "{conta}", Sesion.BaseConta)
        strsql = Replace(strsql, "{fec}", fecha.ToString(FORMATO_MYSQL))
        strsql = Replace(strsql, "{user}", Sesion.Usuario)

        Return strsql
    End Function
    Private Function SQLDetalleAnticipoVenta(ByVal poliza As Integer, ByVal cat As Integer, ByVal anio As Integer, ByVal num As Integer, ByVal TipoIng As Integer)
        Dim strsql As String = STR_VACIO

        strsql = "INSERT INTO {conta}.detalle_polizas "
        strsql &= " Select 0 Transaccion,h.HDoc_Sis_Emp empresa , {ejercicio},{poliza}, @fila:=@fila+1 AS linea,p.cli_cuenta cuenta,0 parametro_cuenta, ROUND(sum(d.DDoc_Prd_NET * h.HDoc_Doc_TC),2)  importe,'' centro_costos, '' partida_presupuestal,'A',h.HDoc_Doc_Fec fecha ,'',28 modo,d.DDoc_Doc_Cat , d.DDoc_Doc_Ano , d.DDoc_Doc_Num ,0
                    FROM (SELECT @fila:=0) r,  Dcmtos_DTL d
                        LEFT JOIN Dcmtos_HDR h ON h.HDoc_Sis_Emp = d.DDoc_Sis_Emp AND h.HDoc_Doc_Cat = d.DDoc_RF1_Num AND h.HDoc_Doc_Ano = d.DDoc_RF2_Num AND h.HDoc_Doc_Num = d.DDoc_RF3_Num
                        LEFT JOIN Clientes p ON p.cli_sisemp  = h.HDoc_Sis_Emp AND p.cli_codigo  = h.HDoc_Emp_Cod
                    WHERE d.DDoc_Sis_Emp = {empresa} AND d.DDoc_Doc_Cat = {cat} AND d.DDoc_Doc_Ano = {anio} AND d.DDoc_Doc_Num = {num}
                    GROUP BY p.cli_cuenta "
        If Sesion.IdEmpresa = 18 Then
            strsql &= "; INSERT INTO contapdm.detalle_polizas "
            strsql &= " Select 0 Transaccion,h.HDoc_Sis_Emp empresa , {ejercicio},{poliza}, @fila:=@fila+1 AS linea,p.cli_cuenta cuenta,0 parametro_cuenta, ROUND(sum(d.DDoc_Prd_NET * h.HDoc_Doc_TC),2)  importe,'' centro_costos, '' partida_presupuestal,'A',h.HDoc_Doc_Fec fecha ,'',28 modo,d.DDoc_Doc_Cat , d.DDoc_Doc_Ano , d.DDoc_Doc_Num ,0
                    FROM (SELECT @fila:=0) r,  Dcmtos_DTL d
                        LEFT JOIN PDM.Dcmtos_HDR h ON h.HDoc_Sis_Emp = d.DDoc_Sis_Emp AND h.HDoc_Doc_Cat = d.DDoc_RF1_Num AND h.HDoc_Doc_Ano = d.DDoc_RF2_Num AND h.HDoc_Doc_Num = d.DDoc_RF3_Num
                        LEFT JOIN PDM.Clientes p ON p.cli_sisemp  = h.HDoc_Sis_Emp AND p.cli_codigo  = h.HDoc_Emp_Cod
                    WHERE d.DDoc_Sis_Emp = {empresa} AND d.DDoc_Doc_Cat = {cat} AND d.DDoc_Doc_Ano = {anio} AND d.DDoc_Doc_Num = {num}
                    GROUP BY p.cli_cuenta "
        End If

        strsql = Replace(strsql, "{empresa}", Sesion.IdEmpresa)
        strsql = Replace(strsql, "{conta}", Sesion.BaseConta)
        strsql = Replace(strsql, "{ejercicio}", EJERCICIO)
        strsql = Replace(strsql, "{poliza}", poliza)
        strsql = Replace(strsql, "{cat}", cat)
        strsql = Replace(strsql, "{anio}", anio)
        strsql = Replace(strsql, "{num}", num)


        Return strsql
    End Function
    Private Function SQLDetalleLineaAnticipoVenta(ByVal poliza As Integer, ByVal cat As Integer, ByVal anio As Integer, ByVal num As Integer, ByVal TipoIng As Integer)
        Dim strsql As String = STR_VACIO

        strsql = "INSERT INTO {conta}.detalle_polizas "
        strsql &= " Select 0 Transaccion,h.HDoc_Sis_Emp empresa , {ejercicio},{poliza}, {linea} linea, (SELECT t.valor  FROM {conta}.parametros_empresa   t WHERE t.empresa   = {empresa} AND t.parametro  = 60) cuenta,
                    0 parametro_cuenta, ROUND(sum(IF(h.HDoc_Doc_Mon<>178,d.DDoc_Prd_NET*h.HDoc_Doc_TC,(d.DDoc_Prd_NET *IFNULL(db.HDoc_Doc_TC,IFNULL(tc.Tasa,(SELECT t.Tasa FROM TCambio t WHERE t.Fecha <= '{fecha}' ORDER BY t.Fecha DESC LIMIT 1)))))),2)  importe,'' centro_costos, '' partida_presupuestal,'C',h.HDoc_Doc_Fec fecha ,'',28 modo,d.DDoc_Doc_Cat , d.DDoc_Doc_Ano , d.DDoc_Doc_Num ,0
                    FROM Dcmtos_DTL d
                        LEFT JOIN Dcmtos_HDR hh ON hh.HDoc_Sis_Emp = d.DDoc_Sis_Emp AND hh.HDoc_Doc_Cat = d.DDoc_Doc_Cat AND hh.HDoc_Doc_Ano = d.DDoc_Doc_Ano AND hh.HDoc_Doc_Num = d.DDoc_Doc_Num
                        LEFT JOIN Dcmtos_HDR h ON h.HDoc_Sis_Emp = d.DDoc_Sis_Emp AND h.HDoc_Doc_Cat = d.DDoc_RF1_Num AND h.HDoc_Doc_Ano = d.DDoc_RF2_Num AND h.HDoc_Doc_Num = d.DDoc_RF3_Num
                        LEFT JOIN TCambio tc ON tc.Fecha = hh.HDoc_DR1_Fec
                        LEFT JOIN Dcmtos_HDR db ON db.HDoc_Sis_Emp = hh.HDoc_Sis_Emp AND db.HDoc_Doc_Cat = hh.HDoc_Pro_DCat AND db.HDoc_Doc_Ano = hh.HDoc_Pro_DAno AND db.HDoc_Doc_Num = hh.HDoc_Pro_DNum
                    WHERE d.DDoc_Sis_Emp = {empresa} AND d.DDoc_Doc_Cat = {cat} AND d.DDoc_Doc_Ano = {anio} AND d.DDoc_Doc_Num = {num} "
        If Sesion.IdEmpresa = 18 Then
            strsql &= ";INSERT INTO contapdm.detalle_polizas "
            strsql &= " Select 0 Transaccion,h.HDoc_Sis_Emp empresa , {ejercicio},{poliza}, {linea} linea, (SELECT t.valor  FROM {conta}.parametros_empresa   t WHERE t.empresa   = {empresa} AND t.parametro  = 60) cuenta,
                    0 parametro_cuenta, ROUND(sum(IF(h.HDoc_Doc_Mon<>178,d.DDoc_Prd_NET*h.HDoc_Doc_TC,(d.DDoc_Prd_NET *IFNULL(db.HDoc_Doc_TC,IFNULL(tc.Tasa,(SELECT t.Tasa FROM TCambio t WHERE t.Fecha <= '{fecha}' ORDER BY t.Fecha DESC LIMIT 1)))))),2)  importe,'' centro_costos, '' partida_presupuestal,'C',h.HDoc_Doc_Fec fecha ,'',28 modo,d.DDoc_Doc_Cat , d.DDoc_Doc_Ano , d.DDoc_Doc_Num ,0
                    FROM PDM.Dcmtos_DTL d
                        LEFT JOIN PDM.Dcmtos_HDR hh ON hh.HDoc_Sis_Emp = d.DDoc_Sis_Emp AND hh.HDoc_Doc_Cat = d.DDoc_Doc_Cat AND hh.HDoc_Doc_Ano = d.DDoc_Doc_Ano AND hh.HDoc_Doc_Num = d.DDoc_Doc_Num
                        LEFT JOIN PDM.Dcmtos_HDR h ON h.HDoc_Sis_Emp = d.DDoc_Sis_Emp AND h.HDoc_Doc_Cat = d.DDoc_RF1_Num AND h.HDoc_Doc_Ano = d.DDoc_RF2_Num AND h.HDoc_Doc_Num = d.DDoc_RF3_Num
                        LEFT JOIN PDM.TCambio tc ON tc.Fecha = hh.HDoc_DR1_Fec
                        LEFT JOIN PDM.Dcmtos_HDR db ON db.HDoc_Sis_Emp = hh.HDoc_Sis_Emp AND db.HDoc_Doc_Cat = hh.HDoc_Pro_DCat AND db.HDoc_Doc_Ano = hh.HDoc_Pro_DAno AND db.HDoc_Doc_Num = hh.HDoc_Pro_DNum
                    WHERE d.DDoc_Sis_Emp = {empresa} AND d.DDoc_Doc_Cat = {cat} AND d.DDoc_Doc_Ano = {anio} AND d.DDoc_Doc_Num = {num} "
        End If
        strsql = Replace(strsql, "{empresa}", Sesion.IdEmpresa)
        strsql = Replace(strsql, "{conta}", Sesion.BaseConta)
        strsql = Replace(strsql, "{ejercicio}", EJERCICIO)
        strsql = Replace(strsql, "{poliza}", poliza)
        strsql = Replace(strsql, "{cat}", cat)
        strsql = Replace(strsql, "{anio}", anio)
        strsql = Replace(strsql, "{num}", num)
        strsql = Replace(strsql, "{linea}", (NuevaLinea(EJERCICIO, poliza) + 1).ToString)
        strsql = Replace(strsql, "{fecha}", Now().ToString(FORMATO_MYSQL))


        Return strsql
    End Function

    Private Function SQLDetalleDiferencialCambiarioAnticipoVenta(ByVal poliza As Integer, ByVal cat As Integer, ByVal anio As Integer, ByVal num As Integer, ByVal TipoIng As Integer)

        Dim strSQl As String = STR_VACIO

        Dim COM As MySqlCommand
        Dim importe As Double


        strSQl = " SELECT ABS(ROUND(sum(IF(h.HDoc_Doc_Mon<>178,d.DDoc_Prd_NET*h.HDoc_Doc_TC,(d.DDoc_Prd_NET *IFNULL(db.HDoc_Doc_TC,IFNULL(tc.Tasa,(SELECT t.Tasa FROM TCambio t WHERE t.Fecha <= '{fecha}' ORDER BY t.Fecha DESC LIMIT 1)))))),2) - ROUND(SUM(d.DDoc_Prd_NET * IF(d.DDoc_RF1_Dbl=0, h.HDoc_Doc_TC,d.DDoc_RF1_Dbl)),2)) importe
                    FROM Dcmtos_DTL d
                    LEFT JOIN Dcmtos_HDR hh ON hh.HDoc_Sis_Emp = d.DDoc_Sis_Emp AND hh.HDoc_Doc_Cat = d.DDoc_Doc_Cat AND hh.HDoc_Doc_Ano = d.DDoc_Doc_Ano AND hh.HDoc_Doc_Num = d.DDoc_Doc_Num
                    LEFT JOIN Dcmtos_HDR h ON h.HDoc_Sis_Emp = d.DDoc_Sis_Emp AND h.HDoc_Doc_Cat = d.DDoc_RF1_Num AND h.HDoc_Doc_Ano = d.DDoc_RF2_Num AND h.HDoc_Doc_Num = d.DDoc_RF3_Num
                    LEFT JOIN TCambio tc ON tc.Fecha = hh.HDoc_DR1_Fec 
                    LEFT JOIN Dcmtos_HDR db ON db.HDoc_Sis_Emp = hh.HDoc_Sis_Emp AND db.HDoc_Doc_Cat = hh.HDoc_Pro_DCat AND db.HDoc_Doc_Ano = hh.HDoc_Pro_DAno AND db.HDoc_Doc_Num = hh.HDoc_Pro_DNum
                    WHERE d.DDoc_Sis_Emp = {emp} AND d.DDoc_Doc_Cat = {cat} AND d.DDoc_Doc_Ano = {anio} AND d.DDoc_Doc_Num = {num}"
        strSQl = Replace(strSQl, "{emp}", Sesion.IdEmpresa)
        strSQl = Replace(strSQl, "{cat}", cat)
        strSQl = Replace(strSQl, "{anio}", anio)
        strSQl = Replace(strSQl, "{num}", num)
        strSQl = Replace(strSQl, "{fecha}", Now().ToString(FORMATO_MYSQL))
        MyCnn.CONECTAR = strConexion
        COM = New MySqlCommand(strSQl, CON)
        importe = COM.ExecuteScalar()

        If importe > 0 Then
            strSQl = STR_VACIO

            strSQl = "INSERT INTO {conta}.detalle_polizas "
            strSQl &= " SELECT A.Transaccion, A.empresa, A.ejercicio, A.poliza, A.linea, (
																				SELECT t.valor
																				FROM {conta}.parametros_empresa t
																				WHERE t.empresa = {empresa} AND t.parametro = IF(A.importe >0,22,21)
																					) cuenta,
                        A.parametro_cuenta, ABS(A.importe), A.centro_costos, A.partida_presupuestal, IF(A.importe >0,'A','C')DH, A.fecha,'',A.modo, A.DDoc_Doc_Cat, A.DDoc_Doc_Ano, A.DDoc_Doc_Num,0

                         FROM  (
                        SELECT 0 Transaccion,h.HDoc_Sis_Emp empresa, {ejercicio} ejercicio,{poliza} poliza, {linea} linea,
                         0 parametro_cuenta, (ROUND(sum(IF(h.HDoc_Doc_Mon<>178,d.DDoc_Prd_NET*h.HDoc_Doc_TC,(d.DDoc_Prd_NET *IFNULL(db.HDoc_Doc_TC,IFNULL(tc.Tasa,(SELECT t.Tasa FROM TCambio t WHERE t.Fecha <= '2024-02-05' ORDER BY t.Fecha DESC LIMIT 1)))))),2) - ROUND(SUM(d.DDoc_Prd_NET * IF(d.DDoc_RF1_Dbl=0, h.HDoc_Doc_TC,d.DDoc_RF1_Dbl)),2)) importe, {centro_num}  centro_costos, '' partida_presupuestal,
                         h.HDoc_Doc_Fec fecha,28 modo,d.DDoc_Doc_Cat, d.DDoc_Doc_Ano, d.DDoc_Doc_Num
                        FROM Dcmtos_DTL d
                        LEFT JOIN Dcmtos_HDR hh ON hh.HDoc_Sis_Emp = d.DDoc_Sis_Emp AND hh.HDoc_Doc_Cat = d.DDoc_Doc_Cat AND hh.HDoc_Doc_Ano = d.DDoc_Doc_Ano AND hh.HDoc_Doc_Num = d.DDoc_Doc_Num
                        LEFT JOIN Dcmtos_HDR h ON h.HDoc_Sis_Emp = d.DDoc_Sis_Emp AND h.HDoc_Doc_Cat = d.DDoc_RF1_Num AND h.HDoc_Doc_Ano = d.DDoc_RF2_Num AND h.HDoc_Doc_Num = d.DDoc_RF3_Num
                        LEFT JOIN TCambio tc ON tc.Fecha = hh.HDoc_DR1_Fec
                        LEFT JOIN Dcmtos_HDR db ON db.HDoc_Sis_Emp = hh.HDoc_Sis_Emp AND db.HDoc_Doc_Cat = hh.HDoc_Pro_DCat AND db.HDoc_Doc_Ano = hh.HDoc_Pro_DAno AND db.HDoc_Doc_Num = hh.HDoc_Pro_DNum
                        WHERE d.DDoc_Sis_Emp = {empresa} AND d.DDoc_Doc_Cat = {cat} AND d.DDoc_Doc_Ano = {anio} AND d.DDoc_Doc_Num = {num}) A "
            If Sesion.IdEmpresa = 18 Then
                strSQl &= "; INSERT INTO contapdm.detalle_polizas "
                strSQl &= " SELECT A.Transaccion, A.empresa, A.ejercicio, A.poliza, A.linea, (
																				SELECT t.valor
																				FROM contapdm.parametros_empresa t
																				WHERE t.empresa = {empresa} AND t.parametro = IF(A.importe >0,22,21)
																					) cuenta,
                        A.parametro_cuenta, ABS(A.importe), A.centro_costos, A.partida_presupuestal, IF(A.importe >0,'A','C')DH, A.fecha,'',A.modo, A.DDoc_Doc_Cat, A.DDoc_Doc_Ano, A.DDoc_Doc_Num,0

                         FROM  (
                        SELECT 0 Transaccion,h.HDoc_Sis_Emp empresa, {ejercicio} ejercicio,{poliza} poliza, {linea} linea,
                         0 parametro_cuenta, (ROUND(sum(IF(h.HDoc_Doc_Mon<>178,d.DDoc_Prd_NET*h.HDoc_Doc_TC,(d.DDoc_Prd_NET *IFNULL(db.HDoc_Doc_TC,IFNULL(tc.Tasa,(SELECT t.Tasa FROM TCambio t WHERE t.Fecha <= '2024-02-05' ORDER BY t.Fecha DESC LIMIT 1)))))),2) - ROUND(SUM(d.DDoc_Prd_NET * IF(d.DDoc_RF1_Dbl=0, h.HDoc_Doc_TC,d.DDoc_RF1_Dbl)),2)) importe, 4 centro_costos, '' partida_presupuestal,
                         h.HDoc_Doc_Fec fecha,28 modo,d.DDoc_Doc_Cat, d.DDoc_Doc_Ano, d.DDoc_Doc_Num
                        FROM Dcmtos_DTL d
                        LEFT JOIN PDM.Dcmtos_HDR hh ON hh.HDoc_Sis_Emp = d.DDoc_Sis_Emp AND hh.HDoc_Doc_Cat = d.DDoc_Doc_Cat AND hh.HDoc_Doc_Ano = d.DDoc_Doc_Ano AND hh.HDoc_Doc_Num = d.DDoc_Doc_Num
                        LEFT JOIN PDM.Dcmtos_HDR h ON h.HDoc_Sis_Emp = d.DDoc_Sis_Emp AND h.HDoc_Doc_Cat = d.DDoc_RF1_Num AND h.HDoc_Doc_Ano = d.DDoc_RF2_Num AND h.HDoc_Doc_Num = d.DDoc_RF3_Num
                        LEFT JOIN PDM.TCambio tc ON tc.Fecha = hh.HDoc_DR1_Fec
                        LEFT JOIN PDM.Dcmtos_HDR db ON db.HDoc_Sis_Emp = hh.HDoc_Sis_Emp AND db.HDoc_Doc_Cat = hh.HDoc_Pro_DCat AND db.HDoc_Doc_Ano = hh.HDoc_Pro_DAno AND db.HDoc_Doc_Num = hh.HDoc_Pro_DNum
                        WHERE d.DDoc_Sis_Emp = {empresa} AND d.DDoc_Doc_Cat = {cat} AND d.DDoc_Doc_Ano = {anio} AND d.DDoc_Doc_Num = {num}) A "

            End If
            strSQl = Replace(strSQl, "{empresa}", Sesion.IdEmpresa)
            strSQl = Replace(strSQl, "{conta}", Sesion.BaseConta)
            strSQl = Replace(strSQl, "{ejercicio}", EJERCICIO)
            strSQl = Replace(strSQl, "{poliza}", poliza)
            strSQl = Replace(strSQl, "{cat}", cat)
            strSQl = Replace(strSQl, "{anio}", anio)
            strSQl = Replace(strSQl, "{num}", num)
            strSQl = Replace(strSQl, "{linea}", (NuevaLinea(EJERCICIO, poliza) + 1).ToString)
            strSQl = Replace(strSQl, "{fecha}", Now().ToString(FORMATO_MYSQL))
            If Sesion.IdEmpresa = 22 Then
                strSQl = Replace(strSQl, "{centro_num}", 0)
            Else
                strSQl = Replace(strSQl, "{centro_num}", 4)
            End If


        End If

        Return strSQl
    End Function


#End Region

#Region "Recibo"
    Private Sub PolizaRecibo(ByVal anio As Integer, ByVal num As Integer, ByVal fec As Date)
        ' Verifica si es Factura Extemporanea
        Dim strsql As String = STR_VACIO
        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader
        Dim extemporaneo As Integer = NO_FILA
        Dim intIVA As Integer = NO_FILA
        Dim intTipoFact As Integer = NO_FILA
        Dim dtFecha As String = STR_VACIO
        Dim strFecha As String = STR_VACIO
        Dim intStatus As Integer = 0
        Dim longPolizas As Long = NO_FILA
        Dim intCaja As Integer = 0
        Try
            '***********************************
            'VERIFICA SI ES EXTEMPORANEA O NO, SI RETIENE IVA O NO Y TIPO DE FACTURA
            strsql = " SELECT h.HDoc_DR2_Cat extemporaneo, h.HDoc_DR1_Emp tipoFact, 0 Iva, CONCAT(MONTH(h.HDoc_Doc_Fec), YEAR(h.HDoc_Doc_Fec)) fecha "
            strsql &= "    From Dcmtos_HDR h "
            strsql &= "        Where h.HDoc_Sis_Emp = {empresa} And h.HDoc_Doc_Cat = 209 And h.HDoc_Doc_Ano = {anio} And h.HDoc_Doc_Num = {num} "

            strsql = Replace(strsql, "{empresa}", Sesion.IdEmpresa)
            strsql = Replace(strsql, "{anio}", anio)
            strsql = Replace(strsql, "{num}", num)

            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strsql, CON)
            REA = COM.ExecuteReader
            If REA.HasRows Then
                While REA.Read
                    extemporaneo = REA.GetInt32("extemporaneo") ' 0 no extemporanea - 1 Extemporanea
                    intIVA = REA.GetInt32("Iva") ' 1 Retiene IVA, 0 No retiene IVA
                    intTipoFact = REA.GetInt32("tipoFact") ' -1 Importacion, 1 Factura Electronica, 2 Pequeño Contribuyente
                    dtFecha = REA.GetString("fecha")
                End While
            End If

            strsql = STR_VACIO


            '********************************
            'VERIFICA QUE EXISTA LIBRO DE COMPRAS Y SI ESTA CERRADO O NO
            'strsql = " SELECT h.HDoc_Doc_Status status "
            'strsql &= "    From Dcmtos_HDR h "
            'strsql &= "        Where h.HDoc_Sis_Emp = {empresa} And h.HDoc_Doc_Cat = 286 And h.HDoc_Doc_Ano = {anio} AND CONCAT(MONTH(h.HDoc_Doc_Fec), YEAR(h.HDoc_Doc_Fec)) = '{fecha}' "

            'strsql = Replace(strsql, "{empresa}", Sesion.IdEmpresa)
            'strsql = Replace(strsql, "{anio}", anio)
            'strsql = Replace(strsql, "{fecha}", dtFecha)

            'MyCnn.CONECTAR = strConexion
            'COM = New MySqlCommand(strsql, CON)
            'intStatus = COM.ExecuteScalar ' Verifica si existe libro de compras y si esta abierto = 0 o cerrado = 1
            strsql = STR_VACIO

            ' VERIFICA SI ES FACTURA DE CAJA CHICA O NO
            strsql = " SELECT h.HDoc_DR1_Cat caja "
            strsql &= "    From Dcmtos_HDR h "
            strsql &= "    WHERE h.HDoc_Sis_Emp = {empresa} AND h.HDoc_Doc_Cat = 209 AND h.HDoc_Doc_Ano = {anio} AND h.HDoc_Doc_Num = {num} "

            strsql = Replace(strsql, "{empresa}", Sesion.IdEmpresa)
            strsql = Replace(strsql, "{anio}", anio)
            strsql = Replace(strsql, "{num}", num)

            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strsql, CON)
            intCaja = COM.ExecuteScalar ' Verifica si es de caja chica > 0 o no = 0
            strsql = STR_VACIO

            longPolizas = NuevaPoliza() ' verifica el ultimo numero de poliza
            UltimaPoliza(longPolizas, EJERCICIO) ' actualiza la ultima poliza

            'ENCABEZADO DE POLIZA
            strsql = SQLEncabezadoRecibo()
            strsql = Replace(strsql, "{ejercicio}", EJERCICIO)
            strsql = Replace(strsql, "{poliza}", longPolizas)
            strsql = Replace(strsql, "{empresa}", Sesion.IdEmpresa)
            strsql = Replace(strsql, "{anio}", anio)
            strsql = Replace(strsql, "{num}", num)
            strsql = Replace(strsql, "{conta}", Sesion.BaseConta)
            strsql = Replace(strsql, "{usuario}", Sesion.Usuario)

            If Year(fec.ToString(FORMATO_MYSQL)) <> Year(Now) Then
                If Month(fec.ToString(FORMATO_MYSQL)) = 12 Then
                    strsql = Replace(strsql, "{fecha}", fec.ToString(FORMATO_MYSQL))
                Else
                    'strsql = Replace(strsql, "{fecha}", (DateSerial(Year(fec.ToString(FORMATO_MYSQL)), 12, 1).ToString(FORMATO_MYSQL)))
                    strsql = Replace(strsql, "{fecha}", fec.ToString(FORMATO_MYSQL))
                End If
            Else
                If extemporaneo = 1 Then
                    'strsql = Replace(strsql, "{fecha}", (DateSerial(Year(Date.Now), Month(Date.Now), 1).ToString(FORMATO_MYSQL)))
                    strsql = Replace(strsql, "{fecha}", fec.ToString(FORMATO_MYSQL))
                Else
                    If intStatus = 1 Then
                        'strsql = Replace(strsql, "{fecha}", (DateSerial(Year(Date.Now), Month(Date.Now), 1).ToString(FORMATO_MYSQL)))
                        strsql = Replace(strsql, "{fecha}", fec.ToString(FORMATO_MYSQL))
                    Else
                        strsql = Replace(strsql, "{fecha}", fec.ToString(FORMATO_MYSQL))
                    End If
                End If
            End If


            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strsql, CON)
            COM.ExecuteNonQuery()
            strsql = STR_VACIO

            ' DETALLE DE POLIZA
            strsql = SQLDetalleRecibo(intIVA, intTipoFact, extemporaneo, intCaja)
            strsql = Replace(strsql, "{ejercicio}", EJERCICIO)
            strsql = Replace(strsql, "{poliza}", longPolizas)
            strsql = Replace(strsql, "{empresa}", Sesion.IdEmpresa)
            strsql = Replace(strsql, "{anio}", anio)
            strsql = Replace(strsql, "{num}", num)
            strsql = Replace(strsql, "{conta}", Sesion.BaseConta)

            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strsql, CON)
            COM.ExecuteNonQuery()
            strsql = STR_VACIO

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try

    End Sub

    Private Function SQLEncabezadoRecibo()
        Dim strSQL As String = STR_VACIO

        strSQL = " INSERT INTO {conta}.polizas"
        strSQL &= "   SELECT h.HDoc_Sis_Emp empresa, {ejercicio} ejercicio, {poliza} poliza, '{fecha}', CONCAT('Poliza de Compra, {documentoTipo}: ', h.HDoc_DR1_Num, ' ', h.HDoc_DR2_Num, ' de fecha ', h.HDoc_Doc_Fec) concepto, 8 tipo, h.HDoc_Doc_TC TC, '' observacion, '{usuario}' operador, 'C' estado, NOW() marca,'' grupo, 8 modo, h.HDoc_Doc_Cat refTipo, h.HDoc_Doc_Ano refCiclo, h.HDoc_Doc_Num refNumero, NULL divisa, h.HDoc_Doc_TC Tasa,0 revisado,'' usuarioRev, NULL ultRev "
        strSQL &= "      FROM Dcmtos_HDR h "
        strSQL &= "         WHERE h.HDoc_Sis_Emp = {empresa} AND h.HDoc_Doc_Cat = 209 AND h.HDoc_Doc_Ano = {anio} AND h.HDoc_Doc_Num = {num} "

        If Sesion.IdEmpresa = 18 Then
            strSQL &= "; INSERT INTO contapdm.polizas"
            strSQL &= "   SELECT h.HDoc_Sis_Emp empresa, {ejercicio} ejercicio, {poliza} poliza, '{fecha}', CONCAT('Poliza de Compra, {documentoTipo}: ', h.HDoc_DR1_Num, ' ', h.HDoc_DR2_Num, ' de fecha ', h.HDoc_Doc_Fec) concepto, 8 tipo, h.HDoc_Doc_TC TC, '' observacion, '{usuario}' operador, 'C' estado, NOW() marca,'' grupo, 8 modo, h.HDoc_Doc_Cat refTipo, h.HDoc_Doc_Ano refCiclo, h.HDoc_Doc_Num refNumero, NULL divisa, h.HDoc_Doc_TC Tasa,0 revisado,'' usuarioRev, NULL ultRev "
            strSQL &= "      FROM PDM.Dcmtos_HDR h "
            strSQL &= "         WHERE h.HDoc_Sis_Emp = {empresa} AND h.HDoc_Doc_Cat = 209 AND h.HDoc_Doc_Ano = {anio} AND h.HDoc_Doc_Num = {num} "
        End If

        If Sesion.idGiro = 1 Then
            strSQL = Replace(strSQL, "{documentoTipo}", "Documento No.")
        Else
            strSQL = Replace(strSQL, "{documentoTipo}", "Recibo")
        End If
        Return strSQL
    End Function

    Private Function SQLDetalleRecibo(ByVal db As String, ByVal conta As String, ByVal intIva As Integer, ByVal intTipoFact As Integer, ByVal Extemporaneo As Integer, Optional ByVal caja As Integer = 0) 'IntTipoFact: -1 Importacion, 1 Factura Electronica, 2 Pequeño Contribuyente, si es de caja chica CAJA = 1 si no = 0
        Dim strSQL As String = STR_VACIO
        Dim item As Integer = 0
        ' IntIVA: 1 Retiene IVA, 0 no Retiene IVA
        ' 0 no extemporanea - 1 Extemporanea
        Try

            item = item + 1
            strSQL = " INSERT INTO {conta}.detalle_polizas"
            strSQL &= "   SELECT 0,'{empresa}',{ejercicio},{poliza}," & item & " item, d.DDoc_RF1_Cod cuenta, 1 parametro_cuenta, Round(SUM((({price} * d.DDoc_Prd_QTY)* h.HDoc_Doc_TC) {combustible} {iva},2) importe, d.DDoc_RF3_Num centro_Costo, NULL partida_Presupuestal, 'C' operacion, h.HDoc_Doc_Fec, 0 clase, 8 modo, h.HDoc_Doc_Cat tipo, h.HDoc_Doc_Ano cilco, h.HDoc_Doc_Num num,0 id "
            strSQL &= "        From {db}Dcmtos_HDR h "
            strSQL &= "            Left JOIN {db}Dcmtos_DTL d ON d.DDoc_Sis_Emp = h.HDoc_Sis_Emp AND d.DDoc_Doc_Cat = h.HDoc_Doc_Cat AND d.DDoc_Doc_Ano= h.HDoc_Doc_Ano AND d.DDoc_Doc_Num = h.HDoc_Doc_Num "
            strSQL &= "                WHERE h.HDoc_Sis_Emp = {empresa} AND h.HDoc_Doc_Cat = 209 AND h.HDoc_Doc_Ano = {anio} AND h.HDoc_Doc_Num = {num} "
            strSQL &= "                     Group By d.DDoc_RF1_Cod, d.DDoc_RF3_Num "

            If Sesion.IdEmpresa = 18 Then
                strSQL = Replace(strSQL, "{price}", " d.DDoc_RF3_Dbl ")
            Else
                strSQL = Replace(strSQL, "{price}", " d.DDoc_Prd_NET ")
            End If

            If Extemporaneo = 0 Then
                If intTipoFact = 2 Then
                    strSQL = Replace(strSQL, "{iva}", STR_VACIO)
                Else

                    If intIva = 1 Then
                        item = item + 1
                        If Sesion.IdEmpresa = 18 Then
                            strSQL &= "                        UNION " ' SEGUNDA LINEA QUE MUESTRA LA CUENTA DE IVA
                            strSQL &= "                            Select 0,'{empresa}',{ejercicio},{poliza}," & item & " item, d.DDoc_RF1_Txt cuenta, 1 parametro_cuenta, ROUND(SUM((d.DDoc_Prd_NET - d.DDoc_RF3_Dbl) * d.DDoc_Prd_QTY) * h.HDoc_Doc_TC ,2) importe, '' centro_Costo, NULL partida_Presupuestal, 'C' operacion, h.HDoc_Doc_Fec, 0 clase, 8 modo, h.HDoc_Doc_Cat tipo, h.HDoc_Doc_Ano cilco, h.HDoc_Doc_Num num,0 id "
                            strSQL &= "                                From {db}Dcmtos_HDR h "
                            strSQL &= "                                    Left JOIN {db}Dcmtos_DTL d ON d.DDoc_Sis_Emp = h.HDoc_Sis_Emp AND d.DDoc_Doc_Cat = h.HDoc_Doc_Cat AND d.DDoc_Doc_Ano = h.HDoc_Doc_Ano AND d.DDoc_Doc_Num = h.HDoc_Doc_Num "
                            strSQL &= "                         WHERE h.HDoc_Sis_Emp = {empresa} AND h.HDoc_Doc_Cat = 209 AND h.HDoc_Doc_Ano = {anio} AND h.HDoc_Doc_Num = {num} AND LENGTH(d.DDoc_RF1_Txt)>0
                                                                GROUP BY d.DDoc_RF1_Txt"

                            strSQL = Replace(strSQL, "{iva}", STR_VACIO)
                        Else
                            strSQL &= "                        UNION " ' SEGUNDA LINEA QUE MUESTRA LA CUENTA DE IVA
                            strSQL &= "                            Select 0,'{empresa}',{ejercicio},{poliza}," & item & " item, e.valor cuenta, 1 parametro_cuenta, p.MDoc_Lin_Monto importe, '' centro_Costo, NULL partida_Presupuestal, 'C' operacion, h.HDoc_Doc_Fec, 0 clase, 8 modo, h.HDoc_Doc_Cat tipo, h.HDoc_Doc_Ano cilco, h.HDoc_Doc_Num num,0 id "
                            strSQL &= "                                From {db}Dcmtos_HDR h "
                            strSQL &= "                                    Left JOIN {db}Dcmtos_DTL d ON d.DDoc_Sis_Emp = h.HDoc_Sis_Emp AND d.DDoc_Doc_Cat = h.HDoc_Doc_Cat AND d.DDoc_Doc_Ano = h.HDoc_Doc_Ano AND d.DDoc_Doc_Num = h.HDoc_Doc_Num "
                            strSQL &= "                                        Left JOIN {db}Dcmtos_IMP p ON p.MDoc_Sis_Emp = d.DDoc_Sis_Emp AND p.MDoc_Doc_Cat = d.DDoc_Doc_Cat AND p.MDoc_Doc_Ano = d.DDoc_Doc_Ano AND p.MDoc_Doc_Num = d.DDoc_Doc_Num "
                            strSQL &= "                                            Left JOIN {conta}.parametros_empresa e ON e.empresa = p.MDoc_Sis_Emp AND e.parametro = 28"
                            strSQL &= "                                                 WHERE h.HDoc_Sis_Emp = {empresa} AND h.HDoc_Doc_Cat = 209 AND h.HDoc_Doc_Ano = {anio} AND h.HDoc_Doc_Num = {num} AND p.MDoc_Lin_Codigo = 'IVA' AND p.MDoc_Lin_Monto >0 "

                            strSQL = Replace(strSQL, "{iva}", " / (((SELECT cat_sist IVA FROM {db}Catalogos c WHERE c.cat_clase = 'Impuestos' AND c.cat_clave ='IVA' AND c.cat_sisemp = {empresa})/100)+1) ")
                        End If

                        item = item + 1
                        strSQL &= "                        UNION " ' LINEA QUE MUESTRA LA CUENTA DE COMBUSTIBLE SI APLICARA
                        strSQL &= "                            Select 0,'{empresa}',{ejercicio},{poliza}," & item & " item, e.valor cuenta, 1 parametro_cuenta, p.MDoc_Lin_Monto importe, d.DDoc_RF3_Num centro_Costo, NULL partida_Presupuestal, 'C' operacion, h.HDoc_Doc_Fec, 0 clase, 8 modo, h.HDoc_Doc_Cat tipo, h.HDoc_Doc_Ano cilco, h.HDoc_Doc_Num num,0 id "
                        strSQL &= "                                From {db}Dcmtos_HDR h "
                        strSQL &= "                                    Left JOIN {db}Dcmtos_DTL d ON d.DDoc_Sis_Emp = h.HDoc_Sis_Emp AND d.DDoc_Doc_Cat = h.HDoc_Doc_Cat AND d.DDoc_Doc_Ano = h.HDoc_Doc_Ano AND d.DDoc_Doc_Num = h.HDoc_Doc_Num "
                        strSQL &= "                                        Left JOIN {db}Dcmtos_IMP p ON p.MDoc_Sis_Emp = d.DDoc_Sis_Emp AND p.MDoc_Doc_Cat = d.DDoc_Doc_Cat AND p.MDoc_Doc_Ano = d.DDoc_Doc_Ano AND p.MDoc_Doc_Num = d.DDoc_Doc_Num "
                        strSQL &= "                                            Left JOIN {conta}.parametros_empresa e ON e.empresa = p.MDoc_Sis_Emp AND e.parametro = 29"
                        strSQL &= "                                                 WHERE h.HDoc_Sis_Emp = {empresa} AND h.HDoc_Doc_Cat = 209 AND h.HDoc_Doc_Ano = {anio} AND h.HDoc_Doc_Num = {num} AND p.MDoc_Lin_Codigo = 'IMP_DC' AND p.MDoc_Lin_Monto >0 "
                    Else
                        strSQL = Replace(strSQL, "{iva}", STR_VACIO)

                    End If
                End If

            Else
                strSQL = Replace(strSQL, "{iva}", STR_VACIO)
            End If

            item = item + 1
            strSQL = Replace(strSQL, "{combustible}", " - (SELECT IFNULL(SUM(p.MDoc_Lin_Monto),0) impuesto FROM {db}Dcmtos_IMP p WHERE p.MDoc_Sis_Emp = d.DDoc_Sis_Emp AND p.MDoc_Doc_Cat = d.DDoc_Doc_Cat AND p.MDoc_Doc_Ano = d.DDoc_Doc_Ano AND p.MDoc_Doc_Num = d.DDoc_Doc_Num AND p.MDoc_Lin_Codigo = 'IMP_DC')) ")
            If caja > 0 Then

                strSQL &= " UNION " ' Tercer Linea, siempre y cuando sea de caja Chica
                strSQL &= "     SELECT 0,{empresa},{ejercicio},{poliza}, " & item & " item, b.BCta_Cuenta cuenta, 1 parametro_cuenta, SUM((d.DDoc_Prd_NET * d.DDoc_Prd_QTY)* h.HDoc_Doc_TC) importe, '' centro_Costo, NULL partida_Presupuestal, 'A' operacion, h.HDoc_Doc_Fec, 0 clase,8 modo, h.HDoc_Doc_Cat tipo, h.HDoc_Doc_Ano cilco, h.HDoc_Doc_Num num,0 id "
                strSQL &= "     FROM {db}Dcmtos_HDR h "
                strSQL &= "      LEFT JOIN {db}Dcmtos_DTL d ON d.DDoc_Sis_Emp = h.HDoc_Sis_Emp AND d.DDoc_Doc_Cat = h.HDoc_Doc_Cat AND d.DDoc_Doc_Ano = h.HDoc_Doc_Ano AND d.DDoc_Doc_Num = h.HDoc_Doc_Num "
                strSQL &= "      LEFT JOIN {db}CtasBcos b ON b.BCta_Sis_Emp = h.HDoc_Sis_Emp AND b.BCta_Num = h.HDoc_DR1_Cat "
                strSQL &= "      WHERE h.HDoc_Sis_Emp = {empresa} AND h.HDoc_Doc_Cat = 209 AND h.HDoc_Doc_Ano = {anio} AND h.HDoc_Doc_Num = {num}"

            Else
                strSQL = Replace(strSQL, "{combustible}", ")")
                strSQL &= "                                        UNION " ' Linea.. la que abona
                strSQL &= "                                    Select 0,'{empresa}',{ejercicio},{poliza}," & item & " item, p.pro_cuenta cuenta, 1 parametro_cuenta, SUM((d.DDoc_Prd_NET * d.DDoc_Prd_QTY)* h.HDoc_Doc_TC) importe, '' centro_Costo, NULL partida_Presupuestal, 'A' operacion, h.HDoc_Doc_Fec, 0 clase,8 modo, h.HDoc_Doc_Cat tipo, h.HDoc_Doc_Ano cilco, h.HDoc_Doc_Num num,0 id "
                strSQL &= "                              From {db}Dcmtos_HDR h "
                strSQL &= "                            Left JOIN {db}Dcmtos_DTL d ON d.DDoc_Sis_Emp = h.HDoc_Sis_Emp AND d.DDoc_Doc_Cat = h.HDoc_Doc_Cat AND d.DDoc_Doc_Ano = h.HDoc_Doc_Ano AND d.DDoc_Doc_Num = h.HDoc_Doc_Num "
                strSQL &= "                    Left JOIN {db}Proveedores p ON p.pro_sisemp = h.HDoc_Sis_Emp AND p.pro_codigo = h.HDoc_Emp_Cod "
                strSQL &= "                WHERE h.HDoc_Sis_Emp = {empresa} AND h.HDoc_Doc_Cat = 209 AND h.HDoc_Doc_Ano = {anio} AND h.HDoc_Doc_Num = {num} "
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        strSQL = Replace(strSQL, "{db}", db)
        If conta <> STR_VACIO Then
            strSQL = Replace(strSQL, "{conta}", conta)
        End If

        Return strSQL
    End Function

    Private Function SQLDetalleRecibo(ByVal intIva As Integer, ByVal intTipoFact As Integer, ByVal Extemporaneo As Integer, Optional ByVal caja As Integer = 0) 'IntTipoFact: -1 Importacion, 1 Factura Electronica, 2 Pequeño Contribuyente, si es de caja chica CAJA = 1 si no = 0
        Dim strSQL As String = SQLDetalleRecibo(STR_VACIO, STR_VACIO, intIva, intTipoFact, Extemporaneo, caja)
        If Sesion.IdEmpresa = 18 Then
            strSQL = String.Concat(strSQL, ";", SQLDetalleRecibo("PDM.", "contapdm", intIva, intTipoFact, Extemporaneo, caja))
        End If
        Return strSQL
    End Function

#End Region

#Region " Inventario Otros Ingresos"
    Private Sub PolizaDeOtrosIngresos(ByVal cat As Integer, ByVal anio As Integer, ByVal num As Integer, ByVal fec As Date, ByVal tipoIngreso As Integer)
        ' Verifica si es Factura Extemporanea
        Dim strsql As String = STR_VACIO
        Dim COM As MySqlCommand
        'Dim REA As MySqlDataReader
        Dim extemporaneo As Integer = NO_FILA
        Dim intIVA As Integer = NO_FILA
        Dim intTipoFact As Integer = NO_FILA
        'Dim dtFecha As String
        Dim strFecha As String = STR_VACIO
        ' Dim intStatus As Integer
        Dim longPolizas As Long = NO_FILA
        Dim intCaja As Integer = 0
        Try
            longPolizas = NuevaPoliza() ' verifica el ultimo numero de poliza
            UltimaPoliza(longPolizas, EJERCICIO) ' actualiza la ultima poliza

            'ENCABEZADO DE POLIZA
            strsql = SQLEncabezadoOtrosIngresos()
            strsql = Replace(strsql, "{ejercicio}", EJERCICIO)
            strsql = Replace(strsql, "{poliza}", longPolizas)
            strsql = Replace(strsql, "{empresa}", Sesion.IdEmpresa)
            strsql = Replace(strsql, "{anio}", anio)
            strsql = Replace(strsql, "{cat}", cat)
            strsql = Replace(strsql, "{num}", num)
            strsql = Replace(strsql, "{conta}", Sesion.BaseConta)
            strsql = Replace(strsql, "{usuario}", Sesion.Usuario)
            strsql = Replace(strsql, "{fecha}", fec.ToString(FORMATO_MYSQL))
            If tipoIngreso = 7 Then
                strsql = Replace(strsql, "{tipoInv}", "Devolución de Producto")
            ElseIf tipoIngreso = 8 Then
                strsql = Replace(strsql, "{tipoInv}", "Inventario 2%")
            ElseIf tipoIngreso = 9 Then
                strsql = Replace(strsql, "{tipoInv}", "Producto Reutilizable")
            ElseIf tipoIngreso = 10 Then
                strsql = Replace(strsql, "{tipoInv}", "Producto utilizado parcialmente")
            ElseIf tipoIngreso = 11 Then
                strsql = Replace(strsql, "{tipoInv}", "Producto en garantía")
            End If
            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strsql, CON)
            COM.ExecuteNonQuery()
            strsql = STR_VACIO

            ' DETALLE DE POLIZA
            strsql = SQLDetalleOtrosIngresos()
            strsql = Replace(strsql, "{ejercicio}", EJERCICIO)
            strsql = Replace(strsql, "{poliza}", longPolizas)
            strsql = Replace(strsql, "{empresa}", Sesion.IdEmpresa)
            strsql = Replace(strsql, "{anio}", anio)
            strsql = Replace(strsql, "{numero}", num)
            strsql = Replace(strsql, "{cat}", cat)
            strsql = Replace(strsql, "{conta}", Sesion.BaseConta)

            If Year(fec.ToString(FORMATO_MYSQL)) <> Year(Now) Then
                If Month(fec.ToString(FORMATO_MYSQL)) = 12 Then
                    strsql = Replace(strsql, "{fecha}", fec.ToString(FORMATO_MYSQL))
                Else
                    strsql = Replace(strsql, "{fecha}", fec.ToString(FORMATO_MYSQL))
                End If

            End If
            MyCnn.CONECTAR = strConexion & ";Allow User Variables=True"
            COM = New MySqlCommand(strsql, CON)
            COM.ExecuteNonQuery()
            strsql = STR_VACIO

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try

    End Sub
    Private Function SQLEncabezadoOtrosIngresos()
        Dim strSQL As String = STR_VACIO

        strSQL = " INSERT INTO {conta}.polizas"
        strSQL &= "   SELECT h.HDoc_Sis_Emp empresa, {ejercicio} ejercicio, {poliza} poliza, '{fecha}', CONCAT('Poliza de Inventario {tipoInv}: ', h.HDoc_DR1_Num, ' ', h.HDoc_DR2_Num, ' de fecha ', h.HDoc_Doc_Fec) concepto, 36 tipo, h.HDoc_Doc_TC TC, '' observacion, '{usuario}' operador, 'C' estado, NOW() marca,'' grupo, 36 modo, h.HDoc_Doc_Cat refTipo, h.HDoc_Doc_Ano refCiclo, h.HDoc_Doc_Num refNumero, NULL divisa, h.HDoc_Doc_TC Tasa,0 revisado,'' usuarioRev, NULL ultRev "
        strSQL &= "      FROM Dcmtos_HDR h "
        strSQL &= "         WHERE h.HDoc_Sis_Emp = {empresa} AND h.HDoc_Doc_Cat = {cat} AND h.HDoc_Doc_Ano = {anio} AND h.HDoc_Doc_Num = {num} "

        If Sesion.IdEmpresa = 18 Then
            strSQL &= "; INSERT INTO contapdm.polizas"
            strSQL &= "   SELECT h.HDoc_Sis_Emp empresa, {ejercicio} ejercicio, {poliza} poliza, '{fecha}', CONCAT('Poliza de Inventario {tipoInv}: ', h.HDoc_DR1_Num, ' ', h.HDoc_DR2_Num, ' de fecha ', h.HDoc_Doc_Fec) concepto, 36 tipo, h.HDoc_Doc_TC TC, '' observacion, '{usuario}' operador, 'C' estado, NOW() marca,'' grupo, 36 modo, h.HDoc_Doc_Cat refTipo, h.HDoc_Doc_Ano refCiclo, h.HDoc_Doc_Num refNumero, NULL divisa, h.HDoc_Doc_TC Tasa,0 revisado,'' usuarioRev, NULL ultRev "
            strSQL &= "      FROM PDM.Dcmtos_HDR h "
            strSQL &= "         WHERE h.HDoc_Sis_Emp = {empresa} AND h.HDoc_Doc_Cat = {cat} AND h.HDoc_Doc_Ano = {anio} AND h.HDoc_Doc_Num = {num} "
        End If

        Return strSQL
    End Function
    Private Function SQLDetalleOtrosIngresos()
        Dim strSQL As String = STR_VACIO
        Dim item As Integer = 0
        ' IntIVA: 1 Retiene IVA, 0 no Retiene IVA
        ' 0 no extemporanea - 1 Extemporanea
        Try
            strSQL = " SET @numero=1; "
            strSQL &= " INSERT INTO {conta}.detalle_polizas "
            strSQL &= "    SELECT 0,'{empresa}',{ejercicio},{poliza},1 item, ic.inventario cuenta, 1 parametro_cuenta, SUM((d.DDoc_Prd_NET * d.DDoc_Prd_QTY)* h.HDoc_Doc_TC) importe, d.DDoc_RF3_Num centro_Costo, NULL partida_Presupuestal, 'C' operacion, h.HDoc_Doc_Fec, 0 clase, 36 modo, h.HDoc_Doc_Cat tipo, h.HDoc_Doc_Ano cilco, h.HDoc_Doc_Num num,0 id
                            FROM Dcmtos_HDR h
                            LEFT JOIN Dcmtos_DTL d ON d.DDoc_Sis_Emp = h.HDoc_Sis_Emp AND d.DDoc_Doc_Cat = h.HDoc_Doc_Cat AND d.DDoc_Doc_Ano= h.HDoc_Doc_Ano AND d.DDoc_Doc_Num = h.HDoc_Doc_Num -- AND d.DDoc_Doc_Lin = e.PDoc_Par_Lin
                            LEFT JOIN Inventarios i ON i.inv_sisemp = d.DDoc_Sis_Emp AND i.inv_numero = d.DDoc_Prd_Cod
                            LEFT JOIN Articulos a ON a.art_sisemp = i.inv_sisemp AND a.art_codigo = i.inv_artcodigo
                            LEFT JOIN {conta}.inventario_codigos ic ON ic.clase = a.art_clase AND ic.ejercicio = 1
                            WHERE h.HDoc_Sis_Emp = {empresa} AND h.HDoc_Doc_Cat = {cat} AND h.HDoc_Doc_Ano = {anio} AND h.HDoc_Doc_Num = {numero}
                            GROUP BY a.art_clase 
                        UNION
                            SELECT 0,'{empresa}',{ejercicio},{poliza},@numero:=@numero+1 item, p.pro_cuenta cuenta, 1 parametro_cuenta, SUM((d.DDoc_Prd_NET * d.DDoc_Prd_QTY)* h.HDoc_Doc_TC) importe, '' centro_Costo, NULL partida_Presupuestal, 'A' operacion, h.HDoc_Doc_Fec, 0 clase,36 modo, h.HDoc_Doc_Cat tipo, h.HDoc_Doc_Ano cilco, h.HDoc_Doc_Num num,0 id
                            FROM Dcmtos_HDR h
                            LEFT JOIN Dcmtos_DTL d ON d.DDoc_Sis_Emp = h.HDoc_Sis_Emp AND d.DDoc_Doc_Cat = h.HDoc_Doc_Cat AND d.DDoc_Doc_Ano= h.HDoc_Doc_Ano AND d.DDoc_Doc_Num = h.HDoc_Doc_Num 
                            LEFT JOIN Proveedores p ON p.pro_sisemp = h.HDoc_Sis_Emp AND p.pro_codigo = h.HDoc_Emp_Cod
                            WHERE h.HDoc_Sis_Emp = {empresa} AND h.HDoc_Doc_Cat = {cat} AND h.HDoc_Doc_Ano = {anio} AND h.HDoc_Doc_Num = {numero} "
            If Sesion.IdEmpresa = 18 Then
                strSQL &= "; SET @numero=1; "
                strSQL &= " INSERT INTO contapdm.detalle_polizas "
                strSQL &= "    SELECT 0,'{empresa}',{ejercicio},{poliza},1 item, ic.inventario cuenta, 1 parametro_cuenta, SUM((d.DDoc_Prd_NET * d.DDoc_Prd_QTY)* h.HDoc_Doc_TC) importe, d.DDoc_RF3_Num centro_Costo, NULL partida_Presupuestal, 'C' operacion, h.HDoc_Doc_Fec, 0 clase, 36 modo, h.HDoc_Doc_Cat tipo, h.HDoc_Doc_Ano cilco, h.HDoc_Doc_Num num,0 id
                            FROM PDM.Dcmtos_HDR h
                            LEFT JOIN PDM.Dcmtos_DTL d ON d.DDoc_Sis_Emp = h.HDoc_Sis_Emp AND d.DDoc_Doc_Cat = h.HDoc_Doc_Cat AND d.DDoc_Doc_Ano= h.HDoc_Doc_Ano AND d.DDoc_Doc_Num = h.HDoc_Doc_Num -- AND d.DDoc_Doc_Lin = e.PDoc_Par_Lin
                            LEFT JOIN PDM.Inventarios i ON i.inv_sisemp = d.DDoc_Sis_Emp AND i.inv_numero = d.DDoc_Prd_Cod
                            LEFT JOIN PDM.Articulos a ON a.art_sisemp = i.inv_sisemp AND a.art_codigo = i.inv_artcodigo
                            LEFT JOIN contapdm.inventario_codigos ic ON ic.clase = a.art_clase AND ic.ejercicio = 1
                            WHERE h.HDoc_Sis_Emp = {empresa} AND h.HDoc_Doc_Cat = {cat} AND h.HDoc_Doc_Ano = {anio} AND h.HDoc_Doc_Num = {numero}
                            GROUP BY a.art_clase 
                        UNION
                            SELECT 0,'{empresa}',{ejercicio},{poliza},@numero:=@numero+1 item, p.pro_cuenta cuenta, 1 parametro_cuenta, SUM((d.DDoc_Prd_NET * d.DDoc_Prd_QTY)* h.HDoc_Doc_TC) importe, '' centro_Costo, NULL partida_Presupuestal, 'A' operacion, h.HDoc_Doc_Fec, 0 clase,36 modo, h.HDoc_Doc_Cat tipo, h.HDoc_Doc_Ano cilco, h.HDoc_Doc_Num num,0 id
                            FROM PDM.Dcmtos_HDR h
                            LEFT JOIN PDM.Dcmtos_DTL d ON d.DDoc_Sis_Emp = h.HDoc_Sis_Emp AND d.DDoc_Doc_Cat = h.HDoc_Doc_Cat AND d.DDoc_Doc_Ano= h.HDoc_Doc_Ano AND d.DDoc_Doc_Num = h.HDoc_Doc_Num 
                            LEFT JOIN PDM.Proveedores p ON p.pro_sisemp = h.HDoc_Sis_Emp AND p.pro_codigo = h.HDoc_Emp_Cod
                            WHERE h.HDoc_Sis_Emp = {empresa} AND h.HDoc_Doc_Cat = {cat} AND h.HDoc_Doc_Ano = {anio} AND h.HDoc_Doc_Num = {numero} "
            End If

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try

        Return strSQL
    End Function
#End Region

#Region "Instruccion de Despacho - Traslado plantas"
    Private Sub PolizaInstruccionDespacho(ByVal cat As Integer, ByVal anio As Integer, ByVal num As Integer, ByVal fecha As Date)
        Dim longPolizas As Long = NO_FILA
        Dim COM As MySqlCommand
        Dim strSQL As String = STR_VACIO
        'Dim TipoIng As Integer
        'Dim tipoAnticipo As Integer

        strSQL = STR_VACIO
        longPolizas = NuevaPoliza()
        UltimaPoliza(longPolizas, EJERCICIO) ' actualiza la ultima poliza

        strSQL = SqlEncabezadoInstruccion(longPolizas, cat, anio, num, fecha)
        MyCnn.CONECTAR = strConexion
        COM = New MySqlCommand(strSQL, CON)
        COM.ExecuteNonQuery()
        strSQL = STR_VACIO

        strSQL = SqlDetalleInstruccion(longPolizas, cat, anio, num, fecha)
        MyCnn.CONECTAR = strConexion & " Allow User Variables=True"
        COM = New MySqlCommand(strSQL, CON)
        COM.ExecuteNonQuery()
        strSQL = STR_VACIO
    End Sub

    Private Function SqlEncabezadoInstruccion(ByVal poliza As Integer, ByVal cat As Integer, ByVal anio As Integer, ByVal num As Integer, ByVal fecha As Date)
        Dim strsql As String = STR_VACIO

        strsql = " INSERT INTO {conta}.polizas"
        strsql &= "   SELECT h.HDoc_Sis_Emp empresa, {ejercicio} ejercicio, {poliza} poliza, '{fec}' fecha, CONCAT('Poliza de instruccion de tendidos, Registro No. ', h.HDoc_Doc_Num) concepto, {tipoPoliza} tipo, 1 TC, '' observacion, '{user}' operador, 'C' estado, NOW() marca,'' grupo, {tipoPoliza} modo, h.HDoc_Doc_Cat refTipo, h.HDoc_Doc_Ano refCiclo, h.HDoc_Doc_Num refNumero, NULL divisa, 1 Tasa,0 revisado,'' usuarioRev, NULL ultRev "
        strsql &= "      FROM Dcmtos_HDR h "
        'strsql &= "      FROM Dcmtos_DTL d ON d.DDoc_Sis_Emp = h.HDoc_Sis_Emp and d.DDoc_Doc_Cat = h.HDoc_Doc_Cat and d.DDoc_Doc_Ano = h.HDoc_Doc_Ano  and d.DDoc_Doc_Num = h.HDoc_Doc_Num "
        strsql &= "         WHERE h.HDoc_Sis_Emp = {empresa} AND h.HDoc_Doc_Cat = {cat} AND h.HDoc_Doc_Ano = {anio} AND h.HDoc_Doc_Num = {num} "

        If Sesion.IdEmpresa = 18 Then
            strsql &= "; INSERT INTO contapdm.polizas"
            strsql &= "   SELECT h.HDoc_Sis_Emp empresa, {ejercicio} ejercicio, {poliza} poliza, '{fec}' fecha, CONCAT('Poliza de instruccion de tendidos, Registro No. ', h.HDoc_Doc_Num) concepto, {tipoPoliza} tipo, 1 TC, '' observacion, '{user}' operador, 'C' estado, NOW() marca,'' grupo, {tipoPoliza} modo, h.HDoc_Doc_Cat refTipo, h.HDoc_Doc_Ano refCiclo, h.HDoc_Doc_Num refNumero, NULL divisa, 1 Tasa,0 revisado,'' usuarioRev, NULL ultRev "
            strsql &= "      FROM PDM.Dcmtos_HDR h "
            strsql &= "         WHERE h.HDoc_Sis_Emp = {empresa} AND h.HDoc_Doc_Cat = {cat} AND h.HDoc_Doc_Ano = {anio} AND h.HDoc_Doc_Num = {num} "
        End If

        strsql = Replace(strsql, "{tipoPoliza}", 37)

        strsql = Replace(strsql, "{ejercicio}", EJERCICIO)
        strsql = Replace(strsql, "{poliza}", poliza)
        strsql = Replace(strsql, "{empresa}", Sesion.IdEmpresa)
        strsql = Replace(strsql, "{cat}", cat)
        strsql = Replace(strsql, "{anio}", anio)
        strsql = Replace(strsql, "{num}", num)
        strsql = Replace(strsql, "{conta}", Sesion.BaseConta)
        strsql = Replace(strsql, "{fec}", fecha.ToString(FORMATO_MYSQL))
        strsql = Replace(strsql, "{user}", Sesion.Usuario)

        Return strsql
    End Function

    Private Function SqlDetalleInstruccion(ByVal poliza As Integer, ByVal cat As Integer, ByVal anio As Integer, ByVal num As Integer, ByVal fecha As Date)
        Dim strSql As String = STR_VACIO

        strSql = " INSERT INTO {conta}.detalle_polizas

                    SELECT s1.transaccion, s1.empresa, s1.ejercicio, s1.poliza, (@REG := @REG + 1) item, IFNULL(s1.cuenta,''), s1.parametro_cuenta, s1.importe, centro_costos, IFNULL(s1.partida_presupuestal,''), s1.operacion, s1.fecha, IFNULL(s1.clase,''), s1.modo, s1.ref_tipo, s1.ref_ciclo, s1.ref_numero, s1.ref_id
                        FROM(
                        SELECT 0 transaccion, h.HDoc_Sis_Emp empresa, {ejercicio} ejercicio, {poliza} poliza, @REG :=0, '110507998' cuenta, h.HDoc_DR1_Cat parametro_cuenta, ROUND(SUM((d.DDoc_Prd_QTY * d47.DDoc_Prd_NET) * h47.HDoc_Doc_TC),2) Importe,0 centro_costos, NULL partida_presupuestal, 'C' operacion, CAST(CURDATE() AS CHAR) fecha, 0 clase, 37 modo, h.HDoc_Doc_Cat ref_tipo, h.HDoc_Doc_Ano ref_ciclo, h.HDoc_Doc_Num ref_numero, d.DDoc_Prd_Cod ref_id
                        FROM Dcmtos_HDR h
                        LEFT JOIN Dcmtos_DTL d ON d.DDoc_Sis_Emp = h.HDoc_Sis_Emp AND d.DDoc_Doc_Cat = h.HDoc_Doc_Cat AND d.DDoc_Doc_Ano = h.HDoc_Doc_Ano AND d.DDoc_Doc_Num = h.HDoc_Doc_Num
                        LEFT JOIN Dcmtos_DTL_Pro p ON p.PDoc_Sis_Emp = d.DDoc_Sis_Emp AND p.PDoc_Chi_Cat = d.DDoc_Doc_Cat AND p.PDoc_Chi_Ano = d.DDoc_Doc_Ano AND p.PDoc_Chi_Num = d.DDoc_Doc_Num AND p.PDoc_Chi_Lin = d.DDoc_Doc_Lin AND p.PDoc_Par_Cat = 47
                        LEFT JOIN Dcmtos_DTL d47 ON d47.DDoc_Sis_Emp = p.PDoc_Sis_Emp AND d47.DDoc_Doc_Cat = p.PDoc_Par_Cat AND d47.DDoc_Doc_Ano = p.PDoc_Par_Ano AND d47.DDoc_Doc_Num = p.PDoc_Par_Num AND d47.DDoc_Doc_Lin = p.PDoc_Par_Lin
                        LEFT JOIN Dcmtos_HDR h47 ON h47.HDoc_Sis_Emp = d47.DDoc_Sis_Emp AND h47.HDoc_Doc_Cat = d47.DDoc_Doc_Cat and h47.HDoc_Doc_Ano = d47.DDoc_Doc_Ano AND h47.HDoc_Doc_Num = d47.DDoc_Doc_Num
                    WHERE h.HDoc_Sis_Emp = {empresa} AND h.HDoc_Doc_Cat = {cat} AND h.HDoc_Doc_Ano = {anio} AND h.HDoc_Doc_Num = {num}


                    UNION
                    SELECT 0 transaccion, h.HDoc_Sis_Emp empresa, {ejercicio} ejercicio, {poliza} poliza, @REG :=0, v.inventario cuenta, h.HDoc_DR1_Cat parametro_cuenta, ROUND(SUM((d.DDoc_Prd_QTY * d47.DDoc_Prd_NET) * h47.HDoc_Doc_TC),2) Importe,0 centro_costos, NULL partida_presupuestal, 'A' operacion, CAST(CURDATE() AS CHAR) fecha, a.art_clase clase, 37 modo, h.HDoc_Doc_Cat ref_tipo, h.HDoc_Doc_Ano ref_ciclo, h.HDoc_Doc_Num ref_numero, d.DDoc_Prd_Cod ref_id
                        FROM Dcmtos_HDR h
                        LEFT JOIN Dcmtos_DTL d ON d.DDoc_Sis_Emp = h.HDoc_Sis_Emp AND d.DDoc_Doc_Cat = h.HDoc_Doc_Cat AND d.DDoc_Doc_Ano = h.HDoc_Doc_Ano AND d.DDoc_Doc_Num = h.HDoc_Doc_Num
                        LEFT JOIN Dcmtos_DTL_Pro p ON p.PDoc_Sis_Emp = d.DDoc_Sis_Emp AND p.PDoc_Chi_Cat = d.DDoc_Doc_Cat AND p.PDoc_Chi_Ano = d.DDoc_Doc_Ano AND p.PDoc_Chi_Num = d.DDoc_Doc_Num AND p.PDoc_Chi_Lin = d.DDoc_Doc_Lin AND p.PDoc_Par_Cat = 47
                        LEFT JOIN Dcmtos_DTL d47 ON d47.DDoc_Sis_Emp = p.PDoc_Sis_Emp AND d47.DDoc_Doc_Cat = p.PDoc_Par_Cat AND d47.DDoc_Doc_Ano = p.PDoc_Par_Ano AND d47.DDoc_Doc_Num = p.PDoc_Par_Num AND d47.DDoc_Doc_Lin = p.PDoc_Par_Lin 
                        LEFT JOIN Dcmtos_HDR h47 ON h47.HDoc_Sis_Emp = d47.DDoc_Sis_Emp AND h47.HDoc_Doc_Cat = d47.DDoc_Doc_Cat and h47.HDoc_Doc_Ano = d47.DDoc_Doc_Ano AND h47.HDoc_Doc_Num = d47.DDoc_Doc_Num                        
                        LEFT JOIN Inventarios i ON i.inv_sisemp = d.DDoc_Sis_Emp AND i.inv_numero = d.DDoc_Prd_Cod
                        LEFT JOIN Articulos a ON a.art_sisemp = i.inv_sisemp AND a.art_codigo = i.inv_artcodigo
                        LEFT JOIN {conta}.inventario_codigos v ON v.empresa = a.art_sisemp AND v.clase = a.art_clase 
                    WHERE h.HDoc_Sis_Emp = {empresa} AND h.HDoc_Doc_Cat = {cat} AND h.HDoc_Doc_Ano = {anio} AND h.HDoc_Doc_Num = {num}
                    GROUP BY a.art_clase)s1"

        If Sesion.IdEmpresa = 18 Then
            strSql &= "; INSERT INTO contapdm.detalle_polizas

                    SELECT s1.transaccion, s1.empresa, s1.ejercicio, s1.poliza, (@REG := @REG + 1) item, IFNULL(s1.cuenta,''), s1.parametro_cuenta, s1.importe, centro_costos, IFNULL(s1.partida_presupuestal,''), s1.operacion, s1.fecha, IFNULL(s1.clase,''), s1.modo, s1.ref_tipo, s1.ref_ciclo, s1.ref_numero, s1.ref_id
                        FROM(
                        SELECT 0 transaccion, h.HDoc_Sis_Emp empresa, {ejercicio} ejercicio, {poliza} poliza, @REG :=0, '110507998' cuenta, h.HDoc_DR1_Cat parametro_cuenta, ROUND(SUM((d.DDoc_Prd_QTY * d47.DDoc_Prd_NET) * h47.HDoc_Doc_TC),2) Importe,0 centro_costos, NULL partida_presupuestal, 'C' operacion, CAST(CURDATE() AS CHAR) fecha, 0 clase, 37 modo, h.HDoc_Doc_Cat ref_tipo, h.HDoc_Doc_Ano ref_ciclo, h.HDoc_Doc_Num ref_numero, d.DDoc_Prd_Cod ref_id
                        FROM PDM.Dcmtos_HDR h
                        LEFT JOIN PDM.Dcmtos_DTL d ON d.DDoc_Sis_Emp = h.HDoc_Sis_Emp AND d.DDoc_Doc_Cat = h.HDoc_Doc_Cat AND d.DDoc_Doc_Ano = h.HDoc_Doc_Ano AND d.DDoc_Doc_Num = h.HDoc_Doc_Num
                        LEFT JOIN PDM.Dcmtos_DTL_Pro p ON p.PDoc_Sis_Emp = d.DDoc_Sis_Emp AND p.PDoc_Chi_Cat = d.DDoc_Doc_Cat AND p.PDoc_Chi_Ano = d.DDoc_Doc_Ano AND p.PDoc_Chi_Num = d.DDoc_Doc_Num AND p.PDoc_Chi_Lin = d.DDoc_Doc_Lin AND p.PDoc_Par_Cat = 47
                        LEFT JOIN PDM.Dcmtos_DTL d47 ON d47.DDoc_Sis_Emp = p.PDoc_Sis_Emp AND d47.DDoc_Doc_Cat = p.PDoc_Par_Cat AND d47.DDoc_Doc_Ano = p.PDoc_Par_Ano AND d47.DDoc_Doc_Num = p.PDoc_Par_Num AND d47.DDoc_Doc_Lin = p.PDoc_Par_Lin
                        LEFT JOIN PDM.Dcmtos_HDR h47 ON h47.HDoc_Sis_Emp = d47.DDoc_Sis_Emp AND h47.HDoc_Doc_Cat = d47.DDoc_Doc_Cat and h47.HDoc_Doc_Ano = d47.DDoc_Doc_Ano AND h47.HDoc_Doc_Num = d47.DDoc_Doc_Num
                    WHERE h.HDoc_Sis_Emp = {empresa} AND h.HDoc_Doc_Cat = {cat} AND h.HDoc_Doc_Ano = {anio} AND h.HDoc_Doc_Num = {num}


                    UNION
                    SELECT 0 transaccion, h.HDoc_Sis_Emp empresa, {ejercicio} ejercicio, {poliza} poliza, @REG :=0, v.inventario cuenta, h.HDoc_DR1_Cat parametro_cuenta, ROUND(SUM((d.DDoc_Prd_QTY * d47.DDoc_Prd_NET) * h47.HDoc_Doc_TC),2) Importe,0 centro_costos, NULL partida_presupuestal, 'A' operacion, CAST(CURDATE() AS CHAR) fecha, a.art_clase clase, 37 modo, h.HDoc_Doc_Cat ref_tipo, h.HDoc_Doc_Ano ref_ciclo, h.HDoc_Doc_Num ref_numero, d.DDoc_Prd_Cod ref_id
                        FROM PDM.Dcmtos_HDR h
                        LEFT JOIN PDM.Dcmtos_DTL d ON d.DDoc_Sis_Emp = h.HDoc_Sis_Emp AND d.DDoc_Doc_Cat = h.HDoc_Doc_Cat AND d.DDoc_Doc_Ano = h.HDoc_Doc_Ano AND d.DDoc_Doc_Num = h.HDoc_Doc_Num
                        LEFT JOIN PDM.Dcmtos_DTL_Pro p ON p.PDoc_Sis_Emp = d.DDoc_Sis_Emp AND p.PDoc_Chi_Cat = d.DDoc_Doc_Cat AND p.PDoc_Chi_Ano = d.DDoc_Doc_Ano AND p.PDoc_Chi_Num = d.DDoc_Doc_Num AND p.PDoc_Chi_Lin = d.DDoc_Doc_Lin AND p.PDoc_Par_Cat = 47
                        LEFT JOIN PDM.Dcmtos_DTL d47 ON d47.DDoc_Sis_Emp = p.PDoc_Sis_Emp AND d47.DDoc_Doc_Cat = p.PDoc_Par_Cat AND d47.DDoc_Doc_Ano = p.PDoc_Par_Ano AND d47.DDoc_Doc_Num = p.PDoc_Par_Num AND d47.DDoc_Doc_Lin = p.PDoc_Par_Lin 
                        LEFT JOIN PDM.Dcmtos_HDR h47 ON h47.HDoc_Sis_Emp = d47.DDoc_Sis_Emp AND h47.HDoc_Doc_Cat = d47.DDoc_Doc_Cat and h47.HDoc_Doc_Ano = d47.DDoc_Doc_Ano AND h47.HDoc_Doc_Num = d47.DDoc_Doc_Num                        
                        LEFT JOIN PDM.Inventarios i ON i.inv_sisemp = d.DDoc_Sis_Emp AND i.inv_numero = d.DDoc_Prd_Cod
                        LEFT JOIN PDM.Articulos a ON a.art_sisemp = i.inv_sisemp AND a.art_codigo = i.inv_artcodigo
                        LEFT JOIN contapdm.inventario_codigos v ON v.empresa = a.art_sisemp AND v.clase = a.art_clase 
                    WHERE h.HDoc_Sis_Emp = {empresa} AND h.HDoc_Doc_Cat = {cat} AND h.HDoc_Doc_Ano = {anio} AND h.HDoc_Doc_Num = {num}
                    GROUP BY a.art_clase)s1"
        End If

        'strSql = Replace(strSql, "{tipoPoliza}", 33)

        strSql = Replace(strSql, "{ejercicio}", EJERCICIO)
        strSql = Replace(strSql, "{poliza}", poliza)
        strSql = Replace(strSql, "{empresa}", Sesion.IdEmpresa)
        strSql = Replace(strSql, "{cat}", cat)
        strSql = Replace(strSql, "{anio}", anio)
        strSql = Replace(strSql, "{num}", num)
        strSql = Replace(strSql, "{conta}", Sesion.BaseConta)
        'strSql = Replace(strSql, "{fec}", fecha.ToString(FORMATO_MYSQL))
        strSql = Replace(strSql, "{user}", Sesion.Usuario)

        Return strSql
    End Function

#End Region


#Region "Inventario Proceso Productivo - (Ingresos NT)"
    Private Function SQLEncabezadoPolizaproductivoNT(ByVal cat As Integer, ByVal anio As Integer, ByVal num As Integer, ByVal poliza As Integer, ByVal tipoingreso As Integer)
        Dim strSQL As String = STR_VACIO

        strSQL = " INSERT INTO {conta}.polizas"
        strSQL &= "   SELECT h.HDoc_Sis_Emp empresa, {ejercicio} ejercicio, {poliza} poliza, h.HDoc_Doc_Fec fecha, CONCAT('Para Registrar Ingreso a Bodega de producto {tipoIngresoNombre}: ', h.HDoc_Doc_Num, ' de fecha ', h.HDoc_Doc_Fec) concepto, {tipoingreso} tipo, h.HDoc_Doc_TC TC, 
'' observacion, h.HDoc_Usuario operador, 'C' estado, NOW() marca,'' grupo, {tipoingreso} modo, h.HDoc_Doc_Cat refTipo, h.HDoc_Doc_Ano refCiclo, h.HDoc_Doc_Num refNumero, NULL divisa, h.HDoc_Doc_TC Tasa,0 revisado,'' usuarioRev, NULL ultRev "
        strSQL &= "      FROM Dcmtos_HDR h "
        strSQL &= "         WHERE h.HDoc_Sis_Emp = {empresa} AND h.HDoc_Doc_Cat = {cat} AND h.HDoc_Doc_Ano = {anio} AND h.HDoc_Doc_Num = {num} "
        If Sesion.IdEmpresa = 18 Then
            strSQL &= "; INSERT INTO contapdm.polizas"
            strSQL &= "   SELECT h.HDoc_Sis_Emp empresa, {ejercicio} ejercicio, {poliza} poliza, h.HDoc_Doc_Fec fecha, CONCAT('Para Registrar Ingreso a Bodega de producto {tipoIngresoNombre}: ', h.HDoc_Doc_Num, ' de fecha ', h.HDoc_Doc_Fec) concepto, {tipoingreso} tipo, h.HDoc_Doc_TC TC, 
'' observacion, h.HDoc_Usuario operador, 'C' estado, NOW() marca,'' grupo, {tipoingreso} modo, h.HDoc_Doc_Cat refTipo, h.HDoc_Doc_Ano refCiclo, h.HDoc_Doc_Num refNumero, NULL divisa, h.HDoc_Doc_TC Tasa,0 revisado,'' usuarioRev, NULL ultRev "
            strSQL &= "      FROM PDM.Dcmtos_HDR h "
            strSQL &= "         WHERE h.HDoc_Sis_Emp = {empresa} AND h.HDoc_Doc_Cat = {cat} AND h.HDoc_Doc_Ano = {anio} AND h.HDoc_Doc_Num = {num} "
        End If
        strSQL = Replace(strSQL, "{ejercicio}", EJERCICIO)
        strSQL = Replace(strSQL, "{poliza}", poliza)
        strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
        strSQL = Replace(strSQL, "{cat}", cat)
        strSQL = Replace(strSQL, "{anio}", anio)
        strSQL = Replace(strSQL, "{num}", num)
        strSQL = Replace(strSQL, "{tipoingreso}", tipoingreso)


        If tipoingreso = 38 Then
            strSQL = Replace(strSQL, "{tipoingresoNombre}", " Dyeing")
        ElseIf tipoingreso = 39 Then
            strSQL = Replace(strSQL, "{tipoingresoNombre}", " Finishing")
        ElseIf tipoingreso = 40 Then
            strSQL = Replace(strSQL, "{tipoingresoNombre}", " Rolling")
        Else
            strSQL = Replace(strSQL, "{tipoingresoNombre}", " Finish good ")
        End If

        strSQL = Replace(strSQL, "{conta}", Sesion.BaseConta)
        Return strSQL
    End Function
    Private Function SQLDetallePolizaProductivoNT(ByVal db As String, ByVal conta As String, ByVal cat As Integer, ByVal anio As Integer, ByVal num As Integer, ByVal poliza As Integer, ByVal tipopoliza As Integer, ByVal tipoingresoanterior As Integer)
        Dim strSQL As String = STR_VACIO

        strSQL = " SET @numero=0;  "
        strSQL &= " INSERT INTO {conta}.detalle_polizas "

        strSQL &= "  SELECT l1.Transaccion,l1.Empresa,l1.ejercicio,l1.poliza, l1.item,l1.cuenta,l1.parametroCuenta, ROUND(SUM((l1.Precio * l1.Tasa)),2) Importe,l1.centroCosto,l1.partidaPresupuestal,l1.operacion, l1.Fecha, l1.clase, l1.modo, l1.refTipo, l1.refCiclo, l1.refNumero,l1.id
                        FROM(
                        SELECT 0 Transaccion,d.DDoc_Sis_Emp Empresa,{ejercicio} ejercicio,{poliza} poliza,@numero:=@numero+1 item, ic.inventario cuenta,1 parametroCuenta,'' centroCosto, '' partidaPresupuestal, 'C' operacion,h.HDoc_Doc_Fec Fecha,0 clase, {tipoPoliza} modo, h.HDoc_Doc_Cat refTipo, h.HDoc_Doc_Ano refCiclo, h.HDoc_Doc_Num refNumero, 0 id, ROUND(d.DDoc_Prd_QTY * d.DDoc_Prd_Net,5) Precio,h.HDoc_Doc_TC Tasa, IFNULL((
                        SELECT ROUND((g.Promedio + g.Total1 + g.Total2),2) Total
                        FROM {db}Gastos_Produccion g
                        LEFT JOIN {db}Catalogos c ON c.cat_num = g.idMoneda AND c.cat_clase = 'Monedas'
                        LEFT JOIN {db}Catalogos gp ON gp.cat_num = g.Gasto AND gp.cat_clase = 'GastoP'
                        WHERE g.idEmpresa = {empresa} AND gp.cat_desc = 'Mano de Obra' AND g.Fecha <= h.HDoc_Doc_Fec
                        ORDER BY g.Fecha DESC
                        LIMIT 1), 0) MO, IFNULL((
                        SELECT ROUND((g.Promedio + g.Total1 + g.Total2),2) Total
                        FROM {db}Gastos_Produccion g
                        LEFT JOIN {db}Catalogos c ON c.cat_num = g.idMoneda AND c.cat_clase = 'Monedas'
                        LEFT JOIN {db}Catalogos gp ON gp.cat_num = g.Gasto AND gp.cat_clase = 'GastoP'
                        WHERE g.idEmpresa = {empresa} AND gp.cat_desc = 'Gastos de fabricación' AND g.Fecha <= h.HDoc_Doc_Fec
                        ORDER BY g.idGastoProduccion DESC
                        LIMIT 1), 0) GF
                        FROM {db}Dcmtos_DTL d
                        LEFT JOIN {db}Dcmtos_HDR h ON h.HDoc_Sis_Emp = d.DDoc_Sis_Emp AND h.HDoc_Doc_Cat = d.DDoc_Doc_Cat AND h.HDoc_Doc_Ano = d.DDoc_Doc_Ano AND h.HDoc_Doc_Num = d.DDoc_Doc_Num
                        LEFT JOIN {db}Inventarios i ON i.inv_sisemp = d.DDoc_Sis_Emp AND i.inv_numero = d.DDoc_Prd_Cod
                        LEFT JOIN {db}Articulos a ON a.art_sisemp = i.inv_sisemp AND a.art_codigo = i.inv_artcodigo
                        LEFT JOIN {conta}.inventario_codigos ic ON ic.empresa = a.art_sisemp AND ic.clase = a.art_clase AND ic.ejercicio  = {tipofactores}
                        WHERE d.DDoc_Sis_Emp = {empresa} AND d.DDoc_Doc_Cat = {cat} AND d.DDoc_Doc_Ano = {anio} AND d.DDoc_Doc_Num = {num})l1
                        GROUP BY l1.cuenta 
                        UNION


                        SELECT l1.Transaccion,l1.Empresa,l1.ejercicio,l1.poliza, l1.item,l1.cuenta,l1.parametroCuenta, ROUND(SUM(((l1.Precio-l1.MO-l1.GF-l1.WI-Factor_MP) * l1.Tasa)),2) Importe, 
                         -- ROUND(SUM((l1.Precio * l1.Tasa)),2)Importe , 
                         -- ROUND(SUM(((l1.Precio-l1.MO-l1.GF) * l1.Tasa)),2) Importe, -- l1.Precio,
                         -- l1.tasa,
                         l1.centroCosto,l1.partidaPresupuestal,l1.operacion, l1.Fecha, l1.clase, l1.modo, l1.refTipo, l1.refCiclo, l1.refNumero,l1.id
                        FROM(
                        SELECT 0 Transaccion,d.DDoc_Sis_Emp Empresa,{ejercicio} ejercicio,{poliza} poliza,@numero:=@numero+1 item, ic.inventario cuenta,1 parametroCuenta,'' centroCosto, '' partidaPresupuestal, 
	                         'A' operacion,h.HDoc_Doc_Fec Fecha,0 clase, {tipoPoliza} modo, h.HDoc_Doc_Cat refTipo, h.HDoc_Doc_Ano refCiclo, h.HDoc_Doc_Num refNumero, 0 id, ROUND(d.DDoc_Prd_QTY * d.DDoc_Prd_Net,5) Precio, h.HDoc_Doc_TC Tasa, 
	
	                         (IFNULL((
                        SELECT (g.Promedio + g.Total1 + g.Total2) Total
                        FROM {db}Gastos_Produccion g
                        LEFT JOIN {db}Catalogos c ON c.cat_num = g.idMoneda AND c.cat_clase = 'Monedas'
                        LEFT JOIN {db}Catalogos gp ON gp.cat_num = g.Gasto AND gp.cat_clase = 'GastoP'
                        WHERE g.idEmpresa = d.DDoc_Sis_Emp AND gp.cat_desc = 'Mano de Obra' AND g.Fecha <= h.HDoc_Doc_Fec
                        ORDER BY g.Fecha DESC
                        LIMIT 1), 0)*d.DDoc_Prd_QTY) MO, 
	
	                         (IFNULL((
                        SELECT (g.Promedio + g.Total1 + g.Total2) Total
                        FROM {db}Gastos_Produccion g
                        LEFT JOIN {db}Catalogos c ON c.cat_num = g.idMoneda AND c.cat_clase = 'Monedas'
                        LEFT JOIN {db}Catalogos gp ON gp.cat_num = g.Gasto AND gp.cat_clase = 'GastoP'
                        WHERE g.idEmpresa = d.DDoc_Sis_Emp AND gp.cat_desc = 'Gastos de fabricación' AND g.Fecha <= h.HDoc_Doc_Fec
                        ORDER BY g.Fecha DESC
                        LIMIT 1), 0)*d.DDoc_Prd_QTY) GF,

                         (IFNULL((
                        SELECT (g.Promedio + g.Total1 + g.Total2) Total
                        FROM {db}Gastos_Produccion g
                        LEFT JOIN {db}Catalogos c ON c.cat_num = g.idMoneda AND c.cat_clase = 'Monedas'
                        LEFT JOIN {db}Catalogos gp ON gp.cat_num = g.Gasto AND gp.cat_clase = 'GastoP'
                        WHERE g.idEmpresa = d.DDoc_Sis_Emp AND gp.cat_desc = 'Waste & invisible' AND g.Fecha <= h.HDoc_Doc_Fec
                        ORDER BY g.Fecha DESC
                        LIMIT 1), 0)*d.DDoc_Prd_QTY) WI,

                         (IFNULL((
                        SELECT (SUM(g.Promedio + g.Total1 + g.Total2)) Total
                        FROM {db}Gastos_Produccion g
                        LEFT JOIN {db}Catalogos gp ON gp.cat_num = g.Gasto AND gp.cat_clase = 'GastoP'
                        WHERE g.idEmpresa = h.HDoc_Sis_Emp AND gp.cat_desc = 'Factor' AND gp.cat_pid = {tipofactores} AND g.Fecha =(
                        SELECT MAX(Fecha)
                        FROM {db}Gastos_Produccion
                        WHERE Fecha <= h.HDoc_Doc_Fec)
                        ORDER BY g.Fecha DESC 
                        ), 0)*d.DDoc_Prd_QTY) Factor_MP
                        FROM {db}Dcmtos_DTL d
                        LEFT JOIN {db}Dcmtos_HDR h ON h.HDoc_Sis_Emp = d.DDoc_Sis_Emp AND h.HDoc_Doc_Cat = d.DDoc_Doc_Cat AND h.HDoc_Doc_Ano = d.DDoc_Doc_Ano AND h.HDoc_Doc_Num = d.DDoc_Doc_Num
                        LEFT JOIN {db}Inventarios i ON i.inv_sisemp = d.DDoc_Sis_Emp AND i.inv_numero = d.DDoc_Prd_Cod
                        LEFT JOIN {db}Articulos a ON a.art_sisemp = i.inv_sisemp AND a.art_codigo = i.inv_artcodigo"
        If tipopoliza = 41 Then
            strSQL &= " LEFT JOIN {db}Dcmtos_DTL_Pro p ON p.PDoc_Sis_Emp = d.DDoc_Sis_Emp AND p.PDoc_Chi_Cat = d.DDoc_Doc_Cat AND p.PDoc_Chi_Ano = d.DDoc_Doc_Ano AND p.PDoc_Chi_Num = d.DDoc_Doc_Num AND p.PDoc_Chi_Lin = d.DDoc_Doc_Lin
                        LEFT JOIN {db}Dcmtos_DTL ant ON ant.DDoc_Sis_Emp = p.PDoc_Sis_Emp AND ant.DDoc_Doc_Cat = p.PDoc_Par_Cat AND ant.DDoc_Doc_Ano = p.PDoc_Par_Ano AND ant.DDoc_Doc_Num = p.PDoc_Par_Num AND ant.DDoc_Doc_Lin = p.PDoc_Par_Lin 
                        LEFT JOIN {db}Dcmtos_HDR hant ON hant.HDoc_Sis_Emp = ant.DDoc_Sis_Emp AND hant.HDoc_Doc_Cat = ant.DDoc_Doc_Cat AND hant.HDoc_Doc_Ano = ant.DDoc_Doc_Ano AND hant.HDoc_Doc_Num = ant.DDoc_Doc_Num 
                        LEFT JOIN {conta}.inventario_codigos ic ON ic.empresa = a.art_sisemp AND ic.clase = a.art_clase AND ic.Terminado = hant.HDoc_DR1_Cat"
        Else
            strSQL &= " LEFT JOIN {conta}.inventario_codigos ic ON ic.empresa = a.art_sisemp AND ic.clase = a.art_clase AND ic.ejercicio  = {tipoFactorAnterior}"
        End If

        strSQL &= "  WHERE d.DDoc_Sis_Emp = {empresa} AND d.DDoc_Doc_Cat = {cat} AND d.DDoc_Doc_Ano = {anio} AND d.DDoc_Doc_Num = {num}
                        )l1
                        GROUP BY l1.cuenta 
                        UNION


                        SELECT l1.Transaccion,l1.Empresa,l1.ejercicio,l1.poliza, l1.item,l1.cuenta,l1.parametroCuenta, ROUND(SUM(((l1.Cantidad * l1.MO))* l1.Tasa),2) importe,l1.centroCosto,l1.partidaPresupuestal,l1.operacion, l1.Fecha, l1.clase, l1.modo, l1.refTipo, l1.refCiclo, l1.refNumero, l1.id
                        FROM (
                        SELECT 0 Transaccion,d.DDoc_Sis_Emp Empresa,{ejercicio} ejercicio,{poliza} poliza,@numero:=@numero+1 item,gp.cat_dato cuenta,1 parametroCuenta,'' centroCosto, '' partidaPresupuestal, 'A' operacion,h.HDoc_Doc_Fec Fecha,0 clase, {tipoPoliza} modo, h.HDoc_Doc_Cat refTipo, h.HDoc_Doc_Ano refCiclo, h.HDoc_Doc_Num refNumero, 0 id,d.DDoc_Prd_QTY Cantidad,h.HDoc_Doc_TC Tasa, (g.Promedio + g.Total1 + g.Total2) MO
                        FROM {db}Dcmtos_DTL d
                        LEFT JOIN {db}Dcmtos_HDR h ON h.HDoc_Sis_Emp = d.DDoc_Sis_Emp AND h.HDoc_Doc_Cat = d.DDoc_Doc_Cat AND h.HDoc_Doc_Ano = d.DDoc_Doc_Ano AND h.HDoc_Doc_Num = d.DDoc_Doc_Num
                        LEFT JOIN (
                        SELECT idEmpresa, Anio, idGastoProduccion, Linea, Fecha, Tasa, Gasto, Promedio, Total1, Total2, idMoneda
                        FROM {db}Gastos_Produccion
                        WHERE (idEmpresa, Anio, idGastoProduccion) IN (
                        SELECT idEmpresa, Anio, MAX(idGastoProduccion) idGastoProduccion
                        FROM {db}Gastos_Produccion
                        GROUP BY idEmpresa, Anio
                        ORDER BY idEmpresa DESC, Anio DESC, idGastoProduccion DESC
                        ) 
                        ) g ON g.idEmpresa = h.HDoc_Sis_Emp AND g.Fecha <= h.HDoc_Doc_Fec
                        LEFT JOIN {db}Catalogos c ON c.cat_num = g.idMoneda AND c.cat_clase = 'Monedas'
                        LEFT JOIN {db}Catalogos gp ON gp.cat_num = g.Gasto AND gp.cat_clase = 'GastoP'
                        WHERE d.DDoc_Sis_Emp = {empresa} AND d.DDoc_Doc_Cat = {cat} AND d.DDoc_Doc_Ano = {anio} AND d.DDoc_Doc_Num = {num} AND gp.cat_desc = 'Factor' AND gp.cat_pid = {tipofactores})l1
                        GROUP BY l1.cuenta "

        strSQL = Replace(strSQL, "{poliza}", poliza)
        strSQL = Replace(strSQL, "{ejercicio}", EJERCICIO)
        strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
        strSQL = Replace(strSQL, "{cat}", cat)
        strSQL = Replace(strSQL, "{anio}", anio)
        strSQL = Replace(strSQL, "{num}", num)
        strSQL = Replace(strSQL, "{tipoPoliza}", tipopoliza)
        strSQL = Replace(strSQL, "{conta}", conta)
        strSQL = Replace(strSQL, "{db}", db)
        If tipopoliza = 38 Then
            strSQL = Replace(strSQL, "{tipofactores}", 2)
            strSQL = Replace(strSQL, "{tipoFactorAnterior}", 1)
        ElseIf tipopoliza = 39 Then
            strSQL = Replace(strSQL, "{tipofactores}", 3)
            strSQL = Replace(strSQL, "{tipoFactorAnterior}", 2)
        ElseIf tipopoliza = 40 Then
            strSQL = Replace(strSQL, "{tipofactores}", 4)
            strSQL = Replace(strSQL, "{tipoFactorAnterior}", 3)
        ElseIf tipopoliza = 41 Then
            If tipoingresoanterior = 15 Then
                strSQL = Replace(strSQL, "{tipoFactorAnterior}", 3)
            ElseIf tipoingresoanterior = 16 Then
                strSQL = Replace(strSQL, "{tipoFactorAnterior}", 4)
            End If
            strSQL = Replace(strSQL, "{tipofactores}", 5)

        End If

        Return strSQL
    End Function
    Private Function SQLDetallePolizaProductivoNT(ByVal cat As Integer, ByVal anio As Integer, ByVal num As Integer, ByVal poliza As Integer, ByVal tipopoliza As Integer, ByVal tipoingresoanterior As Integer)
        Dim strSQL As String = SQLDetallePolizaProductivoNT(STR_VACIO, Sesion.BaseConta, cat, anio, num, poliza, tipopoliza, tipoingresoanterior)

        If Sesion.IdEmpresa = 18 Then
            strSQL = String.Concat(strSQL, ";", SQLDetallePolizaProductivoNT("PDM.", "contapdm", cat, anio, num, poliza, tipopoliza, tipoingresoanterior))
        End If

        Return strSQL
    End Function
    Private Sub PolizaInventarioProductivoNT(ByVal cat As Integer, ByVal anio As Integer, ByVal num As Integer, ByVal tipoingreso As Integer, ByVal tipoIngresoAnterior As Integer)

        Dim longPolizas As Long = NO_FILA
        Dim COM As MySqlCommand
        Dim strSQL As String = STR_VACIO

        Try
            longPolizas = NuevaPoliza()
            UltimaPoliza(longPolizas, EJERCICIO) ' actualiza la ultima poliza

            strSQL = SQLEncabezadoPolizaproductivoNT(cat, anio, num, longPolizas, tipoingreso)
            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSQL, CON)
            COM.ExecuteNonQuery()

            strSQL = STR_VACIO

            strSQL = SQLDetallePolizaProductivoNT(cat, anio, num, longPolizas, tipoingreso, tipoIngresoAnterior)
            MyCnn.CONECTAR = strConexion & ";Allow User Variables=True"
            COM = New MySqlCommand(strSQL, CON)
            COM.ExecuteNonQuery()
            strSQL = STR_VACIO

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub
#End Region
End Class
