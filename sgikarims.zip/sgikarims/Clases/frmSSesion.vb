﻿Public Class frmSSesion

   Dim cSesion As New clsSesion
    Const LOCAL = "CUR_LOC"
    Const EXTERNA = "CUR_EXT"

#Region "Funciones y Procedimientos"
    Private Sub CargarDivisas()
        Dim strSQL As String = STR_VACIO
        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader

        strSQL = " select cc.cat_num  cod ,cc.cat_desc des , cc.cat_clave sim  , cc.cat_sist factor "
        strSQL &= "  from Catalogos c "
        strSQL &= "     left join Catalogos cc on cc.cat_num = c.cat_clave   "
        strSQL &= "  where c.cat_clase = 'Defaults' and c.cat_sist = '{tipo}'"
        Try
            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(Replace(strSQL, "{tipo}", LOCAL), CON)
            REA = COM.ExecuteReader
            If REA.HasRows Then
                REA.Read()
                Divisa.Local.id = REA.GetInt32("cod")
                Divisa.Local.nombre = REA.GetString("des")
                Divisa.Local.simbolo = REA.GetString("sim")
                Divisa.Local.factor = CDbl(REA.GetString("factor"))

            End If
            REA = Nothing

            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(Replace(strSQL, "{tipo}", EXTERNA), CON)
            REA = COM.ExecuteReader
            If REA.HasRows Then
                REA.Read()
                Divisa.Externa.id = REA.GetInt32("cod")
                Divisa.Externa.nombre = REA.GetString("des")
                Divisa.Externa.simbolo = REA.GetString("sim")
                Divisa.Externa.factor = CDbl(REA.GetString("factor"))
            End If
            REA = Nothing
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub Reset()
        CeldaClave.Text = ""
        CeldaUsuario.Text = ""
        CeldaUsuario.Focus()
    End Sub

#End Region

    Private Sub frmSSesion_Load(sender As Object, e As EventArgs) Handles Me.Load

        MyCnn.ObtenerCredencialesXml()

        If cSesion.debug = True Then
            If MsgBox("¿Modo de depuración (Local)?", MsgBoxStyle.YesNo) = vbYes Then
                strConexion = MyCnn.StringConexion("1")
                EtiquetaConexion.Text = Conexion.local.Modo
                strModo = Conexion.local.Modo
            Else
                strConexion = MyCnn.StringConexion("2")
                EtiquetaConexion.Text = Conexion.servidor.Modo
                strModo = Conexion.servidor.Modo
            End If
        ElseIf Conexion.servidor.Def = 1 Then
            strConexion = MyCnn.StringConexion("2")
            EtiquetaConexion.Text = Conexion.servidor.Modo
            strModo = Conexion.servidor.Modo
        ElseIf Conexion.wan1.Def = 1 Then
            strConexion = MyCnn.StringConexion("3")
            EtiquetaConexion.Text = Conexion.wan1.Modo
            strModo = Conexion.wan1.Modo
        ElseIf Conexion.wan2.Def = 1 Then
            strConexion = MyCnn.StringConexion("4")
            EtiquetaConexion.Text = Conexion.wan2.Modo
            strModo = Conexion.wan2.Modo
        End If

        If MyCnn.ProbarConexiones() = True Then
            EtiquetaConexion.ForeColor = Color.Black
            cSesion.ComprobarActualizacion()
            cSesion.ComprobarConfiguracion()
        Else
            EtiquetaConexion.ForeColor = Color.Red
        End If
        Sistema.Version = My.Application.Info.Version.ToString
        Sesion.Estacion = cFunciones.ObtenerIPoEquipo(clsFunciones.IpEquipo.equipo)
        Sesion.IP = cFunciones.ObtenerIPoEquipo(clsFunciones.IpEquipo.ip)
        EtiquetaVersion.Text = Sistema.Version

    End Sub

    Private Sub botonAceptar_Click(sender As Object, e As EventArgs) Handles BotonAceptar.Click
        ' PanelNewPass.Location = New Point(120, 1)
        ' PanelNewPass.Dock = DockStyle.Fill
        If CeldaUsuario.Text.Length > 0 And CeldaClave.Text.Length > 0 Then
            If cSesion.ComprobarUsuario(Trim(cFunciones.MyStr(CeldaUsuario.Text)), Trim(CeldaClave.Text)) = True Then
                Empresas.Visible = True
                Panel2.Visible = False
                Empresas.Dock = DockStyle.Fill
                cSesion.CargarEmpresas(CeldaUsuario.Text, Empresas)
                Empresas.Focus()
            Else
                reset()
            End If
        Else
            MsgBox("Ingrese usuario o contraseña")
        End If

    End Sub

    Private Sub CeldaUsuario_KeyDown(sender As Object, e As KeyEventArgs) Handles CeldaUsuario.KeyDown
        If e.KeyCode = Keys.Enter Then
            SendKeys.Send(vbTab)
            e.Handled = True
            e.SuppressKeyPress = True
        End If
    End Sub

    Private Sub CeldaClave_KeyDown(sender As Object, e As KeyEventArgs) Handles CeldaClave.KeyDown
        Try
            If e.KeyCode = Keys.Enter Or e.KeyCode = Keys.Tab Then
                BotonAceptar.PerformClick()
                e.Handled = True
                e.SuppressKeyPress = True
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Function BuscarBase() As String
        Dim strSQL As String = STR_VACIO
        Dim CON As MySqlConnection
        Dim COM As MySqlCommand
        Dim ValorBase As String = STR_VACIO

        strSQL = "select cat_sist Sistema " & _
                 "FROM Catalogos " & _
                 "where cat_clase = 'Datos' and cat_clave = 'Contabilidad' "

        CON = New MySqlConnection(strConexion)
        CON.Open()

        COM = New MySqlCommand(strSQL, CON)
        ValorBase = COM.ExecuteScalar()

        Return ValorBase
    End Function

    Private Sub Empresas_DoubleClick(sender As Object, e As EventArgs) Handles Empresas.DoubleClick
        Dim itm As New ListViewItem
        If Empresas.SelectedItems.Count = 0 Then Exit Sub
        itm = Empresas.SelectedItems(0)
        Sesion.IdEmpresa = CInt(itm.SubItems(0).Text)
        Sesion.Empresa = itm.SubItems(1).Text
        Sesion.BaseConta = cFunciones.ContaEmpresa
        cSesion.EscribirSesion()
        BaseConta = cFunciones.ContaEmpresa
        CargarDivisas()
        Fprincipal.Show()
        Me.Hide()
    End Sub

    Private Sub Empresas_KeyDown(sender As Object, e As KeyEventArgs) Handles Empresas.KeyDown
        If e.KeyCode = Keys.Enter Then
            Dim itm As New ListViewItem
            If Empresas.SelectedItems.Count = 0 Then Exit Sub
            itm = Empresas.SelectedItems(0)
            Sesion.IdEmpresa = CInt(itm.SubItems(0).Text)
            Sesion.Empresa = itm.SubItems(1).Text
            Sesion.BaseConta = cFunciones.ContaEmpresa
            cSesion.EscribirSesion()
            CargarDivisas()
            Fprincipal.Show()
            Me.Hide()
            e.Handled = True
            e.SuppressKeyPress = True
        End If

    End Sub

    Private Sub IconoConexion_DoubleClick(sender As Object, e As EventArgs) Handles IconoConexion.DoubleClick
        Dim frm As New frmOption
        Try
            frm.Titulo = "Opciones de conexión"
            frm.Mensaje = "Seleccione una conexión"
            frm.Opciones = Conexion.servidor.Modo & "|" & Conexion.wan1.Modo & "|" & Conexion.wan2.Modo
            frm.ShowDialog(Me)
            If frm.DialogResult = Windows.Forms.DialogResult.OK Then
                Select Case frm.Seleccion
                    Case 0
                        strConexion = MyCnn.StringConexion("2")
                        EtiquetaConexion.Text = Conexion.servidor.Modo
                        strModo = Conexion.servidor.Modo
                    Case 1
                        strConexion = MyCnn.StringConexion("3")
                        EtiquetaConexion.Text = Conexion.wan1.Modo
                        strModo = Conexion.wan1.Modo
                    Case 2
                        strConexion = MyCnn.StringConexion("4")
                        EtiquetaConexion.Text = Conexion.wan2.Modo
                        strModo = Conexion.wan2.Modo
                End Select
            End If

            If MyCnn.ProbarConexiones() = True Then
                EtiquetaConexion.ForeColor = Color.Black
                cSesion.ComprobarActualizacion()
            Else
                EtiquetaConexion.ForeColor = Color.Red
                MsgBox("Imposible conectar con el servidor", MsgBoxStyle.Critical)
            End If

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub Empresas_SelectedIndexChanged(sender As Object, e As EventArgs) Handles Empresas.SelectedIndexChanged
        Dim itm As New ListViewItem
        If Empresas.SelectedItems.Count = 0 Then Exit Sub
        itm = Empresas.SelectedItems(0)

        CuadroLogo.Image = ImageList1.Images(itm.SubItems(0).Text)
        CuadroLogo.SizeMode = PictureBoxSizeMode.StretchImage
    End Sub

End Class
