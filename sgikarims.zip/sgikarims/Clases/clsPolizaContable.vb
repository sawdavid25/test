﻿Public Class clsPolizaContable

#Region "Miembros"

    Public intTipo As String = STR_VACIO
    Public intCiclo As String = STR_VACIO
    Public intNumero As String = STR_VACIO
    Public intModo As String = STR_VACIO
    Public intPoliza As String = STR_VACIO

#End Region

#Region "Propiedades"

    Public Property Tipo As Integer
        Get
            Return intTipo
        End Get
        Set(value As Integer)
            intTipo = value
        End Set
    End Property

    Public Property Ciclo As Integer
        Get
            Return intCiclo
        End Get
        Set(value As Integer)
            intCiclo = value
        End Set
    End Property

    Public Property Numero As Integer
        Get
            Return intNumero
        End Get
        Set(value As Integer)
            intNumero = value
        End Set
    End Property

    Public Property Modo As Integer
        Get
            Return intModo
        End Get
        Set(value As Integer)
            intModo = value
        End Set
    End Property

    Public Property Poliza As Integer
        Get
            Return intPoliza
        End Get
        Set(value As Integer)
            intPoliza = value
        End Set
    End Property

#End Region

    Public Function PeridoValidar() As Integer
        Dim strSQL As String = STR_VACIO
        Dim COM As MySqlCommand
        Dim CON As MySqlConnection
        Dim Valor As Integer = 0



        strSQL = "SELECT A.valor " & _
                 "FROM {conta}.parametros_empresa A " & _
                 "LEFT JOIN {conta}.ejercicio_empresa ej on ej.empresa = A.empresa AND ej.ejercicio = A.valor  " & _
                 "WHERE A.empresa = {empresa} AND A.parametro = 3 AND ej.estado = 'A' "

        strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
        strSQL = Replace(strSQL, "{conta}", cFunciones.ContaEmpresa)


        CON = New MySqlConnection(strConexion)
        CON.Open()

        Try
            COM = New MySqlCommand(strSQL, CON)
            Valor = COM.ExecuteScalar

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try

        Return Valor

    End Function



    'Muestra la póliza contable del documento indicado
    Public Function MostrarPolizaContable()
        Dim COM As MySqlCommand
        'Dim REA As MySqlDataReader
        Dim strsql As String = STR_VACIO
        Dim frm As frmNPolizasContables
        Dim st As Long

        'Verificar si posee poliza
        strsql = " SELECT poliza"
        strsql &= "  FROM {base}.polizas"
        strsql &= "   WHERE empresa = {empresa} AND ref_tipo = {tipo} AND ref_ciclo = {ciclo} AND ref_numero = {numero} "
        If intModo = STR_VACIO Then
        Else
            strsql &= " AND modo = {modo}"
        End If
        strsql &= "     LIMIT 1 "

        strsql = Replace(strsql, "{empresa}", Sesion.IdEmpresa)
        strsql = Replace(strsql, "{tipo}", intTipo)
        strsql = Replace(strsql, "{ciclo}", intCiclo)
        strsql = Replace(strsql, "{numero}", intnumero)
        strsql = Replace(strsql, "{modo}", intModo)
        strsql = Replace(strsql, "{base}", cFunciones.ContaEmpresa)

        MyCnn.CONECTAR = strConexion
        COM = New MySqlCommand(strsql, CON)
        st = COM.ExecuteScalar
        If st > 0 Then
            frm = New frmNPolizasContables
            'frm.Existe = True
            frm.Poliza = st
            frm.Tipo = intTipo
            frm.Ciclo = intCiclo
            frm.Numero = intNumero
            frm.Modo = intModo
            frm.Show()
            frm.CargarDetalle()
        Else
            MsgBox("It Does Not Have Accounting Policy", vbInformation, "Notice")
        End If

        Return strsql
    End Function

End Class
