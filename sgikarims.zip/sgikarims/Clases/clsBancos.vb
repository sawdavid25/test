﻿Public Class clsBancos
    'Variables de moneda
    Private intCurLoc As Integer = INT_CERO
    Private intCurExt As Integer = INT_CERO

    'Variables de documentos
    Private intDocCompra As Integer = INT_CERO
    Private intDocVenta As Integer = INT_CERO
    Private intDocDebito As Integer = INT_CERO
    Private intDocCobro As Integer = INT_CERO
    Private intDocRetencion As Integer = INT_CERO
    Private intDocLiquidacion As Integer = INT_CERO

    'Descripcion de items de cada grupo 
    Private strGrupos() As String = New String(6) {"Payment,Income tax (ISR),Advance payment,Expenses",
                                                   "Reconciliation,Opening funds,Advance of travel expenses,Closure",
                                                   "Collection",
                                                   "Salary,Annual bonus (aguinaldo),Half year bonus (bono 14),Advance/Loan,Refund (advance/loan),Liquidation,Bonus/Incentive,Extra bonus,Vacation,Compensation,Income tax refund (ISR)",
                                                   "Payroll",
                                                   "Deposit in transit,Expenses",
                                                   "VAT to pay (IVA),Employees income tax (ISR),Income tax retentions (ISR),Monthly income tax (ISR),Income tax retentions (IVA)"}

    'Documentos de catalogo
    Public Const DOC_DEPOSITO As String = "Doc_BDeposit"
    Public Const DOC_CHEQUE As String = "Doc_BCheque"
    Public Const DOC_DEBITO As String = "Doc_BNDebito"
    Public Const DOC_CREDITO As String = "Doc_BNCredit"

    Public Const DOC_RECIBO As String = "Doc_CRecibo"
    Public Const DOC_COMPRA As String = "Doc_PFactura"
    Public Const DOC_ANTICIPO As String = "Doc_Anticipo"
    Public Const DOC_RETENCION As String = "Doc_RISR"
    Public Const DOC_FACTURA As String = "Doc_CFactura"
    Public Const DOC_NOTA_DEBITO As String = "Doc_CNDebito"
    Public Const DOC_COBRO As String = "Doc_FCobro"
    Public Const DOC_LIQUIDACION As String = "Doc_RLiq"

    'Documento bancario
    Public Const BCO_DEPOSITO As String = "Doc_BcosDep"
    Public Const BCO_CHEQUE As String = "Doc_BcosChq"
    Public Const BCO_CREDITO As String = "Doc_BcosNC"
    Public Const BCO_DEBITO As String = "Doc_BcosND"
    Public Const BCO_TRANSFER As String = "Doc_BcosTrn"

    'Otras constantes
    Public Const ES_ANULADO As Integer = 3
    Public Const FMT_DATE As String = FORMATO_MYSQL

    Public Property IdDeposito As Integer = 0
    Public Property IdCheque As Integer = 0
    Public Property IdCredito As Integer = 0
    Public Property IdDebito As Integer = 0

    Public Property IdRecibo As Integer = 0
    Public Property IdAnticipo As Integer = 0


    Public Structure DatoRelacion
        Dim Tipo As Integer
        Dim Ciclo As Integer
        Dim Numero As Integer
        Dim Nota As String
    End Structure

    Public Structure DatoLista
        Dim Codigo As String
        Dim Texto As String
        Dim Texto2 As String
        Dim Monto As Double
    End Structure

    'Grupo de transaccion para el documento
    Public Enum BancoGrupo As Integer
        Proveedor = 0
        Caja = 1
        Cliente = 2
        Empleado = 3
        Planilla = 4
        Transferencia = 5
        Impuestos = 6
    End Enum

    '0 - Proveedor
    Public Enum EnumProveedor
        Pago = 0
        Impuesto = 1
        Anticipo = 2
        Gasto = 3
        Pendiente = 4
    End Enum

    '1 - Caja
    Public Enum EnumCaja
        Liquidacion = 0
        Apertura = 1
        Anticipo = 2
        Cierre = 3
    End Enum

    '2 - Cliente
    Public Enum EnumCliente
        Cobro = 0
        Descuento = 1
    End Enum

    '3 - Empleado
    Public Enum EnumEmpleado
        Salario = vbEmpty
        Aguinaldo = 1
        Bono14 = 2
        Anticipo = 3
        Devolucion = 4
        Liquidacion = 5
        Bonificacion = 6
        BonoExtra = 7
        Vacaciones = 8
        Indemnizacion = 9
        DevolucionISR = 10
    End Enum

    '5 - Transferencia
    Public Enum EnumTransferencia
        Depositos = 0
        Gasto = 1
    End Enum

    '6 - Impuestos
    Public Enum EnumImpuestos
        IVAPagar = vbEmpty
        ISRAsalariado = 1
        ISRRetenciones = 2
        ISRMensual = 3
        IVARetenciones = 4
    End Enum

    'Limpia una cadena de texta para usarse con MySQL
    Public Function Text(ByVal Data As String, Optional Quoted As Boolean = True) As String
        Dim strData As String = If(Data, String.Empty).Trim

        'strData = Data.Trim
        strData = strData.Replace("\", "\\")
        strData = strData.Replace(vbNullChar, "\0")
        strData = strData.Replace("'", "\'")
        strData = strData.Replace("""", "\""")
        strData = strData.Replace(vbBack, "\b")
        strData = strData.Replace(vbLf, "\n")
        strData = strData.Replace(vbCr, "\r")
        strData = strData.Replace(vbTab, "\t")
        If Quoted Then
            strData = Chr(39) & strData & Chr(39)
        End If

        Return strData
    End Function

    'Devuelve la descripcion de los items para un grupo de transacciones
    Public Function ItemsDeGrupo(ByVal Grupo As Integer) As String()
        Dim Items() As String = New String() {}
        Items = strGrupos(Grupo).Split(","c)
        Return Items
    End Function

#Region "Instruciones SQL"

    'SQL para listar las cuentas bancarias
    Public Function SQLListaCuentas() As String
        Dim strSQL As String = STR_VACIO
        strSQL = " SELECT c.BCta_Num NO, ccc.cat_desc Bank, c.BCta_Num_Cue Account_Number, c.BCta_Nom_Cue Account_Name, c.BCta_Des_Cue Description, cc.cat_desc Currency "
        strSQL &= "     FROM Permisos p  "
        strSQL &= "         LEFT JOIN CtasBcos c ON c.BCta_Sis_Emp = p.pms_empresa AND c.BCta_Num = p.pms_id  "
        strSQL &= "             LEFT JOIN Catalogos cc ON cc.cat_num = c.BCta_Mon "
        strSQL &= "                 LEFT JOIN Catalogos ccc ON ccc.cat_num = c.BCta_Cod_Ban  "
        strSQL &= "                     WHERE c.BCta_Sis_Emp = {empresa} AND c.BCta_Tipo = 0 AND p.pms_modulo = 94 AND p.pms_usuario = '{usuario}' "
        strSQL &= "                         GROUP By p.pms_id "
        strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
        strSQL = Replace(strSQL, "{usuario}", Sesion.Usuario)
        Return strSQL
    End Function

    'SQL para leer el registro de la cuenta bancaria
    Public Function SQLCuenta(ByVal ID As Integer) As String
        Dim strSQL As String = " SELECT BCta_Tip_Cue tipo, BCta_Num codigo, BCta_Cod_Ban id_banco, BCta_Cnt_Ban contacto, BCta_Num_Cue numero, BCta_Nom_Cue nombre, BCta_Des_Cue descripcion, " &
                               "        BCta_Mon id_moneda, BCta_Sob_Aut sobregiro, BCta_Sob_Plz plazo, BCta_Cuenta cuenta, IFNULL(cm.cat_clave,'') moneda, IFNULL(cm.cat_desc,'') divisa, " &
                               "        IFNULL(cb.cat_desc,'') banco, " &
                               "        IFNULL((SELECT cc.cat_desc FROM Catalogos cc WHERE cc.cat_clase='Cheques' AND cc.cat_clave='Max_Num' AND cc.cat_sist=BCta_Num LIMIT 1),0) cheque " &
                               " FROM CtasBcos c " &
                               "      LEFT JOIN Catalogos cb ON cb.cat_clase='Bancos' AND cb.cat_num=BCta_Cod_Ban" &
                               "      LEFT JOIN Catalogos cm ON cm.cat_clase='Monedas' AND cm.cat_num=BCta_Mon" &
                               " WHERE c.BCta_Sis_Emp =  {empresa} and c.BCta_Tipo = 0 AND c.BCta_Num = {id} " &
                               " LIMIT 1"
        strSQL = strSQL.Replace("{empresa}", Sesion.IdEmpresa)
        strSQL = strSQL.Replace("{id}", ID)
        Return strSQL
    End Function

    'SQL para obtener el saldo de una cuenta bancaria
    Public Function SQLSaldoDeCuenta(ByVal ID As Integer, Fecha As Date, Optional Todo As Boolean = False)
        Dim strSQL As String
        Dim strClase As String
        Dim intEmpresa As Integer = Sesion.IdEmpresa

        'Tipo de cuenta bancaria Local / Exterior
        strSQL = " SELECT IF(b.BCta_Mon = CAST(a.cat_clave AS SIGNED),'Loc','Ext') Clase  " &
            " FROM Catalogos a " &
            "      LEFT JOIN CtasBcos b ON b.BCta_Sis_Emp = {empresa} AND b.BCta_Num = {id}" &
            " WHERE a.cat_sist='CUR_LOC'"
        strSQL = Replace(strSQL, "{empresa}", intEmpresa)
        strSQL = Replace(strSQL, "{id}", ID)
        MyCnn.CONECTAR = strConexion
        Dim cmd As New MySqlCommand(strSQL, CON)
        strClase = cmd.ExecuteScalar.ToString
        If String.IsNullOrEmpty(strClase) Then
            MessageBox.Show("Could not find CUR_LOC setting", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning)
        Else
            strSQL = String.Empty
            strSQL = strSQL & " SELECT COALESCE(SUM(m.BMov_Abno_{clase})-SUM(m.BMov_Crgo_{clase}),0) Saldo"
            strSQL = strSQL & " FROM MvtosBcos m"
            strSQL = strSQL & " WHERE BMov_Sis_Emp = {empresa} AND BMov_Cta = {id} {fecha}"
            If Todo Then
                strSQL = Replace(strSQL, "{fecha}", String.Empty)
            Else
                strSQL = Replace(strSQL, "{fecha}", " AND (BMov_Fec < {fecha})")
            End If

            strSQL = Replace(strSQL, "{empresa}", intEmpresa)
            strSQL = Replace(strSQL, "{id}", ID)
            strSQL = Replace(strSQL, "{fecha}", Text(Fecha.ToString(FORMATO_MYSQL)))
            strSQL = Replace(strSQL, "{clase}", strClase)
        End If

        SQLSaldoDeCuenta = strSQL
    End Function

    'SQL para contar la cantidad de movimientos de una cuenta bancaria
    Public Function SQLCantidadMovimientos(ByVal ID As Integer) As String
        Dim strSQL As String = "SELECT COUNT(1) FROM MvtosBcos m WHERE m.BMov_Sis_Emp = {empresa} AND m.BMov_Cta = {id}".Replace("{empresa}", Sesion.IdEmpresa).Replace("{id}", ID)
        Return strSQL
    End Function

    'SQL para listar movimientos en una cuenta bancaria
    Public Function SQLMovimiento(ByVal ID As Integer, ByVal Clase As String, ByVal TipoDocumento As Integer, ByVal Desde As Date, ByVal Hasta As Date) As String
        Dim strSQL As String

        strSQL = " SELECT m.BMov_Doc_Cat Tipo, m.BMov_Doc_Ano Ciclo, m.BMov_Doc_Num Numero, m.BMov_Fec Fecha, lt.cat_desc Documento, m.BMov_Num_Doc Referencia, " &
                 "        IF((m.BMov_Abno_{clase} = 0) AND (m.BMov_Crgo_{clase} = 0),'- ANULADO -',m.BMov_Beneficiario) Dato, (m.BMov_Abno_{clase}) Credito, (m.BMov_Crgo_{clase}) Debito, IFNULL(m.BMov_Concepto,'') Concepto, " &
                 "        h.HDoc_DR1_Cat Categoria, h.HDoc_DR2_Cat Sub, IFNULL({poliza},0) Poliza, {presupuesto} Presupuesto, IFNULL(h.HDoc_Doc_Status,-1) Estado, {costos} Costos, " &
                 "        IFNULL(h.HDoc_DR2_Emp,0) Secreto " &
                 " FROM MvtosBcos m" &
                 "      LEFT JOIN Catalogos lt ON lt.cat_clase = 'DocsBcos' AND lt.cat_num = m.BMov_Cat_Doc" &
                 "      LEFT JOIN Dcmtos_HDR h ON h.HDoc_Sis_Emp = m.BMov_Sis_Emp AND h.HDoc_Doc_Cat = m.BMov_Doc_Cat AND h.HDoc_Doc_Ano = m.BMov_Doc_Ano AND h.HDoc_Doc_Num = m.BMov_Doc_Num "

        If cFunciones.ContaActiva Then
            strSQL = strSQL.Replace("{poliza}", "c.poliza")
            strSQL = strSQL.Replace("{presupuesto}", "IFNULL((SELECT 1 FROM {conta}.detalle_presupuesto d WHERE d.empresa=m.BMov_Sis_Emp AND d.categoria=m.BMov_Doc_Cat AND d.ano=m.BMov_Doc_Ano AND d.numero=m.BMov_Doc_Num LIMIT 1),0)")
            strSQL = strSQL.Replace("{costos}", "IFNULL((SELECT GROUP_CONCAT(dp.centro_costos SEPARATOR '') AS C_COSTOS FROM {conta}.detalle_polizas dp WHERE dp.poliza =c.poliza and dp.empresa = c.empresa and dp.ejercicio = c.ejercicio  GROUP BY dp.poliza),'0')")

            strSQL &= " LEFT JOIN {conta}.polizas c ON c.empresa = h.HDoc_Sis_Emp AND c.ref_tipo = h.HDoc_Doc_Cat AND c.ref_ciclo = h.HDoc_Doc_Ano AND c.ref_numero = h.HDoc_Doc_Num "
        End If

        strSQL &= " WHERE m.BMov_Sis_Emp = {empresa} AND m.BMov_Cta = {id} AND (m.BMov_Fec BETWEEN {inicio} AND {fin}) {tipo}" &
                  " ORDER BY m.BMov_Fec, m.BMov_Doc_Cat DESC, m.BMov_Num_Doc"

        strSQL = strSQL.Replace("{conta}", Sesion.BaseConta)
        strSQL = strSQL.Replace("{poliza}", "NULL")
        strSQL = strSQL.Replace("{presupuesto}", INT_CERO)
        strSQL = strSQL.Replace("{costos}", INT_CERO)

        strSQL = strSQL.Replace("{empresa}", Sesion.IdEmpresa)
        strSQL = strSQL.Replace("{id}", ID)
        strSQL = strSQL.Replace("{inicio}", Text(Desde.ToString(FORMATO_MYSQL)))
        strSQL = strSQL.Replace("{fin}", Text(Hasta.ToString(FORMATO_MYSQL)))
        If TipoDocumento.Equals(INT_CERO) Then
            strSQL = strSQL.Replace("{tipo}", String.Empty)
        Else : strSQL = strSQL.Replace("{tipo}", " AND m.BMov_Cat_Doc=" & TipoDocumento)
        End If
        strSQL = strSQL.Replace("{clase}", Clase)

        Return strSQL
    End Function

    'SQL para listar documentos en reserva
    Public Function SQLReserva(ByVal ID As Integer) As String
        Dim intEnReserva As Integer = INT_CERO
        Dim strSQL As String = String.Empty

        strSQL = " SELECT e.HDoc_DR1_Num Deposit, d.DDoc_RF1_Fec 'Date', d.DDoc_RF1_Txt Drawer, d.DDoc_RF1_Cod Reference, d.DDoc_RF1_Dbl Amount" &
                 " FROM Dcmtos_HDR e" &
                 "      LEFT JOIN Dcmtos_DTL d ON d.DDoc_Sis_Emp = e.HDoc_Sis_Emp AND d.DDoc_Doc_Cat = e.HDoc_Doc_Cat AND d.DDoc_Doc_Ano = e.HDoc_Doc_Ano AND d.DDoc_Doc_Num = e.HDoc_Doc_Num" &
                 " WHERE e.HDoc_Sis_Emp = {empresa} AND e.HDoc_Doc_Cat = {tipo} AND e.HDoc_RF1_Num = {id} AND d.DDoc_RF1_Num = {estado}" &
                 " ORDER BY d.DDoc_RF1_Fec, d.DDoc_RF1_Txt, d.DDoc_RF1_Cod"
        strSQL = strSQL.Replace("{empresa}", Sesion.IdEmpresa)
        strSQL = strSQL.Replace("{tipo}", IdDeposito)
        strSQL = strSQL.Replace("{id}", ID)
        strSQL = strSQL.Replace("{estado}", intEnReserva)

        Return strSQL
    End Function

    'SQL para obtener la suma total de documentos en reserva
    Public Function SQLTotalEnReserva(ByVal ID As Integer) As String
        Dim strSQL As String
        Dim intEnReserva As Integer = INT_CERO

        strSQL = " SELECT SUM(d.DDoc_RF1_Dbl) Reserva" &
                 " FROM Dcmtos_HDR e" &
                 "      LEFT JOIN Dcmtos_DTL d ON d.DDoc_Sis_Emp = e.HDoc_Sis_Emp AND d.DDoc_Doc_Cat = e.HDoc_Doc_Cat AND d.DDoc_Doc_Ano = e.HDoc_Doc_Ano AND d.DDoc_Doc_Num = e.HDoc_Doc_Num" &
                 " WHERE e.HDoc_Sis_Emp = {empresa} AND e.HDoc_Doc_Cat = {tipo} AND e.HDoc_RF1_Num = {id} AND d.DDoc_RF1_Num = {estado}"

        strSQL = strSQL.Replace("{empresa}", Sesion.IdEmpresa)
        strSQL = strSQL.Replace("{id}", ID)
        strSQL = Replace(strSQL, "{tipo}", IdDeposito)
        strSQL = Replace(strSQL, "{estado}", intEnReserva)

        Return strSQL
    End Function

    'SQL para saber si la moneda es Local o Exterior
    Public Function SQLTipoDeMoneda(ByVal ID As Integer) As String
        Dim strSQL As String = " SELECT IF({moneda} = CAST(a.cat_clave AS SIGNED),'Loc','Ext') Clase  " &
                               " FROM Catalogos a " &
                               " WHERE a.cat_sist='CUR_LOC'"
        Return strSQL.Replace("{moneda}", ID)
    End Function

    'SQL para insertar una cuenta bancaria
    Public Function SQLCrearCuenta() As String
        Dim strSQL As String = "INSERT INTO CtasBcos (BCta_Sis_Emp, BCta_Tipo, BCta_Num, BCta_Cod_Ban, BCta_Cnt_Ban, BCta_Num_Cue, BCta_Nom_Cue, BCta_Des_Cue, BCta_Tip_Cue, BCta_Sob_Aut, BCta_Sob_Plz, BCta_Mon, BCta_Cuenta, BCta_Status) VALUES (@empresa, @tipo, @id, @id_banco, @contacto, @numero, @nombre, @descripcion, @tipo_cuenta, @sobregiro, @plazo, @moneda, @contable, 1)"
        If Sesion.IdEmpresa = 18 Then
            strSQL &= ";INSERT INTO PDM.CtasBcos (BCta_Sis_Emp, BCta_Tipo, BCta_Num, BCta_Cod_Ban, BCta_Cnt_Ban, BCta_Num_Cue, BCta_Nom_Cue, BCta_Des_Cue, BCta_Tip_Cue, BCta_Sob_Aut, BCta_Sob_Plz, BCta_Mon, BCta_Cuenta, BCta_Status) VALUES (@empresa, @tipo, @id, @id_banco, @contacto, @numero, @nombre, @descripcion, @tipo_cuenta, @sobregiro, @plazo, @moneda, @contable, 1)"
        End If
        Return strSQL
    End Function

    'SQL para borrar una cuenta bancaria
    Public Function SQLBorrarCuenta(ByVal ID As Integer) As String
        Dim strSQL As String = "DELETE FROM CtasBcos WHERE BCta_Sis_Emp={empresa} AND BCta_Num={id}".Replace("{empresa}", Sesion.IdEmpresa).Replace("{id}", ID)
        If Sesion.IdEmpresa = 18 Then
            strSQL &= ";DELETE FROM PDM.CtasBcos WHERE BCta_Sis_Emp={empresa} AND BCta_Num={id}".Replace("{empresa}", Sesion.IdEmpresa).Replace("{id}", ID)
        End If
        Return strSQL
    End Function

    'SQL para actualizar una cuenta bancaria
    Public Function SQLActualizarCuenta() As String
        Dim strSQL As String = "UPDATE CtasBcos SET BCta_Cod_Ban=@id_banco, BCta_Cnt_Ban=@contacto, BCta_Num_Cue=@numero, BCta_Nom_Cue=@nombre, BCta_Des_Cue=@descripcion, BCta_Tip_Cue=@tipo_cuenta, BCta_Sob_Aut=@sobregiro, BCta_Sob_Plz=@plazo, BCta_Mon=@moneda, BCta_Cuenta=@contable WHERE BCta_Sis_Emp=@empresa AND BCta_Num=@id"
        If Sesion.IdEmpresa = 18 Then
            strSQL &= ";UPDATE PDM.CtasBcos SET BCta_Cod_Ban=@id_banco, BCta_Cnt_Ban=@contacto, BCta_Num_Cue=@numero, BCta_Nom_Cue=@nombre, BCta_Des_Cue=@descripcion, BCta_Tip_Cue=@tipo_cuenta, BCta_Sob_Aut=@sobregiro, BCta_Sob_Plz=@plazo, BCta_Mon=@moneda, BCta_Cuenta=@contable WHERE BCta_Sis_Emp=@empresa AND BCta_Num=@id"
        End If
        Return strSQL
    End Function

    'SQL para seleccionar la clase segun el tipo de documento
    Public Function SQLGruposDeDocumento(ByVal Tipo As Integer) As String
        Dim strSQL As String = String.Empty

        If IdDeposito.Equals(INT_CERO) Then
            CargarTipos()
        End If

        Select Case Tipo
            Case IdDeposito : strSQL = FormarSQLParaGrupo(New String() {"1,Provider", "2,Petty cash", "3,Customer", "4,Employee", "6,Bank transfer"})
            Case IdCredito : strSQL = FormarSQLParaGrupo(New String() {"3,Customer", "6,Bank Transfer"})
            Case IdCheque : strSQL = FormarSQLParaGrupo(New String() {"1,Provider", "2,Petty cash", "4,Employee", "6,Bank transfer"})
            Case IdDebito : strSQL = FormarSQLParaGrupo(New String() {"1,Provider", "2,Petty cash", "4,Employee", "5,Payroll", "6,Bank transfer", "7,Taxes"})
        End Select
        Return strSQL
    End Function

    'Devuelve una consulta SQL de UNION para los items de un grupo
    Public Function FormarSQLParaGrupo(ByVal Items As String()) As String
        Dim strSQL As String = String.Empty
        Dim cmp As String()
        For Each s As String In Items
            If Not strSQL.Equals(String.Empty) Then
                strSQL &= " UNION "
            End If
            cmp = s.Split(",")
            If cmp.Length = 2 Then
                If cmp.Length = 2 Then
                    s = cmp(0) & " ID, " & Text(cmp(1)) & " Description"
                    strSQL &= "(SELECT {campos})".Replace("{campos}", s)
                End If
            Else : strSQL &= "(SELECT 0 ID, 'Unknown' Description)"
            End If
        Next
        strSQL = Strings.Replace("({sql}) x", "{sql}", strSQL)
        Return strSQL
    End Function

    'SQL para recuperar el grupo e item de un documento 
    Public Function SQLObtenerDocumentoGrupo(ByVal Tipo As Integer, ByVal Ciclo As Integer, ByVal Numero As Integer) As String
        Dim strSQL As String = "SELECT IFNULL(HDoc_DR1_Cat,0) Grupo, IFNULL(HDoc_DR2_Cat,0) Item FROM Dcmtos_HDR WHERE HDoc_Sis_Emp={empresa} AND HDoc_Doc_Cat={tipo} AND HDoc_Doc_Ano={año} AND HDoc_Doc_Num={numero}"
        strSQL = strSQL.Replace("{empresa}", Sesion.IdEmpresa)
        strSQL = strSQL.Replace("{tipo}", Tipo)
        strSQL = strSQL.Replace("{año}", Ciclo)
        strSQL = strSQL.Replace("{numero}", Numero)
        Return strSQL
    End Function

    'SQL para recuperar el listado de documentos de venta con saldo pendiente de pago (ref. cliente)
    Public Function SQLVentasPendientes(ByVal Tipo As Integer, ByVal Ciclo As Integer, ByVal Numero As Integer, ByVal ID As Integer, ByVal Moneda As Integer) As String
        'Const I_INTERES As Byte = 1
        'Const I_MORA As Byte = 4

        Dim logLocal As Boolean
        Dim strSQL As String

        'Determinar si la moneda de la cuenta es igual a la de la empresa
        If intCurLoc.Equals(INT_CERO) Then
            intCurLoc = ObtenerIdMonedaLocal()
        End If
        logLocal = (Moneda = Divisa.Local.id)

        'Asignar si no se tiene el ID de documentos (factura de venta, nota de debito y factura de cobro)
        If intDocVenta.Equals(INT_CERO) Then
            intDocVenta = ObtenerIdDeDocumento(DOC_FACTURA)
        End If
        If intDocDebito.Equals(INT_CERO) Then
            intDocDebito = ObtenerIdDeDocumento(DOC_NOTA_DEBITO)
        End If
        If intDocCobro.Equals(INT_CERO) Then
            intDocCobro = ObtenerIdDeDocumento(DOC_COBRO)
        End If

        'Recuperar documentos de venta con saldo pendiente de pago
        strSQL = " SELECT f.*, (SUM(COALESCE(c.ECta_Crgo_Ext,0)) - SUM(COALESCE(c.ECta_Abno_Ext,0))+complemento) Saldo " &
                 " FROM (SELECT e.HDoc_Sis_Emp Empresa, IFNULL(ld.cat_ext,'') Grupo, e.HDoc_Doc_Cat Tipo, e.HDoc_Emp_Cod Codigo, e.HDoc_Doc_Ano Ciclo, e.HDoc_Doc_Num Numero, e.HDoc_Doc_Fec Fecha, 
                    e.HDoc_Usuario Usuario, IFNULL(cm.cat_ext,'') letra, " &
                 "              CONCAT(CAST(e.HDoc_Doc_Num AS CHAR(10)),IFNULL(CONCAT(' ',e.HDoc_DR2_Num),'')) Documento, 
                    IF(IFNULL(e.HDoc_DR1_Num,'')='', CONCAT(CAST(e.HDoc_Doc_Num AS CHAR(10)),IFNULL(CONCAT(' ',e.HDoc_DR2_Num),'')), e.HDoc_DR1_Num) Referencia,
                    
                 /* IF(e.HDoc_Doc_Cat=296,e.HDoc_RF1_Dbl+ sum(ifnull(d.DDoc_RF4_Dbl,0)), SUM(IFNULL(d.DDoc_Prd_QTY * d.DDoc_Prd_NET,0))+ sum(ifnull(d.DDoc_RF4_Dbl,0))) Monto, 
                 SUM(IFNULL(d.DDoc_RF4_Dbl,0)) complemento, */

                  IF(e.HDoc_Doc_Cat=296,
 	                e.HDoc_RF1_Dbl+ if(e.HDoc_DR1_Cat=2, SUM(IFNULL(d.DDoc_RF4_Dbl,0)), SUM(IFNULL(dd.DDoc_RF4_Dbl,0))), 
	                SUM(IFNULL(d.DDoc_Prd_QTY * d.DDoc_Prd_NET,0))+ if(e.HDoc_DR1_Cat=2, SUM(IFNULL(d.DDoc_RF4_Dbl,0)), SUM(IFNULL(dd.DDoc_RF4_Dbl,0)))
	                ) Monto, 
 
                 IF(e.HDoc_DR1_Cat=2, SUM(IFNULL(d.DDoc_RF4_Dbl,0)), SUM(IFNULL(dd.DDoc_RF4_Dbl,0))) complemento, 

                 
                 e.HDoc_Doc_Mon Moneda, 
                    e.HDoc_Doc_TC Tasa, LPAD(e.HDoc_DR1_Dbl ,4,0) Secuencia, t.cli_cliente CxC {fact} {fel} " &
                 "       FROM Dcmtos_HDR e " &
                 "            LEFT JOIN Dcmtos_DTL d ON d.DDoc_Sis_Emp = e.HDoc_Sis_Emp AND d.DDoc_Doc_Cat = e.HDoc_Doc_Cat AND d.DDoc_Doc_Ano = e.HDoc_Doc_Ano AND d.DDoc_Doc_Num = e.HDoc_Doc_Num " &
                 "            LEFT JOIN Dcmtos_DTL_Pro p ON p.PDoc_Sis_Emp = e.HDoc_Sis_Emp AND p.PDoc_Chi_Cat = e.HDoc_Doc_Cat AND p.PDoc_Chi_Ano = e.HDoc_Doc_Ano AND p.PDoc_Chi_Num = e.HDoc_Doc_Num AND p.PDoc_Par_Cat = 48
                              LEFT JOIN Dcmtos_DTL_Pro pf ON pf.PDoc_Sis_Emp = p.PDoc_Sis_Emp AND pf.PDoc_Chi_Cat = p.PDoc_Par_Cat AND pf.PDoc_Chi_Ano = p.PDoc_Par_Ano AND pf.PDoc_Chi_Num = p.PDoc_Par_Num AND pf.PDoc_Par_Cat = 75
                              LEFT JOIN Dcmtos_HDR h ON h.HDoc_Sis_Emp = pf.PDoc_Sis_Emp AND h.HDoc_Doc_Cat = pf.PDoc_Par_Cat AND h.HDoc_Doc_Ano = pf.PDoc_Par_Ano AND h.HDoc_Doc_Num = pf.PDoc_Par_Num
                              LEFT JOIN Dcmtos_HDR hh ON hh.HDoc_Sis_Emp=e.HDoc_Sis_Emp and hh.HDoc_Pro_DCat=e.HDoc_Doc_Cat AND hh.HDoc_Pro_DAno=e.HDoc_Doc_Ano AND hh.HDoc_Pro_DNum=e.HDoc_Doc_Num  AND hh.HDoc_Doc_Cat=303
	                          LEFT JOIN Dcmtos_DTL dd ON dd.DDoc_Sis_Emp = hh.HDoc_Sis_Emp AND dd.DDoc_Doc_Cat = hh.HDoc_Doc_Cat AND dd.DDoc_Doc_Ano = hh.HDoc_Doc_Ano AND dd.DDoc_Doc_Num = hh.HDoc_Doc_Num AND dd.DDoc_Prd_Ref='comp'
	                          LEFT JOIN Clientes t ON t.cli_sisemp = h.HDoc_Sis_Emp AND t.cli_codigo = h.HDoc_DR1_Cat " &
                 "            LEFT JOIN Catalogos ld ON ld.cat_clase='Documentos' AND ld.cat_num=e.HDoc_Doc_Cat " &
                 "            LEFT JOIN Catalogos cm ON cm.cat_clase='Monedas' AND cm.cat_num=e.HDoc_Doc_Mon " &
                 "            LEFT JOIN Fel fe ON fe.Empresa = e.HDoc_Sis_Emp AND fe.Catalogo = e.HDoc_Doc_Cat AND fe.Anio = e.HDoc_Doc_Ano AND fe.Numero = e.HDoc_Doc_Num" &
                 "       WHERE e.HDoc_Sis_Emp = {empresa} AND (e.HDoc_Doc_Cat = {factura} OR e.HDoc_Doc_Cat={fc} OR (e.HDoc_Doc_Cat={nd} /* AND e.HDoc_DR1_Cat IN ({interes},{mora})*/ )) AND e.HDoc_Emp_Cod = {id} AND e.HDoc_Doc_Status = 1 " &
                 "       GROUP BY e.HDoc_Sis_Emp, e.HDoc_Doc_Cat, e.HDoc_Doc_Ano, e.HDoc_Doc_Num " &
                 "       ORDER BY e.HDoc_Doc_Fec, e.HDoc_Doc_Num) f " &
                 "      LEFT JOIN ECtaCte c ON c.ECta_Sis_Emp = f.Empresa AND c.ECta_Ref_Cat = f.Tipo AND c.ECta_Ref_Ano = f.Ciclo AND c.ECta_Ref_Num = f.Numero AND NOT(c.ECta_Doc_Cat = {tipo} AND c.ECta_Doc_Ano = {ciclo} AND c.ECta_Doc_Num = {numero}) " &
                 " GROUP BY f.Tipo,f.Ciclo, f.Numero " &
                 " HAVING (Saldo > 0.1) "

        'Si es local intercambiar campos de cargos y abonos
        If Sesion.IdEmpresa = 16 Then
        Else
            If logLocal Then

                strSQL = strSQL.Replace("Crgo_Ext", "Crgo_Loc")
                strSQL = strSQL.Replace("Abno_Ext", "Abno_Loc")
            End If
        End If


        'Sustituir parametros
        If Sesion.IdEmpresa = 16 Or Sesion.IdEmpresa = 14 Or Sesion.IdEmpresa = 11 Or Sesion.idGiro = 2 Then
            strSQL = strSQL.Replace("{fact}", ",e.HDoc_DR1_Dbl Numero2")
        Else
            strSQL = strSQL.Replace("{fact}", " ")
        End If
        If Sesion.IdEmpresa = 12 Or Sesion.IdEmpresa = 10 Then
            strSQL = strSQL.Replace("{fel}", ",fe.NumeroAutorizacion")
        Else
            strSQL = strSQL.Replace("{fel}", " ")
        End If
        strSQL = strSQL.Replace("{empresa}", Sesion.IdEmpresa)
        strSQL = strSQL.Replace("{factura}", intDocVenta)
        strSQL = strSQL.Replace("{nd}", intDocDebito)
        strSQL = strSQL.Replace("{fc}", intDocCobro)
        'strSQL = strSQL.Replace("{interes}", I_INTERES)
        'strSQL = strSQL.Replace("{mora}", I_MORA)
        strSQL = strSQL.Replace("{id}", ID)
        strSQL = strSQL.Replace("{tipo}", Tipo)
        strSQL = strSQL.Replace("{ciclo}", Ciclo)
        strSQL = strSQL.Replace("{numero}", Numero)

        Return strSQL
    End Function

    'SQL para recuperar el listado de documentos de compra con saldo pendiente de pago (ref. proveedor)
    Public Function SQLComprasPendientes(ByVal ID As Integer)
        Dim strSQL As String

        'Determinar si la moneda de la cuenta es igual a la de la empresa
        If intCurLoc.Equals(INT_CERO) Then
            intCurLoc = ObtenerIdMonedaLocal()
        End If

        'Asignar si no se tiene el ID de documentos (factura de compra)
        If intDocCompra.Equals(INT_CERO) Then
            intDocCompra = ObtenerIdDeDocumento(DOC_COMPRA)
        End If

        'Recuperar documentos de compra con saldo pendiente de pago

        strSQL = " SELECT s1.*, {saldo} saldo FROM" &
                 "       (SELECT ef.HDoc_Sis_Emp empresa, IFNULL(ld.cat_ext,'') grupo, ef.HDoc_Doc_Cat tipo, ef.HDoc_Doc_Ano ciclo, ef.HDoc_Doc_Num numero, ef.HDoc_Doc_Fec fecha, IF(ef.HDoc_Doc_Mon=" & intCurLoc & ",'LOCAL','EXTERNA') divisa, " &
                 "               CONCAT(ef.HDoc_DR1_Num,' ',ef.HDoc_DR2_Num) referencia, lm.cat_num id_moneda, lm.cat_clave moneda, IFNULL(lm.cat_ext,'') letra, ef.HDoc_Doc_TC tasa," &
                 "               ROUND((cf.ECta_Crgo_Loc + COALESCE(SUM(cd.ECta_Crgo_Loc),0)) - COALESCE(SUM(cd.ECta_Abno_Loc),0),2) saldo_loc," &
                 "               ROUND((cf.ECta_Crgo_Ext + COALESCE(SUM(cd.ECta_Crgo_Ext),0)) - COALESCE(SUM(cd.ECta_Abno_Ext),0),2) saldo_ext," &
                 "               ef.HDoc_RF1_Txt notas" &
                 "        FROM Dcmtos_HDR ef " &
                 "           INNER JOIN ECtaCte cf ON cf.ECta_Sis_Emp = ef.HDoc_Sis_Emp AND cf.ECta_Doc_Cat = ef.HDoc_Doc_Cat AND cf.ECta_Doc_Ano = ef.HDoc_Doc_Ano AND cf.ECta_Doc_Num = ef.HDoc_Doc_Num " &
                 "           LEFT  JOIN ECtaCte cd ON cd.ECta_Sis_Emp = ef.HDoc_Sis_Emp AND cd.ECta_Ref_Cat = ef.HDoc_Doc_Cat AND cd.ECta_Ref_Ano = ef.HDoc_Doc_Ano AND cd.ECta_Ref_Num = ef.HDoc_Doc_Num AND NOT(cd.ECta_Doc_Cat = ef.HDoc_Doc_Cat) " &
                 "           LEFT  JOIN Proveedores lc ON lc.pro_sisemp = ef.HDoc_Sis_Emp AND lc.pro_codigo = ef.HDoc_Emp_Cod " &
                 "           LEFT  JOIN Catalogos lm ON lm.cat_clase='Monedas' AND lm.cat_num=ef.HDoc_Doc_Mon " &
                 "           LEFT  JOIN Catalogos ld ON ld.cat_clase='Documentos' AND ld.cat_num=ef.HDoc_Doc_Cat " &
                 "        WHERE ef.HDoc_Sis_Emp = {empresa} AND ef.HDoc_Doc_Cat {tipo} AND ef.HDoc_Emp_Cod = {id} AND ef.HDoc_Doc_Status = 1" &
                 "        GROUP BY ef.HDoc_Doc_Ano,ef.HDoc_Doc_Cat, ef.HDoc_Doc_Num) s1 " &
                 " HAVING NOT(saldo=0) " &
                 " ORDER BY fecha, numero "

        'Sustituir parámetros
        If Sesion.IdEmpresa = 16 Then
            strSQL = strSQL.Replace("{saldo}", " ROUND(IF(divisa='LOCAL',saldo_ext,saldo_ext),2)")
        Else
            strSQL = strSQL.Replace("{saldo}", " ROUND(IF(divisa='LOCAL',saldo_loc,saldo_ext),2)")
        End If
        strSQL = strSQL.Replace("{empresa}", Sesion.IdEmpresa)
        strSQL = strSQL.Replace("{tipo}", "IN(209," & intDocCompra & ")")
        strSQL = strSQL.Replace("{id}", ID)

        Return strSQL
    End Function

    'SQL para recuperar el listado de retenciones de ISR pendientes de procesar
    Public Function SQLRetencionesPendientes()
        Dim strSQL As String

        'Asignar si no se tiene el ID de documento (retencion de ISR)
        If intDocRetencion.Equals(INT_CERO) Then
            intDocRetencion = ObtenerIdDeDocumento(DOC_RETENCION)
        End If

        strSQL = " SELECT h.HDoc_Doc_Cat Tipo, h.HDoc_Doc_Ano Ciclo, h.HDoc_Doc_Num Numero, h.HDoc_Doc_Fec Fecha, IFNULL(t.cat_ext,'') Grupo, c.cat_clave Moneda, c.cat_ext Letra, c.cat_num Id_Moneda, h.HDoc_Doc_TC Tasa, CONCAT(h.HDoc_DR1_Num, ' - Fact: ' , h.HDoc_DR2_Num) Referencia, h.HDoc_RF1_Dbl Saldo, h.HDoc_DR2_Num Notas, " &
                 "        h.HDoc_Pro_DAno Ref_Ciclo, h.HDoc_Pro_DCat Ref_Tipo, h.HDoc_Pro_DNum Ref_Numero " &
                 " FROM Dcmtos_HDR h " &
                 "      LEFT JOIN Catalogos c ON c.cat_clase='Monedas' AND c.cat_num=h.HDoc_Doc_Mon " &
                 "      LEFT JOIN Catalogos t ON t.cat_num=h.HDoc_Doc_Cat " &
                 " WHERE h.HDoc_Sis_Emp = {empresa} AND h.HDoc_Doc_Cat = {tipo} AND h.HDoc_Doc_Status = {estado}" &
                 " ORDER BY fecha "

        'Sustituir parámetros
        strSQL = strSQL.Replace("{empresa}", Sesion.IdEmpresa)
        strSQL = strSQL.Replace("{tipo}", intDocRetencion)
        strSQL = strSQL.Replace("{estado}", INT_CERO)

        Return strSQL
    End Function

    'SQL para recuperar el nombre de una cuenta contable
    Private Function SQLNombreCuentaContable(ByVal Codigo As String) As String
        Dim strSQL As String = "SELECT '' Nombre"
        If cFunciones.ContaActiva Then
            strSQL = "SELECT nombre FROM {base}.cuentas WHERE id_cuenta={cuenta} AND empresa = {emp} "
            strSQL = strSQL.Replace("{base}", Sesion.BaseConta)
            strSQL = strSQL.Replace("{cuenta}", Text(Codigo))
            strSQL = strSQL.Replace("{emp}", Sesion.IdEmpresa)
        End If
        Return strSQL
    End Function

    'SQL para listar cuentas contables
    Public Function SQLCuentasContables(Optional Tipo As Integer = INT_CERO) As String
        Dim strSQL As String = "SELECT id_cuenta Account, nombre Description FROM {base}.cuentas WHERE empresa={empresa}{tipo} ORDER BY id_cuenta"
        If Tipo.Equals(INT_CERO) Then
            strSQL = strSQL.Replace("{tipo}", String.Empty)
        Else : strSQL = strSQL.Replace("{tipo}", " AND tipo_cuenta={tipo}")
        End If
        strSQL = strSQL.Replace("{base}", Sesion.BaseConta)
        strSQL = strSQL.Replace("{empresa}", Sesion.IdEmpresa)
        strSQL = strSQL.Replace("{tipo}", Tipo)
        Return strSQL
    End Function

    'SQL para listar cuentas contables de gastos
    Public Function SQLCuentasContablesDeGastos(Optional Tipo As Integer = INT_CERO) As String
        Const TIPO_PARAMETRO As Integer = 27
        Dim strSQL As String
        Dim strPadre As String
        Dim cmd As MySqlCommand


        strSQL = "SELECT valor FROM {base}.parametros_empresa WHERE empresa={empresa} AND parametro={tipo_parametro}"
        strSQL = strSQL.Replace("{base}", Sesion.BaseConta)
        strSQL = strSQL.Replace("{empresa}", Sesion.IdEmpresa)
        strSQL = strSQL.Replace("{tipo_parametro}", TIPO_PARAMETRO)
        MyCnn.CONECTAR = strConexion
        cmd = New MySqlCommand(strSQL, CON)
        strPadre = cmd.ExecuteScalar

        strSQL = "SELECT id_cuenta Account, nombre Description FROM {base}.cuentas WHERE empresa={empresa} AND pid={padre} ORDER BY id_cuenta"
        strSQL = strSQL.Replace("{base}", Sesion.BaseConta)
        strSQL = strSQL.Replace("{empresa}", Sesion.IdEmpresa)
        strSQL = strSQL.Replace("{padre}", Text(strPadre))
        Return strSQL
    End Function

    'SQL para cargar el detalle de una liquidacion de caja chica
    Public Function SQLDetalleDeLiquidacion(ByVal Tipo As Integer, ByVal Ciclo As Integer, ByVal Numero As Integer)
        Dim strSQL As String

        'Asignar si no se tiene el ID de documentos (liquidacion)
        If intDocLiquidacion.Equals(INT_CERO) Then
            intDocLiquidacion = ObtenerIdDeDocumento(DOC_LIQUIDACION)
        End If

        strSQL = " SELECT cd.cat_desc Documento, TRIM(CONCAT(d.DDoc_Prd_Des,' ',d.DDoc_Prd_PNr)) Numero, d.DDoc_RF1_Fec Fecha, d.DDoc_RF1_Txt Nombre, cm.cat_ext Moneda, ROUND(d.DDoc_RF1_Dbl,2) Total, ROUND(d.DDoc_RF1_Dbl-d.DDoc_RF2_Dbl,2) Diferencia, d.DDoc_RF2_Txt Concepto" &
                 " FROM Dcmtos_DTL d" &
                 "    LEFT JOIN Catalogos cd ON cd.cat_clase='Documentos' AND cd.cat_num=d.DDoc_Prd_Cod" &
                 "    LEFT JOIN Catalogos cm ON cm.cat_clase='Monedas' AND cm.cat_num=d.DDoc_RF2_Num" &
                 " WHERE d.DDoc_Sis_Emp={empresa} AND d.DDoc_Doc_Cat={tipo} AND d.DDoc_Doc_Ano={ciclo} AND d.DDoc_Doc_Num={numero} AND NOT(d.DDoc_Prd_Cod=0)" &
                 " ORDER BY d.DDoc_Doc_Lin"
        strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
        strSQL = Replace(strSQL, "{tipo}", Tipo)
        strSQL = Replace(strSQL, "{ciclo}", Ciclo)
        strSQL = Replace(strSQL, "{numero}", Numero)

        Return strSQL
    End Function

    'SQL para listar las liquidaciones pendientes para una caja chica
    Public Function SQLLiquidacionesPendientes(ByVal ID As Integer)
        Dim strSQL As String

        'Asignar si no se tiene el ID de documentos (liquidacion)
        If intDocLiquidacion.Equals(INT_CERO) Then
            intDocLiquidacion = ObtenerIdDeDocumento(DOC_LIQUIDACION)
        End If

        strSQL = " SELECT c.BCta_Num ID, e.HDoc_Doc_Cat Tipo, e.HDoc_Doc_Ano Ciclo, e.HDoc_Doc_Num Numero, c.BCta_Nom_Cue Caja, e.HDoc_Doc_Mon Divisa, e.HDoc_Doc_TC Tasa, IFNULL(e.HDoc_DR1_Num,0) Documento, e.HDoc_Doc_Fec Fecha, cm.cat_ext Moneda, e.HDoc_RF2_Dbl Monto, e.HDoc_RF1_Dbl Bruto, " &
                 "    e.HDoc_DR1_Fec Inicio, e.HDoc_DR2_Fec Fin " &
                 " FROM Dcmtos_HDR e" &
                 "    LEFT JOIN CtasBcos c ON c.BCta_Sis_Emp=e.HDoc_Sis_Emp AND c.BCta_Num=e.HDoc_DR1_Cat" &
                 "    LEFT JOIN Catalogos cm ON cm.cat_clase='Monedas' AND cm.cat_num=e.HDoc_Doc_Mon" &
                 " WHERE e.HDoc_Sis_Emp={empresa} AND e.HDoc_Doc_Cat={liquidacion} AND e.HDoc_DR1_Cat={caja} AND (e.HDoc_RF2_Dbl > 0) AND (e.HDoc_Pro_DCat=0 AND e.HDoc_Pro_DAno=0 AND e.HDoc_Pro_DNum=0)" &
                 " ORDER BY Caja, Fecha, Numero"
        strSQL = strSQL.Replace("{empresa}", Sesion.IdEmpresa)
        strSQL = strSQL.Replace("{caja}", ID)
        strSQL = strSQL.Replace("{liquidacion}", intDocLiquidacion)

        Return strSQL
    End Function

    'SQL para la operacion de banco en la poliza contable
    Public Function SQLContaBanco(ByVal Tipo As Integer, ByVal Ciclo As Integer, ByVal Numero As Integer) As String
        Dim strSQL As String = " SELECT b.BCta_Cuenta Cuenta, ROUND(h.HDoc_Doc_TC, 5) Tasa, IF(h.HDoc_Doc_Mon={externa}, h.HDoc_RF1_Dbl * h.HDoc_Doc_TC, h.HDoc_RF1_Dbl) Total , IFNULL(h.HDoc_Emp_NIT, '') Presupuesto " &
                               " FROM Dcmtos_HDR h " &
                               " LEFT JOIN CtasBcos b ON b.BCta_Sis_Emp = h.HDoc_Sis_Emp AND b.BCta_Num = h.HDoc_RF1_Num " &
                               " WHERE h.HDoc_Sis_Emp = {empresa} AND h.HDoc_Doc_Cat = {tipo} AND h.HDoc_Doc_Ano = {ciclo} AND h.HDoc_Doc_Num = {numero}"

        'Determinar si la moneda es igual a la exterior
        If intCurExt.Equals(INT_CERO) Then
            intCurExt = ObtenerIdMonedaExterna()
        End If
        strSQL = strSQL.Replace("{empresa}", Sesion.IdEmpresa)
        strSQL = strSQL.Replace("{tipo}", Tipo)
        strSQL = strSQL.Replace("{ciclo}", Ciclo)
        strSQL = strSQL.Replace("{numero}", Numero)
        strSQL = strSQL.Replace("{externa}", intCurExt)

        Return strSQL
    End Function

    'SQL para listar los movimientos de la cuenta bancaria
    Public Function SQLEstadoDeCuenta(ByVal ID As Integer, ByVal Desde As Date, ByVal Hasta As Date, ByVal Clase As String, ByVal Tipo As Integer, ByVal TipoRpt As Integer) As String
        Dim strSQL As String = " SELECT w.anio,w.cat, w.Fecha,w.Documento,w.NumDoc,w.Referencia, w.Dato,w.Credito,w.Debito,w.Concepto,w.Poliza, IF(w.Concepto = 'ANULADO',0,w.Presupuesto) Presupuesto, IFNULL(IF(w.Concepto = 'ANULADO','',w.nombre_ext),'') descripcion, IF(w.Concepto = 'ANULADO',0,w.Presupuesto$) Presupuesto$ " &
                               " FROM ( " &
                               "      SELECT m.BMov_Doc_Ano anio,m.BMov_Doc_Cat cat, m.BMov_Doc_Num NumDoc, m.BMov_Fec Fecha, lt.cat_desc Documento, m.BMov_Num_Doc Referencia, if(m.BMov_Abno_Loc=0,if(m.BMov_Crgo_Loc=0,'ANULADO',m.BMov_Beneficiario ),m.BMov_Beneficiario ) Dato, (m.BMov_Abno_{clase}) Credito, (m.BMov_Crgo_{clase}) Debito, if(m.BMov_Abno_Loc=0,if(m.BMov_Crgo_Loc=0,'ANULADO',m.BMov_Concepto ),m.BMov_Concepto ) Concepto, c.poliza Poliza, IFNULL(IF(d.moneda = {mon}, d.importe_loc ,d.importe_ext),0) Presupuesto, p.nombre_ext, IFNULL(d.importe_ext,0) presupuesto$" &
                               "      FROM MvtosBcos m" &
                               "         LEFT JOIN Catalogos lt ON lt.cat_clase = 'DocsBcos' AND lt.cat_num = m.BMov_Cat_Doc" &
                               "         LEFT JOIN {conta}.detalle_presupuesto d ON d.empresa = m.BMov_Sis_Emp AND d.categoria = m.BMov_Doc_Cat AND d.ano = m.BMov_Doc_Ano AND d.numero = m.BMov_Doc_Num " &
                               "         LEFT JOIN {conta}.cuentas_presupuesto p ON p.empresa = d.empresa AND p.id_cuenta = d.cuenta " &
                               "         LEFT JOIN {conta}.polizas c ON c.empresa = m.BMov_Sis_Emp AND c.ref_tipo = m.BMov_Doc_Cat AND c.ref_ciclo = m.BMov_Doc_Ano AND c.ref_numero = m.BMov_Doc_Num " &
                               "      WHERE m.BMov_Sis_Emp = {empresa} AND m.BMov_Cta = {id} AND (m.BMov_Fec BETWEEN {desde} AND {hasta}) {tipo}" &
                               "      ORDER BY m.BMov_Fec, m.BMov_Doc_Cat DESC, m.BMov_Num_Doc,d.numero)w {TipoRpt} ORDER BY w.Fecha,w.Referencia "

        If TipoRpt = 0 Then
            strSQL = Replace(strSQL, "{TipoRpt}", " GROUP BY w.cat, w.NumDoc,w.anio ")
        Else
            strSQL = Replace(strSQL, "{TipoRpt}", " ")
        End If

        strSQL = Replace(strSQL, "{conta}", Sesion.BaseConta)
        strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
        strSQL = Replace(strSQL, "{id}", ID)
        strSQL = Replace(strSQL, "{desde}", Text(Desde.ToString(FORMATO_MYSQL)))
        strSQL = Replace(strSQL, "{hasta}", Text(Hasta.ToString(FORMATO_MYSQL)))
        strSQL = Replace(strSQL, "{clase}", Clase)
        strSQL = Replace(strSQL, "{mon}", cFunciones.DivisaLocal)
        If Not Tipo.Equals(INT_CERO) Then
            strSQL = strSQL.Replace("{tipo}", " AND m.BMov_Cat_Doc={tipo}")
        Else : strSQL = strSQL.Replace("{tipo}", String.Empty)
        End If
        strSQL = strSQL.Replace("{tipo}", Tipo)

        Return strSQL
    End Function

    'SQL para listar los movimientos de la cuenta bancaria
    Public Function SQLEstadoDeCuentaResumen(ByVal ID As Integer, ByVal Desde As Date, ByVal Hasta As Date, ByVal Clase As String) As String
        Dim strSQL As String = " SELECT lt.cat_desc Documento, COUNT(*) Cantidad, SUM(m.BMov_Abno_{clase}) Credito, SUM(m.BMov_Crgo_{clase}) Debito" &
                               " FROM MvtosBcos m" &
                               "      LEFT JOIN Catalogos lt ON lt.cat_clase = 'DocsBcos' AND lt.cat_num = m.BMov_Cat_Doc" &
                               " WHERE m.BMov_Sis_Emp = {empresa} AND m.BMov_Cta = {id} AND (m.BMov_Fec BETWEEN {desde} AND {hasta})" &
                               " GROUP BY lt.cat_clave" &
                               " ORDER BY m.BMov_Fec, m.BMov_Doc_Cat DESC, m.BMov_Doc_Num"

        strSQL = strSQL.Replace("{empresa}", Sesion.IdEmpresa)
        strSQL = strSQL.Replace("{id}", ID)
        strSQL = strSQL.Replace("{desde}", Text(Desde.ToString(FMT_DATE)))
        strSQL = strSQL.Replace("{hasta}", Text(Hasta.ToString(FMT_DATE)))
        strSQL = strSQL.Replace("{clase}", Clase)

        Return strSQL
    End Function

    'SQL para recuperar los datos que describen la cuenta (banco, cuenta, descripcion, moneda)
    Public Function SQLDatosDeCuenta(ByVal ID As Integer) As String
        Dim strSQL As String = " SELECT cb.cat_desc Banco, c.BCta_Num_Cue Cuenta, c.BCta_Des_Cue Descripcion, cm.cat_desc Moneda, " &
                               "        IF(c.BCta_Mon=IFNULL((SELECT CAST(cc.cat_clave AS SIGNED) FROM Catalogos cc WHERE cc.cat_sist='CUR_LOC' LIMIT 1),-1),'Loc','Ext') Clase" &
                               " FROM CtasBcos c " &
                               "     LEFT JOIN Catalogos cm ON cm.cat_num= c.BCta_Mon " &
                               "     LEFT JOIN Catalogos cb ON cb.cat_num= c.BCta_Cod_Ban " &
                               " WHERE c.BCta_Sis_Emp={empresa} AND c.BCta_Num={id}"
        strSQL = strSQL.Replace("{empresa}", Sesion.IdEmpresa)
        strSQL = strSQL.Replace("{id}", ID)
        Return strSQL
    End Function

    'SQL para recuperar la tasa de cambio de la moneda externa desde la tabla catalogos
    Public Function SQLTasaDesdeCatalogos(ByVal ID As Integer) As String
        Dim strSQL As String = " SELECT IFNULL(ROUND(cat_sist,5),0) Tasa " &
                               " FROM Catalogos " &
                               " WHERE cat_clase='Monedas' AND  cat_num={id}".Replace("{id}", ID)
        Return strSQL
    End Function

#End Region

    'Cargar ID de tipos de documentos bancarios
    Public Sub CargarTipos()
        _IdDeposito = ObtenerIdDeDocumento(DOC_DEPOSITO)
        _IdCredito = ObtenerIdDeDocumento(DOC_CREDITO)
        _IdCheque = ObtenerIdDeDocumento(DOC_CHEQUE)
        _IdDebito = ObtenerIdDeDocumento(DOC_DEBITO)

        _IdRecibo = ObtenerIdDeDocumento(DOC_RECIBO)
        _IdAnticipo = ObtenerIdDeDocumento(DOC_ANTICIPO)
    End Sub

    'Devuelve el texto para un tipo de documento
    Public Function TextoDeTipo(ByVal Tipo As Integer) As String
        Dim strTipo As String = "(Unknown document type)"

        If IdDeposito.Equals(INT_CERO) Then
            CargarTipos()
        End If
        Select Case Tipo
            Case IdDeposito : strTipo = "Deposit"
            Case IdCheque : strTipo = "Check"
            Case IdCredito : strTipo = "Credit"
            Case IdDebito : strTipo = "Debit"
        End Select

        Return strTipo
    End Function

    'Devuelve el texto para un grupo
    Public Function TextoDeGrupo(ByVal ID As Integer) As String
        Dim strTipo As String = "(Unknown transaction group)"
        Select Case ID
            Case BancoGrupo.Proveedor : strTipo = "Provider"
            Case BancoGrupo.Caja : strTipo = "Petty Cash"
            Case BancoGrupo.Cliente : strTipo = "Customer"
            Case BancoGrupo.Empleado : strTipo = "Employee"
            Case BancoGrupo.Planilla : strTipo = "Payroll"
            Case BancoGrupo.Transferencia : strTipo = "Bank Transfer"
            Case BancoGrupo.Impuestos : strTipo = "Taxes"
        End Select
        Return strTipo
    End Function

    'Muestra un cuadro de dialogo para que el usuario ingrese un dato
    Public Function PedirDato(ByVal Info As String, ByVal Titulo As String, Optional Valor As String = STR_VACIO) As String
        Dim strDato As String = Valor
        Dim logEx As Boolean = False
        If strDato.Equals(String.Empty) Then
            strDato = Space(1)
        End If
        Do While Not logEx
            strDato = InputBox(Info, Titulo, strDato)
            If String.IsNullOrEmpty(strDato) Then
                logEx = True
            ElseIf strDato.Trim.Equals(String.Empty) Then
                MessageBox.Show("Please enter a valid value", Titulo, MessageBoxButtons.OK, MessageBoxIcon.Information)
            Else
                logEx = True
            End If
        Loop
        Return strDato.Trim
    End Function

    'Devulve el nombre de una cuenta contable
    Public Function ObtenerNombreCC(ByVal Codigo As String) As String
        Dim strSQL As String = SQLNombreCuentaContable(Codigo.Trim)
        Dim strTemp As String = String.Empty
        MyCnn.CONECTAR = strConexion
        Dim cmd As New MySqlCommand(strSQL, CON)
        strTemp = cmd.ExecuteScalar
        Return strTemp
    End Function

    'Devuelve si un documenot es confidencial
    Public Function EsConfidencial(ByVal Tipo As Integer, ByVal Ciclo As Integer, ByVal Numero As Integer) As Boolean
        Dim strSQL As String = "SELECT IFNULL(HDoc_DR2_Emp,0) restringido FROM Dcmtos_HDR WHERE HDoc_Sis_Emp=@empresa AND HDoc_Doc_Cat=@tipo AND HDoc_Doc_Ano=@ciclo AND HDoc_Doc_Num=@numero LIMIT 1"
        Dim intRest As Integer = INT_CERO
        MyCnn.CONECTAR = strConexion
        'Asignar parametros y obtener resultado
        Using cmd As New MySqlCommand(strSQL, CON)
            cmd.Parameters.AddWithValue("@empresa", Sesion.IdEmpresa)
            cmd.Parameters.AddWithValue("@tipo", Tipo)
            cmd.Parameters.AddWithValue("@ciclo", Ciclo)
            cmd.Parameters.AddWithValue("@numero", Numero)
            intRest = CInt(cmd.ExecuteScalar)
        End Using

        Return Not intRest.Equals(INT_CERO)
    End Function

    'Devuelve un ID de catalogo para un nuevo registro
    Public Function ObtenerNuevoCatalogoID() As Integer
        Dim strSQL As String = "SELECT (IFNULL(MAX(cat_num),0)+1) ID FROM Catalogos"
        MyCnn.CONECTAR = strConexion
        Dim cmd As New MySqlCommand(strSQL, CON)
        Dim intID As Integer = INT_CERO
        Try
            intID = CInt(cmd.ExecuteScalar)
        Catch ex As Exception
        End Try
        Return intID
    End Function

    'Devuelve un ID para una nuevo documento basado en el tipo & año
    Public Function ObtenerNuevoDocumentoID(ByVal Tipo As Integer, ByVal Ciclo As Integer) As Integer
        Dim strSQL As String = "SELECT (IFNULL(MAX(HDoc_Doc_Num),0)+1) ID FROM Dcmtos_HDR WHERE HDoc_Sis_Emp={empresa} AND HDoc_Doc_Cat={tipo} AND HDoc_Doc_Ano={ciclo}"
        strSQL = strSQL.Replace("{empresa}", Sesion.IdEmpresa)
        strSQL = strSQL.Replace("{tipo}", Tipo)
        strSQL = strSQL.Replace("{ciclo}", Ciclo)
        MyCnn.CONECTAR = strConexion
        Dim cmd As New MySqlCommand(strSQL, CON)
        Dim intID As Integer = INT_CERO
        Try
            intID = CInt(cmd.ExecuteScalar)
        Catch ex As Exception
        End Try
        Return intID
    End Function

    'Devuelve un ID para una cuenta bancaria nueva
    Public Function ObtenerNuevaCuentaID() As Integer
        Dim strSQL As String = "SELECT (IFNULL(MAX(BCta_Num),0)+1) ID FROM CtasBcos"
        MyCnn.CONECTAR = strConexion
        Dim cmd As New MySqlCommand(strSQL, CON)
        Dim intID As Integer = INT_CERO
        Try
            intID = CInt(cmd.ExecuteScalar)
        Catch ex As Exception
        End Try
        Return intID
    End Function

    'Devuelve el ID de catalogo de un documento bancario
    Public Function ObtenerIdDeDocumento(ByVal Codigo As String, Optional Clave As String = STR_VACIO, Optional Aviso As Boolean = True) As Integer
        Dim intID As Integer = INT_CERO
        Dim strSQL As String
        Dim strTemp As String = Clave

        If Not strTemp.Equals(String.Empty) Then
            strTemp = " AND cat_clave={clave}"
        End If
        strSQL = ("SELECT cat_num FROM Catalogos WHERE cat_sist = {codigo}{clave}").Replace("{clave}", strTemp)

        strSQL = strSQL.Replace("{codigo}", Text(Codigo))
        strSQL = Replace(strSQL, "{clave}", Text(Clave))
        MyCnn.CONECTAR = strConexion
        Dim cmd As New MySqlCommand(strSQL, CON)
        Try
            intID = CInt(cmd.ExecuteScalar)
        Catch ex As Exception
            MessageBox.Show(ex.Message, ex.Source, MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
        cmd.Dispose()

        If intID <= INT_CERO And Not (Codigo = "(sin documento)") Then
            If Aviso Then
                MessageBox.Show("Could not find ID# " & intID, "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning)
            End If
        End If
        Return intID
    End Function

    'Devuelve el ID del documento bancario 
    Public Function ObtenerIdBancoDocumento(ByVal Tipo As Integer) As Integer
        Dim strClase As String = String.Empty
        Dim intID As Integer = INT_CERO

        If IdDeposito.Equals(INT_CERO) Then
            CargarTipos()
        End If
        Select Case Tipo
            Case IdDeposito : strClase = BCO_DEPOSITO
            Case IdCheque : strClase = BCO_CHEQUE
            Case IdCredito : strClase = BCO_CREDITO
            Case IdDebito : strClase = BCO_DEBITO
        End Select

        intID = ObtenerIdDeDocumento(strClase)
        Return intID
    End Function

    'Devuelve el ID de tipo para documento de compra
    Public Function ObtenerIdDocumentoCompra() As Integer
        If intDocCompra.Equals(INT_CERO) Then
            intDocCompra = ObtenerIdDeDocumento(DOC_COMPRA)
        End If

        Return intDocCompra
    End Function

    'Obtener ID de moneda local de empresa o predeterminada
    Public Function ObtenerIdMonedaLocal() As Integer
        Dim strSQL As String = "SELECT emp_moneda FROM Empresas WHERE emp_no={empresa}".Replace("{empresa}", Sesion.IdEmpresa)
        Dim cmd As MySqlCommand

        If intCurLoc.Equals(INT_CERO) Then
            'Determinar la moneda local (de la empresa)
            MyCnn.CONECTAR = strConexion
            cmd = New MySqlCommand(strSQL, CON)
            intCurLoc = CInt(cmd.ExecuteScalar)
            If intCurLoc.Equals(INT_CERO) Then
                'Recuperar moneda predeterminada
                strSQL = " SELECT c.cat_num  " &
                         " FROM Catalogos c " &
                         "      INNER JOIN Catalogos m ON m.cat_clase = 'Defaults' AND m.cat_clave = c.cat_num AND m.cat_sist = {id} " &
                         " WHERE c.cat_clase = 'Monedas'".Replace("{id}", Text("CUR_LOC"))
                MyCnn.CONECTAR = strConexion
                cmd = New MySqlCommand(strSQL, CON)
                intCurLoc = CInt(cmd.ExecuteScalar)
            End If
        End If
        Return intCurLoc
    End Function

    'Obtener ID de moneda externa predeterminada
    Public Function ObtenerIdMonedaExterna() As Integer
        Dim strSQL As String = String.Empty
        Dim cmd As MySqlCommand

        If intCurExt.Equals(INT_CERO) Then
            'Recuperar moneda externa
            strSQL = " SELECT c.cat_num  " &
                     " FROM Catalogos c " &
                     "      INNER JOIN Catalogos m ON m.cat_clase = 'Defaults' AND m.cat_clave = c.cat_num AND m.cat_sist = {id} " &
                     " WHERE c.cat_clase = 'Monedas'"
            strSQL = strSQL.Replace("{id}", Text("CUR_EXT"))
            cmd = New MySqlCommand(strSQL, CON)
            intCurExt = CInt(cmd.ExecuteScalar)
        End If
        Return intCurExt
    End Function

    'Recupera la tasa para la moneda desde catalogos
    Public Function ObtenerTasaDesdeCatalogos(ByVal ID As Integer) As Double
        Dim dblTasa As Double = 0
        Dim strSQL As String = SQLTasaDesdeCatalogos(ID)
        MyCnn.CONECTAR = strConexion
        Using cmd As New MySqlCommand(strSQL, CON)
            Dim obj As Object = cmd.ExecuteScalar
            If obj IsNot Nothing Then
                dblTasa = CDbl(obj)
            End If
        End Using
        Return dblTasa
    End Function

    'Elimina la cuenta actual
    Public Function BorrarCuenta(ByVal ID As Integer) As Boolean
        Dim logEx As Boolean = False

        Return logEx
    End Function

    'Devuelve el saldo actual de la cuenta bancaria
    Public Function SaldoActual(ByVal ID As Integer, ByVal DeFecha As Date, Optional Todo As Boolean = False) As Double
        Dim dbl As Double = 0.0
        Dim strSQL As String = SQLSaldoDeCuenta(ID, DeFecha, Todo)
        MyCnn.CONECTAR = strConexion
        Dim cmd = New MySqlCommand(strSQL, CON)
        Try
            dbl = Convert.ToDouble(cmd.ExecuteScalar)
        Catch ex As Exception
        End Try
        Return Math.Round(dbl, 2)
    End Function

    'Devuelve el total en reserva
    Public Function TotalEnReserva(ByVal ID As Integer) As Double
        Dim dbl As Double = 0.0
        Dim strSQL As String = SQLTotalEnReserva(ID)
        MyCnn.CONECTAR = strConexion
        Dim cmd = New MySqlCommand(strSQL, CON)
        Try
            dbl = Convert.ToDouble(cmd.ExecuteScalar)
        Catch ex As Exception
        End Try
        Return Math.Round(dbl, 2)
    End Function

    Public Sub ImprimirEstadoDeCuenta(ByVal ID As Integer, ByVal Desde As Date, ByVal Hasta As Date, ByVal Tipo As Integer, Optional tipoRpt As Integer = 0)
        Dim cmd As MySqlCommand
        Try
            Dim rpt As New clsReportes
            Dim strSQL As String = String.Empty
            Dim strFile As String = cFunciones.ArchivoTemporal()
            Dim strTitulo As String = "Bank Account Statement"
            Dim strClase As String = "Ext"
            Dim strTexto As String

            Dim f As Byte = FreeFile()
            Dim i As Integer = INT_CERO

            Dim dblSaldo As Double = 0.0
            Dim dblCargo As Double = 0.0
            Dim dblAbono As Double = 0.0

            Dim dblSumCargo As Double = 0
            Dim dblSumAbono As Double = 0
            Dim dblSumPresupuesto As Double = 0
            Dim dblSumPresupuestoDls As Double = 0

            FileOpen(f, strFile, OpenMode.Output)
            Print(f, "<html>")
            Print(f, "<head>")
            Print(f, "<title>" & strTitulo & "</title>")
            Print(f, "<style type='text/css'>")
            Print(f, " table {table-layout: fixed; empty-cells: show; border-collapse:collapse}")
            Print(f, " th {width: 5cm; border:solid Gray 1px; background-color: White; color: Black; padding:2px 5px; font-family: Tahoma,  Arial;font-size: 7pt}")
            Print(f, " th.titulo {width: 5cm; border:solid Gray 1px; background-color: Black; color: White; padding:2px 5px; font-family: Tahoma,  Arial;font-size: 7pt}")
            Print(f, " th.encabezado {text-align:center;border:solid Gray 1px; padding:3px 5px; font-family: Tahoma,  Arial;font-size: 10pt}")
            Print(f, " td {text-align:left;border:solid Gray 1px; padding:3px 5px; font-family: Tahoma, Arial;font-size: 7pt}")
            Print(f, " td.centro {text-align:center;border:solid Gray 1px; padding:3px 5px; font-family: Tahoma, Arial;font-size: 7pt}")
            Print(f, " td.numero {text-align:right;border:solid Gray 1px; padding:3px 5px; font-family: Tahoma, Arial;font-size: 7pt; mso-number-format:\#\,\#\#0\.00}")
            Print(f, "</style>")
            Print(f, "<body>")
            Print(f, "<div style='text-align:left;'>")
            Print(f, "<table cellspacing=0 width=500 >")
            Print(f, "<tr>")
            Print(f, "<td rowspan='3'style = 'border: none' >&nbsp;</td>")
            Print(f, "<td style='border: none'> <font face='impact' size=3 color=black>" & Sesion.Empresa & "</FONT> </td>")
            Print(f, "</tr>")
            Print(f, "<tr>")
            Print(f, "<td style='border: none'><font face=Arial color=black><b> Bank Account Statement </b></FONT></td>")
            Print(f, "</tr>")
            Print(f, "<tr><td style = 'border: 0'>&nbsp;</td></tr>")
            Print(f, "</table>")

            'Datos de la cuenta (incluida la clase de moneda Loc / Ext)
            strSQL = SQLDatosDeCuenta(ID)
            MyCnn.CONECTAR = strConexion
            cmd = New MySqlCommand(strSQL, CON)
            Using dr As MySqlDataReader = cmd.ExecuteReader
                If dr.Read Then
                    strClase = dr.Item("clase").ToString
                    Print(f, "<table style='border: none'>")
                    Print(f, "<tr>")
                    Print(f, "<th style = 'width: 3cm; background-color: Silver'> Bank Name </th>")
                    Print(f, "<td style = 'width: 5cm; border: 0; padding-left: 15px'> " & dr.Item("banco").ToString & " </td>")
                    Print(f, "</tr>")
                    Print(f, "<tr>")
                    Print(f, "<th style = 'width: 3cm; background-color: Silver'> Account Number </th>")
                    Print(f, "<td style = 'width: 5cm; border: 0; padding-left: 15px'> " & dr.Item("cuenta").ToString & " </td>")
                    Print(f, "</tr>")
                    Print(f, "<tr>")
                    Print(f, "<th style = 'width: 3cm; background-color: Silver'> Description </th>")
                    Print(f, "<td style = 'width: 5cm; border: 0; padding-left: 15px'> " & dr.Item("descripcion").ToString & " </td>")
                    Print(f, "</tr>")
                    Print(f, "<tr>")
                    Print(f, "<th style = 'width: 3cm; background-color: Silver'> Currency </th>")
                    Print(f, "<td style = 'width: 5cm;border: 0; padding-left: 15px'> " & dr.Item("moneda").ToString & " </td>")
                    Print(f, "</tr>")
                    Print(f, "<tr>")
                    Print(f, "<th style = 'width: 3cm; background-color: Silver'> Date Range </th>")
                    Print(f, "<td style = 'width: 5cm;border: 0; padding-left: 15px'> " & Desde.ToString("dd/MM/yyyy") & " - " & Hasta.ToString("dd/MM/yyyy") & " </td>")
                    Print(f, "</tr>")
                    Print(f, "<tr><td style = 'border: 0'>&nbsp;</td></tr>")
                    Print(f, "</table>")
                End If
            End Using

            'Saldo de la cuenta a la fecha inicial
            dblSaldo = SaldoActual(ID, Desde, False)

            Print(f, "<table>")
            Print(f, "<tr>")
            Print(f, "<th style = 'width: 1cm; background-color: Silver'>Item</th>")
            Print(f, "<th style = 'width: 2cm; background-color: Silver'>Date</th>")
            Print(f, "<th style = 'width: 2.5cm; background-color: Silver'>Transaction</th>")
            Print(f, "<th style = 'width: 2.5cm; background-color: Silver'>Reference</th>")
            Print(f, "<th style = 'background-color: Silver'>Name</th>")
            Print(f, "<th style = 'width: 2cm; background-color: Silver'>Credit</th>")
            Print(f, "<th style = 'width: 2cm; background-color: Silver'>Debit</th>")
            Print(f, "<th style = 'width: 2cm; background-color: Silver'>Balance</th>")
            Print(f, "<th style = 'background-color: Silver'>Memo</th>")
            If tipoRpt = 1 Then
                Print(f, "<th style = 'width: 2cm; background-color: Silver'>Budget</th>")
                If strClase = "Loc" Then
                    Print(f, "<th style = 'width: 2cm; background-color: Silver'>Budget US$</th>")
                End If
                Print(f, "<th style = 'background-color: Silver'>Concept</th>")
                End If

                Print(f, "</tr>")

            'Movimientos en el rango de fecha, clase de moneda y tipo de documento
            strSQL = SQLEstadoDeCuenta(ID, Desde, Hasta, strClase, Tipo, tipoRpt)
            MyCnn.CONECTAR = strConexion
            cmd = New MySqlCommand(strSQL, CON)
            Using dr As MySqlDataReader = cmd.ExecuteReader
                While dr.Read
                    i += 1
                    dblCargo = CDbl(dr.Item("debito"))
                    dblAbono = CDbl(dr.Item("credito"))
                    dblSaldo += (dblAbono - dblCargo)
                    strTexto = dr.Item("dato").ToString
                    If strTexto.ToUpper.Trim = "ANULADO" Then
                        strTexto = Replace("<font color='Crimson'><b>{dato}</b></font>", "{dato}", strTexto)
                    End If

                    Print(f, "<tr>")
                    Print(f, "<td class='centro'>" & i.ToString & "</td>")
                    Print(f, "<td class='centro'>" & CDate(dr.Item("fecha")).ToString(FORMATO_MYSQL) & "</td>")
                    Print(f, "<td>" & dr.Item("documento").ToString & "</td>")
                    Print(f, "<td class='centro'>" & dr.Item("referencia").ToString & "</td>")
                    Print(f, "<td>" & strTexto & "</td>")

                    Print(f, "<td class='numero'>" & PintarTexto(dblAbono.ToString("n2"), True) & "</td>")
                    Print(f, "<td class='numero'>" & PintarTexto(dblCargo.ToString("n2"), True) & "</td>")

                    Print(f, "<td class='numero'>" & dblSaldo.ToString("n2") & "</td>")
                    Print(f, "<td>" & dr.Item("concepto").ToString & "</td>")

                    'Hace las Sumas
                    dblSumAbono += dblAbono
                    dblSumCargo += dblCargo

                    If tipoRpt = 1 Then
                        Print(f, "<td class='numero'>" & PintarTexto(CDbl(dr.Item("Presupuesto")).ToString(FORMATO_MONEDA), True) & "</td>")
                        If strClase = "Loc" Then
                            Print(f, "<td class='numero'>" & PintarTexto(CDbl(dr.Item("Presupuesto$")).ToString(FORMATO_MONEDA), True) & "</td>")
                            dblSumPresupuestoDls += dr.Item("Presupuesto$")
                        End If
                        Print(f, "<td>" & dr.Item("descripcion").ToString & "</td>")
                        dblSumPresupuesto += dr.Item("Presupuesto")
                    End If
                    Print(f, "</tr>")
                End While
                Print(f, "<tr>")
                Print(f, "<td style = 'background-color: Silver'</td>")
                Print(f, "<td style = 'background-color: Silver'><br></td>")
                Print(f, "<td style = 'background-color: Silver'><br></td>")
                Print(f, "<td style = 'background-color: Silver'><br></td>")
                Print(f, "<td style = 'background-color: Silver'><br></td>")

                Print(f, "<td style = 'background-color: Silver;text-align:right'>" & dblSumAbono.ToString(FORMATO_MONEDA) & "</td>")
                Print(f, "<td style = 'background-color: Silver;text-align:right'>" & dblSumCargo.ToString(FORMATO_MONEDA) & "</td>")
                Print(f, "<td style = 'background-color: Silver;text-align:right'>" & dblSaldo.ToString(FORMATO_MONEDA) & "</td>")
                Print(f, "<td style = 'background-color: Silver;text-align:right'><br></td>")
                If tipoRpt = 1 Then
                    Print(f, "<td style = 'background-color: Silver;text-align:right'>" & dblSumPresupuesto.ToString(FORMATO_MONEDA) & "</td>")
                    If strClase = "Loc" Then
                        Print(f, "<td style = 'background-color: Silver;text-align:right'>" & dblSumPresupuestoDls.ToString(FORMATO_MONEDA) & "</td>")
                    End If
                    Print(f, "<td style = 'background-color: Silver;text-align:right'><br></td>")
                End If
            End Using
            Print(f, "</tr>")
            Print(f, "</table>")

            Print(f, "</div>")
            Print(f, "</body>")
            Print(f, "<html>")

            FileClose(f)
            rpt.MostarReporte(strFile)
        Catch ex As Exception
            MessageBox.Show(ex.Message, ex.Source, MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    Public Sub ImprimirEstadoDeCuentaResumen(ByVal ID As Integer, ByVal Desde As Date, ByVal Hasta As Date)
        Dim cmd As MySqlCommand
        Try
            Dim rpt As New clsReportes
            Dim strSQL As String = String.Empty
            Dim strFile As String = cFunciones.ArchivoTemporal()
            Dim strTitulo As String = "Bank Account Summary"
            Dim strClase As String = "Ext"

            Dim f As Byte = FreeFile()
            Dim i As Integer = INT_CERO

            Dim dblSaldo As Double = 0.0
            Dim dblCargo As Double = 0.0
            Dim dblAbono As Double = 0.0

            FileOpen(f, strFile, OpenMode.Output)
            Print(f, "<html>")
            Print(f, "<head>")
            Print(f, "<title>" & strTitulo & "</title>")
            Print(f, "<style type='text/css'>")
            Print(f, " table {table-layout: fixed; empty-cells: show; border-collapse:collapse}")
            Print(f, " th {width: 5cm; border:solid Gray 1px; background-color: White; color: Black; padding:2px 5px; font-family: Tahoma,  Arial;font-size: 7pt}")
            Print(f, " th.titulo {width: 5cm; border:solid Gray 1px; background-color: Black; color: White; padding:2px 5px; font-family: Tahoma,  Arial;font-size: 7pt}")
            Print(f, " th.encabezado {text-align:center;border:solid Gray 1px; padding:3px 5px; font-family: Tahoma,  Arial;font-size: 10pt}")
            Print(f, " td {text-align:left;border:solid Gray 1px; padding:3px 5px; font-family: Tahoma, Arial;font-size: 7pt}")
            Print(f, " td.centro {text-align:center;border:solid Gray 1px; padding:3px 5px; font-family: Tahoma, Arial;font-size: 7pt}")
            Print(f, " td.numero {text-align:right;border:solid Gray 1px; padding:3px 5px; font-family: Tahoma, Arial;font-size: 7pt; mso-number-format:\#\,\#\#0\.00}")
            Print(f, "</style>")
            Print(f, "<body>")
            Print(f, "<div style='text-align:left;'>")
            Print(f, "<table cellspacing=0 width=500 >")
            Print(f, "<tr>")
            Print(f, "<td rowspan='3'style = 'border: none' >&nbsp;</td>")
            Print(f, "<td style='border: none'> <font face='impact' size=3 color=black>" & Sesion.Empresa & "</FONT> </td>")
            Print(f, "</tr>")
            Print(f, "<tr>")
            Print(f, "<td style='border: none'><font face=Arial color=black><b> Bank Account Statement </b></FONT></td>")
            Print(f, "</tr>")
            Print(f, "<tr><td style = 'border: 0'>&nbsp;</td></tr>")
            Print(f, "</table>")

            'Datos de la cuenta (incluida la clase de moneda Loc / Ext)
            strSQL = SQLDatosDeCuenta(ID)
            MyCnn.CONECTAR = strConexion
            cmd = New MySqlCommand(strSQL, CON)

            Using dr As MySqlDataReader = cmd.ExecuteReader
                If dr.Read Then
                    strClase = dr.Item("clase").ToString

                    Print(f, "<table style='border: none'>")
                    Print(f, "<tr>")
                    Print(f, "<th style = 'width: 3cm; background-color: Silver'> Bank Name </th>")
                    Print(f, "<td style = 'width: 5cm; border: 0; padding-left: 15px'> " & dr.Item("banco").ToString & " </td>")
                    Print(f, "</tr>")
                    Print(f, "<tr>")
                    Print(f, "<th style = 'width: 3cm; background-color: Silver'> Account Number </th>")
                    Print(f, "<td style = 'width: 5cm; border: 0; padding-left: 15px'> " & dr.Item("cuenta").ToString & " </td>")
                    Print(f, "</tr>")
                    Print(f, "<tr>")
                    Print(f, "<th style = 'width: 3cm; background-color: Silver'> Description </th>")
                    Print(f, "<td style = 'width: 5cm; border: 0; padding-left: 15px'> " & dr.Item("descripcion").ToString & " </td>")
                    Print(f, "</tr>")
                    Print(f, "<tr>")
                    Print(f, "<th style = 'width: 3cm; background-color: Silver'> Currency </th>")
                    Print(f, "<td style = 'width: 5cm;border: 0; padding-left: 15px'> " & dr.Item("moneda").ToString & " </td>")
                    Print(f, "</tr>")
                    Print(f, "<tr>")
                    Print(f, "<th style = 'width: 3cm; background-color: Silver'> Date Range </th>")
                    Print(f, "<td style = 'width: 5cm;border: 0; padding-left: 15px'> " & Desde.ToString("dd/MM/yyyy") & " - " & Hasta.ToString("dd/MM/yyyy") & " </td>")
                    Print(f, "</tr>")
                    Print(f, "<tr><td style = 'border: 0'>&nbsp;</td></tr>")
                    Print(f, "</table>")
                End If
            End Using

            'Saldo de la cuenta a la fecha inicial
            dblSaldo = SaldoActual(ID, Desde, False)

            Print(f, "<table>")
            Print(f, "<tr>")
            Print(f, "<th style = 'width: 1cm; background-color: Silver'>N°</th>")
            Print(f, "<th style = 'width: 2.5cm; background-color: Silver'>Transaction</th>")
            Print(f, "<th style = 'width: 2cm; background-color: Silver'>Documents</th>")
            Print(f, "<th style = 'width: 2cm; background-color: Silver'>Credits</th>")
            Print(f, "<th style = 'width: 2cm; background-color: Silver'>Debits</th>")
            Print(f, "</tr>")

            'Movimientos en el rango de fecha, clase de moneda y tipo de documento
            strSQL = SQLEstadoDeCuentaResumen(ID, Desde, Hasta, strClase)
            MyCnn.CONECTAR = strConexion
            cmd = New MySqlCommand(strSQL, CON)
            Using dr As MySqlDataReader = cmd.ExecuteReader
                While dr.Read
                    i += 1
                    dblCargo = CDbl(dr.Item("debito"))
                    dblAbono = CDbl(dr.Item("credito"))
                    dblSaldo += (dblAbono - dblCargo)

                    Print(f, "<tr>")
                    Print(f, "<td class='centro'>" & i.ToString & "</td>")
                    Print(f, "<td>" & dr.Item("documento").ToString & "</td>")
                    Print(f, "<td class='centro'>" & dr.Item("cantidad").ToString & "</td>")
                    Print(f, "<td class='numero'>" & PintarTexto(dblAbono.ToString("n2"), True) & "</td>")
                    Print(f, "<td class='numero'>" & PintarTexto(dblCargo.ToString("n2"), True) & "</td>")
                    Print(f, "</tr>")
                End While
            End Using

            Print(f, "</table>")

            Print(f, "</div>")
            Print(f, "</body>")
            Print(f, "<html>")

            FileClose(f)
            rpt.MostarReporte(strFile)
        Catch ex As Exception
            MessageBox.Show(ex.Message, ex.Source, MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub


    'Asigna el estilo css de color para un texto
    Private Function PintarTexto(ByVal Texto As String, Optional Vacio As Boolean = False, Optional Positivo As String = vbNullString, Optional Negativo As String = "Crimson", Optional Cero As String = "White") As String
        Dim strTemp As String
        Dim strDato As String

        strDato = Trim(Replace(Texto, Divisa.Externa.simbolo, vbNullString))
        strTemp = Trim(Texto)
        If Val(strDato) = vbEmpty Then
            If Vacio Then
                strTemp = "<font color=" & Cero & ">" & Texto & "</font>"
            End If
        ElseIf Val(strDato) > vbEmpty Then
            If Not (Positivo = vbNullString) Then
                strTemp = "<font color=" & Positivo & ">" & Texto & "</font>"
            End If
        ElseIf Not (Negativo = vbNullString) Then
            strTemp = "<font color=" & Negativo & ">" & Texto & "</font>"
        End If

        PintarTexto = strTemp
    End Function
End Class
