﻿Imports System.Reflection

Public Class clsPrincipal

#Region "Funciones"

    Public Function SQLProgramas() As String
        Dim strSQl As String = ""
        strSQl = vbNullString
        strSQl = strSQl & " SELECT gpr_codigo Grupo, gpr_nombre Titulo, gpr_estado Estado, pro_codigo ID, pro_forma Objeto, pro_descripcion Descripcion"
        strSQl = strSQl & " FROM Grupos"
        strSQl = strSQl & "      LEFT JOIN Programas ON pro_grupo = gpr_codigo"
        strSQl = strSQl & "      INNER JOIN Accesos ON seg_sisemp = {empresa} AND seg_programa = pro_codigo"
        strSQl = strSQl & " WHERE pro_net = 1 AND seg_usuario = '{usuario}' AND NOT((pro_forma = '') OR CONCAT(seg_insertar, seg_editar, seg_borrar, seg_buscar) = '')"
        strSQl = strSQl & " ORDER BY gpr_orden, pro_item, pro_descripcion"
        strSQl = Replace(strSQl, "{empresa}", Sesion.IdEmpresa)
        strSQl = Replace(strSQl, "{usuario}", cFunciones.MyStr(Sesion.Usuario))
        Return strSQl
    End Function

    Public Function NombreDeFormulario(ByVal Nombre As String) As String
        Dim strDato As String
        Select Case Nombre
            Case "Frm01_Polizas" : strDato = "frmNTipos"
            Case "Frm02_Cuentas" : strDato = "frmNPlan"
            Case "Frm03_Partidas" : strDato = "frmNDiario"

            Case "Frm13_Clientes" : strDato = "frmLClientes"
            Case "Frm14_Proveedores" : strDato = "frmLProveedores"
            Case "Frm15_Inventarios" : strDato = "frmLCodigos"
            Case "Frm15_Mercaderias" : strDato = "frmLProductos"
            Case "frm_Transferencia" : strDato = "frmTransferencias"

            Case "Frm16_PedidosCltes" : strDato = "frmDPedidos"
            Case "Frm16_SugerPedidos" : strDato = "frmDSugerido"
            Case "Frm17_PedidosProvs" : strDato = "frmDRequisicion"
            Case "Frm18_ImpEmbarques" : strDato = "frmDConfirmacion"
            Case "Frm18_PolImport" : strDato = "frmDDatos"
            Case "Frm19_Desaduanaje" : strDato = "frmDImportacion"
            Case "Frm20_IngBodega" : strDato = "frmDIngreso"
            Case "Frm21_EgrBodega" : strDato = "frmDInstruccion"
            Case "Frm22_FacturasCltes" : strDato = "frmDFactura"
            Case "Frm22_PolExp" : strDato = "frmDExportacion"
            Case "frmCCredito" : strDato = "frmDCCredito"
            Case "frmContrato" : strDato = "frmDContrato"
            Case "frmCotizacion" : strDato = "frmDCotizacion"
            Case "frmCR" : strDato = "frmDCR"
            Case "frmYM" : strDato = "frmDYM"
            Case "frmRecibo" : strDato = "frmDRecibo"
            Case "frmNDebito" : strDato = "frmDNDebito"
            Case "frmNCredito" : strDato = "frmDNCredito"
            Case "frmNAbono" : strDato = "frmDNAbono"

            Case "frmPFactura" : strDato = "frmGFactura"
            Case "frmPolizasConta" : strDato = "frmNPolizasConta"

            Case "Frm27_Catalogos" : strDato = "frmSParametros"
            Case "Frm30_Seguridad" : strDato = "frmSPermisos"

            Case "frmEmpresa" : strDato = "frmEDatos"
            Case "Frm27_Departamentos" : strDato = "frmPDeptos"
            Case "Frm28_Personal" : strDato = "frmEUsuarios"

            Case "frmBCuenta" : strDato = "frmBCuentas"

            Case "frmCompraSolicitada" : strDato = "frmCompraSolicitada"
            Case "frmAutorizacionCompra" : strDato = "frmAutorizacionCompra"

            Case Else : strDato = Nombre
        End Select

        Return strDato
    End Function

#End Region

#Region "Procedimientos"
    Private Function ValidarForma(ByRef frm As String) As Boolean
        Dim bolResult As Boolean = False
        Try
            For Each f As Form In System.Windows.Forms.Application.OpenForms
                If f.Name = frm Then
                    frm = Nothing
                    f.Focus()
                    f.WindowState = FormWindowState.Maximized
                    bolResult = True
                    Exit For
                End If
            Next
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try

        Return bolResult
    End Function

    Private Sub MostrarForma(ByVal logFocus As Boolean, ByRef frm As Form)
        If logFocus = False Then
            frm.MdiParent = Fprincipal
            frm.Show()
        Else
            frm.Focus()
        End If
    End Sub

    Public Function MostrarFormulario(ByVal strForm As String, ByRef FromParent As Form, Optional ByVal LogFocus As Boolean = False) As Boolean
        MostrarFormulario = False
        Dim frm As Object = Nothing
        Try
            Select Case strForm
                Case "rpt_Mass_Balance"
                    Dim spo As New clsReportes
                    spo.Mass_Balance()
                    Exit Function
                Case "Rpt_DocumentosCajaChica"
                    Dim spo As New clsReportes
                    spo.ReporteDocumetosCajaChica()
                    Exit Function
                Case "Rpt_SaldoPOPlantas"
                    Dim spo As New clsReportes
                    spo.Saldos_PO_Plantas()
                    Exit Function
                Case "frm_insumos"
                    frm = New frm_insumos
                    frm.key = strForm
                Case "RptContenedores"
                    Dim rptCont As New clsReportes
                    rptCont.RptContenedores()
                    Exit Function
                Case "Rpt_PacasReporte"
                    Dim rptPacasReporte As New clsReportes
                    rptPacasReporte.CargarPacasProduccion()
                    Exit Function
                Case "frmDepreciacion"
                    frm = New frmDepreciacion1
                    frm.key = strForm
                Case "frmAUnidades"
                    frm = New frmActivosUnidades
                    frm.key = strForm
                Case "frmDescargoConsumibles"
                    frm = New frmDescargoConsumibles
                    frm.key = strForm
                Case "frmnavieras"
                    frm = New frmnavieras
                    frm.key = strForm
                Case "Rpt_Certificado"
                    Dim rptCertificaciones As New clsReportes
                    rptCertificaciones.ReporteCertificado()
                    Exit Function
                Case "frmPedidoPHilo"
                    frm = New frmPedidoProduccionHilo
                    frm.key = strForm
                Case "Rpt_NotaC2"
                    Dim rpt_NotaCredito2 As New clsReportes
                    rpt_NotaCredito2.ReporteNotaDeCredito2()
                    Exit Function
                Case "Rpt_AsiaWeek"
                    Dim RptAsia As New clsReportesCorporativos
                    Dim intTipoReport As Integer = 20
                    RptAsia.SincronizarReportesCorp(intTipoReport)
                    Exit Function
                Case "Rpt_Inventory"
                    Dim rpt_Inventory As New clsReportes
                    rpt_Inventory.ReporteInventoryCost()
                    Exit Function
                Case "Rpt_InventarioTransitoC"
                    Dim corp As New clsReportesCorporativos
                    Dim intTipoReport As Integer = 19
                    corp.SincronizarReportesCorp(intTipoReport)
                    Exit Function
                Case "Rpt_CombinedBalanceC"
                    Dim corp As New clsReportesCorporativos
                    Dim intTipoReport As Integer = 21
                    corp.SincronizarReportesCorp(intTipoReport)
                    Exit Function
                Case "Rpt_CombinedPL"
                    Dim corp As New clsReportesCorporativos
                    Dim intTipoReport As Integer = 22
                    corp.SincronizarReportesCorp(intTipoReport)
                    Exit Function
                Case "Rpt_Nomenclatura"
                    Dim rpt_nom As New clsReportes
                    rpt_nom.ImprimirNomenclatura()
                    Exit Function

                Case "frmGastoProduccion"
                    frm = New frmGastoProduccion
                    frm.key = strForm
                Case "frm_programas1"
                    frm = New frm_programas1
                    frm.key = strForm
                Case "Rpt_RetencionIVA"
                    Dim rpt_RetencionIva As New clsReportes
                    rpt_RetencionIva.ReporteRetencionesIVA()
                    Exit Function
                Case "Rpt_RetencionISR"
                    Dim rpt_RetencionISR As New clsReportes
                    rpt_RetencionISR.ReporteRetencionesISR()
                    Exit Function
                Case "Rpt_InvoiceFiber"
                    Dim rpt_InvoiceFiber As New clsReportes
                    rpt_InvoiceFiber.InvoiceFiber()
                    Exit Function
                Case "Rpt_OpenFiber"
                    Dim rpt_Openfiber As New clsReportes
                    rpt_Openfiber.OpenPosFibra()
                    Exit Function
                Case "Rpt_CreditLimit"
                    Dim rptInbentario As New clsReportesCorporativos
                    Dim intTipoReport As Integer = 18
                    rptInbentario.SincronizarReportesCorp(intTipoReport)
                    Exit Function
                Case "frmInstFibra"
                    frm = New frmInstDespachoFibra
                    frm.key = strForm
                Case "frmPedidosFibra"
                    frm = New frmPedidoFibra
                    frm.key = strForm
                Case "Rpt_Proforma"
                    Dim rpt_Proforma As New clsReportes
                    rpt_Proforma.ReporteProforma()
                    Exit Function
                Case "Rpt_BalanceMiami"
                    Dim rpt_BMiami As New clsReportes
                    rpt_BMiami.BalanceReport()
                    Exit Function
                Case "Rpt_EResultadoMiami"
                    Dim rpt_BMiami As New clsReportes
                    rpt_BMiami.EResultadoReport()
                    Exit Function
                Case "Rpt_NCProvAbierta"
                    Dim rpt_NotaCreditoProvAb As New clsReportes
                    rpt_NotaCreditoProvAb.ReporteNotaProveedorAbierta()
                    Exit Function
                Case "Rpt_LCReport"
                    Dim rpt_LCReport As New clsReportes
                    rpt_LCReport.ReportLC()
                    Exit Function
                Case "Rpt_NotasCProv"
                    Dim rpt_NotaCredito As New clsReportes
                    rpt_NotaCredito.ReporteNotaDeCreditoProv()
                    Exit Function
                Case "frmFCertificacion"
                    frm = New frmCertificacion
                    frm.key = strForm
                Case "frmCartaCredito"
                    frm = New frmCartaCreditoNet
                    frm.key = strForm
                Case "Rpt_VentasxCliente"
                    Dim corp As New clsReportesCorporativos
                    Dim intTipoReport As Integer = 17
                    corp.SincronizarReportesCorp(intTipoReport)
                    Exit Function
                Case "Rpt_InventarioTransito"
                    Dim invTransito As New clsReportes
                    invTransito.ReporteEnTransito()
                    Exit Function
                Case "Rpt_ARDetail"
                    Dim corp As New clsReportesCorporativos
                    Dim intTipoReport As Integer = 16
                    corp.SincronizarReportesCorp(intTipoReport)
                    Exit Function
                Case "Rpt_SemestralSAT"
                    Dim rpt As New clsReportes
                    rpt.ReporteSemestralSAT()
                    Exit Function
                Case "Rpt_InspeccíonSalidas"
                    Dim rpt As New clsReportes
                    rpt.ReporteInspeccionSalidas(STR_VACIO, 1)
                    Exit Function
                Case "Rpt_Movimiento"
                    Dim rpt As New clsReportes
                    rpt.MovimientoDeInventario()
                    Exit Function
                Case "Rpt_AnticipoVentas"
                    Dim rpt As New clsReportes
                    rpt.AnticipoVentas()
                    Exit Function
                Case "rptVentasConsignaciones"
                    Dim rpt As New clsReportes
                    rpt.ReporteDeVentasConsignaciones()
                    Exit Function
                Case "rptEstadoCtaMask"
                    Dim rpt As New clsReportes
                    rpt.ReporteEstadoCuenta_Mascarillas()
                    Exit Function
                Case "rptEstadoCtaConsignacion"
                    Dim rpt As New clsReportes
                    rpt.ReporteEstadoCuenta_Consignaciones()
                    Exit Function
                Case "rptInventarioConsignacion"
                    Dim rpt As New clsReportes
                    rpt.InventarioConsignaciones()
                    Exit Function
                Case "rptGastosMascarillas"
                    Dim rpt As New clsReportes
                    rpt.ReporteDeGastosMascarillas()
                    Exit Function
                Case "rptSalesMask"
                    Dim rpt As New clsReportes
                    rpt.VentasMascarillas()
                    Exit Function
                Case "frmFacturacionMascarillas"
                    frm = New frmFacturacionMascarillas
                    frm.key = strForm
                Case "rptInventarioMask"
                    Dim rpt As New clsReportes
                    rpt.InventarioMascarillas()
                    Exit Function
                Case "frmProductosMascarillas"
                    frm = New frmProductosMask
                    frm.key = strForm
                Case "rptTareasDeAuditoria"
                    Dim rpt As New clsReportes
                    rpt.TareasPendientesDeAuditoria()
                    Exit Function
                Case "frmPagarDespachos"
                    frm = New frmPagarDespachos
                    frm.key = strForm
                Case "rptOpenDO"
                    Dim rpt As New clsReportes
                    rpt.OpenIvoiceDD()
                    Exit Function
                Case "rptInventarioFibra"
                    Dim rptInventarioFibra As New clsReportes
                    rptInventarioFibra.ReporteGeneralDeInventarioFibra()
                    Exit Function
                Case "frmDespachoDirecto"
                    frm = New frmDespachoDirecto
                    frm.key = strForm
                Case "rptDespachoDirecto"
                    Dim rpt As New clsReportes
                    rpt.DespachosDirectos()
                    Exit Function
                Case "rptMantenimientos"
                    Dim rpt As New clsReportes
                    rpt.ReporteManteminientos()
                    Exit Function
                Case "frmMantenimientos"
                    frm = New frmMantenimientos
                    frm.key = strForm
                Case "Rpt_BackupControl"
                    Dim rpt As New clsReportes
                    rpt.BackupControl()
                    Exit Function
                Case "frmBackup"
                    frm = New frmBackup
                    frm.key = strForm
                Case "Rpt_CartaIT"
                    Dim rptCartaResponsabilidad As New clsReportes
                    rptCartaResponsabilidad.ReporteCartaResponsabilidadIT()
                    Exit Function
                Case "frmInventarioIT"
                    frm = New frmInventarioIT
                    frm.key = strForm
                Case "frmActualizador"
                    frm = New frmActualizacionSGI
                    frm.key = strForm
                Case "Rpt_PresupuestoCorp"
                    Dim corp As New clsReportesCorporativos
                    Dim intTipoReport As Integer = 15
                    corp.SincronizarReportesCorp(intTipoReport)
                    Exit Function
                Case "frmABienes"
                    frm = New frmActivosFijos
                    frm.key = strForm
                Case "Rpt_Presupuesto"
                    Dim rpt As New clsReportes
                    rpt.ReportesPresupuesto()
                    Exit Function
                Case "frmABienes"
                    frm = New frmActivosFijos
                    frm.key = strForm
                Case "frmATipos"
                    frm = New frmTipoActivos
                    frm.key = strForm
                Case "Rpt_GastosI"
                    Dim rptGastosI As New clsReportes
                    rptGastosI.ReporteGastosImportacion()
                    Exit Function
                Case "frmContrasena"
                    frm = New frmContraseña
                    frm.key = strForm
                Case "frmGastosIM"
                    frm = New frmGastosIM
                    frm.key = strForm
                Case "frmAnticiposClientes"
                    frm = New frmAnticiposClientes
                    frm.key = strForm
                Case "RptPurchesCorp"
                    Dim rptInbentario As New clsReportesCorporativos
                    Dim intTipoReport As Integer = 14
                    rptInbentario.SincronizarReportesCorp(intTipoReport)
                    Exit Function
                Case "RptProjectM"
                    Dim rptProjectoMercado As New clsReportes
                    rptProjectoMercado.ReporteProyectoMercadeo()
                    Exit Function
                Case "frmCierreMensual"
                    frm = New frmCierreMensual
                    frm.key = strForm
                Case "frmAnticipos"
                    frm = New frmAnticipos
                    frm.key = strForm
                Case "frmCategoriaMercadeo"
                    frm = New frmCategoriaMercadeo
                    frm.key = strForm
                Case "RptInventoryCorp"
                    Dim rptInbentario As New clsReportesCorporativos
                    Dim intTipoReport As Integer = 13
                    rptInbentario.SincronizarReportesCorp(intTipoReport)
                    Exit Function
                Case "frmNCostos"
                    frm = New frmCentrosCostos
                    frm.key = strForm
                Case "Rpt_CajaChica"
                    Dim rptCajaChica As New clsReportes
                    rptCajaChica.ReporteCajaChica()
                    Exit Function
                Case "frmDRetencionISR"
                    frm = New frmRetenISRCliente
                    frm.Key = strForm
                Case "frmDRetencionIVA"
                    frm = New frmRetenIVACliente
                    frm.Key = strForm
                Case "Rpt_ResumenAMIGO"
                    Dim rptAmigoR As New clsReportes
                    rptAmigoR.ReporteResumenAMIGO()
                    Exit Function
                Case "Rpt_EstadoDeResultados"
                    Dim EstadoResultados As New clsReportes
                    EstadoResultados.ReporteEstadoDeResultados()
                    Exit Function
                Case "Rpt_BalanceGeneral"
                    Dim BalanceGeneral As New clsReportes
                    BalanceGeneral.ReporteBalanceGeneral()
                    Exit Function
                Case "Rpt_LibroMayor"
                    Dim LibroMayor As New clsReportes
                    LibroMayor.ReporteLibroMayor()
                    Exit Function
                Case "Rpt_LibroDiario"
                    Dim LibroDiario As New clsReportes
                    LibroDiario.ReporteLibroDiario()
                    Exit Function
                Case "RptInventarioHistorico"
                    Dim rpthistorico As New clsReportesCorporativos
                    Dim intTipoReport As Integer = 12
                    rpthistorico.SincronizarReportesCorp(intTipoReport)
                    Exit Function
                Case "frmNDebito"
                    frm = New frmNDebito
                    frm.key = strForm
                Case "Rpt_Amigo"
                    Dim rptAmigo As New clsReportes
                    rptAmigo.ReporteAmigo()
                    Exit Function
                Case "Rpt_CierreApertura"
                    Dim conta As New clsContabilidad
                    conta.CierresyAperturas()
                    Exit Function
                Case "Rpt_NotasD"
                    Dim Debito As New clsReportes
                    Debito.ReporteDeNotas(32)
                    Exit Function
                Case "Rpt_InsEntradas"
                    Dim rptIns As New clsReportes
                    rptIns.ReporteInspeccionDeEntradas()
                    Exit Function
                Case "Frm02_Cuentas"
                    frm = New frmNomenclatura
                    frm.key = strForm
                Case "frmADepreciar"
                    frm = New frmDepreciacion
                    frm.Key = strForm
                Case "RptOrdProveedor"
                    Dim ordProveedor As New clsReportesCorporativos
                    Dim intTipoReport As Integer = 9
                    ordProveedor.SincronizarReportesCorp(intTipoReport)
                    Exit Function
                Case "RptUsaInventoryCorp"
                    Dim ordProveedor As New clsReportesCorporativos
                    Dim intTipoReport As Integer = 11
                    ordProveedor.SincronizarReportesCorp(intTipoReport)
                    Exit Function
                Case "Rpt_InventarioCorp"
                    Dim ordProveedor As New clsReportesCorporativos
                    Dim intTipoReport As Integer = 10
                    ordProveedor.SincronizarReportesCorp(intTipoReport)
                    Exit Function
                Case "RptCxpCorp"
                    Dim cxp As New clsReportesCorporativos
                    Dim intTipoReport As Integer = 4
                    cxp.SincronizarReportesCorp(intTipoReport)
                    Exit Function
                Case "Rpt_AccountPayable"
                    Dim rpt_Account As New clsReportes
                    rpt_Account.CxpMiami()
                    Exit Function

                Case "Rpt_USAInventory"
                    Dim rpt As New clsReportes
                    rpt.USAInventoryReport()
                    Exit Function
                Case "Rpt_VentasCorp"
                    Dim ventas As New clsReportesCorporativos
                    Dim intTipoReport As Integer = 7
                    ventas.SincronizarReportesCorp(intTipoReport)
                    Exit Function
                Case "Rpt_GrossCorp"
                    Dim gross As New clsReportesCorporativos
                    Dim intTipoReport As Integer = 8
                    gross.SincronizarReportesCorp(intTipoReport)
                    Exit Function
                Case "frmRegularTasa"
                    frm = New frmRegularTasa
                    frm.key = strForm
                Case "frmGeneradorPolizas"
                    frm = New GeneradorDePolizas
                    frm.key = strForm

                Case "Rpt_OpenInvoiceCCF"
                    Dim rptCCF As New clsReportes
                    rptCCF.OpenInvoiceCCF()
                    Exit Function
                Case "Rpt_CheckReportCorp"
                    Dim Planning As New clsReportesCorporativos
                    Dim intTipoReport As Integer = 6
                    Planning.SincronizarReportesCorp(intTipoReport)
                    Exit Function
                Case "Rpt_Collected"
                    Dim Planning As New clsReportes
                    Dim frm2 As New frmFiltro
                    frmFiltro.key = strForm
                    frm2.BanderaFechas = True
                    frm2.ShowDialog()
                    If frm2.DialogResult = System.Windows.Forms.DialogResult.OK Then
                        Planning.CheckReportCMC(frm2.FechaInicio, frm2.FechaFin)
                    End If

                    Exit Function
                Case "Rpt_SalesByCustomer"
                    Dim rpt_LImpor As New clsReportes
                    rpt_LImpor.VentasSemanalesxCliente()
                    Exit Function
                Case "Rpt_SalesByYarn"
                    Dim rpt_LImpor As New clsReportes
                    rpt_LImpor.VentasSemanalesxProducto()
                    Exit Function
                Case "Rpt_Transito"
                    Dim Rpt_Transito As New clsReportes
                    Rpt_Transito.ReporteTransito()
                    Exit Function
                Case "frmTraslado"
                    frm = New frmTraslado
                    frm.key = strForm
                Case "Rpt_Rampa"
                    Dim Contenedores As New clsReportes
                    Contenedores.ReporteDeRampa()
                    Exit Function
                Case "frmCR"
                    frm = New FrmCargoReceipt
                    frm.key = strForm
                Case "frmDN"
                    frm = New frmDebiteNote
                    frm.Key = strForm
                Case "Rpt_CxC"
                    Dim rpt As New clsReportes
                    rpt.EstadoCuentaCliente()
                    Exit Function
                Case "Rpt_LibroImport"
                    Dim rpt_LImpor As New clsReportes
                    rpt_LImpor.LibroDeImportacionesYarn()
                    Exit Function
                Case "Rpt_OpenPOs"
                    Dim rpt_OpenPOS As New clsReportes
                    rpt_OpenPOS.OpenPOs()
                    Exit Function
                Case "frmRetencionesIVA"
                    frm = New frmRetenIVAProveedor
                    frm.Key = strForm
                Case "frmDRetenciones"
                    frm = New frmRetenISRProveedor
                    frm.Key = strForm
                Case "Rpt_Margin"
                    Dim crp As New clsReportes
                    crp.GrossMargin()
                    Exit Function
                Case "PymeResultado"
                    Dim pyme As New clsPymes
                    pyme.EstadoDeResultadosPyme()
                    Exit Function
                Case "Pyme_Balance"
                    Dim pyme As New clsPymes
                    pyme.BlancePyme()
                    Exit Function
                Case "Rpt_PlanningCorp"
                    Dim Planning As New clsReportesCorporativos
                    Dim intTipoReport As Integer = 5
                    Planning.SincronizarReportesCorp(intTipoReport)
                    Exit Function
                Case "Rpt_LibroCompras"
                    frm = New frmLibroComprasgt
                    frm.key = strForm
                Case "Rpt_GFase"
                    Dim rpt_GFase As New clsReportes
                    rpt_GFase.ReporteGFase()
                    Exit Function
                Case "Rpt_CuadDem"
                    Dim rpt_Rcheck As New clsReportes
                    rpt_Rcheck.rptCuadroDemostrativoDescargos()
                    Exit Function

                Case "Rpt_LbVenContr"
                    Dim rpt_Rcheck As New clsReportes
                    rpt_Rcheck.rptLibrsoIvaDebito()
                    Exit Function

                Case "Rpt_NotasC"
                    Dim rpt_NotaCredito As New clsReportes
                    rpt_NotaCredito.ReporteNotaDeCredito()
                    Exit Function

                Case "Rpt_InvProdTrm"
                    Dim rpt_Rcheck As New clsReportes
                    rpt_Rcheck.rptInventarioProductoTerminado()
                    Exit Function

                Case "Rpt_FactSinYRM"
                    Dim rpt_Rcheck As New clsReportes
                    rpt_Rcheck.ReporteFacturaSinYRM()
                    Exit Function
                Case "frmNotasCreditoProveedor"
                    frm = New frmNotasCreditoProveedor
                    frm.key = strForm

                Case "Rpt_Diferencia"
                    Dim rpt_Rcheck As New clsReportes
                    rpt_Rcheck.DiferenciaDePrecios()
                    Exit Function

                Case "Rpt_RCheck"
                    Dim rpt_Rcheck As New clsReportes
                    rpt_Rcheck.ReporteCheckReport2()
                    Exit Function


                Case "Rpt_BillCorporate"
                    Dim OpenBill As New clsReportesCorporativos
                    Dim intTipoReport As Integer = 4
                    OpenBill.SincronizarReportesCorp(intTipoReport)
                    Exit Function


                Case "Rpt_AccountPayable"
                    Dim rpt_Account As New clsReportes
                    rpt_Account.ReporteAccountPayable()
                    Exit Function

                Case "frmBloqueo"
                    frm = New FrmBloqueo
                    frm.key = strForm

                Case "Rpt_InventarioFibraHSM"
                    Dim rpt As New clsReportes
                    rpt.InventarioFibraHSM()
                    Exit Function

                Case "Rtp_ProdPlan"
                    Dim Exportacion As New clsReportes
                    Exportacion.ProductionPlan()
                    Exit Function

                Case "Rpt_LibroImportHSM"
                    Dim LibroHSM As New clsReportes
                    LibroHSM.HSMLibroImportacion()
                    Exit Function

                Case "Rpt_LibroExport"
                    Dim Exportacion As New clsReportes
                    Exportacion.LibroDeExportaciones()
                    Exit Function

                Case "Rpt_Saldos"
                    Dim CXC As New clsReportes
                    CXC.ReporteCxC()
                    Exit Function

                Case "Rpt_Compras"
                    Dim ReporteEstadoProveedor As New clsReportes
                    ReporteEstadoProveedor.ReporteDeSaldosDeCompras()
                    Exit Function

                Case "Rpt_SaldoDeCompras"
                    Dim PorPAgar As New clsReportes
                    PorPAgar.ReporteCxP()
                    Exit Function

                Case "Rpt_BalanceSheet"
                    Dim Loss As New clsReportes
                    Loss.BalanceSheet()
                    Exit Function

                Case "Rpt_Profit"
                    Dim Loss As New clsReportes
                    Loss.ProfitLoss()
                    Exit Function

                Case "Rpt_VendorDetail"
                    Dim VendorD As New clsReportes
                    VendorD.PurcharsesVendorDetail()
                    Exit Function
                Case "Rpt_TransactionsA"
                    Dim TransaccionA As New clsReportes
                    TransaccionA.TransactionAccount()
                    Exit Function
                Case "Rpt_AgingSummary"
                    Dim Again As New clsReportes
                    Again.AgingSummary()
                    Exit Function

                Case "Rpt_Sincronizacion" ' Open Invoice
                    Dim sincronizar As New clsReportesCorporativos
                    Dim intTipoReport As Integer = 1
                    sincronizar.SincronizarReportesCorp(intTipoReport)
                    Exit Function

                Case "Rpt_AR_AgingCorp"
                    Dim sincronizar As New clsReportesCorporativos
                    Dim intTipoReport As Integer = 3
                    sincronizar.SincronizarReportesCorp(intTipoReport)
                    Exit Function

                Case "Rpt_CustomerDetail"
                    Dim SalesBy As New clsReportes
                    SalesBy.SalesByAccount()
                    Exit Function

                Case "Rpt_YMRs"
                    Dim Movement As New clsReportes
                    Movement.ReporteYMR()
                    Exit Function

                Case "frm_InventoryR"
                    frm = New FrmInventario
                    frm.key = strForm

                Case "frm_LibroComprasM"
                    frm = New FrmCompras
                    frm.key = strForm

                Case "Rpt_Compras"
                    Dim ReporteEstadoProveedor As New clsReportes
                    ReporteEstadoProveedor.ReporteDeSaldosDeCompras()
                    Exit Function

                Case "Rpt_Compras_SV"
                    Dim ReporteEstadoProveedor As New clsReportes
                    ReporteEstadoProveedor.ReporteDeSaldosDeCompras_sv()
                    Exit Function
                Case "Rpt_LibroVentas"
                    Dim LibroVentas As New clsReportes
                    LibroVentas.ReporteLibroVentas()
                    Exit Function

                Case "frmMargen"
                    frm = New frmMargen
                    frm.Key = strForm

                Case "rpt_ResponseReport"
                    Dim checkReport As New clsReportes
                    checkReport.ReporteCheckReport()
                    Exit Function

                Case "Rpt_VentasHN"
                    Dim creporte As New clsReportes
                    creporte.LibroVentasHN()
                    Exit Function

                Case "rpt_ProyectReport"
                    Dim workFLow As New clsReportes
                    workFLow.ReporteProyectoNancy()
                    Exit Function

                Case "frmPanelG"
                    frm = New frmPanelG
                    frm.key = strForm

                Case "frmGrupos"
                    frm = New frmGrupos
                    frm.Key = strForm

                Case "rptImportacionPrideYarn"
                    Dim creporte As New clsReportes
                    creporte.rptImportacionPrideYarn()
                    Exit Function

                Case "rptExportacionPrideYarn"
                    Dim creporte As New clsReportes
                    creporte.rptExportacionPrideYarn()
                    Exit Function
                Case "Rpt_Librodecompras"
                    Dim creporte As New clsReportes
                    creporte.LibroComprasHonduras()
                    Exit Function

                    'Case "rptImportacionPrideYarnL"
                    '    Dim creporte As New clsReportes
                    '    creporte.rptImportacionPrideYarnL()
                    '    Exit Function
                Case "Rpt_tiemposporusuario"
                    Dim creporte As New clsReportes
                    creporte.TiempoporUsuario()
                    Exit Function
                Case "Rpt_Tareapendientes"
                    Dim creporte As New clsReportes
                    creporte.tareaspendientes()
                    Exit Function
                    'Case "rptExportacionPrideYarnL"
                    '    Dim creporte As New clsReportes
                    '    creporte.rptExportacionPrideYarnL()
                    '    Exit Function
                Case "Rpt_GeneralOpenBalance"
                    Dim creporte As New clsReportes
                    creporte.ReporteGeneralOpenBalance()
                    Exit Function
                Case "RptBodega"
                    Dim Reportes As New clsReportes
                    Reportes.Reportes()
                    Exit Function
                Case "Rpt_VentasIngreso"
                    Dim Ingreso As New clsReportes
                    Ingreso.VentasIngreso()
                    Exit Function
                Case "Rpt_InvAntiguedad"
                    Dim Antiguedad As New clsReportes
                    Antiguedad.SeleccionarTipoReporte()
                    Exit Function

                Case "Rpt_InvXProd"
                    Dim Producto As New clsReportes
                    Producto.ReporteInventarioPorProducto()
                    Exit Function
                Case "RptGastosPorCC"
                    Dim creporte As New clsReportes
                    creporte.RptGastosPorCCostos()
                    Exit Function
                Case "Rpt_Costodpt"
                    Dim CostoDept As New clsReportes
                    CostoDept.ReporteCostos()
                    Exit Function
                Case "Rpt_SergioLeon"
                    Dim Reporte As New clsReportes
                    Reporte.ReporteSergio()
                    Exit Function
                Case "frmDevoluciones"
                    frm = New frmDevoluciones
                    frm.Key = strForm
                Case "frmGastos"
                    frm = New frmGastos
                    frm.Key = strForm
                Case "frmProyecto"
                    frm = New frmProyecto
                    frm.Key = strForm

                Case "Rpt_CCReferencia"
                    Dim CuentaReferencia As New clsReportes
                    CuentaReferencia.CuentaCorrienteReferencia(frmReporteCuentaCorrienteReferencia)
                    Exit Function
                Case "Rpt_Inventarios"
                    Dim Inventario As New clsReportes
                    Inventario.ReporteGeneralDeInventario()
                    Exit Function
                Case "Rpt_ResInventario"
                    Dim Resumen As New clsReportes
                    Resumen.ResumenDeInventario()
                    Exit Function
                Case "Rpt_Reservado"
                    Dim InventarioReserva As New clsReportes
                    InventarioReserva.ReporteDeReservas()
                    Exit Function
                Case "Rpt_DocsCltes"
                    Dim ClientePedidos As New clsReportes
                    ClientePedidos.PedidoClientes()
                    Exit Function
                Case "Rpt_Ordenes"
                    Dim OrdenesCompra As New clsReportes
                    OrdenesCompra.OrdenesDeCompra()
                    Exit Function
                Case "Rpt_OrdenesCompraNSM"
                    Dim OrdenesCompraNSM As New clsReportes
                    OrdenesCompraNSM.OC_ConsumiblesNSM()
                    Exit Function
                Case "Rpt_CostoInventario"
                    Dim Inventario As New clsReportes
                    Inventario.ReporteCostoDeInventario()
                    Exit Function
                Case "Rpt_TomaInv"
                    Dim Physical As New clsReportes
                    Physical.ReporteTomaDeInventario()
                    Exit Function
                Case "Rpt_Reexports"
                    Dim ReExportacion As New clsReportes
                    ReExportacion.ReporteDevoluciones()
                    Exit Function
                Case "Rpt_USAAvailable"
                    Dim Available As New clsReportes
                    Available.ReporteDisponibleUSA()
                    Exit Function
                Case "Rpt_Contenedores"
                    Dim Contenedor As New clsReportes
                    Contenedor.ReporteDeContenedores()
                    Exit Function
                Case "Rpt_IngresoFabricante"
                    Dim Fabricante As New clsReportes
                    Fabricante.ReporteIngresoPorFabricante()
                    Exit Function
                Case "Rpt_OrdenRevisar"
                    Dim Ordenes As New clsReportes
                    Ordenes.OrdenesNoDescargas()
                    Exit Function
                Case "Rpt_Facturas"
                    Dim DetalleFacturas As New clsReportes
                    DetalleFacturas.ReporteDetalleDeFacturas()
                    Exit Function

                Case "Rpt_FacturaCreditoFiscal"
                    Dim DetalleFacturas As New clsReportes
                    DetalleFacturas.ReporteFacturaCreditoFiscal()
                    Exit Function

                Case "frmPanelControl"
                    frm = New frmPanelControl
                    frm.key = strForm
                Case "frmProcesos"
                    frm = New frmProcesses
                    frm.Key = strForm

                Case "frmFlujos"
                    frm = New frmFlujos
                    frm.Key = strForm

                Case "frmDFacturaCobro"
                    frm = New frmFacturaIva
                    frm.Key = strForm
                Case "frmCuentasIncobrables"
                    frm = New frmCuentasIncobrables
                    frm.Key = strForm
                Case "Frm15_Mercaderias"
                    frm = New frmProductos
                    frm.Key = strForm
                Case "frmDevoluciones"
                    frm = New frmDevoluciones
                    frm.Key = strForm
                Case "Rpt_InvXDia"
                    Dim creporte As New clsReportes
                    creporte.ReporteInventarioXSemana()
                    Exit Function
                Case "Frm19_Desaduanaje"
                    frm = New frmPolizaImportacion
                    frm.Key = strForm
                Case "Frm22_PolExp"
                    frm = New frmPolizaExportacion
                    frm.Key = strForm
                Case "frmNCredito"
                    frm = New frmNotasDeCredito
                    frm.Key = strForm
                Case "Frm20_IngBodega"
                    frm = New frmIngresoBodega
                    frm.Key = strForm
                Case "Frm_GruposVentas"
                    frm = New frmEquiposVentas
                    frm.Key = strForm
                'Case "Rpt_Facturas"
                '    Dim creporte As New clsReportes
                '    creporte.ReporteDetalleFacturacion()
                '    Exit Function
                Case "Frm_FacturasCredFiscal"
                    frm = New frmFacturacionCredFiscal
                    frm.Key = strForm
                Case "frmPolizasConta"
                    frm = New frmNPolizasContables
                    frm.Key = strForm
                Case "Frm21_EgrBodega"
                    frm = New frmInstDespacho
                    frm.Key = strForm
                Case "Frm22_FacturasCltes"
                    frm = New frmFacturacion
                    frm.Key = strForm
                Case "Frm18_ImpEmbarques"
                    frm = New frmConfirmacion
                    frm.Key = strForm
                Case "Frm16_PedidosCltes"
                    frm = New frmPedidosClient_proforma_
                    frm.Key = strForm
                Case "frmCCredito"
                    frm = New frmCartaCredito
                    frm.Key = strForm
                Case "frmContrato"
                    frm = New frmContrato_PM_
                    frm.Key = strForm
                Case "Frm15_Inventarios"
                    frm = New frmCodigosInventario
                    frm.Key = strForm
                Case "Frm13_Clientes"
                    frm = frmClientes
                    frm.Key = strForm
                Case "frmGCajas"
                    frm = New frmCajaChica
                    frm.Key = strForm
                Case "Frm14_Proveedores"
                    frm = New frmProveedores
                    frm.Key = strForm
                Case "frmPCentros"
                    frm = frmPCentros
                    frm.key = strForm
                Case "Frm27_Departamentos"
                    frm = New frmPDepartamentos
                    frm.key = strForm
                Case "frmPPuestos"
                    frm = New frmPPuestos
                    frm.key = strForm
                Case "frmPEmpleados"
                    frm = New frmPEmpleados
                    frm.key = strForm
                Case "frmPContrato"
                    frm = New frmPContratos
                    frm.key = strForm
                Case "frmDummy" : frm = frmMigracionNomenclatura
                    frm.key = strForm
                Case "frmPagare"
                    frm = New frmPagare
                    frm.key = strForm
                Case "frmCertificadoOrigen"
                    frm = New frmCerificadoOrigen
                    frm.key = strForm
                Case "frmTransferencias"
                    frm = New frmTransferencias
                    frm.Key = strForm
                Case "frmPPlanilla"
                    frm = frmPPlanilla
                    frm.key = strForm
                Case "frmDepurar"
                    frm = New frmDepurar
                    frm.key = strForm
                Case "rpt_CMC-Pretexsa"
                    Dim frm2 As New frmFiltro
                    Dim cReportes As New clsReportes
                    frmFiltro.key = strForm
                    frm2.BanderaFechas = True
                    frm2.ShowDialog()
                    If frm2.DialogResult = System.Windows.Forms.DialogResult.OK Then
                        cReportes.GenerarRseporteCMC(frm2.FechaInicio, frm2.FechaFin, frm2.SelFiltro, frmSPrincipal)
                    End If
                    Exit Function
                Case "frmOrdenCompra"
                    frm = New frmOrdenCompra
                    frm.Key = strForm

                Case "frmBlowRoom"
                    frm = New frmProduccion
                    frm.Key = strForm & INT_UNO
                    frm.NumProceso = INT_UNO
                Case "frmCardado"
                    frm = New frmProduccion
                    frm.Key = strForm & 2
                    frm.NumProceso = 2
                Case "frmPeinado"
                    frm = New frmProduccion
                    frm.Key = strForm & 3
                    frm.NumProceso = 3
                Case "frmDrawing"
                    frm = New frmProduccion
                    frm.Key = strForm & 4
                    frm.NumProceso = 4
                Case "frmSimplex"
                    frm = New frmProduccion
                    frm.Key = strForm & 5
                    frm.NumProceso = 5
                Case "frmRings"
                    frm = New frmProduccion
                    frm.Key = strForm & 6
                    frm.NumProceso = 6
                Case "frmAutocone"
                    frm = New frmProduccion
                    frm.Key = strForm & 7
                    frm.NumProceso = 7
                Case "frmPacking"
                    frm = New frmProduccion
                    frm.Key = strForm & 8
                    frm.NumProceso = 8

                Case "frmReclamos"
                    frm = New frmReclamos
                    frm.Key = strForm

                Case "frmCotizacion"
                    frm = New frmCotizacion
                    frm.key = strForm


                Case "frmDPresupuesto"
                    frm = New frmPresupuesto
                    frm.Key = strForm


                Case "frmClientes"
                    frm = New frmClientes
                    frm.Key = strForm

                Case "frmBCuenta"
                    frm = New frmBCuentas
                    frm.Key = strForm

                Case "Frm17_PedidosProvs"
                    frm = New frmOrdenRequisicion
                    frm.key = strForm

                Case "rpt_Rep_EEUU"
                    Dim creportes As New clsReportes
                    creportes.GenerarReporteEEUU()
                    Exit Function
                Case "Rpt_OpenInvoices"
                    Dim creportes As New clsReportes
                    creportes.GenerarReporteOpenInvoices()
                    Exit Function
                Case "Rpt_AccRecSch"
                    Dim creportes As New clsReportes
                    creportes.GenerarReporteAccountReceivable("Rpt_AccRecSch")
                    Exit Function
                Case "Rpt_CRCxC"
                    Dim creportes As New clsReportes
                    creportes.GenerarReporteCargoReceipLC()
                    Exit Function
                Case "Rpt_FactPendientes"
                    Dim creportes As New clsReportes
                    creportes.GenerarInstruccionesPendientes()
                    Exit Function
                Case "frmYM"
                    frm = New frmYarnMovementV
                    frm.key = strForm
                Case "rptInstruccionsDiarias"
                    Dim creportes As New clsReportes
                    creportes.ReportInstruccionesDiarias()
                    Exit Function
                Case "rptReporteNancy"
                    Dim creporte As New clsReportes
                    creporte.ReporteNancy()
                    Exit Function

                Case "rptEstadoResultado"
                    Dim creporte As New clsReportes
                    creporte.rptEstadoResultado()
                    Exit Function

                Case "Rpt_Summary"
                    Dim creporte As New clsReportes
                    creporte.ReporteSumaryYarns()
                    Exit Function

                Case "rptSalesProgram"
                    Dim creporte As New clsReportes
                    creporte.rptSalesProgram()
                    Exit Function

                Case "rptLibroPF"  ' Updates on customer orders (proforma) '
                    Dim PF As New clsReportes
                    PF.ReportePF()
                    Exit Function


                Case "Rpt_LibrodecomprasHNNN" 'Reporte 2 '
                    Dim LibroHonduras As New clsReportes
                    LibroHonduras.LibroComprasHonduras2()
                    Exit Function

                Case "frmAutorizacionCompra"
                    frm = New frmCotizacionAprobada
                    frm.key = strForm


                Case "frmCompraSolicitada"
                    frm = New frmCompraSolicitada
                    frm.key = strForm




                    'PROCESO DE PRODUCCION****************************************************
                Case "frmProduccionF1"
                    frm = New frmProduccionNSM
                    frm.Key = strForm
                Case "frmProduccionF2"
                    frm = New frmTendidos
                    frm.Key = strForm '& 2
                    'frm.NumProceso = 2
                Case "frmEstimacion"
                    frm = New frmEstimacion
                    frm.Key = strForm


                Case "frmPFactura"
                    frm = New frmFacturaCompra
                    frm.Key = strForm







                    '***************************Autorizacion y Compra autorizada

                Case "frmAutorizacionCompra"
                    frm = New frmCotizacionAprobada
                    frm.key = strForm
                Case "frmCompraSolicitada"
                    frm = New frmCompraSolicitada
                    frm.key = strForm



                    '*******************Reporte Inventario Por Producto*****************

                Case "Rpt_InventarioProducto"
                    Dim ReporteInventario As New clsReportes
                    ReporteInventario.InventarioProducto()
                    Exit Function

                Case "Rpt_DiarioMayorGeneral"
                    Dim creporte As New clsReportes
                    creporte.ReporteDiarioMayorGeneral()
                    Exit Function

                Case "Rpt_DMGAmtexSV"
                    Dim rpt As New clsReportes
                    rpt.ReporteDiarioMayorGeneralSV()
                    Exit Function

                Case "Rpt_DiagramaGannt"
                    Dim creporte As New clsReportes
                    creporte.ReporteDiagramaGannt()
                    Exit Function

                    '******Reporte Detalle Factura CMC**********
                Case "Rpt_DetalleFacturaCMC"
                    Dim rptDetalleFCMC As New clsReportes
                    rptDetalleFCMC.ReporteDetalleDeFacturasCMC()
                    Exit Function

                Case "frm_Presupuesto"
                    frm = New frmPresupuestoMes
                    frm.Key = strForm

                Case "Rpt_PresupuestoConsolidado"
                    Dim rptPresupuestoConsolidado As New clsReportes
                    rptPresupuestoConsolidado.GenerarReportePresupuestoConsolidado()
                    Exit Function
                Case "Rpt_PresupuestoConsolidadoCC"
                    Dim rptPresupuestoConsolidado As New clsReportes
                    rptPresupuestoConsolidado.GenerarReportePresupuestoConsolidadoCentroCosto()
                    Exit Function
                Case "Rpt_PresupuestoEjecutado"
                    Dim rptPresupuestoEjecutado As New clsReportes
                    rptPresupuestoEjecutado.GenerarReportePresupuestoEjecutado()
                    Exit Function
                Case "Rpt_PresupuestoEjecutadoCC"
                    Dim rptPresupuestoEjecutadoCC As New clsReportes
                    rptPresupuestoEjecutadoCC.GenerarReportePresupuestoEjecutadoCentroCosto()
                    Exit Function
                Case "Rpt_PresupuestoVsEjecutado"
                    Dim rptPresupuestoVsEjecutado As New clsReportes
                    rptPresupuestoVsEjecutado.GenerarReportePresupesto_vs_Ejecutado()
                    Exit Function
                Case "Rpt_PresupuestoVsEjecutadoCC"
                    Dim rptPresupuestoVsEjecutadoCC As New clsReportes
                    rptPresupuestoVsEjecutadoCC.GenerarReportePresupesto_vs_EjecutadoCC()
                    Exit Function
                Case "rptdmcReporte"
                    Dim creporte As New clsReportes
                    creporte.rptdmcReporte()
                    Exit Function
                Case "ReporteBaleReport2"
                    Dim rptReporte As New clsReportes
                    rptReporte.ReporteBaleReport2()
                    Exit Function
                Case "rpt_POConsumidas"
                    Dim creporte As New clsReportes
                    creporte.rpt_POConsumidas()
                    Exit Function
                Case "rpt_WasteResume"
                    Dim creporte As New clsReportes
                    creporte.rpt_Desperdicios()
                    Exit Function
                Case "rpt_OCE"
                    Dim creporte As New clsReportes
                    creporte.rpt_OCE()
                    Exit Function
                Case "rpt_Estado_OC"
                    Dim creporte As New clsReportes
                    creporte.rpt_Estado_OC()
                    Exit Function
                Case "rpt_kardex"
                    Dim creporte As New clsReportes
                    creporte.rpt_Kardex()
                    Exit Function
                Case "rpt_kardex_2_0"
                    Dim creporte As New clsReportes
                    creporte.rpt_Kardex2()
                    Exit Function
                Case "rpt_Inv_General_Materia_Prima"
                    Dim creporte As New clsReportes
                    creporte.inventarios_MP_opciones()
                    Exit Function
                Case "rpt_kardex_Acumulado"
                    Dim creporte As New clsReportes
                    creporte.rpt_Kardex_Acumulado()
                    Exit Function
                Case "rpt_Depreciaciones"
                    Dim rptReporte As New clsReportes
                    rptReporte.ReporteDepreciaciones()
                    Exit Function
                Case "Rpt_Anothers_Account"
                    Dim rptReporte As New clsReportes
                    rptReporte.ReporteCuentaAjena()
                    Exit Function
                Case "frmRequisa"
                    frm = New frmRequisa
                    frm.key = strForm
                Case "frmCotizacionInsumos"
                    frm = New frmCotizacionInsumos
                    frm.key = strForm
                Case "rpt_Requisa"
                    Dim rptReporte As New clsReportes
                    rptReporte.ReporteRequisa()
                    Exit Function
                Case "Rpt_GeneralidadesDeEgreso"
                    Dim rptReporte As New clsReportes
                    rptReporte.ReporteGeneralidadesEgreso()
                    Exit Function
                Case "rpt_GeneralidadesDeIngreso"
                    Dim rptReporte As New clsReportes
                    rptReporte.rpt_GeneralidadesDeIngreso()
                    Exit Function
                Case "rpt_Laying_bale_list"
                    Dim rptReporte As New clsReportes
                    rptReporte.ReporteLayingBaleList()
                    Exit Function
                Case "rpt_Mill_Inventory_Control"
                    Dim rptReporte As New clsReportes
                    rptReporte.ReporteMillInventoryControl()
                    Exit Function
                Case "rpt_Daily_Layouts"
                    Dim rptReporte As New clsReportes
                    rptReporte.ReporteDailyLayouts()
                    Exit Function
                Case "frmSPermisos"
                    frm = New frmSPermisos
                    frm.key = strForm
                Case "frmLotesPT"
                    frm = New frmLotesPT
                    frm.key = strForm
                Case "frmCajasPT"
                    frm = New frmCajasPT
                    frm.key = strForm
                'Case "rpt_Daily_Box_Production"
                '    Dim bProdClsReportes As New clsReportes
                '    bProdClsReportes.GenerarReporteProduccionDiariaCajas()
                '    Exit Function
                Case "rpt_Daily_Box_Production"
                    Dim bProdClsReportes As New clsReportes
                    bProdClsReportes.ConsultaReporteGenerar()
                    Exit Function
                Case "rpt_Box_Production_Disponible"
                    Dim ClsReportes As New clsReportes
                    ClsReportes.ReporteCajasDisponibles()
                    Exit Function
                Case "rpt_Codigos_Inventario"
                    Dim ClsReportes As New clsReportes
                    ClsReportes.ReporteCodigosInventario()
                    Exit Function
                Case "rpt_PO_Produccion"
                    Dim ClsReportes As New clsReportes
                    ClsReportes.ReportePOProduccion()
                    Exit Function
                Case "rpt_inventario_knitting"
                    Dim ClsReportes As New clsReportes
                    ClsReportes.ReporteInventarioKnitting()
                    Exit Function
                Case "rpt_inventario_greige"
                    Dim ClsReportes As New clsReportes
                    ClsReportes.ReporteInventarioGreige()
                    Exit Function
                Case "rpt_inventario_dyeing"
                    Dim ClsReportes As New clsReportes
                    ClsReportes.ReporteInventarioDyeing()
                    Exit Function
                Case "rpt_inventario_finishing"
                    Dim ClsReportes As New clsReportes
                    ClsReportes.ReporteInventarioFinishing()
                    Exit Function
                Case "rpt_inventario_rolling"
                    Dim ClsReportes As New clsReportes
                    ClsReportes.ReporteInventarioRolling()
                    Exit Function
                Case "rpt_inventario_producto_terminado"
                    Dim ClsReportes As New clsReportes
                    ClsReportes.ReporteInventarioProductoTerminado()
                    Exit Function
                Case "rpt_ordenes_compra_insumos"
                    Dim ClsReportes As New clsReportes
                    ClsReportes.ReporteOrdenesCompraInsumos()
                    Exit Function
                Case "rpt_recibos_proveedor"
                    Dim ClsReportes As New clsReportes
                    ClsReportes.ReporteRecibosProveedor()
                    Exit Function
                Case "rpt_Inventario_General"
                    Dim ClsReportes As New clsReportes
                    ClsReportes.ReporteInventarioGeneral()
                    Exit Function
                Case "rpt_Inventario_General_Acumulado"
                    Dim ClsReportes As New clsReportes
                    ClsReportes.ReporteInventarioGeneralAcumulado()
                    Exit Function
                Case "rpt_Detalle_Caja_Chica"
                    Dim rptCajaChica As New clsReportes
                    rptCajaChica.ReporteDetalleCajaChica()
                    Exit Function
                Case "Rpt_LibroComprasOtros"
                    frm = New frmLibroComprasOtros
                    frm.key = strForm
                Case "Rpt_InventarioYarn"
                    Dim rpt As New clsReportes
                    rpt.InventarioYarn()
                    Exit Function
                Case Else
                    Exit Function

            End Select
            'validar si el formulario no esta abierto
            LogFocus = ValidarForma(frm.Name)
            ' mostrar formulario
            MostrarForma(LogFocus, frm)

            MostrarFormulario = True
            frm = Nothing
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Function

    Private Function TasaCambio(ByVal intMoneda As Integer) As Integer
        Dim strSQL As String = STR_VACIO
        Dim dblTasa As Double = INT_CERO
        Dim conec As MySqlConnection
        Dim COM As MySqlCommand

        strSQL = " SELECT Tasa "
        strSQL &= "     FROM TCambio "
        strSQL &= "         WHERE Fecha= CURDATE() AND LOCAL={moneda} AND Exterior={externa} "
        strSQL = Replace(strSQL, "{moneda}", intMoneda)
        strSQL = Replace(strSQL, "{externa}", cFunciones.DivisaExtranjera())
        conec = New MySqlConnection(strConexion)
        conec.Open()
        COM = New MySqlCommand(strSQL, conec)
        dblTasa = COM.ExecuteScalar
        conec.Close()
        conec.Dispose()
        conec = Nothing
        System.GC.Collect()
        Return dblTasa
    End Function
    Public Sub InsertarTasaCambio(ByVal dblTasa As Double, Optional bd As String = STR_VACIO)
        Dim strSQL As String = STR_VACIO
        Dim COM As MySqlCommand
        Try
            strSQL = "INSERT INTO {bd}TCambio (Fecha, Local, Exterior, Tasa) VALUES (CURDATE(),{0},{1},{2})"
            strSQL = Replace(strSQL, "{0}", Divisa.Local.id)
            strSQL = Replace(strSQL, "{1}", Divisa.Externa.id)
            strSQL = Replace(strSQL, "{2}", dblTasa)
            strSQL = Replace(strSQL, "{bd}", bd)
            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSQL, CON)
            COM.ExecuteNonQuery()
            COM.Dispose()
            System.GC.Collect()
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub
    Public Sub InsertarCatalogo(ByVal dblTasa As Double, Optional bd As String = STR_VACIO)
        Dim strSQL As String = STR_VACIO
        Dim COM As MySqlCommand
        Try
            strSQL = "UPDATE {bd}Catalogos SET cat_sist = " & dblTasa & " WHERE  cat_num = " & Divisa.Externa.id
            strSQL = Replace(strSQL, "{bd}", bd)
            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSQL, CON)
            COM.ExecuteNonQuery()
            COM.Dispose()
            System.GC.Collect()
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub
    Public Sub ComprobarTasaGt()
        Dim strQuery = ""
        Dim REA As MySqlDataReader
        Dim dblTasa As Double = INT_CERO
        Dim strDato As String
        Try
            strQuery = vbNullString
            strQuery = strQuery & " Select c.cat_num pais, e.emp_moneda moneda, s.cat_desc sitio, c.cat_desc "
            strQuery = strQuery & " FROM Empresas e "
            strQuery = strQuery & "      INNER JOIN Catalogos c On c.cat_clase='Paises' AND c.cat_num=e.emp_pais "
            strQuery = strQuery & "      LEFT JOIN Catalogos s ON s.cat_clase='Sitio' AND s.cat_clave='BANGUAT'  "
            strQuery = strQuery & " WHERE e.emp_no={empresa} AND c.cat_sist='DEF_COUNTRY' "
            strQuery = Replace(strQuery, "{empresa}", Sesion.IdEmpresa)
            Dim STRBOX As String = ""
            REA = MyCnn.GetReader(strQuery)
            If REA.HasRows = False Then
                'STRBOX = InputBox("INGRESE UNA PRUEBA", "ESTE ES EL TITULO", "HOLAMUNDO")
                'MsgBox(STRBOX)
            Else
                dblTasa = TasaCambio(REA.GetInt32("moneda"))
                If dblTasa <= vbEmpty Then
                    If MsgBox("Fecha: " & Format(Now(), FORMATO_MYSQL) & vbCr & vbCr & "No fue posible encontrar la tasa de cambio del día" & vbCr & vbCr & "NOTA:" & vbTab & "si responde [SI] se intentara abrir la página del Banco de " & REA.GetString("cat_desc") & vbCr & vbTab & "para que Ud. pueda copiar la tasa de cambio de referencia" & vbCr & vbCr & "¿Desea ingresarla manualmente?", vbExclamation + vbYesNo + vbDefaultButton2, "Tasa de cambio") = vbYes Then
                        'Abre URL de la pagina del Banco 
                        System.Diagnostics.Process.Start(REA.GetString("sitio"))
                        strDato = InputBox("Fecha: " & Format(Now(), FORMATO_MYSQL) & vbCr & vbCr & "Ingrese la tasa de cambio del día", "Tasa de cambio (" & Divisa.Externa.simbolo & ")", vbEmpty)
                        strDato = Left(Trim(strDato), 10)
                        If Not (strDato = vbNullString Or Val(strDato) <= vbEmpty) And IsNumeric(strDato) Then
                            dblTasa = Math.Round(CDbl(Val(strDato)), 5)
                            If MsgBox("Tasa del día: " & vbTab & dblTasa & vbCr & "Fecha: " & vbTab & vbTab & Format(Now(), FORMATO_MYSQL) & vbCr & vbCr & "¿Confirma la utilización de la tasa ingresada?", vbQuestion + vbYesNo, "Tasa de cambio") = vbYes Then
                                If Sesion.IdEmpresa = 18 Then
                                    InsertarTasaCambio(dblTasa, "PDM.")
                                    InsertarCatalogo(dblTasa, "PDM.")
                                End If
                                InsertarTasaCambio(dblTasa)
                                InsertarCatalogo(dblTasa)
                                cFunciones.EscribirRegistro("TCambio", clsFunciones.AccEnum.acAdd, CLng(Divisa.Local.id), , , , "T.C.: " & dblTasa)
                            End If
                        Else
                            MsgBox("Dato ingresado no válido" & vbCr & vbCr & "NOTA: se utilizará la tasa de cambio del día anterior", vbExclamation, "Tasa de cambio")
                        End If
                    End If
                    ' CREAR ESTRUCTURA DE DIVISAS
                    ' STRBOX = InputBox("INGRESE UNA PRUEBA", "ESTE ES EL TITULO", "HOLAMUNDO")
                    ' MsgBox(STRBOX)
                    ' MsgBox(REA.GetString("pais") & "---" & REA.GetDouble("moneda") & REA.GetString("sitio"))
                End If
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        Finally
            REA = Nothing
        End Try
    End Sub

#End Region

End Class