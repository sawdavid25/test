﻿Imports System.IO
Imports System.Drawing
Imports System.Drawing.Imaging
Imports ZXing



Public Class clsEtiquetas

#Region "Variables globales y Constantes"

    Dim fontPath As String = "C:\ruta\a\la\fuente\PF.TTF"
    Dim barcodeFont As New Font(fontPath, 12, FontStyle.Regular)
#End Region
#Region "Variables"

    'Variables de parametros en query datos generales
    Dim rptCategoria As Integer = 776
    Dim rptAnio As Integer = 0
    Dim rptNum As Integer = 0
    Dim rptLinea As Integer = 0
    Dim hora_actual, hora_Inicio_P As DateTime

#End Region

    Public Property Anio As Integer
        Get
            Return rptAnio
        End Get
        Set(value As Integer)
            rptAnio = value
        End Set
    End Property
    Public Property Number As Integer
        Get
            Return rptNum
        End Get
        Set(value As Integer)
            rptNum = value
        End Set
    End Property
    Public Property Linea As Integer
        Get
            Return rptLinea
        End Get
        Set(value As Integer)
            rptLinea = value
        End Set
    End Property



#Region "Funciones Generales - Diferentes Etiquetas"

    Private Function SQLDatosGenerales(ByVal Anio As Integer, ByVal Num As Integer, ByVal Linea As Integer) As String
        Dim strSQL As String = STR_VACIO

        Try
            strSQL = "SELECT DDoc_Doc_Cat col_catalogo,
                           DDoc_Doc_Ano col_ano,
                           DDoc_Doc_Num col_numero,
                           DDoc_Doc_Lin col_linea,
                           DDoc_RF1_Txt col_numLote,
                           DDoc_RF4_Txt col_fecha,
                           DDoc_RF1_COD col_correlativo,
                           DDoc_Prd_DSP col_tara,
                           DDoc_Prd_QTY col_PesoNeto,
                           (DDoc_Prd_QTY + DDoc_Prd_DSP) col_PesoBruto,
                           1 col_estado,
                           IFNULL(pp.PDoc_Chi_Num, 0) col_numIngreso,
                           IFNULL(pp.PDoc_Chi_Ano, 0) col_anoIngreso,
                           IFNULL(pp.PDoc_Chi_Lin, 0) col_lineaIngreso,
                           IFNULL(p.PDoc_Par_Lin, 0) col_lineaLote,
                           a.emp_razon nombreEmpresa,
                           12345 codigoBarra,
                        (SELECT a.art_DCorta Descripcion
                         FROM Articulos a
                         left join Inventarios i on a.art_sisemp = i.inv_sisemp
                         and a.art_codigo = i.inv_artcodigo
                         WHERE i.inv_numero = h.HDoc_Emp_Cod ) producto,
                           DATE_FORMAT(DDoc_RF4_Txt, '%M %e, %Y') fechaTraspaso,
                           DATE_FORMAT(DDoc_RF4_Txt, '%M %e, %Y') fechaPeso,
                           DATE_FORMAT(CURDATE(), '%e %M, %Y')  fechaHilo,
                           WEEK(DDoc_RF4_Txt,4) AS week_number,
                           1 cantidadCajas,
                           d.DDoc_RF1_COD correlativoInicio,
                           d.DDoc_RF1_COD correlativoFin,
                           IFNULL(tn.cat_desc,'') Turno,
                        IFNULL(e.cat_desc,'') empacador,
                        IFNULL(e.cat_desc,'')lider,
                        DDoc_RF1_COD paquete,
                        IFNULL(cc.cat_desc,'') colorCono,
                        d.DDOC_PRD_DSP tara,
                        h.HDoc_DR1_Emp colorEtiquetaID,
                        IFNULL(ce.cat_desc,'') colorEtiqueta,
                        h.HDoc_DR2_Cat FrameID,
                        IFNULL(f.cat_desc,'') Frame,
                        d.DDOC_RF2_DBL RollosCaja,
                        h.HDoc_RF2_Num correlativo,
                        h.HDoc_RF1_Num tipoLoteId,
                        IFNULL(tl.cat_desc,'') tipoLote
                    FROM Dcmtos_DTL d
                    INNER JOIN Dcmtos_HDR h ON h.HDoc_Sis_Emp = d.DDoc_Sis_Emp
                        AND h.HDoc_Doc_Cat = d.DDoc_Doc_Cat
                        AND h.HDoc_Doc_Ano = d.DDoc_Doc_Ano
                        AND h.HDoc_Doc_Num = d.DDoc_Doc_Num
                    LEFT JOIN Dcmtos_DTL_Pro p ON p.PDoc_Sis_Emp=d.DDoc_Sis_Emp
                        AND p.PDoc_Chi_Cat=d.DDoc_Doc_Cat
                        AND p.PDoc_Chi_Ano=d.DDoc_Doc_Ano
                        AND p.PDoc_Chi_Num=d.DDoc_Doc_Num
                        AND p.PDoc_Chi_Lin=d.DDoc_Doc_Lin
                    LEFT JOIN Dcmtos_DTL_Pro pp ON pp.PDoc_Sis_Emp=d.DDoc_Sis_Emp
                        AND pp.PDoc_Par_Cat=d.DDoc_Doc_Cat
                        AND pp.PDoc_Par_Ano=d.DDoc_Doc_Ano
                        AND pp.PDoc_Par_Num=d.DDoc_Doc_Num
                        AND pp.PDoc_Par_Lin=d.DDoc_Doc_Lin
                    LEFT JOIN Empresas a ON a.emp_no = d.DDoc_Sis_Emp
                    LEFT JOIN Catalogos_lotes cc ON cc.cat_num = d.DDOC_RF4_DBL
                        AND cc.cat_clase = 'ColorCono'
                    LEFT JOIN Catalogos_lotes ce ON ce.cat_num = h.HDoc_DR1_Emp
                        AND ce.cat_clase = 'ColorEtiqueta'
                    LEFT JOIN Catalogos_lotes f ON f.cat_num = d.DDoc_RF3_Txt
                        AND f.cat_clase = 'Frame'
                    LEFT JOIN Catalogos_lotes e ON e.cat_num = d.DDOC_RF2_NUM
                        AND e.cat_clase = 'Empacador'
                    LEFT JOIN Catalogos_lotes tl ON tl.cat_num = h.HDoc_RF1_Num
                        AND tl.cat_clase = 'TipoLote'
                    LEFT JOIN Catalogos_lotes tn ON tn.cat_num = d.DDoc_RF4_Cod
                        AND tn.cat_clase = 'Turno'
                    WHERE DDoc_Sis_Emp={empresa} AND DDoc_Doc_Cat= " & rptCategoria & " AND DDoc_Doc_Ano= {anio} AND DDoc_Doc_Num= {num} AND DDoc_Doc_Lin = {linea} ; "

            strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
            strSQL = Replace(strSQL, "{anio}", Anio)
            strSQL = Replace(strSQL, "{num}", Num)
            strSQL = Replace(strSQL, "{linea}", Linea)

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        Return strSQL
    End Function
    Private Function SQLDatosGeneralesConoEmpacador(ByVal Anio As Integer, ByVal Num As Integer) As String
        Dim strSQL As String = STR_VACIO
        Try
            strSQL = "SELECT 

                        h.HDoc_Sis_Emp
                        , h.HDoc_Doc_Cat
                        , h.HDoc_Doc_Ano Anio
                        , h.HDoc_Doc_Num numero
                        , DATE_FORMAT(h.HDoc_Doc_Fec, '%d %M %Y') fecha
                        , h.HDoc_RF2_Cod anoLote
                        , h.HDoc_RF2_Txt idLote
                        , h.HDoc_DR1_Num Lote
                        ,WEEK(h.HDoc_Doc_Fec) AS week_number

                        ,h.HDoc_RF1_Dbl poID
                        ,h.HDoc_RF3_Dbl poIdAno
                        , (SELECT hh.HDoc_DR1_Num Reference
                          FROM  Dcmtos_HDR hh 
                          WHERE hh.HDoc_Sis_Emp = h.HDoc_Sis_Emp And hh.HDoc_Doc_Cat = 980 AND hh.HDoc_Doc_Ano=h.HDoc_RF3_Dbl AND hh.HDoc_Doc_Num=h.HDoc_RF1_Dbl) po
                        , h.HDoc_DR1_Cat colorConoID
                        , cc.cat_desc colorCono
                        , h.HDoc_DR1_Dbl tara
                        , h.HDoc_DR1_Emp colorEtiquetaID
                        , ce.cat_desc colorEtiqueta
                        , h.HDoc_DR2_Cat FrameID
                        , f.cat_desc Frame
                        , h.HDoc_RF2_Dbl RollosCaja
                        , h.HDoc_RF2_Num correlativo
                        , h.HDoc_DR2_Emp empacadorId
                        , e.cat_desc empacador
                        , h.HDoc_RF1_Num tipoLoteId
                        , tl.cat_desc tipoLote
                        , h.HDoc_Emp_Cod ProductoId
                        , (SELECT a.art_DCorta Descripcion FROM Articulos a left join Inventarios i on a.art_sisemp=i.inv_sisemp and a.art_codigo=i.inv_artcodigo WHERE i.inv_numero=h.HDoc_Emp_Cod ) producto
                        , h.HDoc_DR1_Num Lote
                        , t.cat_desc turno
                        FROM Dcmtos_HDR h
                        LEFT JOIN Catalogos_lotes cc ON cc.cat_num = h.HDoc_DR1_Cat AND cc.cat_clase='ColorCono'
                        LEFT JOIN Catalogos_lotes ce ON ce.cat_num = h.HDoc_DR1_Emp AND ce.cat_clase='ColorEtiqueta'
                        LEFT JOIN Catalogos_lotes f ON f.cat_num = h.HDoc_DR2_Cat AND f.cat_clase='Frame'
                        LEFT JOIN Catalogos_lotes e ON e.cat_num = h.HDoc_DR2_Emp AND e.cat_clase='Empacador'
                        LEFT JOIN Catalogos_lotes tl ON tl.cat_num = h.HDoc_RF1_Num AND tl.cat_clase='TipoLote'  
                        LEFT JOIN Catalogos_lotes t ON t.cat_num = h.HDoc_RF1_Txt AND t.cat_clase='Turno' 
                    WHERE h.HDoc_Sis_Emp = {empresa} AND h.HDoc_Doc_Cat = 776 AND h.HDoc_Doc_Ano = {anio} AND h.HDoc_Doc_Num = {num} LIMIT 1; "

            strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
            strSQL = Replace(strSQL, "{anio}", Anio)
            strSQL = Replace(strSQL, "{num}", Num)

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        Return strSQL
    End Function

    Private Sub turnoInicial(numero As Integer)
        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader
        Dim strSQL As String = ""
        ' hora_actual = TimeOfDay
        Try
            strSQL = "SELECT cat_ext hora_Inicio FROM "
            strSQL &= " Catalogos_lotes WHERE cat_clase = 'Turno'
                        and Cat_num=" & numero

            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSQL, CON)
            REA = COM.ExecuteReader
            If REA.HasRows Then
                Do While REA.Read
                    hora_Inicio_P = REA.GetString("hora_Inicio")
                Loop

            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Public Function imprimirEtiquetaPeso()
        'Public Sub imprimirFichaTraspasoBodegaPT(ByVal ID As Integer, ByVal Desde As Date, ByVal Hasta As Date, ByVal Tipo As Integer, Optional tipoRpt As Integer = 0)
        Try

            Dim COM As MySqlCommand
            Dim REA As MySqlDataReader
            Dim strSQL As String = String.Empty

            ' Definir variables

            ' Logo y otros datos
            Dim logo1 As String = "logo1.png"
            Dim logo2 As String = "logo2.png"
            Dim logo3 As String = "logo3.png"
            Dim logo4 As String = "logo4.png"

            ' Asignar valores a las variables
            Dim pesoBruto As Double
            Dim pesoNeto As Double
            Dim paquete As String
            Dim unidad As String
            Dim lote As String
            Dim Frame As String
            Dim fecha As String
            Dim fechaImpresion As String = Now().ToString("MMMM d, yyyy hh:mm:ss tt")
            Dim semana As String
            'Dim fecha_formato As Date
            Dim color As String
            Dim col_correlativo As String
            Dim descripcion As String
            Dim cajaNum As String
            Dim frmCajas As New frmCajasPT
            ' hora_actual = TimeOfDay

            turnoInicial(1)
            'OBTENER DATOS DE LA BASE SEGUN SELECCION
            strSQL = SQLDatosGenerales(rptAnio, rptNum, rptLinea)
            hora_actual = TimeOfDay
            Try
                MyCnn.CONECTAR = strConexion
                COM = New MySqlCommand(strSQL, CON)
                REA = COM.ExecuteReader()

                If REA.HasRows Then
                    ' Leer la primera fila
                    REA.Read()
                    ' Asignar valores a las variables
                    pesoBruto = REA.GetDouble("col_PesoBruto") ' Ajusta el nombre de columna según la base de datos
                    pesoNeto = REA.GetDouble("col_PesoNeto") ' Ajusta el nombre de columna según la base de datos
                    paquete = REA.GetString("RollosCaja") ' Numero de rollos por caja
                    unidad = REA.GetString("col_linea") ' Numero de caja del lote
                    lote = REA.GetString("col_numLote") ' Ajusta el nombre de columna según la base de datos
                    Frame = REA.GetString("Frame") ' Ajusta el nombre de columna según la base de datos
                    fecha = REA.GetString("fechaTraspaso") ' Formato: December 2, 2024
                    semana = REA.GetString("week_number") ' Ajusta el nombre de columna según la base de datos
                    color = REA.GetString("colorCono") ' Ajusta el nombre de columna según la base de datos
                    col_correlativo = REA.GetString("col_correlativo") ' Ajusta el nombre de columna según la base de datos
                    descripcion = REA.GetString("producto") ' Ajusta el nombre de columna según la base de datos
                    cajaNum = REA.GetString("col_linea")
                    'fecha_formato = Format(CDate(fecha), "dd/mm/yyyy")
                End If

            Catch ex As Exception
                MsgBox(ex.ToString())
            End Try


            Dim rutaImagen As String = GenerarCodigoDeBarras(col_correlativo)


            Dim f As Integer = FreeFile()

            ' Crear un nombre de archivo temporal para guardar el HTML
            Dim strFile As String = Path.Combine(Path.GetTempPath(), "vista_previa_nuevo2.html")

            ' Abrir el archivo en modo escritura
            FileOpen(f, strFile, OpenMode.Output)
            Print(f, "<html>")
            Print(f, "<head>")
            Print(f, "    <title>Etiqueta Peso</title>")
            Print(f, "</head>")
            Print(f, "<body style='font-family: Arial, sans-serif; margin: 0; padding: 0;'>")
            Print(f, "    <div style='width: 10cm; height: 15cm; border: 0px solid black; padding: 0.5cm; box-sizing: border-box;'>")
            Print(f, "        <div style='text-align: center; margin-bottom: 10px;'>")
            Print(f, "            <div style='display: flex; justify-content: space-between; align-items: center;'>")

            ' Las imágenes que estás mostrando, las mantengo igual
            Print(f, "<td rowspan='3' style='border: none' ><IMG height='95px' width='75px' border='0' hspace=1 vspace=1 src='file:" & System.Windows.Forms.Application.StartupPath & "\" & Sesion.IdEmpresa & ".png'></td>")
            Print(f, "<td rowspan='3' style='border: none' ><IMG height='95px' width='75px' border='0' hspace=1 vspace=1 src='file:" & System.Windows.Forms.Application.StartupPath & "\eokoTex1.png'></td>")
            Print(f, "<td rowspan='3' style='border: none' ><IMG height='95px' width='75px' border='0' hspace=1 vspace=1 src='file:" & System.Windows.Forms.Application.StartupPath & "\eokoTex2.png'></td>")
            Print(f, "<td rowspan='3' style='border: none' ><IMG height='95px' width='75px' border='0' hspace=1 vspace=1 src='file:" & System.Windows.Forms.Application.StartupPath & "\CottonUSA.png'></td>")
            Print(f, "            </div>")
            Print(f, "        </div>")

            ' Descripción
            Print(f, "        <div style='text-align: center; margin-bottom: 0px;'>")
            Print(f, "            <h3 style='margin: 5px 0; font-size: 10px;'>Description</h3>")
            Print(f, "            <h4 style='margin: 0px 0; font-size: 14px;'>" & descripcion & "</h4>")
            Print(f, "        </div>")
            Print(f, "        <hr style='border: 1px solid black; margin: 0px 0;' />")

            ' Pesos
            Print(f, "        <table style='margin-bottom: 0px;' width='100%'>")
            Print(f, "            <tbody>")
            Print(f, "                <tr>")
            Print(f, "                    <td style='text-align: left;' width='48%'>")
            Print(f, "                        <h4 style='margin: 0px 0; font-size: 12px;'>Gross Wt:</h4>")
            Print(f, "                        <h1 style='margin: 0; font-size: 18px;'>" & pesoBruto.ToString(FORMATO_MONEDA) & " lb. </h1>")
            Print(f, "                    </td>")
            Print(f, "                    <td style='text-align: right;' width='48%'>")
            Print(f, "                        <h4 style='margin: 0px 0; font-size: 12px;'>Net Wt:</h4>")
            Print(f, "                        <h1 style='margin: 0px; font-size: 18px;'>" & pesoNeto.ToString(FORMATO_MONEDA) & " lb. </h1>")
            Print(f, "                    </td>")
            Print(f, "                </tr>")
            Print(f, "            </tbody>")
            Print(f, "        </table>")

            ' Paquete y unidad
            Print(f, "        <hr style='border: 1px solid black; margin: 0px 0;' />")
            Print(f, "        <table style='margin-bottom: 0px;' width='100%'>")
            Print(f, "            <tbody>")
            Print(f, "                <tr>")
            Print(f, "                    <td style='text-align: left;' width='33.3%'>")
            Print(f, "                        <h4 style='margin: 0px 0; font-size: 12px;'>Pkg #:</h4>")
            Print(f, "                        <h1 style='margin: 0px; font-size: 18px;'>" & paquete & "</h1>")
            Print(f, "                    </td>")
            Print(f, "                    <td style='text-align: center;' width='33.3%'>")
            Print(f, "                        <h4 style='margin: 0px 0; font-size: 12px;'></h4>")
            Print(f, "                        <h4 style='margin: 0px; font-size: 12px;'>Lot #:</h4>")
            Print(f, "                    </td>")
            Print(f, "                    <td style='text-align: right;' width='33.3%'>")
            Print(f, "                        <h4 style='margin: 0px 0; font-size: 12px;'>Unit #:</h4>")
            Print(f, "                        <h1 style='margin: 0px; font-size: 18px;'>" & col_correlativo & "</h1>")
            Print(f, "                    </td>")
            Print(f, "                </tr>")
            Print(f, "            </tbody>")
            Print(f, "        </table>")

            ' Lote
            Print(f, "        <div style='text-align: center; margin-bottom: 0px;'>")
            'Print(f, "            <h4 style='margin: 5px 0; font-size: 12px;'>Lot #:</h4>")
            Print(f, "            <h1 style='margin: 0px; font-size: 40px;'>" & lote & "</h1>")
            Print(f, "        </div>")

            ' Marco, Fecha y Semana
            Print(f, "        <hr style='border: 1px solid black; margin: 0px 0;' />")
            Print(f, "        <table style='margin-bottom: 0px;' width='100%'>")
            Print(f, "            <tbody>")
            Print(f, "                <tr>")
            Print(f, "                    <td style='text-align: center;' width='25%'>")
            Print(f, "                        <h4 style='margin: 0px 0; font-size: 12px;'>Frame #:</h4>")
            Print(f, "                        <h1 style='margin: 0px; font-size: 18px;'>" & Frame & "</h1>")
            Print(f, "                    </td>")
            Print(f, "                    <td style='text-align: center;' width='50%'>")
            Print(f, "                        <h4 style='margin: 0px 0; font-size: 12px;'>Date:</h4>")
            Print(f, "                        <h1 style='margin: 0px; font-size: 18px;'>" & fecha & "</h1>")
            Print(f, "                    </td>")
            Print(f, "                    <td style='text-align: center;' width='25%'>")
            Print(f, "                        <h4 style='margin: 0px 0; font-size: 12px;'>Week #:</h4>")
            Print(f, "                        <h1 style='margin: 0px; font-size: 18px;'>" & semana & "</h1>")
            Print(f, "                    </td>")
            Print(f, "                </tr>")
            Print(f, "            </tbody>")
            Print(f, "        </table>")

            ' Color y código de barras (Ahora como imagen)
            Print(f, "        <hr style='border: 1px solid black; margin: 0px 0;' />")
            Print(f, "        <div style='text-align: center; margin-bottom: 0px;'>")
            Print(f, "            <h4 style='margin: 10px 0; font-size: 14px;'>" & color & "</h4>")
            ' Aquí se incluye la imagen del código de barras generado
            Print(f, "            <img src='file:" & rutaImagen & "'width='300px height='60px' '/>")

            Print(f, "        </div>")

            Print(f, "    </div>")
            Print(f, "</body>")
            Print(f, "</html>")

            FileClose(f)



            ' Retornar la ruta del archivo generado
            Return strFile


        Catch ex As Exception
            MessageBox.Show(ex.Message, ex.Source, MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Function

    Public Function imprimirFichaTraspasoBodegaPT(ByVal correlativoI As String, ByVal correlativoF As String, ByVal cantidadC As String)
        'Public Sub imprimirFichaTraspasoBodegaPT(ByVal ID As Integer, ByVal Desde As Date, ByVal Hasta As Date, ByVal Tipo As Integer, Optional tipoRpt As Integer = 0)
        Try
            Dim COM As MySqlCommand
            Dim REA As MySqlDataReader
            Dim strSQL As String = String.Empty

            ' Definir variables
            Dim strTitulo As String = "FICHA DE TRASPASO A BODEGA DE PRODUCTO TERMINADO"
            Dim empresa As String
            Dim lote As String
            Dim fecha As String
            Dim descripcionProducto As String
            Dim turno As String
            Dim lider As String
            Dim footerFecha As String
            Dim correlativoInicio As String = correlativoI
            Dim correlativoFin As String = correlativoF
            Dim cantidadCajas As String = cantidadC
            Dim respuesta As DialogResult


            'OBTENER DATOS DE LA BASE SEGUN SELECCION
            strSQL = SQLDatosGenerales(rptAnio, rptNum, rptLinea)

            Try
                MyCnn.CONECTAR = strConexion
                COM = New MySqlCommand(strSQL, CON)
                REA = COM.ExecuteReader()

                If REA.HasRows Then
                    ' Leer la primera fila
                    REA.Read()

                    ' Asignar valores a las variables
                    empresa = REA.GetString("nombreEmpresa") ' Empacadora/empresa
                    lote = REA.GetString("col_numLote") ' Lote
                    fecha = REA.GetString("fechaTraspaso") ' Fecha de traspaso
                    descripcionProducto = REA.GetString("producto") ' Descripción del producto
                    turno = REA.GetString("turno") ' Turno
                    lider = REA.GetString("lider") ' Líder
                    footerFecha = Now().ToString("MM/dd/yyyy hh:mm:ss tt") ' Fecha de impresión actual

                    If respuesta = DialogResult.No Then
                        correlativoInicio = REA.GetString("correlativoInicio") ' Correlativo de inicio
                        correlativoFin = REA.GetString("correlativoFin") ' Correlativo de fin
                        cantidadCajas = REA.GetString("cantidadCajas") ' Cantidad de cajas
                    End If

                End If
            Catch ex As Exception
                MsgBox(ex.ToString())
            End Try

            Dim f As Integer = FreeFile()

            ' Crear un nombre de archivo temporal para guardar el HTML
            Dim strFile As String = Path.Combine(Path.GetTempPath(), "vista_previa.html")

            ' Abrir el archivo en modo escritura
            FileOpen(f, strFile, OpenMode.Output)
            Print(f, "<html>")
            Print(f, "<head>")
            Print(f, "<title>" & strTitulo & "</title>")
            Print(f, "<style>")
            Print(f, "body { font-family: Arial, sans-serif; margin: 0; padding: 0; }")
            Print(f, ".etiqueta { width: 10cm; height: 15cm; border: 0px solid black; padding: 0.5cm; box-sizing: border-box; }")
            Print(f, ".empresa { font-size: 16px; font-weight: bold; text-align: center; margin-bottom: 20px; }")
            Print(f, ".tituloEtiqueta { font-size: 20px; text-align: center; margin-bottom: 20px; font-weight: bold; }")
            Print(f, ".campo { margin-bottom: 20px; font-size: 14px; }")
            Print(f, ".campoCenter { margin-bottom: 22px; font-size: 14px; text-align: center; }")
            Print(f, ".lote { margin-bottom: 20px; font-size: 24px; text-align: center; font-weight: bold; }")
            Print(f, ".valor { font-weight: bold; }")
            Print(f, ".footer { margin-bottom: 10px; font-size: 14px; text-align: center; }")
            Print(f, "</style>")
            Print(f, "</head>")
            Print(f, "<body>")
            Print(f, "<div class='etiqueta'>")
            Print(f, "<div class='empresa'>" & empresa & "</div>")
            Print(f, "<div class='tituloEtiqueta'>" & strTitulo & "</div>")
            Print(f, "<div class='lote'>LOTE: <span class='valor'>" & lote & "</span></div>")
            Print(f, "<div class='campo'>FECHA: <span class='valor'>" & fecha & "</span></div>")
            Print(f, "<div class='campoCenter'>DESCRIPCIÓN/PRODUCTO:<br><span class='valor'>" & descripcionProducto & "</span></div>")
            Print(f, "<div class='campo'>CORRELATIVO: <span class='valor'>" & correlativoInicio & " - " & correlativoFin & "</span></div>")
            Print(f, "<div class='campo'>CANTIDAD DE BULTOS: <span class='valor'>" & cantidadCajas & "</span></div>")
            Print(f, "<div class='campo'>TURNO: <span class='valor'>" & turno & "</span></div>")
            Print(f, "<div class='campo'>LÍDER: <span class='valor'>" & Sesion.Usuario & "</span></div>")
            Print(f, "<div class='footer' style='margin-top: 20px; font-size: 12px;'>" & footerFecha & "</div>")
            Print(f, "</div>")
            Print(f, "</body>")
            Print(f, "</html>")

            ' Cerrar el archivo
            FileClose(f)

            ' Retornar la ruta del archivo generado
            Return strFile

        Catch ex As Exception
            MessageBox.Show(ex.Message, ex.Source, MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Function


    Public Function imprimirEtiquetaInfoEmpacador(vano As Integer, vnumero As Integer)
        Try
            Dim COM As MySqlCommand
            Dim REA As MySqlDataReader
            Dim strSQL As String = String.Empty

            ' Definir variables
            Dim f As Integer = FreeFile()

            ' Información del producto
            Dim descripcion As String
            Dim lote As String
            Dim color As String
            Dim semana As String
            Dim empacador As String



            'OBTENER DATOS DE LA BASE SEGUN SELECCION
            strSQL = SQLDatosGeneralesConoEmpacador(vano, vnumero)

            Try
                MyCnn.CONECTAR = strConexion
                COM = New MySqlCommand(strSQL, CON)
                REA = COM.ExecuteReader()

                If REA.HasRows Then
                    ' Leer la primera fila
                    REA.Read()

                    ' Información del producto
                    descripcion = REA.GetString("producto") ' Descripción del producto (articulo)
                    lote = REA.GetString("Lote") ' Código de barras
                    color = REA.GetString("colorCono") ' Color del cono
                    semana = REA.GetString("week_number") ' Semana del año
                    empacador = REA.GetString("empacador") ' Empacador


                End If
            Catch ex As Exception
                MsgBox(ex.ToString())
            End Try

            ' Crear un nombre de archivo temporal para guardar el HTML
            Dim strFile As String = Path.Combine(Path.GetTempPath(), "vista_previa_nuevo2.html")

            ' Abrir el archivo en modo escritura
            FileOpen(f, strFile, OpenMode.Output)
            Print(f, "<html>")
            Print(f, "<head>")
            Print(f, "    <title>Etiqueta</title>")
            Print(f, "    <style>")
            Print(f, "        table {")
            Print(f, "            width: 100%;")
            Print(f, "            height: 100%;")
            Print(f, "            border-collapse: collapse;")
            Print(f, "            font-family: Arial, sans-serif;")
            Print(f, "            text-align: center;")
            Print(f, "            border: 0px solid black; ")
            Print(f, "        }")
            Print(f, "        td {")
            Print(f, "            padding: 5px;")
            Print(f, "            white-space: nowrap;")
            Print(f, "            border: 0px solid black;")
            Print(f, "        }")
            Print(f, "        .bold {")
            Print(f, "            font-weight: bold;")
            Print(f, "        }")
            Print(f, "    </style>")
            Print(f, "</head>")
            Print(f, "<body style='font-family: Arial, sans-serif; margin: 0; padding: 0;'>")
            Print(f, "    <div style='width: 15cm; height: 10cm; padding: 0.5cm; box-sizing: border-box;'>")

            ' Contenido de la etiqueta
            Print(f, "        <table>")
            Print(f, "            <tr>")
            Print(f, "                <td style='font-size: 18px;' class='bold'>" & descripcion & "</td>")
            Print(f, "            </tr>")
            Print(f, "            <tr>")
            Print(f, "                <td style='font-size: 70px;' class='bold'>" & lote & "</td>")
            Print(f, "            </tr>")
            Print(f, "            <tr>")
            Print(f, "                <td style='font-size: 30px;'>" & color & "</td>")
            Print(f, "            </tr>")
            Print(f, "            <tr>")
            Print(f, "                <td style='font-size: 30px;'>Hilo Inspeccionado y Empacado por:</td>")
            Print(f, "            </tr>")
            Print(f, "            <tr>")
            Print(f, "                <td style='font-size: 50px;' class='bold'>" & empacador & "</td>")
            Print(f, "            </tr>")
            Print(f, "        </table>")

            Print(f, "    </div>")
            Print(f, "</body>")
            Print(f, "</html>")


            FileClose(f)

            'Retornar la ruta del archivo generado
            Return strFile

        Catch ex As Exception
            MessageBox.Show(ex.Message, ex.Source, MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Function


    Public Function imprimirEtiquetaCono(vano As Integer, vnumero As Integer)
        Try

            Dim COM As MySqlCommand
            Dim REA As MySqlDataReader
            Dim strSQL As String = String.Empty

            ' Información de la etiqueta
            Dim descripcion As String
            Dim lote As String
            Dim fecha As String
            Dim empacador As String
            Dim turno As String

            'OBTENER DATOS DE LA BASE SEGUN SELECCION
            strSQL = SQLDatosGeneralesConoEmpacador(vano, vnumero)

            Try
                MyCnn.CONECTAR = strConexion
                COM = New MySqlCommand(strSQL, CON)
                REA = COM.ExecuteReader()

                If REA.HasRows Then
                    ' Leer la primera fila
                    REA.Read()

                    ' Asignar los valores a las nuevas variables
                    descripcion = REA.GetString("producto") ' Asignar a la variable descripcion
                    lote = REA.GetString("Lote") ' Asignar a la variable lote
                    fecha = REA.GetString("fecha") ' Asignar a la variable fecha
                    turno = "Shift " & REA.GetString("turno") ' Asignar a la variable fecha
                    empacador = REA.GetString("empacador") ' Asignar a la variable fecha

                End If
            Catch ex As Exception
                MsgBox(ex.ToString())
            End Try

            Dim f As Integer = FreeFile()
            ' Crear un nombre de archivo temporal para guardar el HTML
            Dim strFile As String = Path.Combine(Path.GetTempPath(), "vista_previa_etiqueta2.html")
            'FileClose(f)
            ' Abrir el archivo en modo escritura
            FileOpen(f, strFile, OpenMode.Output)
            Print(f, "<html>")
            Print(f, "<head>")
            Print(f, "    <meta charset='UTF-8'>")
            Print(f, "    <meta name='viewport' content='width=device-width, initial-scale=1.0'>")
            Print(f, "    <title>Etiqueta Cono</title>")
            Print(f, "</head>")
            Print(f, "<body style='font-family: Arial, sans-serif; margin: 0; padding: 0;'>")

            ' Contenedor para las dos tablas, con espacio entre ellas
            Print(f, "<table style='width:  8.7cm; border: 0px; border-spacing: 0px;'>")
            Print(f, "            <tr>")
            Print(f, "            <td style='width: 50%; vertical-align: top;'>")
            ' Primera Tabla
            Print(f, "        <table style='width: 3.5cm; height: 2.5cm; border: 0px solid black; margin-right: 10px; table-layout: fixed;'>")
            Print(f, "            <tr>")
            Print(f, "                <td style='font-size: " & If(descripcion.Length > 38, "9", "10") & "px; text-align: center; vertical-align: middle; word-wrap: break-word; white-space: normal; display: block;'>")
            Print(f, "                    " & descripcion)
            Print(f, "                </td>")
            Print(f, "            </tr>")
            Print(f, "            <tr>")
            Print(f, "                <td style='font-size: " & If(lote.Length > 4 Or descripcion.Length > 38, "14", "25") & "px; text-align: center; vertical-align: middle;'>LOT " & lote)
            Print(f, "                </td>")
            Print(f, "            </tr>")
            Print(f, "            <tr>")
            Print(f, "                <td style='font-size: 10px; text-align: center; vertical-align: middle;'>" & fecha & "</td>")
            Print(f, "            </tr>")
            Print(f, "            <tr>")
            Print(f, "                <td style='font-size: 10px; text-align: center; vertical-align: middle;'>" & empacador & " " & turno & "</td>")
            Print(f, "            </tr>")
            Print(f, "        </table>")
            Print(f, "            <td>")

            ' Segunda Tabla con la misma estructura
            Print(f, "<td style='width: 50%; vertical-align: top;'>")
            Print(f, "        <table style='width: 3.5cm; height: 2.5cm; border: 0px solid black; margin-right: 10px; table-layout: fixed;'>")
            Print(f, "            <tr>")
            Print(f, "                <td style='font-size: " & If(descripcion.Length > 38, "9", "10") & "px; text-align: center; vertical-align: middle; word-wrap: break-word; white-space: normal; display: block;'>")
            Print(f, "                    " & descripcion)
            Print(f, "                </td>")
            Print(f, "            </tr>")
            Print(f, "            <tr>")
            Print(f, "                <td style='font-size: " & If(lote.Length > 4 Or descripcion.Length > 38, "14", "25") & "px; text-align: center; vertical-align: middle;'>LOT " & lote)
            Print(f, "                </td>")
            Print(f, "            </tr>")
            Print(f, "            <tr>")
            Print(f, "                <td style='font-size: 10px; text-align: center; vertical-align: middle;'>" & fecha & "</td>")
            Print(f, "            </tr>")
            Print(f, "            <tr>")
            Print(f, "                <td style='font-size: 10px; text-align: center; vertical-align: middle;'>" & empacador & " " & turno & "</td>")
            Print(f, "            </tr>")
            Print(f, "        </table>")
            Print(f, "            </td>")
            Print(f, "            </tr>")
            Print(f, "            </table>")

            Print(f, "</body>")
            Print(f, "</html>")

            FileClose(f)

            ' Retornar la ruta del archivo generado
            Return strFile

        Catch ex As Exception
            MessageBox.Show(ex.Message, ex.Source, MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Function

    Public Sub imprimirFichaTraspasoBodegaPTOrigin()
        'Public Sub imprimirFichaTraspasoBodegaPT(ByVal ID As Integer, ByVal Desde As Date, ByVal Hasta As Date, ByVal Tipo As Integer, Optional tipoRpt As Integer = 0)

        Dim cmd As MySqlCommand

        Try
            Dim rpt As New clsReportes
            Dim strSQL As String = String.Empty
            Dim strFile As String = cFunciones.ArchivoTemporal()
            Dim strClase As String = "Ext"
            Dim strTexto As String

            Dim i As Integer = INT_CERO

            Dim dblSaldo As Double = 0.0
            Dim dblCargo As Double = 0.0
            Dim dblAbono As Double = 0.0

            Dim dblSumCargo As Double = 0
            Dim dblSumAbono As Double = 0
            Dim dblSumPresupuesto As Double = 0
            Dim dblSumPresupuestoDls As Double = 0


            ' Abrir el archivo en modo escritura
            Dim f As Integer = FreeFile()
            Dim strTitulo As String = "Ficha de Traspaso"
            Dim lote As String = "828"
            Dim fecha As String = "7 enero, 2025"
            Dim descripcionProducto As String = "30/1 60% COTTON 40% RECYCLED POLY CM RS"
            Dim correlativoInicio As String = "270"
            Dim correlativoFin As String = "270"
            Dim cantidadCajas As String = "1"
            Dim turno As String = "A"
            Dim lider As String = "FREDY CARTAGENA"
            Dim footerFecha As String = "07/01/2025 8:19:51"

            FileOpen(f, strFile, OpenMode.Output)

            ' Crear la estructura del HTML
            Print(f, "<!DOCTYPE html>" & vbCrLf)
            Print(f, "<html lang='es'>" & vbCrLf)
            Print(f, "<head>" & vbCrLf)
            Print(f, "    <meta charset='UTF-8'>" & vbCrLf)
            Print(f, "    <meta name='viewport' content='width=device-width, initial-scale=1.0'>" & vbCrLf)
            Print(f, "    <title>" & strTitulo & "</title>" & vbCrLf)
            Print(f, "    <style>" & vbCrLf)
            Print(f, "        body {" & vbCrLf)
            Print(f, "            font-family: Arial, sans-serif;" & vbCrLf)
            Print(f, "            margin: 0;" & vbCrLf)
            Print(f, "            padding: 0;" & vbCrLf)
            Print(f, "            display: flex;" & vbCrLf)
            Print(f, "            justify-content: center;" & vbCrLf)
            Print(f, "            align-items: center;" & vbCrLf)
            Print(f, "            height: 100vh;" & vbCrLf)
            Print(f, "            background-color: #f5f5f5;" & vbCrLf)
            Print(f, "        }" & vbCrLf)
            Print(f, "        .container {" & vbCrLf)
            Print(f, "            width: 18cm;" & vbCrLf)
            Print(f, "            padding: 1cm;" & vbCrLf)
            Print(f, "            background: white;" & vbCrLf)
            Print(f, "            border: 0px solid #000;" & vbCrLf)
            Print(f, "            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);" & vbCrLf)
            Print(f, "            text-align: center;" & vbCrLf)
            Print(f, "            box-sizing: border-box;" & vbCrLf)
            Print(f, "        }" & vbCrLf)
            Print(f, "        .title {" & vbCrLf)
            Print(f, "            font-size: 14pt;" & vbCrLf)
            Print(f, "            font-weight: bold;" & vbCrLf)
            Print(f, "            margin-bottom: 10px;" & vbCrLf)
            Print(f, "        }" & vbCrLf)
            Print(f, "        .subtitle {" & vbCrLf)
            Print(f, "            font-size: 12pt;" & vbCrLf)
            Print(f, "            margin-bottom: 15px;" & vbCrLf)
            Print(f, "        }" & vbCrLf)
            Print(f, "        .content {" & vbCrLf)
            Print(f, "            text-align: left;" & vbCrLf)
            Print(f, "            font-size: 11pt;" & vbCrLf)
            Print(f, "            line-height: 1.5;" & vbCrLf)
            Print(f, "        }" & vbCrLf)
            Print(f, "        .field {" & vbCrLf)
            Print(f, "            margin: 5px 0;" & vbCrLf)
            Print(f, "        }" & vbCrLf)
            Print(f, "        .field b {" & vbCrLf)
            Print(f, "            font-weight: bold;" & vbCrLf)
            Print(f, "        }" & vbCrLf)
            Print(f, "        .footer {" & vbCrLf)
            Print(f, "            margin-top: 15px;" & vbCrLf)
            Print(f, "            font-size: 10pt;" & vbCrLf)
            Print(f, "        }" & vbCrLf)
            Print(f, "    </style>" & vbCrLf)
            Print(f, "</head>" & vbCrLf)
            Print(f, "<body>" & vbCrLf)
            Print(f, "    <div class='container'>" & vbCrLf)
            Print(f, "        <div class='title'>HONDURAS SPINNING MILLS S.A. DE C.V.</div>" & vbCrLf)
            Print(f, "        <div class='subtitle'>FICHA DE TRASPASO A BODEGA DE PRODUCTO TERMINADO</div>" & vbCrLf)
            Print(f, "        <div class='content'>" & vbCrLf)
            Print(f, "            <div class='field'><b>LOTE:</b> " & lote & "</div>" & vbCrLf)
            Print(f, "            <div class='field'><b>FECHA:</b> " & fecha & "</div>" & vbCrLf)
            Print(f, "            <div class='field'><b>DESCRIPCIÓN/PRODUCTO:</b> " & descripcionProducto & "</div>" & vbCrLf)
            Print(f, "            <div class='field'><b>CORRELATIVO:</b> " & correlativoInicio & " - " & correlativoFin & "</div>" & vbCrLf)
            Print(f, "            <div class='field'><b>CANTIDAD DE CAJAS:</b> " & cantidadCajas & "</div>" & vbCrLf)
            Print(f, "            <div class='field'><b>TURNO:</b> " & turno & "</div>" & vbCrLf)
            Print(f, "            <div class='field'><b>LÍDER:</b> " & lider & "</div>" & vbCrLf)
            Print(f, "        </div>" & vbCrLf)
            Print(f, "        <div class='footer'>" & footerFecha & "</div>" & vbCrLf)
            Print(f, "    </div>" & vbCrLf)
            Print(f, "</body>" & vbCrLf)
            Print(f, "</html>")

            ' Cerrar el archivo
            FileClose(f)
            rpt.MostarReporte(strFile)


        Catch ex As Exception
            MessageBox.Show(ex.Message, ex.Source, MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    Public Function GenerarCodigoDeBarras(ByVal texto As String) As String
        Try
            ' Crear una instancia del codificador de códigos de barras
            Dim barcodeWriter As New BarcodeWriter()

            ' Establecer el tipo de código de barras a CODE_39
            barcodeWriter.Format = BarcodeFormat.CODE_39

            ' Configurar las opciones del código de barras
            barcodeWriter.Options = New ZXing.Common.EncodingOptions With {
                .Width = 230,  ' Ancho en píxeles
                .Height = 60,  ' Alto en píxeles
                .Margin = 1    ' Márgenes
            }

            ' Generar la imagen del código de barras
            Dim imagen As Bitmap = barcodeWriter.Write(texto)

            ' Obtener la ruta temporal del sistema
            Dim carpetaTemporal As String = Path.GetTempPath()


            ' Crear un nombre único para la imagen (para evitar sobreescribir archivos)
            Dim nombreArchivo As String = "codigo_de_barras" & Guid.NewGuid().ToString() & ".png"

            ' Ruta completa del archivo temporal donde se guardará la imagen
            Dim rutaArchivo As String = Path.Combine(carpetaTemporal, nombreArchivo)

            ' Guardar la imagen en el archivo
            imagen.Save(rutaArchivo, System.Drawing.Imaging.ImageFormat.Png)

            ' Retornar la ruta del archivo temporal donde se guardó la imagen
            Return rutaArchivo
            'Return String.Empty

        Catch ex As Exception
            ' Manejo de excepciones en caso de error
            MessageBox.Show("Error al generar el código de barras: " & ex.Message)
            Return String.Empty
        End Try
    End Function



#End Region










End Class
