﻿Public Class clsReportesCorporativos
    Const DIAS_SEMANA As Integer = 7
    Dim frmP As Form = frmSPrincipal
    Const YarnD As String = "YarnDivision"
    Dim PromedioTC As Double = INT_CERO
    Dim PromedioTC2 As Double = INT_CERO
    Dim PromedioTC3 As Double = INT_CERO
    Dim intMoneda As Integer = NO_FILA
    Dim PromedioTC4 As Double = INT_CERO
    Public WriteOnly Property Parent As Form
        Set(value As Form)
            frmP = value
        End Set
    End Property

    Private Sub MostarReporte(ByVal strTemp As String)
        Dim frm As New frmReporte
        frm.ArchivoTemporal = strTemp
        frm.Show()
        If IsNothing(frmP) Then
            frm.Show()
        Else
            frm.MdiParent = Fprincipal
            frm.Show()
        End If
        strTemp = STR_VACIO
    End Sub

    Private Function Encabezado(ByVal logEmpresa As Boolean, ByVal strTitulo As String, Optional ByVal strTitulo2 As String = STR_VACIO, Optional ByVal strTitulo3 As String = STR_VACIO) As String
        Dim strTemp As String = STR_VACIO
        Dim f As Byte
        Dim cEmp As New Tablas.TEMPRESAS
        Dim strSQL As String = STR_VACIO
        Dim COM As MySqlCommand
        Dim conec As MySqlConnection
        Dim intPais As Integer

        Try
            strTemp = cFunciones.ArchivoTemporal()
            f = FreeFile()
            FileOpen(f, strTemp, OpenMode.Output)
            Print(f, "<html>")
            Print(f, "<HEAD>")
            Print(f, " <TITLE>" & strTitulo & "</TITLE>")
            Print(f, "<style type='text/css'>")


            Print(f, " th {width: 3.8cm; VALIGN=MIDDLE;border:solid Gray 0px; background-color: #BDBDBD; color: Black; padding:2px 5px; font-family: Tahoma, Arial;font-size: 7pt}")

            Print(f, " td {text-align:center;border:solid Gray 1px; padding:3px 5px; font-family: Tahoma, Arial;font-size: 7pt}")

            Print(f, "</style>")
            Print(f, " </HEAD>")
            Print(f, "<BODY>")
            Print(f, "<TABLE cellspacing=0 width=500 >")

            strSQL = "   SELECT e.emp_pais Pais"
            strSQL &= "      FROM Empresas e"
            strSQL &= "          WHERE e.emp_no = {empresa}"

            strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
            conec = New MySqlConnection(strConexion)
            conec.Open()
            COM = New MySqlCommand(strSQL, conec)
            Using conec
                intPais = COM.ExecuteScalar
                COM.Dispose()
                COM = Nothing
                conec.Close()
                conec.Dispose()
                conec = Nothing
                System.GC.Collect()
            End Using

            If (intPais = 310 And Sesion.IdEmpresa = 12) Or Sesion.IdEmpresa = 16 Then
                Print(f, "<tr>")
                Print(f, "<td rowspan='3'style = 'border: none' ><IMG height='100px' width='200px'  border='0' hspace=1 vspace=1 src='file:" & System.Windows.Forms.Application.StartupPath & "\" & "Amtex.jpg '" & "></td>")
            Else
                Print(f, "<tr>")
                Print(f, "<td rowspan='3'style = 'border: none' ><IMG height='100px' width='200px'  border='0' hspace=1 vspace=1 src='file:" & System.Windows.Forms.Application.StartupPath & "\" & Sesion.IdEmpresa & ".jpg '" & "></td>")
            End If
            If logEmpresa = True Then
                cEmp.CONEXION = strConexion
                If cEmp.Seleccionar(Sesion.IdEmpresa) = True Then
                    'Print(f, "<th style='width: 2.2cm'; style= 'border : none'>" & " " & " </th>")
                    Print(f, "</tr>")
                    Print(f, "<tr>")
                    Print(f, "<td style='width: 6.2cm'; style= 'border : none'; VALIGN=BOTTOM>" & cEmp.EMP_RAZON & " </td>")
                    Print(f, "</tr>")
                    Print(f, "<tr>")
                    Print(f, "<td  style='width: 6.2cm'; style= 'border : none'; font-size: 6pt;VALIGN=TOP>" & cEmp.EMP_DIRECCION & "</td>")
                    Print(f, "</tr>")
                Else
                    MsgBox(cEmp.MERROR.ToString)
                End If
                cEmp.Dispose()
            Else

                Print(f, "<td style='border: none'> <FONT FACE='impact' SIZE=3 COLOR='black'>" & strTitulo2 & "</FONT> </td>")
                Print(f, "</tr>")
                Print(f, "<tr>")
                Print(f, "<td style='border: none'><FONT FACE='Arial' COLOR='black'> <b>" & strTitulo3 & "</b></FONT></td>")
                Print(f, "</tr>")
            End If

            Print(f, "</TABLE>")
            FileClose(f)
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try

        Return strTemp

    End Function

    Public Sub SincronizarReportesCorp(ByVal intTipoReport As Integer)
        Dim Sync As New frmSincronizacion
        Sync.TipoReporte = intTipoReport
        If intTipoReport = 4 Or intTipoReport = 7 Or intTipoReport = 8 Or intTipoReport = 15 Or intTipoReport = 17 Then
            Sync.dtpFechaInicial.Visible = True
        Else
            Sync.dtpFechaInicial.Visible = False
        End If
        Sync.Show(frmP)
    End Sub

    Private Function PintarTexto(ByVal Texto As String, Optional Vacio As Boolean = False, Optional Positivo As String = vbNullString, Optional Negativo As String = "Crimson", Optional Cero As String = "White") As String
        Dim strTemp As String
        Dim strDato As String

        strDato = Trim(Replace(Texto, "$", vbNullString))
        strTemp = Trim(Texto)
        If Val(strDato) = vbEmpty Then
            If Vacio Then
                strTemp = "<font color=" & Cero & ">" & Texto & "</font>"
            End If
        ElseIf Val(strDato) > vbEmpty Then
            If Not (Positivo = vbNullString) Then
                strTemp = "<font color=" & Positivo & ">" & Texto & "</font>"
            End If
        ElseIf Not (Negativo = vbNullString) Then
            strTemp = "<font color=" & Negativo & ">" & Texto & "</font>"
        End If

        PintarTexto = strTemp
    End Function

#Region " Cxp Corporativo"
    Public Shared Function ObtenerMiercoles(diaSemana As DateTime) As DateTime
        Dim MiercolesDeSemana As DateTime = diaSemana.Date
        While MiercolesDeSemana.DayOfWeek <> DayOfWeek.Wednesday
            MiercolesDeSemana = MiercolesDeSemana.AddDays(+1)
        End While
        Return MiercolesDeSemana
    End Function

    Private Function SQLCxpCorporativo(ByVal Fcorte As Date, ByVal intEmp As Integer, ByVal intTipoRpt As Integer) As String
        Dim strSql As String = STR_VACIO
        Try
            strSql = " SELECT IFNULL(g.idGrupo,-1)igrup, ifnull(g.nombre_Grupo, '_NO GROUP') grup, emp.nombre_empresa, cp.*
                        FROM YarnDivision.cxp cp
                            INNER JOIN YarnDivision.Empresa emp ON emp.idEmpresa = cp.idEmpresa
                            LEFT JOIN YarnDivision.Grupo_Detalle gd ON gd.idEmpresa = emp.idEmpresa AND gd.Codigo = cp.id AND gd.idTipo = 3
                            LEFT JOIN YarnDivision.Grupo g ON g.idGrupo = gd.idGrupo AND g.idTipo =gd.idTipo
                            Where cp.id>0 {emp} {filtro}
                        ORDER BY grup,nombre_empresa,cp.fecha asc,cp.factura "

            If intEmp = 0 Then
                strSql = strSql.Replace("{emp}", "")
            Else
                strSql = strSql.Replace("{emp}", " AND emp.idEmpresa = " & intEmp)
            End If

            If intTipoRpt = 0 Then
                strSql = strSql.Replace("{filtro}", "")
            ElseIf intTipoRpt = 1 Then
                strSql = strSql.Replace("{filtro}", " AND g.nombre_Grupo LIKE '%Intercompany%'")
            ElseIf intTipoRpt = 2 Then
                strSql = strSql.Replace("{filtro}", " AND NOT g.nombre_Grupo LIKE '%Intercompany%' AND NOT g.nombre_Grupo LIKE '%Quimico%' AND NOT g.nombre_Grupo LIKE 'Planta%'")
            ElseIf intTipoRpt = 3 Then
                strSql = strSql.Replace("{filtro}", " AND g.nombre_Grupo LIKE '%Quimico%'")
            ElseIf intTipoRpt = 4 Then
                strSql = strSql.Replace("{filtro}", " AND g.nombre_Grupo LIKE 'Planta%'")
            End If

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        Return strSql
    End Function

    Private Function SQLCxpCorporativoSumary(ByVal Fcorte As Date, ByVal intEmp As Integer, ByVal intTipoRpt As Integer) As String
        Dim strSql As String = STR_VACIO
        Try
            strSql = "SELECT IFNULL(g.idGrupo,-1)igrup, ifnull(g.nombre_Grupo, '_NO GROUP') grup, sum(cp.dia0)dia0, sum(cp.dia1_30)dia1_30, sum(cp.dia31_60)dia31_60, sum(cp.dia60_90)dia60_90, sum(cp.dia90)dia90 
                        FROM YarnDivision.cxp cp
                            INNER JOIN YarnDivision.Empresa emp ON emp.idEmpresa = cp.idEmpresa
                            LEFT JOIN YarnDivision.Grupo_Detalle gd ON gd.idEmpresa = emp.idEmpresa AND gd.Codigo = cp.id AND gd.idTipo = 3
                            LEFT JOIN YarnDivision.Grupo g ON g.idGrupo = gd.idGrupo AND g.idTipo =gd.idTipo
                            Where g.idGrupo<>0 {emp} {filtro}
                        GROUP BY igrup
                        ORDER BY grup,cp.dias"

            If intEmp = 0 Then
                strSql = strSql.Replace("{emp}", "")
            Else
                strSql = strSql.Replace("{emp}", " AND emp.idEmpresa = " & intEmp)
            End If

            If intTipoRpt = 0 Then
                strSql = strSql.Replace("{filtro}", "")
            ElseIf intTipoRpt = 1 Then
                strSql = strSql.Replace("{filtro}", " AND g.nombre_Grupo LIKE '%Intercompany%'")
            ElseIf intTipoRpt = 2 Then
                strSql = strSql.Replace("{filtro}", " AND NOT g.nombre_Grupo LIKE '%Intercompany%' AND NOT g.nombre_Grupo LIKE '%Quimico%' AND NOT g.nombre_Grupo LIKE 'Planta%'")
            ElseIf intTipoRpt = 3 Then
                strSql = strSql.Replace("{filtro}", " AND g.nombre_Grupo LIKE '%Quimico%'")
            ElseIf intTipoRpt = 4 Then
                strSql = strSql.Replace("{filtro}", " AND g.nombre_Grupo LIKE 'Planta%'")
            End If

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        Return strSql
    End Function

    Private Function EncabezadoCxpCorporativo(ByVal Ffin As Date, Optional ByVal intEmpresaSelect As Integer = 0) As String
        Dim strEncabezado As String = STR_VACIO
        Dim Empresa As Integer = 0

        'Op.Opciones = "All|Hilos|PrideYarn|Amtex|Dominican"
        '                0 | 1   |    2    | 3   |   4    
        'Select Case intEmpresaSelect
        '    Case 0 'Naranjas dulces -  All
        '        Empresa = 0
        '    Case 1 'Hilos
        '        Empresa = 12
        '    Case 2 ' PrideYarn
        '        Empresa = 11
        '    Case 3 'Amtex
        '        Empresa = 16
        '    Case 4 'Dominican
        '        Empresa = 14
        'End Select

        Try

            '---------------------------------------------- NAME EMPRESA ----------------------------------------------
            Dim nombreEmpresa As String = ""
            If intEmpresaSelect > 0 Then
                Dim strSQL As String = STR_VACIO
                Dim COM As MySqlCommand

                strSQL = "   SELECT nombre_Empresa empresa"
                strSQL &= "      FROM YarnDivision.Empresa e"
                strSQL &= "          WHERE e.idEmpresa = {empresa}"

                strSQL = Replace(strSQL, "{empresa}", intEmpresaSelect)
                MyCnn.CONECTAR = strConexion
                COM = New MySqlCommand(strSQL, CON)
                nombreEmpresa = Convert.ToString(COM.ExecuteScalar())
            End If
            '-----------------------------------------------------------------------------------------------------------

            strEncabezado &= "<html>"
            strEncabezado &= "<head>"
            strEncabezado &= "<title>" & "Cxp Corporativos" & "</title>"
            strEncabezado &= "<style type='text/css'>"
            strEncabezado &= " table {table-layout: fixed; empty-cells: show; border-collapse:collapse}"
            strEncabezado &= " caption {padding: 5px; text-align:left; font-family: Tahoma, Arial;font-size: 8pt}"
            strEncabezado &= " th {width: 1.8cm; border:solid Silver 1px; background-color: #000080; color: White; padding:2px 5px; font-family: Tahoma, Arial;font-size: 7pt}"
            strEncabezado &= " td {text-align:center;border:solid Silver 1px; padding:3px 5px; font-family: Tahoma, Arial;font-size: 7pt}"
            strEncabezado &= " .titulo {font-family: Tahoma, Arial;font-size: 9pt}"
            strEncabezado &= " .encabezado {text-align: left; border: none; width: 3.1cm}"
            strEncabezado &= " .pie {font-family: Tahoma, Arial;font-size: 7pt}"
            strEncabezado &= " .izquierda {text-align:left}"
            strEncabezado &= " .centro {text-align:center}"
            strEncabezado &= " .derecha {text-align:right}"
            strEncabezado &= " .info {text-align:left; border:none}"
            strEncabezado &= " td.numero {text-align:right; mso-number-format:\#\,\#\#0\.00}"
            strEncabezado &= "</style>"
            strEncabezado &= "</head>"
            strEncabezado &= "<body>"

            ' strEncabezado &= "<span class='titulo'><b>" & Sesion.Empresa & "</b></span><br/><br/>"
            strEncabezado &= "<span class='titulo'><b>" & UCase("Account Payable ") & "</b></span><br/>"
            strEncabezado &= "<span class='pie'>UNTIL " & Ffin.ToString(FORMATO_MYSQL) & "<br></span>"
            strEncabezado &= "<span class='titulo'><b>Amounts expressed in US$</span>"
            strEncabezado &= "<br><span class='titulo'><b>" & nombreEmpresa & "</span>"
            strEncabezado &= "<br/><br/>"

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        Return strEncabezado
    End Function

    Private Function ColumnasCxpCorporativo(ByVal fechaCorte As Date) As String
        Dim strColumnas As String = STR_VACIO
        Dim Miercoles1 As Date
        Dim Miercoles2 As Date
        Dim Miercoles3 As Date
        Dim Miercoles4 As Date
        Dim Miercoles5 As Date
        Dim Miercoles6 As Date
        Dim Miercoles7 As Date
        Dim Miercoles8 As Date
        Dim Miercoles9 As Date
        Try

            '  strColumnas = "<table cellspacing=0> "
            strColumnas &= " <tr> "
            'strColumnas &= "<th style= 'width:3cm' > Id </th>"
            strColumnas &= "<th style= 'width:4cm' > Company </th>"
            strColumnas &= "<th style= 'width:4cm' > Group </th>"
            strColumnas &= "<th style= 'width:4cm' > Vendor </th>"
            strColumnas &= "<th style= 'width:2cm' > Reference </th>"
            strColumnas &= "<th style= 'width:6cm' > Num </th>"
            strColumnas &= "<th style= 'width:2cm' > Date </th>"
            strColumnas &= "<th style= 'width:2cm' > Due Date </th>"
            strColumnas &= "<th style= 'width:2cm' > Terms </th>"
            strColumnas &= "<th style= 'width:2cm' > Open Balance </th>"
            Miercoles1 = ObtenerMiercoles(fechaCorte)
            Miercoles2 = Miercoles1.AddDays(+7)
            Miercoles3 = Miercoles2.AddDays(+7)
            Miercoles4 = Miercoles3.AddDays(+7)
            Miercoles5 = Miercoles4.AddDays(+7)
            Miercoles6 = Miercoles5.AddDays(+7)
            Miercoles7 = Miercoles6.AddDays(+7)
            Miercoles8 = Miercoles7.AddDays(+7)
            Miercoles9 = Miercoles8.AddDays(+7)
            strColumnas &= "<th style='width: 2.8cm'>" & Miercoles1 & "</th>"
            strColumnas &= "<th style='width: 2.8cm'>" & Miercoles2 & "</th>"
            strColumnas &= "<th style='width: 2.8cm'>" & Miercoles3 & "</th>"
            strColumnas &= "<th style='width: 2.8cm'>" & Miercoles4 & "</th>"
            strColumnas &= "<th style='width: 2.8cm'>" & Miercoles5 & "</th>"
            strColumnas &= "<th style='width: 2.8cm'>" & Miercoles6 & "</th>"
            strColumnas &= "<th style='width: 2.8cm'>" & Miercoles7 & "</th>"
            strColumnas &= "<th style='width: 2.8cm'>" & Miercoles8 & "</th>"
            strColumnas &= "<th style='width: 2.8cm'>" & Miercoles9 & "</th>"
            strColumnas &= "<th style= 'width: 3.5cm' > Notes </th>"
            'strColumnas &= "<th style= 'width:2cm' > Total </th>"

            strColumnas &= " </tr> "
            ' strColumnas &= " </table> "
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        Return strColumnas
    End Function

    Private Function ColumnasCxpCorporativoSummary() As String
        Dim strColumnas As String = STR_VACIO
        Try
            '  strColumnas = "<table cellspacing=0> "
            strColumnas &= " <tr> "
            'strColumnas &= "<th style= 'width:3cm' > Id </th>"
            strColumnas &= "<th style= 'width:4cm' > Customer </th>"
            strColumnas &= "<th style= 'width:2cm' > Current </th>"
            strColumnas &= "<th style= 'width:2cm' > 1 to 30 </th>"
            strColumnas &= "<th style= 'width:2cm' > 30 to 60 </th>"
            strColumnas &= "<th style= 'width:2cm' > 60 to 90 </th>"
            strColumnas &= "<th style= 'width:2cm' > + 90 </th>"
            strColumnas &= "<th style= 'width:2cm' > Total </th>"
            strColumnas &= " </tr> "
            ' strColumnas &= " </table> "
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        Return strColumnas
    End Function

    Private Function SubTotalCxpCorporativo(ByVal sCategoria As String, ByVal dblCurrent As Double, ByVal dbl1to30 As Double, ByVal dbl30to60 As Double, ByVal dbl60to90 As Double, ByVal dblmas90 As Double, ByVal dblTotal As Double, ByVal dblSemana1 As Double, ByVal dblSemana2 As Double, ByVal dblSemana3 As Double, ByVal dblSemana4 As Double, ByVal dblSemana5 As Double, ByVal dblSemana6 As Double, ByVal dblSemana7 As Double, ByVal dblSemana8 As Double, ByVal dblSemana9 As Double) As String
        Dim strTotalRegion As String = STR_VACIO
        Try

            ' strTotalRegion &= "<table >"
            strTotalRegion &= " <tr> "
            strTotalRegion &= "<th  style= 'background:gray;text-align: right;width:8cm' colspan='7'> - Total </th>"
            strTotalRegion &= "<th style= 'background:gray' > - </th>"
            'strTotalRegion &= "<th style= 'background:gray' > " & dblCurrent.ToString(FORMATO_MONEDA) & " </th>"
            'strTotalRegion &= "<th style= 'background:gray' > " & dbl1to30.ToString(FORMATO_MONEDA) & " </th>"
            'strTotalRegion &= "<th style= 'background:gray' > " & dbl30to60.ToString(FORMATO_MONEDA) & " </th>"
            'strTotalRegion &= "<th style= 'background:gray' > " & dbl60to90.ToString(FORMATO_MONEDA) & " </th>"
            'strTotalRegion &= "<th style= 'background:gray' > " & dblmas90.ToString(FORMATO_MONEDA) & " </th>"
            strTotalRegion &= "<th style= 'background:gray' > " & ((dblCurrent + dbl1to30 + dbl30to60 + dbl60to90 + dblmas90)).ToString(FORMATO_MONEDA) & " </th>"
            strTotalRegion &= "<th style= 'background:gray' > " & dblSemana1.ToString(FORMATO_MONEDA) & " </th>"
            strTotalRegion &= "<th style= 'background:gray' > " & dblSemana2.ToString(FORMATO_MONEDA) & " </th>"
            strTotalRegion &= "<th style= 'background:gray' > " & dblSemana3.ToString(FORMATO_MONEDA) & " </th>"
            strTotalRegion &= "<th style= 'background:gray' > " & dblSemana4.ToString(FORMATO_MONEDA) & " </th>"
            strTotalRegion &= "<th style= 'background:gray' > " & dblSemana5.ToString(FORMATO_MONEDA) & " </th>"
            strTotalRegion &= "<th style= 'background:gray' > " & dblSemana6.ToString(FORMATO_MONEDA) & " </th>"
            strTotalRegion &= "<th style= 'background:gray' > " & dblSemana7.ToString(FORMATO_MONEDA) & " </th>"
            strTotalRegion &= "<th style= 'background:gray' > " & dblSemana8.ToString(FORMATO_MONEDA) & " </th>"
            strTotalRegion &= "<th style= 'background:gray' > " & dblSemana9.ToString(FORMATO_MONEDA) & " </th>"
            strTotalRegion &= "<th style= 'background:gray' > </th>"

            strTotalRegion &= " </tr> "
            ' strTotalRegion &= "</table>"
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        Return strTotalRegion
    End Function

    Private Function TotalGeneralCxpCorporativo(ByVal dblCurrent As Double, ByVal dbl1to30 As Double, ByVal dbl30to60 As Double, ByVal dbl60to90 As Double, ByVal dblmas90 As Double, ByVal dblTotal As Double, ByVal dblTotalSemana1 As Double, ByVal dblTotalSemana2 As Double, ByVal dblTotalSemana3 As Double, ByVal dblTotalSemana4 As Double, ByVal dblTotalSemana5 As Double, ByVal dblTotalSemana6 As Double, ByVal dblTotalSemana7 As Double, ByVal dblTotalSemana8 As Double, ByVal dblTotalSemana9 As Double) As String
        Dim strTotalRegion As String = STR_VACIO
        Try
            ' strTotalRegion &= "<table >"
            strTotalRegion &= " <tr> "
            strTotalRegion &= "<th colspan = '7' style= 'background:gray;text-align: right'> - Gran Total </th>"
            strTotalRegion &= "<th style= 'background:gray' > - </th>"
            strTotalRegion &= "<th style= 'background:gray;width:2cm' > " & (dblCurrent + dbl1to30 + dbl30to60 + dbl60to90 + dblmas90).ToString(FORMATO_MONEDA) & " </th>"
            strTotalRegion &= "<th style= 'background:gray' > " & dblTotalSemana1.ToString(FORMATO_MONEDA) & " </th>"
            strTotalRegion &= "<th style= 'background:gray' > " & dblTotalSemana2.ToString(FORMATO_MONEDA) & " </th>"
            strTotalRegion &= "<th style= 'background:gray' > " & dblTotalSemana3.ToString(FORMATO_MONEDA) & " </th>"
            strTotalRegion &= "<th style= 'background:gray' > " & dblTotalSemana4.ToString(FORMATO_MONEDA) & " </th>"
            strTotalRegion &= "<th style= 'background:gray' > " & dblTotalSemana5.ToString(FORMATO_MONEDA) & " </th>"
            strTotalRegion &= "<th style= 'background:gray' > " & dblTotalSemana6.ToString(FORMATO_MONEDA) & " </th>"
            strTotalRegion &= "<th style= 'background:gray' > " & dblTotalSemana7.ToString(FORMATO_MONEDA) & " </th>"
            strTotalRegion &= "<th style= 'background:gray' > " & dblTotalSemana8.ToString(FORMATO_MONEDA) & " </th>"
            strTotalRegion &= "<th style= 'background:gray' > " & dblTotalSemana9.ToString(FORMATO_MONEDA) & " </th>"
            strTotalRegion &= "<th style= 'background:gray' > </th>"
            strTotalRegion &= " </tr> "
            'strTotalRegion &= "</table>"
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        Return strTotalRegion
    End Function

    Private Function TotalGeneralCxpCorporativoSummary(ByVal dblCurrent As Double, ByVal dbl1to30 As Double, ByVal dbl30to60 As Double, ByVal dbl60to90 As Double, ByVal dblmas90 As Double, ByVal dblTotal As Double) As String
        Dim strTotalRegion As String = STR_VACIO
        Try
            ' strTotalRegion &= "<table >"
            strTotalRegion &= " <tr> "
            strTotalRegion &= "<th style= 'background:gray;width:1cm' > - Total </th>"
            strTotalRegion &= "<th style= 'background:gray;width:3cm' >" & dblCurrent.ToString(FORMATO_MONEDA) & " </th>"
            strTotalRegion &= "<th style= 'background:gray;width:2cm' >" & dbl1to30.ToString(FORMATO_MONEDA) & " </th>"
            strTotalRegion &= "<th style= 'background:gray;width:2cm' >" & dbl30to60.ToString(FORMATO_MONEDA) & " </th>"
            strTotalRegion &= "<th style= 'background:gray;width:2cm' >" & dbl60to90.ToString(FORMATO_MONEDA) & " </th>"
            strTotalRegion &= "<th style= 'background:gray;width:1cm' >" & dblmas90.ToString(FORMATO_MONEDA) & " </th>"
            strTotalRegion &= "<th style= 'background:gray;width:2cm' > " & (dblCurrent + dbl1to30 + dbl30to60 + dbl60to90 + dblmas90).ToString(FORMATO_MONEDA) & " </th>"

            strTotalRegion &= " </tr> "
            'strTotalRegion &= "</table>"
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        Return strTotalRegion
    End Function

    Public Sub Cxprepcorporativo(ByVal FechaCorte As Date, ByVal intEmp As Integer, ByVal intTipoRpt As Integer)
        Dim strSQL As String = STR_VACIO
        Dim f As Byte
        Dim strTemp As String = STR_VACIO
        Dim logPrimeraLInea As Boolean = True
        ' Dim frm As New frmFiltro

        Dim dblSubtotaCurrent As Double = INT_CERO
        Dim dblSubtotal1to30 As Double = INT_CERO
        Dim dblSubtotal30to60 As Double = INT_CERO
        Dim dblSubtotal60to90 As Double = INT_CERO
        Dim dblSubtotalmas90 As Double = INT_CERO
        Dim dblSubtotalTotal As Double = INT_CERO
        Dim dblSubTotalSemana1 As Double = INT_CERO
        Dim dblSubTotalSemana2 As Double = INT_CERO
        Dim dblSubTotalSemana3 As Double = INT_CERO
        Dim dblSubTotalSemana4 As Double = INT_CERO
        Dim dblSubTotalSemana5 As Double = INT_CERO
        Dim dblSubTotalSemana6 As Double = INT_CERO
        Dim dblSubTotalSemana7 As Double = INT_CERO
        Dim dblSubTotalSemana8 As Double = INT_CERO
        Dim dblSubTotalSemana9 As Double = INT_CERO

        Dim dblTotaCurrent As Double = INT_CERO
        Dim dblTotal1to30 As Double = INT_CERO
        Dim dblTotal30to60 As Double = INT_CERO
        Dim dblTotal60to90 As Double = INT_CERO
        Dim dblTotalmas90 As Double = INT_CERO
        Dim dblTtoalTotal As Double = INT_CERO
        Dim dblTotalSemana1 As Double = INT_CERO
        Dim dblTotalSemana2 As Double = INT_CERO
        Dim dblTotalSemana3 As Double = INT_CERO
        Dim dblTotalSemana4 As Double = INT_CERO
        Dim dblTotalSemana5 As Double = INT_CERO
        Dim dblTotalSemana6 As Double = INT_CERO
        Dim dblTotalSemana7 As Double = INT_CERO
        Dim dblTotalSemana8 As Double = INT_CERO
        Dim dblTotalSemana9 As Double = INT_CERO

        Dim strHTML As String = STR_VACIO
        Dim strSubtotal As String = STR_VACIO
        Dim strDetalle As String = STR_VACIO
        Dim intGrupo As Integer = NO_FILA
        Dim strGrupo As String = STR_VACIO

        Dim Miercoles1 As DateTime
        Dim Miercoles2 As DateTime
        Dim Miercoles3 As DateTime
        Dim Miercoles4 As DateTime
        Dim Miercoles5 As DateTime
        Dim Miercoles6 As DateTime
        Dim Miercoles7 As DateTime
        Dim Miercoles8 As DateTime
        Dim Miercoles9 As DateTime
        'Dim Miercoles3 As DateTime

        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader
        Try


            strTemp = cFunciones.ArchivoTemporal
            f = FreeFile()
            FileOpen(f, strTemp, OpenMode.Append)


            strHTML &= EncabezadoCxpCorporativo(FechaCorte, intEmp)
            strHTML &= "<table>"

            strSQL = SQLCxpCorporativo(FechaCorte, intEmp, intTipoRpt)
            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSQL, CON)
            REA = COM.ExecuteReader

            strHTML &= ColumnasCxpCorporativo(FechaCorte)
            If REA.HasRows Then
                Do While REA.Read
                    If logPrimeraLInea = True Then
                        logPrimeraLInea = False
                        intGrupo = REA.GetInt32("igrup")
                        strGrupo = REA.GetString("grup")
                    Else
                        If intGrupo = REA.GetInt32("igrup") Then

                        Else
                            strHTML &= strDetalle
                            strHTML &= SubTotalCxpCorporativo(strGrupo, dblSubtotaCurrent, dblSubtotal1to30, dblSubtotal30to60, dblSubtotal60to90, dblSubtotalmas90, dblSubtotalTotal, dblSubTotalSemana1, dblSubTotalSemana2, dblSubTotalSemana3, dblSubTotalSemana4, dblSubTotalSemana5, dblSubTotalSemana6, dblSubTotalSemana7, dblSubTotalSemana8, dblSubTotalSemana9)
                            'strHTML &= ColumnasCxpCorporativo()
                            intGrupo = REA.GetInt32("igrup")
                            strGrupo = REA.GetString("grup")


                            dblSubTotalSemana1 = INT_CERO
                            dblSubTotalSemana2 = INT_CERO
                            dblSubTotalSemana3 = INT_CERO
                            dblSubTotalSemana4 = INT_CERO
                            dblSubTotalSemana5 = INT_CERO
                            dblSubTotalSemana6 = INT_CERO
                            dblSubTotalSemana7 = INT_CERO
                            dblSubTotalSemana8 = INT_CERO
                            dblSubTotalSemana9 = INT_CERO

                            dblSubtotaCurrent = INT_CERO
                            dblSubtotal1to30 = INT_CERO
                            dblSubtotal30to60 = INT_CERO
                            dblSubtotal60to90 = INT_CERO
                            dblSubtotalmas90 = INT_CERO
                            dblSubtotalTotal = INT_CERO
                            strSubtotal = STR_VACIO
                            strDetalle = STR_VACIO
                        End If
                    End If
                    '' linea
                    'acumular

                    dblSubtotaCurrent = dblSubtotaCurrent + REA.GetDouble("dia0")
                    dblSubtotal1to30 = dblSubtotal1to30 + REA.GetDouble("dia1_30")
                    dblSubtotal30to60 = dblSubtotal30to60 + REA.GetDouble("dia31_60")
                    dblSubtotal60to90 = dblSubtotal60to90 + REA.GetDouble("dia60_90")
                    dblSubtotalmas90 = dblSubtotalmas90 + REA.GetDouble("dia90")
                    dblSubtotalTotal = dblSubtotalTotal + dblSubtotaCurrent + dblSubtotal1to30 + dblSubtotal30to60 + dblSubtotal60to90 + dblSubtotalmas90


                    dblTotaCurrent = dblTotaCurrent + REA.GetDouble("dia0")
                    dblTotal1to30 = dblTotal1to30 + REA.GetDouble("dia1_30")
                    dblTotal30to60 = dblTotal30to60 + REA.GetDouble("dia31_60")
                    dblTotal60to90 = dblTotal60to90 + REA.GetDouble("dia60_90")
                    dblTotalmas90 = dblTotalmas90 + REA.GetDouble("dia90")
                    dblTtoalTotal = dblTtoalTotal + dblTotaCurrent + dblTotal1to30 + dblTotal30to60 + dblTotal60to90 + dblTotalmas90
                    ' Totales 
                    'dblTotalSemana1 = dblTotalSemana1 + (REA.GetDouble("dia0") + REA.GetDouble("dia1_30") + REA.GetDouble("dia31_60") + REA.GetDouble("dia60_90") + REA.GetDouble("dia90")).ToString(FORMATO_MONEDA)
                    'dblTotalSemana2 = dblTotalSemana2 + (REA.GetDouble("dia0") + REA.GetDouble("dia1_30") + REA.GetDouble("dia31_60") + REA.GetDouble("dia60_90") + REA.GetDouble("dia90")).ToString(FORMATO_MONEDA)
                    'dblTotalSemana3 = dblTotalSemana3 + (REA.GetDouble("dia0") + REA.GetDouble("dia1_30") + REA.GetDouble("dia31_60") + REA.GetDouble("dia60_90") + REA.GetDouble("dia90")).ToString(FORMATO_MONEDA)

                    'De viernes pasó a miércoles
                    Miercoles1 = ObtenerMiercoles(FechaCorte)
                    Miercoles2 = Miercoles1.AddDays(+7)
                    Miercoles3 = Miercoles2.AddDays(+7)
                    Miercoles4 = Miercoles3.AddDays(+7)
                    Miercoles5 = Miercoles4.AddDays(+7)
                    Miercoles6 = Miercoles5.AddDays(+7)
                    Miercoles7 = Miercoles6.AddDays(+7)
                    Miercoles8 = Miercoles7.AddDays(+7)
                    Miercoles9 = Miercoles8.AddDays(+7)

                    strDetalle &= " <tr> "
                    strDetalle &= "<td>" & REA.GetString("nombre_empresa") & "</td>"
                    strDetalle &= "<td>" & strGrupo & "</td>"
                    strDetalle &= "<td>" & REA.GetString("nombre") & "</td>"

                    strDetalle &= "<td>" & REA.GetString("referencia") & "</td>"
                    strDetalle &= "<td>" & REA.GetString("factura") & "</td>"
                    strDetalle &= "<td>" & REA.GetMySqlDateTime("fecha").ToString & "</td>"
                    strDetalle &= "<td>" & REA.GetMySqlDateTime("vencimiento").ToString & "</td>"
                    strDetalle &= "<td>" & (DateDiff(DateInterval.Day, REA.GetDateTime("fecha"), REA.GetDateTime("vencimiento"))) & "</td>"

                    strDetalle &= "<td>" & (REA.GetDouble("dia0") + REA.GetDouble("dia1_30") + REA.GetDouble("dia31_60") + REA.GetDouble("dia60_90") + REA.GetDouble("dia90")).ToString(FORMATO_MONEDA) & "</td>"
                    If REA.GetMySqlDateTime("vencimiento").ToString <= Miercoles1 Then
                        dblSubTotalSemana1 = dblSubTotalSemana1 + (REA.GetDouble("dia0") + REA.GetDouble("dia1_30") + REA.GetDouble("dia31_60") + REA.GetDouble("dia60_90") + REA.GetDouble("dia90")).ToString(FORMATO_MONEDA)
                        dblTotalSemana1 = dblTotalSemana1 + (REA.GetDouble("dia0") + REA.GetDouble("dia1_30") + REA.GetDouble("dia31_60") + REA.GetDouble("dia60_90") + REA.GetDouble("dia90")).ToString(FORMATO_MONEDA)
                        strDetalle &= "<td>" & (REA.GetDouble("dia0") + REA.GetDouble("dia1_30") + REA.GetDouble("dia31_60") + REA.GetDouble("dia60_90") + REA.GetDouble("dia90")).ToString(FORMATO_MONEDA) & "<br></td>"
                    Else
                        strDetalle &= "<td> <br></td>"
                    End If
                    If REA.GetMySqlDateTime("vencimiento").ToString > Miercoles1 And REA.GetMySqlDateTime("vencimiento").ToString <= Miercoles2 Then
                        dblSubTotalSemana2 = dblSubTotalSemana2 + (REA.GetDouble("dia0") + REA.GetDouble("dia1_30") + REA.GetDouble("dia31_60") + REA.GetDouble("dia60_90") + REA.GetDouble("dia90")).ToString(FORMATO_MONEDA)
                        dblTotalSemana2 = dblTotalSemana2 + (REA.GetDouble("dia0") + REA.GetDouble("dia1_30") + REA.GetDouble("dia31_60") + REA.GetDouble("dia60_90") + REA.GetDouble("dia90")).ToString(FORMATO_MONEDA)
                        strDetalle &= "<td>" & (REA.GetDouble("dia0") + REA.GetDouble("dia1_30") + REA.GetDouble("dia31_60") + REA.GetDouble("dia60_90") + REA.GetDouble("dia90")).ToString(FORMATO_MONEDA) & "<br></td>"
                    Else
                        strDetalle &= "<td> <br></td>"
                    End If
                    If REA.GetMySqlDateTime("vencimiento").ToString > Miercoles2 And REA.GetMySqlDateTime("vencimiento").ToString <= Miercoles3 Then
                        dblSubTotalSemana3 = dblSubTotalSemana3 + (REA.GetDouble("dia0") + REA.GetDouble("dia1_30") + REA.GetDouble("dia31_60") + REA.GetDouble("dia60_90") + REA.GetDouble("dia90")).ToString(FORMATO_MONEDA)
                        dblTotalSemana3 = dblTotalSemana3 + (REA.GetDouble("dia0") + REA.GetDouble("dia1_30") + REA.GetDouble("dia31_60") + REA.GetDouble("dia60_90") + REA.GetDouble("dia90")).ToString(FORMATO_MONEDA)
                        strDetalle &= "<td>" & (REA.GetDouble("dia0") + REA.GetDouble("dia1_30") + REA.GetDouble("dia31_60") + REA.GetDouble("dia60_90") + REA.GetDouble("dia90")).ToString(FORMATO_MONEDA) & "<br></td>"
                    Else
                        strDetalle &= "<td> <br></td>"
                    End If
                    If REA.GetMySqlDateTime("vencimiento").ToString > Miercoles3 And REA.GetMySqlDateTime("vencimiento").ToString <= Miercoles4 Then
                        dblSubTotalSemana4 = dblSubTotalSemana4 + (REA.GetDouble("dia0") + REA.GetDouble("dia1_30") + REA.GetDouble("dia31_60") + REA.GetDouble("dia60_90") + REA.GetDouble("dia90")).ToString(FORMATO_MONEDA)
                        dblTotalSemana4 = dblTotalSemana4 + (REA.GetDouble("dia0") + REA.GetDouble("dia1_30") + REA.GetDouble("dia31_60") + REA.GetDouble("dia60_90") + REA.GetDouble("dia90")).ToString(FORMATO_MONEDA)
                        strDetalle &= "<td>" & (REA.GetDouble("dia0") + REA.GetDouble("dia1_30") + REA.GetDouble("dia31_60") + REA.GetDouble("dia60_90") + REA.GetDouble("dia90")).ToString(FORMATO_MONEDA) & "<br></td>"
                    Else
                        strDetalle &= "<td> <br></td>"
                    End If
                    If REA.GetMySqlDateTime("vencimiento").ToString > Miercoles4 And REA.GetMySqlDateTime("vencimiento").ToString <= Miercoles5 Then
                        dblSubTotalSemana5 = dblSubTotalSemana5 + (REA.GetDouble("dia0") + REA.GetDouble("dia1_30") + REA.GetDouble("dia31_60") + REA.GetDouble("dia60_90") + REA.GetDouble("dia90")).ToString(FORMATO_MONEDA)
                        dblTotalSemana5 = dblTotalSemana5 + (REA.GetDouble("dia0") + REA.GetDouble("dia1_30") + REA.GetDouble("dia31_60") + REA.GetDouble("dia60_90") + REA.GetDouble("dia90")).ToString(FORMATO_MONEDA)
                        strDetalle &= "<td>" & (REA.GetDouble("dia0") + REA.GetDouble("dia1_30") + REA.GetDouble("dia31_60") + REA.GetDouble("dia60_90") + REA.GetDouble("dia90")).ToString(FORMATO_MONEDA) & "<br></td>"
                    Else
                        strDetalle &= "<td> <br></td>"
                    End If
                    If REA.GetMySqlDateTime("vencimiento").ToString > Miercoles5 And REA.GetMySqlDateTime("vencimiento").ToString <= Miercoles6 Then
                        dblSubTotalSemana6 = dblSubTotalSemana6 + (REA.GetDouble("dia0") + REA.GetDouble("dia1_30") + REA.GetDouble("dia31_60") + REA.GetDouble("dia60_90") + REA.GetDouble("dia90")).ToString(FORMATO_MONEDA)
                        dblTotalSemana6 = dblTotalSemana6 + (REA.GetDouble("dia0") + REA.GetDouble("dia1_30") + REA.GetDouble("dia31_60") + REA.GetDouble("dia60_90") + REA.GetDouble("dia90")).ToString(FORMATO_MONEDA)
                        strDetalle &= "<td>" & (REA.GetDouble("dia0") + REA.GetDouble("dia1_30") + REA.GetDouble("dia31_60") + REA.GetDouble("dia60_90") + REA.GetDouble("dia90")).ToString(FORMATO_MONEDA) & "<br></td>"
                    Else
                        strDetalle &= "<td> <br></td>"
                    End If
                    If REA.GetMySqlDateTime("vencimiento").ToString > Miercoles6 And REA.GetMySqlDateTime("vencimiento").ToString <= Miercoles7 Then
                        dblSubTotalSemana7 = dblSubTotalSemana7 + (REA.GetDouble("dia0") + REA.GetDouble("dia1_30") + REA.GetDouble("dia31_60") + REA.GetDouble("dia60_90") + REA.GetDouble("dia90")).ToString(FORMATO_MONEDA)
                        dblTotalSemana7 = dblTotalSemana7 + (REA.GetDouble("dia0") + REA.GetDouble("dia1_30") + REA.GetDouble("dia31_60") + REA.GetDouble("dia60_90") + REA.GetDouble("dia90")).ToString(FORMATO_MONEDA)
                        strDetalle &= "<td>" & (REA.GetDouble("dia0") + REA.GetDouble("dia1_30") + REA.GetDouble("dia31_60") + REA.GetDouble("dia60_90") + REA.GetDouble("dia90")).ToString(FORMATO_MONEDA) & "<br></td>"
                    Else
                        strDetalle &= "<td> <br></td>"
                    End If
                    If REA.GetMySqlDateTime("vencimiento").ToString > Miercoles7 And REA.GetMySqlDateTime("vencimiento").ToString <= Miercoles8 Then
                        dblSubTotalSemana8 = dblSubTotalSemana8 + (REA.GetDouble("dia0") + REA.GetDouble("dia1_30") + REA.GetDouble("dia31_60") + REA.GetDouble("dia60_90") + REA.GetDouble("dia90")).ToString(FORMATO_MONEDA)
                        dblTotalSemana8 = dblTotalSemana8 + (REA.GetDouble("dia0") + REA.GetDouble("dia1_30") + REA.GetDouble("dia31_60") + REA.GetDouble("dia60_90") + REA.GetDouble("dia90")).ToString(FORMATO_MONEDA)
                        strDetalle &= "<td>" & (REA.GetDouble("dia0") + REA.GetDouble("dia1_30") + REA.GetDouble("dia31_60") + REA.GetDouble("dia60_90") + REA.GetDouble("dia90")).ToString(FORMATO_MONEDA) & "<br></td>"
                    Else
                        strDetalle &= "<td> <br></td>"
                    End If
                    If REA.GetMySqlDateTime("vencimiento").ToString > Miercoles8 And REA.GetMySqlDateTime("vencimiento").ToString <= Miercoles9 Then
                        dblSubTotalSemana9 = dblSubTotalSemana9 + (REA.GetDouble("dia0") + REA.GetDouble("dia1_30") + REA.GetDouble("dia31_60") + REA.GetDouble("dia60_90") + REA.GetDouble("dia90")).ToString(FORMATO_MONEDA)
                        dblTotalSemana9 = dblTotalSemana9 + (REA.GetDouble("dia0") + REA.GetDouble("dia1_30") + REA.GetDouble("dia31_60") + REA.GetDouble("dia60_90") + REA.GetDouble("dia90")).ToString(FORMATO_MONEDA)
                        strDetalle &= "<td>" & (REA.GetDouble("dia0") + REA.GetDouble("dia1_30") + REA.GetDouble("dia31_60") + REA.GetDouble("dia60_90") + REA.GetDouble("dia90")).ToString(FORMATO_MONEDA) & "<br></td>"
                    Else
                        strDetalle &= "<td> <br></td>"
                    End If
                    strDetalle &= "<td>" & REA.GetString("notas") & "</td>"
                    REA.GetMySqlDateTime("vencimiento").ToString()

                    strDetalle &= " </tr> "


                Loop
                strHTML &= strDetalle
                strHTML &= SubTotalCxpCorporativo(strGrupo, dblSubtotaCurrent, dblSubtotal1to30, dblSubtotal30to60, dblSubtotal60to90, dblSubtotalmas90, dblSubtotalTotal, dblSubTotalSemana1, dblSubTotalSemana2, dblSubTotalSemana3, dblSubTotalSemana4, dblSubTotalSemana5, dblSubTotalSemana6, dblSubTotalSemana7, dblSubTotalSemana8, dblSubTotalSemana9)

            End If
            '    strHTML &= SubTotalCxpCorporativo(strGrupo, dblSubtotaCurrent, dblSubtotal1to30, dblSubtotal30to60, dblSubtotal60to90, dblSubtotalmas90, dblSubtotalTotal)
            strHTML &= TotalGeneralCxpCorporativo(dblTotaCurrent, dblTotal1to30, dblTotal30to60, dblTotal60to90, dblTotalmas90, dblTtoalTotal, dblTotalSemana1, dblTotalSemana2, dblTotalSemana3, dblTotalSemana4, dblTotalSemana5, dblTotalSemana6, dblTotalSemana7, dblTotalSemana8, dblTotalSemana9)
            Print(f, strHTML)
            Print(f, "</table>")
            Print(f, "</body>")
            Print(f, "</html>")
            FileClose(f)
            MostarReporte(strTemp)



        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Public Sub CxprepcorporativoSummary(ByVal FechaCorte As Date, ByVal intEmp As Integer, ByVal intTipoRpt As Integer)
        Dim strSQL As String = STR_VACIO
        Dim f As Byte
        Dim strTemp As String = STR_VACIO
        Dim logPrimeraLInea As Boolean = True
        ' Dim frm As New frmFiltro

        Dim dblTotaCurrent As Double = INT_CERO
        Dim dblTotal1to30 As Double = INT_CERO
        Dim dblTotal30to60 As Double = INT_CERO
        Dim dblTotal60to90 As Double = INT_CERO
        Dim dblTotalmas90 As Double = INT_CERO
        Dim dblTotalTotal As Double = INT_CERO

        Dim strHTML As String = STR_VACIO
        Dim intGrupo As Integer = NO_FILA
        Dim strGrupo As String = STR_VACIO

        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader
        Try


            strTemp = cFunciones.ArchivoTemporal
            f = FreeFile()
            FileOpen(f, strTemp, OpenMode.Append)

            strHTML &= EncabezadoCxpCorporativo(FechaCorte, intEmp)
            strHTML &= "<table>"

            strSQL = SQLCxpCorporativoSumary(FechaCorte, intEmp, intTipoRpt)
            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSQL, CON)
            REA = COM.ExecuteReader

            strHTML &= ColumnasCxpCorporativoSummary()
            If REA.HasRows Then
                Do While REA.Read

                    '' linea
                    strHTML &= " <tr> "
                    strHTML &= "<td>" & REA.GetString("grup") & "</td>"

                    '    strHTML &= "<td>" & REA.GetDouble("Saldo").ToString(FORMATO_MONEDA) & "</td>"
                    strHTML &= "<td>" & REA.GetDouble("dia0").ToString(FORMATO_MONEDA) & "</td>"
                    strHTML &= "<td>" & REA.GetDouble("dia1_30").ToString(FORMATO_MONEDA) & "</td>"
                    strHTML &= "<td>" & REA.GetDouble("dia31_60").ToString(FORMATO_MONEDA) & "</td>"
                    strHTML &= "<td>" & REA.GetDouble("dia60_90").ToString(FORMATO_MONEDA) & "</td>"
                    strHTML &= "<td>" & REA.GetDouble("dia90").ToString(FORMATO_MONEDA) & "</td>"
                    strHTML &= "<td>" & (REA.GetDouble("dia0") + REA.GetDouble("dia1_30") + REA.GetDouble("dia31_60") + REA.GetDouble("dia60_90") + REA.GetDouble("dia90")).ToString(FORMATO_MONEDA) & "</td>"
                    strHTML &= " </tr> "

                    'acumular

                    dblTotaCurrent = dblTotaCurrent + REA.GetDouble("dia0")
                    dblTotal1to30 = dblTotal1to30 + REA.GetDouble("dia1_30")
                    dblTotal30to60 = dblTotal30to60 + REA.GetDouble("dia31_60")
                    dblTotal60to90 = dblTotal60to90 + REA.GetDouble("dia60_90")
                    dblTotalmas90 = dblTotalmas90 + REA.GetDouble("dia90")
                    dblTotalTotal = dblTotalTotal + dblTotaCurrent + dblTotal1to30 + dblTotal60to90 + dblTotalmas90
                Loop

            End If

            strHTML &= TotalGeneralCxpCorporativoSummary(dblTotaCurrent, dblTotal1to30, dblTotal30to60, dblTotal60to90, dblTotalmas90, dblTotalTotal)
            Print(f, strHTML)
            Print(f, "</table>")
            Print(f, "</body>")
            Print(f, "</html>")
            FileClose(f)
            MostarReporte(strTemp)

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub
#End Region


#Region "OpenInvoice"

    Private Function SqlOpenInvoiceCorp()
        Dim strSQL As String = STR_VACIO

        strSQL = " SELECT op.serief,op.autorizacionf,op.idGrupo, op.idEmpresa, op.codigo, op.nombreEmp, op.fecha, op.numero, op.referencia, op.descripcion, op.limiteCredito, op.diasCredito, op.Vencimiento, op.dias_atrasados, op.balance_abierto, IFNULL(op.monto_Vencido,0.00) monto_Vencido, op.intereses, op.balanceQ, op.tasa_Cambio, op.programa, op.proforma, op.pagare, IFNULL(op.fecha_entrega, '-')fecha_entrega, op.registro, IFNULL(g.nombre_Grupo, 'SIN GRUPO') nombreGrupo,e.nombre_empresa "
        strSQL &= "    From YarnDivision.Open_Invoice op "
        strSQL &= "        LEFT JOIN YarnDivision.Grupo_Detalle gd ON gd.idGrupo =op.idGrupo AND gd.Codigo = op.codigo AND gd.idEmpresa = op.idEmpresa AND gd.idTipo = 1 "
        strSQL &= "            LEFT JOIN YarnDivision.Grupo g ON g.idGrupo = gd.idGrupo AND g.idTipo = 1 "
        strSQL &= "                LEFT JOIN YarnDivision.Empresa e ON e.idEmpresa = op.idEmpresa "
        strSQL &= "                    WHERE op.correlativo >0 AND op.idGrupo IN(gd.idGrupo, -1) " ' se le agregó el tipo de grupo ya que habrán diversos tipos de grupos
        strSQL &= "                        ORDER BY  g.nombre_Grupo ASC, e.idEmpresa, op.codigo, op.fecha "

        Return strSQL

    End Function


    Public Sub OpenInvoiceCorp()
        Dim sql As String = STR_VACIO
        Dim strTemp As String = STR_VACIO
        Dim REA As MySqlDataReader
        Dim COM As MySqlCommand
        Dim f As Byte
        Dim i As Integer = 0
        Dim intGrupo As Integer = 0
        Dim dblAcumula As Double = 0
        Dim SaldoVencido As Double = 0
        Dim intLineas As Integer = 0
        Dim SumaInteres As Double = 0
        Dim SaldoQ As Double = 0
        Dim diasAtrasados As String = vbNullString
        Dim strCadena As String = STR_VACIO
        Dim arrayCadena() As String

        sql = SqlOpenInvoiceCorp()
        Try
            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(sql, CON)
            REA = COM.ExecuteReader

            strTemp = cFunciones.ArchivoTemporal
            f = FreeFile()
            FileOpen(f, strTemp, OpenMode.Append)

            If REA.HasRows Then
                Do While REA.Read

                    If i = 0 Then

                        Print(f, " <html > ")
                        Print(f, " <head > ")
                        Print(f, "<style type='text/css'>")
                        Print(f, " table {table-layout: fixed; empty-cells: show; border-collapse:collapse}")
                        Print(f, " caption {padding: 5px; text-align:left; font-family: Tahoma,  Arial;font-size: 8pt}")
                        Print(f, " td {text-align:center;border:solid Gray 1px; padding:3px 5px; font-family: Tahoma, Arial;font-size: 7pt}")
                        Print(f, " th {width: 1.8cm; border:solid Gray 1px; background-color: Black; color: White; padding:2px 5px; font-family: Tahoma,  Arial;font-size: 6pt}")
                        Print(f, " th {text-align:center;border:solid Gray 1px; padding:3px 5px; font-family: Tahoma,  Arial;font-size: 7pt}")
                        Print(f, " th.numero {text-align:right; mso-number-format:\#\,\#\#0\.00}")
                        Print(f, " th.unitario {text-align:right; mso-number-format:\#\,\#\#0\.00#####}")
                        Print(f, " th.titulo {text-align:right;font-family: Tahoma,  Arial;font-size: 9pt")
                        Print(f, " .titulo {font-family: Tahoma,  Arial;font-size: 9pt}")
                        Print(f, " .encabezado {text-align: left; border: none; width: 3.1cm}")
                        Print(f, " .pie {font-family: Tahoma,  Arial;font-size: 7pt}")
                        Print(f, " .izquierda {text-align:left}")
                        Print(f, " .centro {text-align:center}")
                        Print(f, " .derecha {text-align:right}")
                        Print(f, " .info {text-align:left; border:none}")
                        Print(f, "</style>")
                        Print(f, "<right><h3> <b> <th > Open Invoice Corp</th></h3></b></right>")
                        Print(f, "<right><h5> <b> <th > cutoff date: " & REA.GetDateTime("registro").ToString(FORMATO_MYSQL) & " </th></h5></b></right>")
                        Print(f, "<right><h3> <b> <th > Amounts expressed in US$ </th></h3></b></right>")
                        Print(f, "</head>")

                        Print(f, "<body>")
                        Print(f, "<table cellspacing =0 >")
                        Print(f, "<tr>")
                        Print(f, "<th style='width: 7cm; border:1px solid black'>CUSTOMER</th>")
                        Print(f, "<th style='width: 4cm; border:1px solid black'>BILLER</th>")
                        Print(f, "<th style='width: 2cm; border:1px solid black'>DATE</th>")
                        Print(f, "<th style='width: 2cm; border:1px solid black'>INVOICE</th>")
                        'Print(f, "<th style='width: 7cm; border:1px solid black; visibility: hidden'>MEMO</th>")
                        Print(f, "<th style='width: 7cm; border:1px solid black'>DESCRIPTION</th>")
                        Print(f, "<th style='width: 1.5cm; border:1px solid black'>TERMS</th>")
                        Print(f, "<th style='width: 2cm; border:1px solid black'>DUE DATE</th>")
                        Print(f, "<th style='width: 1cm; border:1px solid black'>AGING</th>")
                        Print(f, "<th style='width: 3.5cm; border:1px solid black'>OPEN BALANCE</th>")
                        Print(f, "<th style='width: 2.2cm; border:1px solid black'>COMULATIVE</th>")
                        Print(f, "<th style='width: 2.8cm; border:1px solid black'>PAST DUES</th>")
                        Print(f, "<th style='width: 2.3cm'; border:1px solid black'>INTEREST</th>")
                        Print(f, "<th style='width: 3cm; border:1px solid black'>BUYER</th>")
                        Print(f, "<th style='width: 1.5cm; border:1px solid black'>T/C</th>")
                        Print(f, "<th style='width: 3.5cm; border:1px solid black'>BALANCE /Q</th>")
                        Print(f, "<th style='width: 4cm; border:1px solid black'>PF</th>")
                        Print(f, "<th style='width: 2.3cm; border:1px solid black'>PROMISSORY NOTE</th>")
                        Print(f, "<th style='width: 3cm; border:1px solid black'>DELIVERY</th>")
                        Print(f, "<th style='width: 3cm; border:1px solid black'>SERIES</th>")
                        Print(f, "<th style='width: 3cm; border:1px solid black'>AUTHORIZATION</th>")

                        Print(f, "</tr>")
                    End If

                    If Not intGrupo = REA.GetInt16("idGrupo") Then


                        If intLineas > 0 Then
                            'imprima total
                            Print(f, " <tr> ")
                            Print(f, " <td style='width: 7cm; border:1px solid black'> <br></td>")
                            Print(f, " <td style='width: 4cm; border:1px solid black'> <br></td>")
                            Print(f, "<td style='width: 2cm; border:1px solid black'> <br></td>")
                            Print(f, "<td style='width: 2cm; border:1px solid black'> <br></td>")
                            'Print(f, "<td style='width: 7cm; border:1px solid black'> <br></td>")
                            Print(f, "<td style='width: 7cm; border:1px solid black'> <br></td>")
                            Print(f, "<td style='width: 1.5cm; border:1px solid black'> <br></td>")
                            Print(f, "<td style='width: 2cm; border:1px solid black'> <br></td>")
                            Print(f, "<td style='width: 1cm; border:1px solid black'> <br></td>")
                            Print(f, "<td style='width: 3.5cm; border:1px solid black'><b>" & dblAcumula.ToString(FORMATO_MONEDA) & " </td>")
                            Print(f, "<td style='width: 2.2cm; border:1px solid black'>  <br></td>")
                            Print(f, "<td style='width: 2.8cm; border:1px solid black; color:red'><b>" & SaldoVencido.ToString(FORMATO_MONEDA) & "</td>")
                            Print(f, "<td style='width: 2.3cm; border:1px solid black; color:purple'><b>" & SumaInteres.ToString(FORMATO_MONEDA) & " </td>")
                            Print(f, "<td style='width: 3cm; border:1px solid black'> <br></td>")
                            Print(f, "<td style='width: 1.5cm; border:1px solid black'> <br></td>")
                            Print(f, "<td style='width: 3.5cm; border:1px solid black; color:navy'><b>" & SaldoQ.ToString(FORMATO_MONEDA) & " </td>")
                            Print(f, "<td style='width: 4cm; border:1px solid black'> <br></td>")
                            Print(f, "<td style='width: 2.3cm; border:1px solid black'> <br></td>")
                            Print(f, "<td style='width: 3cm; border:1px solid black'> <br></td>")
                            Print(f, "<td style='width: 3cm; border:1px solid black'> <br></td>")
                            Print(f, "<td style='width: 3cm; border:1px solid black'> <br></td>")

                            Print(f, "</tr>")
                        End If

                        'Reinicia Valores Necesarios
                        intLineas = 0
                        dblAcumula = 0
                        SaldoVencido = 0
                        SumaInteres = 0
                        SaldoQ = 0

                        Print(f, " <tr> ")
                        Print(f, "<th style=' border:1px solid black; background-color: teal; color: white; colspan:20'>" & REA.GetString("nombreGrupo") & " </th>")
                        Print(f, "<th style=' border:1px solid black; background-color: teal'> </th>")
                        Print(f, "<th style=' border:1px solid black; background-color: teal'> </th>")
                        Print(f, "<th style=' border:1px solid black; background-color: teal'> </th>")
                        'Print(f, "<th style=' border:1px solid black; background-color: teal'> </th>")
                        Print(f, "<th style=' border:1px solid black; background-color: teal'> </th>")
                        Print(f, "<th style=' border:1px solid black; background-color: teal'> </th>")
                        Print(f, "<th style=' border:1px solid black; background-color: teal'> </th>")
                        Print(f, "<th style=' border:1px solid black; background-color: teal'> </th>")
                        Print(f, "<th style=' border:1px solid black; background-color: teal'> </th>")
                        Print(f, "<th style=' border:1px solid black; background-color: teal'> </th>")
                        Print(f, "<th style=' border:1px solid black; background-color: teal'> </th>")
                        Print(f, "<th style=' border:1px solid black; background-color: teal'> </th>")
                        Print(f, "<th style=' border:1px solid black; background-color: teal'> </th>")
                        Print(f, "<th style=' border:1px solid black; background-color: teal'> </th>")
                        Print(f, "<th style=' border:1px solid black; background-color: teal'> </th>")
                        Print(f, "<th style=' border:1px solid black; background-color: teal'> </th>")
                        Print(f, "<th style=' border:1px solid black; background-color: teal'> </th>")
                        Print(f, "<th style=' border:1px solid black; background-color: teal'> </th>")
                        Print(f, "<th style=' border:1px solid black; background-color: teal'> </th>")
                        Print(f, "<th style=' border:1px solid black; background-color: teal'> </th>")

                        Print(f, " </tr> ")

                        Print(f, " <tr> ")
                        Print(f, " <td style='width: 7cm; border:1px solid black'>" & REA.GetString("nombreEmp") & " / " & REA.GetString("limiteCredito") & "</td>")
                        Print(f, "<td style='width: 4cm; border:1px solid black; background-color: #F2F5A9'>" & REA.GetString("nombre_empresa") & "</td>")
                        Print(f, "<td style='width: 2cm; border:1px solid black'>" & REA.GetMySqlDateTime("fecha").ToString & "</td>")
                        Print(f, "<td style='width: 2cm; border:1px solid black'>" & REA.GetInt32("numero") & "</td>")
                        'Print(f, "<td style='width: 7cm; border:1px solid black; visibility: hidden'>" & REA.GetString("referencia") & "</td>")
                        Print(f, "<td style='width: 7cm; border:1px solid black'>" & REA.GetString("Descripcion") & "</td>")
                        Print(f, "<td style='width: 1.5cm; border:1px solid black'>" & REA.GetString("diasCredito") & "</td>")
                        Print(f, "<td style='width: 2cm; border:1px solid black'>" & REA.GetMySqlDateTime("Vencimiento").ToString & "</td>")
                        If REA.GetString("dias_atrasados") = vbNullString Then
                            diasAtrasados = "-"
                        Else
                            diasAtrasados = REA.GetString("dias_atrasados")
                        End If
                        Print(f, "<td style='width: 1cm; border:1px solid black; color:red'>" & diasAtrasados & "</td>")
                        Print(f, "<td style='width: 3.5cm; border:1px solid black'>" & REA.GetDouble("balance_abierto") & "</td>")
                        dblAcumula = REA.GetDouble("balance_abierto") + dblAcumula
                        Print(f, "<td style='width: 2.2cm; border:1px solid black'>" & dblAcumula.ToString(FORMATO_MONEDA) & "</td>")
                        Print(f, "<td style='width: 2.8cm; border:1px solid black'>" & REA.GetDouble("monto_Vencido").ToString(FORMATO_MONEDA) & "</td>")
                        Print(f, "<td style='width: 2.3cm; border:1px solid black; color:orange'>" & REA.GetDouble("intereses").ToString(FORMATO_MONEDA) & "</td>")
                        Print(f, "<td style='width: 3cm; border:1px solid black'>" & REA.GetString("programa") & "</td>")
                        Print(f, "<td style='width: 1.5cm; border:1px solid black'>" & REA.GetDouble("tasa_Cambio").ToString(FORMATO_MONEDA) & "</td>")
                        Print(f, "<td style='width: 3.5cm; border:1px solid black; background-color: #F2F5A9'>" & REA.GetDouble("balanceQ").ToString(FORMATO_MONEDA) & "</td>")
                        Print(f, "<td style='width: 4cm; border:1px solid black'>" & REA.GetString("proforma") & "</td>")
                        Print(f, "<td style='width: 2.3cm; border:1px solid black'>" & REA.GetString("pagare") & "</td>")
                        Print(f, "<td style='width: 3cm; border:1px solid black; background-color: #F2F5A9'>" & REA.GetString("fecha_entrega") & "</td>")
                        strCadena = REA.GetString("serief")
                        arrayCadena = strCadena.Split("-".ToCharArray)
                        Print(f, "<td style='width: 3cm; border:1px solid black'>" & arrayCadena(INT_CERO) & "</td>")
                        Print(f, "<td style='width: 3cm; border:1px solid black'>" & REA.GetString("autorizacionf") & "</td>")

                        Print(f, "</tr>")

                    Else
                        Print(f, " <tr > ")
                        Print(f, " <td style='width: 7cm; border:1px solid black'>" & REA.GetString("nombreEmp") & " / " & REA.GetString("limiteCredito") & "</td>")
                        Print(f, "<td style='width: 4cm; border:1px solid black; background-color: #F2F5A9'>" & REA.GetString("nombre_empresa") & "</td>")
                        Print(f, "<td style='width: 2cm; border:1px solid black'>" & REA.GetMySqlDateTime("fecha").ToString & "</td>")
                        Print(f, "<td style='width: 2cm; border:1px solid black'>" & REA.GetInt32("numero") & "</td>")
                        'Print(f, "<td style='width: 7cm; border:1px solid black'>" & REA.GetString("referencia") & "</td>")
                        Print(f, "<td style='width: 7cm; border:1px solid black'>" & REA.GetString("Descripcion") & "</td>")
                        Print(f, "<td style='width: 1.5cm; border:1px solid black'>" & REA.GetString("diasCredito") & "</td>")
                        Print(f, "<td style='width: 2cm; border:1px solid black'>" & REA.GetMySqlDateTime("Vencimiento").ToString & "</td>")
                        If REA.GetString("dias_atrasados") = vbNullString Then
                            diasAtrasados = "-"
                        Else
                            diasAtrasados = REA.GetString("dias_atrasados")
                        End If
                        Print(f, "<td style='width: 1cm; border:1px solid black; color:red'>" & diasAtrasados & "</td>")
                        Print(f, "<td style='width: 3.5cm; border:1px solid black'>" & REA.GetDouble("balance_abierto") & "</td>")
                        dblAcumula = REA.GetDouble("balance_abierto") + dblAcumula
                        Print(f, "<td style='width: 2.2cm; border:1px solid black'>" & dblAcumula & "</td>")
                        Print(f, "<td style='width: 2.8cm; border:1px solid black'>" & REA.GetDouble("monto_Vencido") & "</td>")
                        Print(f, "<td style='width: 2.3cm; border:1px solid black;color:orange'>" & REA.GetDouble("intereses") & "</td>")
                        Print(f, "<td style='width: 3cm; border:1px solid black'>" & REA.GetString("programa") & "</td>")
                        Print(f, "<td style='width: 1.5cm; border:1px solid black'>" & REA.GetDouble("tasa_Cambio") & "</td>")
                        Print(f, "<td style='width: 3.5cm; border:1px solid black; background-color: #F2F5A9'>" & REA.GetDouble("balanceQ") & "</td>")
                        Print(f, "<td style='width: 4cm; border:1px solid black'>" & REA.GetString("proforma") & "</td>")
                        Print(f, "<td style='width: 2.3cm; border:1px solid black'>" & REA.GetString("pagare") & "</td>")
                        Print(f, "<td style='width: 3cm; border:1px solid black; background-color: #F2F5A9'>" & REA.GetString("fecha_entrega") & "</td>")
                        strCadena = REA.GetString("serief")
                        arrayCadena = strCadena.Split("-".ToCharArray)
                        Print(f, "<td style='width: 3cm; border:1px solid black'>" & arrayCadena(INT_CERO) & "</td>")
                        Print(f, "<td style='width: 3cm; border:1px solid black'>" & REA.GetString("autorizacionf") & "</td>")

                        Print(f, "</tr>")

                    End If

                    intLineas = intLineas + 1
                    intGrupo = REA.GetInt16("idGrupo")
                    SaldoVencido = SaldoVencido + CDbl(REA.GetDouble("monto_Vencido"))
                    SumaInteres = SumaInteres + CDbl(REA.GetDouble("intereses"))
                    SaldoQ = SaldoQ + CDbl(REA.GetDouble("balanceQ"))
                    i = i + 1
                Loop
                'Utlimo Total

                Print(f, " <tr> ")
                Print(f, " <td style='width: 7cm; border:1px solid black'> <br></td>")
                Print(f, " <td style='width: 4cm; border:1px solid black'> <br></td>")
                Print(f, "<td style='width: 2cm; border:1px solid black'> <br></td>")
                Print(f, "<td style='width: 2cm; border:1px solid black'> <br></td>")
                'Print(f, "<td style='width: 7cm; border:1px solid black'> <br></td>")
                Print(f, "<td style='width: 7cm; border:1px solid black'> <br></td>")
                Print(f, "<td style='width: 1.5cm; border:1px solid black'> <br></td>")
                Print(f, "<td style='width: 2cm; border:1px solid black'> <br></td>")
                Print(f, "<td style='width: 1cm; border:1px solid black'> <br></td>")
                Print(f, "<td style='width: 3.5cm; border:1px solid black'>" & dblAcumula.ToString(FORMATO_MONEDA) & " </td>")
                Print(f, "<td style='width: 2.2cm; border:1px solid black'>  <br></td>")
                Print(f, "<td style='width: 2.8cm; border:1px solid black; color:red'>" & SaldoVencido.ToString(FORMATO_MONEDA) & "</td>")
                Print(f, "<td style='width: 2.3cm; border:1px solid black; color:purple'>" & SumaInteres.ToString(FORMATO_MONEDA) & " </td>")
                Print(f, "<td style='width: 3cm; border:1px solid black'> <br></td>")
                Print(f, "<td style='width: 1.5cm; border:1px solid black'> <br></td>")
                Print(f, "<td style='width: 3.5cm; border:1px solid black; color:navy'>" & SaldoQ.ToString(FORMATO_MONEDA) & " </td>")
                Print(f, "<td style='width: 4cm; border:1px solid black'> <br></td>")
                Print(f, "<td style='width: 2.3cm; border:1px solid black'> <br></td>")
                Print(f, "<td style='width: 3cm; border:1px solid black'> <br></td>")
                Print(f, "<td style='width: 3cm; border:1px solid black'> <br></td>")
                Print(f, "<td style='width: 3cm; border:1px solid black'> <br></td>")

                Print(f, "</tr>")
            End If
            Print(f, "</table>")
            Print(f, "</body>")
            Print(f, "</html>")
            FileClose(f)
            MostarReporte(strTemp)
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub


#End Region

#Region "Aging Sumary"

    Private Function SQLAgingSummaryCorp(ByVal intCompany As Integer, ByVal intFiltro As Integer)
        Dim strSQL As String = STR_VACIO

        strSQL = " SELECT a.idGrupo, a.idEmpresa, a.CodigoCliente, a.Cliente, a.NoVencido Current, a.VencidoQuince, a.VencidoTreinta, a.VencidoSesenta, a.VencidoNoventa, a.ExtraVencido, a.Total, IFNULL(g.nombre_Grupo, 'SIN GRUPO') nombreGrupo,e.nombre_empresa, a.Registro "
        strSQL &= "       FROM YarnDivision.AgingSummary a "
        strSQL &= "          LEFT JOIN YarnDivision.Grupo_Detalle gd ON gd.idGrupo = a.idGrupo AND gd.Codigo = a.CodigoCliente AND gd.idEmpresa = a.idEmpresa "
        strSQL &= "                Left JOIN YarnDivision.Grupo g ON g.idGrupo = gd.idGrupo AND g.idTipo = gd.idTipo "
        strSQL &= "                Left JOIN YarnDivision.Empresa e ON e.idEmpresa = a.idEmpresa "
        strSQL &= "            WHERE a.Correlativo >0 AND gd.idTipo =1 {emp} {filtro}"
        strSQL &= "        ORDER BY g.nombre_Grupo ASC, e.idEmpresa, a.CodigoCliente "

        If intCompany = 0 Then
            strSQL = strSQL.Replace("{emp}", "")
        Else
            strSQL = strSQL.Replace("{emp}", " AND e.idEmpresa = " & intCompany)
        End If
        If intFiltro = 0 Then
            strSQL = strSQL.Replace("{filtro}", "")
        ElseIf intFiltro = 1 Then
            strSQL = strSQL.Replace("{filtro}", " AND g.nombre_Grupo LIKE '%Intercompany%'")
        ElseIf intFiltro = 2 Then
            strSQL = strSQL.Replace("{filtro}", " AND NOT g.nombre_Grupo LIKE '%Intercompany%' AND NOT g.nombre_Grupo LIKE '%Quimico%' AND NOT g.nombre_Grupo LIKE 'Planta%'")
        ElseIf intFiltro = 3 Then
            strSQL = strSQL.Replace("{filtro}", " AND g.nombre_Grupo LIKE '%Quimico%'")
        ElseIf intFiltro = 4 Then
            strSQL = strSQL.Replace("{filtro}", " AND g.nombre_Grupo LIKE 'Planta%'")
        End If

        Return strSQL
    End Function



    Public Sub ReporteAR_AgingCorp(ByVal intCompany As Integer, ByVal intFiltro As Integer, ByVal dtpfec As Date)
        Dim sql As String = STR_VACIO
        Dim strTemp As String = STR_VACIO
        Dim REA As MySqlDataReader
        Dim COM As MySqlCommand
        Dim f As Byte
        Dim i As Integer = 0
        Dim intGrupo As Integer = 0
        Dim intLinea As Integer = 0
        'Variables de sub totales
        Dim dblSumCurrent As Double = 0
        Dim dblVencido15 As Double = 0
        Dim dblVencido30 As Double = 0
        Dim dblVencido60 As Double = 0
        Dim dblVencido90 As Double = 0
        Dim dblVencidoExtra As Double = 0
        Dim dblTotal As Double = 0

        'Variables de Totales Generales
        Dim TotalCurrent As Double = 0
        Dim TotalVencido15 As Double = 0
        Dim TotalVencido30 As Double = 0
        Dim TotalVencido60 As Double = 0
        Dim TotalVencido90 As Double = 0
        Dim TotalVencidoXtra As Double = 0
        Dim TotalGeneral As Double = 0

        sql = SQLAgingSummaryCorp(intCompany, intFiltro)
        Try
            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(sql, CON)
            REA = COM.ExecuteReader

            strTemp = cFunciones.ArchivoTemporal
            f = FreeFile()
            FileOpen(f, strTemp, OpenMode.Append)

            If REA.HasRows Then
                Do While REA.Read

                    If i = 0 Then
                        Print(f, " <html > ")
                        Print(f, " <head > ")
                        Print(f, "<style type='text/css'>")
                        Print(f, " table {table-layout: fixed; empty-cells: show; border-collapse:collapse}")
                        Print(f, " caption {padding: 5px; text-align:left; font-family: Tahoma,  Arial;font-size: 8pt}")
                        Print(f, " td {text-align:center;border:solid Gray 1px; padding:3px 5px; font-family: Tahoma, Arial;font-size: 7pt}")
                        Print(f, " th {width: 1.8cm; border:solid Gray 1px; background-color: Black; color: White; padding:2px 5px; font-family: Tahoma,  Arial;font-size: 6pt}")
                        Print(f, " th {text-align:center;border:solid Gray 1px; padding:3px 5px; font-family: Tahoma,  Arial;font-size: 7pt}")
                        Print(f, " th.numero {text-align:right; mso-number-format:\#\,\#\#0\.00}")
                        Print(f, " th.unitario {text-align:right; mso-number-format:\#\,\#\#0\.00#####}")
                        Print(f, " th.titulo {text-align:right;font-family: Tahoma,  Arial;font-size: 9pt")
                        Print(f, " .titulo {font-family: Tahoma,  Arial;font-size: 9pt}")
                        Print(f, " .encabezado {text-align: left; border: none; width: 3.1cm}")
                        Print(f, " .pie {font-family: Tahoma,  Arial;font-size: 7pt}")
                        Print(f, " .izquierda {text-align:left}")
                        Print(f, " .centro {text-align:center}")
                        Print(f, " .derecha {text-align:right}")
                        Print(f, " .info {text-align:left; border:none}")
                        Print(f, "</style>")
                        Print(f, "<right><h3> <b> <td > A/R Aging Sumary</td></h2></b></right>")
                        Print(f, "<right><h5> <b> <td > cutoff date: " & dtpfec.ToString(FORMATO_MYSQL) & " </td></h5></b></right>")
                        Print(f, "<right><h3> <b> <td > Amounts expressed in US$</td></h2></b></right>")
                        Print(f, "</head>")
                        Print(f, "<body>")
                        Print(f, "<table cellspacing =0 >")
                        Print(f, "<tr>")
                        Print(f, "<th style='width: 7cm; border:1px solid black'>Customer </th>")
                        Print(f, "<th style='width: 3cm; border:1px solid black'>Company </th>")
                        Print(f, "<th style='width: 2cm; border:1px solid black'>Current <br> US$</th>")
                        Print(f, "<th style='width: 2cm; border:1px solid black'>'01 - 15 <br> US$</th>")
                        Print(f, "<th style='width: 2cm; border:1px solid black'>16 - 30 <br> US$</th>")
                        Print(f, "<th style='width: 2cm; border:1px solid black'>31 - 60 <br> US$</th>")
                        Print(f, "<th style='width: 2cm; border:1px solid black'>61 - 90 <br> US$</th>")
                        Print(f, "<th style='width: 2cm; border:1px solid black'>> 90 <br> US$</th>")
                        Print(f, "<th style='width: 2cm; border:1px solid black'>Total <br> US$</th>")
                        Print(f, "</tr>")
                    End If
                    If Not intGrupo = REA.GetInt32("idGrupo") Then

                        If intLinea > 0 Then
                            Print(f, "<tr>")
                            Print(f, "<td colspan='2' style='background-color: #CCD1D1;border:1px solid black; text-align:right'><b>Total </td>")
                            Print(f, "<td style='background-color: #CCD1D1;width: 2cm; border:1px solid black; text-align:right'><b>" & dblSumCurrent.ToString(FORMATO_MONEDA) & " </td>")
                            Print(f, "<td style='background-color: #CCD1D1;width: 2cm; border:1px solid black; text-align:right'><b>" & dblVencido15.ToString(FORMATO_MONEDA) & " </td>")
                            Print(f, "<td style='background-color: #CCD1D1;width: 2cm; border:1px solid black; text-align:right'><b>" & dblVencido30.ToString(FORMATO_MONEDA) & " </td>")
                            Print(f, "<td style='background-color: #CCD1D1;width: 2cm; border:1px solid black; text-align:right'><b>" & dblVencido60.ToString(FORMATO_MONEDA) & " </td>")
                            Print(f, "<td style='background-color: #CCD1D1;width: 2cm; border:1px solid black; text-align:right'><b>" & dblVencido90.ToString(FORMATO_MONEDA) & " </td>")
                            Print(f, "<td style='background-color: #CCD1D1;width: 2cm; border:1px solid black; text-align:right'><b>" & dblVencidoExtra.ToString(FORMATO_MONEDA) & " </td>")
                            Print(f, "<td style='background-color: #CCD1D1;width: 2cm; border:1px solid black; text-align:right'><b>" & dblTotal.ToString(FORMATO_MONEDA) & " </td>")
                            Print(f, "</tr>")
                        End If
                        'Reiniciar Valores
                        intLinea = 0
                        dblSumCurrent = 0
                        dblVencido15 = 0
                        dblVencido30 = 0
                        dblVencido60 = 0
                        dblVencido90 = 0
                        dblVencidoExtra = 0
                        dblTotal = 0

                        Print(f, "<tr>")
                        Print(f, "<tr>")
                        Print(f, "<td style='width: 7cm; border:1px solid black; text-align:left'>" & REA.GetString("Cliente") & "  </td>")
                        Print(f, "<td style='width: 3cm; border:1px solid black; text-align:left'>" & REA.GetString("nombre_empresa") & "  </td>")
                        If REA.GetDouble("Current") = 0 Then
                            Print(f, "<td style='width: 2cm; border:1px solid black; text-align:right;color:White'>" & REA.GetDouble("Current").ToString(FORMATO_MONEDA) & " </td>")
                        Else
                            Print(f, "<td style='width: 2cm; border:1px solid black; text-align:right'>" & REA.GetDouble("Current").ToString(FORMATO_MONEDA) & " </td>")
                        End If
                        If REA.GetDouble("VencidoQuince") = 0 Then
                            Print(f, "<td style='width: 2cm; border:1px solid black; text-align:right;color:White'>" & REA.GetDouble("VencidoQuince").ToString(FORMATO_MONEDA) & " </td>")
                        Else
                            Print(f, "<td style='width: 2cm; border:1px solid black; text-align:right'>" & REA.GetDouble("VencidoQuince").ToString(FORMATO_MONEDA) & " </td>")
                        End If
                        If REA.GetDouble("VencidoTreinta") = 0 Then
                            Print(f, "<td style='width: 2cm; border:1px solid black; text-align:right;color:White'>" & REA.GetDouble("VencidoTreinta").ToString(FORMATO_MONEDA) & " </td>")
                        Else
                            Print(f, "<td style='width: 2cm; border:1px solid black; text-align:right'>" & REA.GetDouble("VencidoTreinta").ToString(FORMATO_MONEDA) & " </td>")
                        End If
                        If REA.GetDouble("VencidoSesenta") = 0 Then
                            Print(f, "<td style='width: 2cm; border:1px solid black; text-align:right;color:White'>" & REA.GetDouble("VencidoSesenta").ToString(FORMATO_MONEDA) & " </td>")
                        Else
                            Print(f, "<td style='width: 2cm; border:1px solid black; text-align:right'>" & REA.GetDouble("VencidoSesenta").ToString(FORMATO_MONEDA) & " </td>")
                        End If
                        If REA.GetDouble("VencidoNoventa") = 0 Then
                            Print(f, "<td style='width: 2cm; border:1px solid black; text-align:right;color:White'>" & REA.GetDouble("VencidoNoventa").ToString(FORMATO_MONEDA) & " </td>")
                        Else
                            Print(f, "<td style='width: 2cm; border:1px solid black; text-align:right'>" & REA.GetDouble("VencidoNoventa").ToString(FORMATO_MONEDA) & " </td>")
                        End If
                        If REA.GetDouble("ExtraVencido") = 0 Then
                            Print(f, "<td style='width: 2cm; border:1px solid black; text-align:right;color:White'>" & REA.GetDouble("ExtraVencido").ToString(FORMATO_MONEDA) & " </td>")
                        Else
                            Print(f, "<td style='width: 2cm; border:1px solid black; text-align:right'>" & REA.GetDouble("ExtraVencido").ToString(FORMATO_MONEDA) & " </td>")
                        End If
                        If REA.GetDouble("Total") = 0 Then
                            Print(f, "<td style='width: 2cm; border:1px solid black; text-align:right;color:White'>" & REA.GetDouble("Total").ToString(FORMATO_MONEDA) & " </td>")
                        Else
                            Print(f, "<td style='width: 2cm; border:1px solid black; text-align:right'>" & REA.GetDouble("Total").ToString(FORMATO_MONEDA) & " </td>")
                        End If

                        Print(f, "</tr>")

                    Else
                        Print(f, "</tr>")

                        Print(f, "<tr>")
                        Print(f, "<td style='width: 7cm; border:1px solid black; text-align:left'>" & REA.GetString("Cliente") & "  </td>")
                        Print(f, "<td style='width: 3cm; border:1px solid black; text-align:left'>" & REA.GetString("nombre_empresa") & "  </td>")
                        If REA.GetDouble("Current") = 0 Then
                            Print(f, "<td style='width: 2cm; border:1px solid black; text-align:right;color:White'>" & REA.GetDouble("Current").ToString(FORMATO_MONEDA) & " </td>")
                        Else
                            Print(f, "<td style='width: 2cm; border:1px solid black; text-align:right'>" & REA.GetDouble("Current").ToString(FORMATO_MONEDA) & " </td>")
                        End If
                        If REA.GetDouble("VencidoQuince") = 0 Then
                            Print(f, "<td style='width: 2cm; border:1px solid black; text-align:right;color:White'>" & REA.GetDouble("VencidoQuince").ToString(FORMATO_MONEDA) & " </td>")
                        Else
                            Print(f, "<td style='width: 2cm; border:1px solid black; text-align:right'>" & REA.GetDouble("VencidoQuince").ToString(FORMATO_MONEDA) & " </td>")
                        End If
                        If REA.GetDouble("VencidoTreinta") = 0 Then
                            Print(f, "<td style='width: 2cm; border:1px solid black; text-align:right;color:White'>" & REA.GetDouble("VencidoTreinta").ToString(FORMATO_MONEDA) & " </td>")
                        Else
                            Print(f, "<td style='width: 2cm; border:1px solid black; text-align:right'>" & REA.GetDouble("VencidoTreinta").ToString(FORMATO_MONEDA) & " </td>")
                        End If
                        If REA.GetDouble("VencidoSesenta") = 0 Then
                            Print(f, "<td style='width: 2cm; border:1px solid black; text-align:right;color:White'>" & REA.GetDouble("VencidoSesenta").ToString(FORMATO_MONEDA) & " </td>")
                        Else
                            Print(f, "<td style='width: 2cm; border:1px solid black; text-align:right'>" & REA.GetDouble("VencidoSesenta").ToString(FORMATO_MONEDA) & " </td>")
                        End If
                        If REA.GetDouble("VencidoNoventa") = 0 Then
                            Print(f, "<td style='width: 2cm; border:1px solid black; text-align:right;color:White'>" & REA.GetDouble("VencidoNoventa").ToString(FORMATO_MONEDA) & " </td>")
                        Else
                            Print(f, "<td style='width: 2cm; border:1px solid black; text-align:right'>" & REA.GetDouble("VencidoNoventa").ToString(FORMATO_MONEDA) & " </td>")
                        End If
                        If REA.GetDouble("ExtraVencido") = 0 Then
                            Print(f, "<td style='width: 2cm; border:1px solid black; text-align:right;color:White'>" & REA.GetDouble("ExtraVencido").ToString(FORMATO_MONEDA) & " </td>")
                        Else
                            Print(f, "<td style='width: 2cm; border:1px solid black; text-align:right'>" & REA.GetDouble("ExtraVencido").ToString(FORMATO_MONEDA) & " </td>")
                        End If
                        If REA.GetDouble("Total") = 0 Then
                            Print(f, "<td style='width: 2cm; border:1px solid black; text-align:right;color:White'>" & REA.GetDouble("Total").ToString(FORMATO_MONEDA) & " </td>")
                        Else
                            Print(f, "<td style='width: 2cm; border:1px solid black; text-align:right'>" & REA.GetDouble("Total").ToString(FORMATO_MONEDA) & " </td>")
                        End If
                        Print(f, "</tr>")


                    End If

                    i = i + 1
                    intLinea = intLinea + 1
                    intGrupo = REA.GetInt32("idGrupo")
                    dblSumCurrent = dblSumCurrent + REA.GetDouble("Current")
                    dblVencido15 = dblVencido15 + REA.GetDouble("VencidoQuince")
                    dblVencido30 = dblVencido30 + REA.GetDouble("VencidoTreinta")
                    dblVencido60 = dblVencido60 + REA.GetDouble("VencidoSesenta")
                    dblVencido90 = dblVencido90 + REA.GetDouble("VencidoNoventa")
                    dblVencidoExtra = dblVencidoExtra + REA.GetDouble("ExtraVencido")
                    dblTotal = dblTotal + REA.GetDouble("Total")

                    'Totales Generales
                    TotalCurrent = TotalCurrent + REA.GetDouble("Current")
                    TotalVencido15 = TotalVencido15 + REA.GetDouble("VencidoQuince")
                    TotalVencido30 = TotalVencido30 + REA.GetDouble("VencidoTreinta")
                    TotalVencido60 = TotalVencido60 + REA.GetDouble("VencidoSesenta")
                    TotalVencido90 = TotalVencido90 + REA.GetDouble("VencidoNoventa")
                    TotalVencidoXtra = TotalVencidoXtra + REA.GetDouble("ExtraVencido")
                    TotalGeneral = TotalGeneral + REA.GetDouble("Total")

                Loop

                Print(f, "<tr>")
                Print(f, "<td colspan='2' style='background-color: #CCD1D1;border:1px solid black; text-align:right'><b>Total </td>")
                Print(f, "<td style='background-color: #CCD1D1;width: 2cm; border:1px solid black; text-align:right'><b>" & dblSumCurrent.ToString(FORMATO_MONEDA) & " </td>")
                Print(f, "<td style='background-color: #CCD1D1;width: 2cm; border:1px solid black; text-align:right'><b>" & dblVencido15.ToString(FORMATO_MONEDA) & " </td>")
                Print(f, "<td style='background-color: #CCD1D1;width: 2cm; border:1px solid black; text-align:right'><b>" & dblVencido30.ToString(FORMATO_MONEDA) & " </td>")
                Print(f, "<td style='background-color: #CCD1D1;width: 2cm; border:1px solid black; text-align:right'><b>" & dblVencido60.ToString(FORMATO_MONEDA) & " </td>")
                Print(f, "<td style='background-color: #CCD1D1;width: 2cm; border:1px solid black; text-align:right'><b>" & dblVencido90.ToString(FORMATO_MONEDA) & " </td>")
                Print(f, "<td style='background-color: #CCD1D1;width: 2cm; border:1px solid black; text-align:right'><b>" & dblVencidoExtra.ToString(FORMATO_MONEDA) & " </td>")
                Print(f, "<td style='background-color: #CCD1D1;width: 2cm; border:1px solid black; text-align:right'><b>" & dblTotal.ToString(FORMATO_MONEDA) & " </td>")
                Print(f, "</tr>")

                Print(f, "<br>")
                Print(f, "<br>")

                Print(f, "<tr>")
                Print(f, "<td colspan='2' style='border:1px solid black; text-align:right; background-color: #F7DC6F'><b>Grand Total </td>")
                Print(f, "<td style='width: 2cm; border:1px solid black; text-align:right; background-color: #F7DC6F'><b>" & TotalCurrent.ToString(FORMATO_MONEDA) & " </td>")
                Print(f, "<td style='width: 2cm; border:1px solid black; text-align:right; background-color: #F7DC6F'><b>" & TotalVencido15.ToString(FORMATO_MONEDA) & " </td>")
                Print(f, "<td style='width: 2cm; border:1px solid black; text-align:right; background-color: #F7DC6F'><b>" & TotalVencido30.ToString(FORMATO_MONEDA) & " </td>")
                Print(f, "<td style='width: 2cm; border:1px solid black; text-align:right; background-color: #F7DC6F'><b>" & TotalVencido60.ToString(FORMATO_MONEDA) & " </td>")
                Print(f, "<td style='width: 2cm; border:1px solid black; text-align:right; background-color: #F7DC6F'><b>" & TotalVencido90.ToString(FORMATO_MONEDA) & " </td>")
                Print(f, "<td style='width: 2cm; border:1px solid black; text-align:right; background-color: #F7DC6F'><b>" & TotalVencidoXtra.ToString(FORMATO_MONEDA) & " </td>")
                Print(f, "<td style='width: 2cm; border:1px solid black; text-align:right; background-color: #F7DC6F'><b>" & TotalGeneral.ToString(FORMATO_MONEDA) & " </td>")
                Print(f, "</tr>")
            End If

            Print(f, "</table>")
            Print(f, "</body>")
            Print(f, "</html>")
            FileClose(f)
            MostarReporte(strTemp)
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try

    End Sub

#End Region

#Region "Inventarios Corp"
    Public Sub ReporteDeInventariosCorp()

    End Sub
#End Region

#Region "Open Bill Corporate"
    Private Function SQLOpenBillCorporate() As String
        Dim strSQL As String = STR_VACIO
        strSQL = " SELECT c.idGrupo, c.idEmpresa, c.CodigoProv,c.Proveedor,c.Referencia,c.Fecha,c.Fecha_Vencimiento, c.Dias, c.Moneda, "
        strSQL &= "      c.Divisa,c.Monto, c.Cargos, c.Abonos,c.Saldo,c.Tasa,c.Current, c.Grupo15,c.Grupo30,c.Grupo60,c.Grupo90,c.Grupo91,"
        strSQL &= "          IFNULL(g.nombre_Grupo,'SIN GRUPO')nombreGrupo, e.nombre_empresa empresa "
        strSQL &= "             FROM YarnDivision.CuentaPorPagar c "
        strSQL &= "                 LEFT JOIN YarnDivision.Grupo_Detalle d ON d.idEmpresa = c.idEmpresa AND d.idGrupo = c.idGrupo AND d.Codigo = c.CodigoProv AND d.idTipo = c.TipoGrupo "
        strSQL &= "                     LEFT JOIN YarnDivision.Grupo g ON g.idGrupo = d.idGrupo AND g.idTipo = d.idTipo "
        strSQL &= "                         LEFT JOIN YarnDivision.Empresa e ON e.idEmpresa= c.idEmpresa "
        strSQL &= "                             WHERE c.Correlativo > 0 AND c.TipoGrupo = 3 "
        strSQL &= "                                 ORDER BY g.nombre_Grupo ASC, e.idEmpresa, c.CodigoProv, c.Fecha "

        Return strSQL
    End Function


    Public Sub OpenBillCorporate(ByVal FechaInicial As Date, ByVal fechaFinal As Date)
        Dim strSQL As String = STR_VACIO
        Dim f As Byte
        Dim strTemp As String = STR_VACIO
        Dim dblSum(8) As Double
        Dim dblSuma As Double
        Dim logPrimeraLinea As Boolean = False
        Dim intGrupo As Integer = INT_CERO
        Dim strDescripcion As String = STR_VACIO
        'conexiones 
        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader
        Try

            strTemp = cFunciones.ArchivoTemporal
            f = FreeFile()
            FileOpen(f, strTemp, OpenMode.Append)

            Print(f, " <html > ")
            Print(f, " <head > ")


            Print(f, "<style type='text/css'>")
            Print(f, " table {table-layout: fixed; empty-cells: show; border-collapse:collapse}")
            Print(f, " caption {padding: 5px; text-align:left; font-family: Tahoma,  Arial;font-size: 8pt}")
            Print(f, " td {text-align:center;border:solid Gray 1px; padding:3px 5px; font-family: Tahoma, Arial;font-size: 7pt}")
            Print(f, " th {width: 1.8cm; border:solid Gray 1px; background-color: Black; color: White; padding:2px 5px; font-family: Tahoma,  Arial;font-size: 6pt}")
            Print(f, " th {text-align:center;border:solid Gray 1px; padding:3px 5px; font-family: Tahoma,  Arial;font-size: 7pt}")
            Print(f, " th.numero {text-align:right; mso-number-format:\#\,\#\#0\.00}")
            Print(f, " th.unitario {text-align:right; mso-number-format:\#\,\#\#0\.00#####}")
            Print(f, " th.titulo {text-align:right;font-family: Tahoma,  Arial;font-size: 9pt")
            Print(f, " .titulo {font-family: Tahoma,  Arial;font-size: 9pt}")
            Print(f, " .encabezado {text-align: left; border: none; width: 3.1cm}")
            Print(f, " .pie {font-family: Tahoma,  Arial;font-size: 7pt}")
            Print(f, " .izquierda {text-align:left}")
            Print(f, " .centro {text-align:center}")
            Print(f, " .derecha {text-align:right}")
            Print(f, " .info {text-align:left; border:none}")
            Print(f, "</style>")

            Print(f, "<right><h2> <b> <td > Open Bill Corporate </td></h2></b></right>")
            Print(f, "<right><h5> <b> <td > From " & FechaInicial.ToString(FORMATO_MYSQL) & " To " & fechaFinal.ToString(FORMATO_MYSQL) & "</td></h5></b></right>")

            Print(f, "</head>")
            Print(f, "<body>")

            Print(f, "<table cellspacing=0>")
            'Encabezado de columnas: style='width: 1cm'
            Print(f, "<tr>")
            Print(f, "<th style='width: 8cm'>Supplier</th>")
            Print(f, "<th style='width: 3.1cm'>Document</th>")
            Print(f, "<th style='width: 2.4cm'>Current</th>")
            Print(f, "<th style='width: 2.4cm'>01 TO 15</th>")
            Print(f, "<th style='width: 2.4cm'>16 TO 30</th>")
            Print(f, "<th style='width: 2.4cm'>31 TO 60</th>")
            Print(f, "<th style='width: 2.4cm'>61 TO 90</th>")
            Print(f, "<th style='width: 2.4cm'>DUE 91</th>")
            Print(f, "<th style='width: 2.4cm'>TOTAL</th>")
            Print(f, "<th style='width: 2.4cm'>Biller</th>")
            Print(f, "</tr>")

            strSQL = SQLOpenBillCorporate()
            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSQL, CON)
            REA = COM.ExecuteReader
            If REA.HasRows Then
                Do While REA.Read


                    If logPrimeraLinea = False Then
                        Print(f, "<tr>")
                        Print(f, "<td  colspan='10' style='border:1px solid black; background-color: #3498DB; text-align:left; font-size:9pt'> <b> " & REA.GetString("nombreGrupo") & "</b> </td>")
                        Print(f, "<tr>")


                        Print(f, "<tr>")
                        Print(f, "<td class='izquierda' style='text-align: left'>" & REA.GetString("Proveedor") & "</td>")

                        Print(f, "<td class='izquierda' style='text-align: left'>" & REA.GetString("Referencia") & "</td>")
                        Print(f, "<td class='numero' style='text-align: right'>" & REA.GetDouble("Current").ToString(FORMATO_MONEDA) & "</td>")
                        Print(f, "<td class='numero' style='text-align: right'>" & PintarTexto(Format(REA.GetDouble("Grupo15"), FORMATO_MONEDA), True) & "</td>")
                        Print(f, "<td class='numero' style='text-align: right'>" & PintarTexto(Format(REA.GetDouble("Grupo30"), FORMATO_MONEDA), True) & "</td>")
                        Print(f, "<td class='numero' style='text-align: right'>" & PintarTexto(Format(REA.GetDouble("Grupo60"), FORMATO_MONEDA), True) & "</td>")
                        Print(f, "<td class='numero' style='text-align: right'>" & PintarTexto(Format(REA.GetDouble("Grupo90"), FORMATO_MONEDA), True) & "</td>")
                        Print(f, "<td class='numero' style='text-align: right'>" & PintarTexto(Format(REA.GetDouble("Grupo91"), FORMATO_MONEDA), True) & "</td>")

                        dblSuma = REA.GetDouble("Current") + REA.GetDouble("Grupo15") + REA.GetDouble("Grupo30") + REA.GetDouble("Grupo60") + REA.GetDouble("Grupo90") + REA.GetDouble("Grupo91")

                        Print(f, "<td class='numero' style='text-align: right'>" & PintarTexto(Format(dblSuma, FORMATO_MONEDA), True) & "</td>")
                        Print(f, "<td class='izquierda' style='text-align: left'>" & REA.GetString("empresa") & "</td>")

                        Print(f, "</tr>")
                        intGrupo = REA.GetInt32("idGrupo")
                        strDescripcion = REA.GetString("nombreGrupo")
                        logPrimeraLinea = True
                        dblSum(1) = dblSum(1) + REA.GetDouble("Current")
                        dblSum(8) = dblSum(8) + dblSuma
                        dblSum(2) = dblSum(2) + dblSuma


                        dblSum(3) = dblSum(3) + REA.GetDouble("Grupo15")
                        dblSum(4) = dblSum(4) + REA.GetDouble("Grupo30")
                        dblSum(5) = dblSum(5) + REA.GetDouble("Grupo60")
                        dblSum(6) = dblSum(6) + REA.GetDouble("Grupo90")
                        dblSum(7) = dblSum(7) + REA.GetDouble("Grupo91")


                    Else
                        If intGrupo = REA.GetInt32("idGrupo") Then

                            Print(f, "<tr>")
                            Print(f, "<td class='izquierda' style='text-align: left'>" & REA.GetString("Proveedor") & "</td>")

                            Print(f, "<td class='izquierda' style='text-align: left'>" & REA.GetString("Referencia") & "</td>")
                            Print(f, "<td class='numero' style='text-align: right'>" & REA.GetDouble("Current").ToString(FORMATO_MONEDA) & "</td>")
                            Print(f, "<td class='numero' style='text-align: right'>" & PintarTexto(Format(REA.GetDouble("Grupo15"), FORMATO_MONEDA), True) & "</td>")
                            Print(f, "<td class='numero' style='text-align: right'>" & PintarTexto(Format(REA.GetDouble("Grupo30"), FORMATO_MONEDA), True) & "</td>")
                            Print(f, "<td class='numero' style='text-align: right'>" & PintarTexto(Format(REA.GetDouble("Grupo60"), FORMATO_MONEDA), True) & "</td>")
                            Print(f, "<td class='numero' style='text-align: right'>" & PintarTexto(Format(REA.GetDouble("Grupo90"), FORMATO_MONEDA), True) & "</td>")
                            Print(f, "<td class='numero' style='text-align: right'>" & PintarTexto(Format(REA.GetDouble("Grupo91"), FORMATO_MONEDA), True) & "</td>")

                            dblSuma = REA.GetDouble("Current") + REA.GetDouble("Grupo15") + REA.GetDouble("Grupo30") + REA.GetDouble("Grupo60") + REA.GetDouble("Grupo90") + REA.GetDouble("Grupo91")

                            Print(f, "<td class='numero' style='text-align: right'>" & PintarTexto(Format(dblSuma, FORMATO_MONEDA), True) & "</td>")
                            Print(f, "<td class='izquierda' style='text-align: left'>" & REA.GetString("empresa") & "</td>")

                            Print(f, "</tr>")
                            intGrupo = REA.GetInt32("idGrupo")
                            strDescripcion = REA.GetString("nombreGrupo")
                            dblSum(1) = dblSum(1) + REA.GetDouble("Current")
                            dblSum(8) = dblSum(8) + dblSuma
                            dblSum(2) = dblSum(2) + dblSuma


                            dblSum(3) = dblSum(3) + REA.GetDouble("Grupo15")
                            dblSum(4) = dblSum(4) + REA.GetDouble("Grupo30")
                            dblSum(5) = dblSum(5) + REA.GetDouble("Grupo60")
                            dblSum(6) = dblSum(6) + REA.GetDouble("Grupo90")
                            dblSum(7) = dblSum(7) + REA.GetDouble("Grupo91")

                        Else
                            Print(f, "<tr>")
                            Print(f, "<td colspan='2' style='background-color:  #AAB7B8; font-family: Tahoma, Arial;font-size: 8pt ; color: black;'>  <b> SubTotal " & strDescripcion & "  </b> </td>")


                            Print(f, "<td style='background-color: #AAB7B8  ; font-family: Tahoma, Arial;font-size: 8pt ; color: White;'> <br> </td>")
                            Print(f, "<td style='background-color: #AAB7B8  ; font-family: Tahoma, Arial;font-size: 8pt ; color: White;'> <br> </td>")
                            Print(f, "<td style='background-color: #AAB7B8  ; font-family: Tahoma, Arial;font-size: 8pt ; color: White;'> <br> </td>")
                            Print(f, "<td style='background-color: #AAB7B8  ; font-family: Tahoma, Arial;font-size: 8pt ; color: White;'> <br> </td>")
                            Print(f, "<td style='background-color: #AAB7B8  ; font-family: Tahoma, Arial;font-size: 8pt ; color: White;'> <br> </td>")
                            Print(f, "<td style='background-color: #AAB7B8  ; font-family: Tahoma, Arial;font-size: 8pt ; color: White;'> <br> </td>")

                            Print(f, "<td style='text-align:right;background-color:  #AAB7B8; color: black;'> <b> " & PintarTexto(Format(dblSum(2), FORMATO_MONEDA), True) & "</b> </td>")
                            Print(f, "<td style='background-color:  #AAB7B8; font-family: Tahoma, Arial;font-size: 8pt ; color: White;'> <br> </td>")
                            Print(f, "</tr>")

                            dblSum(2) = INT_CERO

                            Print(f, "<tr>")
                            Print(f, "<td colspan='10' style='border:1px solid black; background-color:#3498DB; text-align:left; font-size:9pt'> <b> " & REA.GetString("nombreGrupo") & " </b> </td>")
                            Print(f, "<tr>")


                            Print(f, "<tr>")
                            Print(f, "<td class='izquierda' style='text-align: left'>" & REA.GetString("Proveedor") & "</td>")

                            Print(f, "<td class='izquierda' style='text-align: left'>" & REA.GetString("Referencia") & "</td>")
                            Print(f, "<td class='numero' style='text-align: right'>" & REA.GetDouble("Current").ToString(FORMATO_MONEDA) & "</td>")
                            Print(f, "<td class='numero' style='text-align: right'>" & PintarTexto(Format(REA.GetDouble("Grupo15"), FORMATO_MONEDA), True) & "</td>")
                            Print(f, "<td class='numero' style='text-align: right'>" & PintarTexto(Format(REA.GetDouble("Grupo30"), FORMATO_MONEDA), True) & "</td>")
                            Print(f, "<td class='numero' style='text-align: right'>" & PintarTexto(Format(REA.GetDouble("Grupo60"), FORMATO_MONEDA), True) & "</td>")
                            Print(f, "<td class='numero' style='text-align: right'>" & PintarTexto(Format(REA.GetDouble("Grupo90"), FORMATO_MONEDA), True) & "</td>")
                            Print(f, "<td class='numero' style='text-align: right'>" & PintarTexto(Format(REA.GetDouble("Grupo91"), FORMATO_MONEDA), True) & "</td>")

                            dblSuma = REA.GetDouble("Current") + REA.GetDouble("Grupo15") + REA.GetDouble("Grupo30") + REA.GetDouble("Grupo60") + REA.GetDouble("Grupo90") + REA.GetDouble("Grupo91")

                            Print(f, "<td class='numero' style='text-align: right'>" & PintarTexto(Format(dblSuma, FORMATO_MONEDA), True) & "</td>")
                            Print(f, "<td class='izquierda' style='text-align: left'>" & REA.GetString("empresa") & "</td>")

                            Print(f, "</tr>")
                            intGrupo = REA.GetInt32("idGrupo")
                            strDescripcion = REA.GetString("nombreGrupo")
                            dblSum(1) = dblSum(1) + REA.GetDouble("Current")
                            dblSum(8) = dblSum(8) + dblSuma
                            dblSum(2) = dblSum(2) + dblSuma


                            dblSum(3) = dblSum(3) + REA.GetDouble("Grupo15")
                            dblSum(4) = dblSum(4) + REA.GetDouble("Grupo30")
                            dblSum(5) = dblSum(5) + REA.GetDouble("Grupo60")
                            dblSum(6) = dblSum(6) + REA.GetDouble("Grupo90")
                            dblSum(7) = dblSum(7) + REA.GetDouble("Grupo91")

                        End If
                    End If
                Loop
                Print(f, "<tr>")
                Print(f, "<td colspan='2' style='background-color: #AAB7B8; font-family: Tahoma, Arial;font-size: 8pt ; color: black;'>  <b> SubTotal " & strDescripcion & "  </b> </td>")


                Print(f, "<td style='background-color: #AAB7B8; font-family: Tahoma, Arial;font-size: 8pt ; color: White;'> <br> </td>")
                Print(f, "<td style='background-color: #AAB7B8; font-family: Tahoma, Arial;font-size: 8pt ; color: White;'> <br> </td>")
                Print(f, "<td style='background-color: #AAB7B8; font-family: Tahoma, Arial;font-size: 8pt ; color: White;'> <br> </td>")
                Print(f, "<td style='background-color: #AAB7B8; font-family: Tahoma, Arial;font-size: 8pt ; color: White;'> <br> </td>")
                Print(f, "<td style='background-color: #AAB7B8; font-family: Tahoma, Arial;font-size: 8pt ; color: White;'> <br> </td>")
                Print(f, "<td style='background-color: #AAB7B8; font-family: Tahoma, Arial;font-size: 8pt ; color: White;'> <br> </td>")

                Print(f, "<td style='text-align:right;background-color: #AAB7B8; color: black;'> <b>" & PintarTexto(Format(dblSum(2), FORMATO_MONEDA), True) & " </b> </td>")
                Print(f, "<td style='background-color: #AAB7B8; font-family: Tahoma, Arial;font-size: 8pt ; color: White;'> <br> </td>")
                Print(f, "</tr>")


                Print(f, "<tr>")
                Print(f, "<td colspan='2' style='border:1px solid black; text-align:right; background-color: #F7DC6F;font-family: Tahoma, Arial;font-size: 8pt'> <b> Grand Total </b> </td>")
                Print(f, "<td class='numero' style='border:1px solid black; text-align:right; background-color: #F7DC6F'> <b>" & PintarTexto(dblSum(1).ToString(FORMATO_MONEDA), True) & " </b>  </td>")
                Print(f, "<td class='numero' style='border:1px solid black; text-align:right; background-color: #F7DC6F'> <b>" & PintarTexto(dblSum(3).ToString(FORMATO_MONEDA), True) & " </b>  </td>")
                Print(f, "<td class='numero' style='border:1px solid black; text-align:right; background-color: #F7DC6F'> <b>" & PintarTexto(dblSum(4).ToString(FORMATO_MONEDA), True) & " </b>  </td>")
                Print(f, "<td class='numero' style='border:1px solid black; text-align:right; background-color: #F7DC6F'> <b>" & PintarTexto(dblSum(5).ToString(FORMATO_MONEDA), True) & " </b>  </td>")
                Print(f, "<td class='numero' style='border:1px solid black; text-align:right; background-color: #F7DC6F'> <b>" & PintarTexto(dblSum(6).ToString(FORMATO_MONEDA), True) & " </b>  </td>")
                Print(f, "<td class='numero' style='border:1px solid black; text-align:right; background-color: #F7DC6F'> <b>" & PintarTexto(dblSum(7).ToString(FORMATO_MONEDA), True) & " </b>  </td>")

                Print(f, "<td class='numero' style='border:1px solid black; text-align:right; background-color: #F7DC6F'> <b> " & PintarTexto(dblSum(8).ToString(FORMATO_MONEDA), True) & " </b> </td>")
                Print(f, "<td style='border:1px solid black; text-align:right; background-color: #F7DC6F'> <br> </td>")
                Print(f, "</tr>")




            End If

            Print(f, "</table>")
            Print(f, "<br/>")
            Print(f, "</body>")
            Print(f, "</html>")

            FileClose(f)
            MostarReporte(strTemp)


        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub
#End Region

#Region "Chart Corporate"

    Private Function sqlChartCorp(ByVal tipo As Integer, ByVal intOrigen As Integer)
        Dim strSQL As String = STR_VACIO

        strSQL = " SELECT p.PProveedor, p.PPO, p.PContrato, p.PYarnDesc, p.PGeneralDesc, p.PEmpresa, p.PReferencia,p.PFactura,p.PLibras,p.PContenedor,p.PNaviera,p.PStatus,p.PStatus_Joby,IF(p.PETD = '0000-00-00','',p.PETD) PETD, IF(p.PETA = '0000-00-00','',p.PETA) PETA,p.PStatus_Venta,p.PCategoria, p.Registro "
        strSQL &= "    From YarnDivision.Planning p "
        If tipo = INT_CERO Then ' hilo
            If intOrigen = 0 Then ' Asia
                strSQL &= "        Where p.PCategoria != 'FIBER' AND p.PCat_Pais != 3 "
            Else ' NAFTA
                strSQL &= "        Where p.PCategoria != 'FIBER' AND p.PCat_Pais = 3 "
            End If
        Else 'Fibra
            If intOrigen = 0 Then 'ASIA
                strSQL &= "        Where p.PCategoria = 'FIBER' AND p.PCat_Pais != 3 "
            Else 'NAFTA
                strSQL &= "        Where p.PCategoria = 'FIBER' AND p.PCat_Pais = 3 "
            End If
        End If

        strSQL &= "          ORDER BY p.PGeneralDesc ASC, p.PPO,p.PContrato,p.PETD "

        Return strSQL

    End Function

    Public Sub ChartCorp(ByVal tipo As Integer)
        Dim strSQL As String = STR_VACIO
        Dim f As Byte
        Dim strTemp As String = STR_VACIO
        Dim strPais As String = STR_VACIO
        Dim i As Integer = 0

        'conexiones 
        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader
        Try
            Dim opOrigen As New frmOption
            opOrigen.Titulo = "Reports"
            opOrigen.Mensaje = "select the Report to Generate"
            opOrigen.Opciones = "ASIA" & "|" & "NAFTA"

            If opOrigen.ShowDialog = System.Windows.Forms.DialogResult.OK Then
                strSQL = sqlChartCorp(tipo, opOrigen.Seleccion)
            Else
                Exit Sub
            End If

            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSQL, CON)
            REA = COM.ExecuteReader
            If REA.HasRows Then
                Do While REA.Read

                    If i = 0 Then
                        strTemp = cFunciones.ArchivoTemporal
                        f = FreeFile()
                        FileOpen(f, strTemp, OpenMode.Append)

                        Print(f, " <html > ")
                        Print(f, " <head > ")

                        Print(f, "<style type='text/css'>")
                        Print(f, " table {table-layout: fixed; empty-cells: show; border-collapse:collapse}")
                        Print(f, " caption {padding: 5px; text-align:left; font-family: Tahoma,  Arial;font-size: 8pt}")
                        Print(f, " td {text-align:center;border:solid Gray 1px; padding:3px 5px; font-family: Tahoma, Arial;font-size: 7pt}")
                        Print(f, " th {width: 1.8cm; border:solid Gray 1px; background-color: Black; color: White; padding:2px 5px; font-family: Tahoma,  Arial;font-size: 6pt}")
                        Print(f, " th {text-align:center;border:solid Gray 1px; padding:3px 5px; font-family: Tahoma,  Arial;font-size: 7pt}")
                        Print(f, " th.numero {text-align:right; mso-number-format:\#\,\#\#0\.00}")
                        Print(f, " th.unitario {text-align:right; mso-number-format:\#\,\#\#0\.00#####}")
                        Print(f, " th.titulo {text-align:right;font-family: Tahoma,  Arial;font-size: 9pt")
                        Print(f, " .titulo {font-family: Tahoma,  Arial;font-size: 9pt}")
                        Print(f, " .encabezado {text-align: left; border: none; width: 3.1cm}")
                        Print(f, " .pie {font-family: Tahoma,  Arial;font-size: 7pt}")
                        Print(f, " .izquierda {text-align:left}")
                        Print(f, " .centro {text-align:center}")
                        Print(f, " .derecha {text-align:right}")
                        Print(f, " .info {text-align:left; border:none}")
                        Print(f, "</style>")

                        Print(f, "<td style='font-family: Tahoma;font-size:25pt'><b>Chart Corporate <br> </b></td>")
                        Print(f, "<td style='font-family: Tahoma;font-size:7pt'><b>To " & REA.GetDateTime("Registro").ToString(FORMATO_MYSQL) & "</b></td>")

                        Print(f, "</head>")
                        Print(f, "<body>")

                        Print(f, "<table cellspacing=0>")
                        'Encabezado de columnas: style='width: 1cm'
                        Print(f, "<tr>")
                        Print(f, "<th style='width: 4cm'>MILL</th>")
                        Print(f, "<th style='width: 2cm'>PO</th>")
                        Print(f, "<th style='width: 2.5cm'>CONTRACT</th>")
                        Print(f, "<th style='width: 8cm'>YARN DESCRIPTION</th>")
                        Print(f, "<th style='width: 8cm'>GENERAL DESCRIPTION</th>")
                        Print(f, "<th style='width: 2cm'>DEST</th>")
                        Print(f, "<th style='width: 2.5cm'>REFERENCE</th>")
                        Print(f, "<th style='width: 2.5cm'>LT</th>")
                        Print(f, "<th style='width: 3cm'>QUANTITY</th>")
                        Print(f, "<th style='width: 3cm'>CONTAINER No.</th>")
                        Print(f, "<th style='width: 4cm'>SHIPPING LINE</th>")
                        Print(f, "<th style='width: 4cm'>STATUS</th>")
                        Print(f, "<th style='width: 4cm'>STATUS JOBY</th>")
                        Print(f, "<th style='width: 2cm'>ETD</th>")
                        Print(f, "<th style='width: 2cm'>ETA</th>")
                        Print(f, "<th style='width: 4cm'>STATUS</th>")
                        Print(f, "<th style='width: 3.5cm'>CATEGORY</th>")
                        Print(f, "</tr>")
                        i = i + 1
                    End If

                    Print(f, "<tr>")
                    Print(f, "<td style='width: 4cm'>" & REA.GetString("PProveedor") & "</td>")
                    Print(f, "<td style='width: 2cm'>" & REA.GetString("PPO") & "</td>")
                    Print(f, "<td style='width: 2.5cm'>" & REA.GetString("PContrato") & "</td>")
                    Print(f, "<td style='width: 8cm'>" & REA.GetString("PYarnDesc") & "</td>")
                    Print(f, "<td style='width: 8cm'>" & REA.GetString("PGeneralDesc") & "</td>")
                    If REA.GetInt32("PEmpresa") = 1 Then
                        strPais = "GT"
                        Print(f, "<td style='width: 2cm'>" & strPais & "</td>")
                    ElseIf REA.GetInt32("PEmpresa") = 2 Then
                        strPais = "SV"
                        Print(f, "<td style='width: 2cm'>" & strPais & "</td>")
                    ElseIf REA.GetInt32("PEmpresa") = 3 Then
                        strPais = "HN"
                        Print(f, "<td style='width: 2cm'>" & strPais & "</td>")
                    ElseIf REA.GetInt32("PEmpresa") = 4 Then
                        strPais = "DR"
                        Print(f, "<td style='width: 2cm'>" & strPais & "</td>")
                    End If
                    Print(f, "<td style='width: 8cm'>" & REA.GetString("PReferencia") & "</td>")
                    Print(f, "<td style='width: 2.5cm'>" & REA.GetString("PFactura") & "</td>")
                    Print(f, "<td style='width: 3cm;text-align:right'>" & REA.GetDouble("PLibras").ToString(FORMATO_MONEDA) & "</td>")
                    Print(f, "<td style='width: 3cm'>" & REA.GetString("PContenedor") & "</td>")
                    Print(f, "<td style='width: 4cm'>" & REA.GetString("PNaviera") & "</td>")
                    Print(f, "<td style='width: 4cm'>" & REA.GetString("PStatus") & "</td>")
                    Print(f, "<td style='width: 4cm'>" & REA.GetString("PStatus_Joby") & "</td>")
                    Print(f, "<td style='width: 2cm'>" & REA.GetString("PETD") & "</td>")
                    Print(f, "<td style='width: 2cm'>" & REA.GetString("PETA") & "</td>")
                    Print(f, "<td style='width: 4cm'>" & If(Len(REA.GetString("PStatus_Venta")) > 2, REA.GetString("PStatus_Venta"), "AVAILABLE") & "</td>")
                    Print(f, "<td style='width: 3.5cm'>" & REA.GetString("PCategoria") & "</td>")
                    Print(f, "</tr>")
                Loop

                Print(f, "</table>")
                Print(f, "<br/>")
                Print(f, "</body>")
                Print(f, "</html>")

                FileClose(f)
                MostarReporte(strTemp)
            Else
                MsgBox("No se encontró inventario para NAFTA. Por favor, revise si fue cargado correctamente.")
            End If

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub
#End Region

#Region "Available Corporate"

    Private Function sqlAvailableCorp(ByVal tipo As Integer)
        Dim strSQL As String = STR_VACIO

        strSQL = " SELECT x1.*, ROUND(SUM(x1.GT_OCEAN + x1.GT_PENDTOSHIP + x1.GT_WAREHOUSE + x1.SV_OCEAN + x1.SV_PENDTOSHIP + x1.SV_WAREHOUSE + x1.HN_OCEAN + x1.HN_PENDTOSHIP + x1.HN_WAREHOUSE + x1.DR_OCEAN + x1.DR_PENDTOSHIP + x1.DR_WAREHOUSE), 2) Total_Grupo, "
        strSQL &= "  ROUND(SUM(x1.GT_OCEAN + x1.GT_PENDTOSHIP + x1.GT_WAREHOUSE + x1.GT_OCEANSOLD + x1.GT_PENDTOSHIPSOLD + x1.GT_WAREHOUSESOLD + x1.SV_OCEAN + x1.SV_PENDTOSHIP + x1.SV_WAREHOUSE + x1.SV_OCEANSOLD + x1.SV_PENDTOSHIPSOLD + x1.SV_WAREHOUSESOLD + x1.HN_OCEAN + x1.HN_PENDTOSHIP + x1.HN_WAREHOUSE + x1.HN_OCEANSOLD + x1.HN_PENDTOSHIPSOLD + x1.HN_WAREHOUSESOLD + x1.DR_OCEAN + x1.DR_PENDTOSHIP + x1.DR_WAREHOUSE + x1.DR_OCEANSOLD + x1.DR_PENDTOSHIPSOLD + x1.DR_WAREHOUSESOLD), 2) Total2 "
        strSQL &= "    FROM( "
        strSQL &= "        Select l2.PIdGrupo, l2.grupo, "
        '-- Guatemala
        strSQL &= "            SUM(CASE WHEN l2.PStatus_Joby = 'OCEAN' THEN l2.GT ELSE 0 END) 'GT_OCEAN', "
        strSQL &= "              SUM(CASE WHEN l2.PStatus_Joby = 'PEND. TO SHIP' THEN l2.GT ELSE 0 END) 'GT_PENDTOSHIP', SUM(CASE WHEN l2.PStatus_Joby = 'PEND. TO SHIP/SOLD' THEN l2.GT ELSE 0 END)'GT_PENDTOSHIPSOLD', "
        strSQL &= "                    SUM(CASE WHEN l2.PStatus_Joby = 'WAREHOUSE' THEN l2.GT ELSE 0 END) 'GT_WAREHOUSE', "
        strSQL &= "                        SUM(CASE WHEN l2.PStatus_Joby = 'WAREHOUSE/SOLD' THEN l2.GT ELSE 0 END) 'GT_WAREHOUSESOLD', "
        strSQL &= "                            SUM(CASE WHEN l2.PStatus_Joby = 'OCEAN/SOLD' THEN l2.GT ELSE 0 END) 'GT_OCEANSOLD', "
        '-- El Salvador
        strSQL &= "                                SUM(CASE WHEN l2.PStatus_Joby = 'OCEAN' THEN l2.SV ELSE 0 END) 'SV_OCEAN', "
        strSQL &= "                                    SUM(CASE WHEN l2.PStatus_Joby = 'PEND. TO SHIP' THEN l2.SV ELSE 0 END) 'SV_PENDTOSHIP', SUM(CASE WHEN l2.PStatus_Joby = 'PEND. TO SHIP/SOLD' THEN l2.SV ELSE 0 END) 'SV_PENDTOSHIPSOLD', "
        strSQL &= "                                        SUM(CASE WHEN l2.PStatus_Joby = 'WAREHOUSE' THEN l2.SV ELSE 0 END) 'SV_WAREHOUSE', "
        strSQL &= "                                            SUM(CASE WHEN l2.PStatus_Joby = 'WAREHOUSE/SOLD' THEN l2.SV ELSE 0 END) 'SV_WAREHOUSESOLD', "
        strSQL &= "                                                SUM(CASE WHEN l2.PStatus_Joby = 'OCEAN/SOLD' THEN l2.SV ELSE 0 END) 'SV_OCEANSOLD', "
        '-- Honduras
        strSQL &= "                                                    SUM(CASE WHEN l2.PStatus_Joby = 'OCEAN' THEN l2.HN ELSE 0 END) 'HN_OCEAN', "
        strSQL &= "                                                        SUM(CASE WHEN l2.PStatus_Joby = 'PEND. TO SHIP' THEN l2.HN ELSE 0 END) 'HN_PENDTOSHIP', SUM(CASE WHEN l2.PStatus_Joby ='PEND. TO SHIP/SOLD' THEN l2.HN ELSE 0 END) 'HN_PENDTOSHIPSOLD',"
        strSQL &= "                                                            SUM(CASE WHEN l2.PStatus_Joby = 'WAREHOUSE' THEN l2.HN ELSE 0 END) 'HN_WAREHOUSE', "
        strSQL &= "                                                                SUM(CASE WHEN l2.PStatus_Joby = 'WAREHOUSE/SOLD' THEN l2.HN ELSE 0 END) 'HN_WAREHOUSESOLD', "
        strSQL &= "                                                                    SUM(CASE WHEN l2.PStatus_Joby = 'OCEAN/SOLD' THEN l2.HN ELSE 0 END) 'HN_OCEANSOLD', "
        '-- Dominicana
        strSQL &= "                                                                        SUM(CASE WHEN l2.PStatus_Joby = 'OCEAN' THEN l2.DR ELSE 0 END) 'DR_OCEAN', "
        strSQL &= "                                                                            SUM(CASE WHEN l2.PStatus_Joby = 'PEND. TO SHIP' THEN l2.DR ELSE 0 END) 'DR_PENDTOSHIP', SUM(CASE WHEN l2.PStatus_Joby = 'PEND. TO SHIP/SOLD' THEN l2.DR ELSE 0 END) 'DR_PENDTOSHIPSOLD', "
        strSQL &= "                                                                                SUM(CASE WHEN l2.PStatus_Joby = 'WAREHOUSE' THEN l2.DR ELSE 0 END) 'DR_WAREHOUSE', "
        strSQL &= "                                                                                SUM(CASE WHEN l2.PStatus_Joby = 'WAREHOUSE/SOLD' THEN l2.DR ELSE 0 END) 'DR_WAREHOUSESOLD', "
        strSQL &= "                                                                            SUM(CASE WHEN l2.PStatus_Joby = 'OCEAN/SOLD' THEN l2.DR ELSE 0 END) 'DR_OCEANSOLD', l2.Registro "
        strSQL &= "                                                                        FROM ( "
        strSQL &= "                                                                    Select s1.PIdGrupo, s1.estado_Grupo grupo, s1.PStatus, s1.PStatus_Joby,s1.GT,s1.SV, s1.HN, s1.DR, s1.Registro "
        strSQL &= "                                                                FROM( "
        strSQL &= "                                                            Select e.idEmpresa, p.PIdGrupo, IFNULL(g.nombre_Grupo,'SIN GRUPO') estado_Grupo,p.PStatus_Joby, p.PStatus, "
        strSQL &= "                                                        SUM(CASE WHEN e.idEmpresa = 1 THEN p.PLibras ELSE 0 END) 'GT', "
        strSQL &= "                                                    SUM(CASE WHEN e.idEmpresa = 2 THEN p.PLibras ELSE 0 END) 'SV', "
        strSQL &= "                                                SUM(CASE WHEN e.idEmpresa = 3 THEN p.PLibras ELSE 0 END) 'HN', "
        strSQL &= "                                            SUM(CASE WHEN e.idEmpresa = 4 THEN p.PLibras ELSE 0 END) 'DR', p.Registro "
        strSQL &= "                                        From YarnDivision.Planning p "
        strSQL &= "                                    Left Join YarnDivision.Grupo_Detalle d ON d.idEmpresa = p.PEmpresa and d.idGrupo = p.PIdGrupo and d.idTipo = p.PTipoGrupo and d.Codigo = p.PArt_Codigo "
        strSQL &= "                                Left Join YarnDivision.Grupo g ON g.idGrupo = d.idGrupo and g.idTipo= d.idTipo "
        strSQL &= "                            Left Join YarnDivision.Empresa e ON e.idEmpresa=  p.PEmpresa "

        If tipo = INT_CERO Then ' hilo
            strSQL &= "        Where p.Correlativo >0 AND p.PTipoGrupo = 2 AND p.PIdGrupo IN(d.idGrupo,-2)  AND p.PCategoria != 'FIBER' AND p.PCat_Pais !=3 "
        Else 'Fibra
            strSQL &= "        Where p.Correlativo >0 AND p.PTipoGrupo = 2 AND p.PIdGrupo IN(d.idGrupo,-2) AND p.PCategoria = 'FIBER' AND p.PCat_Pais !=3 "
        End If

        strSQL &= "                    GROUP BY p.PIdGrupo, p.PStatus_Joby) s1 )l2"
        strSQL &= "                GROUP BY l2.PIdGrupo) x1 "
        strSQL &= "            GROUP BY x1.PIdGrupo "
        strSQL &= "      ORDER BY x1.grupo ASC "

        Return strSQL

    End Function

    Public Sub AvailableCorp(ByVal tipo As Integer)
        Dim strSQL As String = STR_VACIO
        Dim f As Byte
        Dim strTemp As String = STR_VACIO
        Dim strPais As String = STR_VACIO
        Dim dblSuma(28) As Double
        Dim SumaPais(7) As Double
        Dim dblSumaSold(3) As Double
        Dim dblSoldxPais(4) As Double
        Dim sumaTotal As Double = INT_CERO
        Dim sumaTotal2 As Double = INT_CERO
        Dim sumaTotalSold As Double = INT_CERO
        Dim sumaDiferencia As Double = INT_CERO
        Dim dblPend(20) As Double
        Dim i As Integer = 0

        'conexiones 
        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader
        Try
            strSQL = sqlAvailableCorp(tipo)
            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSQL, CON)
            REA = COM.ExecuteReader
            If REA.HasRows Then
                Do While REA.Read

                    If i = 0 Then
                        strTemp = cFunciones.ArchivoTemporal
                        f = FreeFile()
                        FileOpen(f, strTemp, OpenMode.Append)

                        Print(f, " <html > ")
                        Print(f, " <head > ")


                        Print(f, " <style type='text/css'>")
                        Print(f, " table {table-layout: fixed; empty-cells: show; border-collapse:collapse}")
                        Print(f, " caption {padding: 5px; text-align:left; font-family: Tahoma,  Arial;font-size: 8pt}")
                        Print(f, " td {text-align:right;border:solid Gray 1px; padding:3px 5px; font-family: Tahoma, Arial;font-size: 7pt}")
                        Print(f, " th {width: 1.8cm; border:solid Gray 1px; background-color: Black; color: White; padding:2px 5px; font-family: Tahoma,  Arial;font-size: 6pt}")
                        Print(f, " th {text-align:center;border:solid Gray 1px; padding:3px 5px; font-family: Tahoma,  Arial;font-size: 7pt}")
                        Print(f, " th.numero {text-align:right; mso-number-format:\#\,\#\#0\.00}")
                        Print(f, " th.unitario {text-align:right; mso-number-format:\#\,\#\#0\.00#####}")
                        Print(f, " th.titulo {text-align:right;font-family: Tahoma,  Arial;font-size: 9pt")
                        Print(f, " .titulo {font-family: Tahoma,  Arial;font-size: 9pt}")
                        Print(f, " .encabezado {text-align: left; border: none; width: 3.1cm}")
                        Print(f, " .pie {font-family: Tahoma,  Arial;font-size: 7pt}")
                        Print(f, " .izquierda {text-align:left}")
                        Print(f, " .centro {text-align:center}")
                        Print(f, " .derecha {text-align:right}")
                        Print(f, " .info {text-align:left; border:none}")
                        Print(f, "</style>")

                        Print(f, "<td style='font-family: Tahoma;font-size:25pt'><b>Available Corporate <br> </b></td>")
                        Print(f, "<td style='font-family: Tahoma;font-size:7pt'><b>To " & REA.GetDateTime("Registro").ToString(FORMATO_MYSQL) & " </b></td>")

                        Print(f, "</head>")
                        Print(f, "<body>")

                        Print(f, "<table cellspacing=0>")
                        'Encabezado de columnas: style='width: 1cm'
                        Print(f, "<tr>")
                        Print(f, "<th style='width: 5cm; background-color: white; color: black'></th>")
                        Print(f, "<th colspan = 3 style='width: 9cm; background-color: #87DE84; color: black'>GUATEMALA</th>")
                        Print(f, "<th colspan = 3 style='width: 9cm; background-color: #70A9E0; color: black'>EL SALVADOR</th>")
                        Print(f, "<th colspan = 3 style='width: 9cm; background-color: #F7DF52; color: black'>HONDURAS</th>")
                        Print(f, "<th colspan = 3 style='width: 9cm; background-color: #BBBABA; color: black'>REPUBLICA DOMINICANA</th>")
                        Print(f, "<th style='width: 3cm; background-color: white; color: white'></th>")
                        Print(f, "<th style='width: 3cm; background-color: #FF8000; color: black'></th>")
                        Print(f, "<th style='width: 3cm; color: black'></th>")
                        Print(f, "</tr>")

                        Print(f, "<tr>")
                        Print(f, "<th style='width: 5cm'>YARN DESCRIPTION</th>")
                        Print(f, "<th style='width: 2.5cm;background-color: #87DE84; color: black'>PEND. TO SHIP</th>")
                        Print(f, "<th style='width: 2.5cm;background-color: #87DE84; color: black'>OCEAN</th>")
                        Print(f, "<th style='width: 2.5cm;background-color: #87DE84; color: black'>WAREHOUSE</th>")

                        Print(f, "<th style='width: 2.5cm;background-color: #70A9E0; color: black'>PEND. TO SHIP</th>")
                        Print(f, "<th style='width: 2.5cm;background-color: #70A9E0; color: black'>OCEAN</th>")
                        Print(f, "<th style='width: 2.5cm;background-color: #70A9E0; color: black'>WAREHOUSE</th>")

                        Print(f, "<th style='width: 2.5cm;background-color: #F7DF52; color: black'>PEND. TO SHIP</th>")
                        Print(f, "<th style='width: 2.5cm;background-color: #F7DF52; color: black'>OCEAN</th>")
                        Print(f, "<th style='width: 2.5cm;background-color: #F7DF52; color: black'>WAREHOUSE</th>")

                        Print(f, "<th style='width: 2.5cm;background-color: #BBBABA; color: black'>PEND. TO SHIP</th>")
                        Print(f, "<th style='width: 2.5cm;background-color: #BBBABA; color: black'>OCEAN</th>")
                        Print(f, "<th style='width: 2.5cm;background-color: #BBBABA; color: black'>WAREHOUSE</th>")

                        Print(f, "<th style ='width: 3cm; background-color: white; color: black'>TOTAL LBS</th>")
                        Print(f, "<th style='width: 2cm; background-color: #FF8000;border-color: #000000; color: black'>TOTAL SOLD</th>")
                        Print(f, "<th style ='width: 3cm'>TOTAL AVAILABLE </th>")
                        'Print(f, "<th style ='width: 3cm'>TOTAL </th>")
                        'Print(f, "<th style ='width: 3cm'>TOTAL-TOTAL SOLD </th>")
                        'Print(f, "<th style ='width: 3cm'>DIFERENCIA </th>")
                        Print(f, "</tr>")
                        i = i + 1
                    End If

                    Print(f, "<tr>")
                    Print(f, "<td style='width: 5cm; text-align:left'>" & REA.GetString("grupo") & "</td>")
                    Print(f, "<td style='width: 2.5cm'>" & If(REA.GetDouble("GT_PENDTOSHIP") + REA.GetDouble("GT_PENDTOSHIPSOLD") = 0, "", (Math.Round(REA.GetDouble("GT_PENDTOSHIP"), 2) + Math.Round(REA.GetDouble("GT_PENDTOSHIPSOLD"), 2)).ToString(FORMATO_MONEDA) & "</td>"))
                    Print(f, "<td style='width: 2.5cm'>" & If(REA.GetDouble("GT_OCEAN") + REA.GetDouble("GT_OCEANSOLD") = 0, "", (Math.Round(REA.GetDouble("GT_OCEAN"), 2) + Math.Round(REA.GetDouble("GT_OCEANSOLD"), 2)).ToString(FORMATO_MONEDA) & "</td>"))
                    Print(f, "<td style='width: 2.5cm'>" & If(REA.GetDouble("GT_WAREHOUSE") + REA.GetDouble("GT_WAREHOUSESOLD") = 0, "", (Math.Round(REA.GetDouble("GT_WAREHOUSE"), 2) + Math.Round(REA.GetDouble("GT_WAREHOUSESOLD"), 2)).ToString(FORMATO_MONEDA) & "</td>"))
                    dblSoldxPais(0) = Math.Round(REA.GetDouble("GT_PENDTOSHIPSOLD"), 2) + Math.Round(REA.GetDouble("GT_OCEANSOLD"), 2) + Math.Round(REA.GetDouble("GT_WAREHOUSESOLD"), 2) ' Suma Sold GT

                    Print(f, "<td style='width: 2.5cm'>" & If(REA.GetDouble("SV_PENDTOSHIP") + REA.GetDouble("SV_PENDTOSHIPSOLD") = 0, "", (Math.Round(REA.GetDouble("SV_PENDTOSHIP"), 2) + Math.Round(REA.GetDouble("SV_PENDTOSHIPSOLD"), 2)).ToString(FORMATO_MONEDA) & "</td>"))
                    Print(f, "<td style='width: 2.5cm'>" & If(REA.GetDouble("SV_OCEAN") + REA.GetDouble("SV_OCEANSOLD") = 0, "", (Math.Round(REA.GetDouble("SV_OCEAN"), 2) + Math.Round(REA.GetDouble("SV_OCEANSOLD"), 2)).ToString(FORMATO_MONEDA) & "</td>"))
                    Print(f, "<td style='width: 2.5cm'>" & If(REA.GetDouble("SV_WAREHOUSE") + REA.GetDouble("SV_WAREHOUSESOLD") = 0, "", (Math.Round(REA.GetDouble("SV_WAREHOUSE"), 2) + Math.Round(REA.GetDouble("SV_WAREHOUSESOLD"), 2)).ToString(FORMATO_MONEDA) & "</td>"))
                    dblSoldxPais(1) = Math.Round(REA.GetDouble("SV_PENDTOSHIPSOLD"), 2) + Math.Round(REA.GetDouble("SV_OCEANSOLD"), 2) + Math.Round(REA.GetDouble("SV_WAREHOUSESOLD"), 2) ' Suma Sold SV

                    Print(f, "<td style='width: 2.5cm'>" & If(REA.GetDouble("HN_PENDTOSHIP") + REA.GetDouble("HN_PENDTOSHIPSOLD") = 0, "", (Math.Round(REA.GetDouble("HN_PENDTOSHIP"), 2) + Math.Round(REA.GetDouble("HN_PENDTOSHIPSOLD"), 2)).ToString(FORMATO_MONEDA) & "</td>"))
                    Print(f, "<td style='width: 2.5cm'>" & If(REA.GetDouble("HN_OCEAN") + REA.GetDouble("HN_OCEANSOLD") = 0, "", (Math.Round(REA.GetDouble("HN_OCEAN"), 2) + Math.Round(REA.GetDouble("HN_OCEANSOLD"), 2)).ToString(FORMATO_MONEDA) & "</td>"))
                    Print(f, "<td style='width: 2.5cm'>" & If(REA.GetDouble("HN_WAREHOUSE") + REA.GetDouble("HN_WAREHOUSESOLD") = 0, "", (Math.Round(REA.GetDouble("HN_WAREHOUSE"), 2) + Math.Round(REA.GetDouble("HN_WAREHOUSESOLD"), 2)).ToString(FORMATO_MONEDA) & "</td>"))
                    dblSoldxPais(2) = Math.Round(REA.GetDouble("HN_PENDTOSHIPSOLD"), 2) + Math.Round(REA.GetDouble("HN_OCEANSOLD"), 2) + Math.Round(REA.GetDouble("HN_WAREHOUSESOLD"), 2) 'Suma Sold HN

                    Print(f, "<td style='width: 2.5cm'>" & If(REA.GetDouble("DR_PENDTOSHIP") + REA.GetDouble("DR_PENDTOSHIPSOLD") = 0, "", (Math.Round(REA.GetDouble("DR_PENDTOSHIP"), 2) + Math.Round(REA.GetDouble("DR_PENDTOSHIPSOLD"), 2)).ToString(FORMATO_MONEDA) & "</td>"))
                    Print(f, "<td style='width: 2.5cm'>" & If(REA.GetDouble("DR_OCEAN") + REA.GetDouble("DR_OCEANSOLD") = 0, "", (Math.Round(REA.GetDouble("DR_OCEAN"), 2) + Math.Round(REA.GetDouble("DR_OCEANSOLD"), 2)).ToString(FORMATO_MONEDA) & "</td>"))
                    Print(f, "<td style='width: 2.5cm'>" & If(REA.GetDouble("DR_WAREHOUSE") + REA.GetDouble("DR_WAREHOUSESOLD") = 0, "", (Math.Round(REA.GetDouble("DR_WAREHOUSE"), 2) + Math.Round(REA.GetDouble("DR_WAREHOUSESOLD"), 2)).ToString(FORMATO_MONEDA) & "</td>"))
                    dblSoldxPais(3) = Math.Round(REA.GetDouble("DR_PENDTOSHIPSOLD"), 2) + Math.Round(REA.GetDouble("DR_OCEANSOLD"), 2) + Math.Round(REA.GetDouble("DR_WAREHOUSESOLD"), 2)

                    dblSoldxPais(4) = Math.Round((dblSoldxPais(0) + dblSoldxPais(1) + dblSoldxPais(2) + dblSoldxPais(3)), 2)
                    sumaTotal = (Math.Round(REA.GetDouble("GT_PENDTOSHIP"), 2) + Math.Round(REA.GetDouble("SV_PENDTOSHIP"), 2) + Math.Round(REA.GetDouble("HN_PENDTOSHIP"), 2) + Math.Round(REA.GetDouble("DR_PENDTOSHIP"), 2) + Math.Round(REA.GetDouble("GT_OCEAN"), 2) + Math.Round(REA.GetDouble("SV_OCEAN"), 2) + Math.Round(REA.GetDouble("HN_OCEAN"), 2) + Math.Round(REA.GetDouble("DR_OCEAN"), 2) + Math.Round(REA.GetDouble("GT_WAREHOUSE"), 2) + Math.Round(REA.GetDouble("SV_WAREHOUSE"), 2) + Math.Round(REA.GetDouble("HN_WAREHOUSE"), 2) + Math.Round(REA.GetDouble("DR_WAREHOUSE"), 2))
                    sumaTotal2 = (Math.Round(REA.GetDouble("GT_PENDTOSHIP"), 2) + Math.Round(REA.GetDouble("SV_PENDTOSHIP"), 2) + Math.Round(REA.GetDouble("HN_PENDTOSHIP"), 2) + Math.Round(REA.GetDouble("DR_PENDTOSHIP"), 2) + Math.Round(REA.GetDouble("GT_PENDTOSHIPSOLD"), 2) + Math.Round(REA.GetDouble("SV_PENDTOSHIPSOLD"), 2) + Math.Round(REA.GetDouble("HN_PENDTOSHIPSOLD"), 2) + Math.Round(REA.GetDouble("DR_PENDTOSHIPSOLD"), 2) + Math.Round(REA.GetDouble("GT_OCEAN"), 2) + Math.Round(REA.GetDouble("SV_OCEAN"), 2) + Math.Round(REA.GetDouble("HN_OCEAN"), 2) + Math.Round(REA.GetDouble("DR_OCEAN"), 2) + Math.Round(REA.GetDouble("GT_OCEANSOLD"), 2) + Math.Round(REA.GetDouble("SV_OCEANSOLD"), 2) + Math.Round(REA.GetDouble("HN_OCEANSOLD"), 2) + Math.Round(REA.GetDouble("DR_OCEANSOLD"), 2) + Math.Round(REA.GetDouble("GT_WAREHOUSE"), 2) + Math.Round(REA.GetDouble("SV_WAREHOUSE"), 2) + Math.Round(REA.GetDouble("HN_WAREHOUSE"), 2) + Math.Round(REA.GetDouble("DR_WAREHOUSE"), 2) + Math.Round(REA.GetDouble("GT_WAREHOUSESOLD"), 2) + Math.Round(REA.GetDouble("SV_WAREHOUSESOLD"), 2) + Math.Round(REA.GetDouble("HN_WAREHOUSESOLD"), 2) + Math.Round(REA.GetDouble("DR_WAREHOUSESOLD"), 2))
                    sumaTotalSold = (sumaTotal2 - dblSoldxPais(4))
                    sumaDiferencia = Math.Round((REA.GetDouble("Total_Grupo") - sumaTotalSold), 2)
                    Print(f, "<td style ='width: 2cm; text-align:right'>" & (sumaTotal + dblSoldxPais(4)).ToString(FORMATO_MONEDA) & "</td>")
                    Print(f, "<td style ='width: 2cm; text-align:right'>" & If(dblSoldxPais(4) = 0, "", dblSoldxPais(4).ToString(FORMATO_MONEDA)) & "</td>")
                    Print(f, "<td style ='width: 3cm; text-align:right'>" & (sumaTotal).ToString(FORMATO_MONEDA) & "</td>")
                    'Print(f, "<td style ='width: 3cm; text-align:right'>" & (sumaTotal2).ToString(FORMATO_MONEDA) & "</td>")
                    'Print(f, "<td style ='width: 3cm; text-align:right'>" & (sumaTotalSold).ToString(FORMATO_MONEDA) & "</td>")
                    'Print(f, "<td style ='width: 3cm; text-align:right'>" & (sumaDiferencia).ToString(FORMATO_MONEDA) & "</td>")
                    Print(f, "</tr>")

                    ' Sumas
                    ' Guatemala
                    dblSuma(0) = dblSuma(0) + Math.Round(REA.GetDouble("GT_PENDTOSHIP"), 2) + Math.Round(REA.GetDouble("GT_PENDTOSHIPSOLD"), 2)
                    dblPend(1) = dblPend(1) + Math.Round(REA.GetDouble("GT_PENDTOSHIP"), 2)
                    dblSuma(21) = dblSuma(21) + Math.Round(REA.GetDouble("GT_PENDTOSHIPSOLD"), 2)
                    dblSuma(1) = dblSuma(1) + Math.Round(REA.GetDouble("GT_OCEAN"), 2) + Math.Round(REA.GetDouble("GT_OCEANSOLD"), 2)
                    dblPend(2) = dblPend(2) + Math.Round(REA.GetDouble("GT_OCEAN"), 2)
                    dblSuma(4) = dblSuma(4) + Math.Round(REA.GetDouble("GT_OCEANSOLD"), 2)
                    dblSuma(2) = dblSuma(2) + Math.Round(REA.GetDouble("GT_WAREHOUSE"), 2) + Math.Round(REA.GetDouble("GT_WAREHOUSESOLD"), 2)
                    dblPend(3) = dblPend(3) + Math.Round(REA.GetDouble("GT_WAREHOUSE"), 2)
                    dblSuma(3) = dblSuma(3) + Math.Round(REA.GetDouble("GT_WAREHOUSESOLD"), 2)
                    SumaPais(4) = SumaPais(4) + SumaPais(0)

                    ' El Salvador
                    dblSuma(5) = dblSuma(5) + Math.Round(REA.GetDouble("SV_PENDTOSHIP"), 2) + Math.Round(REA.GetDouble("SV_PENDTOSHIPSOLD"), 2)
                    dblPend(4) = dblPend(4) + Math.Round(REA.GetDouble("SV_PENDTOSHIP"), 2)
                    dblSuma(22) = dblSuma(22) + Math.Round(REA.GetDouble("SV_PENDTOSHIPSOLD"), 2)
                    dblSuma(6) = dblSuma(6) + Math.Round(REA.GetDouble("SV_OCEAN") + REA.GetDouble("SV_OCEANSOLD"), 2)
                    dblPend(5) = dblPend(5) + Math.Round(REA.GetDouble("SV_OCEAN"), 2)
                    dblSuma(9) = dblSuma(9) + Math.Round(REA.GetDouble("SV_OCEANSOLD"), 2)
                    dblSuma(7) = dblSuma(7) + Math.Round(REA.GetDouble("SV_WAREHOUSE") + REA.GetDouble("SV_WAREHOUSESOLD"), 2)
                    dblPend(6) = dblPend(6) + Math.Round(REA.GetDouble("SV_WAREHOUSE"), 2)
                    dblSuma(8) = dblSuma(8) + Math.Round(REA.GetDouble("SV_WAREHOUSESOLD"), 2)
                    SumaPais(5) = SumaPais(5) + SumaPais(1)

                    ' Honduras
                    dblSuma(10) = dblSuma(10) + Math.Round(REA.GetDouble("HN_PENDTOSHIP"), 2) + Math.Round(REA.GetDouble("HN_PENDTOSHIPSOLD"), 2)
                    dblPend(7) = dblPend(7) + Math.Round(REA.GetDouble("HN_PENDTOSHIP"), 2)
                    dblSuma(23) = dblSuma(23) + Math.Round(REA.GetDouble("HN_PENDTOSHIPSOLD"), 2)
                    dblSuma(11) = dblSuma(11) + Math.Round(REA.GetDouble("HN_OCEAN") + REA.GetDouble("HN_OCEANSOLD"), 2)
                    dblPend(8) = dblPend(8) + Math.Round(REA.GetDouble("HN_OCEAN"), 2)
                    dblSuma(14) = dblSuma(14) + Math.Round(REA.GetDouble("HN_OCEANSOLD"), 2)
                    dblSuma(12) = dblSuma(12) + Math.Round(REA.GetDouble("HN_WAREHOUSE") + REA.GetDouble("HN_WAREHOUSESOLD"), 2)
                    dblPend(9) = dblPend(9) + Math.Round(REA.GetDouble("HN_WAREHOUSE"), 2)
                    dblSuma(13) = dblSuma(13) + Math.Round(REA.GetDouble("HN_WAREHOUSESOLD"), 2)
                    SumaPais(6) = SumaPais(6) + SumaPais(2)

                    ' Dominicana
                    dblSuma(15) = dblSuma(15) + Math.Round(REA.GetDouble("DR_PENDTOSHIP"), 2) + Math.Round(REA.GetDouble("DR_PENDTOSHIPSOLD"), 2)
                    dblPend(10) = dblPend(10) + Math.Round(REA.GetDouble("DR_PENDTOSHIP"), 2)
                    dblSuma(24) = dblSuma(24) + Math.Round(REA.GetDouble("DR_PENDTOSHIPSOLD"), 2)
                    dblSuma(16) = dblSuma(16) + Math.Round(REA.GetDouble("DR_OCEAN") + REA.GetDouble("DR_OCEANSOLD"), 2)
                    dblPend(11) = dblPend(11) + Math.Round(REA.GetDouble("DR_OCEAN"), 2)
                    dblSuma(19) = dblSuma(19) + Math.Round(REA.GetDouble("DR_OCEANSOLD"), 2)
                    dblSuma(17) = dblSuma(17) + Math.Round(REA.GetDouble("DR_WAREHOUSE") + REA.GetDouble("DR_WAREHOUSESOLD"), 2)
                    dblPend(12) = dblPend(12) + Math.Round(REA.GetDouble("DR_WAREHOUSE"), 2)
                    dblSuma(18) = dblSuma(18) + Math.Round(REA.GetDouble("DR_WAREHOUSESOLD"), 2)
                    SumaPais(7) = SumaPais(7) + SumaPais(3)

                    ' Total
                    dblSumaSold(0) = Math.Round(dblSuma(21) + dblSuma(22) + dblSuma(23) + dblSuma(24), 2) 'Suma Pend. to Ship / Sold de todos los paises
                    dblSumaSold(1) = Math.Round(dblSuma(4) + dblSuma(9) + dblSuma(14) + dblSuma(19), 2) 'Suma Ocean / Sold de todos los paises
                    dblSumaSold(2) = Math.Round(dblSuma(3) + dblSuma(8) + dblSuma(13) + dblSuma(18), 2) 'Suma Warehouse / Sold de todos los paises
                    dblSumaSold(3) = Math.Round(dblSumaSold(0) + dblSumaSold(1) + dblSumaSold(2), 2) ' Suma Total de Sold
                    dblSuma(20) = dblSuma(20) + sumaTotal
                    dblSuma(25) = dblSuma(25) + sumaTotal2

                Loop
            End If

            Print(f, "<tr>")
            Print(f, "<th style='width: 5cm'>Total General</th>")
            Print(f, "<td style='width: 2.5cm; background-color: #87DE84; color: black'>" & dblSuma(0).ToString(FORMATO_MONEDA) & "</td>")
            Print(f, "<td style='width: 2.5cm; background-color: #87DE84; color: black'>" & dblSuma(1).ToString(FORMATO_MONEDA) & "</td>")
            Print(f, "<td style='width: 2.5cm; background-color: #87DE84; color: black'>" & dblSuma(2).ToString(FORMATO_MONEDA) & "</td>")

            Print(f, "<td style='width: 2.5cm; background-color: #70A9E0; color: black'>" & dblSuma(5).ToString(FORMATO_MONEDA) & "</td>")
            Print(f, "<td style='width: 2.5cm; background-color: #70A9E0; color: black'>" & dblSuma(6).ToString(FORMATO_MONEDA) & "</td>")
            Print(f, "<td style='width: 2.5cm; background-color: #70A9E0; color: black'>" & dblSuma(7).ToString(FORMATO_MONEDA) & "</td>")

            Print(f, "<td style='width: 2.5cm; background-color: #F7DF52; color: black'>" & dblSuma(10).ToString(FORMATO_MONEDA) & "</td>")
            Print(f, "<td style='width: 2.5cm; background-color: #F7DF52; color: black'>" & dblSuma(11).ToString(FORMATO_MONEDA) & "</td>")
            Print(f, "<td style='width: 2.5cm; background-color: #F7DF52; color: black'>" & dblSuma(12).ToString(FORMATO_MONEDA) & "</td>")

            Print(f, "<td style='width: 2.5cm; background-color: #BBBABA; color: black'>" & dblSuma(15).ToString(FORMATO_MONEDA) & "</td>")
            Print(f, "<td style='width: 2.5cm; background-color: #BBBABA; color: black'>" & dblSuma(16).ToString(FORMATO_MONEDA) & "</td>")
            Print(f, "<td style='width: 2.5cm; background-color: #BBBABA; color: black'>" & dblSuma(17).ToString(FORMATO_MONEDA) & "</td>")

            Print(f, "<th style='width: 3cm; text-align:right; background-color: white; color: black'>" & (dblSuma(20) + dblSumaSold(3)).ToString(FORMATO_MONEDA) & "</th>") 'Columna TOTAL LBS
            Print(f, "<td style='width: 2cm; text-align:right;background-color: #FF8000; color: black'>" & dblSumaSold(3).ToString(FORMATO_MONEDA) & "</td>") 'SOLD
            Print(f, "<th style='width: 3cm; text-align:right'>" & (dblSuma(20)).ToString(FORMATO_MONEDA) & "</th>") 'AVAILABLE
            'Print(f, "<th style='width: 3cm; text-align:right'>" & (dblSuma(25)).ToString(FORMATO_MONEDA) & "</th>")
            'Dim totalSold As Double = Math.Round((dblSuma(25) - dblSumaSold(3)), 2)
            'Print(f, "<th style='width: 3cm; text-align:right'>" & (totalSold).ToString(FORMATO_MONEDA) & "</th>")
            'Print(f, "<th style='width: 3cm; text-align:right'>" & (dblSuma(20) - totalSold).ToString(FORMATO_MONEDA) & "</th>")
            Print(f, "</tr>")

            Print(f, "</table>")
            Print(f, "<br/>")
            Print(f, "</body>")
            Print(f, "</html>")

            FileClose(f)
            MostarReporte(strTemp)

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

#End Region

#Region "Available Revised"

    Public Sub AvailableRevisedCorp(ByVal tipo As Integer)
        Dim strSQL As String = STR_VACIO
        Dim f As Byte
        Dim strTemp As String = STR_VACIO
        Dim strPais As String = STR_VACIO
        Dim dblSuma(20) As Double
        Dim SumaPais(7) As Double
        Dim i As Integer = 0

        'conexiones 
        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader
        Try
            strSQL = sqlAvailableCorp(tipo)
            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSQL, CON)
            REA = COM.ExecuteReader
            If REA.HasRows Then
                Do While REA.Read

                    If i = 0 Then
                        strTemp = cFunciones.ArchivoTemporal
                        f = FreeFile()
                        FileOpen(f, strTemp, OpenMode.Append)

                        Print(f, " <html > ")
                        Print(f, " <head > ")


                        Print(f, " <style type='text/css'>")
                        Print(f, " table {table-layout: fixed; empty-cells: show; border-collapse:collapse}")
                        Print(f, " caption {padding: 5px; text-align:left; font-family: Tahoma,  Arial;font-size: 8pt}")
                        Print(f, " td {text-align:right;border:solid Gray 1px; padding:3px 5px; font-family: Tahoma, Arial;font-size: 7pt}")
                        Print(f, " th {width: 1.8cm; border:solid Gray 1px; background-color: Black; color: White; padding:2px 5px; font-family: Tahoma,  Arial;font-size: 6pt}")
                        Print(f, " th {text-align:center;border:solid Gray 1px; padding:3px 5px; font-family: Tahoma,  Arial;font-size: 7pt}")
                        Print(f, " th.numero {text-align:right; mso-number-format:\#\,\#\#0\.00}")
                        Print(f, " th.unitario {text-align:right; mso-number-format:\#\,\#\#0\.00#####}")
                        Print(f, " th.titulo {text-align:right;font-family: Tahoma,  Arial;font-size: 9pt")
                        Print(f, " .titulo {font-family: Tahoma,  Arial;font-size: 9pt}")
                        Print(f, " .encabezado {text-align: left; border: none; width: 3.1cm}")
                        Print(f, " .pie {font-family: Tahoma,  Arial;font-size: 7pt}")
                        Print(f, " .izquierda {text-align:left}")
                        Print(f, " .centro {text-align:center}")
                        Print(f, " .derecha {text-align:right}")
                        Print(f, " .info {text-align:left; border:none}")
                        Print(f, "</style>")

                        Print(f, "<td style='font-family: Tahoma;font-size:25pt'><b>Available Corporate <br> </b></td>")
                        Print(f, "<td style='font-family: Tahoma;font-size:7pt'><b>To " & REA.GetDateTime("Registro").ToString(FORMATO_MYSQL) & " </b></td>")

                        Print(f, "</head>")
                        Print(f, "<body>")

                        Print(f, "<table cellspacing=0>")
                        'Encabezado de columnas: style='width: 1cm'
                        Print(f, "<tr>")
                        Print(f, "<th style='width: 5cm; color: black'></th>")
                        Print(f, "<th colspan = 4 style='width: 12cm; background-color: #87DE84; color: black'>GUATEMALA</th>")
                        Print(f, "<th colspan = 4 style='width: 12cm; background-color: #70A9E0; color: black'>EL SALVADOR</th>")
                        Print(f, "<th colspan = 4 style='width: 12cm; background-color: #F7DF52; color: black'>HONDURAS</th>")
                        Print(f, "<th colspan = 4 style='width: 12cm; background-color: #BBBABA; color: black'>REPUBLICA DOMINICANA</th>")
                        Print(f, "<th style='width: 3cm; color: black'></th>")
                        Print(f, "</tr>")

                        Print(f, "<tr>")
                        Print(f, "<th style='width: 5cm'>YARN DESCRIPTION</th>")
                        Print(f, "<th style='width: 2.5cm;background-color: #87DE84; color: black'>PEND. TO SHIP</th>")
                        Print(f, "<th style='width: 2.5cm;background-color: #87DE84; color: black'>OCEAN</th>")
                        Print(f, "<th style='width: 2.5cm;background-color: #87DE84; color: black'>WAREHOUSE</th>")
                        Print(f, "<th style='width: 2.5cm;background-color: #87DE84; color: black'>TOTAL GT</th>")

                        Print(f, "<th style='width: 2.5cm;background-color: #70A9E0; color: black'>PEND. TO SHIP</th>")
                        Print(f, "<th style='width: 2.5cm;background-color: #70A9E0; color: black'>OCEAN</th>")
                        Print(f, "<th style='width: 2.5cm;background-color: #70A9E0; color: black'>WAREHOUSE</th>")
                        Print(f, "<th style='width: 2.5cm;background-color: #70A9E0; color: black'>TOTAL SV</th>")

                        Print(f, "<th style='width: 2.5cm;background-color: #F7DF52; color: black'>PEND. TO SHIP</th>")
                        Print(f, "<th style='width: 2.5cm;background-color: #F7DF52; color: black'>OCEAN</th>")
                        Print(f, "<th style='width: 2.5cm;background-color: #F7DF52; color: black'>WAREHOUSE</th>")
                        Print(f, "<th style='width: 2.5cm;background-color: #F7DF52; color: black'>TOTAL HN</th>")

                        Print(f, "<th style='width: 2.5cm;background-color: #BBBABA; color: black'>PEND. TO SHIP</th>")
                        Print(f, "<th style='width: 2.5cm;background-color: #BBBABA; color: black'>OCEAN</th>")
                        Print(f, "<th style='width: 2.5cm;background-color: #BBBABA; color: black'>WAREHOUSE</th>")
                        Print(f, "<th style='width: 2.5cm;background-color: #BBBABA; color: black'>TOTAL DR</th>")

                        Print(f, "<th style ='width: 3cm'>TOTAL GENERAL </th>")
                        Print(f, "</tr>")
                        i = i + 1
                    End If

                    Print(f, "<tr>")
                    Print(f, "<td style='width: 5cm; text-align:left'>" & REA.GetString("grupo") & "</td>")
                    Print(f, "<td style='width: 2.5cm'>" & If(REA.GetDouble("GT_PENDTOSHIP") = 0, "", REA.GetDouble("GT_PENDTOSHIP").ToString(FORMATO_MONEDA) & "</td>"))
                    Print(f, "<td style='width: 2.5cm'>" & If(REA.GetDouble("GT_OCEAN") + REA.GetDouble("GT_OCEANSOLD") = 0, "", ((REA.GetDouble("GT_OCEAN")) + (REA.GetDouble("GT_OCEANSOLD"))).ToString(FORMATO_MONEDA) & "</td>"))
                    Print(f, "<td style='width: 2.5cm'>" & If(REA.GetDouble("GT_WAREHOUSE") + REA.GetDouble("GT_WAREHOUSESOLD") = 0, "", ((REA.GetDouble("GT_WAREHOUSE")) + (REA.GetDouble("GT_WAREHOUSESOLD"))).ToString(FORMATO_MONEDA) & "</td>"))
                    SumaPais(0) = (REA.GetDouble("GT_PENDTOSHIP")) + (REA.GetDouble("GT_OCEAN")) + (REA.GetDouble("GT_OCEANSOLD")) + (REA.GetDouble("GT_WAREHOUSE")) + (REA.GetDouble("GT_WAREHOUSESOLD"))
                    Print(f, "<td style='width: 5cm; background-color: #BDBDBD'>" & If(SumaPais(0) = 0, "", SumaPais(0).ToString(FORMATO_MONEDA) & "</td>"))
                    'Print(f, "<td style='width: 2.5cm'>" & REA.GetDouble("GT_WAREHOUSESOLD") & "</td>")
                    'Print(f, "<td style='width: 2.5cm'>" & REA.GetDouble("GT_OCEANSOLD") & "</td>")
                    Print(f, "<td style='width: 2.5cm'>" & If(REA.GetDouble("SV_PENDTOSHIP") = 0, "", REA.GetDouble("SV_PENDTOSHIP").ToString(FORMATO_MONEDA) & "</td>"))
                    Print(f, "<td style='width: 2.5cm'>" & If(REA.GetDouble("SV_OCEAN") + REA.GetDouble("SV_OCEANSOLD") = 0, "", ((REA.GetDouble("SV_OCEAN")) + (REA.GetDouble("SV_OCEANSOLD"))).ToString(FORMATO_MONEDA) & "</td>"))
                    Print(f, "<td style='width: 2.5cm'>" & If(REA.GetDouble("SV_WAREHOUSE") + REA.GetDouble("SV_WAREHOUSESOLD") = 0, "", ((REA.GetDouble("SV_WAREHOUSE")) + (REA.GetDouble("SV_WAREHOUSESOLD"))).ToString(FORMATO_MONEDA) & "</td>"))
                    SumaPais(1) = (REA.GetDouble("SV_PENDTOSHIP")) + (REA.GetDouble("SV_OCEAN")) + (REA.GetDouble("SV_OCEANSOLD")) + (REA.GetDouble("SV_WAREHOUSE")) + (REA.GetDouble("SV_WAREHOUSESOLD"))
                    Print(f, "<td style='width: 5cm; background-color: #BDBDBD'>" & If(SumaPais(1) = 0, "", SumaPais(1).ToString(FORMATO_MONEDA) & "</td>"))
                    'Print(f, "<td style='width: 2.5cm'>" & REA.GetDouble("SV_WAREHOUSESOLD") & "</td>")
                    'Print(f, "<td style='width: 2.5cm'>" & REA.GetDouble("SV_OCEANSOLD") & "</td>")
                    Print(f, "<td style='width: 2.5cm'>" & If(REA.GetDouble("HN_PENDTOSHIP") = 0, "", REA.GetDouble("HN_PENDTOSHIP").ToString(FORMATO_MONEDA) & "</td>"))
                    Print(f, "<td style='width: 2.5cm'>" & If(REA.GetDouble("HN_OCEAN") + REA.GetDouble("HN_OCEANSOLD") = 0, "", ((REA.GetDouble("HN_OCEAN")) + (REA.GetDouble("HN_OCEANSOLD"))).ToString(FORMATO_MONEDA) & "</td>"))
                    Print(f, "<td style='width: 2.5cm'>" & If(REA.GetDouble("HN_WAREHOUSE") + REA.GetDouble("HN_WAREHOUSESOLD") = 0, "", ((REA.GetDouble("HN_WAREHOUSE")) + (REA.GetDouble("HN_WAREHOUSESOLD"))).ToString(FORMATO_MONEDA) & "</td>"))
                    SumaPais(2) = (REA.GetDouble("HN_PENDTOSHIP")) + (REA.GetDouble("HN_OCEAN")) + (REA.GetDouble("HN_OCEANSOLD")) + (REA.GetDouble("HN_WAREHOUSE")) + (REA.GetDouble("HN_WAREHOUSESOLD"))
                    Print(f, "<td style='width: 5cm; background-color: #BDBDBD'>" & If(SumaPais(2) = 0, "", SumaPais(2).ToString(FORMATO_MONEDA) & "</td>"))
                    'Print(f, "<td style='width: 2.5cm'>" & REA.GetDouble("HN_WAREHOUSESOLD") & "</td>")
                    'Print(f, "<td style='width: 2.5cm'>" & REA.GetDouble("HN_OCEANSOLD") & "</td>")
                    Print(f, "<td style='width: 2.5cm'>" & If(REA.GetDouble("DR_PENDTOSHIP") = 0, "", REA.GetDouble("DR_PENDTOSHIP").ToString(FORMATO_MONEDA) & "</td>"))
                    Print(f, "<td style='width: 2.5cm'>" & If(REA.GetDouble("DR_OCEAN") + REA.GetDouble("DR_OCEANSOLD") = 0, "", ((REA.GetDouble("DR_OCEAN")) + (REA.GetDouble("DR_OCEANSOLD"))).ToString(FORMATO_MONEDA) & "</td>"))
                    Print(f, "<td style='width: 2.5cm'>" & If(REA.GetDouble("DR_WAREHOUSE") + REA.GetDouble("DR_WAREHOUSESOLD") = 0, "", ((REA.GetDouble("DR_WAREHOUSE")) + (REA.GetDouble("DR_WAREHOUSESOLD"))).ToString(FORMATO_MONEDA) & "</td>"))
                    SumaPais(3) = (REA.GetDouble("DR_PENDTOSHIP")) + (REA.GetDouble("DR_OCEAN")) + (REA.GetDouble("DR_OCEANSOLD")) + (REA.GetDouble("DR_WAREHOUSE")) + (REA.GetDouble("DR_WAREHOUSESOLD"))
                    Print(f, "<td style='width: 5cm; background-color: #BDBDBD'>" & If(SumaPais(3) = 0, "", SumaPais(3).ToString(FORMATO_MONEDA) & "</td>"))
                    'Print(f, "<td style='width: 2.5cm'>" & REA.GetDouble("DR_WAREHOUSESOLD") & "</td>")
                    'Print(f, "<td style='width: 2.5cm'>" & REA.GetDouble("DR_OCEANSOLD") & "</td>")
                    Print(f, "<td style ='width: 3cm; text-align:right'>" & REA.GetDouble("Total_Grupo").ToString(FORMATO_MONEDA) & "</td>")
                    Print(f, "</tr>")

                    ' Sumas
                    ' Guatemala
                    dblSuma(0) = dblSuma(0) + REA.GetDouble("GT_PENDTOSHIP")
                    dblSuma(1) = dblSuma(1) + REA.GetDouble("GT_OCEAN") + REA.GetDouble("GT_OCEANSOLD")
                    dblSuma(2) = dblSuma(2) + REA.GetDouble("GT_WAREHOUSE") + REA.GetDouble("GT_WAREHOUSESOLD")
                    SumaPais(4) = SumaPais(4) + SumaPais(0)
                    'dblSuma(3) = dblSuma(3) + REA.GetDouble("GT_WAREHOUSESOLD")
                    'dblSuma(4) = dblSuma(4) + REA.GetDouble("GT_OCEANSOLD")
                    ' El Salvador
                    dblSuma(5) = dblSuma(5) + REA.GetDouble("SV_PENDTOSHIP")
                    dblSuma(6) = dblSuma(6) + REA.GetDouble("SV_OCEAN") + REA.GetDouble("SV_OCEANSOLD")
                    dblSuma(7) = dblSuma(7) + REA.GetDouble("SV_WAREHOUSE") + REA.GetDouble("SV_WAREHOUSESOLD")
                    SumaPais(5) = SumaPais(5) + SumaPais(1)
                    'dblSuma(8) = dblSuma(8) + REA.GetDouble("SV_WAREHOUSESOLD")
                    'dblSuma(9) = dblSuma(9) + REA.GetDouble("SV_OCEANSOLD")
                    ' Honduras
                    dblSuma(10) = dblSuma(10) + REA.GetDouble("HN_PENDTOSHIP")
                    dblSuma(11) = dblSuma(11) + REA.GetDouble("HN_OCEAN") + REA.GetDouble("HN_OCEANSOLD")
                    dblSuma(12) = dblSuma(12) + REA.GetDouble("HN_WAREHOUSE") + REA.GetDouble("HN_WAREHOUSESOLD")
                    SumaPais(6) = SumaPais(6) + SumaPais(2)
                    ' dblSuma(13) = dblSuma(13) + REA.GetDouble("HN_WAREHOUSESOLD")
                    'dblSuma(14) = dblSuma(14) + REA.GetDouble("HN_OCEANSOLD")
                    ' Dominicana
                    dblSuma(15) = dblSuma(15) + REA.GetDouble("DR_PENDTOSHIP")
                    dblSuma(16) = dblSuma(16) + REA.GetDouble("DR_OCEAN") + REA.GetDouble("DR_OCEANSOLD")
                    dblSuma(17) = dblSuma(17) + REA.GetDouble("DR_WAREHOUSE") + REA.GetDouble("DR_WAREHOUSESOLD")
                    SumaPais(7) = SumaPais(7) + SumaPais(3)
                    'dblSuma(18) = dblSuma(18) + REA.GetDouble("DR_WAREHOUSESOLD")
                    'dblSuma(19) = dblSuma(19) + REA.GetDouble("DR_OCEANSOLD")
                    ' Total
                    dblSuma(20) = dblSuma(20) + REA.GetDouble("Total_Grupo")

                Loop
            End If

            Print(f, "<tr>")
            Print(f, "<th style='width: 5cm'>Total General</th>")
            Print(f, "<td style='width: 2.5cm; background-color: #87DE84; color: black'>" & dblSuma(0).ToString(FORMATO_MONEDA) & "</td>")
            Print(f, "<td style='width: 2.5cm; background-color: #87DE84; color: black'>" & dblSuma(1).ToString(FORMATO_MONEDA) & "</td>")
            Print(f, "<td style='width: 2.5cm; background-color: #87DE84; color: black'>" & dblSuma(2).ToString(FORMATO_MONEDA) & "</td>")
            Print(f, "<td style='width: 2.5cm; background-color: #87DE84; color: black'>" & SumaPais(4).ToString(FORMATO_MONEDA) & "</td>")
            'Print(f, "<td style='width: 2.5cm; background-color: #BCF5A9; color: black'>" & dblSuma(4) & "</td>")
            Print(f, "<td style='width: 2.5cm; background-color: #70A9E0; color: black'>" & dblSuma(5).ToString(FORMATO_MONEDA) & "</td>")
            Print(f, "<td style='width: 2.5cm; background-color: #70A9E0; color: black'>" & dblSuma(6).ToString(FORMATO_MONEDA) & "</td>")
            Print(f, "<td style='width: 2.5cm; background-color: #70A9E0; color: black'>" & dblSuma(7).ToString(FORMATO_MONEDA) & "</td>")
            Print(f, "<td style='width: 2.5cm; background-color: #70A9E0; color: black'>" & SumaPais(5).ToString(FORMATO_MONEDA) & "</td>")
            'Print(f, "<td style='width: 2.5cm; background-color: #BCF5A9; color: black'>" & dblSuma(9) & "</td>")
            Print(f, "<td style='width: 2.5cm; background-color: #F7DF52; color: black'>" & dblSuma(10).ToString(FORMATO_MONEDA) & "</td>")
            Print(f, "<td style='width: 2.5cm; background-color: #F7DF52; color: black'>" & dblSuma(11).ToString(FORMATO_MONEDA) & "</td>")
            Print(f, "<td style='width: 2.5cm; background-color: #F7DF52; color: black'>" & dblSuma(12).ToString(FORMATO_MONEDA) & "</td>")
            Print(f, "<td style='width: 2.5cm; background-color: #F7DF52; color: black'>" & SumaPais(6).ToString(FORMATO_MONEDA) & "</td>")
            'Print(f, "<td style='width: 2.5cm; background-color: #BCF5A9; color: black'>" & dblSuma(14) & "</td>")
            Print(f, "<td style='width: 2.5cm; background-color: #BBBABA; color: black'>" & dblSuma(15).ToString(FORMATO_MONEDA) & "</td>")
            Print(f, "<td style='width: 2.5cm; background-color: #BBBABA; color: black'>" & dblSuma(16).ToString(FORMATO_MONEDA) & "</td>")
            Print(f, "<td style='width: 2.5cm; background-color: #BBBABA; color: black'>" & dblSuma(17).ToString(FORMATO_MONEDA) & "</td>")
            Print(f, "<td style='width: 2.5cm; background-color: #BBBABA; color: black'>" & SumaPais(7).ToString(FORMATO_MONEDA) & "</td>")
            'Print(f, "<td style='width: 2.5cm; background-color: #BCF5A9; color: black'>" & dblSuma(19) & "</td>")
            Print(f, "<th style='width: 3cm; text-align:right'>" & dblSuma(20).ToString(FORMATO_MONEDA) & "</th>")
            Print(f, "</tr>")

            Print(f, "</table>")
            Print(f, "<br/>")
            Print(f, "</body>")
            Print(f, "</html>")

            FileClose(f)
            MostarReporte(strTemp)

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub
#End Region

#Region "Inventory Sumary"

    Private Function sqlInventoryInWH(ByVal tipo As Integer)
        Dim strSQL As String = STR_VACIO

        strSQL = " SELECT s1.*, SUM(s1.GT + s1.SV + s1.HN + s1.DR) Total "
        strSQL &= "    FROM( "
        strSQL &= "        Select e.idEmpresa, p.PIdGrupo, IFNULL(g.nombre_Grupo,'SIN GRUPO') nombre, p.PStatus, "
        strSQL &= "            SUM(CASE WHEN e.idEmpresa = 1 THEN p.PLibras ELSE 0 END) 'GT', "
        strSQL &= "                SUM(CASE WHEN e.idEmpresa = 2 THEN p.PLibras ELSE 0 END) 'SV', "
        strSQL &= "                    SUM(CASE WHEN e.idEmpresa = 3 THEN p.PLibras ELSE 0 END) 'HN', "
        strSQL &= "                        SUM(CASE WHEN e.idEmpresa = 4 THEN p.PLibras ELSE 0 END) 'DR', p.Registro  "
        strSQL &= "                            From YarnDivision.Planning p "
        strSQL &= "                            Left Join YarnDivision.Grupo_Detalle d ON d.idEmpresa = p.PEmpresa and d.idGrupo = p.PIdGrupo and d.idTipo = p.PTipoGrupo and d.Codigo = p.PArt_Codigo "
        strSQL &= "                        Left Join YarnDivision.Grupo g ON g.idGrupo = d.idGrupo and g.idTipo= d.idTipo "
        strSQL &= "                    Left Join YarnDivision.Empresa e ON e.idEmpresa=  p.PEmpresa "

        If tipo = INT_CERO Then ' hilo
            strSQL &= "        Where  p.Correlativo > 0 AND p.PStatus = 'WAREHOUSE' AND p.PTipoGrupo = 2 AND p.PIdGrupo IN(d.idGrupo,-2) and  p.PCategoria != 'FIBER' AND p.PCat_Pais !=3 "
        Else 'Fibra
            strSQL &= "        Where  p.Correlativo > 0 AND p.PStatus = 'WAREHOUSE' AND p.PTipoGrupo = 2 AND p.PIdGrupo IN(d.idGrupo,-2) and  p.PCategoria = 'FIBER' AND p.PCat_Pais !=3 "
        End If
        strSQL &= "            Group by g.idGrupo)s1 "
        strSQL &= "        Group By s1.PidGrupo "
        strSQL &= "  ORDER BY s1.nombre asc "

        Return strSQL
    End Function
    Public Sub InventoryInWarehouse(ByVal tipo As Integer)
        Dim strSQL As String = STR_VACIO
        Dim f As Byte
        Dim strTemp As String = STR_VACIO
        Dim dblSumPais(4) As Double
        Dim i As Integer = 0

        'conexiones 
        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader
        Try
            strSQL = sqlInventoryInWH(tipo)
            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSQL, CON)
            REA = COM.ExecuteReader
            If REA.HasRows Then
                Do While REA.Read

                    If i = 0 Then
                        strTemp = cFunciones.ArchivoTemporal
                        f = FreeFile()
                        FileOpen(f, strTemp, OpenMode.Append)

                        Print(f, " <html > ")
                        Print(f, " <head > ")


                        Print(f, " <style type='text/css'>")
                        Print(f, " table {table-layout: fixed; empty-cells: show; border-collapse:collapse}")
                        Print(f, " caption {padding: 5px; text-align:left; font-family: Tahoma,  Arial;font-size: 8pt}")
                        Print(f, " td {text-align:center;border:solid Gray 1px; padding:3px 5px; font-family: Tahoma, Arial;font-size: 7pt}")
                        Print(f, " th {width: 1.8cm; border:solid Gray 1px; background-color: Black; color: White; padding:2px 5px; font-family: Tahoma,  Arial;font-size: 6pt}")
                        Print(f, " th {text-align:center;border:solid Gray 1px; padding:3px 5px; font-family: Tahoma,  Arial;font-size: 7pt}")
                        Print(f, " th.numero {text-align:right; mso-number-format:\#\,\#\#0\.00}")
                        Print(f, " th.unitario {text-align:right; mso-number-format:\#\,\#\#0\.00#####}")
                        Print(f, " th.titulo {text-align:right;font-family: Tahoma,  Arial;font-size: 9pt")
                        Print(f, " .titulo {font-family: Tahoma,  Arial;font-size: 9pt}")
                        Print(f, " .encabezado {text-align: left; border: none; width: 3.1cm}")
                        Print(f, " .pie {font-family: Tahoma,  Arial;font-size: 7pt}")
                        Print(f, " .izquierda {text-align:left}")
                        Print(f, " .centro {text-align:center}")
                        Print(f, " .derecha {text-align:right}")
                        Print(f, " .info {text-align:left; border:none}")
                        Print(f, "</style>")

                        Print(f, "<td style='font-family: Tahoma;font-size:25pt'><b>DETAIL WAREHOUSE INVENTORY <br> </b></td>")
                        Print(f, "<td style='font-family: Tahoma;font-size:7pt'><b>To " & REA.GetDateTime("Registro").ToString(FORMATO_MYSQL) & "</b></td>")

                        Print(f, "</head>")
                        Print(f, "<body>")

                        Print(f, "<table cellspacing=0>")
                        'Encabezado de columnas: style='width: 1cm'
                        Print(f, "<tr>")
                        Print(f, "<th style='width: 5cm'>DESCRIPTION</th>")
                        Print(f, "<th style='width: 3cm'>HILOS Y ALGODON</th>")
                        Print(f, "<th style='width: 3cm'>AMTEX</th>")
                        Print(f, "<th style='width: 3cm'>PRIDE YARN</th>")
                        Print(f, "<th style='width: 3cm'>DOMINICAN REPUBLIC</th>")
                        Print(f, "<th style='width: 4cm'>TOTAL</th>")

                        Print(f, "</tr>")
                        i = i + 1
                    End If

                    Print(f, "<tr>")
                    Print(f, "<td style='width: 5cm;text-align:left'>" & REA.GetString("nombre") & "</td>")
                    Print(f, "<td style='width: 3cm;text-align:right'>" & If(REA.GetDouble("GT") = 0, "", REA.GetDouble("GT").ToString(FORMATO_MONEDA) & "</td>"))
                    Print(f, "<td style='width: 3cm;text-align:right'>" & If(REA.GetDouble("SV") = 0, "", REA.GetDouble("SV").ToString(FORMATO_MONEDA) & "</td>"))
                    Print(f, "<td style='width: 3cm;text-align:right'>" & If(REA.GetDouble("HN") = 0, "", REA.GetDouble("HN").ToString(FORMATO_MONEDA) & "</td>"))
                    Print(f, "<td style='width: 3cm;text-align:right'>" & If(REA.GetDouble("DR") = 0, "", REA.GetDouble("DR").ToString(FORMATO_MONEDA) & "</td>"))
                    Print(f, "<td style='width: 4cm;text-align:right'>" & If(REA.GetDouble("Total") = 0, "", REA.GetDouble("Total").ToString(FORMATO_MONEDA) & "</td>"))
                    Print(f, "</tr>")

                    dblSumPais(0) = (dblSumPais(0) + REA.GetDouble("GT"))
                    dblSumPais(1) = (dblSumPais(1) + REA.GetDouble("SV"))
                    dblSumPais(2) = (dblSumPais(2) + REA.GetDouble("HN"))
                    dblSumPais(3) = (dblSumPais(3) + REA.GetDouble("DR"))
                    dblSumPais(4) = (dblSumPais(4) + REA.GetDouble("Total"))
                Loop
            End If

            Print(f, "<tr>")
            Print(f, "<th style='width: 5cm;text-align:left'>Grand Total </th>")
            Print(f, "<th style='width: 3cm;text-align:right'>" & dblSumPais(0).ToString(FORMATO_MONEDA) & "</th>")
            Print(f, "<th style='width: 3cm;text-align:right'>" & dblSumPais(1).ToString(FORMATO_MONEDA) & "</th>")
            Print(f, "<th style='width: 3cm;text-align:right'>" & dblSumPais(2).ToString(FORMATO_MONEDA) & "</th>")
            Print(f, "<th style='width: 3cm;text-align:right'>" & dblSumPais(3).ToString(FORMATO_MONEDA) & "</th>")
            Print(f, "<th style='width: 4cm;text-align:right'>" & dblSumPais(4).ToString(FORMATO_MONEDA) & "</th>")
            Print(f, "</tr>")

            Print(f, "</table>")
            Print(f, "<br/>")
            Print(f, "</body>")
            Print(f, "</html>")

            FileClose(f)
            MostarReporte(strTemp)

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub
#End Region

#Region "Inventory by Category"
    Private Function sqlCategoria(ByVal tipo As Integer)
        Dim strSQL As String = STR_VACIO

        strSQL = " SELECT s1.*, SUM(s1.GT + s1.SV + s1.HN + s1.DR) Total "
        strSQL &= "    FROM( "
        strSQL &= "        Select e.idEmpresa, p.PIdGrupo, IFNULL(g.nombre_Grupo,'SIN GRUPO') nombre, p.PStatus, SUM(CASE WHEN e.idEmpresa = 1 THEN p.PLibras ELSE 0 END) 'GT', SUM(CASE WHEN e.idEmpresa = 2 THEN p.PLibras ELSE 0 END) 'SV', SUM(CASE WHEN e.idEmpresa = 3 THEN p.PLibras ELSE 0 END) 'HN', SUM(CASE WHEN e.idEmpresa = 4 THEN p.PLibras ELSE 0 END) 'DR', p.Registro, p.PCategoria "
        strSQL &= "            From YarnDivision.Planning p "
        strSQL &= "                Left JOIN YarnDivision.Grupo_Detalle d ON d.idEmpresa = p.PEmpresa AND d.idGrupo = p.PIdGrupo AND d.idTipo = p.PTipoGrupo AND d.Codigo = p.PArt_Codigo "
        strSQL &= "                    Left JOIN YarnDivision.Grupo g ON g.idGrupo = d.idGrupo AND g.idTipo= d.idTipo "
        strSQL &= "                        Left JOIN YarnDivision.Empresa e ON e.idEmpresa= p.PEmpresa "
        If tipo = INT_CERO Then ' hilo
            strSQL &= "        Where p.Correlativo > 0 AND p.PTipoGrupo = 2 AND p.PIdGrupo IN(d.idGrupo,-2) and p.PCategoria != 'FIBER' AND p.PCat_Pais !=3 "
        Else 'Fibra
            strSQL &= "        Where p.Correlativo > 0 AND p.PTipoGrupo = 2 AND p.PIdGrupo IN(d.idGrupo,-2) and  p.PCategoria = 'FIBER' AND p.PCat_Pais !=3 "
        End If
        strSQL &= "                                GROUP BY p.PCategoria, p.PStatus)s1 "
        strSQL &= "                                    GROUP BY s1.PCategoria, s1.PStatus "

        Return strSQL
    End Function

    Public Sub InventarioPorCategoria(ByVal tipo As Integer)
        Dim strSQL As String = STR_VACIO
        Dim f As Byte
        Dim strTemp As String = STR_VACIO
        Dim dblSumPais(4) As Double
        Dim i As Integer = 0

        'conexiones 
        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader
        Try
            strSQL = sqlCategoria(tipo)
            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSQL, CON)
            REA = COM.ExecuteReader
            If REA.HasRows Then
                Do While REA.Read

                    If i = 0 Then
                        strTemp = cFunciones.ArchivoTemporal
                        f = FreeFile()
                        FileOpen(f, strTemp, OpenMode.Append)

                        Print(f, " <html > ")
                        Print(f, " <head > ")


                        Print(f, " <style type='text/css'>")
                        Print(f, " table {table-layout: fixed; empty-cells: show; border-collapse:collapse}")
                        Print(f, " caption {padding: 5px; text-align:left; font-family: Tahoma,  Arial;font-size: 8pt}")
                        Print(f, " td {text-align:center;border:solid Gray 1px; padding:3px 5px; font-family: Tahoma, Arial;font-size: 7pt}")
                        Print(f, " th {width: 1.8cm; border:solid Gray 1px; background-color: Black; color: White; padding:2px 5px; font-family: Tahoma,  Arial;font-size: 6pt}")
                        Print(f, " th {text-align:center;border:solid Gray 1px; padding:3px 5px; font-family: Tahoma,  Arial;font-size: 7pt}")
                        Print(f, " th.numero {text-align:right; mso-number-format:\#\,\#\#0\.00}")
                        Print(f, " th.unitario {text-align:right; mso-number-format:\#\,\#\#0\.00#####}")
                        Print(f, " th.titulo {text-align:right;font-family: Tahoma,  Arial;font-size: 9pt")
                        Print(f, " .titulo {font-family: Tahoma,  Arial;font-size: 9pt}")
                        Print(f, " .encabezado {text-align: left; border: none; width: 3.1cm}")
                        Print(f, " .pie {font-family: Tahoma,  Arial;font-size: 7pt}")
                        Print(f, " .izquierda {text-align:left}")
                        Print(f, " .centro {text-align:center}")
                        Print(f, " .derecha {text-align:right}")
                        Print(f, " .info {text-align:left; border:none}")
                        Print(f, "</style>")

                        Print(f, "<td style='font-family: Tahoma;font-size:25pt'><b>INVENTORY BY CATEGORY<br> </b></td>")
                        Print(f, "<td style='font-family: Tahoma;font-size:7pt'><b>To " & REA.GetDateTime("Registro").ToString(FORMATO_MYSQL) & "</b></td>")

                        Print(f, "</head>")
                        Print(f, "<body>")

                        Print(f, "<table cellspacing=0>")
                        'Encabezado de columnas: style='width: 1cm'
                        Print(f, "<tr>")
                        Print(f, "<th style='width: 4cm'>STATUS</th>")
                        Print(f, "<th style='width: 5cm'>CATEGORY</th>")
                        Print(f, "<th style='width: 3cm'>GUATEMALA</th>")
                        Print(f, "<th style='width: 3cm'>EL SALVADOR</th>")
                        Print(f, "<th style='width: 3cm'>HONDURAS</th>")
                        Print(f, "<th style='width: 3cm'>REPUBLICA DOMINICANA</th>")
                        Print(f, "<th style='width: 4cm'>GRAND TOTAL</th>")

                        Print(f, "</tr>")
                        i = i + 1
                    End If

                    Print(f, "<tr>")
                    Print(f, "<td style='width: 5cm;text-align:left'>" & REA.GetString("PStatus") & "</td>")
                    Print(f, "<td style='width: 5cm;text-align:left'>" & REA.GetString("PCategoria") & "</td>")
                    Print(f, "<td style='width: 3cm;text-align:right'>" & REA.GetDouble("GT").ToString(FORMATO_MONEDA) & "</td>")
                    Print(f, "<td style='width: 3cm;text-align:right'>" & REA.GetDouble("SV").ToString(FORMATO_MONEDA) & "</td>")
                    Print(f, "<td style='width: 3cm;text-align:right'>" & REA.GetDouble("HN").ToString(FORMATO_MONEDA) & "</td>")
                    Print(f, "<td style='width: 3cm;text-align:right'>" & REA.GetDouble("DR").ToString(FORMATO_MONEDA) & "</td>")
                    Print(f, "<td style='width: 4cm;text-align:right'>" & REA.GetDouble("Total").ToString(FORMATO_MONEDA) & "</td>")
                    Print(f, "</tr>")

                    dblSumPais(0) = (dblSumPais(0) + REA.GetDouble("GT"))
                    dblSumPais(1) = (dblSumPais(1) + REA.GetDouble("SV"))
                    dblSumPais(2) = (dblSumPais(2) + REA.GetDouble("HN"))
                    dblSumPais(3) = (dblSumPais(3) + REA.GetDouble("DR"))
                    dblSumPais(4) = (dblSumPais(4) + REA.GetDouble("Total"))
                Loop
            End If

            Print(f, "<tr>")
            Print(f, "<th colspan = 2 style='width: 10cm;text-align:left'>GRAND TOTAL </th>")
            'Print(f, "<th style='width: 5cm;text-align:left'>Grand Total </th>")
            Print(f, "<th style='width: 3cm;text-align:right'>" & dblSumPais(0).ToString(FORMATO_MONEDA) & "</th>")
            Print(f, "<th style='width: 3cm;text-align:right'>" & dblSumPais(1).ToString(FORMATO_MONEDA) & "</th>")
            Print(f, "<th style='width: 3cm;text-align:right'>" & dblSumPais(2).ToString(FORMATO_MONEDA) & "</th>")
            Print(f, "<th style='width: 3cm;text-align:right'>" & dblSumPais(3).ToString(FORMATO_MONEDA) & "</th>")
            Print(f, "<th style='width: 4cm;text-align:right'>" & dblSumPais(4).ToString(FORMATO_MONEDA) & "</th>")
            Print(f, "</tr>")

            Print(f, "</table>")
            Print(f, "<br/>")
            Print(f, "</body>")
            Print(f, "</html>")

            FileClose(f)
            MostarReporte(strTemp)

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub
#End Region

#Region "Projection"
    Private Function SqlProjection(ByVal Finicio As Date, ByVal Ffin As Date) As String

        Dim strSQL As String = STR_VACIO
        Dim intSemanas As Integer = INT_CERO
        Dim FechaAnterior As Date
        Try
            strSQL = " SELECT o.idEmpresa, e.nombre_empresa empresa,  o.clase clase ,"
            strSQL &= " SUM(IF(o.Vencimiento <= '{fecha1}',o.balance_abierto, 0))semana1  "

            FechaAnterior = Finicio.AddDays(DIAS_SEMANA)

            strSQL = Replace(strSQL, "{fecha1}", FechaAnterior.ToString(FORMATO_MYSQL))

            intSemanas = (CInt(DateDiff(DateInterval.Day, Finicio, Ffin)) / 7)
            For i As Integer = 2 To intSemanas
                strSQL &= " , SUM(IF(o.Vencimiento BETWEEN '{inicio}' AND '{fin}', o.balance_abierto, 0)) semana" & i
                strSQL = Replace(strSQL, "{inicio}", FechaAnterior.AddDays(INT_UNO).ToString(FORMATO_MYSQL))
                FechaAnterior = FechaAnterior.AddDays(DIAS_SEMANA)
                strSQL = Replace(strSQL, "{fin}", FechaAnterior.ToString(FORMATO_MYSQL))
            Next

            strSQL &= "  FROM YarnDivision.Open_Invoice o "
            strSQL &= "    LEFT JOIN YarnDivision.Empresa e ON e.idEmpresa = o.idEmpresa "
            ' strSQL &= "  WHERE o.Vencimiento BETWEEN '{inicio}' AND '{fin}' "
            strSQL &= "  GROUP BY o.idEmpresa, o.clase "
            strSQL &= "  ORDER BY o.idEmpresa"

            strSQL = Replace(strSQL, "{inicio}", Finicio.ToString(FORMATO_MYSQL))
            strSQL = Replace(strSQL, "{fin}", Ffin.ToString(FORMATO_MYSQL))


        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        Return strSQL
    End Function

    Private Function HtmlColumnas(ByVal Finicio As Date, ByVal Ffin As Date) As String
        Dim strColumbasHtml As String = STR_VACIO
        Dim fecha As Date
        Dim intSemanas As Integer = INT_CERO
        Try

            ''columna 1
            strColumbasHtml = "<tr>"
            intSemanas = CInt(DateDiff(DateInterval.Day, Finicio, Ffin)) / 7

            fecha = Finicio.AddDays(1)
            strColumbasHtml &= " <th style='width: 3cm'> COMPANY</th> "
            strColumbasHtml &= " <th style='width: 3cm'> CLASS</th> "
            strColumbasHtml &= " <th style='width: 3cm'> PROJECTION WEEK " & Finicio & " to " & Finicio.AddDays(DIAS_SEMANA) & " </th> "
            For i As Integer = 2 To intSemanas
                strColumbasHtml &= " <th style='width: 3cm'> PROJECTION WEEK " & fecha.AddDays((DIAS_SEMANA) * (i - 1)) & " to " & Finicio.AddDays((DIAS_SEMANA) * (i)) & " </th> "

            Next
            strColumbasHtml &= "</tr>"
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        Return strColumbasHtml
    End Function

    Public Sub Projection()
        Dim strSQL As String = STR_VACIO
        Dim Filtro As New frmFiltro
        Dim f As Byte
        Dim strTemp As String = STR_VACIO
        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader
        Dim intSemanas As Integer = INT_CERO
        Dim logPrimeraLinea As Boolean = True
        Dim intEmpresa As Integer = NO_FILA

        Try
            Filtro.Titulo = "Projection Report"
            Filtro.BanderaFechas = True
            Filtro.ShowDialog(frmSPrincipal)
            If Filtro.DialogResult = DialogResult.OK Then
                strTemp = cFunciones.ArchivoTemporal
                f = FreeFile()
                FileOpen(f, strTemp, OpenMode.Append)

                Print(f, " <html > ")
                Print(f, " <head > ")


                Print(f, " <style type='text/css'>")
                Print(f, " table {table-layout: fixed; empty-cells: show; border-collapse:collapse}")
                Print(f, " caption {padding: 5px; text-align:left; font-family: Tahoma,  Arial;font-size: 8pt}")
                Print(f, " td {text-align:center;border:solid Gray 1px; padding:3px 5px; font-family: Tahoma, Arial;font-size: 7pt}")
                Print(f, " th {width: 1.8cm; border:solid Gray 1px; background-color: Black; color: White; padding:2px 5px; font-family: Tahoma,  Arial;font-size: 6pt}")
                Print(f, " th {text-align:center;border:solid Gray 1px; padding:3px 5px; font-family: Tahoma,  Arial;font-size: 7pt}")
                Print(f, " th.numero {text-align:right; mso-number-format:\#\,\#\#0\.00}")
                Print(f, " th.unitario {text-align:right; mso-number-format:\#\,\#\#0\.00#####}")
                Print(f, " th.titulo {text-align:right;font-family: Tahoma,  Arial;font-size: 9pt")
                Print(f, " .titulo {font-family: Tahoma,  Arial;font-size: 9pt}")
                Print(f, " .encabezado {text-align: left; border: none; width: 3.1cm}")
                Print(f, " .pie {font-family: Tahoma,  Arial;font-size: 7pt}")
                Print(f, " .izquierda {text-align:left}")
                Print(f, " .centro {text-align:center}")
                Print(f, " .derecha {text-align:right}")
                Print(f, " .info {text-align:left; border:none}")
                Print(f, "</style>")

                Print(f, "</head>")
                Print(f, "<body>")
                Print(f, "<table cellspacing=0>")
                Print(f, "<td style='font-family: Tahoma;font-size:25pt'><b>PROJECTION<br> </b></td>")
                Print(f, "<td style='font-family: Tahoma;font-size:7pt'><b>To " & Filtro.FechaFin & "</b></td>")
                Print(f, "</table>")
                Print(f, "<br><br>")
                Print(f, "<table cellspacing=0>")

                strSQL = SqlProjection(Filtro.FechaInicio, Filtro.FechaFin)

                Print(f, HtmlColumnas(Filtro.FechaInicio, Filtro.FechaFin))

                MyCnn.CONECTAR = strConexion
                COM = New MySqlCommand(strSQL, CON)
                REA = COM.ExecuteReader
                If REA.HasRows Then
                    intSemanas = CInt(DateDiff(DateInterval.Day, Filtro.FechaInicio, Filtro.FechaFin)) / 7

                    Do While REA.Read
                        Print(f, "<tr>")
                        Print(f, "<td> " & REA.GetString("empresa") & "</td>")
                        Print(f, "<td> " & REA.GetString("clase") & "</td>")
                        Print(f, "<td> " & REA.GetDouble("semana1").ToString(FORMATO_MONEDA) & "</td>")
                        Try
                            For i As Integer = 2 To intSemanas
                                Print(f, "<td> " & REA.GetDouble("semana" & i).ToString(FORMATO_MONEDA) & "</td>")
                            Next
                        Catch ex As Exception

                        End Try
                        Print(f, "</tr>")
                    Loop
                End If

                Print(f, "</table>")

                Print(f, "</body>")
                Print(f, "</html>")

                FileClose(f)
                MostarReporte(strTemp)
            End If

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub
#End Region

#Region "Check Report"
    Private Function sqlCheckReport() As String
        Dim strSQL As String = STR_VACIO
        Try
            strSQL = " select IFNULL(c.Cliente,'') Cliente , c.Monto , e.idEmpresa , e.nombre_empresa  "
            strSQL &= " from YarnDivision.CheckReport c "
            strSQL &= "     left join YarnDivision.Empresa e on e.idEmpresa = c.idEmpresa "
            strSQL &= " where c.Correlativo >0 "

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        Return strSQL
    End Function

    Private Function EncabezadoCheck(ByVal Finicio As Date, ByVal Ffin As Date) As String
        Dim strEncabezado As String = STR_VACIO
        Try
            strEncabezado &= "<html>"
            strEncabezado &= "<head>"
            strEncabezado &= "<title>" & "VSxP" & "</title>"
            strEncabezado &= "<style type='text/css'>"
            strEncabezado &= " table {table-layout: fixed; empty-cells: show; border-collapse:collapse}"
            strEncabezado &= " caption {padding: 5px; text-align:left; font-family: Tahoma, Arial;font-size: 8pt}"
            strEncabezado &= " th {width: 1.8cm; border:solid Silver 1px; background-color: #000080; color: White; padding:2px 5px; font-family: Tahoma, Arial;font-size: 7pt}"
            strEncabezado &= " td {text-align:center;border:solid Silver 1px; padding:3px 5px; font-family: Tahoma, Arial;font-size: 7pt}"
            strEncabezado &= " .titulo {font-family: Tahoma, Arial;font-size: 9pt}"
            strEncabezado &= " .encabezado {text-align: left; border: none; width: 3.1cm}"
            strEncabezado &= " .pie {font-family: Tahoma, Arial;font-size: 7pt}"
            strEncabezado &= " .izquierda {text-align:left}"
            strEncabezado &= " .centro {text-align:center}"
            strEncabezado &= " .derecha {text-align:right}"
            strEncabezado &= " .info {text-align:left; border:none}"
            strEncabezado &= " td.numero {text-align:right; mso-number-format:\#\,\#\#0\.00}"
            strEncabezado &= "</style>"
            strEncabezado &= "</head>"
            strEncabezado &= "<body>"

            ' strEncabezado &= "<span class='titulo'><b>" & Sesion.Empresa & "</b></span><br/><br/>"
            strEncabezado &= "<span class='titulo'><b>" & UCase("CHECK REPORT CORP ") & "</b></span><br/>"
            strEncabezado &= "<span class='pie'>FROM" & Finicio.ToString(FORMATO_MYSQL) & " TO " & Ffin.ToString(FORMATO_MYSQL) & "</span>"
            strEncabezado &= "<br/><br/>"

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        Return strEncabezado
    End Function

    Private Function ColumnasCheck() As String
        Dim strColumnas As String = STR_VACIO
        Try
            strColumnas = "<table cellspacing=0> "
            strColumnas &= " <tr> "
            strColumnas &= "<th style= 'width:3cm' > Company </th>"
            strColumnas &= "<th style= 'width:8cm' > CUSTOMER</th>"
            strColumnas &= "<th> TOTAL US$ </th>"
            strColumnas &= " </tr> "
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        Return strColumnas
    End Function

    Private Function SubTotalCheck(ByVal sCategoria As String, ByVal dblMonto As Double) As String
        Dim strTotalRegion As String = STR_VACIO
        Try
            strTotalRegion &= "<br>"
            strTotalRegion &= "<table >"
            strTotalRegion &= "<tr>"
            strTotalRegion &= " <th style= 'background:gray; width:3cm'> - </th>"
            strTotalRegion &= " <th style= 'width:8cm;background:gray '>  TOTAL COLLECTED  - " & sCategoria & " - </th>"
            strTotalRegion &= " <th style= 'background:gray'> " & dblMonto.ToString(FORMATO_MONEDA) & " </th>"
            strTotalRegion &= "</tr>"
            strTotalRegion &= "</table>"
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        Return strTotalRegion
    End Function

    Private Function TotalGeneralC(ByVal dblMonto As Double) As String
        Dim strTotalRegion As String = STR_VACIO
        Try
            strTotalRegion &= "<br>"
            strTotalRegion &= "<table >"
            strTotalRegion &= "<tr>"
            strTotalRegion &= " <th style= 'background:gray; width:3cm'> - </th>"
            strTotalRegion &= " <th style= 'width:8cm;background:gray '> -- TOTAL COLLECTED  -- </th>"
            strTotalRegion &= " <th style= 'background:gray'> " & dblMonto.ToString(FORMATO_MONEDA) & " </th>"
            strTotalRegion &= "</tr>"
            strTotalRegion &= "</table>"
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        Return strTotalRegion
    End Function

    Public Sub CheckReport(ByVal Finicio As Date, ByVal Ffin As Date)
        Dim strSQL As String = STR_VACIO
        Dim f As Byte
        Dim strTemp As String = STR_VACIO
        Dim logPrimeraLInea As Boolean = True
        Dim dblSubtotal As Double = INT_CERO
        Dim dblTotal As Double = INT_CERO
        Dim strHTML As String = STR_VACIO
        Dim strEmpresa As String = STR_VACIO

        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader
        Try
            strTemp = cFunciones.ArchivoTemporal
            f = FreeFile()
            FileOpen(f, strTemp, OpenMode.Append)

            strSQL = sqlCheckReport()
            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSQL, CON)
            REA = COM.ExecuteReader
            strHTML &= EncabezadoCheck(Finicio, Ffin)
            strHTML &= ColumnasCheck()
            If REA.HasRows Then
                Do While REA.Read
                    If logPrimeraLInea = True Then
                        logPrimeraLInea = False
                        strEmpresa = REA.GetString("nombre_empresa")

                    Else
                        If strEmpresa = REA.GetString("nombre_empresa") Then

                        Else

                            strHTML &= SubTotalCheck(strEmpresa, dblSubtotal)
                            strHTML &= ColumnasCheck()
                            strEmpresa = REA.GetString("nombre_empresa")
                            dblSubtotal = INT_CERO
                        End If
                    End If
                    '' linea
                    strHTML &= " <tr> "
                    strHTML &= "<td>" & REA.GetString("nombre_empresa") & "</td>"
                    strHTML &= "<td>" & REA.GetString("Cliente") & "</td>"
                    strHTML &= "<td>" & REA.GetDouble("Monto").ToString(FORMATO_MONEDA) & "</td>"
                    strHTML &= " </tr> "

                    dblSubtotal = dblSubtotal + REA.GetDouble("Monto")
                    dblTotal = dblTotal + REA.GetDouble("Monto")
                Loop

            End If
            strHTML &= SubTotalCheck(strEmpresa, dblSubtotal)
            strHTML &= TotalGeneralC(dblTotal)
            Print(f, strHTML)
            Print(f, "</table>")
            Print(f, "<br/>")
            Print(f, "</body>")
            Print(f, "</html>")
            FileClose(f)
            MostarReporte(strTemp)
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub


#End Region

#Region "Ventas"

    'Private Function sqlResumen()

    '    Dim strSQL As String = STR_VACIO

    '    Try

    '        strSQL = "select e.nombre_empresa,round(sum(c.total),2) Quetzales "
    '        strSQL &= "from YarnDivision.ventas c "
    '        strSQL &= "left join YarnDivision.Empresa e on e.idEmpresa = c.empresa  where c.Correlativo >0  "
    '        strSQL &= " GROUP BY e.nombre_empresa "

    '    Catch ex As Exception
    '        MsgBox(ex.ToString)
    '    End Try


    'End Function

    Private Function sqlVentas(ByVal intVal As Int16) As String
        Dim strSQL As String = STR_VACIO
        Dim frm As New frmOption
        Try
            strSQL = " select "
            If intVal <> 1 Then
                strSQL &= " ifnull(gg.nombre_Grupo, '_NO GROUP') grup ,IFNULL(gg.idGrupo,-1) igrup,c.*,e.nombre_empresa  "
            Else
                strSQL &= "  e.nombre_empresa,round(sum(c.total),2) quetzaL "
            End If
            strSQL &= " FROM YarnDivision.ventas c
                            LEFT JOIN YarnDivision.Empresa e ON e.idEmpresa = c.empresa
                            LEFT JOIN YarnDivision.Grupo_Detalle g ON g.idEmpresa = e.idEmpresa AND g.Codigo = c.idcliente AND g.idTipo = 1
                            LEFT JOIN YarnDivision.Grupo gg ON gg.idGrupo = g.idGrupo AND gg.idTipo = g.idTipo"

            frm.Titulo = "What do you need?"
            frm.Text = " Choose an option "
            frm.Opciones = " Exclude Sisters Company| Only Sisters Company | All "
            frm.ShowDialog(frmSPrincipal)
            If frm.DialogResult = DialogResult.OK Then
                Select Case frm.Seleccion
                    Case 0
                        strSQL &= " WHERE gg.nombre_Grupo not LIKE 'INTERCOMPANY%' "
                    Case 1
                        strSQL &= " WHERE gg.nombre_Grupo  LIKE 'INTERCOMPANY%' "
                End Select
            End If
            If intVal = 1 Then
                strSQL &= " GROUP BY e.nombre_empresa "
            Else
                strSQL &= " ORDER BY grup, gg.idGrupo"
            End If

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        Return strSQL
    End Function

    Public Sub ResumenByAcount(ByVal FInicio As Date, ByVal FFin As Date)


        Dim strResumen As String = STR_VACIO
        Dim AñoFinal As Integer
        Dim AñoInicial As Integer
        Dim DiaInicial As Integer
        Dim DiaFinal As Integer
        Dim MesFinal As Integer
        Dim MesInicial As Integer
        Dim fechaInicial As Date
        Dim fechaFinal As Date
        Dim mesInglesFinal As String
        Dim mesInglesInicial As String
        Try

            Dim COM1 As MySqlCommand
            Dim REA1 As MySqlDataReader

            'FECHA FINAL
            fechaFinal = FInicio
            DiaFinal = fechaFinal.Day
            MesFinal = fechaFinal.Month
            AñoFinal = fechaFinal.Year
            'FECHA INICIAL
            fechaInicial = FInicio
            DiaInicial = FInicio.Day
            MesInicial = fechaInicial.Month
            AñoInicial = fechaInicial.Year

            strResumen = sqlVentas(1)

            MyCnn.CONECTAR = strConexion
            COM1 = New MySqlCommand(strResumen, CON)
            REA1 = COM1.ExecuteReader

            If REA1.HasRows Then
                Dim f As Byte
                Dim strTemp As String = STR_VACIO
                f = FreeFile()
                strTemp = cFunciones.ArchivoTemporal
                FileOpen(f, strTemp, OpenMode.Append)
                Print(f, "<html>")

                Print(f, "<table cellspacing = 0>")
                Print(f, "<tr>")
                Print(f, "<td rowspan=2; style='width: 4cm;  border:none'><div><IMG border=0 hspace=1 vspace=1 src='file:" & System.Windows.Forms.Application.StartupPath & "\" & Sesion.IdEmpresa & ".jpg'" & " width='40px' height='40px'></div> </td> ")

                If MesInicial = MesFinal And AñoInicial = AñoFinal And DiaInicial <> DiaFinal Then
                    mesInglesFinal = cFunciones.MesIngles(MesFinal)

                    Print(f, "<td style='width: 12cm;  font-size: 10pt; border-right:none; border-left:none; border-top:none; border-bottom:none; text-align: center'><b><i>" & Sesion.Empresa & "<br>" & "Sales by Vendor Detail <br>" & " YARN DIVISION" & "&nbsp;" & DiaInicial & "-" & "&nbsp;" & DiaFinal & "," & AñoFinal & "</i></b></td>")
                    Print(f, "</tr>")
                ElseIf MesInicial <> MesFinal And AñoInicial = AñoFinal Then
                    mesInglesFinal = cFunciones.MesIngles(MesFinal)
                    mesInglesInicial = cFunciones.MesIngles(MesInicial)

                    Print(f, "<td style='width: 12cm; font-size: 10pt; border-right:none; border-left:none; border-top:none; border-bottom:none; text-align: center'><b><i>" & Sesion.Empresa & "<br>" & "Sales by Vendor Detail <br>" & mesInglesInicial & "&nbsp;" & DiaInicial & "-" & "&nbsp;" & mesInglesFinal & "&nbsp;" & DiaFinal & "," & AñoFinal & "</i></b></td>")
                    Print(f, "</tr>")
                ElseIf MesInicial <> MesFinal And AñoInicial <> AñoFinal Then
                    mesInglesFinal = cFunciones.MesIngles(MesFinal)
                    mesInglesInicial = cFunciones.MesIngles(MesInicial)

                    Print(f, "<td style='width: 12cm; font-size: 10pt; border-right:none; border-left:none; border-top:none; border-bottom:none; text-align: center'><b><i>" & Sesion.Empresa & "<br>" & "Sales by Vendor Detail <br>" & mesInglesInicial & "&nbsp;" & DiaInicial & "," & AñoInicial & "-" & "&nbsp;" & mesInglesFinal & "&nbsp;" & DiaFinal & "," & AñoFinal & "</i></b></td>")
                    Print(f, "</tr>")
                ElseIf DiaInicial = DiaFinal And MesInicial = MesFinal And AñoInicial = AñoFinal Then
                    mesInglesFinal = cFunciones.MesIngles(MesFinal)

                    Print(f, "<td style='width: 12cm;  font-size: 10pt; border-right:none; border-left:none; border-top:none; border-bottom:none; text-align: center'><b><i>" & Sesion.Empresa & "<br>" & "Sales by Company Summary <br>" & mesInglesFinal & "&nbsp;" & DiaFinal & "," & AñoFinal & "</i></b></td>")
                    Print(f, "</tr>")
                End If

                Print(f, "<tr>")
                Print(f, "<td style='width: 30cm; hight: 1cm; font-size: 10pt; border-right:none; border-left:none; border-top:none; border-bottom:none; text-align: center'><b><i><br></i></b></td>")
                Print(f, "</tr>")
                Print(f, "</table>")

                Print(f, "<style type='text/css'>")
                Print(f, " th {width: 3.8cm; VALIGN=MIDDLE;border:solid Gray 0px; background-color: #BDBDBD; color: Black; padding:2px 5px; font-family: Tahoma, Arial;font-size: 7pt}")
                Print(f, " td {text-align:center;border:solid Gray 1px; padding:3px 5px; font-family: Tahoma, Arial;font-size: 7pt}")
                Print(f, "</style>")

                Print(f, "<table cellspacing = 0>")
                Print(f, "<thead><tr>")
                Print(f, "<td style='width: 2cm; border-right: none; border-top: 1px solid black; border-left: 1px solid black; border-bottom: 1px solid black; font-size: 10pt; background-color: #D7DBDD '>Company</td>")
                Print(f, "<td style='width: 1.4cm; border-right: none; border-top: 1px solid black; border-left: 1px solid black; border-bottom: 1px solid black; font-size: 10pt; background-color: #D7DBDD '>Amount</td>")
                Print(f, "</tr></thead>")
                Print(f, "<tbody>")
                Do While REA1.Read
                    Print(f, "<tr>")
                    Print(f, "<td style='border: 1px solid black'>" & REA1.GetString("nombre_empresa") & "</td><td style='border: 1px solid black'> " & REA1.GetDouble("quetzaL").ToString(FORMATO_MONEDA) & "</td>")
                    Print(f, "</tr>")
                Loop
                Print(f, "</tbody>")
                Print(f, "</table>")
                Print(f, "</html>")

                FileClose(f)
                MostarReporte(strTemp)


            End If


        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try




    End Sub

    Public Sub SalesByAccount(ByVal FInicio As Date, ByVal FFin As Date)
        Dim f As Byte
        Dim strTemp As String = STR_VACIO
        Dim strSQL As String
        Dim dblSubtotal1 As Double
        Dim dblSubtotal2 As Double
        Dim dblTotal2 As Double
        Dim dblTotal1 As Double
        Dim logPrimeraLinea As Integer = 0
        Dim intNumero As Integer
        Dim AñoFinal As Integer
        Dim AñoInicial As Integer
        Dim DiaInicial As Integer
        Dim DiaFinal As Integer
        Dim MesFinal As Integer
        Dim MesInicial As Integer
        Dim fechaInicial As Date
        Dim fechaFinal As Date
        Dim frm As New frmOption

        Dim vEmpresa As String = STR_VACIO
        'Dim frm As New frmFiltro
        Dim valor As Integer = INT_CERO
        Dim mesInglesFinal As String
        Dim mesInglesInicial As String
        Dim intPais As Integer = -1

        ' Conexiones 
        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader
        Try
            strSQL = "select emp_pais from Empresas e where e.emp_no =  " & Sesion.IdEmpresa
            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSQL, CON)
            intPais = COM.ExecuteScalar

            ' frm.FechaFin = Today
            ' frm.FechaInicio = Today.AddMonths(NO_FILA)
            ' frm.BanderaFechas = True
            ' frm.ShowDialog(frmSPrincipal)

            'frm.Titulo = "Opcion de Reporte"
            'frm.Mensaje = "Tipo de Reporte"
            'frm.Opciones = "General | Detalle"

            'If frm.DialogResult = DialogResult.OK Then

            'FECHA FINAL
            fechaFinal = FFin
            DiaFinal = fechaFinal.Day
            MesFinal = fechaFinal.Month
            AñoFinal = fechaFinal.Year
            'FECHA INICIAL
            fechaInicial = FInicio
            DiaInicial = FInicio.Day
            MesInicial = fechaInicial.Month
            AñoInicial = fechaInicial.Year


            f = FreeFile()
            strTemp = cFunciones.ArchivoTemporal
            FileOpen(f, strTemp, OpenMode.Append)
            Print(f, "<html>")

            Print(f, "<table cellspacing = 0>")
            Print(f, "<tr>")
            Print(f, "<td rowspan=2; style='width: 4cm;  border:none'><div><IMG border=0 hspace=1 vspace=1 src='file:" & System.Windows.Forms.Application.StartupPath & "\" & "YARN DIVISION" & ".jpg'" & " width='40px' height='40px'></div> </td> ")

            If MesInicial = MesFinal And AñoInicial = AñoFinal And DiaInicial <> DiaFinal Then
                mesInglesFinal = cFunciones.MesIngles(MesFinal)

                Print(f, "<td style='width: 12cm;  font-size: 10pt; border-right:none; border-left:none; border-top:none; border-bottom:none; text-align: center'><b><i>" & Sesion.Empresa & "<br>" & "Sales by Vendor Detail <br>" & mesInglesFinal & "&nbsp;" & DiaInicial & "-" & "&nbsp;" & DiaFinal & "," & AñoFinal & "</i></b></td>")
                Print(f, "</tr>")
            ElseIf MesInicial <> MesFinal And AñoInicial = AñoFinal Then
                mesInglesFinal = cFunciones.MesIngles(MesFinal)
                mesInglesInicial = cFunciones.MesIngles(MesInicial)

                Print(f, "<td style='width: 12cm; font-size: 10pt; border-right:none; border-left:none; border-top:none; border-bottom:none; text-align: center'><b><i>" & Sesion.Empresa & "<br>" & "Sales by Vendor Detail <br>" & mesInglesInicial & "&nbsp;" & DiaInicial & "-" & "&nbsp;" & mesInglesFinal & "&nbsp;" & DiaFinal & "," & AñoFinal & "</i></b></td>")
                Print(f, "</tr>")
            ElseIf MesInicial <> MesFinal And AñoInicial <> AñoFinal Then
                mesInglesFinal = cFunciones.MesIngles(MesFinal)
                mesInglesInicial = cFunciones.MesIngles(MesInicial)

                Print(f, "<td style='width: 12cm; font-size: 10pt; border-right:none; border-left:none; border-top:none; border-bottom:none; text-align: center'><b><i>" & Sesion.Empresa & "<br>" & "Sales by Vendor Detail <br>" & mesInglesInicial & "&nbsp;" & DiaInicial & "," & AñoInicial & "-" & "&nbsp;" & mesInglesFinal & "&nbsp;" & DiaFinal & "," & AñoFinal & "</i></b></td>")
                Print(f, "</tr>")
            ElseIf DiaInicial = DiaFinal And MesInicial = MesFinal And AñoInicial = AñoFinal Then
                mesInglesFinal = cFunciones.MesIngles(MesFinal)

                Print(f, "<td style='width: 12cm;  font-size: 10pt; border-right:none; border-left:none; border-top:none; border-bottom:none; text-align: center'><b><i>" & Sesion.Empresa & "<br>" & "Sales by Vendor Detail <br>" & mesInglesFinal & "&nbsp;" & DiaFinal & "," & AñoFinal & "</i></b></td>")
                Print(f, "</tr>")
            End If

            Print(f, "<tr>")
            Print(f, "<td style='width: 30cm; hight: 1cm; font-size: 10pt; border-right:none; border-left:none; border-top:none; border-bottom:none; text-align: center'><b><i><br></i></b></td>")
            Print(f, "</tr>")
            Print(f, "</table>")

            Print(f, "<style type='text/css'>")
            Print(f, " th {width: 3.8cm; VALIGN=MIDDLE;border:solid Gray 0px; background-color: #BDBDBD; color: Black; padding:2px 5px; font-family: Tahoma, Arial;font-size: 7pt}")
            Print(f, " td {text-align:center;border:solid Gray 1px; padding:3px 5px; font-family: Tahoma, Arial;font-size: 7pt}")
            Print(f, "</style>")

            Print(f, "<table cellspacing=0>")
            Print(f, "<tr>")
            Print(f, "<td style='width: 2cm; border-right: none; border-top: 1px solid black; border-left: 1px solid black; border-bottom: 1px solid black; font-size: 10pt; background-color: #D7DBDD '><b><i>DATE</i></b></td>")
            Print(f, "<td style='width: 1.4cm; border-right: none; border-top: 1px solid black; border-left: 1px solid black; border-bottom: 1px solid black; font-size: 10pt; background-color: #D7DBDD '><b><i>Num</i></b></td>")
            Print(f, "<td style='width: 4cm; border-right: none; border-top: 1px solid black; border-left: 1px solid black; border-bottom: 1px solid black; font-size: 10pt; background-color: #D7DBDD '><b><i>Name</i></b></td>")
            Print(f, "<td style='width: 2.4cm; border-right: none; border-top: 1px solid black; border-left: 1px solid black; border-bottom: 1px solid black; font-size: 10pt;background-color: #D7DBDD '><b><i>Item</i></b></td>")
            Print(f, "<td style='width: 2.4cm; border-right: none; border-top: 1px solid black; border-left: 1px solid black; border-bottom: 1px solid black; font-size: 10pt; background-color: #D7DBDD '><b><i>Qty</i></b></td>")
            Print(f, "<td style='width: 1.4cm; border-right: none; border-top: 1px solid black; border-left: 1px solid black; border-bottom: 1px solid black; font-size: 10pt; background-color: #D7DBDD '><b><i>SalesPrice</i></b></td>")
            Print(f, "<td style='width: 2.4cm; border-right: 1px solid black; border-top: 1px solid black; border-left: 1px solid black; border-bottom: 1px solid black; font-size: 10pt; background-color: #D7DBDD '><b><i>Amount</i></b></td>")
            Print(f, "<td style='width: 2.4cm; border-right: 1px solid black; border-top: 1px solid black; border-left: 1px solid black; border-bottom: 1px solid black; font-size: 10pt; background-color: #D7DBDD '><b><i>Company</i></b></td>")
            Print(f, "</tr>")

            strSQL = sqlVentas(2)
            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSQL, CON)
            REA = COM.ExecuteReader
            If REA.HasRows Then
                Do While REA.Read

                    If intNumero = REA.GetInt32("igrup") Then
                        Print(f, "<tr>")
                        Print(f, "<td style='border-top: none; border-bottom: none; border-right: 1px solid black; border-left: 1px solid black;text-align: center'> " & REA.GetDateTime("fecha").ToString(FORMATO_MYSQL) & "</td>")
                        Select Case Sesion.IdEmpresa
                            Case 12, 11, 16

                                If intPais = 310 Then
                                    Print(f, "<td style='border-top: none;  border-bottom: none; border-right: none; border-left: none;text-align: left; text-align: center'> " & REA.GetInt32("num2") & "</td>")
                                Else
                                    Print(f, "<td style='border-top: none;  border-bottom: none; border-right: none; border-left: none;text-align: left; text-align: center'> " & REA.GetInt32("numero") & "</td>")
                                End If
                            Case 14
                                Print(f, "<td style='border-top: none;  border-bottom: none; border-right: none; border-left: none;text-align: left; text-align: center'> " & REA.GetInt32("num2") & "</td>")
                        End Select

                        Print(f, "<td style='border-top: none;  border-bottom: none;text-align: left; border-right: none; border-left: 1px solid black;text-align: left'> " & REA.GetString("nombre") & " </td>")
                        Print(f, "<td style='border-top: none;  border-bottom: none;text-align: left; border-right: none; border-left: 1px solid black;text-align: left'> " & REA.GetString("Referencia") & " </td>")
                        Print(f, "<td style='border-top: none;  border-bottom: none;text-align: right; border-right: none; border-left: 1px solid black;text-align: right'> " & REA.GetDouble("cantidad").ToString(FORMATO_MONEDA) & " </td>")
                        Print(f, "<td style='border-top: none;  border-bottom: none;text-align: right; border-right: none; border-left: 1px solid black;text-align: right'> " & REA.GetDouble("precio").ToString(FORMATO_MONEDA) & "  </td>")
                        Print(f, "<td style='border-top: none;  border-bottom: none;text-align: right; border-right: 1px solid black; border-left: 1px solid black;text-align: right'> " & REA.GetDouble("total").ToString(FORMATO_MONEDA) & " </td>")
                        Print(f, "<td style='border-top: 1px solid black;  text-align: center'> " & REA.GetString("nombre_empresa") & " </td>")
                        Print(f, "</tr>")
                        dblSubtotal1 = dblSubtotal1 + REA.GetDouble("cantidad")
                        dblSubtotal2 = dblSubtotal2 + REA.GetDouble("total")
                        intNumero = REA.GetInt32("igrup")
                    Else
                        If logPrimeraLinea = 0 Then
                            Print(f, "<tr>")
                            Print(f, "<td colspan='7' style='border: 1px solid black; text-align: left; background-color: #A3E4D7;'><i><b>" & REA.GetString("grup") & "</b></i></td>")
                            Print(f, "</tr>")

                            Print(f, "<tr>")
                            Print(f, "<td style='border-top: 1px solid black;  border-bottom: none; border-right: 1px solid black; border-left: 1px solid black;text-align: center'> " & REA.GetDateTime("fecha").ToString(FORMATO_MYSQL) & "</td>")
                            Select Case Sesion.IdEmpresa
                                Case 12, 11, 16
                                    If intPais = 310 Then
                                        Print(f, "<td style='border-top: 1px solid black;  border-bottom: none; border-right: none; border-left: none;text-align: left; text-align: center'> " & REA.GetInt32("num2") & "</td>")
                                    Else
                                        Print(f, "<td style='border-top: none;  border-bottom: none; border-right: none; border-left: none;text-align: left; text-align: center'> " & REA.GetInt32("numero") & "</td>")
                                    End If
                                Case 14
                                    Print(f, "<td style='border-top: none;  border-bottom: none; border-right: none; border-left: none;text-align: left; text-align: center'> " & REA.GetInt32("num2") & "</td>")
                            End Select

                            Print(f, "<td style='border-top: 1px solid black;  border-bottom: none; border-right: none; border-left: 1px solid black;text-align: left'> " & REA.GetString("nombre") & " </td>")
                            Print(f, "<td style='border-top: 1px solid black;  border-bottom: none; border-right: none; border-left: 1px solid black;text-align: left'> " & REA.GetString("Referencia") & " </td>")
                            Print(f, "<td style='border-top: 1px solid black;  border-bottom: none; border-right: none; border-left: 1px solid black;text-align: right'> " & REA.GetDouble("cantidad").ToString(FORMATO_MONEDA) & " </td>")
                            Print(f, "<td style='border-top: 1px solid black;  border-bottom: none; border-right: none; border-left: 1px solid black;text-align: right'> " & REA.GetDouble("precio").ToString(FORMATO_MONEDA) & "  </td>")
                            Print(f, "<td style='border-top: 1px solid black;  border-bottom: none; border-right: 1px solid black; border-left: 1px solid black;text-align: right'> " & REA.GetDouble("total").ToString(FORMATO_MONEDA) & " </td>")
                            Print(f, "<td style='border-top: 1px solid black;  border-left: 1px solid black;text-align: left'> " & REA.GetString("nombre_empresa") & " </td>")
                            Print(f, "</tr>")

                            dblSubtotal1 = dblSubtotal1 + REA.GetDouble("cantidad")
                            dblSubtotal2 = dblSubtotal2 + REA.GetDouble("total")

                            intNumero = REA.GetInt32("igrup")
                            logPrimeraLinea = 1
                        Else
                            Print(f, "<tr>")
                            Print(f, "<td colspan='4' style='width: 9.8cm; border-top: 1px solid black;  border-bottom: 1px solid black; border-right: 1px solid black; border-left: 1px solid black;text-align: right'><i><b> TOTAL </b></i></td>")
                            'Print(f, "<td colspan=4; style='width: 9.8cm; border-top: 1px solid black;  border-bottom: 1px solid black; border-right: 1px solid black; border-left: 1px solid black;text-align: right'><i><b> TOTAL </b></i></td>")
                            Print(f, "<td style='width: 2.4cm; border-top: 1px solid black;  border-bottom: 1px solid black; border-right: 1px solid black; border-left: none; text-align: right'><i><b>" & dblSubtotal1.ToString(FORMATO_MONEDA) & "</b></i></td>")
                            Print(f, "<td style='width: 1.4cm; border-top: 1px solid black;  border-bottom: 1px solid black; border-right: 1px solid black; border-left: none;'><i><b><br></b></i></td>")
                            Print(f, "<td style='width: 2.4cm; border-top: 1px solid black;  border-bottom: 1px solid black; border-right: 1px solid black; border-left: none; text-align: right'><i><b>" & dblSubtotal2.ToString(FORMATO_MONEDA) & "</b></i></td>")
                            Print(f, "</tr>")

                            dblTotal1 = dblTotal1 + dblSubtotal1
                            dblTotal2 = dblTotal2 + dblSubtotal2

                            dblSubtotal1 = INT_CERO
                            dblSubtotal2 = INT_CERO

                            Print(f, "<tr>")
                            Print(f, "<th colspan='7' style=' border: 1px solid black; text-align: left; background-color: #A3E4D7;'><i><b>" & REA.GetString("grup") & "</b></i></th>")
                            Print(f, "</tr>")

                            Print(f, "<tr>")
                            Print(f, "<td style='border-top: 1px solid black;  border-bottom: none; border-right: 1px solid black; border-left: 1px solid black; text-align: center'> " & REA.GetDateTime("fecha").ToString(FORMATO_MYSQL) & "</td>")
                            Select Case Sesion.IdEmpresa
                                Case 12, 11, 16
                                    If intPais = 310 Then
                                        Print(f, "<td style='border-bottom: 1px solid black;text-align: left; text-align: center'> " & REA.GetInt32("num2") & "</td>")
                                    Else
                                        Print(f, "<td style='border-top: none;  border-bottom: none; border-right: none; border-left: none;text-align: left; text-align: center'> " & REA.GetInt32("numero") & "</td>")
                                    End If
                                Case 14
                                    Print(f, "<td style='border-top: 1px solid black;  border-bottom: 1px solid black;text-align: left; text-align: center'> " & REA.GetInt32("num2") & "</td>")
                            End Select

                            Print(f, "<td style='border-top: 1px solid black;  border-bottom: none; border-right: none; border-left: 1px solid black;text-align: left'> " & REA.GetString("nombre") & " </td>")
                            Print(f, "<td style='border-top: 1px solid black;  border-bottom: none; border-right: none; border-left: 1px solid black;text-align: left'> " & REA.GetString("Referencia") & " </td>")
                            Print(f, "<td style='border-top: 1px solid black;  border-bottom: none; border-right: none; border-left: 1px solid black;text-align: right'> " & REA.GetDouble("cantidad").ToString(FORMATO_MONEDA) & " </td>")
                            Print(f, "<td style='border-top: 1px solid black;  border-bottom: none; border-right: none; border-left: 1px solid black;text-align: right'> " & REA.GetDouble("precio").ToString(FORMATO_MONEDA) & "  </td>")
                            Print(f, "<td style='border-top: 1px solid black;  border-bottom: none; border-right: 1px solid black; border-left: 1px solid black;text-align: right'> " & REA.GetDouble("total").ToString(FORMATO_MONEDA) & " </td>")
                            Print(f, "<td style='border-top: 1px solid black;  border-left: 1px solid black;text-align: left'> " & REA.GetString("nombre_empresa") & " </td>")
                            Print(f, "</tr>")

                            dblSubtotal1 = dblSubtotal1 + REA.GetDouble("cantidad")
                            dblSubtotal2 = dblSubtotal2 + REA.GetDouble("total")


                            'dblTotal(1) = dblTotal(1) + dblSubtotal(1)
                            'dblTotal(2) = dblTotal(2) + dblSubtotal(2)
                            intNumero = REA.GetInt32("igrup")

                        End If
                    End If
                Loop
                Print(f, "<tr>")
                Print(f, "<td colspan='4' style='width: 9.8cm; style=' border-top: 1px solid black;  border-bottom: 1px solid black; border-right: 1px solid black; border-left: 1px solid black;text-align: left'><i><b> TOTAL </b></i></td>")
                Print(f, "<td style='width: 2.4cm; border-top: 1px solid black;  border-bottom: 1px solid black; border-right: 1px solid black; border-left: none; text-align: right'><i><b>" & dblSubtotal1.ToString(FORMATO_MONEDA) & " </b></i></td>")
                Print(f, "<td style='width: 1.4cm; border-top: 1px solid black;  border-bottom: 1px solid black; border-right: 1px solid black; border-left: none;'><i><b> <br> </b></i></td>")
                Print(f, "<td style='width: 2.4cm; border-top: 1px solid black;  border-bottom: 1px solid black; border-right: 1px solid black; border-left: none; text-align: right'><i><b>" & dblSubtotal2.ToString(FORMATO_MONEDA) & " </b></i></td>")
                Print(f, "</tr>")


                'dblSubtotal1 = dblSubtotal1 + REA.GetDouble("cantidad")
                'dblSubtotal2 = dblSubtotal2 + REA.GetDouble("total")


                dblTotal1 = dblTotal1 + dblSubtotal1
                dblTotal2 = dblTotal2 + dblSubtotal2


                Print(f, "<tr>")
                Print(f, "<td colspan='4' style=' border-top: 1px solid black;  border-bottom: 1px solid black; border-right: 1px solid black; border-left: 1px solid black;text-align: right; font-size: 12pt; background-color: #D7DBDD '><i><b> TOTAL </b></td>")
                Print(f, "<td style='width: 2.4cm; border-top: 1px solid black;  border-bottom: 1px solid black; border-right: 1px solid black; border-left: none; text-align: right;font-family: Tahoma, Arial;font-size: 12pt; background-color: #D7DBDD '> <i><b> " & dblTotal1.ToString(FORMATO_MONEDA) & "</b></i></td>")
                Print(f, "<td style='width: 1.4cm; border-top: 1px solid black;  border-bottom: 1px solid black; border-right: 1px solid black; border-left: none; background-color: #D7DBDD '><br></td>")
                Print(f, "<td style='width: 2.4cm; border-top: 1px solid black;  border-bottom: 1px solid black; border-right: 1px solid black; border-left: none; text-align: right;font-family: Tahoma, Arial;font-size: 12pt; background-color: #D7DBDD '> <i><b>" & dblTotal2.ToString(FORMATO_MONEDA) & "</b></i></td>")
                Print(f, "</tr>")


            End If
            Print(f, "</table>")
            Print(f, "<br/>")
            Print(f, "</BODY>")
            Print(f, "</html>")
            FileClose(f)
            MostarReporte(strTemp)
            'End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

#End Region

#Region " Gross Margin"

    Private Function SQLGrossMargin() As String
        Dim strSql As String = STR_VACIO
        Try
            strSql = " SELECT e.idEmpresa idEmpresa, e.nombre_empresa, s.Numero1, s.Fecha, s.Numero2, s.Cliente, s.Hilo  , s.Origen, s.Fabricante, s.Referencia, s.Medida, s.Cantidad, s.Precio , (s.Cantidad * s.Precio)Sale  , s.Costo ,(s.Cantidad * s.Costo)Cost ,ifnull(g.idGrupo,0) idgroup, ifnull(g.nombre_Grupo,'NO GROUP') groupo, e.Facturacion 
                        FROM YarnDivision.Gross s
	                        LEFT JOIN YarnDivision.Grupo g ON g.idGrupo = s.idGrupo AND g.idTipo =  1
	                        LEFT JOIN YarnDivision.Empresa e ON e.idEmpresa = s.idEmpresa
                        ORDER BY e.ordenamiento, s.idGrupo, s.Fecha "
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        Return strSql
    End Function

    Private Function SQLGrossMarginSummary() As String
        Dim strSql As String = STR_VACIO
        Try
            strSql = " SELECT e.nombre_empresa,sum(s.Cantidad * s.Precio)Sale, sum(s.Cantidad * s.Costo)Cost
                        FROM YarnDivision.Gross s
	                        LEFT JOIN YarnDivision.Grupo g ON g.idGrupo = s.idGrupo AND g.idTipo = 1
	                        LEFT JOIN YarnDivision.Empresa e ON e.idEmpresa = s.idEmpresa
                        GROUP BY e.idEmpresa
                        ORDER BY g.nombre_Grupo, g.idGrupo, s.Fecha"
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        Return strSql
    End Function

    Private Function SQLGrossMarginSumaryIntercompany()
        Dim strSql As String = STR_VACIO
        Try
            strSql = " SELECT e.nombre_empresa,sum(s.Cantidad * s.Precio)Sale, sum(s.Cantidad * s.Costo)Cost
                        FROM YarnDivision.Gross s
	                        LEFT JOIN YarnDivision.Grupo g ON g.idGrupo = s.idGrupo AND g.idTipo = 1
	                        LEFT JOIN YarnDivision.Empresa e ON e.idEmpresa = s.idEmpresa
                        WHERE g.nombre_Grupo LIKE 'INTERCOMPANY%'
                        GROUP BY e.idEmpresa
                        ORDER BY e.nombre_empresa"
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        Return strSql
    End Function

    Private Function SQLGrossMarginSumarySinIntercompany()
        Dim strSql As String = STR_VACIO
        Try
            strSql = " SELECT e.nombre_empresa,sum(s.Cantidad * s.Precio)Sale, sum(s.Cantidad * s.Costo)Cost
                        FROM YarnDivision.Gross s
	                        LEFT JOIN YarnDivision.Grupo g ON g.idGrupo = s.idGrupo AND g.idTipo = 1
	                        LEFT JOIN YarnDivision.Empresa e ON e.idEmpresa = s.idEmpresa
                        WHERE g.nombre_Grupo NOT LIKE 'INTERCOMPANY%'
                        GROUP BY e.idEmpresa
                        ORDER BY g.nombre_Grupo, g.idGrupo, s.Fecha"
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        Return strSql
    End Function
    Private Function EncabezadoGross(ByVal Finicio As Date, ByVal Ffin As Date) As String
        Dim strEncabezado As String = STR_VACIO
        Try
            strEncabezado &= "<html>"
            strEncabezado &= "<head>"
            strEncabezado &= "<title>" & "VSxP" & "</title>"
            strEncabezado &= "<style type='text/css'>"
            strEncabezado &= " table {table-layout: fixed; empty-cells: show; border-collapse:collapse}"
            strEncabezado &= " caption {padding: 5px; text-align:left; font-family: Tahoma, Arial;font-size: 8pt}"
            strEncabezado &= " th {width: 1.8cm; border:solid Silver 1px; background-color: #000080; color: White; padding:2px 5px; font-family: Tahoma, Arial;font-size: 7pt}"
            strEncabezado &= " td {text-align:center;border:solid Silver 1px; padding:3px 5px; font-family: Tahoma, Arial;font-size: 7pt}"
            strEncabezado &= " .titulo {font-family: Tahoma, Arial;font-size: 9pt}"
            strEncabezado &= " .encabezado {text-align: left; border: none; width: 3.1cm}"
            strEncabezado &= " .pie {font-family: Tahoma, Arial;font-size: 7pt}"
            strEncabezado &= " .izquierda {text-align:left}"
            strEncabezado &= " .centro {text-align:center}"
            strEncabezado &= " .derecha {text-align:right}"
            strEncabezado &= " .info {text-align:left; border:none}"
            strEncabezado &= " td.numero {text-align:right; mso-number-format:\#\,\#\#0\.00}"
            strEncabezado &= "</style>"
            strEncabezado &= "</head>"
            strEncabezado &= "<body>"

            ' strEncabezado &= "<span class='titulo'><b>" & Sesion.Empresa & "</b></span><br/><br/>"
            strEncabezado &= "<span class='titulo'><b>" & UCase("Gross Margin Corp ") & "</b></span><br/>"
            strEncabezado &= "<span class='pie'>FROM " & Finicio.ToString(FORMATO_MYSQL) & " TO " & Ffin.ToString(FORMATO_MYSQL) & "</span>"
            strEncabezado &= "<br/><br/>"

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        Return strEncabezado
    End Function

    Private Function ColumnasGross() As String
        Dim strColumnas As String = STR_VACIO
        Try
            strColumnas = "<table cellspacing=0> "
            strColumnas &= " <tr> "
            strColumnas &= "<th style= 'width:3cm' > COMPANY </th>"
            strColumnas &= "<th style= 'width:2cm' > NUM </th>"
            strColumnas &= "<th style= 'width:2cm' > DATE </th>"
            'strColumnas &= "<th style= 'width:5cm' > CLIENT GROUP </th>"
            strColumnas &= "<th style= 'width:5cm' > CUSTOMER </th>"
            strColumnas &= "<th style= 'width:3cm' > DESCRIPTION </th>"
            strColumnas &= "<th style= 'width:5cm' > SUPPLIER </th>"
            strColumnas &= "<th style= 'width:3cm' > REFERENCE </th>"
            strColumnas &= "<th style= 'width:3cm' > QUANTITY </th>"
            strColumnas &= "<th style= 'width:2cm' > PRICE </th>"
            strColumnas &= "<th style= 'width:3cm' > TOTAL SALE </th>"
            strColumnas &= "<th style= 'width:2cm' > COST </th>"
            strColumnas &= "<th style= 'width:3cm' > TOTAL COST </th>"
            strColumnas &= "<th style= 'width:2cm' > ORIGIN </th>"
            strColumnas &= "<th style= 'width:1cm' > UM </th>"
            strColumnas &= "<th style= 'width:3cm' > VARIATION </th>"
            strColumnas &= "<th style= 'width:5cm' > GROUP </th>"
            strColumnas &= " </tr> "
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        Return strColumnas
    End Function

    Private Function ColumnasGrossSummary() As String
        Dim strColumnas As String = STR_VACIO
        Try
            strColumnas = "<table cellspacing=0> "
            strColumnas &= " <tr> "
            strColumnas &= "<th style= 'width:3cm' > COMPANY </th>"
            strColumnas &= "<th style= 'width:2cm' > TOTAL SALE </th>"
            strColumnas &= "<th style= 'width:2cm' > TOTAL COST </th>"
            strColumnas &= "<th style= 'width:2cm' > VARIATION </th>"
            strColumnas &= " </tr> "
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        Return strColumnas
    End Function

    Private Function SubTotalGross(ByVal sCategoria As String, ByVal dblCantidad As Double, ByVal dblVenta As Double, ByVal dblCosto As Double) As String
        Dim strTotalRegion As String = STR_VACIO
        Try
            strTotalRegion &= "<br>"
            strTotalRegion &= "<table >"
            strTotalRegion &= "<tr>"
            strTotalRegion &= " <th style= 'background:gray; width:3cm'> - </th>"
            strTotalRegion &= " <th style= 'background:gray; width:2cm'> - </th>"
            strTotalRegion &= " <th style= 'background:gray; width:5cm'> - </th>"
            strTotalRegion &= " <th style= 'background:gray; width:5cm'> - </th>"
            strTotalRegion &= " <th style= 'background:gray; width:3cm'> - </th>"
            'strTotalRegion &= " <th style= 'background:gray; width:1cm'> - </th>"
            'strTotalRegion &= " <th style= 'background:gray; width:5cm'> - </th>"
            strTotalRegion &= " <th style= 'background:gray; width:3cm'> TOTAL  -  </th>"
            strTotalRegion &= " <th style= 'width:1cm;background:gray '>  - </th>"
            strTotalRegion &= " <th style= 'width:1cm;background:gray '>  - </th>"
            strTotalRegion &= " <th style= 'background:gray; width:3cm '> " & dblCantidad.ToString(FORMATO_MONEDA) & " </th>"
            strTotalRegion &= " <th style= 'background:gray; width:2cm'> - </th>"
            strTotalRegion &= " <th style= 'background:gray; width:3cm'> " & dblVenta.ToString(FORMATO_MONEDA) & " </th>"
            strTotalRegion &= " <th style= 'background:gray; width:2cm'> - </th>"
            strTotalRegion &= " <th style= 'background:gray; width:3cm'> " & dblCosto.ToString(FORMATO_MONEDA) & " </th>"
            strTotalRegion &= " <th style= 'background:gray; width:2cm'> - </th>"
            strTotalRegion &= " <th style= 'background:gray; width:1cm'> - </th>"
            strTotalRegion &= " <th style= 'background:gray; width:3cm'> " & (dblVenta - dblCosto).ToString(FORMATO_MONEDA) & " </th>"
            strTotalRegion &= " <th style= 'background:gray; width:5cm'> - </th>"
            strTotalRegion &= "</tr>"
            strTotalRegion &= "</table>"
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        Return strTotalRegion
    End Function

    Private Function TotalGeneralGross(ByVal dblCantidad As Double, ByVal dblVenta As Double, ByVal dblCosto As Double) As String
        Dim strTotalRegion As String = STR_VACIO
        Try
            strTotalRegion &= "<br>"
            strTotalRegion &= "<table >"
            strTotalRegion &= "<tr>"
            strTotalRegion &= " <th style= 'background:gray; width:3cm'> - </th>"
            strTotalRegion &= " <th style= 'background:gray; width:2cm'> - </th>"
            strTotalRegion &= " <th style= 'background:gray; width:5cm'> - </th>"
            strTotalRegion &= " <th style= 'background:gray; width:5cm'> - </th>"
            strTotalRegion &= " <th style= 'background:gray; width:3cm'> - </th>"
            'strTotalRegion &= " <th style= 'background:gray; width:1cm'> - </th>"
            'strTotalRegion &= " <th style= 'background:gray; width:5cm'> - </th>"
            strTotalRegion &= " <th style= 'background:gray; width:3cm'> TOTAL   -  </th>"
            strTotalRegion &= " <th style= 'width:1cm;background:gray '>  - </th>"
            strTotalRegion &= " <th style= 'width:1cm;background:gray '>  - </th>"
            strTotalRegion &= " <th style= 'background:gray; width:3cm '> " & dblCantidad.ToString(FORMATO_MONEDA) & " </th>"
            strTotalRegion &= " <th style= 'background:gray; width:2cm'> - </th>"
            strTotalRegion &= " <th style= 'background:gray; width:3cm'> " & dblVenta.ToString(FORMATO_MONEDA) & " </th>"
            strTotalRegion &= " <th style= 'background:gray; width:2cm'> - </th>"
            strTotalRegion &= " <th style= 'background:gray; width:3cm'> " & dblCosto.ToString(FORMATO_MONEDA) & " </th>"
            strTotalRegion &= " <th style= 'background:gray; width:2cm'> - </th>"
            strTotalRegion &= " <th style= 'background:gray; width:1cm'> - </th>"
            strTotalRegion &= " <th style= 'background:gray; width:3cm'> " & (dblVenta - dblCosto).ToString(FORMATO_MONEDA) & " </th>"
            strTotalRegion &= " <th style= 'background:gray; width:5cm'> - </th>"
            strTotalRegion &= "</tr>"
            strTotalRegion &= "</table>"
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        Return strTotalRegion
    End Function

    Private Function TotalGeneralGrossSummary(ByVal dblVenta As Double, ByVal dblCosto As Double) As String
        Dim strTotalRegion As String = STR_VACIO
        Try
            strTotalRegion &= "<br>"
            strTotalRegion &= "<table >"
            strTotalRegion &= "<tr>"
            strTotalRegion &= " <th style= 'background:gray; width:3cm'> TOTAL </th>"
            strTotalRegion &= " <th style= 'background:gray; width:2cm'> " & dblVenta.ToString(FORMATO_MONEDA) & " </th>"
            strTotalRegion &= " <th style= 'background:gray; width:2cm'> " & dblCosto.ToString(FORMATO_MONEDA) & " </th>"
            strTotalRegion &= " <th style= 'background:gray; width:2cm'> " & (dblVenta - dblCosto).ToString(FORMATO_MONEDA) & " </th>"
            strTotalRegion &= "</tr>"
            strTotalRegion &= "</table>"
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        Return strTotalRegion
    End Function

    Public Sub GrossMarginCorp(ByVal Finicio As Date, ByVal Ffin As Date)
        Dim strSQL As String = STR_VACIO
        Dim f As Byte
        Dim strTemp As String = STR_VACIO
        Dim logPrimeraLInea As Boolean = True
        Dim dblSubtotalLBS As Double = INT_CERO
        Dim dblSubtotalVenta As Double = INT_CERO
        Dim dblSubtotalCosto As Double = INT_CERO
        Dim dblTotalLBS As Double = INT_CERO
        Dim dblTotalVenta As Double = INT_CERO
        Dim dblTotalCosto As Double = INT_CERO
        Dim strHTML As String = STR_VACIO
        Dim intGrupo As Integer = NO_FILA
        Dim strGrupo As String = STR_VACIO

        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader
        Try
            strTemp = cFunciones.ArchivoTemporal
            f = FreeFile()
            FileOpen(f, strTemp, OpenMode.Append)

            strSQL = SQLGrossMargin()
            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSQL, CON)
            REA = COM.ExecuteReader
            strHTML &= EncabezadoGross(Finicio, Ffin)
            strHTML &= ColumnasGross()
            If REA.HasRows Then
                Do While REA.Read
                    If logPrimeraLInea = True Then
                        logPrimeraLInea = False
                        'intGrupo = REA.GetInt32("idgroup")
                        intGrupo = REA.GetInt32("idEmpresa")
                        strGrupo = REA.GetString("groupo")

                    Else
                        'If intGrupo = REA.GetInt32("idgroup") Then
                        If intGrupo = REA.GetInt32("idEmpresa") Then
                        Else

                            strHTML &= SubTotalGross(strGrupo, dblSubtotalLBS, dblSubtotalVenta, dblSubtotalCosto)
                            strHTML &= ColumnasGross()
                            'intGrupo = REA.GetInt32("idgroup")
                            intGrupo = REA.GetInt32("idEmpresa")
                            strGrupo = REA.GetString("groupo")
                            dblSubtotalLBS = INT_CERO
                            dblSubtotalVenta = INT_CERO
                            dblSubtotalCosto = INT_CERO
                        End If
                    End If
                    '' linea
                    strHTML &= " <tr> "
                    strHTML &= "<td>" & REA.GetString("nombre_empresa") & "</td>"
                    strHTML &= "<td>" & REA.GetString("Numero" & REA.GetInt32("Facturacion")) & "</td>"
                    strHTML &= "<td>" & REA.GetDateTime("Fecha").ToString(FORMATO_MYSQL) & "</td>"
                    'strHTML &= "<td>" & REA.GetString("groupo") & "</td>"
                    strHTML &= "<td>" & REA.GetString("Cliente") & "</td>"
                    strHTML &= "<td>" & REA.GetString("Hilo") & "</td>"
                    strHTML &= "<td>" & REA.GetString("Fabricante") & "</td>"
                    strHTML &= "<td>" & REA.GetString("Referencia") & "</td>"
                    strHTML &= "<td>" & REA.GetDouble("Cantidad").ToString(FORMATO_MONEDA) & "</td>"
                    strHTML &= "<td>" & REA.GetDouble("Precio").ToString(FORMATO_MONEDA) & "</td>"
                    strHTML &= "<td>" & REA.GetDouble("Sale").ToString(FORMATO_MONEDA) & "</td>"
                    strHTML &= "<td>" & REA.GetDouble("Costo").ToString(FORMATO_MONEDA) & "</td>"
                    strHTML &= "<td>" & REA.GetDouble("Cost").ToString(FORMATO_MONEDA) & "</td>"
                    strHTML &= "<td>" & REA.GetString("Origen") & "</td>"
                    strHTML &= "<td>" & REA.GetString("Medida") & "</td>"
                    strHTML &= "<td>" & (REA.GetDouble("Sale") - REA.GetDouble("Cost")).ToString(FORMATO_MONEDA) & "</td>"
                    strHTML &= "<td>" & REA.GetString("groupo") & "</td>"
                    strHTML &= " </tr> "

                    dblSubtotalLBS = dblSubtotalLBS + REA.GetDouble("Cantidad")
                    dblSubtotalVenta = dblSubtotalVenta + REA.GetDouble("Sale")
                    dblSubtotalCosto = dblSubtotalCosto + REA.GetDouble("Cost")

                    dblTotalLBS = dblTotalLBS + REA.GetDouble("Cantidad")
                    dblTotalVenta = dblTotalVenta + REA.GetDouble("Sale")
                    dblTotalCosto = dblTotalCosto + REA.GetDouble("Cost")
                Loop

            End If
            strHTML &= SubTotalGross(strGrupo, dblSubtotalLBS, dblSubtotalVenta, dblSubtotalCosto)
            strHTML &= TotalGeneralGross(dblTotalLBS, dblTotalVenta, dblTotalCosto)
            Print(f, strHTML)
            Print(f, "</table>")
            Print(f, "<br/>")
            Print(f, "</body>")
            Print(f, "</html>")
            FileClose(f)
            MostarReporte(strTemp)
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Public Sub GrossMarginCorpSummary(ByVal Finicio As Date, ByVal Ffin As Date)
        Dim strSQL As String = STR_VACIO
        Dim f As Byte
        Dim strTemp As String = STR_VACIO
        Dim logPrimeraLInea As Boolean = True

        Dim dblTotalVenta As Double = INT_CERO
        Dim dblTotalCosto As Double = INT_CERO
        Dim strHTML As String = STR_VACIO
        Dim strTitulo As String = STR_VACIO

        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader
        Try
            strTemp = cFunciones.ArchivoTemporal
            f = FreeFile()
            FileOpen(f, strTemp, OpenMode.Append)

            strHTML &= EncabezadoGross(Finicio, Ffin)

            For j As Integer = 0 To 2
                If j = 0 Then
                    strSQL = SQLGrossMarginSumarySinIntercompany()
                    strTitulo = "Other"
                ElseIf j = 1 Then
                    strSQL = SQLGrossMarginSumaryIntercompany()
                    strTitulo = "Intercompany"
                Else
                    strSQL = SQLGrossMarginSummary()
                    strTitulo = "Total"
                End If

                MyCnn.CONECTAR = strConexion
                COM = New MySqlCommand(strSQL, CON)
                REA = COM.ExecuteReader
                If j > 0 Then
                    strHTML &= " <br> "
                    strHTML &= " <br> "
                End If
                strHTML &= " <tr> "
                strHTML &= "<span class='titulo'><b>" & strTitulo & "</b></span><br/>"
                strHTML &= " <tr> "
                strHTML &= ColumnasGrossSummary()
                If REA.HasRows Then
                    Do While REA.Read

                        '' linea
                        strHTML &= " <tr> "
                        strHTML &= "<td>" & REA.GetString("nombre_empresa") & "</td>"
                        strHTML &= "<td>" & REA.GetDouble("Sale").ToString(FORMATO_MONEDA) & "</td>"
                        strHTML &= "<td>" & REA.GetDouble("Cost").ToString(FORMATO_MONEDA) & "</td>"
                        strHTML &= "<td>" & (REA.GetDouble("Sale") - REA.GetDouble("Cost")).ToString(FORMATO_MONEDA) & "</td>"
                        strHTML &= " </tr> "
                        dblTotalVenta = dblTotalVenta + REA.GetDouble("Sale")
                        dblTotalCosto = dblTotalCosto + REA.GetDouble("Cost")
                    Loop

                End If

                strHTML &= TotalGeneralGrossSummary(dblTotalVenta, dblTotalCosto)
                dblTotalVenta = 0
                dblTotalCosto = 0
            Next
            Print(f, strHTML)
            Print(f, "</table>")
            Print(f, "<br/>")

            Print(f, "</body>")
            Print(f, "</html>")
            FileClose(f)

            MostarReporte(strTemp)
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

#End Region

#Region "VendorsPO"
    Private Function SQLVendorsPO() As String
        Dim strSql As String = STR_VACIO
        Try
            strSql = "SELECT e.nombre_empresa, IFNULL(g.nombre_Grupo,'_NO GROUP') grup, IFNULL(g.idGrupo,-1) igrup, v.Fecha, v.Num, v.Proveedor, v.Hilo, v.FOB, v.CIF, sum(v.Cantidad) Cantidad , sum(v.T_Transito) T_Transito, sum(v.T_Descargo + v.Manual) Descargo, sum(v.Saldo) Saldo, v.Fabricante Fabricante
                        FROM YarnDivision.VendorsPO v
                            LEFT JOIN YarnDivision.Empresa e ON e.idEmpresa = v.idEmpresa
                            LEFT JOIN YarnDivision.Grupo_Detalle gd ON gd.idTipo = 3 AND gd.idEmpresa = e.idEmpresa AND gd.Codigo = v.Codigo
                            LEFT JOIN YarnDivision.Grupo g ON g.idGrupo = gd.idGrupo AND g.idTipo = gd.idTipo
                        GROUP BY v.Num , v.Hilo
                        HAVING  Saldo >0
                        ORDER BY grup, v.Hilo"
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        Return strSql
    End Function

    Private Function EncabezadoVendosPO(ByVal Finicio As Date, ByVal Ffin As Date) As String
        Dim strEncabezado As String = STR_VACIO
        Try
            strEncabezado &= "<html>"
            strEncabezado &= "<head>"
            strEncabezado &= "<meta charset='utf-8'>"
            strEncabezado &= "<title>" & "VSxP" & "</title>"
            strEncabezado &= "<style type='text/css'>"
            strEncabezado &= " table {table-layout: fixed; empty-cells: show; border-collapse:collapse}"
            strEncabezado &= " caption {padding: 5px; text-align:left; font-family: Tahoma, Arial;font-size: 8pt}"
            strEncabezado &= " th {width: 1.8cm; border:solid Silver 1px; background-color: #000080; color: White; padding:2px 5px; font-family: Tahoma, Arial;font-size: 7pt}"
            strEncabezado &= " td {text-align:center;border:solid Silver 1px; padding:3px 5px; font-family: Tahoma, Arial;font-size: 7pt}"
            strEncabezado &= " .titulo {font-family: Tahoma, Arial;font-size: 9pt}"
            strEncabezado &= " .encabezado {text-align: left; border: none; width: 3.1cm}"
            strEncabezado &= " .pie {font-family: Tahoma, Arial;font-size: 7pt}"
            strEncabezado &= " .izquierda {text-align:left}"
            strEncabezado &= " .centro {text-align:center}"
            strEncabezado &= " .derecha {text-align:right}"
            strEncabezado &= " .info {text-align:left; border:none}"
            strEncabezado &= " td.numero {text-align:right; mso-number-format:\#\,\#\#0\.00}"
            strEncabezado &= "</style>"
            strEncabezado &= "</head>"
            strEncabezado &= "<body>"

            ' strEncabezado &= "<span class='titulo'><b>" & Sesion.Empresa & "</b></span><br/><br/>"
            strEncabezado &= "<span class='titulo'><b>" & UCase("Vendos PO Corp ") & "</b></span><br/>"
            strEncabezado &= "<span class='pie'>FROM" & Finicio.ToString(FORMATO_MYSQL) & " TO " & Ffin.ToString(FORMATO_MYSQL) & "</span>"
            strEncabezado &= "<br/><br/>"

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        Return strEncabezado
    End Function

    Private Function ColumnasVendorsPO() As String
        Dim strColumnas As String = STR_VACIO
        Try
            strColumnas = "<table cellspacing=0> "
            strColumnas &= " <tr> "
            strColumnas &= "<th style= 'width:3cm' > Company </th>"
            strColumnas &= "<th style= 'width:2cm' >  DATE </th>"
            strColumnas &= "<th style= 'width:2cm' > PO  </th>"
            strColumnas &= "<th style= 'width:4cm' > VENDOR </th>"
            strColumnas &= "<th style= 'width:4cm' > SPINNING MILL </th>"
            strColumnas &= "<th style= 'width:5cm' > YARN </th>"
            strColumnas &= "<th style= 'width:2cm' > FOB </th>"
            strColumnas &= "<th style= 'width:2cm' > CIF </th>"
            strColumnas &= "<th style= 'width:2.5cm' > QUANTITY </th>"
            strColumnas &= "<th style= 'width:2.5cm' > ON TRANSIT </th>"
            strColumnas &= "<th style= 'width:2.5cm' > DISPATCHED </th>"
            strColumnas &= "<th style= 'width:2.5cm' > BALANCE </th>"
            strColumnas &= " </tr> "
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        Return strColumnas
    End Function

    Private Function SubTotalVendorsPO(ByVal sCategoria As String, ByVal dblCantidad As Double, ByVal dblTransito As Double, ByVal dblDescargo As Double, ByVal dblSaldo As Double) As String
        Dim strTotalRegion As String = STR_VACIO
        Try
            strTotalRegion &= "<br>"
            strTotalRegion &= "<table >"
            strTotalRegion &= "<tr>"
            strTotalRegion &= " <th style= 'background:gray; width:3cm'> - </th>"
            strTotalRegion &= " <th style= 'background:gray; width:2cm'> - </th>"
            strTotalRegion &= " <th style= 'background:gray; width:2cm'>  - </th>"
            strTotalRegion &= " <th style= 'background:gray; width:4cm'>  - </th>"
            strTotalRegion &= " <th style= 'background:gray; width:4cm'> TOTAL   - " & sCategoria & " </th>"
            strTotalRegion &= " <th style= 'background:gray; width:5cm'> - </th>"
            strTotalRegion &= " <th style= 'background:gray; width:2cm'> - </th>"
            strTotalRegion &= " <th style= 'background:gray; width:2cm'> - </th>"
            strTotalRegion &= " <th style= 'background:gray; width:2.5cm'> " & dblCantidad.ToString(FORMATO_MONEDA) & " </th>"
            strTotalRegion &= " <th style= 'background:gray; width:2.5cm'>  " & dblTransito.ToString(FORMATO_MONEDA) & " </th>"
            strTotalRegion &= " <th style= 'background:gray; width:2.5cm'> " & dblDescargo.ToString(FORMATO_MONEDA) & " </th>"
            strTotalRegion &= " <th style= 'background:gray; width:2.5cm'> " & dblSaldo.ToString(FORMATO_MONEDA) & " </th>"
            strTotalRegion &= "</tr>"
            strTotalRegion &= "</table>"
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        Return strTotalRegion
    End Function

    Private Function TotalVendorsPO(ByVal dblCantidad As Double, ByVal dblTransito As Double, ByVal dblDescargo As Double, ByVal dblSaldo As Double) As String
        Dim strTotalRegion As String = STR_VACIO
        Try
            strTotalRegion &= "<br>"
            strTotalRegion &= "<table >"
            strTotalRegion &= "<tr>"
            strTotalRegion &= " <th style= 'background:gray; width:3cm'> - </th>"
            strTotalRegion &= " <th style= 'background:gray; width:2cm'> - </th>"
            strTotalRegion &= " <th style= 'background:gray; width:2cm'> TOTAL   -  </th>"
            strTotalRegion &= " <th style= 'background:gray; width:4cm'>  - </th>"
            strTotalRegion &= " <th style= 'background:gray; width:4cm'>  - </th>"
            strTotalRegion &= " <th style= 'background:gray; width:5cm'> - </th>"
            strTotalRegion &= " <th style= 'background:gray; width:2cm'> - </th>"
            strTotalRegion &= " <th style= 'background:gray; width:2cm'>  - </th>"
            strTotalRegion &= " <th style= 'background:gray; width:2.5cm'> " & dblCantidad.ToString(FORMATO_MONEDA) & " </th>"
            strTotalRegion &= " <th style= 'background:gray; width:2.5cm'>  " & dblTransito.ToString(FORMATO_MONEDA) & " </th>"
            strTotalRegion &= " <th style= 'background:gray; width:2.5cm'> " & dblDescargo.ToString(FORMATO_MONEDA) & " </th>"
            strTotalRegion &= " <th style= 'background:gray; width:2.5cm'> " & dblSaldo.ToString(FORMATO_MONEDA) & " </th>"
            strTotalRegion &= "</tr>"
            strTotalRegion &= "</table>"
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        Return strTotalRegion
    End Function

    Public Sub VendorsPOCorp(ByVal Finicio As Date, ByVal Ffin As Date)
        Dim strSQL As String = STR_VACIO
        Dim f As Byte
        Dim strTemp As String = STR_VACIO
        Dim logPrimeraLInea As Boolean = True

        Dim dblSubtotalCantidad As Double = INT_CERO
        Dim dblSubtotalTransito As Double = INT_CERO
        Dim dblSubtotalDescargo As Double = INT_CERO
        Dim dblSubtotalSaldo As Double = INT_CERO

        Dim dblTotalCantidad As Double = INT_CERO
        Dim dblTotalTransito As Double = INT_CERO
        Dim dblTotalDescargo As Double = INT_CERO
        Dim dblTotalSaldo As Double = INT_CERO

        Dim strHTML As String = STR_VACIO
        Dim intGrupo As Integer = NO_FILA
        Dim strGrupo As String = STR_VACIO

        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader
        Try
            strTemp = cFunciones.ArchivoTemporal
            f = FreeFile()
            FileOpen(f, strTemp, OpenMode.Append)

            strSQL = SQLVendorsPO()
            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSQL, CON)
            REA = COM.ExecuteReader
            strHTML &= EncabezadoVendosPO(Finicio, Ffin)
            strHTML &= ColumnasVendorsPO()
            If REA.HasRows Then
                Do While REA.Read
                    If logPrimeraLInea = True Then
                        logPrimeraLInea = False
                        intGrupo = REA.GetInt32("igrup")
                        strGrupo = REA.GetString("grup")

                    Else
                        If intGrupo = REA.GetInt32("igrup") Then

                        Else

                            strHTML &= SubTotalVendorsPO(strGrupo, dblSubtotalCantidad, dblSubtotalTransito, dblSubtotalDescargo, dblSubtotalSaldo)
                            strHTML &= ColumnasVendorsPO()
                            intGrupo = REA.GetInt32("igrup")
                            strGrupo = REA.GetString("grup")
                            dblSubtotalCantidad = INT_CERO
                            dblSubtotalTransito = INT_CERO
                            dblSubtotalDescargo = INT_CERO
                            dblSubtotalSaldo = INT_CERO
                        End If
                    End If
                    '' linea
                    strHTML &= " <tr> "
                    strHTML &= "<td>" & REA.GetString("nombre_empresa") & "</td>"
                    strHTML &= "<td>" & REA.GetMySqlDateTime("Fecha").ToString & "</td>"
                    strHTML &= "<td>" & REA.GetString("Num") & "</td>"
                    strHTML &= "<td>" & REA.GetString("Proveedor") & "</td>"
                    strHTML &= "<td>" & REA.GetString("Fabricante") & "</td>"
                    strHTML &= "<td>" & REA.GetString("Hilo") & "</td>"

                    strHTML &= "<td>" & REA.GetDouble("FOB").ToString(FORMATO_MONEDA) & "</td>"
                    strHTML &= "<td>" & REA.GetDouble("CIF").ToString(FORMATO_MONEDA) & "</td>"
                    strHTML &= "<td>" & REA.GetDouble("Cantidad").ToString(FORMATO_MONEDA) & "</td>"
                    strHTML &= "<td>" & REA.GetDouble("T_Transito").ToString(FORMATO_MONEDA) & "</td>"
                    strHTML &= "<td>" & REA.GetDouble("Descargo").ToString(FORMATO_MONEDA) & "</td>"
                    strHTML &= "<td>" & REA.GetDouble("Saldo").ToString(FORMATO_MONEDA) & "</td>"

                    strHTML &= " </tr> "

                    dblSubtotalCantidad = dblSubtotalCantidad + REA.GetDouble("Cantidad")
                    dblSubtotalTransito = dblSubtotalTransito + REA.GetDouble("T_Transito")
                    dblSubtotalDescargo = dblSubtotalDescargo + REA.GetDouble("Descargo")
                    dblSubtotalSaldo = dblSubtotalSaldo + REA.GetDouble("Saldo")

                    dblTotalCantidad = dblTotalCantidad + REA.GetDouble("Cantidad")
                    dblTotalTransito = dblTotalTransito + REA.GetDouble("T_Transito")
                    dblTotalDescargo = dblTotalDescargo + REA.GetDouble("Descargo")
                    dblTotalSaldo = dblTotalSaldo + REA.GetDouble("Saldo")
                Loop

            End If
            strHTML &= SubTotalVendorsPO(strGrupo, dblSubtotalCantidad, dblSubtotalTransito, dblSubtotalDescargo, dblSubtotalSaldo)
            strHTML &= TotalVendorsPO(dblTotalCantidad, dblTotalTransito, dblTotalDescargo, dblTotalSaldo)
            Print(f, strHTML)
            Print(f, "</table>")
            Print(f, "<br/>")
            Print(f, "</body>")
            Print(f, "</html>")
            FileClose(f)
            MostarReporte(strTemp)
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

#End Region

#Region "Usa Inventory"
    Private Function SQLUsaInventory() As String
        Dim strSql As String = STR_VACIO
        Try
            strSql = " SELECT u.hilo, u.Fabricante, 
                        SUM(IF(u.idEmpresa = 1, u.saldoInventario,0)) GT, 
                        SUM(IF(u.idEmpresa = 1, u.reserva,0)) ReservaGT, 
                        SUM(IF(u.idEmpresa = 2, u.saldoInventario,0)) SV, 
                        SUM(IF(u.idEmpresa = 2, u.reserva,0)) ReservaSV, 
                        SUM(IF(u.idEmpresa = 3, u.saldoInventario,0)) HN, 
                        SUM(IF(u.idEmpresa = 3, u.reserva,0)) ReservaHN,
                        SUM(IF(u.idEmpresa = 4, u.saldoInventario,0)) DR, 
                        SUM(IF(u.idEmpresa = 4, u.reserva,0)) ReservaDR,
                        SUM(u.saldoPo ),
                        SUM(u.saldoPo ),
                        if(LENGTH(u.GID )>1, u.grupo , '_OTHER YARNS') _grupo
                       FROM YarnDivision.Usa_Inventory u
                        where u.saldoInventario>0 or u.reserva >0
                       GROUP BY _grupo , u.hilo 
                       ORDER BY _grupo, hilo, fabricante "
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        Return strSql
    End Function

    Private Function EncabezadoUsaInventory() As String
        Dim strEncabezado As String = STR_VACIO
        Try
            strEncabezado &= "<html>"
            strEncabezado &= "<head>"
            strEncabezado &= "<title>" & "VSxP" & "</title>"
            strEncabezado &= "<style type='text/css'>"
            strEncabezado &= " table {table-layout: fixed; empty-cells: show; border-collapse:collapse}"
            strEncabezado &= " caption {padding: 5px; text-align:left; font-family: Tahoma, Arial;font-size: 8pt}"
            strEncabezado &= " th {width: 1.8cm; border:solid Silver 1px; background-color: #000080; color: White; padding:2px 5px; font-family: Tahoma, Arial;font-size: 7pt}"
            strEncabezado &= " td {text-align:center;border:solid Silver 1px; padding:3px 5px; font-family: Tahoma, Arial;font-size: 7pt}"
            strEncabezado &= " .titulo {font-family: Tahoma, Arial;font-size: 9pt}"
            strEncabezado &= " .encabezado {text-align: left; border: none; width: 3.1cm}"
            strEncabezado &= " .pie {font-family: Tahoma, Arial;font-size: 7pt}"
            strEncabezado &= " .izquierda {text-align:left}"
            strEncabezado &= " .centro {text-align:center}"
            strEncabezado &= " .derecha {text-align:right}"
            strEncabezado &= " .info {text-align:left; border:none}"
            strEncabezado &= " td.numero {text-align:right; mso-number-format:\#\,\#\#0\.00}"
            strEncabezado &= "</style>"
            strEncabezado &= "</head>"
            strEncabezado &= "<body>"

            ' strEncabezado &= "<span class='titulo'><b>" & Sesion.Empresa & "</b></span><br/><br/>"
            strEncabezado &= "<span class='titulo'><b>" & UCase(" USA INVENTORY REPORT CORP ") & "</b></span><br/>"
            strEncabezado &= "<span class='pie'>DATE " & Today & "</span>"
            ' strEncabezado &= "<br/><br/>"

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        Return strEncabezado
    End Function

    Private Function ColumnasUsaInventory(ByVal strCategoria As String) As String
        Dim strColumnas As String = STR_VACIO
        Try
            ' strColumnas = "<table cellspacing=0> "
            strColumnas &= " <tr> "
            strColumnas &= " <th style='width:31cm' colspan='13'> " & strCategoria & "</th> "
            strColumnas &= " </tr> "
            strColumnas &= " <tr> "
            strColumnas &= "<th style= 'width:3cm' > COUNT </th>"
            strColumnas &= "<th style= 'width:2cm' >  SPINNING MILL </th>"
            strColumnas &= "<th style= 'width:2cm' > GT  </th>"
            strColumnas &= "<th style= 'width:4cm' > RESERVED </th>"
            strColumnas &= "<th style= 'width:5cm' > HN </th>"
            strColumnas &= "<th style= 'width:2.5cm' > RESERVED </th>"
            strColumnas &= "<th style= 'width:2.5cm' > SV </th>"
            strColumnas &= "<th style= 'width:2.5cm' > RESERVED </th>"
            strColumnas &= "<th style= 'width:2.5cm' > DR </th>"
            strColumnas &= "<th style= 'width:2.5cm' > RESERVED </th>"
            strColumnas &= "<th style= 'width:2.5cm' > TOTAL WAREHOUSE </th>"
            strColumnas &= "<th style= 'width:2.5cm' > TOTAL RESERVE </th>" ' #12
            strColumnas &= "<th style= 'width:2.5cm' > TOTAL AVAILABLE </th>" ' #13
            strColumnas &= " </tr> "
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        Return strColumnas
    End Function

    Private Function SubTotalUsaInventory(ByVal sCategoria As String, ByVal subTotalGT As Double, ByVal subTotalReservaGT As Double, ByVal subTotalHN As Double, ByVal subTotalReservaHN As Double, ByVal subTotalSV As Double, ByVal subTotalReservaSV As Double, ByVal subTotalDR As Double, ByVal subTotalReservaDR As Double) As String
        Dim strTotalRegion As String = STR_VACIO
        Try
            ' strTotalRegion &= "<br>"
            ' strTotalRegion &= "<table >"

            strTotalRegion &= " <tr> "
            strTotalRegion &= "<th style= 'width:3cm' > TOTAL </th>"
            strTotalRegion &= "<th style= 'width:2cm' >   </th>"
            strTotalRegion &= "<th style= 'width:2cm' > " & subTotalGT.ToString(FORMATO_MONEDA) & "  </th>"
            strTotalRegion &= "<th style= 'width:4cm' > " & subTotalReservaGT.ToString(FORMATO_MONEDA) & " </th>"
            strTotalRegion &= "<th style= 'width:5cm' > " & subTotalHN.ToString(FORMATO_MONEDA) & "  </th>"
            strTotalRegion &= "<th style= 'width:2.5cm' > " & subTotalReservaHN.ToString(FORMATO_MONEDA) & " </th>"
            strTotalRegion &= "<th style= 'width:2.5cm' > " & subTotalSV.ToString(FORMATO_MONEDA) & "  </th>"
            strTotalRegion &= "<th style= 'width:2.5cm' > " & subTotalReservaSV.ToString(FORMATO_MONEDA) & " </th>"
            strTotalRegion &= "<th style= 'width:2.5cm' > " & subTotalDR.ToString(FORMATO_MONEDA) & "  </th>"
            strTotalRegion &= "<th style= 'width:2.5cm' > " & subTotalReservaDR.ToString(FORMATO_MONEDA) & " </th>"
            strTotalRegion &= "<th style= 'width:2.5cm' >  " & ((subTotalGT + subTotalHN + subTotalSV + subTotalDR)).ToString(FORMATO_MONEDA) & " </th>"
            strTotalRegion &= "<th style= 'width:2.5cm' >  " & ((subTotalReservaGT + subTotalReservaHN + subTotalReservaSV + subTotalReservaDR)).ToString(FORMATO_MONEDA) & " </th>"
            strTotalRegion &= "<th style= 'width:2.5cm' >  " & ((subTotalGT + subTotalHN + subTotalSV + subTotalDR) - (subTotalReservaGT + subTotalReservaHN + subTotalReservaSV + subTotalReservaDR)).ToString(FORMATO_MONEDA) & " </th>"
            strTotalRegion &= " </tr> "
            strTotalRegion &= " <tr> "
            strTotalRegion &= " <th style='background-color: white; width:24cm' colspan='9'> ------------- </th> "
            strTotalRegion &= " </tr> "
            ' strTotalRegion &= "</table>"
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        Return strTotalRegion
    End Function

    Private Function TotalUsaInventory(ByVal sCategoria As String, ByVal subTotalGT As Double, ByVal subTotalReservaGT As Double, ByVal subTotalHN As Double, ByVal subTotalReservaHN As Double, ByVal subTotalSV As Double, ByVal subTotalReservaSV As Double, ByVal subTotalDR As Double, ByVal subTotalReservaDR As Double) As String
        Dim strTotalRegion As String = STR_VACIO
        Try
            ' strTotalRegion &= "<br>"
            '  strTotalRegion &= "<table >"
            strTotalRegion &= " <tr> "
            strTotalRegion &= "<th style= 'width:3cm' > GRAND TOTAL </th>"
            strTotalRegion &= "<th style= 'width:2cm' >   </th>"
            strTotalRegion &= "<th style= 'width:2cm' > " & subTotalGT.ToString(FORMATO_MONEDA) & "  </th>"
            strTotalRegion &= "<th style= 'width:4cm' > " & subTotalReservaGT.ToString(FORMATO_MONEDA) & " </th>"
            strTotalRegion &= "<th style= 'width:5cm' > " & subTotalHN.ToString(FORMATO_MONEDA) & "  </th>"
            strTotalRegion &= "<th style= 'width:2.5cm' > " & subTotalReservaHN.ToString(FORMATO_MONEDA) & " </th>"
            strTotalRegion &= "<th style= 'width:2.5cm' > " & subTotalSV.ToString(FORMATO_MONEDA) & "  </th>"
            strTotalRegion &= "<th style= 'width:2.5cm' > " & subTotalReservaSV.ToString(FORMATO_MONEDA) & " </th>"
            strTotalRegion &= "<th style= 'width:2.5cm' > " & subTotalDR.ToString(FORMATO_MONEDA) & "  </th>"
            strTotalRegion &= "<th style= 'width:2.5cm' > " & subTotalReservaDR.ToString(FORMATO_MONEDA) & " </th>"
            strTotalRegion &= "<th style= 'width:2.5cm' >  " & ((subTotalGT + subTotalHN + subTotalSV + subTotalDR)).ToString(FORMATO_MONEDA) & " </th>"
            strTotalRegion &= "<th style= 'width:2.5cm' >  " & ((subTotalReservaGT + subTotalReservaHN + subTotalReservaSV + subTotalReservaDR)).ToString(FORMATO_MONEDA) & " </th>"
            strTotalRegion &= "<th style= 'width:2.5cm' >  " & ((subTotalGT + subTotalHN + subTotalSV + subTotalDR) - (subTotalReservaGT + subTotalReservaHN + subTotalReservaSV + subTotalReservaDR)).ToString(FORMATO_MONEDA) & " </th>"
            strTotalRegion &= " </tr> "
            '  strTotalRegion &= "</table>"
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        Return strTotalRegion
    End Function

    Public Sub UsaInventoryCorp()
        Dim strSQL As String = STR_VACIO
        Dim f As Byte
        Dim strTemp As String = STR_VACIO
        Dim logPrimeraLInea As Boolean = True

        Dim dblSubtotalGT As Double = INT_CERO
        Dim dblSubtotalReservaGT As Double = INT_CERO
        Dim dblSubtotalHN As Double = INT_CERO
        Dim dblSubtotalReservaHN As Double = INT_CERO
        Dim dblSubtotalSV As Double = INT_CERO
        Dim dblSubtotalReservaSV As Double = INT_CERO
        Dim dblSubtotalDR As Double = INT_CERO
        Dim dblSubtotalReservaDR As Double = INT_CERO
        Dim dblSubtotalDisponible As Double = INT_CERO


        Dim dbltotalGT As Double = INT_CERO
        Dim dbltotalReservaGT As Double = INT_CERO
        Dim dbltotalHN As Double = INT_CERO
        Dim dbltotalReservaHN As Double = INT_CERO
        Dim dbltotalSV As Double = INT_CERO
        Dim dbltotalReservaSV As Double = INT_CERO
        Dim dbltotalDR As Double = INT_CERO
        Dim dbltotalReservaDR As Double = INT_CERO
        Dim dbltotalDisponible As Double = INT_CERO

        Dim strHTML As String = STR_VACIO
        Dim intGrupo As Integer = NO_FILA
        Dim strGrupo As String = STR_VACIO

        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader
        Try
            strTemp = cFunciones.ArchivoTemporal
            f = FreeFile()
            FileOpen(f, strTemp, OpenMode.Append)

            strSQL = SQLUsaInventory()
            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSQL, CON)
            REA = COM.ExecuteReader
            strHTML &= EncabezadoUsaInventory()

            If REA.HasRows Then
                strHTML &= "  <table style='width:24cm'>"
                Do While REA.Read
                    If logPrimeraLInea = True Then
                        logPrimeraLInea = False
                        strGrupo = REA.GetString("_grupo")
                        strHTML &= ColumnasUsaInventory(strGrupo)
                    Else
                        If strGrupo = REA.GetString("_grupo") Then

                        Else

                            strHTML &= SubTotalUsaInventory(strGrupo, dblSubtotalGT, dblSubtotalReservaGT, dblSubtotalHN, dblSubtotalReservaHN, dblSubtotalSV, dblSubtotalReservaSV, dblSubtotalDR, dblSubtotalReservaDR)
                            strHTML &= ColumnasUsaInventory(REA.GetString("_grupo"))

                            strGrupo = REA.GetString("_grupo")
                            dblSubtotalGT = INT_CERO
                            dblSubtotalReservaGT = INT_CERO
                            dblSubtotalHN = INT_CERO
                            dblSubtotalReservaHN = INT_CERO
                            dblSubtotalSV = INT_CERO
                            dblSubtotalReservaSV = INT_CERO
                            dblSubtotalDR = INT_CERO
                            dblSubtotalReservaDR = INT_CERO
                            dblSubtotalDisponible = INT_CERO
                        End If
                    End If
                    '' linea
                    strHTML &= " <tr> "
                    strHTML &= "<td>" & REA.GetString("hilo") & "</td>"
                    strHTML &= "<td>" & REA.GetString("Fabricante") & "</td>"

                    strHTML &= "<td  style='color: " & IIf(REA.GetDouble("GT") = 0, "white", "black") & "; background-color: white; text-align:right'>" & REA.GetDouble("GT").ToString(FORMATO_MONEDA) & "</td>"
                    strHTML &= "<td style='color: " & IIf(REA.GetDouble("ReservaGT") = 0, "lightyellow", "black") & ";background-color: lightyellow; text-align:right'>" & REA.GetDouble("ReservaGT").ToString(FORMATO_MONEDA) & "</td>"

                    strHTML &= "<td style='color: " & IIf(REA.GetDouble("HN") = 0, "white", "black") & ";background-color: white; text-align:right'>" & REA.GetDouble("HN").ToString(FORMATO_MONEDA) & "</td>"
                    strHTML &= "<td style='color: " & IIf(REA.GetDouble("ReservaHN") = 0, "lightyellow", "black") & ";background-color: lightyellow; text-align:right'>" & REA.GetDouble("ReservaHN").ToString(FORMATO_MONEDA) & "</td>"

                    strHTML &= "<td style='color: " & IIf(REA.GetDouble("SV") = 0, "white", "black") & ";background-color: white; text-align:right'>" & REA.GetDouble("SV").ToString(FORMATO_MONEDA) & "</td>"
                    strHTML &= "<td style='color: " & IIf(REA.GetDouble("ReservaSV") = 0, "lightyellow", "black") & ";background-color: lightyellow; text-align:right'>" & REA.GetDouble("ReservaSV").ToString(FORMATO_MONEDA) & "</td>"

                    strHTML &= "<td style='color: " & IIf(REA.GetDouble("DR") = 0, "white", "black") & ";background-color: white; text-align:right'>" & REA.GetDouble("DR").ToString(FORMATO_MONEDA) & "</td>"
                    strHTML &= "<td style='color: " & IIf(REA.GetDouble("ReservaDR") = 0, "lightyellow", "black") & ";background-color: lightyellow; text-align:right'>" & REA.GetDouble("ReservaDR").ToString(FORMATO_MONEDA) & "</td>"

                    strHTML &= "<td style='background-color: white; text-align:right'>" & ((REA.GetDouble("GT") + REA.GetDouble("SV") + REA.GetDouble("HN") + REA.GetDouble("DR"))).ToString(FORMATO_MONEDA) & "</td>"
                    strHTML &= "<td style='background-color: white; text-align:right'>" & ((REA.GetDouble("ReservaGT") + REA.GetDouble("ReservaSV") + REA.GetDouble("ReservaHN") + REA.GetDouble("ReservaDR"))).ToString(FORMATO_MONEDA) & "</td>"
                    strHTML &= "<td style='background-color: white; text-align:right'>" & ((REA.GetDouble("GT") + REA.GetDouble("SV") + REA.GetDouble("HN") + REA.GetDouble("DR")) - (REA.GetDouble("ReservaGT") + REA.GetDouble("ReservaSV") + REA.GetDouble("ReservaHN") + REA.GetDouble("ReservaDR"))).ToString(FORMATO_MONEDA) & "</td>"
                    strHTML &= " </tr> "

                    dblSubtotalGT = dblSubtotalGT + REA.GetDouble("GT")
                    dblSubtotalReservaGT = dblSubtotalReservaGT + REA.GetDouble("ReservaGT")
                    dblSubtotalHN = dblSubtotalHN + REA.GetDouble("HN")
                    dblSubtotalReservaHN = dblSubtotalReservaHN + REA.GetDouble("ReservaHN")
                    dblSubtotalSV = dblSubtotalSV + REA.GetDouble("SV")
                    dblSubtotalReservaSV = dblSubtotalReservaSV + REA.GetDouble("ReservaSV")
                    dblSubtotalDR = dblSubtotalDR + REA.GetDouble("DR")
                    dblSubtotalReservaDR = dblSubtotalReservaDR + REA.GetDouble("ReservaDR")

                    dbltotalGT = dbltotalGT + REA.GetDouble("GT")
                    dbltotalReservaGT = dbltotalReservaGT + REA.GetDouble("ReservaGT")
                    dbltotalHN = dbltotalHN + REA.GetDouble("HN")
                    dbltotalReservaHN = dbltotalReservaHN + REA.GetDouble("ReservaHN")
                    dbltotalSV = dbltotalSV + REA.GetDouble("SV")
                    dbltotalReservaSV = dbltotalReservaSV + REA.GetDouble("ReservaSV")
                    dbltotalDR = dbltotalDR + REA.GetDouble("DR")
                    dbltotalReservaDR = dbltotalReservaDR + REA.GetDouble("ReservaDR")
                Loop

            End If
            strHTML &= SubTotalUsaInventory(strGrupo, dblSubtotalGT, dblSubtotalReservaGT, dblSubtotalHN, dblSubtotalReservaHN, dblSubtotalSV, dblSubtotalReservaSV, dblSubtotalDR, dblSubtotalReservaDR)
            strHTML &= TotalUsaInventory(strGrupo, dbltotalGT, dbltotalReservaGT, dbltotalHN, dbltotalReservaHN, dbltotalSV, dbltotalReservaSV, dbltotalDR, dbltotalReservaDR)
            Print(f, strHTML)
            Print(f, "</table>")
            ' Print(f, "<br/>")
            Print(f, "</body>")
            Print(f, "</html>")
            FileClose(f)
            MostarReporte(strTemp)
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub
#End Region

#Region "Historical Inventory"
    Private Function SQLInventoryHistorical(ByVal fechaInicio As Date, ByVal fechaFin As Date)
        Dim strSQL As String = STR_VACIO
        strSQL = "  SELECT ih.Fecha ,SUM(ih.Total_Inventario/ 1000000) Total_Inventario , SUM(ih.Sold/ 1000000) Sold, SUM(ih.Transito/ 1000000) Transito , SUM(ih.Pendiente/ 1000000) Pendiente, "
        strSQL &= "     ROUND(SUM((ih.Total_Inventario + ih.Transito + ih.Pendiente)/ 1000000),3) Total   "
        strSQL &= "         FROM YarnDivision.Inventario_Historico ih  "
        strSQL &= "             WHERE ih.Fecha BETWEEN '{fechainicio}' AND '{fechafin}'"
        strSQL &= "             GROUP By ih.Fecha "
        strSQL = Replace(strSQL, "{fechainicio}", fechaInicio.ToString(FORMATO_MYSQL))
        strSQL = Replace(strSQL, "{fechafin}", fechaFin.ToString(FORMATO_MYSQL))
        Return strSQL
    End Function
    Public Sub InventoryHistorical()
        Dim strSQL As String = STR_VACIO
        Dim f As Byte
        Dim strTemp As String = STR_VACIO
        Dim strPais As String = STR_VACIO
        Dim intFila As Integer = INT_CERO
        Dim ArrayPrueba(100) As String
        Dim ArrayFila(100) As String
        Dim ArrayDatos As String
        Dim frm As New frmFiltro
        Dim dblSuma(25) As Double
        Dim i As Integer = -1
        'conexiones 
        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader
        Try
            frm.BanderaFechas = True
            frm.ShowDialog(Fprincipal)
            If frm.DialogResult = DialogResult.OK Then
                strTemp = cFunciones.ArchivoTemporal
                f = FreeFile()
                FileOpen(f, strTemp, OpenMode.Append)

                Print(f, " <html > ")
                Print(f, " <head > ")


                Print(f, " <style type='text/css'>")
                Print(f, " table {table-layout: fixed; empty-cells: show; border-collapse:collapse}")
                Print(f, " caption {padding: 5px; text-align:left; font-family: Tahoma,  Arial;font-size: 8pt}")
                Print(f, " td {text-align:center;border:solid Gray 1px; padding:3px 5px; font-family: Tahoma, Arial;font-size: 7pt}")
                Print(f, " th {width: 1.8cm; border:solid Gray 1px; background-color: Black; color: White; padding:2px 5px; font-family: Tahoma,  Arial;font-size: 6pt}")
                Print(f, " th {text-align:center;border:solid Gray 1px; padding:3px 5px; font-family: Tahoma,  Arial;font-size: 7pt}")
                Print(f, " th.numero {text-align:right; mso-number-format:\#\,\#\#0\.00}")
                Print(f, " th.unitario {text-align:right; mso-number-format:\#\,\#\#0\.00#####}")
                Print(f, " th.titulo {text-align:right;font-family: Tahoma,  Arial;font-size: 9pt")
                Print(f, " .titulo {font-family: Tahoma,  Arial;font-size: 9pt}")
                Print(f, " .encabezado {text-align: left; border: none; width: 3.1cm}")
                Print(f, " .pie {font-family: Tahoma,  Arial;font-size: 7pt}")
                Print(f, " .izquierda {text-align:left}")
                Print(f, " .centro {text-align:center}")
                Print(f, " .derecha {text-align:right}")
                Print(f, " .info {text-align:left; border:none}")
                Print(f, "</style>")

                Print(f, "<td style='font-family: Tahoma;font-size:25pt'><b>Historical Inventory <br> </b></td>")
                Print(f, "<td style='font-family: Tahoma;font-size:7pt'><b>To " & Now().ToString(FORMATO_MYSQL) & " </b></td>")

                Print(f, "</head>")
                Print(f, "<body>")

                Print(f, "<table cellspacing=0>")
                'Encabezado de columnas: style='width: 1cm'
                Print(f, "<tr>")
                Print(f, "<th style='width: 2.5cm; background-color: #BCF5A9; color: black'></th>")
                Print(f, "<th colspan = 5 style='width: 14.5cm; background-color: #BCF5A9; color: black'>Grand Total - In Million</th>")
                Print(f, "</tr>")

                Print(f, "<tr>")
                Print(f, "<th style='width: 2.5cm'>WEEK</th>")
                Print(f, "<th style='width: 2.5cm'>Total Available for Inventory</th>")
                Print(f, "<th style='width: 2.5cm'>Total Sold</th>")
                Print(f, "<th style='width: 2.5cm'>Total In Transit</th>")
                Print(f, "<th style='width: 2.5cm'>Total Pending To Ship</th>")
                Print(f, "<th style='width: 2.5cm'>Grand Total Available After Sale (in Millions)</th>")
                Print(f, "</tr>")

                strSQL = SQLInventoryHistorical(frm.FechaInicio, frm.FechaFin)
                MyCnn.CONECTAR = strConexion
                COM = New MySqlCommand(strSQL, CON)
                REA = COM.ExecuteReader
                If REA.HasRows Then
                    Do While REA.Read
                        i = i + 1
                        ReDim Preserve ArrayPrueba(i)
                        ArrayPrueba(i) = REA.GetDateTime("Fecha") & "|" & Math.Round(REA.GetDouble("Total_Inventario"), 3) & "|" & Math.Round(REA.GetDouble("Sold"), 3) & "|" & Math.Round(REA.GetDouble("Transito"), 3) & "|" & Math.Round(REA.GetDouble("Pendiente"), 3) & "|" & Math.Round(REA.GetDouble("Total"), 3)
                    Loop
                End If
                For z As Integer = 0 To ArrayPrueba.Count - 1
                    intFila = z
                Next

                For j As Integer = 0 To ArrayPrueba.Count - 1
                    ArrayDatos = ArrayPrueba(j)
                    ArrayFila = ArrayDatos.Split("|".ToCharArray)
                    If intFila = j Then
                        Print(f, "<tr>")
                        Print(f, "<td style='width: 2.5cm;background-color: #FFFF00;'>" & ArrayFila(INT_CERO) & "</td>")
                        Print(f, "<td style='width: 2.5cm;background-color: #FFFF00;'>" & ArrayFila(INT_UNO) & "</td>")
                        Print(f, "<td style='width: 2.5cm;background-color: #FFFF00;'>" & ArrayFila(2) & "</td>")
                        Print(f, "<td style='width: 2.5cm;background-color: #FFFF00;'>" & ArrayFila(3) & "</td>")
                        Print(f, "<td style='width: 2.5cm;background-color: #FFFF00;'>" & ArrayFila(4) & "</td>")
                        Print(f, "<td style='width: 2.5cm;background-color: #FFFF00;'>" & ArrayFila(5) & "</td>")
                        Print(f, "</tr>")
                    Else
                        Print(f, "<tr>")
                        Print(f, "<td style='width: 2.5cm'>" & ArrayFila(INT_CERO) & "</td>")
                        Print(f, "<td style='width: 2.5cm'>" & ArrayFila(INT_UNO) & "</td>")
                        Print(f, "<td style='width: 2.5cm'>" & ArrayFila(2) & "</td>")
                        Print(f, "<td style='width: 2.5cm'>" & ArrayFila(3) & "</td>")
                        Print(f, "<td style='width: 2.5cm'>" & ArrayFila(4) & "</td>")
                        Print(f, "<td style='width: 2.5cm'>" & ArrayFila(5) & "</td>")
                        Print(f, "</tr>")
                    End If
                Next


                Print(f, "</table>")
                Print(f, "<br/>")
                Print(f, "</body>")
                Print(f, "</html>")

                FileClose(f)
                MostarReporte(strTemp)
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

#End Region

#Region "Inventory Corp"

    Private Function SQLInventoryCorp(ByVal Estado As String, ByVal Hilo As String, ByVal cantidadinicio As Double, ByVal cantidadfin As Double) As String
        Dim strSql As String = STR_VACIO
        Try
            strSql = " SELECT e.nombre_empresa , i.Fecha , i.Descripcion , i.Origen , i.Referencia , i.Fabricante , i.Saldo , if(i.Estado ='GOOD', 'GOOD', 'BAD') Estado 
                        FROM YarnDivision.Inventario i
                            LEFT JOIN YarnDivision.Empresa e  ON e.idEmpresa = i.idEmpresa 
                         WHERE 1=1  {hilo} {cantidad} {estado}
                        ORDER BY i.Descripcion , i.idEmpresa , Estado   "

            If Not Estado = STR_VACIO Then
                strSql = strSql.Replace("{estado}", " Having Estado = '" & Estado & "'")
            Else
                strSql = strSql.Replace("{estado}", STR_VACIO)
            End If
            If Not Hilo = STR_VACIO Then
                strSql = strSql.Replace("{hilo}", " and  i.Descripcion = '" & Hilo & "'")
            Else
                strSql = strSql.Replace("{hilo}", STR_VACIO)
            End If
            If cantidadinicio > 0 Then
                strSql = strSql.Replace("{cantidad}", " and  i.Saldo between " & cantidadinicio & " and " & cantidadfin)
            Else
                strSql = strSql.Replace("{cantidad}", STR_VACIO)
            End If

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        Return strSql
    End Function

    Private Function EncabezadoInventoryCorp() As String
        Dim strEncabezado As String = STR_VACIO
        Try
            strEncabezado &= "<html>"
            strEncabezado &= "<head>"
            strEncabezado &= "<title>" & "VSxP" & "</title>"
            strEncabezado &= "<style type='text/css'>"
            strEncabezado &= " table {table-layout: fixed; empty-cells: show; border-collapse:collapse}"
            strEncabezado &= " caption {padding: 5px; text-align:left; font-family: Tahoma, Arial;font-size: 8pt}"
            strEncabezado &= " th {width: 1.8cm; border:solid Silver 1px; background-color: #000080; color: White; padding:2px 5px; font-family: Tahoma, Arial;font-size: 7pt}"
            strEncabezado &= " td {text-align:center;border:solid Silver 1px; padding:3px 5px; font-family: Tahoma, Arial;font-size: 7pt}"
            strEncabezado &= " .titulo {font-family: Tahoma, Arial;font-size: 9pt}"
            strEncabezado &= " .encabezado {text-align: left; border: none; width: 3.1cm}"
            strEncabezado &= " .pie {font-family: Tahoma, Arial;font-size: 7pt}"
            strEncabezado &= " .izquierda {text-align:left}"
            strEncabezado &= " .centro {text-align:center}"
            strEncabezado &= " .derecha {text-align:right}"
            strEncabezado &= " .info {text-align:left; border:none}"
            strEncabezado &= " td.numero {text-align:right; mso-number-format:\#\,\#\#0\.00}"
            strEncabezado &= "</style>"
            strEncabezado &= "</head>"
            strEncabezado &= "<body>"

            ' strEncabezado &= "<span class='titulo'><b>" & Sesion.Empresa & "</b></span><br/><br/>"
            strEncabezado &= "<span class='titulo'><b>" & UCase(" INVENTORY CORP ") & "</b></span><br/>"
            strEncabezado &= "<span class='pie'>DATE " & Today & "</span>"
            ' strEncabezado &= "<br/><br/>"

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        Return strEncabezado
    End Function

    Private Function ColumnasInventoryCorp() As String
        Dim strColumnas As String = STR_VACIO
        Try
            strColumnas &= " <tr> "
            strColumnas &= "<th style= 'width:3cm' > COMPANY </th>"
            strColumnas &= "<th style= 'width:2cm' >  DATE </th>"
            strColumnas &= "<th style= 'width:5cm' > YARN  </th>"
            strColumnas &= "<th style= 'width:2cm' > ORIGIN </th>"
            strColumnas &= "<th style= 'width:5cm' > REFERENCE </th>"
            strColumnas &= "<th style= 'width:3cm' > MILL </th>"
            strColumnas &= "<th style= 'width:2.5cm' > BALACE </th>"
            strColumnas &= "<th style= 'width:2.5cm' > STATUS </th>"
            strColumnas &= " </tr> "
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        Return strColumnas
    End Function

    Private Function SubTotalInventoryCorp(ByVal sCategoria As String, ByVal subSALDO As Double) As String
        Dim strTotalRegion As String = STR_VACIO
        Try

            strTotalRegion &= " <tr> "
            strTotalRegion &= "<th style= 'width:3cm' >  </th>"
            strTotalRegion &= "<th style= 'width:2cm' >   </th>"
            strTotalRegion &= "<th style= 'width:2cm' >   </th>"
            strTotalRegion &= "<th style= 'width:4cm' >  </th>"
            strTotalRegion &= "<th style= 'width:5cm' > Total  " & sCategoria & " </th>"
            strTotalRegion &= "<th style= 'width:2.5cm' >  </th>"
            strTotalRegion &= "<th style= 'width:2.5cm' > " & subSALDO.ToString(FORMATO_MONEDA) & " </th>"
            strTotalRegion &= "<th style= 'width:2.5cm' >  </th>"
            strTotalRegion &= " </tr> "
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        Return strTotalRegion
    End Function

    Private Function TotalInventoryCorp(ByVal sCategoria As String, ByVal subSALDO As Double) As String
        Dim strTotalRegion As String = STR_VACIO
        Try

            strTotalRegion &= " <tr> "
            strTotalRegion &= "<th style= 'width:3cm' >  </th>"
            strTotalRegion &= "<th style= 'width:2cm' >   </th>"
            strTotalRegion &= "<th style= 'width:2cm' >   </th>"
            strTotalRegion &= "<th style= 'width:4cm' >  </th>"
            strTotalRegion &= "<th style= 'width:5cm' > Total  </th>"
            strTotalRegion &= "<th style= 'width:2.5cm' >  </th>"
            strTotalRegion &= "<th style= 'width:2.5cm' > " & subSALDO.ToString(FORMATO_MONEDA) & " </th>"
            strTotalRegion &= "<th style= 'width:2.5cm' >  </th>"
            strTotalRegion &= " </tr> "
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        Return strTotalRegion
    End Function

    Public Sub InventoryCorp(ByVal Estado As String, ByVal Hilo As String, ByVal cantidadinicio As Double, ByVal cantidadfin As Double)
        Dim strSQL As String = STR_VACIO
        Dim f As Byte
        Dim strTemp As String = STR_VACIO
        Dim logPrimeraLInea As Boolean = True

        Dim dblSubtotal As Double = INT_CERO
        Dim dbltotal As Double = INT_CERO

        Dim strHTML As String = STR_VACIO
        Dim strGrupo As String = STR_VACIO
        Dim frm As New frmMensaje

        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader
        frm.Mensaje = "Please wait.. "
        frm.Show()
        System.Windows.Forms.Application.DoEvents()
        Try

            strTemp = cFunciones.ArchivoTemporal
            f = FreeFile()
            FileOpen(f, strTemp, OpenMode.Append)

            strSQL = SQLInventoryCorp(Estado, Hilo, cantidadinicio, cantidadfin)
            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSQL, CON)
            REA = COM.ExecuteReader
            strHTML &= EncabezadoInventoryCorp()

            If REA.HasRows Then
                strHTML &= "  <table style='width:24cm'>"
                Do While REA.Read
                    If logPrimeraLInea = True Then
                        logPrimeraLInea = False
                        strGrupo = REA.GetString("Descripcion")
                        strHTML &= ColumnasInventoryCorp()
                    Else
                        If strGrupo = REA.GetString("Descripcion") Then

                        Else

                            strHTML &= SubTotalInventoryCorp(strGrupo, dblSubtotal)
                            strHTML &= ColumnasInventoryCorp()

                            strGrupo = REA.GetString("Descripcion")
                            dblSubtotal = INT_CERO
                        End If
                    End If
                    '' linea
                    strHTML &= " <tr> "
                    strHTML &= "<td>" & REA.GetString("nombre_empresa") & "</td>"
                    strHTML &= "<td>" & REA.GetMySqlDateTime("Fecha").ToString & "</td>"
                    strHTML &= "<td>" & REA.GetString("Descripcion") & "</td>"
                    strHTML &= "<td>" & REA.GetString("Origen") & "</td>"
                    strHTML &= "<td>" & REA.GetString("Referencia") & "</td>"
                    strHTML &= "<td>" & REA.GetString("Fabricante") & "</td>"
                    strHTML &= "<td>" & REA.GetDouble("Saldo").ToString(FORMATO_MONEDA) & "</td>"
                    strHTML &= "<td>" & REA.GetString("Estado") & "</td>"

                    dblSubtotal = dblSubtotal + REA.GetDouble("Saldo")
                    dbltotal = dbltotal + REA.GetDouble("Saldo")

                Loop

            End If
            strHTML &= SubTotalInventoryCorp(strGrupo, dblSubtotal)
            strHTML &= TotalInventoryCorp(strGrupo, dbltotal)
            Print(f, strHTML)
            Print(f, "</table>")
            ' Print(f, "<br/>")
            Print(f, "</body>")
            Print(f, "</html>")
            FileClose(f)
            MostarReporte(strTemp)
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        frm.Close()
    End Sub


#End Region

#Region "Purchase by Vendor Corp"

    Private Function SQLPurchase(ByVal intEmp As Integer) As String
        Dim strSql As String = STR_VACIO
        Try
            strSql = "  SELECT ifnull(gg.idGrupo,-1)  idgroup,  IFNULL(gg.nombre_Grupo, '_N/A') groupo, s.Proveedor, s.Fecha, s.Fechaemision, s.Numero, s.Hilo,s.Terminos, s.Referencia, s.Region, s.Cantidad,s.Precio, (s.Cantidad * s.Precio) Total, e.nombre_empresa Empresas
                        FROM YarnDivision.Purchase s
                            LEFT JOIN YarnDivision.Grupo_Detalle g ON g.idEmpresa = s.idEmpresa AND g.Codigo = s.id AND g.idTipo = 3
                            LEFT JOIN YarnDivision.Grupo gg ON gg.idGrupo = g.idGrupo AND gg.idTipo = g.idTipo
                            LEFT JOIN YarnDivision.Empresa e ON e.idEmpresa = s.idEmpresa
                        {emp}
                        ORDER BY groupo, gg.idGrupo, s.Proveedor , s.Fecha , e.idEmpresa "

            If intEmp = 0 Then
                strSql = strSql.Replace("{emp}", "")
            Else
                strSql = strSql.Replace("{emp}", " WHERE e.idEmpresa = " & intEmp)
            End If

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        Return strSql
    End Function

    Private Function EncabezadoPurchase(ByVal Finicio As Date, ByVal Ffin As Date) As String
        Dim strEncabezado As String = STR_VACIO
        Try
            strEncabezado &= "<html>"
            strEncabezado &= "<head>"
            strEncabezado &= "<title>" & "VSxP" & "</title>"
            strEncabezado &= "<style type='text/css'>"
            strEncabezado &= " table {table-layout: fixed; empty-cells: show; border-collapse:collapse}"
            strEncabezado &= " caption {padding: 5px; text-align:left; font-family: Tahoma, Arial;font-size: 8pt}"
            strEncabezado &= " th {width: 1.8cm; border:solid Silver 1px; background-color: #000080; color: White; padding:2px 5px; font-family: Tahoma, Arial;font-size: 7pt}"
            strEncabezado &= " td {text-align:center;border:solid Silver 1px; padding:3px 5px; font-family: Tahoma, Arial;font-size: 7pt}"
            strEncabezado &= " .titulo {font-family: Tahoma, Arial;font-size: 9pt}"
            strEncabezado &= " .encabezado {text-align: left; border: none; width: 3.1cm}"
            strEncabezado &= " .pie {font-family: Tahoma, Arial;font-size: 7pt}"
            strEncabezado &= " .izquierda {text-align:left}"
            strEncabezado &= " .centro {text-align:center}"
            strEncabezado &= " .derecha {text-align:right}"
            strEncabezado &= " .info {text-align:left; border:none}"
            strEncabezado &= " td.numero {text-align:right; mso-number-format:\#\,\#\#0\.00}"
            strEncabezado &= "</style>"
            strEncabezado &= "</head>"
            strEncabezado &= "<body>"

            ' strEncabezado &= "<span class='titulo'><b>" & Sesion.Empresa & "</b></span><br/><br/>"
            strEncabezado &= "<span class='titulo'><b>" & UCase("Purchase by Vendor Corp ") & "</b></span><br/>"
            strEncabezado &= "<span class='pie'>FROM" & Finicio.ToString(FORMATO_MYSQL) & " TO " & Ffin.ToString(FORMATO_MYSQL) & "<br></span>"
            strEncabezado &= "<span class='titulo'><b> Amounts expressed in US$</b></span><br/>"
            strEncabezado &= "<br/><br/>"

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        Return strEncabezado
    End Function

    Private Function ColumnasPurchase(ByVal Grupo As String) As String
        Dim strColumnas As String = STR_VACIO
        Try
            strColumnas = "<table cellspacing=0> "
            strColumnas &= "<tr>"
            strColumnas &= "<td colspan='12' style='border-right: none; border-top: none; border-left: none;background-color: #BDBDBD;text-align: left;font-family: Tahoma, Arial;font-size: 8pt'> <b>" & Grupo & " </b></td>"
            strColumnas &= "</tr>"
            strColumnas &= " <tr> "

            strColumnas &= "<th style='width: 1cm;border-right: none; border-top: none; border-left: none; border-bottom: none;background-color: #BDBDBD'>COMPANY</th>"
            strColumnas &= "<th style='width: 3cm;border-right: none; border-top: none; border-left: none; border-bottom: none;background-color: #BDBDBD'>VENDOR</th>"
            strColumnas &= "<th style='width: 1cm;border-right: none; border-top: none; border-left: none; border-bottom: none;background-color: #BDBDBD'>DATE</th>"
            strColumnas &= "<th style='width: 1cm;border-right: none; border-top: none; border-left: none; border-bottom: none;background-color: #BDBDBD'>ISSUANCE DATE</th>"
            strColumnas &= "<th style='width: 1cm;border-right: none; border-top: none; border-left: none; border-bottom: none;background-color: #BDBDBD'>NUM</th>"
            strColumnas &= "<th style='width: 4cm;border-right: none; border-top: none; border-left: none; border-bottom: none;background-color: #BDBDBD'>MEMO</th>"
            strColumnas &= "<th style='width: 2.5cm;border-right: none; border-top: none; border-left: none; border-bottom: none;background-color: #BDBDBD'>TERMS</th>"
            strColumnas &= "<th style='width: 2.4cm;border-right: none; border-top: none; border-left: none; border-bottom: none;background-color: #BDBDBD'>ITEM</th>"
            strColumnas &= "<th style='width: 2.5cm;border-right: none; border-top: none; border-left: none; border-bottom: none;background-color: #BDBDBD'>REGION</th>"
            strColumnas &= "<th style='width: 1.4cm;border-right: none; border-top: none; border-left: none; border-bottom: none;background-color: #BDBDBD'>QTY</th>"
            strColumnas &= "<th style='width: 1.4cm;border-right: none; border-top: none; border-left: none; border-bottom: none;background-color: #BDBDBD'>COST PRICE</th>"
            strColumnas &= "<th style='width: 1.4cm;border-right: none; border-top: none; border-left: none; border-bottom: none;background-color: #BDBDBD'>AMOUNT</th>"
            strColumnas &= " </tr> "


        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        Return strColumnas
    End Function

    Private Function SubTotalPurchase(ByVal dblCantidad As Double, ByVal dblTotal As Double) As String
        Dim strTotalRegion As String = STR_VACIO
        Try

            strTotalRegion &= "<tr>"

            strTotalRegion &= "<td colspan='9' style=' border-right: none border-left: none;text-align: right'> TOTAL </td>"
            'Print(f, "<td style=' border-right: none; border-left: none;'> </td>"
            strTotalRegion &= "<td style=' text-align: right'>  " & dblCantidad.ToString(FORMATO_MONEDA) & "  </td>"
            strTotalRegion &= "<td style=' border-right: none; border-left: none;'><br> </td>"
            strTotalRegion &= "<td style='  text-align: right'>  " & dblTotal.ToString(FORMATO_MONEDA) & "   </td>"

            strTotalRegion &= "</tr>"

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        Return strTotalRegion
    End Function

    Private Function TotalGeneralPurchase(ByVal dblCantidad As Double, ByVal dbltotal As Double) As String
        Dim strTotalRegion As String = STR_VACIO
        Try

            strTotalRegion &= "<tr>"
            strTotalRegion &= "<td colspan='9' style=' border-right: none;border-top: none; border-left: none; border-bottom: none;text-align: right;background-color: #BDBDBD'><b> TOTAL </b></td>"
            strTotalRegion &= "<td style=' border-right: none; border-left: none;border-top: none;border-bottom: none; text-align: right;background-color: #BDBDBD; font-family: Tahoma, Arial;font-size: 8pt'> <b> " & dblCantidad.ToString(FORMATO_MONEDA) & "</b>  </td>"
            strTotalRegion &= "<td style=' border-right: none; border-top: none; border-left: none; border-bottom: none;background-color: #BDBDBD'> </td>"
            strTotalRegion &= "<td style=' border-right: none; border-left: none;border-top: none; border-bottom: none; text-align: right;background-color: #BDBDBD;font-family: Tahoma, Arial;font-size: 8pt'> <b> " & dbltotal.ToString(FORMATO_MONEDA) & " </b>   </td>"

            strTotalRegion &= "</tr>"

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        Return strTotalRegion
    End Function

    Public Sub PurchasByVendorCorp(ByVal Finicio As Date, ByVal Ffin As Date, ByVal intEmp As Integer)
        Dim strSQL As String = STR_VACIO
        Dim f As Byte
        Dim strTemp As String = STR_VACIO
        Dim logPrimeraLInea As Boolean = True
        Dim dblSubtotalLBs As Double = INT_CERO
        Dim dblSubtotalAmount As Double = INT_CERO
        Dim dblTotalLBS As Double = INT_CERO
        Dim dblTotalAmount As Double = INT_CERO
        Dim strHTML As String = STR_VACIO
        Dim intGrupo As Integer = NO_FILA
        Dim strGrupo As String = STR_VACIO

        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader
        Try
            strTemp = cFunciones.ArchivoTemporal
            f = FreeFile()
            FileOpen(f, strTemp, OpenMode.Append)

            strSQL = SQLPurchase(intEmp)
            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSQL, CON)
            REA = COM.ExecuteReader
            strHTML &= EncabezadoPurchase(Finicio, Ffin)

            If REA.HasRows Then
                Do While REA.Read
                    If logPrimeraLInea = True Then
                        logPrimeraLInea = False
                        intGrupo = REA.GetInt32("idgroup")
                        strGrupo = REA.GetString("groupo")
                        strHTML &= ColumnasPurchase(strGrupo)
                    Else
                        If intGrupo = REA.GetInt32("idgroup") Then

                        Else

                            strHTML &= SubTotalPurchase(dblSubtotalLBs, dblSubtotalAmount)
                            intGrupo = REA.GetInt32("idgroup")
                            strGrupo = REA.GetString("groupo")
                            strHTML &= ColumnasPurchase(strGrupo)
                            dblSubtotalLBs = INT_CERO
                            dblSubtotalAmount = INT_CERO

                        End If
                    End If
                    '' linea
                    strHTML &= " <tr> "
                    strHTML &= "<td style='  border-top: none;  border-bottom: none;text-align: left'> " & REA.GetString("Empresas") & " </td>"
                    strHTML &= "<td style='  border-top: none;  border-bottom: none;text-align: left'> " & REA.GetString("Proveedor") & " </td>"
                    strHTML &= "<td style='  border-top: none; border-bottom: none'> " & REA.GetDateTime("Fecha").ToString(FORMATO_MYSQL) & "</td>"
                    strHTML &= "<td style='  border-top: none; border-bottom: none'> " & REA.GetString("Fechaemision") & "</td>"
                    strHTML &= "<td style='  border-top: none;  border-bottom: none'> " & REA.GetString("Numero") & "</td>"
                    strHTML &= "<td style='  border-top: none;  border-bottom: none;text-align: left'> " & REA.GetString("Hilo") & " </td>"
                    strHTML &= "<td style='  border-top: none;  border-bottom: none;text-align: left'> " & REA.GetString("Terminos") & " </td>"
                    strHTML &= "<td style='  border-top: none;  border-bottom: none;text-align: left'> " & REA.GetString("Referencia") & " </td>"
                    strHTML &= "<td style='  border-top: none;  border-bottom: none;text-align: left'> " & REA.GetString("Region") & " </td>"
                    strHTML &= "<td style='  border-top: none;  border-bottom: none;text-align: right'> " & REA.GetDouble("Cantidad").ToString(FORMATO_MONEDA) & " </td>"
                    strHTML &= "<td style='  border-top: none;  border-bottom: none;text-align: right'> " & REA.GetDouble("Precio").ToString(FORMATO_MONEDA) & "  </td>"
                    strHTML &= "<td style='  border-top: none;  border-bottom: none;text-align: right'> " & REA.GetDouble("Total").ToString(FORMATO_MONEDA) & " </td>"
                    strHTML &= " </tr> "

                    dblSubtotalLBs = dblSubtotalLBs + REA.GetDouble("Cantidad")
                    dblSubtotalAmount = dblSubtotalAmount + REA.GetDouble("Total")


                    dblTotalLBS = dblTotalLBS + REA.GetDouble("Cantidad")
                    dblTotalAmount = dblTotalAmount + REA.GetDouble("Total")

                Loop

            End If
            strHTML &= SubTotalPurchase(dblSubtotalLBs, dblSubtotalAmount)
            strHTML &= TotalGeneralPurchase(dblTotalLBS, dblTotalAmount)
            Print(f, strHTML)
            Print(f, "</table>")
            Print(f, "<br/>")
            Print(f, "</body>")
            Print(f, "</html>")
            FileClose(f)
            MostarReporte(strTemp)
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

#End Region

#Region "Budget By Year Corp"

    Private Function SqlPresupuestado()
        Dim strSQL As String = STR_VACIO
        Try
            strSQL = " SELECT  r.Padre , g.nombre_Grupo , 
		                SUM(b.Presupuestado_Enero ) preEne,
		                SUM(b.Presupuestado_Febrero  ) preFeb,
		                SUM(b.Presupuestado_Marzo  )preMar,
		                SUM(b.Presupuestado_Abril  )preAbr,
		                SUM(b.Presupuestado_Mayo  )preMay,
		                SUM(b.Presupuestado_Junio  )preJun,
		                SUM(b.Presupuestado_Julio  )preJul,
		                SUM(b.Presupuestado_Agosto  )preAgo,
		                SUM(b.Presupuestado_Septiembre)preSep,
		                SUM(b.Presupuestado_Octubre  )preOct,
		                SUM(b.Presupuestado_Noviembre  )preNov,
		                SUM(b.Presupuestado_Diciembre  )preDic		
		                    FROM " & YarnD & ".Rpt_Plantilla r
	                        LEFT JOIN " & YarnD & ".Budget b ON b.idGrupo = r.idGrupo
	                        LEFT JOIN " & YarnD & ".Grupo g ON g.idGrupo = b.idGrupo AND g.idTipo = 5
	                            WHERE r.idReporte =1
                                GROUP  BY g.idGrupo 
                                ORDER BY r.Linea "

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        Return strSQL
    End Function

    Private Function SqlEjecutado()
        Dim strSQL As String = STR_VACIO
        Try
            strSQL = " SELECT  r.Padre , g.nombre_Grupo , 
		                sum(b.Ejecutado_Enero )ejeEne,
		                sum(b.Ejecutado_Febrero  )ejeFeb,
		                sum(b.Ejecutado_Marzo  )ejeMar,
		                sum(b.Ejecutado_Abril  )ejeAbr,
		                sum(b.Ejecutado_Mayo  )ejeMay,
		                sum(b.Ejecutado_Junio  )ejeJun,
		                sum(b.Ejecutado_Julio  )ejeJul,
		                sum(b.Ejecutado_Agosto  )ejeAgo,
		                sum(b.Ejecutado_Septiembre  )ejeSep,
		                sum(b.Ejecutado_Octubre  )ejeOct,
		                sum(b.Ejecutado_Noviembre  )ejeNov,
		                sum(b.Ejecutado_Diciembre  ) ejeDic		
		                    FROM " & YarnD & ".Rpt_Plantilla r
	                        LEFT JOIN " & YarnD & ".Budget b ON b.idGrupo = r.idGrupo
	                        LEFT JOIN " & YarnD & ".Grupo g ON g.idGrupo = b.idGrupo AND g.idTipo = 5
                                WHERE r.idReporte =1
                                GROUP  BY g.idGrupo 
                                ORDER BY r.Linea "


        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        Return strSQL
    End Function

    Private Function EncabezadoPresupuesto(ByVal Finicio As Date) As String
        Dim strEncabezado As String = STR_VACIO
        Try
            strEncabezado &= "<html>"
            strEncabezado &= "<head>"
            strEncabezado &= "<title>" & "VSxP" & "</title>"
            strEncabezado &= "<style type='text/css'>"
            strEncabezado &= " table {table-layout: fixed; empty-cells: show; border-collapse:collapse}"
            strEncabezado &= " caption {padding: 5px; text-align:left; font-family: Tahoma, Arial;font-size: 8pt}"
            strEncabezado &= " th { border:solid Silver 1px; background-color: #000080; color: White; padding:2px 5px; font-family: Tahoma, Arial;font-size: 7pt}"
            strEncabezado &= " td {text-align:center;border:solid Silver 1px; padding:3px 5px; font-family: Tahoma, Arial;font-size: 7pt}"
            strEncabezado &= " .titulo {font-family: Tahoma, Arial;font-size: 9pt}"
            strEncabezado &= " .encabezado {text-align: left; border: none; width: 3.1cm}"
            strEncabezado &= " .pie {font-family: Tahoma, Arial;font-size: 7pt}"
            strEncabezado &= " .izquierda {text-align:left}"
            strEncabezado &= " .centro {text-align:center}"
            strEncabezado &= " .derecha {text-align:right}"
            strEncabezado &= " .info {text-align:left; border:none}"
            strEncabezado &= " td.numero {text-align:right; mso-number-format:\#\,\#\#0\.00}"
            strEncabezado &= "</style>"
            strEncabezado &= "</head>"
            strEncabezado &= "<body>"

            strEncabezado &= "<span class='titulo'><b>" & Sesion.Empresa & "</b></span><br/><br/>"
            strEncabezado &= "<span class='titulo'><b>" & UCase("BUDGET ") & "</b></span><br/>"
            strEncabezado &= "<span class='pie'> " & Finicio.Year.ToString & "</span>"
            strEncabezado &= "<br/><br/>"

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        Return strEncabezado
    End Function

    Private Function ColumnasPresupuesto() As String
        Dim strColumnas As String = STR_VACIO
        Try
            strColumnas = "<table cellspacing=0> "
            strColumnas &= " <tr> "
            strColumnas &= "<th style= 'width:5cm' > Description </th>"
            strColumnas &= "<th style= 'width:3cm' > JAN </th>"
            strColumnas &= "<th style= 'width:3cm' > FEB  </th>"
            strColumnas &= "<th style= 'width:3cm' > MAR </th>"
            strColumnas &= "<th style= 'width:3cm' > APR </th>"
            strColumnas &= "<th style= 'width:3cm' > MAY </th>"
            strColumnas &= "<th style= 'width:3cm' > JUN </th>"
            strColumnas &= "<th style= 'width:3cm' > JUL </th>"
            strColumnas &= "<th style= 'width:3cm' > AUG </th>"
            strColumnas &= "<th style= 'width:3cm' > SEP </th>"
            strColumnas &= "<th style= 'width:3cm' > OCT </th>"
            strColumnas &= "<th style= 'width:3cm' > NOV </th>"
            strColumnas &= "<th style= 'width:3cm' > DIC </th>"
            strColumnas &= "<th style= 'width:3cm' > TOTAL </th>"
            strColumnas &= "<th style= 'width:3cm' > AVG </th>"
            strColumnas &= " </tr> "
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        Return strColumnas
    End Function

    Private Function LineaCostoLBs() As String
        Dim strHtml As String = STR_VACIO
        Try
            strHtml &= " <tr> "
            strHtml &= "<td> Total Fixed and Variable Costs per Lbs </td>"
            strHtml &= "<td>{ene}</td>"
            strHtml &= "<td>{feb}</td>"
            strHtml &= "<td>{mar}</td>"
            strHtml &= "<td>{abr}</td>"
            strHtml &= "<td>{may}</td>"
            strHtml &= "<td>{jun}</td>"
            strHtml &= "<td>{jul}</td>"
            strHtml &= "<td>{ago}</td>"
            strHtml &= "<td>{sep}</td>"
            strHtml &= "<td>{oct}</td>"
            strHtml &= "<td>{nov}</td>"
            strHtml &= "<td>{dic}</td>"
            strHtml &= "<td>{tot}</td>"
            strHtml &= "<td>{pro}</td>"

            strHtml &= " </tr> "
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        Return strHtml
    End Function

    Private Function SubTotalPresupuesto(ByVal sCategoria As String, ByVal intMeses As Integer, ByVal dblEne As Double, ByVal dblFeb As Double, ByVal dblMar As Double, ByVal dblAbr As Double, ByVal dblMay As Double, ByVal dblJun As Double, ByVal dblJul As Double, ByVal dblAgo As Double, ByVal dblSep As Double, ByVal dblOct As Double, ByVal dblNov As Double, ByVal dblDic As Double) As String
        Dim strTotalRegion As String = STR_VACIO
        Dim dblTotal As Double = 0
        Dim dblPromedio As Double = 0
        Try

            dblTotal = dblEne + dblFeb + dblMar + dblAbr + dblMay + dblJun + dblJul + dblAgo + dblSep + dblOct + dblNov + dblDic
            dblPromedio = dblTotal / intMeses

            strTotalRegion &= "<tr>"
            strTotalRegion &= " <th style= 'background:gray; width:5cm'>  " & sCategoria & "  </th>"
            strTotalRegion &= " <th style= 'background:gray; width:3cm'>  " & dblEne.ToString(FORMATO_MONEDA) & "  </th>"
            strTotalRegion &= " <th style= 'background:gray; width:3cm'>  " & dblFeb.ToString(FORMATO_MONEDA) & "  </th>"
            strTotalRegion &= " <th style= 'background:gray; width:3cm'>  " & dblMar.ToString(FORMATO_MONEDA) & "  </th>"
            strTotalRegion &= " <th style= 'background:gray; width:3cm'>  " & dblAbr.ToString(FORMATO_MONEDA) & "  </th>"
            strTotalRegion &= " <th style= 'background:gray; width:3cm'>  " & dblMay.ToString(FORMATO_MONEDA) & "  </th>"
            strTotalRegion &= " <th style= 'background:gray; width:3cm'>  " & dblJun.ToString(FORMATO_MONEDA) & "  </th>"
            strTotalRegion &= " <th style= 'background:gray; width:3cm'>  " & dblJul.ToString(FORMATO_MONEDA) & "  </th>"
            strTotalRegion &= " <th style= 'background:gray; width:3cm'>  " & dblAgo.ToString(FORMATO_MONEDA) & "  </th>"
            strTotalRegion &= " <th style= 'background:gray; width:3cm'>  " & dblSep.ToString(FORMATO_MONEDA) & "  </th>"
            strTotalRegion &= " <th style= 'background:gray; width:3cm>  " & dblOct.ToString(FORMATO_MONEDA) & "  </th>"
            strTotalRegion &= " <th style= 'background:gray; width:3cm '> " & dblNov.ToString(FORMATO_MONEDA) & " </th>"
            strTotalRegion &= " <th style= 'background:gray; width:3cm'>  " & dblDic.ToString(FORMATO_MONEDA) & "  </th>"
            strTotalRegion &= " <th style= 'background:gray; width:3cm'>  " & dblTotal.ToString(FORMATO_MONEDA) & "  </th>"
            strTotalRegion &= " <th style= 'background:gray; width:3cm'>  " & dblPromedio.ToString(FORMATO_MONEDA) & "  </th>"

            strTotalRegion &= "</tr>"
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        Return strTotalRegion
    End Function

    Private Function TotalGeneralPresupuesto(ByVal sCategoria As String, ByVal intMeses As Integer, ByVal dblEne As Double, ByVal dblFeb As Double, ByVal dblMar As Double, ByVal dblAbr As Double, ByVal dblMay As Double, ByVal dblJun As Double, ByVal dblJul As Double, ByVal dblAgo As Double, ByVal dblSep As Double, ByVal dblOct As Double, ByVal dblNov As Double, ByVal dblDic As Double) As String
        Dim strTotalRegion As String = STR_VACIO
        Dim dblTotal As Double = 0
        Dim dblPromedio As Double = 0
        Try

            dblTotal = dblEne + dblFeb + dblMar + dblAbr + dblMay + dblJun + dblJul + dblAgo + dblSep + dblOct + dblNov + dblDic
            dblPromedio = dblTotal / intMeses

            strTotalRegion &= "<tr>"
            strTotalRegion &= " <th style= 'background:gray; width:5cm'>   TOTAL </th>"
            strTotalRegion &= " <th style= 'background:gray; width:3cm'>  " & dblEne.ToString(FORMATO_MONEDA) & "  </th>"
            strTotalRegion &= " <th style= 'background:gray; width:3cm'>  " & dblFeb.ToString(FORMATO_MONEDA) & "  </th>"
            strTotalRegion &= " <th style= 'background:gray; width:3cm'>  " & dblMar.ToString(FORMATO_MONEDA) & "  </th>"
            strTotalRegion &= " <th style= 'background:gray; width:3cm'>  " & dblAbr.ToString(FORMATO_MONEDA) & "  </th>"
            strTotalRegion &= " <th style= 'background:gray; width:3cm'>  " & dblMay.ToString(FORMATO_MONEDA) & "  </th>"
            strTotalRegion &= " <th style= 'background:gray; width:3cm'>  " & dblJun.ToString(FORMATO_MONEDA) & "  </th>"
            strTotalRegion &= " <th style= 'background:gray; width:3cm'>  " & dblJul.ToString(FORMATO_MONEDA) & "  </th>"
            strTotalRegion &= " <th style= 'background:gray; width:3cm'>  " & dblAgo.ToString(FORMATO_MONEDA) & "  </th>"
            strTotalRegion &= " <th style= 'background:gray; width:3cm'>  " & dblSep.ToString(FORMATO_MONEDA) & "  </th>"
            strTotalRegion &= " <th style= 'background:gray; width:3cm>  " & dblOct.ToString(FORMATO_MONEDA) & "  </th>"
            strTotalRegion &= " <th style= 'background:gray; width:3cm '> " & dblNov.ToString(FORMATO_MONEDA) & " </th>"
            strTotalRegion &= " <th style= 'background:gray; width:3cm'>  " & dblDic.ToString(FORMATO_MONEDA) & "  </th>"
            strTotalRegion &= " <th style= 'background:gray; width:3cm'>  " & dblTotal.ToString(FORMATO_MONEDA) & "  </th>"
            strTotalRegion &= " <th style= 'background:gray; width:3cm'>  " & dblPromedio.ToString(FORMATO_MONEDA) & "  </th>"

            strTotalRegion &= "</tr>"
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        Return strTotalRegion
    End Function

    Public Sub ReportePresupuestoAnual(ByVal dtFechaInicial As Date, ByVal dtFechaFinal As Date, ByVal intTipoRpt As Integer)
        Dim strSQL As String = STR_VACIO
        Dim dblTotalFila As Double
        Dim dblPromedioFila As Double

        Dim f As Byte
        Dim strTemp As String = STR_VACIO
        Dim logPrimeraLInea As Boolean = True

        Dim dblSubtotalEne As Double = INT_CERO
        Dim dblSubtotalFeb As Double = INT_CERO
        Dim dblSubtotalMar As Double = INT_CERO
        Dim dblSubtotalAbr As Double = INT_CERO
        Dim dblSubtotalMay As Double = INT_CERO
        Dim dblSubtotalJun As Double = INT_CERO
        Dim dblSubtotalJul As Double = INT_CERO
        Dim dblSubtotalAgo As Double = INT_CERO
        Dim dblSubtotalSep As Double = INT_CERO
        Dim dblSubtotalOct As Double = INT_CERO
        Dim dblSubtotalNov As Double = INT_CERO
        Dim dblSubtotalDic As Double = INT_CERO

        Dim dblTotalEne As Double = INT_CERO
        Dim dblTotalFeb As Double = INT_CERO
        Dim dblTotalMar As Double = INT_CERO
        Dim dblTotalAbr As Double = INT_CERO
        Dim dblTotalMay As Double = INT_CERO
        Dim dblTotalJun As Double = INT_CERO
        Dim dblTotalJul As Double = INT_CERO
        Dim dblTotalAgo As Double = INT_CERO
        Dim dblTotalSep As Double = INT_CERO
        Dim dblTotalOct As Double = INT_CERO
        Dim dblTotalNov As Double = INT_CERO
        Dim dblTotalDic As Double = INT_CERO

        Dim dblLibrasVendidasene As Double = INT_CERO
        Dim dblLibrasVendidasfeb As Double = INT_CERO
        Dim dblLibrasVendidasmar As Double = INT_CERO
        Dim dblLibrasVendidasabr As Double = INT_CERO
        Dim dblLibrasVendidasmay As Double = INT_CERO
        Dim dblLibrasVendidasjun As Double = INT_CERO
        Dim dblLibrasVendidasjul As Double = INT_CERO
        Dim dblLibrasVendidasago As Double = INT_CERO
        Dim dblLibrasVendidassep As Double = INT_CERO
        Dim dblLibrasVendidasoct As Double = INT_CERO
        Dim dblLibrasVendidasnov As Double = INT_CERO
        Dim dblLibrasVendidasdic As Double = INT_CERO
        Dim dblLibrasVendidastotal As Double = INT_CERO
        Dim dblLibrasVendidaspromedio As Double = INT_CERO

        Dim dblTotal As Double = 0
        Dim dblPromedio As Double = 0


        Dim strHTML As String = STR_VACIO
        Dim intGrupo As String = STR_VACIO
        Dim strGrupo As String = STR_VACIO
        Dim strPrefijo As String = STR_VACIO

        Dim intMeses As Integer
        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader

        strTemp = cFunciones.ArchivoTemporal
        f = FreeFile()
        FileOpen(f, strTemp, OpenMode.Append)

        If intTipoRpt = INT_CERO Then
            strSQL = SqlPresupuestado()
            strPrefijo = "pre" ' PRESUPUESTADO
        ElseIf intTipoRpt = INT_UNO Then
            strSQL = SqlEjecutado()
            strPrefijo = "eje"   ' EJECUTADO
        ElseIf intTipoRpt = 2 Then
            'Integrado
        End If

        intMeses = (dtFechaFinal.Month - dtFechaInicial.Month) + 1
        MyCnn.CONECTAR = strConexion
        COM = New MySqlCommand(strSQL, CON)
        REA = COM.ExecuteReader
        strHTML &= EncabezadoPresupuesto(dtFechaInicial)
        strHTML &= ColumnasPresupuesto()
        If REA.HasRows Then
            Do While REA.Read
                If logPrimeraLInea = True Then
                    logPrimeraLInea = False
                    intGrupo = REA.GetString("padre")
                    strGrupo = "Subtotal"
                Else
                    If intGrupo = REA.GetString("padre") Then

                    Else

                        strHTML &= SubTotalPresupuesto(strGrupo, intMeses, dblSubtotalEne, dblSubtotalFeb, dblSubtotalMar, dblSubtotalAbr, dblSubtotalMay, dblSubtotalJun, dblSubtotalJul, dblSubtotalAgo, dblSubtotalSep, dblSubtotalOct, dblSubtotalNov, dblSubtotalDic)
                        intGrupo = REA.GetString("padre")
                        strGrupo = "Subtotal"

                        dblSubtotalEne = INT_CERO
                        dblSubtotalFeb = INT_CERO
                        dblSubtotalMar = INT_CERO
                        dblSubtotalAbr = INT_CERO
                        dblSubtotalMay = INT_CERO
                        dblSubtotalJun = INT_CERO
                        dblSubtotalJul = INT_CERO
                        dblSubtotalAgo = INT_CERO
                        dblSubtotalSep = INT_CERO
                        dblSubtotalOct = INT_CERO
                        dblSubtotalNov = INT_CERO
                        dblSubtotalDic = INT_CERO

                    End If
                End If
                '' linea
                dblTotalFila = 0
                dblTotalFila = REA.GetDouble(strPrefijo & "Ene") + REA.GetDouble(strPrefijo & "Feb") + REA.GetDouble(strPrefijo & "Mar") + REA.GetDouble(strPrefijo & "Abr") + REA.GetDouble(strPrefijo & "May") + REA.GetDouble(strPrefijo & "Jun") + REA.GetDouble(strPrefijo & "Jul") + REA.GetDouble(strPrefijo & "Ago") + REA.GetDouble(strPrefijo & "Sep") + REA.GetDouble(strPrefijo & "Oct") + REA.GetDouble(strPrefijo & "Nov") + REA.GetDouble(strPrefijo & "Dic")
                dblPromedioFila = dblTotalFila / intMeses

                If REA.GetString("Padre") = "SALES" Then
                    dblLibrasVendidasene = REA.GetDouble("PreEne") ' capturar libras vendidas
                    dblLibrasVendidasfeb = REA.GetDouble("PreFeb") ' capturar libras vendidas
                    dblLibrasVendidasmar = REA.GetDouble("PreMar") ' capturar libras vendidas
                    dblLibrasVendidasabr = REA.GetDouble("PreAbr") ' capturar libras vendidas
                    dblLibrasVendidasmay = REA.GetDouble("PreMay") ' capturar libras vendidas
                    dblLibrasVendidasjun = REA.GetDouble("PreJun") ' capturar libras vendidas
                    dblLibrasVendidasjul = REA.GetDouble("PreJul") ' capturar libras vendidas
                    dblLibrasVendidasago = REA.GetDouble("PreAgo") ' capturar libras vendidas
                    dblLibrasVendidassep = REA.GetDouble("PreSep") ' capturar libras vendidas
                    dblLibrasVendidasoct = REA.GetDouble("PreOct") ' capturar libras vendidas
                    dblLibrasVendidasnov = REA.GetDouble("PreNov") ' capturar libras vendidas
                    dblLibrasVendidasdic = REA.GetDouble("PreDic") ' capturar libras vendidas

                    dblLibrasVendidastotal = dblLibrasVendidasene + dblLibrasVendidasfeb + dblLibrasVendidasmar + dblLibrasVendidasabr + dblLibrasVendidasmay + dblLibrasVendidasjun + dblLibrasVendidasjul + dblLibrasVendidasago + dblLibrasVendidassep + dblLibrasVendidasoct + dblLibrasVendidasnov + dblLibrasVendidasdic
                    dblLibrasVendidaspromedio = dblLibrasVendidastotal / intMeses
                End If
                If REA.GetString("Padre") = "COST" Then
                    strHTML &= LineaCostoLBs() ' imprimir linea de costo
                End If
                strHTML &= " <tr> "
                strHTML &= "<td>" & REA.GetString("nombre_Grupo") & "</td>"
                strHTML &= "<td>" & REA.GetDouble(strPrefijo & "Ene").ToString(FORMATO_MONEDA) & "</td>"
                strHTML &= "<td>" & REA.GetDouble(strPrefijo & "Feb").ToString(FORMATO_MONEDA) & "</td>"
                strHTML &= "<td>" & REA.GetDouble(strPrefijo & "Mar").ToString(FORMATO_MONEDA) & "</td>"
                strHTML &= "<td>" & REA.GetDouble(strPrefijo & "Abr").ToString(FORMATO_MONEDA) & "</td>"
                strHTML &= "<td>" & REA.GetDouble(strPrefijo & "May").ToString(FORMATO_MONEDA) & "</td>"
                strHTML &= "<td>" & REA.GetDouble(strPrefijo & "Jun").ToString(FORMATO_MONEDA) & "</td>"
                strHTML &= "<td>" & REA.GetDouble(strPrefijo & "Jul").ToString(FORMATO_MONEDA) & "</td>"
                strHTML &= "<td>" & REA.GetDouble(strPrefijo & "Ago").ToString(FORMATO_MONEDA) & "</td>"

                strHTML &= "<td>" & REA.GetDouble(strPrefijo & "Sep").ToString(FORMATO_MONEDA) & "</td>"
                strHTML &= "<td>" & REA.GetDouble(strPrefijo & "Oct").ToString(FORMATO_MONEDA) & "</td>"
                strHTML &= "<td>" & REA.GetDouble(strPrefijo & "Nov").ToString(FORMATO_MONEDA) & "</td>"
                strHTML &= "<td>" & REA.GetDouble(strPrefijo & "Dic").ToString(FORMATO_MONEDA) & "</td>"
                strHTML &= "<td>" & dblTotalFila.ToString(FORMATO_MONEDA) & "</td>"
                strHTML &= "<td>" & dblPromedioFila.ToString(FORMATO_MONEDA) & "</td>"
                strHTML &= " </tr> "

                dblSubtotalEne = dblSubtotalEne + REA.GetDouble(strPrefijo & "Ene")
                dblSubtotalFeb = dblSubtotalFeb + REA.GetDouble(strPrefijo & "Feb")
                dblSubtotalMar = dblSubtotalMar + REA.GetDouble(strPrefijo & "Mar")
                dblSubtotalAbr = dblSubtotalAbr + REA.GetDouble(strPrefijo & "Abr")
                dblSubtotalMay = dblSubtotalMay + REA.GetDouble(strPrefijo & "May")
                dblSubtotalJun = dblSubtotalJun + REA.GetDouble(strPrefijo & "Jun")
                dblSubtotalJul = dblSubtotalJul + REA.GetDouble(strPrefijo & "Jul")
                dblSubtotalAgo = dblSubtotalAgo + REA.GetDouble(strPrefijo & "Ago")
                dblSubtotalSep = dblSubtotalSep + REA.GetDouble(strPrefijo & "Sep")
                dblSubtotalOct = dblSubtotalOct + REA.GetDouble(strPrefijo & "Oct")
                dblSubtotalNov = dblSubtotalNov + REA.GetDouble(strPrefijo & "Nov")
                dblSubtotalDic = dblSubtotalDic + REA.GetDouble(strPrefijo & "Dic")

                dblTotalEne = dblTotalEne + REA.GetDouble(strPrefijo & "Ene")
                dblTotalFeb = dblTotalFeb + REA.GetDouble(strPrefijo & "Feb")
                dblTotalMar = dblTotalMar + REA.GetDouble(strPrefijo & "Mar")
                dblTotalAbr = dblTotalAbr + REA.GetDouble(strPrefijo & "Abr")
                dblTotalMay = dblTotalMay + REA.GetDouble(strPrefijo & "May")
                dblTotalJun = dblTotalJun + REA.GetDouble(strPrefijo & "Jun")
                dblTotalJul = dblTotalJun + REA.GetDouble(strPrefijo & "Jul")
                dblTotalAgo = dblTotalAgo + REA.GetDouble(strPrefijo & "Ago")
                dblTotalSep = dblTotalSep + REA.GetDouble(strPrefijo & "Sep")
                dblTotalOct = dblTotalOct + REA.GetDouble(strPrefijo & "Oct")
                dblTotalNov = dblTotalNov + REA.GetDouble(strPrefijo & "Nov")
                dblTotalDic = dblTotalDic + REA.GetDouble(strPrefijo & "Dic")
            Loop

        End If
        strHTML &= SubTotalPresupuesto(strGrupo, intMeses, dblSubtotalEne, dblSubtotalFeb, dblSubtotalMar, dblSubtotalAbr, dblSubtotalMay, dblSubtotalJun, dblSubtotalJul, dblSubtotalAgo, dblSubtotalSep, dblSubtotalOct, dblSubtotalNov, dblSubtotalDic)
        strHTML &= TotalGeneralPresupuesto(strGrupo, intMeses, dblTotalEne, dblTotalFeb, dblTotalMar, dblTotalAbr, dblTotalMay, dblTotalJun, dblTotalJul, dblTotalAgo, dblTotalSep, dblTotalOct, dblTotalNov, dblTotalDic)

        strHTML = strHTML.Replace("{ene}", (dblTotalEne / dblLibrasVendidasene).ToString(FORMATO_MONEDA))
        strHTML = strHTML.Replace("{feb}", (dblTotalFeb / dblLibrasVendidasfeb).ToString(FORMATO_MONEDA))
        strHTML = strHTML.Replace("{mar}", (dblTotalMar / dblLibrasVendidasmar).ToString(FORMATO_MONEDA))
        strHTML = strHTML.Replace("{abr}", (dblTotalAbr / dblLibrasVendidasabr).ToString(FORMATO_MONEDA))
        strHTML = strHTML.Replace("{may}", (dblTotalMay / dblLibrasVendidasmay).ToString(FORMATO_MONEDA))
        strHTML = strHTML.Replace("{jun}", (dblTotalJun / dblLibrasVendidasjun).ToString(FORMATO_MONEDA))
        strHTML = strHTML.Replace("{jul}", (dblTotalJul / dblLibrasVendidasjul).ToString(FORMATO_MONEDA))
        strHTML = strHTML.Replace("{ago}", (dblTotalAgo / dblLibrasVendidasago).ToString(FORMATO_MONEDA))
        strHTML = strHTML.Replace("{sep}", (dblTotalSep / dblLibrasVendidassep).ToString(FORMATO_MONEDA))
        strHTML = strHTML.Replace("{oct}", (dblTotalOct / dblLibrasVendidasoct).ToString(FORMATO_MONEDA))
        strHTML = strHTML.Replace("{nov}", (dblTotalNov / dblLibrasVendidasnov).ToString(FORMATO_MONEDA))
        strHTML = strHTML.Replace("{dic}", (dblTotalDic / dblLibrasVendidasdic).ToString(FORMATO_MONEDA))

        dblTotal = dblTotalEne + dblTotalFeb + dblTotalMar + dblTotalAbr + dblTotalMay + dblTotalJun + dblTotalJul + dblTotalAgo + dblTotalSep + dblTotalOct + dblTotalNov + dblTotalDic
        dblPromedio = dblTotal / intMeses
        strHTML = strHTML.Replace("{tot}", (dblTotal / dblLibrasVendidasdic).ToString(FORMATO_MONEDA))
        strHTML = strHTML.Replace("{pro}", (dblPromedio / dblLibrasVendidasdic).ToString(FORMATO_MONEDA))

        Print(f, strHTML)
        Print(f, "</table>")
        Print(f, "<br/>")
        Print(f, "</body>")
        Print(f, "</html>")
        FileClose(f)
        MostarReporte(strTemp)

    End Sub

#End Region

#Region "Integrated Budget"

    Private Function SQLPresupuestadoEjecutado(ByVal finicio As Date, ByVal ffin As Date) As String
        Dim strsql As String = STR_VACIO

        Try
            strsql = " SELECT  r.Padre , g.nombre_Grupo , 
		        		SUM(b.Presupuestado_Enero ) PreEne,
		                SUM(b.Presupuestado_Febrero  )PreFeb,
		                SUM(b.Presupuestado_Marzo  )PreMar,
		                SUM(b.Presupuestado_Abril  )PreAbr,
		                SUM(b.Presupuestado_Mayo  )PreMay,
		                SUM(b.Presupuestado_Junio  )PreJun,
		                SUM(b.Presupuestado_Julio  )PreJul,
		                SUM(b.Presupuestado_Agosto  )PreAgo,
		                SUM(b.Presupuestado_Septiembre  )PreSep,
		                SUM(b.Presupuestado_Octubre  )PreOct,
		                SUM(b.Presupuestado_Noviembre  )PreNov,
		                SUM(b.Presupuestado_Diciembre  )PreDic ,
		                sum(b.Ejecutado_Enero )EjeEne,
		                sum(b.Ejecutado_Febrero  )EjeFeb,
		                sum(b.Ejecutado_Marzo  )EjeMar,
		                sum(b.Ejecutado_Abril  )EjeAbr,
		                sum(b.Ejecutado_Mayo  )EjeMay,
		                sum(b.Ejecutado_Junio  )EjeJun,
		                sum(b.Ejecutado_Julio  )EjeJul,
		                sum(b.Ejecutado_Agosto  )EjeAgo,
		                sum(b.Ejecutado_Septiembre  )EjeSep,
		                sum(b.Ejecutado_Octubre  )EjeOct,
		                sum(b.Ejecutado_Noviembre  )EjeNov,
		                sum(b.Ejecutado_Diciembre  )EjeDic
		               FROM " & YarnD & ".Rpt_Plantilla r
	                    LEFT JOIN " & YarnD & ".Budget b ON b.idGrupo = r.idGrupo
	                    LEFT JOIN " & YarnD & ".Grupo g ON g.idGrupo = b.idGrupo AND g.idTipo = 5
                WHERE r.idReporte =1
                GROUP  BY g.idGrupo 
                ORDER BY r.Linea  "


            strsql = strsql.Replace("{empresa}", Sesion.IdEmpresa)

            strsql = strsql.Replace("ORDER BY r.linea", STR_VACIO)
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        Return strsql
    End Function

    Private Function EncabezadoPresupuestoIntegrado(ByVal Finicio As Date) As String
        Dim strEncabezado As String = STR_VACIO
        Try
            strEncabezado &= "<html>"
            strEncabezado &= "<head>"
            strEncabezado &= "<title>" & "VSxP" & "</title>"
            strEncabezado &= "<style type='text/css'>"
            strEncabezado &= " table {table-layout: fixed; empty-cells: show; border-collapse:collapse}"
            strEncabezado &= " caption {padding: 5px; text-align:left; font-family: Tahoma, Arial;font-size: 8pt}"
            strEncabezado &= " th { border:solid Silver 1px; background-color: #000080; color: White; padding:2px 5px; font-family: Tahoma, Arial;font-size: 7pt}"
            strEncabezado &= " td {text-align:center;border:solid Silver 1px; padding:3px 5px; font-family: Tahoma, Arial;font-size: 7pt}"
            strEncabezado &= " .titulo {font-family: Tahoma, Arial;font-size: 9pt}"
            strEncabezado &= " .encabezado {text-align: left; border: none; width: 3.1cm}"
            strEncabezado &= " .pie {font-family: Tahoma, Arial;font-size: 7pt}"
            strEncabezado &= " .izquierda {text-align:left}"
            strEncabezado &= " .centro {text-align:center}"
            strEncabezado &= " .derecha {text-align:right}"
            strEncabezado &= " .info {text-align:left; border:none}"
            strEncabezado &= " td.numero {text-align:right; mso-number-format:\#\,\#\#0\.00}"
            strEncabezado &= "</style>"
            strEncabezado &= "</head>"
            strEncabezado &= "<body>"

            strEncabezado &= "<span class='titulo'><b>" & Sesion.Empresa & "</b></span><br/><br/>"
            strEncabezado &= "<span class='titulo'><b>" & UCase("BUDGET CORP ") & "</b></span><br/>"
            strEncabezado &= "<span class='pie'> " & Finicio.Year.ToString & "</span>"
            strEncabezado &= "<br/><br/>"

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        Return strEncabezado
    End Function

    Private Function ColumnasPresupuestoIntegrado() As String
        Dim strColumnas As String = STR_VACIO
        Try
            strColumnas = "<table border> "
            strColumnas &= " <tr> "
            strColumnas &= "<th rowspan='2' width='200' > Description </th>"
            strColumnas &= "<th colspan='3'   width='200' > JAN </th>"
            strColumnas &= "<th colspan='3'  width='200'> FEB  </th>"
            strColumnas &= "<th colspan='3'  width='200'> MAR </th>"
            strColumnas &= "<th colspan='3'  width='200'> APR </th>"
            strColumnas &= "<th colspan='3'  width='200'> MAY </th>"
            strColumnas &= "<th colspan='3'  width='200'> JUN </th>"
            strColumnas &= "<th colspan='3'  width='200'> JUL </th>"
            strColumnas &= "<th colspan='3'  width='200'> AUG </th>"
            strColumnas &= "<th colspan='3'  width='200'> SEP </th>"
            strColumnas &= "<th colspan='3'  width='200'> OCT </th>"
            strColumnas &= "<th colspan='3'  width='200'> NOV </th>"
            strColumnas &= "<th colspan='3'  width='200'> DIC </th>"
            strColumnas &= "<th colspan='3'  width='200'> TOTAL </th>"
            strColumnas &= "<th colspan='3'  width='200'> AVG </th>"
            strColumnas &= " </tr> "
            strColumnas &= " <tr> "

            strColumnas &= "<th > Budgeted </th>"
            strColumnas &= "<th > Spent  </th>"
            strColumnas &= "<th > Difference </th>"

            strColumnas &= "<th > Budgeted </th>"
            strColumnas &= "<th  > Spent  </th>"
            strColumnas &= "<th > Difference </th>"

            strColumnas &= "<th style= 'width:2cm' > Budgeted </th>"
            strColumnas &= "<th style= 'width:2cm' > Spent  </th>"
            strColumnas &= "<th style= 'width:2cm' > Difference </th>"

            strColumnas &= "<th style= 'width:2cm' > Budgeted </th>"
            strColumnas &= "<th style= 'width:2cm' > Spent  </th>"
            strColumnas &= "<th style= 'width:2cm' > Difference </th>"

            strColumnas &= "<th style= 'width:2cm' > Budgeted </th>"
            strColumnas &= "<th style= 'width:2cm' > Spent  </th>"
            strColumnas &= "<th style= 'width:2cm' > Difference </th>"

            strColumnas &= "<th style= 'width:2cm' > Budgeted </th>"
            strColumnas &= "<th style= 'width:2cm' > Spent  </th>"
            strColumnas &= "<th style= 'width:2cm' > Difference </th>"

            strColumnas &= "<th style= 'width:2cm' > Budgeted </th>"
            strColumnas &= "<th style= 'width:2cm' > Spent  </th>"
            strColumnas &= "<th style= 'width:2cm' > Difference </th>"

            strColumnas &= "<th style= 'width:2cm' > Budgeted </th>"
            strColumnas &= "<th style= 'width:2cm' > Spent  </th>"
            strColumnas &= "<th style= 'width:2cm' > Difference </th>"

            strColumnas &= "<th style= 'width:2cm' > Budgeted </th>"
            strColumnas &= "<th style= 'width:2cm' > Spent  </th>"
            strColumnas &= "<th style= 'width:2cm' > Difference </th>"

            strColumnas &= "<th style= 'width:2cm' > Budgeted </th>"
            strColumnas &= "<th style= 'width:2cm' > Spent  </th>"
            strColumnas &= "<th style= 'width:2cm' > Difference </th>"

            strColumnas &= "<th style= 'width:2cm' > Budgeted </th>"
            strColumnas &= "<th style= 'width:2cm' > Spent  </th>"
            strColumnas &= "<th style= 'width:2cm' > Difference </th>"

            strColumnas &= "<th style= 'width:2cm' > Budgeted </th>"
            strColumnas &= "<th style= 'width:2cm' > Spent  </th>"
            strColumnas &= "<th style= 'width:2cm' > Difference </th>"

            strColumnas &= "<th style= 'width:2cm' > Budgeted </th>"
            strColumnas &= "<th style= 'width:2cm' > Spent  </th>"
            strColumnas &= "<th style= 'width:2cm' > Difference </th>"

            strColumnas &= "<th style= 'width:2cm' > Budgeted </th>"
            strColumnas &= "<th style= 'width:2cm' > Spent  </th>"
            strColumnas &= "<th style= 'width:2cm' > Difference </th>"

            strColumnas &= " </tr> "
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        Return strColumnas
    End Function

    Private Function SubTotalPresupuestoIntegrado(ByVal sCategoria As String, ByVal intMeses As Integer, ByVal dblEne As Double, ByVal dblFeb As Double, ByVal dblMar As Double, ByVal dblAbr As Double, ByVal dblMay As Double, ByVal dblJun As Double, ByVal dblJul As Double, ByVal dblAgo As Double, ByVal dblSep As Double, ByVal dblOct As Double, ByVal dblNov As Double, ByVal dblDic As Double, ByVal dblEEne As Double, ByVal dblEFeb As Double, ByVal dblEMar As Double, ByVal dblEAbr As Double, ByVal dblEMay As Double, ByVal dblEJun As Double, ByVal dblEJul As Double, ByVal dblEAgo As Double, ByVal dblESep As Double, ByVal dblEOct As Double, ByVal dblENov As Double, ByVal dblEDic As Double) As String
        Dim strTotalRegion As String = STR_VACIO
        Dim dblTotalPresupuestado As Double = 0
        Dim dblTotalEjecutado As Double = 0
        Dim dblPromedioPresupuestado As Double = 0
        Dim dblPromedioEjecutado As Double = 0
        Try

            dblTotalPresupuestado = dblEne + dblFeb + dblMar + dblAbr + dblMay + dblJun + dblJul + dblAgo + dblSep + dblOct + dblNov + dblDic
            dblPromedioPresupuestado = dblTotalPresupuestado / intMeses

            dblTotalEjecutado = dblEEne + dblEFeb + dblEMar + dblEAbr + dblEMay + dblEJun + dblEJul + dblEAgo + dblESep + dblEOct + dblENov + dblEDic
            dblPromedioEjecutado = dblTotalEjecutado / intMeses

            strTotalRegion &= " <tr> "
            strTotalRegion &= "<th style= 'background:gray; 'width:2cm' > " & sCategoria & " </th>"
            strTotalRegion &= "<th style= 'background:gray; 'width:2cm' > " & dblEne.ToString(FORMATO_MONEDA) & " </th>"
            strTotalRegion &= "<th style= 'background:gray; 'width:2cm' > " & dblEEne.ToString(FORMATO_MONEDA) & "  </th>"
            strTotalRegion &= "<th style= 'background:gray; 'width:2cm' > " & (dblEne - dblEEne).ToString(FORMATO_MONEDA) & " </th>"

            strTotalRegion &= "<th style= 'background:gray; 'width:2cm' > " & dblFeb.ToString(FORMATO_MONEDA) & " </th>"
            strTotalRegion &= "<th style= 'background:gray; 'width:2cm' > " & dblEFeb.ToString(FORMATO_MONEDA) & "  </th>"
            strTotalRegion &= "<th style= 'background:gray; 'width:2cm' > " & (dblFeb - dblEFeb).ToString(FORMATO_MONEDA) & " </th>"

            strTotalRegion &= "<th style= 'background:gray; 'width:2cm' > " & dblMar.ToString(FORMATO_MONEDA) & " </th>"
            strTotalRegion &= "<th style= 'background:gray; 'width:2cm' > " & dblEMar.ToString(FORMATO_MONEDA) & "  </th>"
            strTotalRegion &= "<th style= 'background:gray; 'width:2cm' > " & (dblMar - dblEMar).ToString(FORMATO_MONEDA) & " </th>"

            strTotalRegion &= "<th style= 'background:gray; 'width:2cm' > " & dblAbr.ToString(FORMATO_MONEDA) & " </th>"
            strTotalRegion &= "<th style= 'background:gray; 'width:2cm' > " & dblEAbr.ToString(FORMATO_MONEDA) & "  </th>"
            strTotalRegion &= "<th style= 'background:gray; 'width:2cm' > " & (dblAbr - dblEAbr).ToString(FORMATO_MONEDA) & " </th>"

            strTotalRegion &= "<th style= 'background:gray; 'width:2cm' > " & dblMay.ToString(FORMATO_MONEDA) & " </th>"
            strTotalRegion &= "<th style= 'background:gray; 'width:2cm' > " & dblEMay.ToString(FORMATO_MONEDA) & "  </th>"
            strTotalRegion &= "<th style= 'background:gray; 'width:2cm' > " & (dblMay - dblEMay).ToString(FORMATO_MONEDA) & " </th>"

            strTotalRegion &= "<th style= 'background:gray; 'width:2cm' > " & dblJun.ToString(FORMATO_MONEDA) & " </th>"
            strTotalRegion &= "<th style= 'background:gray; 'width:2cm' > " & dblEJun.ToString(FORMATO_MONEDA) & "  </th>"
            strTotalRegion &= "<th style= 'background:gray; 'width:2cm' > " & (dblJun - dblEJun).ToString(FORMATO_MONEDA) & " </th>"

            strTotalRegion &= "<th style= 'background:gray; 'width:2cm' > " & dblJul.ToString(FORMATO_MONEDA) & " </th>"
            strTotalRegion &= "<th style= 'background:gray; 'width:2cm' > " & dblEJul.ToString(FORMATO_MONEDA) & "  </th>"
            strTotalRegion &= "<th style= 'background:gray; 'width:2cm' > " & (dblJul - dblEJul).ToString(FORMATO_MONEDA) & " </th>"

            strTotalRegion &= "<th style= 'background:gray; 'width:2cm' > " & dblAgo.ToString(FORMATO_MONEDA) & " </th>"
            strTotalRegion &= "<th style= 'background:gray; 'width:2cm' > " & dblEAgo.ToString(FORMATO_MONEDA) & "  </th>"
            strTotalRegion &= "<th style= 'background:gray; 'width:2cm' > " & (dblAgo - dblEAgo).ToString(FORMATO_MONEDA) & " </th>"

            strTotalRegion &= "<th style= 'background:gray; 'width:2cm' > " & dblSep.ToString(FORMATO_MONEDA) & " </th>"
            strTotalRegion &= "<th style= 'background:gray; 'width:2cm' > " & dblESep.ToString(FORMATO_MONEDA) & "  </th>"
            strTotalRegion &= "<th style= 'background:gray; 'width:2cm' > " & (dblSep - dblESep).ToString(FORMATO_MONEDA) & " </th>"

            strTotalRegion &= "<th style= 'background:gray; 'width:2cm' > " & dblOct.ToString(FORMATO_MONEDA) & " </th>"
            strTotalRegion &= "<th style= 'background:gray; 'width:2cm' > " & dblEOct.ToString(FORMATO_MONEDA) & "  </th>"
            strTotalRegion &= "<th style= 'background:gray; 'width:2cm' > " & (dblOct - dblEOct).ToString(FORMATO_MONEDA) & " </th>"

            strTotalRegion &= "<th style= 'background:gray; 'width:2cm' > " & dblNov.ToString(FORMATO_MONEDA) & " </th>"
            strTotalRegion &= "<th style= 'background:gray; 'width:2cm' > " & dblENov.ToString(FORMATO_MONEDA) & "  </th>"
            strTotalRegion &= "<th style= 'background:gray; 'width:2cm' > " & (dblNov - dblENov).ToString(FORMATO_MONEDA) & " </th>"

            strTotalRegion &= "<th style= 'background:gray; 'width:2cm' > " & dblDic.ToString(FORMATO_MONEDA) & " </th>"
            strTotalRegion &= "<th style= 'background:gray; 'width:2cm' > " & dblEDic.ToString(FORMATO_MONEDA) & "  </th>"
            strTotalRegion &= "<th style= 'background:gray; 'width:2cm' > " & (dblDic - dblEDic).ToString(FORMATO_MONEDA) & " </th>"

            strTotalRegion &= "<th style= 'background:gray; 'width:2cm' > " & dblTotalPresupuestado.ToString(FORMATO_MONEDA) & " </th>"
            strTotalRegion &= "<th style= 'background:gray; 'width:2cm' > " & dblTotalEjecutado.ToString(FORMATO_MONEDA) & "  </th>"
            strTotalRegion &= "<th style= 'background:gray; 'width:2cm' > " & (dblTotalPresupuestado - dblTotalEjecutado).ToString(FORMATO_MONEDA) & " </th>"

            strTotalRegion &= "<th style= 'background:gray; 'width:2cm' > " & dblPromedioPresupuestado.ToString(FORMATO_MONEDA) & " </th>"
            strTotalRegion &= "<th style= 'background:gray; 'width:2cm' > " & dblPromedioEjecutado.ToString(FORMATO_MONEDA) & "  </th>"
            strTotalRegion &= "<th style= 'background:gray; 'width:2cm' > " & (dblPromedioPresupuestado - dblPromedioEjecutado).ToString(FORMATO_MONEDA) & " </th>"

            strTotalRegion &= " </tr> "
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        Return strTotalRegion
    End Function

    Private Function TotalPresupuestoIntegrado(ByVal sCategoria As String, ByVal intMeses As Integer, ByVal dblEne As Double, ByVal dblFeb As Double, ByVal dblMar As Double, ByVal dblAbr As Double, ByVal dblMay As Double, ByVal dblJun As Double, ByVal dblJul As Double, ByVal dblAgo As Double, ByVal dblSep As Double, ByVal dblOct As Double, ByVal dblNov As Double, ByVal dblDic As Double, ByVal dblEEne As Double, ByVal dblEFeb As Double, ByVal dblEMar As Double, ByVal dblEAbr As Double, ByVal dblEMay As Double, ByVal dblEJun As Double, ByVal dblEJul As Double, ByVal dblEAgo As Double, ByVal dblESep As Double, ByVal dblEOct As Double, ByVal dblENov As Double, ByVal dblEDic As Double) As String
        Dim strTotalRegion As String = STR_VACIO
        Dim dblTotalPresupuestado As Double = 0
        Dim dblTotalEjecutado As Double = 0
        Dim dblPromedioPresupuestado As Double = 0
        Dim dblPromedioEjecutado As Double = 0
        Try

            dblTotalPresupuestado = dblEne + dblFeb + dblMar + dblAbr + dblMay + dblJun + dblJul + dblAgo + dblSep + dblOct + dblNov + dblDic
            dblPromedioPresupuestado = dblTotalPresupuestado / intMeses

            dblTotalEjecutado = dblEEne + dblEFeb + dblEMar + dblEAbr + dblEMay + dblEJun + dblEJul + dblEAgo + dblESep + dblEOct + dblENov + dblEDic
            dblPromedioEjecutado = dblTotalEjecutado / intMeses

            strTotalRegion &= " <tr> "
            strTotalRegion &= "<th style= 'background:gray; 'width:2cm' > " & "TOTAL" & " </th>"
            strTotalRegion &= "<th style= 'background:gray; 'width:2cm' > " & dblEne.ToString(FORMATO_MONEDA) & " </th>"
            strTotalRegion &= "<th style= 'background:gray; 'width:2cm' > " & dblEEne.ToString(FORMATO_MONEDA) & "  </th>"
            strTotalRegion &= "<th style= 'background:gray; 'width:2cm' > " & (dblEne - dblEEne).ToString(FORMATO_MONEDA) & " </th>"

            strTotalRegion &= "<th style= 'background:gray; 'width:2cm' > " & dblFeb.ToString(FORMATO_MONEDA) & " </th>"
            strTotalRegion &= "<th style= 'background:gray; 'width:2cm' > " & dblEFeb.ToString(FORMATO_MONEDA) & "  </th>"
            strTotalRegion &= "<th style= 'background:gray; 'width:2cm' > " & (dblFeb - dblEFeb).ToString(FORMATO_MONEDA) & " </th>"

            strTotalRegion &= "<th style= 'background:gray; 'width:2cm' > " & dblMar.ToString(FORMATO_MONEDA) & " </th>"
            strTotalRegion &= "<th style= 'background:gray; 'width:2cm' > " & dblEMar.ToString(FORMATO_MONEDA) & "  </th>"
            strTotalRegion &= "<th style= 'background:gray; 'width:2cm' > " & (dblMar - dblEMar).ToString(FORMATO_MONEDA) & " </th>"

            strTotalRegion &= "<th style= 'background:gray; 'width:2cm' > " & dblAbr.ToString(FORMATO_MONEDA) & " </th>"
            strTotalRegion &= "<th style= 'background:gray; 'width:2cm' > " & dblEAbr.ToString(FORMATO_MONEDA) & "  </th>"
            strTotalRegion &= "<th style= 'background:gray; 'width:2cm' > " & (dblAbr - dblEAbr).ToString(FORMATO_MONEDA) & " </th>"

            strTotalRegion &= "<th style= 'background:gray; 'width:2cm' > " & dblMay.ToString(FORMATO_MONEDA) & " </th>"
            strTotalRegion &= "<th style= 'background:gray; 'width:2cm' > " & dblEMay.ToString(FORMATO_MONEDA) & "  </th>"
            strTotalRegion &= "<th style= 'background:gray; 'width:2cm' > " & (dblMay - dblEMay).ToString(FORMATO_MONEDA) & " </th>"

            strTotalRegion &= "<th style= 'background:gray; 'width:2cm' > " & dblJun.ToString(FORMATO_MONEDA) & " </th>"
            strTotalRegion &= "<th style= 'background:gray; 'width:2cm' > " & dblEJun.ToString(FORMATO_MONEDA) & "  </th>"
            strTotalRegion &= "<th style= 'background:gray; 'width:2cm' > " & (dblJun - dblEJun).ToString(FORMATO_MONEDA) & " </th>"

            strTotalRegion &= "<th style= 'background:gray; 'width:2cm' > " & dblJul.ToString(FORMATO_MONEDA) & " </th>"
            strTotalRegion &= "<th style= 'background:gray; 'width:2cm' > " & dblEJul.ToString(FORMATO_MONEDA) & "  </th>"
            strTotalRegion &= "<th style= 'background:gray; 'width:2cm' > " & (dblJul - dblEJul).ToString(FORMATO_MONEDA) & " </th>"

            strTotalRegion &= "<th style= 'background:gray; 'width:2cm' > " & dblAgo.ToString(FORMATO_MONEDA) & " </th>"
            strTotalRegion &= "<th style= 'background:gray; 'width:2cm' > " & dblEAgo.ToString(FORMATO_MONEDA) & "  </th>"
            strTotalRegion &= "<th style= 'background:gray; 'width:2cm' > " & (dblAgo - dblEAgo).ToString(FORMATO_MONEDA) & " </th>"

            strTotalRegion &= "<th style= 'background:gray; 'width:2cm' > " & dblSep.ToString(FORMATO_MONEDA) & " </th>"
            strTotalRegion &= "<th style= 'background:gray; 'width:2cm' > " & dblESep.ToString(FORMATO_MONEDA) & "  </th>"
            strTotalRegion &= "<th style= 'background:gray; 'width:2cm' > " & (dblSep - dblESep).ToString(FORMATO_MONEDA) & " </th>"

            strTotalRegion &= "<th style= 'background:gray; 'width:2cm' > " & dblOct.ToString(FORMATO_MONEDA) & " </th>"
            strTotalRegion &= "<th style= 'background:gray; 'width:2cm' > " & dblEOct.ToString(FORMATO_MONEDA) & "  </th>"
            strTotalRegion &= "<th style= 'background:gray; 'width:2cm' > " & (dblOct - dblEOct).ToString(FORMATO_MONEDA) & " </th>"

            strTotalRegion &= "<th style= 'background:gray; 'width:2cm' > " & dblNov.ToString(FORMATO_MONEDA) & " </th>"
            strTotalRegion &= "<th style= 'background:gray; 'width:2cm' > " & dblENov.ToString(FORMATO_MONEDA) & "  </th>"
            strTotalRegion &= "<th style= 'background:gray; 'width:2cm' > " & (dblNov - dblENov).ToString(FORMATO_MONEDA) & " </th>"

            strTotalRegion &= "<th style= 'background:gray; 'width:2cm' > " & dblDic.ToString(FORMATO_MONEDA) & " </th>"
            strTotalRegion &= "<th style= 'background:gray; 'width:2cm' > " & dblEDic.ToString(FORMATO_MONEDA) & "  </th>"
            strTotalRegion &= "<th style= 'background:gray; 'width:2cm' > " & (dblDic - dblEDic).ToString(FORMATO_MONEDA) & " </th>"

            strTotalRegion &= "<th style= 'background:gray; 'width:2cm' > " & dblTotalPresupuestado.ToString(FORMATO_MONEDA) & " </th>"
            strTotalRegion &= "<th style= 'background:gray; 'width:2cm' > " & dblTotalEjecutado.ToString(FORMATO_MONEDA) & "  </th>"
            strTotalRegion &= "<th style= 'background:gray; 'width:2cm' > " & (dblTotalPresupuestado - dblTotalEjecutado).ToString(FORMATO_MONEDA) & " </th>"

            strTotalRegion &= "<th style= 'background:gray; 'width:2cm' > " & dblPromedioPresupuestado.ToString(FORMATO_MONEDA) & " </th>"
            strTotalRegion &= "<th style= 'background:gray; 'width:2cm' > " & dblPromedioEjecutado.ToString(FORMATO_MONEDA) & "  </th>"
            strTotalRegion &= "<th style= 'background:gray; 'width:2cm' > " & (dblPromedioPresupuestado - dblPromedioEjecutado).ToString(FORMATO_MONEDA) & " </th>"

            strTotalRegion &= " </tr> "
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        Return strTotalRegion
    End Function

    Public Sub ReportePresupuestoIntegrado(ByVal finicio As Date, ByVal ffin As Date)
        Dim strSQL As String = STR_VACIO
        Dim dblTotalFilaPresupuestado As Double
        Dim dblPromedioFilaPresupuestado As Double
        Dim dblTotalFilaEjecutado As Double
        Dim dblPromedioFilaEjecutado As Double

        Dim f As Byte
        Dim strTemp As String = STR_VACIO
        Dim logPrimeraLInea As Boolean = True

        Dim dblSubtotalEne As Double = INT_CERO
        Dim dblSubtotalFeb As Double = INT_CERO
        Dim dblSubtotalMar As Double = INT_CERO
        Dim dblSubtotalAbr As Double = INT_CERO
        Dim dblSubtotalMay As Double = INT_CERO
        Dim dblSubtotalJun As Double = INT_CERO
        Dim dblSubtotalJul As Double = INT_CERO
        Dim dblSubtotalAgo As Double = INT_CERO
        Dim dblSubtotalSep As Double = INT_CERO
        Dim dblSubtotalOct As Double = INT_CERO
        Dim dblSubtotalNov As Double = INT_CERO
        Dim dblSubtotalDic As Double = INT_CERO

        Dim dblESubtotalEne As Double = INT_CERO
        Dim dblESubtotalFeb As Double = INT_CERO
        Dim dblESubtotalMar As Double = INT_CERO
        Dim dblESubtotalAbr As Double = INT_CERO
        Dim dblESubtotalMay As Double = INT_CERO
        Dim dblESubtotalJun As Double = INT_CERO
        Dim dblESubtotalJul As Double = INT_CERO
        Dim dblESubtotalAgo As Double = INT_CERO
        Dim dblESubtotalSep As Double = INT_CERO
        Dim dblESubtotalOct As Double = INT_CERO
        Dim dblESubtotalNov As Double = INT_CERO
        Dim dblESubtotalDic As Double = INT_CERO

        Dim dblTotalEne As Double = INT_CERO
        Dim dblTotalFeb As Double = INT_CERO
        Dim dblTotalMar As Double = INT_CERO
        Dim dblTotalAbr As Double = INT_CERO
        Dim dblTotalMay As Double = INT_CERO
        Dim dblTotalJun As Double = INT_CERO
        Dim dblTotalJul As Double = INT_CERO
        Dim dblTotalAgo As Double = INT_CERO
        Dim dblTotalSep As Double = INT_CERO
        Dim dblTotalOct As Double = INT_CERO
        Dim dblTotalNov As Double = INT_CERO
        Dim dblTotalDic As Double = INT_CERO

        Dim dblETotalEne As Double = INT_CERO
        Dim dblETotalFeb As Double = INT_CERO
        Dim dblETotalMar As Double = INT_CERO
        Dim dblETotalAbr As Double = INT_CERO
        Dim dblETotalMay As Double = INT_CERO
        Dim dblETotalJun As Double = INT_CERO
        Dim dblETotalJul As Double = INT_CERO
        Dim dblETotalAgo As Double = INT_CERO
        Dim dblETotalSep As Double = INT_CERO
        Dim dblETotalOct As Double = INT_CERO
        Dim dblETotalNov As Double = INT_CERO
        Dim dblETotalDic As Double = INT_CERO

        Dim dblLibrasVendidasene As Double = INT_CERO
        Dim dblLibrasVendidasfeb As Double = INT_CERO
        Dim dblLibrasVendidasmar As Double = INT_CERO
        Dim dblLibrasVendidasabr As Double = INT_CERO
        Dim dblLibrasVendidasmay As Double = INT_CERO
        Dim dblLibrasVendidasjun As Double = INT_CERO
        Dim dblLibrasVendidasjul As Double = INT_CERO
        Dim dblLibrasVendidasago As Double = INT_CERO
        Dim dblLibrasVendidassep As Double = INT_CERO
        Dim dblLibrasVendidasoct As Double = INT_CERO
        Dim dblLibrasVendidasnov As Double = INT_CERO
        Dim dblLibrasVendidasdic As Double = INT_CERO
        Dim dblLibrasVendidastotal As Double = INT_CERO
        Dim dblLibrasVendidaspromedio As Double = INT_CERO

        Dim dblTotal As Double = 0
        Dim dblPromedio As Double = 0


        Dim strHTML As String = STR_VACIO
        Dim intGrupo As String = STR_VACIO
        Dim strGrupo As String = STR_VACIO
        Dim strPrefijo As String = STR_VACIO

        Dim intMeses As Integer
        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader
        Try

            intMeses = (finicio.Month - ffin.Month) + 1

            strSQL = SQLPresupuestadoEjecutado(finicio, ffin)

            strTemp = cFunciones.ArchivoTemporal
            f = FreeFile()
            FileOpen(f, strTemp, OpenMode.Append)

            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSQL, CON)
            REA = COM.ExecuteReader
            strHTML &= EncabezadoPresupuestoIntegrado(finicio)
            strHTML &= ColumnasPresupuestoIntegrado()
            If REA.HasRows Then

                Do While REA.Read

                    If logPrimeraLInea = True Then

                        logPrimeraLInea = False
                        intGrupo = REA.GetString("padre")
                        strGrupo = REA.GetString("padre")
                    Else
                        If intGrupo = REA.GetString("padre") Then


                        Else

                            strHTML &= SubTotalPresupuestoIntegrado(strGrupo, intMeses, dblSubtotalEne, dblSubtotalFeb, dblSubtotalMar, dblSubtotalAbr, dblSubtotalMay, dblSubtotalJun, dblSubtotalJul, dblSubtotalAgo, dblSubtotalSep, dblSubtotalOct, dblSubtotalNov, dblSubtotalDic, dblESubtotalEne, dblESubtotalFeb, dblESubtotalMar, dblESubtotalAbr, dblESubtotalMay, dblESubtotalJun, dblESubtotalJul, dblESubtotalAgo, dblESubtotalSep, dblESubtotalOct, dblESubtotalNov, dblESubtotalDic)
                            '    strHTML &= ColumnasGross()
                            intGrupo = REA.GetString("padre")
                            strGrupo = "Subtotal"

                            dblSubtotalEne = INT_CERO
                            dblSubtotalFeb = INT_CERO
                            dblSubtotalMar = INT_CERO
                            dblSubtotalAbr = INT_CERO
                            dblSubtotalMay = INT_CERO
                            dblSubtotalJun = INT_CERO
                            dblSubtotalJul = INT_CERO
                            dblSubtotalAgo = INT_CERO
                            dblSubtotalSep = INT_CERO
                            dblSubtotalOct = INT_CERO
                            dblSubtotalNov = INT_CERO
                            dblSubtotalDic = INT_CERO

                            dblESubtotalEne = INT_CERO
                            dblESubtotalFeb = INT_CERO
                            dblESubtotalMar = INT_CERO
                            dblESubtotalAbr = INT_CERO
                            dblESubtotalMay = INT_CERO
                            dblESubtotalJun = INT_CERO
                            dblESubtotalJul = INT_CERO
                            dblESubtotalAgo = INT_CERO
                            dblESubtotalSep = INT_CERO
                            dblESubtotalOct = INT_CERO
                            dblESubtotalNov = INT_CERO
                            dblESubtotalDic = INT_CERO

                        End If
                    End If
                    '' linea
                    dblTotalFilaPresupuestado = 0
                    strPrefijo = "Pre"
                    dblTotalFilaPresupuestado = REA.GetDouble(strPrefijo & "Ene") + REA.GetDouble(strPrefijo & "Feb") + REA.GetDouble(strPrefijo & "Mar") + REA.GetDouble(strPrefijo & "Abr") + REA.GetDouble(strPrefijo & "May") + REA.GetDouble(strPrefijo & "Jun") + REA.GetDouble(strPrefijo & "Jul") + REA.GetDouble(strPrefijo & "Ago") + REA.GetDouble(strPrefijo & "Sep") + REA.GetDouble(strPrefijo & "Oct") + REA.GetDouble(strPrefijo & "Nov") + REA.GetDouble(strPrefijo & "Dic")
                    dblPromedioFilaPresupuestado = dblTotalFilaPresupuestado / intMeses

                    strPrefijo = "Eje"
                    dblTotalFilaEjecutado = REA.GetDouble(strPrefijo & "Ene") + REA.GetDouble(strPrefijo & "Feb") + REA.GetDouble(strPrefijo & "Mar") + REA.GetDouble(strPrefijo & "Abr") + REA.GetDouble(strPrefijo & "May") + REA.GetDouble(strPrefijo & "Jun") + REA.GetDouble(strPrefijo & "Jul") + REA.GetDouble(strPrefijo & "Ago") + REA.GetDouble(strPrefijo & "Sep") + REA.GetDouble(strPrefijo & "Oct") + REA.GetDouble(strPrefijo & "Nov") + REA.GetDouble(strPrefijo & "Dic")
                    dblPromedioFilaEjecutado = dblTotalFilaEjecutado / intMeses

                    If REA.GetString("Padre") = "Sales" Then
                        dblLibrasVendidasene = REA.GetDouble("PreEne") ' capturar libras vendidas
                        dblLibrasVendidasfeb = REA.GetDouble("PreFeb") ' capturar libras vendidas
                        dblLibrasVendidasmar = REA.GetDouble("PreMar") ' capturar libras vendidas
                        dblLibrasVendidasabr = REA.GetDouble("PreAbr") ' capturar libras vendidas
                        dblLibrasVendidasmay = REA.GetDouble("PreMay") ' capturar libras vendidas
                        dblLibrasVendidasjun = REA.GetDouble("PreJun") ' capturar libras vendidas
                        dblLibrasVendidasjul = REA.GetDouble("PreJul") ' capturar libras vendidas
                        dblLibrasVendidasago = REA.GetDouble("PreAgo") ' capturar libras vendidas
                        dblLibrasVendidassep = REA.GetDouble("PreSep") ' capturar libras vendidas
                        dblLibrasVendidasoct = REA.GetDouble("PreOct") ' capturar libras vendidas
                        dblLibrasVendidasnov = REA.GetDouble("PreNov") ' capturar libras vendidas
                        dblLibrasVendidasdic = REA.GetDouble("PreDic") ' capturar libras vendidas

                        dblLibrasVendidastotal = dblLibrasVendidasene + dblLibrasVendidasfeb + dblLibrasVendidasmar + dblLibrasVendidasabr + dblLibrasVendidasmay + dblLibrasVendidasjun + dblLibrasVendidasjul + dblLibrasVendidasago + dblLibrasVendidassep + dblLibrasVendidasoct + dblLibrasVendidasnov + dblLibrasVendidasdic
                        dblLibrasVendidaspromedio = dblLibrasVendidastotal / intMeses
                    End If
                    If REA.GetString("padre") = "COST" Then
                        ' strHTML &= LineaCostoLBs() ' imprimir linea de costo

                    End If
                    strPrefijo = "Pre"
                    strHTML &= " <tr> "
                    strHTML &= "<td>" & REA.GetString("nombre_Grupo") & "</td>"
                    strHTML &= "<td>" & REA.GetDouble(strPrefijo & "Ene").ToString(FORMATO_MONEDA) & "</td>"
                    strHTML &= "<td>" & REA.GetDouble("Eje" & "Ene").ToString(FORMATO_MONEDA) & "</td>"
                    strHTML &= "<td>" & (REA.GetDouble(strPrefijo & "Ene") - REA.GetDouble("Eje" & "Ene")).ToString(FORMATO_MONEDA) & "</td>"

                    strHTML &= "<td>" & REA.GetDouble(strPrefijo & "Feb").ToString(FORMATO_MONEDA) & "</td>"
                    strHTML &= "<td>" & REA.GetDouble("Eje" & "Feb").ToString(FORMATO_MONEDA) & "</td>"
                    strHTML &= "<td>" & (REA.GetDouble(strPrefijo & "Feb") - REA.GetDouble("Eje" & "Feb")).ToString(FORMATO_MONEDA) & "</td>"

                    strHTML &= "<td>" & REA.GetDouble(strPrefijo & "Mar").ToString(FORMATO_MONEDA) & "</td>"
                    strHTML &= "<td>" & REA.GetDouble("Eje" & "Mar").ToString(FORMATO_MONEDA) & "</td>"
                    strHTML &= "<td>" & (REA.GetDouble(strPrefijo & "Mar") - REA.GetDouble("Eje" & "Mar")).ToString(FORMATO_MONEDA) & "</td>"

                    strHTML &= "<td>" & REA.GetDouble(strPrefijo & "Abr").ToString(FORMATO_MONEDA) & "</td>"
                    strHTML &= "<td>" & REA.GetDouble("Eje" & "Abr").ToString(FORMATO_MONEDA) & "</td>"
                    strHTML &= "<td>" & (REA.GetDouble(strPrefijo & "Abr") - REA.GetDouble("Eje" & "Abr")).ToString(FORMATO_MONEDA) & "</td>"

                    strHTML &= "<td>" & REA.GetDouble(strPrefijo & "May").ToString(FORMATO_MONEDA) & "</td>"
                    strHTML &= "<td>" & REA.GetDouble("Eje" & "May").ToString(FORMATO_MONEDA) & "</td>"
                    strHTML &= "<td>" & (REA.GetDouble(strPrefijo & "May") - REA.GetDouble("Eje" & "May")).ToString(FORMATO_MONEDA) & "</td>"

                    strHTML &= "<td>" & REA.GetDouble(strPrefijo & "Jun").ToString(FORMATO_MONEDA) & "</td>"
                    strHTML &= "<td>" & REA.GetDouble("Eje" & "Jun").ToString(FORMATO_MONEDA) & "</td>"
                    strHTML &= "<td>" & (REA.GetDouble(strPrefijo & "Jun") - REA.GetDouble("Eje" & "Jun")).ToString(FORMATO_MONEDA) & "</td>"

                    strHTML &= "<td>" & REA.GetDouble(strPrefijo & "Jul").ToString(FORMATO_MONEDA) & "</td>"
                    strHTML &= "<td>" & REA.GetDouble("Eje" & "Jul").ToString(FORMATO_MONEDA) & "</td>"
                    strHTML &= "<td>" & (REA.GetDouble(strPrefijo & "Jul") - REA.GetDouble("Eje" & "Jul")).ToString(FORMATO_MONEDA) & "</td>"

                    strHTML &= "<td>" & REA.GetDouble(strPrefijo & "Ago").ToString(FORMATO_MONEDA) & "</td>"
                    strHTML &= "<td>" & REA.GetDouble("Eje" & "Ago").ToString(FORMATO_MONEDA) & "</td>"
                    strHTML &= "<td>" & (REA.GetDouble(strPrefijo & "Ago") - REA.GetDouble("Eje" & "Ago")).ToString(FORMATO_MONEDA) & "</td>"

                    strHTML &= "<td>" & REA.GetDouble(strPrefijo & "Sep").ToString(FORMATO_MONEDA) & "</td>"
                    strHTML &= "<td>" & REA.GetDouble("Eje" & "Sep").ToString(FORMATO_MONEDA) & "</td>"
                    strHTML &= "<td>" & (REA.GetDouble(strPrefijo & "Sep") - REA.GetDouble("Eje" & "Sep")).ToString(FORMATO_MONEDA) & "</td>"

                    strHTML &= "<td>" & REA.GetDouble(strPrefijo & "Oct").ToString(FORMATO_MONEDA) & "</td>"
                    strHTML &= "<td>" & REA.GetDouble("Eje" & "Oct").ToString(FORMATO_MONEDA) & "</td>"
                    strHTML &= "<td>" & (REA.GetDouble(strPrefijo & "Oct") - REA.GetDouble("Eje" & "Oct")).ToString(FORMATO_MONEDA) & "</td>"

                    strHTML &= "<td>" & REA.GetDouble(strPrefijo & "Nov").ToString(FORMATO_MONEDA) & "</td>"
                    strHTML &= "<td>" & REA.GetDouble("Eje" & "Nov").ToString(FORMATO_MONEDA) & "</td>"
                    strHTML &= "<td>" & (REA.GetDouble(strPrefijo & "Nov") - REA.GetDouble("Eje" & "Nov")).ToString(FORMATO_MONEDA) & "</td>"

                    strHTML &= "<td>" & REA.GetDouble(strPrefijo & "Dic").ToString(FORMATO_MONEDA) & "</td>"
                    strHTML &= "<td>" & REA.GetDouble("Eje" & "Dic").ToString(FORMATO_MONEDA) & "</td>"
                    strHTML &= "<td>" & (REA.GetDouble(strPrefijo & "Dic") - REA.GetDouble("Eje" & "Dic")).ToString(FORMATO_MONEDA) & "</td>"

                    strHTML &= "<td>" & dblTotalFilaPresupuestado.ToString(FORMATO_MONEDA) & "</td>"
                    strHTML &= "<td>" & dblTotalFilaEjecutado.ToString(FORMATO_MONEDA) & "</td>"
                    strHTML &= "<td>" & (dblTotalFilaPresupuestado - dblTotalFilaEjecutado).ToString(FORMATO_MONEDA) & "</td>"

                    strHTML &= "<td>" & dblPromedioFilaPresupuestado.ToString(FORMATO_MONEDA) & "</td>"
                    strHTML &= "<td>" & dblPromedioFilaEjecutado.ToString(FORMATO_MONEDA) & "</td>"
                    strHTML &= "<td>" & (dblPromedioFilaPresupuestado - dblPromedioFilaEjecutado).ToString(FORMATO_MONEDA) & "</td>"

                    strHTML &= " </tr> "

                    dblSubtotalEne = dblSubtotalEne + REA.GetDouble(strPrefijo & "Ene")
                    dblSubtotalFeb = dblSubtotalFeb + REA.GetDouble(strPrefijo & "Feb")
                    dblSubtotalMar = dblSubtotalMar + REA.GetDouble(strPrefijo & "Mar")
                    dblSubtotalAbr = dblSubtotalAbr + REA.GetDouble(strPrefijo & "Abr")
                    dblSubtotalMay = dblSubtotalMay + REA.GetDouble(strPrefijo & "May")
                    dblSubtotalJun = dblSubtotalJun + REA.GetDouble(strPrefijo & "Jun")
                    dblSubtotalJul = dblSubtotalJul + REA.GetDouble(strPrefijo & "Jul")
                    dblSubtotalAgo = dblSubtotalAgo + REA.GetDouble(strPrefijo & "Ago")
                    dblSubtotalSep = dblSubtotalSep + REA.GetDouble(strPrefijo & "Sep")
                    dblSubtotalOct = dblSubtotalOct + REA.GetDouble(strPrefijo & "Oct")
                    dblSubtotalNov = dblSubtotalNov + REA.GetDouble(strPrefijo & "Nov")
                    dblSubtotalDic = dblSubtotalDic + REA.GetDouble(strPrefijo & "Dic")

                    dblESubtotalEne = dblESubtotalEne + REA.GetDouble("Eje" & "Ene")
                    dblESubtotalFeb = dblESubtotalFeb + REA.GetDouble("Eje" & "Feb")
                    dblESubtotalMar = dblESubtotalMar + REA.GetDouble("Eje" & "Mar")
                    dblESubtotalAbr = dblESubtotalAbr + REA.GetDouble("Eje" & "Abr")
                    dblESubtotalMay = dblESubtotalMay + REA.GetDouble("Eje" & "May")
                    dblESubtotalJun = dblESubtotalJun + REA.GetDouble("Eje" & "Jun")
                    dblESubtotalJul = dblESubtotalJul + REA.GetDouble("Eje" & "Jul")
                    dblESubtotalAgo = dblESubtotalAgo + REA.GetDouble("Eje" & "Ago")
                    dblESubtotalSep = dblESubtotalSep + REA.GetDouble("Eje" & "Sep")
                    dblESubtotalOct = dblESubtotalOct + REA.GetDouble("Eje" & "Oct")
                    dblESubtotalNov = dblESubtotalNov + REA.GetDouble("Eje" & "Nov")
                    dblESubtotalDic = dblESubtotalDic + REA.GetDouble("Eje" & "Dic")

                    dblTotalEne = dblTotalEne + REA.GetDouble(strPrefijo & "Ene")
                    dblTotalFeb = dblTotalFeb + REA.GetDouble(strPrefijo & "Feb")
                    dblTotalMar = dblTotalMar + REA.GetDouble(strPrefijo & "Mar")
                    dblTotalAbr = dblTotalAbr + REA.GetDouble(strPrefijo & "Abr")
                    dblTotalMay = dblTotalMay + REA.GetDouble(strPrefijo & "May")
                    dblTotalJun = dblTotalJun + REA.GetDouble(strPrefijo & "Jun")
                    dblTotalJul = dblTotalJun + REA.GetDouble(strPrefijo & "Jul")
                    dblTotalAgo = dblTotalAgo + REA.GetDouble(strPrefijo & "Ago")
                    dblTotalSep = dblTotalSep + REA.GetDouble(strPrefijo & "Sep")
                    dblTotalOct = dblTotalOct + REA.GetDouble(strPrefijo & "Oct")
                    dblTotalNov = dblTotalNov + REA.GetDouble(strPrefijo & "Nov")
                    dblTotalDic = dblTotalDic + REA.GetDouble(strPrefijo & "Dic")

                    dblETotalEne = dblETotalEne + REA.GetDouble("Eje" & "Ene")
                    dblETotalFeb = dblETotalFeb + REA.GetDouble("Eje" & "Feb")
                    dblETotalMar = dblETotalMar + REA.GetDouble("Eje" & "Mar")
                    dblETotalAbr = dblETotalAbr + REA.GetDouble("Eje" & "Abr")
                    dblETotalMay = dblETotalMay + REA.GetDouble("Eje" & "May")
                    dblETotalJun = dblETotalJun + REA.GetDouble("Eje" & "Jun")
                    dblETotalJul = dblETotalJun + REA.GetDouble("Eje" & "Jul")
                    dblETotalAgo = dblETotalAgo + REA.GetDouble("Eje" & "Ago")
                    dblETotalSep = dblETotalSep + REA.GetDouble("Eje" & "Sep")
                    dblETotalOct = dblETotalOct + REA.GetDouble("Eje" & "Oct")
                    dblETotalNov = dblETotalNov + REA.GetDouble("Eje" & "Nov")
                    dblETotalDic = dblETotalDic + REA.GetDouble("Eje" & "Dic")
                Loop


                strHTML &= SubTotalPresupuestoIntegrado(strGrupo, intMeses, dblSubtotalEne, dblSubtotalFeb, dblSubtotalMar, dblSubtotalAbr, dblSubtotalMay, dblSubtotalJun, dblSubtotalJul, dblSubtotalAgo, dblSubtotalSep, dblSubtotalOct, dblSubtotalNov, dblSubtotalDic, dblESubtotalEne, dblESubtotalFeb, dblESubtotalMar, dblESubtotalAbr, dblESubtotalMay, dblESubtotalJun, dblESubtotalJul, dblESubtotalAgo, dblESubtotalSep, dblESubtotalOct, dblESubtotalNov, dblESubtotalDic)
                strHTML &= TotalPresupuestoIntegrado(strGrupo, intMeses, dblTotalEne, dblTotalFeb, dblTotalMar, dblTotalAbr, dblTotalMay, dblTotalJun, dblTotalJul, dblTotalAgo, dblTotalSep, dblTotalOct, dblTotalNov, dblTotalDic, dblETotalEne, dblETotalFeb, dblETotalMar, dblETotalAbr, dblETotalMay, dblETotalJun, dblETotalJul, dblETotalAgo, dblETotalSep, dblETotalOct, dblETotalNov, dblETotalDic)

                strHTML = strHTML.Replace("{ene}", (dblTotalEne / dblLibrasVendidasene).ToString(FORMATO_MONEDA))
                strHTML = strHTML.Replace("{feb}", (dblTotalFeb / dblLibrasVendidasfeb).ToString(FORMATO_MONEDA))
                strHTML = strHTML.Replace("{mar}", (dblTotalMar / dblLibrasVendidasmar).ToString(FORMATO_MONEDA))
                strHTML = strHTML.Replace("{abr}", (dblTotalAbr / dblLibrasVendidasabr).ToString(FORMATO_MONEDA))
                strHTML = strHTML.Replace("{may}", (dblTotalMay / dblLibrasVendidasmay).ToString(FORMATO_MONEDA))
                strHTML = strHTML.Replace("{jun}", (dblTotalJun / dblLibrasVendidasjun).ToString(FORMATO_MONEDA))
                strHTML = strHTML.Replace("{jul}", (dblTotalJul / dblLibrasVendidasjul).ToString(FORMATO_MONEDA))
                strHTML = strHTML.Replace("{ago}", (dblTotalAgo / dblLibrasVendidasago).ToString(FORMATO_MONEDA))
                strHTML = strHTML.Replace("{sep}", (dblTotalSep / dblLibrasVendidassep).ToString(FORMATO_MONEDA))
                strHTML = strHTML.Replace("{oct}", (dblTotalOct / dblLibrasVendidasoct).ToString(FORMATO_MONEDA))
                strHTML = strHTML.Replace("{nov}", (dblTotalNov / dblLibrasVendidasnov).ToString(FORMATO_MONEDA))
                strHTML = strHTML.Replace("{dic}", (dblTotalDic / dblLibrasVendidasdic).ToString(FORMATO_MONEDA))

                dblTotal = dblTotalEne + dblTotalFeb + dblTotalMar + dblTotalAbr + dblTotalMay + dblTotalJun + dblTotalJul + dblTotalAgo + dblTotalSep + dblTotalOct + dblTotalNov + dblTotalDic
                dblPromedio = dblTotal / intMeses
                strHTML = strHTML.Replace("{tot}", (dblTotal / dblLibrasVendidasdic).ToString(FORMATO_MONEDA))
                strHTML = strHTML.Replace("{pro}", (dblPromedio / dblLibrasVendidasdic).ToString(FORMATO_MONEDA))

                Print(f, strHTML)
                Print(f, "</table>")
                Print(f, "<br/>")
                Print(f, "</body>")
                Print(f, "</html>")
                FileClose(f)
                MostarReporte(strTemp)

            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try

    End Sub

#End Region

#Region "AR_Detail"

    Private Function SqlAR_Detail(ByVal intEmp As Integer, ByVal intFiltro As Integer)
        Dim strSQL As String = STR_VACIO

        strSQL = " SELECT op.serief,op.autorizacionf,op.idGrupo, op.idEmpresa, op.codigo, op.nombreEmp, op.fecha, op.numero, op.referencia, op.limiteCredito, op.diasCredito, op.Vencimiento, op.dias_atrasados, op.balance_abierto, IFNULL(op.monto_Vencido,0.00) monto_Vencido, op.intereses, op.balanceQ, op.tasa_Cambio, op.programa, op.proforma, op.pagare, IFNULL(op.fecha_entrega, '-')fecha_entrega, op.registro, IFNULL(g.nombre_Grupo, 'SIN GRUPO') nombreGrupo,e.nombre_empresa "
        strSQL &= "    From YarnDivision.AR_Detail op "
        strSQL &= "        LEFT JOIN YarnDivision.Grupo_Detalle gd ON gd.idGrupo =op.idGrupo AND gd.Codigo = op.codigo AND gd.idEmpresa = op.idEmpresa AND gd.idTipo = 1 "
        strSQL &= "            LEFT JOIN YarnDivision.Grupo g ON g.idGrupo = gd.idGrupo AND g.idTipo = 1 "
        strSQL &= "                LEFT JOIN YarnDivision.Empresa e ON e.idEmpresa = op.idEmpresa "
        strSQL &= "                    WHERE op.correlativo >0 AND op.idGrupo IN(gd.idGrupo, -1) {emp} {filtro} " ' se le agregó el tipo de grupo ya que habrán diversos tipos de grupos
        strSQL &= "                        ORDER BY  g.nombre_Grupo ASC, e.idEmpresa, op.codigo, op.fecha "

        If intEmp = 0 Then
            strSQL = strSQL.Replace("{emp}", "")
        Else
            strSQL = strSQL.Replace("{emp}", " AND e.idEmpresa = " & intEmp)
        End If

        If intFiltro = 0 Then
            strSQL = strSQL.Replace("{filtro}", "")
        ElseIf intFiltro = 1 Then
            strSQL = strSQL.Replace("{filtro}", " AND g.nombre_Grupo LIKE '%Intercompany%'")
        ElseIf intFiltro = 2 Then
            strSQL = strSQL.Replace("{filtro}", " AND NOT g.nombre_Grupo LIKE '%Intercompany%' AND NOT g.nombre_Grupo LIKE '%Quimico%' AND NOT g.nombre_Grupo LIKE 'Planta%'")
        ElseIf intFiltro = 3 Then
            strSQL = strSQL.Replace("{filtro}", " AND g.nombre_Grupo LIKE '%Quimico%'")
        ElseIf intFiltro = 4 Then
            strSQL = strSQL.Replace("{filtro}", " AND g.nombre_Grupo LIKE 'Planta%'")
        End If

        Return strSQL

    End Function

    Public Shared Function ObtenerViernes(diaSemana As DateTime) As DateTime
        Dim ViernesDeSemana As DateTime = diaSemana.Date
        While ViernesDeSemana.DayOfWeek <> DayOfWeek.Friday
            ViernesDeSemana = ViernesDeSemana.AddDays(+1)
        End While
        Return ViernesDeSemana
    End Function

    Public Sub AR_DetailCorp(ByVal intEmp As Integer, ByVal intfilter As Integer, ByVal fec As Date)
        Dim sql As String = STR_VACIO
        Dim strTemp As String = STR_VACIO
        Dim REA As MySqlDataReader
        Dim COM As MySqlCommand
        Dim f As Byte
        Dim i As Integer = 0
        Dim intGrupo As Integer = 0
        Dim dblAcumula As Double = 0
        Dim SaldoVencido As Double = 0
        Dim intLineas As Integer = 0
        Dim SumaInteres As Double = 0
        Dim SaldoQ As Double = 0
        Dim diasAtrasados As String = vbNullString
        Dim strCadena As String = STR_VACIO
        Dim arrayCadena() As String
        Dim dblGranTotalBalance As Double = 0
        Dim dblGranTotalVencido As Double = 0
        Dim Viernes1 As DateTime
        Dim Viernes2 As DateTime
        Dim Viernes3 As DateTime
        Dim Viernes4 As DateTime
        Dim Viernes5 As DateTime
        Dim Viernes6 As DateTime
        Dim Viernes7 As DateTime
        Dim Viernes8 As DateTime
        Dim Viernes9 As DateTime

        Dim dblSubTotalSemana1 As Double = INT_CERO
        Dim dblSubTotalSemana2 As Double = INT_CERO
        Dim dblSubTotalSemana3 As Double = INT_CERO
        Dim dblSubTotalSemana4 As Double = INT_CERO
        Dim dblSubTotalSemana5 As Double = INT_CERO
        Dim dblSubTotalSemana6 As Double = INT_CERO
        Dim dblSubTotalSemana7 As Double = INT_CERO
        Dim dblSubTotalSemana8 As Double = INT_CERO
        Dim dblSubTotalSemana9 As Double = INT_CERO

        Dim dblTotalSemana1 As Double = INT_CERO
        Dim dblTotalSemana2 As Double = INT_CERO
        Dim dblTotalSemana3 As Double = INT_CERO
        Dim dblTotalSemana4 As Double = INT_CERO
        Dim dblTotalSemana5 As Double = INT_CERO
        Dim dblTotalSemana6 As Double = INT_CERO
        Dim dblTotalSemana7 As Double = INT_CERO
        Dim dblTotalSemana8 As Double = INT_CERO
        Dim dblTotalSemana9 As Double = INT_CERO

        sql = SqlAR_Detail(intEmp, intfilter)
        Try
            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(sql, CON)
            REA = COM.ExecuteReader

            strTemp = cFunciones.ArchivoTemporal
            f = FreeFile()
            FileOpen(f, strTemp, OpenMode.Append)

            If REA.HasRows Then
                Do While REA.Read

                    If i = 0 Then

                        Print(f, " <html > ")
                        Print(f, " <head > ")
                        Print(f, "<style type='text/css'>")
                        Print(f, " table {table-layout: fixed; empty-cells: show; border-collapse:collapse}")
                        Print(f, " caption {padding: 5px; text-align:left; font-family: Tahoma,  Arial;font-size: 8pt}")
                        Print(f, " td {text-align:center;border:solid Gray 1px; padding:3px 5px; font-family: Tahoma, Arial;font-size: 7pt}")
                        Print(f, " th {width: 1.8cm; border:solid Gray 1px; background-color: Black; color: White; padding:2px 5px; font-family: Tahoma,  Arial;font-size: 6pt}")
                        Print(f, " th {text-align:center;border:solid Gray 1px; padding:3px 5px; font-family: Tahoma,  Arial;font-size: 7pt}")
                        Print(f, " th.numero {text-align:right; mso-number-format:\#\,\#\#0\.00}")
                        Print(f, " th.unitario {text-align:right; mso-number-format:\#\,\#\#0\.00#####}")
                        Print(f, " th.titulo {text-align:right;font-family: Tahoma,  Arial;font-size: 9pt")
                        Print(f, " .titulo {font-family: Tahoma,  Arial;font-size: 9pt}")
                        Print(f, " .encabezado {text-align: left; border: none; width: 3.1cm}")
                        Print(f, " .pie {font-family: Tahoma,  Arial;font-size: 7pt}")
                        Print(f, " .izquierda {text-align:left}")
                        Print(f, " .centro {text-align:center}")
                        Print(f, " .derecha {text-align:right}")
                        Print(f, " .info {text-align:left; border:none}")
                        Print(f, "</style>")
                        Print(f, "<right><h3> <b> <th > AR Detail</th></h3></b></right>")
                        Print(f, "<right><h5> <b> <th > cutoff date: " & fec.ToString(FORMATO_MYSQL) & " </th></h5></b></right>")
                        Print(f, "<right><h3> <b> <th > Amounts expressed in US$</th></h3></b></right>")
                        Print(f, "</head>")

                        Print(f, "<body>")
                        Print(f, "<table cellspacing =0 >")
                        Print(f, "<tr>")
                        Print(f, "<th style='width: 4cm; border:1px solid black'>GROUP</th>")
                        Print(f, "<th style='width: 5cm; border:1px solid black'>CUSTOMER</th>")
                        Print(f, "<th style='width: 3cm; border:1px solid black'>CREDIT LIMIT</th>")
                        Print(f, "<th style='width: 3cm; border:1px solid black'>COMPANY</th>")
                        Print(f, "<th style='width: 2cm; border:1px solid black'>DATE</th>")
                        Print(f, "<th style='width: 2cm; border:1px solid black'>INVOICE</th>")
                        Print(f, "<th style='width: 1.5cm; border:1px solid black'>TERMS</th>")
                        Print(f, "<th style='width: 2cm; border:1px solid black'>DUE DATE</th>")
                        Print(f, "<th style='width: 3.5cm; border:1px solid black'>OPEN BALANCE</th>")
                        Print(f, "<th style='width: 2.8cm; border:1px solid black'>PAST DUES</th>")
                        Viernes1 = ObtenerViernes(REA.GetDateTime("registro"))
                        Viernes2 = Viernes1.AddDays(+7)
                        Viernes3 = Viernes2.AddDays(+7)
                        Viernes4 = Viernes3.AddDays(+7)
                        Viernes5 = Viernes4.AddDays(+7)
                        Viernes6 = Viernes5.AddDays(+7)
                        Viernes7 = Viernes6.AddDays(+7)
                        Viernes8 = Viernes7.AddDays(+7)
                        Viernes9 = Viernes8.AddDays(+7)
                        Print(f, "<th style='width: 2.8cm; border:1px solid black'>" & Viernes1 & "</th>")
                        Print(f, "<th style='width: 2.8cm; border:1px solid black'>" & Viernes2 & "</th>")
                        Print(f, "<th style='width: 2.8cm; border:1px solid black'>" & Viernes3 & "</th>")
                        Print(f, "<th style='width: 2.8cm; border:1px solid black'>" & Viernes4 & "</th>")
                        Print(f, "<th style='width: 2.8cm; border:1px solid black'>" & Viernes5 & "</th>")
                        Print(f, "<th style='width: 2.8cm; border:1px solid black'>" & Viernes6 & "</th>")
                        Print(f, "<th style='width: 2.8cm; border:1px solid black'>" & Viernes7 & "</th>")
                        Print(f, "<th style='width: 2.8cm; border:1px solid black'>" & Viernes8 & "</th>")
                        Print(f, "<th style='width: 2.8cm; border:1px solid black'>" & Viernes9 & "</th>")
                        Print(f, "</tr>")
                    End If

                    If Not intGrupo = REA.GetInt16("idGrupo") Then


                        If intLineas > 0 Then
                            'imprima total
                            Print(f, " <tr> ")
                            Print(f, " <td colspan='8' style='width: 4cm; border:1px solid black;background-color: #CCD1D1'><b> Total <br></td>")
                            Print(f, "<td style='width: 3.5cm; border:1px solid black;text-align:right;background-color: #CCD1D1'><b>" & dblAcumula.ToString(FORMATO_MONEDA) & " </td>")
                            Print(f, "<td style='width: 2.8cm; border:1px solid black; color:red;text-align:right;background-color: #CCD1D1'><b>" & SaldoVencido.ToString(FORMATO_MONEDA) & "</td>")
                            Print(f, " <td style='width: 2.8cm; border:1px solid black;background-color: #CCD1D1;text-align:right'><b>" & dblSubTotalSemana1.ToString(FORMATO_MONEDA) & " </td>")
                            Print(f, " <td style='width: 2.8cm; border:1px solid black;background-color: #CCD1D1;text-align:right'><b>" & dblSubTotalSemana2.ToString(FORMATO_MONEDA) & " </td>")
                            Print(f, " <td style='width: 2.8cm; border:1px solid black;background-color: #CCD1D1;text-align:right'><b>" & dblSubTotalSemana3.ToString(FORMATO_MONEDA) & " </td>")
                            Print(f, " <td style='width: 2.8cm; border:1px solid black;background-color: #CCD1D1;text-align:right'><b>" & dblSubTotalSemana4.ToString(FORMATO_MONEDA) & " </td>")
                            Print(f, " <td style='width: 2.8cm; border:1px solid black;background-color: #CCD1D1;text-align:right'><b>" & dblSubTotalSemana5.ToString(FORMATO_MONEDA) & " </td>")
                            Print(f, " <td style='width: 2.8cm; border:1px solid black;background-color: #CCD1D1;text-align:right'><b>" & dblSubTotalSemana6.ToString(FORMATO_MONEDA) & " </td>")
                            Print(f, " <td style='width: 2.8cm; border:1px solid black;background-color: #CCD1D1;text-align:right'><b>" & dblSubTotalSemana7.ToString(FORMATO_MONEDA) & " </td>")
                            Print(f, " <td style='width: 2.8cm; border:1px solid black;background-color: #CCD1D1;text-align:right'><b>" & dblSubTotalSemana8.ToString(FORMATO_MONEDA) & " </td>")
                            Print(f, " <td style='width: 2.8cm; border:1px solid black;background-color: #CCD1D1;text-align:right'><b>" & dblSubTotalSemana9.ToString(FORMATO_MONEDA) & " </td>")
                            Print(f, "</tr>")
                            dblGranTotalBalance = dblGranTotalBalance + dblAcumula
                            dblGranTotalVencido = dblGranTotalVencido + SaldoVencido
                        End If

                        'Reinicia Valores Necesarios
                        intLineas = 0
                        dblAcumula = 0
                        SaldoVencido = 0
                        SumaInteres = 0
                        SaldoQ = 0
                        dblSubTotalSemana1 = 0
                        dblSubTotalSemana2 = 0
                        dblSubTotalSemana3 = 0
                        dblSubTotalSemana4 = 0
                        dblSubTotalSemana5 = 0
                        dblSubTotalSemana6 = 0
                        dblSubTotalSemana7 = 0
                        dblSubTotalSemana8 = 0
                        dblSubTotalSemana9 = 0

                        Print(f, " <tr> ")
                        Print(f, " <td style='width: 4cm; border:1px solid black'>" & REA.GetString("nombreGrupo") & "</td>")
                        Print(f, " <td style='width: 5cm; border:1px solid black'>" & REA.GetString("nombreEmp") & "</td>")
                        Print(f, " <td style='width: 3cm; border:1px solid black'>" & REA.GetDouble("limiteCredito").ToString(FORMATO_MONEDA) & "</td>")
                        Print(f, "<td style='width: 4cm; border:1px solid black; background-color: #F2F5A9'>" & REA.GetString("nombre_empresa") & "</td>")
                        Print(f, "<td style='width: 2cm; border:1px solid black'>" & REA.GetMySqlDateTime("fecha").ToString & "</td>")
                        Print(f, "<td style='width: 2cm; border:1px solid black'>" & REA.GetInt32("numero") & "</td>")
                        Print(f, "<td style='width: 1.5cm; border:1px solid black'>" & REA.GetString("diasCredito") & "</td>")
                        Print(f, "<td style='width: 2cm; border:1px solid black'>" & REA.GetMySqlDateTime("Vencimiento").ToString & "</td>")
                        If REA.GetString("dias_atrasados") = vbNullString Then
                            diasAtrasados = "-"
                        Else
                            diasAtrasados = REA.GetString("dias_atrasados")
                        End If
                        Print(f, "<td style='width: 3.5cm; border:1px solid black;text-align:right'>" & REA.GetDouble("balance_abierto").ToString(FORMATO_MONEDA) & "</td>")
                        dblAcumula = REA.GetDouble("balance_abierto") + dblAcumula
                        Print(f, "<td style='width: 2.8cm; border:1px solid black;text-align:right'>" & REA.GetDouble("monto_Vencido").ToString(FORMATO_MONEDA) & "</td>")
                        If REA.GetMySqlDateTime("Vencimiento").ToString <= Viernes1 Then
                            dblSubTotalSemana1 = dblSubTotalSemana1 + REA.GetDouble("balance_abierto")
                            dblTotalSemana1 = dblTotalSemana1 + REA.GetDouble("balance_abierto")
                            Print(f, "<td style='width: 2.8cm; border:1px solid black;text-align:right'>" & REA.GetDouble("balance_abierto").ToString(FORMATO_MONEDA) & "</td>")
                        Else
                            Print(f, "<td style='width: 2.8cm; border:1px solid black;text-align:right'></td>")
                        End If
                        If REA.GetMySqlDateTime("Vencimiento").ToString > Viernes1 And REA.GetMySqlDateTime("Vencimiento").ToString <= Viernes2 Then
                            dblSubTotalSemana2 = dblSubTotalSemana2 + REA.GetDouble("balance_abierto")
                            dblTotalSemana2 = dblTotalSemana2 + REA.GetDouble("balance_abierto")
                            Print(f, "<td style='width: 2.8cm; border:1px solid black;text-align:right'>" & REA.GetDouble("balance_abierto").ToString(FORMATO_MONEDA) & "</td>")
                        Else
                            Print(f, "<td style='width: 2.8cm; border:1px solid black;text-align:right'></td>")
                        End If
                        If REA.GetMySqlDateTime("Vencimiento").ToString > Viernes2 And REA.GetMySqlDateTime("Vencimiento").ToString <= Viernes3 Then
                            dblSubTotalSemana3 = dblSubTotalSemana3 + REA.GetDouble("balance_abierto")
                            dblTotalSemana3 = dblTotalSemana3 + REA.GetDouble("balance_abierto")
                            Print(f, "<td style='width: 2.8cm; border:1px solid black;text-align:right'>" & REA.GetDouble("balance_abierto").ToString(FORMATO_MONEDA) & "</td>")
                        Else
                            Print(f, "<td style='width: 2.8cm; border:1px solid black;text-align:right'></td>")
                        End If
                        If REA.GetMySqlDateTime("Vencimiento").ToString > Viernes3 And REA.GetMySqlDateTime("Vencimiento").ToString <= Viernes4 Then
                            dblSubTotalSemana4 = dblSubTotalSemana4 + REA.GetDouble("balance_abierto")
                            dblTotalSemana4 = dblTotalSemana4 + REA.GetDouble("balance_abierto")
                            Print(f, "<td style='width: 2.8cm; border:1px solid black;text-align:right'>" & REA.GetDouble("balance_abierto").ToString(FORMATO_MONEDA) & "</td>")
                        Else
                            Print(f, "<td style='width: 2.8cm; border:1px solid black;text-align:right'></td>")
                        End If
                        If REA.GetMySqlDateTime("Vencimiento").ToString > Viernes4 And REA.GetMySqlDateTime("Vencimiento").ToString <= Viernes5 Then
                            dblSubTotalSemana5 = dblSubTotalSemana5 + REA.GetDouble("balance_abierto")
                            dblTotalSemana5 = dblTotalSemana5 + REA.GetDouble("balance_abierto")
                            Print(f, "<td style='width: 2.8cm; border:1px solid black;text-align:right'>" & REA.GetDouble("balance_abierto").ToString(FORMATO_MONEDA) & "</td>")
                        Else
                            Print(f, "<td style='width: 2.8cm; border:1px solid black;text-align:right'></td>")
                        End If
                        If REA.GetMySqlDateTime("Vencimiento").ToString > Viernes5 And REA.GetMySqlDateTime("Vencimiento").ToString <= Viernes6 Then
                            dblSubTotalSemana6 = dblSubTotalSemana5 + REA.GetDouble("balance_abierto")
                            dblTotalSemana6 = dblTotalSemana6 + REA.GetDouble("balance_abierto")
                            Print(f, "<td style='width: 2.8cm; border:1px solid black;text-align:right'>" & REA.GetDouble("balance_abierto").ToString(FORMATO_MONEDA) & "</td>")
                        Else
                            Print(f, "<td style='width: 2.8cm; border:1px solid black;text-align:right'></td>")
                        End If
                        If REA.GetMySqlDateTime("Vencimiento").ToString > Viernes6 And REA.GetMySqlDateTime("Vencimiento").ToString <= Viernes7 Then
                            dblSubTotalSemana7 = dblSubTotalSemana7 + REA.GetDouble("balance_abierto")
                            dblTotalSemana7 = dblTotalSemana7 + REA.GetDouble("balance_abierto")
                            Print(f, "<td style='width: 2.8cm; border:1px solid black;text-align:right'>" & REA.GetDouble("balance_abierto").ToString(FORMATO_MONEDA) & "</td>")
                        Else
                            Print(f, "<td style='width: 2.8cm; border:1px solid black;text-align:right'></td>")
                        End If
                        If REA.GetMySqlDateTime("Vencimiento").ToString > Viernes7 And REA.GetMySqlDateTime("Vencimiento").ToString <= Viernes8 Then
                            dblSubTotalSemana8 = dblSubTotalSemana8 + REA.GetDouble("balance_abierto")
                            dblTotalSemana8 = dblTotalSemana8 + REA.GetDouble("balance_abierto")
                            Print(f, "<td style='width: 2.8cm; border:1px solid black;text-align:right'>" & REA.GetDouble("balance_abierto").ToString(FORMATO_MONEDA) & "</td>")
                        Else
                            Print(f, "<td style='width: 2.8cm; border:1px solid black;text-align:right'></td>")
                        End If

                        If REA.GetMySqlDateTime("Vencimiento").ToString > Viernes8 And REA.GetMySqlDateTime("Vencimiento").ToString <= Viernes9 Then
                            dblSubTotalSemana9 = dblSubTotalSemana9 + REA.GetDouble("balance_abierto")
                            dblTotalSemana9 = dblTotalSemana9 + REA.GetDouble("balance_abierto")
                            Print(f, "<td style='width: 2.8cm; border:1px solid black;text-align:right'>" & REA.GetDouble("balance_abierto").ToString(FORMATO_MONEDA) & "</td>")
                        Else
                            Print(f, "<td style='width: 2.8cm; border:1px solid black;text-align:right'></td>")
                        End If
                        'Print(f, "<td style='width: 2.8cm; border:1px solid black;text-align:right'></td>")
                        '    Print(f, "<td style='width: 2.8cm; border:1px solid black;text-align:right'></td>")
                        Print(f, "</tr>")

                    Else
                        Print(f, " <tr> ")
                        Print(f, " <td style='width: 4cm; border:1px solid black'>" & REA.GetString("nombreGrupo") & "</td>")
                        Print(f, " <td style='width: 5cm; border:1px solid black'>" & REA.GetString("nombreEmp") & "</td>")
                        Print(f, " <td style='width: 3cm; border:1px solid black'>" & REA.GetString("limiteCredito") & "</td>")
                        Print(f, "<td style='width: 4cm; border:1px solid black; background-color: #F2F5A9'>" & REA.GetString("nombre_empresa") & "</td>")
                        Print(f, "<td style='width: 2cm; border:1px solid black'>" & REA.GetMySqlDateTime("fecha").ToString & "</td>")
                        Print(f, "<td style='width: 2cm; border:1px solid black'>" & REA.GetInt32("numero") & "</td>")
                        Print(f, "<td style='width: 1.5cm; border:1px solid black'>" & REA.GetString("diasCredito") & "</td>")
                        Print(f, "<td style='width: 2cm; border:1px solid black'>" & REA.GetMySqlDateTime("Vencimiento").ToString & "</td>")
                        If REA.GetString("dias_atrasados") = vbNullString Then
                            diasAtrasados = "-"
                        Else
                            diasAtrasados = REA.GetString("dias_atrasados")
                        End If
                        Print(f, "<td style='width: 3.5cm; border:1px solid black;text-align:right'>" & REA.GetDouble("balance_abierto").ToString(FORMATO_MONEDA) & "</td>")
                        dblAcumula = REA.GetDouble("balance_abierto") + dblAcumula
                        Print(f, "<td style='width: 2.8cm; border:1px solid black;text-align:right'>" & REA.GetDouble("monto_Vencido").ToString(FORMATO_MONEDA) & "</td>")
                        If REA.GetMySqlDateTime("Vencimiento").ToString <= Viernes1 Then
                            dblSubTotalSemana1 = dblSubTotalSemana1 + REA.GetDouble("balance_abierto")
                            dblTotalSemana1 = dblTotalSemana1 + REA.GetDouble("balance_abierto")
                            Print(f, "<td style='width: 2.8cm; border:1px solid black;text-align:right'>" & REA.GetDouble("balance_abierto").ToString(FORMATO_MONEDA) & "</td>")
                        Else
                            Print(f, "<td style='width: 2.8cm; border:1px solid black;text-align:right'></td>")
                        End If
                        If REA.GetMySqlDateTime("Vencimiento").ToString > Viernes1 And REA.GetMySqlDateTime("Vencimiento").ToString <= Viernes2 Then
                            dblSubTotalSemana2 = dblSubTotalSemana2 + REA.GetDouble("balance_abierto")
                            dblTotalSemana2 = dblTotalSemana2 + REA.GetDouble("balance_abierto")
                            Print(f, "<td style='width: 2.8cm; border:1px solid black;text-align:right'>" & REA.GetDouble("balance_abierto").ToString(FORMATO_MONEDA) & "</td>")
                        Else
                            Print(f, "<td style='width: 2.8cm; border:1px solid black;text-align:right'></td>")
                        End If
                        If REA.GetMySqlDateTime("Vencimiento").ToString > Viernes2 And REA.GetMySqlDateTime("Vencimiento").ToString <= Viernes3 Then
                            dblSubTotalSemana3 = dblSubTotalSemana3 + REA.GetDouble("balance_abierto")
                            dblTotalSemana3 = dblTotalSemana3 + REA.GetDouble("balance_abierto")
                            Print(f, "<td style='width: 2.8cm; border:1px solid black;text-align:right'>" & REA.GetDouble("balance_abierto").ToString(FORMATO_MONEDA) & "</td>")
                        Else
                            Print(f, "<td style='width: 2.8cm; border:1px solid black;text-align:right'></td>")
                        End If
                        If REA.GetMySqlDateTime("Vencimiento").ToString > Viernes3 And REA.GetMySqlDateTime("Vencimiento").ToString <= Viernes4 Then
                            dblSubTotalSemana4 = dblSubTotalSemana4 + REA.GetDouble("balance_abierto")
                            dblTotalSemana5 = dblTotalSemana4 + REA.GetDouble("balance_abierto")
                            Print(f, "<td style='width: 2.8cm; border:1px solid black;text-align:right'>" & REA.GetDouble("balance_abierto").ToString(FORMATO_MONEDA) & "</td>")
                        Else
                            Print(f, "<td style='width: 2.8cm; border:1px solid black;text-align:right'></td>")
                        End If
                        If REA.GetMySqlDateTime("Vencimiento").ToString > Viernes4 And REA.GetMySqlDateTime("Vencimiento").ToString <= Viernes5 Then
                            dblSubTotalSemana5 = dblSubTotalSemana5 + REA.GetDouble("balance_abierto")
                            dblTotalSemana5 = dblTotalSemana5 + REA.GetDouble("balance_abierto")
                            Print(f, "<td style='width: 2.8cm; border:1px solid black;text-align:right'>" & REA.GetDouble("balance_abierto").ToString(FORMATO_MONEDA) & "</td>")
                        Else
                            Print(f, "<td style='width: 2.8cm; border:1px solid black;text-align:right'></td>")
                        End If
                        If REA.GetMySqlDateTime("Vencimiento").ToString > Viernes5 And REA.GetMySqlDateTime("Vencimiento").ToString <= Viernes6 Then
                            dblSubTotalSemana6 = dblSubTotalSemana6 + REA.GetDouble("balance_abierto")
                            dblTotalSemana6 = dblTotalSemana6 + REA.GetDouble("balance_abierto")
                            Print(f, "<td style='width: 2.8cm; border:1px solid black;text-align:right'>" & REA.GetDouble("balance_abierto").ToString(FORMATO_MONEDA) & "</td>")
                        Else
                            Print(f, "<td style='width: 2.8cm; border:1px solid black;text-align:right'></td>")
                        End If
                        If REA.GetMySqlDateTime("Vencimiento").ToString > Viernes6 And REA.GetMySqlDateTime("Vencimiento").ToString <= Viernes7 Then
                            dblSubTotalSemana7 = dblSubTotalSemana7 + REA.GetDouble("balance_abierto")
                            dblTotalSemana7 = dblTotalSemana7 + REA.GetDouble("balance_abierto")
                            Print(f, "<td style='width: 2.8cm; border:1px solid black;text-align:right'>" & REA.GetDouble("balance_abierto").ToString(FORMATO_MONEDA) & "</td>")
                        Else
                            Print(f, "<td style='width: 2.8cm; border:1px solid black;text-align:right'></td>")
                        End If
                        If REA.GetMySqlDateTime("Vencimiento").ToString > Viernes7 And REA.GetMySqlDateTime("Vencimiento").ToString <= Viernes8 Then
                            dblSubTotalSemana8 = dblSubTotalSemana8 + REA.GetDouble("balance_abierto")
                            dblTotalSemana8 = dblTotalSemana8 + REA.GetDouble("balance_abierto")
                            Print(f, "<td style='width: 2.8cm; border:1px solid black;text-align:right'>" & REA.GetDouble("balance_abierto").ToString(FORMATO_MONEDA) & "</td>")
                        Else
                            Print(f, "<td style='width: 2.8cm; border:1px solid black;text-align:right'></td>")
                        End If
                        If REA.GetMySqlDateTime("Vencimiento").ToString > Viernes8 And REA.GetMySqlDateTime("Vencimiento").ToString <= Viernes9 Then
                            dblSubTotalSemana9 = dblSubTotalSemana9 + REA.GetDouble("balance_abierto")
                            dblTotalSemana9 = dblTotalSemana9 + REA.GetDouble("balance_abierto")
                            Print(f, "<td style='width: 2.8cm; border:1px solid black;text-align:right'>" & REA.GetDouble("balance_abierto").ToString(FORMATO_MONEDA) & "</td>")
                        Else
                            Print(f, "<td style='width: 2.8cm; border:1px solid black;text-align:right'></td>")
                        End If
                        Print(f, "</tr>")

                    End If

                    intLineas = intLineas + 1
                    intGrupo = REA.GetInt16("idGrupo")
                    SaldoVencido = SaldoVencido + CDbl(REA.GetDouble("monto_Vencido"))
                    SumaInteres = SumaInteres + CDbl(REA.GetDouble("intereses"))
                    SaldoQ = SaldoQ + CDbl(REA.GetDouble("balanceQ"))
                    i = i + 1
                Loop
                'Utlimo Total

                Print(f, " <tr> ")
                Print(f, " <td colspan = '8' style='width: 4cm; border:1px solid black;background-color: #CCD1D1'> <b> Total</td>")
                Print(f, "<td style='width: 3.5cm; border:1px solid black;text-align:right;background-color: #CCD1D1'>" & dblAcumula.ToString(FORMATO_MONEDA) & " </td>")
                Print(f, "<td style='width: 2.8cm; border:1px solid black; color:red;text-align:right;background-color: #CCD1D1'>" & SaldoVencido.ToString(FORMATO_MONEDA) & "</td>")
                Print(f, " <td style='width: 2.8cm; border:1px solid black;background-color: #CCD1D1;text-align:right'><b>" & dblSubTotalSemana1.ToString(FORMATO_MONEDA) & " </td>")
                Print(f, " <td style='width: 2.8cm; border:1px solid black;background-color: #CCD1D1;text-align:right'><b>" & dblSubTotalSemana2.ToString(FORMATO_MONEDA) & " </td>")
                Print(f, " <td style='width: 2.8cm; border:1px solid black;background-color: #CCD1D1;text-align:right'><b>" & dblSubTotalSemana3.ToString(FORMATO_MONEDA) & " </td>")
                Print(f, " <td style='width: 2.8cm; border:1px solid black;background-color: #CCD1D1;text-align:right'><b>" & dblSubTotalSemana4.ToString(FORMATO_MONEDA) & " </td>")
                Print(f, " <td style='width: 2.8cm; border:1px solid black;background-color: #CCD1D1;text-align:right'><b>" & dblSubTotalSemana5.ToString(FORMATO_MONEDA) & " </td>")
                Print(f, " <td style='width: 2.8cm; border:1px solid black;background-color: #CCD1D1;text-align:right'><b>" & dblSubTotalSemana6.ToString(FORMATO_MONEDA) & " </td>")
                Print(f, " <td style='width: 2.8cm; border:1px solid black;background-color: #CCD1D1;text-align:right'><b>" & dblSubTotalSemana7.ToString(FORMATO_MONEDA) & " </td>")
                Print(f, " <td style='width: 2.8cm; border:1px solid black;background-color: #CCD1D1;text-align:right'><b>" & dblSubTotalSemana8.ToString(FORMATO_MONEDA) & " </td>")
                Print(f, " <td style='width: 2.8cm; border:1px solid black;background-color: #CCD1D1;text-align:right'><b>" & dblSubTotalSemana9.ToString(FORMATO_MONEDA) & " </td>")
                Print(f, "</tr>")
                dblGranTotalBalance = dblGranTotalBalance + dblAcumula
                dblGranTotalVencido = dblGranTotalVencido + SaldoVencido

                Print(f, " <tr> ")
                Print(f, " <td colspan = '8' style='width: 4cm; border:1px solid black;background-color: #F7DC6F'><b>GRAND TOTAL </td>")
                Print(f, "<td style='width: 3.5cm; border:1px solid black;text-align:right;background-color: #F7DC6F'><b>" & dblGranTotalBalance.ToString(FORMATO_MONEDA) & " </td>")
                Print(f, "<td style='width: 2.8cm; border:1px solid black; color:red;text-align:right;background-color: #F7DC6F'><b>" & dblGranTotalVencido.ToString(FORMATO_MONEDA) & "</td>")
                Print(f, " <td style='width: 2.8cm; border:1px solid black;background-color: #F7DC6F;text-align:right'><b>" & dblTotalSemana1.ToString(FORMATO_MONEDA) & " </td>")
                Print(f, " <td style='width: 2.8cm; border:1px solid black;background-color: #F7DC6F;text-align:right'><b>" & dblTotalSemana2.ToString(FORMATO_MONEDA) & " </td>")
                Print(f, " <td style='width: 2.8cm; border:1px solid black;background-color: #F7DC6F;text-align:right'><b>" & dblTotalSemana3.ToString(FORMATO_MONEDA) & " </td>")
                Print(f, " <td style='width: 2.8cm; border:1px solid black;background-color: #F7DC6F;text-align:right'><b>" & dblTotalSemana4.ToString(FORMATO_MONEDA) & " </td>")
                Print(f, " <td style='width: 2.8cm; border:1px solid black;background-color: #F7DC6F;text-align:right'><b>" & dblTotalSemana5.ToString(FORMATO_MONEDA) & " </td>")
                Print(f, " <td style='width: 2.8cm; border:1px solid black;background-color: #F7DC6F;text-align:right'><b>" & dblTotalSemana6.ToString(FORMATO_MONEDA) & " </td>")
                Print(f, " <td style='width: 2.8cm; border:1px solid black;background-color: #F7DC6F;text-align:right'><b>" & dblTotalSemana7.ToString(FORMATO_MONEDA) & " </td>")
                Print(f, " <td style='width: 2.8cm; border:1px solid black;background-color: #F7DC6F;text-align:right'><b>" & dblTotalSemana8.ToString(FORMATO_MONEDA) & " </td>")
                Print(f, " <td style='width: 2.8cm; border:1px solid black;background-color: #F7DC6F;text-align:right'><b>" & dblTotalSemana9.ToString(FORMATO_MONEDA) & " </td>")
                Print(f, "</tr>")
            End If
            Print(f, "</table>")
            Print(f, "</body>")
            Print(f, "</html>")
            FileClose(f)
            MostarReporte(strTemp)
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub


#End Region

#Region "Ventas X Cliente"
    Private Function SqlVentasXCliente(ByVal intEmp, ByVal intfilter)
        Dim strSQL As String = STR_VACIO
        strSQL = " SELECT vc.codigo , vc.Cliente, vc.Cantidad, vc.Total , vc.Categoria "
        strSQL &= "     FROM YarnDivision.Ventasx_Cliente vc "
        If intEmp = INT_CERO And intfilter = INT_CERO Then
        Else
            strSQL &= "         WHERE idCategoria = {empresa} "
            'strSQL = Replace(strSQL, "{emp}", intEmp)
            strSQL = Replace(strSQL, "{empresa}", intfilter)
        End If
        Return strSQL
    End Function
    Private Function EncabezadoVSxC(ByVal Finicio As Date, ByVal Ffin As Date) As String
        Dim strEncabezado As String = STR_VACIO
        Try
            strEncabezado &= "<html>"
            strEncabezado &= "<head>"
            strEncabezado &= "<title>" & "VSxP" & "</title>"
            strEncabezado &= "<style type='text/css'>"
            strEncabezado &= " table {table-layout: fixed; empty-cells: show; border-collapse:collapse}"
            strEncabezado &= " caption {padding: 5px; text-align:left; font-family: Tahoma, Arial;font-size: 8pt}"
            strEncabezado &= " th {width: 1.8cm; border:solid Silver 1px; background-color: #000080; color: White; padding:2px 5px; font-family: Tahoma, Arial;font-size: 7pt}"
            strEncabezado &= " td {text-align:center;border:solid Silver 1px; padding:3px 5px; font-family: Tahoma, Arial;font-size: 7pt}"
            strEncabezado &= " .titulo {font-family: Tahoma, Arial;font-size: 9pt}"
            strEncabezado &= " .encabezado {text-align: left; border: none; width: 3.1cm}"
            strEncabezado &= " .pie {font-family: Tahoma, Arial;font-size: 7pt}"
            strEncabezado &= " .izquierda {text-align:left}"
            strEncabezado &= " .centro {text-align:center}"
            strEncabezado &= " .derecha {text-align:right}"
            strEncabezado &= " .info {text-align:left; border:none}"
            strEncabezado &= " td.numero {text-align:right; mso-number-format:\#\,\#\#0\.00}"
            strEncabezado &= "</style>"
            strEncabezado &= "</head>"
            strEncabezado &= "<body>"

            '      strEncabezado &= "<span class='titulo'><b>" & Sesion.Empresa & "</b></span><br/><br/>"
            strEncabezado &= "<span class='titulo'><b>" & UCase("SALES BY  YARN  CUSTOMER SUMMARY ") & "</b></span><br/>"
            '   strEncabezado &= "<span class='pie'>FROM" & Finicio.ToString(FORMATO_MYSQL) & " TO " & Ffin.ToString(FORMATO_MYSQL) & "</span>"
            strEncabezado &= "<br/><br/>"

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        Return strEncabezado
    End Function

    Private Function ColumnaVSxC() As String
        Dim strColumnas As String = STR_VACIO
        Try
            strColumnas = "<table cellspacing=0> "
            strColumnas &= " <tr> "
            strColumnas &= "<th style= 'width:6cm' > CUSTOMER</th>"
            strColumnas &= "<th style= 'width:3.5cm'> QUANTITY </th>"
            strColumnas &= "<th style= 'width:3.5cm'> TOTAL US$ </th>"
            strColumnas &= "<th> % </th>"
            strColumnas &= "<th> %ACUM </th>"
            strColumnas &= " </tr> "
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        Return strColumnas
    End Function

    Private Function TotalCategoriaC(ByVal sCategoria As String, ByVal dblLibras As Double, ByVal dblMonto As Double) As String
        Dim strTotalRegion As String = STR_VACIO
        Try
            strTotalRegion &= "<br>"
            strTotalRegion &= "<table >"
            strTotalRegion &= "<tr>"
            strTotalRegion &= " <th style= 'width:6cm;background:gray '>  TOTAL SALES BY CUSTOMER  - " & sCategoria & " - </th>"
            strTotalRegion &= " <th style= 'width:3.5cm;background:gray'> " & dblLibras.ToString(FORMATO_MONEDA) & " </th>"
            strTotalRegion &= " <th style= 'width:3.5cm;background:gray'> " & dblMonto.ToString(FORMATO_MONEDA) & " </th>"
            strTotalRegion &= " <th style= 'background:gray'> 100.00% </th>"
            strTotalRegion &= " <th style= 'background:gray'> - </th>"
            strTotalRegion &= "</tr>"
            strTotalRegion &= "</table>"
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        Return strTotalRegion
    End Function

    Private Function TotalGeneralC(ByVal dblLibras As Double, ByVal dblMonto As Double) As String
        Dim strTotalRegion As String = STR_VACIO
        Try
            strTotalRegion &= "<br>"
            strTotalRegion &= "<table >"
            strTotalRegion &= "<tr>"
            strTotalRegion &= " <th style= 'width:6cm;background:gray '> --  TOTAL SALES BY CUSTOMER  --  </th>"
            strTotalRegion &= " <th style= 'width:3.5cm;background:gray'> " & dblLibras.ToString(FORMATO_MONEDA) & " </th>"
            strTotalRegion &= " <th style= 'width:3.5cm;background:gray'> " & dblMonto.ToString(FORMATO_MONEDA) & " </th>"
            strTotalRegion &= " <th style= 'background:gray'> -- </th>"
            strTotalRegion &= " <th style= 'background:gray'> -- </th>"
            strTotalRegion &= "</tr>"
            strTotalRegion &= "</table>"
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        Return strTotalRegion
    End Function
    Public Sub VentasXClienteCorp(ByVal intEmp As Integer, ByVal intfilter As Integer)
        Dim strSQL As String = STR_VACIO
        Dim frm As New frmFiltro
        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader
        Dim f As Byte
        Dim strTemp As String = STR_VACIO
        Dim strCategoria As String = STR_VACIO

        Dim logPrimeraLinea As Integer = True
        Dim strHtml As String = STR_VACIO

        Dim dblCategoriaMon As Double = INT_CERO
        Dim dblCategorialbs As Double = INT_CERO
        Dim dblTotallbs As Double = INT_CERO
        Dim dblTotalMon As Double = INT_CERO
        Dim dblAcumulado As Double = INT_CERO

        Dim dicTotales As New Dictionary(Of Integer, Double)
        Try
            strTemp = cFunciones.ArchivoTemporal
            f = FreeFile()
            FileOpen(f, strTemp, OpenMode.Append)
            'Encabezado
            Print(f, EncabezadoVSxC(frm.FechaInicio, frm.FechaFin))

            strSQL = SqlVentasXCliente(intEmp, intfilter)

            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSQL, CON)
            REA = COM.ExecuteReader
            If REA.HasRows Then
                Do While REA.Read
                    If logPrimeraLinea = True Then
                        logPrimeraLinea = False

                        strHtml &= ColumnaVSxC()
                        strCategoria = REA.GetString("Categoria")

                    Else
                        If strCategoria = REA.GetString("Categoria") Then

                        Else
                            dicTotales.Add(REA.GetInt32("codigo"), REA.GetDouble("Total"))
                            dblAcumulado = INT_CERO
                            For i As Integer = 0 To dicTotales.Keys.Count - 1
                                strHtml = Replace(strHtml, "%" & dicTotales.Keys(i), (dicTotales.Values(i) / dblCategoriaMon * 100).ToString(FORMATO_MONEDA) & "%")
                                dblAcumulado = dblAcumulado + (dicTotales.Values(i) / dblCategoriaMon * 100)
                                strHtml = Replace(strHtml, "AC" & dicTotales.Keys(i), (dblAcumulado).ToString(FORMATO_MONEDA) & "%")
                            Next
                            dicTotales.Clear()
                            strHtml &= TotalCategoriaC(strCategoria, dblCategorialbs, dblCategoriaMon)
                            strHtml &= ColumnaVSxC()
                            dblCategorialbs = INT_CERO
                            dblCategoriaMon = INT_CERO
                            strCategoria = REA.GetString("Categoria")
                        End If
                    End If
                    '' linea
                    strHtml &= " <tr> "
                    strHtml &= "<td>" & REA.GetString("Cliente") & "</td>"
                    strHtml &= "<td>" & REA.GetDouble("Cantidad").ToString(FORMATO_MONEDA) & "</td>"
                    strHtml &= "<td>" & REA.GetDouble("Total").ToString(FORMATO_MONEDA) & "</td>"
                    strHtml &= "<td>%" & REA.GetInt32("codigo") & "</td>"
                    strHtml &= "<td>AC" & REA.GetInt32("codigo") & "</td>"
                    strHtml &= " </tr> "
                    ' agregar a diccionario
                    dicTotales.Add(REA.GetInt32("codigo"), REA.GetDouble("Total"))

                    dblCategorialbs = dblCategorialbs + REA.GetDouble("Cantidad")
                    dblCategoriaMon = dblCategoriaMon + REA.GetDouble("Total")
                    'dblTotallbs = dblTotallbs + REA.GetDouble("Cantidad")
                    dblTotalMon = dblTotalMon + REA.GetDouble("Total")
                    dblTotallbs = dblTotallbs + REA.GetDouble("Cantidad")
                Loop
            End If
            dblAcumulado = INT_CERO
            For i As Integer = 0 To dicTotales.Keys.Count - 1
                strHtml = Replace(strHtml, "%" & dicTotales.Keys(i), (dicTotales.Values(i) / dblCategoriaMon * 100).ToString(FORMATO_MONEDA) & "%")
                dblAcumulado = dblAcumulado + (dicTotales.Values(i) / dblCategoriaMon * 100)
                strHtml = Replace(strHtml, "AC" & dicTotales.Keys(i), (dblAcumulado).ToString(FORMATO_MONEDA) & "%")
            Next
            dicTotales.Clear()

            strHtml &= TotalCategoriaC(strCategoria, dblCategorialbs, dblCategoriaMon)
            strHtml &= TotalGeneralC(dblTotallbs, dblTotalMon)
            Print(f, strHtml)
            Print(f, "</table>")
            Print(f, "<br/>")
            Print(f, "</body>")
            Print(f, "</html>")
            FileClose(f)
            MostarReporte(strTemp)
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try

    End Sub

#End Region

#Region "AR_Detail_CreditLimit"

    Public Sub AR_DetailCorpCreditLimit(ByVal intEmp As Integer, ByVal intfilter As Integer, ByVal fec As Date)
        Dim sql As String = STR_VACIO
        Dim strTemp As String = STR_VACIO
        Dim REA As MySqlDataReader
        Dim COM As MySqlCommand
        Dim f As Byte
        Dim i As Integer = 0
        Dim intGrupo As Integer = 0
        Dim dblAcumula As Double = 0
        Dim SaldoVencido As Double = 0
        Dim intLineas As Integer = 0
        Dim SumaInteres As Double = 0
        Dim SaldoQ As Double = 0
        Dim diasAtrasados As String = vbNullString
        Dim strCadena As String = STR_VACIO
        Dim arrayCadena() As String
        Dim dblGranTotalBalance As Double = 0
        Dim dblGranTotalVencido As Double = 0
        Dim Viernes1 As DateTime
        Dim Viernes2 As DateTime
        Dim Viernes3 As DateTime

        Dim strNombreGrRpt As String = STR_VACIO
        Dim strClienteRpt As String = STR_VACIO
        Dim strCreditLimitRpt As Double = INT_CERO
        Dim strCompaniaRpt As String = STR_VACIO
        Dim strTermsRpt As String = STR_VACIO


        Dim dblSubTotalSemana1 As Double = INT_CERO
        Dim dblSubTotalSemana2 As Double = INT_CERO
        Dim dblSubTotalSemana3 As Double = INT_CERO
        Dim dblTotalSemana1 As Double = INT_CERO
        Dim dblTotalSemana2 As Double = INT_CERO
        Dim dblTotalSemana3 As Double = INT_CERO

        sql = SqlAR_Detail(intEmp, intfilter)
        Try
            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(sql, CON)
            REA = COM.ExecuteReader

            strTemp = cFunciones.ArchivoTemporal
            f = FreeFile()
            FileOpen(f, strTemp, OpenMode.Append)

            If REA.HasRows Then
                Do While REA.Read

                    If i = 0 Then

                        Print(f, " <html > ")
                        Print(f, " <head > ")
                        Print(f, "<style type='text/css'>")
                        Print(f, " table {table-layout: fixed; empty-cells: show; border-collapse:collapse}")
                        Print(f, " caption {padding: 5px; text-align:left; font-family: Tahoma,  Arial;font-size: 8pt}")
                        Print(f, " td {text-align:center;border:solid Gray 1px; padding:3px 5px; font-family: Tahoma, Arial;font-size: 7pt}")
                        Print(f, " th {width: 1.8cm; border:solid Gray 1px; background-color: Black; color: White; padding:2px 5px; font-family: Tahoma,  Arial;font-size: 6pt}")
                        Print(f, " th {text-align:center;border:solid Gray 1px; padding:3px 5px; font-family: Tahoma,  Arial;font-size: 7pt}")
                        Print(f, " th.numero {text-align:right; mso-number-format:\#\,\#\#0\.00}")
                        Print(f, " th.unitario {text-align:right; mso-number-format:\#\,\#\#0\.00#####}")
                        Print(f, " th.titulo {text-align:right;font-family: Tahoma,  Arial;font-size: 9pt")
                        Print(f, " .titulo {font-family: Tahoma,  Arial;font-size: 9pt}")
                        Print(f, " .encabezado {text-align: left; border: none; width: 3.1cm}")
                        Print(f, " .pie {font-family: Tahoma,  Arial;font-size: 7pt}")
                        Print(f, " .izquierda {text-align:left}")
                        Print(f, " .centro {text-align:center}")
                        Print(f, " .derecha {text-align:right}")
                        Print(f, " .info {text-align:left; border:none}")
                        Print(f, "</style>")
                        Print(f, "<right><h3> <b> <th > AR Detail</th></h3></b></right>")
                        Print(f, "<right><h5> <b> <th > cutoff date: " & fec.ToString(FORMATO_MYSQL) & " </th></h5></b></right>")
                        Print(f, "<right><h3> <b> <th > Amounts expressed in US$</th></h3></b></right>")
                        Print(f, "</head>")

                        Print(f, "<body>")
                        Print(f, "<table cellspacing =0 >")
                        Print(f, "<tr>")
                        Print(f, "<th style='width: 4cm; border:1px solid black'>GROUP</th>")
                        Print(f, "<th style='width: 5cm; border:1px solid black'>CUSTOMER</th>")
                        Print(f, "<th style='width: 3cm; border:1px solid black'>CREDIT LIMIT</th>")
                        Print(f, "<th style='width: 3cm; border:1px solid black'>COMPANY</th>")
                        Print(f, "<th style='width: 1.5cm; border:1px solid black'>TERMS</th>")
                        Print(f, "<th style='width: 3.5cm; border:1px solid black'>OPEN BALANCE</th>")
                        Print(f, "<th style='width: 2.8cm; border:1px solid black'>PAST DUES</th>")
                        Viernes1 = ObtenerViernes(REA.GetDateTime("registro"))
                        Viernes2 = Viernes1.AddDays(+7)
                        Viernes3 = Viernes1.AddDays(+14)
                        Print(f, "<th style='width: 2.8cm; border:1px solid black'>" & Viernes1 & "</th>")
                        Print(f, "<th style='width: 2.8cm; border:1px solid black'>" & Viernes2 & "</th>")
                        Print(f, "<th style='width: 2.8cm; border:1px solid black'>" & Viernes3 & "</th>")
                        Print(f, "</tr>")
                    End If

                    If Not intGrupo = REA.GetInt16("idGrupo") Then


                        If intLineas > 0 Then
                            'imprima total
                            Print(f, " <tr> ")
                            Print(f, " <td style='width: 4cm; border:1px solid black'>" & strNombreGrRpt & "</td>")
                            Print(f, " <td style='width: 5cm; border:1px solid black'>" & strClienteRpt & "</td>")
                            Print(f, " <td style='width: 3cm; border:1px solid black'>" & strCreditLimitRpt.ToString(FORMATO_MONEDA) & "</td>")
                            Print(f, "<td style='width: 4cm; border:1px solid black; background-color: #F2F5A9'>" & strCompaniaRpt & "</td>")
                            Print(f, "<td style='width: 1.5cm; border:1px solid black'>" & strTermsRpt & "</td>")

                            Print(f, "<td style='width: 3.5cm; border:1px solid black;text-align:right;background-color: #CCD1D1'><b>" & dblAcumula.ToString(FORMATO_MONEDA) & " </td>")
                            If SaldoVencido = 0 Then
                                Print(f, "<td style='width: 2.8cm; border:1px solid black; color:red;text-align:right;background-color: #CCD1D1'><br></td>")
                            Else
                                Print(f, "<td style='width: 2.8cm; border:1px solid black; color:red;text-align:right;background-color: #CCD1D1'><b>" & SaldoVencido.ToString(FORMATO_MONEDA) & "</td>")
                            End If
                            If dblSubTotalSemana1 = 0 Then
                                Print(f, " <td style='width: 2.8cm; border:1px solid black;background-color: #CCD1D1;text-align:right'><br> </td>")
                            Else
                                Print(f, " <td style='width: 2.8cm; border:1px solid black;background-color: #CCD1D1;text-align:right'><b>" & dblSubTotalSemana1.ToString(FORMATO_MONEDA) & " </td>")
                            End If
                            If dblSubTotalSemana2 = 0 Then
                                Print(f, " <td style='width: 2.8cm; border:1px solid black;background-color: #CCD1D1;text-align:right'><br></td>")
                            Else
                                Print(f, " <td style='width: 2.8cm; border:1px solid black;background-color: #CCD1D1;text-align:right'><b>" & dblSubTotalSemana2.ToString(FORMATO_MONEDA) & " </td>")
                            End If
                            If dblSubTotalSemana3 = 0 Then
                                Print(f, " <td style='width: 2.8cm; border:1px solid black;background-color: #CCD1D1;text-align:right'><br> </td>")
                            Else
                                Print(f, " <td style='width: 2.8cm; border:1px solid black;background-color: #CCD1D1;text-align:right'><b>" & dblSubTotalSemana3.ToString(FORMATO_MONEDA) & " </td>")
                            End If

                            Print(f, "</tr>")
                            dblGranTotalBalance = dblGranTotalBalance + dblAcumula
                            dblGranTotalVencido = dblGranTotalVencido + SaldoVencido
                        End If

                        'Reinicia Valores Necesarios
                        intLineas = 0
                        dblAcumula = 0
                        SaldoVencido = 0
                        SumaInteres = 0
                        SaldoQ = 0
                        dblSubTotalSemana1 = 0
                        dblSubTotalSemana2 = 0
                        dblSubTotalSemana3 = 0
                        strNombreGrRpt = STR_VACIO
                        strClienteRpt = STR_VACIO
                        strCreditLimitRpt = INT_CERO
                        strCompaniaRpt = STR_VACIO
                        strTermsRpt = STR_VACIO

                        strNombreGrRpt = REA.GetString("nombreGrupo")
                        strClienteRpt = REA.GetString("nombreEmp")
                        strCreditLimitRpt = REA.GetDouble("limiteCredito").ToString(FORMATO_MONEDA)
                        strCompaniaRpt = REA.GetString("nombre_empresa")
                        strTermsRpt = REA.GetString("diasCredito")

                        dblAcumula = REA.GetDouble("balance_abierto") + dblAcumula
                        If REA.GetMySqlDateTime("Vencimiento").ToString <= Viernes1 Then
                            dblSubTotalSemana1 = dblSubTotalSemana1 + REA.GetDouble("balance_abierto")
                            dblTotalSemana1 = dblTotalSemana1 + REA.GetDouble("balance_abierto")

                        End If
                        If REA.GetMySqlDateTime("Vencimiento").ToString > Viernes1 And REA.GetMySqlDateTime("Vencimiento").ToString <= Viernes2 Then
                            dblSubTotalSemana2 = dblSubTotalSemana2 + REA.GetDouble("balance_abierto")
                            dblTotalSemana2 = dblTotalSemana2 + REA.GetDouble("balance_abierto")
                        End If
                        If REA.GetMySqlDateTime("Vencimiento").ToString > Viernes2 And REA.GetMySqlDateTime("Vencimiento").ToString <= Viernes3 Then
                            dblSubTotalSemana3 = dblSubTotalSemana3 + REA.GetDouble("balance_abierto")
                            dblTotalSemana3 = dblTotalSemana3 + REA.GetDouble("balance_abierto")
                        End If

                    Else
                        dblAcumula = REA.GetDouble("balance_abierto") + dblAcumula
                        If REA.GetMySqlDateTime("Vencimiento").ToString <= Viernes1 Then
                            dblSubTotalSemana1 = dblSubTotalSemana1 + REA.GetDouble("balance_abierto")
                            dblTotalSemana1 = dblTotalSemana1 + REA.GetDouble("balance_abierto")
                        End If
                        If REA.GetMySqlDateTime("Vencimiento").ToString > Viernes1 And REA.GetMySqlDateTime("Vencimiento").ToString <= Viernes2 Then
                            dblSubTotalSemana2 = dblSubTotalSemana2 + REA.GetDouble("balance_abierto")
                            dblTotalSemana2 = dblTotalSemana2 + REA.GetDouble("balance_abierto")
                        End If
                        If REA.GetMySqlDateTime("Vencimiento").ToString > Viernes2 And REA.GetMySqlDateTime("Vencimiento").ToString <= Viernes3 Then
                            dblSubTotalSemana3 = dblSubTotalSemana3 + REA.GetDouble("balance_abierto")
                            dblTotalSemana3 = dblTotalSemana3 + REA.GetDouble("balance_abierto")
                        End If

                    End If

                    intLineas = intLineas + 1
                    intGrupo = REA.GetInt16("idGrupo")
                    SaldoVencido = SaldoVencido + CDbl(REA.GetDouble("monto_Vencido"))
                    SumaInteres = SumaInteres + CDbl(REA.GetDouble("intereses"))
                    SaldoQ = SaldoQ + CDbl(REA.GetDouble("balanceQ"))
                    i = i + 1
                Loop
                'Utlimo Total

                Print(f, " <tr> ")
                Print(f, " <td style='width: 4cm; border:1px solid black'>" & strNombreGrRpt & "</td>")
                Print(f, " <td style='width: 5cm; border:1px solid black'>" & strClienteRpt & "</td>")
                Print(f, " <td style='width: 3cm; border:1px solid black'>" & strCreditLimitRpt.ToString(FORMATO_MONEDA) & "</td>")
                Print(f, "<td style='width: 4cm; border:1px solid black; background-color: #F2F5A9'>" & strCompaniaRpt & "</td>")
                Print(f, "<td style='width: 1.5cm; border:1px solid black'>" & strTermsRpt & "</td>")
                Print(f, "<td style='width: 3.5cm; border:1px solid black;text-align:right;background-color: #CCD1D1'><b>" & dblAcumula.ToString(FORMATO_MONEDA) & " </td>")
                If SaldoVencido = 0 Then
                    Print(f, "<td style='width: 2.8cm; border:1px solid black; color:red;text-align:right;background-color: #CCD1D1'><br></td>")
                Else
                    Print(f, "<td style='width: 2.8cm; border:1px solid black; color:red;text-align:right;background-color: #CCD1D1'><b>" & SaldoVencido.ToString(FORMATO_MONEDA) & "</td>")
                End If
                If dblSubTotalSemana1 = 0 Then
                    Print(f, " <td style='width: 2.8cm; border:1px solid black;background-color: #CCD1D1;text-align:right'><br> </td>")
                Else
                    Print(f, " <td style='width: 2.8cm; border:1px solid black;background-color: #CCD1D1;text-align:right'><b>" & dblSubTotalSemana1.ToString(FORMATO_MONEDA) & " </td>")
                End If
                If dblSubTotalSemana2 = 0 Then
                    Print(f, " <td style='width: 2.8cm; border:1px solid black;background-color: #CCD1D1;text-align:right'><br></td>")
                Else
                    Print(f, " <td style='width: 2.8cm; border:1px solid black;background-color: #CCD1D1;text-align:right'><b>" & dblSubTotalSemana2.ToString(FORMATO_MONEDA) & " </td>")
                End If
                If dblSubTotalSemana3 = 0 Then
                    Print(f, " <td style='width: 2.8cm; border:1px solid black;background-color: #CCD1D1;text-align:right'><br> </td>")
                Else
                    Print(f, " <td style='width: 2.8cm; border:1px solid black;background-color: #CCD1D1;text-align:right'><b>" & dblSubTotalSemana3.ToString(FORMATO_MONEDA) & " </td>")
                End If
                Print(f, "</tr>")
                dblGranTotalBalance = dblGranTotalBalance + dblAcumula
                dblGranTotalVencido = dblGranTotalVencido + SaldoVencido

                Print(f, " <tr> ")
                Print(f, " <td colspan = '5' style='width: 4cm; border:1px solid black;background-color: #F7DC6F'><b>GRAND TOTAL </td>")
                Print(f, "<td style='width: 3.5cm; border:1px solid black;text-align:right;background-color: #F7DC6F'><b>" & dblGranTotalBalance.ToString(FORMATO_MONEDA) & " </td>")
                Print(f, "<td style='width: 2.8cm; border:1px solid black; color:red;text-align:right;background-color: #F7DC6F'><b>" & dblGranTotalVencido.ToString(FORMATO_MONEDA) & "</td>")
                Print(f, " <td style='width: 2.8cm; border:1px solid black;background-color: #F7DC6F;text-align:right'><b>" & dblTotalSemana1.ToString(FORMATO_MONEDA) & " </td>")
                Print(f, " <td style='width: 2.8cm; border:1px solid black;background-color: #F7DC6F;text-align:right'><b>" & dblTotalSemana2.ToString(FORMATO_MONEDA) & " </td>")
                Print(f, " <td style='width: 2.8cm; border:1px solid black;background-color: #F7DC6F;text-align:right'><b>" & dblTotalSemana3.ToString(FORMATO_MONEDA) & " </td>")
                Print(f, "</tr>")
            End If
            Print(f, "</table>")
            Print(f, "</body>")
            Print(f, "</html>")
            FileClose(f)
            MostarReporte(strTemp)
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub


#End Region

#Region "Inventario en Transito"
    Private Function sqlInventarioenTransito(ByVal intEmp As Integer, ByVal intFiltro As Integer, ByVal Fecha As Date) As String
        Dim strSQL As String = STR_VACIO

        strSQL = " SELECT e.nombre_empresa empresa,it.*  "
        strSQL &= "     FROM YarnDivision.Inventario_Transito it "
        strSQL &= "         LEFT JOIN YarnDivision.Empresa e ON e.idEmpresa = it.idEmpresa  "
        strSQL &= "             WHERE it.Correlativo > 0 {emp} {filtro} AND Fecha <= '{fecha}'"
        strSQL &= "                 ORDER BY Tipo DESC, Correlativo"
        If intEmp = INT_CERO Then
            strSQL = Replace(strSQL, "{emp}", "")
        Else
            strSQL = Replace(strSQL, "{emp}", " AND it.idEmpresa = " & intEmp)
        End If
        If intFiltro = INT_CERO Then
            strSQL = Replace(strSQL, "{filtro}", " AND it.Tipo = 'YARN' ")
        ElseIf intFiltro = INT_UNO Then
            strSQL = Replace(strSQL, "{filtro}", " AND it.Tipo = 'CHEMICAL' ")
        ElseIf intFiltro = 2 Then
            strSQL = Replace(strSQL, "{filtro}", " AND it.Tipo = 'FIBER' ")
        ElseIf intFiltro = 3 Then
            strSQL = Replace(strSQL, "{filtro}", " ")
        End If
        strSQL = Replace(strSQL, "{fecha}", Fecha.ToString(FORMATO_MYSQL))

        Return strSQL
    End Function
    Private Function sqlInventarioTransitoCompany(ByVal intEmp As Integer) As String
        Dim strSQL As String = STR_VACIO
        strSQL = " SELECT  it.Origen,it.Intercompany,SUM(ROUND(it.Cantidad,2)) Cantidad,SUM(Round(it.Total,2)) Total "
        strSQL &= "     FROM YarnDivision.Inventario_Transito it  "
        strSQL &= "         WHERE it.Intercompany <> '' {emp}"
        strSQL &= "             GROUP BY it.idEmpresa,it.idIntercompany "

        If intEmp = INT_CERO Then
            strSQL = Replace(strSQL, "{emp}", "")
        Else
            strSQL = Replace(strSQL, "{emp}", " AND it.idEmpresa = " & intEmp)
        End If
        Return strSQL
    End Function
    Private Function SQLEmpresaTransito() As String
        Dim strSQL As String = STR_VACIO
        strSQL = " SELECT e.idEmpresa Empresa , e.nombre_empresa Nombre "
        strSQL &= "    FROM YarnDivision.Empresa e  "
        strSQL &= "        ORDER BY e.Ordenamiento "
        Return strSQL
    End Function
    Public Sub InventarioenTransito(ByVal intEmp As Integer, ByVal intFiltro As Integer, ByVal dtFecha As Date)
        Dim sql As String = STR_VACIO
        Dim strTemp As String = STR_VACIO
        Dim logPrimera As Boolean = False
        Dim REA As MySqlDataReader
        Dim COM As MySqlCommand
        Dim f As Byte
        Dim dblTotal(9) As Double
        Dim dblGranTotal(6) As Double
        Dim dblSuperCantidadTotal As Double
        Dim dblSuperGranTotal As Double
        Dim dblSuperGranTotalLocal As Double
        Dim totalYarn As Double
        Dim totalFiber As Double
        Dim totalChemical As Double
        'Hilo
        Dim dblCantidadHilos As Double = INT_CERO
        Dim dblCantidadPrideYarn As Double = INT_CERO
        Dim dblCantidadAmtex As Double = INT_CERO
        Dim dblCantidadDominican As Double = INT_CERO
        Dim dblMontoHilos As Double = INT_CERO
        Dim dblMontoPrideYarn As Double = INT_CERO
        Dim dblMontoAmtex As Double = INT_CERO
        Dim dblMontoDominican As Double = INT_CERO
        'Quimicos
        Dim dblCantidadQuimicosAmtex As Double = INT_CERO
        Dim dblMontoQuimicosAmtex As Double = INT_CERO
        Dim dblCantidadQuimicosHilos As Double = INT_CERO
        Dim dblMontoQuimicosHilos As Double = INT_CERO
        Dim dblCantidadQuimicosPrideYarn As Double = INT_CERO
        Dim dblMontoQuimicosPrideYarn As Double = INT_CERO
        Dim dblCantidadQuimicosDominican As Double = INT_CERO
        Dim dblMontoQuimicosDominican As Double = INT_CERO
        'Fibra
        Dim dblCantidadFibraHilos As Double = INT_CERO
        Dim dblCantidadFibraPrideYarn As Double = INT_CERO
        Dim dblCantidadFibraAmtex As Double = INT_CERO
        Dim dblCantidadFibraDominican As Double = INT_CERO
        Dim dblMontoFibraHilos As Double = INT_CERO
        Dim dblMontoFibraPrideYarn As Double = INT_CERO
        Dim dblMontoFibraAmtex As Double = INT_CERO
        Dim dblMontoFibraDominican As Double = INT_CERO

        Dim intEmpresa As Integer = INT_CERO
        Dim strTipo As String = STR_VACIO
        Dim strMonedaLocal As String
        Dim strMonedaExt As String

        Try
            sql = sqlInventarioenTransito(intEmp, intFiltro, dtFecha)
            strMonedaLocal = cFunciones.TraerMoneda(cFunciones.DivisaLocal)
            strMonedaExt = cFunciones.TraerMoneda(cFunciones.DivisaExtranjera)

            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(sql, CON)
            REA = COM.ExecuteReader

            strTemp = cFunciones.ArchivoTemporal
            f = FreeFile()

            FileOpen(f, strTemp, OpenMode.Append)
            Print(f, " <html > ")
            Print(f, " <head > ")
            Print(f, "<style type='text/css'>")
            Print(f, " table {table-layout: fixed; empty-cells: show; border-collapse:collapse}")
            Print(f, " caption {padding: 5px; text-align:left; font-family: Tahoma,  Arial;font-size: 8pt}")
            Print(f, " td {text-align:center;border:solid Gray 1px; padding:3px 5px; font-family: Tahoma, Arial;font-size: 7pt}")
            Print(f, " th {width: 1.8cm; border:solid Gray 1px; background-color: Black; color: White; padding:2px 5px; font-family: Tahoma,  Arial;font-size: 6pt}")
            Print(f, " th {text-align:center;border:solid Gray 1px; padding:3px 5px; font-family: Tahoma,  Arial;font-size: 7pt}")
            Print(f, " th.numero {text-align:right; mso-number-format:\#\,\#\#0\.00}")
            Print(f, " th.unitario {text-align:right; mso-number-format:\#\,\#\#0\.00#####}")
            Print(f, " th.titulo {text-align:right;font-family: Tahoma,  Arial;font-size: 9pt")
            Print(f, " .titulo {font-family: Tahoma,  Arial;font-size: 9pt}")
            Print(f, " .encabezado {text-align: left; border: none; width: 3.1cm}")
            Print(f, " .pie {font-family: Tahoma,  Arial;font-size: 7pt}")
            Print(f, " .izquierda {text-align:left}")
            Print(f, " .centro {text-align:center}")
            Print(f, " .derecha {text-align:right}")
            Print(f, " .info {text-align:left; border:none}")
            Print(f, "</style>")
            Print(f, "<center><h3> <b> <th > INVENTORY IN TRANSIT</th></h3></b></center>")
            Print(f, "<center><h3> <b> <th > " & dtFecha.ToString(FORMATO_MYSQL) & "</th></h3></b></center>")
            Print(f, "</head>")
            Print(f, "<body>")
            If REA.HasRows Then
                Do While REA.Read
                    If logPrimera = False Then
                        Print(f, "<table cellspacing =0 >")

                        Print(f, " <tr> ")
                        Print(f, "<th colspan = 13 style='background-color: gray; font-weight: bold; text-align: center; width: 37cm'>" & REA.GetString("Tipo") & "</th>")
                        Print(f, "</tr>")

                        Print(f, "<tr>")
                        Print(f, "<th style='width: 4cm; border:1px solid black'>COMPANY</th>")
                        Print(f, "<th style='width: 2cm; border:1px solid black'>DATE</th>")
                        Print(f, "<th style='width: 4cm; border:1px solid black'>PROVIDER</th>")
                        Print(f, "<th style='width: 4cm; border:1px solid black'>REFERENCE</th>")
                        Print(f, "<th style='width: 9cm; border:1px solid black'>YARN</th>")
                        Print(f, "<th style='width: 2cm; border:1px solid black'>QUANTITY</th>")
                        Print(f, "<th style='width: 2cm; border:1px solid black'>PRICE</th>")
                        Print(f, "<th style='width: 2cm; border:1px solid black'>TOTAL " & strMonedaExt & " </th>")
                        Print(f, "<th style='width: 2cm; border:1px solid black'>TC</th>")
                        Print(f, "<th style='width: 2cm; border:1px solid black'>TOTAL LOCAL</th>")
                        Print(f, "<th style='width: 2cm; border:1px solid black'>ETD </th>")
                        Print(f, "<th style='width: 2cm; border:1px solid black'>ETA</th>")
                        Print(f, "<th style='width: 2cm; border:1px solid black'>CREATION DATE</th>")
                        Print(f, "</tr>")

                        Print(f, " <tr> ")
                        Print(f, "<td>" & REA.GetString("empresa") & "</td>")
                        Print(f, "<td>" & REA.GetDateTime("Fecha") & "</td>")
                        Print(f, "<td>" & REA.GetString("Proveedor") & "</td>")
                        Print(f, "<td>" & REA.GetString("Referencia") & "</td>")
                        Print(f, "<td>" & REA.GetString("Hilo") & "</td>")
                        Print(f, "<td>" & REA.GetDouble("Cantidad").ToString(FORMATO_MONEDA) & "</td>")
                        Print(f, "<td>" & REA.GetDouble("Precio") & "</td>")
                        Print(f, "<td>" & Math.Round(REA.GetDouble("Total") + 0.0000000001, 2).ToString(FORMATO_MONEDA) & "</td>")
                        Print(f, "<td>" & REA.GetDouble("Tasa") & "</td>")
                        Print(f, "<td>" & Math.Round(REA.GetDouble("TotalLocal"), 2).ToString(FORMATO_MONEDA) & "</td>")
                        Print(f, "<td>" & REA.GetString("ETD") & "</td>")
                        Print(f, "<td>" & REA.GetString("ETA") & "</td>")
                        Print(f, "<td>" & REA.GetDateTime("FechaCreacion") & "</td>")
                        Print(f, "</tr>")

                        ' If REA.GetString("Tipo") = "YARN" Then
                        dblTotal(1) = dblTotal(1) + REA.GetDouble("Cantidad")
                        dblTotal(2) = dblTotal(2) + Math.Round(REA.GetDouble("Total") + 0.0000000001, 2)
                        dblTotal(3) = dblTotal(3) + Math.Round(REA.GetDouble("TotalLocal"), 2)
                        'dblSuperCantidadTotal = dblSuperCantidadTotal + dblTotal(1)
                        'dblSuperGranTotal = dblSuperGranTotal + dblTotal(2)
                        'dblSuperGranTotalLocal = dblSuperGranTotalLocal + dblTotal(3)
                        ' ElseIf REA.GetString("Tipo") = "CHEMICAL" Then
                        ' dblTotal(4) = dblTotal(4) + REA.GetDouble("Cantidad")
                        ' dblTotal(5) = dblTotal(5) + Math.Round(REA.GetDouble("Total") + 0.0000000001, 2)
                        ' dblTotal(6) = dblTotal(6) + Math.Round(REA.GetDouble("TotalLocal"), 2)
                        '   Else
                        ' dblTotal(7) = dblTotal(7) + REA.GetDouble("Cantidad")
                        'dblTotal(8) = dblTotal(8) + Math.Round(REA.GetDouble("Total") + 0.0000000001, 2)
                        'dblTotal(9) = dblTotal(9) + Math.Round(REA.GetDouble("TotalLocal"), 2)
                        '  End If
                        strTipo = REA.GetString("Tipo")
                        intEmpresa = REA.GetInt32("idEmpresa")
                        logPrimera = True

                    Else

                        If strTipo = REA.GetString("Tipo") Then
                            Print(f, " <tr> ")
                            Print(f, "<td>" & REA.GetString("empresa") & "</td>")
                            Print(f, "<td>" & REA.GetDateTime("Fecha") & "</td>")
                            Print(f, "<td>" & REA.GetString("Proveedor") & "</td>")
                            Print(f, "<td>" & REA.GetString("Referencia") & "</td>")
                            Print(f, "<td>" & REA.GetString("Hilo") & "</td>")
                            Print(f, "<td>" & REA.GetDouble("Cantidad").ToString(FORMATO_MONEDA) & "</td>")
                            Print(f, "<td>" & REA.GetDouble("Precio") & "</td>")
                            Print(f, "<td>" & Math.Round(REA.GetDouble("Total") + 0.0000000001, 2).ToString(FORMATO_MONEDA) & "</td>")
                            Print(f, "<td>" & REA.GetDouble("Tasa") & "</td>")
                            Print(f, "<td>" & Math.Round(REA.GetDouble("TotalLocal"), 2).ToString(FORMATO_MONEDA) & "</td>")
                            Print(f, "<td>" & REA.GetString("ETD") & "</td>")
                            Print(f, "<td>" & REA.GetString("ETA") & "</td>")
                            Print(f, "<td>" & REA.GetDateTime("FechaCreacion") & "</td>")
                            Print(f, "</tr>")
                            '   If REA.GetString("Tipo") = "YARN" Then
                            dblTotal(1) = dblTotal(1) + REA.GetDouble("Cantidad")
                            dblTotal(2) = dblTotal(2) + Math.Round(REA.GetDouble("Total") + 0.0000000001, 2)
                            dblTotal(3) = dblTotal(3) + Math.Round(REA.GetDouble("TotalLocal"), 2)
                            '  ElseIf REA.GetString("Tipo") = "CHEMICAL" Then
                            '     dblTotal(4) = dblTotal(4) + REA.GetDouble("Cantidad")
                            '    dblTotal(5) = dblTotal(5) + Math.Round(REA.GetDouble("Total") + 0.0000000001, 2)
                            '   dblTotal(6) = dblTotal(6) + Math.Round(REA.GetDouble("TotalLocal"), 2)
                            '   Else
                            '  dblTotal(7) = dblTotal(7) + REA.GetDouble("Cantidad")
                            ' dblTotal(8) = dblTotal(8) + Math.Round(REA.GetDouble("Total") + 0.0000000001, 2)
                            ' dblTotal(9) = dblTotal(9) + Math.Round(REA.GetDouble("TotalLocal"), 2)
                            '  End If
                            strTipo = REA.GetString("Tipo")
                            intEmpresa = REA.GetInt32("idEmpresa")
                        Else
                            '  If strTipo = "YARN" Then
                            Print(f, "<tr style='background-color: Silver'>")
                            Print(f, "<td colspan = 5>Sub-Total</td>")
                            Print(f, "<td class='numero'>" & dblTotal(1).ToString(FORMATO_MONEDA) & "</td>")
                            Print(f, "<td></td>")
                            Print(f, "<td class='numero'>" & dblTotal(2).ToString(FORMATO_MONEDA) & "</td>")
                            Print(f, "<td></td>")
                            Print(f, "<td class='numero'>" & dblTotal(3).ToString(FORMATO_MONEDA) & "</td>")
                            Print(f, "<td></td>")
                            Print(f, "<td></td>")
                            Print(f, "</tr>")
                            Print(f, "<br/>")

                            dblSuperCantidadTotal = dblSuperCantidadTotal + dblTotal(1)
                            dblSuperGranTotal = dblSuperGranTotal + dblTotal(2)
                            dblSuperGranTotalLocal = dblSuperGranTotalLocal + dblTotal(3)
                            dblTotal(1) = INT_CERO
                            dblTotal(2) = INT_CERO
                            dblTotal(3) = INT_CERO
                            '   ElseIf strTipo = "FIBER" Then
                            'Print(f, "<tr style='background-color: Silver'>")
                            '    Print(f, "<td colspan = 5>Sub-Total</td>")
                            '    Print(f, "<td class='numero'>" & dblTotal(7).ToString(FORMATO_MONEDA) & "</td>")
                            '    Print(f, "<td></td>")
                            '    Print(f, "<td class='numero'>" & dblTotal(8).ToString(FORMATO_MONEDA) & "</td>")
                            '    Print(f, "<td></td>")
                            '    Print(f, "<td class='numero'>" & dblTotal(9).ToString(FORMATO_MONEDA) & "</td>")
                            '    Print(f, "<td></td>")
                            '    Print(f, "<td></td>")
                            '    Print(f, "</tr>")
                            '    Print(f, "<br/>")
                            'End If
                            Print(f, " <tr> ")
                            Print(f, "<th colspan = 13 style='background-color: gray; font-weight: bold; text-align: center; width: 37cm'>" & REA.GetString("Tipo") & "</th>")
                            Print(f, "</tr>")
                            Print(f, "<tr>")
                            Print(f, "<th style='width: 4cm; border:1px solid black'>COMPANY</th>")
                            Print(f, "<th style='width: 2cm; border:1px solid black'>DATE</th>")
                            Print(f, "<th style='width: 4cm; border:1px solid black'>PROVIDER</th>")
                            Print(f, "<th style='width: 4cm; border:1px solid black'>REFERENCE</th>")
                            Print(f, "<th style='width: 9cm; border:1px solid black'>YARN</th>")
                            Print(f, "<th style='width: 2cm; border:1px solid black'>QUANTITY</th>")
                            Print(f, "<th style='width: 2cm; border:1px solid black'>PRICE</th>")
                            Print(f, "<th style='width: 2cm; border:1px solid black'>TOTAL " & strMonedaExt & " </th>")
                            Print(f, "<th style='width: 2cm; border:1px solid black'>TC</th>")
                            Print(f, "<th style='width: 2cm; border:1px solid black'>TOTAL LOCAL</th>")
                            Print(f, "<th style='width: 2cm; border:1px solid black'>ETD </th>")
                            Print(f, "<th style='width: 2cm; border:1px solid black'>ETA</th>")
                            Print(f, "<th style='width: 2cm; border:1px solid black'>CREATION DATE</th>")
                            Print(f, "</tr>")

                            Print(f, " <tr> ")
                            Print(f, "<td>" & REA.GetString("empresa") & "</td>")
                            Print(f, "<td>" & REA.GetDateTime("Fecha") & "</td>")
                            Print(f, "<td>" & REA.GetString("Proveedor") & "</td>")
                            Print(f, "<td>" & REA.GetString("Referencia") & "</td>")
                            Print(f, "<td>" & REA.GetString("Hilo") & "</td>")
                            Print(f, "<td>" & REA.GetDouble("Cantidad").ToString(FORMATO_MONEDA) & "</td>")
                            Print(f, "<td>" & REA.GetDouble("Precio") & "</td>")
                            Print(f, "<td>" & Math.Round(REA.GetDouble("Total") + 0.0000000001, 2).ToString(FORMATO_MONEDA) & "</td>")
                            Print(f, "<td>" & REA.GetDouble("Tasa") & "</td>")
                            Print(f, "<td>" & Math.Round(REA.GetDouble("TotalLocal"), 2).ToString(FORMATO_MONEDA) & "</td>")
                            Print(f, "<td>" & REA.GetString("ETD") & "</td>")
                            Print(f, "<td>" & REA.GetString("ETA") & "</td>")
                            Print(f, "<td>" & REA.GetDateTime("FechaCreacion") & "</td>")
                            Print(f, "</tr>")
                            '   If REA.GetString("Tipo") = "YARN" Then
                            dblTotal(1) = dblTotal(1) + REA.GetDouble("Cantidad")
                            dblTotal(2) = dblTotal(2) + Math.Round(REA.GetDouble("Total") + 0.0000000001, 2)
                            dblTotal(3) = dblTotal(3) + Math.Round(REA.GetDouble("TotalLocal"), 2)
                            '  ElseIf REA.GetString("Tipo") = "CHEMICAL" Then
                            ' dblTotal(4) = dblTotal(4) + REA.GetDouble("Cantidad")
                            'dblTotal(5) = dblTotal(5) + Math.Round(REA.GetDouble("Total") + 0.0000000001, 2)
                            ' dblTotal(6) = dblTotal(6) + Math.Round(REA.GetDouble("TotalLocal"), 2)
                            ' Else
                            ' dblTotal(7) = dblTotal(7) + REA.GetDouble("Cantidad")
                            ' dblTotal(8) = dblTotal(8) + Math.Round(REA.GetDouble("Total") + 0.0000000001, 2)
                            ' dblTotal(9) = dblTotal(9) + Math.Round(REA.GetDouble("TotalLocal"), 2)
                            '  End If
                            strTipo = REA.GetString("Tipo")
                            intEmpresa = REA.GetInt32("idEmpresa")
                        End If
                        ' Fin Primer IF 
                    End If
                    If intEmpresa = 1 Then
                        If REA.GetString("Tipo") = "YARN" Then
                            dblCantidadHilos = dblCantidadHilos + REA.GetDouble("Cantidad")
                            dblMontoHilos = dblMontoHilos + Math.Round(REA.GetDouble("Total") + 0.0000000001, 2)
                        ElseIf REA.GetString("Tipo") = "CHEMICAL" Then
                            dblCantidadQuimicosHilos = dblCantidadQuimicosHilos + REA.GetDouble("Cantidad")
                            dblMontoQuimicosHilos = dblMontoQuimicosHilos + Math.Round(REA.GetDouble("Total") + 0.0000000001, 2)
                        Else
                            dblCantidadFibraHilos = dblCantidadFibraHilos + REA.GetDouble("Cantidad")
                            dblMontoFibraHilos = dblMontoFibraHilos + Math.Round(REA.GetDouble("Total") + 0.0000000001, 2)
                        End If
                    ElseIf intEmpresa = 2 Then
                        If REA.GetString("Tipo") = "YARN" Then
                            dblCantidadAmtex = dblCantidadAmtex + REA.GetDouble("Cantidad")
                            dblMontoAmtex = dblMontoAmtex + Math.Round(REA.GetDouble("Total") + 0.0000000001, 2)
                        ElseIf REA.GetString("Tipo") = "CHEMICAL" Then
                            dblCantidadQuimicosAmtex = dblCantidadQuimicosAmtex + REA.GetDouble("Cantidad")
                            dblMontoQuimicosAmtex = dblMontoQuimicosAmtex + Math.Round(REA.GetDouble("Total") + 0.0000000001, 2)
                        Else
                            dblCantidadFibraAmtex = dblCantidadFibraAmtex + REA.GetDouble("Cantidad")
                            dblMontoFibraAmtex = dblMontoFibraAmtex + Math.Round(REA.GetDouble("Total") + 0.0000000001, 2)
                        End If
                    ElseIf intEmpresa = 3 Then
                        If REA.GetString("Tipo") = "YARN" Then
                            dblCantidadPrideYarn = dblCantidadPrideYarn + REA.GetDouble("Cantidad")
                            dblMontoPrideYarn = dblMontoPrideYarn + Math.Round(REA.GetDouble("Total") + 0.0000000001, 2)
                        ElseIf REA.GetString("Tipo") = "CHEMICAL" Then
                            dblCantidadQuimicosPrideYarn = dblCantidadQuimicosPrideYarn + REA.GetDouble("Cantidad")
                            dblMontoQuimicosPrideYarn = dblMontoQuimicosPrideYarn + Math.Round(REA.GetDouble("Total") + 0.0000000001, 2)
                        Else
                            dblCantidadFibraPrideYarn = dblCantidadFibraPrideYarn + REA.GetDouble("Cantidad")
                            dblMontoFibraPrideYarn = dblMontoFibraPrideYarn + Math.Round(REA.GetDouble("Total") + 0.0000000001, 2)
                        End If
                    ElseIf intEmpresa = 4 Then
                        If REA.GetString("Tipo") = "YARN" Then
                            dblCantidadDominican = dblCantidadDominican + REA.GetDouble("Cantidad")
                            dblMontoDominican = dblMontoDominican + Math.Round(REA.GetDouble("Total") + 0.0000000001, 2)
                        ElseIf REA.GetString("Tipo") = "CHEMICAL" Then
                            dblCantidadQuimicosDominican = dblCantidadQuimicosDominican + REA.GetDouble("Cantidad")
                            dblMontoQuimicosDominican = dblMontoQuimicosDominican + Math.Round(REA.GetDouble("Total") + 0.0000000001, 2)
                        Else
                            dblCantidadFibraDominican = dblCantidadFibraDominican + REA.GetDouble("Cantidad")
                            dblMontoFibraDominican = dblMontoFibraDominican + Math.Round(REA.GetDouble("Total") + 0.0000000001, 2)
                        End If
                    End If
                Loop
            End If
            sql = STR_VACIO
            REA.Close()
            COM = Nothing
            If (dblTotal(1) <> INT_CERO) Or (dblTotal(2) <> INT_CERO) Or (dblTotal(3) <> INT_CERO) Then
                Print(f, "<tr style='background-color: Silver'>")
                Print(f, "<td colspan = 5 >Sub-Total</td>")
                Print(f, "<td class='numero'>" & dblTotal(1).ToString(FORMATO_MONEDA) & "</td>")
                Print(f, "<td></td>")
                Print(f, "<td class='numero'>" & dblTotal(2).ToString(FORMATO_MONEDA) & "</td>")
                Print(f, "<td></td>")
                Print(f, "<td class='numero'>" & dblTotal(3).ToString(FORMATO_MONEDA) & "</td>")
                Print(f, "<td></td>")
                Print(f, "<td></td>")
                Print(f, "</tr>")
                dblSuperCantidadTotal = dblSuperCantidadTotal + dblTotal(1)
                dblSuperGranTotal = dblSuperGranTotal + dblTotal(2)
                dblSuperGranTotalLocal = dblSuperGranTotalLocal + dblTotal(3)
                Print(f, "<tr style='background-color: Silver'>")
                Print(f, "<td colspan = 5>GRAND-TOTAL</td>")
                Print(f, "<td class='numero'>" & dblSuperCantidadTotal.ToString(FORMATO_MONEDA) & "</td>")
                Print(f, "<td></td>")
                Print(f, "<td class='numero'>" & dblSuperGranTotal.ToString(FORMATO_MONEDA) & "</td>")
                Print(f, "<td></td>")
                Print(f, "<td class='numero'>" & dblSuperGranTotalLocal.ToString(FORMATO_MONEDA) & "</td>")
                Print(f, "<td></td>")
                Print(f, "<td></td>")
                Print(f, "</tr>")
                Print(f, "</table>")
                Print(f, "<br/>")
            End If
            'If intEmp = 2 Then
            '    If intFiltro = INT_CERO Then
            '        Print(f, "<td class='numero'>" & dblTotal(1).ToString(FORMATO_MONEDA) & "</td>")
            '        Print(f, "<td></td>")
            '        Print(f, "<td class='numero'>" & dblTotal(2).ToString(FORMATO_MONEDA) & "</td>")
            '        Print(f, "<td></td>")
            '        Print(f, "<td class='numero'>" & dblTotal(3).ToString(FORMATO_MONEDA) & "</td>")
            '    ElseIf intFiltro = INT_UNO Then
            '        Print(f, "<td class='numero'>" & dblTotal(4).ToString(FORMATO_MONEDA) & "</td>")
            '        Print(f, "<td></td>")
            '        Print(f, "<td class='numero'>" & dblTotal(5).ToString(FORMATO_MONEDA) & "</td>")
            '        Print(f, "<td></td>")
            '        Print(f, "<td class='numero'>" & dblTotal(6).ToString(FORMATO_MONEDA) & "</td>")
            '    ElseIf intFiltro = 2 Then
            '        Print(f, "<td class='numero'>" & dblTotal(7).ToString(FORMATO_MONEDA) & "</td>")
            '        Print(f, "<td></td>")
            '        Print(f, "<td class='numero'>" & dblTotal(8).ToString(FORMATO_MONEDA) & "</td>")
            '        Print(f, "<td></td>")
            '        Print(f, "<td class='numero'>" & dblTotal(9).ToString(FORMATO_MONEDA) & "</td>")
            '    ElseIf intFiltro = 3 Then
            '        Print(f, "<td class='numero'>" & dblTotal(4).ToString(FORMATO_MONEDA) & "</td>")
            '        Print(f, "<td></td>")
            '        Print(f, "<td class='numero'>" & dblTotal(5).ToString(FORMATO_MONEDA) & "</td>")
            '        Print(f, "<td></td>")
            '        Print(f, "<td class='numero'>" & dblTotal(6).ToString(FORMATO_MONEDA) & "</td>")
            '    End If
            'Else
            '    If intFiltro = INT_CERO Then
            '        Print(f, "<td class='numero'>" & dblTotal(1).ToString(FORMATO_MONEDA) & "</td>")
            '        Print(f, "<td></td>")
            '        Print(f, "<td class='numero'>" & dblTotal(2).ToString(FORMATO_MONEDA) & "</td>")
            '        Print(f, "<td></td>")
            '        Print(f, "<td class='numero'>" & dblTotal(3).ToString(FORMATO_MONEDA) & "</td>")
            '    ElseIf intFiltro = INT_UNO Then
            '        Print(f, "<td class='numero'>" & dblTotal(4).ToString(FORMATO_MONEDA) & "</td>")
            '        Print(f, "<td></td>")
            '        Print(f, "<td class='numero'>" & dblTotal(5).ToString(FORMATO_MONEDA) & "</td>")
            '        Print(f, "<td></td>")
            '        Print(f, "<td class='numero'>" & dblTotal(6).ToString(FORMATO_MONEDA) & "</td>")
            '    ElseIf intFiltro = 2 Then
            '        Print(f, "<td class='numero'>" & dblTotal(7).ToString(FORMATO_MONEDA) & "</td>")
            '        Print(f, "<td></td>")
            '        Print(f, "<td class='numero'>" & dblTotal(8).ToString(FORMATO_MONEDA) & "</td>")
            '        Print(f, "<td></td>")
            '        Print(f, "<td class='numero'>" & dblTotal(9).ToString(FORMATO_MONEDA) & "</td>")
            '    ElseIf intFiltro = 3 Then
            '        Print(f, "<td class='numero'>" & dblTotal(4).ToString(FORMATO_MONEDA) & "</td>")
            '        Print(f, "<td></td>")
            '        Print(f, "<td class='numero'>" & dblTotal(5).ToString(FORMATO_MONEDA) & "</td>")
            '        Print(f, "<td></td>")
            '        Print(f, "<td class='numero'>" & dblTotal(6).ToString(FORMATO_MONEDA) & "</td>")
            '    End If
            'End If




            Print(f, "<table cellspacing =0 >")
            If intEmp = 0 Then
                Print(f, "<tr>")
                Print(f, "<th style='border: white; background-color: white'></th>")
                Print(f, "<th colspan='3' style='width: 9cm'>YARN</th>")
                Print(f, "</tr>")
                Print(f, "<tr>")
                Print(f, "<td style='border: white'> <br> </td>")
                Print(f, "<td style='font-weight: bold'> COMPANY </td>")
                Print(f, "<td style='font-weight: bold'> QUANTITY </td>")
                Print(f, "<td style='font-weight: bold'> AMOUNT $ </td>")
                Print(f, "</tr>")

                'Query de empresas
                sql = SQLEmpresaTransito()
                MyCnn.CONECTAR = strConexion
                COM = New MySqlCommand(sql, CON)
                REA = COM.ExecuteReader
                If REA.HasRows Then
                    Do While REA.Read
                        Print(f, "<tr>")
                        Print(f, "<td style='border: white'> <br> </td>")
                        Print(f, "<td> " & REA.GetString("Nombre") & "</td>")
                        If REA.GetInt32("Empresa") = 1 Then
                            Print(f, "<td> " & dblCantidadHilos.ToString(FORMATO_MONEDA) & "</td>")
                            Print(f, "<td> " & dblMontoHilos.ToString(FORMATO_MONEDA) & "</td>")
                            dblGranTotal(1) = dblGranTotal(1) + dblCantidadHilos
                            dblGranTotal(2) = dblGranTotal(2) + Math.Round(dblMontoHilos + 0.0000000001, 2)
                        ElseIf REA.GetInt32("Empresa") = 2 Then
                            Print(f, "<td> " & dblCantidadAmtex.ToString(FORMATO_MONEDA) & "</td>")
                            Print(f, "<td> " & dblMontoAmtex.ToString(FORMATO_MONEDA) & "</td>")
                            dblGranTotal(1) = dblGranTotal(1) + dblCantidadAmtex
                            dblGranTotal(2) = dblGranTotal(2) + Math.Round(dblMontoAmtex + 0.0000000001, 2)
                        ElseIf REA.GetInt32("Empresa") = 3 Then
                            Print(f, "<td> " & dblCantidadPrideYarn.ToString(FORMATO_MONEDA) & "</td>")
                            Print(f, "<td> " & dblMontoPrideYarn.ToString(FORMATO_MONEDA) & "</td>")
                            dblGranTotal(1) = dblGranTotal(1) + dblCantidadPrideYarn
                            dblGranTotal(2) = dblGranTotal(2) + Math.Round(dblMontoPrideYarn + 0.0000000001, 2)
                        ElseIf REA.GetInt32("Empresa") = 4 Then
                            Print(f, "<td> " & dblCantidadDominican.ToString(FORMATO_MONEDA) & "</td>")
                            Print(f, "<td> " & dblMontoDominican.ToString(FORMATO_MONEDA) & "</td>")
                            dblGranTotal(1) = dblGranTotal(1) + dblCantidadDominican
                            dblGranTotal(2) = dblGranTotal(2) + Math.Round(dblMontoDominican + 0.0000000001, 2)
                        End If
                        Print(f, "</tr>")
                    Loop
                End If
                Print(f, "<tr>")
                Print(f, "<td style='border: white'></td>")
                Print(f, "<td colspan='1'> <b> TOTAL </b> </td>")
                Print(f, "<td>" & dblGranTotal(1).ToString(FORMATO_MONEDA) & "</td>")
                Print(f, "<td>" & dblGranTotal(2).ToString(FORMATO_MONEDA) & "</td>")
                Print(f, "</tr>")

                REA.Close()
                COM = Nothing
                sql = STR_VACIO

                Print(f, "<tr>")
                Print(f, "<th style='border: white; background-color: white'></th>")
                Print(f, "<th colspan='3' style='width: 9cm'>FIBER</th>")
                Print(f, "</tr>")
                Print(f, "<tr>")
                Print(f, "<td style='border: white'> <br> </td>")
                Print(f, "<td style='font-weight: bold'> COMPANY </td>")
                Print(f, "<td style='font-weight: bold'> QUANTITY </td>")
                Print(f, "<td style='font-weight: bold'> AMOUNT $ </td>")
                Print(f, "</tr>")

                'Query de empresas
                sql = SQLEmpresaTransito()
                MyCnn.CONECTAR = strConexion
                COM = New MySqlCommand(sql, CON)
                REA = COM.ExecuteReader
                If REA.HasRows Then
                    Do While REA.Read
                        Print(f, "<tr>")
                        Print(f, "<td style='border: white'> <br> </td>")
                        Print(f, "<td> " & REA.GetString("Nombre") & "</td>")
                        If REA.GetInt32("Empresa") = 1 Then
                            Print(f, "<td> " & dblCantidadFibraHilos.ToString(FORMATO_MONEDA) & "</td>")
                            Print(f, "<td> " & dblMontoFibraHilos.ToString(FORMATO_MONEDA) & "</td>")
                            dblGranTotal(5) = dblGranTotal(5) + dblCantidadFibraHilos
                            dblGranTotal(6) = dblGranTotal(6) + dblMontoFibraHilos
                        ElseIf REA.GetInt32("Empresa") = 2 Then
                            Print(f, "<td> " & dblCantidadFibraAmtex.ToString(FORMATO_MONEDA) & "</td>")
                            Print(f, "<td> " & dblMontoFibraAmtex.ToString(FORMATO_MONEDA) & "</td>")
                            dblGranTotal(5) = dblGranTotal(5) + dblCantidadFibraAmtex
                            dblGranTotal(6) = dblGranTotal(6) + dblMontoFibraAmtex
                        ElseIf REA.GetInt32("Empresa") = 3 Then
                            Print(f, "<td> " & dblCantidadFibraPrideYarn.ToString(FORMATO_MONEDA) & "</td>")
                            Print(f, "<td> " & dblMontoFibraPrideYarn.ToString(FORMATO_MONEDA) & "</td>")
                            dblGranTotal(5) = dblGranTotal(5) + dblCantidadFibraPrideYarn
                            dblGranTotal(6) = dblGranTotal(6) + dblMontoFibraPrideYarn
                        ElseIf REA.GetInt32("Empresa") = 4 Then
                            Print(f, "<td> " & dblCantidadFibraDominican.ToString(FORMATO_MONEDA) & "</td>")
                            Print(f, "<td> " & dblMontoFibraDominican.ToString(FORMATO_MONEDA) & "</td>")
                            dblGranTotal(5) = dblGranTotal(5) + dblCantidadFibraDominican
                            dblGranTotal(6) = dblGranTotal(6) + dblMontoFibraDominican
                        End If
                        Print(f, "</tr>")
                    Loop
                End If
                Print(f, "<tr>")
                Print(f, "<td style='border: white'></td>")
                Print(f, "<td colspan='1'> <b> TOTAL </b> </td>")
                Print(f, "<td>" & dblGranTotal(5).ToString(FORMATO_MONEDA) & "</td>")
                Print(f, "<td>" & dblGranTotal(6).ToString(FORMATO_MONEDA) & "</td>")
                Print(f, "</tr>")

                REA.Close()
                COM = Nothing
                sql = STR_VACIO

                Print(f, "<tr>")
                Print(f, "<th style='border: white; background-color: white'></th>")
                Print(f, "<th colspan='3' style='width: 9cm'>CHEMICAL</th>")
                Print(f, "</tr>")
                Print(f, "<tr>")
                Print(f, "<td style='border: white'> <br> </td>")
                Print(f, "<td style='font-weight: bold'> COMPANY </td>")
                Print(f, "<td style='font-weight: bold'> QUANTITY </td>")
                Print(f, "<td style='font-weight: bold'> AMOUNT $ </td>")
                Print(f, "</tr>")
                'Aqui va Query de Empresas
                sql = SQLEmpresaTransito()
                MyCnn.CONECTAR = strConexion
                COM = New MySqlCommand(sql, CON)
                REA = COM.ExecuteReader
                If REA.HasRows Then
                    Do While REA.Read
                        Print(f, "<tr>")
                        Print(f, "<td style='border: white'> <br> </td>")
                        Print(f, "<td> " & REA.GetString("Nombre") & "</td>")
                        If REA.GetInt32("Empresa") = 1 Then
                            Print(f, "<td> " & dblCantidadQuimicosHilos.ToString(FORMATO_MONEDA) & "</td>")
                            Print(f, "<td> " & dblMontoQuimicosHilos.ToString(FORMATO_MONEDA) & " </td>")
                            dblGranTotal(3) = dblGranTotal(3) + dblCantidadQuimicosHilos
                            dblGranTotal(4) = dblGranTotal(4) + dblMontoQuimicosHilos
                        ElseIf REA.GetInt32("Empresa") = 2 Then
                            Print(f, "<td> " & dblCantidadQuimicosAmtex.ToString(FORMATO_MONEDA) & "</td>")
                            Print(f, "<td> " & dblMontoQuimicosAmtex.ToString(FORMATO_MONEDA) & " </td>")
                            dblGranTotal(3) = dblGranTotal(3) + dblCantidadQuimicosAmtex
                            dblGranTotal(4) = dblGranTotal(4) + dblMontoQuimicosAmtex
                        ElseIf REA.GetInt32("Empresa") = 3 Then
                            Print(f, "<td> " & dblCantidadQuimicosPrideYarn.ToString(FORMATO_MONEDA) & "</td>")
                            Print(f, "<td> " & dblMontoQuimicosPrideYarn.ToString(FORMATO_MONEDA) & " </td>")
                            dblGranTotal(3) = dblGranTotal(3) + dblCantidadQuimicosPrideYarn
                            dblGranTotal(4) = dblGranTotal(4) + dblMontoQuimicosPrideYarn
                        ElseIf REA.GetInt32("Empresa") = 4 Then
                            Print(f, "<td> " & dblCantidadQuimicosDominican.ToString(FORMATO_MONEDA) & "</td>")
                            Print(f, "<td> " & dblMontoQuimicosDominican.ToString(FORMATO_MONEDA) & " </td>")
                            dblGranTotal(3) = dblGranTotal(3) + dblCantidadQuimicosDominican
                            dblGranTotal(4) = dblGranTotal(4) + dblMontoQuimicosDominican
                        End If
                        Print(f, "</tr>")
                    Loop
                End If
                Print(f, "<tr>")
                Print(f, "<td style='border: white'></td>")
                Print(f, "<td colspan='1'> <b> TOTAL </b> </td>")
                Print(f, "<td>" & dblGranTotal(3).ToString(FORMATO_MONEDA) & "</td>")
                Print(f, "<td>" & dblGranTotal(4).ToString(FORMATO_MONEDA) & "</td>")
                Print(f, "</tr>")
            ElseIf intEmp = 1 Then
                Print(f, "<tr>")
                Print(f, "<th style='border: white; background-color: white'></th>")
                Print(f, "<th colspan='3' style='width: 9cm'>YARN</th>")
                Print(f, "</tr>")
                Print(f, "<tr>")
                Print(f, "<td style='border: white'> <br> </td>")
                Print(f, "<td style='font-weight: bold'> COMPANY </td>")
                Print(f, "<td style='font-weight: bold'> QUANTITY </td>")
                Print(f, "<td style='font-weight: bold'> AMOUNT $ </td>")
                Print(f, "</tr>")

                Print(f, "<tr>")
                Print(f, "<td style='border: white'> <br> </td>")
                Print(f, "<td> Hilos y Algodon, S.A.</td>")
                Print(f, "<td> " & dblCantidadHilos.ToString(FORMATO_MONEDA) & "</td>")
                Print(f, "<td> " & dblMontoHilos.ToString(FORMATO_MONEDA) & "</td>")
                dblGranTotal(1) = dblGranTotal(1) + dblCantidadHilos
                dblGranTotal(2) = dblGranTotal(2) + dblMontoHilos
                Print(f, "</tr>")

                Print(f, "<tr>")
                Print(f, "<td style='border: white'></td>")
                Print(f, "<td colspan='1'> <b> TOTAL </b> </td>")
                Print(f, "<td>" & dblGranTotal(1).ToString(FORMATO_MONEDA) & "</td>")
                Print(f, "<td>" & dblGranTotal(2).ToString(FORMATO_MONEDA) & "</td>")
                Print(f, "</tr>")

                Print(f, "<tr>")
                Print(f, "<th style='border: white; background-color: white'></th>")
                Print(f, "<th colspan='3' style='width: 9cm'>FIBER</th>")
                Print(f, "</tr>")
                Print(f, "<tr>")
                Print(f, "<td style='border: white'> <br> </td>")
                Print(f, "<td style='font-weight: bold'> COMPANY </td>")
                Print(f, "<td style='font-weight: bold'> QUANTITY </td>")
                Print(f, "<td style='font-weight: bold'> AMOUNT $ </td>")
                Print(f, "</tr>")
                Print(f, "<tr>")
                Print(f, "<td style='border: white'> <br> </td>")
                Print(f, "<td> Pride  Yarn, S. de R.L.</td>")
                Print(f, "<td> " & dblCantidadFibraHilos.ToString(FORMATO_MONEDA) & "</td>")
                Print(f, "<td> " & dblMontoFibraHilos.ToString(FORMATO_MONEDA) & " </td>")
                dblGranTotal(5) = dblGranTotal(5) + dblCantidadFibraHilos
                dblGranTotal(6) = dblGranTotal(6) + dblMontoFibraHilos
                Print(f, "</tr>")

                Print(f, "<tr>")
                Print(f, "<td style='border: white'></td>")
                Print(f, "<td colspan='1'> <b> TOTAL </b> </td>")
                Print(f, "<td>" & dblGranTotal(5).ToString(FORMATO_MONEDA) & "</td>")
                Print(f, "<td>" & dblGranTotal(6).ToString(FORMATO_MONEDA) & "</td>")
                Print(f, "</tr>")

                Print(f, "<tr>")
                Print(f, "<th style='border: white; background-color: white'></th>")
                Print(f, "<th colspan='3' style='width: 9cm'>CHEMICAL</th>")
                Print(f, "</tr>")
                Print(f, "<tr>")
                Print(f, "<td style='border: white'> <br> </td>")
                Print(f, "<td style='font-weight: bold'> COMPANY </td>")
                Print(f, "<td style='font-weight: bold'> QUANTITY </td>")
                Print(f, "<td style='font-weight: bold'> AMOUNT $ </td>")
                Print(f, "</tr>")
                Print(f, "<tr>")
                Print(f, "<td style='border: white'> <br> </td>")
                Print(f, "<td> Hilos y Algodon, S.A.</td>")
                Print(f, "<td> " & dblCantidadQuimicosHilos.ToString(FORMATO_MONEDA) & "</td>")
                Print(f, "<td> " & dblMontoQuimicosHilos.ToString(FORMATO_MONEDA) & " </td>")
                dblGranTotal(3) = dblGranTotal(3) + dblCantidadQuimicosHilos
                dblGranTotal(4) = dblGranTotal(4) + dblMontoQuimicosHilos
                Print(f, "</tr>")

                Print(f, "<tr>")
                Print(f, "<td style='border: white'></td>")
                Print(f, "<td colspan='1'> <b> TOTAL </b> </td>")
                Print(f, "<td>" & dblGranTotal(3).ToString(FORMATO_MONEDA) & "</td>")
                Print(f, "<td>" & dblGranTotal(4).ToString(FORMATO_MONEDA) & "</td>")
                Print(f, "</tr>")
            ElseIf intEmp = 2 Then
                Print(f, "<tr>")
                Print(f, "<th style='border: white; background-color: white'></th>")
                Print(f, "<th colspan='3' style='width: 9cm'>YARN</th>")
                Print(f, "</tr>")
                Print(f, "<tr>")
                Print(f, "<td style='border: white'> <br> </td>")
                Print(f, "<td style='font-weight: bold'> COMPANY </td>")
                Print(f, "<td style='font-weight: bold'> QUANTITY </td>")
                Print(f, "<td style='font-weight: bold'> AMOUNT $ </td>")
                Print(f, "</tr>")
                Print(f, "<tr>")
                Print(f, "<td style='border: white'> <br> </td>")
                Print(f, "<td> Amtex de El Salvador, S.A. DE C.V. </td>")
                Print(f, "<td> " & dblCantidadAmtex.ToString(FORMATO_MONEDA) & "</td>")
                Print(f, "<td> " & dblMontoAmtex.ToString(FORMATO_MONEDA) & "</td>")
                dblGranTotal(1) = dblGranTotal(1) + dblCantidadAmtex
                dblGranTotal(2) = dblGranTotal(2) + dblMontoAmtex
                Print(f, "</tr>")

                Print(f, "<tr>")
                Print(f, "<td style='border: white'></td>")
                Print(f, "<td colspan='1'> <b> TOTAL </b> </td>")
                Print(f, "<td>" & dblGranTotal(1).ToString(FORMATO_MONEDA) & "</td>")
                Print(f, "<td>" & dblGranTotal(2).ToString(FORMATO_MONEDA) & "</td>")
                Print(f, "</tr>")

                Print(f, "<tr>")
                Print(f, "<th style='border: white; background-color: white'></th>")
                Print(f, "<th colspan='3' style='width: 9cm'>FIBER</th>")
                Print(f, "</tr>")
                Print(f, "<tr>")
                Print(f, "<td style='border: white'> <br> </td>")
                Print(f, "<td style='font-weight: bold'> COMPANY </td>")
                Print(f, "<td style='font-weight: bold'> QUANTITY </td>")
                Print(f, "<td style='font-weight: bold'> AMOUNT $ </td>")
                Print(f, "</tr>")
                Print(f, "<tr>")
                Print(f, "<td style='border: white'> <br> </td>")
                Print(f, "<td> Pride  Yarn, S. de R.L.</td>")
                Print(f, "<td> " & dblCantidadFibraAmtex.ToString(FORMATO_MONEDA) & "</td>")
                Print(f, "<td> " & dblMontoFibraAmtex.ToString(FORMATO_MONEDA) & " </td>")
                dblGranTotal(5) = dblGranTotal(5) + dblCantidadFibraAmtex
                dblGranTotal(6) = dblGranTotal(6) + dblMontoFibraAmtex
                Print(f, "</tr>")

                Print(f, "<tr>")
                Print(f, "<td style='border: white'></td>")
                Print(f, "<td colspan='1'> <b> TOTAL </b> </td>")
                Print(f, "<td>" & dblGranTotal(5).ToString(FORMATO_MONEDA) & "</td>")
                Print(f, "<td>" & dblGranTotal(6).ToString(FORMATO_MONEDA) & "</td>")
                Print(f, "</tr>")

                Print(f, "<tr>")
                Print(f, "<th style='border: white; background-color: white'></th>")
                Print(f, "<th colspan='3' style='width: 9cm'>CHEMICAL</th>")
                Print(f, "</tr>")
                Print(f, "<tr>")
                Print(f, "<td style='border: white'> <br> </td>")
                Print(f, "<td style='font-weight: bold'> COMPANY </td>")
                Print(f, "<td style='font-weight: bold'> QUANTITY </td>")
                Print(f, "<td style='font-weight: bold'> AMOUNT $ </td>")
                Print(f, "</tr>")
                Print(f, "<tr>")
                Print(f, "<td style='border: white'> <br> </td>")
                Print(f, "<td> Amtex de El Salvador, S.A. DE C.V. </td>")
                Print(f, "<td> " & dblCantidadQuimicosAmtex.ToString(FORMATO_MONEDA) & "</td>")
                Print(f, "<td> " & dblMontoQuimicosAmtex.ToString(FORMATO_MONEDA) & " </td>")
                dblGranTotal(3) = dblGranTotal(3) + dblCantidadQuimicosAmtex
                dblGranTotal(4) = dblGranTotal(4) + dblMontoQuimicosAmtex
                Print(f, "</tr>")

                Print(f, "<tr>")
                Print(f, "<td style='border: white'></td>")
                Print(f, "<td colspan='1'> <b> TOTAL </b> </td>")
                Print(f, "<td>" & dblGranTotal(3).ToString(FORMATO_MONEDA) & "</td>")
                Print(f, "<td>" & dblGranTotal(4).ToString(FORMATO_MONEDA) & "</td>")
                Print(f, "</tr>")

            ElseIf intEmp = 3 Then
                Print(f, "<tr>")
                Print(f, "<th style='border: white; background-color: white'></th>")
                Print(f, "<th colspan='3' style='width: 9cm'>YARN</th>")
                Print(f, "</tr>")
                Print(f, "<tr>")
                Print(f, "<td style='border: white'> <br> </td>")
                Print(f, "<td style='font-weight: bold'> COMPANY </td>")
                Print(f, "<td style='font-weight: bold'> QUANTITY </td>")
                Print(f, "<td style='font-weight: bold'> AMOUNT $ </td>")
                Print(f, "</tr>")
                Print(f, "<tr>")
                Print(f, "<td style='border: white'> <br> </td>")
                Print(f, "<td> Pride  Yarn, S. de R.L.</td>")
                Print(f, "<td> " & dblCantidadPrideYarn.ToString(FORMATO_MONEDA) & "</td>")
                Print(f, "<td> " & dblMontoPrideYarn.ToString(FORMATO_MONEDA) & "</td>")
                dblGranTotal(1) = dblGranTotal(1) + dblCantidadPrideYarn
                dblGranTotal(2) = dblGranTotal(2) + dblMontoPrideYarn
                Print(f, "</tr>")

                Print(f, "<tr>")
                Print(f, "<td style='border: white'></td>")
                Print(f, "<td colspan='1'> <b> TOTAL </b> </td>")
                Print(f, "<td>" & dblGranTotal(1).ToString(FORMATO_MONEDA) & "</td>")
                Print(f, "<td>" & dblGranTotal(2).ToString(FORMATO_MONEDA) & "</td>")
                Print(f, "</tr>")

                Print(f, "<tr>")
                Print(f, "<th style='border: white; background-color: white'></th>")
                Print(f, "<th colspan='3' style='width: 9cm'>FIBER</th>")
                Print(f, "</tr>")
                Print(f, "<tr>")
                Print(f, "<td style='border: white'> <br> </td>")
                Print(f, "<td style='font-weight: bold'> COMPANY </td>")
                Print(f, "<td style='font-weight: bold'> QUANTITY </td>")
                Print(f, "<td style='font-weight: bold'> AMOUNT $ </td>")
                Print(f, "</tr>")
                Print(f, "<tr>")
                Print(f, "<td style='border: white'> <br> </td>")
                Print(f, "<td> Pride  Yarn, S. de R.L.</td>")
                Print(f, "<td> " & dblCantidadFibraPrideYarn.ToString(FORMATO_MONEDA) & "</td>")
                Print(f, "<td> " & dblMontoFibraPrideYarn.ToString(FORMATO_MONEDA) & " </td>")
                dblGranTotal(5) = dblGranTotal(5) + dblCantidadFibraPrideYarn
                dblGranTotal(6) = dblGranTotal(6) + dblMontoFibraPrideYarn
                Print(f, "</tr>")

                Print(f, "<tr>")
                Print(f, "<td style='border: white'></td>")
                Print(f, "<td colspan='1'> <b> TOTAL </b> </td>")
                Print(f, "<td>" & dblGranTotal(5).ToString(FORMATO_MONEDA) & "</td>")
                Print(f, "<td>" & dblGranTotal(6).ToString(FORMATO_MONEDA) & "</td>")
                Print(f, "</tr>")

                Print(f, "<tr>")
                Print(f, "<th style='border: white; background-color: white'></th>")
                Print(f, "<th colspan='3' style='width: 9cm'>CHEMICAL</th>")
                Print(f, "</tr>")
                Print(f, "<tr>")
                Print(f, "<td style='border: white'> <br> </td>")
                Print(f, "<td style='font-weight: bold'> COMPANY </td>")
                Print(f, "<td style='font-weight: bold'> QUANTITY </td>")
                Print(f, "<td style='font-weight: bold'> AMOUNT $ </td>")
                Print(f, "</tr>")
                Print(f, "<tr>")
                Print(f, "<td style='border: white'> <br> </td>")
                Print(f, "<td> Pride  Yarn, S. de R.L.</td>")
                Print(f, "<td> " & dblCantidadQuimicosPrideYarn.ToString(FORMATO_MONEDA) & "</td>")
                Print(f, "<td> " & dblMontoQuimicosPrideYarn.ToString(FORMATO_MONEDA) & " </td>")
                dblGranTotal(3) = dblGranTotal(3) + dblCantidadQuimicosPrideYarn
                dblGranTotal(4) = dblGranTotal(4) + dblMontoQuimicosPrideYarn
                Print(f, "</tr>")

                Print(f, "<tr>")
                Print(f, "<td style='border: white'></td>")
                Print(f, "<td colspan='1'> <b> TOTAL </b> </td>")
                Print(f, "<td>" & dblGranTotal(3).ToString(FORMATO_MONEDA) & "</td>")
                Print(f, "<td>" & dblGranTotal(4).ToString(FORMATO_MONEDA) & "</td>")
                Print(f, "</tr>")

            ElseIf intEmp = 4 Then
                Print(f, "<tr>")
                Print(f, "<th style='border: white; background-color: white'></th>")
                Print(f, "<th colspan='3' style='width: 9cm'>YARN</th>")
                Print(f, "</tr>")
                Print(f, "<tr>")
                Print(f, "<td style='border: white'> <br> </td>")
                Print(f, "<td style='font-weight: bold'> COMPANY </td>")
                Print(f, "<td style='font-weight: bold'> QUANTITY </td>")
                Print(f, "<td style='font-weight: bold'> AMOUNT $ </td>")
                Print(f, "</tr>")
                Print(f, "<tr>")
                Print(f, "<td style='border: white'> <br> </td>")
                Print(f, "<td> Dominican Republic Yarn Suppliers GK, S.R.L.</td>")
                Print(f, "<td> " & dblCantidadDominican.ToString(FORMATO_MONEDA) & "</td>")
                Print(f, "<td> " & dblMontoDominican.ToString(FORMATO_MONEDA) & "</td>")
                dblGranTotal(1) = dblGranTotal(1) + dblCantidadDominican
                dblGranTotal(2) = dblGranTotal(2) + dblMontoDominican
                Print(f, "</tr>")

                Print(f, "<tr>")
                Print(f, "<td style='border: white'></td>")
                Print(f, "<td colspan='1'> <b> TOTAL </b> </td>")
                Print(f, "<td>" & dblGranTotal(1).ToString(FORMATO_MONEDA) & "</td>")
                Print(f, "<td>" & dblGranTotal(2).ToString(FORMATO_MONEDA) & "</td>")
                Print(f, "</tr>")

                Print(f, "<tr>")
                Print(f, "<th style='border: white; background-color: white'></th>")
                Print(f, "<th colspan='3' style='width: 9cm'>FIBER</th>")
                Print(f, "</tr>")
                Print(f, "<tr>")
                Print(f, "<td style='border: white'> <br> </td>")
                Print(f, "<td style='font-weight: bold'> COMPANY </td>")
                Print(f, "<td style='font-weight: bold'> QUANTITY </td>")
                Print(f, "<td style='font-weight: bold'> AMOUNT $ </td>")
                Print(f, "</tr>")
                Print(f, "<tr>")
                Print(f, "<td style='border: white'> <br> </td>")
                Print(f, "<td> Pride  Yarn, S. de R.L.</td>")
                Print(f, "<td> " & dblCantidadFibraDominican.ToString(FORMATO_MONEDA) & "</td>")
                Print(f, "<td> " & dblMontoFibraDominican.ToString(FORMATO_MONEDA) & " </td>")
                dblGranTotal(5) = dblGranTotal(5) + dblCantidadFibraDominican
                dblGranTotal(6) = dblGranTotal(6) + dblMontoFibraDominican
                Print(f, "</tr>")

                Print(f, "<tr>")
                Print(f, "<td style='border: white'></td>")
                Print(f, "<td colspan='1'> <b> TOTAL </b> </td>")
                Print(f, "<td>" & dblGranTotal(5).ToString(FORMATO_MONEDA) & "</td>")
                Print(f, "<td>" & dblGranTotal(6).ToString(FORMATO_MONEDA) & "</td>")
                Print(f, "</tr>")

                Print(f, "<tr>")
                Print(f, "<th style='border: white; background-color: white'></th>")
                Print(f, "<th colspan='3' style='width: 9cm'>CHEMICAL</th>")
                Print(f, "</tr>")
                Print(f, "<tr>")
                Print(f, "<td style='border: white'> <br> </td>")
                Print(f, "<td style='font-weight: bold'> COMPANY </td>")
                Print(f, "<td style='font-weight: bold'> QUANTITY </td>")
                Print(f, "<td style='font-weight: bold'> AMOUNT $ </td>")
                Print(f, "</tr>")
                Print(f, "<tr>")
                Print(f, "<td style='border: white'> <br> </td>")
                Print(f, "<td> Dominican Republic Yarn Suppliers GK, S.R.L.</td>")
                Print(f, "<td> " & dblCantidadQuimicosDominican.ToString(FORMATO_MONEDA) & "</td>")
                Print(f, "<td> " & dblMontoQuimicosDominican.ToString(FORMATO_MONEDA) & " </td>")
                dblGranTotal(3) = dblGranTotal(3) + dblCantidadQuimicosDominican
                dblGranTotal(4) = dblGranTotal(4) + dblMontoQuimicosDominican
                Print(f, "</tr>")

                Print(f, "<tr>")
                Print(f, "<td style='border: white'></td>")
                Print(f, "<td colspan='1'> <b> TOTAL </b> </td>")
                Print(f, "<td>" & dblGranTotal(3).ToString(FORMATO_MONEDA) & "</td>")
                Print(f, "<td>" & dblGranTotal(4).ToString(FORMATO_MONEDA) & "</td>")
                Print(f, "</tr>")

            End If

            Print(f, "</table>")
            Print(f, "<br/>")
            dblGranTotal(1) = INT_CERO
            dblGranTotal(2) = INT_CERO
            sql = sqlInventarioTransitoCompany(intEmp)
            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(sql, CON)
            REA = COM.ExecuteReader
            If REA.HasRows Then
                Print(f, "<table cellspacing =0 >")
                Print(f, "<tr>")
                Print(f, "<th colspan='4' style='width: 9cm'>INTERCOMPANY</th>")
                Print(f, "</tr>")
                Print(f, "<tr>")
                Print(f, "<td style='font-weight: bold'> Buyer </td>")
                Print(f, "<td style='font-weight: bold'> Seller </td>")
                Print(f, "<td style='font-weight: bold'> Quantity </td>")
                Print(f, "<td style='font-weight: bold'> Amount $ </td>")
                Print(f, "</tr>")
                Do While REA.Read
                    Print(f, "<tr>")
                    Print(f, "<td> " & REA.GetString("Origen") & "</td>")
                    Print(f, "<td> " & REA.GetString("Intercompany") & "</td>")
                    Print(f, "<td> " & REA.GetDouble("Cantidad").ToString(FORMATO_MONEDA) & "</td>")
                    Print(f, "<td> " & REA.GetDouble("Total").ToString(FORMATO_MONEDA) & "</td>")
                    dblGranTotal(1) = dblGranTotal(1) + REA.GetDouble("Cantidad")
                    dblGranTotal(2) = dblGranTotal(2) + REA.GetDouble("Total")
                    Print(f, "</tr>")
                Loop
            End If
            REA.Close()
            COM = Nothing
            sql = STR_VACIO
            If dblGranTotal(0) > INT_CERO Then
                Print(f, "<tr>")
                Print(f, "<td colspan='2'><b> TOTAL </b></td>")
                Print(f, "<td> " & dblGranTotal(1).ToString(FORMATO_MONEDA) & "</td>")
                Print(f, "<td> " & dblGranTotal(2).ToString(FORMATO_MONEDA) & "</td>")
                Print(f, "</tr>")
            End If
            Print(f, "</table>")
            Print(f, "<br/>")
            Print(f, "</body>")
            Print(f, "</html>")
            FileClose(f)
            MostarReporte(strTemp)
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

#End Region

#Region " ASIA REPORT WEEK"
    Private Function sqlASIAReport(ByVal Fecha As Date) As String
        Dim strSQL As String = STR_VACIO
        strSQL = "  SELECT x1.*,SUM(x1.PENDTOSHIP + x1.PENDTOSHIPSOLD + x1.OCEAN + x1.OCEANSOLD + x1.WAREHOUSE + x1.WAREHOUSESOLD) TotalGeneral,SUM(x1.PENDTOSHIPSOLD + x1.OCEANSOLD + x1.WAREHOUSESOLD) SOLD "
        strSQL &= "     FROM( "
        strSQL &= "         SELECT l2.PIdGrupo,l2.Fecha,l2.grupo, SUM(CASE WHEN l2.PStatus_Joby = 'PEND. TO SHIP' THEN l2.Total ELSE 0 END) 'PENDTOSHIP', SUM(CASE WHEN l2.PStatus_Joby = 'PEND. TO SHIP/SOLD' THEN l2.Total ELSE 0 END) 'PENDTOSHIPSOLD', SUM(CASE WHEN l2.PStatus_Joby = 'OCEAN' THEN l2.Total ELSE 0 END)'OCEAN', SUM(CASE WHEN l2.PStatus_Joby = 'OCEAN/SOLD' THEN l2.Total ELSE 0 END) 'OCEANSOLD', SUM(CASE WHEN l2.PStatus_Joby = 'WAREHOUSE' THEN l2.Total ELSE 0 END) 'WAREHOUSE', SUM(CASE WHEN l2.PStatus_Joby = 'WAREHOUSE/SOLD' THEN l2.Total ELSE 0 END) 'WAREHOUSESOLD', l2.Registro "
        strSQL &= "             FROM ( "
        strSQL &= "                 SELECT s1.PIdGrupo,s1.Fecha,s1.estado_Grupo grupo, s1.PStatus, s1.PStatus_Joby,s1.Total, s1.Registro "
        strSQL &= "                     FROM( "
        strSQL &= "                         SELECT p.PFecha Fecha,e.idEmpresa, p.PIdGrupo, IFNULL(g.nombre_Grupo,'SIN GRUPO') estado_Grupo,p.PStatus_Joby, p.PStatus, SUM(p.PLibras) Total, p.Registro "
        strSQL &= "                             FROM YarnDivision.Planning p "
        strSQL &= "                                 LEFT JOIN YarnDivision.Grupo_Detalle d ON d.idEmpresa = p.PEmpresa AND d.idGrupo = p.PIdGrupo AND d.idTipo = p.PTipoGrupo AND d.Codigo = p.PArt_Codigo "
        strSQL &= "                             LEFT JOIN YarnDivision.Grupo g ON g.idGrupo = d.idGrupo AND g.idTipo= d.idTipo "
        strSQL &= "                         LEFT JOIN YarnDivision.Empresa e ON e.idEmpresa= p.PEmpresa "
        strSQL &= "                     WHERE p.Correlativo >0 AND p.PTipoGrupo = 2 AND p.PIdGrupo IN(d.idGrupo,-2) AND p.PFecha <= '{fecha}' AND p.PCategoria != 'FIBER'"
        strSQL &= "                 GROUP BY p.PIdGrupo, p.PStatus_Joby)s1)l2 "
        strSQL &= "             GROUP BY l2.PIdGrupo) x1 "
        strSQL &= "         GROUP BY x1.PIdGrupo "
        strSQL &= "     ORDER BY x1.grupo ASC "
        strSQL = Replace(strSQL, "{fecha}", Fecha.ToString(FORMATO_MYSQL))
        Return strSQL
    End Function
    Public Sub InventoryAsiaReport(ByVal Fecha As Date)
        Dim strSQL As String = STR_VACIO
        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader
        Dim intSemana As Integer
        Dim dblDisponible As Double = INT_CERO
        Dim dblTotales(5) As Double
        Dim dblContainers(5) As Double
        Dim strTemp As String = STR_VACIO
        Dim f As Byte
        Try
            strTemp = cFunciones.ArchivoTemporal
            f = FreeFile()
            FileOpen(f, strTemp, OpenMode.Append)

            Print(f, " <html > ")
            Print(f, " <head > ")


            Print(f, " <style type='text/css'>")
            Print(f, " table {table-layout: fixed; empty-cells: show; border-collapse:collapse}")
            Print(f, " caption {padding: 5px; text-align:left; font-family: Tahoma,  Arial;font-size: 8pt}")
            Print(f, " td {text-align:right;border:solid Gray 1px; padding:3px 5px; font-family: Tahoma, Arial;font-size: 7pt}")
            Print(f, " th {width: 1.8cm; border:solid Gray 1px; background-color: Black; color: White; padding:2px 5px; font-family: Tahoma,  Arial;font-size: 6pt}")
            Print(f, " th {text-align:center;border:solid Gray 1px; padding:3px 5px; font-family: Tahoma,  Arial;font-size: 7pt}")
            Print(f, " th.numero {text-align:right; mso-number-format:\#\,\#\#0\.00}")
            Print(f, " th.unitario {text-align:right; mso-number-format:\#\,\#\#0\.00#####}")
            Print(f, " th.titulo {text-align:right;font-family: Tahoma,  Arial;font-size: 9pt")
            Print(f, " .titulo {font-family: Tahoma,  Arial;font-size: 9pt}")
            Print(f, " .encabezado {text-align: left; border: none; width: 3.1cm}")
            Print(f, " .pie {font-family: Tahoma,  Arial;font-size: 7pt}")
            Print(f, " .izquierda {text-align:left}")
            Print(f, " .centro {text-align:center}")
            Print(f, " .derecha {text-align:right}")
            Print(f, " .info {text-align:left; border:none}")
            Print(f, "</style>")
            intSemana = DatePart(DateInterval.WeekOfYear, Fecha)
            Print(f, "<td colspan:'3' style='width: 21cm ;font-family: Tahoma;font-size:25pt;text-align:center'><b>ASIA REPORT WEEK  " & intSemana & " <br> </b></td>")
            ' Print(f, "<center><h3> <b> <td style=' width: 7cm;font-family: Tahoma;font-size:7pt;text-align:center'><b>ASIA REPORT WEEK  " & intSemana & "</td></h3></b></center>")
            ' Print(f, "<center><h3> <b> <td style='font-family: Tahoma;font-size:7pt;text-align:center'><b>To " & Fecha.ToString(FORMATO_MYSQL) & " </td></h3></b></center>")
            Print(f, "</head>")
            Print(f, "<body>")

            Print(f, "<table cellspacing=0>")
            Print(f, "<tr>")
            Print(f, "<th style='width: 5cm'>YARN DESCRIPTION</th>")
            Print(f, "<th style='width: 2.5cm;text-align:center'>PEND. TO SHIP</th>")
            Print(f, "<th style='width: 2.5cm;text-align:center'>OCEAN</th>")
            Print(f, "<th style='width: 2.5cm;text-align:center'>WAREHOUSE</th>")
            Print(f, "<th style='width: 2.5cm;text-align:center'>TOTAL GENERAL</th>")
            Print(f, "<th style='width: 2.5cm;text-align:center'>SOLD</th>")
            Print(f, "<th style='width: 2.5cm;text-align:center'>AVAILABLE</th>")
            Print(f, "</tr>")
            strSQL = sqlASIAReport(Fecha)
            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSQL, CON)
            REA = COM.ExecuteReader
            If REA.HasRows Then
                Do While REA.Read
                    dblDisponible = REA.GetDouble("TotalGeneral") - REA.GetDouble("SOLD")
                    Print(f, "<tr>")
                    Print(f, "<td style='width: 5cm; text-align:left'>" & REA.GetString("grupo") & "</td>")
                    Print(f, "<td style='width: 2.5cm'>" & (REA.GetDouble("PENDTOSHIP") + REA.GetDouble("PENDTOSHIPSOLD")).ToString(FORMATO_MONEDA) & "</td>")
                    Print(f, "<td style='width: 2.5cm'>" & (REA.GetDouble("OCEAN") + REA.GetDouble("OCEANSOLD")).ToString(FORMATO_MONEDA) & "</td>")
                    Print(f, "<td style='width: 2.5cm'>" & (REA.GetDouble("WAREHOUSE") + REA.GetDouble("WAREHOUSESOLD")).ToString(FORMATO_MONEDA) & "</td>")
                    Print(f, "<td style='width: 2.5cm'>" & REA.GetDouble("TotalGeneral").ToString(FORMATO_MONEDA) & "</td>")
                    Print(f, "<td style='width: 2.5cm'>" & REA.GetDouble("SOLD").ToString(FORMATO_MONEDA) & "</td>")
                    Print(f, "<td style='width: 2.5cm'>" & dblDisponible.ToString(FORMATO_MONEDA) & "</td>")
                    Print(f, "</tr>")
                    dblTotales(0) = dblTotales(0) + (REA.GetDouble("PENDTOSHIP") + REA.GetDouble("PENDTOSHIPSOLD")).ToString(FORMATO_MONEDA)
                    dblTotales(1) = dblTotales(1) + (REA.GetDouble("OCEAN") + REA.GetDouble("OCEANSOLD")).ToString(FORMATO_MONEDA)
                    dblTotales(2) = dblTotales(2) + (REA.GetDouble("WAREHOUSE") + REA.GetDouble("WAREHOUSESOLD")).ToString(FORMATO_MONEDA)
                    dblTotales(3) = dblTotales(3) + REA.GetDouble("TotalGeneral").ToString(FORMATO_MONEDA)
                    dblTotales(4) = dblTotales(4) + REA.GetDouble("SOLD").ToString(FORMATO_MONEDA)
                    dblTotales(5) = dblTotales(5) + dblDisponible
                Loop
            End If
            Print(f, "</table>")
            Print(f, "<br/>")
            Print(f, "<table cellspacing=0>")
            Print(f, "<tr>")
            Print(f, "<th style='width: 5cm;text-align:center;background-color: #87DE84; color: black'>ALL YARNS</th>")
            Print(f, "<th style='width: 2.5cm;text-align:center;background-color: #87DE84; color: black'>PEND TO SHIP</th>")
            Print(f, "<th style='width: 2.5cm;text-align:center;background-color: #87DE84; color: black'>OCEAN</th>")
            Print(f, "<th style='width: 2.5cm;text-align:center;background-color: #87DE84; color: black'>WAREHOUSE</th>")
            Print(f, "<th style='width: 2.5cm;text-align:center;background-color: #87DE84; color: black'>TOTAL GENERAL</th>")
            Print(f, "<th style='width: 2.5cm;text-align:center;background-color: #87DE84; color: black'>TOTAL SOLD</th>")
            Print(f, "<th style='width: 2.5cm;text-align:center;background-color: #87DE84; color: black'>TOTAL AVAILABLE</th>")
            Print(f, "</tr>")
            Print(f, "<tr>")
            Print(f, "<td style='width: 5cm; text-align:center'>TOTAL YARN</td>")
            Print(f, "<td style='width: 2.5cm'>" & dblTotales(0).ToString(FORMATO_MONEDA) & "</td>")
            Print(f, "<td style='width: 2.5cm'>" & dblTotales(1).ToString(FORMATO_MONEDA) & "</td>")
            Print(f, "<td style='width: 2.5cm'>" & dblTotales(2).ToString(FORMATO_MONEDA) & "</td>")
            Print(f, "<td style='width: 2.5cm'>" & dblTotales(3).ToString(FORMATO_MONEDA) & "</td>")
            Print(f, "<td style='width: 2.5cm'>" & dblTotales(4).ToString(FORMATO_MONEDA) & "</td>")
            Print(f, "<td style='width: 2.5cm'>" & dblTotales(5).ToString(FORMATO_MONEDA) & "</td>")
            Print(f, "</tr>")
            dblContainers(0) = dblContainers(0) + (dblTotales(0) / 40000)
            dblContainers(1) = dblContainers(1) + (dblTotales(1) / 40000)
            dblContainers(2) = dblContainers(2) + (dblTotales(2) / 40000)
            dblContainers(3) = dblContainers(3) + (dblTotales(3) / 40000)
            dblContainers(4) = dblContainers(4) + (dblTotales(4) / 40000)
            dblContainers(5) = dblContainers(5) + (dblTotales(5) / 40000)

            Print(f, "<tr>")
            Print(f, "<td style='width: 5cm; text-align:center'>TOTAL CONTAINERS</td>")
            Print(f, "<td style='width: 2.5cm'>" & CInt(dblContainers(0)).ToString(FORMATO_MONEDA) & "</td>")
            Print(f, "<td style='width: 2.5cm'>" & CInt(dblContainers(1)).ToString(FORMATO_MONEDA) & "</td>")
            Print(f, "<td style='width: 2.5cm'>" & CInt(dblContainers(2)).ToString(FORMATO_MONEDA) & "</td>")
            Print(f, "<td style='width: 2.5cm'>" & CInt(dblContainers(3)).ToString(FORMATO_MONEDA) & "</td>")
            Print(f, "<td style='width: 2.5cm'>" & CInt(dblContainers(4)).ToString(FORMATO_MONEDA) & "</td>")
            Print(f, "<td style='width: 2.5cm'>" & CInt(dblContainers(5)).ToString(FORMATO_MONEDA) & "</td>")
            Print(f, "</tr>")

            Print(f, "<tr>")
            Print(f, "<td style='width: 5cm; text-align:center'>% TOTAL SOLD AND AVAILABLE</td>")
            Print(f, "<td style='width: 2.5cm'>" & CInt((dblContainers(0) / dblContainers(3)) * 100).ToString(FORMATO_MONEDA) & " %</td>")
            Print(f, "<td style='width: 2.5cm'>" & CInt((dblContainers(1) / dblContainers(3)) * 100).ToString(FORMATO_MONEDA) & " %</td>")
            Print(f, "<td style='width: 2.5cm'>" & CInt((dblContainers(2) / dblContainers(3)) * 100).ToString(FORMATO_MONEDA) & " %</td>")
            Print(f, "<td style='width: 2.5cm'><br></td>")
            Print(f, "<td style='width: 2.5cm'>" & CInt((dblContainers(4) / dblContainers(3)) * 100).ToString(FORMATO_MONEDA) & " %</td>")
            Print(f, "<td style='width: 2.5cm'>" & CInt((dblContainers(5) / dblContainers(3)) * 100).ToString(FORMATO_MONEDA) & " %</td>")
            Print(f, "</tr>")


            Print(f, "</body>")
            Print(f, "</html>")


            FileClose(f)
            MostarReporte(strTemp)
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

#End Region

    Private Function EspacioHtml(ByVal numero As Integer) As String

        Dim strespacios As String = STR_VACIO
        For i As Integer = 0 To numero
            strespacios = strespacios & "&nbsp;"
        Next
        Return strespacios
    End Function


#Region "Balance Combinado"

    Private Function SQLBase()
        Dim strSQL As String = STR_VACIO

        strSQL = " SELECT e.idEmpresa empresa, e.Descripcion base, e.codigo_empresa codigo, e.conta_empresa conta "
        strSQL &= "    From " & YarnD & ".Empresa e "

        Return strSQL

    End Function
    Private Function PrimeraLineaReporte(ByVal emp As Integer, ByVal intNivel As Integer, ByVal strCuenta0 As String, strCuenta1 As String, ByVal strCuenta2 As String, ByVal strCuenta3 As String, ByVal dblSaldo As Double, ByVal dblSaldo2 As Double, ByVal dblSaldo3 As Double, ByVal dblSaldo4 As Double, ByVal dblSaldo5 As Double, ByVal logPrimera As Boolean, Optional lin As Integer = 0, Optional dbltotal As Double = 0, Optional dbltotal2 As Double = 0, Optional dbltotal3 As Double = 0, Optional dbltotal4 As Double = 0, Optional dbltotal5 As Double = 0, Optional intValidar2 As Integer = 0) As String
        Dim strHtml As String = STR_VACIO
        Dim intValidar As Integer
        Try
            Select Case intNivel
                Case 0
                    If logPrimera = True Then
                        If intValidar = INT_CERO And strCuenta0 = "EXPENSES" Then
                            strHtml &= "<tr>"
                            strHtml &= "<td class='titulo' style='background-color: #BDBDBD'>" & "GROSS PROFIT" & "</td>"
                            strHtml &= "<td class='encabezado' style='background-color: #BDBDBD; text-align: right'>" & dbltotal.ToString(FORMATO_MONEDA) & "</td>"
                            strHtml &= "<td class='encabezado' style='background-color: #BDBDBD; text-align: right'>" & dbltotal2.ToString(FORMATO_MONEDA) & "</td>"
                            strHtml &= "<td class='encabezado' style='background-color: #BDBDBD; text-align: right'>" & dbltotal2.ToString(FORMATO_MONEDA) & "</td>"
                            strHtml &= "<td class='encabezado' style='background-color: #BDBDBD; text-align: right'>" & dbltotal4.ToString(FORMATO_MONEDA) & "</td>"
                            Dim tataldbl = Math.Round((dbltotal + dbltotal2 + dbltotal3 + dbltotal4), 2)
                            strHtml &= "<td class='encabezado' style='background-color: #BDBDBD; text-align: right'>" & dbltotal.ToString(FORMATO_MONEDA) & "</td>"
                            strHtml &= "<td class='encabezado' style='background-color: #BDBDBD; text-align: right'>" & dbltotal5.ToString(FORMATO_MONEDA) & "</td>"
                            strHtml &= "</tr>"
                            intValidar = intValidar + 1
                        End If
                        strHtml &= "<tr>"
                        strHtml &= "<td class='titulo'>" & strCuenta0 & "</td>"
                        strHtml &= "<td class='derecha'>" & dblSaldo.ToString(FORMATO_MONEDA) & "</td>"
                        strHtml &= "<td class='derecha'>" & dblSaldo2.ToString(FORMATO_MONEDA) & "</td>"
                        strHtml &= "<td class='derecha'>" & dblSaldo3.ToString(FORMATO_MONEDA) & "</td>"
                        strHtml &= "<td class='derecha'>" & dblSaldo4.ToString(FORMATO_MONEDA) & "</td>"

                        Dim sumaTotal As Double = Math.Round((dblSaldo + dblSaldo2 + dblSaldo3 + dblSaldo4), 2)
                        strHtml &= "<td class='derecha'>" & sumaTotal.ToString(FORMATO_MONEDA) & "</td>"
                        strHtml &= "<td class='derecha'>" & dblSaldo5.ToString(FORMATO_MONEDA) & "</td>"
                        strHtml &= "<td class='derecha'>" & (sumaTotal - dbltotal5).ToString(FORMATO_MONEDA) & "</td>"
                        strHtml &= "</tr>"
                    End If
                Case 1
                    If logPrimera = True Then
                        If intValidar = INT_CERO And strCuenta0 = "EXPENSES" Then
                            strHtml &= "<tr>"
                            strHtml &= "<td class='titulo' style='background-color: #BDBDBD'>" & "GROSS PROFIT" & "</td>"
                            strHtml &= "<td class='encabezado' style='background-color: #BDBDBD; text-align: right'>" & dbltotal.ToString(FORMATO_MONEDA) & "</td>"
                            strHtml &= "<td class='encabezado' style='background-color: #BDBDBD; text-align: right'>" & dbltotal2.ToString(FORMATO_MONEDA) & "</td>"
                            strHtml &= "<td class='encabezado' style='background-color: #BDBDBD; text-align: right'>" & dbltotal2.ToString(FORMATO_MONEDA) & "</td>"
                            strHtml &= "<td class='encabezado' style='background-color: #BDBDBD; text-align: right'>" & dbltotal4.ToString(FORMATO_MONEDA) & "</td>"
                            Dim tataldbl = Math.Round((dbltotal + dbltotal2 + dbltotal3 + dbltotal4), 2)
                            strHtml &= "<td class='encabezado' style='background-color: #BDBDBD; text-align: right'>" & dbltotal.ToString(FORMATO_MONEDA) & "</td>"
                            strHtml &= "<td class='encabezado' style='background-color: #BDBDBD; text-align: right'>" & dbltotal5.ToString(FORMATO_MONEDA) & "</td>"
                            strHtml &= "</tr>"
                            intValidar = intValidar + 1
                        End If
                        strHtml &= "<tr>"
                        strHtml &= "<td class='titulo'>" & strCuenta0 & "</td>"
                        strHtml &= "</tr>"
                    End If
                    strHtml &= "<tr>"
                    strHtml &= "<td class='encabezado'>" & EspacioHtml(5) & strCuenta1 & "</td>"
                    strHtml &= "<td class='derecha'>" & dblSaldo.ToString(FORMATO_MONEDA) & "</td>"
                    strHtml &= "<td class='derecha'>" & dblSaldo2.ToString(FORMATO_MONEDA) & "</td>"
                    strHtml &= "<td class='derecha'>" & dblSaldo3.ToString(FORMATO_MONEDA) & "</td>"
                    strHtml &= "<td class='derecha'>" & dblSaldo4.ToString(FORMATO_MONEDA) & "</td>"

                    Dim sumaTotal As Double = Math.Round((dblSaldo + dblSaldo2 + dblSaldo3 + dblSaldo4), 2)
                    strHtml &= "<td class='derecha'>" & sumaTotal.ToString(FORMATO_MONEDA) & "</td>"
                    strHtml &= "<td class='derecha'>" & dblSaldo5.ToString(FORMATO_MONEDA) & "</td>"
                    strHtml &= "<td class='derecha'>" & (sumaTotal - dbltotal5).ToString(FORMATO_MONEDA) & "</td>"
                    strHtml &= "</tr>"

                Case 2
                    If logPrimera = True Then
                        If intValidar = 0 And strCuenta0 = "EXPENSES" Then
                            strHtml &= "<tr>"
                            strHtml &= "<td class='titulo' style='background-color: #BDBDBD'>" & "GROSS PROFIT" & "</td>"
                            strHtml &= "<td class='encabezado' style='background-color: #BDBDBD; text-align: right'>" & dbltotal.ToString(FORMATO_MONEDA) & "</td>"
                            strHtml &= "<td class='encabezado' style='background-color: #BDBDBD; text-align: right'>" & dbltotal2.ToString(FORMATO_MONEDA) & "</td>"
                            strHtml &= "<td class='encabezado' style='background-color: #BDBDBD; text-align: right'>" & dbltotal2.ToString(FORMATO_MONEDA) & "</td>"
                            strHtml &= "<td class='encabezado' style='background-color: #BDBDBD; text-align: right'>" & dbltotal4.ToString(FORMATO_MONEDA) & "</td>"
                            Dim tataldbl = Math.Round((dbltotal + dbltotal2 + dbltotal3 + dbltotal4), 2)
                            strHtml &= "<td class='encabezado' style='background-color: #BDBDBD; text-align: right'>" & dbltotal.ToString(FORMATO_MONEDA) & "</td>"
                            strHtml &= "<td class='encabezado' style='background-color: #BDBDBD; text-align: right'>" & dbltotal5.ToString(FORMATO_MONEDA) & "</td>"
                            strHtml &= "</tr>"
                            intValidar = intValidar + 1
                        End If
                        If lin = 0 Then
                            strHtml &= "<tr>"
                            strHtml &= "<td class='titulo'>" & strCuenta0 & "</td>"
                            strHtml &= "</tr>"

                            strHtml &= "<tr>"
                            strHtml &= "<td class='encabezado'>" & EspacioHtml(5) & strCuenta1 & "</td>"
                            strHtml &= "</tr>"
                        Else
                            strHtml &= "<tr>"
                            strHtml &= "<td class='encabezado'>" & EspacioHtml(5) & strCuenta1 & "</td>"
                            strHtml &= "</tr>"
                        End If
                    End If

                    strHtml &= "<tr>"
                    strHtml &= "<td class='centro'> " & EspacioHtml(10) & strCuenta2.ToString & "</td>"
                    strHtml &= "<td class='derecha'>" & dblSaldo.ToString(FORMATO_MONEDA) & "</td>"
                    strHtml &= "<td class='derecha'>" & dblSaldo2.ToString(FORMATO_MONEDA) & "</td>"
                    strHtml &= "<td class='derecha'>" & dblSaldo3.ToString(FORMATO_MONEDA) & "</td>"
                    strHtml &= "<td class='derecha'>" & dblSaldo4.ToString(FORMATO_MONEDA) & "</td>"

                    Dim sumaTotal As Double = Math.Round((dblSaldo + dblSaldo2 + dblSaldo3 + dblSaldo4), 2)
                    strHtml &= "<td class='derecha'>" & sumaTotal.ToString(FORMATO_MONEDA) & "</td>"
                    strHtml &= "<td class='derecha'>" & dblSaldo5.ToString(FORMATO_MONEDA) & "</td>"
                    strHtml &= "<td class='derecha'>" & (sumaTotal - dblSaldo5).ToString(FORMATO_MONEDA) & "</td>"
                    strHtml &= "</tr>"
                Case 3
                    If logPrimera = True Then
                        If intValidar2 = 0 And strCuenta0 = "EXPENSES" Then
                            strHtml &= "<tr>"
                            strHtml &= "<td class='titulo' style='background-color: #BDBDBD'>" & "GROSS PROFIT" & "</td>"
                            strHtml &= "<td class='encabezado' style='background-color: #BDBDBD; text-align: right'>" & dbltotal.ToString(FORMATO_MONEDA) & "</td>"
                            strHtml &= "<td class='encabezado' style='background-color: #BDBDBD; text-align: right'>" & dbltotal2.ToString(FORMATO_MONEDA) & "</td>"
                            strHtml &= "<td class='encabezado' style='background-color: #BDBDBD; text-align: right'>" & dbltotal3.ToString(FORMATO_MONEDA) & "</td>"
                            strHtml &= "<td class='encabezado' style='background-color: #BDBDBD; text-align: right'>" & dbltotal4.ToString(FORMATO_MONEDA) & "</td>"

                            Dim sumadblTotal1 As Double = Math.Round((dbltotal + dbltotal2 + dbltotal3 + dbltotal4), 2)
                            strHtml &= "<td class='encabezado' style='background-color: #BDBDBD; text-align: right; text-align: right'>" & sumadblTotal1.ToString(FORMATO_MONEDA) & "</td>"
                            strHtml &= "<td class='encabezado' style='background-color: #BDBDBD; text-align: right'>" & dbltotal5.ToString(FORMATO_MONEDA) & "</td>"
                            strHtml &= "<td class='encabezado' style='background-color: #BDBDBD; text-align: right'>" & (sumadblTotal1 - dbltotal5).ToString(FORMATO_MONEDA) & "</td>"
                            strHtml &= "</tr>"
                            intValidar = intValidar + 1
                        End If
                        If lin = 0 Then
                            strHtml &= "<tr>"
                            strHtml &= "<td class='titulo'>" & strCuenta0 & "</td>"
                            strHtml &= "</tr>"

                            strHtml &= "<tr>"
                            strHtml &= "<td class='encabezado'>" & EspacioHtml(5) & strCuenta1 & "</td>"
                            strHtml &= "</tr>"
                        Else
                            strHtml &= "<tr>"
                            strHtml &= "<td class='encabezado'>" & EspacioHtml(5) & strCuenta1 & "</td>"
                            strHtml &= "</tr>"
                        End If

                    End If

                    strHtml &= "<tr>"
                    strHtml &= "<td class='centro'> " & EspacioHtml(10) & strCuenta2.ToString & "</td>"
                    strHtml &= "</tr>"

                    strHtml &= "<tr>"
                    strHtml &= "<td class='centro'> " & EspacioHtml(15) & strCuenta3.ToString & "</td>"
                    strHtml &= "<td class='derecha'>" & dblSaldo.ToString(FORMATO_MONEDA) & "</td>"
                    strHtml &= "<td class='derecha'>" & dblSaldo2.ToString(FORMATO_MONEDA) & "</td>"
                    strHtml &= "<td class='derecha'>" & dblSaldo3.ToString(FORMATO_MONEDA) & "</td>"
                    strHtml &= "<td class='derecha'>" & dblSaldo4.ToString(FORMATO_MONEDA) & "</td>"

                    Dim sumadblTotal As Double = Math.Round((dblSaldo + dblSaldo2 + dblSaldo3 + dblSaldo4), 2)
                    strHtml &= "<td class='derecha'>" & sumadblTotal.ToString(FORMATO_MONEDA) & "</td>"
                    strHtml &= "<td class='derecha'>" & dblSaldo5.ToString(FORMATO_MONEDA) & "</td>"
                    strHtml &= "<td class='derecha'>" & (sumadblTotal - dblSaldo5).ToString(FORMATO_MONEDA) & "</td>"
                    strHtml &= "</tr>"
            End Select
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        Return strHtml
    End Function

    Private Function SubtotalReport(ByVal intNivel As Integer, ByVal strCuenta As String, ByVal dblsub As Double, ByVal dblsub2 As Double, ByVal dblsub3 As Double, ByVal dblsub4 As Double, ByVal dblsub5 As Double)
        Dim strHtml As String = STR_VACIO
        Try
            Select Case intNivel
                Case 0
                    strHtml &= "<tr>"
                    strHtml &= "<td class='titulo'>  TOTAL " & strCuenta & "</td>"
                    strHtml &= "<td class='titulo' style='text-align: right'>" & dblsub.ToString(FORMATO_MONEDA) & "</td>"
                    strHtml &= "<td class='titulo' style='text-align: right'>" & dblsub2.ToString(FORMATO_MONEDA) & "</td>"
                    strHtml &= "<td class='titulo' style='text-align: right'>" & dblsub3.ToString(FORMATO_MONEDA) & "</td>"
                    strHtml &= "<td class='titulo' style='text-align: right'>" & dblsub4.ToString(FORMATO_MONEDA) & "</td>"

                    Dim sumaTotal As Double = Math.Round((dblsub + dblsub2 + dblsub3 + dblsub4), 2)
                    strHtml &= "<td class='encabezado' style='text-align: right'>" & sumaTotal.ToString(FORMATO_MONEDA) & "</td>"
                    strHtml &= "<td class='encabezado' style='text-align: right'>" & dblsub5.ToString(FORMATO_MONEDA) & "</td>"
                    strHtml &= "<td class='encabezado' style='text-align: right'>" & (sumaTotal - dblsub5).ToString(FORMATO_MONEDA) & "</td>"
                    strHtml &= "</tr>"
                Case 1
                    strHtml &= "<tr>"
                    strHtml &= "<td class='encabezado'> " & EspacioHtml(5) & " TOTAL " & strCuenta & "</td>"
                    strHtml &= "<td class='encabezado' style='text-align: right'>" & dblsub.ToString(FORMATO_MONEDA) & "</td>"
                    strHtml &= "<td class='encabezado' style='text-align: right'>" & dblsub2.ToString(FORMATO_MONEDA) & "</td>"
                    strHtml &= "<td class='encabezado' style='text-align: right'>" & dblsub3.ToString(FORMATO_MONEDA) & "</td>"
                    strHtml &= "<td class='encabezado' style='text-align: right'>" & dblsub4.ToString(FORMATO_MONEDA) & "</td>"

                    Dim sumaTotal As Double = Math.Round((dblsub + dblsub2 + dblsub3 + dblsub4), 2)
                    strHtml &= "<td class='encabezado' style='text-align: right'>" & sumaTotal.ToString(FORMATO_MONEDA) & "</td>"
                    strHtml &= "<td class='encabezado' style='text-align: right'>" & dblsub5.ToString(FORMATO_MONEDA) & "</td>"
                    strHtml &= "<td class='encabezado' style='text-align: right'>" & (sumaTotal - dblsub5).ToString(FORMATO_MONEDA) & "</td>"
                    strHtml &= "</tr>"
                Case 2
                    strHtml &= "<tr>"
                    strHtml &= "<td class='encabezado'> " & EspacioHtml(10) & " TOTAL " & strCuenta & "</td>"
                    strHtml &= "<td class='encabezado' style='text-align: right'>" & dblsub.ToString(FORMATO_MONEDA) & "</td>"
                    strHtml &= "<td class='encabezado' style='text-align: right'>" & dblsub2.ToString(FORMATO_MONEDA) & "</td>"
                    strHtml &= "<td class='encabezado' style='text-align: right'>" & dblsub3.ToString(FORMATO_MONEDA) & "</td>"
                    strHtml &= "<td class='encabezado' style='text-align: right'>" & dblsub4.ToString(FORMATO_MONEDA) & "</td>"

                    Dim sumaTotal As Double = Math.Round((dblsub + dblsub2 + dblsub3 + dblsub4), 2)
                    strHtml &= "<td class='encabezado' style='text-align: right'>" & sumaTotal.ToString(FORMATO_MONEDA) & "</td>"
                    strHtml &= "<td class='encabezado' style='text-align: right'>" & dblsub5.ToString(FORMATO_MONEDA) & "</td>"
                    strHtml &= "<td class='encabezado' style='text-align: right'>" & (sumaTotal - dblsub5).ToString(FORMATO_MONEDA) & "</td>"
                    strHtml &= "</tr>"
                Case 3
                    strHtml &= "<tr>"
                    strHtml &= "<td class='encabezado'> " & EspacioHtml(15) & " TOTAL " & strCuenta & "</td>"
                    strHtml &= "<td class='encabezado' style='text-align: right'>" & dblsub.ToString(FORMATO_MONEDA) & "</td>"
                    strHtml &= "<td class='encabezado' style='text-align: right'>" & dblsub2.ToString(FORMATO_MONEDA) & "</td>"
                    strHtml &= "<td class='encabezado' style='text-align: right'>" & dblsub3.ToString(FORMATO_MONEDA) & "</td>"
                    strHtml &= "<td class='encabezado' style='text-align: right'>" & dblsub4.ToString(FORMATO_MONEDA) & "</td>"

                    Dim sumatotal As Double = Math.Round((dblsub + dblsub2 + dblsub3 + dblsub4), 2)
                    strHtml &= "<td class='encabezado' style='text-align: right'>" & sumatotal.ToString(FORMATO_MONEDA) & "</td>"
                    strHtml &= "<td class='encabezado' style='text-align: right'>" & dblsub5.ToString(FORMATO_MONEDA) & "</td>"
                    strHtml &= "<td class='encabezado' style='text-align: right'>" & (sumatotal - dblsub5).ToString(FORMATO_MONEDA) & "</td>"
                    strHtml &= "</tr>"
                Case 4
                    strHtml &= "<tr>"
                    strHtml &= "<td class='encabezado'> " & EspacioHtml(20) & " TOTAL " & strCuenta & "</td>"
                    strHtml &= "<td class='encabezado' style='text-align: right'>" & dblsub.ToString(FORMATO_MONEDA) & "</td>"
                    strHtml &= "<td class='encabezado' style='text-align: right'>" & dblsub2.ToString(FORMATO_MONEDA) & "</td>"
                    strHtml &= "<td class='encabezado' style='text-align: right'>" & dblsub3.ToString(FORMATO_MONEDA) & "</td>"
                    strHtml &= "<td class='encabezado' style='text-align: right'>" & dblsub4.ToString(FORMATO_MONEDA) & "</td>"

                    Dim sumaTotal As Double = Math.Round((dblsub + dblsub2 + dblsub3 + dblsub4), 2)
                    strHtml &= "<td class='encabezado' style='text-align: right'>" & sumaTotal.ToString(FORMATO_MONEDA) & "</td>"
                    strHtml &= "<td class='encabezado' style='text-align: right'>" & dblsub5.ToString(FORMATO_MONEDA) & "</td>"
                    strHtml &= "<td class='encabezado' style='text-align: right'>" & (sumaTotal - dblsub5).ToString(FORMATO_MONEDA) & "</td>"
                    strHtml &= "</tr>"
            End Select

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        Return strHtml
    End Function

    Private Function LineaReport(ByVal intNivel As Integer, ByVal strCuenta As String, ByVal dblsaldo As Double, ByVal dblsaldo2 As Double, ByVal dblsaldo3 As Double, ByVal dblsaldo4 As Double, ByVal dblsaldo5 As Double) As String
        Dim strHtml As String = STR_VACIO
        Try
            Select Case intNivel
                Case 0
                    strHtml &= "<tr>"
                    strHtml &= "<td class='centro'>" & strCuenta.ToString & "</td>"
                    strHtml &= "<td class='derecha'>" & dblsaldo.ToString(FORMATO_MONEDA) & "</td>"
                    strHtml &= "<td class='derecha'>" & dblsaldo2.ToString(FORMATO_MONEDA) & "</td>"
                    strHtml &= "<td class='derecha'>" & dblsaldo3.ToString(FORMATO_MONEDA) & "</td>"
                    strHtml &= "<td class='derecha'>" & dblsaldo4.ToString(FORMATO_MONEDA) & "</td>"

                    Dim sumadblTotal As Double = Math.Round((dblsaldo + dblsaldo2 + dblsaldo3 + dblsaldo4), 2)
                    strHtml &= "<td class='derecha'>" & sumadblTotal.ToString(FORMATO_MONEDA) & "</td>"
                    strHtml &= "<td class='derecha' style='text-align: right'>" & dblsaldo5.ToString(FORMATO_MONEDA) & "</td>"
                    strHtml &= "<td class='derecha' style='text-align: right'>" & (sumadblTotal - dblsaldo5).ToString(FORMATO_MONEDA) & "</td>"
                    strHtml &= "</tr>"
                Case 1
                    strHtml &= "<tr>"
                    strHtml &= "<td class='centro'>" & EspacioHtml(5) & strCuenta.ToString & "</td>"
                    strHtml &= "<td class='derecha'>" & dblsaldo.ToString(FORMATO_MONEDA) & "</td>"
                    strHtml &= "<td class='derecha'>" & dblsaldo2.ToString(FORMATO_MONEDA) & "</td>"
                    strHtml &= "<td class='derecha'>" & dblsaldo3.ToString(FORMATO_MONEDA) & "</td>"
                    strHtml &= "<td class='derecha'>" & dblsaldo4.ToString(FORMATO_MONEDA) & "</td>"

                    Dim sumadblTotal As Double = Math.Round((dblsaldo + dblsaldo2 + dblsaldo3 + dblsaldo4), 2)
                    strHtml &= "<td class='derecha'>" & sumadblTotal.ToString(FORMATO_MONEDA) & "</td>"
                    strHtml &= "<td class='derecha' style='text-align: right'>" & dblsaldo5.ToString(FORMATO_MONEDA) & "</td>"
                    strHtml &= "<td class='derecha' style='text-align: right'>" & (sumadblTotal - dblsaldo5).ToString(FORMATO_MONEDA) & "</td>"
                    strHtml &= "</tr>"
                Case 2
                    strHtml &= "<tr>"
                    strHtml &= "<td class='centro'>" & EspacioHtml(10) & strCuenta.ToString & "</td>"
                    strHtml &= "<td class='derecha'>" & dblsaldo.ToString(FORMATO_MONEDA) & "</td>"
                    strHtml &= "<td class='derecha'>" & dblsaldo2.ToString(FORMATO_MONEDA) & "</td>"
                    strHtml &= "<td class='derecha'>" & dblsaldo3.ToString(FORMATO_MONEDA) & "</td>"
                    strHtml &= "<td class='derecha'>" & dblsaldo4.ToString(FORMATO_MONEDA) & "</td>"

                    Dim sumadblTotal As Double = Math.Round((dblsaldo + dblsaldo2 + dblsaldo3 + dblsaldo4), 2)
                    strHtml &= "<td class='derecha'>" & sumadblTotal.ToString(FORMATO_MONEDA) & "</td>"
                    strHtml &= "<td class='derecha' style='text-align: right'>" & dblsaldo5.ToString(FORMATO_MONEDA) & "</td>"
                    strHtml &= "<td class='derecha' style='text-align: right'>" & (sumadblTotal - dblsaldo5).ToString(FORMATO_MONEDA) & "</td>"
                    strHtml &= "</tr>"
                Case 3
                    strHtml &= "<tr>"
                    strHtml &= "<td class='centro'>" & EspacioHtml(15) & strCuenta.ToString & "</td>"
                    strHtml &= "<td class='derecha'>" & dblsaldo.ToString(FORMATO_MONEDA) & "</td>"
                    strHtml &= "<td class='derecha'>" & dblsaldo2.ToString(FORMATO_MONEDA) & "</td>"
                    strHtml &= "<td class='derecha'>" & dblsaldo3.ToString(FORMATO_MONEDA) & "</td>"
                    strHtml &= "<td class='derecha'>" & dblsaldo4.ToString(FORMATO_MONEDA) & "</td>"

                    Dim sumatotal As Double = Math.Round((dblsaldo + dblsaldo2 + dblsaldo3 + dblsaldo4), 2)
                    strHtml &= "<td class='derecha'>" & sumatotal.ToString(FORMATO_MONEDA) & "</td>"
                    strHtml &= "<td class='derecha' style='text-align: right'>" & dblsaldo5.ToString(FORMATO_MONEDA) & "</td>"
                    strHtml &= "<td class='derecha' style='text-align: right'>" & (sumatotal - dblsaldo5).ToString(FORMATO_MONEDA) & "</td>"
                    strHtml &= "</tr>"
                Case 4
                    strHtml &= "<tr>"
                    strHtml &= "<td class='centro'>" & EspacioHtml(20) & strCuenta.ToString & "</td>"
                    strHtml &= "<td class='derecha'>" & dblsaldo.ToString(FORMATO_MONEDA) & "</td>"
                    strHtml &= "<td class='derecha'>" & dblsaldo2.ToString(FORMATO_MONEDA) & "</td>"
                    strHtml &= "<td class='derecha'>" & dblsaldo3.ToString(FORMATO_MONEDA) & "</td>"
                    strHtml &= "<td class='derecha'>" & dblsaldo4.ToString(FORMATO_MONEDA) & "</td>"

                    Dim sumadblTotal As Double = Math.Round((dblsaldo + dblsaldo2 + dblsaldo3 + dblsaldo4), 2)
                    strHtml &= "<td class='derecha'>" & sumadblTotal.ToString(FORMATO_MONEDA) & "</td>"
                    strHtml &= "<td class='derecha' style='text-align: right'>" & dblsaldo5.ToString(FORMATO_MONEDA) & "</td>"
                    strHtml &= "<td class='derecha' style='text-align: right'>" & (sumadblTotal - dblsaldo5).ToString(FORMATO_MONEDA) & "</td>"
                    strHtml &= "</tr>"
            End Select


        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        Return strHtml
    End Function

    Private Function SqlBalanceReport(ByVal intOpcion As Integer, ByVal TC As Double) As String
        Dim strSql As String = STR_VACIO
        Try
            strSql = "SELECT t.*, e.conta_empresa conta FROM (SELECT CEmpresa, Cuenta0, Cuenta1, Cuenta2, Nivel0, Nivel1, Nivel2, NIvel3, Nivel4, Cuenta3, SUM(CASE WHEN CEmpresa = 1 THEN Saldo ELSE 0 END) SaldoGt, 
                        SUM(CASE WHEN CEmpresa = 2 THEN Saldo ELSE 0 END) SaldoSv, SUM(CASE WHEN CEmpresa = 3 THEN Saldo ELSE 0 END) SaldoHn, 
                            SUM(CASE WHEN CEmpresa = 4 THEN Saldo ELSE 0 END) SaldoDr, 0 trading 
                                FROM YarnDivision.Combined_Balance
                                    GROUP BY Cuenta3) t
                                        LEFT JOIN YarnDivision.Empresa e ON e.idEmpresa = t.CEmpresa "
            Select Case intOpcion
                Case 0
                    strSql &= "  group by t.Cuenta0 "
                Case 1
                    strSql &= "  group by t.Cuenta1 "
                Case 2
                    strSql &= "  group by t.Cuenta2 "
                Case 3
                    strSql &= "  group by t.Cuenta3 "
                    'Case 4
                    '    strSql &= "  group by n.Cuenta4 "

            End Select

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        Return strSql
    End Function


    Private Function ResultadoEjercicioReport(ByVal FechaIni As Date, ByVal FechaFic As Date, ByVal TC As Double, ByVal conta As String, ByVal empresa As String) As Double
        Dim strSql As String = STR_VACIO
        Dim dblResultado As Double = INT_CERO
        Dim COM As MySqlCommand
        Dim CON2 As MySqlConnection
        Try
            strSql = " SELECT SUM((
                        SELECT IFNULL(SUM(IF(d.operacion = 'C', (IFNULL(d.importe / {tc},0)), (IFNULL(d.importe / {tc},0))*-1)),0)
                        FROM {conta}.polizas p
                        LEFT JOIN {conta}.detalle_polizas d ON d.empresa = p.empresa AND d.ejercicio = p.ejercicio AND d.poliza = p.poliza
                        LEFT JOIN {conta}.tipo_poliza t on t.tipo_poliza = p.tipo
                            WHERE p.empresa = {empresa} AND p.fecha BETWEEN '{inicio}' AND '{fin}' AND d.cuenta = n.Cuenta4 AND NOT t.tipo_poliza IN(4,5)))saldo
                            FROM {conta}.nomenclatura_nivel n
                            WHERE n.Cuenta0 >=4 "

            strSql = Replace(strSql, "{tc}", TC)
            strSql = Replace(strSql, "{conta}", conta)
            strSql = Replace(strSql, "{empresa}", empresa)
            strSql = Replace(strSql, "{inicio}", FechaIni.ToString(FORMATO_MYSQL))
            strSql = Replace(strSql, "{fin}", FechaFic.ToString(FORMATO_MYSQL))

            CON2 = New MySqlConnection(strConexion)
            CON2.Open()
            COM = New MySqlCommand(strSql, CON2)
            dblResultado = CDbl(COM.ExecuteScalar)
            dblResultado = dblResultado
            CON2.Clone()
            CON2.Dispose()
            CON2 = Nothing
            System.GC.Collect()

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        Return dblResultado
    End Function

    Private Function SQLTC_Corte(ByVal fecha As Date) As Double
        Dim strsql As String = STR_VACIO
        Dim dblresultado As Double = INT_CERO
        Dim com As MySqlCommand
        Dim CON3 As MySqlConnection
        Try
            strsql = "SELECT t.Tasa
                                FROM TCambio t
                                WHERE t.Fecha= '{fecha}'"

            strsql = strsql.Replace("{fecha}", fecha.ToString(FORMATO_MYSQL))
            CON3 = New MySqlConnection(strConexion)
            CON3.Open()
            com = New MySqlCommand(strsql, CON3)
            dblresultado = CDbl(com.ExecuteScalar)
            dblresultado = dblresultado
            CON3.Clone()
            CON3.Dispose()
            CON3 = Nothing
            System.GC.Collect()

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        Return dblresultado
    End Function

    Private Function SqlPromedioTC(ByVal FechaIni As Date, ByVal FechaFic As Date, ByVal empresa As String) As Double
        Dim strsql As String = STR_VACIO
        Dim dblresultado As Double = INT_CERO
        Dim com As MySqlCommand
        Dim CON3 As MySqlConnection
        Try
            strsql = "SELECT ROUND(AVG(c.Tasa),4) TC
                        FROM {empresa}.TCambio c
                        WHERE c.Fecha BETWEEN '{fechai}' AND '{fechan}'"

            strsql = strsql.Replace("{fechai}", FechaIni.ToString(FORMATO_MYSQL))
            strsql = strsql.Replace("{fechan}", FechaFic.ToString(FORMATO_MYSQL))
            strsql = strsql.Replace("{empresa}", empresa.ToString)
            CON3 = New MySqlConnection(strConexion)
            CON3.Open()
            com = New MySqlCommand(strsql, CON3)
            dblresultado = CDbl(com.ExecuteScalar)
            dblresultado = dblresultado
            CON3.Clone()
            CON3.Dispose()
            CON3 = Nothing
            System.GC.Collect()

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        Return dblresultado
    End Function

    Private Function SqlTCDia(ByVal FechaIni As Date, ByVal FechaFic As Date, ByVal empresa As String) As Double
        Dim strsql As String = STR_VACIO
        Dim dblresultado As Double = INT_CERO
        Dim com As MySqlCommand
        Dim CON3 As MySqlConnection
        Try
            strsql = "SELECT ROUND(IFNULL(c.Tasa,0),4) TC
                        FROM {empresa}.TCambio c
                        WHERE c.Fecha BETWEEN DATE_ADD('{fechan}',INTERVAL -1 MONTH) AND '{fechan}' ORDER BY c.Fecha DESC LIMIT 1 "

            'strsql = strsql.Replace("{fechai}", FechaIni.ToString(FORMATO_MYSQL))
            strsql = strsql.Replace("{fechan}", FechaFic.ToString(FORMATO_MYSQL))
            strsql = strsql.Replace("{empresa}", empresa.ToString)
            CON3 = New MySqlConnection(strConexion)
            CON3.Open()
            com = New MySqlCommand(strsql, CON3)
            dblresultado = CDbl(com.ExecuteScalar)
            dblresultado = dblresultado
            CON3.Clone()
            CON3.Dispose()
            CON3 = Nothing
            System.GC.Collect()

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        Return dblresultado
    End Function

    Public Sub BalanceReport(ByVal FechaIni As Date, ByVal FechaFic As Date)
        Dim crport As New clsReportes
        Dim strsql As String = STR_VACIO
        Dim strHtml As String = STR_VACIO
        Dim frm As New frmFiltro
        Dim frmO As New frmOption
        Dim frmMon As New frmOption
        Dim logPrimeraLinea As Boolean = True
        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader
        Dim REA2 As MySqlDataReader
        Dim strTemp As String = STR_VACIO
        Dim conta As String = STR_VACIO
        Dim conta1 As String = STR_VACIO
        Dim conta2 As String = STR_VACIO
        Dim conta3 As String = STR_VACIO
        Dim conta4 As String = STR_VACIO
        Dim empresa1 As String = STR_VACIO
        Dim empresa2 As String = STR_VACIO
        Dim empresa3 As String = STR_VACIO
        Dim empresa4 As String = STR_VACIO

        Dim dblTotalNivel0 As Double = INT_CERO
        Dim dblTotalNivel02 As Double = INT_CERO
        Dim dblTotalNivel03 As Double = INT_CERO
        Dim dblTotalNivel04 As Double = INT_CERO
        Dim dblTotalNivel05 As Double = INT_CERO
        Dim dblTotalNivel1 As Double = INT_CERO
        Dim dblTotalNivel12 As Double = INT_CERO
        Dim dblTotalNivel13 As Double = INT_CERO
        Dim dblTotalNivel14 As Double = INT_CERO
        Dim dblTotalNivel15 As Double = INT_CERO
        Dim dblTotalNivel2 As Double = INT_CERO
        Dim dblTotalNivel22 As Double = INT_CERO
        Dim dblTotalNivel23 As Double = INT_CERO
        Dim dblTotalNivel24 As Double = INT_CERO
        Dim dblTotalNivel25 As Double = INT_CERO
        Dim dblTotalNivel3 As Double = INT_CERO
        Dim dblTotalNivel32 As Double = INT_CERO
        Dim dblTotalNivel33 As Double = INT_CERO
        Dim dblTotalNivel34 As Double = INT_CERO
        Dim dblTotalNivel35 As Double = INT_CERO
        Dim dblTotalNivel4 As Double = INT_CERO
        Dim dblTotalNivel5 As Double = INT_CERO
        Dim dblEjercicioActual As Double = INT_CERO
        Dim dblEjercicioActual2 As Double = INT_CERO
        Dim dblEjercicioActual3 As Double = INT_CERO
        Dim dblEjercicioActual4 As Double = INT_CERO
        Dim dblEjercicioActual5 As Double = INT_CERO

        Dim intMoneda As Integer = NO_FILA
        Dim dblTC_ As Double = INT_CERO
        Dim dblTC_2 As Double = INT_CERO
        Dim dblTC_3 As Double = INT_CERO
        Dim dblTC_4 As Double = INT_CERO
        Dim PromedioTC As Double = INT_CERO
        Dim PromedioTC2 As Double = INT_CERO
        Dim PromedioTC3 As Double = INT_CERO
        Dim PromedioTC4 As Double = INT_CERO

        Dim PromedioTCTitulo As Double = INT_CERO
        Dim PromedioTC2Titulo As Double = INT_CERO
        Dim PromedioTC3Titulo As Double = INT_CERO
        Dim PromedioTC4Titulo As Double = INT_CERO

        Dim strMon As String = STR_VACIO
        Dim dblSaldoVenta As Double = INT_CERO
        Dim dblSaldoVenta2 As Double = INT_CERO
        Dim dblSaldoVenta3 As Double = INT_CERO
        Dim dblSaldoVenta4 As Double = INT_CERO
        Dim dblSaldoVenta5 As Double = INT_CERO

        Dim strNivel0 As String = STR_VACIO
        Dim strNivel1 As String = STR_VACIO
        Dim strNivel2 As String = STR_VACIO
        Dim strNivel3 As String = STR_VACIO
        Dim strNivel4 As String = STR_VACIO
        Dim intConteo As Integer = 0

        Dim str2Niveles As String = STR_VACIO
        Dim dbl2Totales As Double = 0
        Dim dbl2Totales2 As Double = 0
        Dim dbl2Totales3 As Double = 0
        Dim dbl2Totales4 As Double = 0
        Dim dbl2Totales5 As Double = 0
        Dim empresa As String = STR_VACIO
        Dim f As Byte
        Try

            frmO.Titulo = "Select a level"
            frmO.Text = "Select a level "
            frmO.Opciones = "Level 1| Level 2 |Level 3 | Level 4"
            frmO.ShowDialog(frmSPrincipal)
            If frmO.DialogResult = DialogResult.OK Then
                If Sesion.IdEmpresa = 16 Then
                    intMoneda = INT_CERO
                    strMon = cFunciones.TraerMoneda(cFunciones.MonedaDefault(0))
                    PromedioTC = SqlPromedioTC(FechaIni, FechaFic, empresa)
                Else
                    frmMon.Titulo = "Select a Currency"
                    frmMon.Text = "Select a Currency"
                    frmMon.Opciones = "Dollars| Local Currency"
                    frmMon.ShowDialog(frmSPrincipal)
                    If frmMon.DialogResult = DialogResult.OK Then
                        Select Case frmMon.Seleccion
                            Case 0
                                intMoneda = INT_CERO 'Dolares
                                empresa = "Hilos"
                                empresa2 = "AmtexPM"
                                empresa3 = "PrideYarn"
                                empresa4 = "Dominican"
                                PromedioTC = SqlPromedioTC(FechaIni, FechaFic, empresa)
                                PromedioTC2 = SqlPromedioTC(FechaIni, FechaFic, empresa2)
                                PromedioTC3 = SqlPromedioTC(FechaIni, FechaFic, empresa3)
                                PromedioTC4 = SqlPromedioTC(FechaIni, FechaFic, empresa4)

                                PromedioTCTitulo = SqlTCDia(FechaIni, FechaFic, empresa)
                                PromedioTC2Titulo = SqlTCDia(FechaIni, FechaFic, empresa2)
                                PromedioTC3Titulo = SqlTCDia(FechaIni, FechaFic, empresa3)
                                PromedioTC4Titulo = SqlTCDia(FechaIni, FechaFic, empresa4)
                                strMon = cFunciones.TraerMoneda(cFunciones.MonedaDefault(1))
                            Case 1
                                intMoneda = INT_UNO  ' Moneda Local
                                PromedioTC = INT_UNO
                                strMon = cFunciones.TraerMoneda(cFunciones.MonedaDefault(0))
                        End Select
                    Else
                        Exit Sub
                    End If
                End If

                If intMoneda = 0 Then
                    empresa = "Hilos"
                    empresa2 = "AmtexPM"
                    empresa3 = "PrideYarn"
                    empresa4 = "Dominican"
                    dblTC_ = cFunciones.TasaSegunFechaC(FechaFic.ToString(FORMATO_MYSQL), empresa)
                    dblTC_2 = cFunciones.TasaSegunFechaC(FechaFic.ToString(FORMATO_MYSQL), empresa2)
                    dblTC_3 = cFunciones.TasaSegunFechaC(FechaFic.ToString(FORMATO_MYSQL), empresa3)
                    dblTC_4 = cFunciones.TasaSegunFechaC(FechaFic.ToString(FORMATO_MYSQL), empresa4) 'SQLTC_Corte(frm.FechaFin)

                Else
                    dblTC_ = INT_UNO
                End If

                strTemp = cFunciones.ArchivoTemporal
                f = FreeFile()
                FileOpen(f, strTemp, OpenMode.Output)
                strHtml &= "<html>"
                strHtml &= "<head>"
                strHtml &= "<title>" & "" & "</title>"
                strHtml &= "<style type='text/css'>"
                strHtml &= " table {empty-cells: show; border-collapse:collapse}"

                strHtml &= " .titulo {text-align: left; border: none; font-weight: bold;font-size: 12pt}"
                strHtml &= " .encabezado {text-align: left; border: none;  font-weight: bold;font-size: 12pt}"
                strHtml &= " .izquierda {text-align:left}"
                strHtml &= " .centro {text-align:left;font-family: Calibri,  Arial;font-size: 12pt}"
                strHtml &= " .derecha {text-align: right;font-family: Calibri, Arial;font-size: 12pt}"

                strHtml &= "</style>"
                strHtml &= "</head>"
                strHtml &= "<body>"

                strHtml &= "<table>"
                strHtml &= "<tr>"
                strHtml &= "<td><strong><h3>YARN DIVISION</h3></strong></td>"
                strHtml &= "  </tr>"

                strHtml &= "<tr>"
                strHtml &= "<td class='titulo'>Balance Sheet</td>"
                strHtml &= "<td class='titulo' style = 'width: 5cm'> <br></td>"
                strHtml &= "<td class='titulo'>" & Now() & " </td>"
                strHtml &= "  </tr>"

                strHtml &= "<tr>"
                strHtml &= "<td class='titulo'>As of " & cFunciones.MesIngles(FechaFic.Month) & " " & FechaFic.Day & ", " & FechaFic.Year & " </td>"
                strHtml &= "<td class='titulo'> <br></td>"
                strHtml &= "<td class='titulo'> <br></td>"
                strHtml &= "<td class='titulo'> <br></td>"
                strHtml &= "<td class='titulo'> <br></td>"
                strHtml &= "<td class='titulo'> <br></td>"
                strHtml &= "<td class='titulo'> <br></td>"
                Select Case frmMon.Seleccion
                    Case 0
                        strHtml &= "<td class='titulo' style = 'width: 5cm'>Amounts in US$</td>"
                    Case 1
                        strHtml &= "<td class='titulo' style = 'width: 5cm'>Montos en Moneda Local</td>"
                End Select
                strHtml &= "  </tr>"


                'strHtml &= "<tr>"
                'strHtml &= "<td class='centro'>(Expresados en " & REA2.GetString("moneda") & ") </td>"
                'strHtml &= "  </tr>"

                strHtml &= "</table>"

                strHtml &= "<hr>"

                strsql = STR_VACIO

                strHtml &= "<table>"
                strHtml &= "<tr>"
                strHtml &= "<td class='titulo'>ER Average </td>"
                strHtml &= "<td class='titulo' style='text-align: center'> " & PromedioTCTitulo & "</td>"
                strHtml &= "<td class='titulo' style='text-align: center'>" & PromedioTC3Titulo & "</td>"
                strHtml &= "<td class='titulo' style='text-align: center'>" & PromedioTC2Titulo & "</td>"
                strHtml &= "<td class='titulo' style='text-align: center'>" & PromedioTC4Titulo & " <br></td>"
                strHtml &= "<td class='titulo'> </td>"
                strHtml &= "  </tr>"
                strHtml &= "<tr>"
                strHtml &= "<td></td>"
                strHtml &= "<td class='encabezado' style=' vertical-align: middle; background-color: #000000; color: #ffffff; border: 1px solid #ffffff; text-align: center'>GUATEMALA</td>"
                strHtml &= "<td class='encabezado' style=' vertical-align: middle; background-color: #000000; color: #ffffff; border: 1px solid #ffffff; text-align: center'> HONDURAS</td>"
                strHtml &= "<td class='encabezado' style=' vertical-align: middle; background-color: #000000; color: #ffffff; border: 1px solid #ffffff; text-align: center; width: 4cm'> EL SALVADOR</td>"
                strHtml &= "<td class='encabezado' style=' vertical-align: middle; background-color: #000000; color: #ffffff; border: 1px solid #ffffff; text-align: center'> DOMINICANA</td>"
                strHtml &= "<td class='encabezado' style=' vertical-align: middle; background-color: #000000; color: #ffffff; border: 1px solid #ffffff; text-align: center; width: 3.5cm'> TOTAL</td>"
                strHtml &= "<td class='encabezado' style=' vertical-align: middle; background-color: #000000; color: #ffffff; border: 1px solid #ffffff; text-align: center'> TRADING ELIMINATION</td>"
                strHtml &= "<td class='encabezado' style=' vertical-align: middle; background-color: #000000; color: #ffffff; border: 1px solid #ffffff; text-align: center; width: 3.5cm'> TRADING</td>"
                strHtml &= "</tr>"
                strsql = SqlBalanceReport(frmO.Seleccion, dblTC_)
                MyCnn.CONECTAR = strConexion
                COM = New MySqlCommand(strsql, CON)
                REA = COM.ExecuteReader
                If REA.HasRows Then
                    Select Case frmO.Seleccion
                        Case 0
                            Do While REA.Read
                                Dim emp = REA.GetInt32("CEmpresa")
                                If REA.GetDouble("Cuenta1") >= 21 Then
                                    dblSaldoVenta = Math.Round(REA.GetDouble("SaldoGt"), 2) * (-1)
                                    dblSaldoVenta2 = Math.Round(REA.GetDouble("SaldoHn"), 2) * (-1)
                                    dblSaldoVenta3 = Math.Round(REA.GetDouble("SaldoSv"), 2) * (-1)
                                    dblSaldoVenta4 = Math.Round(REA.GetDouble("SaldoDr"), 2) * (-1)
                                    dblSaldoVenta5 = Math.Round(REA.GetDouble("trading"), 2) * (-1)
                                Else
                                    dblSaldoVenta = Math.Round(REA.GetDouble("SaldoGt"), 2)
                                    dblSaldoVenta2 = Math.Round(REA.GetDouble("SaldoHn"), 2)
                                    dblSaldoVenta3 = Math.Round(REA.GetDouble("SaldoSv"), 2)
                                    dblSaldoVenta4 = Math.Round(REA.GetDouble("SaldoDr"), 2)
                                    dblSaldoVenta5 = Math.Round(REA.GetDouble("trading"), 2)
                                End If
                                If logPrimeraLinea = True Then
                                    logPrimeraLinea = False
                                    strNivel0 = REA.GetString("Nivel0")
                                    strNivel1 = REA.GetString("Nivel1")
                                    strNivel2 = REA.GetString("Nivel2")
                                    strNivel3 = REA.GetString("Nivel3")
                                    'strNivel4 = REA.GetString("Nivel4")

                                    dblTotalNivel0 = dblSaldoVenta
                                    dblTotalNivel02 = dblSaldoVenta2
                                    dblTotalNivel03 = dblSaldoVenta3
                                    dblTotalNivel04 = dblSaldoVenta4
                                    dblTotalNivel05 = dblSaldoVenta5
                                    dblTotalNivel1 = dblSaldoVenta
                                    dblTotalNivel12 = dblSaldoVenta2
                                    dblTotalNivel13 = dblSaldoVenta3
                                    dblTotalNivel14 = dblSaldoVenta4
                                    dblTotalNivel15 = dblSaldoVenta5
                                    dblTotalNivel2 = dblSaldoVenta
                                    dblTotalNivel22 = dblSaldoVenta2
                                    dblTotalNivel23 = dblSaldoVenta3
                                    dblTotalNivel24 = dblSaldoVenta4
                                    dblTotalNivel25 = dblSaldoVenta5
                                    dblTotalNivel3 = dblSaldoVenta
                                    dblTotalNivel32 = dblSaldoVenta2
                                    dblTotalNivel33 = dblSaldoVenta3
                                    dblTotalNivel34 = dblSaldoVenta4
                                    dblTotalNivel35 = dblSaldoVenta5
                                    'dblTotalNivel4 = REA.GetDouble("saldo")

                                    strHtml &= PrimeraLineaReporte(emp, 0, REA.GetString("Nivel0"), REA.GetString("Nivel1"), REA.GetString("Nivel2"), REA.GetString("Nivel3"), dblSaldoVenta, dblSaldoVenta2, dblSaldoVenta3, dblSaldoVenta4, dblSaldoVenta5, True)
                                Else
                                    If strNivel0 = REA.GetString("Nivel0") Then
                                        strHtml &= LineaReport(0, REA.GetString("Nivel0"), dblSaldoVenta, dblSaldoVenta2, dblSaldoVenta3, dblSaldoVenta4, dblSaldoVenta5)
                                    Else
                                        intConteo = intConteo + 1
                                        If intConteo = 2 Then
                                            str2Niveles = strNivel0
                                            dbl2Totales = dblTotalNivel0
                                            dbl2Totales2 = dblTotalNivel02
                                            dbl2Totales3 = dblTotalNivel03
                                            dbl2Totales4 = dblTotalNivel04
                                            dbl2Totales5 = dblTotalNivel05
                                        End If
                                        If REA.GetString("Cuenta2") = "3101" Then
                                            conta1 = "contahilos"
                                            conta2 = "contapm"
                                            conta3 = "contapy"
                                            conta4 = "contadominican"
                                            empresa1 = "12"
                                            empresa2 = "16"
                                            empresa3 = "11"
                                            empresa4 = "14"
                                            Dim dblResultadoEjercicio As Double = ResultadoEjercicioReport(FechaIni, FechaFic, PromedioTC, conta1, empresa1)
                                            Dim dblResultadoEjercicio2 As Double = ResultadoEjercicioReport(FechaIni, FechaFic, PromedioTC2, conta2, empresa2)
                                            Dim dblResultadoEjercicio3 As Double = ResultadoEjercicioReport(FechaIni, FechaFic, PromedioTC3, conta3, empresa3)
                                            Dim dblResultadoEjercicio4 As Double = ResultadoEjercicioReport(FechaIni, FechaFic, PromedioTC4, conta4, empresa4)
                                            Dim dblResultadoEjercicio5 As Double = INT_CERO
                                            strHtml &= SubtotalReport(0, strNivel0, dblTotalNivel0, dblTotalNivel02, dblTotalNivel03, dblTotalNivel04, dblTotalNivel05)
                                            strHtml &= PrimeraLineaReporte(emp, 0, REA.GetString("Nivel0"), REA.GetString("Nivel1"), REA.GetString("Nivel2"), REA.GetString("Nivel3"), dblSaldoVenta + (dblResultadoEjercicio * -1), dblSaldoVenta2 + (dblResultadoEjercicio2 * -1), dblSaldoVenta3 + (dblResultadoEjercicio3 * -1), dblSaldoVenta4 + (dblResultadoEjercicio4 * -1), dblSaldoVenta5 + (dblResultadoEjercicio5 * -1), True)
                                            'strHtml &= LineaReport(0, REA.GetString("Nivel0"), (REA.GetDouble("saldo") + dblResultadoEjercicio))
                                            strNivel0 = REA.GetString("Nivel0")
                                            dblTotalNivel0 = dblSaldoVenta + (dblResultadoEjercicio * -1)
                                            dblTotalNivel02 = dblSaldoVenta2 + (dblResultadoEjercicio2 * -1)
                                            dblTotalNivel03 = dblSaldoVenta3 + (dblResultadoEjercicio3 * -1)
                                            dblTotalNivel04 = dblSaldoVenta4 + (dblResultadoEjercicio4 * -1)
                                            dblTotalNivel05 = dblSaldoVenta5 + (dblResultadoEjercicio5 * -1)

                                        Else
                                            strHtml &= SubtotalReport(0, strNivel0, dblTotalNivel0, dblTotalNivel02, dblTotalNivel03, dblTotalNivel04, dblTotalNivel05)
                                            strHtml &= PrimeraLineaReporte(emp, 0, REA.GetString("Nivel0"), REA.GetString("Nivel1"), REA.GetString("Nivel2"), REA.GetString("Nivel3"), dblSaldoVenta, dblSaldoVenta, dblSaldoVenta2, dblSaldoVenta3, dblSaldoVenta4, True)
                                            'strHtml &= LineaReport(0, REA.GetString("Nivel0"), REA.GetDouble("saldo"))
                                            strNivel0 = REA.GetString("Nivel0")
                                            dblTotalNivel0 = dblSaldoVenta
                                            dblTotalNivel02 = dblSaldoVenta2
                                            dblTotalNivel03 = dblSaldoVenta3
                                            dblTotalNivel04 = dblSaldoVenta4
                                            dblTotalNivel05 = dblSaldoVenta5
                                        End If

                                    End If

                                End If

                            Loop
                            strHtml &= SubtotalReport(0, strNivel0, dblTotalNivel0, dblTotalNivel02, dblTotalNivel03, dblTotalNivel04, dblTotalNivel05)
                            strHtml &= "<tr>"
                            strHtml &= "<td class='titulo'> TOTAL " & str2Niveles & " & " & strNivel0 & "</td>"
                            strHtml &= "<td class='titulo'>" & (dbl2Totales + dblTotalNivel0).ToString(FORMATO_MONEDA) & "</td>"
                            strHtml &= "<td class='titulo'>" & (dbl2Totales2 + dblTotalNivel02).ToString(FORMATO_MONEDA) & "</td>"
                            strHtml &= "<td class='titulo'>" & (dbl2Totales3 + dblTotalNivel03).ToString(FORMATO_MONEDA) & "</td>"
                            strHtml &= "<td class='titulo'>" & (dbl2Totales4 + dblTotalNivel04).ToString(FORMATO_MONEDA) & "</td>"

                            Dim sumaTotal As Double = Math.Round(((dbl2Totales + dblTotalNivel0) + (dbl2Totales2 + dblTotalNivel02) + (dbl2Totales3 + dblTotalNivel03) + (dbl2Totales4 + dblTotalNivel04)), 2)
                            strHtml &= "<td class='titulo'>" & sumaTotal.ToString(FORMATO_MONEDA) & "</td>"
                            strHtml &= "<td class='titulo'>" & (dbl2Totales5 + dblTotalNivel05).ToString(FORMATO_MONEDA) & "</td>"
                            strHtml &= "<td class='titulo'>" & (sumaTotal - dbl2Totales5).ToString(FORMATO_MONEDA) & "</td>"
                            strHtml &= "</tr>"
                            strHtml &= "</table>"
                            strHtml &= "<br/>"
                        Case 1

                            Do While REA.Read
                                Dim emp As Integer = REA.GetInt32("CEmpresa")
                                If REA.GetDouble("Cuenta1") >= 21 Then
                                    dblSaldoVenta = Math.Round(REA.GetDouble("SaldoGt"), 2) * (-1)
                                    dblSaldoVenta2 = Math.Round(REA.GetDouble("SaldoHn"), 2) * (-1)
                                    dblSaldoVenta3 = Math.Round(REA.GetDouble("SaldoSv"), 2) * (-1)
                                    dblSaldoVenta4 = Math.Round(REA.GetDouble("SaldoDr"), 2) * (-1)
                                    dblSaldoVenta5 = Math.Round(REA.GetDouble("trading"), 2) * (-1)
                                Else
                                    dblSaldoVenta = Math.Round(REA.GetDouble("SaldoGt"), 2)
                                    dblSaldoVenta2 = Math.Round(REA.GetDouble("SaldoHn"), 2)
                                    dblSaldoVenta3 = Math.Round(REA.GetDouble("SaldoSv"), 2)
                                    dblSaldoVenta4 = Math.Round(REA.GetDouble("SaldoDr"), 2)
                                    dblSaldoVenta5 = Math.Round(REA.GetDouble("trading"), 2)
                                End If
                                If logPrimeraLinea = True Then
                                    logPrimeraLinea = False
                                    strNivel0 = REA.GetString("Nivel0")
                                    strNivel1 = REA.GetString("Nivel1")
                                    strNivel2 = REA.GetString("Nivel2")
                                    strNivel3 = REA.GetString("Nivel3")
                                    'strNivel4 = REA.GetString("Nivel4")

                                    dblTotalNivel0 = dblSaldoVenta
                                    dblTotalNivel02 = dblSaldoVenta2
                                    dblTotalNivel03 = dblSaldoVenta3
                                    dblTotalNivel04 = dblSaldoVenta4
                                    dblTotalNivel1 = dblSaldoVenta
                                    dblTotalNivel12 = dblSaldoVenta2
                                    dblTotalNivel13 = dblSaldoVenta3
                                    dblTotalNivel14 = dblSaldoVenta4
                                    dblTotalNivel2 = dblSaldoVenta
                                    dblTotalNivel22 = dblSaldoVenta2
                                    dblTotalNivel23 = dblSaldoVenta3
                                    dblTotalNivel24 = dblSaldoVenta4
                                    dblTotalNivel3 = dblSaldoVenta
                                    'dblTotalNivel4 = REA.GetDouble("saldo")

                                    strHtml &= PrimeraLineaReporte(emp, 1, REA.GetString("Nivel0"), REA.GetString("Nivel1"), REA.GetString("Nivel2"), REA.GetString("Nivel3"), dblSaldoVenta, dblSaldoVenta2, dblSaldoVenta3, dblSaldoVenta4, dblSaldoVenta5, True)
                                    strNivel0 = REA.GetString("Nivel0")
                                Else
                                    If strNivel0 = REA.GetString("Nivel0") Then
                                        strHtml &= LineaReport(1, REA.GetString("Nivel1"), dblSaldoVenta, dblSaldoVenta2, dblSaldoVenta3, dblSaldoVenta4, dblSaldoVenta5)
                                        dblTotalNivel0 = dblTotalNivel0 + dblSaldoVenta
                                        dblTotalNivel02 = dblTotalNivel02 + dblSaldoVenta2
                                        dblTotalNivel03 = dblTotalNivel03 + dblSaldoVenta3
                                        dblTotalNivel04 = dblTotalNivel04 + dblSaldoVenta4
                                        strNivel0 = REA.GetString("Nivel0")
                                    Else
                                        intConteo = intConteo + 1
                                        strHtml &= SubtotalReport(0, strNivel0, dblTotalNivel0, dblTotalNivel02, dblTotalNivel03, dblTotalNivel04, dblTotalNivel05)
                                        If intConteo = 2 Then
                                            str2Niveles = strNivel0
                                            dbl2Totales = dblTotalNivel0
                                            dbl2Totales2 = dblTotalNivel02
                                            dbl2Totales3 = dblTotalNivel03
                                            dbl2Totales4 = dblTotalNivel04
                                        End If
                                        dblTotalNivel0 = INT_CERO
                                        If REA.GetString("Cuenta2") = "3101" Then
                                            conta1 = "contahilos"
                                            conta2 = "contapm"
                                            conta3 = "contapy"
                                            conta4 = "contadominican"
                                            empresa1 = "12"
                                            empresa2 = "16"
                                            empresa3 = "11"
                                            empresa4 = "14"
                                            Dim dblResultadoEjercicio As Double = ResultadoEjercicioReport(FechaIni, FechaFic, PromedioTC, conta1, empresa1)
                                            Dim dblResultadoEjercicio2 As Double = ResultadoEjercicioReport(FechaIni, FechaFic, PromedioTC2, conta2, empresa2)
                                            Dim dblResultadoEjercicio3 As Double = ResultadoEjercicioReport(FechaIni, FechaFic, PromedioTC3, conta3, empresa3)
                                            Dim dblResultadoEjercicio4 As Double = ResultadoEjercicioReport(FechaIni, FechaFic, PromedioTC4, conta4, empresa4)
                                            Dim dblResultadoEjercicio5 As Double = INT_CERO

                                            dblTotalNivel0 = dblSaldoVenta + (dblResultadoEjercicio * -1)
                                            dblTotalNivel02 = dblSaldoVenta2 + (dblResultadoEjercicio2 * -1)
                                            dblTotalNivel03 = dblSaldoVenta3 + (dblResultadoEjercicio3 * -1)
                                            dblTotalNivel04 = dblSaldoVenta4 + (dblResultadoEjercicio4 * -1)
                                            dblTotalNivel05 = dblSaldoVenta5 + (dblResultadoEjercicio5 * -1)
                                            'dblTotalNivel0 = dblTotalNivel0 + REA.GetDouble("saldo") + dblResultadoEjercicio
                                            strHtml &= PrimeraLineaReporte(emp, 1, REA.GetString("Nivel0"), REA.GetString("Nivel1"), REA.GetString("Nivel2"), REA.GetString("Nivel3"), dblTotalNivel0, dblTotalNivel02, dblTotalNivel03, dblTotalNivel04, dblTotalNivel05, True)

                                        Else
                                            dblTotalNivel0 = dblTotalNivel0 + dblSaldoVenta
                                            dblTotalNivel02 = dblTotalNivel02 + dblSaldoVenta2
                                            dblTotalNivel03 = dblTotalNivel03 + dblSaldoVenta3
                                            dblTotalNivel04 = dblTotalNivel04 + dblSaldoVenta4
                                            dblTotalNivel05 = dblTotalNivel05 + dblSaldoVenta5
                                            strHtml &= PrimeraLineaReporte(emp, 1, REA.GetString("Nivel0"), REA.GetString("Nivel1"), REA.GetString("Nivel2"), REA.GetString("Nivel3"), dblSaldoVenta, dblSaldoVenta2, dblSaldoVenta3, dblSaldoVenta4, dblSaldoVenta5, True)
                                            ' strHtml &= Linea(1, REA.GetString("nivel1"), REA.GetDouble("saldo"))

                                        End If

                                        strNivel0 = REA.GetString("Nivel0")

                                    End If
                                End If
                            Loop
                            strHtml &= SubtotalReport(0, strNivel0, dblTotalNivel0, dblTotalNivel02, dblTotalNivel03, dblTotalNivel04, dblTotalNivel05)
                            strHtml &= "<tr>"
                            strHtml &= "<td class='titulo'> TOTAL " & str2Niveles & " & " & strNivel0 & "</td>"
                            strHtml &= "<td class='titulo'>" & (dbl2Totales + dblTotalNivel0).ToString(FORMATO_MONEDA) & "</td>"
                            strHtml &= "<td class='titulo'>" & (dbl2Totales2 + dblTotalNivel02).ToString(FORMATO_MONEDA) & "</td>"
                            strHtml &= "<td class='titulo'>" & (dbl2Totales3 + dblTotalNivel03).ToString(FORMATO_MONEDA) & "</td>"
                            strHtml &= "<td class='titulo'>" & (dbl2Totales4 + dblTotalNivel04).ToString(FORMATO_MONEDA) & "</td>"

                            Dim sumaTotal As Double = Math.Round(((dbl2Totales + dblTotalNivel0) + (dbl2Totales2 + dblTotalNivel02) + (dbl2Totales3 + dblTotalNivel03) + (dbl2Totales4 + dblTotalNivel04)), 2)
                            strHtml &= "<td class='titulo'>" & sumaTotal.ToString(FORMATO_MONEDA) & "</td>"
                            strHtml &= "<td class='titulo'>" & (dbl2Totales5 + dblTotalNivel05).ToString(FORMATO_MONEDA) & "</td>"
                            strHtml &= "</tr>"
                            strHtml &= "</table>"
                            strHtml &= "<br/>"
                        Case 2
                            Do While REA.Read
                                Dim emp As Integer = REA.GetInt32("CEmpresa")
                                If REA.GetDouble("Cuenta1") >= 21 Then
                                    dblSaldoVenta = Math.Round(REA.GetDouble("SaldoGt"), 2) * (-1)
                                    dblSaldoVenta2 = Math.Round(REA.GetDouble("saldoHn"), 2) * (-1)
                                    dblSaldoVenta3 = Math.Round(REA.GetDouble("SaldoSv"), 2) * (-1)
                                    dblSaldoVenta4 = Math.Round(REA.GetDouble("SaldoDr"), 2) * (-1)
                                    dblSaldoVenta5 = Math.Round(REA.GetDouble("trading"), 2) * (-1)
                                Else
                                    dblSaldoVenta = Math.Round(REA.GetDouble("SaldoGt"), 2)
                                    dblSaldoVenta2 = Math.Round(REA.GetDouble("saldoHn"), 2)
                                    dblSaldoVenta3 = Math.Round(REA.GetDouble("SaldoSv"), 2)
                                    dblSaldoVenta4 = Math.Round(REA.GetDouble("SaldoDr"), 2)
                                    dblSaldoVenta5 = Math.Round(REA.GetDouble("trading"), 2)
                                End If
                                If logPrimeraLinea = True Then
                                    logPrimeraLinea = False
                                    strNivel0 = REA.GetString("Nivel0")
                                    strNivel1 = REA.GetString("Nivel1")
                                    strNivel2 = REA.GetString("Nivel2")
                                    strNivel3 = REA.GetString("Nivel3")
                                    'strNivel4 = REA.GetString("Nivel4")

                                    dblTotalNivel0 = dblSaldoVenta
                                    dblTotalNivel02 = dblSaldoVenta2
                                    dblTotalNivel03 = dblSaldoVenta3
                                    dblTotalNivel04 = dblSaldoVenta4
                                    dblTotalNivel1 = dblSaldoVenta
                                    dblTotalNivel12 = dblSaldoVenta2
                                    dblTotalNivel13 = dblSaldoVenta3
                                    dblTotalNivel14 = dblSaldoVenta4
                                    dblTotalNivel2 = dblSaldoVenta
                                    dblTotalNivel22 = dblSaldoVenta2
                                    dblTotalNivel23 = dblSaldoVenta3
                                    dblTotalNivel24 = dblSaldoVenta4
                                    dblTotalNivel3 = dblSaldoVenta
                                    dblTotalNivel32 = dblSaldoVenta2
                                    dblTotalNivel33 = dblSaldoVenta3
                                    dblTotalNivel34 = dblSaldoVenta4
                                    'dblTotalNivel4 = REA.GetDouble("saldo")

                                    strHtml &= PrimeraLineaReporte(emp, 2, REA.GetString("Nivel0"), REA.GetString("Nivel1"), REA.GetString("Nivel2"), REA.GetString("Nivel3"), dblSaldoVenta, dblSaldoVenta2, dblSaldoVenta3, dblSaldoVenta4, dblSaldoVenta5, True)
                                Else

                                    If strNivel0 = REA.GetString("Nivel0") Then
                                        If strNivel1 = REA.GetString("Nivel1") Then

                                            If REA.GetString("Cuenta2") = "3101" Then
                                                conta1 = "contahilos"
                                                conta2 = "contapm"
                                                conta3 = "contapy"
                                                conta4 = "contadominican"
                                                empresa1 = "12"
                                                empresa2 = "16"
                                                empresa3 = "11"
                                                empresa4 = "14"
                                                Dim dblResultadoEjercicio As Double = ResultadoEjercicioReport(FechaIni, FechaFic, PromedioTC, conta1, empresa1)
                                                Dim dblResultadoEjercicio2 As Double = ResultadoEjercicioReport(FechaIni, FechaFic, PromedioTC2, conta2, empresa2)
                                                Dim dblResultadoEjercicio3 As Double = ResultadoEjercicioReport(FechaIni, FechaFic, PromedioTC3, conta3, empresa3)
                                                Dim dblResultadoEjercicio4 As Double = ResultadoEjercicioReport(FechaIni, FechaFic, PromedioTC4, conta4, empresa4)

                                                dblTotalNivel0 = dblTotalNivel0 + (dblResultadoEjercicio * -1)
                                                dblTotalNivel02 = dblTotalNivel02 + (dblResultadoEjercicio2 * -1)
                                                dblTotalNivel03 = dblTotalNivel03 + (dblResultadoEjercicio3 * -1)
                                                dblTotalNivel04 = dblTotalNivel04 + (dblResultadoEjercicio4 * -1)
                                                dblTotalNivel1 = dblTotalNivel1 + (dblResultadoEjercicio * -1)
                                                dblTotalNivel12 = dblTotalNivel12 + (dblResultadoEjercicio2 * -1)
                                                dblTotalNivel13 = dblTotalNivel13 + (dblResultadoEjercicio3 * -1)
                                                dblTotalNivel14 = dblTotalNivel14 + (dblResultadoEjercicio4 * -1)
                                                strHtml &= "<tr>"
                                                strHtml &= "<td class='centro'>" & EspacioHtml(10) & REA.GetString("Nivel2").ToString & "</td>"
                                                strHtml &= "<td class='derecha'>" & (dblResultadoEjercicio.ToString(FORMATO_MONEDA) * -1) & "</td>"
                                                strHtml &= "<td class='derecha'>" & (dblResultadoEjercicio2.ToString(FORMATO_MONEDA) * -1) & "</td>"
                                                strHtml &= "<td class='derecha'>" & (dblResultadoEjercicio3.ToString(FORMATO_MONEDA) * -1) & "</td>"
                                                strHtml &= "<td class='derecha'>" & (dblResultadoEjercicio4.ToString(FORMATO_MONEDA) * -1) & "</td>"
                                                strHtml &= "</tr>"
                                            Else
                                                dblTotalNivel0 = dblTotalNivel0 + dblSaldoVenta
                                                dblTotalNivel02 = dblTotalNivel02 + dblSaldoVenta2
                                                dblTotalNivel03 = dblTotalNivel03 + dblSaldoVenta3
                                                dblTotalNivel04 = dblTotalNivel04 + dblSaldoVenta4
                                                dblTotalNivel1 = dblTotalNivel1 + dblSaldoVenta
                                                dblTotalNivel12 = dblTotalNivel12 + dblSaldoVenta
                                                dblTotalNivel13 = dblTotalNivel13 + dblSaldoVenta
                                                dblTotalNivel14 = dblTotalNivel14 + dblSaldoVenta
                                                strHtml &= LineaReport(2, REA.GetString("Nivel2"), dblSaldoVenta, dblSaldoVenta2, dblSaldoVenta3, dblSaldoVenta4, dblSaldoVenta5)
                                            End If


                                        Else
                                            strHtml &= SubtotalReport(1, strNivel1, dblTotalNivel1, dblTotalNivel02, dblTotalNivel03, dblTotalNivel04, dblTotalNivel05)
                                            strHtml &= PrimeraLineaReporte(emp, 2, REA.GetString("Nivel0"), REA.GetString("Nivel1"), REA.GetString("Nivel2"), REA.GetString("Nivel3"), dblSaldoVenta, dblSaldoVenta2, dblSaldoVenta3, dblSaldoVenta4, dblSaldoVenta5, False)
                                            dblTotalNivel0 = dblTotalNivel0 + dblSaldoVenta
                                            dblTotalNivel02 = dblTotalNivel02 + dblSaldoVenta2
                                            dblTotalNivel03 = dblTotalNivel03 + dblSaldoVenta3
                                            dblTotalNivel04 = dblTotalNivel04 + dblSaldoVenta4
                                            dblTotalNivel1 = dblSaldoVenta
                                            dblTotalNivel12 = dblSaldoVenta2
                                            dblTotalNivel13 = dblSaldoVenta3
                                            dblTotalNivel14 = dblSaldoVenta4

                                        End If
                                    Else
                                        intConteo = intConteo + 1

                                        strHtml &= SubtotalReport(1, strNivel1, dblTotalNivel1, dblTotalNivel12, dblTotalNivel13, dblTotalNivel14, dblTotalNivel15)
                                        strHtml &= SubtotalReport(0, strNivel0, dblTotalNivel0, dblTotalNivel02, dblTotalNivel03, dblTotalNivel04, dblTotalNivel04)


                                        'If REA.GetString("Cuenta2") = "3101" Then


                                        '    strHtml &= PrimeraLineaReporte(3, REA.GetString("Nivel0"), REA.GetString("Nivel1"), REA.GetString("Nivel2"), REA.GetString("Nivel3"), dblResultadoEjercicio, True)
                                        '    If intConteo = 2 Then
                                        '        str2Niveles = strNivel0
                                        '        dbl2Totales = dblTotalNivel0
                                        '    End If
                                        '    dblTotalNivel0 = dblResultadoEjercicio + REA.GetDouble("saldo")
                                        '    dblTotalNivel1 = dblResultadoEjercicio

                                        'Else
                                        If REA.GetString("Cuenta2") = "3101" Then
                                            conta1 = "contahilos"
                                            conta2 = "contapm"
                                            conta3 = "contapy"
                                            conta4 = "contadominican"
                                            empresa1 = "12"
                                            empresa2 = "16"
                                            empresa3 = "11"
                                            empresa4 = "14"
                                            Dim dblResultadoEjercicio As Double = ResultadoEjercicioReport(FechaIni, FechaFic, PromedioTC, conta1, empresa1)
                                            Dim dblResultadoEjercicio2 As Double = ResultadoEjercicioReport(FechaIni, FechaFic, PromedioTC2, conta2, empresa2)
                                            Dim dblResultadoEjercicio3 As Double = ResultadoEjercicioReport(FechaIni, FechaFic, PromedioTC3, conta3, empresa3)
                                            Dim dblResultadoEjercicio4 As Double = ResultadoEjercicioReport(FechaIni, FechaFic, PromedioTC4, conta4, empresa4)
                                            dblEjercicioActual = (dblResultadoEjercicio * -1) + dblSaldoVenta
                                            dblEjercicioActual2 = (dblResultadoEjercicio2 * -1) + dblSaldoVenta2
                                            dblEjercicioActual3 = (dblResultadoEjercicio3 * -1) + dblSaldoVenta3
                                            dblEjercicioActual4 = (dblResultadoEjercicio4 * -1) + dblSaldoVenta4
                                            strHtml &= PrimeraLineaReporte(emp, 2, REA.GetString("Nivel0"), REA.GetString("Nivel1"), REA.GetString("Nivel2"), REA.GetString("Nivel3"), dblEjercicioActual, dblEjercicioActual2, dblEjercicioActual3, dblEjercicioActual4, dblEjercicioActual5, True)
                                        Else
                                            strHtml &= PrimeraLineaReporte(emp, 2, REA.GetString("Nivel0"), REA.GetString("Nivel1"), REA.GetString("Nivel2"), REA.GetString("Nivel3"), dblSaldoVenta, dblSaldoVenta2, dblSaldoVenta3, dblSaldoVenta4, dblSaldoVenta5, True)
                                        End If

                                        If intConteo = 2 Then
                                            str2Niveles = strNivel0
                                            dbl2Totales = dblTotalNivel0
                                            dbl2Totales2 = dblTotalNivel02
                                            dbl2Totales3 = dblTotalNivel03
                                            dbl2Totales4 = dblTotalNivel04
                                        End If
                                        If REA.GetString("Cuenta2") = "3101" Then
                                            dblTotalNivel0 = dblEjercicioActual
                                            dblTotalNivel02 = dblEjercicioActual2
                                            dblTotalNivel03 = dblEjercicioActual3
                                            dblTotalNivel04 = dblEjercicioActual4
                                            dblTotalNivel1 = dblEjercicioActual
                                            dblTotalNivel12 = dblEjercicioActual2
                                            dblTotalNivel13 = dblEjercicioActual3
                                            dblTotalNivel14 = dblEjercicioActual4
                                        Else
                                            dblTotalNivel0 = dblSaldoVenta
                                            dblTotalNivel02 = dblSaldoVenta2
                                            dblTotalNivel03 = dblSaldoVenta3
                                            dblTotalNivel04 = dblSaldoVenta4
                                            dblTotalNivel1 = dblSaldoVenta
                                            dblTotalNivel12 = dblSaldoVenta2
                                            dblTotalNivel13 = dblSaldoVenta3
                                            dblTotalNivel14 = dblSaldoVenta4
                                        End If

                                        'End If
                                    End If
                                End If
                                strNivel0 = REA.GetString("Nivel0")
                                strNivel1 = REA.GetString("Nivel1")
                            Loop
                            strHtml &= SubtotalReport(1, strNivel1, dblTotalNivel1, dblTotalNivel12, dblTotalNivel13, dblTotalNivel14, dblTotalNivel15)

                            strHtml &= SubtotalReport(0, strNivel0, dblTotalNivel0, dblTotalNivel02, dblTotalNivel03, dblTotalNivel04, dblTotalNivel05)
                            strHtml &= "<tr>"
                            strHtml &= "<td class='titulo'> TOTAL " & str2Niveles & " & " & strNivel0 & "</td>"
                            strHtml &= "<td class='titulo'>" & (dbl2Totales + dblTotalNivel0).ToString(FORMATO_MONEDA) & "</td>"
                            strHtml &= "<td class='titulo'>" & (dbl2Totales2 + dblTotalNivel02).ToString(FORMATO_MONEDA) & "</td>"
                            strHtml &= "<td class='titulo'>" & (dbl2Totales3 + dblTotalNivel03).ToString(FORMATO_MONEDA) & "</td>"
                            strHtml &= "<td class='titulo'>" & (dbl2Totales4 + dblTotalNivel04).ToString(FORMATO_MONEDA) & "</td>"
                            Dim sumaTotal As Double = Math.Round(((dbl2Totales + dblTotalNivel0) + (dbl2Totales2 + dblTotalNivel02) + (dbl2Totales3 + dblTotalNivel03) + (dbl2Totales4 + dblTotalNivel04)), 2)
                            strHtml &= "<td class='titulo'>" & sumaTotal.ToString(FORMATO_MONEDA) & "</td>"
                            strHtml &= "</tr>"
                            strHtml &= "</table>"
                            strHtml &= "<br/>"
                        Case 3
                            Do While REA.Read
                                Dim emp As Integer = REA.GetInt32("CEmpresa")
                                If REA.GetDouble("Cuenta1") >= 21 Then
                                    dblSaldoVenta = Math.Round(REA.GetDouble("SaldoGt"), 2) * (-1)
                                    dblSaldoVenta2 = Math.Round(REA.GetDouble("SaldoHn"), 2) * (-1)
                                    dblSaldoVenta3 = Math.Round(REA.GetDouble("SaldoSv"), 2) * (-1)
                                    dblSaldoVenta4 = Math.Round(REA.GetDouble("SaldoDr"), 2) * (-1)
                                    dblSaldoVenta5 = Math.Round(REA.GetDouble("trading"), 2) * (-1)
                                Else
                                    dblSaldoVenta = Math.Round(REA.GetDouble("SaldoGt"), 2)
                                    dblSaldoVenta2 = Math.Round(REA.GetDouble("SaldoHn"), 2)
                                    dblSaldoVenta3 = Math.Round(REA.GetDouble("SaldoSv"), 2)
                                    dblSaldoVenta4 = Math.Round(REA.GetDouble("SaldoDr"), 2)
                                    dblSaldoVenta5 = Math.Round(REA.GetDouble("trading"), 2)
                                End If
                                If logPrimeraLinea = True Then
                                    logPrimeraLinea = False
                                    strNivel0 = REA.GetString("Nivel0")
                                    strNivel1 = REA.GetString("Nivel1")
                                    strNivel2 = REA.GetString("Nivel2")
                                    strNivel3 = REA.GetString("Nivel3")
                                    strNivel4 = REA.GetString("Nivel4")

                                    dblTotalNivel0 = dblSaldoVenta
                                    dblTotalNivel02 = dblSaldoVenta2
                                    dblTotalNivel03 = dblSaldoVenta3
                                    dblTotalNivel04 = dblSaldoVenta4
                                    dblTotalNivel1 = dblSaldoVenta
                                    dblTotalNivel12 = dblSaldoVenta2
                                    dblTotalNivel13 = dblSaldoVenta3
                                    dblTotalNivel14 = dblSaldoVenta4
                                    dblTotalNivel2 = dblSaldoVenta
                                    dblTotalNivel22 = dblSaldoVenta2
                                    dblTotalNivel23 = dblSaldoVenta3
                                    dblTotalNivel24 = dblSaldoVenta4
                                    dblTotalNivel3 = dblSaldoVenta
                                    dblTotalNivel4 = dblSaldoVenta

                                    strHtml &= PrimeraLineaReporte(emp, 3, REA.GetString("Nivel0"), REA.GetString("Nivel1"), REA.GetString("Nivel2"), REA.GetString("Nivel3"), dblSaldoVenta, dblSaldoVenta2, dblSaldoVenta3, dblSaldoVenta4, dblSaldoVenta5, True)
                                Else

                                    If strNivel0 = REA.GetString("Nivel0") Then
                                        If strNivel1 = REA.GetString("Nivel1") Then
                                            If strNivel2 = REA.GetString("Nivel2") Then

                                                If REA.GetString("Cuenta3") = "310101" Then
                                                    conta1 = "contahilos"
                                                    conta2 = "contapm"
                                                    conta3 = "contapy"
                                                    conta4 = "contadominican"
                                                    empresa1 = "12"
                                                    empresa2 = "16"
                                                    empresa3 = "11"
                                                    empresa4 = "14"
                                                    Dim dblResultadoEjercicio1 As Double = ResultadoEjercicioReport(FechaIni, FechaFic, PromedioTC, conta1, empresa1)
                                                    Dim dblResultadoEjercicio22 As Double = ResultadoEjercicioReport(FechaIni, FechaFic, PromedioTC2, conta2, empresa2)
                                                    Dim dblResultadoEjercicio33 As Double = ResultadoEjercicioReport(FechaIni, FechaFic, PromedioTC3, conta3, empresa3)
                                                    Dim dblResultadoEjercicio44 As Double = ResultadoEjercicioReport(FechaIni, FechaFic, PromedioTC4, conta4, empresa4)

                                                    dblTotalNivel0 = dblTotalNivel0 + (dblResultadoEjercicio1 * -1)
                                                    dblTotalNivel02 = dblTotalNivel02 + (dblResultadoEjercicio22 * -1)
                                                    dblTotalNivel03 = dblTotalNivel03 + (dblResultadoEjercicio33 * -1)
                                                    dblTotalNivel04 = dblTotalNivel04 + (dblResultadoEjercicio44 * -1)
                                                    dblTotalNivel1 = dblTotalNivel1 + (dblResultadoEjercicio1 * -1)
                                                    dblTotalNivel12 = dblTotalNivel12 + (dblResultadoEjercicio22 * -1)
                                                    dblTotalNivel13 = dblTotalNivel13 + (dblResultadoEjercicio33 * -1)
                                                    dblTotalNivel14 = dblTotalNivel14 + (dblResultadoEjercicio44 * -1)
                                                    dblTotalNivel2 = dblTotalNivel2 + (dblResultadoEjercicio1 * -1)
                                                    dblTotalNivel22 = dblTotalNivel22 + (dblResultadoEjercicio22 * -1)
                                                    dblTotalNivel23 = dblTotalNivel23 + (dblResultadoEjercicio33 * -1)
                                                    dblTotalNivel24 = dblTotalNivel24 + (dblResultadoEjercicio44 * -1)
                                                    strHtml &= "<tr>"
                                                    strHtml &= "<td class='centro'>" & EspacioHtml(10) & REA.GetString("Nivel3").ToString & "</td>"
                                                    strHtml &= "<td class='derecha'>" & (dblResultadoEjercicio1.ToString(FORMATO_MONEDA) * -1) & "</td>"
                                                    strHtml &= "<td class='derecha'>" & (dblResultadoEjercicio22.ToString(FORMATO_MONEDA) * -1) & "</td>"
                                                    strHtml &= "<td class='derecha'>" & (dblResultadoEjercicio33.ToString(FORMATO_MONEDA) * -1) & "</td>"
                                                    strHtml &= "<td class='derecha'>" & (dblResultadoEjercicio44.ToString(FORMATO_MONEDA) * -1) & "</td>"
                                                    strHtml &= "</tr>"
                                                Else
                                                    dblTotalNivel0 = dblTotalNivel0 + dblSaldoVenta
                                                    dblTotalNivel02 = dblTotalNivel02 + dblSaldoVenta2
                                                    dblTotalNivel03 = dblTotalNivel03 + dblSaldoVenta3
                                                    dblTotalNivel04 = dblTotalNivel04 + dblSaldoVenta4
                                                    dblTotalNivel1 = dblTotalNivel1 + dblSaldoVenta
                                                    dblTotalNivel12 = dblTotalNivel12 + dblSaldoVenta2
                                                    dblTotalNivel13 = dblTotalNivel13 + dblSaldoVenta3
                                                    dblTotalNivel14 = dblTotalNivel14 + dblSaldoVenta4
                                                    dblTotalNivel2 = dblTotalNivel2 + dblSaldoVenta
                                                    dblTotalNivel22 = dblTotalNivel22 + dblSaldoVenta2
                                                    dblTotalNivel23 = dblTotalNivel23 + dblSaldoVenta3
                                                    dblTotalNivel24 = dblTotalNivel24 + dblSaldoVenta4
                                                    strHtml &= LineaReport(3, REA.GetString("Nivel3"), dblSaldoVenta, dblSaldoVenta2, dblSaldoVenta3, dblSaldoVenta4, dblSaldoVenta5)
                                                End If
                                            Else

                                                strHtml &= SubtotalReport(2, strNivel2, dblTotalNivel2, dblTotalNivel22, dblTotalNivel23, dblTotalNivel24, dblTotalNivel25)
                                                strHtml &= PrimeraLineaReporte(emp, 3, REA.GetString("Nivel0"), REA.GetString("Nivel1"), REA.GetString("Nivel2"), REA.GetString("Nivel3"), dblSaldoVenta, dblSaldoVenta2, dblSaldoVenta3, dblSaldoVenta4, dblSaldoVenta5, False)
                                                dblTotalNivel0 = dblTotalNivel0 + dblSaldoVenta
                                                dblTotalNivel02 = dblTotalNivel02 + dblSaldoVenta2
                                                dblTotalNivel03 = dblTotalNivel03 + dblSaldoVenta3
                                                dblTotalNivel04 = dblTotalNivel04 + dblSaldoVenta4
                                                dblTotalNivel1 = dblTotalNivel1 + dblSaldoVenta
                                                dblTotalNivel12 = dblTotalNivel12 + dblSaldoVenta2
                                                dblTotalNivel13 = dblTotalNivel13 + dblSaldoVenta3
                                                dblTotalNivel14 = dblTotalNivel14 + dblSaldoVenta4
                                                dblTotalNivel2 = dblSaldoVenta
                                                dblTotalNivel22 = dblSaldoVenta2
                                                dblTotalNivel23 = dblSaldoVenta3
                                                dblTotalNivel24 = dblSaldoVenta4
                                                dblTotalNivel25 = dblSaldoVenta5

                                            End If

                                        Else
                                            strHtml &= SubtotalReport(2, strNivel2, dblTotalNivel2, dblTotalNivel22, dblTotalNivel23, dblTotalNivel24, dblTotalNivel25)
                                            strHtml &= SubtotalReport(1, strNivel1, dblTotalNivel1, dblTotalNivel12, dblTotalNivel13, dblTotalNivel14, dblTotalNivel15)
                                            strHtml &= PrimeraLineaReporte(emp, 3, REA.GetString("Nivel0"), REA.GetString("Nivel1"), REA.GetString("Nivel2"), REA.GetString("Nivel3"), dblSaldoVenta, dblSaldoVenta2, dblSaldoVenta3, dblSaldoVenta4, True, 1)
                                            dblTotalNivel0 = dblTotalNivel0 + dblSaldoVenta
                                            dblTotalNivel02 = dblTotalNivel02 + dblSaldoVenta2
                                            dblTotalNivel03 = dblTotalNivel03 + dblSaldoVenta3
                                            dblTotalNivel04 = dblTotalNivel04 + dblSaldoVenta4
                                            dblTotalNivel1 = dblSaldoVenta ' dblTotalNivel1 + REA.GetDouble("saldo")
                                            dblTotalNivel12 = dblSaldoVenta2
                                            dblTotalNivel13 = dblSaldoVenta3
                                            dblTotalNivel14 = dblSaldoVenta4
                                            dblTotalNivel2 = dblSaldoVenta
                                            dblTotalNivel22 = dblSaldoVenta2
                                            dblTotalNivel23 = dblSaldoVenta3
                                            dblTotalNivel24 = dblSaldoVenta4
                                        End If
                                    Else
                                        intConteo = intConteo + 1

                                        strHtml &= SubtotalReport(2, strNivel2, dblTotalNivel2, dblTotalNivel22, dblTotalNivel23, dblTotalNivel24, dblTotalNivel25)
                                        strHtml &= SubtotalReport(1, strNivel1, dblTotalNivel1, dblTotalNivel12, dblTotalNivel13, dblTotalNivel14, dblTotalNivel15)
                                        strHtml &= SubtotalReport(0, strNivel0, dblTotalNivel0, dblTotalNivel02, dblTotalNivel03, dblTotalNivel04, dblTotalNivel05)

                                        'If REA.GetString("Cuenta3") = "310101" Then
                                        '    Dim dblResultadoEjercicio As Double = ResultadoEjercicioReport(frm.FechaInicio, frm.FechaFin)

                                        '    strHtml &= PrimeraLineaReporte(3, REA.GetString("Nivel0"), REA.GetString("Nivel1"), REA.GetString("Nivel2"), REA.GetString("Nivel3"), dblResultadoEjercicio, True)
                                        '    If intConteo = 2 Then
                                        '        str2Niveles = strNivel0
                                        '        dbl2Totales = dblTotalNivel0
                                        '    End If
                                        '    dblTotalNivel0 = dblResultadoEjercicio
                                        '    dblTotalNivel1 = dblResultadoEjercicio
                                        '    dblTotalNivel2 = dblResultadoEjercicio
                                        'Else
                                        strHtml &= PrimeraLineaReporte(emp, 3, REA.GetString("Nivel0"), REA.GetString("Nivel1"), REA.GetString("Nivel2"), REA.GetString("Nivel3"), dblSaldoVenta, dblSaldoVenta2, dblSaldoVenta3, dblSaldoVenta4, dblSaldoVenta5, True)
                                        If intConteo = 2 Then
                                            str2Niveles = strNivel0
                                            dbl2Totales = dblTotalNivel0
                                            dbl2Totales2 = dblTotalNivel02
                                            dbl2Totales3 = dblTotalNivel03
                                            dbl2Totales4 = dblTotalNivel04
                                            dbl2Totales5 = dblTotalNivel05
                                        End If
                                        dblTotalNivel0 = dblSaldoVenta
                                        dblTotalNivel02 = dblSaldoVenta2
                                        dblTotalNivel03 = dblSaldoVenta3
                                        dblTotalNivel04 = dblSaldoVenta4
                                        dblTotalNivel05 = dblSaldoVenta5
                                        dblTotalNivel1 = dblSaldoVenta
                                        dblTotalNivel12 = dblSaldoVenta2
                                        dblTotalNivel13 = dblSaldoVenta3
                                        dblTotalNivel14 = dblSaldoVenta4
                                        dblTotalNivel15 = dblSaldoVenta5
                                        dblTotalNivel2 = dblSaldoVenta
                                        dblTotalNivel22 = dblSaldoVenta2
                                        dblTotalNivel23 = dblSaldoVenta3
                                        dblTotalNivel24 = dblSaldoVenta4
                                        dblTotalNivel25 = dblSaldoVenta5
                                        'End If
                                    End If
                                End If
                                strNivel0 = REA.GetString("Nivel0")
                                strNivel1 = REA.GetString("Nivel1")
                                strNivel2 = REA.GetString("Nivel2")
                            Loop

                            conta1 = "contahilos"
                            conta2 = "contapm"
                            conta3 = "contapy"
                            conta4 = "contadominican"
                            empresa1 = "12"
                            empresa2 = "16"
                            empresa3 = "11"
                            empresa4 = "14"

                            Dim dblResultadoEjercicio As Double = ResultadoEjercicioReport(FechaIni, FechaFic, PromedioTC, conta1, empresa1)
                            Dim dblResultadoEjercicio3 As Double = ResultadoEjercicioReport(FechaIni, FechaFic, PromedioTC2, conta2, empresa2)
                            Dim dblResultadoEjercicio2 As Double = ResultadoEjercicioReport(FechaIni, FechaFic, PromedioTC3, conta3, empresa3)
                            Dim dblResultadoEjercicio4 As Double = ResultadoEjercicioReport(FechaIni, FechaFic, PromedioTC4, conta4, empresa4)
                            Dim dblResultadoEjercicio5 As Double = INT_CERO

                            dblTotalNivel0 = dblTotalNivel0 + (dblResultadoEjercicio * -1)
                            dblTotalNivel02 = dblTotalNivel02 + (dblResultadoEjercicio2 * -1)
                            dblTotalNivel03 = dblTotalNivel03 + (dblResultadoEjercicio3 * -1)
                            dblTotalNivel04 = dblTotalNivel04 + (dblResultadoEjercicio4 * -1)
                            dblTotalNivel1 = dblTotalNivel1 + (dblResultadoEjercicio * -1)
                            dblTotalNivel12 = dblTotalNivel12 + (dblResultadoEjercicio2 * -1)
                            dblTotalNivel13 = dblTotalNivel13 + (dblResultadoEjercicio3 * -1)
                            dblTotalNivel14 = dblTotalNivel14 + (dblResultadoEjercicio4 * -1)
                            dblTotalNivel2 = dblTotalNivel2 + (dblResultadoEjercicio * -1)
                            dblTotalNivel22 = dblTotalNivel22 + (dblResultadoEjercicio2 * -1)
                            dblTotalNivel23 = dblTotalNivel23 + (dblResultadoEjercicio3 * -1)
                            dblTotalNivel24 = dblTotalNivel24 + (dblResultadoEjercicio4 * -1)
                            strHtml &= "<tr>"
                            strHtml &= "<td class='centro'>" & EspacioHtml(15) & "Actual Results" & "</td>"
                            strHtml &= "<td class='derecha'>" & (dblResultadoEjercicio.ToString(FORMATO_MONEDA) * -1) & "</td>"
                            strHtml &= "<td class='derecha'>" & (dblResultadoEjercicio2.ToString(FORMATO_MONEDA) * -1) & "</td>"
                            strHtml &= "<td class='derecha'>" & (dblResultadoEjercicio3.ToString(FORMATO_MONEDA) * -1) & "</td>"
                            strHtml &= "<td class='derecha'>" & (dblResultadoEjercicio4.ToString(FORMATO_MONEDA) * -1) & "</td>"

                            Dim totalResult As Double = Math.Round((dblResultadoEjercicio + dblResultadoEjercicio2 + dblResultadoEjercicio3 + dblResultadoEjercicio4), 2)
                            strHtml &= "<td class='derecha' style='font-weight'>" & (totalResult * -1).ToString(FORMATO_MONEDA) & "</td>"
                            strHtml &= "<td class='derecha'>" & (dblResultadoEjercicio5 * -1).ToString(FORMATO_MONEDA) & "</td>"
                            strHtml &= "<td class='derecha' style='font-weight'>" & ((totalResult - dblResultadoEjercicio5) * -1).ToString(FORMATO_MONEDA) & "</td>"
                            strHtml &= "</tr>"

                            strHtml &= SubtotalReport(1, strNivel1, dblTotalNivel1, dblTotalNivel12, dblTotalNivel13, dblTotalNivel14, dblTotalNivel15)

                            strHtml &= SubtotalReport(0, strNivel0, dblTotalNivel0, dblTotalNivel02, dblTotalNivel03, dblTotalNivel04, dblTotalNivel05)
                            strHtml &= "<tr>"
                            strHtml &= "<td class='titulo'> TOTAL " & str2Niveles & " Y " & strNivel0 & "</td>"
                            strHtml &= "<td class='encabezado' style='text-align: right'>" & EspacioHtml(3) & (dbl2Totales + dblTotalNivel0).ToString(FORMATO_MONEDA) & "</td>"
                            strHtml &= "<td class='encabezado' style='text-align: right'>" & EspacioHtml(3) & (dbl2Totales2 + dblTotalNivel02).ToString(FORMATO_MONEDA) & "</td>"
                            strHtml &= "<td class='encabezado' style='text-align: right'>" & EspacioHtml(3) & (dbl2Totales3 + dblTotalNivel03).ToString(FORMATO_MONEDA) & "</td>"
                            strHtml &= "<td class='encabezado' style='text-align: right'>" & EspacioHtml(4) & (dbl2Totales4 + dblTotalNivel04).ToString(FORMATO_MONEDA) & "</td>"
                            Dim grandTotal As Double = (dbl2Totales + dblTotalNivel0) + (dbl2Totales2 + dblTotalNivel02) + (dbl2Totales3 + dblTotalNivel03) + (dbl2Totales4 + dblTotalNivel04)
                            strHtml &= "<td class='encabezado' style='text-align: right'>" & grandTotal.ToString(FORMATO_MONEDA) & "</td>"
                            strHtml &= "<td class='encabezado' style='text-align: right'>" & (dbl2Totales5 + dblTotalNivel05).ToString(FORMATO_MONEDA) & "</td>"
                            strHtml &= "<td class='encabezado' style='text-align: right'>" & (grandTotal - dblResultadoEjercicio5).ToString(FORMATO_MONEDA) & "</td>"
                            strHtml &= "</tr>"
                            strHtml &= "</table>"
                            strHtml &= "<br/>"


                    End Select

                    strHtml &= "</body>"
                    strHtml &= "</html>"
                    Print(f, strHtml)
                    FileClose(f)
                    crport.MostarReporte(strTemp)
                End If
            End If

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try

    End Sub
#End Region

#Region "P & L Combinado"

    Private Function SqlEResultadoReport(ByVal intOpcion As Integer, ByVal intMoneda As Integer, ByVal FechaIni As Date, ByVal FechaFic As Date) As String
        Dim strSql As String = STR_VACIO
        Dim empresa1 As String = STR_VACIO
        Dim empresa2 As String = STR_VACIO
        Dim empresa3 As String = STR_VACIO
        Dim empresa4 As String = STR_VACIO
        Try
            empresa1 = "Hilos"
            empresa2 = "AmtexPM"
            empresa3 = "PrideYarn"
            empresa4 = "Dominican"
            PromedioTC = SqlPromedioTC(FechaIni, FechaFic, empresa1)
            PromedioTC2 = SqlPromedioTC(FechaIni, FechaFic, empresa2)
            PromedioTC3 = SqlPromedioTC(FechaIni, FechaFic, empresa3)
            PromedioTC4 = SqlPromedioTC(FechaIni, FechaFic, empresa4)

            If intMoneda = 0 Then ' Dolares
                strSql = " SELECT t.*, e.conta_empresa conta FROM (SELECT CEmpresa, Cuenta0, Cuenta1, Cuenta2, Nivel0, Nivel1, Nivel2, NIvel3, Nivel4, Cuenta3, SUM(CASE WHEN CEmpresa = 1 THEN Saldo ELSE 0 END) SaldoGt, 
                        SUM(CASE WHEN CEmpresa = 2 THEN Saldo ELSE 0 END) SaldoSv, SUM(CASE WHEN CEmpresa = 3 THEN Saldo ELSE 0 END) SaldoHn, 
                            SUM(CASE WHEN CEmpresa = 4 THEN Saldo ELSE 0 END) SaldoDr, 0 trading 
                                FROM YarnDivision.CombinedLP
                                    {group}) t
                                        LEFT JOIN YarnDivision.Empresa e ON e.idEmpresa = t.CEmpresa "
            Else
                strSql = " SELECT t.*, e.conta_empresa conta FROM (SELECT CEmpresa, Cuenta0, Cuenta1, Cuenta2, Nivel0, Nivel1, Nivel2, NIvel3, Nivel4, Cuenta3, 
                                SUM(CASE WHEN CEmpresa = 1 THEN (Saldo * " & PromedioTC & ") ELSE 0 END) SaldoGt, 
                                SUM(CASE WHEN CEmpresa = 2 THEN (Saldo * " & PromedioTC2 & ") ELSE 0 END) SaldoSv, 
                                SUM(CASE WHEN CEmpresa = 3 THEN (Saldo * " & PromedioTC3 & ") ELSE 0 END) SaldoHn, 
                                SUM(CASE WHEN CEmpresa = 4 THEN (Saldo * " & PromedioTC4 & ") ELSE 0 END) SaldoDr, 
                                0 trading 
                                FROM YarnDivision.CombinedLP
                                    {group}) t
                                        LEFT JOIN YarnDivision.Empresa e ON e.idEmpresa = t.CEmpresa "

            End If

            Select Case intOpcion
                Case 0
                    strSql &= "  group by t.Cuenta0 "
                    strSql = Replace(strSql, "{group}", "GROUP BY Cuenta0")
                Case 1
                    strSql &= "  group by t.Cuenta1 "
                    strSql = Replace(strSql, "{group}", "GROUP BY Cuenta1")
                Case 2
                    strSql &= "  group by t.Cuenta2 "
                    strSql = Replace(strSql, "{group}", "GROUP BY Cuenta2")
                Case 3
                    strSql &= "  group by t.Cuenta3 "
                    strSql = Replace(strSql, "{group}", "GROUP BY Cuenta3")
                    'Case 4
                    '    strSql &= "  group by n.Cuenta4 "

            End Select

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        Return strSql
    End Function

    Private Function SqlEncabezadoEResultadoReport() As String
        Dim strSQL As String = STR_VACIO
        Try
            strSQL = "  select e.emp_razon empresa, c.cat_dato moneda , p.cat_dato nacionalidad  from Empresas e "
            strSQL &= " 	LEFT JOIN Catalogos c on c.cat_num = e.emp_moneda "
            strSQL &= "  	left join Catalogos p on p.cat_num = e.emp_pais  "
            strSQL &= " where e.emp_no=  " & Sesion.IdEmpresa

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        Return strSQL
    End Function

    Public Sub PLReport(ByVal FechaIni As Date, ByVal FechaFic As Date)
        Dim crport As New clsReportes
        Dim strsql As String = STR_VACIO
        Dim strHtml As String = STR_VACIO
        Dim frm As New frmFiltro
        Dim frmO As New frmOption
        Dim frmMon As New frmOption
        Dim logPrimeraLinea As Boolean = True
        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader
        Dim REA2 As MySqlDataReader
        Dim strTemp As String = STR_VACIO
        Dim conta As String = STR_VACIO
        Dim conta1 As String = STR_VACIO
        Dim conta2 As String = STR_VACIO
        Dim conta3 As String = STR_VACIO
        Dim conta4 As String = STR_VACIO
        Dim empresa As String = STR_VACIO
        Dim empresa1 As String = STR_VACIO
        Dim empresa2 As String = STR_VACIO
        Dim empresa3 As String = STR_VACIO
        Dim empresa4 As String = STR_VACIO

        Dim dblTC_ As Double = INT_CERO
        Dim dblTC_2 As Double = INT_CERO
        Dim dblTC_3 As Double = INT_CERO
        Dim dblTC_4 As Double = INT_CERO
        Dim PromedioTC As Double = INT_CERO
        Dim PromedioTC2 As Double = INT_CERO
        Dim PromedioTC3 As Double = INT_CERO
        Dim PromedioTC4 As Double = INT_CERO
        Dim strMon As String = STR_VACIO
        Dim dblSaldoVenta As Double = INT_CERO
        Dim dblSaldoVenta2 As Double = INT_CERO
        Dim dblSaldoVenta3 As Double = INT_CERO
        Dim dblSaldoVenta4 As Double = INT_CERO
        Dim dblSaldoVenta5 As Double = INT_CERO

        Dim dblTotalNivel0 As Double = INT_CERO
        Dim dblTotalNivel02 As Double = INT_CERO
        Dim dblTotalNivel03 As Double = INT_CERO
        Dim dblTotalNivel04 As Double = INT_CERO
        Dim dblTotalNivel05 As Double = INT_CERO
        Dim dblTotalNivel1 As Double = INT_CERO
        Dim dblTotalNivel12 As Double = INT_CERO
        Dim dblTotalNivel13 As Double = INT_CERO
        Dim dblTotalNivel14 As Double = INT_CERO
        Dim dblTotalNivel15 As Double = INT_CERO
        Dim dblTotalNivel2 As Double = INT_CERO
        Dim dblTotalNivel22 As Double = INT_CERO
        Dim dblTotalNivel23 As Double = INT_CERO
        Dim dblTotalNivel24 As Double = INT_CERO
        Dim dblTotalNivel25 As Double = INT_CERO
        Dim dblTotalNivel3 As Double = INT_CERO
        Dim dblTotalNivel32 As Double = INT_CERO
        Dim dblTotalNivel33 As Double = INT_CERO
        Dim dblTotalNivel34 As Double = INT_CERO
        Dim dblTotalNivel35 As Double = INT_CERO
        Dim dblTotalNivel4 As Double = INT_CERO
        Dim dblEjercicioActual As Double = INT_CERO
        Dim dblEjercicioActual2 As Double = INT_CERO
        Dim dblEjercicioActual3 As Double = INT_CERO
        Dim dblEjercicioActual4 As Double = INT_CERO
        Dim dblEjercicioActual5 As Double = INT_CERO
        Dim dblPerdidaPeriodo As Double = INT_CERO
        Dim dblPerdidaPeriodo2 As Double = INT_CERO
        Dim dblPerdidaPeriodo3 As Double = INT_CERO
        Dim dblPerdidaPeriodo4 As Double = INT_CERO
        Dim dblPerdidaPeriodo5 As Double = INT_CERO
        Dim intMoneda As Integer = NO_FILA

        Dim strNivel0 As String = STR_VACIO
        Dim strNivel1 As String = STR_VACIO
        Dim strNivel2 As String = STR_VACIO
        Dim strNivel3 As String = STR_VACIO
        Dim strNivel4 As String = STR_VACIO
        Dim intConteo As Integer = 0
        Dim intValidar As Integer = 0
        Dim str2Niveles As String = STR_VACIO
        Dim dbl2Totales As Double = 0
        Dim dbl2Totales2 As Double = 0
        Dim dbl2Totales3 As Double = 0
        Dim dbl2Totales4 As Double = 0
        Dim dbl2Totales5 As Double = 0
        Dim f As Byte
        Try
            frmO.Titulo = "Select a level"
            frmO.Text = "Select a level "
            frmO.Opciones = "Level 1| Level 2 |Level 3 | Level 4"
            frmO.ShowDialog(frmSPrincipal)
            If frmO.DialogResult = DialogResult.OK Then

                If Sesion.IdEmpresa = 16 Then
                    intMoneda = INT_CERO
                    strMon = cFunciones.TraerMoneda(cFunciones.MonedaDefault(0))
                    PromedioTC = SqlPromedioTC(FechaIni, FechaFic, empresa1)
                Else
                    frmMon.Titulo = "Select a Currency"
                    frmMon.Text = "Select a Currency"
                    frmMon.Opciones = "Dollars| Local Currency"
                    frmMon.ShowDialog(frmSPrincipal)
                    If frmMon.DialogResult = DialogResult.OK Then
                        Select Case frmMon.Seleccion
                            Case 0
                                intMoneda = INT_CERO 'Dolares
                                empresa1 = "Hilos"
                                empresa2 = "AmtexPM"
                                empresa3 = "PrideYarn"
                                empresa4 = "Dominican"
                                PromedioTC = SqlPromedioTC(FechaIni, FechaFic, empresa1)
                                PromedioTC2 = SqlPromedioTC(FechaIni, FechaFic, empresa2)
                                PromedioTC3 = SqlPromedioTC(FechaIni, FechaFic, empresa3)
                                PromedioTC4 = SqlPromedioTC(FechaIni, FechaFic, empresa4)
                                strMon = cFunciones.TraerMoneda(cFunciones.MonedaDefault(1))
                            Case 1
                                intMoneda = INT_UNO  ' Moneda Local
                                PromedioTC = INT_UNO
                                strMon = cFunciones.TraerMoneda(cFunciones.MonedaDefault(0))
                        End Select
                    Else
                        Exit Sub
                    End If
                End If

                strTemp = cFunciones.ArchivoTemporal
                f = FreeFile()
                FileOpen(f, strTemp, OpenMode.Output)
                strHtml &= "<html>"
                strHtml &= "<head>"
                strHtml &= "<title>" & "" & "</title>"
                strHtml &= "<style type='text/css'>"
                strHtml &= " table {empty-cells: show; border-collapse:collapse}"

                strHtml &= " .titulo {text-align: left; border: none; font-weight: bold;font-size: 12pt}"
                strHtml &= " .encabezado {text-align: left; border: none;  font-weight: bold;font-size: 12pt}"
                strHtml &= " .izquierda {text-align:left}"
                strHtml &= " .centro {text-align:left;font-family: Calibri,  Arial;font-size: 12pt}"
                strHtml &= " .derecha {text-align: right;font-family: Calibri, Arial;font-size: 12pt}"

                strHtml &= "</style>"
                strHtml &= "</head>"
                strHtml &= "<body>"

                strsql = SqlEncabezadoEResultadoReport()
                MyCnn.CONECTAR = strConexion
                COM = New MySqlCommand(strsql, CON)
                REA2 = COM.ExecuteReader
                If REA2.HasRows Then
                    Do While REA2.Read
                        strHtml &= "<table>"
                        strHtml &= "<tr>"
                        strHtml &= "<td><strong><h3>Yarn Division</h3></strong></td>"
                        strHtml &= "  </tr>"

                        strHtml &= "<tr>"
                        strHtml &= "<td class='titulo'>Combined P & L</td>"
                        strHtml &= "<td class='titulo' style = 'width: 5cm'> <br></td>"
                        strHtml &= "<td class='titulo'>" & Now() & " </td>"
                        strHtml &= "  </tr>"

                        strHtml &= "<tr>"
                        strHtml &= "<td class='titulo'>Between date " & FechaIni.ToString(FORMATO_MYSQL) & " and " & FechaFic.ToString(FORMATO_MYSQL) & "</td>"

                        strHtml &= "  </tr>"
                        strHtml &= "  <tr>"
                        Select Case frmMon.Seleccion
                            Case 0
                                strHtml &= "<td class='titulo' style = 'width: 5cm'>Amounts in US$</td>"
                            Case 1
                                strHtml &= "<td class='titulo' style = 'width: 5cm'>Montos en Moneda Local</td>"
                        End Select
                        strHtml &= "  </tr>"




                        strHtml &= "</table>"


                    Loop
                    strHtml &= "<hr>"
                End If
                strHtml &= "<table>"
                strHtml &= "<tr>"
                strHtml &= "<td class='titulo'>ER Average </td>"
                strHtml &= "<td class='titulo' style='text-align: center'> " & PromedioTC & "</td>"
                strHtml &= "<td class='titulo' style='text-align: center'>" & PromedioTC3 & "</td>"
                strHtml &= "<td class='titulo' style='text-align: center'>" & PromedioTC2 & "</td>"
                strHtml &= "<td class='titulo' style='text-align: center'>" & PromedioTC4 & " <br></td>"
                strHtml &= "<td class='titulo'> </td>"
                strHtml &= "  </tr>"
                strHtml &= "<tr>"
                strHtml &= "<td></td>"
                strHtml &= "<td class='encabezado' style=' vertical-align: middle; background-color: #000000; color: #ffffff; border: 1px solid #ffffff; text-align: center'>GUATEMALA</td>"
                strHtml &= "<td class='encabezado' style=' vertical-align: middle; background-color: #000000; color: #ffffff; border: 1px solid #ffffff; text-align: center; width: 3.5cm'> HONDURAS</td>"
                strHtml &= "<td class='encabezado' style=' vertical-align: middle; background-color: #000000; color: #ffffff; border: 1px solid #ffffff; text-align: center; width: 4cm'> EL SALVADOR</td>"
                strHtml &= "<td class='encabezado' style=' vertical-align: middle; background-color: #000000; color: #ffffff; border: 1px solid #ffffff; text-align: center'> DOMINICANA</td>"
                strHtml &= "<td class='encabezado' style=' vertical-align: middle; background-color: #000000; color: #ffffff; border: 1px solid #ffffff; text-align: center; width: 3.5cm'> TOTAL</td>"
                strHtml &= "<td class='encabezado' style=' vertical-align: middle; background-color: #000000; color: #ffffff; border: 1px solid #ffffff; text-align: center'> TRADING ELIMINATION</td>"
                strHtml &= "<td class='encabezado' style=' vertical-align: middle; background-color: #000000; color: #ffffff; border: 1px solid #ffffff; text-align: center; width: 3.5cm'> TRADING</td>"
                strHtml &= "</tr>"
                strsql = SqlEResultadoReport(frmO.Seleccion, intMoneda, FechaIni, FechaFic)
                MyCnn.CONECTAR = strConexion
                COM = New MySqlCommand(strsql, CON)
                REA = COM.ExecuteReader
                If REA.HasRows Then
                    Select Case frmO.Seleccion
                        Case 0
                            Do While REA.Read
                                Dim emp = REA.GetInt32("CEmpresa")
                                If REA.GetDouble("Cuenta1") = 41 Then
                                    dblSaldoVenta = Math.Round(REA.GetDouble("SaldoGt"), 2) * (-1)
                                    dblSaldoVenta2 = Math.Round(REA.GetDouble("SaldoHn"), 2) * (-1)
                                    dblSaldoVenta3 = Math.Round(REA.GetDouble("SaldoSv"), 2) * (-1)
                                    dblSaldoVenta4 = Math.Round(REA.GetDouble("SaldoDr"), 2) * (-1)
                                    dblSaldoVenta5 = Math.Round(REA.GetDouble("trading"), 2) * (-1)
                                Else
                                    dblSaldoVenta = Math.Round(REA.GetDouble("SaldoGt"), 2)
                                    dblSaldoVenta2 = Math.Round(REA.GetDouble("SaldoHn"), 2)
                                    dblSaldoVenta3 = Math.Round(REA.GetDouble("SaldoSv"), 2)
                                    dblSaldoVenta4 = Math.Round(REA.GetDouble("SaldoDr"), 2)
                                    dblSaldoVenta5 = Math.Round(REA.GetDouble("trading"), 2)
                                End If

                                If logPrimeraLinea = True Then
                                    logPrimeraLinea = False
                                    strNivel0 = REA.GetString("Nivel0")
                                    strNivel1 = REA.GetString("Nivel1")
                                    strNivel2 = REA.GetString("Nivel2")
                                    strNivel3 = REA.GetString("Nivel3")
                                    'strNivel4 = REA.GetString("Nivel4")

                                    dblTotalNivel0 = dblSaldoVenta
                                    dblTotalNivel02 = dblSaldoVenta2
                                    dblTotalNivel03 = dblSaldoVenta3
                                    dblTotalNivel04 = dblSaldoVenta4
                                    dblTotalNivel05 = dblSaldoVenta5
                                    dblTotalNivel1 = dblSaldoVenta
                                    dblTotalNivel12 = dblSaldoVenta2
                                    dblTotalNivel13 = dblSaldoVenta3
                                    dblTotalNivel14 = dblSaldoVenta4
                                    dblTotalNivel15 = dblSaldoVenta5
                                    dblTotalNivel2 = dblSaldoVenta
                                    dblTotalNivel22 = dblSaldoVenta2
                                    dblTotalNivel23 = dblSaldoVenta3
                                    dblTotalNivel24 = dblSaldoVenta4
                                    dblTotalNivel25 = dblSaldoVenta5
                                    dblTotalNivel3 = dblSaldoVenta
                                    dblTotalNivel32 = dblSaldoVenta2
                                    dblTotalNivel33 = dblSaldoVenta3
                                    dblTotalNivel34 = dblSaldoVenta4
                                    dblTotalNivel35 = dblSaldoVenta5
                                    'dblTotalNivel4 = dblSaldoVenta

                                    strHtml &= PrimeraLineaReporte(emp, 0, REA.GetString("Nivel0"), REA.GetString("Nivel1"), REA.GetString("Nivel2"), REA.GetString("Nivel3"), dblSaldoVenta, dblSaldoVenta2, dblSaldoVenta3, dblSaldoVenta4, dblSaldoVenta5, True)
                                Else
                                    If strNivel0 = REA.GetString("Nivel0") Then
                                        strHtml &= LineaReport(0, REA.GetString("Nivel0"), dblSaldoVenta, dblSaldoVenta2, dblSaldoVenta3, dblSaldoVenta4, dblSaldoVenta5)
                                    Else
                                        If intConteo = 0 Then
                                            dblPerdidaPeriodo = dblPerdidaPeriodo + dblTotalNivel0
                                            dblPerdidaPeriodo2 = dblPerdidaPeriodo2 + dblTotalNivel02
                                            dblPerdidaPeriodo3 = dblPerdidaPeriodo3 + dblTotalNivel03
                                            dblPerdidaPeriodo4 = dblPerdidaPeriodo4 + dblTotalNivel04
                                            dblPerdidaPeriodo5 = dblPerdidaPeriodo5 + dblTotalNivel05
                                        Else
                                            dblPerdidaPeriodo = dblPerdidaPeriodo - dblTotalNivel0
                                            dblPerdidaPeriodo2 = dblPerdidaPeriodo2 - dblTotalNivel02
                                            dblPerdidaPeriodo3 = dblPerdidaPeriodo3 - dblTotalNivel03
                                            dblPerdidaPeriodo4 = dblPerdidaPeriodo4 - dblTotalNivel04
                                            dblPerdidaPeriodo5 = dblPerdidaPeriodo5 - dblTotalNivel05
                                        End If
                                        intConteo = intConteo + 1
                                        If intConteo = 2 Then
                                            str2Niveles = strNivel0
                                            dbl2Totales = dblTotalNivel0
                                            dbl2Totales2 = dblTotalNivel02
                                            dbl2Totales3 = dblTotalNivel03
                                            dbl2Totales4 = dblTotalNivel04
                                            dbl2Totales5 = dblTotalNivel05
                                        End If
                                        If REA.GetString("Cuenta2") = "3101" Then
                                            conta1 = "contahilos"
                                            conta2 = "contapm"
                                            conta3 = "contapy"
                                            conta4 = "contadominican"
                                            empresa1 = "12"
                                            empresa2 = "16"
                                            empresa3 = "11"
                                            empresa4 = "14"
                                            Dim dblResultadoEjercicio As Double = ResultadoEjercicioReport(FechaIni, FechaFic, PromedioTC, conta1, empresa1)
                                            Dim dblResultadoEjercicio2 As Double = ResultadoEjercicioReport(FechaIni, FechaFic, PromedioTC2, conta2, empresa2)
                                            Dim dblResultadoEjercicio3 As Double = ResultadoEjercicioReport(FechaIni, FechaFic, PromedioTC3, conta3, empresa3)
                                            Dim dblResultadoEjercicio4 As Double = ResultadoEjercicioReport(FechaIni, FechaFic, PromedioTC4, conta4, empresa4)
                                            Dim dblResultadoEjercicio5 As Double = INT_CERO

                                            strHtml &= SubtotalReport(0, strNivel0, dblTotalNivel0, dblTotalNivel02, dblTotalNivel03, dblTotalNivel04, dblTotalNivel05)
                                            strHtml &= PrimeraLineaReporte(emp, 0, REA.GetString("Nivel0"), REA.GetString("Nivel1"), REA.GetString("Nivel2"), REA.GetString("Nivel3"), dblSaldoVenta + (dblResultadoEjercicio * -1), dblSaldoVenta2 + (dblResultadoEjercicio2 * -1), dblSaldoVenta3 + (dblResultadoEjercicio3 * -1), dblSaldoVenta4 + (dblResultadoEjercicio4 * -1), dblSaldoVenta5 + (dblResultadoEjercicio5 * -1), True)
                                            'strHtml &= LineaReport(0, REA.GetString("Nivel0"), (REA.GetDouble("saldo") + dblResultadoEjercicio))
                                            strNivel0 = REA.GetString("Nivel0")
                                            dblTotalNivel0 = dblSaldoVenta + (dblResultadoEjercicio * -1)
                                            dblTotalNivel02 = dblSaldoVenta2 + (dblResultadoEjercicio2 * -1)
                                            dblTotalNivel03 = dblSaldoVenta3 + (dblResultadoEjercicio3 * -1)
                                            dblTotalNivel04 = dblSaldoVenta4 + (dblResultadoEjercicio4 * -1)
                                            dblTotalNivel05 = dblSaldoVenta5 + (dblResultadoEjercicio5 * -1)

                                        Else
                                            strHtml &= SubtotalReport(0, strNivel0, dblTotalNivel0, dblTotalNivel02, dblTotalNivel03, dblTotalNivel04, dblTotalNivel05)
                                            strHtml &= PrimeraLineaReporte(emp, 0, REA.GetString("Nivel0"), REA.GetString("Nivel1"), REA.GetString("Nivel2"), REA.GetString("Nivel3"), dblSaldoVenta, dblSaldoVenta, dblSaldoVenta2, dblSaldoVenta3, dblSaldoVenta4, True)
                                            'strHtml &= LineaReport(0, REA.GetString("Nivel0"), REA.GetDouble("saldo"))
                                            strNivel0 = REA.GetString("Nivel0")
                                            dblTotalNivel0 = dblSaldoVenta
                                            dblTotalNivel02 = dblSaldoVenta2
                                            dblTotalNivel03 = dblSaldoVenta3
                                            dblTotalNivel04 = dblSaldoVenta4
                                            dblTotalNivel05 = dblSaldoVenta5
                                        End If

                                    End If

                                End If

                            Loop
                            strHtml &= SubtotalReport(0, strNivel0, dblTotalNivel0, dblTotalNivel02, dblTotalNivel03, dblTotalNivel04, dblTotalNivel05)
                            dblPerdidaPeriodo = dblPerdidaPeriodo - dblTotalNivel0
                            dblPerdidaPeriodo2 = dblPerdidaPeriodo2 - dblTotalNivel02
                            dblPerdidaPeriodo3 = dblPerdidaPeriodo3 - dblTotalNivel03
                            dblPerdidaPeriodo4 = dblPerdidaPeriodo4 - dblTotalNivel04
                            dblPerdidaPeriodo5 = dblPerdidaPeriodo5 - dblTotalNivel05
                            'strHtml &= "</table>"
                            strHtml &= "<br/>"
                        Case 1

                            Do While REA.Read
                                Dim emp = REA.GetInt32("CEmpresa")
                                If REA.GetDouble("Cuenta1") = 41 Then
                                    dblSaldoVenta = Math.Round(REA.GetDouble("SaldoGt"), 2) * (-1)
                                    dblSaldoVenta2 = Math.Round(REA.GetDouble("SaldoHn"), 2) * (-1)
                                    dblSaldoVenta3 = Math.Round(REA.GetDouble("SaldoSv"), 2) * (-1)
                                    dblSaldoVenta4 = Math.Round(REA.GetDouble("SaldoDr"), 2) * (-1)
                                    dblSaldoVenta5 = Math.Round(REA.GetDouble("trading"), 2) * (-1)
                                Else
                                    dblSaldoVenta = Math.Round(REA.GetDouble("SaldoGt"), 2)
                                    dblSaldoVenta2 = Math.Round(REA.GetDouble("SaldoHn"), 2)
                                    dblSaldoVenta3 = Math.Round(REA.GetDouble("SaldoSv"), 2)
                                    dblSaldoVenta4 = Math.Round(REA.GetDouble("SaldoDr"), 2)
                                    dblSaldoVenta5 = Math.Round(REA.GetDouble("trading"), 2)
                                End If
                                If logPrimeraLinea = True Then
                                    logPrimeraLinea = False
                                    strNivel0 = REA.GetString("Nivel0")
                                    strNivel1 = REA.GetString("Nivel1")
                                    strNivel2 = REA.GetString("Nivel2")
                                    strNivel3 = REA.GetString("Nivel3")
                                    'strNivel4 = REA.GetString("Nivel4")

                                    dblTotalNivel0 = dblSaldoVenta
                                    dblTotalNivel02 = dblSaldoVenta2
                                    dblTotalNivel03 = dblSaldoVenta3
                                    dblTotalNivel04 = dblSaldoVenta4
                                    dblTotalNivel1 = dblSaldoVenta
                                    dblTotalNivel12 = dblSaldoVenta2
                                    dblTotalNivel13 = dblSaldoVenta3
                                    dblTotalNivel14 = dblSaldoVenta4
                                    dblTotalNivel2 = dblSaldoVenta
                                    dblTotalNivel22 = dblSaldoVenta2
                                    dblTotalNivel23 = dblSaldoVenta3
                                    dblTotalNivel24 = dblSaldoVenta4
                                    dblTotalNivel3 = dblSaldoVenta
                                    'dblTotalNivel4 = dblSaldoVenta

                                    strHtml &= PrimeraLineaReporte(emp, 1, REA.GetString("Nivel0"), REA.GetString("Nivel1"), REA.GetString("Nivel2"), REA.GetString("Nivel3"), dblSaldoVenta, dblSaldoVenta2, dblSaldoVenta3, dblSaldoVenta4, dblSaldoVenta5, True, dbltotal:=dblPerdidaPeriodo, dbltotal2:=dblPerdidaPeriodo2, dbltotal3:=dblPerdidaPeriodo3, dbltotal4:=dblPerdidaPeriodo4, dbltotal5:=dblPerdidaPeriodo5)
                                    strNivel0 = REA.GetString("Nivel0")
                                Else
                                    If strNivel0 = REA.GetString("Nivel0") Then
                                        strHtml &= LineaReport(1, REA.GetString("Nivel1"), dblSaldoVenta, dblSaldoVenta2, dblSaldoVenta3, dblSaldoVenta4, dblSaldoVenta5)
                                        dblTotalNivel0 = dblTotalNivel0 + dblSaldoVenta
                                        dblTotalNivel02 = dblTotalNivel02 + dblSaldoVenta2
                                        dblTotalNivel03 = dblTotalNivel03 + dblSaldoVenta3
                                        dblTotalNivel04 = dblTotalNivel04 + dblSaldoVenta4
                                        dblTotalNivel05 = dblTotalNivel05 + dblSaldoVenta5
                                        strNivel0 = REA.GetString("Nivel0")
                                    Else
                                        If intConteo = 0 Then
                                            dblPerdidaPeriodo = dblPerdidaPeriodo + dblTotalNivel0
                                            dblPerdidaPeriodo2 = dblPerdidaPeriodo2 + dblTotalNivel02
                                            dblPerdidaPeriodo3 = dblPerdidaPeriodo3 + dblTotalNivel03
                                            dblPerdidaPeriodo4 = dblPerdidaPeriodo4 + dblTotalNivel04
                                            dblPerdidaPeriodo5 = dblPerdidaPeriodo5 + dblTotalNivel05
                                        Else
                                            dblPerdidaPeriodo = dblPerdidaPeriodo - dblTotalNivel0
                                            dblPerdidaPeriodo2 = dblPerdidaPeriodo2 - dblTotalNivel02
                                            dblPerdidaPeriodo3 = dblPerdidaPeriodo3 - dblTotalNivel03
                                            dblPerdidaPeriodo4 = dblPerdidaPeriodo4 - dblTotalNivel04
                                            dblPerdidaPeriodo5 = dblPerdidaPeriodo5 - dblTotalNivel05
                                        End If
                                        intConteo = intConteo + 1
                                        strHtml &= SubtotalReport(0, strNivel0, dblTotalNivel0, dblTotalNivel02, dblTotalNivel03, dblTotalNivel04, dblTotalNivel05)
                                        If intConteo = 2 Then
                                            str2Niveles = strNivel0
                                            dbl2Totales = dblTotalNivel0
                                            dbl2Totales2 = dblTotalNivel02
                                            dbl2Totales3 = dblTotalNivel03
                                            dbl2Totales4 = dblTotalNivel04
                                            dbl2Totales5 = dblTotalNivel05
                                        End If
                                        dblTotalNivel0 = INT_CERO
                                        If REA.GetString("Cuenta2") = "3101" Then
                                            conta1 = "contahilos"
                                            conta2 = "contapm"
                                            conta3 = "contapy"
                                            conta4 = "contadominican"
                                            empresa1 = "12"
                                            empresa2 = "16"
                                            empresa3 = "11"
                                            empresa4 = "14"
                                            Dim dblResultadoEjercicio As Double = ResultadoEjercicioReport(FechaIni, FechaFic, PromedioTC, conta1, empresa1)
                                            Dim dblResultadoEjercicio2 As Double = ResultadoEjercicioReport(FechaIni, FechaFic, PromedioTC2, conta2, empresa2)
                                            Dim dblResultadoEjercicio3 As Double = ResultadoEjercicioReport(FechaIni, FechaFic, PromedioTC3, conta3, empresa3)
                                            Dim dblResultadoEjercicio4 As Double = ResultadoEjercicioReport(FechaIni, FechaFic, PromedioTC4, conta4, empresa4)
                                            Dim dblResultadoEjercicio5 As Double = INT_CERO

                                            dblTotalNivel0 = dblSaldoVenta + dblResultadoEjercicio
                                            dblTotalNivel02 = dblSaldoVenta2 + dblResultadoEjercicio2
                                            dblTotalNivel03 = dblSaldoVenta3 + dblResultadoEjercicio3
                                            dblTotalNivel04 = dblSaldoVenta4 + dblResultadoEjercicio4
                                            dblTotalNivel05 = dblSaldoVenta5 + dblResultadoEjercicio5
                                            'dblTotalNivel0 = dblTotalNivel0 + REA.GetDouble("saldo") + dblResultadoEjercicio
                                            strHtml &= PrimeraLineaReporte(emp, 1, REA.GetString("Nivel0"), REA.GetString("Nivel1"), REA.GetString("Nivel2"), REA.GetString("Nivel3"), dblTotalNivel0, dblTotalNivel02, dblTotalNivel03, dblTotalNivel04, dblTotalNivel05, True)

                                        Else
                                            dblTotalNivel0 = dblTotalNivel0 + dblSaldoVenta
                                            dblTotalNivel02 = dblTotalNivel02 + dblSaldoVenta2
                                            dblTotalNivel03 = dblTotalNivel03 + dblSaldoVenta3
                                            dblTotalNivel04 = dblTotalNivel04 + dblSaldoVenta4
                                            dblTotalNivel05 = dblTotalNivel05 + dblSaldoVenta5
                                            strHtml &= PrimeraLineaReporte(emp, 1, REA.GetString("Nivel0"), REA.GetString("Nivel1"), REA.GetString("Nivel2"), REA.GetString("Nivel3"), dblSaldoVenta, dblSaldoVenta2, dblSaldoVenta3, dblSaldoVenta4, dblSaldoVenta5, True, dbltotal:=dblPerdidaPeriodo, dbltotal2:=dblPerdidaPeriodo2, dbltotal3:=dblPerdidaPeriodo3, dbltotal4:=dblPerdidaPeriodo4, dbltotal5:=dblPerdidaPeriodo5)
                                            ' strHtml &= Linea(1, REA.GetString("nivel1"), dblSaldoVenta)

                                        End If

                                        strNivel0 = REA.GetString("Nivel0")

                                    End If
                                End If
                            Loop
                            strHtml &= SubtotalReport(0, strNivel0, dblTotalNivel0, dblTotalNivel02, dblTotalNivel03, dblTotalNivel04, dblTotalNivel05)
                            dblPerdidaPeriodo = dblPerdidaPeriodo - dblTotalNivel0
                            dblPerdidaPeriodo2 = dblPerdidaPeriodo2 - dblTotalNivel02
                            dblPerdidaPeriodo3 = dblPerdidaPeriodo3 - dblTotalNivel03
                            dblPerdidaPeriodo4 = dblPerdidaPeriodo4 - dblTotalNivel04
                            dblPerdidaPeriodo5 = dblPerdidaPeriodo5 - dblTotalNivel05

                            'strHtml &= "</table>"
                            strHtml &= "<br/>"
                        Case 2

                            Do While REA.Read
                                Dim emp = REA.GetInt32("CEmpresa")
                                If REA.GetDouble("Cuenta1") = 41 Then
                                    dblSaldoVenta = Math.Round(REA.GetDouble("SaldoGt"), 2) * (-1)
                                    dblSaldoVenta2 = Math.Round(REA.GetDouble("SaldoHn"), 2) * (-1)
                                    dblSaldoVenta3 = Math.Round(REA.GetDouble("SaldoSv"), 2) * (-1)
                                    dblSaldoVenta4 = Math.Round(REA.GetDouble("SaldoDr"), 2) * (-1)
                                    dblSaldoVenta5 = Math.Round(REA.GetDouble("trading"), 2) * (-1)
                                Else
                                    dblSaldoVenta = Math.Round(REA.GetDouble("SaldoGt"), 2)
                                    dblSaldoVenta2 = Math.Round(REA.GetDouble("SaldoHn"), 2)
                                    dblSaldoVenta3 = Math.Round(REA.GetDouble("SaldoSv"), 2)
                                    dblSaldoVenta4 = Math.Round(REA.GetDouble("SaldoDr"), 2)
                                    dblSaldoVenta5 = Math.Round(REA.GetDouble("trading"), 2)
                                End If
                                If logPrimeraLinea = True Then
                                    logPrimeraLinea = False
                                    strNivel0 = REA.GetString("Nivel0")
                                    strNivel1 = REA.GetString("Nivel1")
                                    strNivel2 = REA.GetString("Nivel2")
                                    strNivel3 = REA.GetString("Nivel3")
                                    'strNivel4 = REA.GetString("Nivel4")

                                    dblTotalNivel0 = dblSaldoVenta
                                    dblTotalNivel02 = dblSaldoVenta2
                                    dblTotalNivel03 = dblSaldoVenta3
                                    dblTotalNivel04 = dblSaldoVenta4
                                    dblTotalNivel05 = dblSaldoVenta5
                                    dblTotalNivel1 = dblSaldoVenta
                                    dblTotalNivel12 = dblSaldoVenta2
                                    dblTotalNivel13 = dblSaldoVenta3
                                    dblTotalNivel14 = dblSaldoVenta4
                                    dblTotalNivel15 = dblSaldoVenta5
                                    dblTotalNivel2 = dblSaldoVenta
                                    dblTotalNivel22 = dblSaldoVenta2
                                    dblTotalNivel23 = dblSaldoVenta3
                                    dblTotalNivel24 = dblSaldoVenta4
                                    dblTotalNivel25 = dblSaldoVenta5
                                    dblTotalNivel3 = dblSaldoVenta
                                    dblTotalNivel32 = dblSaldoVenta2
                                    dblTotalNivel33 = dblSaldoVenta3
                                    dblTotalNivel34 = dblSaldoVenta4
                                    dblTotalNivel35 = dblSaldoVenta5
                                    'dblTotalNivel4 = dblSaldoVenta

                                    strHtml &= PrimeraLineaReporte(emp, 2, REA.GetString("Nivel0"), REA.GetString("Nivel1"), REA.GetString("Nivel2"), REA.GetString("Nivel3"), dblSaldoVenta, dblSaldoVenta2, dblSaldoVenta3, dblSaldoVenta4, dblSaldoVenta5, True, dbltotal:=dblPerdidaPeriodo, dbltotal2:=dblPerdidaPeriodo2, dbltotal3:=dblPerdidaPeriodo3, dbltotal4:=dblPerdidaPeriodo4, dbltotal5:=dblPerdidaPeriodo5)
                                Else


                                    If strNivel0 = REA.GetString("Nivel0") Then
                                        If strNivel1 = REA.GetString("Nivel1") Then

                                            If REA.GetString("Cuenta2") = "3101" Then

                                                conta1 = "contahilos"
                                                conta2 = "contapm"
                                                conta3 = "contapy"
                                                conta4 = "contadominican"
                                                empresa1 = "12"
                                                empresa2 = "16"
                                                empresa3 = "11"
                                                empresa4 = "14"
                                                Dim dblResultadoEjercicio As Double = ResultadoEjercicioReport(FechaIni, FechaFic, PromedioTC, conta1, empresa1)
                                                Dim dblResultadoEjercicio2 As Double = ResultadoEjercicioReport(FechaIni, FechaFic, PromedioTC2, conta2, empresa2)
                                                Dim dblResultadoEjercicio3 As Double = ResultadoEjercicioReport(FechaIni, FechaFic, PromedioTC3, conta3, empresa3)
                                                Dim dblResultadoEjercicio4 As Double = ResultadoEjercicioReport(FechaIni, FechaFic, PromedioTC4, conta4, empresa4)
                                                Dim dblResultadoEjercicio5 As Double = INT_CERO

                                                dblTotalNivel0 = dblTotalNivel0 + dblResultadoEjercicio
                                                dblTotalNivel02 = dblTotalNivel02 + dblResultadoEjercicio2
                                                dblTotalNivel03 = dblTotalNivel03 + dblResultadoEjercicio3
                                                dblTotalNivel04 = dblTotalNivel04 + dblResultadoEjercicio4
                                                dblTotalNivel05 = dblTotalNivel05 + dblResultadoEjercicio5
                                                dblTotalNivel1 = dblTotalNivel1 + dblResultadoEjercicio
                                                dblTotalNivel12 = dblTotalNivel12 + dblResultadoEjercicio2
                                                dblTotalNivel13 = dblTotalNivel13 + dblResultadoEjercicio3
                                                dblTotalNivel14 = dblTotalNivel14 + dblResultadoEjercicio4
                                                dblTotalNivel15 = dblTotalNivel15 + dblResultadoEjercicio5
                                                strHtml &= "<tr>"
                                                strHtml &= "<td class='centro'>" & EspacioHtml(10) & REA.GetString("Nivel2").ToString & "</td>"
                                                strHtml &= "<td class='derecha'>" & dblResultadoEjercicio.ToString(FORMATO_MONEDA) & "</td>"
                                                strHtml &= "</tr>"
                                            Else
                                                dblTotalNivel0 = dblTotalNivel0 + dblSaldoVenta
                                                dblTotalNivel02 = dblTotalNivel02 + dblSaldoVenta2
                                                dblTotalNivel03 = dblTotalNivel03 + dblSaldoVenta3
                                                dblTotalNivel04 = dblTotalNivel04 + dblSaldoVenta4
                                                dblTotalNivel05 = dblTotalNivel05 + dblSaldoVenta5
                                                dblTotalNivel1 = dblTotalNivel1 + dblSaldoVenta
                                                dblTotalNivel12 = dblTotalNivel12 + dblSaldoVenta2
                                                dblTotalNivel13 = dblTotalNivel13 + dblSaldoVenta3
                                                dblTotalNivel14 = dblTotalNivel14 + dblSaldoVenta4
                                                dblTotalNivel15 = dblTotalNivel15 + dblSaldoVenta5
                                                strHtml &= LineaReport(2, REA.GetString("Nivel2"), dblSaldoVenta, dblSaldoVenta2, dblSaldoVenta3, dblSaldoVenta4, dblSaldoVenta5)
                                            End If


                                        Else
                                            strHtml &= SubtotalReport(1, strNivel1, dblTotalNivel1, dblTotalNivel12, dblTotalNivel13, dblTotalNivel14, dblTotalNivel15)
                                            strHtml &= PrimeraLineaReporte(emp, 2, REA.GetString("Nivel0"), REA.GetString("Nivel1"), REA.GetString("Nivel2"), REA.GetString("Nivel3"), dblSaldoVenta, dblSaldoVenta2, dblSaldoVenta3, dblSaldoVenta4, dblSaldoVenta, False, dbltotal:=dblPerdidaPeriodo, dbltotal2:=dblPerdidaPeriodo2, dbltotal3:=dblPerdidaPeriodo3, dbltotal4:=dblPerdidaPeriodo4, dbltotal5:=dblPerdidaPeriodo5)
                                            dblTotalNivel0 = dblTotalNivel0 + dblSaldoVenta
                                            dblTotalNivel02 = dblTotalNivel02 + dblSaldoVenta2
                                            dblTotalNivel03 = dblTotalNivel03 + dblSaldoVenta3
                                            dblTotalNivel04 = dblTotalNivel04 + dblSaldoVenta4
                                            dblTotalNivel05 = dblTotalNivel05 + dblSaldoVenta5
                                            dblTotalNivel1 = dblSaldoVenta
                                            dblTotalNivel12 = dblSaldoVenta2
                                            dblTotalNivel13 = dblSaldoVenta3
                                            dblTotalNivel14 = dblSaldoVenta4
                                            dblTotalNivel15 = dblSaldoVenta5

                                        End If
                                    Else
                                        If intConteo = 0 Then
                                            dblPerdidaPeriodo = dblPerdidaPeriodo + dblTotalNivel0
                                            dblPerdidaPeriodo2 = dblPerdidaPeriodo2 + dblTotalNivel02
                                            dblPerdidaPeriodo3 = dblPerdidaPeriodo3 + dblTotalNivel03
                                            dblPerdidaPeriodo4 = dblPerdidaPeriodo4 + dblTotalNivel04
                                            dblPerdidaPeriodo5 = dblPerdidaPeriodo5 + dblTotalNivel05
                                        Else
                                            dblPerdidaPeriodo = dblPerdidaPeriodo - dblTotalNivel0
                                            dblPerdidaPeriodo2 = dblPerdidaPeriodo2 - dblTotalNivel02
                                            dblPerdidaPeriodo3 = dblPerdidaPeriodo3 - dblTotalNivel03
                                            dblPerdidaPeriodo4 = dblPerdidaPeriodo4 - dblTotalNivel04
                                            dblPerdidaPeriodo5 = dblPerdidaPeriodo5 - dblTotalNivel05
                                        End If
                                        intConteo = intConteo + 1

                                        strHtml &= SubtotalReport(1, strNivel1, dblTotalNivel1, dblTotalNivel12, dblTotalNivel13, dblTotalNivel14, dblTotalNivel15)
                                        strHtml &= SubtotalReport(0, strNivel0, dblTotalNivel0, dblTotalNivel02, dblTotalNivel03, dblTotalNivel04, dblTotalNivel05)

                                        If REA.GetString("Cuenta2") = "3101" Then

                                            conta1 = "contahilos"
                                            conta2 = "contapm"
                                            conta3 = "contapy"
                                            conta4 = "contadominican"
                                            empresa1 = "12"
                                            empresa2 = "16"
                                            empresa3 = "11"
                                            empresa4 = "14"
                                            Dim dblResultadoEjercicio As Double = ResultadoEjercicioReport(FechaIni, FechaFic, PromedioTC, conta1, empresa1)
                                            Dim dblResultadoEjercicio2 As Double = ResultadoEjercicioReport(FechaIni, FechaFic, PromedioTC2, conta2, empresa2)
                                            Dim dblResultadoEjercicio3 As Double = ResultadoEjercicioReport(FechaIni, FechaFic, PromedioTC3, conta3, empresa3)
                                            Dim dblResultadoEjercicio4 As Double = ResultadoEjercicioReport(FechaIni, FechaFic, PromedioTC4, conta4, empresa4)
                                            Dim dblResultadoEjercicio5 As Double = INT_CERO
                                            dblEjercicioActual = dblResultadoEjercicio + dblSaldoVenta
                                            dblEjercicioActual2 = dblResultadoEjercicio2 + dblSaldoVenta2
                                            dblEjercicioActual3 = dblResultadoEjercicio3 + dblSaldoVenta3
                                            dblEjercicioActual4 = dblResultadoEjercicio4 + dblSaldoVenta4
                                            dblEjercicioActual5 = dblResultadoEjercicio5 + dblSaldoVenta5
                                            strHtml &= PrimeraLineaReporte(emp, 2, REA.GetString("Nivel0"), REA.GetString("Nivel1"), REA.GetString("Nivel2"), REA.GetString("Nivel3"), dblEjercicioActual, dblEjercicioActual2, dblEjercicioActual3, dblEjercicioActual4, dblEjercicioActual5, True, dbltotal:=dblPerdidaPeriodo, dbltotal2:=dblPerdidaPeriodo2, dbltotal3:=dblPerdidaPeriodo3, dbltotal4:=dblPerdidaPeriodo4, dbltotal5:=dblPerdidaPeriodo5)
                                        Else
                                            strHtml &= PrimeraLineaReporte(emp, 2, REA.GetString("Nivel0"), REA.GetString("Nivel1"), REA.GetString("Nivel2"), REA.GetString("Nivel3"), dblSaldoVenta, dblSaldoVenta2, dblSaldoVenta3, dblSaldoVenta, dblSaldoVenta, True, dbltotal:=dblPerdidaPeriodo, dbltotal2:=dblPerdidaPeriodo2, dbltotal3:=dblPerdidaPeriodo3, dbltotal4:=dblPerdidaPeriodo4, dbltotal5:=dblPerdidaPeriodo5)
                                        End If

                                        If intConteo = 2 Then
                                            str2Niveles = strNivel0
                                            dbl2Totales = dblTotalNivel0
                                            dbl2Totales2 = dblTotalNivel02
                                            dbl2Totales3 = dblTotalNivel03
                                            dbl2Totales4 = dblTotalNivel04
                                            dbl2Totales5 = dblTotalNivel05
                                        End If
                                        If REA.GetString("Cuenta2") = "3101" Then
                                            dblTotalNivel0 = dblEjercicioActual
                                            dblTotalNivel02 = dblEjercicioActual2
                                            dblTotalNivel03 = dblEjercicioActual3
                                            dblTotalNivel04 = dblEjercicioActual4
                                            dblTotalNivel05 = dblEjercicioActual5
                                            dblTotalNivel1 = dblEjercicioActual
                                            dblTotalNivel12 = dblEjercicioActual2
                                            dblTotalNivel13 = dblEjercicioActual3
                                            dblTotalNivel14 = dblEjercicioActual4
                                            dblTotalNivel15 = dblEjercicioActual5
                                        Else
                                            dblTotalNivel0 = dblSaldoVenta
                                            dblTotalNivel02 = dblSaldoVenta2
                                            dblTotalNivel03 = dblSaldoVenta3
                                            dblTotalNivel04 = dblSaldoVenta4
                                            dblTotalNivel05 = dblSaldoVenta5
                                            dblTotalNivel1 = dblSaldoVenta
                                            dblTotalNivel12 = dblSaldoVenta2
                                            dblTotalNivel13 = dblSaldoVenta3
                                            dblTotalNivel14 = dblSaldoVenta4
                                            dblTotalNivel15 = dblSaldoVenta5
                                        End If

                                        'End If
                                    End If
                                End If
                                strNivel0 = REA.GetString("Nivel0")
                                strNivel1 = REA.GetString("Nivel1")
                            Loop
                            strHtml &= SubtotalReport(1, strNivel1, dblTotalNivel1, dblTotalNivel12, dblTotalNivel13, dblTotalNivel14, dblTotalNivel15)

                            strHtml &= SubtotalReport(0, strNivel0, dblTotalNivel0, dblTotalNivel02, dblTotalNivel03, dblTotalNivel04, dblTotalNivel05)
                            dblPerdidaPeriodo = dblPerdidaPeriodo - dblTotalNivel0
                            dblPerdidaPeriodo2 = dblPerdidaPeriodo2 - dblTotalNivel02
                            dblPerdidaPeriodo3 = dblPerdidaPeriodo3 - dblTotalNivel03
                            dblPerdidaPeriodo4 = dblPerdidaPeriodo4 - dblTotalNivel04
                            dblPerdidaPeriodo5 = dblPerdidaPeriodo5 - dblTotalNivel05

                            'strHtml &= "</table>"
                            strHtml &= "<br/>"
                        Case 3
                            Do While REA.Read
                                Dim emp = REA.GetInt32("CEmpresa")
                                If REA.GetDouble("Cuenta1") = 41 Then
                                    dblSaldoVenta = Math.Round(REA.GetDouble("SaldoGt"), 2) * (-1)
                                    dblSaldoVenta2 = Math.Round(REA.GetDouble("SaldoHn"), 2) * (-1)
                                    dblSaldoVenta3 = Math.Round(REA.GetDouble("SaldoSv"), 2) * (-1)
                                    dblSaldoVenta4 = Math.Round(REA.GetDouble("SaldoDr"), 2) * (-1)
                                    dblSaldoVenta5 = Math.Round(REA.GetDouble("trading"), 2) * (-1)
                                Else
                                    dblSaldoVenta = Math.Round(REA.GetDouble("SaldoGt"), 2)
                                    dblSaldoVenta2 = Math.Round(REA.GetDouble("SaldoHn"), 2)
                                    dblSaldoVenta3 = Math.Round(REA.GetDouble("SaldoSv"), 2)
                                    dblSaldoVenta4 = Math.Round(REA.GetDouble("SaldoDr"), 2)
                                    dblSaldoVenta5 = Math.Round(REA.GetDouble("trading"), 2)
                                End If
                                If logPrimeraLinea = True Then
                                    logPrimeraLinea = False
                                    strNivel0 = REA.GetString("Nivel0")
                                    strNivel1 = REA.GetString("Nivel1")
                                    strNivel2 = REA.GetString("Nivel2")
                                    strNivel3 = REA.GetString("Nivel3")
                                    strNivel4 = REA.GetString("Nivel4")

                                    dblTotalNivel0 = dblSaldoVenta
                                    dblTotalNivel02 = dblSaldoVenta2
                                    dblTotalNivel03 = dblSaldoVenta3
                                    dblTotalNivel04 = dblSaldoVenta4
                                    dblTotalNivel05 = dblSaldoVenta5
                                    dblTotalNivel1 = dblSaldoVenta
                                    dblTotalNivel12 = dblSaldoVenta2
                                    dblTotalNivel13 = dblSaldoVenta3
                                    dblTotalNivel14 = dblSaldoVenta4
                                    dblTotalNivel15 = dblSaldoVenta5
                                    dblTotalNivel2 = dblSaldoVenta
                                    dblTotalNivel22 = dblSaldoVenta2
                                    dblTotalNivel23 = dblSaldoVenta3
                                    dblTotalNivel24 = dblSaldoVenta4
                                    dblTotalNivel25 = dblSaldoVenta5
                                    dblTotalNivel3 = dblSaldoVenta
                                    dblTotalNivel32 = dblSaldoVenta2
                                    dblTotalNivel33 = dblSaldoVenta3
                                    dblTotalNivel34 = dblSaldoVenta4
                                    dblTotalNivel35 = dblSaldoVenta5
                                    dblTotalNivel4 = dblSaldoVenta

                                    strHtml &= PrimeraLineaReporte(emp, 3, REA.GetString("Nivel0"), REA.GetString("Nivel1"), REA.GetString("Nivel2"), REA.GetString("Nivel3"), dblSaldoVenta, dblSaldoVenta2, dblSaldoVenta3, dblSaldoVenta4, dblSaldoVenta5, True, dbltotal:=dblPerdidaPeriodo, dbltotal2:=dblPerdidaPeriodo2, dbltotal3:=dblPerdidaPeriodo3, dbltotal4:=dblPerdidaPeriodo4, dbltotal5:=dblPerdidaPeriodo5)
                                Else
                                    If strNivel0 = "EXPENSES" Then
                                        intValidar = intValidar + 1
                                    End If
                                    If strNivel0 = REA.GetString("Nivel0") Then
                                        If strNivel1 = REA.GetString("Nivel1") Then
                                            If strNivel2 = REA.GetString("Nivel2") Then

                                                If REA.GetString("Cuenta3") = "310101" Then

                                                    conta1 = "contahilos"
                                                    conta2 = "contapm"
                                                    conta3 = "contapy"
                                                    conta4 = "contadominican"
                                                    empresa1 = "12"
                                                    empresa2 = "16"
                                                    empresa3 = "11"
                                                    empresa4 = "14"
                                                    Dim dblResultadoEjercicio1 As Double = ResultadoEjercicioReport(FechaIni, FechaFic, PromedioTC, conta1, empresa1)
                                                    Dim dblResultadoEjercicio2 As Double = ResultadoEjercicioReport(FechaIni, FechaFic, PromedioTC2, conta2, empresa2)
                                                    Dim dblResultadoEjercicio3 As Double = ResultadoEjercicioReport(FechaIni, FechaFic, PromedioTC3, conta3, empresa3)
                                                    Dim dblResultadoEjercicio4 As Double = ResultadoEjercicioReport(FechaIni, FechaFic, PromedioTC4, conta4, empresa4)
                                                    Dim dblResultadoEjercicio5 As Double = INT_CERO

                                                    dblTotalNivel0 = dblTotalNivel0 + dblResultadoEjercicio1
                                                    dblTotalNivel02 = dblTotalNivel02 + dblResultadoEjercicio2
                                                    dblTotalNivel03 = dblTotalNivel03 + dblResultadoEjercicio3
                                                    dblTotalNivel04 = dblTotalNivel04 + dblResultadoEjercicio4
                                                    dblTotalNivel05 = dblTotalNivel05 + dblResultadoEjercicio5
                                                    dblTotalNivel1 = dblTotalNivel1 + dblResultadoEjercicio1
                                                    dblTotalNivel12 = dblTotalNivel12 + dblResultadoEjercicio2
                                                    dblTotalNivel13 = dblTotalNivel13 + dblResultadoEjercicio3
                                                    dblTotalNivel14 = dblTotalNivel14 + dblResultadoEjercicio4
                                                    dblTotalNivel15 = dblTotalNivel15 + dblResultadoEjercicio5
                                                    dblTotalNivel2 = dblTotalNivel2 + dblResultadoEjercicio1
                                                    dblTotalNivel22 = dblTotalNivel22 + dblResultadoEjercicio2
                                                    dblTotalNivel23 = dblTotalNivel23 + dblResultadoEjercicio3
                                                    dblTotalNivel24 = dblTotalNivel24 + dblResultadoEjercicio4
                                                    dblTotalNivel25 = dblTotalNivel25 + dblResultadoEjercicio5

                                                    strHtml &= "<tr>"
                                                    strHtml &= "<td class='centro'>" & EspacioHtml(10) & REA.GetString("Nivel3").ToString & "</td>"
                                                    strHtml &= "<td class='derecha'>" & dblResultadoEjercicio1.ToString(FORMATO_MONEDA) & "</td>"
                                                    strHtml &= "<td class='derecha'>" & dblResultadoEjercicio2.ToString(FORMATO_MONEDA) & "</td>"
                                                    strHtml &= "<td class='derecha'>" & dblResultadoEjercicio3.ToString(FORMATO_MONEDA) & "</td>"
                                                    strHtml &= "<td class='derecha'>" & dblResultadoEjercicio4.ToString(FORMATO_MONEDA) & "</td>"
                                                    strHtml &= "<td class='derecha'>" & dblResultadoEjercicio5.ToString(FORMATO_MONEDA) & "</td>"
                                                    strHtml &= "</tr>"
                                                Else
                                                    dblTotalNivel0 = dblTotalNivel0 + dblSaldoVenta
                                                    dblTotalNivel02 = dblTotalNivel02 + dblSaldoVenta2
                                                    dblTotalNivel03 = dblTotalNivel03 + dblSaldoVenta3
                                                    dblTotalNivel04 = dblTotalNivel04 + dblSaldoVenta4
                                                    dblTotalNivel05 = dblTotalNivel05 + dblSaldoVenta5
                                                    dblTotalNivel1 = dblTotalNivel1 + dblSaldoVenta
                                                    dblTotalNivel12 = dblTotalNivel12 + dblSaldoVenta2
                                                    dblTotalNivel13 = dblTotalNivel13 + dblSaldoVenta3
                                                    dblTotalNivel14 = dblTotalNivel14 + dblSaldoVenta4
                                                    dblTotalNivel15 = dblTotalNivel15 + dblSaldoVenta5
                                                    dblTotalNivel2 = dblTotalNivel2 + dblSaldoVenta
                                                    dblTotalNivel22 = dblTotalNivel22 + dblSaldoVenta2
                                                    dblTotalNivel23 = dblTotalNivel23 + dblSaldoVenta3
                                                    dblTotalNivel24 = dblTotalNivel24 + dblSaldoVenta4
                                                    dblTotalNivel25 = dblTotalNivel25 + dblSaldoVenta5
                                                    strHtml &= LineaReport(3, REA.GetString("Nivel3"), dblSaldoVenta, dblSaldoVenta2, dblSaldoVenta3, dblSaldoVenta4, dblSaldoVenta5)
                                                End If
                                            Else

                                                strHtml &= SubtotalReport(2, strNivel2, dblTotalNivel2, dblTotalNivel22, dblTotalNivel23, dblTotalNivel24, dblTotalNivel25)
                                                strHtml &= PrimeraLineaReporte(emp, 3, REA.GetString("Nivel0"), REA.GetString("Nivel1"), REA.GetString("Nivel2"), REA.GetString("Nivel3"), dblSaldoVenta, dblSaldoVenta2, dblSaldoVenta3, dblSaldoVenta4, dblSaldoVenta5, False, dbltotal:=dblPerdidaPeriodo, dbltotal2:=dblPerdidaPeriodo2, dbltotal3:=dblPerdidaPeriodo3, dbltotal4:=dblPerdidaPeriodo4, dbltotal5:=dblPerdidaPeriodo5)
                                                dblTotalNivel0 = dblTotalNivel0 + dblSaldoVenta
                                                dblTotalNivel02 = dblTotalNivel02 + dblSaldoVenta2
                                                dblTotalNivel03 = dblTotalNivel03 + dblSaldoVenta3
                                                dblTotalNivel04 = dblTotalNivel04 + dblSaldoVenta4
                                                dblTotalNivel05 = dblTotalNivel05 + dblSaldoVenta5
                                                dblTotalNivel1 = dblTotalNivel1 + dblSaldoVenta
                                                dblTotalNivel12 = dblTotalNivel12 + dblSaldoVenta2
                                                dblTotalNivel13 = dblTotalNivel13 + dblSaldoVenta3
                                                dblTotalNivel14 = dblTotalNivel14 + dblSaldoVenta4
                                                dblTotalNivel15 = dblTotalNivel15 + dblSaldoVenta5
                                                dblTotalNivel2 = dblSaldoVenta
                                                dblTotalNivel22 = dblSaldoVenta2
                                                dblTotalNivel23 = dblSaldoVenta3
                                                dblTotalNivel24 = dblSaldoVenta4
                                                dblTotalNivel25 = dblSaldoVenta5

                                            End If

                                        Else
                                            strHtml &= SubtotalReport(2, strNivel2, dblTotalNivel2, dblTotalNivel22, dblTotalNivel23, dblTotalNivel24, dblTotalNivel2)
                                            strHtml &= SubtotalReport(1, strNivel1, dblTotalNivel1, dblTotalNivel12, dblTotalNivel13, dblTotalNivel14, dblTotalNivel15)
                                            strHtml &= PrimeraLineaReporte(emp, 3, REA.GetString("Nivel0"), REA.GetString("Nivel1"), REA.GetString("Nivel2"), REA.GetString("Nivel3"), dblSaldoVenta, dblSaldoVenta2, dblSaldoVenta3, dblSaldoVenta4, dblSaldoVenta5, True, 1, dbltotal:=dblPerdidaPeriodo, dbltotal2:=dblPerdidaPeriodo2, dbltotal3:=dblPerdidaPeriodo3, dbltotal4:=dblPerdidaPeriodo4, dbltotal5:=dblPerdidaPeriodo5, intValidar2:=intValidar)
                                            dblTotalNivel0 = dblTotalNivel0 + dblSaldoVenta
                                            dblTotalNivel02 = dblTotalNivel02 + dblSaldoVenta2
                                            dblTotalNivel03 = dblTotalNivel03 + dblSaldoVenta3
                                            dblTotalNivel04 = dblTotalNivel04 + dblSaldoVenta4
                                            dblTotalNivel05 = dblTotalNivel05 + dblSaldoVenta5
                                            dblTotalNivel1 = dblSaldoVenta
                                            dblTotalNivel12 = dblSaldoVenta2
                                            dblTotalNivel13 = dblSaldoVenta3
                                            dblTotalNivel14 = dblSaldoVenta4
                                            dblTotalNivel15 = dblSaldoVenta5  ' dblTotalNivel1 + dblSaldoVenta
                                            dblTotalNivel2 = dblSaldoVenta
                                            dblTotalNivel22 = dblSaldoVenta2
                                            dblTotalNivel23 = dblSaldoVenta3
                                            dblTotalNivel24 = dblSaldoVenta4
                                            dblTotalNivel25 = dblSaldoVenta5
                                        End If
                                    Else
                                        If intConteo = 0 Then
                                            dblPerdidaPeriodo = dblPerdidaPeriodo + dblTotalNivel0
                                            dblPerdidaPeriodo2 = dblPerdidaPeriodo2 + dblTotalNivel02
                                            dblPerdidaPeriodo3 = dblPerdidaPeriodo3 + dblTotalNivel03
                                            dblPerdidaPeriodo4 = dblPerdidaPeriodo4 + dblTotalNivel04
                                            dblPerdidaPeriodo5 = dblPerdidaPeriodo5 + dblTotalNivel05
                                        Else
                                            dblPerdidaPeriodo = dblPerdidaPeriodo - dblTotalNivel0
                                            dblPerdidaPeriodo2 = dblPerdidaPeriodo2 - dblTotalNivel02
                                            dblPerdidaPeriodo3 = dblPerdidaPeriodo3 - dblTotalNivel03
                                            dblPerdidaPeriodo4 = dblPerdidaPeriodo4 - dblTotalNivel04
                                            dblPerdidaPeriodo5 = dblPerdidaPeriodo5 - dblTotalNivel05
                                        End If
                                        intConteo = intConteo + 1

                                        strHtml &= SubtotalReport(2, strNivel2, dblTotalNivel2, dblTotalNivel22, dblTotalNivel23, dblTotalNivel24, dblTotalNivel25)
                                        strHtml &= SubtotalReport(1, strNivel1, dblTotalNivel1, dblTotalNivel12, dblTotalNivel13, dblTotalNivel14, dblTotalNivel15)
                                        strHtml &= SubtotalReport(0, strNivel0, dblTotalNivel0, dblTotalNivel02, dblTotalNivel03, dblTotalNivel04, dblTotalNivel05)

                                        'If REA.GetString("Cuenta3") = "310101" Then
                                        '    Dim dblResultadoEjercicio As Double = ResultadoEjercicioReport(frm.FechaInicio, frm.FechaFin)

                                        '    strHtml &= PrimeraLineaReporte(3, REA.GetString("Nivel0"), REA.GetString("Nivel1"), REA.GetString("Nivel2"), REA.GetString("Nivel3"), dblResultadoEjercicio, True)
                                        '    If intConteo = 2 Then
                                        '        str2Niveles = strNivel0
                                        '        dbl2Totales = dblTotalNivel0
                                        '    End If
                                        '    dblTotalNivel0 = dblResultadoEjercicio
                                        '    dblTotalNivel1 = dblResultadoEjercicio
                                        '    dblTotalNivel2 = dblResultadoEjercicio
                                        'Else
                                        strHtml &= PrimeraLineaReporte(emp, 3, REA.GetString("Nivel0"), REA.GetString("Nivel1"), REA.GetString("Nivel2"), REA.GetString("Nivel3"), dblSaldoVenta, dblSaldoVenta2, dblSaldoVenta3, dblSaldoVenta4, dblSaldoVenta5, True, dbltotal:=dblPerdidaPeriodo, dbltotal2:=dblPerdidaPeriodo2, dbltotal3:=dblPerdidaPeriodo3, dbltotal4:=dblPerdidaPeriodo4, dbltotal5:=dblPerdidaPeriodo5, intValidar2:=intValidar)
                                        If intConteo = 2 Then
                                            str2Niveles = strNivel0
                                            dbl2Totales = dblTotalNivel0
                                            dbl2Totales2 = dblTotalNivel02
                                            dbl2Totales3 = dblTotalNivel03
                                            dbl2Totales4 = dblTotalNivel04
                                            dbl2Totales5 = dblTotalNivel05
                                        End If
                                        dblTotalNivel0 = dblSaldoVenta
                                        dblTotalNivel02 = dblSaldoVenta2
                                        dblTotalNivel03 = dblSaldoVenta3
                                        dblTotalNivel04 = dblSaldoVenta4
                                        dblTotalNivel05 = dblSaldoVenta5
                                        dblTotalNivel1 = dblSaldoVenta
                                        dblTotalNivel12 = dblSaldoVenta2
                                        dblTotalNivel13 = dblSaldoVenta3
                                        dblTotalNivel14 = dblSaldoVenta4
                                        dblTotalNivel15 = dblSaldoVenta5
                                        dblTotalNivel2 = dblSaldoVenta
                                        dblTotalNivel22 = dblSaldoVenta2
                                        dblTotalNivel23 = dblSaldoVenta3
                                        dblTotalNivel24 = dblSaldoVenta4
                                        dblTotalNivel25 = dblSaldoVenta5
                                        'End If
                                    End If
                                End If
                                strNivel0 = REA.GetString("Nivel0")
                                strNivel1 = REA.GetString("Nivel1")
                                strNivel2 = REA.GetString("Nivel2")
                            Loop

                            'Dim dblResultadoEjercicio As Double = ResultadoEjercicioReport(frm.FechaInicio, frm.FechaFin)

                            dblTotalNivel0 = dblTotalNivel0
                            dblTotalNivel02 = dblTotalNivel02
                            dblTotalNivel03 = dblTotalNivel03
                            dblTotalNivel04 = dblTotalNivel04
                            dblTotalNivel05 = dblTotalNivel05 '+ dblResultadoEjercicio
                            dblTotalNivel1 = dblTotalNivel1
                            dblTotalNivel12 = dblTotalNivel12
                            dblTotalNivel13 = dblTotalNivel13
                            dblTotalNivel14 = dblTotalNivel14
                            dblTotalNivel15 = dblTotalNivel15 '+ dblResultadoEjercicio
                            dblTotalNivel2 = dblTotalNivel2
                            dblTotalNivel22 = dblTotalNivel22
                            dblTotalNivel23 = dblTotalNivel23
                            dblTotalNivel24 = dblTotalNivel24
                            dblTotalNivel25 = dblTotalNivel25 '+ dblResultadoEjercicio
                            'strHtml &= "<tr>"
                            'strHtml &= "<td class='centro'>" & EspacioHtml(15) & "Actual Results" & "</td>"
                            'strHtml &= "<td class='derecha'>" & dblResultadoEjercicio.ToString(FORMATO_MONEDA) & "</td>"
                            'strHtml &= "</tr>"

                            strHtml &= SubtotalReport(1, strNivel1, dblTotalNivel1, dblTotalNivel12, dblTotalNivel13, dblTotalNivel14, dblTotalNivel15)
                            strHtml &= SubtotalReport(0, strNivel0, dblTotalNivel0, dblTotalNivel02, dblTotalNivel03, dblTotalNivel04, dblTotalNivel05)
                            dblPerdidaPeriodo = dblPerdidaPeriodo - dblTotalNivel0
                            dblPerdidaPeriodo2 = dblPerdidaPeriodo2 - dblTotalNivel02
                            dblPerdidaPeriodo3 = dblPerdidaPeriodo3 - dblTotalNivel03
                            dblPerdidaPeriodo4 = dblPerdidaPeriodo4 - dblTotalNivel04
                            dblPerdidaPeriodo5 = dblPerdidaPeriodo5 - dblTotalNivel05

                    End Select
                    strHtml &= "<tr>"
                    strHtml &= "<td class='titulo'> </td>"
                    strHtml &= "<td class='titulo'> </td>"
                    strHtml &= "<td class='titulo'> </td>"
                    strHtml &= "</tr>"
                    strHtml &= "<tr>"
                    If dblPerdidaPeriodo < 0 Then
                        strHtml &= "<td class='titulo'> PERIOD LOSSES </td>"
                    Else
                        strHtml &= "<td class='titulo'> PROFIT FOR THE PERIOD </td>"
                    End If

                    strHtml &= "<td class='titulo' style='text-align: right'><b>" & dblPerdidaPeriodo.ToString(FORMATO_MONEDA) & "</td>"
                    strHtml &= "<td class='titulo' style='text-align: right'><b>" & dblPerdidaPeriodo2.ToString(FORMATO_MONEDA) & "</td>"
                    strHtml &= "<td class='titulo' style='text-align: right'><b>" & dblPerdidaPeriodo3.ToString(FORMATO_MONEDA) & "</td>"
                    strHtml &= "<td class='titulo' style='text-align: right'><b>" & dblPerdidaPeriodo4.ToString(FORMATO_MONEDA) & "</td>"
                    Dim totalPerdida = Math.Round((dblPerdidaPeriodo + dblPerdidaPeriodo2 + dblPerdidaPeriodo3 + dblPerdidaPeriodo4 + dblPerdidaPeriodo5), 2)
                    strHtml &= "<td class='titulo' style='text-align: right'><b>" & totalPerdida.ToString(FORMATO_MONEDA) & "</td>"
                    strHtml &= "<td class='titulo' style='text-align: right'><b>" & dblPerdidaPeriodo5.ToString(FORMATO_MONEDA) & "</td>"
                    strHtml &= "<td class='titulo' style='text-align: right'><b>" & (totalPerdida - dblPerdidaPeriodo5).ToString(FORMATO_MONEDA) & "</td>"
                    strHtml &= "</tr>"
                    strHtml &= "</table>"
                    strHtml &= "<br/>"
                    strHtml &= "</body>"
                    strHtml &= "</html>"
                    Print(f, strHtml)
                    FileClose(f)
                    crport.MostarReporte(strTemp)
                End If


            End If


        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try

    End Sub
#End Region

End Class
