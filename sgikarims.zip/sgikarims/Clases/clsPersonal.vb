NameSpace Manejo_Tablas
Public Class clsPersonal

#Region "Miembros"

	Public Enum TipoReset
		Full = 1
		Data = 2
	End Enum

	Public Structure PERSONAL
		Dim Simon_REGISTRO as Boolean
		Dim MERROR as String
		Dim PER_SISEMP	 As Integer
		Dim PER_CODIGO	 As Integer
		Dim PER_USUARIO	 As String
		Dim PER_CLAVE	 As String
		Dim PER_APELLIDO1	 As String
		Dim PER_APELLIDO2	 As String
		Dim PER_NOMBRE1	 As String
		Dim PER_NOMBRE2	 As String
		Dim PER_PUESTO	 As Integer
		Dim PER_CORREO	 As String
		Dim PER_FIRMA	 As Object
		Dim PER_NIVEL	 As Integer
		Dim PER_PAIS	 As Integer
		Dim PER_ESTADO	 As Integer
		Dim PER_JEFE	 As Integer
		Dim PER_FECHA	 As MYSQLDATETIME
	End Structure

	private m_int_per_sisemp As Integer
	private m_int_per_codigo As Integer
	private m_str_per_usuario As String
	private m_str_per_clave As String
	private m_str_per_apellido1 As String
	private m_str_per_apellido2 As String
	private m_str_per_nombre1 As String
	private m_str_per_nombre2 As String
	private m_int_per_puesto As Integer
	private m_str_per_correo As String
	private m_obj_per_firma As Object
	private m_int_per_nivel As Integer
	private m_int_per_pais As Integer
	private m_int_per_estado As Integer
	private m_int_per_jefe As Integer
	private m_dt_per_fecha As MYSQLDATETIME
	Private MENSAJE As String
	Private Cantidad_de_la_Clase As Integer = 0
	Private CON As MySqlConnection
	Private TRA As MySqlTransaction
	Private REA As MysqlDataReader
	Private CONstr As String
#End Region


#Region "Propiedades"

	Public Property PER_SISEMP() As Integer
	Get
		return m_int_per_sisemp
	End Get
	Set (ByVal Value As Integer)
		m_int_per_sisemp = Value 
	End Set
	End Property

	Public Property PER_CODIGO() As Integer
	Get
		return m_int_per_codigo
	End Get
	Set (ByVal Value As Integer)
		m_int_per_codigo = Value 
	End Set
	End Property

	Public Property PER_USUARIO() As String
	Get
		return m_str_per_usuario.Trim()
	End Get
	Set (ByVal Value As String)
		m_str_per_usuario = Value 
	End Set
	End Property

	Public Property PER_CLAVE() As String
	Get
		return m_str_per_clave.Trim()
	End Get
	Set (ByVal Value As String)
		m_str_per_clave = Value 
	End Set
	End Property

	Public Property PER_APELLIDO1() As String
	Get
		return m_str_per_apellido1.Trim()
	End Get
	Set (ByVal Value As String)
		m_str_per_apellido1 = Value 
	End Set
	End Property

	Public Property PER_APELLIDO2() As String
	Get
		return m_str_per_apellido2.Trim()
	End Get
	Set (ByVal Value As String)
		m_str_per_apellido2 = Value 
	End Set
	End Property

	Public Property PER_NOMBRE1() As String
	Get
		return m_str_per_nombre1.Trim()
	End Get
	Set (ByVal Value As String)
		m_str_per_nombre1 = Value 
	End Set
	End Property

	Public Property PER_NOMBRE2() As String
	Get
		return m_str_per_nombre2.Trim()
	End Get
	Set (ByVal Value As String)
		m_str_per_nombre2 = Value 
	End Set
	End Property

	Public Property PER_PUESTO() As Integer
	Get
		return m_int_per_puesto
	End Get
	Set (ByVal Value As Integer)
		m_int_per_puesto = Value 
	End Set
	End Property

	Public Property PER_CORREO() As String
	Get
		return m_str_per_correo.Trim()
	End Get
	Set (ByVal Value As String)
		m_str_per_correo = Value 
	End Set
	End Property

	Public Property PER_FIRMA() As Object
	Get
		return m_obj_per_firma
	End Get
	Set (ByVal Value As Object)
		m_obj_per_firma = Value 
	End Set
	End Property

	Public Property PER_NIVEL() As Integer
	Get
		return m_int_per_nivel
	End Get
	Set (ByVal Value As Integer)
		m_int_per_nivel = Value 
	End Set
	End Property

	Public Property PER_PAIS() As Integer
	Get
		return m_int_per_pais
	End Get
	Set (ByVal Value As Integer)
		m_int_per_pais = Value 
	End Set
	End Property

	Public Property PER_ESTADO() As Integer
	Get
		return m_int_per_estado
	End Get
	Set (ByVal Value As Integer)
		m_int_per_estado = Value 
	End Set
	End Property

	Public Property PER_JEFE() As Integer
	Get
		return m_int_per_jefe
	End Get
	Set (ByVal Value As Integer)
		m_int_per_jefe = Value 
	End Set
	End Property

	Public Property PER_FECHA() As MYSQLDATETIME
	Get
		return m_dt_per_fecha
	End Get
	Set (ByVal Value As MYSQLDATETIME)
		m_dt_per_fecha = Value 
	End Set
	End Property

	Public WriteOnly Property per_fecha_NET() As DateTime
	Set (ByVal Value As DateTime)
		m_dt_per_fecha = new MySQLDATETIME(Value.Year, Value.Month, Value.Day, Value.Hour, Value.Minute, Value.Second) 
	End Set
	End Property

	Public ReadOnly Property CantRecorSet() as Integer
		Get
			Return Cantidad_de_la_Clase
		End Get
	End Property

	Public Property 	CONEXION()	 As String
		Set (ByVal VALUE as string)
			CONstr = VALUE
			Try
				MENSAJE = ""
				If isnothing(CON) = true then
					CON = new MySqlConnection
				End If
				If CON.State = ConnectionState.Open then
					CON.Close()
				End If
				CON.ConnectionString = CONstr
				CON.Open()
			Catch MyEX as MySqlException
				MENSAJE = "BiblioTABLAS - clsPersonal - CONEXION MyError=" & MyEX.ToString
			Catch EX as Exception
				MENSAJE = "BiblioTABLAS - clsPersonal - CONEXION Error=" & EX.ToString
			End Try
		End Set
		Get
			Return CONstr
		End Get
	End Property

	Public WriteOnly Property 	TRANSACCION()	 As MySqlTransaction
	Set (ByVal VALUE as MySqlTransaction)
		TRA = VALUE
	End Set
	End Property

	Public ReadOnly Property 	MERROR()	 As String
		Get
			Return MENSAJE
		End Get
	End Property

#End Region


#Region "Funciones Publicas"

	Public Sub New()
		PER_SISEMP = 0
		PER_CODIGO = 0
		PER_USUARIO = ""
		PER_CLAVE = ""
		PER_APELLIDO1 = ""
		PER_APELLIDO2 = ""
		PER_NOMBRE1 = ""
		PER_NOMBRE2 = ""
		PER_PUESTO = 0
		PER_CORREO = ""
		PER_FIRMA = Nothing
		PER_NIVEL = 0
		PER_PAIS = 0
		PER_ESTADO = 0
		PER_JEFE = 0
		PER_FECHA = New MySqlDateTime(0, 0, 0, 0, 0, 0)
	End Sub

	Public Sub Reset(Optional ByVal Tipo as TipoReset = TipoReset.Data)
		Try
			INIT_LLAVE()
			INIT()
			If Tipo = clsPersonal.TipoReset.Full Then
				Dispose()
			End If
		Catch Ex as Exception
			MENSAJE = "BiblioTABLAS - clsPersonal - RESET No se podo hacer el Reset de la Clase" & Ex.ToString
		End Try
	End Sub

	Public Sub Dispose()
		Try
			If IsNothing(REA) = False then
				Rea.Close
			End If
			If isnothing(CON) = False Then
				if CON.State = ConnectionState.Open then
					CON.Close()
				End If
			End If
			CON = Nothing
			REA = Nothing
		Catch EX as Exception
		End Try
	End Sub

	Private Sub INIT()
		PER_USUARIO = ""
		PER_CLAVE = ""
		PER_APELLIDO1 = ""
		PER_APELLIDO2 = ""
		PER_NOMBRE1 = ""
		PER_NOMBRE2 = ""
		PER_PUESTO = 0
		PER_CORREO = ""
		PER_FIRMA = Nothing
		PER_NIVEL = 0
		PER_PAIS = 0
		PER_ESTADO = 0
		PER_JEFE = 0
		PER_FECHA = New MySqlDateTime(0, 0, 0, 0, 0, 0)
		Cantidad_de_la_Clase = 0
	End Sub

	Private Sub INIT_LLAVE()
		PER_SISEMP = 0
		PER_CODIGO = 0
	End Sub

Public Function PMOVE_NEXT() As Boolean

	PMOVE_NEXT = False
	INIT()
	INIT_LLAVE()
	If IsNothing(REA) = True Then
		MENSAJE = "BiblioTABLAS - clsPersonal - PMOVE_NEXT Conexi�n no definida"
		Exit Function
	End If
	Try
		If REA.Read = True Then
			If REA.IsDBNull(REA.GetOrdinal("per_sisemp")) = False Then
				M_INT_PER_SISEMP = REA.GetInt32("per_sisemp")
			Else
				M_INT_PER_SISEMP = -1
			End If
			If REA.IsDBNull(REA.GetOrdinal("per_codigo")) = False Then
				M_INT_PER_CODIGO = REA.GetInt32("per_codigo")
			Else
				M_INT_PER_CODIGO = -1
			End If
			If REA.IsDBNull(REA.GetOrdinal("per_usuario")) = False Then
				M_STR_PER_USUARIO = REA.GetString("per_usuario")
			Else
				M_STR_PER_USUARIO = "NULL"
			End If
			If REA.IsDBNull(REA.GetOrdinal("per_clave")) = False Then
				M_STR_PER_CLAVE = REA.GetString("per_clave")
			Else
				M_STR_PER_CLAVE = "NULL"
			End If
			If REA.IsDBNull(REA.GetOrdinal("per_apellido1")) = False Then
				M_STR_PER_APELLIDO1 = REA.GetString("per_apellido1")
			Else
				M_STR_PER_APELLIDO1 = "NULL"
			End If
			If REA.IsDBNull(REA.GetOrdinal("per_apellido2")) = False Then
				M_STR_PER_APELLIDO2 = REA.GetString("per_apellido2")
			Else
				M_STR_PER_APELLIDO2 = "NULL"
			End If
			If REA.IsDBNull(REA.GetOrdinal("per_nombre1")) = False Then
				M_STR_PER_NOMBRE1 = REA.GetString("per_nombre1")
			Else
				M_STR_PER_NOMBRE1 = "NULL"
			End If
			If REA.IsDBNull(REA.GetOrdinal("per_nombre2")) = False Then
				M_STR_PER_NOMBRE2 = REA.GetString("per_nombre2")
			Else
				M_STR_PER_NOMBRE2 = "NULL"
			End If
			If REA.IsDBNull(REA.GetOrdinal("per_puesto")) = False Then
				M_INT_PER_PUESTO = REA.GetInt32("per_puesto")
			Else
				M_INT_PER_PUESTO = -1
			End If
			If REA.IsDBNull(REA.GetOrdinal("per_correo")) = False Then
				M_STR_PER_CORREO = REA.GetString("per_correo")
			Else
				M_STR_PER_CORREO = "NULL"
			End If
			If REA.IsDBNull(REA.GetOrdinal("per_firma")) = False Then
				Dim LTam As Long
				LTam = REA.GetBytes(REA.GetOrdinal("per_firma"), 0, Nothing, 0, 0)
				Dim VecByte(CInt(LTam)) As Byte
				LTam = REA.GetBytes(REA.GetOrdinal("per_firma"), 0, VecByte, 0, CInt(LTam))
				M_OBJ_PER_FIRMA =  VecByte
			End If
			If REA.IsDBNull(REA.GetOrdinal("per_nivel")) = False Then
				M_INT_PER_NIVEL = REA.GetInt32("per_nivel")
			Else
				M_INT_PER_NIVEL = -1
			End If
			If REA.IsDBNull(REA.GetOrdinal("per_pais")) = False Then
				M_INT_PER_PAIS = REA.GetInt32("per_pais")
			Else
				M_INT_PER_PAIS = -1
			End If
			If REA.IsDBNull(REA.GetOrdinal("per_estado")) = False Then
				M_INT_PER_ESTADO = REA.GetInt32("per_estado")
			Else
				M_INT_PER_ESTADO = -1
			End If
			If REA.IsDBNull(REA.GetOrdinal("per_jefe")) = False Then
				M_INT_PER_JEFE = REA.GetInt32("per_jefe")
			Else
				M_INT_PER_JEFE = -1
			End If
			If REA.IsDBNull(REA.GetOrdinal("per_fecha")) = False Then
				M_DT_PER_FECHA = REA.GetMySQLDateTime("per_fecha")
			End If
			PMOVE_NEXT = True
		Else
			REA.Close()
			REA = Nothing
		End If
	Catch MYEX As MySqlException
		MENSAJE = "BiblioTABLAS - clsPersonal - PMOVE_NEXT Error=" & MYEX.ToString
	Catch EX As Exception
		MENSAJE = "BiblioTABLAS - clsPersonal - PMOVE_NEXT Error=" & EX.ToString
	End Try
End Function

Public Function PSELECT_RECORDSET(Optional ByVal CONDICION As String = "", Optional ByVal ORDENAMIENTO As String = "") As Boolean
	Dim COM As MySqlCommand
	Dim SQL As String
	DIM SQL1 as String

	PSELECT_RECORDSET = False
	If IsNothing(REA) = False Then
		REA.CLOSE()
		REA = Nothing
	End If
	If IsNothing(CON) = True Then
		MENSAJE = "BiblioTABLAS - clsPersonal - PSELECT_RECORDSET Conexi�n no definida"
		Exit Function
	End If
	If CON.State = ConnectionState.Closed Or CON.State = ConnectionState.Broken Then
		If CON.ConnectionString.Length <> 0 Then
			Try
				CON.Open()
			Catch MYEX As MySqlException
				MENSAJE = "BiblioTABLAS - TclsPersonal - PSELECT_RECORDSET Error#=" & MYEX.Number & " " & MYEX.ToString
				Exit Function
			Catch EX As Exception
				MENSAJE = "BiblioTABLAS - TclsPersonal - PSELECT_RECORDSET Error=" & EX.ToString
				Exit Function
			End Try
		Else
			MENSAJE = "BiblioTABLAS - TclsPersonal - PSELECT_RECORDSET String de Conexi�n no definido"
			Exit Function
		End If
	End If

	COM = NOTHING
	Sql = "Select * from personal"
	If CONDICION.Length <> 0 Then
		Sql &= " Where " & CONDICION
	End If
	If ORDENAMIENTO.Length <> 0 Then
		Sql &= " Order By " & ORDENAMIENTO
	End If

	SQL1 = "Select Count(*) as Cuenta from personal"
	If CONDICION.Length <> 0 Then
		Sql1 &= " Where " & CONDICION
	End If
	Try
		INIT()
		INIT_LLAVE()

		COM = New MySqlCommand(SQL1,CON)
		Cantidad_de_la_Clase = CInt(COM.ExecuteScalar())
		COM.Dispose()
		COM = Nothing

		COM = New MySqlCommand(Sql, CON)
		COM.CommandType = CommandType.Text
		REA = COM.ExecuteReader
		PSELECT_RECORDSET = True
	Catch MYEX As MySqlException
		MENSAJE = "BiblioTABLAS - clsPersonal - PSELECT_RECORDSET MyError#=" & MYEX.Number & " MyError=" & MYEX.ToString
	Catch EX As Exception
		MENSAJE = "BiblioTABLAS - clsPersonal - PSELECT_RECORDSET Error=" & EX.ToString
	Finally
		If IsNothing(COM) = False Then
			COM.Dispose()
			COM = Nothing
		End If
	End Try
End Function

Public Function PSELECT(ByVal KPER_SISEMP as Integer, ByVal KPER_CODIGO as Integer) AS Boolean
	Dim READER As MySqlDataReader
	Dim COM As MySqlCommand
	Dim SQL as String

	Mensaje  = ""
	PSELECT = False
	If IsNothing(CON) = True Then
		MENSAJE = "BiblioTABLAS - clsPersonal - PSELECT Conexi�n no definida"
		Exit Function
	End If
	If CON.State = ConnectionState.Closed Or CON.State = ConnectionState.Broken Then
		If CON.ConnectionString.Length <> 0 Then
			Try
				CON.Open()
			Catch MYEX As MySqlException
				MENSAJE = "BiblioTABLAS - TclsPersonal - PSELECT Error#=" & MYEX.Number & " " & MYEX.ToString
				Exit Function
			Catch EX As Exception
				MENSAJE = "BiblioTABLAS - TclsPersonal - PSELECT Error=" & EX.ToString
				Exit Function
			End Try
		Else
			MENSAJE = "BiblioTABLAS - TclsPersonal - PSELECT String de Conexi�n no definido"
			Exit Function
		End If
	End If

	SQL = "SELECT * FROM personal WHERE PER_SISEMP = ?P1 AND PER_CODIGO = ?P2"
	READER = NOTHING
	COM = NOTHING
	TRY
		INIT()
		COM = New MySqlCommand(SQL,CON)
		COM.CommandType = CommandType.Text
		COM.Parameters.AddWithValue("?P1",KPER_SISEMP)
		COM.Parameters.AddWithValue("?P2",KPER_CODIGO)
		READER = COM.ExecuteReader(CommandBehavior.SingleRow)
		READER.READ()
		If READER.HasRows = True Then
			If READER.IsDBNull(READER.GetOrdinal("per_sisemp")) = False Then
				M_INT_PER_SISEMP = READER.GetInt32("per_sisemp")
			Else
				M_INT_PER_SISEMP = -1
			End If
			If READER.IsDBNull(READER.GetOrdinal("per_codigo")) = False Then
				M_INT_PER_CODIGO = READER.GetInt32("per_codigo")
			Else
				M_INT_PER_CODIGO = -1
			End If
			If READER.IsDBNull(READER.GetOrdinal("per_usuario")) = False Then
				M_STR_PER_USUARIO = READER.GetString("per_usuario")
			Else
				M_STR_PER_USUARIO = "NULL"
			End If
			If READER.IsDBNull(READER.GetOrdinal("per_clave")) = False Then
				M_STR_PER_CLAVE = READER.GetString("per_clave")
			Else
				M_STR_PER_CLAVE = "NULL"
			End If
			If READER.IsDBNull(READER.GetOrdinal("per_apellido1")) = False Then
				M_STR_PER_APELLIDO1 = READER.GetString("per_apellido1")
			Else
				M_STR_PER_APELLIDO1 = "NULL"
			End If
			If READER.IsDBNull(READER.GetOrdinal("per_apellido2")) = False Then
				M_STR_PER_APELLIDO2 = READER.GetString("per_apellido2")
			Else
				M_STR_PER_APELLIDO2 = "NULL"
			End If
			If READER.IsDBNull(READER.GetOrdinal("per_nombre1")) = False Then
				M_STR_PER_NOMBRE1 = READER.GetString("per_nombre1")
			Else
				M_STR_PER_NOMBRE1 = "NULL"
			End If
			If READER.IsDBNull(READER.GetOrdinal("per_nombre2")) = False Then
				M_STR_PER_NOMBRE2 = READER.GetString("per_nombre2")
			Else
				M_STR_PER_NOMBRE2 = "NULL"
			End If
			If READER.IsDBNull(READER.GetOrdinal("per_puesto")) = False Then
				M_INT_PER_PUESTO = READER.GetInt32("per_puesto")
			Else
				M_INT_PER_PUESTO = -1
			End If
			If READER.IsDBNull(READER.GetOrdinal("per_correo")) = False Then
				M_STR_PER_CORREO = READER.GetString("per_correo")
			Else
				M_STR_PER_CORREO = "NULL"
			End If
			If READER.IsDBNull(READER.GetOrdinal("per_firma")) = False Then
				Dim LTam As Long
				LTam = READER.GetBytes(READER.GetOrdinal("per_firma"), 0, Nothing, 0, 0)
				Dim VecByte(CInt(LTam)) As Byte
				LTam = READER.GetBytes(READER.GetOrdinal("per_firma"), 0, VecByte, 0, CInt(LTam))
				M_OBJ_PER_FIRMA =  VecByte
			End If
			If READER.IsDBNull(READER.GetOrdinal("per_nivel")) = False Then
				M_INT_PER_NIVEL = READER.GetInt32("per_nivel")
			Else
				M_INT_PER_NIVEL = -1
			End If
			If READER.IsDBNull(READER.GetOrdinal("per_pais")) = False Then
				M_INT_PER_PAIS = READER.GetInt32("per_pais")
			Else
				M_INT_PER_PAIS = -1
			End If
			If READER.IsDBNull(READER.GetOrdinal("per_estado")) = False Then
				M_INT_PER_ESTADO = READER.GetInt32("per_estado")
			Else
				M_INT_PER_ESTADO = -1
			End If
			If READER.IsDBNull(READER.GetOrdinal("per_jefe")) = False Then
				M_INT_PER_JEFE = READER.GetInt32("per_jefe")
			Else
				M_INT_PER_JEFE = -1
			End If
			If READER.IsDBNull(READER.GetOrdinal("per_fecha")) = False Then
				M_DT_PER_FECHA = READER.GetMySQLDateTime("per_fecha")
			End If
		Else
			MENSAJE = ""
			Exit Function
		End IF
		READER.CLOSE()
		COM.DISPOSE()
		READER = NOTHING
		COM = NOTHING
		PSELECT = TRUE
	Catch MYEX As MySqlException
		MENSAJE = "BiblioTABLAS - clsPersonal - PSELECT MyError#=" & MYEX.Number & " MyError=" & MYEX.ToString
	Catch EX As Exception
		MENSAJE = "BiblioTABLAS - clsPersonal - PSELECT Error=" & EX.ToString
	Finally
		If IsNothing(READER) = False Then
			READER.Close()
			READER = Nothing
		End If
		If IsNothing(COM) = False Then
			COM.Dispose()
			COM = Nothing
		End If
	End Try
End Function

Public Function PSELECT_CONDICION(BYVAL CONDICION AS STRING) AS Boolean

	Dim READER As MySqlDataReader
	Dim COM As MySqlCommand
	Dim SQL as String

	Mensaje  = ""
	PSELECT_CONDICION = False
	If IsNothing(CON) = True Then
		MENSAJE = "BiblioTABLAS - clsPersonal - PSELECT_CONDICION Conexi�n no definida"
		Exit Function
	End If
	If CON.State = ConnectionState.Closed Or CON.State = ConnectionState.Broken Then
		If CON.ConnectionString.Length <> 0 Then
			Try
				CON.Open()
			Catch MYEX As MySqlException
				MENSAJE = "BiblioTABLAS - TclsPersonal - PSELECT_CONDICION Error#=" & MYEX.Number & " " & MYEX.ToString
				Exit Function
			Catch EX As Exception
				MENSAJE = "BiblioTABLAS - TclsPersonal - PSELECT_CONDICION Error=" & EX.ToString
				Exit Function
			End Try
		Else
			MENSAJE = "BiblioTABLAS - TclsPersonal - PSELECT_CONDICION String de Conexi�n no definido"
			Exit Function
		End If
	End If

	SQL = "SELECT * FROM personal WHERE " & CONDICION
	READER = NOTHING
	COM = NOTHING
	TRY
		INIT()
		COM = New MySqlCommand(SQL,CON)
		COM.CommandType = CommandType.Text
		READER = COM.ExecuteReader(CommandBehavior.SingleRow)
		READER.READ()
		If READER.HasRows = True Then
			If READER.IsDBNull(READER.GetOrdinal("per_sisemp")) = False Then
				M_INT_PER_SISEMP = READER.GetInt32("per_sisemp")
			Else
				M_INT_PER_SISEMP = -1
			End If
			If READER.IsDBNull(READER.GetOrdinal("per_codigo")) = False Then
				M_INT_PER_CODIGO = READER.GetInt32("per_codigo")
			Else
				M_INT_PER_CODIGO = -1
			End If
			If READER.IsDBNull(READER.GetOrdinal("per_usuario")) = False Then
				M_STR_PER_USUARIO = READER.GetString("per_usuario")
			Else
				M_STR_PER_USUARIO = "NULL"
			End If
			If READER.IsDBNull(READER.GetOrdinal("per_clave")) = False Then
				M_STR_PER_CLAVE = READER.GetString("per_clave")
			Else
				M_STR_PER_CLAVE = "NULL"
			End If
			If READER.IsDBNull(READER.GetOrdinal("per_apellido1")) = False Then
				M_STR_PER_APELLIDO1 = READER.GetString("per_apellido1")
			Else
				M_STR_PER_APELLIDO1 = "NULL"
			End If
			If READER.IsDBNull(READER.GetOrdinal("per_apellido2")) = False Then
				M_STR_PER_APELLIDO2 = READER.GetString("per_apellido2")
			Else
				M_STR_PER_APELLIDO2 = "NULL"
			End If
			If READER.IsDBNull(READER.GetOrdinal("per_nombre1")) = False Then
				M_STR_PER_NOMBRE1 = READER.GetString("per_nombre1")
			Else
				M_STR_PER_NOMBRE1 = "NULL"
			End If
			If READER.IsDBNull(READER.GetOrdinal("per_nombre2")) = False Then
				M_STR_PER_NOMBRE2 = READER.GetString("per_nombre2")
			Else
				M_STR_PER_NOMBRE2 = "NULL"
			End If
			If READER.IsDBNull(READER.GetOrdinal("per_puesto")) = False Then
				M_INT_PER_PUESTO = READER.GetInt32("per_puesto")
			Else
				M_INT_PER_PUESTO = -1
			End If
			If READER.IsDBNull(READER.GetOrdinal("per_correo")) = False Then
				M_STR_PER_CORREO = READER.GetString("per_correo")
			Else
				M_STR_PER_CORREO = "NULL"
			End If
			If READER.IsDBNull(READER.GetOrdinal("per_firma")) = False Then
				Dim LTam As Long
				LTam = READER.GetBytes(READER.GetOrdinal("per_firma"), 0, Nothing, 0, 0)
				Dim VecByte(CInt(LTam)) As Byte
				LTam = READER.GetBytes(READER.GetOrdinal("per_firma"), 0, VecByte, 0, CInt(LTam))
				M_OBJ_PER_FIRMA =  VecByte
			End If
			If READER.IsDBNull(READER.GetOrdinal("per_nivel")) = False Then
				M_INT_PER_NIVEL = READER.GetInt32("per_nivel")
			Else
				M_INT_PER_NIVEL = -1
			End If
			If READER.IsDBNull(READER.GetOrdinal("per_pais")) = False Then
				M_INT_PER_PAIS = READER.GetInt32("per_pais")
			Else
				M_INT_PER_PAIS = -1
			End If
			If READER.IsDBNull(READER.GetOrdinal("per_estado")) = False Then
				M_INT_PER_ESTADO = READER.GetInt32("per_estado")
			Else
				M_INT_PER_ESTADO = -1
			End If
			If READER.IsDBNull(READER.GetOrdinal("per_jefe")) = False Then
				M_INT_PER_JEFE = READER.GetInt32("per_jefe")
			Else
				M_INT_PER_JEFE = -1
			End If
			If READER.IsDBNull(READER.GetOrdinal("per_fecha")) = False Then
				M_DT_PER_FECHA = READER.GetMySQLDateTime("per_fecha")
			End If
			PSelect_Condicion = True
		Else
			MENSAJE = ""
			Exit Function
		End IF
		READER.CLOSE()
		COM.DISPOSE()
		READER = NOTHING
		COM = NOTHING
		PSELECT_CONDICION = TRUE
	Catch MYEX As MySqlException
		MENSAJE = "BiblioTABLAS - clsPersonal - PSELECT_CONDICION MyError#=" & MYEX.Number & " MyError=" & MYEX.ToString
	Catch EX As Exception
		MENSAJE = "BiblioTABLAS - clsPersonal - PSELECT_CONDICION Error=" & EX.ToString
	Finally
		If IsNothing(READER) = False Then
			READER.Close()
			READER = Nothing
		End If
		If IsNothing(COM) = False Then
			COM.Dispose()
			COM = Nothing
		End If
	End Try
End Function

Public Function PSELECT_READER(ByRef READER As MySqlDataReader, _
				Optional ByVal CAMPOS As String = "", _
				Optional ByVal CONDICION As String = "", _
				Optional ByVal ORDENAMIENTO As String = "") AS Boolean

	Dim COM As MySqlCommand
	Dim SQL as String
	Dim SQL1 as String

	Mensaje  = ""
	PSELECT_READER = False
	If IsNothing(CON) = True Then
		MENSAJE = "BiblioTABLAS - clsPersonal - PSELECT_READER Conexi�n no definida"
		Exit Function
	End If
	If CON.State = ConnectionState.Closed Or CON.State = ConnectionState.Broken Then
		If CON.ConnectionString.Length <> 0 Then
			Try
				CON.Open()
			Catch MYEX As MySqlException
				MENSAJE = "BiblioTABLAS - TclsPersonal - PSELECT_READER Error#=" & MYEX.Number & " " & MYEX.ToString
				Exit Function
			Catch EX As Exception
				MENSAJE = "BiblioTABLAS - TclsPersonal - PSELECT_READER Error=" & EX.ToString
				Exit Function
			End Try
		Else
			MENSAJE = "BiblioTABLAS - TclsPersonal - PSELECT_READER String de Conexi�n no definido"
			Exit Function
		End If
	End If

	If CAMPOS.Length = 0 Then
		Sql = "Select * from personal"
	Else
		Sql = "SELECT " & CAMPOS & " FROM personal"
	End If
	If CONDICION.Length <> 0 Then
		Sql &= " Where " & CONDICION
	End If
	If ORDENAMIENTO.Length <> 0 Then
		Sql &= " Order By " & ORDENAMIENTO
	End If

		Sql1 = "Select Count(*) as Cuenta from personal"
	If CONDICION.Length <> 0 Then
		Sql1 &= " Where " & CONDICION
	End If

	READER = NOTHING
	COM = NOTHING
	TRY
		INIT()
		COM = New MySqlCommand(SQL1,CON)
		Cantidad_de_la_Clase = CInt(COM.ExecuteScalar())
		COM.Dispose()
		COM = Nothing

		COM = New MySqlCommand(SQL,CON)
		COM.CommandType = CommandType.Text
		READER = COM.ExecuteReader()
		COM.DISPOSE()
		COM = NOTHING
		PSELECT_READER = TRUE
	Catch MYEX As MySqlException
		MENSAJE = "BiblioTABLAS - clsPersonal - PSELECT_READER MyError#=" & MYEX.Number & " MyError=" & MYEX.ToString
	Catch EX As Exception
		MENSAJE = "BiblioTABLAS - clsPersonal - PSELECT_READER Error=" & EX.ToString
	Finally
		If IsNothing(COM) = False Then
			COM.Dispose()
			COM = Nothing
		End If
	End Try
End Function

Public Function PINSERT() AS Boolean
	Dim COM As MySqlCommand
	Dim SQL as String

	MENSAJE = ""
	PINSERT = False
	If IsNothing(CON) = True Then
		MENSAJE = "BiblioTABLAS - clsPersonal - PINSERT Conexi�n no definida"
		Exit Function
	End If
	If CON.State = ConnectionState.Closed Or CON.State = ConnectionState.Broken Then
		If CON.ConnectionString.Length <> 0 Then
			Try
				CON.Open()
			Catch MYEX As MySqlException
				MENSAJE = "BiblioTABLAS - TclsPersonal - PINSERT Error#=" & MYEX.Number & " " & MYEX.ToString
				Exit Function
			Catch EX As Exception
				MENSAJE = "BiblioTABLAS - TclsPersonal - PINSERT Error=" & EX.ToString
				Exit Function
			End Try
		Else
			MENSAJE = "BiblioTABLAS - TclsPersonal - PINSERT String de Conexi�n no definido"
			Exit Function
		End If
	End If

	COM = Nothing
	TRY
		SQL = "INSERT INTO personal (per_sisemp,per_codigo,per_usuario,per_clave,per_apellido1,per_apellido2,per_nombre1,per_nombre2,per_puesto,per_correo,per_firma,per_nivel,per_pais,per_estado,per_jefe,per_fecha) " & _
			"VALUES(?P1,?P2,?P3,?P4,?P5,?P6,?P7,?P8,?P9,?P10,?P11,?P12,?P13,?P14,?P15,?P16)"
		If IsNothing(TRA) = False Then
			COM = New MySqlCommand(Sql, tra.Connection, TRA)
		Else
			COM = New MySqlCommand(Sql, CON)
		End If
		COM.CommandType = CommandType.Text
		If m_int_per_sisemp = -1 then
			COM.Parameters.AddWithValue("?P1",DBNull.Value)
		Else
			COM.Parameters.AddWithValue("?P1",m_int_per_sisemp)
		End If
		If m_int_per_codigo = -1 then
			COM.Parameters.AddWithValue("?P2",DBNull.Value)
		Else
			COM.Parameters.AddWithValue("?P2",m_int_per_codigo)
		End If
		If m_str_per_usuario.ToUpper = "NULL" then
			COM.Parameters.AddWithValue("?P3",DBNull.Value)
		Else
			COM.Parameters.AddWithValue("?P3",m_str_per_usuario)
		End If
		If m_str_per_clave.ToUpper = "NULL" then
			COM.Parameters.AddWithValue("?P4",DBNull.Value)
		Else
			COM.Parameters.AddWithValue("?P4",m_str_per_clave)
		End If
		If m_str_per_apellido1.ToUpper = "NULL" then
			COM.Parameters.AddWithValue("?P5",DBNull.Value)
		Else
			COM.Parameters.AddWithValue("?P5",m_str_per_apellido1)
		End If
		If m_str_per_apellido2.ToUpper = "NULL" then
			COM.Parameters.AddWithValue("?P6",DBNull.Value)
		Else
			COM.Parameters.AddWithValue("?P6",m_str_per_apellido2)
		End If
		If m_str_per_nombre1.ToUpper = "NULL" then
			COM.Parameters.AddWithValue("?P7",DBNull.Value)
		Else
			COM.Parameters.AddWithValue("?P7",m_str_per_nombre1)
		End If
		If m_str_per_nombre2.ToUpper = "NULL" then
			COM.Parameters.AddWithValue("?P8",DBNull.Value)
		Else
			COM.Parameters.AddWithValue("?P8",m_str_per_nombre2)
		End If
		If m_int_per_puesto = -1 then
			COM.Parameters.AddWithValue("?P9",DBNull.Value)
		Else
			COM.Parameters.AddWithValue("?P9",m_int_per_puesto)
		End If
		If m_str_per_correo.ToUpper = "NULL" then
			COM.Parameters.AddWithValue("?P10",DBNull.Value)
		Else
			COM.Parameters.AddWithValue("?P10",m_str_per_correo)
		End If
		COM.Parameters.AddWithValue("?P11",m_obj_per_firma)
		If m_int_per_nivel = -1 then
			COM.Parameters.AddWithValue("?P12",DBNull.Value)
		Else
			COM.Parameters.AddWithValue("?P12",m_int_per_nivel)
		End If
		If m_int_per_pais = -1 then
			COM.Parameters.AddWithValue("?P13",DBNull.Value)
		Else
			COM.Parameters.AddWithValue("?P13",m_int_per_pais)
		End If
		If m_int_per_estado = -1 then
			COM.Parameters.AddWithValue("?P14",DBNull.Value)
		Else
			COM.Parameters.AddWithValue("?P14",m_int_per_estado)
		End If
		If m_int_per_jefe = -1 then
			COM.Parameters.AddWithValue("?P15",DBNull.Value)
		Else
			COM.Parameters.AddWithValue("?P15",m_int_per_jefe)
		End If
		If m_dt_per_fecha.IsValidDateTime = False then
			COM.Parameters.AddWithValue("?P16",DBNull.Value)
		Else
			COM.Parameters.AddWithValue("?P16",m_dt_per_fecha.value)
		End If
		COM.ExecuteNonQuery()
		COM.Dispose()
		COM = Nothing
		PINSERT = True
	Catch MYEX As MySqlException
		MENSAJE = "BiblioTABLAS - clsPersonal - PINSERT MyError#=" & MYEX.Number & " MyError=" & MYEX.ToString
	Catch ex As Exception
		MENSAJE = "BiblioTABLAS - clsPersonal - PINSERT Error=" & ex.ToString
	Finally
		If IsNothing(COM) = False Then
			COM.Dispose()
			COM = Nothing
		End If
	End Try
End Function

Public Function PDELETE(Optional ByVal Condicion as String = "") AS Boolean

	Dim COM As MySqlCommand
	Dim SQL as String

	MENSAJE = ""
	PDELETE = False
	If IsNothing(CON) = True Then
		MENSAJE = "BiblioTABLAS - clsPersonal - PDELETE Conexi�n no definida"
		Exit Function
	End If
	If CON.State = ConnectionState.Closed Or CON.State = ConnectionState.Broken Then
		If CON.ConnectionString.Length <> 0 Then
			Try
				CON.Open()
			Catch MYEX As MySqlException
				MENSAJE = "BiblioTABLAS - TclsPersonal - PDELETE Error#=" & MYEX.Number & " " & MYEX.ToString
				Exit Function
			Catch EX As Exception
				MENSAJE = "BiblioTABLAS - TclsPersonal - PDELETE Error=" & EX.ToString
				Exit Function
			End Try
		Else
			MENSAJE = "BiblioTABLAS - TclsPersonal - PDELETE String de Conexi�n no definido"
			Exit Function
		End If
	End If

	COM = Nothing
	TRY
		If Condicion.Length <> 0 then
			SQL = "DELETE FROM personal WHERE " & Condicion
			If IsNothing(TRA) = False Then
				COM = New MySqlCommand(Sql, tra.Connection, TRA)
			Else
				COM = New MySqlCommand(Sql, CON)
			End If
			COM.CommandType = CommandType.Text
		Else
			SQL = "DELETE FROM personal WHERE per_sisemp = ?P1  AND per_codigo = ?P2 "
			If IsNothing(TRA) = False Then
				COM = New MySqlCommand(Sql, tra.Connection, TRA)
			Else
				COM = New MySqlCommand(Sql, CON)
			End If
			COM.CommandType = CommandType.Text
			COM.Parameters.AddWithValue("?P1", m_int_per_sisemp)
			COM.Parameters.AddWithValue("?P2", m_int_per_codigo)
		End If
		COM.ExecuteNonQuery()
		COM.Dispose()
		COM = Nothing
		PDELETE = True
	Catch MYEX As MySqlException
		MENSAJE = "BiblioTABLAS - clsPersonal - PDELETE MyError#=" & MYEX.Number & " MyError=" & MYEX.ToString
	Catch ex As Exception
		MENSAJE = "BiblioTABLAS - clsPersonal - PDELETE Error=" & ex.ToString
	Finally
		If IsNothing(COM) = False Then
			COM.Dispose()
			COM = Nothing
		End If
	End Try
End Function

Public Function PUPDATE() AS Boolean

	Dim COM As MySqlCommand
	Dim SQL as String

	MENSAJE = ""
	PUPDATE = False
	If IsNothing(CON) = True Then
		MENSAJE = "BiblioTABLAS - clsPersonal - PUPDATE Conexi�n no definida"
		Exit Function
	End If
	If CON.State = ConnectionState.Closed Or CON.State = ConnectionState.Broken Then
		If CON.ConnectionString.Length <> 0 Then
			Try
				CON.Open()
			Catch MYEX As MySqlException
				MENSAJE = "BiblioTABLAS - TclsPersonal - PUPDATE Error#=" & MYEX.Number & " " & MYEX.ToString
				Exit Function
			Catch EX As Exception
				MENSAJE = "BiblioTABLAS - TclsPersonal - PUPDATE Error=" & EX.ToString
				Exit Function
			End Try
		Else
			MENSAJE = "BiblioTABLAS - TclsPersonal - PUPDATE String de Conexi�n no definido"
			Exit Function
		End If
	End If

	COM = Nothing
	TRY
		SQL = "UPDATE personal SET per_usuario = ?P3, per_clave = ?P4, per_apellido1 = ?P5, per_apellido2 = ?P6, per_nombre1 = ?P7, per_nombre2 = ?P8, per_puesto = ?P9, per_correo = ?P10, per_firma = ?P11, per_nivel = ?P12, per_pais = ?P13, per_estado = ?P14, per_jefe = ?P15, per_fecha = ?P16 WHERE per_sisemp = ?P1 AND per_codigo = ?P2"
		If IsNothing(TRA) = False Then
			COM = New MySqlCommand(Sql, tra.Connection, TRA)
		Else
			COM = New MySqlCommand(Sql, CON)
		End If
		COM.CommandType = CommandType.Text
		If m_str_per_usuario.ToUpper = "NULL" then
			COM.Parameters.AddWithValue("?P3",DBNull.Value)
		Else
			COM.Parameters.AddWithValue("?P3",m_str_per_usuario)
		End If
		If m_str_per_clave.ToUpper = "NULL" then
			COM.Parameters.AddWithValue("?P4",DBNull.Value)
		Else
			COM.Parameters.AddWithValue("?P4",m_str_per_clave)
		End If
		If m_str_per_apellido1.ToUpper = "NULL" then
			COM.Parameters.AddWithValue("?P5",DBNull.Value)
		Else
			COM.Parameters.AddWithValue("?P5",m_str_per_apellido1)
		End If
		If m_str_per_apellido2.ToUpper = "NULL" then
			COM.Parameters.AddWithValue("?P6",DBNull.Value)
		Else
			COM.Parameters.AddWithValue("?P6",m_str_per_apellido2)
		End If
		If m_str_per_nombre1.ToUpper = "NULL" then
			COM.Parameters.AddWithValue("?P7",DBNull.Value)
		Else
			COM.Parameters.AddWithValue("?P7",m_str_per_nombre1)
		End If
		If m_str_per_nombre2.ToUpper = "NULL" then
			COM.Parameters.AddWithValue("?P8",DBNull.Value)
		Else
			COM.Parameters.AddWithValue("?P8",m_str_per_nombre2)
		End If
		If m_int_per_puesto = -1 then
			COM.Parameters.AddWithValue("?P9",DBNull.Value)
		Else
			COM.Parameters.AddWithValue("?P9",m_int_per_puesto)
		End If
		If m_str_per_correo.ToUpper = "NULL" then
			COM.Parameters.AddWithValue("?P10",DBNull.Value)
		Else
			COM.Parameters.AddWithValue("?P10",m_str_per_correo)
		End If
		COM.Parameters.AddWithValue("?P11",m_obj_per_firma)
		If m_int_per_nivel = -1 then
			COM.Parameters.AddWithValue("?P12",DBNull.Value)
		Else
			COM.Parameters.AddWithValue("?P12",m_int_per_nivel)
		End If
		If m_int_per_pais = -1 then
			COM.Parameters.AddWithValue("?P13",DBNull.Value)
		Else
			COM.Parameters.AddWithValue("?P13",m_int_per_pais)
		End If
		If m_int_per_estado = -1 then
			COM.Parameters.AddWithValue("?P14",DBNull.Value)
		Else
			COM.Parameters.AddWithValue("?P14",m_int_per_estado)
		End If
		If m_int_per_jefe = -1 then
			COM.Parameters.AddWithValue("?P15",DBNull.Value)
		Else
			COM.Parameters.AddWithValue("?P15",m_int_per_jefe)
		End If
		If m_dt_per_fecha.IsValidDateTime = False then
			COM.Parameters.AddWithValue("?P16",DBNull.Value)
		Else
			COM.Parameters.AddWithValue("?P16",m_dt_per_fecha.value)
		End If
		COM.Parameters.AddWithValue("?P1",m_int_per_sisemp)
		COM.Parameters.AddWithValue("?P2",m_int_per_codigo)
		COM.ExecuteNonQuery()
		COM.Dispose()
		COM = Nothing
		PUPDATE = True
	Catch MYEX As MySqlException
		MENSAJE = "BiblioTABLAS - clsPersonal - PUPDATE MyError#=" & MYEX.Number & " MyError=" & MYEX.ToString
	Catch ex As Exception
		MENSAJE = "BiblioTABLAS - clsPersonal - PUPDATE Error=" & ex.ToString
	Finally
		If IsNothing(COM) = False Then
			COM.Dispose()
			COM = Nothing
		End If
	End Try
End Function

Function PRECUPERA_REGISTRO() as PERSONAL
	Dim VAL as New PERSONAL
	VAL.PER_SISEMP = 0
	VAL.PER_CODIGO = 0
	Val.Simon_REGISTRO = False
	Val.MERROR = ""
	PRECUPERA_REGISTRO = VAL
	Try
			VAL.PER_SISEMP = PER_SISEMP
			VAL.PER_CODIGO = PER_CODIGO
			VAL.PER_USUARIO = PER_USUARIO
			VAL.PER_CLAVE = PER_CLAVE
			VAL.PER_APELLIDO1 = PER_APELLIDO1
			VAL.PER_APELLIDO2 = PER_APELLIDO2
			VAL.PER_NOMBRE1 = PER_NOMBRE1
			VAL.PER_NOMBRE2 = PER_NOMBRE2
			VAL.PER_PUESTO = PER_PUESTO
			VAL.PER_CORREO = PER_CORREO
			VAL.PER_FIRMA = PER_FIRMA
			VAL.PER_NIVEL = PER_NIVEL
			VAL.PER_PAIS = PER_PAIS
			VAL.PER_ESTADO = PER_ESTADO
			VAL.PER_JEFE = PER_JEFE
			VAL.PER_FECHA = PER_FECHA
			VAL.Simon_REGISTRO = True
			PRECUPERA_REGISTRO = VAL
	Catch Ex as Exception
		MENSAJE = "BiblioTABLAS - clsPersonal - PRECUPERA_REGISTRO Error=" & ex.ToString
	End Try
End Function

Function PPONE_REGISTRO(ByVal VAL As PERSONAL) as Boolean
	PPONE_REGISTRO = False
	Try
			PER_SISEMP = VAL.PER_SISEMP
			PER_CODIGO = VAL.PER_CODIGO
			PER_USUARIO = VAL.PER_USUARIO
			PER_CLAVE = VAL.PER_CLAVE
			PER_APELLIDO1 = VAL.PER_APELLIDO1
			PER_APELLIDO2 = VAL.PER_APELLIDO2
			PER_NOMBRE1 = VAL.PER_NOMBRE1
			PER_NOMBRE2 = VAL.PER_NOMBRE2
			PER_PUESTO = VAL.PER_PUESTO
			PER_CORREO = VAL.PER_CORREO
			PER_FIRMA = VAL.PER_FIRMA
			PER_NIVEL = VAL.PER_NIVEL
			PER_PAIS = VAL.PER_PAIS
			PER_ESTADO = VAL.PER_ESTADO
			PER_JEFE = VAL.PER_JEFE
			PER_FECHA = VAL.PER_FECHA
			PPONE_REGISTRO = True
	Catch Ex as Exception
		MENSAJE = "BiblioTABLAS - clsPersonal - PPONE_REGISTRO Error=" & ex.ToString
	End Try
End Function

Function PLLENA_COLECCION(ByRef COLECCION as Collection, ByVal CONDICION as String, Optional ByVal ORDENAMIENTO as String = "") as Boolean
	Dim CC as New Manejo_Tablas.clsPersonal
	Dim TEMPO as PERSONAL
	Dim Llave as String

	PLLENA_COLECCION = False
	Try
		If IsNothing(CON) = True Then
			Mensaje = "BiblioTABLAS - clsPersonal - PLLENA_COLLECION Error = No se ha definido el String de Conexi�n a la base de datos."
			Exit Function
		End If

		CC.CONEXION = CONstr
		If CC.PSELECT_RECORDSET(CONDICION,ORDENAMIENTO) = False Then
			Mensaje = "BiblioTABLAS - clsPersonal - PLLENA_COLLECION Error en Query = " & CC.MERROR
			Exit Function
		End If

		Do While CC.PMOVE_NEXT = True
			TEMPO = CC.PRECUPERA_REGISTRO
			Llave = TEMPO.per_sisemp.toString & "|" & TEMPO.per_codigo.toString
			COLECCION.Add(TEMPO,Llave)
		Loop
		PLLENA_COLECCION = True
	Catch EX as Exception
		MENSAJE="BiblioTABLAS - clsPersonal - PLLENA_COLECCION Error=" & Ex.ToString
	Finally
		CC.Dispose()
		CC = Nothing
		Tempo = Nothing

		System.GC.Collect()
	End Try
End Function

Function POBTIENE_DEFAULT() as PERSONAL
	Dim VAL as New PERSONAL
	Val.Simon_REGISTRO = False
	Val.MERROR = ""
	POBTIENE_DEFAULT = VAL
	Try
			VAL.PER_SISEMP = 0
			VAL.PER_CODIGO = 0
			VAL.PER_USUARIO = "" 
			VAL.PER_CLAVE = "" 
			VAL.PER_APELLIDO1 = "" 
			VAL.PER_APELLIDO2 = "" 
			VAL.PER_NOMBRE1 = "" 
			VAL.PER_NOMBRE2 = "" 
			VAL.PER_PUESTO = 0
			VAL.PER_CORREO = "" 
			VAL.PER_FIRMA = "" 
			VAL.PER_NIVEL = 0
			VAL.PER_PAIS = -1
			VAL.PER_ESTADO = 1
			VAL.PER_JEFE = 0
			VAL.PER_FECHA = new MysqlDateTime(0,0,0,0,0,0)
			VAL.Simon_REGISTRO = True
			POBTIENE_DEFAULT = VAL
	Catch Ex as Exception
		MENSAJE = "BiblioTABLAS - clsPersonal - POBTIENE_DEFAULT Error=" & ex.ToString
	End Try
End Function


#End REGION

End Class
End NameSpace
