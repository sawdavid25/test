﻿Imports System.Web.Services
Imports System.Web.Services.Protocols
Imports System.Net
Imports System.Xml
Imports System.Text
Imports System.IO
Imports System.Web
Public Class Fel

#Region "Produccion"
    Public Function SolicitarToken1(ByVal XML As String) As String
        Dim request = CType(HttpWebRequest.Create("https://apiv2.ifacere-fel.com/api/solicitarToken"), HttpWebRequest)
        Dim PostData = ""
        'Dim xmlDoc2 As XmlDocument = New XmlDocument
        PostData = XML
        Dim xmlDoc As XmlDocument = New XmlDocument
        Try
            'xmlDoc.Load(HttpContext.Current.Server.MapPath(XML))
            xmlDoc.Load(XML)
            Dim data = Encoding.ASCII.GetBytes(xmlDoc.InnerXml)
            request.Method = "POST"
            request.ContentType = "application/xml"
            request.ContentLength = data.Length
            Using stream = request.GetRequestStream
                stream.Write(data, 0, data.Length)
            End Using
            Dim response = CType(request.GetResponse(), System.Net.HttpWebResponse)
            Dim responseString As String = New StreamReader(response.GetResponseStream()).ReadToEnd()
            Dim xmlDoc2 As XmlDocument = New XmlDocument
            xmlDoc2.LoadXml(responseString)
            Return xmlDoc2.InnerXml
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        'Return xmlDoc2.InnerXml
    End Function
    Public Function VerificaDocumento(ByVal XML As String, ByVal Token As String) As String
        Dim request = CType(HttpWebRequest.Create("https://apiv2.ifacere-fel.com/api/verificarDocumento"), HttpWebRequest)
        Dim PostData = ""
        Dim xmlDoc2 As XmlDocument = New XmlDocument
        PostData = XML
        Dim xmlDoc As XmlDocument = New XmlDocument
        Try
            xmlDoc.Load(XML)
            Dim data = Encoding.ASCII.GetBytes(xmlDoc.InnerXml)
            request.Headers.Add("authorization", "Bearer " & Token.ToString().Trim())
            request.Method = "POST"
            request.ContentType = "application/xml"
            request.ContentLength = data.Length
            Using stream = request.GetRequestStream
                stream.Write(data, 0, data.Length)
            End Using
            Dim response = CType(request.GetResponse(), System.Net.HttpWebResponse)
            Dim responseString As String = New StreamReader(response.GetResponseStream()).ReadToEnd()
            xmlDoc2.LoadXml(responseString)
        Catch ex As Exception
            MessageBox.Show(ex.ToString(), "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
        Return xmlDoc2.InnerXml
    End Function
    Public Function FirmaElectronica(ByVal XML As String, ByVal Token As String, ByRef logResultado As Boolean) As String
        Dim request = CType(HttpWebRequest.Create("https://api.soluciones-mega.com/api/solicitaFirma"), HttpWebRequest)
        Dim PostData = ""
        Dim xmlDoc2 As XmlDocument = New XmlDocument
        PostData = XML
        Dim xmlDoc As XmlDocument = New XmlDocument
        Try
            xmlDoc.Load(XML)
            Dim data = Encoding.ASCII.GetBytes(xmlDoc.InnerXml)
            request.Headers.Add("authorization", "Bearer " & Token.ToString().Trim())
            request.Method = "POST"
            request.ContentType = "application/xml"
            request.ContentLength = data.Length
            Using stream = request.GetRequestStream
                stream.Write(data, 0, data.Length)
            End Using
            Dim response = CType(request.GetResponse(), System.Net.HttpWebResponse)
            Dim responseString As String = New StreamReader(response.GetResponseStream(), Encoding.UTF8).ReadToEnd()
            xmlDoc2.LoadXml(responseString)
        Catch ex As Exception
            logResultado = False
            MessageBox.Show(ex.ToString(), "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
        Return xmlDoc2.InnerXml
    End Function
    Public Function RegistrarDocumento(ByVal XML As String, ByVal Token As String, ByRef LogResultado As Boolean) As String
        Dim request = CType(HttpWebRequest.Create("https://apiv2.ifacere-fel.com/api/registrarDocumentoXML"), HttpWebRequest)
        Dim PostData = ""
        Dim xmlDoc2 As XmlDocument = New XmlDocument
        PostData = XML
        Dim xmlDoc As XmlDocument = New XmlDocument
        Try
            xmlDoc.Load(XML)
            'Dim data = Encoding.ASCII.GetBytes(xmlDoc.InnerXml)
            Dim data = Encoding.UTF8.GetBytes(xmlDoc.InnerXml)
            request.Headers.Add("authorization", "Bearer " & Token.ToString().Trim())
            request.Method = "POST"
            request.ContentType = "application/xml"
            request.ContentLength = data.Length
            Using stream = request.GetRequestStream
                stream.Write(data, 0, data.Length)
            End Using
            Dim response = CType(request.GetResponse(), System.Net.HttpWebResponse)
            Dim responseString As String = New StreamReader(response.GetResponseStream(), Text.Encoding.UTF8).ReadToEnd()
            xmlDoc2.LoadXml(responseString)
        Catch ex As Exception
            LogResultado = False
            MessageBox.Show(ex.ToString(), "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
        Return xmlDoc2.InnerXml
    End Function
    Public Function AnulaDocumento(ByVal XML As String, ByVal Token As String, ByRef LogResultado As Boolean) As String
        Dim request = CType(HttpWebRequest.Create("https://apiv2.ifacere-fel.com/api/anularDocumentoXML"), HttpWebRequest)
        Dim PostData = ""
        Dim xmlDoc2 As XmlDocument = New XmlDocument
        PostData = XML
        Dim xmlDoc As XmlDocument = New XmlDocument
        Try
            xmlDoc.Load(XML)
            Dim data = Encoding.ASCII.GetBytes(xmlDoc.InnerXml)
            request.Headers.Add("authorization", "Bearer " & Token.ToString().Trim())
            request.Method = "POST"
            request.ContentType = "application/xml"
            request.ContentLength = data.Length
            Using stream = request.GetRequestStream
                stream.Write(data, 0, data.Length)
            End Using
            Dim response = CType(request.GetResponse(), System.Net.HttpWebResponse)
            Dim responseString As String = New StreamReader(response.GetResponseStream()).ReadToEnd()
            xmlDoc2.LoadXml(responseString)
        Catch ex As Exception
            LogResultado = False
            MessageBox.Show(ex.ToString(), "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
        Return xmlDoc2.InnerXml
    End Function
    Public Function RetornaPDF2(ByVal XML As String, ByVal Token As String) As String
        Dim request = CType(HttpWebRequest.Create("https://apiv2.ifacere-fel.com/api/retornarPDF"), HttpWebRequest)
        Dim PostData = ""
        PostData = XML
        Dim xmlDoc As XmlDocument = New XmlDocument
        Dim xmlDoc2 As XmlDocument = New XmlDocument

        xmlDoc.Load(XML)
        Dim data = Encoding.ASCII.GetBytes(xmlDoc.InnerXml)
        Try
            request.Method = "POST"
            request.ContentType = "application/xml"
            request.ContentLength = data.Length
            Using stream = request.GetRequestStream
                stream.Write(data, 0, data.Length)
            End Using
            Dim response = CType(request.GetResponse(), System.Net.HttpWebResponse)
            Dim responseString As String = New StreamReader(response.GetResponseStream()).ReadToEnd()

            xmlDoc2.LoadXml(responseString)
        Catch ex As Exception

            MessageBox.Show(ex.ToString(), "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
        request.Headers.Add("authorization", "Bearer " & Token.ToString().Trim())

        Return xmlDoc2.InnerXml
    End Function
    Public Function RetornaPDF(ByVal XML As String, ByVal Token As String) As String
        Dim request = CType(HttpWebRequest.Create("https://apiv2.ifacere-fel.com/api/retornarPDF"), HttpWebRequest)
        Dim PostData = ""
        PostData = XML
        Dim xmlDoc As XmlDocument = New XmlDocument

        xmlDoc.Load(XML)
        Dim data = Encoding.ASCII.GetBytes(xmlDoc.InnerXml)
        Try
            request.Headers.Add("authorization", "Bearer " & Token.ToString().Trim())
            request.Method = "POST"
            request.ContentType = "application/xml"
            request.ContentLength = data.Length
            Using stream = request.GetRequestStream
                stream.Write(data, 0, data.Length)
            End Using
            Dim response = CType(request.GetResponse(), System.Net.HttpWebResponse)
            Dim responseString As String = New StreamReader(response.GetResponseStream()).ReadToEnd()
            Dim xmlDoc2 As XmlDocument = New XmlDocument
            xmlDoc2.LoadXml(responseString)
            Return xmlDoc2.InnerXml
        Catch ex As WebException
            Dim responseReader As New StreamReader(ex.Response.GetResponseStream())
            Dim errorResponse As String = responseReader.ReadToEnd()
            MessageBox.Show("Error: " & ex.Message & vbCrLf & "Response: " & errorResponse, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Function
#End Region










#Region "desarrollo"
    '    Public Function SolicitarToken1(ByVal XML As String) As String
    '        Dim request = CType(HttpWebRequest.Create("https://dev2.api.ifacere-fel.com/api/solicitarToken"), HttpWebRequest)
    '        Dim PostData = ""
    '        Dim xmlDoc2 As XmlDocument = New XmlDocument
    '        PostData = XML
    '        Dim xmlDoc As XmlDocument = New XmlDocument
    '        Try
    '            '   xmlDoc.Load(HttpContext.Current.Server.MapPath(XML))
    '            xmlDoc.Load(XML)
    '            Dim data = Encoding.ASCII.GetBytes(xmlDoc.InnerXml)
    '            request.Method = "POST"
    '            request.ContentType = "application/xml"
    '            request.ContentLength = data.Length
    '            Using stream = request.GetRequestStream
    '                stream.Write(data, 0, data.Length)
    '            End Using
    '            Dim response = CType(request.GetResponse(), System.Net.HttpWebResponse)
    '            Dim responseString As String = New StreamReader(response.GetResponseStream()).ReadToEnd()
    '            xmlDoc2.LoadXml(responseString)
    '        Catch ex As Exception
    '            MsgBox(ex.ToString)
    '        End Try
    '        Return xmlDoc2.InnerXml
    '    End Function
    '    Public Function VerificaDocumento(ByVal XML As String, ByVal Token As String) As String
    '        Dim request = CType(HttpWebRequest.Create("https://dev2.api.ifacere-fel.com/api/verificarDocumento"), HttpWebRequest)
    '        Dim PostData = ""
    '        Dim xmlDoc2 As XmlDocument = New XmlDocument
    '        PostData = XML
    '        Dim xmlDoc As XmlDocument = New XmlDocument
    '        Try
    '            xmlDoc.Load(XML)
    '            Dim data = Encoding.ASCII.GetBytes(xmlDoc.InnerXml)
    '            request.Headers.Add("authorization", "Bearer " & Token.ToString().Trim())
    '            request.Method = "POST"
    '            request.ContentType = "application/xml"
    '            request.ContentLength = data.Length
    '            Using stream = request.GetRequestStream
    '                stream.Write(data, 0, data.Length)
    '            End Using
    '            Dim response = CType(request.GetResponse(), System.Net.HttpWebResponse)
    '            Dim responseString As String = New StreamReader(response.GetResponseStream()).ReadToEnd()
    '            xmlDoc2.LoadXml(responseString)
    '        Catch ex As Exception
    '            MessageBox.Show(ex.ToString(), "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
    '        End Try
    '        Return xmlDoc2.InnerXml
    '    End Function
    '    Public Function FirmaElectronica(ByVal XML As String, ByVal Token As String, ByRef logResultado As Boolean) As String
    '        Dim request = CType(HttpWebRequest.Create("https://dev.api.soluciones-mega.com/api/solicitaFirma"), HttpWebRequest)
    '        Dim PostData = ""
    '        Dim xmlDoc2 As XmlDocument = New XmlDocument
    '        PostData = XML
    '        Dim xmlDoc As XmlDocument = New XmlDocument
    '        Try
    '            xmlDoc.Load(XML)
    '            Dim data = Encoding.ASCII.GetBytes(xmlDoc.InnerXml)
    '            request.Headers.Add("authorization", "Bearer " & Token.ToString().Trim())
    '            request.Method = "POST"
    '            request.ContentType = "application/xml"
    '            request.ContentLength = data.Length
    '            Using stream = request.GetRequestStream
    '                stream.Write(data, 0, data.Length)
    '            End Using
    '            Dim response = CType(request.GetResponse(), System.Net.HttpWebResponse)
    '            Dim responseString As String = New StreamReader(response.GetResponseStream(), Encoding.UTF8).ReadToEnd()
    '            xmlDoc2.LoadXml(responseString)
    '        Catch ex As Exception
    '            logResultado = False
    '            MessageBox.Show(ex.ToString(), "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
    '        End Try
    '        Return xmlDoc2.InnerXml
    '    End Function
    '    Public Function RegistrarDocumento(ByVal XML As String, ByVal Token As String, ByRef LogResultado As Boolean) As String
    '        Dim request = CType(HttpWebRequest.Create("https://dev2.api.ifacere-fel.com/api/registrarDocumentoXML"), HttpWebRequest)
    '        Dim PostData = ""
    '        Dim xmlDoc2 As XmlDocument = New XmlDocument
    '        PostData = XML
    '        Dim xmlDoc As XmlDocument = New XmlDocument
    '        Try
    '            xmlDoc.Load(XML)
    '            ' Dim data = Encoding.ASCII.GetBytes(xmlDoc.InnerXml)
    '            Dim data = Encoding.UTF8.GetBytes(xmlDoc.InnerXml)
    '            request.Headers.Add("authorization", "Bearer " & Token.ToString().Trim())
    '            request.Method = "POST"
    '            request.ContentType = "application/xml"
    '            request.ContentLength = data.Length
    '            Using stream = request.GetRequestStream
    '                stream.Write(data, 0, data.Length)
    '            End Using
    '            Dim response = CType(request.GetResponse(), System.Net.HttpWebResponse)
    '            Dim responseString As String = New StreamReader(response.GetResponseStream(), Text.Encoding.UTF8).ReadToEnd()
    '            xmlDoc2.LoadXml(responseString)
    '        Catch ex As Exception
    '            LogResultado = False
    '            MessageBox.Show(ex.ToString(), "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
    '        End Try
    '        Return xmlDoc2.InnerXml
    '    End Function
    '    Public Function AnulaDocumento(ByVal XML As String, ByVal Token As String, ByRef LogResultado As Boolean) As String
    '        Dim request = CType(HttpWebRequest.Create("https://dev2.api.ifacere-fel.com/api/anularDocumentoXML"), HttpWebRequest)
    '        Dim PostData = ""
    '        Dim xmlDoc2 As XmlDocument = New XmlDocument
    '        PostData = XML
    '        Dim xmlDoc As XmlDocument = New XmlDocument
    '        Try
    '            xmlDoc.Load(XML)
    '            Dim data = Encoding.ASCII.GetBytes(xmlDoc.InnerXml)
    '            request.Headers.Add("authorization", "Bearer " & Token.ToString().Trim())
    '            request.Method = "POST"
    '            request.ContentType = "application/xml"
    '            request.ContentLength = data.Length
    '            Using stream = request.GetRequestStream
    '                stream.Write(data, 0, data.Length)
    '            End Using
    '            Dim response = CType(request.GetResponse(), System.Net.HttpWebResponse)
    '            Dim responseString As String = New StreamReader(response.GetResponseStream()).ReadToEnd()
    '            xmlDoc2.LoadXml(responseString)
    '        Catch ex As Exception
    '            LogResultado = False
    '            MessageBox.Show(ex.ToString(), "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
    '        End Try
    '        Return xmlDoc2.InnerXml
    '    End Function
    '    Public Function RetornaPDF(ByVal XML As String, ByVal Token As String) As String
    '        Dim request = CType(HttpWebRequest.Create("https://dev2.api.ifacere-fel.com/api/retornarPDF"), HttpWebRequest)
    '        Dim PostData = ""
    '        PostData = XML
    '        Dim xmlDoc As XmlDocument = New XmlDocument
    '        xmlDoc.Load(XML)
    '        Dim data = Encoding.ASCII.GetBytes(xmlDoc.InnerXml)

    '        request.Headers.Add("authorization", "Bearer " & Token.ToString().Trim())
    '        request.Method = "POST"
    '        request.ContentType = "application/xml"
    '        request.ContentLength = data.Length
    '        Using stream = request.GetRequestStream
    '            stream.Write(data, 0, data.Length)
    '        End Using
    '        Dim response = CType(request.GetResponse(), System.Net.HttpWebResponse)
    '        Dim responseString As String = New StreamReader(response.GetResponseStream()).ReadToEnd()
    '        Dim xmlDoc2 As XmlDocument = New XmlDocument
    '        xmlDoc2.LoadXml(responseString)
    '        Return xmlDoc2.InnerXml
    '    End Function
    '    Public Function ValidaCUI(ByVal XML As String, ByVal Token As String) As String
    '        Dim request = CType(HttpWebRequest.Create("https://dev2.api.ifacere-fel.com/api/retornarDatosClienteCui"), HttpWebRequest)
    '        Dim PostData = ""
    '        PostData = XML
    '        Dim xmlDoc As XmlDocument = New XmlDocument
    '        xmlDoc.Load(XML)
    '        Dim data = Encoding.ASCII.GetBytes(xmlDoc.InnerXml)

    '        request.Headers.Add("authorization", "Bearer " & Token.ToString().Trim())
    '        request.Method = "POST"
    '        request.ContentType = "application/xml"
    '        request.ContentLength = data.Length
    '        Using stream = request.GetRequestStream
    '            stream.Write(data, 0, data.Length)
    '        End Using
    '        Dim response = CType(request.GetResponse(), System.Net.HttpWebResponse)
    '        Dim responseString As String = New StreamReader(response.GetResponseStream()).ReadToEnd()
    '        Dim xmlDoc2 As XmlDocument = New XmlDocument
    '        xmlDoc2.LoadXml(responseString)
    '        Return xmlDoc2.InnerXml
    '    End Function
#End Region
End Class
