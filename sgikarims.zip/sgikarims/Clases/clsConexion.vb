﻿Imports System.Xml
Imports System.IO
Public Class ClsConexion
    Dim constr As String


    Public Property CONECTAR() As String
        Set(ByVal VALUE As String)
            constr = VALUE
            Try
                If IsNothing(CON) = True Then
                    CON = New MySqlConnection
                End If
                If CON.State = ConnectionState.Open Then
                    CON.Close()
                End If
                CON.ConnectionString = constr
                If CON.State = ConnectionState.Closed Or CON.State = ConnectionState.Broken Then
                    CON.Open()
                End If
                'CON.Open()
            Catch MyEX As MySqlException
                MsgBox(MyEX.ToString)
            Catch EX As Exception
                MsgBox(EX.ToString)
            End Try
        End Set
        Get
            Return CONstr
        End Get
    End Property

#Region "Procedimientos"
    'XML
    Private Sub VerificarXml()
        Dim xml_Documento As New XmlDocument
        Dim nodos_lista As XmlNodeList
        Dim nodo As XmlNode
        Dim strpath As String = System.Windows.Forms.Application.StartupPath & "\Conexion.xml"
        Dim strTemp As String = STR_VACIO
        If cFunciones.ExisteArchivo(strpath) Then
            Try
                xml_Documento.Load(strpath)
                nodos_lista = xml_Documento.SelectNodes("/conexion/name")
                For Each nodo In nodos_lista
                    'If Left(nodo.Attributes.GetNamedItem("codigo").Value, INT_UNO) = ARROBA Then
                    '    nodo.Attributes.GetNamedItem("codigo").Value = cFunciones.Encriptar(nodo.Attributes.GetNamedItem("codigo").Value, CLAVE_ENCRIPTAMIENTO)
                    'End If
                    If Left(nodo.ChildNodes.Item(0).InnerText, INT_UNO) = ARROBA Then
                        strTemp = STR_VACIO
                        strTemp = Replace(nodo.ChildNodes.Item(0).InnerText.ToString, "@", "")
                        nodo.ChildNodes.Item(0).InnerText = cFunciones.Encriptar(strTemp, CLAVE_ENCRIPTAMIENTO)
                    End If
                    If Left(nodo.ChildNodes.Item(INT_UNO).InnerText, INT_UNO) = ARROBA Then
                        strTemp = STR_VACIO
                        strTemp = Replace(nodo.ChildNodes.Item(1).InnerText.ToString, "@", "")
                        nodo.ChildNodes.Item(INT_UNO).InnerText = cFunciones.Encriptar(strTemp, CLAVE_ENCRIPTAMIENTO)
                    End If
                    If Left(nodo.ChildNodes.Item(2).InnerText, INT_UNO) = ARROBA Then
                        strTemp = STR_VACIO
                        strTemp = Replace(nodo.ChildNodes.Item(2).InnerText.ToString, "@", "")
                        nodo.ChildNodes.Item(2).InnerText = cFunciones.Encriptar(strTemp, CLAVE_ENCRIPTAMIENTO)
                    End If
                    If Left(nodo.ChildNodes.Item(3).InnerText, INT_UNO) = ARROBA Then
                        strTemp = STR_VACIO
                        strTemp = Replace(nodo.ChildNodes.Item(3).InnerText.ToString, "@", "")
                        nodo.ChildNodes.Item(3).InnerText = cFunciones.Encriptar(strTemp, CLAVE_ENCRIPTAMIENTO)
                    End If
                    If Left(nodo.ChildNodes.Item(4).InnerText, INT_UNO) = ARROBA Then
                        strTemp = STR_VACIO
                        strTemp = Replace(nodo.ChildNodes.Item(4).InnerText.ToString, "@", "")
                        nodo.ChildNodes.Item(4).InnerText = cFunciones.Encriptar(strTemp, CLAVE_ENCRIPTAMIENTO)
                    End If
                    If Left(nodo.ChildNodes.Item(5).InnerText, INT_UNO) = ARROBA Then
                        strTemp = STR_VACIO
                        strTemp = Replace(nodo.ChildNodes.Item(5).InnerText.ToString, "@", "")
                        nodo.ChildNodes.Item(5).InnerText = cFunciones.Encriptar(strTemp, CLAVE_ENCRIPTAMIENTO)
                    End If
                Next
                xml_Documento.Save(strpath)
            Catch ex As Exception
                MsgBox(ex.ToString)
            End Try
        Else
            MsgBox("No se encontró el archivo de conexión", MsgBoxStyle.ApplicationModal)
            End
        End If
    End Sub

    Public Sub ConexionFavorita(ByVal strNombre As String)
        Dim xml_Documento As New XmlDocument
        Dim nodos_lista As XmlNodeList
        Dim nodo As XmlNode
        Dim strpath As String = System.Windows.Forms.Application.StartupPath & "\Conexion.xml"
        Dim strTemp As String = STR_VACIO
        If cFunciones.ExisteArchivo(strpath) Then
            Try
                xml_Documento.Load(strpath)
                nodos_lista = xml_Documento.SelectNodes("/conexion/name")
                For Each nodo In nodos_lista
                    'If Left(nodo.Attributes.GetNamedItem("codigo").Value, INT_UNO) = ARROBA Then
                    '    nodo.Attributes.GetNamedItem("codigo").Value = cFunciones.Encriptar(nodo.Attributes.GetNamedItem("codigo").Value, CLAVE_ENCRIPTAMIENTO)
                    'End If

                    If nodo.ChildNodes.Item(0).InnerText = strNombre Then
                        If Left(nodo.ChildNodes.Item(6).InnerText, INT_UNO) = INT_CERO Or INT_UNO Then
                            strTemp = STR_VACIO
                            strTemp = Replace(nodo.ChildNodes.Item(6).InnerText.ToString, "@", "")
                            nodo.ChildNodes.Item(6).InnerText = INT_UNO
                        End If
                    Else
                        If Left(nodo.ChildNodes.Item(6).InnerText, INT_UNO) = INT_UNO Then
                            strTemp = STR_VACIO
                            strTemp = Replace(nodo.ChildNodes.Item(6).InnerText.ToString, "@", "")
                            nodo.ChildNodes.Item(6).InnerText = INT_CERO
                        End If
                    End If



                Next
                xml_Documento.Save(strpath)
            Catch ex As Exception
                MsgBox(ex.ToString)
            End Try
        Else
            MsgBox("No se encontró el archivo de conexión", MsgBoxStyle.ApplicationModal)
            End
        End If
    End Sub

    Public Sub ObtenerCredencialesXml(ByRef ArrayNombre() As String, ByRef ArrayServer() As String, ByRef ArrayUsuario() As String, ByRef ArrayPass() As String, ByRef ArrayDb() As String, ByRef ArrayPuerto() As String, ByRef ArrayDefault() As String)
        Try
            Dim xml_Documento As New XmlDocument
            Dim nodos_lista As XmlNodeList
            Dim nodo As XmlNode
            Dim strpath As String = System.Windows.Forms.Application.StartupPath & "\Conexion.xml"

            Dim n As Integer = NO_FILA
            Dim s As Integer = NO_FILA
            Dim u As Integer = NO_FILA
            Dim p As Integer = NO_FILA
            Dim d As Integer = NO_FILA
            Dim t As Integer = NO_FILA
            Dim x As Integer = NO_FILA

            'Cargamos el archivo
            VerificarXml()
            'ReDim ArrayNombre(100)
            'ReDim ArrayServer(100)
            'ReDim arr

            If cFunciones.ExisteArchivo(strpath) Then
                xml_Documento.Load(strpath)
                'Obtenemos la lista de los nodos "name"
                nodos_lista = xml_Documento.SelectNodes("/conexion/name")
                'Iniciamos el ciclo de lectura
                For Each nodo In nodos_lista
                    'Suma los contadores
                    n = n + 1
                    s = s + 1
                    u = u + 1
                    p = p + 1
                    d = d + 1
                    t = t + 1
                    x = x + 1

                    ReDim Preserve ArrayNombre(n)
                    ReDim Preserve ArrayServer(s)
                    ReDim Preserve ArrayUsuario(u)
                    ReDim Preserve ArrayPass(p)
                    ReDim Preserve ArrayDb(d)
                    ReDim Preserve ArrayPuerto(t)
                    ReDim Preserve ArrayDefault(x)

                    'Obtenemos el atributo del codigo
                    Dim mCodigo = nodo.Attributes.GetNamedItem("codigo").Value
                    'Obtenemos Elementos
                    Dim nombre = nodo.ChildNodes.Item(0).InnerText
                    ArrayNombre(n) = nombre
                    Dim server = cFunciones.Desencriptar(nodo.ChildNodes.Item(1).InnerText, CLAVE_ENCRIPTAMIENTO)
                    ArrayServer(s) = server
                    Dim user = cFunciones.Desencriptar(nodo.ChildNodes.Item(2).InnerText, CLAVE_ENCRIPTAMIENTO)
                    ArrayUsuario(u) = user
                    Dim pass = cFunciones.Desencriptar(nodo.ChildNodes.Item(3).InnerText, CLAVE_ENCRIPTAMIENTO)
                    ArrayPass(p) = pass
                    Dim db = cFunciones.Desencriptar(nodo.ChildNodes.Item(4).InnerText, CLAVE_ENCRIPTAMIENTO)
                    ArrayDb(d) = db
                    Dim port = cFunciones.Desencriptar(nodo.ChildNodes.Item(5).InnerText, CLAVE_ENCRIPTAMIENTO)
                    ArrayPuerto(t) = port
                    Dim def = nodo.ChildNodes.Item(6).InnerText
                    ArrayDefault(x) = def

                Next
            End If
        Catch ex As Exception
            MsgBox(ex.ToString())
        End Try
    End Sub

#End Region

#Region "Funciones"


    Public Function StringConexion(ByVal srtLocal As String) As String
        Dim strConexion As String = "server={server};Port={port};database={db} ;uid={user};password={pass};"
        If srtLocal = "1" Then
            strConexion = Replace(strConexion, "{server}", Conexion.local.Servidor)
            strConexion = Replace(strConexion, "{user}", Conexion.local.Usuario)
            strConexion = Replace(strConexion, "{pass}", Conexion.local.Clave)
            strConexion = Replace(strConexion, "{db}", Conexion.local.Base)
            strConexion = Replace(strConexion, "{port}", Conexion.local.Def)
        ElseIf srtLocal = "2" Then
            strConexion = Replace(strConexion, "{server}", Conexion.servidor.Servidor)
            strConexion = Replace(strConexion, "{user}", Conexion.servidor.Usuario)
            strConexion = Replace(strConexion, "{pass}", Conexion.servidor.Clave)
            strConexion = Replace(strConexion, "{db}", Conexion.servidor.Base)
            strConexion = Replace(strConexion, "{port}", Conexion.servidor.Def)
        ElseIf srtLocal = "3" Then
            strConexion = Replace(strConexion, "{server}", Conexion.wan1.Servidor)
            strConexion = Replace(strConexion, "{user}", Conexion.wan1.Usuario)
            strConexion = Replace(strConexion, "{pass}", Conexion.wan1.Clave)
            strConexion = Replace(strConexion, "{db}", Conexion.wan1.Base)
            strConexion = Replace(strConexion, "{port}", Conexion.wan1.Def)
        ElseIf srtLocal = "4" Then
            strConexion = Replace(strConexion, "{server}", Conexion.wan2.Servidor)
            strConexion = Replace(strConexion, "{user}", Conexion.wan2.Usuario)
            strConexion = Replace(strConexion, "{pass}", Conexion.wan2.Clave)
            strConexion = Replace(strConexion, "{db}", Conexion.wan2.Base)
            strConexion = Replace(strConexion, "{port}", Conexion.wan2.Def)
        End If
        Return strConexion
    End Function

    Public Function ProbarConexiones() As Boolean
        Dim logResultado As Boolean = False
        Dim mensaje As String

        If IsNothing(CON) = True Then
            CON = New MySqlConnection
        End If
        If CON.State = ConnectionState.Open Then
            CON.Close()
        End If
        CON.ConnectionString = strConexion
        If CON.State = ConnectionState.Closed Or CON.State = ConnectionState.Broken Then
            If CON.ConnectionString.Length <> 0 Then
                Try
                    CON.Open()
                    logResultado = True
                Catch MYEX As MySqlException
                    MsgBox(MYEX.ToString)
                    mensaje = "BiblioTABLAS - TTDCMTOS_DTL - PSELECT_CONDICION Error#=" & MYEX.Number & " " & MYEX.ToString
                    Return logResultado
                    Exit Function
                Catch EX As Exception
                    mensaje = "BiblioTABLAS - TTDCMTOS_DTL - PSELECT_CONDICION Error=" & EX.ToString
                    Return logResultado
                    Exit Function
                End Try
            Else
                mensaje = "BiblioTABLAS - TTDCMTOS_DTL - PSELECT_CONDICION String de Conexión no definido"
                Return logResultado
                Exit Function
            End If
        Else
            logResultado = True
        End If
        Return logResultado
    End Function

    Public Function MyOpen() As MySqlConnection
        Dim logPing As Boolean = False
        Dim CON As New MySqlConnection
        Try
            CON.ConnectionString = CONECTAR
            CON.Open()
            logPing = True
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        Return CON
    End Function

    Public Function GetReader(ByVal strQuery As String) As MySqlDataReader
        Dim REA As MySqlDataReader
        Dim COM As MySqlCommand
        Try
            CONECTAR = strConexion
            If ProbarConexiones() = True Then
                COM = New MySqlCommand(strQuery, CON)
                COM.CommandType = CommandType.Text
                REA = COM.ExecuteReader()
                REA.Read()
                Return REA
                Exit Function
            Else
                Return Nothing
                Exit Function
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
            REA = Nothing
        End Try
        Return Nothing
    End Function

    Public Function BorrarRegistro(ByVal strTabla As String, Optional ByVal strCondicion As String = "", Optional intLimite As Integer = 0) As Boolean
        BorrarRegistro = False
        Dim COM As MySqlCommand
        Dim strSQL As String = ""
        strSQL = "DELETE FROM " & strTabla
        If strCondicion.Length > 0 Then
            strSQL &= " WHERE " & strCondicion
            If intLimite > 0 Then
                strSQL &= " LIMIT " & intLimite
            End If
        End If

        strSQL &= " ;"

        If Sesion.IdEmpresa = 18 Then
            strSQL &= "DELETE FROM " & strTabla
            If strCondicion.Length > 0 Then
                strSQL &= " WHERE " & strCondicion
                If intLimite > 0 Then
                    strSQL &= " LIMIT " & intLimite
                End If
            End If
            strSQL &= " ;"
        End If

        Try
            If MsgBox("¿Está seguro que desea borrar este registro?", MsgBoxStyle.YesNo) = MsgBoxResult.Yes Then
                CONECTAR = strConexion
                If ProbarConexiones() = True Then
                    COM = New MySqlCommand(strSQL, CON)
                    COM.ExecuteNonQuery()
                    BorrarRegistro = True
                    cFunciones.EscribirRegistro(strTabla, clsFunciones.AccEnum.acDelete)
                End If
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Function

    Public Function GetEscalar(ByVal strSQL As String) As String
        Return STR_VACIO
    End Function

#End Region

End Class