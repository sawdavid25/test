﻿Public Class clsBPoliza
    Implements IDisposable
    'Modificado: 2019-08-28

    '[polizas]
    'empresa, ejercicio, poliza
    'fecha, concepto, tipo, tipo_cambio?, observaciones?, operador, estado, marca?, grupo, modo, ref_tipo, ref_ciclo, ref_numero, divisa?, tasa?, revisado, usuario_ref?, ult_rev?

    '[detalle_polizas]
    'transaccion, empresa, ejercicio, poliza, item 
    'cuenta, parametro_cuenta?, importe, centro_costos?, partida_presupuestal?, operacion?, fecha, clase, modo, ref_tipo, ref_ciclo, ref_numero, ref_id

    'Identificadores de documentos
    Public Const ID_DEPRECIACION As Integer = 160

    'Operacion contable
    Public Const STR_CARGO As String = "C"
    Public Const STR_ABONO As String = "A"

    'Grupo y transaccion no validos
    Public Const NO_GRUPO As Integer = 7
    Public Const NO_ITEM As Integer = 10

    'Documentos de catalogo
    Public Const DOC_DEPOSITO As String = "Doc_BDeposit"
    Public Const DOC_CHEQUE As String = "Doc_BCheque"
    Public Const DOC_DEBITO As String = "Doc_BNDebito"
    Public Const DOC_CREDITO As String = "Doc_BNCredit"

    'Otras constantes
    Public Const DEF_ESTADO As Integer = 2
    Public Const STR_ESTADO As String = "C"
    Public Const INT_ANULADO As Integer = 3

    Private Const SALDO_DIFERENCIAL As Integer = 0
    Private Const SALDO_CARGO As Integer = 1
    Private Const SALDO_ABONO As Integer = 2

    Private Const DEC_TOTAL As Integer = 2
    Private Const DEC_TASA As Integer = 5

    Private Const STR_CUENTA As String = "CUENTA"

    'Informacion de modos para poliza
    Private Structure DatoModo
        Dim ID As Integer
        Dim Modo As Integer
    End Structure

    'Modos segun tipo de documento
    Private Structure DatoTipos
        Dim Cheque As DatoModo
        Dim Debito As DatoModo
        Dim Credito As DatoModo
        Dim Deposito As DatoModo
    End Structure

    'Datos basicos del documento actual
    Private Structure DatoSoporte
        Dim Tipo As Integer
        Dim Ciclo As Integer
        Dim Numero As Integer
        Dim Catalogo As String
        Dim Documento As String
        Dim Nota_ As String

        Dim Nombre As String
        Dim EsMultiple As Boolean

        Dim Grupo As Integer
        Dim Item As Integer

        Dim Fecha As Date
        Dim Moneda As Integer
        Dim Tasa As Double
        Dim Usuario As String
        Dim Estado As Integer
    End Structure

    'Tipos de poliza segun documentos
    Private Structure DatoPoliza
        Dim Dato As DatoSoporte
        Dim Ejercicio As Integer
        Dim Transaccion As Integer
        Dim TransaccionPDM As Integer

        Dim Modo As Integer
        Dim Debe As String
        Dim Haber As String
    End Structure

    'Linea de detalle de poliza
    Private Structure DatoDetalle
        Dim Item As Integer
        Dim Cuenta As String
        Dim Parametro As Integer
        Dim Importe As Double
        Dim Centro As String
        Dim Presupuesto As String
        Dim Operacion As String
        Dim Fecha As String
        Dim Clase As String
        Dim Modo As Integer
        Dim Tipo As Integer
        Dim Ciclo As Integer
        Dim Numero As Integer
        Dim ID As Integer
    End Structure

    'Modos de saldo
    Private Enum EnumSaldo
        Diferencia = INT_CERO
        Abono = 1
        Cargo = 2
    End Enum

    'Modos de póliza contable
    Private Enum EnumModo
        'Clientes
        Venta = 9
        VentaBlanco = 18
        Costo = 10
        CostoBlanco = 19
        NotaCredito = 13
        NotaDebito = 20
        'Proveedor
        Compra = 8
        Cobro = 21
        RetenISRPro = 24
        'Inventario
        Ingreso = 11
        Devolucion = 12
        'Bancos
        Cheque = 14
        Debito = 15
        Credito = 16
        Deposito = 17
        'Otros
        Liquidacion = 22
        Depreciacion = 23
        RetenISR = 24
        RetenIVA = 25
    End Enum

    'Parametros contables
    Private Enum EnumParametro
        DescuentoVentas = 14
        DiferencialDebe = 21
        DiferencialHaber = 22
        GastoComision = 26
        IVAPorPagar = 28
        SueldoPorPagar = 31
        AnticipoDeCompra = 32
        AguinaldoPorPagar = 33
        BonoPorPagar = 34
        ISRRetencion = 36 'NSM: Retenciones por pagar, bienes y servicios 2%
        ISRRetencionTM = 61 'NSM: Transporte marítimo, aéreo y carga 3%
        ISRRetencionSP = 62 'NSM: Servicios Profesionales o técnicos 10%
        ISRRetencionesIP = 63 'NSM: Intereses Pagados 13%
        ISRRetencionAS = 64 'NSM: Arrendamientos y Subarrendamientos 15%
        ISRSalario = 37
        Vacaciones = 38
        Bonificacion = 43
        ISRMensual = 48
        Indemnizacion = 44
        Transferencia = 45
        BonoExtra = 49
        ISREspecial = 52
        IVARetencion = 55
        IVAEspecial = 54

        PagoISR = ISRSalario
    End Enum

    'Propiedades públicas
    Public Property Empresa As Integer
    Public Property Ejercicio As Integer
    Public Property Poliza As Integer
    Public Property Fecha As Date?
    Public Property Concepto As String
    Public Property Tipo As Integer
    Public Property TC As Double
    Public Property Observaciones As String
    Public Property Operador As String
    Public Property Estado As String
    Public Property Grupo As String
    Public Property Modo As Integer

    'Documento de referencia: tipo, año y numero
    Public Property Referencia As Integer
    Public Property Ciclo As Integer
    Public Property Numero As Integer

    'Divisa y tasa de cambio de referencia
    Public Property Moneda As Integer
    Public Property Tasa As Double

    'Revisión: estado, usuario y fecha 
    Public Property Revisado As Integer
    Public Property Usuario As String
    Public Property Revision As Date?

    Private Documento As DatoPoliza
    Private Info As DatoTipos
    Private Base As New clsBancos
    Private Detalle As New List(Of DatoDetalle)

    Private logDisposed As Boolean = False
    Private intItem As Integer = INT_CERO

    'Procesa la poliza contable para un documento bancario 
    Public Function ProcesarDocumento(ByVal tipo As Integer, ByVal ciclo As Integer, ByVal numero As Integer, Optional ByVal fecha As Date = Nothing, Optional Finicial As Date = Nothing, Optional Ffinal As Date = Nothing) As Boolean
        Dim strFecha As String = String.Empty
        Dim logEx As Boolean = False
        Dim strSQL As String = STR_VACIO
        Dim cfun As New clsFunciones
        Dim COMAN As MySqlCommand
        Dim ESC As MySqlDataReader
        Dim conecC As MySqlConnection
        ' Ingresa aqui cuando va a generar poliza por documento
        If Finicial = Nothing Or Ffinal = Nothing Then
            'Limpia las variables y carga los tipos de documento y modos
            Limpiar()
            CargarTipos()

            'Recuperar informacion basica del documento
            With Documento.Dato
                .Tipo = tipo
                .Ciclo = ciclo
                .Numero = numero
                '.Nota_ = Documento.Dato.Nota_
            End With
            RecuperarInfo(fecha.ToString(FORMATO_MYSQL))

            'Determinar modo
            Select Case tipo
                Case Info.Cheque.ID : Documento.Modo = Info.Cheque.Modo
                Case Info.Debito.ID : Documento.Modo = Info.Debito.Modo
                Case Info.Deposito.ID : Documento.Modo = Info.Deposito.Modo
                Case Info.Credito.ID : Documento.Modo = Info.Credito.Modo
                Case Else
                    Throw New System.Exception("Invalid document for this process")
            End Select

            If fecha.ToString(FORMATO_MYSQL) IsNot Nothing Then
                _Fecha = fecha
                strFecha = fecha.ToString(FORMATO_MYSQL)
            End If

            'Recupera el ejercicio para el documento y verifica su estado
            Documento.Ejercicio = EjercicioDeDocumento(Sesion.IdEmpresa, tipo, ciclo, numero, strFecha)
            If EjercicioEstaActivo(Documento.Ejercicio) Then
                'Verifica el estado del documento
                If DocumentoEstaActivo(tipo, ciclo, numero) Then
                    'Generar poliza de documento
                    GenerarPolizaBancaria()
                Else
                    'REM: posteriormente no se eliminara, se creara poliza con valores inversos (suma cero)
                    'Borrar si tiene poliza
                    BorrarPoliza(Sesion.BaseConta, tipo, ciclo, numero)
                    If Sesion.IdEmpresa = 18 Then
                        BorrarPoliza("contapdm", tipo, ciclo, numero)
                    End If
                End If
            Else
                MessageBox.Show("There is no active fiscal year for this document date", "Accounting", MessageBoxButtons.OK, MessageBoxIcon.Warning)
            End If
            ' Entra aqui si se va a regenerar masivamente
        Else
            strSQL = " SELECT h.HDoc_Doc_Ano anio, h.HDoc_Doc_Num numero, h.HDoc_Doc_Fec fecha"
            strSQL &= "    From Dcmtos_HDR h "
            strSQL &= "     WHERE h.HDoc_Sis_Emp = {emp} AND h.HDoc_Doc_Cat = {cat} AND h.HDoc_Doc_Fec BETWEEN '{inicio}' AND '{fin}' "


            strSQL = Replace(strSQL, "{emp}", Sesion.IdEmpresa)
            strSQL = Replace(strSQL, "{inicio}", Finicial.ToString(FORMATO_MYSQL))
            strSQL = Replace(strSQL, "{fin}", Ffinal.ToString(FORMATO_MYSQL))
            strSQL = Replace(strSQL, "{cat}", tipo)

            conecC = New MySqlConnection(strConexion)
            conecC.Open()

            COMAN = New MySqlCommand(strSQL, conecC)
            ESC = COMAN.ExecuteReader
            If ESC.HasRows Then
                Do While ESC.Read
                    ciclo = ESC.GetInt32("anio")
                    numero = ESC.GetInt32("numero")
                    fecha = cfun.SQLValidarFechaContable(tipo, ciclo, numero)

                    'Limpia las variables y carga los tipos de documento y modos
                    Limpiar()
                    CargarTipos()

                    'Recuperar informacion basica del documento
                    With Documento.Dato
                        .Tipo = tipo
                        .Ciclo = ciclo
                        .Numero = numero
                    End With
                    RecuperarInfo(fecha.ToString(FORMATO_MYSQL))

                    'Determinar modo
                    Select Case tipo
                        Case Info.Cheque.ID : Documento.Modo = Info.Cheque.Modo
                        Case Info.Debito.ID : Documento.Modo = Info.Debito.Modo
                        Case Info.Deposito.ID : Documento.Modo = Info.Deposito.Modo
                        Case Info.Credito.ID : Documento.Modo = Info.Credito.Modo
                        Case Else
                            Throw New System.Exception("Invalid document for this process")
                    End Select

                    If fecha.ToString(FORMATO_MYSQL) IsNot Nothing Then
                        _Fecha = fecha
                        strFecha = fecha.ToString(FORMATO_MYSQL)
                    End If

                    'Recupera el ejercicio para el documento y verifica su estado
                    Documento.Ejercicio = EjercicioDeDocumento(Sesion.IdEmpresa, tipo, ciclo, numero, strFecha)
                    If EjercicioEstaActivo(Documento.Ejercicio) Then
                        'Verifica el estado del documento
                        If DocumentoEstaActivo(tipo, ciclo, numero) Then
                            'Generar poliza de documento
                            GenerarPolizaBancaria()
                        Else
                            'REM: posteriormente no se eliminara, se creara poliza con valores inversos (suma cero)
                            'Borrar si tiene poliza
                            BorrarPoliza(Sesion.BaseConta, tipo, ciclo, numero)
                            If Sesion.IdEmpresa = 18 Then
                                BorrarPoliza("contapdm", tipo, ciclo, numero)
                            End If
                        End If
                    Else
                        MessageBox.Show("There is no active fiscal year for this document date", "Accounting", MessageBoxButtons.OK, MessageBoxIcon.Warning)
                    End If
                Loop
                conecC.Close()
                conecC.Dispose()
                conecC = Nothing
                System.GC.Collect()
            End If
        End If

        Return logEx
    End Function

    'Recupera informacion basica del documento como grupo y transaccion
    Private Sub RecuperarInfo(ByVal fec As Date)
        Dim strSQL As String = " SELECT HDoc_DR1_Num Documento, IF(IFNULL(HDoc_Emp_Nom,'')='', HDoc_Emp_Per, HDoc_Emp_Nom) Nombre,  '{fecha}' Fecha, HDoc_Doc_Mon Moneda, HDoc_Doc_TC Tasa, IFNULL(HDoc_RF1_Txt,'') nota, " &
                               "        IFNULL(HDoc_DR1_Cat,{no_grupo}) Grupo, IFNULL(HDoc_DR2_Cat,{no_item}) Item, IFNULL(HDoc_DR1_Emp,0) Multiple, HDoc_Usuario Usuario, HDoc_Doc_Status Estado, " &
                               "        IFNULL((SELECT cat_desc FROM Catalogos WHERE cat_num=HDoc_Doc_Cat LIMIT 1),'') Catalogo " &
                               " FROM Dcmtos_HDR e " &
                               " WHERE e.HDoc_Sis_Emp=@empresa AND e.HDoc_Doc_Cat=@tipo AND e.HDoc_Doc_Ano=@ciclo AND e.HDoc_Doc_Num=@numero " &
                               " LIMIT 1"
        strSQL = strSQL.Replace("{no_grupo}", NO_GRUPO.ToString)
        strSQL = strSQL.Replace("{no_item}", NO_ITEM.ToString)
        strSQL = strSQL.Replace("{fecha}", fec.ToString(FORMATO_MYSQL))
        Dim cmd As MySqlCommand

        cmd = New MySqlCommand(strSQL, CON)
        cmd.Parameters.AddWithValue("@empresa", Sesion.IdEmpresa)
        cmd.Parameters.AddWithValue("@tipo", Documento.Dato.Tipo)
        cmd.Parameters.AddWithValue("@ciclo", Documento.Dato.Ciclo)
        cmd.Parameters.AddWithValue("@numero", Documento.Dato.Numero)
        Using dr As MySqlDataReader = cmd.ExecuteReader
            If dr.Read Then
                Documento.Dato.Grupo = CInt(dr.Item("grupo"))
                Documento.Dato.Item = CInt(dr.Item("item"))
                Documento.Dato.Catalogo = dr.Item("catalogo").ToString
                Documento.Dato.Documento = dr.Item("documento").ToString

                Documento.Dato.Nombre = dr.Item("nombre").ToString
                Documento.Dato.EsMultiple = CBool(dr.Item("multiple"))

                Documento.Dato.Fecha = CDate(dr.Item("fecha"))
                Documento.Dato.Moneda = CInt(dr.Item("moneda"))
                Documento.Dato.Tasa = CDbl(dr.Item("tasa"))
                Documento.Dato.Nota_ = dr.Item("nota").ToString

                Documento.Dato.Usuario = dr.Item("usuario").ToString
                Documento.Dato.Estado = CInt(dr.Item("estado"))
            End If
        End Using
    End Sub

    'Genera la poliza contable para el documento bancario
    Private Sub GenerarPolizaBancaria()
        If OperacionEsValida() Then
            'Tipo de operacion contable (cargo / abono) para el banco
            Select Case Documento.Dato.Tipo
                Case Info.Cheque.ID, Info.Debito.ID
                    Documento.Debe = STR_CARGO
                    Documento.Haber = STR_ABONO
                Case Info.Deposito.ID, Info.Credito.ID
                    If Documento.Dato.Grupo = clsBancos.BancoGrupo.Cliente And (Documento.Dato.Tipo = Info.Deposito.ID Or Documento.Dato.Tipo = Info.Credito.ID) Then
                        'Solo para Cliente en Deposito y NC
                        Documento.Debe = STR_CARGO
                        Documento.Haber = STR_ABONO
                    Else
                        Documento.Debe = STR_ABONO
                        Documento.Haber = STR_CARGO
                    End If
                Case Else
                    Throw New Exception("Invalid document type for this operation")
            End Select

            'Datos del encabezado de la poliza
            _Empresa = Sesion.IdEmpresa
            _Ejercicio = Documento.Ejercicio
            _Tipo = Documento.Modo
            _Modo = Documento.Modo

            _Fecha = Documento.Dato.Fecha
            _Moneda = Documento.Dato.Moneda
            _TC = Documento.Dato.Tasa
            _Tasa = Documento.Dato.Tasa

            _Referencia = Documento.Dato.Tipo
            _Ciclo = Documento.Dato.Ciclo
            _Numero = Documento.Dato.Numero

            _Usuario = Documento.Dato.Usuario
            _Estado = DEF_ESTADO

            _Observaciones = String.Empty
            _Concepto = PrepararConcepto()

            'Informacion de operacion contable para el documento (otra entidad / cuenta)
            Select Case Documento.Dato.Grupo
                Case clsBancos.BancoGrupo.Proveedor
                    OperarProveedor()
                Case clsBancos.BancoGrupo.Caja
                    OperarCaja()
                Case clsBancos.BancoGrupo.Cliente
                    OperarCliente()
                Case clsBancos.BancoGrupo.Empleado
                    OperarEmpleado()
                Case clsBancos.BancoGrupo.Planilla
                    OperarPlanilla()
                Case clsBancos.BancoGrupo.Transferencia
                    OperarTransferencia()
                Case clsBancos.BancoGrupo.Impuestos
                    OperarImpuesto()
            End Select

            'Escribir datos
            If Not (Documento.Dato.Item = NO_ITEM) Then
                'Numero de poliza y de transaccion (detalle)
                _Poliza = NuevaPoliza()
                Documento.Transaccion = NuevaTransaccion()
                Documento.TransaccionPDM = Documento.Transaccion

                'Escribir la poliza a la base de datos
                'Si ya tiene una poliza intentar borrarla (no se borra si no es del ejercicio actual)
                EscribirPoliza()
            End If
        Else
            Throw New System.Exception("Invalid operation for this group")
        End If
    End Sub

    'Prepara el contenido del campo concepto de acuerdo al grupo e item
    Private Function PrepararConcepto() As String
        Const STR_VARIOS As String = "Varios"

        'TODO revisar aqui y en clsBancos Bonificacion y Bono para Empleado, igual en documento bancario (no coinciden)
        Dim strGrupos() As String = New String(6) {"Pago,Impuestos,Anticipo sobre compra,Gastos",
                                                   "Liquidacion de caja,Apertura de caja,Anticipo de caja,Cierre de caja",
                                                   "Cobro,Descuento",
                                                   "Salario,Aguinaldo,Bono 14,Anticipo/prestamo,Devolucion de anticipo/prestamo,Liquidacion,Bono,Bono,Vacaciones,Indemnizacion,Devolucion de ISR",
                                                   "Planilla",
                                                   "En transito,Transferencia contra cuenta",
                                                   "Pago de IVA,Pago ISR asalariados,Pago ISR retenciones,Pago ISR mensual,Pago IVA retenciones"}

        Dim strDato As String = Documento.Dato.Catalogo & " #" & Documento.Dato.Documento & " de fecha " & Documento.Dato.Fecha.ToString("dd/MM/yyyy")

        'Agregar beneficiario excepto para transferencias
        If Not (Documento.Dato.Grupo = clsBancos.BancoGrupo.Transferencia) Then
            'Nombre, si no son multiples
            strDato &= " - " & IIf(Documento.Dato.EsMultiple, STR_VARIOS, Documento.Dato.Nombre)
        End If
        'Agrega al final la transaccion 
        If Not (Documento.Dato.Grupo = NO_GRUPO Or Documento.Dato.Item = NO_ITEM) Then
            'LATER validar grupo e item
            Dim texto As String() = strGrupos(Documento.Dato.Grupo).Split(New Char() {","c})
            strDato &= " ({texto})".Replace("{texto}", texto(Documento.Dato.Item))
        End If

        'Agrega notas al final
        strDato &= " - " & Documento.Dato.Nota_

        Return strDato
    End Function

    '00 Opera una transaccion de Proveedor
    Private Sub OperarProveedor()
        Dim da As MySqlDataAdapter
        Dim dt As System.Data.DataTable, dn As System.Data.DataTable
        Dim row As DataRow

        Dim dblDiferencial As Double = INT_CERO
        Dim dblTemp As Double = INT_CERO
        Dim strSQL As String

        intItem = INT_CERO
        If Not (Documento.Dato.Item = NO_ITEM) Then
            'Informacion de detalle de la cuenta bancaria
            strSQL = Base.SQLContaBanco(Documento.Dato.Tipo, Documento.Dato.Ciclo, Documento.Dato.Numero)
            Using cmd As New MySqlCommand(strSQL, CON)
                da = New MySqlDataAdapter(cmd)
                dt = New System.Data.DataTable
                da.Fill(dt)
            End Using
            PrepararDetalle(Documento.Haber, dt,,, True,, Documento.Modo)

            'Información de detalle del documento de soporte
            strSQL = SqlOperarProveedor()
            Using cmd As New MySqlCommand(strSQL, CON)
                cmd.Parameters.AddWithValue("@empresa", Sesion.IdEmpresa)
                cmd.Parameters.AddWithValue("@tipo", Documento.Dato.Tipo)
                cmd.Parameters.AddWithValue("@ciclo", Documento.Dato.Ciclo)
                cmd.Parameters.AddWithValue("@numero", Documento.Dato.Numero)

                da = New MySqlDataAdapter(cmd)
                dt = New System.Data.DataTable
                da.Fill(dt)
            End Using

            If Documento.Dato.Item.Equals(clsBancos.EnumProveedor.Pago) Then
                'Linea de pago
                dblDiferencial = Math.Round(ObtenerDiferencial(dt), DEC_TOTAL)

                'Anticipo sobre compras
                row = dt.Rows(INT_CERO)
                If CDbl(row("anticipo")) > INT_CERO Then
                    dn = RecuperarAnticipo(dt)
                    PrepararDetalle(Documento.Haber, dn,,, True,, Documento.Modo)
                End If

                'Si el documento tiene detalle
                Dim intLineas As Integer = LineasDeDocumento()
                If intLineas.Equals(INT_CERO) Then
                    PrepararDetalleTotal(Documento.Debe, dt)
                Else
                    dn = RecuperarDetalleGrupo(dt)
                    PrepararDetalle(Documento.Debe, dn,,,,, Documento.Modo)
                End If
            ElseIf Documento.Dato.Item.Equals(clsBancos.EnumProveedor.Gasto) Then
                'Linea de gasto
                PrepararDetalleGasto(Documento.Debe, dt)
                dblDiferencial = Math.Round(ObtenerDiferencial(dt), DEC_TOTAL)
            Else
                PrepararDetalle(Documento.Debe, dt,,,,, Documento.Modo)
            End If

            'Si hay diferencial
            If Math.Abs(dblDiferencial) > INT_CERO Then
                If dblDiferencial > INT_CERO Then
                    'Si es positivo
                    PrepararDetalle(STR_CARGO, dt, dblDiferencial, True,,, Documento.Modo)
                Else : PrepararDetalle(STR_ABONO, dt, dblDiferencial, True,,, Documento.Modo)
                End If
            End If

            'Verifica la suma de las operaciones
            dblTemp = SaldoDeOperaciones(EnumSaldo.Diferencia)
            If Not dblTemp.Equals(INT_CERO) Then
                ActualizarOperaciones()
            End If
        End If
    End Sub

    'Actualiza el detalle de acuerdo al saldo de las operaciones
    Private Sub ActualizarOperaciones()
        Dim dblCargo As Double = SaldoDeOperaciones(EnumSaldo.Cargo)
        Dim dblAbono As Double = SaldoDeOperaciones(EnumSaldo.Abono)
        Dim dblDiferencia As Double = (dblCargo - dblAbono)
        Dim strOpera As String = STR_CARGO

        If dblDiferencia < 0 Then
            dblDiferencia = dblDiferencia * -1
        End If
        'Si hay diferencia de al menos un centavo
        If dblDiferencia > 0.009 Then
            'Determinar diferencia y operacion para sumar
            If dblDiferencia < 0 Then dblDiferencia = (dblDiferencia * (-1))
            If dblCargo > dblAbono Then strOpera = STR_ABONO

            For Each det As DatoDetalle In Detalle
                If det.Operacion = strOpera Then
                    'Sumar la diferencia a la primera linea de esa operacion
                    det.Importe += dblDiferencia
                    Exit For
                End If
            Next
        End If
    End Sub

    Private Function SqlOperarProveedor() As String
        Dim strSQL As String = String.Empty
        Dim strTemp As String

        'Campos: fecha, tasa, total, usuario, multiple, cuenta, presupuesto, [documentonumero]
        Select Case Documento.Dato.Item
            Case clsBancos.EnumProveedor.Pago
                'NOTA ahora se verifica si en el detalle tiene valor RF2_Dbl y eso se toma como tasa del documento
                strSQL = " SELECT x.* " &
                         " FROM ( " &
                         " SELECT h.HDoc_Doc_Fec Fecha, " &
                         "        ROUND(h.HDoc_Doc_TC, 5) Tasa, " &
                         "        IF(h.HDoc_Doc_Mon={local}, IF(f.HDoc_Doc_Mon = {externa}, Round((ROUND(d.DDoc_RF1_Dbl/h.HDoc_Doc_TC,2))*f.HDoc_Doc_TC,2), ROUND(h.HDoc_RF1_Dbl, 2)), (ROUND(h.HDoc_Doc_TC * h.HDoc_RF1_Dbl, 2))) Total, " &
                         "        IF(h.HDoc_Doc_Mon = {local}, IF(f.HDoc_Doc_Mon = {externa}, Round((ROUND(d.DDoc_RF1_Dbl/h.HDoc_Doc_TC,2))*f.HDoc_Doc_TC,2), ROUND(h.HDoc_RF1_Dbl, 2)), IF(d.DDoc_RF1_Num=0,(ROUND(d.DDoc_Prd_Net,2)),IF(f.HDoc_Doc_Mon = {local},(ROUND(d.DDoc_Prd_Net,2)),(ROUND(f.HDoc_Doc_TC * d.DDoc_RF1_Dbl,2))))) Parcial, d.DDoc_RF1_Dbl parcial2,  " &
                         "        h.HDoc_Usuario Usuario, ROUND(((IFNULL(f.HDoc_RF1_Dbl,0) - d.DDoc_RF1_Dbl) * h.HDoc_Doc_TC)+ 0.0000000001,2) Retencion, " &
                         "        IFNULL(h.HDoc_DR1_Emp, 0) Multiple, " &
                         "        IFNULL(h.HDoc_Emp_NIT,'') Presupuesto, " &
                         "        b.BCta_Mon BancoMoneda, b.BCta_Cuenta BancoCuenta, " &
                         "        h.HDoc_Emp_Cod BeneficiarioID, IFNULL(p.pro_cuenta,'') BeneficiarioCuenta, d.DDoc_Prd_Ref BeneficiarioGasto, " &
                         "        IFNULL(f.HDoc_Emp_Cod, 0) ProveedorID, IFNULL(z.pro_cuenta, d.DDoc_Prd_Ref) ProveedorCuenta, " &
                         "        IFNULL(f.HDoc_Doc_Num,'') DocumentoNumero, ROUND(IFNULL(IF(d.DDoc_RF2_Dbl>1,d.DDoc_RF2_Dbl,f.HDoc_Doc_TC),0),5) DocumentoTasa, IFNULL(f.HDoc_Doc_Mon, 0) DocumentoMoneda, ROUND({suma}(IFNULL(f.HDoc_RF1_Dbl,0)), 2) DocumentoMonto, " &
                         "        IFNULL(h.HDoc_Ant_Com,0) Anticipo, " &
                         "        d.DDoc_Sis_Emp Empresa, d.DDoc_Doc_Cat Tipo, d.DDoc_Doc_Ano Ciclo, d.DDoc_Doc_Num Numero, d.DDoc_Doc_Lin Linea {campos}"

                strSQL = strSQL.Replace("{suma}", String.Empty)
                If Documento.Dato.EsMultiple Then
                    strSQL = strSQL.Replace("{campos}", String.Empty)
                Else
                    strTemp = ", ROUND( (f.HDoc_RF1_Dbl +  
                                         IFNULL( (SELECT SUM(IF(s.ECta_Doc_Cat IN (40,53,54),
						  		                                IF(f.HDoc_Doc_Mon=177, 
									   	                           (CASE WHEN s.ECta_moneda=f.HDoc_Doc_Mon THEN s.ECta_Crgo_Loc ELSE ROUND(s.ECta_Crgo_Ext * s.ECta_TC,2) END),
										                           (CASE WHEN s.ECta_moneda=f.HDoc_Doc_Mon THEN ROUND(s.ECta_Crgo_Ext * f.HDoc_Doc_TC,2)ELSE s.ECta_Crgo_Loc END)), 0)) - 
						                                 (SUM(IF(s.ECta_Doc_Cat IN (39,51,52),
						  		                                 IF(f.HDoc_Doc_Mon=177, 
									                                (CASE WHEN s.ECta_moneda=f.HDoc_Doc_Mon THEN s.ECta_Abno_Loc ELSE ROUND(s.ECta_Abno_Ext * s.ECta_TC,2) END), 
									                                (CASE WHEN s.ECta_moneda=f.HDoc_Doc_Mon THEN  ROUND(s.ECta_Abno_Ext * f.HDoc_Doc_TC,2) ELSE (s.ECta_Abno_Ext * f.HDoc_Doc_TC) END)), 0)) + 
						                                 (SELECT IFNULL(SUM(r.HDoc_RF1_Dbl),0) 
						  		                          FROM Dcmtos_HDR r     
						  		                          WHERE r.HDoc_Sis_Emp=f.HDoc_Sis_Emp AND r.HDoc_Doc_Cat=220 AND r.HDoc_Pro_DCat=f.HDoc_Doc_Cat AND r.HDoc_Pro_DAno=f.HDoc_Doc_Ano AND r.HDoc_Pro_DNum=f.HDoc_Doc_Num))										
			  		                            FROM ECtaCte s
			  		                            WHERE s.ECta_Sis_Emp=f.HDoc_Sis_Emp AND s.ECta_Ref_Cat=f.HDoc_Doc_Cat AND s.ECta_Ref_Ano=f.HDoc_Doc_Ano AND s.ECta_Ref_Num=f.HDoc_Doc_Num AND NOT(s.ECta_Doc_Cat=f.HDoc_Doc_Cat AND s.ECta_Doc_Ano=f.HDoc_Doc_Ano AND s.ECta_Doc_Num=f.HDoc_Doc_Num) and not(s.ECta_Doc_Cat=h.HDoc_Doc_Cat AND s.ECta_Doc_Ano=h.HDoc_Doc_Ano AND s.ECta_Doc_Num=h.HDoc_Doc_Num)), 0)), 2) Saldo"
                    strSQL = strSQL.Replace("{campos}", strTemp)
                End If

                strSQL &= " FROM Dcmtos_HDR h " &
                          "      LEFT JOIN Dcmtos_DTL  d ON d.DDoc_Sis_Emp = h.HDoc_Sis_Emp AND d.DDoc_Doc_Cat = h.HDoc_Doc_Cat AND d.DDoc_Doc_Ano = h.HDoc_Doc_Ano AND d.DDoc_Doc_Num = h.HDoc_Doc_Num " &
                          "      LEFT JOIN Dcmtos_HDR  f ON f.HDoc_Sis_Emp = d.DDoc_Sis_Emp AND f.HDoc_Doc_Cat = d.DDoc_RF1_Num AND f.HDoc_Doc_Ano = d.DDoc_RF2_Num AND f.HDoc_Doc_Num = d.DDoc_RF3_Num " &
                          "      LEFT JOIN CtasBcos    b ON b.BCta_Sis_Emp = h.HDoc_Sis_Emp AND b.BCta_Num = h.HDoc_RF1_Num " &
                          "      LEFT JOIN Proveedores p ON p.pro_sisemp = h.HDoc_Sis_Emp AND p.pro_codigo = h.HDoc_Emp_Cod " &
                          "      LEFT JOIN Proveedores z ON z.pro_sisemp = f.HDoc_Sis_Emp AND z.pro_codigo = f.HDoc_Emp_Cod " &
                          " WHERE h.HDoc_Sis_Emp=@empresa AND h.HDoc_Doc_Cat=@tipo AND h.HDoc_Doc_Ano=@ciclo AND h.HDoc_Doc_Num=@numero ) x"
                strSQL &= " GROUP BY x.Empresa, x.Tipo, x.Ciclo, x.Numero, x.Linea "
            Case clsBancos.EnumProveedor.Anticipo
                strSQL = " SELECT h.HDoc_Doc_Fec Fecha, " &
                         "        ROUND(h.HDoc_Doc_TC, 4) Tasa, " &
                         "        IF(h.HDoc_Doc_Mon={local}, ROUND(h.HDoc_RF1_Dbl, 2), (ROUND(h.HDoc_Doc_TC * h.HDoc_RF1_Dbl, 2))) Total, " &
                         "        h.HDoc_Usuario Usuario, " &
                         "        IFNULL(h.HDoc_DR1_Emp, 0)  Multiple, " &
                         "        IFNULL(p.pro_anticipos,'') Cuenta, " &
                         "        IFNULL(h.HDoc_Emp_NIT,'') Presupuesto, " &
                         "        '' DocumentoNumero  " &
                         " FROM Dcmtos_HDR h " &
                         "      LEFT JOIN Proveedores p ON p.pro_sisemp = h.HDoc_Sis_Emp AND p.pro_codigo = h.HDoc_Emp_Cod " &
                         " WHERE h.HDoc_Sis_Emp=@empresa AND h.HDoc_Doc_Cat=@tipo AND h.HDoc_Doc_Ano=@ciclo AND h.HDoc_Doc_Num=@numero "
            Case clsBancos.EnumProveedor.Gasto
                strSQL = " SELECT h.HDoc_Doc_Fec Fecha, " &
                         "        ROUND(h.HDoc_Doc_TC, 4) Tasa, " &
                         "        IF(h.HDoc_Doc_Mon={local}, ROUND(d.DDoc_RF1_Dbl, 2), (ROUND(h.HDoc_Doc_TC * d.DDoc_RF1_Dbl, 2))) Total, " &
                         "        h.HDoc_Usuario Usuario, " &
                         "        IFNULL(h.HDoc_DR1_Emp, 0) Multiple, " &
                         "        IFNULL(d.DDoc_Prd_Ref,'') Cuenta, " &
                         "        IFNULL(h.HDoc_Emp_NIT,'') Presupuesto, " &
                         "        '' DocumentoNumero,d.DDoc_RF2_Dbl DocumentoTasa,d.DDoc_RF1_Dbl Parcial2,b.BCta_Mon BancoMoneda,IFNULL(f.HDoc_Doc_Mon, 0) DocumentoMoneda  " &
                         " FROM Dcmtos_HDR h " &
                         "      LEFT JOIN Dcmtos_DTL d ON d.DDoc_Sis_Emp = h.HDoc_Sis_Emp AND d.DDoc_Doc_Cat = h.HDoc_Doc_Cat AND d.DDoc_Doc_Ano = h.HDoc_Doc_Ano AND d.DDoc_Doc_Num = h.HDoc_Doc_Num " &
                         "      LEFT JOIN CtasBcos b ON b.BCta_Sis_Emp = h.HDoc_Sis_Emp AND b.BCta_Num = h.HDoc_RF1_Num " &
                         "      LEFT JOIN Dcmtos_HDR f ON f.HDoc_Sis_Emp = d.DDoc_Sis_Emp AND f.HDoc_Doc_Cat = d.DDoc_RF1_Num AND f.HDoc_Doc_Ano = d.DDoc_RF2_Num AND f.HDoc_Doc_Num = d.DDoc_RF3_Num " &
                         " WHERE h.HDoc_Sis_Emp=@empresa AND h.HDoc_Doc_Cat=@tipo AND h.HDoc_Doc_Ano=@ciclo AND h.HDoc_Doc_Num=@numero "
            Case clsBancos.EnumProveedor.Impuesto
                strSQL = " SELECT h.HDoc_Doc_Fec Fecha, " &
                         "        ROUND(h.HDoc_Doc_TC, 4) Tasa, " &
                         "        IF(h.HDoc_Doc_Mon={local}, ROUND(h.HDoc_RF1_Dbl, 2), (ROUND(h.HDoc_Doc_TC * h.HDoc_RF1_Dbl, 2))) Total, " &
                         "        h.HDoc_Usuario Usuario, " &
                         "        IFNULL(h.HDoc_DR1_Emp, 0)  Multiple, " &
                         "        '' Cuenta, " &
                         "        IFNULL(h.HDoc_Emp_NIT,'') Presupuesto, " &
                         "        '' DocumentoNumero " &
                         " FROM Dcmtos_HDR h " &
                         " WHERE h.HDoc_Sis_Emp=@empresa AND h.HDoc_Doc_Cat=@tipo AND h.HDoc_Doc_Ano=@ciclo AND h.HDoc_Doc_Num=@numero "
            Case clsBancos.EnumProveedor.Pendiente
        End Select
        strSQL = strSQL.Replace("{local}", Divisa.Local.id.ToString)
        strSQL = strSQL.Replace("{externa}", Divisa.Externa.id.ToString)

        Return strSQL
    End Function

    'Determinar el saldo de las operaciones (cargo, abono, diferencial)
    Private Function SaldoDeOperaciones(ByVal Tipo As EnumSaldo) As Double
        Dim d As Double = INT_CERO
        Dim dblCargo As Double
        Dim dblAbono As Double

        For Each det As DatoDetalle In Detalle
            If det.Operacion = STR_ABONO Then
                dblCargo = 0
                dblAbono = det.Importe
            ElseIf det.Operacion = STR_CARGO Then
                dblCargo = det.Importe
                dblAbono = 0
            End If

            Select Case Tipo
                Case EnumSaldo.Cargo
                    d += dblCargo
                Case EnumSaldo.Abono
                    d += dblAbono
                Case Else
                    d += (dblAbono - dblCargo)
            End Select
        Next

        Return Math.Round(d, 2)
    End Function

    'Devuelve la cantidad de lineas de detalle del documento de soporte
    Private Function LineasDeDocumento(Optional Codigo As String = Nothing) As Integer
        Dim i As Integer = INT_CERO
        Dim strCodigo = If(Codigo, String.Empty)
        Dim strSQL As String = " SELECT COUNT(*) FROM Dcmtos_DTL WHERE DDoc_Sis_Emp=@empresa AND DDoc_Doc_Cat=@tipo AND DDoc_Doc_Ano=@ciclo AND DDoc_Doc_Num=@numero {codigo}"

        'Filtrar por codigo
        If Not strCodigo.Equals(String.Empty) Then
            strSQL = strSQL.Replace("{codigo}", " AND DDoc_RF2_Cod={codigo}").Replace("{codigo}", Base.Text(Codigo))
        Else : strSQL = strSQL.Replace("{codigo}", String.Empty)
        End If

        Using cmd As New MySqlCommand(strSQL, CON)
            cmd.Parameters.AddWithValue("@empresa", Sesion.IdEmpresa)
            cmd.Parameters.AddWithValue("@tipo", Documento.Dato.Tipo)
            cmd.Parameters.AddWithValue("@ciclo", Documento.Dato.Ciclo)
            cmd.Parameters.AddWithValue("@numero", Documento.Dato.Numero)

            i = CInt(cmd.ExecuteScalar)
        End Using
        Return i
    End Function

    'Devuelve el monto del diferencial cambiario
    Private Function ObtenerDiferencial(ByRef Tabla As System.Data.DataTable)
        Dim dblTemp1 As Double
        Dim dblTemp2 As Double
        Dim dblSuma As Double
        Dim dblDiferencial As Double = 0.0
        Dim logPrimeraLinea As Boolean = False

        If Tabla.Rows.Count > INT_CERO Then
            For Each dr As DataRow In Tabla.Rows
                If Not String.IsNullOrEmpty(dr("DocumentoNumero").ToString()) Then
                    dblSuma = 0.0
                    If CInt(dr("BancoMoneda")).Equals(Divisa.Externa.id) And CInt(dr("DocumentoMoneda")).Equals(Divisa.Externa.id) Then
                        'If (Documento.Dato.Tipo = 51) Or (Documento.Dato.Tipo = 52) Then
                        '    If logPrimeraLinea = False Then
                        '        ''Carga Saldo para el diferencial si existiera
                        '        'dblTemp2 = Math.Round((dr("DocumentoTasa") * dr("parcial2")), 2)
                        '        'dblSuma = Math.Round((dr("Total") - dblTemp2), 2)
                        '        'dblTemp1 = dblSuma
                        '        'logPrimeraLinea = True
                        '        'dblDiferencial += dblSuma
                        '        dblTemp1 = Math.Round((Documento.Dato.Tasa * CDbl(dr("Parcial"))), 2)
                        '        dblTemp2 = Math.Round((dr("DocumentoTasa") * dr("Parcial")), 2)
                        '        dblSuma = Math.Round(((dblTemp1 - dblTemp2) / dr("DocumentoTasa")), 2)
                        '        dblDiferencial += dblSuma
                        '        logPrimeraLinea = True
                        '    Else
                        '        ' va restando al saldo inicial
                        '        dblTemp2 = Math.Round((dr("DocumentoTasa") * dr("parcial2")), 2)
                        '        dblSuma = (dblTemp2 * -1)
                        '        dblDiferencial += dblSuma
                        '    End If
                        'Else
                        'Ambas monedas son externas
                        If Sesion.IdEmpresa = 18 Or Sesion.IdEmpresa = 19 Or Sesion.IdEmpresa = 21 Then
                            If Documento.Dato.Tipo = 51 Or Documento.Dato.Tipo = 52 Then
                                If Documento.Dato.Grupo.Equals(clsBancos.BancoGrupo.Proveedor) Then
                                    'dblTemp1 = Math.Round((dr("DocumentoTasa") * CDbl(dr("DocumentoMonto"))), 2)
                                    'dblTemp1 = Math.Round(dblTemp1 - dr("Retencion"), 2)
                                    'dblTemp2 = Math.Round((dr("Tasa") * dr("Parcial2")), 2)
                                    'dblSuma = Math.Round(((dblTemp2 - dblTemp1)), 2)
                                    dblTemp1 = Math.Round((dr("Tasa") * CDbl(dr("Parcial2"))), 2)
                                    dblTemp2 = Math.Round((dr("DocumentoTasa") * dr("Parcial2")), 2)
                                    dblSuma = Math.Round(((dblTemp1 - dblTemp2)), 2)
                                Else
                                    dblTemp1 = Math.Round((Documento.Dato.Tasa * CDbl(dr("Parcial"))), 2)
                                    dblTemp2 = Math.Round((dr("DocumentoTasa") * dr("Parcial")), 2)
                                    dblSuma = Math.Round(((dblTemp1 - dblTemp2) / dr("DocumentoTasa")), 2)
                                End If

                            Else
                                dblTemp1 = Math.Round((Documento.Dato.Tasa * CDbl(dr("Parcial"))), 2)
                                dblTemp2 = Math.Round((dr("DocumentoTasa") * dr("Parcial")), 2)
                                dblSuma = Math.Round(((dblTemp1 - dblTemp2) / dr("DocumentoTasa")), 2)
                            End If

                        Else
                            dblTemp1 = Math.Round((Documento.Dato.Tasa * CDbl(dr("Parcial"))), 2)
                            dblTemp2 = Math.Round((dr("DocumentoTasa") * dr("Parcial")), 2)
                            dblSuma = Math.Round(((dblTemp1 - dblTemp2) / dr("DocumentoTasa")), 2)
                        End If

                        dblDiferencial += dblSuma
                        'End If
                    ElseIf CInt(dr("BancoMoneda")).Equals(Divisa.Externa.id) And CInt(dr("DocumentoMoneda")).Equals(Divisa.Local.id) And CDbl(dr("DocumentoTasa")) > INT_UNO Then
                        'Moneda de banco es externa, documento es local y mayor que 1 
                        dblTemp1 = Math.Round((CDbl(dr("Parcial2")) * Documento.Dato.Tasa), 2)
                        dblTemp2 = Math.Round((CDbl(dr("Parcial2")) * dr("DocumentoTasa")), 2)
                        dblSuma = (dblTemp1 - dblTemp2)
                        dblDiferencial += dblSuma
                    ElseIf CInt(dr("BancoMoneda")).Equals(Divisa.Local.id) And CInt(dr("DocumentoMoneda")).Equals(Divisa.Externa.id) Then
                        'Moneda de banco es local, documento es externa
                        Dim montoTemp As Double
                        montoTemp = dr("parcial") / dr("tasa")
                        dblTemp1 = Math.Round((Documento.Dato.Tasa * montoTemp), 2)
                        dblTemp2 = Math.Round((dr("DocumentoTasa") * montoTemp), 2)
                        dblSuma = ((dblTemp1 - dblTemp2))
                        dblDiferencial += dblSuma
                    ElseIf CInt(dr("BancoMoneda")).Equals(Divisa.Externa.id) And CInt(dr("DocumentoMoneda")).Equals(Divisa.Local.id) Then
                        'Si se usa la tasa del banco con moneda local no hay diferencial
                        'TODO documento en moneda local sin tasa de cambio, ir a traer la tasa mas proxima a esta fecha
                    ElseIf CInt(dr("BancoMoneda")).Equals(Divisa.Local.id) And CInt(dr("DocumentoMoneda")).Equals(Divisa.Local.id) Then
                        'If logPrimeraLinea = False Then
                        '    'Carga Saldo para el diferencial si existiera
                        '    dblTemp2 = Math.Round(dr("parcial2"), 2)
                        '    dblSuma = Math.Round((dr("Total") - dblTemp2), 2)
                        '    dblTemp1 = dblSuma
                        '    logPrimeraLinea = True
                        '    dblDiferencial += dblSuma
                        'Else
                        '    ' va restando al saldo inicial
                        '    dblTemp2 = Math.Round(dr("parcial2"), 2)
                        '    dblSuma = (dblTemp2 * -1)
                        '    dblDiferencial += dblSuma
                        'End If
                    End If
                Else
                    If CInt(dr("BancoMoneda")).Equals(Divisa.Externa.id) And CInt(dr("DocumentoMoneda")).Equals(Divisa.Externa.id) Then
                        ' va restando al saldo inicial
                        dblTemp1 = Math.Round((Documento.Dato.Tasa * CDbl(dr("parcial2"))), 2)
                        dblTemp2 = Math.Round((dr("DocumentoTasa") * dr("parcial2")), 2)

                        dblSuma = ((dblTemp2 - dblTemp1) * -1)
                        dblDiferencial += dblSuma
                    ElseIf CInt(dr("BancoMoneda")).Equals(Divisa.Externa.id) And CInt(dr("DocumentoMoneda")).Equals(Divisa.Local.id) And CDbl(dr("DocumentoTasa")) > INT_UNO Then
                        ' va restando al saldo inicial
                        dblTemp1 = Math.Round((Documento.Dato.Tasa * CDbl(dr("parcial2"))), 2)
                        dblTemp2 = Math.Round((dr("DocumentoTasa") * dr("parcial2")), 2)

                        dblSuma = ((dblTemp2 - dblTemp1) * -1)
                        dblDiferencial += dblSuma
                    ElseIf CInt(dr("BancoMoneda")).Equals(Divisa.Local.id) And CInt(dr("DocumentoMoneda")).Equals(Divisa.Externa.id) Then
                        ' va restando al saldo inicial
                        dblTemp1 = Math.Round((Documento.Dato.Tasa * CDbl(dr("parcial2"))), 2)
                        dblTemp2 = Math.Round((dr("DocumentoTasa") * dr("parcial2")), 2)

                        dblSuma = ((dblTemp2 - dblTemp1) * -1)
                        dblDiferencial += dblSuma
                    ElseIf CInt(dr("BancoMoneda")).Equals(Divisa.Externa.id) And CInt(dr("DocumentoMoneda")).Equals(INT_CERO) Then
                        ' va restando al saldo inicial
                        If Not Sesion.IdEmpresa = 16 Then
                            dblTemp1 = Math.Round((Documento.Dato.Tasa * CDbl(dr("parcial2"))), 2)
                            dblTemp2 = Math.Round((dr("DocumentoTasa") * dr("parcial2")), 2)

                            dblSuma = ((dblTemp2 - dblTemp1) * -1)
                            dblDiferencial += dblSuma
                        End If
                    ElseIf CInt(dr("BancoMoneda")).Equals(Divisa.Local.id) And CInt(dr("DocumentoMoneda")).Equals(INT_CERO) Then

                    ElseIf CInt(dr("BancoMoneda")).Equals(Divisa.Local.id) And CInt(dr("DocumentoMoneda")).Equals(Divisa.Local.id) Then

                    End If

                    'If (Documento.Dato.Tipo = 51) Or (Documento.Dato.Tipo = 52) Then
                    '    If logPrimeraLinea = False Then
                    '        If CInt(dr("BancoMoneda")).Equals(Divisa.Local.id) Then
                    '            'Carga Saldo para el diferencial si existiera
                    '            dblTemp2 = Math.Round(dr("parcial2"), 2)
                    '            dblSuma = Math.Round((dr("Total") - dblTemp2), 2)
                    '            dblTemp1 = dblSuma
                    '            logPrimeraLinea = True
                    '            dblDiferencial += dblSuma

                    '            '        'Carga Saldo para el diferencial si existiera
                    '            '        dblTemp2 = Math.Round((dr("DocumentoTasa") * dr("parcial2")), 2)
                    '            '        dblSuma = Math.Round((dr("Total") - dblTemp2), 2)
                    '            '        dblTemp1 = dblSuma

                    '        Else
                    '            'Carga Saldo para el diferencial si existiera
                    '            dblTemp2 = Math.Round((dr("DocumentoTasa") * dr("parcial2")), 2)
                    '            dblSuma = Math.Round((dr("Total") - dblTemp2), 2)
                    '            dblTemp1 = dblSuma
                    '            logPrimeraLinea = True
                    '            dblDiferencial += dblSuma
                    '        End If
                    '    Else
                    '        If (Documento.Dato.Tipo = 51) Or (Documento.Dato.Tipo = 52) Then
                    '            If CInt(dr("BancoMoneda")).Equals(Divisa.Local.id) Then
                    '                ' va restando al saldo inicial
                    '                dblTemp2 = Math.Round(dr("parcial2"), 2)
                    '                dblSuma = (dblTemp2 * -1)
                    '                dblDiferencial += dblSuma

                    '            Else
                    '                ' va restando al saldo inicial
                    '                dblTemp1 = Math.Round((Documento.Dato.Tasa * CDbl(dr("parcial2"))), 2)
                    '                dblTemp2 = Math.Round((dr("DocumentoTasa") * dr("parcial2")), 2)

                    '                dblSuma = ((dblTemp2 - dblTemp1) * -1)
                    '                dblDiferencial += dblSuma
                    '            End If
                    '        End If
                    '    End If
                    'End If
                End If
            Next
        End If
        Return Math.Round(dblDiferencial, 2)
    End Function

    'Devuelve los datos de anticipo sobre compra
    Private Function RecuperarAnticipo(ByRef Tabla As System.Data.DataTable) As System.Data.DataTable
        Dim strSQL As String = " SELECT IFNULL((SELECT valor FROM {conta}.parametros_empresa WHERE empresa= h.HDoc_Sis_Emp AND parametro = {parametro}),'anticipoNoConfigurado') Cuenta, " &
                               "		  IFNULL(h.HDoc_Emp_NIT, '') Presupuesto , " &
                               "		  ROUND(h.HDoc_Doc_TC, 5) Tasa, " &
                               "		  IF(h.HDoc_Doc_Mon={externa}, (ROUND(h.HDoc_Ant_Com * h.HDoc_Doc_TC, 2)), ROUND(h.HDoc_Ant_Com, 2)) Total " &
                               " FROM Dcmtos_HDR h " &
                               "	   LEFT JOIN CtasBcos b    ON b.BCta_Sis_Emp = h.HDoc_Sis_Emp AND b.BCta_Num = h.HDoc_RF1_Num " &
                               " WHERE h.HDoc_Sis_Emp=@empresa AND h.HDoc_Doc_Cat=@tipo AND h.HDoc_Doc_Ano=@ciclo AND h.HDoc_Doc_Num=@numero "
        strSQL = strSQL.Replace("{parametro}", CInt(EnumParametro.AnticipoDeCompra).ToString)
        strSQL = strSQL.Replace("{externa}", Divisa.Externa.id.ToString)
        strSQL = strSQL.Replace("{conta}", Sesion.BaseConta)

        Dim da As MySqlDataAdapter
        Dim dt As System.Data.DataTable

        Using cmd As New MySqlCommand(strSQL, CON)
            cmd.Parameters.AddWithValue("@empresa", Sesion.IdEmpresa)
            cmd.Parameters.AddWithValue("@tipo", Documento.Dato.Tipo)
            cmd.Parameters.AddWithValue("@ciclo", Documento.Dato.Ciclo)
            cmd.Parameters.AddWithValue("@numero", Documento.Dato.Numero)

            da = New MySqlDataAdapter(cmd)
            dt = New System.Data.DataTable
            da.Fill(dt)
        End Using

        Return dt
    End Function

    'Devuelve los datos totalizados de cliente o proveedor para el detalle de poliza
    Private Function RecuperarDetalleGrupo(ByRef Tabla As System.Data.DataTable) As System.Data.DataTable
        Dim strSQL As String
        Dim strTabla As String = String.Concat(Sesion.Usuario.ToLower, "_detalle_poliza")

        Dim dblTasa As Double = 0
        Dim dblMonto As Double

        Dim dt As System.Data.DataTable

        'Crear tabla temporal para datos de cliente o proveedor  
        strSQL = "CREATE TEMPORARY TABLE IF NOT EXISTS {tabla} (Monto DOUBLE, BeneficiarioID INT, BeneficiarioCuenta VARCHAR(20), BeneficiarioGasto VARCHAR(20), ProveedorID INT, ProveedorCuenta VARCHAR(20))".Replace("{tabla}", strTabla)
        If Sesion.IdEmpresa = 18 Then
            strSQL &= ";CREATE TEMPORARY TABLE IF NOT EXISTS PDM.{tabla} (Monto DOUBLE, BeneficiarioID INT, BeneficiarioCuenta VARCHAR(20), BeneficiarioGasto VARCHAR(20), ProveedorID INT, ProveedorCuenta VARCHAR(20))".Replace("{tabla}", strTabla)
        End If
        clsQuery.Execute(strSQL)

        'Borrar el contenido si ya existe
        strSQL = "DELETE FROM {tabla}".Replace("{tabla}", strTabla)
        If Sesion.IdEmpresa = 18 Then
            strSQL &= ";DELETE FROM PDM.{tabla}".Replace("{tabla}", strTabla)
        End If
        clsQuery.Execute(strSQL)

        For Each row As DataRow In Tabla.Rows
            strSQL = "INSERT INTO {tabla} VALUES( {monto}, {BeneficiarioID}, {BeneficiarioCuenta}, {BeneficiarioGasto}, {ProveedorID}, {ctaProveedor} )".Replace("{tabla}", strTabla)
            If Sesion.IdEmpresa = 18 Then
                strSQL &= ";INSERT INTO PDM.{tabla} VALUES( {monto}, {BeneficiarioID}, {BeneficiarioCuenta}, {BeneficiarioGasto}, {ProveedorID}, {ctaProveedor} )".Replace("{tabla}", strTabla)
            End If
            If CInt(row("BancoMoneda")).Equals(Divisa.Externa.id) And ((CInt(row("DocumentoMoneda")).Equals(Divisa.Externa.id))) Then
                'Moneda banco externa, moneda documento externa 
                'INFO monto en moneda local del documento (monto $ * tasa de cambio de documento)
                'NOTA aca no deberia venir ningun documento sin tasa
                If Sesion.IdEmpresa = 18 Or Sesion.IdEmpresa = 19 Or Sesion.IdEmpresa = 21 Then
                    If Documento.Dato.Tipo = 51 Or Documento.Dato.Tipo = 52 Then
                        'If Documento.Dato.Grupo.Equals(clsBancos.BancoGrupo.Proveedor) Then
                        '    dblMonto = Math.Round((row("DocumentoMonto") * row("DocumentoTasa")) - row("Retencion"), 2)
                        'Else
                        '    dblMonto = Math.Round(CDbl(row("parcial")), 5)
                        'End If
                        dblMonto = Math.Round(CDbl(row("parcial")), 5)


                        'dblMonto = Math.Round(dblMonto - CDbl(row("Total")), 5)
                    Else
                        dblMonto = Math.Round(CDbl(row("parcial")), 5)
                    End If
                Else
                    dblMonto = Math.Round(CDbl(row("parcial")), 5)
                End If

                strSQL = strSQL.Replace("{monto}", dblMonto)
            ElseIf CInt(row("BancoMoneda")).Equals(Divisa.Externa.id) And (CInt(row("DocumentoMoneda")).Equals(Divisa.Local.id)) Then
                'Moneda banco externa, moneda documento local 
                'INFO si el documento viene sin tasa valida se usa la del banco
                dblTasa = CDbl(row("DocumentoTasa"))
                If dblTasa <= 1 Then
                    'TODO ir a traer la tasa de cambio mas proxima p ara esta fecha
                    dblTasa = CDbl(row("tasa"))
                End If
                dblMonto = Math.Round(CDbl(row("parcial2")) * dblTasa, 5)
                strSQL = strSQL.Replace("{monto}", dblMonto)
            ElseIf CInt(row("BancoMoneda")).Equals(Divisa.Local.id) And (CInt(row("DocumentoMoneda")).Equals(Divisa.Local.id)) Then
                'Moneda banco local, moneda documento local
                'INFO banco y documento en moneda local no hay necesidad de convertir
                If (Sesion.IdEmpresa = 12 And (Documento.Dato.Tipo = 53 Or Documento.Dato.Tipo = 54)) Or (Sesion.idGiro = 2 And (Documento.Dato.Tipo = 53 Or Documento.Dato.Tipo = 54)) Then ' Hilos
                    dblMonto = CDbl(row("parcial"))
                Else
                    dblMonto = CDbl(row("parcial2"))
                End If

                strSQL = strSQL.Replace("{monto}", dblMonto)

            ElseIf CInt(row("BancoMoneda")).Equals(Divisa.Local.id) And (CInt(row("DocumentoMoneda")).Equals(Divisa.Externa.id)) Then
                'Moneda banco local, moneda documento externa
                dblMonto = Math.Round(CDbl(row("parcial")), 5)
                strSQL = strSQL.Replace("{monto}", dblMonto)
            Else
                'No tiene moneda cuando es una cuenta contable
                dblTasa = INT_UNO
                If CInt(row("BancoMoneda")).Equals(Divisa.Externa.id) Then
                    If (Documento.Dato.Tipo = 51) Or (Documento.Dato.Tipo = 52) Then
                        If Sesion.IdEmpresa = 16 Then
                            dblTasa = INT_UNO
                        Else
                            dblTasa = CDbl(row("DocumentoTasa"))
                        End If

                    Else

                        dblTasa = CDbl(row("tasa"))
                    End If
                End If
                dblMonto = Math.Round(CDbl(row("parcial2")) * dblTasa, 5)
                strSQL = strSQL.Replace("{monto}", dblMonto)
            End If

            strSQL = strSQL.Replace("{BeneficiarioID}", CInt(row("BeneficiarioId")))
            strSQL = strSQL.Replace("{BeneficiarioCuenta}", Base.Text(row("BeneficiarioCuenta").ToString()))
            strSQL = strSQL.Replace("{BeneficiarioGasto}", Base.Text(row("BeneficiarioGasto").ToString()))
            strSQL = strSQL.Replace("{ProveedorID}", Base.Text(row("ProveedorID").ToString()))
            strSQL = strSQL.Replace("{ctaProveedor}", Base.Text(row("ProveedorCuenta").ToString()))

            'Ejecutar insercion en tabla temporal
            clsQuery.Execute(strSQL)
        Next

        'Devolver tabla temporal
        If Documento.Dato.EsMultiple Then
            strSQL = " SELECT ROUND(SUM(Monto),2) Total, IF(ProveedorID=0, BeneficiarioGasto, ProveedorCuenta) Cuenta " &
                     " FROM {tabla} " &
                     " GROUP BY ProveedorCuenta"
        Else
            strSQL = " SELECT ROUND(SUM(Monto),2) Total, BeneficiarioCuenta Cuenta " &
                     " FROM {tabla} " &
                     " GROUP BY BeneficiarioID"
        End If
        strSQL = strSQL.Replace("{tabla}", strTabla)

        Using cmd As New MySqlCommand(strSQL, CON)
            Dim da As New MySqlDataAdapter(cmd)
            dt = New System.Data.DataTable
            da.Fill(dt)
        End Using

        Return dt
    End Function

    '01 Opera una transaccion de CAJA CHICA
    Private Sub OperarCaja()
        Dim da As MySqlDataAdapter
        Dim dt As System.Data.DataTable

        Dim strSQL As String

        intItem = INT_CERO
        If Not (Documento.Dato.Item = NO_ITEM) Then
            'Informacion de detalle de la cuenta bancaria
            strSQL = Base.SQLContaBanco(Documento.Dato.Tipo, Documento.Dato.Ciclo, Documento.Dato.Numero)
            Using cmd As New MySqlCommand(strSQL, CON)
                da = New MySqlDataAdapter(cmd)
                dt = New System.Data.DataTable
                da.Fill(dt)
            End Using
            PrepararDetalle(Documento.Haber, dt,,, True,, Documento.Modo)

            'Información de detalle del documento de soporte
            strSQL = SqlOperarCaja()
            Using cmd As New MySqlCommand(strSQL, CON)
                cmd.Parameters.AddWithValue("@empresa", Sesion.IdEmpresa)
                cmd.Parameters.AddWithValue("@tipo", Documento.Dato.Tipo)
                cmd.Parameters.AddWithValue("@ciclo", Documento.Dato.Ciclo)
                cmd.Parameters.AddWithValue("@numero", Documento.Dato.Numero)

                da = New MySqlDataAdapter(cmd)
                dt = New System.Data.DataTable
                da.Fill(dt)
            End Using
            PrepararDetalle(Documento.Debe, dt,,,,, Documento.Modo)
        End If
    End Sub

    Private Function SqlOperarCaja()
        Dim strSQL As String
        If Documento.Dato.Item = clsBancos.EnumCaja.Liquidacion Then
            'Solo liguidacion de caja
            strSQL = " SELECT a.Fecha, a.Tasa, (a.total-a.Diferencia) Total, a.Diferencia, a.Usuario,a.Multiple,a.Cuenta,a.CC,a.Presupuesto FROM(SELECT h.HDoc_Doc_Fec Fecha, " &
                     "        ROUND(h.HDoc_Doc_TC, 4) Tasa, " &
                     "        IF(h.HDoc_Doc_Mon={local}, ROUND(h.HDoc_RF1_Dbl, 2), (ROUND(h.HDoc_Doc_TC * h.HDoc_RF1_Dbl, 2))) Total, " &
                     "        IF(h.HDoc_Doc_Mon={local}, ROUND(h.HDoc_RF2_Dbl, 2), ROUND(h.HDoc_Doc_TC * h.HDoc_RF2_Dbl, 2)) Diferencia, " &
                     "        h.HDoc_Usuario Usuario, " &
                     "        IFNULL(h.HDoc_DR1_Emp, 0)  Multiple, " &
                     "        c.BCta_Cuenta Cuenta, " &
                     "        IFNULL(h.HDoc_RF2_Cod,'') CC, " &
                     "        IFNULL(h.HDoc_Emp_NIT,'') Presupuesto " &
                     " FROM Dcmtos_HDR h " &
                     "      LEFT JOIN CtasBcos c ON c.BCta_Sis_Emp = h.HDoc_Sis_Emp AND c.BCta_Num = h.HDoc_Emp_Cod " &
                     " WHERE h.HDoc_Sis_Emp=@empresa AND h.HDoc_Doc_Cat=@tipo AND h.HDoc_Doc_Ano=@ciclo AND h.HDoc_Doc_Num=@numero)a "
        Else
            'Anticipo, apertura y cierre
            strSQL = " SELECT h.HDoc_Doc_Fec Fecha, " &
                     "        ROUND(h.HDoc_Doc_TC, 4) Tasa, " &
                     "        IF(h.HDoc_Doc_Mon={local}, ROUND(h.HDoc_RF1_Dbl, 2), (ROUND(h.HDoc_Doc_TC * h.HDoc_RF1_Dbl, 2))) Total, " &
                     "        0 Diferencia, " &
                     "        h.HDoc_Usuario Usuario, " &
                     "        IFNULL(h.HDoc_DR1_Emp, 0) Multiple, " &
                     "        c.BCta_Cuenta Cuenta, " &
                     "        '' CC, " &
                     "        IFNULL(h.HDoc_Emp_NIT,'') Presupuesto " &
                     " FROM Dcmtos_HDR h " &
                     "      LEFT JOIN CtasBcos c ON c.BCta_Sis_Emp = h.HDoc_Sis_Emp AND c.BCta_Num = h.HDoc_Emp_Cod " &
                     " WHERE h.HDoc_Sis_Emp=@empresa AND h.HDoc_Doc_Cat=@tipo AND h.HDoc_Doc_Ano=@ciclo AND h.HDoc_Doc_Num=@numero "
        End If
        strSQL = strSQL.Replace("{local}", Divisa.Local.id.ToString)
        Return strSQL
    End Function

    '02 Opera una transaccion de CLIENTE
    Private Sub OperarCliente()
        Dim da As MySqlDataAdapter
        Dim dt As System.Data.DataTable, dn As System.Data.DataTable

        Dim dblDiferencial As Double = INT_CERO
        Dim dblComision As Double = INT_CERO
        Dim dblTemp As Double = INT_CERO
        Dim strSQL As String

        intItem = INT_CERO
        If Not (Documento.Dato.Item = NO_ITEM) Then

            If Documento.Dato.Tipo = 54 Then
                strSQL = SqlOperarCliente()
                Using cmd As New MySqlCommand(strSQL, CON)
                    cmd.Parameters.AddWithValue("@empresa", Sesion.IdEmpresa)
                    cmd.Parameters.AddWithValue("@tipo", Documento.Dato.Tipo)
                    cmd.Parameters.AddWithValue("@ciclo", Documento.Dato.Ciclo)
                    cmd.Parameters.AddWithValue("@numero", Documento.Dato.Numero)

                    da = New MySqlDataAdapter(cmd)
                    dt = New System.Data.DataTable
                    da.Fill(dt)
                End Using
                If dt.Rows.Count >= 1 Then
                Else
                    DetalleParaAnticipoSinDoc()
                    Exit Sub
                End If
            End If

            Documento.Dato.EsMultiple = True

            'Informacion de detalle de la cuenta bancaria
            strSQL = Base.SQLContaBanco(Documento.Dato.Tipo, Documento.Dato.Ciclo, Documento.Dato.Numero)
            Using cmd As New MySqlCommand(strSQL, CON)
                da = New MySqlDataAdapter(cmd)
                dt = New System.Data.DataTable
                da.Fill(dt)
            End Using
            PrepararDetalle(Documento.Debe, dt,,, True,, Documento.Modo)

            'Información de detalle del documento de soporte
            strSQL = SqlOperarCliente()
            Using cmd As New MySqlCommand(strSQL, CON)
                cmd.Parameters.AddWithValue("@empresa", Sesion.IdEmpresa)
                cmd.Parameters.AddWithValue("@tipo", Documento.Dato.Tipo)
                cmd.Parameters.AddWithValue("@ciclo", Documento.Dato.Ciclo)
                cmd.Parameters.AddWithValue("@numero", Documento.Dato.Numero)
                da = New MySqlDataAdapter(cmd)
                dt = New System.Data.DataTable
                da.Fill(dt)
            End Using

            Documento.Dato.EsMultiple = True
            If dt.Rows.Count >= 1 Then ' cuenta las lineas de datatable (si hay documento anclado)
                If Documento.Dato.Item.Equals(clsBancos.EnumCliente.Cobro) Then
                    'Linea de pago
                    dblDiferencial = Math.Round(ObtenerDiferencial(dt), DEC_TOTAL)
                    dblComision = Math.Round(CDbl(dt.Rows(0)("gastocomision")), DEC_TOTAL)

                    'Preparar datos en tabla temporal
                    dn = RecuperarDetalleGrupo(dt)
                    PrepararDetalle(Documento.Haber, dn,,,,, Documento.Modo)
                Else
                    PrepararDetalle(Documento.Haber, dt,,,,, Documento.Modo)
                End If

            End If

            'Si en el detalle hay lineas con cuenta contable asignada
            Dim intlineas = LineasDeDocumento("CUENTA")
            If intlineas > INT_CERO Then
                dn = RecuperarLineasCuenta(dt)
                PrepararDetalle(Documento.Haber, dn,,,,, Documento.Modo)
            End If

            'Gastos de comision
            If Math.Abs(dblComision) > INT_CERO Then
                PrepararDetalle(Documento.Debe, dt, dblComision, , , True, Documento.Modo)
            End If

            'Si hay diferencial cambiario
            If Math.Abs(dblDiferencial) > INT_CERO Then
                If dblDiferencial > INT_CERO Then
                    'Si es positivo
                    PrepararDetalle(STR_ABONO, dt, dblDiferencial, True,,, Documento.Modo)
                Else : PrepararDetalle(STR_CARGO, dt, dblDiferencial, True,,, Documento.Modo)
                End If
            End If

            'Verifica la suma de las operaciones y ajusta la operacion necesaria
            dblTemp = SaldoDeOperaciones(EnumSaldo.Diferencia)
            If Not dblTemp.Equals(INT_CERO) Then
                'REM temporalmente comentado para depuracion
                'ActualizarOperaciones()
            End If
        End If
    End Sub

    Private Sub DetalleParaAnticipoSinDoc()
        Dim da As MySqlDataAdapter
        Dim dt As System.Data.DataTable, dn As System.Data.DataTable

        Dim dblComision As Double = INT_CERO
        Dim dblTemp As Double = INT_CERO
        Dim strSQL As String
        Dim COM As MySqlCommand
        'Cuando es un anticipo sin documentos Anclados
        'Si en el detalle hay lineas con cuenta contable asignada
        Dim intlineas = LineasDeDocumento("CUENTA")

        strSQL = Base.SQLContaBanco(Documento.Dato.Tipo, Documento.Dato.Ciclo, Documento.Dato.Numero)
        Using cmd As New MySqlCommand(strSQL, CON)
            da = New MySqlDataAdapter(cmd)
            dt = New System.Data.DataTable
            da.Fill(dt)
        End Using
        PrepararDetalle(Documento.Debe, dt,,, True,, Documento.Modo)

        strSQL = " SELECT h.HDoc_Doc_Fec Fecha, ROUND(h.HDoc_Doc_TC, 4) Tasa, IF(h.HDoc_Doc_Mon=177, ROUND(h.HDoc_RF1_Dbl, 2), (ROUND(h.HDoc_Doc_TC * h.HDoc_RF1_Dbl, 2))) Total, IF(h.HDoc_Doc_Mon = 177, ROUND(d.DDoc_RF1_Dbl, 2), (ROUND(h.HDoc_Doc_TC * d.DDoc_RF1_Dbl,2))) Parcial, h.HDoc_Usuario Usuario, IFNULL(h.HDoc_DR1_Emp, 0) Multiple, IFNULL(h.HDoc_Emp_NIT,'') Presupuesto, b.BCta_Mon BancoMoneda, IFNULL(b.BCta_Cuenta,'') Cuenta, h.HDoc_Emp_Cod BeneficiarioID, p.cli_cuenta BeneficiarioCuenta, d.DDoc_Prd_Ref BeneficiarioGasto, IFNULL(h.HDoc_Emp_Cod, 0) ProveedorID, IFNULL(p.cli_cuenta, '') ProveedorCuenta, IFNULL(h.HDoc_Doc_Num,'') DocumentoNumero, ROUND(h.HDoc_Doc_TC, 4) DocumentoTasa, IFNULL(h.HDoc_Doc_Mon,0) DocumentoMoneda, 0 DocumentoMonto, IF(h.HDoc_Doc_Mon=177, h.HDoc_DR1_Dbl, (ROUND(ROUND(h.HDoc_Doc_TC, 4), 4) * h.HDoc_DR1_Dbl)) GastoComision
                                    FROM Dcmtos_HDR h
                                    LEFT JOIN Dcmtos_DTL d ON d.DDoc_Sis_Emp=h.HDoc_Sis_Emp AND d.DDoc_Doc_Cat=h.HDoc_Doc_Cat AND d.DDoc_Doc_Ano=h.HDoc_Doc_Ano AND d.DDoc_Doc_Num=h.HDoc_Doc_Num
                                    LEFT JOIN CtasBcos b ON b.BCta_Sis_Emp=h.HDoc_Sis_Emp AND b.BCta_Num=h.HDoc_RF1_Num
                                    LEFT JOIN Clientes p ON p.cli_sisemp=h.HDoc_Sis_Emp AND p.cli_codigo=h.HDoc_Emp_Cod
                            WHERE h.HDoc_Sis_Emp=@empresa AND h.HDoc_Doc_Cat=@tipo AND h.HDoc_Doc_Ano= @ciclo AND h.HDoc_Doc_Num= @numero "

        Using cmd As New MySqlCommand(strSQL, CON)
            cmd.Parameters.AddWithValue("@empresa", Sesion.IdEmpresa)
            cmd.Parameters.AddWithValue("@tipo", Documento.Dato.Tipo)
            cmd.Parameters.AddWithValue("@ciclo", Documento.Dato.Ciclo)
            cmd.Parameters.AddWithValue("@numero", Documento.Dato.Numero)

            da = New MySqlDataAdapter(cmd)
            dt = New System.Data.DataTable
            da.Fill(dt)
        End Using
        dblComision = Math.Truncate((dt.Rows(0)("gastocomision")) * 100) / 100
        If dblComision > 0 Then
            PrepararDetalle(Documento.Debe, dt, dblComision, , , True, Documento.Modo)
        End If

        If intlineas > INT_CERO Then
            dn = RecuperarLineasCuenta(dt)
            PrepararDetalle(Documento.Haber, dn,,,,, Documento.Modo)
        End If

        'Verifica la suma de las operaciones y ajusta la operacion necesaria
        dblTemp = SaldoDeOperaciones(EnumSaldo.Diferencia)
        If Not dblTemp.Equals(INT_CERO) Then
            'REM temporalmente comentado para depuracion
            'ActualizarOperaciones()
        End If

    End Sub

    'Instruccion para operar transacciones de Cliente
    Private Function SqlOperarCliente() As String
        Dim strSQL As String
        strSQL = " SELECT h.HDoc_Doc_Fec Fecha, " &
                 "        ROUND(h.HDoc_Doc_TC, 4) Tasa, " &
                 "        IF(h.HDoc_Doc_Mon={local}, ROUND(h.HDoc_RF1_Dbl, 2), (ROUND(h.HDoc_Doc_TC * h.HDoc_RF1_Dbl, 2))) Total, " &
                 "        IF(h.HDoc_Doc_Mon = {local}, ROUND(d.DDoc_RF1_Dbl, 2), (ROUND(f.HDoc_Doc_TC * d.DDoc_RF1_Dbl,2))) Parcial, {parcial2} " &
                 "        h.HDoc_Usuario Usuario, " &
                 "        IFNULL(h.HDoc_DR1_Emp, 0) Multiple, " &
                 "        IFNULL(h.HDoc_Emp_NIT,'') Presupuesto, " &
                 "        b.BCta_Mon BancoMoneda, IFNULL(b.BCta_Cuenta,'') Cuenta, " &
                 "        h.HDoc_Emp_Cod BeneficiarioID, p.cli_cuenta BeneficiarioCuenta, d.DDoc_Prd_Ref BeneficiarioGasto, " &
                 "        IFNULL(f.HDoc_Emp_Cod, 0) ProveedorID, IFNULL(z.cli_cuenta, '') ProveedorCuenta, " &
                 "        IFNULL(f.HDoc_Doc_Num,'') DocumentoNumero, ROUND(f.HDoc_Doc_TC, 4) DocumentoTasa, IFNULL(f.HDoc_Doc_Mon,0) DocumentoMoneda, " &
                 "        (SELECT SUM(l.DDoc_Prd_NET * l.DDoc_Prd_QTY) " &
                 "         FROM Dcmtos_DTL l " &
                 "         WHERE l.DDoc_Sis_Emp=f.HDoc_Sis_Emp AND l.DDoc_Doc_Cat=f.HDoc_Doc_Cat AND l.DDoc_Doc_Ano=f.HDoc_Doc_Ano AND l.DDoc_Doc_Num=f.HDoc_Doc_Num " &
                 "         GROUP BY l.DDoc_Doc_Num ) DocumentoMonto, " &
                 "        IF(h.HDoc_Doc_Mon={local}, h.HDoc_DR1_Dbl, (ROUND(ROUND(h.HDoc_Doc_TC, 4), 4) * h.HDoc_DR1_Dbl)) GastoComision " &
                 " FROM Dcmtos_HDR h " &
                 "      LEFT JOIN Dcmtos_DTL d ON d.DDoc_Sis_Emp=h.HDoc_Sis_Emp AND d.DDoc_Doc_Cat=h.HDoc_Doc_Cat AND d.DDoc_Doc_Ano=h.HDoc_Doc_Ano AND d.DDoc_Doc_Num=h.HDoc_Doc_Num " &
                 "      LEFT JOIN Dcmtos_HDR f ON f.HDoc_Sis_Emp=d.DDoc_Sis_Emp AND f.HDoc_Doc_Cat=d.DDoc_RF1_Num AND f.HDoc_Doc_Ano=d.DDoc_RF2_Num AND f.HDoc_Doc_Num=d.DDoc_RF3_Num " &
                 "      LEFT JOIN CtasBcos   b ON b.BCta_Sis_Emp=h.HDoc_Sis_Emp AND b.BCta_Num=h.HDoc_RF1_Num " &
                 "      LEFT JOIN Clientes   p ON p.cli_sisemp=h.HDoc_Sis_Emp AND p.cli_codigo=h.HDoc_Emp_Cod " &
                 "      LEFT JOIN Clientes   z ON z.cli_sisemp=f.HDoc_Sis_Emp AND z.cli_codigo=f.HDoc_Emp_Cod " &
                 " WHERE h.HDoc_Sis_Emp=@empresa AND h.HDoc_Doc_Cat=@tipo AND h.HDoc_Doc_Ano=@ciclo AND h.HDoc_Doc_Num=@numero AND f.HDoc_Doc_Num IS NOT NULL "
        strSQL = strSQL.Replace("{local}", Divisa.Local.id.ToString)
        If Sesion.IdEmpresa = 10 Or Sesion.IdEmpresa = 9 Or Sesion.IdEmpresa = 14 Or Sesion.IdEmpresa = 15 Then
            strSQL = strSQL.Replace("{parcial2}", " ROUND(d.DDoc_RF1_Dbl, 2) parcial2,")
        Else

            strSQL = strSQL.Replace("{parcial2}", STR_VACIO)
        End If
        Return strSQL
    End Function

    'Devuelve los datos del detalle de documento conde el codigo sea CUENTA
    Private Function RecuperarLineasCuenta(ByRef Tabla As System.Data.DataTable) As System.Data.DataTable
        Dim strSQL As String = " SELECT IF(HDoc_Doc_Mon = {moneda}, ROUND(SUM(DDoc_RF1_Dbl),2), ROUND(SUM(DDoc_RF1_Dbl * DDoc_RF3_Dbl),2)) Total, DDoc_RF1_Cod Cuenta " &
                               "  FROM Dcmtos_DTL " &
                               "  LEFT JOIN Dcmtos_HDR ON HDoc_Sis_Emp = DDoc_Sis_Emp AND HDoc_Doc_Cat = DDoc_Doc_Cat AND HDoc_Doc_Ano = DDoc_Doc_Ano AND HDoc_Doc_Num = DDoc_Doc_Num " &
                               "  WHERE DDoc_Sis_Emp=@empresa AND DDoc_Doc_Cat=@tipo AND DDoc_Doc_Ano=@ciclo AND DDoc_Doc_Num=@numero AND DDoc_RF2_Cod={cuenta} " &
                               "  GROUP BY DDoc_RF1_Cod "
        Dim da As MySqlDataAdapter
        Dim dt As System.Data.DataTable

        strSQL = strSQL.Replace("{cuenta}", Base.Text(STR_CUENTA))
        strSQL = strSQL.Replace("{moneda}", cFunciones.DivisaLocal)
        Using cmd As New MySqlCommand(strSQL, CON)
            cmd.Parameters.AddWithValue("@empresa", Sesion.IdEmpresa)
            cmd.Parameters.AddWithValue("@tipo", Documento.Dato.Tipo)
            cmd.Parameters.AddWithValue("@ciclo", Documento.Dato.Ciclo)
            cmd.Parameters.AddWithValue("@numero", Documento.Dato.Numero)

            da = New MySqlDataAdapter(cmd)
            dt = New System.Data.DataTable
            da.Fill(dt)
        End Using

        Return dt
    End Function

    '03 Opera una transaccion de EMPLEADO
    Private Sub OperarEmpleado()
        Dim da As MySqlDataAdapter
        Dim dt As System.Data.DataTable
        Dim strSQL As String

        intItem = INT_CERO
        If Not (Documento.Dato.Item = NO_ITEM) Then
            'Informacion de detalle de la cuenta bancaria
            strSQL = Base.SQLContaBanco(Documento.Dato.Tipo, Documento.Dato.Ciclo, Documento.Dato.Numero)
            Using cmd As New MySqlCommand(strSQL, CON)
                da = New MySqlDataAdapter(cmd)
                dt = New System.Data.DataTable
                da.Fill(dt)
            End Using
            PrepararDetalle(Documento.Haber, dt, , , True, , Documento.Modo)

            'Información de detalle del documento de soporte
            strSQL = SqlOperarEmpleado()
            Using cmd As New MySqlCommand(strSQL, CON)
                cmd.Parameters.AddWithValue("@empresa", Sesion.IdEmpresa)
                cmd.Parameters.AddWithValue("@tipo", Documento.Dato.Tipo)
                cmd.Parameters.AddWithValue("@ciclo", Documento.Dato.Ciclo)
                cmd.Parameters.AddWithValue("@numero", Documento.Dato.Numero)

                da = New MySqlDataAdapter(cmd)
                dt = New System.Data.DataTable
                da.Fill(dt)
            End Using
            PrepararDetalle(Documento.Debe, dt,,,,, Documento.Modo)
        End If
    End Sub

    'Instruccion de seleccion para operar transacciones de Empleado
    Private Function SqlOperarEmpleado() As String
        Dim strSQL As String = " SELECT h.HDoc_Emp_Cod EmpleadoCodigo, h.HDoc_Doc_Fec Fecha, ROUND(h.HDoc_Doc_TC, 4) Tasa, IF(h.HDoc_Doc_Mon={local}, ROUND(h.HDoc_RF1_Dbl, 2), (ROUND(h.HDoc_Doc_TC * h.HDoc_RF1_Dbl, 2))) Total, h.HDoc_Usuario Usuario, IFNULL(h.HDoc_DR1_Emp, 0)  Multiple, '' Cuenta, IFNULL(h.HDoc_Emp_NIT,'') Presupuesto " &
                               " FROM Dcmtos_HDR h " &
                               " WHERE h.HDoc_Sis_Emp=@empresa AND h.HDoc_Doc_Cat=@tipo AND h.HDoc_Doc_Ano=@ciclo AND h.HDoc_Doc_Num=@numero "
        strSQL = strSQL.Replace("{local}", Divisa.Local.id.ToString)
        Return strSQL
    End Function

    '04 Opera una transaccion de PLANILLA
    Private Sub OperarPlanilla()
        'NOTA no implementado
    End Sub

    '05 Opera una transaccion de TRANSFERENCIA bancaria
    Private Sub OperarTransferencia()
        Dim da As MySqlDataAdapter
        Dim dt As System.Data.DataTable
        Dim strSQL As String

        intItem = INT_CERO
        If Not (Documento.Dato.Item = NO_ITEM) Then
            'Informacion de detalle de la cuenta bancaria
            strSQL = Base.SQLContaBanco(Documento.Dato.Tipo, Documento.Dato.Ciclo, Documento.Dato.Numero)
            Using cmd As New MySqlCommand(strSQL, CON)
                da = New MySqlDataAdapter(cmd)
                dt = New System.Data.DataTable
                da.Fill(dt)
            End Using
            PrepararDetalle(Documento.Haber, dt, , , True, , Documento.Modo)

            'Información de detalle del documento de soporte
            strSQL = SqlOperarTransferencia()
            Using cmd As New MySqlCommand(strSQL, CON)
                cmd.Parameters.AddWithValue("@empresa", Sesion.IdEmpresa)
                cmd.Parameters.AddWithValue("@tipo", Documento.Dato.Tipo)
                cmd.Parameters.AddWithValue("@ciclo", Documento.Dato.Ciclo)
                cmd.Parameters.AddWithValue("@numero", Documento.Dato.Numero)

                da = New MySqlDataAdapter(cmd)
                dt = New System.Data.DataTable
                da.Fill(dt)
            End Using
            PrepararDetalle(Documento.Debe, dt,,,,, Documento.Modo)
        End If
    End Sub

    'Instruccion de seleccion para operar Transferencias
    Private Function SqlOperarTransferencia() As String
        Dim strSQL As String = " SELECT h.HDoc_Doc_Fec Fecha, " &
                               " 		 ROUND(h.HDoc_Doc_TC, 4) Tasa, " &
                               " 		 IF(h.HDoc_Doc_Mon={local}, ROUND(h.HDoc_RF1_Dbl, 2),(ROUND(h.HDoc_Doc_TC * h.HDoc_RF1_Dbl, 2))) Total, " &
                               " 		 h.HDoc_Usuario Usuario, " &
                               " 		 IFNULL(h.HDoc_DR1_Emp, 0)  Multiple, " &
                               " 		 IFNULL(h.HDoc_RF2_Cod, '') Cuenta, " &
                               " 		 IFNULL(h.HDoc_Emp_NIT,'') Presupuesto " &
                               " FROM Dcmtos_HDR h " &
                               "      LEFT JOIN CtasBcos c ON c.BCta_Sis_Emp=h.HDoc_Sis_Emp AND c.BCta_Num=h.HDoc_Emp_Cod " &
                               " WHERE h.HDoc_Sis_Emp=@empresa AND h.HDoc_Doc_Cat=@tipo AND h.HDoc_Doc_Ano=@ciclo AND h.HDoc_Doc_Num=@numero "
        strSQL = strSQL.Replace("{local}", Divisa.Local.id.ToString)
        Return strSQL
    End Function

    '06 Opera una transaccion de IMPUESTOS
    Private Sub OperarImpuesto()
        Dim da As MySqlDataAdapter
        Dim dt As System.Data.DataTable
        Dim strSQL As String

        intItem = INT_CERO
        If Not (Documento.Dato.Item = NO_ITEM) Then
            'Informacion de detalle de la cuenta bancaria
            strSQL = Base.SQLContaBanco(Documento.Dato.Tipo, Documento.Dato.Ciclo, Documento.Dato.Numero)
            Using cmd As New MySqlCommand(strSQL, CON)
                da = New MySqlDataAdapter(cmd)
                dt = New System.Data.DataTable
                da.Fill(dt)
            End Using
            PrepararDetalle(Documento.Haber, dt, , , True, , Documento.Modo)

            'Información de detalle del documento de soporte
            strSQL = SqlOperarImpuesto()
            Using cmd As New MySqlCommand(strSQL, CON)
                cmd.Parameters.AddWithValue("@empresa", Sesion.IdEmpresa)
                cmd.Parameters.AddWithValue("@tipo", Documento.Dato.Tipo)
                cmd.Parameters.AddWithValue("@ciclo", Documento.Dato.Ciclo)
                cmd.Parameters.AddWithValue("@numero", Documento.Dato.Numero)

                da = New MySqlDataAdapter(cmd)
                dt = New System.Data.DataTable
                da.Fill(dt)
            End Using
            PrepararDetalle(Documento.Debe, dt,,,,, Documento.Modo)
        End If
    End Sub

    'Instruccion de seleccion para operar Impuestos
    Private Function SqlOperarImpuesto() As String
        Dim strSQL As String
        Select Case Documento.Dato.Item
            Case clsBancos.EnumImpuestos.ISRRetenciones, clsBancos.EnumImpuestos.IVARetenciones
                strSQL = " SELECT h.HDoc_Doc_Fec Fecha, ROUND(h.HDoc_Doc_TC, 4) Tasa, IF(h.HDoc_Doc_Mon={local}, ROUND(SUM(d.DDoc_RF1_Dbl), 2), (ROUND(h.HDoc_Doc_TC, 4) * ROUND(SUM(d.DDoc_RF1_Dbl), 2))) Total, h.HDoc_Usuario Usuario, IFNULL(h.HDoc_DR1_Emp, 0)  Multiple, IFNULL(h.HDoc_Emp_NIT,'') Presupuesto, d.DDoc_Prd_Ref Cuenta, IFNULL(hr.HDoc_DR1_Cat,0) Especial, h.HDoc_Emp_Cod EmpleadoCodigo, IFNULL(hr.HDoc_RF2_Dbl,0) porcentaje " &
                         " FROM Dcmtos_HDR h " &
                         "      LEFT JOIN Dcmtos_DTL d ON d.DDoc_Sis_Emp=h.HDoc_Sis_Emp AND d.DDoc_Doc_Cat=h.HDoc_Doc_Cat AND d.DDoc_Doc_Ano=h.HDoc_Doc_Ano AND d.DDoc_Doc_Num=h.HDoc_Doc_Num" &
                         "      left join Dcmtos_HDR hr on hr.HDoc_Sis_Emp = d.DDoc_Sis_Emp and hr.HDoc_Doc_Cat =d.DDoc_RF1_Num and hr.HDoc_Doc_Ano =d.DDoc_RF2_Num  and hr.HDoc_Doc_Num = d.DDoc_RF3_Num  " &
                         " WHERE h.HDoc_Sis_Emp=@empresa AND h.HDoc_Doc_Cat=@tipo AND h.HDoc_Doc_Ano=@ciclo AND h.HDoc_Doc_Num=@numero " &
                         " GROUP BY h.HDoc_Sis_Emp, h.HDoc_Doc_Cat, h.HDoc_Doc_Ano, h.HDoc_Doc_Num, d.DDoc_Prd_Ref , hr.HDoc_DR1_Cat  "
            Case Else
                'IVA x Pagar, ISR Asalariados, ISR Mensual
                strSQL = " SELECT h.HDoc_Doc_Fec FechaDocumento, ROUND(h.HDoc_Doc_TC, 4) TasaBanco, IF(h.HDoc_Doc_Mon={local}, ROUND(h.HDoc_RF1_Dbl, 2), (ROUND(h.HDoc_Doc_TC * h.HDoc_RF1_Dbl, 2))) Total, h.HDoc_Usuario Usuario, IFNULL(h.HDoc_DR1_Emp, 0)  Multiple, IFNULL(h.HDoc_Emp_NIT,'') Presupuesto, '' Cuenta, 0 Especial, h.HDoc_Emp_Cod EmpleadoCodigo " &
                         " FROM Dcmtos_HDR h " &
                         " WHERE h.HDoc_Sis_Emp=@empresa AND h.HDoc_Doc_Cat=@tipo AND h.HDoc_Doc_Ano=@ciclo AND h.HDoc_Doc_Num=@numero "
        End Select
        strSQL = strSQL.Replace("{local}", Divisa.Local.id.ToString)
        Return strSQL
    End Function

    'Prepara la informacion de detalle para el documento o entidad de soporte
    Private Sub PrepararDetalle(ByVal Operacion As String, ByRef Tabla As System.Data.DataTable, Optional Valor As Double = 0.0, Optional Diferencial As Boolean = False, Optional EsBanco As Boolean = False, Optional Comision As Boolean = False, Optional ModoOperacion As Integer = INT_CERO)
        Dim strCuenta As String = String.Empty
        Dim strAnticipo As String = String.Empty
        Dim intItem As Integer = 0

        Dim det As DatoDetalle
        Dim row As DataRow

        If Tabla.Rows.Count > INT_CERO Then
            'Cuenta contable de anticipos sobre compras
            If Documento.Dato.Grupo.Equals(clsBancos.BancoGrupo.Proveedor) Then
                If Documento.Dato.Item.Equals(clsBancos.EnumProveedor.Pago) Or Documento.Dato.Item.Equals(clsBancos.EnumProveedor.Anticipo) Then
                    strAnticipo = BuscarCuentaParametro(EnumParametro.AnticipoDeCompra)
                End If
            End If

            'Diferencia de liquidacion de caja chica
            If Documento.Dato.Grupo.Equals(clsBancos.BancoGrupo.Caja) Then
                If Documento.Dato.Item.Equals(clsBancos.EnumCaja.Liquidacion) And Operacion.Equals(Documento.Debe) Then
                    row = Tabla.Rows(0)
                    If CDbl(row("diferencia")) <> INT_CERO Then
                        strCuenta = row("cc").ToString()

                        intItem += 1
                        det = New DatoDetalle
                        det.Parametro = 1
                        If Math.Round(CDbl(row("diferencia")), 2) < 0 Then
                            det.Operacion = "A"
                            det.Importe = CDbl(row("diferencia") * -1).ToString("f")
                        Else
                            det.Operacion = Operacion
                            det.Importe = CDbl(row("diferencia")).ToString("f")
                        End If

                        det.Cuenta = strCuenta
                        det.Centro = String.Empty
                        det.Fecha = "CURRENT_DATE()"
                        det.Clase = String.Empty
                        det.Modo = Documento.Modo
                        det.Tipo = Documento.Dato.Tipo
                        det.Ciclo = Documento.Dato.Ciclo
                        det.Numero = Documento.Dato.Numero
                        det.ID = INT_CERO
                        Detalle.Add(det)
                    End If
                End If
            End If

            If Diferencial Or Comision Then
                '***** LINEA: diferencial o comision

                intItem += 1
                det = New DatoDetalle

                If Diferencial Then
                    'Cuenta de diferencial cambiario a favor o en contra
                    If Operacion.Equals(STR_CARGO) Then
                        det.Cuenta = BuscarCuentaParametro(EnumParametro.DiferencialDebe)
                    Else : det.Cuenta = BuscarCuentaParametro(EnumParametro.DiferencialHaber)
                    End If
                Else
                    'Cuenta contable de comision
                    det.Cuenta = BuscarCuentaParametro(EnumParametro.GastoComision)
                End If

                det.Parametro = 1
                det.Operacion = Operacion
                det.Importe = Math.Abs(Valor)
                det.Centro = String.Empty
                det.Fecha = "CURRENT_DATE()"
                det.Clase = String.Empty
                det.Modo = Documento.Modo
                det.Tipo = Documento.Dato.Tipo
                det.Ciclo = Documento.Dato.Ciclo
                det.Numero = Documento.Dato.Numero
                det.ID = INT_CERO
                Detalle.Add(det)
            End If

            If Not (Diferencial Or Comision) Then
                '***** LINEA: detalle 

                For Each dr As DataRow In Tabla.Rows
                    intItem += 1
                    det = New DatoDetalle

                    det.Cuenta = String.Empty
                    If EsBanco Then
                        'Partida presupuestaria (para linea de banco)
                        det.Presupuesto = dr("presupuesto").ToString
                    Else
                        'Cuenta contable especifica
                        If Documento.Dato.Grupo = clsBancos.BancoGrupo.Transferencia Then
                            If Documento.Dato.Item = clsBancos.EnumTransferencia.Depositos Then
                                'Para transferencias
                                det.Cuenta = BuscarCuentaParametro(EnumParametro.Transferencia)
                            End If
                        ElseIf Documento.Dato.Grupo = clsBancos.BancoGrupo.Cliente Then
                            If Documento.Dato.Item = clsBancos.EnumCliente.Descuento Then
                                'Descuento para clientes
                                det.Cuenta = BuscarCuentaParametro(EnumParametro.DescuentoVentas)
                            End If
                        ElseIf Documento.Dato.Grupo = clsBancos.BancoGrupo.Empleado Then
                            'Transacciones de empleado
                            Select Case Documento.Dato.Item
                                Case clsBancos.EnumEmpleado.Salario
                                    det.Cuenta = BuscarCuentaParametro(EnumParametro.SueldoPorPagar)
                                Case clsBancos.EnumEmpleado.Aguinaldo
                                    det.Cuenta = BuscarCuentaParametro(EnumParametro.AguinaldoPorPagar)
                                Case clsBancos.EnumEmpleado.Bono14
                                    det.Cuenta = BuscarCuentaParametro(EnumParametro.BonoPorPagar)
                                Case clsBancos.EnumEmpleado.Anticipo
                                    det.Cuenta = BuscarCuentaEmpleado(CInt(dr("EmpleadoCodigo")), "em_cuenta1")
                                Case clsBancos.EnumEmpleado.Devolucion
                                    det.Cuenta = BuscarCuentaEmpleado(CInt(dr("EmpleadoCodigo")), "em_cuenta2")
                                Case clsBancos.EnumEmpleado.Bonificacion
                                    det.Cuenta = BuscarCuentaParametro(EnumParametro.Bonificacion)
                                Case clsBancos.EnumEmpleado.BonoExtra
                                    det.Cuenta = BuscarCuentaParametro(EnumParametro.BonoExtra)
                                Case clsBancos.EnumEmpleado.Vacaciones
                                    det.Cuenta = BuscarCuentaParametro(EnumParametro.Vacaciones)
                                Case clsBancos.EnumEmpleado.Indemnizacion
                                    det.Cuenta = BuscarCuentaParametro(EnumParametro.Indemnizacion)
                                Case clsBancos.EnumEmpleado.DevolucionISR
                                    det.Cuenta = BuscarCuentaParametro(EnumParametro.PagoISR)
                            End Select
                        ElseIf Documento.Dato.Grupo = clsBancos.BancoGrupo.Impuestos Then
                            'Pago de impuestos
                            Select Case Documento.Dato.Item
                                Case clsBancos.EnumImpuestos.IVAPagar
                                    det.Cuenta = BuscarCuentaParametro(EnumParametro.IVAPorPagar)
                                Case clsBancos.EnumImpuestos.ISRAsalariado
                                    det.Cuenta = BuscarCuentaParametro(EnumParametro.ISRSalario)
                                Case clsBancos.EnumImpuestos.ISRMensual
                                    det.Cuenta = BuscarCuentaParametro(EnumParametro.ISRMensual)
                                Case clsBancos.EnumImpuestos.ISRRetenciones
                                    det.Cuenta = Convert.ToString(dr("cuenta"))
                                    If det.Cuenta.Equals(String.Empty) Then
                                        If Not CInt(dr("especial")).Equals(INT_CERO) Then
                                            'ISR Facturas especiales
                                            det.Cuenta = BuscarCuentaParametro(EnumParametro.ISREspecial)
                                        Else
                                            If Sesion.IdEmpresa = 18 Or Sesion.IdEmpresa = 19 Or Sesion.IdEmpresa = 21 Then 'And Sesion.IdEmpresa = 15 Then
                                                Select Case CInt(dr("porcentaje"))
                                                    Case 2
                                                        det.Cuenta = BuscarCuentaParametro(EnumParametro.ISRRetencion) '2%
                                                    Case 3
                                                        det.Cuenta = BuscarCuentaParametro(EnumParametro.ISRRetencionTM) '3%
                                                    Case 10
                                                        det.Cuenta = BuscarCuentaParametro(EnumParametro.ISRRetencionSP) '10%
                                                    Case 13
                                                        det.Cuenta = BuscarCuentaParametro(EnumParametro.ISRRetencionesIP) '13%
                                                    Case 15
                                                        det.Cuenta = BuscarCuentaParametro(EnumParametro.ISRRetencionAS) '15%
                                                End Select

                                            Else
                                                det.Cuenta = BuscarCuentaParametro(EnumParametro.ISRRetencion)
                                            End If

                                        End If
                                    End If
                                Case clsBancos.EnumImpuestos.IVARetenciones
                                    det.Cuenta = Convert.ToString(dr("cuenta"))
                                    If det.Cuenta.Equals(String.Empty) Then
                                        If Sesion.IdEmpresa = 15 Then
                                            Select Case CInt(dr("porcentaje"))
                                                Case 1
                                                    det.Cuenta = "210602002" ' BuscarCuentaParametro(EnumParametro.ISRRetencion) '1%
                                                Case 10
                                                    det.Cuenta = "210602003" 'BuscarCuentaParametro(EnumParametro.ISRRetencionTM) '10%
                                                Case 12.5
                                                    det.Cuenta = "210602004" 'BuscarCuentaParametro(EnumParametro.ISRRetencionSP) '12.5%
                                                Case 25
                                                    det.Cuenta = "210602005" 'BuscarCuentaParametro(EnumParametro.ISRRetencionesIP) '25%
                                                Case 15
                                                    det.Cuenta = "210602006" 'BuscarCuentaParametro(EnumParametro.ISRRetencionAS) '15%
                                            End Select
                                        Else
                                            If Not CInt(dr("especial")).Equals(INT_CERO) Then
                                                'IVA Facturas especiales
                                                det.Cuenta = BuscarCuentaParametro(EnumParametro.IVAEspecial)
                                            Else : det.Cuenta = BuscarCuentaParametro(EnumParametro.IVARetencion)
                                            End If
                                        End If

                                    End If
                            End Select
                        End If
                    End If

                    If det.Cuenta.Equals(String.Empty) Then
                        det.Cuenta = dr("cuenta").ToString
                    End If

                    det.Parametro = 1
                    If CDbl(dr("total")).ToString(FORMATO_MONEDA) < 0 Then
                        det.Operacion = "A"
                        det.Importe = CDbl(dr("total")).ToString(FORMATO_MONEDA) * -1
                    Else
                        det.Operacion = Operacion
                        det.Importe = CDbl(dr("total")).ToString(FORMATO_MONEDA)
                    End If
                    det.Centro = String.Empty
                    det.Fecha = "CURRENT_DATE()"
                    det.Clase = String.Empty
                    det.Modo = Documento.Modo
                    det.Tipo = Documento.Dato.Tipo
                    det.Ciclo = Documento.Dato.Ciclo
                    det.Numero = Documento.Dato.Numero
                    det.ID = INT_CERO
                    Detalle.Add(det)
                Next
            End If
        End If
    End Sub

    'Busca la cuenta de anticipo y de devolucion para un empleado
    Private Function BuscarCuentaEmpleado(ByVal ID As Integer, ByVal Campo As String) As String
        Dim strSQL As String = "SELECT {campo} FROM Empleados WHERE em_empresa=@empresa AND em_codigo=@id LIMIT 1".Replace("{campo}", Campo)
        Dim strDato As String = String.Empty

        Using cmd As New MySqlCommand(strSQL, CON)
            cmd.Parameters.AddWithValue("empresa", Sesion.IdEmpresa)
            cmd.Parameters.AddWithValue("id", ID)
            Dim obj As Object = cmd.ExecuteScalar
            If obj IsNot Nothing Then
                strDato = obj.ToString()
            End If
        End Using
        Return strDato
    End Function

    'Prepara la informacion de detalle para el documento o entidad de soporte
    Private Sub PrepararDetalleGasto(ByVal Operacion As String, ByRef Tabla As System.Data.DataTable)
        Dim det As DatoDetalle
        If Tabla.Rows.Count > INT_CERO Then
            For Each row As DataRow In Tabla.Rows
                'Lineas de gasto
                intItem += 1
                det = New DatoDetalle

                det.Parametro = 1
                det.Operacion = Operacion
                det.Cuenta = row("cuenta").ToString
                If (Documento.Dato.Tipo) = 51 Or (Documento.Dato.Tipo = 52) Then
                    If CInt(row("BancoMoneda")).Equals(Divisa.Local.id) Then
                        det.Importe = Math.Round(CDbl(row("Parcial2")), 2)
                    Else
                        det.Importe = Math.Round(CDbl(row("Parcial2")) * CDbl(row("DocumentoTasa")), 2)
                    End If
                Else
                    det.Importe = Math.Round(CDbl(row("total")), 2)
                End If
                det.Centro = String.Empty
                det.Fecha = "CURRENT_DATE()"
                det.Clase = String.Empty
                det.Modo = Documento.Modo
                det.Tipo = Documento.Dato.Tipo
                det.Ciclo = Documento.Dato.Ciclo
                det.Numero = Documento.Dato.Numero
                det.ID = INT_CERO
                Detalle.Add(det)
            Next
        End If
    End Sub

    'Prepara la informacion de detalle para el total del documento de soporte
    Private Sub PrepararDetalleTotal(ByVal Operacion As String, ByRef Tabla As System.Data.DataTable)
        Dim strSQL As String = "SELECT '' Cuenta"
        Dim strCuenta As String = String.Empty
        Dim dblTotal As Double = INT_CERO
        Dim det As DatoDetalle

        dblTotal = CDbl(Tabla.Rows(INT_CERO)("total"))
        Select Case Documento.Dato.Grupo
            Case clsBancos.BancoGrupo.Proveedor
                If Documento.Dato.Item.Equals(clsBancos.EnumProveedor.Pago) Then
                    strSQL = " SELECT IFNULL(pro_cuenta,'') Cuenta " &
                             " FROM Dcmtos_HDR " &
                             "      LEFT JOIN Proveedores ON pro_sisemp = HDoc_Sis_Emp AND pro_codigo = HDoc_Emp_Cod " &
                             " WHERE HDoc_Sis_Emp=@empresa AND HDoc_Doc_Cat=@tipo AND HDoc_Doc_Ano=@ciclo AND HDoc_Doc_Num=@numero "
                End If
            Case clsBancos.BancoGrupo.Caja
                strSQL = " SELECT IFNULL({cuenta},'') Cuenta " &
                             " FROM Dcmtos_HDR " &
                             "      LEFT JOIN CtasBcos ON BCta_Sis_Emp = HDoc_Sis_Emp AND BCta_Num = HDoc_Emp_Cod " &
                             " WHERE HDoc_Sis_Emp=@empresa AND HDoc_Doc_Cat=@tipo AND HDoc_Doc_Ano=@ciclo AND HDoc_Doc_Num=@numero "
                If Documento.Dato.Item.Equals(clsBancos.EnumCaja.Anticipo) Then
                    strSQL = strSQL.Replace("{cuenta}", "IFNULL(BCta_Anticipo, BCta_Cuenta)")
                Else
                    strSQL = strSQL.Replace("{cuenta}", "BCta_Cuenta")
                End If
        End Select

        'Ejecutar la consulta
        If Not strSQL.Equals(String.Empty) Then
            Using cmd As New MySqlCommand(strSQL, CON)
                cmd.Parameters.AddWithValue("@empresa", Sesion.IdEmpresa)
                cmd.Parameters.AddWithValue("@tipo", Documento.Dato.Tipo)
                cmd.Parameters.AddWithValue("@ciclo", Documento.Dato.Ciclo)
                cmd.Parameters.AddWithValue("@numero", Documento.Dato.Numero)

                strCuenta = cmd.ExecuteScalar.ToString()
            End Using
        End If

        '***** LINEA: total 

        intItem += 1
        det = New DatoDetalle

        det.Parametro = 1
        det.Operacion = Operacion
        det.Cuenta = strCuenta
        det.Importe = Math.Round(dblTotal, 2)
        det.Centro = String.Empty
        det.Fecha = "CURRENT_DATE()"
        det.Clase = String.Empty
        det.Modo = Documento.Modo
        det.Tipo = Documento.Dato.Tipo
        det.Ciclo = Documento.Dato.Ciclo
        det.Numero = Documento.Dato.Numero
        det.ID = INT_CERO
        Detalle.Add(det)
    End Sub

    'Busca el valor de un parametro en la base de datos de contabilidad
    Private Function BuscarCuentaParametro(ByVal ID As Integer) As String
        Dim strSQL As String = "SELECT valor FROM {base}.parametros_empresa WHERE empresa={empresa} AND parametro={id} LIMIT 1"
        Dim s As String = String.Empty
        Dim obj As Object

        strSQL = strSQL.Replace("{base}", Sesion.BaseConta)
        strSQL = strSQL.Replace("{empresa}", Sesion.IdEmpresa)
        strSQL = strSQL.Replace("{id}", ID)

        Using cmd As New MySqlCommand(strSQL, CON)
            obj = cmd.ExecuteScalar
            If obj IsNot Nothing Then
                s = obj.ToString.Trim
            End If
        End Using

        Return s
    End Function

    'Escribe el encabezado de la poliza
    Private Function EscribirPoliza() As Boolean
        Dim logEx As Boolean = False

        'Borrar poliza si ya existe
        BorrarPoliza(Sesion.BaseConta, Documento.Dato.Tipo, Documento.Dato.Ciclo, Documento.Dato.Numero)

        'Actualizar [ejercicio_empresa].[ult_poliza]
        ActualizarUltimaPoliza(Sesion.BaseConta)

        If Sesion.IdEmpresa = 18 Then
            BorrarPoliza("contapdm", Documento.Dato.Tipo, Documento.Dato.Ciclo, Documento.Dato.Numero)
            ActualizarUltimaPoliza("contapdm")
        End If

        'Escribir encabezado y detalle
        If EscribirEncabezado(Sesion.BaseConta) Then
            If EscribirDetalle(Sesion.BaseConta) Then
                logEx = True
            End If
        End If
        If Sesion.IdEmpresa = 18 Then
            If EscribirEncabezado("contapdm") Then
                Documento.Transaccion = Documento.TransaccionPDM
                If EscribirDetalle("contapdm") Then
                    logEx = True
                End If
            End If
        End If
        Return logEx
    End Function

    'Escribe el detalle de la poliza
    Private Function EscribirDetalle(ByVal conta As String) As Boolean
        Dim logErr As Boolean = False
        Dim strSQL As String
        Dim i As Integer = INT_UNO

        For Each det As DatoDetalle In Detalle
            Using sql As New clsQuery
                sql.Name = "{conta}.detalle_polizas".Replace("{conta}", conta)
                sql.Kind = clsQuery.Mode.Insert

                'Relacion con encabezado
                sql.Add("empresa", _Empresa)
                sql.Add("ejercicio", _Ejercicio)
                sql.Add("poliza", _Poliza)
                sql.Add("item", i)
                sql.Add("transaccion", Documento.Transaccion)

                'Datos del detalle
                sql.Add("cuenta", Base.Text(det.Cuenta))

                sql.Add("parametro_cuenta", INT_UNO)
                sql.Add("operacion", Base.Text(det.Operacion))
                sql.Add("importe", det.Importe)

                'Procedimiento para el centro de costo por default
                If Sesion.IdEmpresa = 12 Then 'Hilos
                    Select Case det.Cuenta
                        Case "0403002", "0503002"
                            sql.Add("centro_costos", 4) 'Finanzas
                        Case "0502058"
                            sql.Add("centro_costos", 19) 'Cobros
                        Case Else
                            sql.Add("centro_costos", Base.Text(det.Centro))
                    End Select
                ElseIf Sesion.IdEmpresa = 11 Then 'Prideyarn
                    Select Case det.Cuenta
                        Case "0403002", "0503002", "0502065"
                            sql.Add("centro_costos", 4) 'Finanzas
                        Case "0502058"
                            sql.Add("centro_costos", 19) 'Cobros
                        Case Else
                            sql.Add("centro_costos", Base.Text(det.Centro))
                    End Select
                ElseIf Sesion.IdEmpresa = 16 Then 'Amtex
                    Select Case det.Cuenta
                        Case "71030101"
                            sql.Add("centro_costos", 4) 'Finanzas
                        Case "71020101"
                            sql.Add("centro_costos", 19) 'Cobros
                        Case Else
                            sql.Add("centro_costos", Base.Text(det.Centro))
                    End Select
                ElseIf Sesion.IdEmpresa = 14 Then 'Dominicana
                    Select Case det.Cuenta
                        Case "0403002", "0503002"
                            sql.Add("centro_costos", 4) 'Finanzas
                        Case "0502058"
                            sql.Add("centro_costos", 19) 'Cobros
                        Case Else
                            sql.Add("centro_costos", Base.Text(det.Centro))
                    End Select
                Else
                    sql.Add("centro_costos", Base.Text(det.Centro))
                End If

                sql.Add("partida_presupuestal", Base.Text(det.Presupuesto))
                If det.Fecha.Equals("CURRENT_DATE()") Then
                    sql.Add("fecha", det.Fecha)
                ElseIf Not det.Fecha.Equals(String.Empty) Then
                    sql.Add("fecha", Base.Text(CDate(det.Fecha).ToString(FORMATO_MYSQL)))
                End If
                sql.Add("clase", Base.Text(det.Clase))
                sql.Add("modo", det.Modo)
                sql.Add("ref_tipo", det.Tipo)
                sql.Add("ref_ciclo", det.Ciclo)
                sql.Add("ref_numero", det.Numero)
                sql.Add("ref_id", det.ID)
                strSQL = sql.SQLString

                'Incrementar transaccion e item
                i += 1
                Documento.Transaccion += 1

                Try
                    Using cmd As New MySqlCommand(strSQL, CON)
                        cmd.ExecuteNonQuery()
                    End Using
                Catch ex As Exception
                    logErr = True
                    MessageBox.Show(ex.Message, String.Concat("clsBPoliza.EscribirEncabezado()->", ex.Source), MessageBoxButtons.OK, MessageBoxIcon.Error)
                End Try
            End Using
        Next
        Return Not logErr
    End Function

    'Escribe el encabezado de la poliza
    Private Function EscribirEncabezado(ByVal conta As String)
        Dim strSQL As String = String.Empty
        Dim logEx As Boolean = False

        Using sql As New clsQuery
            sql.Name = "{conta}.polizas".Replace("{conta}", conta)
            sql.Kind = clsQuery.Mode.Insert

            sql.Add("empresa", _Empresa)
            sql.Add("ejercicio", _Ejercicio)
            sql.Add("poliza", _Poliza)
            sql.Add("fecha", Base.Text(_Fecha.Value.ToString(FORMATO_MYSQL)))
            sql.Add("concepto", Base.Text(_Concepto))
            sql.Add("tipo", Documento.Modo)
            sql.Add("tipo_cambio", _Tasa)
            sql.Add("observaciones", Base.Text(_Observaciones))
            sql.Add("operador", Base.Text(_Usuario))
            sql.Add("estado", Base.Text(STR_ESTADO))
            sql.Add("modo", Documento.Modo)
            sql.Add("ref_tipo", _Referencia)
            sql.Add("ref_ciclo", _Ciclo)
            sql.Add("ref_numero", _Numero)
            sql.Add("tasa", _Tasa)
            strSQL = sql.SQLString

            Try
                Using cmd As New MySqlCommand(strSQL, CON)
                    cmd.ExecuteNonQuery()
                    logEx = True
                End Using
            Catch ex As Exception
                MessageBox.Show(ex.Message, String.Concat("clsBPoliza.EscribirEncabezado()->", ex.Source), MessageBoxButtons.OK, MessageBoxIcon.Error)
            End Try
        End Using
        Return logEx
    End Function

    'Actualiza el numero de la ultima poliza en la tabla Ejercicio_Empresa
    Private Sub ActualizarUltimaPoliza(ByVal conta As String)
        Dim strSQL As String = "UPDATE {conta}.ejercicio_empresa SET ult_poliza={poliza} WHERE empresa=@empresa AND ejercicio=@ejercicio"
        strSQL = strSQL.Replace("{conta}", conta)
        strSQL = strSQL.Replace("{poliza}", _Poliza)
        Dim cmd As New MySqlCommand(strSQL, CON)
        cmd.Parameters.AddWithValue("@empresa", Sesion.IdEmpresa)
        cmd.Parameters.AddWithValue("@ejercicio", Documento.Ejercicio)
        cmd.ExecuteNonQuery()
    End Sub

    'Valida la operacion (item) de acuerdo al grupo 
    Private Function OperacionEsValida() As Boolean
        Dim logValido As Boolean = True

        'TODO unificar logica con usrBancoDocumento.ListaDeItems

        Select Case Documento.Dato.Tipo
            Case Info.Cheque.ID, Info.Debito.ID
                Select Case Documento.Dato.Grupo
                    Case clsBancos.BancoGrupo.Cliente
                        logValido = False
                    Case clsBancos.BancoGrupo.Empleado
                        If Documento.Dato.Item = clsBancos.EnumEmpleado.Devolucion Then
                            logValido = False
                        End If
                    Case clsBancos.BancoGrupo.Planilla
                        logValido = False
                End Select
            Case Info.Credito.ID
                Select Case Documento.Dato.Grupo
                    Case clsBancos.BancoGrupo.Empleado, clsBancos.BancoGrupo.Proveedor, clsBancos.BancoGrupo.Caja, clsBancos.BancoGrupo.Planilla, clsBancos.BancoGrupo.Impuestos
                        logValido = False
                End Select
            Case Info.Deposito.ID
                Select Case Documento.Dato.Grupo
                    Case clsBancos.BancoGrupo.Proveedor
                        Select Case Documento.Dato.Item
                            Case clsBancos.EnumProveedor.Pago, clsBancos.EnumProveedor.Impuesto, clsBancos.EnumProveedor.Gasto, clsBancos.EnumProveedor.Pendiente
                                logValido = False
                        End Select
                    Case clsBancos.BancoGrupo.Caja
                        If (Documento.Dato.Item = clsBancos.EnumCaja.Liquidacion Or Documento.Dato.Item = clsBancos.EnumCaja.Apertura) Then
                            logValido = False
                        End If
                    Case clsBancos.BancoGrupo.Empleado
                        Select Case Documento.Dato.Item
                            Case clsBancos.EnumEmpleado.Salario, clsBancos.EnumEmpleado.Aguinaldo, clsBancos.EnumEmpleado.Bono14, clsBancos.EnumEmpleado.Anticipo, clsBancos.EnumEmpleado.Liquidacion, clsBancos.EnumEmpleado.Bonificacion, clsBancos.EnumEmpleado.Vacaciones, clsBancos.EnumEmpleado.Indemnizacion, clsBancos.EnumEmpleado.DevolucionISR
                                logValido = False
                        End Select
                    Case clsBancos.BancoGrupo.Planilla, clsBancos.BancoGrupo.Impuestos
                        logValido = False
                End Select
        End Select

        Return logValido
    End Function

    'Recupera el numero para la NUEVA poliza
    Private Function NuevaPoliza() As Integer
        Dim strSQL As String = "SELECT (IFNULL(MAX(poliza),0)+1) ID FROM {conta}.polizas WHERE empresa=@empresa AND ejercicio=@ejercicio"
        strSQL = strSQL.Replace("{conta}", Sesion.BaseConta)

        Dim i As Integer = NO_FILA, j As Integer = NO_FILA
        Dim obj As Object

        'Nueva poliza segun tabla Polizas
        Dim cmd As New MySqlCommand(strSQL, CON)
        cmd.Parameters.AddWithValue("@empresa", Sesion.IdEmpresa)
        cmd.Parameters.AddWithValue("@ejercicio", Documento.Ejercicio)
        obj = cmd.ExecuteScalar
        If obj IsNot Nothing Then
            i = CInt(obj)
        End If

        'Nueva poliza segun tabla Ejercicio_Empresa
        strSQL = "SELECT IFNULL(ult_poliza,0) ID FROM {conta}.ejercicio_empresa WHERE empresa=@empresa AND ejercicio=@ejercicio"
        strSQL = strSQL.Replace("{conta}", Sesion.BaseConta)
        cmd = New MySqlCommand(strSQL, CON)
        cmd.Parameters.AddWithValue("@empresa", Sesion.IdEmpresa)
        cmd.Parameters.AddWithValue("@ejercicio", Documento.Ejercicio)
        obj = cmd.ExecuteScalar
        If obj IsNot Nothing Then
            j = CInt(obj)
        End If

        'Devuelve el dato mayo
        If j > i Then i = j
        If i = INT_CERO Then i = INT_UNO

        Return i
    End Function

    'Recupera el numero para la primera NUEVA transaccion en detalle
    Private Function NuevaTransaccion() As Integer
        Dim strSQL As String = "SELECT (IFNULL(MAX(transaccion),0)+1) ID FROM {conta}.detalle_polizas"
        Dim obj As Object

        strSQL = strSQL.Replace("{conta}", Sesion.BaseConta)

        Dim i As Integer = NO_FILA
        Using cmd As New MySqlCommand(strSQL, CON)
            obj = cmd.ExecuteScalar
            If obj IsNot Nothing Then
                i = CInt(obj)
            End If
        End Using
        Return i
    End Function

    'Verifica si el documento tiene poliza contable
    Private Function TienePoliza(ByVal conta As String, ByVal ejercicio As Integer, ByVal tipo As Integer, ByVal ciclo As Integer, ByVal numero As Integer) As Boolean
        Dim strSQL As String = "SELECT COUNT(*) FROM {base}.polizas WHERE empresa=@empresa AND ejercicio=@ejercicio AND ref_tipo=@tipo AND ref_ciclo=@ciclo AND ref_numero=@numero "
        Dim logEx As Boolean = False
        Dim obj As Object

        strSQL = strSQL.Replace("{base}", conta)


        Using cmd As New MySqlCommand(strSQL, CON)
            cmd.Parameters.AddWithValue("@empresa", Sesion.IdEmpresa)
            cmd.Parameters.AddWithValue("@ejercicio", ejercicio)
            cmd.Parameters.AddWithValue("@tipo", tipo)
            cmd.Parameters.AddWithValue("@ciclo", ciclo)
            cmd.Parameters.AddWithValue("@numero", numero)
            obj = cmd.ExecuteScalar
            If obj IsNot Nothing Then
                If CInt(obj) > INT_CERO Then
                    logEx = True
                End If
            End If
        End Using

        Return logEx
    End Function

    'Borra la poliza para el documento indicado
    Public Function BorrarPoliza(ByVal conta As String, ByVal tipo As Integer, ByVal ciclo As Integer, ByVal numero As Integer, Optional MostrarAviso As Boolean = False) As Boolean
        Dim logEx As Boolean = False
        Dim strSQL As String
        Dim intEjercicio As Integer = EjercicioActivoID()
        Dim cmd As MySqlCommand

        If TienePoliza(conta, intEjercicio, tipo, ciclo, numero) Then
            'Borrar detalle
            strSQL = "DELETE FROM {base}.detalle_polizas WHERE empresa=@empresa AND ejercicio=@ejercicio AND ref_tipo=@tipo AND ref_ciclo=@ciclo AND ref_numero=@numero "
            strSQL = strSQL.Replace("{base}", conta)
            cmd = New MySqlCommand(strSQL, CON)
            cmd.Parameters.AddWithValue("@empresa", Sesion.IdEmpresa)
            cmd.Parameters.AddWithValue("@ejercicio", intEjercicio)
            cmd.Parameters.AddWithValue("@tipo", tipo)
            cmd.Parameters.AddWithValue("@ciclo", ciclo)
            cmd.Parameters.AddWithValue("@numero", numero)
            cmd.ExecuteNonQuery()

            'Borrar encabezado
            strSQL = "DELETE FROM {base}.polizas WHERE empresa=@empresa AND ejercicio=@ejercicio AND ref_tipo=@tipo AND ref_ciclo=@ciclo AND ref_numero=@numero "
            strSQL = strSQL.Replace("{base}", conta)
            cmd = New MySqlCommand(strSQL, CON)
            cmd.Parameters.AddWithValue("@empresa", Sesion.IdEmpresa)
            cmd.Parameters.AddWithValue("@ejercicio", intEjercicio)
            cmd.Parameters.AddWithValue("@tipo", tipo)
            cmd.Parameters.AddWithValue("@ciclo", ciclo)
            cmd.Parameters.AddWithValue("@numero", numero)
            cmd.ExecuteNonQuery()

            logEx = True
        ElseIf MostrarAviso Then
            MessageBox.Show("This document do not have any journal entry in current accounting year" & vbCr & vbCr & "No journal entry was deleted", "Journal", MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
        End If
        Return logEx
    End Function

    'Devuelve el ID del ejercicio contable activo para esta empresa
    Private Function EjercicioActivoID() As Integer
        Dim strSQL As String = "SELECT valor FROM {base}.parametros_empresa WHERE empresa=@empresa AND parametro=3 LIMIT 1"
        Dim id As Integer = INT_CERO
        Dim obj As Object

        strSQL = strSQL.Replace("{base}", Sesion.BaseConta)
        Using cmd As New MySqlCommand(strSQL, CON)
            cmd.Parameters.AddWithValue("@empresa", Sesion.IdEmpresa)
            obj = cmd.ExecuteScalar
            If obj IsNot Nothing Then
                id = CInt(obj)
            End If
        End Using

        Return id
    End Function

    'Identifica si el documento de banco esta activo
    Private Function DocumentoEstaActivo(ByVal tipo As Integer, ByVal ciclo As Integer, ByVal numero As Integer) As Boolean
        Dim strSQL As String = "SELECT HDoc_Doc_Status Estado FROM Dcmtos_HDR WHERE HDoc_Sis_Emp=@empresa AND HDoc_Doc_Cat=@tipo AND HDoc_Doc_Ano=@ciclo AND HDoc_Doc_Num=@numero LIMIT 1"
        Dim logEx As Boolean = False
        Dim obj As Object

        Using cmd As New MySqlCommand(strSQL, CON)
            cmd.Parameters.AddWithValue("@empresa", Sesion.IdEmpresa)
            cmd.Parameters.AddWithValue("@tipo", tipo)
            cmd.Parameters.AddWithValue("@ciclo", ciclo)
            cmd.Parameters.AddWithValue("@numero", numero)
            obj = cmd.ExecuteScalar
            If obj IsNot Nothing Then
                'Estado 3 es ANULADO para documentos de banco
                If Not (CInt(obj) = INT_ANULADO) Then
                    logEx = True
                End If
            End If
        End Using

        Return logEx
    End Function

    'Carga los tipos de documento para bancos
    Private Sub CargarTipos()
        Base.CargarTipos()
        With Info
            'ID de documento
            .Cheque.ID = Base.IdCheque
            .Deposito.ID = Base.IdDeposito
            .Debito.ID = Base.IdDebito
            .Credito.ID = Base.IdCredito

            'Modo de poliza contable
            .Cheque.Modo = EnumModo.Cheque
            .Deposito.Modo = EnumModo.Deposito
            .Debito.Modo = EnumModo.Debito
            .Credito.Modo = EnumModo.Credito
        End With
    End Sub

    'Limpia los datos de la clase
    Public Sub Limpiar()
        'Limpiar variables internas
        _Empresa = 0
        _Ejercicio = 0
        _Poliza = 0
        _Fecha = Nothing
        _Concepto = String.Empty
        _Tipo = 0
        _TC = 0
        _Observaciones = String.Empty
        _Operador = String.Empty
        _Estado = 0
        _Grupo = String.Empty
        _Modo = 0
        _Referencia = 0
        _Ciclo = 0
        _Numero = 0
        _Moneda = 0
        _Tasa = 0
        _Revisado = 0
        _Usuario = String.Empty
        _Revision = Nothing

        'Limpiar datos de modos
        With Info
            .Cheque.ID = 0 : .Cheque.Modo = 0
            .Debito.ID = 0 : .Debito.Modo = 0
            .Deposito.ID = 0 : .Deposito.Modo = 0
            .Credito.ID = 0 : .Credito.Modo = 0
        End With

        'Limpiar datos del documento
        With Documento
            'Datos de poliza
            .Ejercicio = 0
            .Transaccion = 0

            'Datos de documento bancario
            .Dato.Tipo = 0
            .Dato.Ciclo = 0
            .Dato.Numero = 0
            .Dato.Catalogo = "Documento"
            .Dato.Documento = "0000"

            .Dato.Nombre = String.Empty
            .Dato.EsMultiple = False

            .Dato.Grupo = NO_GRUPO
            .Dato.Item = NO_ITEM
            .Dato.Fecha = Today.Date
            .Dato.Moneda = 0
            .Dato.Tasa = 0.0
            .Dato.Usuario = Sesion.Usuario
            .Dato.Estado = 0

            .Modo = 0
            .Debe = STR_CARGO
            .Haber = STR_ABONO
        End With

        LimpiarDetalle()
    End Sub

    'Limpia las variables del detalle
    Private Sub LimpiarDetalle()
        Detalle = New List(Of DatoDetalle)
    End Sub

    'Determina y devuelve el ID de ejercicio contable
    Public Function EjercicioDeDocumento(ByVal empresa As Integer, ByVal tipo As Integer, ByVal ciclo As Integer, ByVal numero As Integer, Optional fecha As String = STR_VACIO) As Integer
        Dim strSQL As String = "SELECT HDoc_Doc_Fec fecha FROM Dcmtos_HDR WHERE HDoc_Sis_Emp=@empresa AND HDoc_Doc_Cat=@tipo AND HDoc_Doc_Ano=@ciclo AND HDoc_Doc_Num=@numero LIMIT 1"
        Dim strFecha As String = String.Empty
        Dim obj As Object
        Dim i As Integer = 0

        Try
            'Recuperar la fecha del documento
            Dim cmd As New MySqlCommand(strSQL, CON)
            cmd.Parameters.AddWithValue("@empresa", empresa)
            cmd.Parameters.AddWithValue("@tipo", tipo)
            cmd.Parameters.AddWithValue("@ciclo", ciclo)
            cmd.Parameters.AddWithValue("@numero", numero)
            obj = cmd.ExecuteScalar
            If obj IsNot Nothing Then
                strFecha = CDate(obj).ToString(FORMATO_MYSQL)
            ElseIf Not fecha.Equals(String.Empty) Then
                strFecha = fecha
            End If

            'Determinar el ejercicio para esa fecha
            strSQL = "SELECT ejercicio FROM {base}.ejercicios WHERE (@fecha >= inicio AND @fecha <= fin) LIMIT 1"
            strSQL = strSQL.Replace("{base}", Sesion.BaseConta)
            cmd = New MySqlCommand(strSQL, CON)
            cmd.Parameters.AddWithValue("@fecha", strFecha)
            obj = cmd.ExecuteScalar
            If obj IsNot Nothing Then
                i = CInt(obj)
            End If
        Catch ex As Exception

        End Try

        Return i
    End Function

    'Devuelve si el ejercicio se encuentra activo
    Public Function EjercicioEstaActivo(ByVal ID As Integer) As Boolean
        Dim obj As Object
        Dim logOk As Boolean = False
        Dim strSQL As String = "SELECT IF(estado='A', 1, 0) estado FROM {base}.ejercicio_empresa WHERE empresa=@empresa AND ejercicio=@ejercicio"
        strSQL = strSQL.Replace("{base}", Sesion.BaseConta)

        Dim cmd As New MySqlCommand(strSQL, CON)
        cmd.Parameters.AddWithValue("@empresa", Sesion.IdEmpresa)
        cmd.Parameters.AddWithValue("@ejercicio", ID)

        obj = cmd.ExecuteScalar
        If obj IsNot Nothing Then
            logOk = Convert.ToBoolean(obj)
        End If

        Return logOk
    End Function

    'Recupera los datos de una póliza
    Public Function CargarPoliza(ByVal empresa As Integer, ByVal ejercicio As Integer, ByVal numero As Integer) As Boolean
        Dim strSQL As String = " SELECT fecha, concepto, tipo, IFNULL(tipo_cambio,0.0) tc, IFNULL(observaciones,'') observaciones, operador, estado, grupo, modo, ref_tipo, ref_ciclo, ref_numero, IFNULL(divisa,0) divisa, IFNULL(tasa,0.0) tasa, revisado, IFNULL(usuario_rev,'') usuario, ult_rev revision" &
                               " FROM {base}.polizas " &
                               " WHERE empresa=@empresa AND ejercicio=@ejercicio AND poliza=@poliza" &
                               " LIMIT 1"
        Dim logEx As Boolean = False
        Dim cmd As MySqlCommand

        Limpiar()
        If cFunciones.ContaActiva Then
            strSQL = strSQL.Replace("{base}", Sesion.BaseConta)
            cmd = New MySqlCommand(strSQL, CON)
            cmd.Parameters.AddWithValue("@empresa", empresa)
            cmd.Parameters.AddWithValue("@ejercicio", empresa)
            cmd.Parameters.AddWithValue("@numero", empresa)
            Using dr As MySqlDataReader = cmd.ExecuteReader
                If dr.Read() Then
                    _Empresa = empresa
                    _Ejercicio = ejercicio
                    _Poliza = Poliza

                    _Fecha = dr.Item("fecha")
                    _Concepto = dr.Item("concepto")
                    _Tipo = dr.Item("tipo")
                    _TC = dr.Item("tc")
                    _Observaciones = dr.Item("observaciones")
                    _Operador = dr.Item("operador")
                    _Estado = dr.Item("estado")
                    _Grupo = dr.Item("grupo")
                    _Modo = dr.Item("modo")
                    _Referencia = dr.Item("ref_tipo")
                    _Ciclo = dr.Item("ref_ciclo")
                    _Numero = dr.Item("ref_numero")
                    _Moneda = dr.Item("divisa")
                    _Tasa = dr.Item("tasa")
                    _Revisado = dr.Item("revisado")
                    _Usuario = dr.Item("usuario")
                    _Revision = dr.Item("revision")
                End If
            End Using
        End If
        Return logEx
    End Function

    'Implementa IDisposable para poder usar la clase dentro de un bloque Using
    Public Sub Dispose() Implements System.IDisposable.Dispose
        If logDisposed = True Then Return

        Base = Nothing
        Detalle = Nothing
        logDisposed = True

        GC.SuppressFinalize(Me)
    End Sub

    Protected Overrides Sub Finalize()
        Dispose()
    End Sub

End Class
