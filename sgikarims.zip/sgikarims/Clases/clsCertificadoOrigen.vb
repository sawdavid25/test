﻿Public Class clsCertificadoOrigen

#Region "Miembros"
    Const CAT_CERTIFICADO As Integer = 263
    Dim intIdCertificado As Integer = NO_FILA
    Dim intAño As Integer = NO_FILA

    Dim intopcfibra As Integer = NO_FILA
    Dim intidfibra As Integer = NO_FILA
    Dim strfibra As String = STR_VACIO
    Dim intPais As Integer = NO_FILA
    Dim strPais As String = STR_VACIO

    Dim strHilo1 As String = STR_VACIO
    Dim strHilo2 As String = STR_VACIO
    Dim strHilo3 As String = STR_VACIO



    Dim intEmpresa As Integer = NO_FILA
    Dim ffecha As MySqlDateTime
    Dim ffechanet As Date
    Dim intIdClinte As Integer = NO_FILA
    Dim strCliente As String = STR_VACIO
    Dim strClienteDireccion As String = STR_VACIO
    Dim strUMedida As String = STR_VACIO
    Dim strArancel As String = STR_VACIO
    Dim strPO As String = STR_VACIO
    Dim strReferencia As String = STR_VACIO
    Dim strContenedor As String = STR_VACIO
    Dim strTransporte As String = STR_VACIO
    Dim strLote As String = STR_VACIO
    Dim cat_doc As Integer = NO_FILA
    Dim intInvoice As Integer = NO_FILA
    Dim intIdProducto As Integer = NO_FILA
    Dim strProducto As String = STR_VACIO
    Dim intCajas As Integer = NO_FILA
    Dim intIDProveedor As Integer = NO_FILA
    Dim strProveedor As String = STR_VACIO
    Dim strProveedorDic As String = STR_VACIO
    Dim intIdOrigen As Integer = NO_FILA
    Dim strOrigen As String = STR_VACIO
    Dim intIdFactura As Integer = NO_FILA
    Dim intAñoFactura As Integer = NO_FILA
    Dim intLinea As String = STR_VACIO
    Dim dblPesoNeto As Double = NO_FILA
    Dim dblPesoBruto As Double = NO_FILA
    Dim intIdFirmante As Integer = NO_FILA
    Dim strFirmante As String = STR_VACIO
    Dim intIdPuesto As Integer = NO_FILA
    Dim strPuesto As String = STR_VACIO
    Dim strCorreo As String = STR_VACIO
    Dim fechaFactura As MySqlDateTime
    Dim strFechaFactura As Date
    Dim intEstado As Integer = INT_UNO
    Dim strDestino As String = STR_VACIO
    Dim strFacHN As String = NO_FILA
    Dim strFactFel As String = STR_VACIO
    Dim strVendedor As String = STR_VACIO
    Dim strTelefono As String = STR_VACIO
    Dim strHBI As String = STR_VACIO

    Dim intIdSerieCert As Integer
    Dim strSerieCert As String
    Dim intCorrelativo As Integer
    Dim marcas As String

    Dim dblSaldoBruto As Double
    Dim dblSaldoNeto As Double
    Dim dblSaldoCajas As Double

#End Region

#Region "Propiedades"

    Public Property Destino As String
        Get
            Return strDestino
        End Get
        Set(value As String)
            strDestino = value
        End Set
    End Property

    Public Property Estado As Integer
        Get
            Return intEstado
        End Get
        Set(value As Integer)
            intEstado = value
        End Set
    End Property

    Public Property Correo As String
        Get
            Return strCorreo
        End Get
        Set(value As String)
            strCorreo = value
        End Set
    End Property

    Public Property Puesto As String
        Get
            Return strPuesto
        End Get
        Set(value As String)
            strPuesto = value
        End Set
    End Property

    Public Property IdPuesto As Integer
        Get
            Return intIdPuesto
        End Get
        Set(value As Integer)
            intIdPuesto = value
        End Set
    End Property

    Public Property Firmante As String
        Get
            Return strFirmante
        End Get
        Set(value As String)
            strFirmante = value
        End Set
    End Property
    Public Property Vendedor As String
        Get
            Return strVendedor
        End Get
        Set(value As String)
            strFirmante = value
        End Set
    End Property
    Public Property IdFirmante As Integer
        Get
            Return intIdFirmante
        End Get
        Set(value As Integer)
            intIdFirmante = value
        End Set
    End Property

    Public ReadOnly Property Catalogo As Integer
        Get
            Return CAT_CERTIFICADO
        End Get
    End Property
    Public Property FactHN As String
        Get
            Return strFacHN
        End Get
        Set(value As String)
            strFacHN = value
        End Set
    End Property
    Public Property FactFel As String
        Get
            Return strFactFel
        End Get
        Set(value As String)
            strFactFel = value
        End Set
    End Property
    Public Property IdCertificado As Integer
        Get
            Return intIdCertificado
        End Get
        Set(value As Integer)
            intIdCertificado = value
        End Set
    End Property

    Public Property Año As Integer
        Get
            Return intAño
        End Get
        Set(value As Integer)
            intAño = value
        End Set
    End Property

    Public Property Empresa As Integer
        Get
            Return intEmpresa
        End Get
        Set(value As Integer)
            intEmpresa = value
        End Set
    End Property

    Public Property Fecha As MySqlDateTime
        Get
            Return ffecha
        End Get
        Set(value As MySqlDateTime)
            ffecha = value
        End Set
    End Property
    Public Property Factura As String
        Get
            Return strFacHN
        End Get
        Set(value As String)
            strFechaFactura = value
        End Set
    End Property

    Public WriteOnly Property Fecha_Net As Date
        Set(value As Date)
            ffecha = New MySqlDateTime(value.Year, value.Month, value.Day, value.Hour, value.Minute, value.Second)
        End Set
    End Property

    Public Property IdCliente As Integer
        Get
            Return intIdClinte
        End Get
        Set(value As Integer)
            intIdClinte = value
        End Set
    End Property

    Public Property Cliente As String
        Get
            Return strCliente
        End Get
        Set(value As String)
            strCliente = value
        End Set
    End Property
    Public Property ClienteDireccion As String
        Get
            Return strClienteDireccion
        End Get
        Set(value As String)
            strClienteDireccion = value
        End Set
    End Property
    Public Property Unidad_Medida As String
        Get
            Return strUMedida
        End Get
        Set(value As String)
            strUMedida = value
        End Set
    End Property

    Public Property Arancel As String
        Get
            Return strArancel
        End Get
        Set(value As String)
            strArancel = value
        End Set
    End Property

    Public Property PO As String
        Get
            Return strPO
        End Get
        Set(value As String)
            strPO = value
        End Set
    End Property

    Public Property Referencia As String
        Get
            Return strReferencia
        End Get
        Set(value As String)
            strReferencia = value
        End Set
    End Property

    Public Property Contenedor As String
        Get
            Return strContenedor
        End Get
        Set(value As String)
            strContenedor = value
        End Set
    End Property

    Public Property Trasporte As String
        Get
            Return strTransporte
        End Get
        Set(value As String)
            strTransporte = value
        End Set
    End Property

    Public Property Lote As String
        Get
            Return strLote
        End Get
        Set(value As String)
            strLote = value
        End Set
    End Property

    Public Property Cat_Documento As Integer
        Get
            Return cat_doc
        End Get
        Set(value As Integer)
            cat_doc = value
        End Set
    End Property

    Public Property Invoice As Integer
        Get
            Return intInvoice
        End Get
        Set(value As Integer)
            intInvoice = value
        End Set
    End Property

    Public Property IdProducto As Integer
        Get
            Return intIdProducto
        End Get
        Set(value As Integer)
            intIdProducto = value
        End Set
    End Property

    Public Property Producto As String
        Get
            Return strProducto
        End Get
        Set(value As String)
            strProducto = value
        End Set
    End Property

    Public Property Cajas As Integer
        Get
            Return intCajas
        End Get
        Set(value As Integer)
            intCajas = value
        End Set
    End Property

    Public Property IdProveedor As Integer
        Get
            Return intIDProveedor
        End Get
        Set(value As Integer)
            intIDProveedor = value
        End Set
    End Property
    Public Property Telefono As String
        Get
            Return strTelefono
        End Get
        Set(value As String)
            strTelefono = value
        End Set
    End Property
    Public Property Proveedor As String
        Get
            Return strProveedor
        End Get
        Set(value As String)
            strProveedor = value
        End Set
    End Property

    Public Property ProveedorDic As String
        Get
            Return strProveedorDic
        End Get
        Set(value As String)
            strProveedorDic = value
        End Set
    End Property

    Public Property IdOrigen As Integer
        Get
            Return intIdOrigen
        End Get
        Set(value As Integer)
            intIdOrigen = value
        End Set
    End Property

    Public Property Origen As String
        Get
            Return strOrigen
        End Get
        Set(value As String)
            strOrigen = value
        End Set
    End Property

    Public Property IdFactura As Integer
        Get
            Return intIdFactura
        End Get
        Set(value As Integer)
            intIdFactura = value
        End Set
    End Property

    Public Property AñoFactrua As Integer
        Get
            Return intAñoFactura
        End Get
        Set(value As Integer)
            intAñoFactura = value
        End Set
    End Property

    Public WriteOnly Property FechaFactura_Net As Date
        Set(value As Date)
            fechaFactura = New MySqlDateTime(value.Year, value.Month, value.Day, value.Hour, value.Minute, value.Second)
        End Set
    End Property

    Public ReadOnly Property FechaFact As MySqlDateTime
        Get
            Return fechaFactura
        End Get
    End Property

    Public Property Linea As String
        Get
            Return intLinea
        End Get
        Set(value As String)
            intLinea = value
        End Set
    End Property

    Public Property Peso_Neto As Double
        Get
            Return dblPesoNeto
        End Get
        Set(value As Double)
            dblPesoNeto = value
        End Set
    End Property

    Public Property Peso_Bruto As Double
        Get
            Return dblPesoBruto
        End Get
        Set(value As Double)
            dblPesoBruto = value
        End Set
    End Property

    'Serie
    Public Property idSerieCert As Integer
        Get
            Return intIdSerieCert
        End Get
        Set(value As Integer)
            intIdSerieCert = value
        End Set
    End Property


    Public Property SerieCert As String
        Get
            Return strSerieCert
        End Get
        Set(value As String)
            strSerieCert = value
        End Set
    End Property

    Public Property intCorrelativoCert As Integer
        Get
            Return intCorrelativo
        End Get
        Set(value As Integer)
            intCorrelativo = value
        End Set
    End Property

    Public Property marcasCadena As String
        Get
            Return marcas
        End Get
        Set(value As String)
            marcas = value
        End Set
    End Property

    Public Property Saldo_Bruto As Double
        Get
            Return dblSaldoBruto
        End Get
        Set(value As Double)
            dblSaldoBruto = value
        End Set
    End Property

    Public Property Saldo_Neto As Double
        Get
            Return dblSaldoNeto
        End Get
        Set(value As Double)
            dblSaldoNeto = value
        End Set
    End Property
    Public Property Saldo_Caja As Double
        Get
            Return dblSaldoCajas
        End Get
        Set(value As Double)
            dblSaldoCajas = value
        End Set
    End Property
    Public Property HBI_PART As String
        Get
            Return strHBI
        End Get
        Set(value As String)
            strHBI = value
        End Set
    End Property

    Public Property Intidfibra1 As Integer
        Get
            Return intidfibra
        End Get
        Set(value As Integer)
            intidfibra = value
        End Set
    End Property

    Public Property Strfibra1 As String
        Get
            Return strfibra
        End Get
        Set(value As String)
            strfibra = value
        End Set
    End Property

    Public Property IntPais1 As Integer
        Get
            Return intPais
        End Get
        Set(value As Integer)
            intPais = value
        End Set
    End Property

    Public Property StrPais1 As String
        Get
            Return strPais
        End Get
        Set(value As String)
            strPais = value
        End Set
    End Property

    Public Property StrHilo11 As String
        Get
            Return strHilo1
        End Get
        Set(value As String)
            strHilo1 = value
        End Set
    End Property

    Public Property StrHilo22 As String
        Get
            Return strHilo2
        End Get
        Set(value As String)
            strHilo2 = value
        End Set
    End Property

    Public Property StrHilo33 As String
        Get
            Return strHilo3
        End Get
        Set(value As String)
            strHilo3 = value
        End Set
    End Property

    Public Property Intopcfibra1 As Integer
        Get
            Return intopcfibra
        End Get
        Set(value As Integer)
            intopcfibra = value
        End Set
    End Property

#End Region

#Region "Funciones"

    Public Sub New()
        strFacHN = STR_VACIO
        intIdCertificado = NO_FILA
        intAño = NO_FILA
        intEmpresa = NO_FILA
        intIdClinte = NO_FILA
        strClienteDireccion = NO_FILA
        strCliente = STR_VACIO
        strUMedida = STR_VACIO
        strArancel = STR_VACIO
        strPO = STR_VACIO
        strReferencia = STR_VACIO
        strContenedor = STR_VACIO
        strTransporte = STR_VACIO
        strLote = STR_VACIO
        cat_doc = NO_FILA
        intInvoice = NO_FILA
        intIdProducto = NO_FILA
        strProducto = STR_VACIO
        intCajas = NO_FILA
        intIDProveedor = NO_FILA
        strProveedor = STR_VACIO
        strProveedorDic = STR_VACIO
        intIdOrigen = NO_FILA
        strOrigen = STR_VACIO
        intIdFactura = NO_FILA
        intAñoFactura = NO_FILA
        intLinea = STR_VACIO
        dblPesoNeto = NO_FILA
        dblPesoBruto = NO_FILA
        intEstado = INT_UNO
        strHBI = STR_VACIO
        'Serie
        intIdSerieCert = INT_CERO
        strSerieCert = STR_VACIO
        intCorrelativoCert = INT_CERO
        marcas = STR_VACIO

        'fibra
        intopcfibra = INT_CERO
        intidfibra = INT_CERO
        strfibra = STR_VACIO
        intPais = INT_CERO
        strPais = STR_VACIO

        'hilos
        strHilo1 = STR_VACIO
        strHilo2 = STR_VACIO
        strHilo3 = STR_VACIO


    End Sub

    Public Function SeleccionarNuevo(Optional intTipo As Integer = 0) As Boolean
        SeleccionarNuevo = False
        Dim strSQL As String = STR_VACIO
        Dim strTarifHN As String = STR_VACIO

        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader

        If intTipo = 0 Then
            strSQL = "SELECT p.pro_proveedor proveedor, p.pro_direccion proveedor_dic, h47.HDoc_RF3_Dbl," &
           "       cat_desc Origen, art_DLarga Producto, SUM(dt.DDoc_Prd_QTY) Peso_Neto," &
           "       SUM(IF(dt.DDoc_Prd_UM = 69, dt.DDoc_RF1_Dbl, dt.DDoc_RF2_Dbl)) Peso_Bruto, dt.DDoc_RF1_Txt Referencia, inv_prodlote Lote," &
           "       SUM(BDoc_Box_QTY) Bultos , a.ADoc_Dta_Chr Transporte, b.ADoc_Dta_Chr POs, " &
           "       p.pro_codigo IdProveedor, cat_num idOrigen, dt.DDoc_Prd_Cod IDProducto," &
           "       ifnull((select concat('PF-',pp.PDoc_Par_Num , '-' ,hh.HDoc_DR1_Num )" &
           "                   from Dcmtos_DTL_Pro p " &
           "                       left join Dcmtos_DTL_Pro pp on pp.PDoc_Sis_Emp = p.PDoc_Sis_Emp and pp.PDoc_Chi_Cat = p.PDoc_Par_Cat and pp.PDoc_Chi_Ano = p.PDoc_Par_Ano " &
           "                       and pp.PDoc_Chi_Num =  p.PDoc_Par_Num and pp.PDoc_Chi_Lin = p.PDoc_Par_Lin and pp.PDoc_Par_Cat = 75 " &
           "                       left join Dcmtos_HDR hh on hh.HDoc_Sis_Emp = pp.PDoc_Sis_Emp and hh.HDoc_Doc_Cat = pp.PDoc_Par_Cat and hh.HDoc_Doc_Ano = pp.PDoc_Par_Ano and hh.HDoc_Doc_Num = pp.PDoc_Par_Num " &
           "                   where p.PDoc_Sis_Emp = dt.DDoc_Sis_Emp and p.PDoc_Chi_Cat = dt.DDoc_Doc_Cat and p.PDoc_Chi_Ano =dt.DDoc_Doc_Ano " &
           "           and p.PDoc_Chi_Num = dt.DDoc_Doc_Num and p.PDoc_Chi_Lin = dt.DDoc_Doc_Lin   ),'') PO, " &
           "            IFNULL(( SELECT dc.EDoc_Lin_Frac " &
           "            FROM Dcmtos_DEC dc " &
           "            WHERE dc.EDoc_Sis_Emp=rp.PDoc_Sis_Emp AND dc.EDoc_Doc_Cat=rp.PDoc_Par_Cat AND dc.EDoc_Doc_Ano=rp.PDoc_Par_Ano AND dc.EDoc_Doc_Num=rp.PDoc_Par_Num AND dc.EDoc_Doc_Lin=rp.PDoc_Par_Lin),'') tarif,"
            If Sesion.IdEmpresa = 16 Then
                If intIdClinte = 8 Then
                    strSQL &= " IFNULL(( "
                    strSQL &= "     SELECT d75.DDoc_RF2_Txt  "
                    strSQL &= "         FROM Dcmtos_DTL_Pro p180 "
                    strSQL &= "             LEFT JOIN Dcmtos_DTL_Pro p75 ON p75.PDoc_Sis_Emp = p180.PDoc_Sis_Emp AND p75.PDoc_Chi_Cat = p180.PDoc_Par_Cat AND p75.PDoc_Chi_Ano = p180.PDoc_Par_Ano AND p75.PDoc_Chi_Num = p180.PDoc_Par_Num AND p75.PDoc_Chi_Lin = p180.PDoc_Par_Lin AND p75.PDoc_Par_Cat = 75 "
                    strSQL &= "                 LEFT JOIN Dcmtos_DTL d75 ON d75.DDoc_Sis_Emp = p75.PDoc_Sis_Emp AND d75.DDoc_Doc_Cat = p75.PDoc_Par_Cat AND d75.DDoc_Doc_Ano = p75.PDoc_Par_Ano AND d75.DDoc_Doc_Num = p75.PDoc_Par_Num AND d75.DDoc_Doc_Lin = p75.PDoc_Par_Lin "
                    strSQL &= "                     WHERE p180.PDoc_Sis_Emp = dt.DDoc_Sis_Emp AND p180.PDoc_Chi_Cat = dt.DDoc_Doc_Cat AND p180.PDoc_Chi_Ano = dt.DDoc_Doc_Ano AND p180.PDoc_Chi_Num = dt.DDoc_Doc_Num AND p180.PDoc_Chi_Lin = dt.DDoc_Doc_Lin),'') HBI, "
                End If
            End If
            strSQL &= "     IFNULL(( select cl.cli_cliente " &
                "           from  Dcmtos_DTL_Pro p" &
                "               left join Dcmtos_DTL dp on dp.DDoc_Sis_Emp = p.PDoc_Sis_Emp and dp.DDoc_Doc_Cat =  p.PDoc_Par_Cat and dp.DDoc_Doc_Ano =  p.PDoc_Par_Ano and dp.DDoc_Doc_Num = p.PDoc_Par_Num and dp.DDoc_Doc_Lin = p.PDoc_Par_Lin " &
                "               left join Clientes cl on cl.cli_sisemp = dp.DDoc_Sis_Emp and cl.cli_codigo =  dp.DDoc_RF1_Num " &
                "           WHERE p.PDoc_Sis_Emp = dt.DDoc_Sis_Emp AND p.PDoc_Chi_Cat = dt.DDoc_Doc_Cat AND p.PDoc_Chi_Ano =dt.DDoc_Doc_Ano AND p.PDoc_Chi_Num = dt.DDoc_Doc_Num AND p.PDoc_Chi_Lin = dt.DDoc_Doc_Lin" &
                "       ),'-') Destino "

            strSQL &= " FROM Dcmtos_DTL dt" &
                "       LEFT JOIN Dcmtos_DTL_Box ON BDoc_Sis_Emp= dt.DDoc_Sis_Emp and BDoc_Doc_Cat=dt.DDoc_Doc_Cat and" &
                "           BDoc_Doc_Ano = dt.DDoc_Doc_Ano and BDoc_Doc_Num = dt.DDoc_Doc_Num and BDoc_Doc_Lin =dt.DDoc_Doc_Lin" &
                "       LEFT JOIN Dcmtos_ACC a ON a.ADoc_Sis_Emp= dt.DDoc_Sis_Emp and a.ADoc_Doc_Cat=dt.DDoc_Doc_Cat" &
                "           and a.ADoc_Doc_Ano = dt.DDoc_Doc_Ano and a.ADoc_Doc_Num = dt.DDoc_Doc_Num and" &
                "           (a.ADoc_Doc_Sub ='Doc_CCPorte' or a.ADoc_Doc_Sub = 'Doc_CCPorte2') and a.ADoc_Doc_Lin = '06'" &
                "       LEFT JOIN Dcmtos_ACC b ON b.ADoc_Sis_Emp= dt.DDoc_Sis_Emp and b.ADoc_Doc_Cat=dt.DDoc_Doc_Cat and" &
                "           b.ADoc_Doc_Ano = dt.DDoc_Doc_Ano and b.ADoc_Doc_Num = dt.DDoc_Doc_Num and" &
                "           (b.ADoc_Doc_Sub ='Doc_CPckLst' or b.ADoc_Doc_Sub = 'Doc_CPckLst2') and b.Adoc_Doc_Lin = '06'" &
                "       LEFT JOIN Dcmtos_DTL_Pro p48 ON p48.PDoc_Sis_Emp = dt.DDoc_Sis_Emp AND p48.PDoc_Chi_Cat = dt.DDoc_Doc_Cat AND p48.PDoc_Chi_Ano = dt.DDoc_Doc_Ano AND p48.PDoc_Chi_Num = dt.DDoc_Doc_Num AND p48.PDoc_Chi_Lin = dt.DDoc_Doc_Lin  AND p48.PDoc_Par_Cat = 48 " &
                "       LEFT JOIN Dcmtos_DTL_Pro p47 ON p47.PDoc_Sis_Emp = p48.PDoc_Sis_Emp AND p47.PDoc_Chi_Cat = p48.PDoc_Par_Cat AND p47.PDoc_Chi_Ano = p48.PDoc_Par_Ano AND p47.PDoc_Chi_Num = p48.PDoc_Par_Num AND p47.PDoc_Chi_Lin = p48.PDoc_Par_Lin AND p47.PDoc_Par_Cat = 47 " &
                "       LEFT JOIN Dcmtos_HDR h47 ON h47.HDoc_Sis_Emp = p47.PDoc_Sis_Emp AND h47.HDoc_Doc_Cat = p47.PDoc_Par_Cat AND h47.HDoc_Doc_Ano = p47.PDoc_Par_Ano AND h47.HDoc_Doc_Num = p47.PDoc_Par_Num " &
                "       LEFT JOIN Dcmtos_DTL_Pro rp ON rp.PDoc_Sis_Emp = p47.PDoc_Sis_Emp AND rp.PDoc_Chi_Cat = p47.PDoc_Par_Cat AND rp.PDoc_Chi_Ano = p47.PDoc_Par_Ano AND rp.PDoc_Chi_Num = p47.PDoc_Par_Num AND rp.PDoc_Chi_Lin = p47.PDoc_Par_Lin AND rp.PDoc_Par_Cat = 180" &
                "       LEFT JOIN Proveedores pp ON pp.pro_sisemp = h47.HDoc_Sis_Emp AND pp.pro_codigo = h47.HDoc_Emp_Cod " &
                "       LEFT JOIN Inventarios  ON dt.DDoc_Prd_Cod = inv_numero and dt.DDoc_Sis_Emp=inv_sisemp" &
                "       LEFT JOIN Articulos  ON inv_artcodigo= art_codigo and inv_sisemp= art_sisemp" &
                "       LEFT JOIN Proveedores p ON inv_provcod=p.pro_codigo and art_sisemp= p.pro_sisemp " &
                "       LEFT JOIN Catalogos  ON cat_num= inv_lugarfab " & ''"       LEFT JOIN Catalogos  ON cat_num= pp.pro_pais " &
                " WHERE dt.DDoc_Doc_Num = {factura} AND dt.DDoc_Doc_Lin = {linea} AND dt.DDoc_Sis_Emp = {empresa}" &
                "   AND dt.DDoc_Doc_Cat = 36 AND dt.DDoc_Doc_Ano = {año} "
            '"GROUP BY proveedor, proveedor_dic, Origen, Producto, Referencia, Lote, Transporte, POs, IdProveedor, idOrigen, IDProducto, PO, tarif, Destino;"
            If Sesion.IdEmpresa = 15 Or Sesion.IdEmpresa = 20 Then
                strSQL &= "GROUP BY proveedor, proveedor_dic, Origen, Producto, Transporte, POs, IdProveedor, idOrigen, PO, Destino;"
            Else
                strSQL &= "GROUP BY proveedor, proveedor_dic, Origen, Producto, Referencia, Lote, Transporte, POs, IdProveedor, idOrigen, IDProducto, PO, tarif, Destino;"
            End If
            strSQL = Replace(strSQL, "{factura}", intIdFactura)
            strSQL = Replace(strSQL, "{linea}", intLinea)
                strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
                strSQL = Replace(strSQL, "{año}", intAñoFactura)
            Else
                strSQL = " SELECT d.DDoc_RF2_Cod tarif,h.HDoc_RF1_Cod proveedor, h.HDoc_RF1_Txt proveedor_dic,h.HDoc_RF2_Cod Origen, h.HDoc_DR2_Num Producto, d.DDoc_Prd_Cif Peso_Neto, d.DDoc_Prd_Fob Peso_Bruto, h.HDoc_DR1_Num Referencia, d.DDoc_RF1_Cod Lote, d.DDoc_RF3_Dbl Bultos, h.HDoc_RF2_Txt Transporte, 
                            d.DDoc_Prd_Des POs, h.HDoc_RF1_Num IdProveedor, h.HDoc_RF2_Num idOrigen, h.HDoc_DR2_Cat IDProducto,d.DDoc_Prd_Des PO, h.HDoc_Emp_Per Destino, d.DDoc_Prd_Ref con,HDoc_Emp_Dir medida
                        FROM Dcmtos_HDR h
                        LEFT JOIN Dcmtos_DTL d ON d.DDoc_Sis_Emp= h.HDoc_Sis_Emp AND d.DDoc_Doc_Cat = h.HDoc_Doc_Cat AND d.DDoc_Doc_Ano = h.HDoc_Doc_Ano AND d.DDoc_Doc_Num = h.HDoc_Doc_Num
                        WHERE h.HDoc_Sis_Emp = {empresa} AND h.HDoc_Doc_Cat = 263 AND h.HDoc_Doc_Ano = {año} AND h.HDoc_Doc_Num = {factura} AND d.DDoc_Doc_Lin = {linea} "

            strSQL = Replace(strSQL, "{factura}", intIdFactura)
            strSQL = Replace(strSQL, "{linea}", intLinea)
            strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
            strSQL = Replace(strSQL, "{año}", intAñoFactura)
        End If


        Try
            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSQL, CON)
            REA = COM.ExecuteReader
            If REA.HasRows = True Then
                REA.Read()
                If REA.IsDBNull(REA.GetOrdinal("Destino")) = False Then
                    strDestino = REA.GetString("Destino")
                End If
                If REA.IsDBNull(REA.GetOrdinal("tarif")) = False Then
                    strTarifHN = REA.GetString("tarif")
                End If
                If REA.IsDBNull(REA.GetOrdinal("proveedor")) = False Then
                    strProveedor = REA.GetString("proveedor")
                End If
                If REA.IsDBNull(REA.GetOrdinal("proveedor_dic")) = False Then
                    strProveedorDic = REA.GetString("proveedor_dic")
                End If
                If REA.IsDBNull(REA.GetOrdinal("Origen")) = False Then
                    strOrigen = REA.GetString("Origen")
                End If
                If REA.IsDBNull(REA.GetOrdinal("Producto")) = False Then
                    strProducto = REA.GetString("Producto")
                End If
                If REA.IsDBNull(REA.GetOrdinal("Peso_Neto")) = False Then
                    dblPesoNeto = REA.GetDouble("Peso_Neto")
                End If
                If REA.IsDBNull(REA.GetOrdinal("Peso_Bruto")) = False Then
                    dblPesoBruto = REA.GetDouble("Peso_Bruto")
                End If
                If REA.IsDBNull(REA.GetOrdinal("Referencia")) = False Then
                    strReferencia = REA.GetString("Referencia")
                End If
                If REA.IsDBNull(REA.GetOrdinal("Lote")) = False Then
                    strLote = REA.GetString("Lote")
                End If
                If REA.IsDBNull(REA.GetOrdinal("Bultos")) = False Then
                    intCajas = REA.GetInt32("Bultos")
                End If
                If REA.IsDBNull(REA.GetOrdinal("Transporte")) = False Then
                    strTransporte = REA.GetString("Transporte")
                End If
                If REA.IsDBNull(REA.GetOrdinal("PO")) = False Then
                    strPO = REA.GetString("PO")
                End If
                If REA.IsDBNull(REA.GetOrdinal("idOrigen")) = False Then
                    intIdOrigen = REA.GetInt32("idOrigen")
                End If
                If REA.IsDBNull(REA.GetOrdinal("IdProveedor")) = False Then
                    intIDProveedor = REA.GetInt32("IdProveedor")
                End If
                If REA.IsDBNull(REA.GetOrdinal("IDProducto")) = False Then
                    intIdProducto = REA.GetInt32("IDProducto")
                End If
                If Sesion.IdEmpresa = 16 Then
                    If intIdClinte = 8 Then
                        If REA.IsDBNull(REA.GetOrdinal("HBI")) = False Then
                            strHBI = REA.GetString("HBI")
                        End If
                    End If
                End If
                If intTipo = 1 Then
                        strContenedor = REA.GetString("con")
                        strArancel = REA.GetString("tarif")
                        strUMedida = REA.GetString("medida")
                    End If
                    REA = Nothing

                    If intTipo = 0 Then
                    ' selecionar el No. De Contenedor
                    strSQL = "select ifnull(ADoc_Dta_Txt,'N/A') cont , pa.EDoc_Lin_Frac tarif" &
                    " from Dcmtos_HDR f " &
                    " left join  Dcmtos_DTL dt " &
                        " on f.HDoc_Doc_Cat= dt.DDoc_Doc_Cat and f.HDoc_Doc_Num= dt.DDoc_Doc_Num and " &
                        " f.HDoc_Doc_Ano = dt.DDoc_Doc_Ano" &
                    " left join  Dcmtos_DTL_Pro id " &
                        " on f.HDoc_Doc_Cat= id.PDoc_Chi_Cat and f.HDoc_Doc_Ano= id.PDoc_Chi_Ano and" &
                        " f.HDoc_Doc_Num = id.PDoc_Chi_Num and dt.DDoc_Doc_Lin = id.PDoc_Chi_Lin and id.PDoc_Par_Cat = 48" &
                    " left join Dcmtos_DTL_Pro bo " &
                        " on id.PDoc_Par_Cat = bo.PDoc_Chi_Cat and id.PDoc_Par_Ano = bo.PDoc_Chi_Ano AND " &
                        " id.PDoc_Par_Num = bo.PDoc_Chi_Num and id.PDoc_Par_Lin = bo.PDoc_Chi_Lin and bo.PDoc_Par_Cat = 47" &
                    " left join Dcmtos_DTL_Pro im" &
                        " on bo.PDoc_Par_Cat = im.PDoc_Chi_Cat and bo.PDoc_Par_Ano = im.PDoc_Chi_Ano and" &
                        " bo.PDoc_Par_Num = im.PDoc_Chi_Num and bo.PDoc_Par_Lin = im.PDoc_Chi_Lin and im.PDoc_Par_Cat = 180" &
                    " Left join Dcmtos_DEC pa on pa.EDoc_Sis_Emp = im.PDoc_Sis_Emp and pa.EDoc_Doc_Cat = im.PDoc_Par_Cat and" &
                        " pa.EDoc_Doc_Ano = im.PDoc_Par_Ano and pa.EDoc_Doc_Num = im.PDoc_Par_Num and pa.EDoc_Doc_Lin = im.PDoc_Par_Lin  " &
                    " left join Dcmtos_DTL_Pro dp " &
                        " on im.PDoc_Par_Cat = dp.PDoc_Chi_Cat and im.PDoc_Par_Ano = dp.PDoc_Chi_Ano and" &
                        " im.PDoc_Par_Num = dp.PDoc_Chi_Num and im.PDoc_Par_Lin = dp.PDoc_Chi_Lin and dp.PDoc_Par_Cat = 55" &
                        " left join Dcmtos_ACC acc " &
                        " on acc.ADoc_Doc_Cat =  dp.PDoc_Par_Cat and acc.ADoc_Doc_Ano = dp.PDoc_Par_Ano and" &
                        " acc.ADoc_Doc_Num =dp.PDoc_Par_Num and acc.ADoc_Sis_Emp=dp.PDoc_Sis_Emp and ADoc_Doc_Lin = '04' and ADoc_Doc_Sub = 'Doc_PBLading'" &
                    "where f.HDoc_Doc_Cat=36 and f.HDoc_Doc_Num = {factura} and f.HDoc_Doc_Ano= {año} and dt.DDoc_Doc_Lin= {linea} and f.HDoc_Sis_Emp = {empresa}"
                    strSQL = Replace(strSQL, "{factura}", intIdFactura)
                        strSQL = Replace(strSQL, "{linea}", intLinea)
                        strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
                        strSQL = Replace(strSQL, "{año}", intAñoFactura)
                        MyCnn.CONECTAR = strConexion
                        COM = New MySqlCommand(strSQL, CON)
                        REA = COM.ExecuteReader
                        If REA.HasRows = True Then
                            REA.Read()
                            strContenedor = REA.GetString("cont")
                            If REA.IsDBNull(REA.GetOrdinal("tarif")) = False Then
                                strArancel = REA.GetString("tarif")
                            Else
                                strArancel = strTarifHN
                            End If
                        End If
                    End If

                    SeleccionarNuevo = True
                End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Function
    Private Function Nuevocertificado() As Integer
        Dim strSQL As String = STR_VACIO
        Dim conec As New MySqlConnection
        Dim COM As MySqlCommand
        Dim CodigoProyecto As Integer

        strSQL = " Select IFNULL(MAX(HDR.HDoc_Doc_Num),0)+1 NUMERO  "
        strSQL &= " FROM Dcmtos_HDR HDR"
        strSQL &= " WHERE HDR.HDoc_Sis_Emp = {empresa} And HDR.HDoc_Doc_Cat = {catalogo}  "

        strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
        strSQL = Replace(strSQL, "{catalogo}", 263)

        conec = New MySqlConnection(strConexion)
        conec.Open()
        COM = New MySqlCommand(strSQL, conec)
        CodigoProyecto = COM.ExecuteScalar
        conec.Close()
        conec.Dispose()
        conec = Nothing
        System.GC.Collect()
        Return CodigoProyecto
    End Function

    Public Function NuevoCorrelativo(ByVal idCatalogo As Integer, ByVal Serie As String) As Long
        Dim intId As Long = NO_FILA
        Dim strSQL As String = STR_VACIO
        Dim COM As New MySqlCommand

        strSQL = "SELECT (IFNULL(MAX(HDoc_DR1_Dbl),0)+1) ID FROM Dcmtos_HDR WHERE HDoc_Sis_Emp= {empresa}" &
            " AND HDoc_Doc_Cat = {cat}  and HDoc_Emp_NIT = '" & Serie & "'"
        strSQL = Replace(strSQL, "{cat}", idCatalogo)
        strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
        Try
            MyCnn.CONECTAR = strConexion
            If MyCnn.ProbarConexiones = True Then
                COM = New MySqlCommand(strSQL, CON)
                intId = CInt(COM.ExecuteScalar)
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        Return intId
    End Function

    Public Function Guardar(Optional logInsert As Boolean = True) As Boolean
        Guardar = True
        Dim cHDR As New clsDcmtos_HDR
        Dim cDTL_FIRMANTE As New clsDcmtos_DTL
        Dim cDTL_REF As New clsDcmtos_DTL
        Try
            'guardar encabezado 
            If logInsert = True Then
                intAño = cFunciones.AñoMySQL
                intIdCertificado = Nuevocertificado()
                cHDR.HDoc_Doc_Fec_NET = cFunciones.HoyMySQL
                'Correlativo
                intCorrelativoCert = NuevoCorrelativo(263, strSerieCert)
            Else
                cHDR.HDoc_Doc_Fec_NET = FechaFact
            End If

            cHDR.HDOC_PRO_FEC = FechaFact
            cHDR.HDOC_DOC_ANO = intAño
            cHDR.HDOC_DOC_NUM = intIdCertificado
            cHDR.HDOC_SIS_EMP = Sesion.IdEmpresa
            cHDR.HDOC_DOC_CAT = CAT_CERTIFICADO
            cHDR.HDOC_EMP_COD = intIdClinte
            cHDR.HDOC_EMP_NOM = strCliente
            cHDR.HDOC_EMP_DIR = strUMedida
            cHDR.HDOC_DR1_NUM = strReferencia
            cHDR.HDOC_DR2_CAT = IdProducto
            cHDR.HDOC_DR2_NUM = strProducto
            cHDR.HDOC_DR2_EMP = intCajas
            cHDR.HDOC_RF1_NUM = IdProveedor
            cHDR.HDOC_RF1_COD = strProveedor
            cHDR.HDOC_RF1_TXT = strProveedorDic
            cHDR.HDOC_RF2_NUM = IdOrigen
            cHDR.HDOC_RF2_COD = strOrigen
            cHDR.HDOC_RF2_TXT = strTransporte
            cHDR.HDOC_USUARIO = Sesion.idUsuario
            cHDR.HDOC_PRO_DCAT = cat_doc
            cHDR.HDOC_PRO_DNUM = IdFactura
            cHDR.HDOC_PRO_DANO = AñoFactrua
            cHDR.HDOC_DOC_MON = intLinea
            cHDR.HDOC_RF1_DBL = dblPesoNeto
            cHDR.HDOC_RF2_DBL = dblPesoBruto
            cHDR.HDOC_USUARIO = Sesion.Usuario
            cHDR.HDOC_DOC_STATUS = intEstado
            cHDR.HDOC_EMP_PER = strDestino
            cHDR.HDOC_EMP_TEL = strHBI
            'Serie
            cHDR.HDOC_DR1_CAT = intIdSerieCert
            cHDR.HDOC_EMP_NIT = strSerieCert
            cHDR.HDOC_DR1_DBL = intCorrelativoCert

            cHDR.HDOC_RF3_DBL = intInvoice

            cHDR.CONEXION = strConexion
            If logInsert = True Then
                If cHDR.Guardar = False Then
                    Guardar = False
                    MsgBox(cHDR.MERROR.ToString)
                    Exit Function
                End If
            Else
                If cHDR.Actualizar = False Then
                    Guardar = False
                    Exit Function
                End If
            End If
            ''guardar datos del firmante
            cDTL_FIRMANTE.DDOC_DOC_NUM = intIdCertificado
            cDTL_FIRMANTE.DDOC_SIS_EMP = cHDR.HDOC_SIS_EMP
            cDTL_FIRMANTE.DDOC_DOC_CAT = cHDR.HDOC_DOC_CAT
            cDTL_FIRMANTE.DDOC_DOC_ANO = cHDR.HDOC_DOC_ANO
            cDTL_FIRMANTE.DDOC_DOC_LIN = INT_UNO
            cDTL_FIRMANTE.DDOC_PRD_PNR = "FIRMANTE"
            cDTL_FIRMANTE.DDOC_PRD_UM = intIdFirmante
            cDTL_FIRMANTE.DDOC_PRD_DES = strFirmante
            cDTL_FIRMANTE.DDOC_RF1_NUM = intIdPuesto
            cDTL_FIRMANTE.DDOC_RF1_COD = strPuesto
            cDTL_FIRMANTE.DDOC_RF2_COD = strCorreo

            cDTL_FIRMANTE.CONEXION = strConexion
            If logInsert = True Then
                If cDTL_FIRMANTE.Guardar = False Then
                    Guardar = False
                End If
            Else
                If cDTL_FIRMANTE.Actualizar = False Then
                    Guardar = False
                End If
            End If

            '' guardar datos de referencias
            cDTL_REF.DDOC_DOC_NUM = intIdCertificado
            cDTL_REF.DDOC_SIS_EMP = cHDR.HDOC_SIS_EMP
            cDTL_REF.DDOC_DOC_CAT = cHDR.HDOC_DOC_CAT
            cDTL_REF.DDOC_DOC_ANO = cHDR.HDOC_DOC_ANO
            cDTL_REF.DDOC_DOC_LIN = 2
            cDTL_REF.DDOC_PRD_PNR = "REFERENCIAS"
            cDTL_REF.DDOC_PRD_DES = strPO
            cDTL_REF.DDOC_RF1_COD = strLote
            cDTL_REF.DDOC_RF2_COD = strArancel
            cDTL_REF.DDOC_PRD_REF = strContenedor
            'Saldo de Certificado
            cDTL_REF.DDOC_PRD_FOB = dblSaldoBruto
            cDTL_REF.DDOC_PRD_CIF = dblSaldoNeto
            cDTL_REF.DDOC_RF3_DBL = dblSaldoCajas

            cDTL_REF.CONEXION = strConexion

            If logInsert = True Then
                If cDTL_REF.Guardar = False Then
                    Guardar = False
                End If
            Else
                If cDTL_REF.Actualizar = False Then
                    Guardar = False
                End If
            End If
            If Guardar = True Then
                cFunciones.EscribirRegistro("Dcmtos_HDR", clsFunciones.AccEnum.acAdd, 0, CAT_CERTIFICADO, intAño, intIdCertificado)
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Function

    Public Function Seleccionar() As Boolean 'VERIFICAR PRIMERO EL PRO_CAT DE HDR PARA VER SI ES 263 QUE USE DIFERENTE QUERY (ESTA EN EL ESCRITORIO)
        Seleccionar = False
        Dim cHDR As New clsDcmtos_HDR
        Dim cDTL As New clsDcmtos_DTL
        Dim cACC As New Tablas.TDCMTOS_ACC
        Dim strCondicion As String = STR_VACIO
        Dim strCampos As String = STR_VACIO
        Dim strSql As String = STR_VACIO
        Dim strSQL2 As String = STR_VACIO
        Dim Sqlfibra As String = STR_VACIO
        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader
        Dim intProCat As Integer

        strSql = " SELECT h.HDoc_Pro_DCat
                        FROM Dcmtos_HDR h
                        WHERE h.HDoc_Sis_Emp= {empresa} AND h.HDoc_Doc_Cat = {certificado} AND h.HDoc_Doc_Ano = {año} AND h.HDoc_Doc_Num = {id}"

        strSql = Replace(strSql, "{empresa}", Sesion.IdEmpresa)
        strSql = Replace(strSql, "{certificado}", CAT_CERTIFICADO)
        strSql = Replace(strSql, "{año}", intAño)
        strSql = Replace(strSql, "{id}", intIdCertificado)

        MyCnn.CONECTAR = strConexion
        COM = New MySqlCommand(strSql, CON)
        intProCat = COM.ExecuteScalar
        cat_doc = intProCat
        strSql = STR_VACIO
        COM.Dispose()

        If intProCat = 36 Then
            strSql = " select if(h.HDoc_Emp_Cod =c.cli_codigo ,h.HDoc_Emp_Nom ,  concat( h.HDoc_Emp_Nom )) a, ifnull(r.HDoc_Emp_Nom,'') Vendedor from Dcmtos_HDR h "
            strSql &= " left join Dcmtos_DTL_Pro  p on p.PDoc_Sis_Emp = h.HDoc_Sis_Emp and p.PDoc_Chi_Cat = h.HDoc_Pro_DCat and  p.PDoc_Chi_Ano = h.HDoc_Pro_DAno and p.PDoc_Chi_Num = h.HDoc_Pro_DNum   and p.PDoc_Chi_Lin = h.HDoc_Doc_Mon "
            strSql &= " left join Dcmtos_DTL_Pro pp on pp.PDoc_Sis_Emp = p.PDoc_Sis_Emp and pp.PDoc_Chi_Cat = p.PDoc_Par_Cat and pp.PDoc_Chi_Ano = p.PDoc_Par_Ano and pp.PDoc_Chi_Num = p.PDoc_Par_Num and pp.PDoc_Chi_Lin = p.PDoc_Par_Lin  and pp.PDoc_Par_Cat = 75 "
            strSql &= "     LEFT JOIN Dcmtos_DTL_Pro d ON d.PDoc_Sis_Emp = p.PDoc_Sis_Emp AND d.PDoc_Chi_Cat = p.PDoc_Par_Cat AND d.PDoc_Chi_Ano = p.PDoc_Par_Ano AND d.PDoc_Chi_Num = p.PDoc_Par_Num  AND d.PDoc_Chi_Lin = p.PDoc_Par_Lin AND d.PDoc_Par_Cat = 47 "
            strSql &= "         LEFT JOIN Dcmtos_HDR r ON r.HDoc_Sis_Emp = d.PDoc_Sis_Emp AND r.HDoc_Doc_Cat = d.PDoc_Par_Cat AND r.HDoc_Doc_Ano = d.PDoc_Par_Ano AND r.HDoc_Doc_Num = d.PDoc_Par_Num "
            strSql &= " left join Dcmtos_HDR hh on hh.HDoc_Sis_Emp = pp.PDoc_Sis_Emp and hh.HDoc_Doc_Cat = pp.PDoc_Par_Cat and hh.HDoc_Doc_Ano = pp.PDoc_Par_Ano and hh.HDoc_Doc_Num = pp.PDoc_Par_Num  "
            strSql &= "	left join Clientes c on c.cli_sisemp = hh.HDoc_Sis_Emp and c.cli_codigo = hh.HDoc_DR1_Emp "
            strSql &= " where h.HDoc_Sis_Emp = {empresa}  and h.HDoc_Doc_Cat = {certificado} and h.HDoc_Doc_Ano = {año} and h.HDoc_Doc_Num = {id}"

        Else
            strSql = " SELECT IF(h.HDoc_Emp_Cod =c.cli_codigo,h.HDoc_Emp_Nom, CONCAT(h.HDoc_Emp_Nom)) a, ifnull(r.HDoc_Emp_Nom,'') Vendedor
                            FROM Dcmtos_HDR h
                            LEFT JOIN Dcmtos_HDR h1 ON h1.HDoc_Sis_Emp = h.HDoc_Sis_Emp AND h1.HDoc_Doc_Cat = h.HDoc_Pro_DCat AND h1.HDoc_Doc_Ano = h.HDoc_Pro_DAno AND h1.HDoc_Doc_Num = h.HDoc_Pro_DNum
                            LEFT JOIN Dcmtos_DTL_Pro p ON p.PDoc_Sis_Emp = h1.HDoc_Sis_Emp AND p.PDoc_Chi_Cat = h1.HDoc_Pro_DCat AND p.PDoc_Chi_Ano = h1.HDoc_Pro_DAno AND p.PDoc_Chi_Num = h1.HDoc_Pro_DNum AND p.PDoc_Chi_Lin = h1.HDoc_Doc_Mon
                            LEFT JOIN Dcmtos_DTL_Pro pp ON pp.PDoc_Sis_Emp = p.PDoc_Sis_Emp AND pp.PDoc_Chi_Cat = p.PDoc_Par_Cat AND pp.PDoc_Chi_Ano = p.PDoc_Par_Ano AND pp.PDoc_Chi_Num = p.PDoc_Par_Num AND pp.PDoc_Chi_Lin = p.PDoc_Par_Lin AND pp.PDoc_Par_Cat = 75
                            LEFT JOIN Dcmtos_DTL_Pro d ON d.PDoc_Sis_Emp = p.PDoc_Sis_Emp AND d.PDoc_Chi_Cat = p.PDoc_Par_Cat AND d.PDoc_Chi_Ano = p.PDoc_Par_Ano AND d.PDoc_Chi_Num = p.PDoc_Par_Num AND d.PDoc_Chi_Lin = p.PDoc_Par_Lin AND d.PDoc_Par_Cat = 47
                            LEFT JOIN Dcmtos_HDR r ON r.HDoc_Sis_Emp = d.PDoc_Sis_Emp AND r.HDoc_Doc_Cat = d.PDoc_Par_Cat AND r.HDoc_Doc_Ano = d.PDoc_Par_Ano AND r.HDoc_Doc_Num = d.PDoc_Par_Num
                            LEFT JOIN Dcmtos_HDR hh ON hh.HDoc_Sis_Emp = pp.PDoc_Sis_Emp AND hh.HDoc_Doc_Cat = pp.PDoc_Par_Cat AND hh.HDoc_Doc_Ano = pp.PDoc_Par_Ano AND hh.HDoc_Doc_Num = pp.PDoc_Par_Num
                            LEFT JOIN Clientes c ON c.cli_sisemp = hh.HDoc_Sis_Emp AND c.cli_codigo = hh.HDoc_DR1_Emp
                                WHERE h.HDoc_Sis_Emp = {empresa} AND h.HDoc_Doc_Cat = {certificado} AND h.HDoc_Doc_Ano = {año} AND h.HDoc_Doc_Num = {id} "
        End If

        strSql = Replace(strSql, "{empresa}", Sesion.IdEmpresa)
        strSql = Replace(strSql, "{certificado}", CAT_CERTIFICADO)
        strSql = Replace(strSql, "{año}", intAño)
        strSql = Replace(strSql, "{id}", intIdCertificado)

        MyCnn.CONECTAR = strConexion

        COM = New MySqlCommand(strSql, CON)
        REA = COM.ExecuteReader
        If REA.HasRows Then
            Do While REA.Read
                strCliente = REA.GetString("a")
                strVendedor = REA.GetString("Vendedor")
            Loop
        End If
        COM = Nothing
        REA.Close()
        REA = Nothing
        'seleccionar encabezado
        If intProCat = 36 Then
            strSQL2 = " SELECT h.HDoc_Emp_Tel,h.HDoc_Emp_NIT serie, h.HDoc_DR1_Cat idSerie, h.HDoc_DR1_Dbl correlativo, h.HDoc_Emp_Per, h.HDoc_Sis_Emp,h.HDoc_Doc_Ano,h.HDoc_Doc_Num,h.HDoc_Doc_Fec,h.HDoc_Emp_Cod,h.HDoc_Emp_Nom," &
            "h.HDoc_Emp_Dir, h.HDoc_DR1_Num, h.HDoc_DR2_Cat, h.HDoc_DR2_Num, h.HDoc_DR2_Emp, h.HDoc_RF1_Num, h.HDoc_RF1_Cod, h.HDoc_RF3_Dbl, " &
            " h.HDoc_RF1_Txt,h.HDoc_RF2_Num, h.HDoc_RF2_Cod,h.HDoc_RF2_Txt,h.HDoc_Pro_DNum,h.HDoc_Pro_DAno,h.HDoc_Doc_Mon," &
            "   h.HDoc_RF1_Dbl, h.HDoc_RF2_Dbl, h.HDoc_Pro_Fec, h.HDoc_Doc_Status ,  IFNULL(CONCAT (IFNULL(hh.HDoc_DR2_Num,''),'-', LPAD(hh.HDoc_DR1_Dbl,8,'0')),'') FactHN, IFNULL(f.NumeroAutorizacion,'') NumeroAutorizacion,p.pro_telefono Telefono, h.HDoc_RF3_Dbl, c.cli_direccion, "
            strSQL2 &= " 	GROUP_CONCAT(DISTINCT IF(i.inv_prodlote='',TRIM(d.DDoc_Prd_PNR), CONCAT('',TRIM(i.inv_prodlote))) ORDER BY IF(i.inv_prodlote='',d.DDoc_Prd_PNR, CONCAT('',i.inv_prodlote)) SEPARATOR ' / ') AS marcas "
            strSQL2 &= "        FROM Dcmtos_HDR h "
            strSQL2 &= "            LEFT JOIN Dcmtos_HDR hh ON hh.HDoc_Sis_Emp = h.HDoc_Sis_Emp AND hh.HDoc_Doc_Cat = h.HDoc_Pro_DCat AND hh.HDoc_Doc_Ano = h.HDoc_Pro_DAno AND hh.HDoc_Doc_Num = h.HDoc_Pro_DNum  "
            strSQL2 &= "                LEFT JOIN Fel f ON f.Empresa = hh.HDoc_Sis_Emp AND f.Catalogo = hh.HDoc_Doc_Cat AND f.Anio = hh.HDoc_Doc_Ano AND f.Numero = hh.HDoc_Doc_Num  "
            strSQL2 &= "            LEFT JOIN Proveedores p ON p.pro_sisemp = h.HDoc_Sis_Emp AND p.pro_codigo = h.HDoc_RF1_Num LEFT JOIN Clientes c ON c.cli_sisemp=h.HDoc_Sis_Emp AND c.cli_codigo=h.HDoc_Emp_Cod"
            strSQL2 &= " LEFT JOIN Dcmtos_DTL d ON d.DDoc_Sis_Emp = hh.HDoc_Sis_Emp AND d.DDoc_Doc_Cat = hh.HDoc_Doc_Cat
            AND d.DDoc_Doc_Ano = hh.HDoc_Doc_Ano AND d.DDoc_Doc_Num = hh.HDoc_Doc_Num
            INNER JOIN Inventarios i ON i.inv_sisemp = d.DDoc_Sis_Emp AND i.inv_numero = d.DDoc_Prd_Cod "
            strSQL2 &= " WHERE h.HDoc_Sis_Emp= {empresa} AND h.HDoc_Doc_Cat= {certificado} AND h.HDoc_Doc_Ano = {año}" &
                " AND h.HDoc_Doc_Num ={id}"

        Else
            strSQL2 = " SELECT h.HDoc_Emp_Tel,h.HDoc_Emp_NIT serie, h.HDoc_DR1_Cat idSerie, h.HDoc_DR1_Dbl correlativo, h.HDoc_Emp_Per, h.HDoc_Sis_Emp,h.HDoc_Doc_Ano,h.HDoc_Doc_Num,h.HDoc_Doc_Fec,h.HDoc_Emp_Cod,h.HDoc_Emp_Nom," &
            "h.HDoc_Emp_Dir, h.HDoc_DR1_Num, h.HDoc_DR2_Cat, h.HDoc_DR2_Num, h.HDoc_DR2_Emp, h.HDoc_RF1_Num, h.HDoc_RF1_Cod, h.HDoc_RF3_Dbl, " &
            " h.HDoc_RF1_Txt,h.HDoc_RF2_Num, h.HDoc_RF2_Cod,h.HDoc_RF2_Txt,h.HDoc_Pro_DNum,h.HDoc_Pro_DAno,h.HDoc_Doc_Mon," &
            "   h.HDoc_RF1_Dbl, h.HDoc_RF2_Dbl, h.HDoc_Pro_Fec, h.HDoc_Doc_Status ,  IFNULL(CONCAT (IFNULL(d.HDoc_DR2_Num,''),'-', LPAD(d.HDoc_DR1_Dbl,8,'0')),'') FactHN, IFNULL(f.NumeroAutorizacion,'') NumeroAutorizacion,p.pro_telefono Telefono, h.HDoc_RF3_Dbl"
            strSQL2 &= "        FROM Dcmtos_HDR h "
            strSQL2 &= "            LEFT JOIN Dcmtos_HDR hh ON hh.HDoc_Sis_Emp = h.HDoc_Sis_Emp AND hh.HDoc_Doc_Cat = h.HDoc_Pro_DCat AND hh.HDoc_Doc_Ano = h.HDoc_Pro_DAno AND hh.HDoc_Doc_Num = h.HDoc_Pro_DNum  "
            strSQL2 &= "            LEFT JOIN Dcmtos_HDR d ON d.HDoc_Sis_Emp = hh.HDoc_Sis_Emp AND d.HDoc_Doc_Cat = hh.HDoc_Pro_DCat AND d.HDoc_Doc_Ano = hh.HDoc_Pro_DAno AND d.HDoc_Doc_Num = hh.HDoc_Pro_DNum"
            strSQL2 &= "            LEFT JOIN Fel f ON f.Empresa = d.HDoc_Sis_Emp AND f.Catalogo = d.HDoc_Doc_Cat AND f.Anio = d.HDoc_Doc_Ano AND f.Numero = d.HDoc_Doc_Num  "
            strSQL2 &= "            LEFT JOIN Proveedores p ON p.pro_sisemp = h.HDoc_Sis_Emp AND p.pro_codigo = h.HDoc_RF1_Num"
            strSQL2 &= " WHERE h.HDoc_Sis_Emp= {empresa} AND h.HDoc_Doc_Cat= {certificado} AND h.HDoc_Doc_Ano = {año}" &
                " AND h.HDoc_Doc_Num ={id}"

        End If



        strSQL2 = Replace(strSQL2, "{empresa}", Sesion.IdEmpresa)
        strSQL2 = Replace(strSQL2, "{certificado}", CAT_CERTIFICADO)
        strSQL2 = Replace(strSQL2, "{año}", intAño)
        strSQL2 = Replace(strSQL2, "{id}", intIdCertificado)

        Try
            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSQL2, CON)
            REA = COM.ExecuteReader
            If REA.HasRows Then
                Do While REA.Read
                    If intProCat = 36 Then
                        IdFactura = REA.GetInt32("HDoc_Pro_DNum")

                        If Sesion.IdEmpresa = 11 Or Sesion.IdEmpresa = 16 Or Sesion.IdEmpresa = 14 Or Sesion.idGiro = 2 Then
                            intInvoice = REA.GetInt32("HDoc_RF3_Dbl")
                            ' strReferencia = REA.GetString("HDoc_RF3_Dbl")
                        Else
                            intInvoice = REA.GetInt32("HDoc_Pro_DNum")
                            ' strReferencia = REA.GetString("HDoc_DR1_Num")
                        End If

                    Else
                        IdFactura = REA.GetInt32("HDoc_Pro_DNum")
                        intInvoice = REA.GetInt32("HDoc_RF3_Dbl")
                        'strReferencia = REA.GetString("HDoc_DR1_Num")

                    End If
                    strFechaFactura = REA.GetDateTime("HDoc_Pro_Fec").ToString(FORMATO_MYSQL)
                    FechaFactura_Net = REA.GetDateTime("HDoc_Pro_Fec")
                    intEmpresa = REA.GetInt32("HDoc_Sis_Emp")
                    intAño = REA.GetInt32("HDoc_Doc_Ano")
                    intIdCertificado = REA.GetInt32("HDoc_Doc_Num")
                    ffechanet = REA.GetDateTime("HDoc_Doc_Fec")
                    intIdClinte = REA.GetInt32("HDoc_Emp_Cod")
                    strClienteDireccion = REA.GetString("cli_direccion")
                    strUMedida = REA.GetString("HDoc_Emp_Dir")
                    strReferencia = REA.GetString("HDoc_DR1_Num")
                    IdProducto = REA.GetInt32("HDoc_DR2_Cat")
                    strProducto = REA.GetString("HDoc_DR2_Num")
                    intCajas = REA.GetInt32("HDoc_DR2_Emp")
                    strDestino = REA.GetString("HDoc_Emp_Per")
                    IdProveedor = REA.GetInt32("HDoc_RF1_Num")
                    strProveedor = REA.GetString("HDoc_RF1_Cod")
                    strProveedorDic = REA.GetString("HDoc_RF1_Txt")
                    IdOrigen = REA.GetInt32("HDoc_RF2_Num")
                    strOrigen = REA.GetString("HDoc_RF2_Cod")
                    strTransporte = REA.GetString("HDoc_RF2_Txt")

                    AñoFactrua = REA.GetInt32("HDoc_Pro_DAno")
                    intLinea = REA.GetInt32("HDoc_Doc_Mon")
                    dblPesoNeto = REA.GetDouble("HDoc_RF1_Dbl")
                    dblPesoBruto = REA.GetDouble("HDoc_RF2_Dbl")
                    intEstado = REA.GetInt32("HDoc_Doc_Status")
                    strFacHN = REA.GetString("FactHN")
                    strFactFel = REA.GetString("NumeroAutorizacion")
                    strTelefono = REA.GetString("Telefono")
                    strHBI = REA.GetString("HDoc_Emp_Tel")
                    'Serie
                    idSerieCert = REA.GetInt32("idSerie")
                    SerieCert = REA.GetString("serie")
                    intCorrelativoCert = REA.GetInt32("correlativo")
                    marcasCadena = REA.GetString("marcas")

                Loop
            End If
            REA.Close()
            REA = Nothing
            COM = Nothing
            strSQL2 = STR_VACIO













            '   If cHDR.Seleccionar(strCondicion, strCampos) = True Then
            'fechaFactura = cHDR.HDOC_PRO_FEC
            'intEmpresa = cHDR.HDOC_SIS_EMP
            'intAño = cHDR.HDOC_DOC_ANO
            'intIdCertificado = cHDR.HDOC_DOC_NUM
            'ffecha = cHDR.HDOC_DOC_FEC
            'intIdClinte = cHDR.HDOC_EMP_COD
            '' strCliente = cHDR.HDOC_EMP_NOM
            'strUMedida = cHDR.HDOC_EMP_DIR
            'strReferencia = cHDR.HDOC_DR1_NUM
            'IdProducto = cHDR.HDOC_DR2_CAT
            'strProducto = cHDR.HDOC_DR2_NUM
            'intCajas = cHDR.HDOC_DR2_EMP
            'IdProveedor = cHDR.HDOC_RF1_NUM
            'strProveedor = cHDR.HDOC_RF1_COD
            'strProveedorDic = cHDR.HDOC_RF1_TXT
            'IdOrigen = cHDR.HDOC_RF2_NUM
            'strOrigen = cHDR.HDOC_RF2_COD
            'strTransporte = cHDR.HDOC_RF2_TXT
            'IdFactura = cHDR.HDOC_PRO_DNUM
            'AñoFactrua = cHDR.HDOC_PRO_DANO
            'intLinea = cHDR.HDOC_DOC_MON
            'dblPesoNeto = cHDR.HDOC_RF1_DBL
            'dblPesoBruto = cHDR.HDOC_RF2_DBL
            'intEstado = cHDR.HDOC_DOC_STATUS

            '' seleccionar datos del firmante
            strSQL2 = " SELECT DDoc_Prd_Um,DDoc_Prd_Des,IFNULL(DDoc_RF1_Num,0) DDoc_RF1_Num,DDoc_RF1_Cod, DDoc_RF2_Cod"
            strSQL2 &= "    FROM Dcmtos_DTL "
            strSQL2 &= " WHERE DDoc_Sis_Emp={empresa} AND DDoc_Doc_Ano= {año} AND DDoc_Doc_Num= {id} " &
                " AND DDoc_Doc_Cat = {certificado} AND DDoc_Doc_Lin = " & INT_UNO
            strSQL2 = Replace(strSQL2, "{empresa}", Sesion.IdEmpresa)
            strSQL2 = Replace(strSQL2, "{certificado}", CAT_CERTIFICADO)
            strSQL2 = Replace(strSQL2, "{año}", intAño)
            strSQL2 = Replace(strSQL2, "{id}", intIdCertificado)
            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSQL2, CON)
            REA = COM.ExecuteReader
            If REA.HasRows Then
                Do While REA.Read
                    intIdFirmante = REA.GetInt32("DDoc_Prd_Um")
                    strFirmante = REA.GetString("DDoc_Prd_Des")
                    intIdPuesto = REA.GetInt32("DDoc_RF1_Num")
                    strPuesto = REA.GetString("DDoc_RF1_Cod")
                    strCorreo = REA.GetString("DDoc_RF2_Cod")
                Loop
            End If


            'If cDTL.Seleccionar(strCondicion, strCampos) = True Then
            '    intIdFirmante = cDTL.DDOC_PRD_UM
            '    strFirmante = cDTL.DDOC_PRD_DES
            '    intIdPuesto = cDTL.DDOC_RF1_NUM
            '    strPuesto = cDTL.DDOC_RF1_COD
            '    strCorreo = cDTL.DDOC_RF2_COD
            'End If
            'cDTL.Dispose()
            'cDTL = Nothing
            'cDTL = New clsDcmtos_DTL
            'seleccionar datos de Referencia
            cDTL.CONEXION = strConexion
            strCampos = "DDoc_Prd_Des,DDoc_RF1_Cod,DDoc_RF2_Cod,DDoc_Prd_Ref, DDoc_Prd_Fob, DDoc_Prd_Cif, DDoc_RF3_Dbl"
            strCondicion = "DDoc_Sis_Emp={empresa} AND DDoc_Doc_Ano= {año} AND DDoc_Doc_Num ={id} " &
                " AND DDoc_Doc_Cat = {certificado} AND DDoc_Doc_Lin = " & 2
            strCondicion = Replace(strCondicion, "{empresa}", Sesion.IdEmpresa)
            strCondicion = Replace(strCondicion, "{certificado}", CAT_CERTIFICADO)
            strCondicion = Replace(strCondicion, "{año}", intAño)
            strCondicion = Replace(strCondicion, "{id}", intIdCertificado)

            If cDTL.Seleccionar(strCondicion, strCampos) = True Then
                strPO = cDTL.DDOC_PRD_DES
                strLote = cDTL.DDOC_RF1_COD
                strArancel = cDTL.DDOC_RF2_COD
                strContenedor = cDTL.DDOC_PRD_REF
                dblSaldoBruto = cDTL.DDOC_PRD_FOB
                dblSaldoNeto = cDTL.DDOC_PRD_CIF
                dblSaldoCajas = cDTL.DDOC_RF3_DBL
            Else
                MsgBox(cDTL.MERROR.ToString)
            End If
            Seleccionar = True
            '  End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Function

    Public Function Borrar() As Boolean
        Borrar = False
        Dim cHDR As New clsDcmtos_HDR
        Dim cDTL As New clsDcmtos_DTL
        Dim Tacc As New Tablas.TDCMTOS_ACC
        Dim strCondicion As String = STR_VACIO
        strCondicion = "DDoc_Sis_Emp={empresa} AND DDoc_Doc_Ano= {año} AND DDoc_Doc_Num ={id} " & _
                    " AND DDoc_Doc_Cat = {certificado}"
        strCondicion = Replace(strCondicion, "{empresa}", Sesion.IdEmpresa)
        strCondicion = Replace(strCondicion, "{certificado}", CAT_CERTIFICADO)
        strCondicion = Replace(strCondicion, "{año}", intAño)
        strCondicion = Replace(strCondicion, "{id}", intIdCertificado)
        Try
            cDTL.CONEXION = strConexion
            If cDTL.Borrar(strCondicion) = True Then
                strCondicion = "HDoc_Sis_Emp= {empresa} AND HDoc_Doc_Cat ={certificado} AND " &
                 " HDoc_Doc_Ano = {año} AND HDoc_Doc_Num = {id}"
                strCondicion = Replace(strCondicion, "{empresa}", Sesion.IdEmpresa)
                strCondicion = Replace(strCondicion, "{certificado}", CAT_CERTIFICADO)
                strCondicion = Replace(strCondicion, "{año}", intAño)
                strCondicion = Replace(strCondicion, "{id}", intIdCertificado)
                cHDR.CONEXION = strConexion
                If cHDR.Borrar(strCondicion) = True Then
                    strCondicion = "ADoc_Sis_Emp= {empresa} AND ADoc_Doc_Cat ={certificado} AND " &
                    " ADoc_Doc_Ano = {año} AND ADoc_Doc_Num = {id}"
                    strCondicion = Replace(strCondicion, "{empresa}", Sesion.IdEmpresa)
                    strCondicion = Replace(strCondicion, "{certificado}", CAT_CERTIFICADO)
                    strCondicion = Replace(strCondicion, "{año}", intAño)
                    strCondicion = Replace(strCondicion, "{id}", intIdCertificado)
                    Tacc.CONEXION = strConexion
                    If Tacc.PDELETE(strCondicion) = True Then
                        Borrar = True
                    End If
                End If
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Function

#End Region

End Class