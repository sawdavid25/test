﻿Public Class clsDepurar

    'Public Sub CambiaraCajaChicha()
    '    Dim strSQL As String = STR_VACIO
    '    Dim CoNE As MySqlConnection
    '    Dim COM As MySqlCommand
    '    Dim REA As MySqlDataReader
    '    Dim DP As New Tablas.clsDETALLE_POLIZAS
    '    Dim strCondicion As String = STR_VACIO
    '    strSQL = "select b.BCta_Cuenta cuenta,dp.transaccion id, dp.empresa sis, dp.ejercicio eje, dp.poliza po" &
    '        "   from Dcmtos_HDR l " &
    '        "       left join Dcmtos_DTL d on d.DDoc_Sis_Emp = l.HDoc_Sis_Emp and d.DDoc_Doc_Cat = " &
    '        "           l.HDoc_Doc_Cat and d.DDoc_Doc_Ano = l.HDoc_Doc_Ano and d.DDoc_Doc_Num = l.HDoc_Doc_Num" &
    '        "       left join Dcmtos_HDR f on d.DDoc_Prd_Cod = f.HDoc_Doc_Cat and d.DDoc_Sis_Emp =" &
    '        "           f.HDoc_Sis_Emp and f.HDoc_Doc_Num = d.DDoc_Prd_UM and f.HDoc_Doc_Ano =d.DDoc_RF1_Num " &
    '        "       left join conta.detalle_polizas dp on dp.ref_tipo = f.HDoc_Doc_Cat and " &
    '        "           dp.empresa = f.HDoc_Sis_Emp and dp.ref_ciclo = f.HDoc_Doc_Ano and dp.ref_numero = f.HDoc_Doc_Num" &
    '        "       left join CtasBcos b on l.HDoc_DR1_Cat = b.BCta_Num and l.HDoc_Sis_Emp = b.BCta_Sis_Emp" &
    '        "   where l.HDoc_Sis_Emp =3 and l.HDoc_Doc_Cat = 246 and l.HDoc_Doc_Fec between '2014-01-01' and '2014-12-31'" &
    '        "       and d.DDoc_Prd_Cod = 44 and dp.poliza is not null and dp.operacion = 'A'" &
    '        ""

    '    CoNE = New MySqlConnection
    '    CoNE.ConnectionString = strConexion
    '    CoNE.Open()
    '    Try
    '        COM = New MySqlCommand(strSQL, CoNE)
    '        REA = COM.ExecuteReader
    '        Do While REA.Read = True
    '            DP.CONEXION = strConexion

    '            strCondicion = " transaccion = {tran} and empresa = {empresa} and ejercicio = {eje}"
    '            strCondicion = Replace(strCondicion, "{tran}", REA.GetUInt32("id"))
    '            strCondicion = Replace(strCondicion, "{empresa}", REA.GetUInt32("sis"))
    '            strCondicion = Replace(strCondicion, "{eje}", REA.GetUInt32("eje"))

    '            If DP.PSELECT_CONDICION(strCondicion) = True Then
    '                DP.CUENTA = REA.GetString("cuenta")
    '                If DP.PUPDATE = False Then
    '                    MsgBox("no se pudeo actualizar la poliza: " & REA.GetString("po"))
    '                End If
    '            End If
    '        Loop
    '    Catch ex As Exception
    '        MsgBox(ex.ToString)
    '    Finally
    '        CoNE.Dispose()
    '        CoNE.Close()
    '        REA = Nothing

    '    End Try
    '    MsgBox("Listo")
    'End Sub

    Public Sub Test()
        MsgBox("si funcino el git, by Sergio")
    End Sub

End Class
