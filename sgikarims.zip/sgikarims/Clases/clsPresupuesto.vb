﻿Public Class clsPresupuesto

    Dim FechaI As MySqlDateTime
    Dim FechaF As MySqlDateTime
    Dim FechaT As MySqlDateTime
    Dim fecha As Date


    Public Property FechaTasa As Date
        Get
            Return FechaT
        End Get
        Set(value As Date)
            FechaT = New MySqlDateTime(value.Year, value.Month, value.Day, value.Hour, value.Minute, value.Second)
        End Set
    End Property


    Public Property FechaInicio As Date
        Get
            Return FechaI
        End Get
        Set(value As Date)
            FechaI = New MySqlDateTime(value.Year, value.Month, value.Day, value.Hour, value.Minute, value.Second)
        End Set
    End Property

    Public Property FechaFin As Date
        Get
            Return FechaF
        End Get
        Set(value As Date)
            FechaF = New MySqlDateTime(value.Year, value.Month, value.Day, value.Hour, value.Minute, value.Second)
        End Set
    End Property

    Public Property Mysql As MySqlDateTime
        Get

        End Get
        Set(value As MySqlDateTime)
            fecha = New Date(value.Day, value.Month, value.Year)
        End Set
    End Property
   


End Class
