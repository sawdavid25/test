﻿Public Class clsPymes
    Dim a As System.IFormattable

    Private Function EspacioHtml(ByVal numero As Integer) As String

        Dim strespacios As String = STR_VACIO
        For i As Integer = 0 To numero
            strespacios = strespacios & "&nbsp;"
        Next
        Return strespacios
    End Function


#Region "Balance Pyme"

    Private Function PrimeraLineaHtml(ByVal intNivel As Integer, ByVal strCuenta0 As String, strCuenta1 As String, ByVal strCuenta2 As String, ByVal strCuenta3 As String, ByVal dblSaldo As Double, ByVal logPrimera As Boolean, Optional lin As Integer = 0) As String
        Dim strHtml As String = STR_VACIO
        Try
            Select Case intNivel
                Case 0
                    If logPrimera = True Then
                        strHtml &= "<tr>"
                        strHtml &= "<td class='titulo'>" & strCuenta0 & "</td>"
                        strHtml &= "<td class='derecha'>" & dblSaldo.ToString(FORMATO_MONEDA) & "</td>"
                        strHtml &= "</tr>"
                    End If

                Case 1
                    If logPrimera = True Then
                        strHtml &= "<tr>"
                        strHtml &= "<td class='titulo'>" & strCuenta0 & "</td>"
                        strHtml &= "</tr>"
                    End If
                    strHtml &= "<tr>"
                    strHtml &= "<td class='encabezado'>" & EspacioHtml(5) & strCuenta1 & "</td>"
                    strHtml &= "<td class='derecha'>" & dblSaldo.ToString(FORMATO_MONEDA) & "</td>"
                    strHtml &= "</tr>"

                Case 2
                    If logPrimera = True Then
                        If lin = 0 Then
                            strHtml &= "<tr>"
                            strHtml &= "<td class='titulo'>" & strCuenta0 & "</td>"
                            strHtml &= "</tr>"

                            strHtml &= "<tr>"
                            strHtml &= "<td class='encabezado'>" & EspacioHtml(5) & strCuenta1 & "</td>"
                            strHtml &= "</tr>"
                        Else
                            strHtml &= "<tr>"
                            strHtml &= "<td class='encabezado'>" & EspacioHtml(5) & strCuenta1 & "</td>"
                            strHtml &= "</tr>"
                        End If
                    End If


                    strHtml &= "<tr>"
                    strHtml &= "<td class='centro'> " & EspacioHtml(10) & strCuenta2.ToString & "</td>"
                    strHtml &= "<td class='derecha'>" & dblSaldo.ToString(FORMATO_MONEDA) & "</td>"
                    strHtml &= "</tr>"
                Case 3
                    If logPrimera = True Then
                        If lin = 0 Then
                            strHtml &= "<tr>"
                            strHtml &= "<td class='titulo'>" & strCuenta0 & "</td>"
                            strHtml &= "</tr>"

                            strHtml &= "<tr>"
                            strHtml &= "<td class='encabezado'>" & EspacioHtml(5) & strCuenta1 & "</td>"
                            strHtml &= "</tr>"
                        Else
                            strHtml &= "<tr>"
                            strHtml &= "<td class='encabezado'>" & EspacioHtml(5) & strCuenta1 & "</td>"
                            strHtml &= "</tr>"
                        End If
                    End If

                    strHtml &= "<tr>"
                    strHtml &= "<td class='centro'> " & EspacioHtml(10) & strCuenta2.ToString & "</td>"
                    strHtml &= "</tr>"

                    strHtml &= "<tr>"
                    strHtml &= "<td class='centro'> " & EspacioHtml(15) & strCuenta3.ToString & "</td>"
                    strHtml &= "<td class='derecha'>" & dblSaldo.ToString(FORMATO_MONEDA) & "</td>"
                    strHtml &= "</tr>"

            End Select
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        Return strHtml
    End Function

    Private Function Subtotal(ByVal intNivel As Integer, ByVal strCuenta As String, ByVal dblsub As Double)
        Dim strHtml As String = STR_VACIO
        Try
            Select Case intNivel
                Case 0
                    strHtml &= "<tr>"
                    strHtml &= "<td class='titulo'>  TOTAL " & strCuenta & "</td>"
                    strHtml &= "<td class='titulo'> </td>"
                    strHtml &= "<td class='titulo'>" & dblsub.ToString(FORMATO_MONEDA) & "</td>"
                    strHtml &= "</tr>"
                Case 1
                    strHtml &= "<tr>"
                    strHtml &= "<td class='encabezado'> " & EspacioHtml(5) & " TOTAL " & strCuenta & "</td>"
                    strHtml &= "<td class='titulo'> </td>"
                    strHtml &= "<td class='encabezado'>" & dblsub.ToString(FORMATO_MONEDA) & "</td>"
                    strHtml &= "</tr>"
                Case 2
                    strHtml &= "<tr>"
                    strHtml &= "<td class='encabezado'> " & EspacioHtml(10) & " TOTAL " & strCuenta & "</td>"
                    strHtml &= "<td class='titulo'> </td>"
                    strHtml &= "<td class='encabezado'>" & dblsub.ToString(FORMATO_MONEDA) & "</td>"
                    strHtml &= "</tr>"
                Case 3
                    strHtml &= "<tr>"
                    strHtml &= "<td class='encabezado'> " & EspacioHtml(15) & " TOTAL " & strCuenta & "</td>"
                    strHtml &= "<td class='titulo'> </td>"
                    strHtml &= "<td class='encabezado'>" & dblsub.ToString(FORMATO_MONEDA) & "</td>"
                    strHtml &= "</tr>"
                Case 4
                    strHtml &= "<tr>"
                    strHtml &= "<td class='encabezado'> " & EspacioHtml(20) & " TOTAL " & strCuenta & "</td>"
                    strHtml &= "<td class='titulo'> </td>"
                    strHtml &= "<td class='encabezado'>" & dblsub.ToString(FORMATO_MONEDA) & "</td>"
                    strHtml &= "</tr>"
            End Select

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        Return strHtml
    End Function

    Private Function Linea(ByVal intNivel As Integer, ByVal strCuenta As String, ByVal dblsaldo As Double) As String
        Dim strHtml As String = STR_VACIO
        Try
            Select Case intNivel
                Case 0
                    strHtml &= "<tr>"
                    strHtml &= "<td class='centro'>" & strCuenta.ToString & "</td>"
                    strHtml &= "<td class='derecha'>" & dblsaldo.ToString(FORMATO_MONEDA) & "</td>"
                    strHtml &= "</tr>"
                Case 1
                    strHtml &= "<tr>"
                    strHtml &= "<td class='centro'>" & EspacioHtml(5) & strCuenta.ToString & "</td>"
                    strHtml &= "<td class='derecha'>" & dblsaldo.ToString(FORMATO_MONEDA) & "</td>"
                    strHtml &= "</tr>"
                Case 2
                    strHtml &= "<tr>"
                    strHtml &= "<td class='centro'>" & EspacioHtml(10) & strCuenta.ToString & "</td>"
                    strHtml &= "<td class='derecha'>" & dblsaldo.ToString(FORMATO_MONEDA) & "</td>"
                    strHtml &= "</tr>"
                Case 3
                    strHtml &= "<tr>"
                    strHtml &= "<td class='centro'>" & EspacioHtml(15) & strCuenta.ToString & "</td>"
                    strHtml &= "<td class='derecha'>" & dblsaldo.ToString(FORMATO_MONEDA) & "</td>"
                    strHtml &= "</tr>"
                Case 4
                    strHtml &= "<tr>"
                    strHtml &= "<td class='centro'>" & EspacioHtml(20) & strCuenta.ToString & "</td>"
                    strHtml &= "<td class='derecha'>" & dblsaldo.ToString(FORMATO_MONEDA) & "</td>"
                    strHtml &= "</tr>"
            End Select


        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        Return strHtml
    End Function

    Private Function SqlBalance(ByVal Finicio As Date, ByVal Ffinal As Date, ByVal intOpcion As Integer) As String
        Dim strSql As String = STR_VACIO
        Try
            strSql = " select  c.cuenta0, c.nivel0, c.nivel1,c.cuenta1, c.nivel2,c.cuenta2,c.nivel3 , c.cuenta3 , c.nivel4 , c.cuentan4,  "
            strSql &= "  sum((select  ifnull(sum(if(d.operacion = 'C', ifnull(d.importe,0) , (ifnull(d.importe,0) *-1))),0) from {conta}.polizas p "
            strSql &= "         left join {conta}.detalle_polizas d on d.empresa = p.empresa and d.ejercicio = p.ejercicio and d.poliza = p.poliza  "
            strSql &= "         LEFT JOIN {conta}.tipo_poliza t ON t.tipo_poliza = p.tipo "
            strSql &= "       where p.empresa = {empresa} and p.fecha between '{inicio}' and '{fin}'  and d.cuenta = c.cuentan4 AND NOT t.tipo_poliza IN(4,5) ))saldo   "
            strSql &= " from {conta}.cuenta_nivel c  "
            strSql &= " where c.cuenta0 in('1','2','3') "
            Select Case intOpcion
                Case 0
                    strSql &= "  group by c.cuenta0 "
                Case 1
                    strSql &= "  group by c.cuenta1 "
                Case 2
                    strSql &= "  group by c.cuenta2 "
                Case 3
                    strSql &= "  group by c.cuenta3 "
                Case 4
                    strSql &= "  group by c.cuenta4 "

            End Select



            strSql = Replace(strSql, "{conta}", Sesion.BaseConta)
            strSql = Replace(strSql, "{empresa}", Sesion.IdEmpresa)
            strSql = Replace(strSql, "{inicio}", Finicio.ToString(FORMATO_MYSQL))
            strSql = Replace(strSql, "{fin}", Ffinal.ToString(FORMATO_MYSQL))

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        Return strSql
    End Function

    Private Function SqlEncabezadoBalance() As String
        Dim strSQL As String = STR_VACIO
        Try
            strSQL = "  select e.emp_razon empresa, c.cat_dato moneda , p.cat_dato nacionalidad  from Empresas e "
            strSQL &= " 	LEFT JOIN Catalogos c on c.cat_num = e.emp_moneda "
            strSQL &= "  	left join Catalogos p on p.cat_num = e.emp_pais  "
            strSQL &= " where e.emp_no=  " & Sesion.IdEmpresa

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        Return strSQL
    End Function

    Private Function ResultadoEjerccio(ByVal Finicio As Date, ByVal Ffin As Date) As Double
        Dim strSql As String = STR_VACIO
        Dim dblResultado As Double = INT_CERO
        Dim COM As MySqlCommand
        Dim CON2 As MySqlConnection
        Try
            strSql = " select  "
            strSql &= "     sum((select  ifnull(sum(if(d.operacion = 'C', (ifnull(d.importe,0)) , (ifnull(d.importe,0))*-1)),0) "
            strSql &= "             from {conta}.polizas p   "
            strSql &= "                 left join {conta}.detalle_polizas d on d.empresa = p.empresa and d.ejercicio = p.ejercicio and d.poliza = p.poliza  "
            strSql &= "         LEFT JOIN {conta}.tipo_poliza t ON t.tipo_poliza = p.tipo "
            strSql &= "             where p.empresa = {empresa} and p.fecha between '{inicio}' and '{fin}'  and d.cuenta = c.cuentan4 AND NOT t.tipo_poliza IN(4,5)))saldo "
            strSql &= " from {conta}.cuenta_nivel c  "
            strSql &= " where c.cuenta0 in('4','5','6',7,8)"

            strSql = Replace(strSql, "{conta}", Sesion.BaseConta)
            strSql = Replace(strSql, "{empresa}", Sesion.IdEmpresa)
            strSql = Replace(strSql, "{inicio}", Finicio.ToString(FORMATO_MYSQL))
            strSql = Replace(strSql, "{fin}", Ffin.ToString(FORMATO_MYSQL))

            CON2 = New MySqlConnection(strConexion)
            CON2.Open()
            COM = New MySqlCommand(strSql, CON2)
            dblResultado = CDbl(COM.ExecuteScalar)
            dblResultado = dblResultado
            CON2.Clone()
            CON2.Dispose()
            CON2 = Nothing
            System.GC.Collect()

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        Return dblResultado
    End Function

    Public Sub BlancePyme()
        Dim crport As New clsReportes
        Dim strsql As String = STR_VACIO
        Dim strHtml As String = STR_VACIO
        Dim frm As New frmFiltro
        Dim frmO As New frmOption
        Dim logPrimeraLinea As Boolean = True
        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader
        Dim REA2 As MySqlDataReader
        Dim strTemp As String = STR_VACIO

        Dim dblTotalNivel0 As Double = INT_CERO
        Dim dblTotalNivel1 As Double = INT_CERO
        Dim dblTotalNivel2 As Double = INT_CERO
        Dim dblTotalNivel3 As Double = INT_CERO
        Dim dblTotalNivel4 As Double = INT_CERO
        Dim dblEjercicioActual As Double = INT_CERO

        Dim strNivel0 As String = STR_VACIO
        Dim strNivel1 As String = STR_VACIO
        Dim strNivel2 As String = STR_VACIO
        Dim strNivel3 As String = STR_VACIO
        Dim strNivel4 As String = STR_VACIO
        Dim intConteo As Integer = 0

        Dim str2Niveles As String = STR_VACIO
        Dim dbl2Totales As Double = 0
        Dim f As Byte
        Try
            frm.BanderaFechas = True
            frm.Titulo = "Balance"
            frm.Text = "Select a range date"

            frm.ShowDialog(frmSPrincipal)
            If frm.DialogResult = DialogResult.OK Then

                frmO.Titulo = "Select a level"
                frmO.Text = "Select a level "
                frmO.Opciones = "Level 1| Level 2 |Level 3 | Level 4"
                frmO.ShowDialog(frmSPrincipal)
                If frmO.DialogResult = DialogResult.OK Then
                    strTemp = cFunciones.ArchivoTemporal
                    f = FreeFile()
                    FileOpen(f, strTemp, OpenMode.Output)
                    strHtml &= "<html>"
                    strHtml &= "<head>"
                    strHtml &= "<title>" & "" & "</title>"
                    strHtml &= "<style type='text/css'>"
                    strHtml &= " table {empty-cells: show; border-collapse:collapse}"

                    strHtml &= " .titulo {text-align: left; border: none;  font-weight: bold;font-size: 12pt}"
                    strHtml &= " .encabezado {text-align: left; border: none;  font-weight: bold;font-size: 10pt}"
                    strHtml &= " .izquierda {text-align:left}"
                    strHtml &= " .centro {text-align:left;  Arial;font-size: 8pt}"
                    strHtml &= " .derecha {text-align: right;font-family: Tahoma,  Arial;font-size: 10pt}"

                    strHtml &= "</style>"
                    strHtml &= "</head>"
                    strHtml &= "<body>"

                    strsql = SqlEncabezadoBalance()
                    MyCnn.CONECTAR = strConexion
                    COM = New MySqlCommand(strsql, CON)
                    REA2 = COM.ExecuteReader
                    If REA2.HasRows Then
                        Do While REA2.Read
                            strHtml &= "<table>"
                            strHtml &= "<tr>"
                            strHtml &= "<td><strong></h3> " & REA2.GetString("empresa") & "</h3></strong></td>"
                            strHtml &= "  </tr>"

                            strHtml &= "<tr>"
                            strHtml &= "<td><h6>(Compañia " & REA2.GetString("nacionalidad") & ")</h6></td>"
                            strHtml &= "  </tr>"

                            strHtml &= "<tr>"
                            strHtml &= "<td class='titulo'>Estados de situación financiera </td>"
                            strHtml &= "  </tr>"

                            strHtml &= "<tr>"
                            strHtml &= "<td class='centro'>Del " & frm.FechaInicio.Day & " de " & cFunciones.MesALetras(frm.FechaInicio.Month) & " al " & frm.FechaFin.Day & " de " & cFunciones.MesALetras(frm.FechaFin.Month) & "  de " & frm.FechaFin.Year & " </td>"
                            strHtml &= "  </tr>"

                            strHtml &= "<tr>"
                            strHtml &= "<td class='centro'>(Expresados en " & REA2.GetString("moneda") & ") </td>"
                            strHtml &= "  </tr>"

                            strHtml &= "</table>"

                        Loop
                        strHtml &= "<hr>"
                    End If
                    strHtml &= "<table>"
                    strsql = SqlBalance(frm.FechaInicio, frm.FechaFin, frmO.Seleccion)
                    MyCnn.CONECTAR = strConexion
                    COM = New MySqlCommand(strsql, CON)
                    REA = COM.ExecuteReader
                    If REA.HasRows Then
                        Select Case frmO.Seleccion
                            Case 0
                                Do While REA.Read
                                    If logPrimeraLinea = True Then
                                        logPrimeraLinea = False
                                        strNivel0 = REA.GetString("nivel0")
                                        strNivel1 = REA.GetString("nivel1")
                                        strNivel2 = REA.GetString("nivel2")
                                        strNivel3 = REA.GetString("nivel3")
                                        strNivel4 = REA.GetString("nivel4")

                                        dblTotalNivel0 = REA.GetDouble("saldo")
                                        dblTotalNivel1 = REA.GetDouble("saldo")
                                        dblTotalNivel2 = REA.GetDouble("saldo")
                                        dblTotalNivel3 = REA.GetDouble("saldo")
                                        dblTotalNivel4 = REA.GetDouble("saldo")

                                        strHtml &= PrimeraLineaHtml(0, REA.GetString("nivel0"), REA.GetString("nivel1"), REA.GetString("nivel2"), REA.GetString("nivel3"), REA.GetDouble("saldo"), True)
                                    Else
                                        If strNivel0 = REA.GetString("nivel0") Then
                                            strHtml &= Linea(0, REA.GetString("nivel0"), REA.GetDouble("saldo"))
                                        Else
                                            intConteo = intConteo + 1
                                            If intConteo = 2 Then
                                                str2Niveles = strNivel0
                                                dbl2Totales = dblTotalNivel0
                                            End If
                                            If REA.GetString("cuenta2") = "3101" Then
                                                Dim dblResultadoEjercicio As Double = ResultadoEjerccio(frm.FechaInicio, frm.FechaFin)
                                                strHtml &= Subtotal(0, strNivel0, dblTotalNivel0)
                                                strHtml &= PrimeraLineaHtml(0, REA.GetString("nivel0"), REA.GetString("nivel1"), REA.GetString("nivel2"), REA.GetString("nivel3"), (REA.GetDouble("saldo") + dblResultadoEjercicio), True)
                                                strNivel0 = REA.GetString("nivel0")
                                                dblTotalNivel0 = REA.GetDouble("saldo") + dblResultadoEjercicio

                                            Else
                                                strHtml &= Subtotal(0, strNivel0, dblTotalNivel0)
                                                strHtml &= PrimeraLineaHtml(0, REA.GetString("nivel0"), REA.GetString("nivel1"), REA.GetString("nivel2"), REA.GetString("nivel3"), REA.GetDouble("saldo"), True)
                                                strNivel0 = REA.GetString("nivel0")
                                                dblTotalNivel0 = REA.GetDouble("saldo")
                                            End If

                                        End If

                                    End If

                                Loop
                                strHtml &= Subtotal(0, strNivel0, dblTotalNivel0)
                                strHtml &= "<tr>"
                                strHtml &= "<td class='titulo'> TOTAL " & str2Niveles & " & " & strNivel0 & "</td>"
                                strHtml &= "<td class='titulo'> </td>"
                                strHtml &= "<td class='titulo'>" & (dbl2Totales + dblTotalNivel0).ToString(FORMATO_MONEDA) & "</td>"
                                strHtml &= "</tr>"
                                strHtml &= "</table>"
                                strHtml &= "<br/>"
                            Case 1

                                Do While REA.Read
                                    If logPrimeraLinea = True Then
                                        logPrimeraLinea = False
                                        strNivel0 = REA.GetString("nivel0")
                                        strNivel1 = REA.GetString("nivel1")
                                        strNivel2 = REA.GetString("nivel2")
                                        strNivel3 = REA.GetString("nivel3")
                                        strNivel4 = REA.GetString("nivel4")

                                        dblTotalNivel0 = REA.GetDouble("saldo")
                                        dblTotalNivel1 = REA.GetDouble("saldo")
                                        dblTotalNivel2 = REA.GetDouble("saldo")
                                        dblTotalNivel3 = REA.GetDouble("saldo")
                                        dblTotalNivel4 = REA.GetDouble("saldo")

                                        strHtml &= PrimeraLineaHtml(1, REA.GetString("nivel0"), REA.GetString("nivel1"), REA.GetString("nivel2"), REA.GetString("nivel3"), REA.GetDouble("saldo"), True)
                                        strNivel0 = REA.GetString("nivel0")
                                    Else
                                        If strNivel0 = REA.GetString("nivel0") Then
                                            strHtml &= Linea(1, REA.GetString("nivel1"), REA.GetDouble("saldo"))
                                            dblTotalNivel0 = dblTotalNivel0 + REA.GetDouble("saldo")
                                            strNivel0 = REA.GetString("nivel0")
                                        Else
                                            intConteo = intConteo + 1
                                            strHtml &= Subtotal(0, strNivel0, dblTotalNivel0)
                                            If intConteo = 2 Then
                                                str2Niveles = strNivel0
                                                dbl2Totales = dblTotalNivel0
                                            End If
                                            dblTotalNivel0 = INT_CERO
                                            If REA.GetString("cuenta2") = "3101" Then
                                                Dim dblResultadoEjercicio As Double = ResultadoEjerccio(frm.FechaInicio, frm.FechaFin)

                                                'dblTotalNivel0 = dblTotalNivel0 + dblResultadoEjercicio
                                                dblTotalNivel0 = REA.GetDouble("saldo") + dblResultadoEjercicio
                                                strHtml &= PrimeraLineaHtml(1, REA.GetString("nivel0"), REA.GetString("nivel1"), REA.GetString("nivel2"), REA.GetString("nivel3"), dblTotalNivel0, True)

                                            Else
                                                dblTotalNivel0 = dblTotalNivel0 + REA.GetDouble("saldo")
                                                strHtml &= PrimeraLineaHtml(1, REA.GetString("nivel0"), REA.GetString("nivel1"), REA.GetString("nivel2"), REA.GetString("nivel3"), REA.GetDouble("saldo"), True)
                                                ' strHtml &= Linea(1, REA.GetString("nivel1"), REA.GetDouble("saldo"))

                                            End If
                                            strNivel0 = REA.GetString("nivel0")

                                        End If
                                    End If
                                Loop
                                strHtml &= Subtotal(0, strNivel0, dblTotalNivel0)
                                strHtml &= "<tr>"
                                strHtml &= "<td class='titulo'> TOTAL " & str2Niveles & " & " & strNivel0 & "</td>"
                                strHtml &= "<td class='titulo'> </td>"
                                strHtml &= "<td class='titulo'>" & (dbl2Totales + dblTotalNivel0).ToString(FORMATO_MONEDA) & "</td>"
                                strHtml &= "</tr>"
                                strHtml &= "</table>"
                                strHtml &= "<br/>"
                            Case 2
                                Do While REA.Read
                                    If logPrimeraLinea = True Then
                                        logPrimeraLinea = False
                                        strNivel0 = REA.GetString("nivel0")
                                        strNivel1 = REA.GetString("nivel1")
                                        strNivel2 = REA.GetString("nivel2")
                                        strNivel3 = REA.GetString("nivel3")
                                        strNivel4 = REA.GetString("nivel4")

                                        dblTotalNivel0 = REA.GetDouble("saldo")
                                        dblTotalNivel1 = REA.GetDouble("saldo")
                                        dblTotalNivel2 = REA.GetDouble("saldo")
                                        dblTotalNivel3 = REA.GetDouble("saldo")
                                        dblTotalNivel4 = REA.GetDouble("saldo")

                                        strHtml &= PrimeraLineaHtml(2, REA.GetString("nivel0"), REA.GetString("nivel1"), REA.GetString("nivel2"), REA.GetString("nivel3"), REA.GetDouble("saldo"), True)
                                    Else

                                        If strNivel0 = REA.GetString("nivel0") Then
                                            If strNivel1 = REA.GetString("nivel1") Then

                                                If REA.GetString("cuenta2") = "3106" Then
                                                    Dim dblResultadoEjercicio As Double = ResultadoEjerccio(frm.FechaInicio, frm.FechaFin)

                                                    dblTotalNivel0 = dblTotalNivel0 + dblResultadoEjercicio
                                                    dblTotalNivel1 = dblTotalNivel1 + dblResultadoEjercicio
                                                    strHtml &= "<tr>"
                                                    strHtml &= "<td class='centro'>" & EspacioHtml(10) & REA.GetString("nivel2").ToString & "</td>"
                                                    strHtml &= "<td class='derecha'>" & dblResultadoEjercicio.ToString(FORMATO_MONEDA) & "</td>"
                                                    strHtml &= "</tr>"
                                                Else
                                                    dblTotalNivel0 = dblTotalNivel0 + REA.GetDouble("saldo")
                                                    dblTotalNivel1 = dblTotalNivel1 + REA.GetDouble("saldo")
                                                    strHtml &= Linea(2, REA.GetString("nivel2"), REA.GetDouble("saldo"))
                                                End If


                                            Else
                                                strHtml &= Subtotal(1, strNivel1, dblTotalNivel1)
                                                strHtml &= PrimeraLineaHtml(2, REA.GetString("nivel0"), REA.GetString("nivel1"), REA.GetString("nivel2"), REA.GetString("nivel3"), REA.GetDouble("saldo"), True, 1)
                                                dblTotalNivel0 = dblTotalNivel0 + REA.GetDouble("saldo")
                                                dblTotalNivel1 = REA.GetDouble("saldo")

                                            End If
                                        Else
                                            intConteo = intConteo + 1

                                            strHtml &= Subtotal(1, strNivel1, dblTotalNivel1)
                                            strHtml &= Subtotal(0, strNivel0, dblTotalNivel0)
                                            If REA.GetString("cuenta3") = "310601" Then
                                                Dim dblResultadoEjercicio As Double = ResultadoEjerccio(frm.FechaInicio, frm.FechaFin)

                                                dblTotalNivel0 = dblTotalNivel0 + dblResultadoEjercicio
                                                dblTotalNivel1 = dblTotalNivel1 + dblResultadoEjercicio
                                                dblTotalNivel2 = dblTotalNivel2 + dblResultadoEjercicio
                                                strHtml &= "<tr>"
                                                strHtml &= "<td class='centro'>" & EspacioHtml(10) & REA.GetString("nivel3").ToString & "</td>"
                                                strHtml &= "<td class='derecha'>" & dblResultadoEjercicio.ToString(FORMATO_MONEDA) & "</td>"
                                                strHtml &= "</tr>"
                                            Else
                                                strHtml &= PrimeraLineaHtml(2, REA.GetString("nivel0"), REA.GetString("nivel1"), REA.GetString("nivel2"), REA.GetString("nivel3"), REA.GetDouble("saldo"), True)
                                                If intConteo = 2 Then
                                                    str2Niveles = strNivel0
                                                    dbl2Totales = dblTotalNivel0
                                                End If
                                                dblTotalNivel0 = REA.GetDouble("saldo")
                                                dblTotalNivel1 = REA.GetDouble("saldo")
                                            End If


                                        End If
                                    End If
                                    strNivel0 = REA.GetString("nivel0")
                                    strNivel1 = REA.GetString("nivel1")
                                Loop
                                strHtml &= Subtotal(1, strNivel1, dblTotalNivel1)

                                strHtml &= Subtotal(0, strNivel0, dblTotalNivel0)
                                strHtml &= "<tr>"
                                strHtml &= "<td class='titulo'> TOTAL " & str2Niveles & " Y " & strNivel0 & "</td>"
                                strHtml &= "<td class='titulo'> </td>"
                                strHtml &= "<td class='titulo'>" & (dbl2Totales + dblTotalNivel0).ToString(FORMATO_MONEDA) & "</td>"
                                strHtml &= "</tr>"
                                strHtml &= "</table>"
                                strHtml &= "<br/>"
                            Case 3
                                Do While REA.Read

                                    If logPrimeraLinea = True Then
                                        logPrimeraLinea = False
                                        strNivel0 = REA.GetString("nivel0")
                                        strNivel1 = REA.GetString("nivel1")
                                        strNivel2 = REA.GetString("nivel2")
                                        strNivel3 = REA.GetString("nivel3")
                                        strNivel4 = REA.GetString("nivel4")

                                        dblTotalNivel0 = REA.GetDouble("saldo")
                                        dblTotalNivel1 = REA.GetDouble("saldo")
                                        dblTotalNivel2 = REA.GetDouble("saldo")
                                        dblTotalNivel3 = REA.GetDouble("saldo")
                                        dblTotalNivel4 = REA.GetDouble("saldo")

                                        strHtml &= PrimeraLineaHtml(3, REA.GetString("nivel0"), REA.GetString("nivel1"), REA.GetString("nivel2"), REA.GetString("nivel3"), REA.GetDouble("saldo"), True)
                                    Else

                                        If strNivel0 = REA.GetString("nivel0") Then
                                            If strNivel1 = REA.GetString("nivel1") Then
                                                If strNivel2 = REA.GetString("nivel2") Then

                                                    If REA.GetString("cuenta3") = "310601" Then
                                                        Dim dblResultadoEjercicio As Double = ResultadoEjerccio(frm.FechaInicio, frm.FechaFin)

                                                        dblTotalNivel0 = dblTotalNivel0 + dblResultadoEjercicio
                                                        dblTotalNivel1 = dblTotalNivel1 + dblResultadoEjercicio
                                                        dblTotalNivel2 = dblTotalNivel2 + dblResultadoEjercicio
                                                        strHtml &= "<tr>"
                                                        strHtml &= "<td class='centro'>" & EspacioHtml(10) & REA.GetString("nivel3").ToString & "</td>"
                                                        strHtml &= "<td class='derecha'>" & dblResultadoEjercicio.ToString(FORMATO_MONEDA) & "</td>"
                                                        strHtml &= "</tr>"
                                                    Else
                                                        dblTotalNivel0 = dblTotalNivel0 + REA.GetDouble("saldo")
                                                        dblTotalNivel1 = dblTotalNivel1 + REA.GetDouble("saldo")
                                                        dblTotalNivel2 = dblTotalNivel2 + REA.GetDouble("saldo")
                                                        strHtml &= Linea(3, REA.GetString("nivel3"), REA.GetDouble("saldo"))
                                                    End If
                                                Else
                                                    If REA.GetString("cuenta3") = "310601" Then
                                                        Dim dblResultadoEjercicio As Double = ResultadoEjerccio(frm.FechaInicio, frm.FechaFin)

                                                        dblTotalNivel0 = dblTotalNivel0 + dblResultadoEjercicio
                                                        dblTotalNivel1 = dblTotalNivel1 + dblResultadoEjercicio
                                                        dblTotalNivel2 = dblTotalNivel2 + dblResultadoEjercicio
                                                        strHtml &= "<tr>"
                                                        strHtml &= "<td class='centro'>" & EspacioHtml(10) & REA.GetString("nivel3").ToString & "</td>"
                                                        strHtml &= "<td class='derecha'>" & dblResultadoEjercicio.ToString(FORMATO_MONEDA) & "</td>"
                                                        strHtml &= "</tr>"
                                                    Else
                                                        strHtml &= Subtotal(2, strNivel2, dblTotalNivel2)
                                                        strHtml &= PrimeraLineaHtml(3, REA.GetString("nivel0"), REA.GetString("nivel1"), REA.GetString("nivel2"), REA.GetString("nivel3"), REA.GetDouble("saldo"), False)
                                                        dblTotalNivel0 = dblTotalNivel0 + REA.GetDouble("saldo")
                                                        dblTotalNivel1 = dblTotalNivel1 + REA.GetDouble("saldo")
                                                        dblTotalNivel2 = REA.GetDouble("saldo")
                                                    End If
                                                End If

                                            Else
                                                strHtml &= Subtotal(2, strNivel2, dblTotalNivel2)
                                                strHtml &= Subtotal(1, strNivel1, dblTotalNivel1)
                                                strHtml &= PrimeraLineaHtml(3, REA.GetString("nivel0"), REA.GetString("nivel1"), REA.GetString("nivel2"), REA.GetString("nivel3"), REA.GetDouble("saldo"), True, 1)
                                                dblTotalNivel0 = dblTotalNivel0 + REA.GetDouble("saldo")
                                                dblTotalNivel1 = REA.GetDouble("saldo")
                                                dblTotalNivel2 = REA.GetDouble("saldo")
                                            End If
                                        Else
                                            intConteo = intConteo + 1
                                            strHtml &= Subtotal(1, strNivel1, dblTotalNivel1)
                                            strHtml &= Subtotal(0, strNivel0, dblTotalNivel0)
                                            If REA.GetString("cuenta3") = "310601" Then
                                                Dim dblResultadoEjercicio As Double = ResultadoEjerccio(frm.FechaInicio, frm.FechaFin)

                                                dblTotalNivel0 = dblTotalNivel0 + dblResultadoEjercicio
                                                dblTotalNivel1 = dblTotalNivel1 + dblResultadoEjercicio
                                                dblTotalNivel2 = dblTotalNivel2 + dblResultadoEjercicio
                                                strHtml &= "<tr>"
                                                strHtml &= "<td class='centro'>" & EspacioHtml(10) & REA.GetString("nivel3").ToString & "</td>"
                                                strHtml &= "<td class='derecha'>" & dblResultadoEjercicio.ToString(FORMATO_MONEDA) & "</td>"
                                                strHtml &= "</tr>"
                                            Else
                                                strHtml &= PrimeraLineaHtml(3, REA.GetString("nivel0"), REA.GetString("nivel1"), REA.GetString("nivel2"), REA.GetString("nivel3"), REA.GetDouble("saldo"), True)
                                                If intConteo = 2 Then
                                                    str2Niveles = strNivel0
                                                    dbl2Totales = dblTotalNivel0
                                                End If
                                                dblTotalNivel0 = REA.GetDouble("saldo")
                                                dblTotalNivel1 = REA.GetDouble("saldo")
                                                dblTotalNivel2 = REA.GetDouble("saldo")
                                            End If

                                        End If
                                    End If
                                    strNivel0 = REA.GetString("nivel0")
                                    strNivel1 = REA.GetString("nivel1")
                                    strNivel2 = REA.GetString("nivel2")
                                Loop

                                strHtml &= Subtotal(2, strNivel2, dblTotalNivel2)
                                strHtml &= Subtotal(1, strNivel1, dblTotalNivel1)

                                strHtml &= Subtotal(0, strNivel0, dblTotalNivel0)
                                strHtml &= "<tr>"
                                strHtml &= "<td class='titulo'> TOTAL " & str2Niveles & " Y " & strNivel0 & "</td>"
                                strHtml &= "<td class='titulo'> </td>"
                                strHtml &= "<td class='titulo'>" & (dbl2Totales + dblTotalNivel0).ToString(FORMATO_MONEDA) & "</td>"
                                strHtml &= "</tr>"
                                strHtml &= "</table>"
                                strHtml &= "<br/>"


                        End Select

                        strHtml &= "</body>"
                        strHtml &= "</html>"
                        Print(f, strHtml)
                        FileClose(f)
                        crport.MostarReporte(strTemp)
                    End If
                End If

            End If


        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try

    End Sub
#End Region

#Region "Estado de Resultados Pyme"
    Private Function SqlEstadoResultadoPyme(ByVal Finicio As Date, ByVal Ffinal As Date, ByVal intOpcion As Integer) As String
        Dim strSql As String = STR_VACIO
        Try
            strSql = " select  c.cuenta0, c.nivel0, c.nivel1,c.cuenta1, c.nivel2,c.cuenta2,c.nivel3 , c.cuenta3 , c.nivel4 , c.cuentan4,     "
            strSql &= "  SUM((SELECT IFNULL(SUM(IF(d.operacion = 'C', (IFNULL(d.importe,0)), IFNULL(d.importe,0)* -1)),0) from {conta}.polizas p "
            strSql &= "         left join {conta}.detalle_polizas d on d.empresa = p.empresa and d.ejercicio = p.ejercicio and d.poliza = p.poliza  "
            strSql &= "         LEFT JOIN {conta}.tipo_poliza t ON t.tipo_poliza = p.tipo "
            strSql &= "       where p.empresa = {empresa} and p.fecha between '{inicio}' and '{fin}'  and d.cuenta = c.cuentan4 AND NOT t.tipo_poliza IN(4,5) ))saldo   "
            strSql &= " from {conta}.cuenta_nivel c  "
            strSql &= " where c.cuenta0 in('4','5','6','7','8') "

            Select Case intOpcion
                Case 0
                    strSql &= "  group by c.cuenta0 "
                Case 1
                    strSql &= "  group by c.cuenta1 "
                Case 2
                    strSql &= "  group by c.cuenta2 "
                Case 3
                    strSql &= "  group by c.cuenta3 "
                Case 4
                    strSql &= "  group by c.cuenta4 "

            End Select

            strSql = Replace(strSql, "{conta}", Sesion.BaseConta)
            strSql = Replace(strSql, "{empresa}", Sesion.IdEmpresa)
            strSql = Replace(strSql, "{inicio}", Finicio.ToString(FORMATO_MYSQL))
            strSql = Replace(strSql, "{fin}", Ffinal.ToString(FORMATO_MYSQL))

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        Return strSql
    End Function

    Private Function SqlEncabezadoEstadoResultados() As String
        Dim strSQL As String = STR_VACIO
        Try
            strSQL = "  select e.emp_razon empresa, c.cat_dato moneda , p.cat_dato nacionalidad  from Empresas e "
            strSQL &= " 	LEFT JOIN Catalogos c on c.cat_num = e.emp_moneda "
            strSQL &= "  	left join Catalogos p on p.cat_num = e.emp_pais  "
            strSQL &= " where e.emp_no=  " & Sesion.IdEmpresa

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        Return strSQL
    End Function

    Public Sub EstadoDeResultadosPyme()
        Dim crport As New clsReportes
        Dim strsql As String = STR_VACIO
        Dim strHtml As String = STR_VACIO

        Dim frm As New frmFiltro
        Dim frmO As New frmOption
        Dim logPrimeraLinea As Boolean = True
        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader
        Dim REA2 As MySqlDataReader
        Dim strTemp As String = STR_VACIO

        Dim dblTotalNivel0 As Double = INT_CERO
        Dim dblTotalNivel1 As Double = INT_CERO
        Dim dblTotalNivel2 As Double = INT_CERO
        Dim dblTotalNivel3 As Double = INT_CERO
        Dim dblTotalNivel4 As Double = INT_CERO

        Dim strNivel0 As String = STR_VACIO
        Dim strNivel1 As String = STR_VACIO
        Dim strNivel2 As String = STR_VACIO
        Dim strNivel3 As String = STR_VACIO
        Dim strNivel4 As String = STR_VACIO
        'Dim intConteo As Integer = 0

        Dim dblSubtotal0 As Double = INT_CERO
        Dim dblSubtotal1 As Double = INT_CERO
        Dim f As Byte
        Try
            frm.BanderaFechas = True
            frm.Titulo = "Profit and Loss"
            frm.Text = "Select a range date"

            frm.ShowDialog(frmSPrincipal)
            If frm.DialogResult = DialogResult.OK Then

                frmO.Titulo = "Select a level"
                frmO.Text = "Select a level "
                frmO.Opciones = "Level 1| Level 2 |Level 3 | Level 4"
                frmO.ShowDialog(frmSPrincipal)
                If frmO.DialogResult = DialogResult.OK Then

                    strTemp = cFunciones.ArchivoTemporal
                    f = FreeFile()
                    FileOpen(f, strTemp, OpenMode.Output)
                    strHtml &= "<html>"
                    strHtml &= "<head>"
                    strHtml &= "<title>" & "" & "</title>"
                    strHtml &= "<style type='text/css'>"
                    strHtml &= " table {empty-cells: show; border-collapse:collapse}"

                    strHtml &= " .titulo {text-align: left; border: none;  font-weight: bold;font-size: 12pt}"
                    strHtml &= " .encabezado {text-align: left; border: none;  font-weight: bold;font-size: 10pt}"

                    strHtml &= " .izquierda {text-align:left}"
                    strHtml &= " .centro {text-align:left;  Arial;font-size: 8pt}"
                    strHtml &= " .derecha {text-align: right;font-family: Tahoma,  Arial;font-size: 10pt}"

                    strHtml &= "</style>"
                    strHtml &= "</head>"
                    strHtml &= "<body>"

                    strsql = SqlEncabezadoEstadoResultados()
                    MyCnn.CONECTAR = strConexion
                    COM = New MySqlCommand(strsql, CON)
                    REA2 = COM.ExecuteReader
                    If REA2.HasRows Then
                        Do While REA2.Read
                            strHtml &= "<table>"
                            strHtml &= "<tr>"
                            strHtml &= "<td><strong></h3> " & REA2.GetString("empresa") & "</h3></strong></td>"
                            strHtml &= "  </tr>"

                            strHtml &= "<tr>"
                            strHtml &= "<td><h6>(Compañia " & REA2.GetString("nacionalidad") & ")</h6></td>"
                            strHtml &= "  </tr>"

                            strHtml &= "<tr>"
                            strHtml &= "<td class='titulo'>Estados del resultado integral </td>"
                            strHtml &= "  </tr>"

                            strHtml &= "<tr>"
                            strHtml &= "<td class='centro'>Del " & frm.FechaInicio.Day & " de " & cFunciones.MesALetras(frm.FechaInicio.Month) & " al " & frm.FechaFin.Day & " de " & cFunciones.MesALetras(frm.FechaFin.Month) & "  de " & frm.FechaFin.Year & " </td>"
                            strHtml &= "  </tr>"

                            strHtml &= "<tr>"
                            strHtml &= "<td class='centro'>(Expresados en " & REA2.GetString("moneda") & ") </td>"
                            strHtml &= "  </tr>"

                            strHtml &= "</table>"

                        Loop
                        strHtml &= "<hr>"
                    End If
                    strHtml &= "<table>"
                    strsql = SqlEstadoResultadoPyme(frm.FechaInicio, frm.FechaFin, frmO.Seleccion)
                    MyCnn.CONECTAR = strConexion
                    COM = New MySqlCommand(strsql, CON)
                    REA = COM.ExecuteReader
                    If REA.HasRows Then
                        Select Case frmO.Seleccion
                            Case 0
                                Do While REA.Read
                                    If logPrimeraLinea = True Then
                                        logPrimeraLinea = False
                                        strNivel0 = REA.GetString("nivel0")
                                        strNivel1 = REA.GetString("nivel1")
                                        strNivel2 = REA.GetString("nivel2")
                                        strNivel3 = REA.GetString("nivel3")
                                        strNivel4 = REA.GetString("nivel4")

                                        dblTotalNivel0 = REA.GetDouble("saldo")
                                        dblTotalNivel1 = REA.GetDouble("saldo")
                                        dblTotalNivel2 = REA.GetDouble("saldo")
                                        dblTotalNivel3 = REA.GetDouble("saldo")
                                        dblTotalNivel4 = REA.GetDouble("saldo")
                                        dblSubtotal0 = dblSubtotal0 + REA.GetDouble("saldo")
                                        strHtml &= PrimeraLineaHtml(0, REA.GetString("nivel0"), REA.GetString("nivel1"), REA.GetString("nivel2"), REA.GetString("nivel3"), REA.GetDouble("saldo"), True)
                                    Else
                                        If strNivel0 = REA.GetString("nivel0") Then
                                            strHtml &= Linea(0, REA.GetString("nivel0"), REA.GetDouble("saldo"))
                                        Else

                                            strHtml &= Subtotal(0, strNivel0, dblTotalNivel0)
                                            strHtml &= Linea(0, REA.GetString("nivel0"), REA.GetDouble("saldo"))
                                            strNivel0 = REA.GetString("nivel0")
                                            dblTotalNivel0 = REA.GetDouble("saldo")
                                            dblTotalNivel1 = REA.GetDouble("saldo")
                                            dblTotalNivel2 = REA.GetDouble("saldo")
                                            dblTotalNivel3 = REA.GetDouble("saldo")
                                            dblTotalNivel4 = REA.GetDouble("saldo")
                                            dblSubtotal0 = dblSubtotal0 + REA.GetDouble("saldo")
                                        End If

                                    End If

                                Loop
                                strHtml &= Subtotal(0, strNivel0, dblTotalNivel0)
                            Case 1

                                Do While REA.Read
                                    If logPrimeraLinea = True Then
                                        logPrimeraLinea = False
                                        strNivel0 = REA.GetString("nivel0")
                                        strNivel1 = REA.GetString("nivel1")
                                        strNivel2 = REA.GetString("nivel2")
                                        strNivel3 = REA.GetString("nivel3")
                                        strNivel4 = REA.GetString("nivel4")

                                        dblTotalNivel0 = REA.GetDouble("saldo")
                                        dblTotalNivel1 = REA.GetDouble("saldo")
                                        dblTotalNivel2 = REA.GetDouble("saldo")
                                        dblTotalNivel3 = REA.GetDouble("saldo")
                                        dblTotalNivel4 = REA.GetDouble("saldo")

                                        strHtml &= PrimeraLineaHtml(1, REA.GetString("nivel0"), REA.GetString("nivel1"), REA.GetString("nivel2"), REA.GetString("nivel3"), REA.GetDouble("saldo"), True)
                                        strNivel0 = REA.GetString("nivel0")
                                    Else
                                        If strNivel0 = REA.GetString("nivel0") Then
                                            strHtml &= Linea(1, REA.GetString("nivel1"), REA.GetDouble("saldo"))
                                            dblTotalNivel0 = dblTotalNivel0 + REA.GetDouble("saldo")
                                            strNivel0 = REA.GetString("nivel0")
                                        Else

                                            strHtml &= Subtotal(0, strNivel0, dblTotalNivel0)
                                            dblTotalNivel0 = INT_CERO
                                            dblTotalNivel0 = dblTotalNivel0 + REA.GetDouble("saldo")
                                            strHtml &= PrimeraLineaHtml(1, REA.GetString("nivel0"), REA.GetString("nivel1"), REA.GetString("nivel2"), REA.GetString("nivel3"), REA.GetDouble("saldo"), True)
                                            ' strHtml &= Linea(1, REA.GetString("nivel1"), REA.GetDouble("saldo"))
                                            strNivel0 = REA.GetString("nivel0")
                                        End If
                                    End If
                                Loop
                            Case 2
                                Do While REA.Read
                                    If logPrimeraLinea = True Then
                                        logPrimeraLinea = False
                                        strNivel0 = REA.GetString("nivel0")
                                        strNivel1 = REA.GetString("nivel1")
                                        strNivel2 = REA.GetString("nivel2")
                                        strNivel3 = REA.GetString("nivel3")
                                        strNivel4 = REA.GetString("nivel4")

                                        dblTotalNivel0 = REA.GetDouble("saldo")
                                        dblTotalNivel1 = REA.GetDouble("saldo")
                                        dblTotalNivel2 = REA.GetDouble("saldo")
                                        dblTotalNivel3 = REA.GetDouble("saldo")
                                        dblTotalNivel4 = REA.GetDouble("saldo")

                                        strHtml &= PrimeraLineaHtml(2, REA.GetString("nivel0"), REA.GetString("nivel1"), REA.GetString("nivel2"), REA.GetString("nivel3"), REA.GetDouble("saldo"), True)
                                    Else


                                        If strNivel0 = REA.GetString("nivel0") Then
                                            If strNivel1 = REA.GetString("nivel1") Then

                                                If REA.GetString("cuenta2") = "3106" Then
                                                    Dim dblResultadoEjercicio As Double = ResultadoEjerccio(frm.FechaInicio, frm.FechaFin)

                                                    dblTotalNivel0 = dblTotalNivel0 + dblResultadoEjercicio
                                                    dblTotalNivel1 = dblTotalNivel1 + dblResultadoEjercicio
                                                    strHtml &= "<tr>"
                                                    strHtml &= "<td class='centro'>" & EspacioHtml(10) & REA.GetString("nivel2").ToString & "</td>"
                                                    strHtml &= "<td class='derecha'>" & dblResultadoEjercicio.ToString(FORMATO_MONEDA) & "</td>"
                                                    strHtml &= "</tr>"
                                                Else
                                                    dblTotalNivel0 = dblTotalNivel0 + REA.GetDouble("saldo")
                                                    dblTotalNivel1 = dblTotalNivel1 + REA.GetDouble("saldo")
                                                    strHtml &= Linea(2, REA.GetString("nivel2"), REA.GetDouble("saldo"))
                                                End If


                                            Else
                                                strHtml &= Subtotal(1, strNivel1, dblTotalNivel1)
                                                strHtml &= PrimeraLineaHtml(2, REA.GetString("nivel0"), REA.GetString("nivel1"), REA.GetString("nivel2"), REA.GetString("nivel3"), REA.GetDouble("saldo"), False)
                                                dblTotalNivel0 = dblTotalNivel0 + REA.GetDouble("saldo")
                                                dblTotalNivel1 = REA.GetDouble("saldo")

                                            End If
                                        Else


                                            strHtml &= Subtotal(1, strNivel1, dblTotalNivel1)
                                            strHtml &= Subtotal(0, strNivel0, dblTotalNivel0)

                                            strHtml &= PrimeraLineaHtml(2, REA.GetString("nivel0"), REA.GetString("nivel1"), REA.GetString("nivel2"), REA.GetString("nivel3"), REA.GetDouble("saldo"), True)

                                            dblTotalNivel0 = REA.GetDouble("saldo")
                                            dblTotalNivel1 = REA.GetDouble("saldo")
                                        End If
                                    End If
                                    strNivel0 = REA.GetString("nivel0")
                                    strNivel1 = REA.GetString("nivel1")
                                Loop
                                strHtml &= Subtotal(1, strNivel1, dblTotalNivel1)

                                strHtml &= Subtotal(0, strNivel0, dblTotalNivel0)

                            Case 3
                                Do While REA.Read

                                    If logPrimeraLinea = True Then
                                        logPrimeraLinea = False
                                        strNivel0 = REA.GetString("nivel0")
                                        strNivel1 = REA.GetString("nivel1")
                                        strNivel2 = REA.GetString("nivel2")
                                        strNivel3 = REA.GetString("nivel3")
                                        strNivel4 = REA.GetString("nivel4")

                                        dblTotalNivel0 = REA.GetDouble("saldo")
                                        dblTotalNivel1 = REA.GetDouble("saldo")
                                        dblTotalNivel2 = REA.GetDouble("saldo")
                                        dblTotalNivel3 = REA.GetDouble("saldo")
                                        dblTotalNivel4 = REA.GetDouble("saldo")

                                        strHtml &= PrimeraLineaHtml(3, REA.GetString("nivel0"), REA.GetString("nivel1"), REA.GetString("nivel2"), REA.GetString("nivel3"), REA.GetDouble("saldo"), True)
                                    Else


                                        If strNivel0 = REA.GetString("nivel0") Then
                                            If strNivel1 = REA.GetString("nivel1") Then
                                                If strNivel2 = REA.GetString("nivel2") Then

                                                    If REA.GetString("cuenta2") = "3106" Then
                                                        Dim dblResultadoEjercicio As Double = ResultadoEjerccio(frm.FechaInicio, frm.FechaFin)

                                                        dblTotalNivel0 = dblTotalNivel0 + dblResultadoEjercicio
                                                        dblTotalNivel1 = dblTotalNivel1 + dblResultadoEjercicio
                                                        dblTotalNivel2 = dblTotalNivel2 + dblResultadoEjercicio
                                                        strHtml &= "<tr>"
                                                        strHtml &= "<td class='centro'>" & EspacioHtml(10) & REA.GetString("nivel3").ToString & "</td>"
                                                        strHtml &= "<td class='derecha'>" & dblResultadoEjercicio.ToString(FORMATO_MONEDA) & "</td>"
                                                        strHtml &= "</tr>"
                                                    Else
                                                        dblTotalNivel0 = dblTotalNivel0 + REA.GetDouble("saldo")
                                                        dblTotalNivel1 = dblTotalNivel1 + REA.GetDouble("saldo")
                                                        dblTotalNivel2 = dblTotalNivel2 + REA.GetDouble("saldo")
                                                        strHtml &= Linea(3, REA.GetString("nivel3"), REA.GetDouble("saldo"))
                                                    End If
                                                Else
                                                    strHtml &= Subtotal(2, strNivel2, dblTotalNivel2)
                                                    strHtml &= PrimeraLineaHtml(3, REA.GetString("nivel0"), REA.GetString("nivel1"), REA.GetString("nivel2"), REA.GetString("nivel3"), REA.GetDouble("saldo"), False)
                                                    dblTotalNivel0 = dblTotalNivel0 + REA.GetDouble("saldo")
                                                    dblTotalNivel1 = dblTotalNivel1 + REA.GetDouble("saldo")
                                                    dblTotalNivel2 = REA.GetDouble("saldo")
                                                End If

                                            Else
                                                strHtml &= Subtotal(2, strNivel2, dblTotalNivel2)
                                                strHtml &= Subtotal(1, strNivel1, dblTotalNivel1)
                                                strHtml &= PrimeraLineaHtml(3, REA.GetString("nivel0"), REA.GetString("nivel1"), REA.GetString("nivel2"), REA.GetString("nivel3"), REA.GetDouble("saldo"), False)
                                                dblTotalNivel0 = dblTotalNivel0 + REA.GetDouble("saldo")
                                                dblTotalNivel1 = REA.GetDouble("saldo")
                                                dblTotalNivel2 = REA.GetDouble("saldo")

                                            End If
                                        Else
                                            'intConteo = intConteo + 1
                                            strHtml &= Subtotal(2, strNivel2, dblTotalNivel2)
                                            strHtml &= Subtotal(1, strNivel1, dblTotalNivel1)
                                            strHtml &= Subtotal(0, strNivel0, dblTotalNivel0)

                                            strHtml &= PrimeraLineaHtml(3, REA.GetString("nivel0"), REA.GetString("nivel1"), REA.GetString("nivel2"), REA.GetString("nivel3"), REA.GetDouble("saldo"), True)
                                            'If intConteo = 2 Then
                                            '    str2Niveles = strNivel0
                                            '    dbl2Totales = dblTotalNivel0
                                            'End If

                                            dblTotalNivel0 = REA.GetDouble("saldo")
                                            dblTotalNivel1 = REA.GetDouble("saldo")
                                            dblTotalNivel2 = REA.GetDouble("saldo")
                                        End If
                                    End If
                                    strNivel0 = REA.GetString("nivel0")
                                    strNivel1 = REA.GetString("nivel1")
                                    strNivel2 = REA.GetString("nivel2")
                                Loop

                                strHtml &= Subtotal(1, strNivel1, dblTotalNivel1)

                                strHtml &= Subtotal(0, strNivel0, dblTotalNivel0)



                        End Select
                        strHtml &= "<tr>"
                        strHtml &= "<td class='titulo'> Resultado del Ejercicio </td>"
                        strHtml &= "<td class='titulo'> </td>"
                        If frmO.Seleccion = 0 Then
                            Dim dblResultadoEjercicio As Double = ResultadoEjerccio(frm.FechaInicio, frm.FechaFin)
                            strHtml &= "<td class='titulo'>" & (dblResultadoEjercicio).ToString(FORMATO_MONEDA) & "</td>"
                        ElseIf frmO.Seleccion = 1 Then
                            Dim dblResultadoEjercicio As Double = ResultadoEjerccio(frm.FechaInicio, frm.FechaFin)
                            strHtml &= "<td class='titulo'>" & (dblResultadoEjercicio).ToString(FORMATO_MONEDA) & "</td>"
                        ElseIf frmO.Seleccion = 2 Then
                            Dim dblResultadoEjercicio As Double = ResultadoEjerccio(frm.FechaInicio, frm.FechaFin)
                            strHtml &= "<td class='titulo'>" & (dblResultadoEjercicio).ToString(FORMATO_MONEDA) & "</td>"
                        Else
                            Dim dblResultadoEjercicio As Double = ResultadoEjerccio(frm.FechaInicio, frm.FechaFin)
                            strHtml &= "<td class='titulo'>" & (dblResultadoEjercicio).ToString(FORMATO_MONEDA) & "</td>"
                            '  Else
                            '     strHtml &= "<td class='titulo'>" & (dblSubtotal1 + dblTotalNivel0).ToString(FORMATO_MONEDA) & "</td>"
                        End If

                            strHtml &= "</tr>"

                            strHtml &= "</table>"
                            strHtml &= "<br/>"
                            strHtml &= "</body>"
                            strHtml &= "</html>"
                            Print(f, strHtml)
                            FileClose(f)
                            crport.MostarReporte(strTemp)
                        End If
                    End If

            End If


        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try

    End Sub
#End Region
End Class
