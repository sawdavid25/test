﻿Imports Microsoft.Office.Interop
Imports System.Text
Imports System.IO
Imports System.IO.Ports
Imports System.Security.Cryptography
Imports System.Windows.Forms
Imports System.Threading

Public Class clsFunciones

#Region "Miembros"

    Public Enum AccEnum

        acAdd = 0
        acDelete = 1
        acUpdate = 2
        acPrint = 3
        acCorrect = 4
        acConfirm = 5
        acUnlock = 6
        acCargar = 7
        acPoliza = 8
        acCarga = 9
        acLiberar = 10
        acSalida = 11
        acGeneraYRM = 12
    End Enum

    Public Enum Monedas

        Mlocal = 0
        Mextrangero = 0

    End Enum

    Public Enum IpEquipo

        ip = 0
        equipo = 1

    End Enum

    Dim strMatrix As String

#End Region
    
#Region "Encriptar"

    Private Function Algoritmo(ByVal strClave As String) As RijndaelManaged
        Const salt As String = "pkdkdkdkd"
        Const tamaño As Integer = 256

        Dim keyBuilder As Rfc2898DeriveBytes = New Rfc2898DeriveBytes(strClave, Encoding.Unicode.GetBytes(salt))
        Dim algorithm As RijndaelManaged = New RijndaelManaged()
        algorithm.KeySize = tamaño
        algorithm.IV = keyBuilder.GetBytes(CType(algorithm.BlockSize / 8, Integer))
        algorithm.Key = keyBuilder.GetBytes(CType(algorithm.KeySize / 8, Integer))
        algorithm.Padding = PaddingMode.PKCS7
        Return algorithm
    End Function

    Public Function Encriptar(ByVal strTextoPlano As String, ByVal strClave As String) As String
        Dim encryptedPassword As String = Nothing
        Using outputStream As MemoryStream = New MemoryStream()
            Dim algorithm As RijndaelManaged = Algoritmo(strClave)
            Using cryptoStream As CryptoStream = New CryptoStream(outputStream, algorithm.CreateEncryptor(), CryptoStreamMode.Write)
                Dim inputBuffer() As Byte = Encoding.Unicode.GetBytes(strTextoPlano)
                cryptoStream.Write(inputBuffer, 0, inputBuffer.Length)
                cryptoStream.FlushFinalBlock()
                encryptedPassword = Convert.ToBase64String(outputStream.ToArray())
            End Using
        End Using
        Return encryptedPassword
    End Function

    Public Function Desencriptar(ByVal BytesEncriptados As String, ByVal strClave As String) As String
        Dim plainText As String = Nothing
        Try
            Using inputStream As MemoryStream = New MemoryStream(Convert.FromBase64String(BytesEncriptados))
                Dim algorithm As RijndaelManaged = Algoritmo(strClave)
                Using cryptoStream As CryptoStream = New CryptoStream(inputStream, algorithm.CreateDecryptor(), CryptoStreamMode.Read)
                    Dim outputBuffer(0 To CType(inputStream.Length - 1, Integer)) As Byte
                    Dim readBytes As Integer = cryptoStream.Read(outputBuffer, 0, CType(inputStream.Length, Integer))
                    plainText = Encoding.Unicode.GetString(outputBuffer, 0, readBytes)
                End Using
            End Using
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        Return plainText
    End Function

#End Region

    Public Sub New()
        strMatrix = STR_VACIO
    End Sub
#Region "Valores Predeterminados"

    Public Function PrimerdiaDelMes(ByVal Fecha As Date) As Date
        Dim FechaResult As Date = Today
        FechaResult = DateSerial(Year(Fecha), Month(Fecha), 1)
        Return FechaResult
    End Function

    Public Function UltimodiaDelMes(ByVal Fecha As Date) As Date
        Dim FechaResult As Date = Today

        FechaResult = DateSerial(Year(Fecha), Month(Fecha) + 1, 0)
        'Select Case Fecha.Month
        '    Case 1, 3, 5, 7, 8, 10, 12
        '        FechaResult = "31/ " & Fecha.Month & "/" & Fecha.Year
        '    Case 4, 6, 9, 11
        '        FechaResult = "30/ " & Fecha.Month & "/" & Fecha.Year
        '    Case 2
        '        Select Case Fecha.Year
        '            Case 2012, 2016, 2020, 2024, 2028, 2032, 2036, 2040, 2044, 2048
        '                FechaResult = "29/ " & Fecha.Month & "/" & Fecha.Year
        '            Case Else
        '                FechaResult = "28/ " & Fecha.Month & "/" & Fecha.Year
        '        End Select

        'End Select
        Return FechaResult
    End Function

    Public Function ContaActiva() As Boolean

        Dim strSql As String = STR_VACIO
        Dim COM As New MySqlCommand
        Dim intEmpresa As Integer = INT_CERO
        MyCnn.CONECTAR = strConexion
        Try
            strSql = " SELECT id_empresa "
            strSql &= " FROM {base}.empresas "
            strSql &= "  Where id_empresa = {empresa}"

            strSql = Replace(strSql, "{empresa}", Sesion.IdEmpresa)
            strSql = Replace(strSql, "{base}", cFunciones.ContaEmpresa)

            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSql, CON)
            intEmpresa = COM.ExecuteScalar

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try

        If intEmpresa > 0 Then
            Return True
        Else
            Return False
        End If
    End Function


    Public Function Verificacion_Nuevo_Registro(ByVal iNumber As Long, ByVal sTable As String, Optional iCatalog As Integer = 0, Optional iYear As Integer = 0, Optional sSerie As String = vbNullString, Optional bSilent As Boolean = False, Optional guardar As Boolean = False) As Long
        Dim strSQL As String
        Dim intMax As Long
        Dim CON As MySqlConnection
        Dim COM As MySqlCommand

        strSQL = vbNullString
        Select Case sTable
            Case "TipoActivo"
                strSQL = "SELECT Codigo FROM Tipos_Activo WHERE Codigo = " & iNumber
            Case "TipoPoliza"
                strSQL = "SELECT pol_poliza FROM Tipos_Poliza WHERE pol_poliza = " & iNumber
            Case "Partidas"
                strSQL &= " SELECT           "
                strSQL &= "     par_numero   "
                strSQL &= " FROM             "
                strSQL &= "     Partidas_HDR "
                strSQL &= " WHERE            "
                strSQL &= "     par_numero = " & iNumber & " AND"
                strSQL &= "     par_sisemp = " & Sesion.IdEmpresa & " AND"
                strSQL &= "     par_ano    = " & MYSQL_AÑO("Acc_Year")
            Case "CtasBcos"
                If iNumber = NO_FILA Then
                    intMax = NuevoId("CtasBcos")
                    If bSilent Then
                        iNumber = intMax
                    ElseIf Not (intMax = NO_FILA) Then
                        If MsgBox("Código de cuenta #" & vbTab & intMax, vbInformation + vbOKCancel + vbDefaultButton2, "Nueva cuenta") = vbOK Then
                            iNumber = intMax
                        End If
                    End If
                End If
                strSQL = "Select BCta_Num FROM CtasBcos WHERE BCta_Num = " & iNumber
            Case "Clientes"
                strSQL = "Select cli_codigo FROM Clientes WHERE cli_sisemp=" & Sesion.IdEmpresa & " AND cli_codigo = " & iNumber
            Case "Proveedores"
                strSQL = "Select pro_codigo FROM Proveedores WHERE pro_sisemp=" & Sesion.IdEmpresa & " AND pro_codigo = " & iNumber
            Case "Articulos"
                strSQL &= " SELECT art_codigo FROM Articulos    "
                strSQL &= " WHERE art_sisemp = " & Sesion.IdEmpresa & "     "
                strSQL &= " AND art_codigo = " & iNumber
            Case "Inventarios"
                strSQL &= " SELECT inv_numero FROM Inventarios  "
                strSQL &= " WHERE inv_sisemp = " & Sesion.IdEmpresa & "     "
                strSQL &= " AND inv_numero = " & iNumber
            Case "Departamentos"
                strSQL = "SELECT dep_no FROM Departamentos WHERE dep_no = " & iNumber
            Case "Personal"
                strSQL &= " SELECT per_codigo FROM Personal     "
                strSQL &= " WHERE per_sisemp = " & Sesion.IdEmpresa & "     "
                strSQL &= " AND per_codigo = " & iNumber
            Case "Puestos"
                strSQL = "SELECT pue_codigo FROM Puestos WHERE pue_codigo = " & iNumber
            Case "Catalogos"
                If iCatalog = vbEmpty Then
                    strSQL = "SELECT cat_num FROM Catalogos WHERE cat_num = " & iNumber
                Else
                    MsgBox("ERR: No se reconoció el DCMTO solicitado.")
                End If
            Case "Dcmtos"
                If iNumber = NO_FILA Then
                    intMax = NuevoId(iCatalog, iYear)
                    If bSilent Then
                        iNumber = intMax
                    ElseIf Not (intMax = NO_FILA) Then
                        If guardar = True Then
                            If MsgBox("Año: " & vbTab & iYear & vbCr & "Número: " & vbTab & intMax & vbCr & vbCr & "¿Confirma el uso de este número de documento?", vbExclamation + vbYesNo + vbDefaultButton2, "Confirmar") = vbYes Then
                                iNumber = intMax
                            End If
                        Else
                            iNumber = intMax
                        End If
                    End If
                End If
                strSQL &= " SELECT HDoc_Doc_Num                     "
                strSQL &= " FROM Dcmtos_HDR                         "
                strSQL &= " WHERE HDOC_Sis_Emp = " & Sesion.IdEmpresa & " "
                strSQL &= "       AND HDoc_Doc_Cat = " & iCatalog & "   "
                strSQL &= "       AND HDoc_Doc_Ano = " & iYear & "      "
                strSQL &= "       AND HDoc_Doc_Num = " & iNumber
            Case Else
                MsgBox("ERR: No se reconoció la tabla solicitada: " & sTable)
        End Select

        If Not (iNumber > vbEmpty) Then
            Verificacion_Nuevo_Registro = NO_FILA
        Else
            Dim logEmpty As Boolean
            CON = New MySqlConnection(strConexion)
            CON.Open()
            Try
                COM = New MySqlCommand(strSQL, CON)
                logEmpty = COM.ExecuteScalar

                If logEmpty = False Then
                    Verificacion_Nuevo_Registro = iNumber
                Else
                    If MsgBox("El registro N° " & iNumber & " ya existe en el sistema." & vbCr & vbCr & _
                              "¿Desea asignar un número nuevo?", _
                               vbExclamation + vbYesNo + vbDefaultButton2, "Aviso") = vbNo Then
                    ElseIf sTable = "Catalogos" Then
                        Verificacion_Nuevo_Registro = NuevoId(iCatalog, iYear)
                    Else
                        Verificacion_Nuevo_Registro = NuevoId(iCatalog, iYear)
                    End If
                End If

            Catch ex As Exception
                MsgBox(ex.ToString)
            End Try

            Return Verificacion_Nuevo_Registro
            Exit Function

        End If
    End Function


    Public Function PaisDefault() As String

        PaisDefault = STR_VACIO
        Dim cCatalogo As New clsCatalogos
        Dim strCondicion As String = STR_VACIO
        strCondicion = "cat_clase = 'Paises' AND cat_sist = 'DEF_COUNTRY'"

        Try
            cCatalogo.CONEXION = strConexion
            If cCatalogo.Seleccionar(strCondicion, "cat_desc") = True Then
                PaisDefault = cCatalogo.CAT_DESC
            Else
                MsgBox(cCatalogo.MERROR.ToString)
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try

    End Function

    Public Function OficinasCentrales(Optional ByVal logNombre As Boolean = False) As String
        OficinasCentrales = STR_VACIO
        Dim strSql As String = STR_VACIO
        Dim strCampo As String = STR_VACIO
        Dim COM As New MySqlCommand
        MyCnn.CONECTAR = strConexion
        Try
            strSql = " SELECT {campo} FROM Empresas Where emp_no = " & Sesion.IdEmpresa
            If logNombre = True Then
                strCampo = "emp_razon"

            Else
                strCampo = "emp_domicilio"
            End If
            strSql = Replace(strSql, "{campo}", strCampo)
            COM = New MySqlCommand(strSql, CON)
            OficinasCentrales = COM.ExecuteScalar
        Catch ex As Exception
            MsgBox("FUNCION OFICINASCENTRALES" & ex.ToString)
        End Try
    End Function

    Public Function GetIdCatalgo(ByVal Id As String, Optional clave As String = vbNullString) As Integer
        Dim idCatalgo As Integer = -1
        Dim strSQL As String
        Dim COM As MySqlCommand
        strSQL = "SELECT cat_num FROM Catalogos WHERE cat_sist = '{id}'{clave}"
        strSQL = Replace(strSQL, "{id}", cFunciones.MyStr(Id))
        strSQL = Replace(strSQL, "{clave}", IIf(clave = vbNullString, vbNullString, " AND cat_clave={clave}"))
        strSQL = Replace(strSQL, "{clave}", cFunciones.MyStr(clave))
        MyCnn.CONECTAR = strConexion
        If MyCnn.ProbarConexiones = True Then
            COM = New MySqlCommand(strSQL, CON)
            idCatalgo = CInt(COM.ExecuteScalar)
            If idCatalgo = -1 And Not (Id = "(sin documento)") Then
                MsgBox("No se encontró el identificador: " & idCatalgo, vbExclamation, "Aviso")
            End If
        End If
        Return idCatalgo
    End Function

    Public Function AñoMySQL() As Integer
        Dim strSQL As String = STR_VACIO
        Dim intAño As Integer = INT_CERO
        Dim COM As New MySqlCommand

        strSQL = "Select " & MYSQL_AÑO

        Try

            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSQL, CON)
            intAño = CInt(COM.ExecuteScalar)

        Catch ex As Exception

            MsgBox("cFunciones.AñoMySQL" & ex.ToString)

        End Try

        Return intAño

    End Function

    Public Function HoyMySQL() As Date
        Dim strSQL As String = STR_VACIO
        Dim mysqlFecha As Date
        Dim COM As New MySqlCommand
        Dim conec As New MySqlConnection
        strSQL = "Select " & MYSQL_HOY
        Try
            'MyCnn.CONECTAR = strConexion
            conec = New MySqlConnection(strConexion)
            conec.Open()
            COM = New MySqlCommand(strSQL, conec)

            mysqlFecha = CDate(COM.ExecuteScalar)

            conec.Close()
            conec.Dispose()
            conec = Nothing

            Return mysqlFecha
        Catch ex As Exception
            MsgBox("cFunciones.AñoMySQL" & ex.ToString)
        End Try
        Return mysqlFecha
    End Function

    Public Function QuitarAcentos(cadena As String) As String
        Const conAcento As String = "áéíóúÁÉÍÓÚ"
        Const sinAcento As String = "aeiouAEIOU"

        For i = 1 To Len(conAcento)
            cadena = Replace(cadena, Mid(conAcento, i, 1), Mid(sinAcento, i, 1))
        Next

        Return cadena

    End Function

    Public Function NuevoId(ByVal idCatalogo As Integer, Optional ByVal año As Integer = 0) As Long
        Dim intId As Long = NO_FILA
        Dim strSQL As String = STR_VACIO
        Dim COM As New MySqlCommand

        strSQL = "SELECT (IFNULL(MAX(HDoc_Doc_Num),0)+1) ID FROM Dcmtos_HDR WHERE HDoc_Sis_Emp= {empresa}" &
            " AND HDoc_Doc_Cat = {cat}  "
        strSQL = Replace(strSQL, "{cat}", idCatalogo)
        strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
        If año = 0 Then
            If Not idCatalogo = 689 Or Not idCatalogo = 950 Then
                If idCatalogo = 220 Then 'Or idCatalogo = 389 Then
                    strSQL &= STR_VACIO
                Else
                    strSQL &= " AND HDoc_Doc_Ano = {año}"
                    strSQL = Replace(strSQL, "{año}", MYSQL_AÑO)
                End If
            End If

        Else
            strSQL &= " AND HDoc_Doc_Ano = {año}"
            strSQL = Replace(strSQL, "{año}", año)
        End If

        Try
            MyCnn.CONECTAR = strConexion
            If MyCnn.ProbarConexiones = True Then
                COM = New MySqlCommand(strSQL, CON)
                intId = CInt(COM.ExecuteScalar)
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        Return intId
    End Function

    Public Function TraerMoneda(ByVal codMoneda As Integer)
        Dim strSQL As String = strConexion
        Dim COM As New MySqlCommand
        Dim nomMoneda As String = STR_VACIO

        strSQL = "SELECT cat_clave " &
                 "FROM Catalogos " &
                 "WHERE cat_clase = 'Monedas' AND cat_num = {codmoneda} "

        strSQL = Replace(strSQL, "{codmoneda}", codMoneda)


        Try
            MyCnn.CONECTAR = strConexion

            If MyCnn.ProbarConexiones = True Then
                COM = New MySqlCommand(strSQL, CON)
                nomMoneda = COM.ExecuteScalar
            End If

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try

        Return nomMoneda

    End Function
    Public Function TraerNumero(ByVal año As Integer)
        Dim strSQL As String ' = strConexion
        Dim COM As New MySqlCommand
        Dim numRetencion As String = STR_VACIO

        strSQL = "SELECT CONCAT( c.cat_sist,'-',LPAD(CAST(RIGHT(MAX(d.HDoc_DR1_Num),8) AS UNSIGNED)+1,8,'0') ) AS 'HDoc_DR1_Num'
                    FROM Dcmtos_HDR d 
                        LEFT JOIN Catalogos c ON d.HDoc_Sis_Emp=c.cat_sisemp AND d.HDoc_DR2_cat=c.cat_num
                    WHERE c.cat_clase='Serie' AND c.cat_clave='Doc_RetenISR' and d.HDoc_Sis_Emp={empresa} AND d.HDoc_Doc_Cat=220 and d.HDoc_Doc_Ano={año} AND d.HDoc_Ant_Com=0"

        strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
        strSQL = Replace(strSQL, "{año}", año)



        Try
            MyCnn.CONECTAR = strConexion

            If MyCnn.ProbarConexiones = True Then
                COM = New MySqlCommand(strSQL, CON)
                numRetencion = COM.ExecuteScalar
            End If

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try

        Return numRetencion

    End Function
    Public Function Traer_Cat_Num_Ret(ByVal tipoDoc As String)
        Dim strSQL As String ' = strConexion
        Dim COM As New MySqlCommand
        Dim numRetencion As String = STR_VACIO

        strSQL = "SELECT cat_num FROM Catalogos WHERE cat_sisemp={empresa} AND cat_clase='Serie' AND cat_clave='{tipo}' AND cat_pid=0"

        strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
        strSQL = Replace(strSQL, "{tipo}", tipoDoc)

        Try
            MyCnn.CONECTAR = strConexion

            If MyCnn.ProbarConexiones = True Then
                COM = New MySqlCommand(strSQL, CON)
                numRetencion = COM.ExecuteScalar
            End If

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try

        Return numRetencion

    End Function
    Public Function NuevoIdCatalogo() As Integer
        Dim strSQL As String = STR_VACIO
        Dim COM As New MySqlCommand
        Dim intId As Long = NO_FILA

        strSQL = "Select MAX(cat_num) From Catalogos"
        Try
            MyCnn.CONECTAR = strConexion
            If MyCnn.ProbarConexiones = True Then
                COM = New MySqlCommand(strSQL, CON)
                intId = CInt(COM.ExecuteScalar) + 1
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        Return intId

    End Function

    Public Function MonedaDefault(ByVal sMonedas As Monedas) As Integer
        Dim sql As String = STR_VACIO
        Dim COMAND As New MySqlCommand
        Dim intLocal As Integer = NO_FILA
        Dim conex As MySqlConnection

        sql = " SELECT cat_clave
                    FROM Catalogos
                WHERE cat_clase = 'Defaults' and cat_sist = {moneda}"

        If sMonedas = 0 Then
            sql = Replace(sql, "{moneda}", "'CUR_LOC'")
        Else
            sql = Replace(sql, "{moneda}", "'CUR_EXT'")
        End If

        Try
            conex = New MySqlConnection(strConexion)
            conex.Open()
            If MyCnn.ProbarConexiones = True Then
                COMAND = New MySqlCommand(sql, conex)
                intLocal = COMAND.ExecuteScalar
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        conex.Close()
        conex.Dispose()
        conex = Nothing
        System.GC.Collect()

        Return intLocal
    End Function

    Public Function SimboloMoneda(ByVal intIdMoneda As Integer) As String
        Dim simbolo As String = STR_VACIO
        Dim strCondicion As String = STR_VACIO

        strCondicion = "cat_num = " & intIdMoneda
        Dim cCat As New clsCatalogos
        Try
            If cCat.Seleccionar(strCondicion, "cat_clave") Then
                simbolo = cCat.CAT_CLAVE
            Else
                MsgBox(cCat.MERROR.ToString)
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        Finally
            cCat.Dispose()
            cCat = Nothing
            System.GC.Collect()
        End Try
        Return simbolo
    End Function

    Public Function SQLSubDocumentos(ByVal catalogo As Integer, ByVal ano As Integer, ByVal numero As Integer) As String
        Dim strSQL As String = STR_VACIO

        strSQL = strSQL & " select cc.cat_clave, cc.cat_desc, "
        strSQL = strSQL & "     if((SELECT COUNT(*) "
        strSQL = strSQL & "     FROM Dcmtos_ACC "
        strSQL = strSQL & "     WHERE ADoc_Sis_Emp = {empresa} AND ADoc_Doc_Cat = c.cat_num AND ADoc_Doc_Ano = {ano} AND ADoc_Doc_Num = {numero} AND ADoc_Doc_Sub = cc.cat_clave)>0,'YES','NO') Cantidad "
        strSQL = strSQL & " from Catalogos c "
        strSQL = strSQL & " left join Catalogos cc on cc.cat_clase ='SubDcmtos' and cc. cat_sist = c.cat_sist  AND (cc.cat_sisemp IN (0,{empresa})) "
        strSQL = strSQL & " where c.cat_num = {catalogo} "

        strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
        strSQL = Replace(strSQL, "{ano}", ano)
        strSQL = Replace(strSQL, "{catalogo}", catalogo)
        strSQL = Replace(strSQL, "{numero}", numero)

        Return strSQL
    End Function

#End Region

#Region "Conversiones"
    Public Function SegundosHoras(ByVal intsegundos As Long) As String
        Dim hor As Integer = NO_FILA
        Dim min As Integer = NO_FILA
        Dim seg As Integer = NO_FILA
        hor = Math.Floor(intsegundos / 3600)
        min = Math.Floor((intsegundos - hor * 3600) / 60)
        seg = intsegundos - (hor * 3600 + min * 60)
        Return Trim(hor) + " : " + Trim(min) + " : " + Trim(seg)
    End Function

    Public Function ExterioLocal(ByVal Cantidad As Double) As Double
        ExterioLocal = INT_CERO
        Dim strSQL As String = STR_VACIO
        Dim COM As MySqlCommand
        Dim dblTCambio As Double = INT_CERO
        strSQL = "select Tasa From TCambio where Fecha= now()"
        Try
            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSQL, CON)
            dblTCambio = CDbl(COM.ExecuteScalar)
            ExterioLocal = Cantidad * dblTCambio
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Function

#End Region

#Region "Controles"

    ' Validacion de caraccteres especiales 

    Public Function ValidarCaracteresEspeciales(ByVal texto As String) As String
        Dim strResultado As String = texto
        Try
            strResultado = strResultado.Replace("'", STR_VACIO) ' comilla simprle
            strResultado = strResultado.Replace(Chr(34), STR_VACIO) ' comilla doble
            strResultado = strResultado.Replace("|", STR_VACIO) ' pipe
            strResultado = strResultado.Replace("&", "y") 'amperson
            strResultado = strResultado.Replace("%", STR_VACIO) 'dolar
            strResultado = strResultado.Replace("#", " No. ") ' Numeral
            strResultado = strResultado.Replace("%", STR_VACIO) 'porcentaje
            strResultado = strResultado.Replace("@", STR_VACIO) ' arroba

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        Return strResultado
    End Function

    'Private Const blanco As Color = Color.White
    Public Sub ValidarFilaGrid(ByRef ListaGrid As DataGridView, ByVal strColumna As String)
        Try
            For i As Integer = 0 To ListaGrid.Rows.Count - 1
                If CStr(ListaGrid.Rows(i).Cells(strColumna).Value) = STR_VACIO Then
                    ListaGrid.Rows(i).Cells(strColumna).Value = Format(INT_CERO, FORMATO_MONEDA)
                ElseIf Not IsNumeric(ListaGrid.Rows(i).Cells(strColumna).Value) Then
                    MsgBox("El valor debe ser numérico")
                    ListaGrid.Rows(i).Cells(strColumna).Value = Format(INT_CERO, FORMATO_MONEDA)
                End If
            Next
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Public Function ValidarFecha(ByVal strFecha As String) As Boolean
        Dim logResultado As Boolean = False
        If IsDate(strFecha) Then
            logResultado = True
        End If

        Return logResultado

    End Function

Public Sub AgregarFila(ByRef Lista As DataGridView, ByVal strFila As String, Optional ByVal color As System.Drawing.Color = Nothing)

        Dim Celda As New DataGridViewTextBoxCell
        Dim Fila As New DataGridViewRow
        Dim arrayFila() As String
        Try
            If color = Nothing Then
                color = Drawing.Color.White
            End If
            arrayFila = strFila.Split("|".ToCharArray)


            For i = 0 To arrayFila.Length - 1



                Celda = New DataGridViewTextBoxCell
                Celda.Value = arrayFila(i)

                Celda.Style.BackColor = color

                Fila.Cells.Add(Celda)
            Next

            Lista.Rows.Add(Fila)

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try

    End Sub



    Public Sub ValidadarLongitudTextBox(ByRef txt As TextBox, ByVal intLongitud As Integer)

        txt.MaxLength = intLongitud
        If txt.Text.Length >= intLongitud Then
            MsgBox("Solo puede ingresar un máximo de " & intLongitud & " caracteres.")
        End If

    End Sub

    Public Function ValidarCampoNumerico(ByRef TxTCampo As TextBox) As Boolean

        If Not IsNumeric(TxTCampo.Text) Then
            TxTCampo.BackColor = Color.Coral
            MsgBox("Ingrese un valor numérico")
            TxTCampo.Text = "0.00"
            TxTCampo.Focus()
            ValidarCampoNumerico = False
        Else
            TxTCampo.BackColor = Color.White
            ValidarCampoNumerico = True
        End If

    End Function

    Public Function ValidarCampoTexto(ByRef TxtCampo As TextBox, Optional ByVal intLongitud As Integer = 32000) As Boolean

        TxtCampo.MaxLength = intLongitud
        If TxtCampo.Text.Length <= 0 Or TxtCampo.Text.Length >= intLongitud Then
            If TxtCampo.Text.Length >= intLongitud Then
                MsgBox("Solo puede ingresar un máximo de " & intLongitud & " caracteres.")
            End If
            TxtCampo.BackColor = Color.Coral
            ValidarCampoTexto = False
        Else
            TxtCampo.BackColor = Color.White
            ValidarCampoTexto = True
        End If

    End Function

    Public Function ValidarCombo(ByRef Combo As ComboBox) As Boolean

        If Combo.SelectedIndex = NO_FILA Then
            Combo.BackColor = Color.Coral
            Return False
        Else
            Combo.BackColor = Color.White
            Return True
        End If

    End Function

    Public Sub CargarLista(ByRef lista As DataGridView, ByVal strSQL As String, Optional ByVal ADD As Boolean = False, Optional ByVal FCompra As Boolean = False)

        Dim COM As New MySqlCommand
        Dim DAR As MySqlDataAdapter
        Dim dataTable As New System.Data.DataTable

        Try
            MyCnn.CONECTAR = strConexion
            If MyCnn.ProbarConexiones = True Then

                COM = New MySqlCommand(strSQL, CON)
                COM.CommandType = CommandType.Text
                DAR = New MySqlDataAdapter(COM)
                DAR.Fill(dataTable)

                'If ADD = False Then
                '    lista.DataSource = Nothing
                '    lista.Refresh()
                'End If

                lista.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.AllCells
                lista.DataSource = dataTable
                lista.RowsDefaultCellStyle.BackColor = Color.White
                lista.AlternatingRowsDefaultCellStyle.BackColor = Color.AliceBlue

            End If
            If lista.Columns.Count > 2 Then

                If lista.Columns("idRubroOcultar") Is Nothing Then
                Else
                    lista.Columns("idRubroOcultar").Visible = False
                End If
                If lista.Columns("dCuentaAfectarOcultar") Is Nothing Then
                Else
                    lista.Columns("dCuentaAfectarOcultar").Visible = False
                End If

            End If
            'If lista.Columns(4).Name = "idCuentaAfectarOcultar" Then
            'lista.Columns(4).Visible = False
            'End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try

    End Sub


    Public Sub CargarCombo(ByRef Combo As ComboBox, ByVal strTabla As String, ByVal strItem As String, ByVal strId As String, ByVal strCondicion As String)
        Dim strSQL As String = ""
        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader
        strSQL = "SELECT {codigo} ID, {item} Descripcion FROM {tabla} WHERE {condicion} ORDER BY {item}"
        strSQL = Replace(strSQL, "{codigo}", strId)
        strSQL = Replace(strSQL, "{item}", strItem)
        strSQL = Replace(strSQL, "{tabla}", strTabla)
        strSQL = Replace(strSQL, "{condicion}", strCondicion)
        Combo.BackColor = Color.Coral
        Try
            MyCnn.CONECTAR = strConexion
            If MyCnn.ProbarConexiones = True Then
                COM = New MySqlCommand(strSQL, CON)
                REA = COM.ExecuteReader
                If REA.HasRows = False Then
                    Exit Sub
                End If
                Combo.Items.Clear()
                Do While REA.Read
                    Combo.Items.Add(New clsItemData(REA.GetString("Descripcion"), REA.GetInt32("ID")))
                Loop
                Combo.SelectedIndex = 0
                Combo.BackColor = Color.White
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try

    End Sub

    'Public Sub BuscarenLista(ByRef lista As DataGridView)
    '    Try


    '        Dim contador As Integer = INT_CERO
    '        Dim intInicio As Integer = 0

    '        strBusquedaLista = InputBox("Enter the Data to Search", "Seeker", strBusquedaLista)
    '        If strBusquedaLista.Length = 0 Then
    '            Exit Sub
    '        End If

    '        For i As Integer = CInt(lista.CurrentRow.Index + 1) To lista.Rows.Count - 1
    '            contador = contador + 1
    '            For j As Integer = 0 To CInt(lista.Columns.Count - 1)
    '                If lista.Rows(i).Cells(j).Value = Nothing Then

    '                Else
    '                    'If (strBusqueda Like "?[" & DataGridView1.Rows(i).Cells(j).Value.ToString & "]") = True Then
    '                    If InStr(lista.Rows(i).Cells(j).Value.ToString, strBusquedaLista, CompareMethod.Text) > 0 Then
    '                        lista.CurrentCell = lista(j, i)
    '                        Exit Sub

    '                    End If
    '                End If
    '            Next

    '        Next

    '        For i As Integer = CInt(0) To lista.Rows.Count - 1
    '            contador = contador + 1
    '            For j As Integer = 0 To CInt(lista.Columns.Count - 1)

    '                ' If (strBusqueda Like "?[" & DataGridView1.Rows(i).Cells(j).Value.ToString & "]") = True Then
    '                If InStr(lista.Rows(i).Cells(j).Value.ToString, strBusquedaLista, CompareMethod.Text) > 0 Then
    '                    lista.CurrentCell = lista(j, i)
    '                    Exit Sub
    '                End If
    '            Next

    '        Next
    '        MsgBox("Not Found")
    '    Catch ex As Exception
    '        MsgBox(ex.ToString)
    '    End Try
    'End Sub

    Public Sub BuscarenLista(ByRef lista As DataGridView)

        Dim contador As Integer = INT_CERO
        Dim intInicio As Integer = 0

        strBusquedaLista = InputBox("ingresa algo para buscar", "buscador", strBusquedaLista)


        For i As Integer = CInt(lista.CurrentRow.Index + 1) To lista.Rows.Count - 1
            contador = contador + 1
            For j As Integer = 0 To CInt(lista.Columns.Count - 1)

                ' If (strBusqueda Like "?[" & DataGridView1.Rows(i).Cells(j).Value.ToString & "]") = True Then
                If InStr(lista.Rows(i).Cells(j).Value.ToString, strBusquedaLista, CompareMethod.Text) > 0 Then
                    If lista.Columns(j).Visible = True Then
                        lista.CurrentCell = lista(j, i)
                        Exit Sub
                    End If
                    

                End If
            Next

        Next


        For i As Integer = CInt(0) To lista.Rows.Count - 1
            contador = contador + 1
            For j As Integer = 0 To CInt(lista.Columns.Count - 1)

                ' If (strBusqueda Like "?[" & DataGridView1.Rows(i).Cells(j).Value.ToString & "]") = True Then
                If InStr(lista.Rows(i).Cells(j).Value.ToString, strBusquedaLista, CompareMethod.Text) > 0 Then
                    lista.CurrentCell = lista(j, i)
                    Exit Sub

                End If
            Next

        Next
        MsgBox("Not Found")
    End Sub

#End Region

#Region "Archivos"

    Public Function ArchivoTemporal(Optional ByVal name As String = "") As String
        Dim strTemp As String
        Dim strDir As String
        strDir = System.IO.Path.GetTempPath
        'strTemp = System.IO.Path.GetTempFileName
        'MsgBox(strDir & vbNewLine & strTemp)

        Dim timestamp As String = DateTime.Now.ToString("yyyyMMdd_HHmmss")

        If String.IsNullOrEmpty(name) Then
            ' Crear archivo temporal con nombre generado automáticamente
            strTemp = System.IO.Path.GetTempFileName()
        Else
            ' Crear ruta con nombre personalizado
            strTemp = System.IO.Path.Combine(strDir, name & "_" & timestamp)
            ' Crear el archivo vacío si no existe
            If Not System.IO.File.Exists(strTemp) Then
                System.IO.File.Create(strTemp).Close()
            End If
        End If

        Return strTemp

    End Function

    Public Function AbrirArchivo(strPath) As Boolean
        AbrirArchivo = False
        If cFunciones.ExisteArchivo(strPath) = True Then
            Try
                Process.Start(strPath)
                AbrirArchivo = True
            Catch ex As Exception
                MsgBox(ex.Message, , "Error al Abrir")
            End Try
        End If
    End Function

    Public Function WordBuscaryReemplazar2(ByVal strPath As String) As Boolean
        Dim srtBusqueda As String
        Dim strReemplazo As Object
        Dim strlinea() As String
        Dim arraybusqueda() As String
        strlinea = strMatrix.Split("|".ToCharArray)
        WordBuscaryReemplazar2 = False

        Dim WordApp As New Word.Application
        Dim WordDoc As New Word.Document
        Try
            If ExisteArchivo(strPath) Then
                WordDoc = WordApp.Documents.Open(strPath)
                WordDoc.Activate()
                WordApp.Visible = False
                WordApp.Selection.Find.ClearFormatting()
                WordApp.Selection.Find.Replacement.ClearFormatting()
                For i As Integer = 0 To strlinea.Length - 2
                    arraybusqueda = strlinea(i).Split(">".ToCharArray)
                    srtBusqueda = arraybusqueda(0)
                    strReemplazo = arraybusqueda(1)
                    Debug.WriteLine("////// " & srtBusqueda & strReemplazo.Length)
                    With WordApp.Selection.Find
                        .Text = srtBusqueda
                        .Replacement.Text = strReemplazo 'Error por el tamanio de string
                        .Forward = True
                        .Wrap = Word.WdFindWrap.wdFindAsk
                        .Format = False
                        .MatchCase = False
                        .MatchWholeWord = False
                        .MatchWildcards = False

                        .MatchSoundsLike = False
                        .MatchAllWordForms = False
                    End With
                    WordApp.Selection.Find.Execute(Replace:=2)
                Next
                WordBuscaryReemplazar2 = True
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        Finally
            WordDoc.Close()
            WordApp.Quit()
            WordDoc = Nothing
            WordApp = Nothing
        End Try
        AbrirArchivo(strPath)
    End Function

    Public Function WordBuscaryReemplazar(ByVal strPath As String) As Boolean
        Dim srtBusqueda As String
        Dim strReemplazo As String
        Dim strlinea() As String
        Dim arraybusqueda() As String
        strlinea = strMatrix.Split("|"c)
        WordBuscaryReemplazar = False

        Dim WordApp As New Microsoft.Office.Interop.Word.Application
        Dim WordDoc As Microsoft.Office.Interop.Word.Document = Nothing

        Try
            If ExisteArchivo(strPath) Then
                WordDoc = WordApp.Documents.Open(strPath)
                WordApp.Visible = False

                For i As Integer = 0 To strlinea.Length - 2
                    arraybusqueda = strlinea(i).Split(">"c)
                    If arraybusqueda.Length < 2 Then Continue For

                    srtBusqueda = arraybusqueda(0)
                    strReemplazo = arraybusqueda(1)

                    Dim rng As Microsoft.Office.Interop.Word.Range = WordDoc.Content
                    rng.Find.ClearFormatting()
                    rng.Find.Replacement.ClearFormatting()

                    With rng.Find
                        .Text = srtBusqueda
                        .Forward = True
                        .Wrap = Microsoft.Office.Interop.Word.WdFindWrap.wdFindStop
                        .Format = False
                        .MatchCase = False
                        .MatchWholeWord = False
                        .MatchWildcards = False
                    End With

                    Do While rng.Find.Execute()
                        ' Guardar la posición actual antes de reemplazar
                        Dim startPos As Integer = rng.Start
                        Dim newRange As Microsoft.Office.Interop.Word.Range = WordDoc.Range(Start:=startPos, End:=rng.End)
                        newRange.Text = strReemplazo

                        ' Mover el rango para continuar después del reemplazo
                        rng.Start = startPos + strReemplazo.Length
                        rng.End = WordDoc.Content.End
                    Loop
                Next

                WordDoc.Save()
                WordBuscaryReemplazar = True
            End If
        Catch ex As Exception
            MsgBox("Error: " & ex.Message)
        Finally
            If Not WordDoc Is Nothing Then WordDoc.Close(False)
            WordApp.Quit()
            WordDoc = Nothing
            WordApp = Nothing
        End Try

        AbrirArchivo(strPath)
    End Function

    Public Function ExisteArchivo(ByVal strPath As String) As Boolean
        ExisteArchivo = False
        Try
            If System.IO.File.Exists(strPath) = True Then
                ExisteArchivo = True
            Else
                MsgBox("El archivo no existe")
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Function

    Public Function CopiarArchivo(ByVal strArchivoOrigen As String, Optional ByVal strArchivoDefault As String = "NuevoArchivo", Optional ByVal strExtDefaul As String = ".docx", Optional ByVal strFiltro As String = "Word documents (.docx)|*.docx")
        CopiarArchivo = STR_VACIO
        Dim DialogoGuardar As New SaveFileDialog
        DialogoGuardar.FileName = strArchivoDefault
        DialogoGuardar.DefaultExt = strExtDefaul
        DialogoGuardar.Filter = strFiltro
        Dim strOrigen As String = System.Windows.Forms.Application.StartupPath & "\" & strArchivoOrigen
        Dim logResultado As Boolean = DialogoGuardar.ShowDialog()
        If logResultado = True Then
            If cFunciones.ExisteArchivo(strOrigen) = True Then
                Dim strDestino As String = DialogoGuardar.FileName
                Try
                    System.IO.File.Copy(strOrigen, strDestino, True)
                    CopiarArchivo = strDestino
                Catch ex As Exception
                    MsgBox(ex.Message, , "Error al copiar")
                End Try
            End If
        End If
    End Function

#End Region

#Region "Funciones"


    Public Function MaximoTranferencia(ByVal catalogo As Integer, ByVal conexion As String, ByVal Empresa As Integer) As Integer

        Dim strSQL As String = ""
        Dim COM As MySqlCommand
        Dim CON As MySqlConnection
        Dim Año As Integer = 0
        Dim ValorT As Integer = 0

        Año = AñoMySQL()

        strSQL = "SELECT IFNULL(MAX(HDoc_Doc_Num),0)+1  Numero " & _
                 "FROM Dcmtos_HDR " & _
                 "WHERE HDoc_Sis_Emp = {empresa} AND HDoc_Doc_Cat = {catalogo}  "

        strSQL = Replace(strSQL, "{empresa}", Empresa)
        strSQL = Replace(strSQL, "{año}", Año)


        Select Case catalogo

            Case 127
                strSQL = Replace(strSQL, "{catalogo}", catalogo)


            Case 55
                strSQL = Replace(strSQL, "{catalogo}", catalogo)


            Case 180
                strSQL = Replace(strSQL, "{catalogo}", catalogo)

            Case 47
                strSQL = Replace(strSQL, "{catalogo}", catalogo)

        End Select

        CON = New MySqlConnection(conexion)
        CON.Open()

        Try
            COM = New MySqlCommand(strSQL, CON)
            ValorT = COM.ExecuteScalar()

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try


        CON.Close()

        Return ValorT

    End Function

    Public Function Mysqldatenet(ByVal fecha As MySqlDateTime) As Date
        Dim fechanet As Date

        Return fechanet
    End Function


    Public Function DivisaLocal() As Integer
        Dim Local As String = STR_VACIO
        Dim COML As MySqlCommand
        Dim CON1 As MySqlConnection
        Dim valorLocal As String = STR_VACIO

        CON1 = New MySqlConnection(strConexion)
        CON1.Open()

        Local = "SELECT Cat_Clave " &
                "FROM Catalogos " &
                "WHERE cat_num in (434)"

        Try
            COML = New MySqlCommand(Local, CON1)
            valorLocal = COML.ExecuteScalar
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try

        CON1.Close()

        Return valorLocal

    End Function


    Public Function DivisaExtranjera() As Integer
        Dim Extrangera As String = STR_VACIO
        Dim COME As MySqlCommand
        Dim CON1 As MySqlConnection
        Dim valorExtranjero As String = STR_VACIO

        CON1 = New MySqlConnection(strConexion)
        CON1.Open()

        Extrangera = " SELECT Cat_Clave " & _
                "FROM Catalogos " & _
                "WHERE cat_num in (433)"
        Try
            COME = New MySqlCommand(Extrangera, CON1)
            valorExtranjero = COME.ExecuteScalar
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try

        CON1.Close()

        Return valorExtranjero

    End Function
    Public Function QueryTasa(Optional ByVal fecha As String = STR_VACIO) As Double
        Dim strSQL As String = STR_VACIO
        Dim strSQL10 As String = STR_VACIO
        'Dim COME As MySqlCommand
        'Dim CON1 As MySqlConnection
        Dim COM As MySqlCommand
        Dim conec As MySqlConnection
        'CON1 = New MySqlConnection(strConexion)
        'CON1.Open()
        Dim cambio As Double
        'Dim cambio2 As Double
        Dim tasa As Double
        Try
            'strSQL &= "SELECT Tasa FROM TCambio WHERE Fecha ={fecha}  AND Local= {local} AND Exterior={extranjero}"

            'strSQL = Replace(strSQL, "{fecha}", fecha)
            'strSQL = Replace(strSQL, "{local}", DivisaLocal)
            'strSQL = Replace(strSQL, "{extranjero}", DivisaExtranjera)

            'COME = New MySqlCommand(strSQL, CON1)
            'cambio = COME.ExecuteScalar

            'If cambio = 0.0 Then
            strSQL10 &= " SELECT cat_sist tasa"
            strSQL10 &= "      FROM Catalogos c"
            strSQL10 &= "              WHERE c.cat_num = 178 AND c.cat_clase = 'Monedas'"

            strSQL10 = Replace(strSQL10, "{id}", DivisaLocal)

            conec = New MySqlConnection(strConexion)
            conec.Open()
            COM = New MySqlCommand(strSQL10, conec)
            cambio = COM.ExecuteScalar
            conec.Close()

            tasa = cambio
            'Else
            'tasa = cambio
            'End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        Return tasa
    End Function

    Public Function MesALetras(ByVal intMes As Integer) As String
        Select Case intMes
            Case 1 : MesALetras = "Enero"
            Case 2 : MesALetras = "Febrero"
            Case 3 : MesALetras = "Marzo"
            Case 4 : MesALetras = "Abril"
            Case 5 : MesALetras = "Mayo"
            Case 6 : MesALetras = "Junio"
            Case 7 : MesALetras = "Julio"
            Case 8 : MesALetras = "Agosto"
            Case 9 : MesALetras = "Septiembre"
            Case 10 : MesALetras = "Octubre"
            Case 11 : MesALetras = "Noviembre"
            Case 12 : MesALetras = "Diciembre"
            Case Else : MesALetras = "Mes no válido"
        End Select
    End Function


    'Convierte un mes en español a ingles
    Public Function MesIngles(ByVal Mes As Integer)
        Dim arrayMes As Array
        Dim mesletras As String
        Dim MesEnIngles As String = ""

        mesletras = "January,February,March,April,May,June,July,August,September,October,November,December"

        arrayMes = mesletras.Split(",".ToCharArray)
        For i As Integer = 0 To Mes - 1
            MesEnIngles = arrayMes(i)
        Next

        Return MesEnIngles
    End Function

    Public Sub LimpiarParametros()
        strMatrix = STR_VACIO
    End Sub

    Public Sub AgregarParametro(ByVal strBusqueda As String, ByVal strReemplazo As String)
        strBusqueda = Replace(strBusqueda, "|", ".")
        strBusqueda = Replace(strBusqueda, ">", ".")
        strReemplazo = Replace(strReemplazo, "|", ".")
        strReemplazo = Replace(strReemplazo, ">", ".")
        strMatrix &= strBusqueda & ">" & strReemplazo & "|"
    End Sub

    Public Function MyStr(ByVal data As String) As String
        data = Replace(data, "\", "\\")
        data = Replace(data, "&", " y ")
        data = Replace(data, "|", " / ")
        data = Replace(data, vbNullChar, "\0")
        data = Replace(data, "'", "\'")
        data = Replace(data, """", "\""")
        data = Replace(data, vbBack, "\b")
        data = Replace(data, vbLf, "\n")
        data = Replace(data, vbCr, "\r")
        data = Replace(data, vbTab, "\t")
        data = Replace(data, Space(2), Space(1))

        Return Trim(data)
    End Function

    Public Function ObtenerIPoEquipo(ByVal IoE As IpEquipo) As String
        Dim nombrePC As String
        Dim entradasIP As Net.IPHostEntry
        nombrePC = Net.Dns.GetHostName
        entradasIP = Net.Dns.GetHostByName(nombrePC)
        Dim direccion_Ip As String = entradasIP.AddressList(0).ToString
        If IoE = IpEquipo.ip Then
            Return direccion_Ip
        ElseIf IoE = IpEquipo.equipo Then
            Return nombrePC
        Else
            MsgBox("Parametro inválido")
            Return vbNull
        End If


    End Function

    Public Function SrtingToDouble(ByVal numero As String) As Double
        Dim doble As Double = vbNull
        Return doble
    End Function

    Public Sub EscribirRegistro(ByVal Tabla As String, ByVal Accion As AccEnum, Optional Codigo As Long = vbEmpty, Optional Catalogo As Integer = vbEmpty, Optional Año As String = STR_VACIO, Optional Numero As Long = vbEmpty, Optional Notas As String = vbNullString, Optional Info As Boolean = False)
        Dim COM As MySqlCommand
        Dim strAccion As String = ""
        Dim strSql As String = ""
        Select Case Accion
            Case AccEnum.acAdd
                strAccion = "AGREGAR"
            Case AccEnum.acDelete
                strAccion = "BORRAR"
            Case AccEnum.acUpdate
                strAccion = "MODIFICAR"
            Case AccEnum.acPrint
                strAccion = "IMPRIMIR"
            Case AccEnum.acCorrect
                strAccion = "CORREGIR"
            Case AccEnum.acConfirm
                strAccion = "CONFIRMAR"
            Case AccEnum.acUnlock
                strAccion = "LIBERAR"
            Case AccEnum.acPoliza
                strAccion = "POLIZA"
            Case AccEnum.acCarga
                strAccion = "CARGA"
            Case AccEnum.acLiberar
                strAccion = "LIBERAR"
            Case AccEnum.acSalida
                strAccion = "SALIDA"
            Case AccEnum.acGeneraYRM
                strAccion = "GENERAR YRM"
            Case Else
                strAccion = "N/A"
        End Select
        If Año = STR_VACIO Then
            Año = INT_CERO
        End If
        strSql = "INSERT INTO Registro Values ({idregistro},{idempresa},{idusuario},'{usuario}',{fecha},'{tabla}', {codigo},{catalogo},{ano},{numero},'{accion}','{notas}');"
        If Sesion.IdEmpresa = 18 Then
            strSql = String.Concat(strSql, "INSERT INTO PDM.Registro Values ({idregistro},{idempresa},{idusuario},'{usuario}',{fecha},'{tabla}', {codigo},{catalogo},{ano},{numero},'{accion}','{notas}');")
        End If
        strSql = Replace(strSql, "{idregistro}", 0)
        strSql = Replace(strSql, "{idempresa}", Sesion.IdEmpresa)
        strSql = Replace(strSql, "{idusuario}", Sesion.idUsuario)
        strSql = Replace(strSql, "{usuario}", Sesion.Usuario)
        strSql = Replace(strSql, "{fecha}", "now()")
        strSql = Replace(strSql, "{tabla}", Tabla)
        strSql = Replace(strSql, "{codigo}", Codigo)
        strSql = Replace(strSql, "{catalogo}", Catalogo)
        strSql = Replace(strSql, "{ano}", Año)
        strSql = Replace(strSql, "{numero}", Numero)
        strSql = Replace(strSql, "{accion}", strAccion)
        strSql = Replace(strSql, "{notas}", Notas)
        Try
            MyCnn.CONECTAR = strConexion
            If MyCnn.ProbarConexiones = True Then
                COM = New MySqlCommand(strSql, CON)
                COM.ExecuteNonQuery()
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try

        Try
            'If Catalogo = 75 And Info = True And strAccion.Then Then

            'End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try

    End Sub

    Public Function ContaEmpresa() As String

        Dim CON As MySqlConnection
        Dim COM As MySqlCommand
        Dim conta As String = STR_VACIO
        Dim strSQL As String = STR_VACIO


        strSQL = "SELECT cat_sist " &
                 "FROM Catalogos ca " &
                 "Where ca.cat_num = 18 "

        CON = New MySqlConnection(strConexion)
        CON.Open()


        Try

            COM = New MySqlCommand(strSQL, CON)
            conta = COM.ExecuteScalar

        Catch ex As Exception

            MsgBox(ex.ToString)

        End Try

        CON.Close()

        Return conta

    End Function
    Public Function nombreCompleto_usuario(id As Integer) As String

        Dim CON As MySqlConnection
        Dim COM As MySqlCommand
        Dim conta As String = STR_VACIO
        Dim strSQL As String = STR_VACIO


        strSQL = "SELECT  CONCAT(per_nombre1,' ', per_apellido1) nombre FROM Personal WHERE per_codigo=" & id & " AND per_sisemp=" & Sesion.IdEmpresa

        CON = New MySqlConnection(strConexion)
        CON.Open()

        Try
            COM = New MySqlCommand(strSQL, CON)
            conta = COM.ExecuteScalar
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try

        CON.Close()
        Return conta

    End Function

#Region "Kardex Producto en Proceso"
    Public Function Kardex_PProceso(ByVal Cat As Integer, ByVal Anio As Integer, ByVal Num As String) As String
        Dim strsql_Kardex As String = STR_VACIO
        'Dim COM_K As MySqlCommand
        Try

            strsql_Kardex = " SELECT k.Kar_Committed Cantidad, k.Kar_Phy_Inc Total, k.Kar_Cost_Ext Cprom
                            FROM Kardex k 
                            WHERE k.Kar_Sis_Emp = {emp} AND k.Kar_Doc_Cat IN(952,47) AND k.Kar_PO_Cat = {cat} AND k.Kar_PO_Ano = {anio} AND k.Kar_PO_Num = {num} AND k.Kar_Opr_Fec <= '{fecha}'
                             ORDER BY k.Kar_TransId DESC 
                            LIMIT 1 "

            strsql_Kardex = Replace(strsql_Kardex, "{emp}", Sesion.IdEmpresa)
            strsql_Kardex = Replace(strsql_Kardex, "{cat}", Cat)
            strsql_Kardex = Replace(strsql_Kardex, "{anio}", Anio)
            strsql_Kardex = Replace(strsql_Kardex, "{num}", Num)
            strsql_Kardex = Replace(strsql_Kardex, "{fecha}", Now().ToString(FORMATO_MYSQL))
        Catch ex As Exception

        End Try
        Return strsql_Kardex
    End Function

    Public Function Kardex_DatosIngresoEliminado(ByVal Cat As Integer, ByVal Anio As Integer, ByVal Num As String, ByVal linea As Integer) As String
        Dim strsql_Kardex As String = STR_VACIO
        'Dim COM_K As MySqlCommand
        Try

            strsql_Kardex = " SELECT k.Kar_Committed Cantidad, k.Kar_Phy_Inc Total, k.Kar_Cost_Ext Cprom
                            FROM Kardex k 
                            WHERE k.Kar_Sis_Emp = {emp} AND k.Kar_Doc_Cat= {cat} AND k.Kar_Doc_Ano = {anio} AND k.Kar_Doc_Num = {num} AND k.Kar_Doc_Lin = {linea} 
                            ORDER BY k.Kar_TransId DESC
                            LIMIT 1"

            strsql_Kardex = Replace(strsql_Kardex, "{emp}", Sesion.IdEmpresa)
            strsql_Kardex = Replace(strsql_Kardex, "{cat}", Cat)
            strsql_Kardex = Replace(strsql_Kardex, "{anio}", Anio)
            strsql_Kardex = Replace(strsql_Kardex, "{num}", Num)
            strsql_Kardex = Replace(strsql_Kardex, "{linea}", linea)
            'strsql_Kardex = Replace(strsql_Kardex, "{fecha}", Now().ToString(FORMATO_MYSQL))
        Catch ex As Exception

        End Try
        Return strsql_Kardex
    End Function

#End Region

    Public Function ALetras(ByVal numero As Double, Optional IDMoneda As Integer = NO_FILA) As String

        Dim palabras As String = STR_VACIO
        Dim entero As String = STR_VACIO
        Dim dec As String = STR_VACIO
        Dim flag As String = STR_VACIO
        Dim strMoneda As String = STR_VACIO
        Dim strCondicion As String = STR_VACIO
        Dim strCampos As String = STR_VACIO
        Dim strMonedaEntera As String = STR_VACIO
        Dim strMondeaDecimal As String = STR_VACIO

        '********Declara variables de tipo entero***********
        Dim num, x, y As Integer

        flag = "N"

        '**********Número Negativo***********
        If Mid(numero, 1, 1) = "-" Then
            numero = Mid(numero, 2, numero.ToString.Length - 1).ToString
            palabras = "menos "
        End If

        '**********Si tiene ceros a la izquierda*************
        Try
            For x = 1 To numero.ToString.Length
                If Mid(numero, 1, 1) = "0" Then
                    numero = Trim(Mid(numero, 2, numero.ToString.Length).ToString)
                    If Trim(numero.ToString.Length) = 0 Then palabras = ""
                Else
                    Exit For
                End If
            Next
        Catch ex As Exception

        End Try


        '*********Dividir parte entera y decimal************
        For y = 1 To Len(numero)
            If Mid(numero, y, 1) = "." Then
                flag = "S"
            Else
                If flag = "N" Then
                    entero = entero + Mid(numero, y, 1)
                Else
                    dec = dec + Mid(numero, y, 1)
                End If
            End If
        Next y

        If Len(dec) = 1 Then dec = dec & "0"

        '**********proceso de conversión***********
        flag = "N"

        If Val(numero) <= 999999999 Then
            For y = Len(entero) To 1 Step -1
                num = Len(entero) - (y - 1)
                Select Case y
                    Case 3, 6, 9
                        '**********Asigna las palabras para las centenas***********
                        Select Case Mid(entero, num, 1)
                            Case "1"
                                If Mid(entero, num + 1, 1) = "0" And Mid(entero, num + 2, 1) = "0" Then
                                    palabras = palabras & "cien "
                                Else
                                    palabras = palabras & "ciento "
                                End If
                            Case "2"
                                palabras = palabras & "doscientos "
                            Case "3"
                                palabras = palabras & "trescientos "
                            Case "4"
                                palabras = palabras & "cuatrocientos "
                            Case "5"
                                palabras = palabras & "quinientos "
                            Case "6"
                                palabras = palabras & "seiscientos "
                            Case "7"
                                palabras = palabras & "setecientos "
                            Case "8"
                                palabras = palabras & "ochocientos "
                            Case "9"
                                palabras = palabras & "novecientos "
                        End Select
                    Case 2, 5, 8
                        '*********Asigna las palabras para las decenas************
                        Select Case Mid(entero, num, 1)
                            Case "1"
                                If Mid(entero, num + 1, 1) = "0" Then
                                    flag = "S"
                                    palabras = palabras & "diez "
                                End If
                                If Mid(entero, num + 1, 1) = "1" Then
                                    flag = "S"
                                    palabras = palabras & "once "
                                End If
                                If Mid(entero, num + 1, 1) = "2" Then
                                    flag = "S"
                                    palabras = palabras & "doce "
                                End If
                                If Mid(entero, num + 1, 1) = "3" Then
                                    flag = "S"
                                    palabras = palabras & "trece "
                                End If
                                If Mid(entero, num + 1, 1) = "4" Then
                                    flag = "S"
                                    palabras = palabras & "catorce "
                                End If
                                If Mid(entero, num + 1, 1) = "5" Then
                                    flag = "S"
                                    palabras = palabras & "quince "
                                End If
                                If Mid(entero, num + 1, 1) > "5" Then
                                    flag = "N"
                                    palabras = palabras & "dieci"
                                End If
                            Case "2"
                                If Mid(entero, num + 1, 1) = "0" Then
                                    palabras = palabras & "veinte "
                                    flag = "S"
                                Else
                                    palabras = palabras & "veinti"
                                    flag = "N"
                                End If
                            Case "3"
                                If Mid(entero, num + 1, 1) = "0" Then
                                    palabras = palabras & "treinta "
                                    flag = "S"
                                Else
                                    palabras = palabras & "treinta y "
                                    flag = "N"
                                End If
                            Case "4"
                                If Mid(entero, num + 1, 1) = "0" Then
                                    palabras = palabras & "cuarenta "
                                    flag = "S"
                                Else
                                    palabras = palabras & "cuarenta y "
                                    flag = "N"
                                End If
                            Case "5"
                                If Mid(entero, num + 1, 1) = "0" Then
                                    palabras = palabras & "cincuenta "
                                    flag = "S"
                                Else
                                    palabras = palabras & "cincuenta y "
                                    flag = "N"
                                End If
                            Case "6"
                                If Mid(entero, num + 1, 1) = "0" Then
                                    palabras = palabras & "sesenta "
                                    flag = "S"
                                Else
                                    palabras = palabras & "sesenta y "
                                    flag = "N"
                                End If
                            Case "7"
                                If Mid(entero, num + 1, 1) = "0" Then
                                    palabras = palabras & "setenta "
                                    flag = "S"
                                Else
                                    palabras = palabras & "setenta y "
                                    flag = "N"
                                End If
                            Case "8"
                                If Mid(entero, num + 1, 1) = "0" Then
                                    palabras = palabras & "ochenta "
                                    flag = "S"
                                Else
                                    palabras = palabras & "ochenta y "
                                    flag = "N"
                                End If
                            Case "9"
                                If Mid(entero, num + 1, 1) = "0" Then
                                    palabras = palabras & "noventa "
                                    flag = "S"
                                Else
                                    palabras = palabras & "noventa y "
                                    flag = "N"
                                End If
                        End Select
                    Case 1, 4, 7
                        '*********Asigna las palabras para las unidades*********
                        Select Case Mid(entero, num, 1)
                            Case "1"
                                If flag = "N" Then
                                    If y = 1 Then
                                        palabras = palabras & "uno "
                                    Else
                                        palabras = palabras & "un "
                                    End If
                                End If
                            Case "2"
                                If flag = "N" Then palabras = palabras & "dos "
                            Case "3"
                                If flag = "N" Then palabras = palabras & "tres "
                            Case "4"
                                If flag = "N" Then palabras = palabras & "cuatro "
                            Case "5"
                                If flag = "N" Then palabras = palabras & "cinco "
                            Case "6"
                                If flag = "N" Then palabras = palabras & "seis "
                            Case "7"
                                If flag = "N" Then palabras = palabras & "siete "
                            Case "8"
                                If flag = "N" Then palabras = palabras & "ocho "
                            Case "9"
                                If flag = "N" Then palabras = palabras & "nueve "
                        End Select

                End Select

                '***********Asigna la palabra mil***************
                If y = 4 Then
                    If Mid(entero, 6, 1) <> "0" Or Mid(entero, 5, 1) <> "0" Or Mid(entero, 4, 1) <> "0" Or
                    (Mid(entero, 6, 1) = "0" And Mid(entero, 5, 1) = "0" And Mid(entero, 4, 1) = "0" And
                    Len(entero) <= 6) Then palabras = palabras & "mil "
                End If
                '**********Asigna la palabra millón*************
                If y = 7 Then
                    If Len(entero) = 7 And Mid(entero, 1, 1) = "1" Then
                        palabras = palabras & "millón "
                    Else
                        palabras = palabras & "millones "
                    End If
                End If
            Next y
            '**********Une la parte entera y la parte decimal*************
            If Not IDMoneda = NO_FILA Then
                Dim cCatalogs As New clsCatalogos
                cCatalogs.CONEXION = strConexion

                strCondicion = "cat_clase = 'Defaults' and cat_clave={moneda} and cat_pid=1"
                strCondicion = Replace(strCondicion, "{moneda}", IDMoneda)
                strCampos = "cat_desc, cat_sist, cat_dato"
                Try
                    If cCatalogs.Seleccionar(strCondicion, strCampos) = True Then
                        strMonedaEntera = cCatalogs.CAT_SIST & Space(1) & cCatalogs.CAT_DESC
                        strMondeaDecimal = cCatalogs.CAT_DATO & Space(1) & cCatalogs.CAT_DESC

                    End If
                Catch ex As Exception
                    MsgBox(cCatalogs.MERROR.ToString & ex.ToString)
                End Try
            End If
            If dec <> STR_VACIO Then
                ALetras = palabras & Space(1) & strMonedaEntera & " con " & ALetras(CDbl(dec)) & " centavos " & strMondeaDecimal
            Else
                ALetras = palabras & strMonedaEntera
            End If
        Else
            ALetras = STR_VACIO
        End If
    End Function

    Public Function ALetrasIngles(ByVal numero As Double, Optional IDMoneda As Integer = NO_FILA) As String

        Dim palabras As String = STR_VACIO
        Dim entero As String = STR_VACIO
        Dim dec As String = STR_VACIO
        Dim flag As String = STR_VACIO
        Dim strMoneda As String = STR_VACIO
        Dim strCondicion As String = STR_VACIO
        Dim strCampos As String = STR_VACIO
        Dim strMonedaEntera As String = STR_VACIO
        Dim strMondeaDecimal As String = STR_VACIO

        '********Declara variables de tipo entero***********
        Dim num, x, y As Integer

        flag = "N"

        '**********Número Negativo***********
        If Mid(numero, 1, 1) = "-" Then
            numero = Mid(numero, 2, numero.ToString.Length - 1).ToString
            palabras = "menos "
        End If

        '**********Si tiene ceros a la izquierda*************
        Try
            For x = 1 To numero.ToString.Length
                If Mid(numero, 1, 1) = "0" Then
                    numero = Trim(Mid(numero, 2, numero.ToString.Length).ToString)
                    If Trim(numero.ToString.Length) = 0 Then palabras = ""
                Else
                    Exit For
                End If
            Next
        Catch ex As Exception

        End Try


        '*********Dividir parte entera y decimal************
        For y = 1 To Len(numero)
            If Mid(numero, y, 1) = "." Then
                flag = "S"
            Else
                If flag = "N" Then
                    entero = entero + Mid(numero, y, 1)
                Else
                    dec = dec + Mid(numero, y, 1)
                End If
            End If
        Next y

        If Len(dec) = 1 Then dec = dec & "0"

        '**********proceso de conversión***********
        flag = "N"

        If Val(numero) <= 999999999 Then
            For y = Len(entero) To 1 Step -1
                num = Len(entero) - (y - 1)
                Select Case y
                    Case 3, 6, 9
                        '**********Asigna las palabras para las centenas***********
                        Select Case Mid(entero, num, 1)
                            Case "1"
                                If Mid(entero, num + 1, 1) = "0" And Mid(entero, num + 2, 1) = "0" Then
                                    palabras = palabras & "One hundred "
                                Else
                                    palabras = palabras & "One hundred "
                                End If
                            Case "2"
                                palabras = palabras & "Two hundred "
                                flag = "N"
                            Case "3"
                                palabras = palabras & "Three hundred "
                                flag = "N"
                            Case "4"
                                palabras = palabras & "Four hundred "
                                flag = "N"
                            Case "5"
                                palabras = palabras & "Five hundred "
                                flag = "N"
                            Case "6"
                                palabras = palabras & "Six hundred "
                                flag = "N"
                            Case "7"
                                palabras = palabras & "Seven hundred "
                                flag = "N"
                            Case "8"
                                palabras = palabras & "Eight hundred "
                                flag = "N"
                            Case "9"
                                palabras = palabras & "Nine hundred "
                                flag = "N"
                        End Select
                    Case 2, 5, 8
                        '*********Asigna las palabras para las decenas************
                        Select Case Mid(entero, num, 1)
                            Case "1"
                                If Mid(entero, num + 1, 1) = "0" Then
                                    flag = "S"
                                    palabras = palabras & "Ten "
                                End If
                                If Mid(entero, num + 1, 1) = "1" Then
                                    flag = "S"
                                    palabras = palabras & "Eleven "
                                End If
                                If Mid(entero, num + 1, 1) = "2" Then
                                    flag = "S"
                                    palabras = palabras & "Twelve "
                                End If
                                If Mid(entero, num + 1, 1) = "3" Then
                                    flag = "S"
                                    palabras = palabras & "Thirteen "
                                End If
                                If Mid(entero, num + 1, 1) = "4" Then
                                    flag = "S"
                                    palabras = palabras & "Fourteen "
                                End If
                                If Mid(entero, num + 1, 1) = "5" Then
                                    flag = "S"
                                    palabras = palabras & "Fifteen "
                                End If
                                If Mid(entero, num + 1, 1) = "6" Then
                                    flag = "S"
                                    palabras = palabras & "Sixteen"
                                End If
                                If Mid(entero, num + 1, 1) = "7" Then
                                    flag = "S"
                                    palabras = palabras & "Seventeen"
                                End If
                                If Mid(entero, num + 1, 1) = "8" Then
                                    flag = "S"
                                    palabras = palabras & "Eighteen"
                                End If
                                If Mid(entero, num + 1, 1) = "9" Then
                                    flag = "S"
                                    palabras = palabras & "Nighteen"
                                End If
                            Case "2"
                                If Mid(entero, num + 1, 1) = "0" Then
                                    palabras = palabras & "Twenty "
                                    flag = "S"
                                Else
                                    palabras = palabras & "Twenty "
                                    flag = "N"
                                End If
                            Case "3"
                                If Mid(entero, num + 1, 1) = "0" Then
                                    palabras = palabras & "Thirty "
                                    flag = "S"
                                Else
                                    palabras = palabras & "Thrity "
                                    flag = "N"
                                End If
                            Case "4"
                                If Mid(entero, num + 1, 1) = "0" Then
                                    palabras = palabras & "Fourty "
                                    flag = "S"
                                Else
                                    palabras = palabras & "Fourty "
                                    flag = "N"
                                End If
                            Case "5"
                                If Mid(entero, num + 1, 1) = "0" Then
                                    palabras = palabras & "Fifty "
                                    flag = "S"
                                Else
                                    palabras = palabras & "Fifty "
                                    flag = "N"
                                End If
                            Case "6"
                                If Mid(entero, num + 1, 1) = "0" Then
                                    palabras = palabras & "Sixty "
                                    flag = "S"
                                Else
                                    palabras = palabras & "Sixty "
                                    flag = "N"
                                End If
                            Case "7"
                                If Mid(entero, num + 1, 1) = "0" Then
                                    palabras = palabras & "Seventy "
                                    flag = "S"
                                Else
                                    palabras = palabras & "Seventy "
                                    flag = "N"
                                End If
                            Case "8"
                                If Mid(entero, num + 1, 1) = "0" Then
                                    palabras = palabras & "Eighty "
                                    flag = "S"
                                Else
                                    palabras = palabras & "Eighty "
                                    flag = "N"
                                End If
                            Case "9"
                                If Mid(entero, num + 1, 1) = "0" Then
                                    palabras = palabras & "Ninety "
                                    flag = "S"
                                Else
                                    palabras = palabras & "Ninety "
                                    flag = "N"
                                End If
                        End Select
                    Case 1, 4, 7
                        '*********Asigna las palabras para las unidades*********
                        Select Case Mid(entero, num, 1)
                            Case "1"
                                If flag = "N" Then
                                    If y = 1 Then
                                        palabras = palabras & "One "
                                    Else
                                        palabras = palabras & "One "
                                    End If
                                End If
                            Case "2"
                                If flag = "N" Then palabras = palabras & "Two "
                            Case "3"
                                If flag = "N" Then palabras = palabras & "Three "
                            Case "4"
                                If flag = "N" Then palabras = palabras & "Four "
                            Case "5"
                                If flag = "N" Then palabras = palabras & "Five "
                            Case "6"
                                If flag = "N" Then palabras = palabras & "Six "
                            Case "7"
                                If flag = "N" Then palabras = palabras & "Seven "
                            Case "8"
                                If flag = "N" Then palabras = palabras & "Eight "
                            Case "9"
                                If flag = "N" Then palabras = palabras & "Nine "
                        End Select

                End Select

                '***********Asigna la palabra mil***************
                If y = 4 Then
                    If Mid(entero, 6, 1) <> "0" Or Mid(entero, 5, 1) <> "0" Or Mid(entero, 4, 1) <> "0" Or
                    (Mid(entero, 6, 1) = "0" And Mid(entero, 5, 1) = "0" And Mid(entero, 4, 1) = "0" And
                    Len(entero) <= 6) Then palabras = palabras & "Thousand "
                End If
                '**********Asigna la palabra millón*************
                If y = 7 Then
                    If Len(entero) = 7 And Mid(entero, 1, 1) = "1" Then
                        palabras = palabras & "Millon "
                    Else
                        palabras = palabras & "Millons "
                    End If
                End If
            Next y
            '**********Une la parte entera y la parte decimal*************
            If Not IDMoneda = NO_FILA Then
                Dim cCatalogs As New clsCatalogos
                cCatalogs.CONEXION = strConexion

                strCondicion = "cat_clase = 'Defaults' and cat_clave={moneda} and cat_pid=1"
                strCondicion = Replace(strCondicion, "{moneda}", IDMoneda)
                strCampos = "cat_desc, cat_sist, cat_dato"
                Try
                    If cCatalogs.Seleccionar(strCondicion, strCampos) = True Then
                        strMonedaEntera = cCatalogs.CAT_SIST & Space(1) & cCatalogs.CAT_DESC
                        strMondeaDecimal = cCatalogs.CAT_DATO & Space(1) & cCatalogs.CAT_DESC

                    End If
                Catch ex As Exception
                    MsgBox(cCatalogs.MERROR.ToString & ex.ToString)
                End Try
            End If
            If dec <> STR_VACIO Then
                ALetrasIngles = palabras & Space(1) & strMonedaEntera & " and " & ALetrasIngles(CDbl(dec)) & " cents " & strMondeaDecimal
            Else
                ALetrasIngles = palabras & strMonedaEntera
            End If
        Else
            ALetrasIngles = STR_VACIO
        End If
    End Function

    'Muestra los documentos que han descargado de este
    Public Sub MostrarDependencias(ByVal Tipo As Integer, ByVal Año As Integer, ByVal Numero As Integer)
        Dim strSQL As String = STR_VACIO
        Dim i As Integer
        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader
        Dim strDato As String = STR_VACIO
        Dim Dato As String = STR_VACIO
        Dim strFila As String = STR_VACIO
        '*** Origen ***

        'Instrucción de selección
        strSQL = vbNullString
        strSQL &= " SELECT DISTINCT COALESCE(c.cat_desc,'') Documento, r.PDoc_Par_Ano Ano, r.PDoc_Par_Num Numero"
        strSQL &= "     FROM Dcmtos_DTL_Pro r"
        strSQL &= "         LEFT JOIN Catalogos c ON c.cat_clase = 'Documentos' AND c.cat_num = r.PDoc_Par_Cat"
        strSQL &= "     WHERE r.PDoc_Sis_Emp = {empresa} AND r.PDoc_Chi_Cat = {Tipo} AND r.PDoc_Chi_Ano = {Año} AND r.PDoc_Chi_Num = {Numero}"
        strSQL &= "  ORDER BY r.PDoc_Par_Ano, r.PDoc_Par_Num"

        strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
        strSQL = Replace(strSQL, "{Tipo}", Tipo)
        strSQL = Replace(strSQL, "{Año}", Año)
        strSQL = Replace(strSQL, "{Numero}", Numero)

        i = vbEmpty
        Try
            MyCnn.CONECTAR = strConexion

            COM = New MySqlCommand(strSQL, CON)
            REA = COM.ExecuteReader

            If REA.HasRows Then

                Do While REA.Read

                    strFila &= i + 1 & ") "
                    strFila &= REA.GetString("Documento") & ": "
                    strFila &= REA.GetInt32("Ano") & Space(4)
                    strFila &= REA.GetInt32("Numero").ToString(FORMATO_MONEDA) & vbCrLf

                    If Not (strFila = vbNullString) Then

                        strDato = "Origin" & vbCr
                        strDato &= "======" & vbCr & vbCr & strFila
                    End If
                Loop
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try

        '*** Dependientes ***

        'Instrucción de selección
        strSQL = vbNullString
        strSQL &= " SELECT DISTINCT COALESCE(c.cat_desc,'') Documento, r.PDoc_Chi_Ano Ano, r.PDoc_Chi_Num Numero"
        strSQL &= "     FROM Dcmtos_DTL_Pro r"
        strSQL &= "         LEFT JOIN Catalogos c ON c.cat_clase = 'Documentos' AND c.cat_num = r.PDoc_Chi_Cat"
        strSQL &= "     WHERE r.PDoc_Sis_Emp = {empresa} AND r.PDoc_Par_Cat = {Tipo} AND r.PDoc_Par_Ano = {Año} AND r.PDoc_Par_Num = {Numero}"
        strSQL &= "  UNION"
        strSQL &= " Select DISTINCT COALESCE(cc.cat_desc,'') Documento, hh.HDoc_Doc_Ano  Año, hh.HDoc_Doc_Num  Numero"
        strSQL &= "     from ECtaCte ce"
        strSQL &= "         left join Dcmtos_HDR hh on hh.HDoc_Sis_Emp = ce.ECta_Sis_Emp and hh.HDoc_Doc_Cat =ce.ECta_Doc_Cat and hh.HDoc_Doc_Ano = ce.ECta_Doc_Ano and hh.HDoc_Doc_Num =ce.ECta_Doc_Num"
        strSQL &= "    left join Catalogos cc on cc.cat_num = hh.HDoc_Doc_Cat"
        strSQL &= "  where ce.ECta_Sis_Emp = {empresa} and ce.ECta_Ref_Cat = {Tipo} and ce.ECta_Ref_Ano = {Año} and ce.ECta_Ref_Num = {Numero} and ce.ECta_Ref_Cat != ce.ECta_Doc_Cat  and hh.HDoc_Doc_Status = 1"

        strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
        strSQL = Replace(strSQL, "{Tipo}", Tipo)
        strSQL = Replace(strSQL, "{Año}", Año)
        strSQL = Replace(strSQL, "{Numero}", Numero)

        i = vbEmpty
        Try
            MyCnn.CONECTAR = strConexion

            COM = New MySqlCommand(strSQL, CON)
            REA = COM.ExecuteReader

            If REA.HasRows Then

                Do While REA.Read
                  
                    strFila = i + 1 & ") "
                    strFila &= REA.GetString("Documento") & ": "
                    strFila &= REA.GetInt32("Ano") & Space(4)
                    strFila &= REA.GetInt32("Numero").ToString(FORMATO_MONEDA) & vbCrLf

                    If Not (strFila = vbNullString) Then
                        strDato = strDato & IIf(strDato = vbNullString, vbNullString, vbCr & vbCr)
                        strDato &= "Dependencies" & vbCr
                        strDato &= "============" & vbCr & vbCr & strFila

                    End If
                Loop
            End If
            If Not (strDato = vbNullString) Then
                MsgBox(strDato, vbInformation, "Relations")
            Else
                MsgBox("No related document information found", vbInformation, "Relations")
            End If
            'End If


        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    'Busca si el tipo de documento tiene una Factura de Venta
    Public Function ValidaFacturaVenta(ByVal Tipo As Integer, ByVal Anio As Integer, ByVal Numero As Integer) As Boolean
        Dim strSQL As String = STR_VACIO
        Dim strDato As String = STR_VACIO
        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader
        Dim valida As Boolean = False

        strSQL &= "SELECT COALESCE(cc.cat_desc,'') Documento, a.PDoc_Chi_Ano Anio, a.PDoc_Chi_Num Numero" & vbCrLf
        strSQL &= "FROM Dcmtos_DTL_Pro a" & vbCrLf
        strSQL &= "left join Catalogos cc on cc.cat_num = a.PDoc_chi_Cat" & vbCrLf
        strSQL &= "left JOIN Dcmtos_DTL_Pro b 		ON a.PDoc_Sis_Emp=b.PDoc_Sis_Emp" & vbCrLf
        strSQL &= "AND a.PDoc_Par_Cat=b.PDoc_Chi_Cat" & vbCrLf
        strSQL &= "AND a.PDoc_Par_Ano=b.PDoc_Chi_Ano" & vbCrLf
        strSQL &= "AND a.PDoc_Par_Num=b.PDoc_Chi_Num" & vbCrLf
        strSQL &= "AND a.PDoc_Par_Lin=b.PDoc_Chi_Lin" & vbCrLf

        If Tipo.Equals(47) Then ''Valida Ingreso a Bodega
            strSQL &= "WHERE a.PDoc_chi_Cat=36 AND b.PDoc_Par_Cat={tipo}" & vbCrLf
            strSQL &= "AND b.PDoc_Sis_Emp={empresa} AND b.PDoc_Par_Ano={anio} AND b.PDoc_Par_Num={numero}" & vbCrLf
        ElseIf Tipo.Equals(180) Or Tipo.Equals(44) Then ''Valida Poliza Importacion
            strSQL &= "left JOIN Dcmtos_DTL_Pro c 		ON b.PDoc_Sis_Emp=c.PDoc_Sis_Emp" & vbCrLf
            strSQL &= "AND b.PDoc_Par_Ano=c.PDoc_Chi_Ano" & vbCrLf
            strSQL &= "AND b.PDoc_Par_Cat=c.PDoc_Chi_Cat" & vbCrLf
            strSQL &= "AND b.PDoc_Par_Num=c.PDoc_Chi_Num" & vbCrLf
            strSQL &= "AND b.PDoc_Par_Lin=c.PDoc_Chi_Lin" & vbCrLf
            strSQL &= "WHERE a.PDoc_chi_Cat=36 AND b.PDoc_Par_Cat=47" & vbCrLf
            strSQL &= "AND c.PDoc_Sis_Emp={empresa} AND c.PDoc_Par_Cat=180 AND c.PDoc_Par_Ano={anio}" & vbCrLf
            If Tipo.Equals(44) Then
                strSQL &= "And c.PDoc_Par_Num IN (SELECT fc.PDoc_Par_Num" & vbCrLf
                strSQL &= "FROM Dcmtos_DTL_Pro fc" & vbCrLf
                strSQL &= "WHERE fc.PDoc_Sis_Emp={empresa} AND fc.PDoc_Par_Cat=c.PDoc_Par_Cat AND fc.PDoc_Par_Ano={anio} AND fc.PDoc_Chi_Cat=44" & vbCrLf
                strSQL &= "AND fc.PDoc_Chi_Num={numero}" & vbCrLf
                strSQL &= "GROUP BY fc.PDoc_Sis_Emp, fc.PDoc_Par_Cat, fc.PDoc_Par_Ano, fc.PDoc_Par_Num)" & vbCrLf
            Else
                strSQL &= "And c.PDoc_Par_Num={numero}" & vbCrLf
            End If
        End If
        strSQL &= "GROUP BY a.PDoc_chi_Cat, a.PDoc_Chi_Ano, a.PDoc_Chi_Num"

        strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
        strSQL = Replace(strSQL, "{tipo}", Tipo)
        strSQL = Replace(strSQL, "{anio}", Anio)
        strSQL = Replace(strSQL, "{numero}", Numero)

        Try
            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSQL, CON)
            REA = COM.ExecuteReader

            If REA.HasRows Then
                strDato &= "No se puede modificar Documentos con: " & vbCrLf
                Do While REA.Read
                    strDato &= REA.GetString("Documento") & ": "
                    strDato &= REA.GetInt32("Anio") & Space(4)
                    strDato &= REA.GetInt32("Numero") & vbCrLf

                Loop
                MsgBox(strDato, vbInformation, "Relations")
                valida = True
            End If
        Catch ex As Exception
            valida = True
            MsgBox(ex.ToString)
        End Try
        Return valida
    End Function
#End Region

#Region "BorrarPolizasContables"
    Public Sub BorrarEncabezadoPoliza(ByVal num As Integer, ByVal anio As Integer, ByVal cat As Integer)
        Dim strSQL As String = STR_VACIO
        Dim COM As MySqlCommand
        Try
            MyCnn.CONECTAR = strConexion
            strSQL = "DELETE FROM {conta}.polizas WHERE empresa = {empresa} AND ref_tipo = {cat} AND ref_ciclo = {anio} AND ref_numero = {numero};"
            If Sesion.IdEmpresa = 18 Then
                strSQL = String.Concat(strSQL, "DELETE FROM contapdm.polizas WHERE empresa = {empresa} AND ref_tipo = {cat} AND ref_ciclo = {anio} AND ref_numero = {numero};")
            End If
            strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
            strSQL = Replace(strSQL, "{anio}", anio)
            strSQL = Replace(strSQL, "{numero}", num)
            strSQL = Replace(strSQL, "{cat}", cat)
            strSQL = Replace(strSQL, "{conta}", cFunciones.ContaEmpresa)
            COM = New MySqlCommand(strSQL, CON)
            COM.ExecuteNonQuery()
            COM = Nothing

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Public Sub BorrarDetallePoliza(ByVal num As Integer, ByVal anio As Integer, ByVal cat As Integer)
        Dim strSQL As String = STR_VACIO
        Dim COM As MySqlCommand
        Try
            MyCnn.CONECTAR = strConexion
            strSQL = "DELETE FROM {conta}.detalle_polizas  WHERE empresa = {empresa} AND ref_tipo = {cat} AND ref_ciclo = {anio} AND ref_numero = {numero}; "
            If Sesion.IdEmpresa = 18 Then
                strSQL = String.Concat(strSQL, "DELETE FROM contapdm.detalle_polizas  WHERE empresa = {empresa} AND ref_tipo = {cat} AND ref_ciclo = {anio} AND ref_numero = {numero}; ")
            End If
            strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
            strSQL = Replace(strSQL, "{anio}", anio)
            strSQL = Replace(strSQL, "{numero}", num)
            strSQL = Replace(strSQL, "{cat}", cat)
            strSQL = Replace(strSQL, "{conta}", cFunciones.ContaEmpresa)
            COM = New MySqlCommand(strSQL, CON)
            COM.ExecuteNonQuery()
            COM = Nothing

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub
#End Region

#Region "Validación de Cierre"
    Public Function SQLVerificarCierre(ByVal cat As Integer, ByVal anio As Integer, ByVal num As Integer, Optional ByVal fechaDocumento As Date = Nothing)
        Dim strSQL As String = STR_VACIO
        Dim intExiste As Integer = NO_FILA
        Dim COM As MySqlCommand
        Dim FechaUtiizable As Date

        If fechaDocumento = Nothing Then
            FechaUtiizable = SQLValidarFechaContable(cat, anio, num)
        Else
            FechaUtiizable = fechaDocumento
        End If



        Try

            strSQL = " SELECT COUNT(c.CE_Fecha_Final) existe "
            strSQL &= "   FROM Dcmtos_HDR h "
            strSQL &= "    Left JOIN Cierre_Encabezado c ON c.CE_Empresa = h.HDoc_Sis_Emp And c.CE_Anio = h.HDoc_Doc_Ano And c.CE_Fecha_Final >= '{fecha}' "
            strSQL &= "        WHERE h.HDoc_Sis_Emp = {emp} And h.HDoc_Doc_Cat = {cat} And h.HDoc_Doc_Ano = {anio} And h.HDoc_Doc_Num = {num} "

            strSQL = Replace(strSQL, "{emp}", Sesion.IdEmpresa)
            strSQL = Replace(strSQL, "{cat}", cat)
            strSQL = Replace(strSQL, "{anio}", anio)
            strSQL = Replace(strSQL, "{num}", num)
            strSQL = Replace(strSQL, "{fecha}", FechaUtiizable.ToString(FORMATO_MYSQL))

            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSQL, CON)
            intExiste = COM.ExecuteScalar

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        Return intExiste

    End Function
    Public Function SQLVerificarConciliacion(ByVal cat As Integer, ByVal anio As Integer, ByVal num As Integer)
        Dim strSQL As String = STR_VACIO
        Dim intConciliado As Integer = NO_FILA
        Dim COM As MySqlCommand
        Dim FechaUtiizable As Date

        FechaUtiizable = SQLValidarFechaContable(cat, anio, num)

        Try
            strSQL = " SELECT count(*)
                        FROM Dcmtos_HDR h
                        WHERE h.HDoc_Sis_Emp = {emp} AND h.HDoc_Doc_Cat = {cat} AND h.HDoc_Doc_Ano = {anio} AND h.HDoc_Doc_Num = {num} AND h.HDoc_DR2_Fec IS NULL"
            strSQL = Replace(strSQL, "{emp}", Sesion.IdEmpresa)
            strSQL = Replace(strSQL, "{cat}", cat)
            strSQL = Replace(strSQL, "{anio}", anio)
            strSQL = Replace(strSQL, "{num}", num)

            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSQL, CON)
            intConciliado = COM.ExecuteScalar

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        Return intConciliado

    End Function
    Public Function SQLVerificarFechaConciliacion(ByVal cat As Integer, ByVal anio As Integer, ByVal num As Integer, ByVal fecha As Date, ByVal cuentaBanco As Integer)
        Dim strSQL As String = STR_VACIO
        Dim intIncluyeFecha As Integer = NO_FILA
        Dim COM As MySqlCommand
        Dim FechaUtiizable As Date

        FechaUtiizable = SQLValidarFechaContable(cat, anio, num)


        Try
            strSQL = "SELECT count(*) -- h.HDoc_DR1_Fec, h.HDoc_DR2_Fec, h.*
                    FROM Dcmtos_HDR h
                    WHERE h.HDoc_Sis_Emp = {emp}
                    AND h.HDoc_Doc_Cat = {cat}
                    AND '{fecha}' BETWEEN HDoc_DR1_Fec AND  HDoc_DR2_Fec
                    AND h.HDoc_DR1_Cat={cuenta}"
            strSQL = Replace(strSQL, "{emp}", Sesion.IdEmpresa)
            strSQL = Replace(strSQL, "{cat}", 257)  ' catalogo conciliaciones
            strSQL = Replace(strSQL, "{anio}", anio)
            strSQL = Replace(strSQL, "{num}", num)
            strSQL = Replace(strSQL, "{fecha}", fecha.ToString(FORMATO_MYSQL))
            strSQL = Replace(strSQL, "{cuenta}", cuentaBanco)

            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSQL, CON)
            intIncluyeFecha = COM.ExecuteScalar


        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        Return intIncluyeFecha

    End Function
    Public Function SQLValidarFechaContable(ByVal cat As Integer, ByVal anio As Integer, ByVal num As Integer) As Date
        Dim strSQL As String = STR_VACIO
        Dim dtFecha As Date
        Dim COM As MySqlCommand

        Try
            strSQL = " SELECT CAST(IFNULL(( "
            strSQL &= "    SELECT p.fecha "
            strSQL &= "    FROM {conta}.polizas p "
            strSQL &= "    WHERE p.empresa = {emp} AND p.ref_tipo = {cat} AND p.ref_ciclo = {anio} AND p.ref_numero = {num} LIMIT 1),h.HDoc_Doc_Fec) AS DATE) fecha "
            strSQL &= "        FROM Dcmtos_HDR h "
            strSQL &= "            WHERE h.HDoc_Sis_Emp = {emp} AND h.HDoc_Doc_Cat = {cat} AND h.HDoc_Doc_Ano = {anio} AND h.HDoc_Doc_Num = {num} "

            strSQL = Replace(strSQL, "{emp}", Sesion.IdEmpresa)
            strSQL = Replace(strSQL, "{cat}", cat)
            strSQL = Replace(strSQL, "{anio}", anio)
            strSQL = Replace(strSQL, "{num}", num)
            strSQL = Replace(strSQL, "{conta}", ContaEmpresa)

            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSQL, CON)
            dtFecha = COM.ExecuteScalar

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try

        Return dtFecha
    End Function

    Public Function AutorizarCambios() As Boolean
        Dim logRes As Boolean = False
        Const str_Margen As String = "POLIZA CONTABLE"
        Dim frm As New frmAutorización
        Try
            frm.Iniciar(139, str_Margen, 0, "Authorize Change, Closure Existing")
            frm.ShowDialog(Fprincipal)
            If frm.Aceptado Then
                If frm.Nivel Then
                    logRes = True
                Else
                    MsgBox("It does not have the required authorization level", vbExclamation, "Notice")
                End If
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try

        Return logRes
    End Function

    Public Function AutorizarBorrarLiquidacion() As Boolean
        Dim logRes As Boolean = False
        Const str_Margen As String = "BORRAR_LIQ"
        Dim frm As New frmAutorización
        Try
            frm.Iniciar(13, str_Margen, 0, "Authorize Delete")
            frm.ShowDialog(Fprincipal)
            If frm.Aceptado Then
                If frm.Nivel Then
                    logRes = True
                Else
                    MsgBox("It does not have the required authorization level", vbExclamation, "Notice")
                End If
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try

        Return logRes
    End Function

    Public Function AutorizarCambioDeReferencia() As Boolean
        Dim logRes As Boolean = False
        Const str_Margen As String = "CAMBIAR REFERENCIA"
        Dim frm As New frmAutorización
        Try
            frm.Iniciar(55, str_Margen, 1, "Authorize Change")
            frm.ShowDialog(Fprincipal)
            If frm.Aceptado Then
                If frm.Nivel Then
                    logRes = True
                Else
                    MsgBox("It does not have the required authorization level", vbExclamation, "Notice")
                End If
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try

        Return logRes
    End Function
    Public Function AutorizarCambioDocumentosConciliados() As Boolean
        Dim logRes As Boolean = False
        Const str_Margen As String = "DOCUMENTOS CONCILIADOS"
        Dim frm As New frmAutorización
        Try
            frm.Iniciar(94, str_Margen, 0, "Request authorization, existing document in conciliation")
            frm.ShowDialog(Fprincipal)
            If frm.Aceptado Then
                If frm.Nivel Then
                    logRes = True
                Else
                    MsgBox("It does not have the required authorization level", vbExclamation, "Notice")
                End If
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try

        Return logRes
    End Function
#End Region

    Public Shared Function EnableDisable(Container As ContainerControl, bVisible As Boolean)
        Dim ctrl As Control
        For Each ctrl In Container.Controls
            If TypeOf ctrl Is TextBox Then
                ctrl.Visible = bVisible
            End If
        Next
    End Function

    Public Function TasaSegunFecha(ByVal fechaDoc As String) As Double
        Dim TC As Double
        Dim strSQL As String
        Dim COM1 As MySqlCommand
        Dim CONETAR_A As MySqlConnection = Nothing
        Try

            CONETAR_A = New MySqlConnection(strConexion)
            CONETAR_A.Open()
            strSQL = " SELECT t.Tasa
                     FROM TCambio t
                        WHERE t.Fecha <= '{date}'
                        ORDER BY t.Fecha DESC
                        LIMIT 1"
            strSQL = Replace(strSQL, "{date}", fechaDoc)

            COM1 = New MySqlCommand(strSQL, CONETAR_A)
            TC = CDbl(COM1.ExecuteScalar)
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        CONETAR_A.Close()
        Return TC
    End Function

    Public Function TasaSegunFechaC(ByVal fechaDoc As String, ByVal bd As String) As Double
        Dim TC As Double
        Dim strSQL As String
        Dim COM1 As MySqlCommand
        Dim CONETAR_A As MySqlConnection
        Try

            CONETAR_A = New MySqlConnection(strConexion)
            CONETAR_A.Open()
            strSQL = " SELECT t.Tasa
                     FROM {empresa}.TCambio t
                        WHERE t.Fecha <= '{date}'
                        ORDER BY t.Fecha DESC
                        LIMIT 1"
            strSQL = Replace(strSQL, "{date}", fechaDoc)
            strSQL = Replace(strSQL, "{empresa}", bd)

            COM1 = New MySqlCommand(strSQL, CONETAR_A)
            TC = CDbl(COM1.ExecuteScalar)
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        CONETAR_A.Close()
        Return TC
    End Function

    Public Function SqlPromedioTCCorp(ByVal fechaini As String, ByVal fechafin As String, ByVal bd As String) As Double
        Dim strsql As String = STR_VACIO
        Dim dblresultado As Double = INT_CERO
        Dim com As MySqlCommand
        Dim CON3 As MySqlConnection
        Try
            strsql = "SELECT ROUND(AVG(c.Tasa),4) TC
                        FROM {empresa}.TCambio c
                        WHERE c.Fecha BETWEEN '{fechai}' AND '{fechan}'"

            strsql = strsql.Replace("{fechai}", fechaini)
            strsql = strsql.Replace("{fechan}", fechafin)
            strsql = Replace(strsql, "{empresa}", bd)
            CON3 = New MySqlConnection(strConexion)
            CON3.Open()
            com = New MySqlCommand(strsql, CON3)
            dblresultado = CDbl(com.ExecuteScalar)
            dblresultado = dblresultado
            CON3.Clone()
            CON3.Dispose()
            CON3 = Nothing
            System.GC.Collect()

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        Return dblresultado
    End Function

    Public Function PermisoAnular() As Boolean
        Dim strSQL As String = STR_VACIO
        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader
        Dim logResultado As Boolean = False
        strSQL = "SELECT p.pms_codigo Permiso"
        strSQL &= "     FROM Permisos p "
        strSQL &= "         WHERE p.pms_usuario = '{usuario}' AND p.pms_modulo = 97 AND p.pms_codigo  ='ANULAR'"
        strSQL = Replace(strSQL, "{usuario}", Sesion.Usuario)
        MyCnn.CONECTAR = strConexion
        COM = New MySqlCommand(strSQL, CON)
        REA = COM.ExecuteReader
        If REA.HasRows Then
            Do While REA.Read
                If REA.GetString("Permiso") = "ANULAR" Then
                    logResultado = True
                End If
            Loop
        End If
        Return logResultado
    End Function
    Public Function UltimoDiaSiguienteMes(fecha As Date) As Date
        Dim primerDiaDelMesSiguiente As Date = fecha.AddMonths(1)
        primerDiaDelMesSiguiente = New Date(primerDiaDelMesSiguiente.Year, primerDiaDelMesSiguiente.Month, 1)
        Dim ultimoDiaDelMesSiguiente As Date = primerDiaDelMesSiguiente.AddMonths(1).AddDays(-1)
        Return ultimoDiaDelMesSiguiente
    End Function
    Public Function convertirXML(texto As String) As String
        texto = Replace(texto, "<", "&lt;")
        texto = Replace(texto, ">", "&gt;")
        texto = Replace(texto, "'", "&apos;")
        'texto=Replace(texto, """, "&quot;")

        texto = Replace(texto, "&", "&#38;")
        'texto = Replace(texto, "á", "&aacute;")
        'texto = Replace(texto, "é", "&eacute;")
        'texto = Replace(texto, "í", "&iacute;")
        'texto = Replace(texto, "ó", "&ocaute;")
        'texto = Replace(texto, "ú", "&uacute;")
        'texto = Replace(texto, "Á", "&Aacute;")
        'texto = Replace(texto, "É", "&Eacute;")
        'texto = Replace(texto, "Í", "&Iacute;")
        'texto = Replace(texto, "Ó", "&Ocaute;")
        'texto = Replace(texto, "Ú", "&Uacute;")

        'texto = Replace(texto, "á", "&#225;")
        'texto = Replace(texto, "é", "&#233;")
        'texto = Replace(texto, "í", "&#237;")
        'texto = Replace(texto, "ó", "&#243;")
        'texto = Replace(texto, "ú", "&#250;")
        texto = Replace(texto, "Á", "&#193;")
        texto = Replace(texto, "É", "&#201;")
        texto = Replace(texto, "Í", "&#205;")
        texto = Replace(texto, "Ó", "&#211;")
        texto = Replace(texto, "Ú", "&#218;")
        texto = Replace(texto, "ñ", "&#241;")
        texto = Replace(texto, "Ñ", "&#209;")
        texto = Replace(texto, "à", "&#224;")
        texto = Replace(texto, "è", "&#232;")
        texto = Replace(texto, "ì", "&#236;")
        texto = Replace(texto, "ò", "&#242;")
        texto = Replace(texto, "ù", "&#249;")

        'texto = Replace(texto, "á", "a")
        'texto = Replace(texto, "é", "e")
        'texto = Replace(texto, "í", "i")
        'texto = Replace(texto, "ó", "o")
        'texto = Replace(texto, "ú", "u")
        'texto = Replace(texto, "Á", "A")
        'texto = Replace(texto, "É", "E;")
        'texto = Replace(texto, "Í", "I;")
        'texto = Replace(texto, "Ó", "O")
        'texto = Replace(texto, "Ú", "U")


        Return texto
    End Function

    Private Function SeleccionarSesionHilos() As String

        Dim strsql As String = STR_VACIO

        strsql = "SELECT cat_clave bd_host, cat_desc bd_name,cat_sist bd_user, cat_Dato bd_pw, cat_pid bd_port"
        strsql &= "     FROM Catalogos"
        strsql &= "   WHERE cat_clase = 'SrvHA' AND cat_sisemp ={empresa}"

        strsql = Replace(strsql, "{empresa}", Sesion.IdEmpresa)

        Return strsql
    End Function
    Public Function sesionHilos() As Boolean
        If Sesion.IdEmpresa = 10 Or Sesion.IdEmpresa = 12 Then
            Dim COM1 As MySqlCommand
            Dim REA1 As MySqlDataReader
            Dim sqlha As String

            sqlha = SeleccionarSesionHilos()
            MyCnn.CONECTAR = strConexion
            COM1 = New MySqlCommand(sqlha, CON)
            REA1 = COM1.ExecuteReader

            If REA1.HasRows Then
                Do While REA1.Read
                    CMC_Hilos_Host = REA1.GetString("bd_host")
                    CMC_Hilos_BASE = REA1.GetString("bd_name")
                    CMC_Hilos_USER = REA1.GetString("bd_user")
                    CMC_Hilos_PASS = REA1.GetString("bd_pw")
                    CMC_Hilos_PORT = REA1.GetString("bd_port")
                Loop
            End If
            Try
                COM1.Dispose()
                REA1.Close()
                Return True
            Catch ex As Exception
                MsgBox(ex.ToString)
                Return False
            End Try
            Return False
        End If
        Return False
    End Function
    Public Function nameBase() As String
        Dim nameDataBase As String = String.Empty
        Dim strSQL As String = "SELECT DATABASE();"
        Dim COM1 As MySqlCommand
        Dim CONETAR_A As MySqlConnection

        Try
            CONETAR_A = New MySqlConnection(strConexion)
            CONETAR_A.Open()
            COM1 = New MySqlCommand(strSQL, CONETAR_A)
            nameDataBase = Convert.ToString(COM1.ExecuteScalar()) ' Convertir el valor a String.
        Catch ex As Exception
            MsgBox("Error: " & ex.Message)
        Finally
            If CONETAR_A IsNot Nothing AndAlso CONETAR_A.State = ConnectionState.Open Then
                CONETAR_A.Close()
            End If
        End Try

        ' Retornar el nombre de la base de datos.
        Return nameDataBase
    End Function


#Region "Pesaje Planta"


    Public Class SerialPortReader
        Private WithEvents SerialPort As New SerialPort
        Private ReadOnly TextBox As TextBox

        Public Sub New(portName As String, baudRate As Integer, textBox As TextBox)
            ' Configurar los parámetros del puerto serial
            SerialPort.PortName = portName
            SerialPort.BaudRate = baudRate
            SerialPort.Parity = Parity.None
            SerialPort.DataBits = 8
            SerialPort.StopBits = StopBits.One
            'SerialPort.Handshake = Handshake.None
            AddHandler SerialPort.DataReceived, AddressOf SerialPort_DataReceived
            Me.TextBox = textBox
        End Sub

        Public Sub OpenPort()
            If Not SerialPort.IsOpen Then
                SerialPort.Open()
            End If
        End Sub

        Public Sub ClosePort()
            If SerialPort.IsOpen Then
                SerialPort.Close()
            End If
        End Sub

        Private Sub SerialPort_DataReceived(sender As Object, e As SerialDataReceivedEventArgs)
            ' Leer los datos recibidos
            Dim receivedData As String = SerialPort.ReadExisting()

            ' Actualizar el TextBox en el hilo principal de la interfaz de usuario
            If TextBox.InvokeRequired Then
                Try
                    Dim data As String() = receivedData.Split("ChrW(2)")
                    'Dim pesoNeto As String = data(0).Substring(5, 11) ''dato que se recibe
                    Dim pesoNeto As String = receivedData 'data(0).Substring(5, 5)
                    Dim pesoTara As String = receivedData 'data(0).Substring(6, 5)


                    TextBox.Invoke(New Action(Of String)(AddressOf UpdateTextBox), pesoNeto)
                    If pesoNeto.Length > 0 Then
                        SerialPort.Close()
                        Exit Sub
                    End If
                Catch ex As Exception

                End Try

            Else
                UpdateTextBox(receivedData)
            End If

        End Sub

        Private Sub UpdateTextBox(data As String)
            TextBox.Text = data
        End Sub
    End Class

    Public Class SerialPortValidator
        Public Shared Function IsDeviceConnected(portName As String, Optional baudRate As Integer = 9600, Optional timeout As Integer = 5000) As Boolean
            Try
                Using serialPort As New SerialPort(portName, baudRate, Parity.None, 8, StopBits.One)
                    ' Configurar los parámetros del puerto serial
                    serialPort.ReadTimeout = timeout
                    serialPort.WriteTimeout = timeout

                    ' Abrir el puerto serial
                    If serialPort.IsOpen Then serialPort.Close()
                    serialPort.Open()

                    ' Enviar un comando para verificar la conexión (por ejemplo, un simple ping)
                    Dim command As String = "PING" & vbCrLf
                    serialPort.Write(command)

                    ' Esperar una respuesta
                    Dim response As String = serialPort.ReadLine()

                    ' Si recibimos una respuesta, asumimos que el dispositivo está conectado
                    If Not String.IsNullOrEmpty(response) Then
                        Return True
                    End If
                End Using
            Catch ex As TimeoutException
                ' Si se produce una excepción de tiempo de espera, el dispositivo no está respondiendo
                Return False
            Catch ex As Exception
                Console.WriteLine($"error:  {ex.Message.ToString} ")

                ' Manejar otras excepciones según sea necesario
                Return False
            End Try

            ' Si llegamos aquí, el dispositivo no está conectado
            Return False
        End Function
    End Class
#End Region

#Region "exportar a Word"


    Public Sub ExportarHTMLaWord(rutaHtml As String, rutaDocx As String)
        Dim wordApp As New Word.Application
        Dim wordDoc As Word.Document = Nothing

        Try
            ' Abre Word sin mostrarlo
            wordApp.Visible = False

            ' Abre el archivo HTML
            'wordDoc = wordApp.Documents.Open(rutaHtml)
            wordDoc = wordApp.Documents.Open(FileName:=rutaHtml, Format:=Word.WdOpenFormat.wdOpenFormatWebPages)
            ' Guarda como documento Word (.docx)
            wordDoc.SaveAs2(rutaDocx, Word.WdSaveFormat.wdFormatDocumentDefault)

            MsgBox("Exportación a Word completada correctamente.", MsgBoxStyle.Information)
            ' Abrir el archivo resultante
            Process.Start(rutaDocx)
        Catch ex As Exception
            MsgBox("Error al exportar a Word: " & ex.Message, MsgBoxStyle.Critical)

        Finally
            ' Cierra el documento y la aplicación Word
            If Not IsNothing(wordDoc) Then
                ' wordDoc.Close(False)
            End If
            wordApp.Quit()

            ' Libera recursos
            ReleaseComObject(wordDoc)
            ReleaseComObject(wordApp)
        End Try
    End Sub

    Private Sub ReleaseComObject(ByVal obj As Object)
        Try
            If obj IsNot Nothing Then
                System.Runtime.InteropServices.Marshal.ReleaseComObject(obj)
                obj = Nothing
            End If
        Catch ex As Exception
            obj = Nothing
        Finally
            GC.Collect()
        End Try
    End Sub

#End Region
End Class
