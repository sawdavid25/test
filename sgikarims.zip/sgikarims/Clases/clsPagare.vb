﻿Public Class clsPagare

#Region "Estructuras"

    Private Structure Deudor
        Dim intId As Integer
        Dim strEmpresa As String
        Dim strRepresentate As String
        Dim strNotario As String
        Dim fechaNombramiento As MySqlDateTime
        Dim fechaVencimiento As MySqlDateTime
        Dim logIndefino As Integer
        Dim longRegistro As Long
        Dim intFolio As Integer
        Dim intLibro As Integer
        Dim strDPI As String
        Dim strNotificaciones As String
        Dim strNotificacionesMunicipio As String
        Dim strNotificacionesDepartamento As String
    End Structure

    Private Structure Acreedor
        Dim strEmpresa As String
        Dim strDireccion As String
    End Structure

    Private Structure Fiador
        Dim strNombre As String
        Dim strDPI As String
        Dim strMunicipio As String
        Dim strDepartamento As String
    End Structure

    Private Structure Pagare
        Dim Id As Integer
        Dim intAño As Integer
        Dim intEmpresa As Integer
        Const idcatalogo As Integer = 465
        Dim fecha As MySqlDateTime
        Dim IdFactura As Integer
        Dim intMoneda As Integer
        Dim strMoneda As String
        Dim dblMonto As Double
        Dim intDias As Integer
        Dim fechaInicio As MySqlDateTime
        Dim fechaVencimiento As MySqlDateTime
        Dim dblInteres As Double
        Dim strPedido As String
        Dim Estado As Integer
        Dim Recibido As Integer
    End Structure

#End Region

#Region "Miembros"

    Dim sDeudor As New Deudor
    Dim sAcreedor As New Acreedor
    Dim sFiador As New Fiador
    Dim sPagare As New Pagare
    Dim ListaFact As DataGridView
    Dim strPedidos As String = STR_VACIO

#End Region

#Region "Propiedades"

    Public Property Estado As Integer
        Get
            Return sPagare.Estado
        End Get
        Set(value As Integer)
            sPagare.Estado = value
        End Set
    End Property

    Public Property Recibido As Integer
        Get
            Return sPagare.Recibido
        End Get
        Set(value As Integer)
            sPagare.Recibido = value
        End Set
    End Property

    Public Property FechaNombramientoVencimiento As MySqlDateTime
        Get
            Return sDeudor.fechaVencimiento
        End Get
        Set(value As MySqlDateTime)
            sDeudor.fechaVencimiento = value
        End Set
    End Property

    Public WriteOnly Property FechaNombramientoVencimietno_Net As Date
        Set(value As Date)
            sDeudor.fechaVencimiento = New MySqlDateTime(value.Year, value.Month, value.Day, value.Hour, value.Minute, value.Second)
        End Set
    End Property

    Public Property NombramientoDefinido As Integer
        Get
            Return sDeudor.logIndefino
        End Get
        Set(value As Integer)
            sDeudor.logIndefino = value
        End Set
    End Property

    Public Property Pedidos As String
        Get
            Return strPedidos
        End Get
        Set(value As String)
            strPedidos = value
        End Set
    End Property

    Public Property Facturas As DataGridView
        Get
            Return ListaFact
        End Get
        Set(value As DataGridView)
            ListaFact = value
        End Set
    End Property

    Public Property DeudorId As String
        Get
            Return sDeudor.intId
        End Get
        Set(value As String)
            sDeudor.intId = value
        End Set
    End Property

    Public Property DeudorEmpreas As String
        Get
            Return sDeudor.strEmpresa
        End Get
        Set(value As String)
            sDeudor.strEmpresa = value
        End Set
    End Property

    Public Property DeudorRepresentante As String
        Get
            Return sDeudor.strRepresentate
        End Get
        Set(value As String)
            sDeudor.strRepresentate = value
        End Set
    End Property

    Public Property DeudorNotario As String
        Get
            Return sDeudor.strNotario
        End Get
        Set(value As String)
            sDeudor.strNotario = value
        End Set
    End Property

    Public Property DeudorFechaNombramiento As MySqlDateTime
        Get
            Return sDeudor.fechaNombramiento
        End Get
        Set(value As MySqlDateTime)
            sDeudor.fechaNombramiento = value
        End Set
    End Property

    Public WriteOnly Property DeudorFechaNombramiento_Net As Date
        Set(value As Date)
            sDeudor.fechaNombramiento = New MySqlDateTime(value.Year, value.Month, value.Day, value.Hour, value.Minute, value.Second)
        End Set
    End Property

    Public Property DeudorRegistro As Long
        Get
            Return sDeudor.longRegistro
        End Get
        Set(value As Long)
            sDeudor.longRegistro = value
        End Set
    End Property

    Public Property DeudorFolio As Integer
        Get
            Return sDeudor.intFolio
        End Get
        Set(value As Integer)
            sDeudor.intFolio = value
        End Set
    End Property

    Public Property DeudorLibro As Integer
        Get
            Return sDeudor.intLibro
        End Get
        Set(value As Integer)
            sDeudor.intLibro = value
        End Set
    End Property

    Public Property DeudorDPI As String
        Get
            Return sDeudor.strDPI
        End Get
        Set(value As String)
            sDeudor.strDPI = value
        End Set
    End Property

    Public Property DeudorNotificaciones As String
        Get
            Return sDeudor.strNotificaciones
        End Get
        Set(value As String)
            sDeudor.strNotificaciones = value
        End Set
    End Property

    Public Property DeudorNotificacionesMunicipio As String
        Get
            Return sDeudor.strNotificacionesMunicipio
        End Get
        Set(value As String)
            sDeudor.strNotificacionesMunicipio = value
        End Set
    End Property

    Public Property DeudorNotificacionesDepartamento As String
        Get
            Return sDeudor.strNotificacionesDepartamento
        End Get
        Set(value As String)
            sDeudor.strNotificacionesDepartamento = value
        End Set
    End Property

    Public Property AcreedorEmpresa As String
        Get
            Return sAcreedor.strEmpresa
        End Get
        Set(value As String)
            sAcreedor.strEmpresa = value
        End Set
    End Property

    Public Property AcreedroDireccion As String
        Get
            Return sAcreedor.strDireccion
        End Get
        Set(value As String)
            sAcreedor.strDireccion = value
        End Set
    End Property

    Public Property FiadorNombre As String
        Get
            Return sFiador.strNombre
        End Get
        Set(value As String)
            sFiador.strNombre = value
        End Set
    End Property

    Public Property FiadorDpi As String
        Get
            Return sFiador.strDPI
        End Get
        Set(value As String)
            sFiador.strDPI = value
        End Set
    End Property

    Public Property FiadorMunicipio As String
        Get
            Return sFiador.strMunicipio
        End Get
        Set(value As String)
            sFiador.strMunicipio = value
        End Set
    End Property

    Public Property FiadorDepartamento As String
        Get
            Return sFiador.strDepartamento
        End Get
        Set(value As String)
            sFiador.strDepartamento = value
        End Set
    End Property

    Public Property PagareId As Integer
        Get
            Return sPagare.Id
        End Get
        Set(value As Integer)
            sPagare.Id = value
        End Set
    End Property

    Public Property PagarePedido As String
        Get
            Return sPagare.strPedido
        End Get
        Set(value As String)
            sPagare.strPedido = value
        End Set
    End Property

    Public Property PagareAño As Integer
        Get
            Return sPagare.intAño
        End Get
        Set(value As Integer)
            sPagare.intAño = value
        End Set
    End Property

    Public Property PagareEmpresa As Integer
        Get
            Return sPagare.intEmpresa
        End Get
        Set(value As Integer)
            sPagare.intEmpresa = value
        End Set
    End Property

    Public ReadOnly Property PagareCatalogo
        Get
            Return Pagare.idcatalogo
        End Get
    End Property

    Public Property PagareFecha As MySqlDateTime
        Get
            Return sPagare.fecha
        End Get
        Set(value As MySqlDateTime)
            sPagare.fecha = value
        End Set
    End Property

    Public WriteOnly Property PagareFecha_Net
        Set(value)
            sPagare.fecha = New MySqlDateTime(value.Year, value.Month, value.Day, value.Hour, value.Minute, value.Second)
        End Set
    End Property

    Public Property PagareIdFactura As Integer
        Get
            Return sPagare.IdFactura
        End Get
        Set(value As Integer)
            sPagare.IdFactura = sPagare.IdFactura
        End Set
    End Property

    Public Property PagareMoneda As Integer
        Get
            Return sPagare.intMoneda
        End Get
        Set(value As Integer)
            sPagare.intMoneda = value
        End Set
    End Property

    Public Property PagareSimboloMoneda As String
        Get
            Return sPagare.strMoneda
        End Get
        Set(value As String)
            sPagare.strMoneda = value
        End Set
    End Property

    Public Property PagareMonto As Double
        Get
            Return sPagare.dblMonto
        End Get
        Set(value As Double)
            sPagare.dblMonto = value
        End Set
    End Property

    Public Property PagareDias As Integer
        Get
            Return sPagare.intDias
        End Get
        Set(value As Integer)
            sPagare.intDias = value
        End Set
    End Property

    Public Property PagareFechaIncio As MySqlDateTime
        Get
            Return sPagare.fechaInicio
        End Get
        Set(value As MySqlDateTime)
            sPagare.fechaInicio = value
        End Set
    End Property

    Public WriteOnly Property PagareFechaInicio_Net As Date
        Set(value As Date)
            sPagare.fechaInicio = New MySqlDateTime(value.Year, value.Month, value.Day, value.Hour, value.Minute, value.Second)
        End Set
    End Property

    Public Property PagareFechaVencimiento As MySqlDateTime
        Get
            Return sPagare.fechaVencimiento
        End Get
        Set(value As MySqlDateTime)
            sPagare.fechaVencimiento = value
        End Set
    End Property

    Public WriteOnly Property PagareFechaVencimiento_Net As Date
        Set(value As Date)
            sPagare.fechaVencimiento = New MySqlDateTime(value.Year, value.Month, value.Day, value.Hour, value.Minute, value.Second)
        End Set
    End Property

    Public Property PagareInteres As Double
        Get
            Return sPagare.dblInteres
        End Get
        Set(value As Double)
            sPagare.dblInteres = value
        End Set
    End Property
#End Region

#Region "Funciones"

    Public Function Guardar(Optional LogActualizar = False) As Boolean
        Guardar = False
        Dim logOk As Boolean = False
        Dim cHdr As New clsDcmtos_HDR
        Try
            ''guardar encabezado
            cHdr.CONEXION = strConexion
            cHdr.HDOC_SIS_EMP = Sesion.IdEmpresa
            cHdr.HDOC_DOC_CAT = Pagare.idcatalogo
            cHdr.HDoc_Doc_Fec_NET = sPagare.fecha
            cHdr.HDOC_EMP_COD = sPagare.IdFactura
            cHdr.HDOC_EMP_NOM = sDeudor.strEmpresa
            cHdr.HDOC_EMP_TEL = sPagare.strMoneda
            cHdr.HDOC_EMP_NIT = sPagare.strPedido
            cHdr.HDOC_EMP_DIR = sAcreedor.strDireccion
            cHdr.HDOC_EMP_PER = sAcreedor.strEmpresa
            cHdr.HDOC_DR1_CAT = sPagare.intMoneda
            cHdr.HDOC_DR1_DBL = sPagare.dblMonto
            cHdr.HDOC_DR1_FEC = sPagare.fechaInicio
            cHdr.HDOC_DR1_EMP = sPagare.intDias
            cHdr.HDOC_DR2_FEC = sPagare.fechaVencimiento
            cHdr.HDOC_RF1_COD = sDeudor.strDPI
            cHdr.HDOC_RF2_COD = sDeudor.strRepresentate
            cHdr.HDOC_DR1_NUM = sDeudor.strNotario
            cHdr.HDOC_USUARIO = Sesion.Usuario
            cHdr.HDOC_PRO_FEC = sDeudor.fechaNombramiento
            cHdr.HDOC_PRO_DCAT = sDeudor.longRegistro
            cHdr.HDOC_PRO_DANO = sDeudor.intLibro
            cHdr.HDOC_PRO_DNUM = sDeudor.intFolio
            cHdr.HDOC_DOC_TC = sPagare.dblInteres
            cHdr.HDOC_DR2_CAT = sDeudor.intId
            cHdr.HDOC_DOC_STATUS = sPagare.Estado
            cHdr.HDOC_RF1_NUM = sPagare.Recibido
            If LogActualizar = False Then
                cHdr.ANOMYSQL = MYSQL_AÑO
                cHdr.HDOC_DOC_NUM = cFunciones.NuevoId(465)
                If cHdr.Guardar = True Then
                    sPagare.intAño = cHdr.HDOC_DOC_ANO
                    sPagare.Id = cHdr.HDOC_DOC_NUM
                    logOk = True
                End If
            Else
                cHdr.HDOC_DOC_ANO = sPagare.intAño
                cHdr.HDOC_DOC_NUM = sPagare.Id
                If cHdr.Actualizar = True Then
                    Dim DTL As New clsDcmtos_DTL
                    Dim PRO As New clsDcmtos_DTL_Pro
                    Dim strCondicion As String = STR_VACIO
                    'Borrar Relecion con facturas DTL_Pro
                    strCondicion = "PDoc_Chi_Cat = 465 and PDoc_Chi_Num={idpagare} and PDoc_Sis_Emp= {empresa}"
                    strCondicion = Replace(strCondicion, "{idpagare}", sPagare.Id)
                    strCondicion = Replace(strCondicion, "{empresa}", Sesion.IdEmpresa)
                    Try
                        PRO.CONEXION = strConexion
                        If PRO.Borrar(strCondicion) = False Then
                            MsgBox("No se pudo borrar" & PRO.MERROR.ToString)
                            Exit Function
                        End If
                    Catch ex As Exception
                        MsgBox("DTL_Pro" & ex.ToString)
                    End Try

                    '' Borrar detalle de Pagare
                    strCondicion = STR_VACIO
                    strCondicion = "DDoc_Doc_Cat = 465 and DDoc_Doc_Num = {idpagare}  and DDoc_Doc_Ano = {año} and DDoc_Sis_Emp= {empresa}"
                    strCondicion = Replace(strCondicion, "{idpagare}", sPagare.Id)
                    strCondicion = Replace(strCondicion, "{empresa}", Sesion.IdEmpresa)
                    strCondicion = Replace(strCondicion, "{año}", sPagare.intAño)
                    Try
                        DTL.CONEXION = strConexion
                        If DTL.Borrar(strCondicion) = False Then
                            MsgBox("No se pudo borrar" & PRO.MERROR.ToString)
                            Exit Function
                        End If
                    Catch ex As Exception
                        MsgBox("DTL -->" & ex.ToString)
                    End Try
                    logOk = True
                Else
                    MsgBox(cHdr.MERROR.ToString)
                End If
            End If
            If logOk = True Then
                ''GUARDAR DATOS DEL FIADOR
                Dim cDtl_Fiador As New clsDcmtos_DTL
                cDtl_Fiador.CONEXION = strConexion
                cDtl_Fiador.DDOC_SIS_EMP = Sesion.IdEmpresa
                cDtl_Fiador.DDOC_DOC_CAT = 465
                cDtl_Fiador.DDOC_DOC_LIN = INT_UNO
                cDtl_Fiador.DDOC_DOC_NUM = cHdr.HDOC_DOC_NUM
                cDtl_Fiador.DDOC_PRD_PNR = "FIADOR"
                cDtl_Fiador.DDOC_PRD_DES = sFiador.strNombre
                cDtl_Fiador.DDOC_RF1_COD = sFiador.strDPI
                cDtl_Fiador.DDOC_RF2_COD = sFiador.strMunicipio
                cDtl_Fiador.DDOC_PRD_REF = sFiador.strDepartamento
                If cDtl_Fiador.Guardar() = False Then
                    MsgBox(cDtl_Fiador.MERROR.ToString)
                End If
                '' GUARDAR DATOS DETALLES
                Dim cDTL_Notificaciones As New clsDcmtos_DTL
                cDTL_Notificaciones.CONEXION = strConexion
                cDTL_Notificaciones.DDOC_SIS_EMP = Sesion.IdEmpresa
                cDTL_Notificaciones.DDOC_DOC_CAT = 465
                cDTL_Notificaciones.DDOC_DOC_LIN = 2
                cDTL_Notificaciones.DDOC_DOC_NUM = cHdr.HDOC_DOC_NUM
                cDTL_Notificaciones.DDOC_PRD_PNR = "NOTIFICACIONES"
                cDTL_Notificaciones.DDOC_RF1_TXT = sDeudor.strNotificaciones
                cDTL_Notificaciones.DDOC_RF2_COD = sDeudor.strNotificacionesMunicipio
                cDTL_Notificaciones.DDOC_PRD_REF = sDeudor.strNotificacionesDepartamento
                If cDTL_Notificaciones.Guardar = False Then
                    MsgBox(cDTL_Notificaciones.MERROR.ToString)
                End If
                ''GUARDAR DATOS DE NOMBRAMIENTO
                Dim cDTL_Nombramiento As New clsDcmtos_DTL
                cDTL_Nombramiento.CONEXION = strConexion
                cDTL_Nombramiento.DDOC_SIS_EMP = Sesion.IdEmpresa
                cDTL_Nombramiento.DDOC_DOC_CAT = 465
                cDTL_Nombramiento.DDOC_DOC_LIN = 3
                cDTL_Nombramiento.DDOC_DOC_NUM = cHdr.HDOC_DOC_NUM
                cDTL_Nombramiento.DDOC_PRD_PNR = "NOMBRAMIENTO"
                cDtl_Fiador.DDOC_PRD_DES = sDeudor.strNotario
                cDTL_Nombramiento.DDOC_PRD_UM = sDeudor.logIndefino
                cDTL_Nombramiento.DDOC_RF1_FEC = sDeudor.fechaNombramiento
                cDTL_Nombramiento.DDOC_RF2_FEC = sDeudor.fechaVencimiento
                If cDTL_Nombramiento.Guardar = False Then
                    MsgBox(cDTL_Nombramiento.MERROR.ToString)
                End If
                ''Guardar Relaciones en Pro
                Dim PRO_Fact As New clsDcmtos_DTL_Pro
                For i As Integer = 0 To ListaFact.Rows.Count - 1
                    Try
                        PRO_Fact.CONEXION = strConexion
                        PRO_Fact.PDOC_SIS_EMP = Sesion.IdEmpresa
                        PRO_Fact.PDOC_PAR_CAT = 36
                        PRO_Fact.PDOC_PAR_ANO = CInt(ListaFact.Rows(i).Cells(0).Value)
                        PRO_Fact.PDOC_PAR_NUM = CInt(ListaFact.Rows(i).Cells(1).Value)
                        PRO_Fact.PDOC_PAR_LIN = INT_UNO
                        PRO_Fact.PDOC_CHI_CAT = 465
                        PRO_Fact.PDOC_CHI_ANO = cFunciones.AñoMySQL
                        PRO_Fact.PDOC_CHI_NUM = cHdr.HDOC_DOC_NUM
                        PRO_Fact.PDOC_CHI_LIN = INT_UNO
                        PRO_Fact.PDOC_CLTE_COD = sPagare.intEmpresa
                        PRO_Fact.PDOC_QTY_PRO = CDbl(ListaFact.Rows(i).Cells(5).Value)
                        PRO_Fact.PDOC_DR1_NUM = CStr(ListaFact.Rows(i).Cells(6).Value)
                        PRO_Fact.Guardar()
                    Catch ex As Exception
                        MsgBox(ex.ToString)
                    End Try
                Next
                Guardar = True
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Function

    Public Function Selecionar(ByVal strCondicion As String, Optional ByVal strCampos_HDR As String = STR_VACIO, Optional ByVal strCampos_DTLFiador As String = STR_VACIO, Optional ByVal strCampos_DTLDetalle As String = STR_VACIO, Optional ByVal Orden As String = STR_VACIO) As Boolean
        Selecionar = False
        Dim cHdr As New clsDcmtos_HDR
        Dim cDtl_Fiador As New clsDcmtos_DTL
        Dim cDTL_Nombramiento As New clsDcmtos_DTL
        Dim arrayCampo_HDR() As String
        Dim arrayCampo_Dtl_Fiador() As String
        Dim arrayCampo_Dtl_Dettalle() As String

        If Not strCampos_HDR = STR_VACIO Then
            If strCampos_HDR = STR_ASTERISCO Then
                strCampos_HDR = "HDoc_Sis_Emp,HDoc_Doc_Ano, HDoc_Doc_Num, HDoc_Doc_Fec,HDoc_Emp_Cod," & _
                    "HDoc_Emp_Nom,HDoc_Emp_Dir,HDoc_Emp_Per,HDoc_DR1_Cat,HDoc_DR1_Num,HDoc_DR1_Dbl," & _
                    "HDoc_DR1_Fec,HDoc_DR1_Emp,HDoc_DR2_Fec,HDoc_RF1_Cod,HDoc_RF2_Cod,HDoc_Pro_Fec," & _
                    "HDoc_Pro_DCat, HDoc_Pro_DAno,HDoc_Pro_DNum,HDoc_Doc_TC, HDoc_Emp_Tel, HDoc_Emp_NIT," & _
                    "HDoc_DR2_Cat, HDoc_Doc_Status, HDoc_RF1_Num"
            End If
            Try
                cHdr.CONEXION = strConexion
                ''seleccionar encabezado
                ''agregar simbolo de moneda al case 
                strCondicion &= " AND HDoc_Doc_Cat = 465"
                If cHdr.Seleccionar(strCondicion, strCampos_HDR, " order by HDoc_Doc_Fec DESC,  HDoc_Doc_Num DESC ") = True Then
                    arrayCampo_HDR = strCampos_HDR.Split(",".ToCharArray)
                    For i = 0 To arrayCampo_HDR.Length - 1
                        Select Case Trim(arrayCampo_HDR(i))
                            Case "HDoc_Sis_Emp"
                                sPagare.intEmpresa = cHdr.HDOC_SIS_EMP
                            Case "HDoc_Doc_Ano"
                                sPagare.intAño = cHdr.HDOC_DOC_ANO
                            Case "HDoc_Doc_Num"
                                sPagare.Id = cHdr.HDOC_DOC_NUM
                            Case "HDoc_Doc_Fec"
                                sPagare.fecha = cHdr.HDOC_DOC_FEC
                            Case "HDoc_Emp_Cod"
                                sPagare.IdFactura = cHdr.HDOC_EMP_COD
                            Case "HDoc_Emp_Nom"
                                sDeudor.strEmpresa = cHdr.HDOC_EMP_NOM
                            Case "HDoc_Emp_Dir"
                                sAcreedor.strDireccion = cHdr.HDOC_EMP_DIR
                            Case "HDoc_Emp_Per"
                                sAcreedor.strEmpresa = cHdr.HDOC_EMP_PER
                            Case "HDoc_DR1_Cat"
                                sPagare.intMoneda = cHdr.HDOC_DR1_CAT
                            Case "HDoc_DR1_Num"
                                sDeudor.strNotario = cHdr.HDOC_DR1_NUM
                            Case "HDoc_DR1_Dbl"
                                sPagare.dblMonto = cHdr.HDOC_DR1_DBL
                            Case "HDoc_DR1_Fec"
                                sPagare.fechaInicio = cHdr.HDOC_DR1_FEC
                            Case "HDoc_DR1_Emp"
                                sPagare.intDias = cHdr.HDOC_DR1_EMP
                            Case "HDoc_DR2_Fec"
                                sPagare.fechaVencimiento = cHdr.HDOC_DR2_FEC
                            Case "HDoc_RF1_Cod"
                                sDeudor.strDPI = cHdr.HDOC_RF1_COD
                            Case "HDoc_RF2_Cod"
                                sDeudor.strRepresentate = cHdr.HDOC_RF2_COD
                            Case "HDoc_Pro_Fec"
                                sDeudor.fechaNombramiento = cHdr.HDOC_PRO_FEC
                            Case "HDoc_Pro_DCat"
                                sDeudor.longRegistro = cHdr.HDOC_PRO_DCAT
                            Case "HDoc_Pro_DAno"
                                sDeudor.intLibro = cHdr.HDOC_PRO_DANO
                            Case "HDoc_Pro_DNum"
                                sDeudor.intFolio = cHdr.HDOC_PRO_DNUM
                            Case "HDoc_Doc_TC"
                                sPagare.dblInteres = cHdr.HDOC_DOC_TC
                            Case "HDoc_Emp_Tel"
                                sPagare.strMoneda = cHdr.HDOC_EMP_TEL
                            Case "HDoc_Emp_NIT"
                                sPagare.strPedido = cHdr.HDOC_EMP_NIT
                            Case "HDoc_DR2_Cat"
                                sDeudor.intId = cHdr.HDOC_DR2_CAT
                            Case "HDoc_Doc_Status"
                                sPagare.Estado = cHdr.HDOC_DOC_STATUS
                            Case "HDoc_RF1_Num"
                                sPagare.Recibido = cHdr.HDOC_RF1_NUM
                        End Select
                    Next
                Else
                    Exit Function
                    MsgBox(cHdr.MERROR.ToString)
                End If
            Catch ex As Exception
                MsgBox(ex.ToString)
            End Try
        End If
        ''seleccionar datos del fiador *********************************************************
        If Not strCampos_DTLFiador = STR_VACIO Then
            strCondicion = STR_VACIO
            strCondicion = "DDoc_Sis_Emp = {empresa} AND DDoc_Doc_Cat = 465 AND DDoc_Doc_Ano= {año}" & _
                " AND DDoc_Doc_Num = {id} AND DDoc_Doc_Lin = 1"
            strCondicion = Replace(strCondicion, "{empresa}", Sesion.IdEmpresa)
            strCondicion = Replace(strCondicion, "{año}", sPagare.intAño)
            strCondicion = Replace(strCondicion, "{id}", sPagare.Id)
            If strCampos_DTLFiador = STR_ASTERISCO Then
                strCampos_DTLFiador = "DDoc_Prd_Des, DDoc_RF1_Cod, DDoc_RF2_Cod, DDoc_Prd_Ref"
            End If
            Try
                cDtl_Fiador.CONEXION = strConexion
                If cDtl_Fiador.Seleccionar(strCondicion, strCampos_DTLFiador) = True Then
                    arrayCampo_Dtl_Fiador = strCampos_DTLFiador.Split(",".ToCharArray)
                    For i = 0 To arrayCampo_Dtl_Fiador.Length - 1
                        Select Case Trim(arrayCampo_Dtl_Fiador(i))
                            Case ("DDoc_Prd_Des")
                                sFiador.strNombre = cDtl_Fiador.DDOC_PRD_DES
                            Case ("DDoc_RF1_Cod")
                                sFiador.strDPI = cDtl_Fiador.DDOC_RF1_COD
                            Case ("DDoc_RF2_Cod")
                                sFiador.strMunicipio = cDtl_Fiador.DDOC_RF2_COD
                            Case ("DDoc_Prd_Ref")
                                sFiador.strDepartamento = cDtl_Fiador.DDOC_PRD_REF
                        End Select
                    Next
                Else
                    MsgBox(cDtl_Fiador.MERROR.ToString)
                End If
            Catch ex As Exception
                MsgBox(ex.ToString)
            End Try
        End If
        ''Seleccionar datos de Nombramiento ***************************************************
        strCondicion = STR_VACIO
        strCondicion = "DDoc_Sis_Emp = {empresa} AND DDoc_Doc_Cat = 465 AND DDoc_Doc_Ano= {año}" & _
                  " AND DDoc_Doc_Num = {id} AND DDoc_Doc_Lin = 3"
        strCondicion = Replace(strCondicion, "{empresa}", Sesion.IdEmpresa)
        strCondicion = Replace(strCondicion, "{año}", sPagare.intAño)
        strCondicion = Replace(strCondicion, "{id}", sPagare.Id)
        strCampos_DTLFiador = STR_VACIO
        strCampos_DTLFiador = "DDoc_RF2_Fec,DDoc_Prd_UM"
        Try
            cDTL_Nombramiento.CONEXION = strConexion
            If cDTL_Nombramiento.Seleccionar(strCondicion, strCampos_DTLFiador) = True Then
                sDeudor.fechaVencimiento = cDTL_Nombramiento.DDOC_RF2_FEC
                sDeudor.logIndefino = cDTL_Nombramiento.DDOC_PRD_UM
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        ''seleccionar datos adicionales *******************************************************
        If Not strCampos_DTLDetalle = STR_VACIO Then
            strCondicion = STR_VACIO
            strCondicion = "DDoc_Sis_Emp = {empresa} AND DDoc_Doc_Cat = 465 AND DDoc_Doc_Ano= {año}" & _
                  " AND DDoc_Doc_Num = {id} AND DDoc_Doc_Lin = 2"
            strCondicion = Replace(strCondicion, "{empresa}", Sesion.IdEmpresa)
            strCondicion = Replace(strCondicion, "{año}", sPagare.intAño)
            strCondicion = Replace(strCondicion, "{id}", sPagare.Id)
            If strCampos_DTLDetalle = STR_ASTERISCO Then
                strCampos_DTLDetalle = STR_VACIO
                strCampos_DTLDetalle = "DDoc_RF1_Txt, DDoc_RF2_Cod, DDoc_Prd_Ref"
            End If
            Try
                Dim cDTL_Notificaciones As New clsDcmtos_DTL
                cDTL_Notificaciones.CONEXION = strConexion
                If cDTL_Notificaciones.Seleccionar(strCondicion, strCampos_DTLDetalle) = True Then
                    arrayCampo_Dtl_Dettalle = strCampos_DTLDetalle.Split(",".ToCharArray)
                    For i = 0 To arrayCampo_Dtl_Dettalle.Length - 1
                        Select Case Trim(arrayCampo_Dtl_Dettalle(i))
                            Case "DDoc_RF1_Txt"
                                sDeudor.strNotificaciones = cDTL_Notificaciones.DDOC_RF1_TXT
                            Case "DDoc_RF2_Cod"
                                sDeudor.strNotificacionesMunicipio = cDTL_Notificaciones.DDOC_RF2_COD
                            Case "DDoc_Prd_Ref"
                                sDeudor.strNotificacionesDepartamento = cDTL_Notificaciones.DDOC_PRD_REF
                        End Select
                    Next
                Else
                    MsgBox(cDTL_Notificaciones.MERROR.ToString)
                End If
                Selecionar = True
            Catch ex As Exception
                MsgBox(ex.ToString)
            End Try
        End If
    End Function

    Public Function SeleccionarPro(ByRef Lista As DataGridView, ByVal IdPagare As Integer) As Boolean
        SeleccionarPro = False
       
        Dim strSQL As String = STR_VACIO
        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader
        Dim Cell As DataGridViewCell
        Dim Row = New DataGridViewRow
        strSQL = "select PDoc_DR1_Num,PDoc_Par_Ano, PDoc_Par_Num, HDoc_Emp_Nom, HDoc_Doc_Fec, cat_clave ,PDoc_QTY_Pro " & _
            " from Dcmtos_DTL_Pro left join Dcmtos_HDR on HDoc_Doc_Cat= PDoc_Par_Cat and HDoc_Doc_Num" & _
            " = PDoc_Par_Num and PDoc_Par_Ano= HDoc_Doc_Ano left join Catalogos on HDoc_Doc_Mon= cat_num" & _
            " where PDoc_Par_Cat = 36 and PDoc_Chi_Cat = 465 and PDoc_Chi_Num= " & IdPagare & " and PDoc_Chi_Ano = " & PagareAño
        Try
            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSQL, CON)
            REA = COM.ExecuteReader
            Lista.Rows.Clear()
            If REA.HasRows = True Then
                Do While REA.Read
                    Row = New DataGridViewRow
                    Cell = New DataGridViewTextBoxCell
                    Cell.Value = REA.GetInt32("PDoc_Par_Ano")
                    Row.Cells.Add(Cell)
                    Cell = New DataGridViewTextBoxCell
                    Cell.Value = REA.GetInt32("PDoc_Par_Num")
                    Row.Cells.Add(Cell)
                    Cell = New DataGridViewTextBoxCell
                    Cell.Value = REA.GetString("HDoc_Emp_Nom")
                    Row.Cells.Add(Cell)
                    Cell = New DataGridViewTextBoxCell
                    If REA.GetMySqlDateTime("HDoc_Doc_Fec").IsValidDateTime Then
                        Cell.Value = REA.GetMySqlDateTime("HDoc_Doc_Fec")
                    Else
                        Cell.Value = "Sin fecha"
                    End If
                    Row.Cells.Add(Cell)
                    Cell = New DataGridViewTextBoxCell

                    Cell.Value = REA.GetString("cat_clave")
                    Row.Cells.Add(Cell)
                    Cell = New DataGridViewTextBoxCell
                    Cell.Value = Format(REA.GetDouble("PDoc_QTY_Pro"), FORMATO_MONEDA)
                    Row.Cells.Add(Cell)
                    Cell = New DataGridViewTextBoxCell
                    Cell.Value = REA.GetString("PDoc_DR1_Num")
                    Row.Cells.Add(Cell)
                    Lista.Rows.Add(Row)
                Loop
                SeleccionarPro = True
            End If
        Catch ex As Exception
            MsgBox(" clsPagare.SeleccionarPro- -->" & ex.ToString)
        End Try
    End Function

    Public Function NumerosdePedido(ByVal strNoPedido As String) As String
        Dim arrayPedidos() As String
        If strPedidos = STR_VACIO Then
            strPedidos = strNoPedido
        Else
            arrayPedidos = strPedidos.Split("&".ToCharArray)
            For i = 0 To arrayPedidos.Length - 1
                If Not arrayPedidos(i) = strNoPedido Then
                    strPedidos &= "&" & strNoPedido
                End If
            Next
        End If
        Return strPedidos
    End Function

    Public Function CalcularMonto(ByVal intAño As Integer, ByVal intEmpresa As Integer, ByVal intFactura As Integer) As Double
        Dim strSQL As String = STR_VACIO
        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader
        Dim MONTO As Double = INT_CERO

        strSQL = "SELECT (df.DDoc_Prd_QTY* if(df.DDoc_Prd_UM = 70 , dp.DDoc_Prd_NET*2.2046, dp.DDoc_Prd_NET))  total, hp.HDoc_DR1_Num pedido" & _
            " from Dcmtos_HDR f " & _
            " 	left join  Dcmtos_DTL df " & _
            "       on f.HDoc_Doc_Cat= df.DDoc_Doc_Cat and f.HDoc_Doc_Num= df.DDoc_Doc_Num and f.HDoc_Doc_Ano = df.DDoc_Doc_Ano" & _
            "       and f.HDoc_Sis_Emp = df.DDoc_Sis_Emp" & _
            "   left join  Dcmtos_DTL_Pro id " & _
            "       on f.HDoc_Doc_Cat= id.PDoc_Chi_Cat and f.HDoc_Doc_Ano= id.PDoc_Chi_Ano and f.HDoc_Doc_Num = id.PDoc_Chi_Num" & _
            "       and df.DDoc_Doc_Lin = id.PDoc_Chi_Lin and id.PDoc_Par_Cat = 48 and id.PDoc_Sis_Emp = f.HDoc_Sis_Emp" & _
            "   left join Dcmtos_DTL_Pro bo" & _
            "       on id.PDoc_Par_Cat = bo.PDoc_Chi_Cat and id.PDoc_Par_Ano = bo.PDoc_Chi_Ano and id.PDoc_Par_Num = bo.PDoc_Chi_Num " & _
            "       and id.PDoc_Par_Lin = bo.PDoc_Chi_Lin and bo.PDoc_Par_Cat = 75 and bo.PDoc_Sis_Emp = f.HDoc_Sis_Emp " & _
            "   left join Dcmtos_HDR hp" & _
            "       on  bo.PDoc_Par_Cat = hp.HDoc_Doc_Cat  and bo.PDoc_Par_Ano = hp.HDoc_Doc_Ano  and bo.PDoc_Par_Num = hp.HDoc_Doc_Num " & _
            "       and  f.HDoc_Sis_Emp = hp.HDoc_Sis_Emp " & _
            "   left join Dcmtos_DTL dp" & _
            "       on bo.PDoc_Par_Cat = dp.DDoc_Doc_Cat  and bo.PDoc_Par_Ano = dp.DDoc_Doc_Ano  and bo.PDoc_Par_Num = dp.DDoc_Doc_Num " & _
            "       and bo.PDoc_Par_Lin = dp.DDoc_Doc_Lin  and f.HDoc_Sis_Emp = dp.DDoc_Sis_Emp " & _
            "where f.HDoc_Doc_Cat=36 and f.HDoc_Doc_Num = {id} and f.HDoc_Doc_Ano= {ano}  and f.HDoc_Sis_Emp = {empresa}"
        strSQL = Replace(strSQL, "{id}", intFactura)
        strSQL = Replace(strSQL, "{ano}", intAño)
        strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
        Try
            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSQL, CON)
            REA = COM.ExecuteReader
            strPedidos = STR_VACIO
            If REA.HasRows = True Then
                Do While REA.Read
                    MONTO = MONTO + REA.GetDouble("total")
                    NumerosdePedido(REA.GetString("pedido"))
                Loop
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        Return MONTO
    End Function

   

#End Region

End Class