﻿Public Class ClsNomina
#Region "General"

    Public Sub CargarLista(ByRef lista As DataGridView, ByVal strSQL As String)
        Dim COM As New MySqlCommand
        Dim DAR As MySqlDataAdapter
        Dim dataTable As New System.Data.DataTable
        Try
            MyCnn.CONECTAR = strConexion
            If MyCnn.ProbarConexiones = True Then
                COM = New MySqlCommand(strSQL, CON)
                COM.CommandType = CommandType.Text
                DAR = New MySqlDataAdapter(COM)
                DAR.Fill(dataTable)
                lista.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.AllCells
                lista.DataSource = dataTable
                lista.RowsDefaultCellStyle.BackColor = Color.White
                lista.AlternatingRowsDefaultCellStyle.BackColor = Color.AliceBlue
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

#End Region

#Region "Centros"
    Private Function NuevoCentro() As Integer
        NuevoCentro = NO_FILA
        Dim strSQL As String
        Dim COM As MySqlCommand
        strSQL = "Select ifnull(max(cen_codigo),0)+1 From Centros Where cen_empresa= " & Sesion.IdEmpresa

        Try
            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSQL, CON)
            NuevoCentro = CInt(COM.ExecuteScalar)
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Function
    Private Function ComprobarCentro(ByVal codigo As Integer, ByVal strDescripcion As String, ByVal strdireccion As String, ByVal strmunicipio As String, Optional ByVal logInsert As Boolean = True) As Boolean
        Dim logok As Boolean = False
        Dim strSQL As String = ""
        Dim COM As MySqlCommand
        If logInsert = True Then
            strSQL = "SELECT COUNT(*) FROM Centros WHERE cen_empresa=" & Sesion.IdEmpresa & " AND (cen_codigo=" & codigo & " OR cen_descripcion='" & strDescripcion & "')"
        Else
            strSQL = "SELECT COUNT(*) FROM Centros WHERE cen_empresa=" & Sesion.IdEmpresa & " AND cen_descripcion='" & strDescripcion & "' AND NOT(cen_codigo=" & codigo & ")"
        End If
        MyCnn.CONECTAR = strConexion
        If MyCnn.ProbarConexiones = True Then
            COM = New MySqlCommand(strSQL, CON)
            COM.CommandType = CommandType.Text
            If COM.ExecuteScalar = vbEmpty Then
                logok = True
            End If
        End If
        Return logok
    End Function

    Public Function GuardarCentro(ByVal codigo As Integer, ByVal strDirecion As String, ByVal strdireccion As String, ByVal strmunicipio As String, Optional ByVal logInsert As Boolean = True) As Boolean
        Dim LOGOK As Boolean = False
        Dim COM As MySqlCommand
        Dim NUEVOID As Integer = -1
        Dim strSQL As String = ""
        If ComprobarCentro(codigo, strDirecion, strdireccion, strmunicipio, logInsert) = True Then
            If logInsert = True Then
                strSQL = "INSERT INTO Centros VALUES ({empresa},{codigo},'{descripcion}','{direcion}','{municipio}') ;"

                If Sesion.IdEmpresa = 18 Then
                    strSQL &= "INSERT INTO PDM.Centros VALUES ({empresa},{codigo},'{descripcion}','{direcion}','{municipio}') ;"
                End If

                strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
                strSQL = Replace(strSQL, "{codigo}", NuevoCentro)
                strSQL = Replace(strSQL, "{descripcion}", strDirecion)
                strSQL = Replace(strSQL, "{direcion}", strdireccion)
                strSQL = Replace(strSQL, "{municipio}", strmunicipio)

            Else
                strSQL = "UPDATE Centros SET cen_descripcion = {descripcion}, cen_direccion = {direccion}, cen_municipio = {municipio} WHERE cen_codigo= {codigo} AND cen_empresa = {empresa} ;"
                If Sesion.IdEmpresa = 18 Then
                    strSQL &= "UPDATE PDM.Centros SET cen_descripcion = {descripcion}, cen_direccion = {direccion}, cen_municipio = {municipio} WHERE cen_codigo= {codigo} AND cen_empresa = {empresa} ;"
                End If
                strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
                strSQL = Replace(strSQL, "{codigo}", codigo)
                strSQL = Replace(strSQL, "{descripcion}", strDirecion)
                strSQL = Replace(strSQL, "{direcion}", strdireccion)
                strSQL = Replace(strSQL, "{municipio}", strmunicipio)
            End If
            Try
                MyCnn.CONECTAR = strConexion
                If MyCnn.ProbarConexiones = True Then
                    COM = New MySqlCommand(strSQL, CON)
                    COM.ExecuteNonQuery()
                    LOGOK = True
                End If
            Catch ex As Exception
                MsgBox(ex.ToString)
            End Try
        End If
        Return LOGOK
    End Function

    Public Function BorrarCentro(ByVal idcentro As Integer, ByVal centro As String) As Boolean
        Dim logOk As Boolean = False
        Dim intDep As Integer = -1
        Dim COM As MySqlCommand
        If MsgBox("¿Desea borrar el centro seleccionado?" & vbNewLine & " Centro: " & centro, MsgBoxStyle.Question + MsgBoxStyle.YesNo) = MsgBoxResult.Yes Then
            Try
                intDep = cFunciones.GetIdCatalgo("Doc_EmpContrato")
                MyCnn.CONECTAR = strConexion
                If MyCnn.ProbarConexiones = True Then
                    COM = New MySqlCommand("SELECT COUNT(*) FROM Dcmtos_HDR WHERE HDoc_Sis_Emp= " & Sesion.IdEmpresa & " AND HDoc_Doc_Cat= " & intDep & " AND HDoc_DR1_Cat= " & idcentro, CON)
                    If COM.ExecuteScalar > vbEmpty Then
                        MsgBox("No se puede borrar si está en uso", MsgBoxStyle.Critical)
                    Else
                        If MyCnn.BorrarRegistro("Centros", "cen_empresa= " & Sesion.IdEmpresa & " AND cen_codigo= " & idcentro, 1) = True Then
                            cFunciones.EscribirRegistro("Centros", clsFunciones.AccEnum.acDelete, idcentro)
                        End If
                        'COM = New MySqlCommand("DELETE FROM Centros WHERE cen_empresa= " & Sesion.IdEmpresa & " AND cen_codigo= " & idcentro)
                        logOk = True
                    End If
                End If
            Catch ex As Exception
                MsgBox(ex.ToString)
            End Try
        End If
        Return logOk
    End Function

    Public Function SelecionarPuesto() As Boolean
        SelecionarPuesto = False
    End Function


#End Region

#Region "Departamentos"

    Private Function ComprobarDepartamento(ByVal id As Integer, ByVal descripcion As String, Optional ByVal logInsert As Boolean = True) As Boolean
        Dim logOk As Boolean = False
        Dim strSQL As String = ""
        Dim intOk As Integer = -1
        Dim COM As MySqlCommand
        If logInsert = True Then
            strSQL = "SELECT COUNT(*) FROM Departamentos WHERE dep_sisemp= " & Sesion.IdEmpresa & " AND (dep_no= " & id & " OR dep_descripcion= '" & cFunciones.MyStr(descripcion) & "')"
        Else
            strSQL = "SELECT COUNT(*) FROM Departamentos WHERE dep_sisemp=" & Sesion.IdEmpresa & " AND dep_descripcion= '" & cFunciones.MyStr(descripcion) & "' AND NOT(dep_no= " & id & ")"
        End If
        Try
            MyCnn.CONECTAR = strConexion
            If MyCnn.ProbarConexiones = True Then
                COM = New MySqlCommand(strSQL, CON)
                intOk = COM.ExecuteScalar
                If intOk > 0 Then
                    MsgBox("El departamento ya existe")
                Else
                    logOk = True
                End If
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        Return logOk
    End Function

    Public Function GuardarDepartamento(ByVal id As Integer, ByVal descripcion As String, Optional ByVal logInsert As Boolean = True) As Boolean
        Dim logOk As Boolean = False
        Dim strSQL As String = ""
        Dim intNuevoId As Integer = -1
        Dim COM As MySqlCommand
        If ComprobarDepartamento(id, descripcion, logInsert) = True Then
            strSQL = "SELECT (IFNULL(MAX(dep_no),0)+1) ID FROM Departamentos WHERE dep_sisemp=" & Sesion.IdEmpresa
            Try
                MyCnn.CONECTAR = strConexion
                If MyCnn.ProbarConexiones = True Then
                    COM = New MySqlCommand(strSQL, CON)
                    intNuevoId = CInt(COM.ExecuteScalar)
                End If
            Catch ex As Exception
                MsgBox(ex.ToString)
            End Try
            If logInsert = True Then
                strSQL = "INSERT INTO Departamentos VALUES ({empresa},{codigo},'{descripcion}') ;"
                strSQL = Replace(strSQL, "{codigo}", intNuevoId)
            Else
                strSQL = "UPDATE Departamentos SET dep_descripcion = '{descripcion}' WHERE dep_no= {codigo} AND dep_sisemp = {empresa} ;"
                strSQL = Replace(strSQL, "{codigo}", id)
            End If

            If Sesion.IdEmpresa = 18 Then
                If logInsert = True Then
                    strSQL = "INSERT INTO Departamentos VALUES ({empresa},{codigo},'{descripcion}') ;"
                    strSQL = Replace(strSQL, "{codigo}", intNuevoId)
                Else
                    strSQL = "UPDATE Departamentos SET dep_descripcion = '{descripcion}' WHERE dep_no= {codigo} AND dep_sisemp = {empresa} ;"
                    strSQL = Replace(strSQL, "{codigo}", id)
                End If
            End If

            strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
            strSQL = Replace(strSQL, "{descripcion}", descripcion)
            Try
                MyCnn.CONECTAR = strConexion
                If MyCnn.ProbarConexiones = True Then
                    COM = New MySqlCommand(strSQL, CON)
                    COM.ExecuteNonQuery()
                    If logInsert = True Then
                        cFunciones.EscribirRegistro("Departamentos", clsFunciones.AccEnum.acAdd, intNuevoId, )
                    Else
                        cFunciones.EscribirRegistro("Departamentos", clsFunciones.AccEnum.acUpdate, id, )
                    End If
                End If
                logOk = True
            Catch ex As Exception
                MsgBox(ex.ToString)
            End Try
        End If

        Return logOk
    End Function

    Public Function BorrarDepartamento(ByVal id As Integer, ByVal descripcion As String) As Boolean
        Dim logOk As Boolean = False
        Dim intDep As Integer = -1
        Dim COM As MySqlCommand
        If MsgBox("¿Desea borrar el departamento seleccionado?" & vbNewLine & " Departamento: " & descripcion, MsgBoxStyle.Question + MsgBoxStyle.YesNo) = MsgBoxResult.Yes Then
            Try
                intDep = cFunciones.GetIdCatalgo("Doc_EmpContrato")
                MyCnn.CONECTAR = strConexion
                If MyCnn.ProbarConexiones = True Then
                    COM = New MySqlCommand("SELECT COUNT(*) FROM Dcmtos_HDR WHERE HDoc_Sis_Emp= " & Sesion.IdEmpresa & " AND HDoc_Doc_Cat= " & intDep & " AND HDoc_DR1_Cat= " & id, CON)
                    If COM.ExecuteScalar > vbEmpty Then
                        MsgBox("No se puede borrar si está en uso", MsgBoxStyle.Critical)
                    Else
                        COM = Nothing
                        MyCnn.CONECTAR = strConexion
                        If MyCnn.ProbarConexiones = True Then
                            Dim sql As String = "DELETE FROM Departamentos WHERE dep_sisemp= " & Sesion.IdEmpresa & " And dep_no= " & id & ";"
                            If Sesion.IdEmpresa = 18 Then
                                sql &= "DELETE FROM PMD.Departamentos WHERE dep_sisemp= " & 18 & " And dep_no= " & id & ";"
                            End If
                            COM = New MySqlCommand(sql, CON)
                            COM.ExecuteNonQuery()
                            cFunciones.EscribirRegistro("Departamentos", clsFunciones.AccEnum.acDelete, id)
                            logOk = True
                        End If
                    End If
                End If
            Catch ex As Exception
                MsgBox(ex.ToString)
            End Try
        End If
        Return logOk
    End Function

#End Region

#Region "Puestos"

   

    Private Function ComprobarPuesto(ByVal id As Integer, ByVal descripcion As String, Optional ByVal logInsert As Boolean = True) As Boolean
        Dim logOk As Boolean = False
        Dim strSQL As String = ""
        Dim intPuesto As Integer = -1
        Dim COM As MySqlCommand
        If logInsert = True Then
            strSQL = "Select COUNT(*) FROM Puestos WHERE pue_sisemp=" & Sesion.IdEmpresa & " And (pue_codigo= " & id & " Or pue_descripcion= '" & cFunciones.MyStr(descripcion) & "')"
        Else
            strSQL = "SELECT COUNT(*) FROM Puestos WHERE pue_sisemp=" & Sesion.IdEmpresa & " AND pue_descripcion= '" & cFunciones.MyStr(descripcion) & "' AND NOT(pue_codigo= " & id & ")"
        End If
        Try
            MyCnn.CONECTAR = strConexion
            If MyCnn.ProbarConexiones = True Then
                COM = New MySqlCommand(strSQL, CON)
                intPuesto = CInt(COM.ExecuteScalar)
                If intPuesto > 0 Then
                    logOk = True
                End If
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        Return logOk
    End Function

    Public Function GuardarPuesto(ByVal id As Integer, ByVal descripcion As String, Optional ByVal loginsert As Boolean = True) As Boolean
        Dim logOk As Boolean = False
        Dim strSQL As String = ""
        Dim COM As MySqlCommand
        Dim intNuevoId As Integer = -1
        If ComprobarPuesto(id, descripcion, loginsert) = True Then
            'recuperar id
            strSQL = "SELECT (IFNULL(MAX(dep_no),0)+1) ID FROM Puestos WHERE pue_sisemp=" & Sesion.IdEmpresa
            Try
                MyCnn.CONECTAR = strConexion
                If MyCnn.ProbarConexiones = True Then
                    COM = New MySqlCommand(strSQL, CON)
                    intNuevoId = CInt(COM.ExecuteScalar)
                End If
            Catch ex As Exception
                MsgBox(ex.ToString)
            End Try
            If loginsert = True Then
                strSQL = "INSERT INTO Puestos VALUES ({empresa},{codigo},'{descripcion}')"
                strSQL = Replace(strSQL, "{codigo}", intNuevoId)
            Else
                strSQL = "UPDATE Departamentos SET dep_descripcion = '{descripcion}' WHERE dep_no= {codigo} AND dep_sisemp = {empresa} "
                strSQL = Replace(strSQL, "{codigo}", id)
            End If
            strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
            strSQL = Replace(strSQL, "{descripcion}", descripcion)
            Try
                MyCnn.CONECTAR = strConexion
                If MyCnn.ProbarConexiones = True Then
                    COM = New MySqlCommand(strSQL, CON)
                    COM.ExecuteNonQuery()
                    If loginsert = True Then
                        cFunciones.EscribirRegistro("Departamentos", clsFunciones.AccEnum.acAdd, intNuevoId, )
                    Else
                        cFunciones.EscribirRegistro("Departamentos", clsFunciones.AccEnum.acUpdate, id, )
                    End If
                End If
                logOk = True
            Catch ex As Exception
                MsgBox(ex.ToString)
            End Try
        End If
        Return logOk
    End Function

    Public Function BorrarPuesto(ByVal id As Integer, ByVal descripcion As String) As Boolean
        Dim logOk As Boolean = False
        Dim intDep As Integer = -1
        Dim COM As MySqlCommand
        If MsgBox("¿Desea borrar el puesto seleccionado?" & vbNewLine & " Puesto: " & descripcion, MsgBoxStyle.Question + MsgBoxStyle.YesNo) = MsgBoxResult.Yes Then
            Try
                intDep = cFunciones.GetIdCatalgo("Doc_EmpContrato")
                MyCnn.CONECTAR = strConexion
                If MyCnn.ProbarConexiones = True Then
                    COM = New MySqlCommand("SELECT COUNT(*) FROM Dcmtos_HDR WHERE HDoc_Sis_Emp= " & Sesion.IdEmpresa & " AND HDoc_Doc_Cat= " & intDep & " AND HDoc_DR1_Cat= " & id, CON)
                    If COM.ExecuteScalar > vbEmpty Then
                        MsgBox("No se puede borrar si está en uso", MsgBoxStyle.Critical)
                    Else
                        COM = Nothing
                        MyCnn.CONECTAR = strConexion
                        If MyCnn.ProbarConexiones = True Then
                            COM = New MySqlCommand("DELETE FROM Puestos WHERE dep_sisemp= " & Sesion.IdEmpresa & " AND dep_no= " & id, CON)
                            COM.ExecuteNonQuery()
                            cFunciones.EscribirRegistro("Puestos", clsFunciones.AccEnum.acDelete, id)
                            logOk = True
                        End If
                    End If
                End If
                
            Catch ex As Exception
                MsgBox(ex.ToString)
            End Try
        End If
        Return logOk
    End Function

#End Region

End Class
