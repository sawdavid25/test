﻿Public Class clsClaimRegister

#Region "Variables de Instancia"


    Private intFechaClaim As MySqlDateTime
    Private intAnoClaim As Integer = INT_CERO
    Private intApply As Integer = -1
    Private intIdNuevo As Integer = INT_CERO
    Private intCodCustomer As Integer = INT_CERO
    Private strNameCustomer As String = STR_VACIO
    Private intInvoceNumber As Integer = INT_CERO
    Private intañoFactura As Integer = INT_CERO
    Private intLinea As Integer = INT_CERO
    Private strProvider As String = STR_VACIO
    Private strCustomerRepresentative = STR_VACIO
    Private intDateInvoce As MySqlDateTime
    Private strActionDone As String = STR_VACIO
    Private dblQuantitySold As Double = 0
    Private strLotNumber As String = STR_VACIO
    Private strYarnDescription As String = STR_VACIO
    Private strLocationProblem As String = STR_VACIO
    Private strTypeProblem As String = STR_VACIO
    Private strDificultiesCustomer As String = STR_VACIO
    Private dblTotalDefectQuantity As Double = 0
    Private dblTotalSavageQuantity As Double = 0
    Private intAplicaoNoAplica As Integer = INT_CERO
    Private dblOriginalAmount As Double = 0
    Private dblTotalChargeback As Double = 0
    Private strObservaciones As String = STR_VACIO
    Private strSolucion As String = STR_VACIO
    Private strPais As String = STR_VACIO
    Private strTypeAnalysis As String = STR_VACIO
    Private strVerificacionyConfirmacion As String = STR_VACIO
    Private strReferencesNum As String = STR_VACIO
    Private strNoExplain As String = STR_VACIO
    Private dblTDQuantity As Double = INT_CERO

#End Region



#Region "Propiedades de Instancia"


    Public Property IdCalim As Integer
        Get
            Return intIdNuevo
        End Get
        Set(value As Integer)
            intIdNuevo = value
        End Set
    End Property


    Public Property TotalDefect As Double
        Get
            Return dblTDQuantity
        End Get
        Set(value As Double)
            dblTDQuantity = value
        End Set
    End Property


    Public Property Pais As String
        Get
            Return strPais
        End Get
        Set(value As String)
            strPais = value
        End Set
    End Property


    Public Property FechaClaim As Date
        Get
            Return intFechaClaim
        End Get
        Set(value As Date)
            intFechaClaim = New MySqlDateTime(value.Year, value.Month, value.Day, value.Hour, value.Minute, value.Second)
        End Set
    End Property


    Public Property DateInvoce As Date
        Get
            Return intDateInvoce
        End Get
        Set(value As Date)
            intDateInvoce = New MySqlDateTime(value.Year, value.Month, value.Day, value.Hour, value.Minute, value.Second)
        End Set
    End Property
    

    Public Property Apply As Integer
        Get
            Return intApply
        End Get
        Set(value As Integer)
            intApply = value
        End Set
    End Property


    Public Property AnoClaim As Integer
        Get
            Return intAnoClaim
        End Get
        Set(value As Integer)
            intAnoClaim = value
        End Set
    End Property

    Public Property Linea As Integer
        Get
            Return intLinea
        End Get
        Set(value As Integer)
            intLinea = value
        End Set
    End Property

    Public Property CodigoCustomer As Integer
        Get
            Return intCodCustomer
        End Get
        Set(value As Integer)
            intCodCustomer = value
        End Set
    End Property


    Public Property NameCustomer As String
        Get
            Return strNameCustomer
        End Get
        Set(value As String)
            strNameCustomer = value
        End Set
    End Property

    Public Property InvoceNumber As Integer
        Get
            Return intInvoceNumber
        End Get
        Set(value As Integer)
            intInvoceNumber = value
        End Set
    End Property


    Public Property AnoFactura As Integer
        Get
            Return intañoFactura
        End Get
        Set(value As Integer)
            intañoFactura = value
        End Set
    End Property


    Public Property Provider As String
        Get
            Return strProvider
        End Get
        Set(value As String)
            strProvider = value
        End Set
    End Property

    Public Property CustomerRepresentative As String
        Get
            Return strCustomerRepresentative
        End Get
        Set(value As String)
            strCustomerRepresentative = value
        End Set
    End Property

    Public Property LocationProblem As String
        Get
            Return strLocationProblem
        End Get
        Set(value As String)
            strLocationProblem = value
        End Set
    End Property

    Public Property TypeProblem As String
        Get
            Return strTypeProblem
        End Get
        Set(value As String)
            strTypeProblem = value
        End Set
    End Property

    Public Property DificultiesCustomer As String
        Get
            Return strDificultiesCustomer
        End Get
        Set(value As String)
            strDificultiesCustomer = value
        End Set
    End Property


    Public Property ActionDone As String
        Get
            Return strActionDone
        End Get
        Set(value As String)
            strActionDone = value
        End Set
    End Property

    Public Property QuantitySold As Double
        Get
            Return dblQuantitySold
        End Get
        Set(value As Double)
            dblQuantitySold = value
        End Set
    End Property

    Public Property LotNumber As String
        Get
            Return strLotNumber
        End Get
        Set(value As String)
            strLotNumber = value
        End Set
    End Property

    Public Property YarnDescription As String
        Get
            Return strYarnDescription
        End Get
        Set(value As String)
            strYarnDescription = value
        End Set
    End Property

    Public Property OriginalAmount As Double
        Get
            Return dblOriginalAmount
        End Get
        Set(value As Double)
            dblOriginalAmount = value
        End Set
    End Property

    Public Property TotalChargeback As Double
        Get
            Return dblTotalChargeback
        End Get
        Set(value As Double)
            dblTotalChargeback = value
        End Set
    End Property

    Public Property Observaciones As String
        Get
            Return strObservaciones
        End Get
        Set(value As String)
            strObservaciones = value
        End Set
    End Property

    Public Property Soluciones As String
        Get
            Return strSolucion
        End Get
        Set(value As String)
            strSolucion = value
        End Set
    End Property

    Public Property Analysis As String
        Get
            Return strTypeAnalysis
        End Get
        Set(value As String)
            strTypeAnalysis = value
        End Set
    End Property

    Public Property Verificacion As String
        Get
            Return strVerificacionyConfirmacion
        End Get
        Set(value As String)
            strVerificacionyConfirmacion = value
        End Set
    End Property

    Public Property DefectQuantity As Double
        Get
            Return dblTotalDefectQuantity
        End Get
        Set(value As Double)
            dblTotalDefectQuantity = value
        End Set
    End Property


    Public Property SaveQuantity As Double
        Get
            Return dblTotalSavageQuantity
        End Get
        Set(value As Double)
            dblTotalSavageQuantity = value
        End Set
    End Property

    Public Property ReferenciaClaim As String
        Get
            Return strReferencesNum
        End Get
        Set(value As String)
            strReferencesNum = value
        End Set
    End Property

    Public Property NoExplain As String
        Get
            Return strNoExplain
        End Get
        Set(value As String)
            strNoExplain = value
        End Set
    End Property

#End Region

#Region "Funciones"

    Public Function BuscarRegistro() As String
        Dim cHDR As New clsDcmtos_HDR

        Dim strSQL As String = STR_VACIO

        strSQL = "select count(*) valor "
        strSQL &= "From Dcmtos_HDR "
        strSQL &= "Where HDoc_Sis_emp = {empresa} AND HDoc_Doc_Cat = 984 AND HDoc_Doc_Ano = {año} AND HDoc_Doc_Num = {claim}"

        strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
        strSQL = Replace(strSQL, "{año}", intAnoClaim)
        strSQL = Replace(strSQL, "{claim}", intIdNuevo)

        Return strSQL

    End Function

    Public Function Seleccionar(ByVal intAnoClaim As Integer, ByVal intIdNuevo As Integer, ByVal intLinea As Integer)
        Seleccionar = False
        Dim cHDR As New clsDcmtos_HDR
        Dim cDtl As New clsDcmtos_DTL

        Dim strCondicion As String = STR_VACIO
        Dim strCampos As String = STR_VACIO

        strCampos = "HDoc_Doc_Num,HDoc_Emp_Cod,HDoc_Emp_Dir,HDoc_Emp_Nom,HDoc_Emp_Per,HDoc_Emp_Tel,HDoc_DR1_Fec,HDoc_DR2_Emp,HDoc_Pro_DNum, "
        strCampos &= "HDoc_DR2_Num,HDoc_RF1_Cod,HDoc_RF1_Txt,HDoc_Pro_DAno,Hdoc_Doc_Num, HDoc_RF2_Cod,HDoc_DR1_Num,HDoc_Doc_Status,HDoc_Emp_Nit, "
        strCampos &= "HDoc_DR1_Dbl"

        strCondicion = "HDoc_Sis_Emp = {empresa} and HDoc_Doc_Cat = 984 and HDoc_Doc_Ano = {año} and HDoc_Doc_Num = {numero} and HDoc_DR2_Emp = {linea}"

        strCondicion = Replace(strCondicion, "{empresa}", Sesion.IdEmpresa)
        strCondicion = Replace(strCondicion, "{año}", intAnoClaim)
        strCondicion = Replace(strCondicion, "{numero}", intIdNuevo)
        strCondicion = Replace(strCondicion, "{linea}", intLinea)

        Try
            If cHDR.Seleccionar(strCondicion, strCampos) = True Then
                intCodCustomer = cHDR.HDOC_EMP_COD
                intIdNuevo = cHDR.HDOC_DOC_NUM

                strNameCustomer = cHDR.HDOC_EMP_NOM
                intInvoceNumber = cHDR.HDOC_PRO_DNUM
                intDateInvoce = cHDR.HDOC_DR1_FEC
                intañoFactura = cHDR.HDOC_PRO_DANO
                intLinea = cHDR.HDOC_DR2_EMP
                strProvider = cHDR.HDOC_EMP_TEL
                strCustomerRepresentative = cHDR.HDOC_DR2_NUM
                strLocationProblem = cHDR.HDOC_EMP_DIR
                strTypeProblem = cHDR.HDOC_RF1_TXT
                strDificultiesCustomer = cHDR.HDOC_RF1_COD
                strVerificacionyConfirmacion = cHDR.HDOC_RF2_COD
                ActionDone = cHDR.HDOC_EMP_PER
                ReferenciaClaim = cHDR.HDOC_DR1_NUM
                intApply = cHDR.HDOC_DOC_STATUS
                dblTDQuantity = cHDR.HDOC_DR1_DBL


                strCampos = "DDoc_Prd_DSQ,DDoc_RF1_Cod,DDoc_Prd_QTY,DDoc_RF3_Txt,DDoc_Prd_Des,"
                strCampos &= "DDoc_Prd_NET,DDoc_RF1_Txt, DDoc_RF2_Txt,DDoc_Prd_PUQ,DDoc_Prd_DSP  "

                strCondicion = "DDoc_Sis_Emp = {empresa} and DDoc_Doc_Cat = 984 and DDoc_Doc_Ano = {año} and DDoc_Doc_Num = {numero} "

                strCondicion = Replace(strCondicion, "{empresa}", Sesion.IdEmpresa)
                strCondicion = Replace(strCondicion, "{año}", intAnoClaim)
                strCondicion = Replace(strCondicion, "{numero}", intIdNuevo)


                If cDtl.Seleccionar(strCondicion, strCampos) Then
                    strYarnDescription = cDtl.DDOC_PRD_DES
                    dblOriginalAmount = cDtl.DDOC_PRD_PUQ
                    dblQuantitySold = cDtl.DDOC_PRD_DSQ
                    dblTotalSavageQuantity = cDtl.DDOC_PRD_NET
                    strLotNumber = cDtl.DDOC_RF1_COD
                    strObservaciones = cDtl.DDOC_RF1_TXT
                    strSolucion = cDtl.DDOC_RF2_TXT
                    DefectQuantity = cDtl.DDOC_PRD_QTY
                    strTypeAnalysis = cDtl.DDOC_RF3_TXT
                    dblTotalChargeback = cDtl.DDOC_PRD_DSP


                Else
                    MsgBox(cDtl.MERROR.ToString)
                End If
            Else
                MsgBox(cHDR.MERROR.ToString)
            End If
        Catch ex As Exception

        End Try

    End Function

#End Region

#Region "Procedimientos"

    Public Sub ClaimRegister()
        Dim strSql As String = STR_VACIO

        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader

        strSql = " SELECT A.HDoc_Doc_Fec DATE, ifnull(B.DDoc_Prd_QTY,0) Quantity,ifnull(C.inv_prodlote,'') Lote,ifnull(D.art_DCorta,'') Descripcion, "
        strSql &= " ifnull(E.pro_proveedor,'') Proveedor, ifnull(G.HDoc_Usuario,'') Usuario, J.cat_clave Pais "
        strSql &= "FROM Dcmtos_HDR A "
        strSql &= "LEFT JOIN Dcmtos_DTL B ON B.DDoc_Sis_Emp = A.HDoc_Sis_Emp AND B.DDoc_Doc_Cat = A.HDoc_Doc_Cat AND B.DDoc_Doc_Ano = A.HDoc_Doc_Ano AND "
        strSql &= "B.DDoc_Doc_Num = A.HDoc_Doc_Num "
        strSql &= "LEFT JOIN Inventarios C on C.inv_sisemp = B.DDoc_Sis_Emp AND C.inv_numero = B.DDoc_Prd_Cod "
        strSql &= "LEFT JOIN Articulos D on D.art_sisemp = C.inv_sisemp and D.art_codigo = C.inv_artcodigo   "
        strSql &= "LEFT JOIN Proveedores E on E.pro_sisemp = C.inv_sisemp  and E.pro_codigo = C.inv_provcod "
        strSql &= "LEFT JOIN Dcmtos_DTL_Pro F on F.PDoc_Sis_Emp = B.DDoc_Sis_Emp and F.PDoc_Chi_Cat = B.DDoc_Doc_Cat "
        strSql &= "and F.PDoc_Chi_Ano = B.DDoc_Doc_Ano and F.PDoc_Chi_Num = B.DDoc_Doc_Num "
        strSql &= "and F.PDoc_Chi_Lin = B.DDoc_Doc_Lin "
        strSql &= "LEFT JOIN Dcmtos_DTL_Pro H ON H.PDoc_Sis_Emp = F.PDoc_Sis_Emp AND H.PDoc_Chi_Cat = F.PDoc_Par_Cat AND H.PDoc_Chi_Ano = F.PDoc_Par_Ano AND H.PDoc_Chi_Num = F.PDoc_Par_Num AND H.PDoc_Chi_Lin = F.PDoc_Par_Lin "
        strSql &= "AND H.PDoc_Par_Cat = 75 "
        strSql &= "LEFT JOIN Clientes I ON I.cli_sisemp = A.HDoc_Sis_Emp AND I.cli_codigo = A.HDoc_Emp_Cod "
        strSql &= "LEFT JOIN Catalogos J on J.cat_num = I.cli_pais "
        strSql &= "LEFT JOIN Dcmtos_HDR  G ON  G.HDoc_Sis_Emp = H.PDoc_Sis_Emp AND G.HDoc_Doc_Cat = H.PDoc_Par_Cat "
        strSql &= "AND G.HDoc_Doc_Ano = H.PDoc_Par_Ano AND G.HDoc_Doc_Num = H.PDoc_Par_Num "
        strSql &= "WHERE A.HDoc_Sis_Emp = {empresa} and A.Hdoc_Doc_cat = 36  and A.HDoc_Doc_Ano = {anio} and A.HDoc_Doc_Num = {factura} and B.DDoc_Doc_Lin = {lineas} "

        strSql = Replace(strSql, "{empresa}", Sesion.IdEmpresa)
        strSql = Replace(strSql, "{anio}", intañoFactura)
        strSql = Replace(strSql, "{factura}", intInvoceNumber)
        strSql = Replace(strSql, "{lineas}", intLinea)

        Try
            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSql, CON)
            REA = COM.ExecuteReader

            If REA.HasRows = True Then
                REA.Read()
                intDateInvoce = REA.GetMySqlDateTime("Date")
                dblQuantitySold = REA.GetDouble("Quantity").ToString(FORMATO_MONEDA)
                strPais = REA.GetString("Pais")
                strLotNumber = REA.GetString("Lote")
                strCustomerRepresentative = REA.GetString("Usuario")
                strYarnDescription = REA.GetString("Descripcion")
                strProvider = REA.GetString("Proveedor")
            End If

        Catch ex As Exception
            MessageBox.Show(ex.ToString)
        End Try

    End Sub

    Private Function NuevoIDClaim() As Integer
        Dim strSQL As String = STR_VACIO
        Dim Valor As Integer = INT_CERO
        Dim CON As MySqlConnection
        Dim COM As MySqlCommand

        strSQL = "SELECT MAX(TAB.Correlativo) + 1 Siguiente  " & _
                 "From(  " & _
                 "(SELECT ifnull(MAX(HDoc_Doc_Num),0) Correlativo  " & _
                 "FROM Contabilidad.Dcmtos_HDR  " & _
                 "WHERE HDoc_Sis_Emp = 3 and HDoc_Doc_Cat = 984)  " & _
                 "Union  " & _
                 "(SELECT ifnull(MAX(HDoc_Doc_Num),0) Correlativo  " & _
                 "FROM Pride.Dcmtos_HDR  " & _
                 "WHERE HDoc_Sis_Emp = 8  and HDoc_Doc_Cat = 984  " & _
                 ")) TAB  "
        CON = New MySqlConnection(strConexion)
        CON.Open()

        Try
            COM = New MySqlCommand(strSQL, CON)
            Valor = COM.ExecuteScalar
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try

        CON.Close()

        Return Valor

    End Function

    Public Sub Guardar()
        Dim chdr As New clsDcmtos_HDR
        Dim cfun As New clsFunciones
        Dim dtlpro As New clsDcmtos_DTL_Pro
        Dim refActualizacion As String = STR_VACIO
        Dim COM As MySqlCommand
        Dim Valor As Integer = INT_CERO
        Dim strSQL As String = STR_VACIO

        MyCnn.CONECTAR = strConexion

        strSQL = BuscarRegistro()

        COM = New MySqlCommand(strSQL, CON)
        Valor = COM.ExecuteScalar
        intAnoClaim = cfun.AñoMySQL

        chdr.CONEXION = strConexion
        chdr.HDOC_SIS_EMP = Sesion.IdEmpresa
        chdr.HDOC_DOC_CAT = 984
        chdr.HDOC_DOC_FEC = intFechaClaim
        chdr.HDOC_DOC_ANO = intAnoClaim

        chdr.HDOC_EMP_TEL = strPais
        chdr.HDOC_EMP_COD = intCodCustomer
        chdr.HDOC_EMP_NOM = strNameCustomer
        chdr.HDOC_EMP_PER = strActionDone

        chdr.HDOC_EMP_NIT = strLocationProblem
        chdr.HDOC_RF1_TXT = strTypeProblem & "|" & strTypeAnalysis
        chdr.HDOC_RF2_TXT = strDificultiesCustomer
        chdr.HDOC_RF2_COD = strVerificacionyConfirmacion
        chdr.HDOC_DOC_STATUS = intApply
        chdr.HDOC_RF1_COD = strObservaciones
        chdr.HDOC_DR1_NUM = strSolucion
        chdr.HDOC_RF1_DBL = dblOriginalAmount
        chdr.HDOC_RF2_DBL = dblTotalChargeback
        chdr.HDOC_RF3_DBL = DefectQuantity
        chdr.HDOC_DOC_TC = dblTotalSavageQuantity
        chdr.HDOC_DR1_DBL = dblTDQuantity
        'chdr.HDOC_DR2_NUM = strNoExplain

        If Valor = 1 Then
            chdr.HDOC_DOC_NUM = intIdNuevo
            strReferencesNum = strPais & "" & intIdNuevo.ToString & "-" & Month(FechaClaim).ToString & "-" & intAnoClaim
            chdr.HDOC_DR2_NUM = strReferencesNum
            If chdr.Actualizar = True Then
                ' MsgBox("Claim Actualizado")
            Else
                MsgBox("No se pudo actualizar el encabezado ")
            End If
        Else
            intIdNuevo = NuevoIDClaim()
            chdr.HDOC_DOC_NUM = intIdNuevo
            strReferencesNum = strPais & "" & intIdNuevo.ToString & "-" & Month(FechaClaim).ToString & "-" & intAnoClaim
            chdr.HDOC_DR2_NUM = strReferencesNum
            If chdr.Guardar = True Then
                MessageBox.Show("No. de Claim " & strReferencesNum & "", "Registro Almacenado", MessageBoxButtons.OK, MessageBoxIcon.Information)
            Else
                MsgBox(chdr.MERROR.ToString)
            End If

        End If

    End Sub

#End Region

End Class
