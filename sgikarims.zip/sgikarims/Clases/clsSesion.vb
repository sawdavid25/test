﻿Public Class clsSesion
    Dim logFecha As Boolean

#Region "Funciones"
    Public Function CurrentIdSesion(sIdUsuario As String) As String
        Dim strsql As String = STR_VACIO
        Dim REA As MySqlDataReader
        Dim COM As MySqlCommand
        Dim intResultado As Integer = 0
        strsql = "SELECT id_sesion FROM Sesiones WHERE id_sesion in (
                       SELECT MAX(id_sesion) ultima FROM Sesiones  s
                       WHERE usuario = '" & sIdUsuario & "')"


        MyCnn.CONECTAR = strConexion
        COM = New MySqlCommand(strsql, CON)
        Dim da As New MySqlDataAdapter(COM)
        da.SelectCommand.ExecuteNonQuery()
        Dim dt As New System.Data.DataTable
        da.Fill(dt)
        If dt.Rows.Count = 0 Then
            Return Nothing
        End If
        COM.ExecuteNonQuery()

        Return dt.Rows(0).Item("id_sesion")

    End Function
    Public Function EscribirSesion(Optional Inicio As Boolean = True) As Boolean
        Dim conexion As New ClsConexion
        Dim logOK As Boolean = False
        Dim strQuery As String = ""
        strQuery = "INSERT INTO Sesiones (fecha, estacion, ip, usuario, empresa, evento, firma, version) " & _
            "VALUES ({fecha},'{estacion}','{ip}','{usuario}','{empresa}','{evento}','{firma}','{version}')"
        strQuery = Replace(strQuery, "{fecha}", "NOW()")
        strQuery = Replace(strQuery, "{estacion}", cFunciones.MyStr(Sesion.Estacion))
        strQuery = Replace(strQuery, "{ip}", cFunciones.MyStr(Sesion.IP))
        strQuery = Replace(strQuery, "{usuario}", cFunciones.MyStr(Sesion.Usuario))
        strQuery = Replace(strQuery, "{empresa}", cFunciones.MyStr(Sesion.Empresa))
        strQuery = Replace(strQuery, "{evento}", cFunciones.MyStr(IIf(Inicio, "INICIO", "FIN")))
        strQuery = Replace(strQuery, "{firma}", cFunciones.MyStr(Sesion.Firma))
        strQuery = Replace(strQuery, "{version}", cFunciones.MyStr(Sistema.Version))
        Try
            MyCnn.CONECTAR = strConexion
            If MyCnn.ProbarConexiones = True Then
                Dim COM As New MySqlCommand(strQuery, CON)
                COM.ExecuteNonQuery()
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try

        Return logOK
    End Function

    Public Function ComprobarUsuario(ByVal strUsuario As String, ByVal strPass As String) As Boolean
        Dim LogResult As Boolean = False
        Dim strQuery = STR_VACIO
        'Dim FechaPass As Date
        Dim intDias As Integer = 0
        Dim REA As MySqlDataReader
        strQuery = " SELECT p.per_usuario, p.per_codigo, p.per_fecha FROM Personal p WHERE p.per_usuario = '{Usuario}' " &
            "AND (p.per_clave = '{Password}' OR p.per_clave = MD5('{Password}'))"
        strQuery = Replace(strQuery, "{Usuario}", strUsuario)
        strQuery = Replace(strQuery, "{Password}", strPass)
        Try

            REA = MyCnn.GetReader(strQuery)
            If REA.HasRows = False Then
                MsgBox("Usuario o contraseña invalida")
                LogResult = False
                Return LogResult
                Exit Function
            End If
            'FechaPass = REA.GetDateTime("per_fecha")
            'Dim td As TimeSpan = DateTime.Now.Subtract(FechaPass)
            'intDias = td.Days
            'If intDias >= 90 Then
            '    MsgBox("Para Continuar, por favor cambie contraseña", vbInformation, "Info")

            'End If

            LogResult = True
            Sesion.idUsuario = REA.GetInt32("per_codigo")
            Sesion.Usuario = REA.GetString("per_usuario")
            Sesion.IP = cFunciones.ObtenerIPoEquipo(clsFunciones.IpEquipo.ip)
            Sesion.Estacion = cFunciones.ObtenerIPoEquipo(clsFunciones.IpEquipo.equipo)

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        Return LogResult
    End Function

    Public Function debug() As Boolean
        Dim LogDebug As Boolean = False
        Dim array() As String
        array = Environment.CommandLine.Split("\".ToCharArray)
        If array(array.Length - 2) = "Debug" Then
            LogDebug = True
        End If
        Return LogDebug
    End Function

    Public Function Version() As String
        Dim strVersion As String = STR_VACIO
        Try
            strVersion = My.Application.Info.Version.Major
            strVersion &= My.Application.Info.Version.Minor
            strVersion &= My.Application.Info.Version.Build
            If My.Application.Info.Version.MinorRevision.ToString.Length = INT_UNO Then
                strVersion &= "0" & My.Application.Info.Version.MinorRevision
            Else
                strVersion &= My.Application.Info.Version.MinorRevision
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        Return strVersion
    End Function

    Public Function ComprobarActualizacion() As Boolean
        Dim strSql As String = STR_VACIO
        Dim COM As MySqlCommand
        Dim frm As New frmActualizacion

        Try
            strSql = " SELECT count(*) FROM YarnDivision.Update_HDR h
                                LEFT JOIN YarnDivision.Update_DTL d ON d.IdUpdate = h.Id 
                                WHERE h.Estado =1 and h.IdEmpresa= {empresa} and h.VersionInteger > {version} AND d.IdPrograma in(SELECT a.seg_programa  FROM Accesos a
																	                                WHERE a.seg_sisemp ={empresa} AND a.seg_usuario = '{usuario}' AND a.seg_programa = d.IdPrograma) "
            strSql = strSql.Replace("{version}", Version())
            strSql = strSql.Replace("{empresa}", Sesion.IdEmpresa)
            strSql = strSql.Replace("{usuario}", Sesion.Usuario)

            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSql, CON)
            If COM.ExecuteScalar > 0 Then
                frm.ShowDialog(frmSPrincipal)
                If frm.DialogResult = DialogResult.OK Then
                    IniciarActualizador()

                End If
            End If

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Function

#End Region

#Region "Procedimientos"

    Private Sub IniciarActualizador()
        If cFunciones.ExisteArchivo("C:\Sistema.Net\SGIUpdate.exe") Then
            Process.Start("C:\Sistema.Net\SGIUpdate.exe")
            End
        End If



    End Sub

    Public Sub CambiarAcceso(ByVal USU As String, ByVal srtPw As String, ByVal COMFIRM As String)

        Dim CON As New MySqlConnection
        Dim COM As MySqlCommand
        Dim strConsulta As String = ""
        strConsulta = " UPDATE Personal SET per_clave = MD5(" & cFunciones.MyStr(srtPw) & ") " & _
                      " WHERE per_usuario = " & cFunciones.MyStr(USU)
        If srtPw = COMFIRM Then
            Try
                CON.ConnectionString = strConexion
                CON.Open()
                COM = New MySqlCommand(strConsulta, CON)

            Catch ex As Exception
                MsgBox(ex.ToString)
            Finally
                CON.Dispose()
                CON = Nothing
                COM = Nothing
                System.GC.Collect()
            End Try
        Else
            MsgBox("Las contraseñas no coinciden")
        End If

    End Sub

    Public Sub ComprobarConfiguracion()
        Dim strDato As String
        Dim Query As String
        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader
        Dim PUNTO As String = CStr(1 / 10).Substring(1, 1)
        Dim COMA As String = FormatNumber(CStr(10 ^ 3)).Substring(1, 1)
        Query = "SELECT CAST(DATE_FORMAT(CURRENT_DATE(),'%d/%m/%Y') AS CHAR) AS fecha"
        Try
            MyCnn.CONECTAR = strConexion
            If MyCnn.ProbarConexiones = True Then
                COM = New MySqlCommand(Query, CON)
                REA = COM.ExecuteReader()
                REA.Read()
                strDato = REA.GetString("fecha")
                If Not (strDato = Today) Then
                    logFecha = True
                    MsgBox("Por favor verifique la fecha de su equipo." & vbCr & vbCr & "Local:" & vbTab & Today & vbCr & "Servidor:" & vbTab & strDato, vbExclamation, "Aviso")
                End If
                If Not (PUNTO = "." And COMA = ",") Then
                    MsgBox("Por favor revise su configuración regional", vbExclamation, "Aviso")
                End If
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub


    Public Sub CargarEmpresas(ByVal usuario As String, ByRef lvData As ListView)
        Dim strQuery As String = ""
        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader
        Dim itm As ListViewItem
        strQuery = " SELECT per_sisemp, emp_nombre, emp_web FROM Personal " &
            " INNER JOIN Empresas ON emp_no = per_sisemp " &
            " WHERE per_usuario = '" & cFunciones.MyStr(usuario) & "' AND per_estado=1 " &
            " ORDER BY per_sisemp;"
        Try
            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strQuery, CON)
            REA = COM.ExecuteReader
            If REA.HasRows = False Then
                Exit Sub
            End If
            lvData.Items.Clear()
            Do While REA.Read
                itm = lvData.Items.Add(REA.GetInt32("per_sisemp"))
                itm.SubItems.Add(REA.GetString("emp_nombre"))
                itm.SubItems.Add(REA.GetString("emp_web"))
            Loop
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

#End Region

End Class