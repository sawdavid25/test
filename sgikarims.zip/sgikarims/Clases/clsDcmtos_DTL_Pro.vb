Public Class clsDcmtos_DTL_Pro

#Region "Miembros"

    Public Enum TipoReset
        Full = 1
        Data = 2
    End Enum
    Private strCamposL As String = STR_ASTERISCO
    Private logCON As String = False
    Private int_PDoc_Sis_Emp As Integer
    Private int_PDoc_Par_Cat As Integer
    Private int_PDoc_Par_Ano As Integer
    Private int_PDoc_Par_Num As Integer
    Private int_PDoc_Par_Lin As Integer
    Private int_PDoc_Chi_Cat As Integer
    Private int_PDoc_Chi_Ano As Integer
    Private STR_PDoc_Chi_Ano As Integer
    Private int_PDoc_Chi_Num As Integer
    Private int_PDoc_Chi_Lin As Integer
    Private int_PDoc_Clte_Cod As Integer
    Private int_PDoc_Prov_Cod As Integer
    Private lng_PDoc_Prd_Cod As Long
    Private str_PDoc_Prd_PNr As String
    Private str_PDoc_DR1_Num As String
    Private str_PDoc_DR2_Num As String
    Private dec_PDoc_Prd_NET As Double
    Private dec_PDoc_QTY_Ord As Double
    Private dec_PDoc_QTY_Pro As Double
    Private strMENSAJE As String
    Private intCantidad_de_la_Clase As Integer = INT_CERO
    Private TRA As MySqlTransaction
    Private REA As MySqlDataReader
    Private CONstr As String
    Dim CON2 As MySqlConnection
#End Region

#Region "Propiedades"
    Public Property PDOC_CHI_ANO_STR
        Get
            Return STR_PDoc_Chi_Ano
        End Get
        Set(value)
            STR_PDoc_Chi_Ano = value
        End Set
    End Property
    Public Property PDOC_SIS_EMP() As Integer
        Get
            Return int_PDoc_Sis_Emp
        End Get
        Set(ByVal Value As Integer)
            int_PDoc_Sis_Emp = Value
        End Set
    End Property

    Public Property PDOC_PAR_CAT() As Integer
        Get
            Return int_PDoc_Par_Cat
        End Get
        Set(ByVal Value As Integer)
            int_PDoc_Par_Cat = Value
        End Set
    End Property

    Public Property PDOC_PAR_ANO() As Integer
        Get
            Return int_PDoc_Par_Ano
        End Get
        Set(ByVal Value As Integer)
            int_PDoc_Par_Ano = Value
        End Set
    End Property

    Public Property PDOC_PAR_NUM() As Integer
        Get
            Return int_PDoc_Par_Num
        End Get
        Set(ByVal Value As Integer)
            int_PDoc_Par_Num = Value
        End Set
    End Property

    Public Property PDOC_PAR_LIN() As Integer
        Get
            Return int_PDoc_Par_Lin
        End Get
        Set(ByVal Value As Integer)
            int_PDoc_Par_Lin = Value
        End Set
    End Property

    Public Property PDOC_CHI_CAT() As Integer
        Get
            Return int_PDoc_Chi_Cat
        End Get
        Set(ByVal Value As Integer)
            int_PDoc_Chi_Cat = Value
        End Set
    End Property

    Public Property PDOC_CHI_ANO() As Integer
        Get
            Return int_PDoc_Chi_Ano
        End Get
        Set(ByVal Value As Integer)
            int_PDoc_Chi_Ano = Value
        End Set
    End Property

    Public Property PDOC_CHI_NUM() As Integer
        Get
            Return int_PDoc_Chi_Num
        End Get
        Set(ByVal Value As Integer)
            int_PDoc_Chi_Num = Value
        End Set
    End Property

    Public Property PDOC_CHI_LIN() As Integer
        Get
            Return int_PDoc_Chi_Lin
        End Get
        Set(ByVal Value As Integer)
            int_PDoc_Chi_Lin = Value
        End Set
    End Property

    Public Property PDOC_CLTE_COD() As Integer
        Get
            Return int_PDoc_Clte_Cod
        End Get
        Set(ByVal Value As Integer)
            int_PDoc_Clte_Cod = Value
        End Set
    End Property

    Public Property PDOC_PROV_COD() As Integer
        Get
            Return int_PDoc_Prov_Cod
        End Get
        Set(ByVal Value As Integer)
            int_PDoc_Prov_Cod = Value
        End Set
    End Property

    Public Property PDOC_PRD_COD() As Long
        Get
            Return lng_PDoc_Prd_Cod
        End Get
        Set(ByVal Value As Long)
            lng_PDoc_Prd_Cod = Value
        End Set
    End Property

    Public Property PDOC_PRD_PNR() As String
        Get
            Return str_PDoc_Prd_PNr.Trim()
        End Get
        Set(ByVal Value As String)
            str_PDoc_Prd_PNr = Value
        End Set
    End Property

    Public Property PDOC_DR1_NUM() As String
        Get
            Return str_PDoc_DR1_Num.Trim()
        End Get
        Set(ByVal Value As String)
            str_PDoc_DR1_Num = Value
        End Set
    End Property

    Public Property PDOC_DR2_NUM() As String
        Get
            Return str_PDoc_DR2_Num.Trim()
        End Get
        Set(ByVal Value As String)
            str_PDoc_DR2_Num = Value
        End Set
    End Property

    Public Property PDOC_PRD_NET() As Double
        Get
            Return dec_PDoc_Prd_NET
        End Get
        Set(ByVal Value As Double)
            dec_PDoc_Prd_NET = Value
        End Set
    End Property

    Public Property PDOC_QTY_ORD() As Double
        Get
            Return dec_PDoc_QTY_Ord
        End Get
        Set(ByVal Value As Double)
            dec_PDoc_QTY_Ord = Value
        End Set
    End Property

    Public Property PDOC_QTY_PRO() As Double
        Get
            Return dec_PDoc_QTY_Pro
        End Get
        Set(ByVal Value As Double)
            dec_PDoc_QTY_Pro = Value
        End Set
    End Property

    Public ReadOnly Property CantRecorSet() As Integer
        Get
            Return intCantidad_de_la_Clase
        End Get
    End Property
    Public WriteOnly Property logConexion As Boolean
        Set(value As Boolean)
            logCON = value
        End Set
    End Property

    Public Property CONEXION() As String
        Set(ByVal VALUE As String)
            CONstr = VALUE
            If logCON = True Then

                If IsNothing(CON2) = True Then
                    CON2 = New MySqlConnection
                End If
                If CON2.State = ConnectionState.Open Then
                    CON2.Close()
                End If
                CON2.ConnectionString = CONstr
                CON2.Open()
            Else
                Try
                    strMENSAJE = ""
                    If IsNothing(CON) = True Then
                        CON = New MySqlConnection
                    End If
                    If CON.State = ConnectionState.Open Then
                        CON.Close()
                    End If
                    CON.ConnectionString = CONstr
                    CON.Open()
                Catch MyEX As MySqlException
                    strMENSAJE = "BiblioTABLAS - TDCMTOS_DTL_PRO - CONEXION MyError=" & MyEX.ToString
                Catch EX As Exception
                    strMENSAJE = "BiblioTABLAS - TDCMTOS_DTL_PRO - CONEXION Error=" & EX.ToString
                End Try
            End If

        End Set
        Get
            Return CONstr
        End Get
    End Property

    Public WriteOnly Property TRANSACCION() As MySqlTransaction
        Set(ByVal VALUE As MySqlTransaction)
            TRA = VALUE
        End Set
    End Property

    Public ReadOnly Property MERROR() As String
        Get
            Return strMENSAJE
        End Get
    End Property

#End Region

#Region "Funciones Publicas"

    Public Sub New()
        PDOC_SIS_EMP = INT_CERO
        PDOC_PAR_CAT = INT_CERO
        PDOC_PAR_ANO = INT_CERO
        PDOC_PAR_NUM = INT_CERO
        PDOC_PAR_LIN = INT_CERO
        PDOC_CHI_CAT = INT_CERO
        PDOC_CHI_ANO = INT_CERO
        PDOC_CHI_NUM = INT_CERO
        PDOC_CHI_LIN = INT_CERO
        PDOC_CLTE_COD = INT_CERO
        PDOC_PROV_COD = INT_CERO
        PDOC_PRD_COD = INT_CERO
        PDOC_PRD_PNR = INT_CERO
        PDOC_DR1_NUM = INT_CERO
        PDOC_DR2_NUM = INT_CERO
        PDOC_PRD_NET = INT_CERO
        PDOC_QTY_ORD = INT_CERO
        PDOC_QTY_PRO = INT_CERO
    End Sub

    Public Sub Reset(Optional ByVal Tipo As TipoReset = TipoReset.Data)
        Try
            INIT_LLAVE()
            INIT()
            If Tipo = clsDcmtos_DTL_Pro.TipoReset.Full Then
                Dispose()
            End If
        Catch Ex As Exception
            strMENSAJE = "BiblioTABLAS - TDCMTOS_DTL_PRO - RESET No se podo hacer el Reset de la Clase" & Ex.ToString
        End Try
    End Sub

    Public Sub Dispose()
        Try
            If IsNothing(REA) = False Then
                REA.Close()
            End If
            If IsNothing(CON) = False Then
                If CON.State = ConnectionState.Open Then
                    CON.Close()
                End If
            End If
            CON = Nothing
            REA = Nothing
        Catch EX As Exception
        End Try
    End Sub

    Private Sub INIT()
        PDOC_CLTE_COD = INT_CERO
        PDOC_PROV_COD = INT_CERO
        PDOC_PRD_COD = INT_CERO
        PDOC_PRD_PNR = INT_CERO
        PDOC_DR1_NUM = INT_CERO
        PDOC_DR2_NUM = INT_CERO
        PDOC_PRD_NET = INT_CERO
        PDOC_QTY_ORD = INT_CERO
        PDOC_QTY_PRO = INT_CERO
        intCantidad_de_la_Clase = INT_CERO
    End Sub

    Private Sub INIT_LLAVE()
        PDOC_SIS_EMP = INT_CERO
        PDOC_PAR_CAT = INT_CERO
        PDOC_PAR_ANO = INT_CERO
        PDOC_PAR_NUM = INT_CERO
        PDOC_PAR_LIN = INT_CERO
        PDOC_CHI_CAT = INT_CERO
        PDOC_CHI_ANO = INT_CERO
        PDOC_CHI_NUM = INT_CERO
        PDOC_CHI_LIN = INT_CERO
    End Sub

    Public Function SiguienteRegistro() As Boolean
        Dim arraycampos() As String
        SiguienteRegistro = False
        INIT()
        INIT_LLAVE()
        If IsNothing(REA) = True Then
            strMENSAJE = "BiblioTABLAS - TDCMTOS_DTL_PRO - PMOVE_NEXT Conexi�n no definida"
            Exit Function
        End If
        Try
            If REA.Read = True Then

                arraycampos = strCamposL.Split(",".ToCharArray)
                For i As Integer = 0 To arraycampos.Length - 1
                    Select Case Trim(arraycampos(i))
                        Case "PDoc_Sis_Emp"
                            If REA.IsDBNull(REA.GetOrdinal("PDoc_Sis_Emp")) = False Then
                                int_PDoc_Sis_Emp = REA.GetInt32("PDoc_Sis_Emp")
                            Else
                                int_PDoc_Sis_Emp = NO_FILA
                            End If
                        Case "PDoc_Par_Cat"
                            If REA.IsDBNull(REA.GetOrdinal("PDoc_Par_Cat")) = False Then
                                int_PDoc_Par_Cat = REA.GetInt32("PDoc_Par_Cat")
                            Else
                                int_PDoc_Par_Cat = NO_FILA
                            End If
                        Case "PDoc_Par_Ano"
                            If REA.IsDBNull(REA.GetOrdinal("PDoc_Par_Ano")) = False Then
                                int_PDoc_Par_Ano = REA.GetInt32("PDoc_Par_Ano")
                            Else
                                int_PDoc_Par_Ano = NO_FILA
                            End If
                        Case "PDoc_Par_Num"
                            If REA.IsDBNull(REA.GetOrdinal("PDoc_Par_Num")) = False Then
                                int_PDoc_Par_Num = REA.GetInt32("PDoc_Par_Num")
                            Else
                                int_PDoc_Par_Num = NO_FILA
                            End If
                        Case "PDoc_Par_Lin"
                            If REA.IsDBNull(REA.GetOrdinal("PDoc_Par_Lin")) = False Then
                                int_PDoc_Par_Lin = REA.GetInt32("PDoc_Par_Lin")
                            Else
                                int_PDoc_Par_Lin = NO_FILA
                            End If
                        Case "PDoc_Chi_Cat"
                            If REA.IsDBNull(REA.GetOrdinal("PDoc_Chi_Cat")) = False Then
                                int_PDoc_Chi_Cat = REA.GetInt32("PDoc_Chi_Cat")
                            Else
                                int_PDoc_Chi_Cat = NO_FILA
                            End If
                        Case "PDoc_Chi_Ano"
                            If REA.IsDBNull(REA.GetOrdinal("PDoc_Chi_Ano")) = False Then
                                int_PDoc_Chi_Ano = REA.GetInt32("PDoc_Chi_Ano")
                            Else
                                int_PDoc_Chi_Ano = NO_FILA
                            End If
                        Case "PDoc_Chi_Num"
                            If REA.IsDBNull(REA.GetOrdinal("PDoc_Chi_Num")) = False Then
                                int_PDoc_Chi_Num = REA.GetInt32("PDoc_Chi_Num")
                            Else
                                int_PDoc_Chi_Num = NO_FILA
                            End If
                        Case "PDoc_Chi_Lin"
                            If REA.IsDBNull(REA.GetOrdinal("PDoc_Chi_Lin")) = False Then
                                int_PDoc_Chi_Lin = REA.GetInt32("PDoc_Chi_Lin")
                            Else
                                int_PDoc_Chi_Lin = NO_FILA
                            End If
                        Case "PDoc_Clte_Cod"
                            If REA.IsDBNull(REA.GetOrdinal("PDoc_Clte_Cod")) = False Then
                                int_PDoc_Clte_Cod = REA.GetInt32("PDoc_Clte_Cod")
                            Else
                                int_PDoc_Clte_Cod = NO_FILA
                            End If
                        Case "PDoc_Prov_Cod"
                            If REA.IsDBNull(REA.GetOrdinal("PDoc_Prov_Cod")) = False Then
                                int_PDoc_Prov_Cod = REA.GetInt32("PDoc_Prov_Cod")
                            Else
                                int_PDoc_Prov_Cod = NO_FILA
                            End If
                        Case "PDoc_Prd_Cod"
                            If REA.IsDBNull(REA.GetOrdinal("PDoc_Prd_Cod")) = False Then
                                lng_PDoc_Prd_Cod = REA.GetString("PDoc_Prd_Cod")
                            End If
                        Case "PDoc_Prd_PNr"
                            If REA.IsDBNull(REA.GetOrdinal("PDoc_Prd_PNr")) = False Then
                                str_PDoc_Prd_PNr = REA.GetString("PDoc_Prd_PNr")
                            Else
                                str_PDoc_Prd_PNr = "NULL"
                            End If
                        Case "PDoc_DR1_Num"
                            If REA.IsDBNull(REA.GetOrdinal("PDoc_DR1_Num")) = False Then
                                str_PDoc_DR1_Num = REA.GetString("PDoc_DR1_Num")
                            Else
                                str_PDoc_DR1_Num = "NULL"
                            End If
                        Case "PDoc_DR2_Num"
                            If REA.IsDBNull(REA.GetOrdinal("PDoc_DR2_Num")) = False Then
                                str_PDoc_DR2_Num = REA.GetString("PDoc_DR2_Num")
                            Else
                                str_PDoc_DR2_Num = "NULL"
                            End If
                        Case "PDoc_Prd_NET"
                            If REA.IsDBNull(REA.GetOrdinal("PDoc_Prd_NET")) = False Then
                                dec_PDoc_Prd_NET = REA.GetDouble("PDoc_Prd_NET")
                            End If
                        Case "PDoc_QTY_Ord"
                            If REA.IsDBNull(REA.GetOrdinal("PDoc_QTY_Ord")) = False Then
                                dec_PDoc_QTY_Ord = REA.GetDouble("PDoc_QTY_Ord")
                            End If
                        Case "PDoc_QTY_Pro"
                            If REA.IsDBNull(REA.GetOrdinal("PDoc_QTY_Pro")) = False Then
                                dec_PDoc_QTY_Pro = REA.GetDouble("PDoc_QTY_Pro")
                            End If
                    End Select
                Next
                SiguienteRegistro = True
            Else
                REA.Close()
                REA = Nothing
            End If
        Catch MYEX As MySqlException
            strMENSAJE = "BiblioTABLAS - TDCMTOS_DTL_PRO - PMOVE_NEXT Error=" & MYEX.ToString
        Catch EX As Exception
            strMENSAJE = "BiblioTABLAS - TDCMTOS_DTL_PRO - PMOVE_NEXT Error=" & EX.ToString
        End Try
    End Function

    Public Function SeleccionarLista(Optional ByVal strCONDICION As String = "", Optional ByVal strCAMPOS As String = STR_ASTERISCO, Optional ByVal strORDENAMIENTO As String = "") As Boolean
        Dim COM As MySqlCommand
        Dim SQL As String
        Dim SQL1 As String


        SeleccionarLista = False
        If IsNothing(REA) = False Then
            REA.Close()
            REA = Nothing
        End If
        If IsNothing(CON2) = True Then
            strMENSAJE = "BiblioTABLAS - TDCMTOS_DTL_PRO - PSELECT_RECORDSET CONexi�n no definida"
            Exit Function
        End If
        If CON2.State = ConnectionState.Closed Or CON.State = ConnectionState.Broken Then
            If CON2.ConnectionString.Length <> 0 Then
                Try
                    CON2.Open()
                Catch MYEX As MySqlException
                    strMENSAJE = "BiblioTABLAS - TTDCMTOS_DTL_PRO - PSELECT_RECORDSET Error#=" & MYEX.Number & " " & MYEX.ToString
                    Exit Function
                Catch EX As Exception
                    strMENSAJE = "BiblioTABLAS - TTDCMTOS_DTL_PRO - PSELECT_RECORDSET Error=" & EX.ToString
                    Exit Function
                End Try
            Else
                strMENSAJE = "BiblioTABLAS - TTDCMTOS_DTL_PRO - PSELECT_RECORDSET String de CONexi�n no definido"
                Exit Function
            End If
        End If
        If strCAMPOS = STR_ASTERISCO Then
            strCAMPOS = "PDoc_Sis_Emp,PDoc_Par_Cat,PDoc_Par_Ano,PDoc_Par_Num,PDoc_Par_Lin,PDoc_Chi_Cat," & _
                        "PDoc_Chi_Ano,PDoc_Chi_Num,PDoc_Chi_Lin,PDoc_Clte_Cod,PDoc_Prov_Cod," & _
                        "PDoc_Prd_Cod,PDoc_Prd_PNr,PDoc_DR1_Num,PDoc_DR2_Num,PDoc_Prd_NET, " & _
                        "PDoc_QTY_Ord,PDoc_QTY_Pro"
        End If
        strCamposL = strCAMPOS
        COM = Nothing
        SQL = "Select " & strCAMPOS & " from Dcmtos_DTL_Pro"
        If strCONDICION.Length <> INT_CERO Then
            SQL &= " Where " & strCONDICION
        End If
        If strORDENAMIENTO.Length <> INT_CERO Then
            SQL &= " Order By " & strORDENAMIENTO
        End If

        SQL1 = "Select Count(*) as Cuenta from Dcmtos_DTL_Pro"
        If strCONDICION.Length <> INT_CERO Then
            SQL1 &= " Where " & strCONDICION
        End If
        Try
            INIT()
            INIT_LLAVE()

            COM = New MySqlCommand(SQL1, CON2)
            intCantidad_de_la_Clase = CInt(COM.ExecuteScalar())
            COM.Dispose()
            COM = Nothing

            COM = New MySqlCommand(SQL, CON2)
            COM.CommandType = CommandType.Text
            REA = COM.ExecuteReader
            SeleccionarLista = True
        Catch MYEX As MySqlException
            strMENSAJE = "BiblioTABLAS - TDCMTOS_DTL_PRO - PSELECT_RECORDSET MyError#=" & MYEX.Number & " MyError=" & MYEX.ToString
        Catch EX As Exception
            strMENSAJE = "BiblioTABLAS - TDCMTOS_DTL_PRO - PSELECT_RECORDSET Error=" & EX.ToString
        Finally
            If IsNothing(COM) = False Then
                COM.Dispose()
                COM = Nothing
            End If
        End Try
    End Function

    Public Function Seleccionar(ByVal CONDICION As String, Optional strCAMPOS As String = STR_ASTERISCO) As Boolean

        Dim READER As MySqlDataReader
        Dim COM As MySqlCommand
        Dim SQL As String
        Dim arrayCAMPOS() As String

        strMENSAJE = ""
        Seleccionar = False
        If IsNothing(CON) = True Then
            strMENSAJE = "BiblioTABLAS - TDCMTOS_DTL_PRO - PSELECT_CONDICION Conexi�n no definida"
            Exit Function
        End If
        If CON.State = ConnectionState.Closed Or CON.State = ConnectionState.Broken Then
            If CON.ConnectionString.Length <> 0 Then
                Try
                    CON.Open()
                Catch MYEX As MySqlException
                    strMENSAJE = "BiblioTABLAS - TTDCMTOS_DTL_PRO - PSELECT_CONDICION Error#=" & MYEX.Number & " " & MYEX.ToString
                    Exit Function
                Catch EX As Exception
                    strMENSAJE = "BiblioTABLAS - TTDCMTOS_DTL_PRO - PSELECT_CONDICION Error=" & EX.ToString
                    Exit Function
                End Try
            Else
                strMENSAJE = "BiblioTABLAS - TTDCMTOS_DTL_PRO - PSELECT_CONDICION String de Conexi�n no definido"
                Exit Function
            End If
        End If
        If strCAMPOS = STR_ASTERISCO Then
            strCAMPOS = "PDoc_Sis_Emp,PDoc_Par_Cat,PDoc_Par_Ano,PDoc_Par_Num,PDoc_Par_Lin,PDoc_Chi_Cat," & _
                        "PDoc_Chi_Ano,PDoc_Chi_Num,PDoc_Chi_Lin,PDoc_Clte_Cod,PDoc_Prov_Cod," & _
                        "PDoc_Prd_Cod,PDoc_Prd_PNr,PDoc_DR1_Num,PDoc_DR2_Num,PDoc_Prd_NET, " & _
                        "PDoc_QTY_Ord,PDoc_QTY_Pro"
        End If

        SQL = "SELECT " & strCAMPOS & " FROM Dcmtos_DTL_Pro WHERE " & CONDICION
        READER = Nothing
        COM = Nothing
        Try
            INIT()
            If logCON = True Then
                COM = New MySqlCommand(SQL, CON2)
            Else
                COM = New MySqlCommand(SQL, CON)
            End If

            COM.CommandType = CommandType.Text
            READER = COM.ExecuteReader(CommandBehavior.SingleRow)
            READER.Read()
            If READER.HasRows = True Then
                arrayCAMPOS = strCAMPOS.Split(",".ToCharArray)
                For i As Integer = 0 To arrayCAMPOS.Length - 1
                    Select Case Trim(arrayCAMPOS(i))
                        Case "PDoc_Sis_Emp"
                            If READER.IsDBNull(READER.GetOrdinal("PDoc_Sis_Emp")) = False Then
                                int_PDoc_Sis_Emp = READER.GetInt32("PDoc_Sis_Emp")
                            Else
                                int_PDoc_Sis_Emp = NO_FILA
                            End If
                        Case "PDoc_Par_Cat"
                            If READER.IsDBNull(READER.GetOrdinal("PDoc_Par_Cat")) = False Then
                                int_PDoc_Par_Cat = READER.GetInt32("PDoc_Par_Cat")
                            Else
                                int_PDoc_Par_Cat = NO_FILA
                            End If
                        Case "PDoc_Par_Ano"
                            If READER.IsDBNull(READER.GetOrdinal("PDoc_Par_Ano")) = False Then
                                int_PDoc_Par_Ano = READER.GetInt32("PDoc_Par_Ano")
                            Else
                                int_PDoc_Par_Ano = NO_FILA
                            End If
                        Case "PDoc_Par_Num"
                            If READER.IsDBNull(READER.GetOrdinal("PDoc_Par_Num")) = False Then
                                int_PDoc_Par_Num = READER.GetInt32("PDoc_Par_Num")
                            Else
                                int_PDoc_Par_Num = NO_FILA
                            End If
                        Case "PDoc_Par_Lin"
                            If READER.IsDBNull(READER.GetOrdinal("PDoc_Par_Lin")) = False Then
                                int_PDoc_Par_Lin = READER.GetInt32("PDoc_Par_Lin")
                            Else
                                int_PDoc_Par_Lin = NO_FILA
                            End If
                        Case "PDoc_Chi_Cat"
                            If READER.IsDBNull(READER.GetOrdinal("PDoc_Chi_Cat")) = False Then
                                int_PDoc_Chi_Cat = READER.GetInt32("PDoc_Chi_Cat")
                            Else
                                int_PDoc_Chi_Cat = NO_FILA
                            End If
                        Case "PDoc_Chi_Ano"
                            If READER.IsDBNull(READER.GetOrdinal("PDoc_Chi_Ano")) = False Then
                                int_PDoc_Chi_Ano = READER.GetInt32("PDoc_Chi_Ano")
                            Else
                                int_PDoc_Chi_Ano = NO_FILA
                            End If
                        Case "PDoc_Chi_Num"
                            If READER.IsDBNull(READER.GetOrdinal("PDoc_Chi_Num")) = False Then
                                int_PDoc_Chi_Num = READER.GetInt32("PDoc_Chi_Num")
                            Else
                                int_PDoc_Chi_Num = NO_FILA
                            End If
                        Case "PDoc_Chi_Lin"
                            If READER.IsDBNull(READER.GetOrdinal("PDoc_Chi_Lin")) = False Then
                                int_PDoc_Chi_Lin = READER.GetInt32("PDoc_Chi_Lin")
                            Else
                                int_PDoc_Chi_Lin = NO_FILA
                            End If
                        Case "PDoc_Clte_Cod"
                            If READER.IsDBNull(READER.GetOrdinal("PDoc_Clte_Cod")) = False Then
                                int_PDoc_Clte_Cod = READER.GetInt32("PDoc_Clte_Cod")
                            Else
                                int_PDoc_Clte_Cod = NO_FILA
                            End If
                        Case "PDoc_Prov_Cod"
                            If READER.IsDBNull(READER.GetOrdinal("PDoc_Prov_Cod")) = False Then
                                int_PDoc_Prov_Cod = READER.GetInt32("PDoc_Prov_Cod")
                            Else
                                int_PDoc_Prov_Cod = NO_FILA
                            End If
                        Case "PDoc_Prd_Cod"
                            If READER.IsDBNull(READER.GetOrdinal("PDoc_Prd_Cod")) = False Then
                                lng_PDoc_Prd_Cod = READER.GetString("PDoc_Prd_Cod")
                            End If
                        Case "PDoc_Prd_PNr"
                            If READER.IsDBNull(READER.GetOrdinal("PDoc_Prd_PNr")) = False Then
                                str_PDoc_Prd_PNr = READER.GetString("PDoc_Prd_PNr")
                            Else
                                str_PDoc_Prd_PNr = "NULL"
                            End If
                        Case "PDoc_DR1_Num"
                            If READER.IsDBNull(READER.GetOrdinal("PDoc_DR1_Num")) = False Then
                                str_PDoc_DR1_Num = READER.GetString("PDoc_DR1_Num")
                            Else
                                str_PDoc_DR1_Num = "NULL"
                            End If
                        Case "PDoc_DR2_Num"
                            If READER.IsDBNull(READER.GetOrdinal("PDoc_DR2_Num")) = False Then
                                str_PDoc_DR2_Num = READER.GetString("PDoc_DR2_Num")
                            Else
                                str_PDoc_DR2_Num = "NULL"
                            End If
                        Case "PDoc_Prd_NET"
                            If READER.IsDBNull(READER.GetOrdinal("PDoc_Prd_NET")) = False Then
                                dec_PDoc_Prd_NET = READER.GetDouble("PDoc_Prd_NET")
                            End If
                        Case "PDoc_QTY_Ord"
                            If READER.IsDBNull(READER.GetOrdinal("PDoc_QTY_Ord")) = False Then
                                dec_PDoc_QTY_Ord = READER.GetDouble("PDoc_QTY_Ord")
                            End If
                        Case "PDoc_QTY_Pro"
                            If READER.IsDBNull(READER.GetOrdinal("PDoc_QTY_Pro")) = False Then
                                dec_PDoc_QTY_Pro = READER.GetDouble("PDoc_QTY_Pro")
                            End If
                    End Select
                Next
                Seleccionar = True
            Else
                strMENSAJE = ""
                Exit Function
            End If
            READER.Close()
            COM.Dispose()
            READER = Nothing
            COM = Nothing
            Seleccionar = True
        Catch MYEX As MySqlException
            strMENSAJE = "BiblioTABLAS - TDCMTOS_DTL_PRO - PSELECT_CONDICION MyError#=" & MYEX.Number & " MyError=" & MYEX.ToString
        Catch EX As Exception
            strMENSAJE = "BiblioTABLAS - TDCMTOS_DTL_PRO - PSELECT_CONDICION Error=" & EX.ToString
        Finally
            If IsNothing(READER) = False Then
                READER.Close()
                READER = Nothing
            End If
            If IsNothing(COM) = False Then
                COM.Dispose()
                COM = Nothing
            End If
        End Try
    End Function

    Public Function Guardar() As Boolean
        Dim COM As MySqlCommand
        Dim SQL As String

        strMENSAJE = ""
        Guardar = False
        If IsNothing(CON) = True Then
            strMENSAJE = "BiblioTABLAS - TDCMTOS_DTL_PRO - PINSERT Conexi�n no definida"
            Exit Function
        End If
        If CON.State = ConnectionState.Closed Or CON.State = ConnectionState.Broken Then
            If CON.ConnectionString.Length <> 0 Then
                Try
                    CON.Open()
                Catch MYEX As MySqlException
                    strMENSAJE = "BiblioTABLAS - TTDCMTOS_DTL_PRO - PINSERT Error#=" & MYEX.Number & " " & MYEX.ToString
                    Exit Function
                Catch EX As Exception
                    strMENSAJE = "BiblioTABLAS - TTDCMTOS_DTL_PRO - PINSERT Error=" & EX.ToString
                    Exit Function
                End Try
            Else
                strMENSAJE = "BiblioTABLAS - TTDCMTOS_DTL_PRO - PINSERT String de Conexi�n no definido"
                Exit Function
            End If
        End If

        COM = Nothing
        Try
            SQL = "INSERT INTO Dcmtos_DTL_Pro (PDoc_Sis_Emp,PDoc_Par_Cat,PDoc_Par_Ano,PDoc_Par_Num," & _
                "PDoc_Par_Lin,PDoc_Chi_Cat,PDoc_Chi_Ano,PDoc_Chi_Num,PDoc_Chi_Lin,PDoc_Clte_Cod," & _
                "PDoc_Prov_Cod,PDoc_Prd_Cod,PDoc_Prd_PNr,PDoc_DR1_Num,PDoc_DR2_Num,PDoc_Prd_NET," & _
                "PDoc_QTY_Ord,PDoc_QTY_Pro) " & _
                "VALUES(?P1,?P2,?P3,?P4,?P5,?P6," & MYSQL_A�O & ",?P8,?P9,?P10,?P11,?P12,?P13,?P14,?P15,?P16,?P17,?P18)"
            If IsNothing(TRA) = False Then
                COM = New MySqlCommand(SQL, TRA.Connection, TRA)
            Else
                COM = New MySqlCommand(SQL, CON)
            End If
            COM.CommandType = CommandType.Text
            If int_PDoc_Sis_Emp = NO_FILA Then
                COM.Parameters.AddWithValue("?P1", DBNull.Value)
            Else
                COM.Parameters.AddWithValue("?P1", int_PDoc_Sis_Emp)
            End If
            If int_PDoc_Par_Cat = NO_FILA Then
                COM.Parameters.AddWithValue("?P2", DBNull.Value)
            Else
                COM.Parameters.AddWithValue("?P2", int_PDoc_Par_Cat)
            End If
            If int_PDoc_Par_Ano = NO_FILA Then
                COM.Parameters.AddWithValue("?P3", DBNull.Value)
            Else
                COM.Parameters.AddWithValue("?P3", int_PDoc_Par_Ano)
            End If
            If int_PDoc_Par_Num = NO_FILA Then
                COM.Parameters.AddWithValue("?P4", DBNull.Value)
            Else
                COM.Parameters.AddWithValue("?P4", int_PDoc_Par_Num)
            End If
            If int_PDoc_Par_Lin = NO_FILA Then
                COM.Parameters.AddWithValue("?P5", DBNull.Value)
            Else
                COM.Parameters.AddWithValue("?P5", int_PDoc_Par_Lin)
            End If
            If int_PDoc_Chi_Cat = NO_FILA Then
                COM.Parameters.AddWithValue("?P6", DBNull.Value)
            Else
                COM.Parameters.AddWithValue("?P6", int_PDoc_Chi_Cat)
            End If
            'If STR_PDoc_Chi_Ano = STR_VACIO Then
            '    COM.Parameters.AddWithValue("?P7", DBNull.Value)
            'Else
            '    COM.Parameters.AddWithValue("?P7", STR_PDoc_Chi_Ano)
            'End If
            If int_PDoc_Chi_Num = NO_FILA Then
                COM.Parameters.AddWithValue("?P8", DBNull.Value)
            Else
                COM.Parameters.AddWithValue("?P8", int_PDoc_Chi_Num)
            End If
            If int_PDoc_Chi_Lin = NO_FILA Then
                COM.Parameters.AddWithValue("?P9", DBNull.Value)
            Else
                COM.Parameters.AddWithValue("?P9", int_PDoc_Chi_Lin)
            End If
            If int_PDoc_Clte_Cod = NO_FILA Then
                COM.Parameters.AddWithValue("?P10", DBNull.Value)
            Else
                COM.Parameters.AddWithValue("?P10", int_PDoc_Clte_Cod)
            End If
            If int_PDoc_Prov_Cod = NO_FILA Then
                COM.Parameters.AddWithValue("?P11", DBNull.Value)
            Else
                COM.Parameters.AddWithValue("?P11", int_PDoc_Prov_Cod)
            End If
            COM.Parameters.AddWithValue("?P12", lng_PDoc_Prd_Cod)
            If str_PDoc_Prd_PNr.ToUpper = "NULL" Then
                COM.Parameters.AddWithValue("?P13", DBNull.Value)
            Else
                COM.Parameters.AddWithValue("?P13", str_PDoc_Prd_PNr)
            End If
            If str_PDoc_DR1_Num.ToUpper = "NULL" Then
                COM.Parameters.AddWithValue("?P14", DBNull.Value)
            Else
                COM.Parameters.AddWithValue("?P14", str_PDoc_DR1_Num)
            End If
            If str_PDoc_DR2_Num.ToUpper = "NULL" Then
                COM.Parameters.AddWithValue("?P15", DBNull.Value)
            Else
                COM.Parameters.AddWithValue("?P15", str_PDoc_DR2_Num)
            End If
            COM.Parameters.AddWithValue("?P16", dec_PDoc_Prd_NET)
            COM.Parameters.AddWithValue("?P17", dec_PDoc_QTY_Ord)
            COM.Parameters.AddWithValue("?P18", dec_PDoc_QTY_Pro)
            COM.ExecuteNonQuery()
            COM.Dispose()
            COM = Nothing
            Guardar = True
        Catch MYEX As MySqlException
            strMENSAJE = "BiblioTABLAS - TDCMTOS_DTL_PRO - PINSERT MyError#=" & MYEX.Number & " MyError=" & MYEX.ToString
        Catch ex As Exception
            strMENSAJE = "BiblioTABLAS - TDCMTOS_DTL_PRO - PINSERT Error=" & ex.ToString
        Finally
            If IsNothing(COM) = False Then
                COM.Dispose()
                COM = Nothing
            End If
        End Try
    End Function

    Public Function Borrar(Optional ByVal Condicion As String = "") As Boolean

        Dim COM As MySqlCommand
        Dim SQL As String

        strMENSAJE = ""
        Borrar = False
        If IsNothing(CON) = True Then
            strMENSAJE = "BiblioTABLAS - TDCMTOS_DTL_PRO - PDELETE Conexi�n no definida"
            Exit Function
        End If
        If CON.State = ConnectionState.Closed Or CON.State = ConnectionState.Broken Then
            If CON.ConnectionString.Length <> 0 Then
                Try
                    CON.Open()
                Catch MYEX As MySqlException
                    strMENSAJE = "BiblioTABLAS - TTDCMTOS_DTL_PRO - PDELETE Error#=" & MYEX.Number & " " & MYEX.ToString
                    Exit Function
                Catch EX As Exception
                    strMENSAJE = "BiblioTABLAS - TTDCMTOS_DTL_PRO - PDELETE Error=" & EX.ToString
                    Exit Function
                End Try
            Else
                strMENSAJE = "BiblioTABLAS - TTDCMTOS_DTL_PRO - PDELETE String de Conexi�n no definido"
                Exit Function
            End If
        End If

        COM = Nothing
        Try
            If Condicion.Length <> INT_CERO Then
                SQL = "DELETE FROM Dcmtos_DTL_Pro WHERE " & Condicion
                If IsNothing(TRA) = False Then
                    COM = New MySqlCommand(SQL, TRA.Connection, TRA)
                Else
                    COM = New MySqlCommand(SQL, CON)
                End If
                COM.CommandType = CommandType.Text
            Else
                SQL = "DELETE FROM Dcmtos_DTL_Pro WHERE PDoc_Sis_Emp = ?P1  AND PDoc_Par_Cat = ?P2  AND PDoc_Par_Ano = ?P3  AND PDoc_Par_Num = ?P4  AND PDoc_Par_Lin = ?P5  AND PDoc_Chi_Cat = ?P6  AND PDoc_Chi_Ano = ?P7  AND PDoc_Chi_Num = ?P8  AND PDoc_Chi_Lin = ?P9 "
                If IsNothing(TRA) = False Then
                    COM = New MySqlCommand(SQL, TRA.Connection, TRA)
                Else
                    COM = New MySqlCommand(SQL, CON)
                End If
                COM.CommandType = CommandType.Text
                COM.Parameters.AddWithValue("?P1", int_PDoc_Sis_Emp)
                COM.Parameters.AddWithValue("?P2", int_PDoc_Par_Cat)
                COM.Parameters.AddWithValue("?P3", int_PDoc_Par_Ano)
                COM.Parameters.AddWithValue("?P4", int_PDoc_Par_Num)
                COM.Parameters.AddWithValue("?P5", int_PDoc_Par_Lin)
                COM.Parameters.AddWithValue("?P6", int_PDoc_Chi_Cat)
                COM.Parameters.AddWithValue("?P7", int_PDoc_Chi_Ano)
                COM.Parameters.AddWithValue("?P8", int_PDoc_Chi_Num)
                COM.Parameters.AddWithValue("?P9", int_PDoc_Chi_Lin)
            End If
            COM.ExecuteNonQuery()
            COM.Dispose()
            COM = Nothing
            Borrar = True
        Catch MYEX As MySqlException
            strMENSAJE = "BiblioTABLAS - TDCMTOS_DTL_PRO - PDELETE MyError#=" & MYEX.Number & " MyError=" & MYEX.ToString
        Catch ex As Exception
            strMENSAJE = "BiblioTABLAS - TDCMTOS_DTL_PRO - PDELETE Error=" & ex.ToString
        Finally
            If IsNothing(COM) = False Then
                COM.Dispose()
                COM = Nothing
            End If
        End Try
    End Function

    Public Function Actualizar() As Boolean

        Dim COM As MySqlCommand
        Dim SQL As String

        strMENSAJE = ""
        Actualizar = False
        If IsNothing(CON) = True Then
            strMENSAJE = "BiblioTABLAS - TDCMTOS_DTL_PRO - PUPDATE Conexi�n no definida"
            Exit Function
        End If
        If CON.State = ConnectionState.Closed Or CON.State = ConnectionState.Broken Then
            If CON.ConnectionString.Length <> 0 Then
                Try
                    CON.Open()
                Catch MYEX As MySqlException
                    strMENSAJE = "BiblioTABLAS - TTDCMTOS_DTL_PRO - PUPDATE Error#=" & MYEX.Number & " " & MYEX.ToString
                    Exit Function
                Catch EX As Exception
                    strMENSAJE = "BiblioTABLAS - TTDCMTOS_DTL_PRO - PUPDATE Error=" & EX.ToString
                    Exit Function
                End Try
            Else
                strMENSAJE = "BiblioTABLAS - TTDCMTOS_DTL_PRO - PUPDATE String de Conexi�n no definido"
                Exit Function
            End If
        End If

        COM = Nothing
        Try
            SQL = "UPDATE Dcmtos_DTL_Pro SET PDoc_Clte_Cod = ?P10, PDoc_Prov_Cod = ?P11, PDoc_Prd_Cod = ?P12, PDoc_Prd_PNr = ?P13, PDoc_DR1_Num = ?P14, PDoc_DR2_Num = ?P15, PDoc_Prd_NET = ?P16, PDoc_QTY_Ord = ?P17, PDoc_QTY_Pro = ?P18 WHERE PDoc_Sis_Emp = ?P1 AND PDoc_Par_Cat = ?P2 AND PDoc_Par_Ano = ?P3 AND PDoc_Par_Num = ?P4 AND PDoc_Par_Lin = ?P5 AND PDoc_Chi_Cat = ?P6 AND PDoc_Chi_Ano = ?P7 AND PDoc_Chi_Num = ?P8 AND PDoc_Chi_Lin = ?P9"
            If IsNothing(TRA) = False Then
                COM = New MySqlCommand(SQL, TRA.Connection, TRA)
            Else
                COM = New MySqlCommand(SQL, CON)
            End If
            COM.CommandType = CommandType.Text
            If int_PDoc_Clte_Cod = NO_FILA Then
                COM.Parameters.AddWithValue("?P10", DBNull.Value)
            Else
                COM.Parameters.AddWithValue("?P10", int_PDoc_Clte_Cod)
            End If
            If int_PDoc_Prov_Cod = NO_FILA Then
                COM.Parameters.AddWithValue("?P11", DBNull.Value)
            Else
                COM.Parameters.AddWithValue("?P11", int_PDoc_Prov_Cod)
            End If
            COM.Parameters.AddWithValue("?P12", lng_PDoc_Prd_Cod)
            If str_PDoc_Prd_PNr.ToUpper = "NULL" Then
                COM.Parameters.AddWithValue("?P13", DBNull.Value)
            Else
                COM.Parameters.AddWithValue("?P13", str_PDoc_Prd_PNr)
            End If
            If str_PDoc_DR1_Num.ToUpper = "NULL" Then
                COM.Parameters.AddWithValue("?P14", DBNull.Value)
            Else
                COM.Parameters.AddWithValue("?P14", str_PDoc_DR1_Num)
            End If
            If str_PDoc_DR2_Num.ToUpper = "NULL" Then
                COM.Parameters.AddWithValue("?P15", DBNull.Value)
            Else
                COM.Parameters.AddWithValue("?P15", str_PDoc_DR2_Num)
            End If
            COM.Parameters.AddWithValue("?P16", dec_PDoc_Prd_NET)
            COM.Parameters.AddWithValue("?P17", dec_PDoc_QTY_Ord)
            COM.Parameters.AddWithValue("?P18", dec_PDoc_QTY_Pro)
            COM.Parameters.AddWithValue("?P1", int_PDoc_Sis_Emp)
            COM.Parameters.AddWithValue("?P2", int_PDoc_Par_Cat)
            COM.Parameters.AddWithValue("?P3", int_PDoc_Par_Ano)
            COM.Parameters.AddWithValue("?P4", int_PDoc_Par_Num)
            COM.Parameters.AddWithValue("?P5", int_PDoc_Par_Lin)
            COM.Parameters.AddWithValue("?P6", int_PDoc_Chi_Cat)
            COM.Parameters.AddWithValue("?P7", int_PDoc_Chi_Ano)
            COM.Parameters.AddWithValue("?P8", int_PDoc_Chi_Num)
            COM.Parameters.AddWithValue("?P9", int_PDoc_Chi_Lin)
            COM.ExecuteNonQuery()
            COM.Dispose()
            COM = Nothing
            Actualizar = True
        Catch MYEX As MySqlException
            strMENSAJE = "BiblioTABLAS - TDCMTOS_DTL_PRO - PUPDATE MyError#=" & MYEX.Number & " MyError=" & MYEX.ToString
        Catch ex As Exception
            strMENSAJE = "BiblioTABLAS - TDCMTOS_DTL_PRO - PUPDATE Error=" & ex.ToString
        Finally
            If IsNothing(COM) = False Then
                COM.Dispose()
                COM = Nothing
            End If
        End Try
    End Function

#End Region

End Class