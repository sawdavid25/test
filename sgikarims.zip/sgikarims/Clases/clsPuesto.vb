Public Class clsPuesto

#Region "Miembros"

    Public Enum TipoReset
        Full = 1
        Data = 2
    End Enum

    Private m_int_pue_sisemp As Integer
    Private m_int_pue_codigo As Integer
    Private m_str_pue_descripcion As String
    Private m_obj_pue_sistema As Object
    Private m_int_pue_moneda As Integer
    Private m_dec_pue_base As Decimal
    Private m_dec_pue_bono1 As Decimal
    Private m_dec_pue_bono2 As Decimal
    Private MENSAJE As String
    Private Cantidad_de_la_Clase As Integer = INT_CERO
    Private TRA As MySqlTransaction
    Private REA As MySqlDataReader
    Private CONstr As String
#End Region


#Region "Propiedades"

    Public Property PUE_SISEMP() As Integer
        Get
            Return m_int_pue_sisemp
        End Get
        Set(ByVal Value As Integer)
            m_int_pue_sisemp = Value
        End Set
    End Property

    Public Property PUE_CODIGO() As Integer
        Get
            Return m_int_pue_codigo
        End Get
        Set(ByVal Value As Integer)
            m_int_pue_codigo = Value
        End Set
    End Property

    Public Property PUE_DESCRIPCION() As String
        Get
            Return m_str_pue_descripcion.Trim()
        End Get
        Set(ByVal Value As String)
            m_str_pue_descripcion = Value
        End Set
    End Property

    Public Property PUE_SISTEMA() As Object
        Get
            Return m_obj_pue_sistema
        End Get
        Set(ByVal Value As Object)
            m_obj_pue_sistema = Value
        End Set
    End Property

    Public Property PUE_MONEDA() As Integer
        Get
            Return m_int_pue_moneda
        End Get
        Set(ByVal Value As Integer)
            m_int_pue_moneda = Value
        End Set
    End Property

    Public Property PUE_BASE() As Decimal
        Get
            Return m_dec_pue_base
        End Get
        Set(ByVal Value As Decimal)
            m_dec_pue_base = Value
        End Set
    End Property

    Public Property PUE_BONO1() As Decimal
        Get
            Return m_dec_pue_bono1
        End Get
        Set(ByVal Value As Decimal)
            m_dec_pue_bono1 = Value
        End Set
    End Property

    Public Property PUE_BONO2() As Decimal
        Get
            Return m_dec_pue_bono2
        End Get
        Set(ByVal Value As Decimal)
            m_dec_pue_bono2 = Value
        End Set
    End Property

    Public ReadOnly Property CantRecorSet() As Integer
        Get
            Return Cantidad_de_la_Clase
        End Get
    End Property

    Public Property CONEXION() As String
        Set(ByVal VALUE As String)
            CONstr = VALUE
            Try
                MENSAJE = ""
                If IsNothing(CON) = True Then
                    CON = New MySqlConnection
                End If
                If CON.State = ConnectionState.Open Then
                    CON.Close()
                End If
                CON.ConnectionString = CONstr
                CON.Open()
            Catch MyEX As MySqlException
                MENSAJE = "BiblioTABLAS - TPUESTOS - CONEXION MyError=" & MyEX.ToString
            Catch EX As Exception
                MENSAJE = "BiblioTABLAS - TPUESTOS - CONEXION Error=" & EX.ToString
            End Try
        End Set
        Get
            Return CONstr
        End Get
    End Property

    Public WriteOnly Property TRANSACCION() As MySqlTransaction
        Set(ByVal VALUE As MySqlTransaction)
            TRA = VALUE
        End Set
    End Property

    Public ReadOnly Property MERROR() As String
        Get
            Return MENSAJE
        End Get
    End Property

#End Region


#Region "Funciones Publicas"

    Public Sub New()
        PUE_SISEMP = INT_CERO
        PUE_CODIGO = INT_CERO
        PUE_DESCRIPCION = STR_VACIO
        PUE_SISTEMA = STR_VACIO
        PUE_MONEDA = INT_CERO
        PUE_BASE = INT_CERO
        PUE_BONO1 = INT_CERO
        PUE_BONO2 = INT_CERO
    End Sub

    Public Sub Reset(Optional ByVal Tipo As TipoReset = TipoReset.Data)
        Try
            INIT_LLAVE()
            INIT()
            If Tipo = clsPuesto.TipoReset.Full Then
                Dispose()
            End If
        Catch Ex As Exception
            MENSAJE = "BiblioTABLAS - TPUESTOS - RESET No se podo hacer el Reset de la Clase" & Ex.ToString
        End Try
    End Sub

    Public Sub Dispose()
        Try
            If IsNothing(REA) = False Then
                REA.Close()
            End If
            If IsNothing(CON) = False Then
                If CON.State = ConnectionState.Open Then
                    CON.Close()
                End If
            End If
            CON = Nothing
            REA = Nothing
        Catch EX As Exception
        End Try
    End Sub

    Private Sub INIT()
        PUE_DESCRIPCION = STR_VACIO
        PUE_SISTEMA = STR_VACIO
        PUE_MONEDA = INT_CERO
        PUE_BASE = INT_CERO
        PUE_BONO1 = INT_CERO
        PUE_BONO2 = INT_CERO
        Cantidad_de_la_Clase = INT_CERO
    End Sub

    Private Sub INIT_LLAVE()
        PUE_SISEMP = INT_CERO
        PUE_CODIGO = INT_CERO
    End Sub

    Public Function SiguienteRegistro() As Boolean

        SiguienteRegistro = False
        INIT()
        INIT_LLAVE()
        If IsNothing(REA) = True Then
            MENSAJE = "BiblioTABLAS - TPUESTOS - PMOVE_NEXT Conexi�n no definida"
            Exit Function
        End If
        Try
            If REA.Read = True Then
                If REA.IsDBNull(REA.GetOrdinal("pue_sisemp")) = False Then
                    m_int_pue_sisemp = REA.GetInt32("pue_sisemp")
                Else
                    m_int_pue_sisemp = NO_FILA
                End If
                If REA.IsDBNull(REA.GetOrdinal("pue_codigo")) = False Then
                    m_int_pue_codigo = REA.GetInt32("pue_codigo")
                Else
                    m_int_pue_codigo = NO_FILA
                End If
                If REA.IsDBNull(REA.GetOrdinal("pue_descripcion")) = False Then
                    m_str_pue_descripcion = REA.GetString("pue_descripcion")
                Else
                    m_str_pue_descripcion = "NULL"
                End If
                If REA.IsDBNull(REA.GetOrdinal("pue_sistema")) = False Then
                    m_obj_pue_sistema = REA.GetString("pue_sistema")
                End If
                If REA.IsDBNull(REA.GetOrdinal("pue_moneda")) = False Then
                    m_int_pue_moneda = REA.GetInt32("pue_moneda")
                Else
                    m_int_pue_moneda = NO_FILA
                End If
                If REA.IsDBNull(REA.GetOrdinal("pue_base")) = False Then
                    m_dec_pue_base = REA.GetDecimal("pue_base")
                End If
                If REA.IsDBNull(REA.GetOrdinal("pue_bono1")) = False Then
                    m_dec_pue_bono1 = REA.GetDecimal("pue_bono1")
                End If
                If REA.IsDBNull(REA.GetOrdinal("pue_bono2")) = False Then
                    m_dec_pue_bono2 = REA.GetDecimal("pue_bono2")
                End If
                SiguienteRegistro = True
            Else
                REA.Close()
                REA = Nothing
            End If
        Catch MYEX As MySqlException
            MENSAJE = "BiblioTABLAS - TPUESTOS - PMOVE_NEXT Error=" & MYEX.ToString
        Catch EX As Exception
            MENSAJE = "BiblioTABLAS - TPUESTOS - PMOVE_NEXT Error=" & EX.ToString
        End Try
    End Function

    Public Function SelecionarLista(Optional ByVal CONDICION As String = STR_VACIO, Optional ByVal ORDENAMIENTO As String = STR_VACIO) As Boolean
        Dim COM As MySqlCommand
        Dim SQL As String
        Dim SQL1 As String

        SelecionarLista = False
        If IsNothing(REA) = False Then
            REA.Close()
            REA = Nothing
        End If
        If IsNothing(CON) = True Then
            MENSAJE = "BiblioTABLAS - TPUESTOS - PSELECT_RECORDSET Conexi�n no definida"
            Exit Function
        End If
        If CON.State = ConnectionState.Closed Or CON.State = ConnectionState.Broken Then
            If CON.ConnectionString.Length <> 0 Then
                Try
                    CON.Open()
                Catch MYEX As MySqlException
                    MENSAJE = "BiblioTABLAS - TTPUESTOS - PSELECT_RECORDSET Error#=" & MYEX.Number & " " & MYEX.ToString
                    Exit Function
                Catch EX As Exception
                    MENSAJE = "BiblioTABLAS - TTPUESTOS - PSELECT_RECORDSET Error=" & EX.ToString
                    Exit Function
                End Try
            Else
                MENSAJE = "BiblioTABLAS - TTPUESTOS - PSELECT_RECORDSET String de Conexi�n no definido"
                Exit Function
            End If
        End If

        COM = Nothing
        SQL = "Select * from Puestos"
        If CONDICION.Length <> 0 Then
            SQL &= " Where " & CONDICION
        End If
        If ORDENAMIENTO.Length <> 0 Then
            SQL &= " Order By " & ORDENAMIENTO
        End If

        SQL1 = "Select Count(*) as Cuenta from Puestos"
        If CONDICION.Length <> 0 Then
            SQL1 &= " Where " & CONDICION
        End If
        Try
            INIT()
            INIT_LLAVE()

            COM = New MySqlCommand(SQL1, CON)
            Cantidad_de_la_Clase = CInt(COM.ExecuteScalar())
            COM.Dispose()
            COM = Nothing

            COM = New MySqlCommand(SQL, CON)
            COM.CommandType = CommandType.Text
            REA = COM.ExecuteReader
            SelecionarLista = True
        Catch MYEX As MySqlException
            MENSAJE = "BiblioTABLAS - TPUESTOS - PSELECT_RECORDSET MyError#=" & MYEX.Number & " MyError=" & MYEX.ToString
        Catch EX As Exception
            MENSAJE = "BiblioTABLAS - TPUESTOS - PSELECT_RECORDSET Error=" & EX.ToString
        Finally
            If IsNothing(COM) = False Then
                COM.Dispose()
                COM = Nothing
            End If
        End Try
    End Function

    Public Function PSELECT(ByVal KPUE_SISEMP As Integer, ByVal KPUE_CODIGO As Integer) As Boolean
        Dim READER As MySqlDataReader
        Dim COM As MySqlCommand
        Dim SQL As String

        MENSAJE = STR_VACIO
        PSELECT = False
        If IsNothing(CON) = True Then
            MENSAJE = "BiblioTABLAS - TPUESTOS - PSELECT Conexi�n no definida"
            Exit Function
        End If
        If CON.State = ConnectionState.Closed Or CON.State = ConnectionState.Broken Then
            If CON.ConnectionString.Length <> 0 Then
                Try
                    CON.Open()
                Catch MYEX As MySqlException
                    MENSAJE = "BiblioTABLAS - TTPUESTOS - PSELECT Error#=" & MYEX.Number & " " & MYEX.ToString
                    Exit Function
                Catch EX As Exception
                    MENSAJE = "BiblioTABLAS - TTPUESTOS - PSELECT Error=" & EX.ToString
                    Exit Function
                End Try
            Else
                MENSAJE = "BiblioTABLAS - TTPUESTOS - PSELECT String de Conexi�n no definido"
                Exit Function
            End If
        End If

        SQL = "SELECT * FROM Puestos WHERE PUE_SISEMP = ?P1 AND PUE_CODIGO = ?P2"
        READER = Nothing
        COM = Nothing
        Try
            INIT()
            COM = New MySqlCommand(SQL, CON)
            COM.CommandType = CommandType.Text
            COM.Parameters.AddWithValue("?P1", KPUE_SISEMP)
            COM.Parameters.AddWithValue("?P2", KPUE_CODIGO)
            READER = COM.ExecuteReader(CommandBehavior.SingleRow)
            READER.Read()
            If READER.HasRows = True Then
                If READER.IsDBNull(READER.GetOrdinal("pue_sisemp")) = False Then
                    m_int_pue_sisemp = READER.GetInt32("pue_sisemp")
                Else
                    m_int_pue_sisemp = NO_FILA
                End If
                If READER.IsDBNull(READER.GetOrdinal("pue_codigo")) = False Then
                    m_int_pue_codigo = READER.GetInt32("pue_codigo")
                Else
                    m_int_pue_codigo = NO_FILA
                End If
                If READER.IsDBNull(READER.GetOrdinal("pue_descripcion")) = False Then
                    m_str_pue_descripcion = READER.GetString("pue_descripcion")
                Else
                    m_str_pue_descripcion = "NULL"
                End If
                If READER.IsDBNull(READER.GetOrdinal("pue_sistema")) = False Then
                    m_obj_pue_sistema = READER.GetString("pue_sistema")
                End If
                If READER.IsDBNull(READER.GetOrdinal("pue_moneda")) = False Then
                    m_int_pue_moneda = READER.GetInt32("pue_moneda")
                Else
                    m_int_pue_moneda = NO_FILA
                End If
                If READER.IsDBNull(READER.GetOrdinal("pue_base")) = False Then
                    m_dec_pue_base = READER.GetDecimal("pue_base")
                End If
                If READER.IsDBNull(READER.GetOrdinal("pue_bono1")) = False Then
                    m_dec_pue_bono1 = READER.GetDecimal("pue_bono1")
                End If
                If READER.IsDBNull(READER.GetOrdinal("pue_bono2")) = False Then
                    m_dec_pue_bono2 = READER.GetDecimal("pue_bono2")
                End If
            Else
                MENSAJE = ""
                Exit Function
            End If
            READER.Close()
            COM.Dispose()
            READER = Nothing
            COM = Nothing
            PSELECT = True
        Catch MYEX As MySqlException
            MENSAJE = "BiblioTABLAS - TPUESTOS - PSELECT MyError#=" & MYEX.Number & " MyError=" & MYEX.ToString
        Catch EX As Exception
            MENSAJE = "BiblioTABLAS - TPUESTOS - PSELECT Error=" & EX.ToString
        Finally
            If IsNothing(READER) = False Then
                READER.Close()
                READER = Nothing
            End If
            If IsNothing(COM) = False Then
                COM.Dispose()
                COM = Nothing
            End If
        End Try
    End Function

    Public Function Seleccionar(ByVal strCampos As String, ByVal CONDICION As String) As Boolean

        Dim READER As MySqlDataReader
        Dim COM As MySqlCommand
        Dim SQL As String
        Dim arrayCampos() As String
        MENSAJE = STR_VACIO
        Seleccionar = False
        If IsNothing(CON) = True Then
            MENSAJE = "BiblioTABLAS - TPUESTOS - PSELECT_CONDICION Conexi�n no definida"
            Exit Function
        End If
        If CON.State = ConnectionState.Closed Or CON.State = ConnectionState.Broken Then
            If CON.ConnectionString.Length <> 0 Then
                Try
                    CON.Open()
                Catch MYEX As MySqlException
                    MENSAJE = "BiblioTABLAS - TTPUESTOS - PSELECT_CONDICION Error#=" & MYEX.Number & " " & MYEX.ToString
                    Exit Function
                Catch EX As Exception
                    MENSAJE = "BiblioTABLAS - TTPUESTOS - PSELECT_CONDICION Error=" & EX.ToString
                    Exit Function
                End Try
            Else
                MENSAJE = "BiblioTABLAS - TTPUESTOS - PSELECT_CONDICION String de Conexi�n no definido"
                Exit Function
            End If
        End If
        If strCampos = STR_ASTERISCO Then
            strCampos = " pue_sisemp, pue_codigo, pue_descripcion, pue_sistema, pue_moneda, pue_base, pue_bono1, pue_bono2"
        End If
        SQL = "SELECT " & strCampos & " FROM Puestos WHERE " & CONDICION & " AND pue_sisemp = " & Sesion.IdEmpresa
        READER = Nothing
        COM = Nothing
        Try
            INIT()
            COM = New MySqlCommand(SQL, CON)
            COM.CommandType = CommandType.Text
            READER = COM.ExecuteReader(CommandBehavior.SingleRow)
            READER.Read()
            If READER.HasRows = True Then
                arrayCampos = strCampos.Split(",".ToCharArray)
                For i As Integer = 0 To arrayCampos.Length - 1
                    Select Case Trim(arrayCampos(i))
                        Case "pue_sisemp"
                            If READER.IsDBNull(READER.GetOrdinal("pue_codigo")) = False Then
                                m_int_pue_codigo = READER.GetInt32("pue_codigo")
                            Else
                                m_int_pue_codigo = NO_FILA
                            End If
                        Case "pue_codigo"

                        Case "pue_descripcion"
                            If READER.IsDBNull(READER.GetOrdinal("pue_descripcion")) = False Then
                                m_str_pue_descripcion = READER.GetString("pue_descripcion")
                            Else
                                m_str_pue_descripcion = "NULL"
                            End If
                        Case "pue_sistema"
                            If READER.IsDBNull(READER.GetOrdinal("pue_sistema")) = False Then
                                m_obj_pue_sistema = READER.GetString("pue_sistema")
                            End If
                        Case "pue_moneda"
                            If READER.IsDBNull(READER.GetOrdinal("pue_moneda")) = False Then
                                m_int_pue_moneda = READER.GetInt32("pue_moneda")
                            Else
                                m_int_pue_moneda = NO_FILA
                            End If
                        Case "pue_base"
                            If READER.IsDBNull(READER.GetOrdinal("pue_base")) = False Then
                                m_dec_pue_base = READER.GetDecimal("pue_base")
                            End If
                        Case "pue_bono1"
                            If READER.IsDBNull(READER.GetOrdinal("pue_bono1")) = False Then
                                m_dec_pue_bono1 = READER.GetDecimal("pue_bono1")
                            End If
                        Case "pue_bono2"
                            If READER.IsDBNull(READER.GetOrdinal("pue_bono2")) = False Then
                                m_dec_pue_bono2 = READER.GetDecimal("pue_bono2")
                            End If
                    End Select
                Next
                Seleccionar = True
            Else
                MENSAJE = STR_VACIO
                Exit Function
            End If
            READER.Close()
            COM.Dispose()
            READER = Nothing
            COM = Nothing
            Seleccionar = True
        Catch MYEX As MySqlException
            MENSAJE = "BiblioTABLAS - TPUESTOS - PSELECT_CONDICION MyError#=" & MYEX.Number & " MyError=" & MYEX.ToString
        Catch EX As Exception
            MENSAJE = "BiblioTABLAS - TPUESTOS - PSELECT_CONDICION Error=" & EX.ToString
        Finally
            If IsNothing(READER) = False Then
                READER.Close()
                READER = Nothing
            End If
            If IsNothing(COM) = False Then
                COM.Dispose()
                COM = Nothing
            End If
        End Try
    End Function

    Public Function Guardar() As Boolean
        Dim COM As MySqlCommand
        Dim SQL As String

        MENSAJE = STR_VACIO
        Guardar = False
        If IsNothing(CON) = True Then
            MENSAJE = "BiblioTABLAS - TPUESTOS - PINSERT Conexi�n no definida"
            Exit Function
        End If
        If CON.State = ConnectionState.Closed Or CON.State = ConnectionState.Broken Then
            If CON.ConnectionString.Length <> 0 Then
                Try
                    CON.Open()
                Catch MYEX As MySqlException
                    MENSAJE = "BiblioTABLAS - TTPUESTOS - PINSERT Error#=" & MYEX.Number & " " & MYEX.ToString
                    Exit Function
                Catch EX As Exception
                    MENSAJE = "BiblioTABLAS - TTPUESTOS - PINSERT Error=" & EX.ToString
                    Exit Function
                End Try
            Else
                MENSAJE = "BiblioTABLAS - TTPUESTOS - PINSERT String de Conexi�n no definido"
                Exit Function
            End If
        End If

        COM = Nothing
        Try
            SQL = "INSERT INTO Puestos (pue_sisemp,pue_codigo,pue_descripcion,pue_sistema,pue_moneda,pue_base,pue_bono1,pue_bono2) " & _
                "VALUES(?P1,?P2,?P3,?P4,?P5,?P6,?P7,?P8)"
            If IsNothing(TRA) = False Then
                COM = New MySqlCommand(SQL, TRA.Connection, TRA)
            Else
                COM = New MySqlCommand(SQL, CON)
            End If
            COM.CommandType = CommandType.Text

            COM.Parameters.AddWithValue("?P1", Sesion.IdEmpresa)

            COM.Parameters.AddWithValue("?P2", NuevoId)

            If m_str_pue_descripcion.ToUpper = "NULL" Then
                COM.Parameters.AddWithValue("?P3", DBNull.Value)
            Else
                COM.Parameters.AddWithValue("?P3", m_str_pue_descripcion)
            End If
            COM.Parameters.AddWithValue("?P4", m_obj_pue_sistema)
            If m_int_pue_moneda = -1 Then
                COM.Parameters.AddWithValue("?P5", DBNull.Value)
            Else
                COM.Parameters.AddWithValue("?P5", m_int_pue_moneda)
            End If
            COM.Parameters.AddWithValue("?P6", m_dec_pue_base)
            COM.Parameters.AddWithValue("?P7", m_dec_pue_bono1)
            COM.Parameters.AddWithValue("?P8", m_dec_pue_bono2)
            COM.ExecuteNonQuery()
            COM.Dispose()
            COM = Nothing
            Guardar = True
        Catch MYEX As MySqlException
            MENSAJE = "BiblioTABLAS - TPUESTOS - PINSERT MyError#=" & MYEX.Number & " MyError=" & MYEX.ToString
        Catch ex As Exception
            MENSAJE = "BiblioTABLAS - TPUESTOS - PINSERT Error=" & ex.ToString
        Finally
            If IsNothing(COM) = False Then
                COM.Dispose()
                COM = Nothing
            End If
        End Try
    End Function

    Public Function Borrar(Optional ByVal Condicion As String = "") As Boolean

        Dim COM As MySqlCommand
        Dim SQL As String

        MENSAJE = STR_VACIO
        Borrar = False
        If IsNothing(CON) = True Then
            MENSAJE = "BiblioTABLAS - TPUESTOS - PDELETE Conexi�n no definida"
            Exit Function
        End If
        If CON.State = ConnectionState.Closed Or CON.State = ConnectionState.Broken Then
            If CON.ConnectionString.Length <> 0 Then
                Try
                    CON.Open()
                Catch MYEX As MySqlException
                    MENSAJE = "BiblioTABLAS - TTPUESTOS - PDELETE Error#=" & MYEX.Number & " " & MYEX.ToString
                    Exit Function
                Catch EX As Exception
                    MENSAJE = "BiblioTABLAS - TTPUESTOS - PDELETE Error=" & EX.ToString
                    Exit Function
                End Try
            Else
                MENSAJE = "BiblioTABLAS - TTPUESTOS - PDELETE String de Conexi�n no definido"
                Exit Function
            End If
        End If

        COM = Nothing
        Try
            If Condicion.Length <> 0 Then
                SQL = "DELETE FROM Puestos WHERE " & Condicion
                If IsNothing(TRA) = False Then
                    COM = New MySqlCommand(SQL, TRA.Connection, TRA)
                Else
                    COM = New MySqlCommand(SQL, CON)
                End If
                COM.CommandType = CommandType.Text
            Else
                SQL = "DELETE FROM Puestos WHERE pue_sisemp = ?P1  AND pue_codigo = ?P2 "
                If IsNothing(TRA) = False Then
                    COM = New MySqlCommand(SQL, TRA.Connection, TRA)
                Else
                    COM = New MySqlCommand(SQL, CON)
                End If
                COM.CommandType = CommandType.Text
                COM.Parameters.AddWithValue("?P1", m_int_pue_sisemp)
                COM.Parameters.AddWithValue("?P2", m_int_pue_codigo)
            End If
            COM.ExecuteNonQuery()
            COM.Dispose()
            COM = Nothing
            Borrar = True
        Catch MYEX As MySqlException
            MENSAJE = "BiblioTABLAS - TPUESTOS - PDELETE MyError#=" & MYEX.Number & " MyError=" & MYEX.ToString
        Catch ex As Exception
            MENSAJE = "BiblioTABLAS - TPUESTOS - PDELETE Error=" & ex.ToString
        Finally
            If IsNothing(COM) = False Then
                COM.Dispose()
                COM = Nothing
            End If
        End Try
    End Function

    Public Function Actuallizar() As Boolean

        Dim COM As MySqlCommand
        Dim SQL As String

        MENSAJE = STR_VACIO
        Actuallizar = False
        If IsNothing(CON) = True Then
            MENSAJE = "BiblioTABLAS - TPUESTOS - PUPDATE Conexi�n no definida"
            Exit Function
        End If
        If CON.State = ConnectionState.Closed Or CON.State = ConnectionState.Broken Then
            If CON.ConnectionString.Length <> 0 Then
                Try
                    CON.Open()
                Catch MYEX As MySqlException
                    MENSAJE = "BiblioTABLAS - TTPUESTOS - PUPDATE Error#=" & MYEX.Number & " " & MYEX.ToString
                    Exit Function
                Catch EX As Exception
                    MENSAJE = "BiblioTABLAS - TTPUESTOS - PUPDATE Error=" & EX.ToString
                    Exit Function
                End Try
            Else
                MENSAJE = "BiblioTABLAS - TTPUESTOS - PUPDATE String de Conexi�n no definido"
                Exit Function
            End If
        End If

        COM = Nothing
        Try
            SQL = "UPDATE Puestos SET pue_descripcion = ?P3, pue_sistema = ?P4, pue_moneda = ?P5, pue_base = ?P6, pue_bono1 = ?P7, pue_bono2 = ?P8 WHERE pue_sisemp = ?P1 AND pue_codigo = ?P2"
            If IsNothing(TRA) = False Then
                COM = New MySqlCommand(SQL, TRA.Connection, TRA)
            Else
                COM = New MySqlCommand(SQL, CON)
            End If
            COM.CommandType = CommandType.Text
            If m_str_pue_descripcion.ToUpper = "NULL" Then
                COM.Parameters.AddWithValue("?P3", DBNull.Value)
            Else
                COM.Parameters.AddWithValue("?P3", m_str_pue_descripcion)
            End If
            COM.Parameters.AddWithValue("?P4", m_obj_pue_sistema)
            If m_int_pue_moneda = NO_FILA Then
                COM.Parameters.AddWithValue("?P5", DBNull.Value)
            Else
                COM.Parameters.AddWithValue("?P5", m_int_pue_moneda)
            End If
            COM.Parameters.AddWithValue("?P6", m_dec_pue_base)
            COM.Parameters.AddWithValue("?P7", m_dec_pue_bono1)
            COM.Parameters.AddWithValue("?P8", m_dec_pue_bono2)
            COM.Parameters.AddWithValue("?P1", m_int_pue_sisemp)
            COM.Parameters.AddWithValue("?P2", m_int_pue_codigo)
            COM.ExecuteNonQuery()
            COM.Dispose()
            COM = Nothing
            Actuallizar = True
        Catch MYEX As MySqlException
            MENSAJE = "BiblioTABLAS - TPUESTOS - PUPDATE MyError#=" & MYEX.Number & " MyError=" & MYEX.ToString
        Catch ex As Exception
            MENSAJE = "BiblioTABLAS - TPUESTOS - PUPDATE Error=" & ex.ToString
        Finally
            If IsNothing(COM) = False Then
                COM.Dispose()
                COM = Nothing
            End If
        End Try
    End Function

    Private Function NuevoId() As Integer
        NuevoId = NO_FILA
        Dim strSQL As String = STR_VACIO
        Dim COM As MySqlCommand
        strSQL = "SELECT ifnull(max(pue_codigo),0)+1 FROM Puestos WHERE pue_sisemp = " & Sesion.IdEmpresa
        Try
            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSQL, CON)
            NuevoId = CInt(COM.ExecuteScalar)
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Function

#End Region

End Class

