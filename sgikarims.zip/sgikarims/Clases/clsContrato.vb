﻿Public Class clsContrato

#Region "Miembros"

    Dim intIdContrato As Integer = NO_FILA
    Dim intIdEmpresa As Integer = NO_FILA
    Const intIdCatalogo As Integer = 436
    Dim strDescPuesto As Object = Nothing
    Dim intAnio As Integer = 2000
    Dim dateFecha As MySqlDateTime = New MySqlDateTime(0, 0, 0, 0, 0, 0)
    Dim intIdEmpleado As Integer = NO_FILA
    Dim strNombre As String = STR_VACIO
    Dim intIdDepartamento As Integer = NO_FILA
    Dim strVigencia As String = STR_VACIO
    Dim intIdCentro As Integer = NO_FILA
    Dim strDias As String = STR_VACIO
    Dim dblISR As Double = INT_CERO
    Dim dateInicio As MySqlDateTime
    Dim dateFin As MySqlDateTime
    Dim intIdPuesto As Integer = NO_FILA
    Dim strDepartameto As String = STR_VACIO
    Dim strFormaPago As String = STR_VACIO
    Dim strUsuario As String = STR_VACIO
    Dim intIdMoneda As Integer = NO_FILA
    Dim dblSueldo As Double = INT_CERO
    Dim dblBonificacion As Double = INT_CERO
    Dim dblBono As Double = INT_CERO
    Dim intEstado As Integer = INT_UNO
    Dim strPath As String = STR_VACIO
    Dim intEdad As Integer = INT_CERO
    Dim Srepresentante As New Representante
    Dim SHorarios As New Horarios
    Dim Strabajador As New Trabajador
    Dim strMunicipio As String = STR_VACIO
    Structure Trabajador
        Dim intIdtrabajador As Integer
        Dim strNombre As String
        Dim strCivil As String
        Dim strMunicipio As String
        Dim strDepartamento As String
        Dim strEmpresa As String
        Dim strDireccion As String
        Dim fecNacimiento As MySqlDateTime
        Dim strNacionaliad As String
        Dim strSexo As String
        Dim strDPI As String
    End Structure
    Structure Representante
        Dim intIdRepresentante As Integer
        Dim strNombreR As String
        Dim strCivilR As String
        Dim strMunicipio As String
        Dim strDepartamento As String
        Dim strEmpresa As String
        Dim strDireccion As String
        Dim fecNacimiento As MySqlDateTime
        Dim strNacionaliad As String
        Dim strSexo As String
        Dim strDPI As String
        Dim strCedula As String
    End Structure
    Structure Horarios
        Dim strJornada As String
        Dim strTipo As String
        Dim IntInicio As Integer
        Dim IntFin As Integer
        Dim strDias As String
    End Structure
#End Region

#Region "Propiedades"
    Public Property DescripcionPuesto As Object
        Get
            Return strDescPuesto
        End Get
        Set(value As Object)
            strDescPuesto = value
        End Set
    End Property
    Public Property Municipio As String
        Get
            Return strMunicipio
        End Get
        Set(value As String)
            strMunicipio = value
        End Set
    End Property
    Public Property IdContrato As Integer
        Get
            Return intIdContrato
        End Get
        Set(value As Integer)
            intIdContrato = value
        End Set
    End Property

    Public Property IdEmpresa As Integer
        Get
            Return intIdEmpresa
        End Get
        Set(value As Integer)
            intIdEmpresa = value
        End Set
    End Property

    Public Property Path As String
        Get
            Return strPath
        End Get
        Set(value As String)
            strPath = value
        End Set
    End Property

    Public Property Edad As Integer
        Get
            Return intEdad
        End Get
        Set(value As Integer)
            intEdad = value
        End Set
    End Property

    Public Property Anio As Integer
        Get
            Return intAnio
        End Get
        Set(value As Integer)
            intAnio = value
        End Set
    End Property

    Public Property Fecha As MySqlDateTime
        Get
            Return dateFecha
        End Get
        Set(value As MySqlDateTime)
            dateFecha = value
        End Set
    End Property

    Public WriteOnly Property Fecha_net As Date
        Set(value As Date)
            dateFecha = New MySqlDateTime(value.Year, value.Month, value.Day, value.Hour, value.Minute, value.Second)
        End Set
    End Property

    Public Property IdEmpleado As Integer
        Get
            Return intIdEmpleado
        End Get
        Set(value As Integer)
            intIdEmpleado = value
        End Set
    End Property

    Public Property NombreEmpleado As String
        Get
            Return strNombre
        End Get
        Set(value As String)
            strNombre = value
        End Set
    End Property

    Public Property IdDepartametno As Integer
        Get
            Return intIdDepartamento
        End Get
        Set(value As Integer)
            intIdDepartamento = value
        End Set
    End Property

    Public Property Vigencia As String
        Get
            Return strVigencia
        End Get
        Set(value As String)
            strVigencia = value
        End Set
    End Property

    Public Property IdCentro As Integer
        Get
            Return intIdCentro
        End Get
        Set(value As Integer)
            intIdCentro = value
        End Set
    End Property

    Public Property Dias As String
        Get
            Return strDias
        End Get
        Set(value As String)
            strDias = value
        End Set
    End Property

    Public Property ISR As Double
        Get
            Return dblISR
        End Get
        Set(value As Double)
            dblISR = value
        End Set
    End Property

    Public Property FechaInicio() As MySqlDateTime
        Get
            Return dateInicio
        End Get
        Set(ByVal Value As MySqlDateTime)
            dateInicio = Value
        End Set
    End Property

    Public WriteOnly Property FechaInicio_Net() As DateTime
        Set(ByVal Value As DateTime)
            dateInicio = New MySqlDateTime(Value.Year, Value.Month, Value.Day, Value.Hour, Value.Minute, Value.Second)
        End Set
    End Property

    Public Property FechaFin As MySqlDateTime
        Get
            Return dateFin
        End Get
        Set(value As MySqlDateTime)
            dateFin = value
        End Set
    End Property

    Public WriteOnly Property FechaFin_Net As Date
        Set(value As Date)
            dateFin = New MySqlDateTime(value.Year, value.Month, value.Day, value.Hour, value.Minute, value.Second)
        End Set
    End Property

    Public Property IdPuesto As Integer
        Get
            Return intIdPuesto
        End Get
        Set(value As Integer)
            intIdPuesto = value
        End Set
    End Property

    Public Property Departamento As String
        Get
            Return strDepartameto
        End Get
        Set(value As String)
            strDepartameto = value
        End Set
    End Property

    Public Property FormaPago As String
        Get
            Return strFormaPago
        End Get
        Set(value As String)
            strFormaPago = value
        End Set
    End Property

    Public Property Usuario As String
        Get
            Return strUsuario
        End Get
        Set(value As String)
            strUsuario = value
        End Set
    End Property

    Public Property IdMoneda As Integer
        Get
            Return intIdMoneda
        End Get
        Set(value As Integer)
            intIdMoneda = value
        End Set
    End Property

    Public Property Sueldo As Double
        Get
            Return dblSueldo
        End Get
        Set(value As Double)
            dblSueldo = value
        End Set
    End Property

    Public Property Bonificacion As Double
        Get
            Return dblBonificacion
        End Get
        Set(value As Double)
            dblBonificacion = value
        End Set
    End Property

    Public Property Bono As Double
        Get
            Return dblBono
        End Get
        Set(value As Double)
            dblBono = value
        End Set
    End Property

    Public Property Estado As Integer
        Get
            Return intEstado
        End Get
        Set(value As Integer)
            intEstado = value
        End Set
    End Property

    Public Property Representanteid As Integer
        Get
            Return Srepresentante.intIdRepresentante
        End Get
        Set(value As Integer)
            Srepresentante.intIdRepresentante = value
        End Set
    End Property

    Public Property RepresentanteNombre As String
        Get
            Return Srepresentante.strNombreR
        End Get
        Set(value As String)
            Srepresentante.strNombreR = value
        End Set
    End Property

    Public Property RepresentanteCivil As String
        Get
            Return Srepresentante.strCivilR
        End Get
        Set(value As String)
            Srepresentante.strCivilR = value
        End Set
    End Property

    Public Property RepresentanteMunicipio As String
        Get
            Return Srepresentante.strMunicipio
        End Get
        Set(value As String)
            Srepresentante.strMunicipio = value
        End Set
    End Property

    Public Property RepresentanteDepartamento As String
        Get
            Return Srepresentante.strDepartamento
        End Get
        Set(value As String)
            Srepresentante.strDepartamento = value
        End Set
    End Property

    Public Property RepresentanteEmpresa As String
        Get
            Return Srepresentante.strEmpresa
        End Get
        Set(value As String)
            Srepresentante.strEmpresa = value
        End Set
    End Property

    Public Property RepresentanteDireccion As String
        Get
            Return Srepresentante.strDireccion
        End Get
        Set(value As String)
            Srepresentante.strDireccion = value
        End Set
    End Property

    Public Property RepresentanteCedula As String
        Get
            Return Srepresentante.strCedula
        End Get
        Set(value As String)
            Srepresentante.strCedula = value
        End Set
    End Property
    Public Property RepresentanteNacionalidad As String
        Get
            Return Srepresentante.strNacionaliad
        End Get
        Set(value As String)
            Srepresentante.strNacionaliad = value
        End Set
    End Property
    Public Property RepresentanteSexo As String
        Get
            Return Srepresentante.strSexo
        End Get
        Set(value As String)
            Srepresentante.strSexo = value
        End Set
    End Property
    Public Property RepresentanteDPI As String
        Get
            Return Srepresentante.strDPI
        End Get
        Set(value As String)
            Srepresentante.strDPI = value
        End Set
    End Property
    Public Property RepresentanteNacimiento As MySqlDateTime
        Get
            Return Srepresentante.fecNacimiento
        End Get
        Set(value As MySqlDateTime)
            Srepresentante.fecNacimiento = value
        End Set
    End Property

    Public WriteOnly Property RepresentanteNacimiento_Net As Date
        Set(value As Date)
            Srepresentante.fecNacimiento = New MySqlDateTime(value.Year, value.Month, value.Day, value.Hour, value.Minute, value.Second)
        End Set
    End Property

#End Region

#Region "Funciones"

    Public Function CopiarArchivo() As Boolean
        CopiarArchivo = False
        Dim DialogoGuardar As New SaveFileDialog
        DialogoGuardar.FileName = "Contrato1"
        DialogoGuardar.DefaultExt = ".docx"
        DialogoGuardar.Filter = "Word documents (.docx)|*.docx"
        Dim strOrigen As String = System.Windows.Forms.Application.StartupPath & "\Contrato.docx"
        Dim logResultado As Boolean = DialogoGuardar.ShowDialog()
        If logResultado = True Then
            If cFunciones.ExisteArchivo(strOrigen) = True Then
                Dim strDestino As String = DialogoGuardar.FileName
                Try
                    System.IO.File.Copy(strOrigen, strDestino, True)
                    strPath = strDestino
                    CopiarArchivo = True
                Catch ex As Exception
                    MsgBox(ex.Message, , "Error al copiar")
                End Try
            End If
        End If
    End Function

    Public Sub New()
        intIdContrato = NO_FILA
        intIdEmpresa = NO_FILA
        intAnio = 2000
        dateFecha = New MySqlDateTime(INT_CERO, INT_CERO, INT_CERO, INT_CERO, INT_CERO, INT_CERO)
        intIdEmpleado = NO_FILA
        strNombre = STR_VACIO
        intIdDepartamento = NO_FILA
        strVigencia = STR_VACIO
        intIdCentro = NO_FILA
        strDias = STR_VACIO
        dblISR = INT_CERO
        dateInicio = New MySqlDateTime(INT_CERO, INT_CERO, INT_CERO, INT_CERO, INT_CERO, INT_CERO)
        dateFin = New MySqlDateTime(INT_CERO, INT_CERO, INT_CERO, INT_CERO, INT_CERO, INT_CERO)
        intIdPuesto = NO_FILA
        strDepartameto = STR_VACIO
        strFormaPago = STR_VACIO
        strUsuario = STR_VACIO
        intIdMoneda = NO_FILA
        dblSueldo = INT_CERO
        dblBonificacion = INT_CERO
        dblBono = INT_CERO
        intEstado = INT_UNO
        strPath = STR_VACIO
        Srepresentante.strCivilR = STR_VACIO
        Srepresentante.strDepartamento = STR_VACIO
        Srepresentante.strEmpresa = STR_VACIO
        Srepresentante.strMunicipio = STR_VACIO
        Srepresentante.strNombreR = STR_VACIO
        SHorarios.IntFin = INT_CERO
        SHorarios.IntInicio = INT_CERO
        SHorarios.strDias = STR_VACIO
        SHorarios.strJornada = STR_VACIO
        SHorarios.strTipo = STR_VACIO
    End Sub

    Private Function NuevoId(ByVal idCatalogo As Integer) As Long
        Dim intId As Long = NO_FILA
        Dim strSQL As String = STR_VACIO
        Dim COM As New MySqlCommand
        strSQL = "SELECT (IFNULL(MAX(HDoc_Doc_Num),0)+1) ID FROM Dcmtos_HDR WHERE HDoc_Sis_Emp= {empresa}" & _
            " AND HDoc_Doc_Cat = {cat} AND HDoc_Doc_Ano = {año} "
        strSQL = Replace(strSQL, "{cat}", idCatalogo)
        strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
        strSQL = Replace(strSQL, "{año}", MYSQL_AÑO)
        Try
            MyCnn.CONECTAR = strConexion
            If MyCnn.ProbarConexiones = True Then
                COM = New MySqlCommand(strSQL, CON)
                intId = CInt(COM.ExecuteScalar)
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        Return intId
    End Function

    Private Function EjecutarSQL(ByVal strSQL As String) As Boolean
        EjecutarSQL = False
        Dim COM As MySqlCommand
        Try
            MyCnn.CONECTAR = strConexion
            If MyCnn.ProbarConexiones = True Then
                COM = New MySqlCommand(strSQL, CON)
                COM.CommandType = CommandType.Text
                COM.ExecuteNonQuery()
                COM = Nothing
                EjecutarSQL = True
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Function

    Public Function Guardar(listaHOrarios As DataGridView) As Boolean
        Dim intNuevoId As Integer = NuevoId(436)
        Dim intLinea As Integer = INT_UNO
        Guardar = False
        Dim fecha As String = Format(FechaInicio.Value, "yyyy-MM-dd")
        'GUARDAR ENCABEZADO DE DOCUMENTO
        Dim strSQL As String = "INSERT INTO Dcmtos_HDR (HDoc_Sis_Emp, HDoc_Doc_Cat, HDoc_Doc_Ano, HDoc_Doc_Num, " &
            " HDoc_Doc_Fec, HDoc_Emp_Cod , HDoc_Emp_Nom , HDoc_Emp_Dir, HDoc_Emp_Per, HDoc_Emp_Tel, " &
            " HDoc_DR1_Cat, HDoc_DR1_Num, HDoc_DR1_Dbl, HDoc_DR1_Fec, HDoc_DR1_Emp, HDoc_DR2_Cat, HDoc_DR2_Num, " &
            " HDoc_Usuario , HDoc_Doc_Mon, HDoc_RF1_Dbl, HDoc_RF2_Dbl, HDoc_RF3_Dbl, " &
            " HDoc_Doc_Status)  VALUES({?p1},{?p2},{?p3},{?p4},{?p5},{?p6},'{?p7}','{?p8}','{?p9}','{?p10}',{?p11},'{?p12}'," &
            " {?p13},'{?p14}',{?p15},{?p16},'{?p17}','{?p18}',{?p20},{?p21},{?p22},{?p23},{?p24}); "
        If Sesion.IdEmpresa = 18 Then
            strSQL &= "INSERT INTO PDM.Dcmtos_HDR (HDoc_Sis_Emp, HDoc_Doc_Cat, HDoc_Doc_Ano, HDoc_Doc_Num, " &
            " HDoc_Doc_Fec, HDoc_Emp_Cod , HDoc_Emp_Nom , HDoc_Emp_Dir, HDoc_Emp_Per, HDoc_Emp_Tel, " &
            " HDoc_DR1_Cat, HDoc_DR1_Num, HDoc_DR1_Dbl, HDoc_DR1_Fec, HDoc_DR1_Emp, HDoc_DR2_Cat, HDoc_DR2_Num, " &
            " HDoc_Usuario , HDoc_Doc_Mon, HDoc_RF1_Dbl, HDoc_RF2_Dbl, HDoc_RF3_Dbl, " &
            " HDoc_Doc_Status)  VALUES({?p1},{?p2},{?p3},{?p4},{?p5},{?p6},'{?p7}','{?p8}','{?p9}','{?p10}',{?p11},'{?p12}'," &
            " {?p13},'{?p14}',{?p15},{?p16},'{?p17}','{?p18}',{?p20},{?p21},{?p22},{?p23},{?p24}); "
        End If
        strSQL = Replace(strSQL, "{?p1}", Sesion.IdEmpresa)
        strSQL = Replace(strSQL, "{?p2}", intIdCatalogo)
        strSQL = Replace(strSQL, "{?p3}", MYSQL_AÑO)
        strSQL = Replace(strSQL, "{?p4}", intNuevoId)
        strSQL = Replace(strSQL, "{?p5}", MYSQL_HOY)
        strSQL = Replace(strSQL, "{?p6}", intIdEmpleado)
        strSQL = Replace(strSQL, "{?p7}", strNombre)
        strSQL = Replace(strSQL, "{?p8}", strDescPuesto)
        strSQL = Replace(strSQL, "{?p9}", strDepartameto)
        strSQL = Replace(strSQL, "{?p10}", strVigencia)
        strSQL = Replace(strSQL, "{?p11}", intIdCentro)
        strSQL = Replace(strSQL, "{?p12}", "") 'strDias
        strSQL = Replace(strSQL, "{?p13}", dblISR)
        strSQL = Replace(strSQL, "{?p14}", fecha)
        strSQL = Replace(strSQL, "{?p15}", intIdPuesto)
        strSQL = Replace(strSQL, "{?p16}", intIdDepartamento)
        strSQL = Replace(strSQL, "{?p17}", strFormaPago)
        strSQL = Replace(strSQL, "{?p18}", Sesion.Usuario)
        strSQL = Replace(strSQL, "{?p20}", intIdMoneda)
        strSQL = Replace(strSQL, "{?p21}", dblSueldo)
        strSQL = Replace(strSQL, "{?p22}", dblBonificacion)
        strSQL = Replace(strSQL, "{?p23}", dblBono)
        strSQL = Replace(strSQL, "{?p24}", intEstado)
        If EjecutarSQL(strSQL) = True Then
            'GUARDAR DATOS DEL REPRESENTANTE
            Dim fnacimiento As String = STR_VACIO
            fnacimiento = Format(Srepresentante.fecNacimiento.Value, "yyyy-MM-dd")
            strSQL = "INSERT INTO Dcmtos_DTL (DDoc_Sis_Emp, DDoc_Doc_Cat, DDoc_Doc_Ano, DDoc_Doc_Num, DDoc_Doc_Lin, DDoc_Prd_PNr," &
                " DDoc_Prd_Des, DDoc_Prd_UM, DDoc_RF1_Cod, DDoc_RF1_Txt, DDoc_RF1_Fec, DDoc_RF2_Cod ,DDoc_Prd_Ref, " &
                " DDoc_RF2_Txt, DDoc_RF3_Txt)" &
                " VALUES (?empresa, ?catalogo, ?ano, ?numero, ?linea, '?llave','?nombre', " &
                " ?idempleado, '?civil', '?direccioncentro', '?nacimiento', '?municipio', '?departamento'," &
                " '?nacionalidad', '?dpi');"
            If Sesion.IdEmpresa = 18 Then
                strSQL &= "INSERT INTO PDM.Dcmtos_DTL (DDoc_Sis_Emp, DDoc_Doc_Cat, DDoc_Doc_Ano, DDoc_Doc_Num, DDoc_Doc_Lin, DDoc_Prd_PNr," &
                " DDoc_Prd_Des, DDoc_Prd_UM, DDoc_RF1_Cod, DDoc_RF1_Txt, DDoc_RF1_Fec, DDoc_RF2_Cod ,DDoc_Prd_Ref, " &
                " DDoc_RF2_Txt, DDoc_RF3_Txt)" &
                " VALUES (?empresa, ?catalogo, ?ano, ?numero, ?linea, '?llave','?nombre', " &
                " ?idempleado, '?civil', '?direccioncentro', '?nacimiento', '?municipio', '?departamento'," &
                " '?nacionalidad', '?dpi')"
            End If
            strSQL = Replace(strSQL, "?empresa", Sesion.IdEmpresa)
            strSQL = Replace(strSQL, "?catalogo", intIdCatalogo)
            strSQL = Replace(strSQL, "?ano", MYSQL_AÑO)
            strSQL = Replace(strSQL, "?numero", intNuevoId)
            intLinea = intLinea + INT_UNO
            strSQL = Replace(strSQL, "?linea", intLinea)
            strSQL = Replace(strSQL, "?llave", "REPRESENTANTE")
            strSQL = Replace(strSQL, "?nombre", Srepresentante.strNombreR)
            strSQL = Replace(strSQL, "?idempleado", Srepresentante.intIdRepresentante)
            strSQL = Replace(strSQL, "?civil", Srepresentante.strCivilR)
            strSQL = Replace(strSQL, "?direccioncentro", Srepresentante.strDireccion)
            strSQL = Replace(strSQL, "?nacimiento", fnacimiento)
            strSQL = Replace(strSQL, "?municipio", Srepresentante.strMunicipio)
            strSQL = Replace(strSQL, "?departamento", Srepresentante.strDepartamento)
            strSQL = Replace(strSQL, "?nacionalidad", Srepresentante.strNacionaliad & "," & Srepresentante.strSexo)
            strSQL = Replace(strSQL, "?dpi", Srepresentante.strDPI)
            If EjecutarSQL(strSQL) = True Then
                'GUARDAR HISTORIAL DE SUELDO
                strSQL = "INSERT INTO Dcmtos_DTL (DDoc_Sis_Emp, DDoc_Doc_Cat, DDoc_Doc_Ano, DDoc_Doc_Num, DDoc_Doc_Lin, " &
                  " DDoc_Prd_PNr, DDoc_Prd_PUQ, DDoc_Prd_DSP, DDoc_Prd_DSQ, DDoc_RF1_Fec, DDoc_RF1_Num, DDoc_Prd_NET) " &
                  "VALUES (?empresa, ?catalogo, ?ano, ?numero, ?linea, '?llave', ?sueldo, ?bonificacio, ?bono, " &
                  "  ?fecha, ?estado, ?isr);"
                If Sesion.IdEmpresa = 18 Then
                    strSQL &= "INSERT INTO PDM.Dcmtos_DTL (DDoc_Sis_Emp, DDoc_Doc_Cat, DDoc_Doc_Ano, DDoc_Doc_Num, DDoc_Doc_Lin, " &
                  " DDoc_Prd_PNr, DDoc_Prd_PUQ, DDoc_Prd_DSP, DDoc_Prd_DSQ, DDoc_RF1_Fec, DDoc_RF1_Num, DDoc_Prd_NET) " &
                  "VALUES (?empresa, ?catalogo, ?ano, ?numero, ?linea, '?llave', ?sueldo, ?bonificacio, ?bono, " &
                  "  ?fecha, ?estado, ?isr)"
                End If
                intLinea = intLinea + INT_UNO
                strSQL = Replace(strSQL, "?empresa", Sesion.IdEmpresa)
                strSQL = Replace(strSQL, "?catalogo", intIdCatalogo)
                strSQL = Replace(strSQL, "?ano", MYSQL_AÑO)
                strSQL = Replace(strSQL, "?numero", intNuevoId)
                strSQL = Replace(strSQL, "?linea", intLinea)
                strSQL = Replace(strSQL, "?llave", "SUELDO")
                strSQL = Replace(strSQL, "?sueldo", dblSueldo)
                strSQL = Replace(strSQL, "?bonificacio", dblBonificacion)
                strSQL = Replace(strSQL, "?bono", dblBono)
                strSQL = Replace(strSQL, "?fecha", MYSQL_HOY)
                strSQL = Replace(strSQL, "?estado", INT_UNO)
                strSQL = Replace(strSQL, "?isr", dblISR)
                If EjecutarSQL(strSQL) = True Then
                    'GUARDAR DATOS ADICIONALES DEL EMPLEADO
                    strSQL = "INSERT INTO Dcmtos_DTL (DDoc_Sis_Emp, DDoc_Doc_Cat,  DDoc_Doc_Ano, DDoc_Doc_Num, DDoc_Doc_Lin, " &
                        " DDoc_Prd_PNr, DDoc_Prd_UM, DDoc_RF2_Cod, DDoc_Prd_Ref, DDoc_RF1_Txt) VALUES (?empresa, ?catalogo, ?ano, " &
                        " ?numero, ?linea, '?llave', ?idempleado, '?municipio', '?departamento', '?descripcionpuesto');"
                    If Sesion.IdEmpresa = 18 Then
                        strSQL &= "INSERT INTO PDM.Dcmtos_DTL (DDoc_Sis_Emp, DDoc_Doc_Cat,  DDoc_Doc_Ano, DDoc_Doc_Num, DDoc_Doc_Lin, " &
                        " DDoc_Prd_PNr, DDoc_Prd_UM, DDoc_RF2_Cod, DDoc_Prd_Ref, DDoc_RF1_Txt) VALUES (?empresa, ?catalogo, ?ano, " &
                        " ?numero, ?linea, '?llave', ?idempleado, '?municipio', '?departamento', '?descripcionpuesto');"
                    End If
                    intLinea = intLinea + INT_UNO
                    strSQL = Replace(strSQL, "?empresa", Sesion.IdEmpresa)
                    strSQL = Replace(strSQL, "?catalogo", intIdCatalogo)
                    strSQL = Replace(strSQL, "?ano", MYSQL_AÑO)
                    strSQL = Replace(strSQL, "?numero", intNuevoId)
                    strSQL = Replace(strSQL, "?linea", intLinea)
                    strSQL = Replace(strSQL, "?llave", "EMPLEADO")
                    strSQL = Replace(strSQL, "?idempleado", intIdEmpleado)
                    strSQL = Replace(strSQL, "?municipio", strMunicipio)
                    strSQL = Replace(strSQL, "?departamento", strDepartameto)
                    strSQL = Replace(strSQL, "?descripcionpuesto", strDescPuesto)
                    If EjecutarSQL(strSQL) = True Then
                        Dim celda As DataGridViewCell
                        Dim idhorario As Integer = INT_CERO
                        Dim strJornada As String = STR_VACIO
                        Dim strHorario As String = STR_VACIO
                        Dim strInico As String = STR_VACIO
                        Dim strFin As String = STR_VACIO
                        'GUARDAR DATOS DE HORARIOS
                        For i As Integer = 0 To listaHOrarios.Rows.Count - 1
                            strSQL = "INSERT INTO Dcmtos_DTL (DDoc_Sis_Emp, DDoc_Doc_Cat, DDoc_Doc_Ano, DDoc_Doc_Num, DDoc_Doc_Lin, " &
                                " DDoc_Prd_PNr, DDoc_Prd_Des, DDoc_RF1_Cod, DDoc_RF2_Cod, DDoc_Prd_Ref) " &
                                "VALUES (?empresa, ?catalogo, ?ano, ?numero, ?linea, '?llave', '?jornada', '?horario', " &
                                " '?horainicio', '?horafin');"
                            If Sesion.IdEmpresa = 18 Then
                                strSQL &= "INSERT INTO PDM.Dcmtos_DTL (DDoc_Sis_Emp, DDoc_Doc_Cat, DDoc_Doc_Ano, DDoc_Doc_Num, DDoc_Doc_Lin, " &
                                " DDoc_Prd_PNr, DDoc_Prd_Des, DDoc_RF1_Cod, DDoc_RF2_Cod, DDoc_Prd_Ref) " &
                                "VALUES (?empresa, ?catalogo, ?ano, ?numero, ?linea, '?llave', '?jornada', '?horario', " &
                                " '?horainicio', '?horafin');"
                            End If
                            celda = listaHOrarios.Rows(i).Cells(0)
                            idhorario = CInt(celda.Value)
                            celda = listaHOrarios.Rows(i).Cells(1)
                            strJornada = celda.Value
                            celda = listaHOrarios.Rows(i).Cells(2)
                            strHorario = celda.Value
                            celda = listaHOrarios.Rows(i).Cells(3)
                            strInico = celda.Value
                            celda = listaHOrarios.Rows(i).Cells(4)
                            strFin = celda.Value
                            intLinea = intLinea + INT_UNO
                            strSQL = Replace(strSQL, "?empresa", Sesion.IdEmpresa)
                            strSQL = Replace(strSQL, "?catalogo", intIdCatalogo)
                            strSQL = Replace(strSQL, "?ano", MYSQL_AÑO)
                            strSQL = Replace(strSQL, "?numero", intNuevoId)
                            strSQL = Replace(strSQL, "?linea", intLinea)
                            strSQL = Replace(strSQL, "?llave", "HORARIO")
                            strSQL = Replace(strSQL, "?jornada", strJornada)
                            strSQL = Replace(strSQL, "?horario", strHorario)
                            strSQL = Replace(strSQL, "?horainicio", strInico)
                            strSQL = Replace(strSQL, "?horafin", strFin)
                            EjecutarSQL(strSQL)
                        Next
                        Guardar = True
                        cFunciones.EscribirRegistro("Contratos", clsFunciones.AccEnum.acAdd, 0, intIdCatalogo, MYSQL_AÑO, intIdContrato)
                    Else
                        MsgBox("No se pudo guardar los datos del trabajador", MsgBoxStyle.Critical, "ERROR")
                    End If
                Else
                    MsgBox("No se pudo guardar los datos salariales", MsgBoxStyle.Critical, "ERROR")
                End If
            Else
                MsgBox("No se pudo guardar la información del representante", MsgBoxStyle.Critical, "ERROR")
            End If
        Else
            MsgBox("No se pudo guardar el contrato", MsgBoxStyle.Critical, "ERROR")
        End If

    End Function

    Public Function Borrar(ByVal intAnio As Integer, ByVal id As Integer) As Boolean
        Borrar = False
        Dim strCondicion As String = "DDoc_Sis_emp = {empresa} AND DDoc_Doc_Cat = " &
            " {catalogo} AND DDoc_Doc_Ano = {anio} AND DDoc_Doc_Num = {contrato} "
        strCondicion = Replace(strCondicion, "{empresa}", Sesion.IdEmpresa)
        strCondicion = Replace(strCondicion, "{catalogo}", intIdCatalogo)
        strCondicion = Replace(strCondicion, "{anio}", intAnio)
        strCondicion = Replace(strCondicion, "{contrato}", id)
        Dim dtl As New clsDcmtos_DTL
        dtl.CONEXION = strConexion
        If dtl.Borrar(strCondicion) = True Then
            Dim hdr As New clsDcmtos_HDR
            hdr.CONEXION = strConexion
            hdr.HDOC_SIS_EMP = Sesion.IdEmpresa
            hdr.HDOC_DOC_CAT = intIdCatalogo
            hdr.HDOC_DOC_ANO = intAnio
            hdr.HDOC_DOC_NUM = id
            If hdr.Borrar() = True Then
                Borrar = True
                cFunciones.EscribirRegistro("Dcmtos_HDR", clsFunciones.AccEnum.acDelete, id, intIdCatalogo, intAnio.ToString)
            End If
        End If
    End Function

    Public Function Seleccionar(ByVal strCampos As String, ByVal strCondicion As String, Optional listaHorarios As DataGridView = Nothing) As Boolean
        Seleccionar = False
        Dim strSQL As String = STR_VACIO
        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader
        Dim Cell As DataGridViewCell
        Dim Row = New DataGridViewRow
        Dim strCamposDTL As String = STR_VACIO
        Dim arrayCampos() As String
        'SELECCIONAR ENCABEZADO ***********************************************************************
        If strCampos = STR_ASTERISCO Then
            strCampos = "HDoc_Sis_Emp, HDoc_Doc_Ano, HDoc_Doc_Num, HDoc_Doc_Fec, HDoc_Emp_Cod, " & _
                "HDoc_Emp_Nom, HDoc_Emp_Dir, HDoc_Emp_Per, HDoc_Emp_Tel, HDoc_DR1_Cat, HDoc_DR1_Num, " & _
                "HDoc_DR1_Dbl, HDoc_DR1_Fec, HDoc_DR1_Emp, HDoc_DR2_Cat, HDoc_DR2_Num, HDoc_Usuario, " & _
                "HDoc_Pro_Fec, HDoc_Doc_Mon, HDoc_RF1_Dbl, HDoc_RF1_Txt, HDoc_RF2_Dbl, HDoc_RF3_Dbl, HDoc_Doc_Status "
        End If
        strSQL = "SELECT " & strCampos & " FROM Dcmtos_HDR WHERE HDoc_Doc_Cat = 436 AND " & strCondicion & " LIMIT 1;"
        Try
            MyCnn.CONECTAR = strConexion
            If MyCnn.ProbarConexiones = True Then
                COM = New MySqlCommand(strSQL, CON)
                REA = COM.ExecuteReader
                REA.Read()
                If REA.HasRows = True Then
                    arrayCampos = strCampos.Split(",".ToCharArray)
                    For i As Integer = 0 To arrayCampos.Length - 1
                        If REA.IsDBNull(REA.GetOrdinal(Trim(arrayCampos(i)))) = False Then
                            Select Case Trim(arrayCampos(i))
                                Case ("HDoc_Sis_Emp")
                                    intIdEmpresa = REA.GetInt32(Trim(arrayCampos(i)))
                                Case ("HDoc_Doc_Ano")
                                    intAnio = REA.GetInt32(Trim(arrayCampos(i)))
                                Case ("HDoc_Doc_Num")
                                    intIdContrato = REA.GetInt32(Trim(arrayCampos(i)))
                                Case ("HDoc_Doc_Fec")
                                    dateFecha = REA.GetMySqlDateTime(Trim(arrayCampos(i)))
                                Case ("HDoc_Emp_Cod")
                                    intIdEmpleado = REA.GetInt32(Trim(arrayCampos(i)))
                                Case ("HDoc_Emp_Nom")
                                    strNombre = REA.GetString(Trim(arrayCampos(i)))
                                Case ("HDoc_Emp_Dir")
                                    strDescPuesto = REA.GetString(Trim(arrayCampos(i)))
                                Case ("HDoc_Emp_Per")
                                    strDepartameto = REA.GetString(Trim(arrayCampos(i)))
                                Case ("HDoc_Emp_Tel")
                                    strVigencia = REA.GetString(Trim(arrayCampos(i)))
                                Case ("HDoc_DR1_Cat")
                                    intIdCentro = REA.GetInt32(Trim(arrayCampos(i)))
                                Case ("HDoc_DR1_Num")
                                    strDias = REA.GetString(Trim(arrayCampos(i)))
                                Case ("HDoc_DR1_Dbl")
                                    dblISR = REA.GetDouble(Trim(arrayCampos(i)))
                                Case ("HDoc_DR1_Fec")
                                    dateInicio = REA.GetMySqlDateTime(Trim(arrayCampos(i)))
                                Case ("HDoc_DR1_Emp")
                                    intIdPuesto = REA.GetInt32(Trim(arrayCampos(i)))
                                Case ("HDoc_DR2_Cat")
                                    intIdDepartamento = REA.GetInt32(Trim(arrayCampos(i)))
                                Case ("HDoc_DR2_Num")
                                    strFormaPago = REA.GetString(Trim(arrayCampos(i)))
                                Case ("HDoc_Usuario")
                                    strUsuario = REA.GetString(Trim(arrayCampos(i)))
                                Case ("HDoc_Pro_Fec")
                                    dateFin = REA.GetMySqlDateTime(Trim(arrayCampos(i)))
                                Case ("HDoc_Doc_Mon")
                                    intIdMoneda = REA.GetInt32(Trim(arrayCampos(i)))
                                Case ("HDoc_RF1_Dbl")
                                    dblSueldo = REA.GetDouble(Trim(arrayCampos(i)))
                                Case ("HDoc_RF2_Dbl")
                                    dblBonificacion = REA.GetDouble(Trim(arrayCampos(i)))
                                Case ("HDoc_RF3_Dbl")
                                    dblBono = REA.GetDouble(Trim(arrayCampos(i)))
                                Case ("HDoc_Doc_Status")
                                    intEstado = REA.GetInt32(Trim(arrayCampos(i)))
                                Case ("HDoc_RF1_Txt")
                                    ' strDescPuesto = REA.GetString(Trim(arrayCampos(i)))
                            End Select
                        End If
                    Next
                    COM.Dispose()
                    COM = Nothing
                    REA = Nothing
                    ' Seleccionar datos del empleado*******************************************************
                    strSQL = STR_VACIO
                    Dim cEmpleado As New clsEmpleado
                    strSQL = "em_codigo = " & intIdEmpleado
                    If cEmpleado.Seleccionar(" em_sexo, em_civil, em_nacionalidad, em_dpi, em_domicilio, em_extendido, em_municipio ", strSQL) = True Then

                    End If
                    strSQL = STR_VACIO
                    'Selecionar Representante *************************************************************
                    Dim Array() As String
                    strSQL = "SELECT * FROM Dcmtos_DTL WHERE ( DDoc_Sis_Emp = {empresa}" & _
                    " AND DDoc_Doc_Cat = {catalogo} AND DDoc_Doc_Ano = {año} AND DDoc_Doc_Num = {id})"
                    strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
                    strSQL = Replace(strSQL, "{catalogo}", intIdCatalogo)
                    strSQL = Replace(strSQL, "{año}", intAnio)
                    strSQL = Replace(strSQL, "{id}", intIdContrato)
                    MyCnn.CONECTAR = strConexion
                    If MyCnn.ProbarConexiones = True Then
                        COM = New MySqlCommand(strSQL, CON)
                        REA = COM.ExecuteReader
                        If REA.HasRows = True Then
                            Do While REA.Read
                                Select Case REA.GetString("DDoc_Prd_PNr")
                                    Case "REPRESENTANTE"
                                        Srepresentante.intIdRepresentante = REA.GetInt32("DDoc_Prd_UM")
                                        Srepresentante.strCivilR = REA.GetString("DDoc_RF1_Cod")
                                        Srepresentante.strDepartamento = REA.GetString("DDoc_Prd_Ref")
                                        Srepresentante.strDireccion = REA.GetString("DDoc_RF1_Txt")
                                        Srepresentante.strMunicipio = REA.GetString("DDoc_RF2_Cod")
                                        If REA.GetMySqlDateTime("DDoc_RF1_Fec").IsValidDateTime Then
                                            Srepresentante.fecNacimiento = REA.GetMySqlDateTime("DDoc_RF1_Fec")
                                        Else
                                            Srepresentante.fecNacimiento = New MySqlDateTime(2000, 1, 1, 0, 0, 0)
                                        End If
                                        If REA.IsDBNull(REA.GetOrdinal("DDoc_RF3_Txt")) = False Then
                                            Srepresentante.strDPI = REA.GetString("DDoc_RF3_Txt").ToString
                                        Else
                                            Srepresentante.strDPI = "DPI NO GUARDADO"
                                        End If
                                        If REA.IsDBNull(REA.GetOrdinal("DDoc_RF2_Txt")) = False Then
                                            Array = REA.GetString("DDoc_RF2_Txt").ToString.Split(",".ToCharArray)
                                            Srepresentante.strNacionaliad = Array(0)
                                            Srepresentante.strSexo = Array(1)
                                        Else
                                            Srepresentante.strNacionaliad = "Nacionalidad no guardada"
                                            Srepresentante.strSexo = "DPI no guardado"
                                        End If
                                        Srepresentante.strNombreR = REA.GetString("DDoc_Prd_Des")
                                    Case "SUELDO"
                                        If REA.IsDBNull(REA.GetOrdinal("DDoc_Prd_PUQ")) = False Then
                                            dblSueldo = CDbl(REA.GetDouble("DDoc_Prd_PUQ"))
                                        Else
                                            dblSueldo = INT_CERO
                                        End If
                                        If REA.IsDBNull(REA.GetOrdinal("DDoc_Prd_DSP")) = False Then
                                            dblBonificacion = CDbl(REA.GetDouble("DDoc_Prd_DSP"))
                                        Else
                                            dblBonificacion = INT_CERO
                                        End If
                                        If REA.IsDBNull(REA.GetOrdinal("DDoc_Prd_DSQ")) = False Then
                                            dblBono = CDbl(REA.GetDouble("DDoc_Prd_DSQ"))
                                        Else
                                            dblBono = INT_CERO
                                        End If
                                        If REA.IsDBNull(REA.GetOrdinal("DDoc_Prd_NET")) = False Then
                                            dblISR = CDbl(REA.GetDouble("DDoc_Prd_NET"))
                                        Else
                                            dblISR = INT_CERO
                                        End If
                                    Case "HORARIO"
                                        Row = New DataGridViewRow
                                        Cell = New DataGridViewTextBoxCell
                                        Cell.Value = REA.GetInt32("DDoc_Doc_Lin")
                                        Row.Cells.Add(Cell)
                                        Cell = New DataGridViewTextBoxCell
                                        Cell.Value = REA.GetString("DDoc_Prd_Des")
                                        Row.Cells.Add(Cell)
                                        Cell = New DataGridViewTextBoxCell
                                        Cell.Value = REA.GetString("DDoc_RF1_Cod")
                                        Row.Cells.Add(Cell)
                                        Cell = New DataGridViewTextBoxCell
                                        Cell.Value = REA.GetString("DDoc_RF2_Cod")
                                        Row.Cells.Add(Cell)
                                        Cell = New DataGridViewTextBoxCell
                                        Cell.Value = REA.GetString("DDoc_Prd_Ref")
                                        Row.Cells.Add(Cell)
                                        listaHorarios.Rows.Add(Row)
                                    Case "EMPLEADO"
                                        strDepartameto = REA.GetString("DDoc_Prd_Ref")
                                        strMunicipio = REA.GetString("DDoc_RF2_Cod")
                                End Select
                            Loop
                        End If
                    End If
                    strSQL = STR_VACIO
                    COM.Dispose()
                    COM = Nothing
                    REA = Nothing
                    Seleccionar = True
                End If
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Function

    Public Function CalcularEdad(ByVal strCondicion) As Integer
        Dim strSQL As String = STR_VACIO
        strSQL = "SELECT (YEAR(CURDATE())-YEAR(em_nacimiento))- (RIGHT(CURDATE(),5)<RIGHT(em_nacimiento,5)) AS EDAD"
        strSQL &= " FROM Empleados WHERE " & strCondicion
        Dim COM As MySqlCommand
        Try
            MyCnn.CONECTAR = strConexion
            If MyCnn.ProbarConexiones = True Then
                COM = New MySqlCommand(strSQL, CON)
                intEdad = CInt(COM.ExecuteScalar)
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        Return intEdad
    End Function

    Public Function SelecionarRepresentanteDefault() As Boolean
        SelecionarRepresentanteDefault = False
        Dim strSQL As String = STR_VACIO
        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader
        strSQL = "SELECT b.em_cedula,b.em_codigo, b.em_descripcion, b.em_sexo, b.em_civil, b.em_nacimiento, b.em_nacionalidad, " & _
            " b.em_dpi, b.em_municipio FROM Catalogos a LEFT JOIN Empleados b ON a.cat_pid = b.em_codigo WHERE ( " & _
            " cat_clave= 'Rep_Legal')"
        Try
            MyCnn.CONECTAR = strConexion
            If MyCnn.ProbarConexiones = True Then
                COM = New MySqlCommand(strSQL, CON)
                REA = COM.ExecuteReader
                REA.Read()
                Srepresentante.intIdRepresentante = REA.GetInt32("em_codigo")
                Srepresentante.strCivilR = REA.GetString("em_civil")
                ' Srepresentante.strDepartamento = REA.GetString("DDoc_Prd_Ref")
                ' Srepresentante.strDireccion = REA.GetString("DDoc_Prd_Des")
                Srepresentante.strMunicipio = REA.GetString("em_municipio")
                If REA.GetMySqlDateTime("em_nacimiento").IsValidDateTime Then
                    Srepresentante.fecNacimiento = REA.GetMySqlDateTime("em_nacimiento")
                Else
                    Srepresentante.fecNacimiento = New MySqlDateTime(2000, 1, 1, 0, 0, 0)
                End If
                'If REA.IsDBNull(REA.GetString("em_dpi")) = False Then
                Srepresentante.strDPI = REA.GetString("em_dpi").ToString
                ' Else
                'Srepresentante.strDPI = "DPI NO GUARDADO"
                ' End If
                Srepresentante.strNacionaliad = REA.GetString("em_nacionalidad")
                ' Srepresentante.strDPI = REA.GetString("em_nacionalidad")
                Srepresentante.strNombreR = REA.GetString("em_descripcion")
                Srepresentante.strSexo = REA.GetString("em_sexo")
                Srepresentante.strMunicipio = REA.GetString("em_municipio")
                Srepresentante.strCedula = REA.GetString("em_cedula")
                SelecionarRepresentanteDefault = True
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Function

#End Region

End Class
