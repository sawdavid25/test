﻿Public Class clsEmpleado

#Region "Miembros"
    Dim intIdEmpresa As Integer = NO_FILA
    Dim intEstado As Integer = INT_UNO
    Dim intIdEmpleado As Integer = NO_FILA
    Dim strNombre1 As String = STR_VACIO
    Dim strNombre2 As String = STR_VACIO
    Dim strNombre3 As String = STR_VACIO
    Dim strApellido1 As String = STR_VACIO
    Dim strApellido2 As String = STR_VACIO
    Dim strApellido3 As String = STR_VACIO
    Dim strDescripcion As String = STR_VACIO
    Dim strSexo As String = STR_VACIO
    Dim strEstadoCivil As String = STR_VACIO
    Dim strConyugue As String = STR_VACIO
    Dim dateFechaNacimiento As MySqlDateTime
    Dim strNacionalidad As String = STR_VACIO
    Dim strCedula As String = STR_VACIO
    Dim strDPI As String = STR_VACIO
    Dim strNit As String = STR_VACIO
    Dim strIgss As String = STR_VACIO
    Dim strIrtra As String = STR_VACIO
    Dim strDireccion As String = STR_VACIO
    Dim strMunicipio As String = STR_VACIO
    Dim strTelefono1 As String = STR_VACIO
    Dim strTelefono2 As String = STR_VACIO
    Dim strObservaciones As String = STR_VACIO
    Dim strCuenta1 As String = STR_VACIO
    Dim strCuenta2 As String = STR_VACIO
    Dim strCuenta3 As String = STR_VACIO
    Dim blobFoto As Byte = 0
    Dim strExtendidaEn As String = STR_VACIO
    Dim strDeposito As String = STR_VACIO
    Dim intCentroCosto As Integer = 0
#End Region

#Region "Propiedades"

    Public Property Depositos As String
        Get
            Return strDeposito
        End Get
        Set(value As String)
            strDeposito = value
        End Set
    End Property

    Public Property idEmpleado As Integer
        Get
            Return intIdEmpleado
        End Get
        Set(value As Integer)
            intIdEmpleado = value
        End Set
    End Property

    Public Property idEmpresa As Integer
        Get
            Return intIdEmpresa
        End Get
        Set(value As Integer)
            intIdEmpresa = value
        End Set
    End Property

    Public Property Estado As Integer
        Get
            Return intEstado
        End Get
        Set(value As Integer)
            intEstado = value
        End Set
    End Property

    Public Property Nombre1 As String
        Get
            Return strNombre1
        End Get
        Set(value As String)
            strNombre1 = value
        End Set
    End Property

    Public Property Nombre2 As String
        Get
            Return strNombre2
        End Get
        Set(value As String)
            strNombre2 = value
        End Set
    End Property
    Public Property Nombre3 As String
        Get
            Return strNombre3
        End Get
        Set(value As String)
            strNombre3 = value
        End Set
    End Property

    Public Property Apellido1 As String
        Get
            Return strApellido1
        End Get
        Set(value As String)
            strApellido1 = value
        End Set
    End Property

    Public Property Apellido2 As String
        Get
            Return strApellido2
        End Get
        Set(value As String)
            strApellido2 = value
        End Set
    End Property

    Public Property Apellido3 As String
        Get
            Return strApellido3
        End Get
        Set(value As String)
            strApellido3 = value
        End Set
    End Property

    Public Property Descripcion As String
        Get
            Return strDescripcion
        End Get
        Set(value As String)
            strDescripcion = value
        End Set
    End Property

    Public Property Sexo As String
        Get
            Return strSexo
        End Get
        Set(value As String)
            strSexo = value
        End Set
    End Property

    Public Property EstadoCivil As String
        Get
            Return strEstadoCivil
        End Get
        Set(value As String)
            strEstadoCivil = value
        End Set
    End Property

    Public Property Conyugue
        Get
            Return strConyugue
        End Get
        Set(value)
            strConyugue = value
        End Set
    End Property

    Public Property FechaNacimiento As MySqlDateTime
        Get
            Return dateFechaNacimiento
        End Get
        Set(value As MySqlDateTime)
            dateFechaNacimiento = value
        End Set
    End Property

    Public WriteOnly Property FechaNacimiento_Net As Date
        Set(value As Date)
            dateFechaNacimiento = New MySqlDateTime(value.Year, value.Month, value.Day, value.Hour, value.Minute, value.Second)
        End Set
    End Property

    Public Property Nacionalidad As String
        Get
            Return strNacionalidad
        End Get
        Set(value As String)
            strNacionalidad = value
        End Set
    End Property

    Public Property Cedula As String
        Get
            Return strCedula
        End Get
        Set(value As String)
            strCedula = value
        End Set
    End Property

    Public Property DPI As String
        Get
            Return strDPI
        End Get
        Set(value As String)
            strDPI = value
        End Set
    End Property

    Public Property Nit As String
        Get
            Return strNit
        End Get
        Set(value As String)
            strNit = value
        End Set
    End Property

    Public Property Igss As String
        Get
            Return strIgss
        End Get
        Set(value As String)
            strIgss = value
        End Set
    End Property

    Public Property Irtra As String
        Get
            Return strIrtra
        End Get
        Set(value As String)
            strIrtra = value
        End Set
    End Property

    Public Property Direccion As String
        Get
            Return strDireccion
        End Get
        Set(value As String)
            strDireccion = value
        End Set
    End Property

    Public Property Municipio As String
        Get
            Return strMunicipio
        End Get
        Set(value As String)
            strMunicipio = value
        End Set
    End Property

    Public Property Telefono1 As String
        Get
            Return strTelefono1
        End Get
        Set(value As String)
            strTelefono1 = value
        End Set
    End Property

    Public Property Telefono2 As String
        Get
            Return strTelefono2
        End Get
        Set(value As String)
            strTelefono2 = value
        End Set
    End Property

    Public Property Observaciones As String
        Get
            Return strObservaciones
        End Get
        Set(value As String)
            strObservaciones = value
        End Set
    End Property

    Public Property Cuenta1 As String
        Get
            Return strCuenta1
        End Get
        Set(value As String)
            strCuenta1 = value
        End Set
    End Property

    Public Property Cuenta2 As String
        Get
            Return strCuenta2
        End Get
        Set(value As String)
            strCuenta2 = value
        End Set
    End Property

    Public Property Cuenta3 As String
        Get
            Return strCuenta3
        End Get
        Set(value As String)
            strCuenta3 = value
        End Set
    End Property

    Public Property ExtendidaEn As String
        Get
            Return strExtendidaEn
        End Get
        Set(value As String)
            strExtendidaEn = value
        End Set
    End Property

    Public Property CentroCosto As Integer
        Get
            Return intCentroCosto
        End Get
        Set(value As Integer)
            intCentroCosto = value
        End Set
    End Property

#End Region

#Region "Fuciones"

    Public Sub New()
        intIdEmpresa = NO_FILA
        intEstado = INT_UNO
        intIdEmpleado = NO_FILA
        strNombre1 = STR_VACIO
        strNombre2 = STR_VACIO
        strNombre3 = STR_VACIO
        strApellido1 = STR_VACIO
        strApellido2 = STR_VACIO
        strApellido3 = STR_VACIO
        strDescripcion = STR_VACIO
        strSexo = STR_VACIO
        strEstadoCivil = STR_VACIO
        strConyugue = STR_VACIO
        dateFechaNacimiento = New MySqlDateTime(INT_CERO, INT_CERO, INT_CERO, INT_CERO, INT_CERO, INT_CERO)
        strNacionalidad = STR_VACIO
        strCedula = STR_VACIO
        strDPI = STR_VACIO
        strNit = STR_VACIO
        strIgss = STR_VACIO
        strIrtra = STR_VACIO
        strDireccion = STR_VACIO
        strMunicipio = STR_VACIO
        strTelefono1 = STR_VACIO
        strTelefono2 = STR_VACIO
        strObservaciones = STR_VACIO
        strCuenta1 = STR_VACIO
        strCuenta2 = STR_VACIO
        strCuenta3 = STR_VACIO
        blobFoto = INT_CERO
        strExtendidaEn = STR_VACIO
        strDeposito = STR_VACIO
        intCentroCosto = INT_CERO
    End Sub

    Public Sub New(ByVal nombre As String, ByVal id As Long)
        intIdEmpleado = id
        strDescripcion = nombre
    End Sub

    Private Function NuevoId() As Integer
        Dim idnuevo As Integer = -1
        Dim COM As MySqlCommand
        Dim strSQl As String = ""
        strSQl = "SELECT (IFNULL(MAX(em_codigo),0)+1) ID FROM Empleados WHERE em_empresa =" & Sesion.IdEmpresa
        Try
            MyCnn.CONECTAR = strConexion
            If MyCnn.ProbarConexiones = True Then
                COM = New MySqlCommand(strSQl, CON)
                idnuevo = CInt(COM.ExecuteScalar)
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        Return idnuevo
    End Function

    Public Function Guardar() As Boolean
        Guardar = False

        Dim strSQL As String = False
        Dim COM As MySqlCommand
        strDescripcion = strNombre1 & Space(1) & strNombre2 & Space(1) & strApellido1
        If strApellido3.Length > 0 Then
            strDescripcion &= " DE " & strApellido3.ToUpper
        Else
            strDescripcion &= Space(1) & strApellido2.ToUpper
        End If
        strSQL = "INSERT INTO Empleados(em_empresa,em_codigo ,em_nombre ,em_nombre2 ,em_nombre3 ,em_apellido , " & _
                  "em_apellido2 ,em_apellido3,em_descripcion ,em_sexo,em_civil ,em_conyuge ,em_nacimiento,em_nacionalidad , " & _
                  "em_cedula ,em_dpi ,em_nit ,em_extendido,em_igss ,em_irtra ,em_domicilio,em_municipio ,em_telefono1,em_telefono2 ," & _
                  "em_observaciones ,em_foto,em_estado ,em_cuenta1 ,em_cuenta2,em_cuenta3 ,em_deposito,em_costo) VALUES(?P1,?P2,?P3,?P4,?P5,?P6," & _
                  "?apellido2,?apellido3,?descripcion,?sexo,?civil,?conyugue,?fecha,?nacionalidad," & _
                  "?cedula,?dpi,?nit,?extendidaen,?igss,?irtra,?direccion,?municipio,?tel1,?tel2," & _
                  "?observaciones,?foto,?estado,?cuenta1,?cuenta2,?cuenta3,?deposito,?centrocosto)"
        Try
            MyCnn.CONECTAR = strConexion
            If MyCnn.ProbarConexiones = True Then
                COM = New MySqlCommand(strSQL, CON)
                COM.CommandType = CommandType.Text
                If intIdEmpresa = -1 Then
                    COM.Parameters.AddWithValue("?P1", DBNull.Value)
                Else
                    COM.Parameters.AddWithValue("?P1", intIdEmpresa)
                End If
                If intIdEmpleado = -1 Then
                    COM.Parameters.AddWithValue("?P2", NuevoId())
                Else
                    COM.Parameters.AddWithValue("?P2", intIdEmpleado)
                End If
                If strNombre1 = "" Then
                    COM.Parameters.AddWithValue("?P3", STR_RELLENO)
                Else
                    COM.Parameters.AddWithValue("?P3", strNombre1.ToUpper)
                End If
                If strNombre2 = "" Then
                    COM.Parameters.AddWithValue("?P4", STR_RELLENO)
                Else
                    COM.Parameters.AddWithValue("?P4", strNombre2.ToUpper)
                End If
                If strNombre3 = "" Then
                    COM.Parameters.AddWithValue("?P5", " ")
                Else
                    COM.Parameters.AddWithValue("?P5", strNombre3.ToUpper)
                End If
                If strApellido1 = "" Then
                    COM.Parameters.AddWithValue("?P6", STR_RELLENO)
                Else
                    COM.Parameters.AddWithValue("?P6", strApellido1.ToUpper)
                End If
                If strApellido2 = "" Then
                    COM.Parameters.AddWithValue("?apellido2", STR_RELLENO)
                Else
                    COM.Parameters.AddWithValue("?apellido2", strApellido2.ToUpper)
                End If
                If strApellido3 = "" Then
                    COM.Parameters.AddWithValue("?apellido3", " ")
                Else
                    COM.Parameters.AddWithValue("?apellido3", strApellido3.ToUpper)
                End If
                If strDescripcion = "" Then
                    COM.Parameters.AddWithValue("?descripcion", STR_RELLENO)
                Else
                    COM.Parameters.AddWithValue("?descripcion", strDescripcion.ToUpper)
                End If
                If strSexo = "" Then
                    COM.Parameters.AddWithValue("?sexo", STR_RELLENO)
                Else
                    COM.Parameters.AddWithValue("?sexo", strSexo.ToUpper)
                End If
                If strEstadoCivil = "" Then
                    COM.Parameters.AddWithValue("?civil", STR_RELLENO)
                Else
                    COM.Parameters.AddWithValue("?civil", strEstadoCivil.ToUpper)
                End If
                If strConyugue = "" Then
                    COM.Parameters.AddWithValue("?conyugue", " ")
                Else
                    COM.Parameters.AddWithValue("?conyugue", strConyugue.ToUpper)
                End If
                If dateFechaNacimiento.IsValidDateTime = False Then
                    COM.Parameters.AddWithValue("?fecha", STR_RELLENO)
                Else
                    COM.Parameters.AddWithValue("?fecha", dateFechaNacimiento.Value)
                End If
                If strNacionalidad = "" Then
                    COM.Parameters.AddWithValue("?nacionalidad", STR_RELLENO)
                Else
                    COM.Parameters.AddWithValue("?nacionalidad", strNacionalidad.ToUpper)
                End If
                If strCedula = "" Then
                    COM.Parameters.AddWithValue("?cedula", STR_RELLENO)
                Else
                    COM.Parameters.AddWithValue("?cedula", strCedula.ToUpper)
                End If
                If strDPI = "" Then
                    COM.Parameters.AddWithValue("?dpi", STR_RELLENO)
                Else
                    COM.Parameters.AddWithValue("?dpi", strDPI)
                End If
                If strNit = "" Then
                    COM.Parameters.AddWithValue("?nit", STR_RELLENO)
                Else
                    COM.Parameters.AddWithValue("?nit", strNit)
                End If
                If strIgss = "" Then
                    COM.Parameters.AddWithValue("?igss", STR_RELLENO)
                Else
                    COM.Parameters.AddWithValue("?igss", strIgss)
                End If
                If strIrtra = "" Then
                    COM.Parameters.AddWithValue("?irtra", STR_RELLENO)
                Else
                    COM.Parameters.AddWithValue("?irtra", strIrtra)
                End If
                If strDireccion = "" Then
                    COM.Parameters.AddWithValue("?direccion", STR_RELLENO)
                Else
                    COM.Parameters.AddWithValue("?direccion", strDireccion)
                End If
                If strMunicipio = "" Then
                    COM.Parameters.AddWithValue("?municipio", STR_RELLENO)
                Else
                    COM.Parameters.AddWithValue("?municipio", strMunicipio)
                End If
                If strTelefono1 = "" Then
                    COM.Parameters.AddWithValue("?tel1", STR_RELLENO)
                Else
                    COM.Parameters.AddWithValue("?tel1", strTelefono1)
                End If
                If strTelefono2 = "" Then
                    COM.Parameters.AddWithValue("?tel2", STR_RELLENO)
                Else
                    COM.Parameters.AddWithValue("?tel2", strTelefono2)
                End If
                If strObservaciones = "" Then
                    COM.Parameters.AddWithValue("?observaciones", STR_RELLENO)
                Else
                    COM.Parameters.AddWithValue("?observaciones", strObservaciones)
                End If
                If strCuenta1 = "" Then
                    COM.Parameters.AddWithValue("?cuenta1", STR_VACIO)
                Else
                    COM.Parameters.AddWithValue("?cuenta1", strCuenta1)
                End If
                If strCuenta2 = STR_VACIO Then
                    COM.Parameters.AddWithValue("?cuenta2", STR_VACIO)
                Else
                    COM.Parameters.AddWithValue("?cuenta2", strCuenta2)
                End If
                If strCuenta3 = STR_VACIO Then
                    COM.Parameters.AddWithValue("?cuenta3", STR_VACIO)
                Else
                    COM.Parameters.AddWithValue("?cuenta3", strCuenta3)
                End If
                If strExtendidaEn = STR_VACIO Then
                    COM.Parameters.AddWithValue("?extendidaen", STR_VACIO)
                Else
                    COM.Parameters.AddWithValue("?extendidaen", strExtendidaEn)
                End If
                If strDeposito = STR_VACIO Then
                    COM.Parameters.AddWithValue("?deposito", STR_VACIO)
                Else
                    COM.Parameters.AddWithValue("?deposito", strDeposito)
                End If

                If intCentroCosto = NO_FILA Then
                    COM.Parameters.AddWithValue("?centrocosto", DBNull.Value)
                Else
                    COM.Parameters.AddWithValue("?centrocosto", intCentroCosto)
                End If

                COM.Parameters.AddWithValue("?estado", INT_UNO)
                COM.Parameters.AddWithValue("?foto", DBNull.Value)
                COM.ExecuteNonQuery()
                COM.Dispose()
                COM = Nothing
                cFunciones.EscribirRegistro("Empleados", clsFunciones.AccEnum.acAdd, intIdEmpleado)
                Guardar = True
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Function

    Public Function Actualizar() As Boolean
        Actualizar = False
        Dim strCondicion As String = STR_VACIO
        Dim strSQL As String = STR_VACIO
        Dim COM As MySqlCommand
        strDescripcion = strNombre1 & Space(1) & strNombre2 & Space(1) & strApellido1
        If strApellido3.Length > 0 Then
            strDescripcion &= " DE " & strApellido3.ToUpper
        Else
            strDescripcion &= Space(1) & strApellido2.ToUpper
        End If
        strCondicion = " em_empresa = ?P1 AND em_Codigo = ?P2"
        strSQL = "UPDATE Empleados SET "
        strSQL &= "em_empresa=?P1,em_codigo=?P2,em_nombre=?P3,em_nombre2=?P4,em_nombre3=?P5,em_apellido=?P6," & _
            "em_apellido2=?apellido2,em_apellido3=?apellido3,em_descripcion=?descripcion," & _
            "em_sexo=?sexo,em_civil=?civil,em_conyuge=?conyugue,em_nacimiento=?fecha," & _
            "em_nacionalidad=?nacionalidad,em_cedula=?cedula,em_dpi=?dpi,em_nit=?nit,em_igss=?igss," & _
            "em_irtra=?irtra,em_domicilio=?direccion,em_municipio=?municipio,em_telefono1=?tel1," & _
            "em_telefono2=?tel2,em_observaciones=?observaciones,em_foto=?foto,em_estado=?estado," & _
            "em_cuenta1=?cuenta1,em_cuenta2=?cuenta2,em_cuenta3=?cuenta3,em_extendido= ?extendidaen,em_deposito = ?deposito,em_costo = ?centrocosto "
        strSQL &= " WHERE " & strCondicion
        Try
            MyCnn.CONECTAR = strConexion
            If MyCnn.ProbarConexiones = True Then
                COM = New MySqlCommand(strSQL, CON)
                COM.CommandType = CommandType.Text
                If intIdEmpresa = -1 Then
                    COM.Parameters.AddWithValue("?P1", DBNull.Value)
                Else
                    COM.Parameters.AddWithValue("?P1", intIdEmpresa)
                End If
                If intIdEmpleado = -1 Then
                    COM.Parameters.AddWithValue("?P2", idEmpleado)
                Else
                    COM.Parameters.AddWithValue("?P2", intIdEmpleado)
                End If
                If strNombre1 = "" Then
                    COM.Parameters.AddWithValue("?P3", STR_RELLENO)
                Else
                    COM.Parameters.AddWithValue("?P3", strNombre1.ToUpper)
                End If
                If strNombre2 = "" Then
                    COM.Parameters.AddWithValue("?P4", STR_RELLENO)
                Else
                    COM.Parameters.AddWithValue("?P4", strNombre2.ToUpper)
                End If
                If strNombre3 = "" Then
                    COM.Parameters.AddWithValue("?P5", " ")
                Else
                    COM.Parameters.AddWithValue("?P5", strNombre3.ToUpper)
                End If
                If strApellido1 = "" Then
                    COM.Parameters.AddWithValue("?P6", STR_RELLENO)
                Else
                    COM.Parameters.AddWithValue("?P6", strApellido1.ToUpper)
                End If
                If strApellido2 = "" Then
                    COM.Parameters.AddWithValue("?apellido2", STR_RELLENO)
                Else
                    COM.Parameters.AddWithValue("?apellido2", strApellido2.ToUpper)
                End If
                If strApellido3 = "" Then
                    COM.Parameters.AddWithValue("?apellido3", " ")
                Else
                    COM.Parameters.AddWithValue("?apellido3", strApellido3.ToUpper)
                End If
                If strDescripcion = "" Then
                    COM.Parameters.AddWithValue("?descripcion", STR_RELLENO)
                Else
                    COM.Parameters.AddWithValue("?descripcion", strDescripcion.ToUpper)
                End If
                If strSexo = "" Then
                    COM.Parameters.AddWithValue("?sexo", STR_RELLENO)
                Else
                    COM.Parameters.AddWithValue("?sexo", strSexo.ToUpper)
                End If
                If strEstadoCivil = "" Then
                    COM.Parameters.AddWithValue("?civil", STR_RELLENO)
                Else
                    COM.Parameters.AddWithValue("?civil", strEstadoCivil.ToUpper)
                End If
                If strConyugue = "" Then
                    COM.Parameters.AddWithValue("?conyugue", " ")
                Else
                    COM.Parameters.AddWithValue("?conyugue", strConyugue.ToUpper)
                End If
                If dateFechaNacimiento.IsValidDateTime = False Then
                    COM.Parameters.AddWithValue("?fecha", STR_RELLENO)
                Else
                    COM.Parameters.AddWithValue("?fecha", dateFechaNacimiento.Value)
                End If
                If strNacionalidad = "" Then
                    COM.Parameters.AddWithValue("?nacionalidad", STR_RELLENO)
                Else
                    COM.Parameters.AddWithValue("?nacionalidad", strNacionalidad.ToUpper)
                End If
                If strCedula = "" Then
                    COM.Parameters.AddWithValue("?cedula", STR_RELLENO)
                Else
                    COM.Parameters.AddWithValue("?cedula", strCedula.ToUpper)
                End If
                If strDPI = "" Then
                    COM.Parameters.AddWithValue("?dpi", STR_RELLENO)
                Else
                    COM.Parameters.AddWithValue("?dpi", strDPI)
                End If
                If strNit = "" Then
                    COM.Parameters.AddWithValue("?nit", STR_RELLENO)
                Else
                    COM.Parameters.AddWithValue("?nit", strNit)
                End If
                If strIgss = "" Then
                    COM.Parameters.AddWithValue("?igss", STR_RELLENO)
                Else
                    COM.Parameters.AddWithValue("?igss", strIgss)
                End If
                If strIrtra = "" Then
                    COM.Parameters.AddWithValue("?irtra", STR_RELLENO)
                Else
                    COM.Parameters.AddWithValue("?irtra", strIrtra)
                End If
                If strDireccion = "" Then
                    COM.Parameters.AddWithValue("?direccion", STR_RELLENO)
                Else
                    COM.Parameters.AddWithValue("?direccion", strDireccion)
                End If
                If strMunicipio = "" Then
                    COM.Parameters.AddWithValue("?municipio", STR_RELLENO)
                Else
                    COM.Parameters.AddWithValue("?municipio", strMunicipio)
                End If
                If strTelefono1 = "" Then
                    COM.Parameters.AddWithValue("?tel1", STR_RELLENO)
                Else
                    COM.Parameters.AddWithValue("?tel1", strTelefono1)
                End If
                If strTelefono2 = "" Then
                    COM.Parameters.AddWithValue("?tel2", STR_RELLENO)
                Else
                    COM.Parameters.AddWithValue("?tel2", strTelefono2)
                End If
                If strObservaciones = "" Then
                    COM.Parameters.AddWithValue("?observaciones", STR_RELLENO)
                Else
                    COM.Parameters.AddWithValue("?observaciones", strObservaciones)
                End If
                If strCuenta1 = "" Then
                    COM.Parameters.AddWithValue("?cuenta1", STR_VACIO)
                Else
                    COM.Parameters.AddWithValue("?cuenta1", strCuenta1)
                End If
                If strCuenta2 = STR_VACIO Then
                    COM.Parameters.AddWithValue("?cuenta2", STR_VACIO)
                Else
                    COM.Parameters.AddWithValue("?cuenta2", strCuenta2)
                End If
                If strCuenta3 = STR_VACIO Then
                    COM.Parameters.AddWithValue("?cuenta3", STR_VACIO)
                Else
                    COM.Parameters.AddWithValue("?cuenta3", strCuenta3)
                End If
                If strExtendidaEn = STR_VACIO Then
                    COM.Parameters.AddWithValue("?extendidaen", STR_VACIO)
                Else
                    COM.Parameters.AddWithValue("?extendidaen", strExtendidaEn)
                End If
                If strDeposito = STR_VACIO Then
                    COM.Parameters.AddWithValue("?deposito", STR_VACIO)
                Else
                    COM.Parameters.AddWithValue("?deposito", strDeposito)
                End If

                If intCentroCosto = NO_FILA Then
                    COM.Parameters.AddWithValue("?centrocosto", DBNull.Value)
                Else
                    COM.Parameters.AddWithValue("?centrocosto", intCentroCosto)
                End If


                COM.Parameters.AddWithValue("?estado", Estado)
                COM.Parameters.AddWithValue("?foto", DBNull.Value)


                COM.ExecuteNonQuery()
                COM.Dispose()
                COM = Nothing
                cFunciones.EscribirRegistro("Empleados", clsFunciones.AccEnum.acCorrect, intIdEmpleado)
                Actualizar = True
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Function

    Public Function Seleccionar(ByVal strCampos As String, ByVal strCondicion As String) As Boolean
        Seleccionar = False
        Reset()
        Dim strSQL As String = ""
        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader
        Dim arrayCampos() As String
        strSQL = "SELECT " & strCampos & " FROM Empleados WHERE " & strCondicion & " LIMIT 1;"

        Try
            MyCnn.CONECTAR = strConexion
            If MyCnn.ProbarConexiones = True Then
                COM = New MySqlCommand(strSQL, CON)
                REA = COM.ExecuteReader
                REA.Read()
                If REA.HasRows = True Then
                    If strCampos = STR_ASTERISCO Then
                        intIdEmpresa = REA.GetInt32("em_empresa")
                        intIdEmpleado = REA.GetInt32("em_codigo")
                        strNombre1 = REA.GetString("em_nombre")
                        strNombre2 = REA.GetString("em_nombre2")
                        strNombre3 = REA.GetString("em_nombre3")
                        strApellido1 = REA.GetString("em_apellido")
                        strApellido2 = REA.GetString("em_apellido2")
                        strApellido3 = REA.GetString("em_apellido3")
                        strNacionalidad = REA.GetString("em_nacionalidad")
                        strDescripcion = REA.GetString("em_descripcion")
                        strSexo = REA.GetString("em_sexo")
                        strEstadoCivil = REA.GetString("em_civil")
                        strConyugue = REA.GetString("em_conyuge")
                        dateFechaNacimiento = REA.GetMySqlDateTime("em_nacimiento")
                        strCedula = REA.GetString("em_cedula")
                        strDPI = REA.GetString("em_dpi")
                        strNit = REA.GetString("em_nit")
                        strIgss = REA.GetString("em_igss")
                        strIrtra = REA.GetString("em_irtra")
                        strDireccion = REA.GetString("em_domicilio")
                        strMunicipio = REA.GetString("em_municipio")
                        strTelefono1 = REA.GetString("em_telefono1")
                        strTelefono2 = REA.GetString("em_telefono2")
                        strObservaciones = REA.GetString("em_observaciones")
                        intEstado = REA.GetString("em_estado")
                        strCuenta1 = REA.GetString("em_cuenta1")
                        strCuenta2 = REA.GetString("em_cuenta2")
                        strCuenta3 = REA.GetString("em_cuenta3")
                        strExtendidaEn = REA.GetString("em_extendido")
                        strDeposito = REA.GetString("em_deposito")
                        intCentroCosto = REA.GetInt32("em_costo")
                        If REA.GetMySqlDateTime("em_nacimiento").IsValidDateTime Then
                            dateFechaNacimiento = REA.GetMySqlDateTime("em_nacimiento")
                        End If
                    Else
                        arrayCampos = strCampos.Split(",".ToCharArray)
                        For i As Integer = 0 To arrayCampos.Length - 1
                            Select Case arrayCampos(i)
                                Case ("em_empresa")
                                    intIdEmpresa = REA.GetInt32("em_empresa")
                                Case ("em_codigo")
                                    intIdEmpleado = REA.GetInt32("em_codigo")
                                Case ("em_nombre")
                                    strNombre1 = REA.GetString("em_nombre")
                                Case ("em_nombre2")
                                    strNombre2 = REA.GetString("em_nombre2")
                                Case ("em_nombre3")
                                    strNombre3 = REA.GetString("em_nombre3")
                                Case ("em_apellido1")
                                    strApellido1 = REA.GetString("em_apellido1")
                                Case ("em_apellido2")
                                    strApellido2 = REA.GetString("em_apellido2")
                                Case ("em_apellido3")
                                    strApellido3 = REA.GetString("em_apellido3")
                                Case ("em_descripcion")
                                    strDescripcion = REA.GetString("em_descripcion")
                                Case ("em_sexo")
                                    strSexo = REA.GetString("em_sexo")
                                Case ("em_civil")
                                    strEstadoCivil = REA.GetString("em_civil")
                                Case ("em_conyuge")
                                    strConyugue = REA.GetString("em_conyuge")
                                Case ("em_nacimiento")
                                    If REA.GetMySqlDateTime("em_nacimiento").IsValidDateTime Then
                                        dateFechaNacimiento = REA.GetMySqlDateTime("em_nacimiento")
                                    Else
                                        dateFechaNacimiento = New MySqlDateTime(2000, 1, 1, 0, 0, 0)
                                    End If
                                Case ("em_cedula")
                                    strCedula = REA.GetString("em_cedula")
                                Case ("em_dpi")
                                    strDPI = REA.GetString("em_dpi")
                                Case ("em_nit")
                                    strNit = REA.GetString("em_nit")
                                Case ("em_igss")
                                    strIgss = REA.GetString("em_igss")
                                Case ("em_irtra")
                                    strIrtra = REA.GetString("em_irtra")
                                Case ("em_domicilio")
                                    strDireccion = REA.GetString("em_domicilio")
                                Case ("em_municipio")
                                    strMunicipio = REA.GetString("em_municipio")
                                Case ("em_telefono1")
                                    strTelefono1 = REA.GetString("em_telefono1")
                                Case ("em_telefono2")
                                    strTelefono2 = REA.GetString("em_telefono2")
                                Case ("em_observaciones")
                                    strObservaciones = REA.GetString("em_observaciones")
                                Case ("em_estado")
                                    intEstado = REA.GetString("em_estado")
                                Case ("em_cuenta1")
                                    strCuenta1 = REA.GetString("em_cuenta1")
                                Case ("em_cuenta2")
                                    strCuenta2 = REA.GetString("em_cuenta2")
                                Case ("em_cuenta3")
                                    strCuenta3 = REA.GetString("em_cuenta3")
                                Case ("em_deposito")
                                    strDeposito = REA.GetString("em_deposito")
                                Case ("em_costo")
                                    intCentroCosto = REA.GetInt32("em_costo")
                                Case ("em_extendido")
                                    strExtendidaEn = REA.GetString("em_extendido")
                            End Select
                        Next
                    End If
                    Seleccionar = True
                End If
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try

    End Function

    Public Function SeleccionarLista(ByVal strCampos As String, Optional ByVal strCondicion As String = "") As Boolean
        SeleccionarLista = False

    End Function

    Public Function Borrar() As Boolean
        Borrar = False
        Dim strSQL As String = STR_VACIO
        Dim COM As MySqlCommand
        strSQL = "DELETE Empleados WHERE em_codigo = {empleado} AND em_empresa = {empresa}"
        strSQL = Replace(strSQL, "{empleado}", intIdEmpleado)
        strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
        Try
            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSQL, CON)
            COM.ExecuteNonQuery()
            Borrar = True
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Function

#End Region

End Class
