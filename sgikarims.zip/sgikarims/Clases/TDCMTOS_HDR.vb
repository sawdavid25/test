NameSpace Tablas
Public Class TDCMTOS_HDR

#Region "Miembros"

	Public Enum TipoReset
		Full = 1
		Data = 2
	End Enum

	Public Structure DCMTOS_HDR
		Dim Simon_REGISTRO as Boolean
		Dim MERROR as String
		Dim HDOC_SIS_EMP	 As Integer
		Dim HDOC_DOC_CAT	 As Integer
		Dim HDOC_DOC_ANO	 As Integer
		Dim HDOC_DOC_NUM	 As Integer
		Dim HDOC_DOC_FEC	 As MYSQLDATETIME
		Dim HDOC_EMP_COD	 As Integer
		Dim HDOC_EMP_NOM	 As String
		Dim HDOC_EMP_DIR	 As Object
		Dim HDOC_EMP_PER	 As String
		Dim HDOC_EMP_TEL	 As String
		Dim HDOC_EMP_NIT	 As String
		Dim HDOC_DR1_CAT	 As Integer
		Dim HDOC_DR1_NUM	 As String
		Dim HDOC_DR1_DBL	 As Decimal
		Dim HDOC_DR1_FEC	 As MYSQLDATETIME
		Dim HDOC_DR1_EMP	 As Integer
		Dim HDOC_DR2_CAT	 As Integer
		Dim HDOC_DR2_NUM	 As String
		Dim HDOC_DR2_FEC	 As MYSQLDATETIME
		Dim HDOC_DR2_EMP	 As Integer
		Dim HDOC_RF1_NUM	 As Integer
		Dim HDOC_RF1_COD	 As String
		Dim HDOC_RF1_TXT	 As Object
		Dim HDOC_RF2_NUM	 As Integer
		Dim HDOC_RF2_COD	 As String
		Dim HDOC_RF2_TXT	 As Object
		Dim HDOC_USUARIO	 As String
		Dim HDOC_PRO_FEC	 As MYSQLDATETIME
		Dim HDOC_PRO_DCAT	 As Integer
		Dim HDOC_PRO_DANO	 As Integer
		Dim HDOC_PRO_DNUM	 As Integer
		Dim HDOC_DOC_TC	 As Decimal
		Dim HDOC_DOC_MON	 As Integer
		Dim HDOC_RF1_DBL	 As Decimal
		Dim HDOC_RF2_DBL	 As Decimal
		Dim HDOC_RF3_DBL	 As Decimal
		Dim HDOC_DOC_STATUS	 As Integer
	End Structure

	private m_int_HDoc_Sis_Emp As Integer
	private m_int_HDoc_Doc_Cat As Integer
	private m_int_HDoc_Doc_Ano As Integer
	private m_int_HDoc_Doc_Num As Integer
	private m_dt_HDoc_Doc_Fec As MYSQLDATETIME
	private m_int_HDoc_Emp_Cod As Integer
	private m_str_HDoc_Emp_Nom As String
	private m_obj_HDoc_Emp_Dir As Object
	private m_str_HDoc_Emp_Per As String
	private m_str_HDoc_Emp_Tel As String
	private m_str_HDoc_Emp_NIT As String
	private m_int_HDoc_DR1_Cat As Integer
	private m_str_HDoc_DR1_Num As String
	private m_dec_HDoc_DR1_Dbl As Decimal
	private m_dt_HDoc_DR1_Fec As MYSQLDATETIME
	private m_int_HDoc_DR1_Emp As Integer
	private m_int_HDoc_DR2_Cat As Integer
	private m_str_HDoc_DR2_Num As String
	private m_dt_HDoc_DR2_Fec As MYSQLDATETIME
	private m_int_HDoc_DR2_Emp As Integer
	private m_int_HDoc_RF1_Num As Integer
	private m_str_HDoc_RF1_Cod As String
	private m_obj_HDoc_RF1_Txt As Object
	private m_int_HDoc_RF2_Num As Integer
	private m_str_HDoc_RF2_Cod As String
	private m_obj_HDoc_RF2_Txt As Object
	private m_str_HDoc_Usuario As String
	private m_dt_HDoc_Pro_Fec As MYSQLDATETIME
	private m_int_HDoc_Pro_DCat As Integer
	private m_int_HDoc_Pro_DAno As Integer
	private m_int_HDoc_Pro_DNum As Integer
	private m_dec_HDoc_Doc_TC As Decimal
	private m_int_HDoc_Doc_Mon As Integer
	private m_dec_HDoc_RF1_Dbl As Decimal
	private m_dec_HDoc_RF2_Dbl As Decimal
	private m_dec_HDoc_RF3_Dbl As Decimal
	private m_int_HDoc_Doc_Status As Integer
	Private MENSAJE As String
	Private Cantidad_de_la_Clase As Integer = 0
	Private CON As MySqlConnection
	Private TRA As MySqlTransaction
	Private REA As MysqlDataReader
	Private CONstr As String
#End Region


#Region "Propiedades"

	Public Property HDOC_SIS_EMP() As Integer
	Get
		return m_int_HDoc_Sis_Emp
	End Get
	Set (ByVal Value As Integer)
		m_int_HDoc_Sis_Emp = Value 
	End Set
	End Property

	Public Property HDOC_DOC_CAT() As Integer
	Get
		return m_int_HDoc_Doc_Cat
	End Get
	Set (ByVal Value As Integer)
		m_int_HDoc_Doc_Cat = Value 
	End Set
	End Property

	Public Property HDOC_DOC_ANO() As Integer
	Get
		return m_int_HDoc_Doc_Ano
	End Get
	Set (ByVal Value As Integer)
		m_int_HDoc_Doc_Ano = Value 
	End Set
	End Property

	Public Property HDOC_DOC_NUM() As Integer
	Get
		return m_int_HDoc_Doc_Num
	End Get
	Set (ByVal Value As Integer)
		m_int_HDoc_Doc_Num = Value 
	End Set
	End Property

	Public Property HDOC_DOC_FEC() As MYSQLDATETIME
	Get
		return m_dt_HDoc_Doc_Fec
	End Get
	Set (ByVal Value As MYSQLDATETIME)
		m_dt_HDoc_Doc_Fec = Value 
	End Set
	End Property

	Public WriteOnly Property HDoc_Doc_Fec_NET() As DateTime
	Set (ByVal Value As DateTime)
		m_dt_HDoc_Doc_Fec = new MySQLDATETIME(Value.Year, Value.Month, Value.Day, Value.Hour, Value.Minute, Value.Second) 
	End Set
	End Property

	Public Property HDOC_EMP_COD() As Integer
	Get
		return m_int_HDoc_Emp_Cod
	End Get
	Set (ByVal Value As Integer)
		m_int_HDoc_Emp_Cod = Value 
	End Set
	End Property

	Public Property HDOC_EMP_NOM() As String
	Get
		return m_str_HDoc_Emp_Nom.Trim()
	End Get
	Set (ByVal Value As String)
		m_str_HDoc_Emp_Nom = Value 
	End Set
	End Property

	Public Property HDOC_EMP_DIR() As Object
	Get
		return m_obj_HDoc_Emp_Dir
	End Get
	Set (ByVal Value As Object)
		m_obj_HDoc_Emp_Dir = Value 
	End Set
	End Property

	Public Property HDOC_EMP_PER() As String
	Get
		return m_str_HDoc_Emp_Per.Trim()
	End Get
	Set (ByVal Value As String)
		m_str_HDoc_Emp_Per = Value 
	End Set
	End Property

	Public Property HDOC_EMP_TEL() As String
	Get
		return m_str_HDoc_Emp_Tel.Trim()
	End Get
	Set (ByVal Value As String)
		m_str_HDoc_Emp_Tel = Value 
	End Set
	End Property

	Public Property HDOC_EMP_NIT() As String
	Get
		return m_str_HDoc_Emp_NIT.Trim()
	End Get
	Set (ByVal Value As String)
		m_str_HDoc_Emp_NIT = Value 
	End Set
	End Property

	Public Property HDOC_DR1_CAT() As Integer
	Get
		return m_int_HDoc_DR1_Cat
	End Get
	Set (ByVal Value As Integer)
		m_int_HDoc_DR1_Cat = Value 
	End Set
	End Property

	Public Property HDOC_DR1_NUM() As String
	Get
		return m_str_HDoc_DR1_Num.Trim()
	End Get
	Set (ByVal Value As String)
		m_str_HDoc_DR1_Num = Value 
	End Set
	End Property

	Public Property HDOC_DR1_DBL() As Decimal
	Get
		return m_dec_HDoc_DR1_Dbl
	End Get
	Set (ByVal Value As Decimal)
		m_dec_HDoc_DR1_Dbl = Value 
	End Set
	End Property

	Public Property HDOC_DR1_FEC() As MYSQLDATETIME
	Get
		return m_dt_HDoc_DR1_Fec
	End Get
	Set (ByVal Value As MYSQLDATETIME)
		m_dt_HDoc_DR1_Fec = Value 
	End Set
	End Property

	Public WriteOnly Property HDoc_DR1_Fec_NET() As DateTime
	Set (ByVal Value As DateTime)
		m_dt_HDoc_DR1_Fec = new MySQLDATETIME(Value.Year, Value.Month, Value.Day, Value.Hour, Value.Minute, Value.Second) 
	End Set
	End Property

	Public Property HDOC_DR1_EMP() As Integer
	Get
		return m_int_HDoc_DR1_Emp
	End Get
	Set (ByVal Value As Integer)
		m_int_HDoc_DR1_Emp = Value 
	End Set
	End Property

	Public Property HDOC_DR2_CAT() As Integer
	Get
		return m_int_HDoc_DR2_Cat
	End Get
	Set (ByVal Value As Integer)
		m_int_HDoc_DR2_Cat = Value 
	End Set
	End Property

	Public Property HDOC_DR2_NUM() As String
	Get
		return m_str_HDoc_DR2_Num.Trim()
	End Get
	Set (ByVal Value As String)
		m_str_HDoc_DR2_Num = Value 
	End Set
	End Property

	Public Property HDOC_DR2_FEC() As MYSQLDATETIME
	Get
		return m_dt_HDoc_DR2_Fec
	End Get
	Set (ByVal Value As MYSQLDATETIME)
		m_dt_HDoc_DR2_Fec = Value 
	End Set
	End Property

	Public WriteOnly Property HDoc_DR2_Fec_NET() As DateTime
	Set (ByVal Value As DateTime)
		m_dt_HDoc_DR2_Fec = new MySQLDATETIME(Value.Year, Value.Month, Value.Day, Value.Hour, Value.Minute, Value.Second) 
	End Set
	End Property

	Public Property HDOC_DR2_EMP() As Integer
	Get
		return m_int_HDoc_DR2_Emp
	End Get
	Set (ByVal Value As Integer)
		m_int_HDoc_DR2_Emp = Value 
	End Set
	End Property

	Public Property HDOC_RF1_NUM() As Integer
	Get
		return m_int_HDoc_RF1_Num
	End Get
	Set (ByVal Value As Integer)
		m_int_HDoc_RF1_Num = Value 
	End Set
	End Property

	Public Property HDOC_RF1_COD() As String
	Get
		return m_str_HDoc_RF1_Cod.Trim()
	End Get
	Set (ByVal Value As String)
		m_str_HDoc_RF1_Cod = Value 
	End Set
	End Property

	Public Property HDOC_RF1_TXT() As Object
	Get
		return m_obj_HDoc_RF1_Txt
	End Get
	Set (ByVal Value As Object)
		m_obj_HDoc_RF1_Txt = Value 
	End Set
	End Property

	Public Property HDOC_RF2_NUM() As Integer
	Get
		return m_int_HDoc_RF2_Num
	End Get
	Set (ByVal Value As Integer)
		m_int_HDoc_RF2_Num = Value 
	End Set
	End Property

	Public Property HDOC_RF2_COD() As String
	Get
		return m_str_HDoc_RF2_Cod.Trim()
	End Get
	Set (ByVal Value As String)
		m_str_HDoc_RF2_Cod = Value 
	End Set
	End Property

	Public Property HDOC_RF2_TXT() As Object
	Get
		return m_obj_HDoc_RF2_Txt
	End Get
	Set (ByVal Value As Object)
		m_obj_HDoc_RF2_Txt = Value 
	End Set
	End Property

	Public Property HDOC_USUARIO() As String
	Get
		return m_str_HDoc_Usuario.Trim()
	End Get
	Set (ByVal Value As String)
		m_str_HDoc_Usuario = Value 
	End Set
	End Property

	Public Property HDOC_PRO_FEC() As MYSQLDATETIME
	Get
		return m_dt_HDoc_Pro_Fec
	End Get
	Set (ByVal Value As MYSQLDATETIME)
		m_dt_HDoc_Pro_Fec = Value 
	End Set
	End Property

	Public WriteOnly Property HDoc_Pro_Fec_NET() As DateTime
	Set (ByVal Value As DateTime)
		m_dt_HDoc_Pro_Fec = new MySQLDATETIME(Value.Year, Value.Month, Value.Day, Value.Hour, Value.Minute, Value.Second) 
	End Set
	End Property

	Public Property HDOC_PRO_DCAT() As Integer
	Get
		return m_int_HDoc_Pro_DCat
	End Get
	Set (ByVal Value As Integer)
		m_int_HDoc_Pro_DCat = Value 
	End Set
	End Property

	Public Property HDOC_PRO_DANO() As Integer
	Get
		return m_int_HDoc_Pro_DAno
	End Get
	Set (ByVal Value As Integer)
		m_int_HDoc_Pro_DAno = Value 
	End Set
	End Property

	Public Property HDOC_PRO_DNUM() As Integer
	Get
		return m_int_HDoc_Pro_DNum
	End Get
	Set (ByVal Value As Integer)
		m_int_HDoc_Pro_DNum = Value 
	End Set
	End Property

	Public Property HDOC_DOC_TC() As Decimal
	Get
		return m_dec_HDoc_Doc_TC
	End Get
	Set (ByVal Value As Decimal)
		m_dec_HDoc_Doc_TC = Value 
	End Set
	End Property

	Public Property HDOC_DOC_MON() As Integer
	Get
		return m_int_HDoc_Doc_Mon
	End Get
	Set (ByVal Value As Integer)
		m_int_HDoc_Doc_Mon = Value 
	End Set
	End Property

	Public Property HDOC_RF1_DBL() As Decimal
	Get
		return m_dec_HDoc_RF1_Dbl
	End Get
	Set (ByVal Value As Decimal)
		m_dec_HDoc_RF1_Dbl = Value 
	End Set
	End Property

	Public Property HDOC_RF2_DBL() As Decimal
	Get
		return m_dec_HDoc_RF2_Dbl
	End Get
	Set (ByVal Value As Decimal)
		m_dec_HDoc_RF2_Dbl = Value 
	End Set
	End Property

	Public Property HDOC_RF3_DBL() As Decimal
	Get
		return m_dec_HDoc_RF3_Dbl
	End Get
	Set (ByVal Value As Decimal)
		m_dec_HDoc_RF3_Dbl = Value 
	End Set
	End Property

	Public Property HDOC_DOC_STATUS() As Integer
	Get
		return m_int_HDoc_Doc_Status
	End Get
	Set (ByVal Value As Integer)
		m_int_HDoc_Doc_Status = Value 
	End Set
	End Property

	Public ReadOnly Property CantRecorSet() as Integer
		Get
			Return Cantidad_de_la_Clase
		End Get
	End Property

	Public Property 	CONEXION()	 As String
		Set (ByVal VALUE as string)
			CONstr = VALUE
			Try
				MENSAJE = ""
				If isnothing(CON) = true then
					CON = new MySqlConnection
				End If
				If CON.State = ConnectionState.Open then
					CON.Close()
				End If
				CON.ConnectionString = CONstr
				CON.Open()
			Catch MyEX as MySqlException
				MENSAJE = "BiblioTABLAS - TDCMTOS_HDR - CONEXION MyError=" & MyEX.ToString
			Catch EX as Exception
				MENSAJE = "BiblioTABLAS - TDCMTOS_HDR - CONEXION Error=" & EX.ToString
			End Try
		End Set
		Get
			Return CONstr
		End Get
	End Property

	Public WriteOnly Property 	TRANSACCION()	 As MySqlTransaction
	Set (ByVal VALUE as MySqlTransaction)
		TRA = VALUE
	End Set
	End Property

	Public ReadOnly Property 	MERROR()	 As String
		Get
			Return MENSAJE
		End Get
	End Property

#End Region


#Region "Funciones Publicas"

	Public Sub New()
		HDOC_SIS_EMP = 0
		HDOC_DOC_CAT = 0
		HDOC_DOC_ANO = 0
		HDOC_DOC_NUM = 0
		HDOC_DOC_FEC = New MySqlDateTime(0, 0, 0, 0, 0, 0)
		HDOC_EMP_COD = 0
		HDOC_EMP_NOM = ""
		HDOC_EMP_DIR = ""
		HDOC_EMP_PER = ""
		HDOC_EMP_TEL = ""
		HDOC_EMP_NIT = ""
		HDOC_DR1_CAT = 0
		HDOC_DR1_NUM = ""
		HDOC_DR1_DBL = 0
		HDOC_DR1_FEC = New MySqlDateTime(0, 0, 0, 0, 0, 0)
		HDOC_DR1_EMP = 0
		HDOC_DR2_CAT = 0
		HDOC_DR2_NUM = ""
		HDOC_DR2_FEC = New MySqlDateTime(0, 0, 0, 0, 0, 0)
		HDOC_DR2_EMP = 0
		HDOC_RF1_NUM = 0
		HDOC_RF1_COD = ""
		HDOC_RF1_TXT = ""
		HDOC_RF2_NUM = 0
		HDOC_RF2_COD = ""
		HDOC_RF2_TXT = ""
		HDOC_USUARIO = ""
		HDOC_PRO_FEC = New MySqlDateTime(0, 0, 0, 0, 0, 0)
		HDOC_PRO_DCAT = 0
		HDOC_PRO_DANO = 0
		HDOC_PRO_DNUM = 0
		HDOC_DOC_TC = 0
		HDOC_DOC_MON = 0
		HDOC_RF1_DBL = 0
		HDOC_RF2_DBL = 0
		HDOC_RF3_DBL = 0
		HDOC_DOC_STATUS = 0
	End Sub

	Public Sub Reset(Optional ByVal Tipo as TipoReset = TipoReset.Data)
		Try
			INIT_LLAVE()
			INIT()
			If Tipo = TDCMTOS_HDR.TipoReset.Full Then
				Dispose()
			End If
		Catch Ex as Exception
			MENSAJE = "BiblioTABLAS - TDCMTOS_HDR - RESET No se podo hacer el Reset de la Clase" & Ex.ToString
		End Try
	End Sub

	Public Sub Dispose()
		Try
			If IsNothing(REA) = False then
				Rea.Close
			End If
			If isnothing(CON) = False Then
				if CON.State = ConnectionState.Open then
					CON.Close()
				End If
			End If
			CON = Nothing
			REA = Nothing
		Catch EX as Exception
		End Try
	End Sub

	Private Sub INIT()
		HDOC_DOC_FEC = New MySqlDateTime(0, 0, 0, 0, 0, 0)
		HDOC_EMP_COD = 0
		HDOC_EMP_NOM = ""
		HDOC_EMP_DIR = ""
		HDOC_EMP_PER = ""
		HDOC_EMP_TEL = ""
		HDOC_EMP_NIT = ""
		HDOC_DR1_CAT = 0
		HDOC_DR1_NUM = ""
		HDOC_DR1_DBL = 0
		HDOC_DR1_FEC = New MySqlDateTime(0, 0, 0, 0, 0, 0)
		HDOC_DR1_EMP = 0
		HDOC_DR2_CAT = 0
		HDOC_DR2_NUM = ""
		HDOC_DR2_FEC = New MySqlDateTime(0, 0, 0, 0, 0, 0)
		HDOC_DR2_EMP = 0
		HDOC_RF1_NUM = 0
		HDOC_RF1_COD = ""
		HDOC_RF1_TXT = ""
		HDOC_RF2_NUM = 0
		HDOC_RF2_COD = ""
		HDOC_RF2_TXT = ""
		HDOC_USUARIO = ""
		HDOC_PRO_FEC = New MySqlDateTime(0, 0, 0, 0, 0, 0)
		HDOC_PRO_DCAT = 0
		HDOC_PRO_DANO = 0
		HDOC_PRO_DNUM = 0
		HDOC_DOC_TC = 0
		HDOC_DOC_MON = 0
		HDOC_RF1_DBL = 0
		HDOC_RF2_DBL = 0
		HDOC_RF3_DBL = 0
		HDOC_DOC_STATUS = 0
		Cantidad_de_la_Clase = 0
	End Sub

	Private Sub INIT_LLAVE()
		HDOC_SIS_EMP = 0
		HDOC_DOC_CAT = 0
		HDOC_DOC_ANO = 0
		HDOC_DOC_NUM = 0
	End Sub

Public Function PMOVE_NEXT() As Boolean

	PMOVE_NEXT = False
	INIT()
	INIT_LLAVE()
	If IsNothing(REA) = True Then
		MENSAJE = "BiblioTABLAS - TDCMTOS_HDR - PMOVE_NEXT Conexi�n no definida"
		Exit Function
	End If
	Try
		If REA.Read = True Then
			If REA.IsDBNull(REA.GetOrdinal("HDoc_Sis_Emp")) = False Then
				M_INT_HDOC_SIS_EMP = REA.GetInt32("HDoc_Sis_Emp")
			Else
				M_INT_HDOC_SIS_EMP = -1
			End If
			If REA.IsDBNull(REA.GetOrdinal("HDoc_Doc_Cat")) = False Then
				M_INT_HDOC_DOC_CAT = REA.GetInt32("HDoc_Doc_Cat")
			Else
				M_INT_HDOC_DOC_CAT = -1
			End If
			If REA.IsDBNull(REA.GetOrdinal("HDoc_Doc_Ano")) = False Then
				M_INT_HDOC_DOC_ANO = REA.GetInt32("HDoc_Doc_Ano")
			Else
				M_INT_HDOC_DOC_ANO = -1
			End If
			If REA.IsDBNull(REA.GetOrdinal("HDoc_Doc_Num")) = False Then
				M_INT_HDOC_DOC_NUM = REA.GetInt32("HDoc_Doc_Num")
			Else
				M_INT_HDOC_DOC_NUM = -1
			End If
			If REA.IsDBNull(REA.GetOrdinal("HDoc_Doc_Fec")) = False Then
				M_DT_HDOC_DOC_FEC = REA.GetMySQLDateTime("HDoc_Doc_Fec")
			End If
			If REA.IsDBNull(REA.GetOrdinal("HDoc_Emp_Cod")) = False Then
				M_INT_HDOC_EMP_COD = REA.GetInt32("HDoc_Emp_Cod")
			Else
				M_INT_HDOC_EMP_COD = -1
			End If
			If REA.IsDBNull(REA.GetOrdinal("HDoc_Emp_Nom")) = False Then
				M_STR_HDOC_EMP_NOM = REA.GetString("HDoc_Emp_Nom")
			Else
				M_STR_HDOC_EMP_NOM = "NULL"
			End If
			If REA.IsDBNull(REA.GetOrdinal("HDoc_Emp_Dir")) = False Then
				M_OBJ_HDOC_EMP_DIR = REA.GetString("HDoc_Emp_Dir")
			End If
			If REA.IsDBNull(REA.GetOrdinal("HDoc_Emp_Per")) = False Then
				M_STR_HDOC_EMP_PER = REA.GetString("HDoc_Emp_Per")
			Else
				M_STR_HDOC_EMP_PER = "NULL"
			End If
			If REA.IsDBNull(REA.GetOrdinal("HDoc_Emp_Tel")) = False Then
				M_STR_HDOC_EMP_TEL = REA.GetString("HDoc_Emp_Tel")
			Else
				M_STR_HDOC_EMP_TEL = "NULL"
			End If
			If REA.IsDBNull(REA.GetOrdinal("HDoc_Emp_NIT")) = False Then
				M_STR_HDOC_EMP_NIT = REA.GetString("HDoc_Emp_NIT")
			Else
				M_STR_HDOC_EMP_NIT = "NULL"
			End If
			If REA.IsDBNull(REA.GetOrdinal("HDoc_DR1_Cat")) = False Then
				M_INT_HDOC_DR1_CAT = REA.GetInt32("HDoc_DR1_Cat")
			Else
				M_INT_HDOC_DR1_CAT = -1
			End If
			If REA.IsDBNull(REA.GetOrdinal("HDoc_DR1_Num")) = False Then
				M_STR_HDOC_DR1_NUM = REA.GetString("HDoc_DR1_Num")
			Else
				M_STR_HDOC_DR1_NUM = "NULL"
			End If
			If REA.IsDBNull(REA.GetOrdinal("HDoc_DR1_Dbl")) = False Then
				M_DEC_HDOC_DR1_DBL = REA.GetDecimal("HDoc_DR1_Dbl")
			End If
			If REA.IsDBNull(REA.GetOrdinal("HDoc_DR1_Fec")) = False Then
				M_DT_HDOC_DR1_FEC = REA.GetMySQLDateTime("HDoc_DR1_Fec")
			End If
			If REA.IsDBNull(REA.GetOrdinal("HDoc_DR1_Emp")) = False Then
				M_INT_HDOC_DR1_EMP = REA.GetInt32("HDoc_DR1_Emp")
			Else
				M_INT_HDOC_DR1_EMP = -1
			End If
			If REA.IsDBNull(REA.GetOrdinal("HDoc_DR2_Cat")) = False Then
				M_INT_HDOC_DR2_CAT = REA.GetInt32("HDoc_DR2_Cat")
			Else
				M_INT_HDOC_DR2_CAT = -1
			End If
			If REA.IsDBNull(REA.GetOrdinal("HDoc_DR2_Num")) = False Then
				M_STR_HDOC_DR2_NUM = REA.GetString("HDoc_DR2_Num")
			Else
				M_STR_HDOC_DR2_NUM = "NULL"
			End If
			If REA.IsDBNull(REA.GetOrdinal("HDoc_DR2_Fec")) = False Then
				M_DT_HDOC_DR2_FEC = REA.GetMySQLDateTime("HDoc_DR2_Fec")
			End If
			If REA.IsDBNull(REA.GetOrdinal("HDoc_DR2_Emp")) = False Then
				M_INT_HDOC_DR2_EMP = REA.GetInt32("HDoc_DR2_Emp")
			Else
				M_INT_HDOC_DR2_EMP = -1
			End If
			If REA.IsDBNull(REA.GetOrdinal("HDoc_RF1_Num")) = False Then
				M_INT_HDOC_RF1_NUM = REA.GetInt32("HDoc_RF1_Num")
			Else
				M_INT_HDOC_RF1_NUM = -1
			End If
			If REA.IsDBNull(REA.GetOrdinal("HDoc_RF1_Cod")) = False Then
				M_STR_HDOC_RF1_COD = REA.GetString("HDoc_RF1_Cod")
			Else
				M_STR_HDOC_RF1_COD = "NULL"
			End If
			If REA.IsDBNull(REA.GetOrdinal("HDoc_RF1_Txt")) = False Then
				M_OBJ_HDOC_RF1_TXT = REA.GetString("HDoc_RF1_Txt")
			End If
			If REA.IsDBNull(REA.GetOrdinal("HDoc_RF2_Num")) = False Then
				M_INT_HDOC_RF2_NUM = REA.GetInt32("HDoc_RF2_Num")
			Else
				M_INT_HDOC_RF2_NUM = -1
			End If
			If REA.IsDBNull(REA.GetOrdinal("HDoc_RF2_Cod")) = False Then
				M_STR_HDOC_RF2_COD = REA.GetString("HDoc_RF2_Cod")
			Else
				M_STR_HDOC_RF2_COD = "NULL"
			End If
			If REA.IsDBNull(REA.GetOrdinal("HDoc_RF2_Txt")) = False Then
				M_OBJ_HDOC_RF2_TXT = REA.GetString("HDoc_RF2_Txt")
			End If
			If REA.IsDBNull(REA.GetOrdinal("HDoc_Usuario")) = False Then
				M_STR_HDOC_USUARIO = REA.GetString("HDoc_Usuario")
			Else
				M_STR_HDOC_USUARIO = "NULL"
			End If
			If REA.IsDBNull(REA.GetOrdinal("HDoc_Pro_Fec")) = False Then
				M_DT_HDOC_PRO_FEC = REA.GetMySQLDateTime("HDoc_Pro_Fec")
			End If
			If REA.IsDBNull(REA.GetOrdinal("HDoc_Pro_DCat")) = False Then
				M_INT_HDOC_PRO_DCAT = REA.GetInt32("HDoc_Pro_DCat")
			Else
				M_INT_HDOC_PRO_DCAT = -1
			End If
			If REA.IsDBNull(REA.GetOrdinal("HDoc_Pro_DAno")) = False Then
				M_INT_HDOC_PRO_DANO = REA.GetInt32("HDoc_Pro_DAno")
			Else
				M_INT_HDOC_PRO_DANO = -1
			End If
			If REA.IsDBNull(REA.GetOrdinal("HDoc_Pro_DNum")) = False Then
				M_INT_HDOC_PRO_DNUM = REA.GetInt32("HDoc_Pro_DNum")
			Else
				M_INT_HDOC_PRO_DNUM = -1
			End If
			If REA.IsDBNull(REA.GetOrdinal("HDoc_Doc_TC")) = False Then
				M_DEC_HDOC_DOC_TC = REA.GetDecimal("HDoc_Doc_TC")
			End If
			If REA.IsDBNull(REA.GetOrdinal("HDoc_Doc_Mon")) = False Then
				M_INT_HDOC_DOC_MON = REA.GetInt32("HDoc_Doc_Mon")
			Else
				M_INT_HDOC_DOC_MON = -1
			End If
			If REA.IsDBNull(REA.GetOrdinal("HDoc_RF1_Dbl")) = False Then
				M_DEC_HDOC_RF1_DBL = REA.GetDecimal("HDoc_RF1_Dbl")
			End If
			If REA.IsDBNull(REA.GetOrdinal("HDoc_RF2_Dbl")) = False Then
				M_DEC_HDOC_RF2_DBL = REA.GetDecimal("HDoc_RF2_Dbl")
			End If
			If REA.IsDBNull(REA.GetOrdinal("HDoc_RF3_Dbl")) = False Then
				M_DEC_HDOC_RF3_DBL = REA.GetDecimal("HDoc_RF3_Dbl")
			End If
			If REA.IsDBNull(REA.GetOrdinal("HDoc_Doc_Status")) = False Then
				M_INT_HDOC_DOC_STATUS = REA.GetInt32("HDoc_Doc_Status")
			Else
				M_INT_HDOC_DOC_STATUS = -1
			End If
			PMOVE_NEXT = True
		Else
			REA.Close()
			REA = Nothing
		End If
	Catch MYEX As MySqlException
		MENSAJE = "BiblioTABLAS - TDCMTOS_HDR - PMOVE_NEXT Error=" & MYEX.ToString
	Catch EX As Exception
		MENSAJE = "BiblioTABLAS - TDCMTOS_HDR - PMOVE_NEXT Error=" & EX.ToString
	End Try
End Function

Public Function PSELECT_RECORDSET(Optional ByVal CONDICION As String = "", Optional ByVal ORDENAMIENTO As String = "") As Boolean
	Dim COM As MySqlCommand
	Dim SQL As String
	DIM SQL1 as String

	PSELECT_RECORDSET = False
	If IsNothing(REA) = False Then
		REA.CLOSE()
		REA = Nothing
	End If
	If IsNothing(CON) = True Then
		MENSAJE = "BiblioTABLAS - TDCMTOS_HDR - PSELECT_RECORDSET Conexi�n no definida"
		Exit Function
	End If
	If CON.State = ConnectionState.Closed Or CON.State = ConnectionState.Broken Then
		If CON.ConnectionString.Length <> 0 Then
			Try
				CON.Open()
			Catch MYEX As MySqlException
				MENSAJE = "BiblioTABLAS - TTDCMTOS_HDR - PSELECT_RECORDSET Error#=" & MYEX.Number & " " & MYEX.ToString
				Exit Function
			Catch EX As Exception
				MENSAJE = "BiblioTABLAS - TTDCMTOS_HDR - PSELECT_RECORDSET Error=" & EX.ToString
				Exit Function
			End Try
		Else
			MENSAJE = "BiblioTABLAS - TTDCMTOS_HDR - PSELECT_RECORDSET String de Conexi�n no definido"
			Exit Function
		End If
	End If

	COM = NOTHING
	Sql = "Select * from Dcmtos_HDR"
	If CONDICION.Length <> 0 Then
		Sql &= " Where " & CONDICION
	End If
	If ORDENAMIENTO.Length <> 0 Then
		Sql &= " Order By " & ORDENAMIENTO
	End If

	SQL1 = "Select Count(*) as Cuenta from Dcmtos_HDR"
	If CONDICION.Length <> 0 Then
		Sql1 &= " Where " & CONDICION
	End If
	Try
		INIT()
		INIT_LLAVE()

		COM = New MySqlCommand(SQL1,CON)
		Cantidad_de_la_Clase = CInt(COM.ExecuteScalar())
		COM.Dispose()
		COM = Nothing

		COM = New MySqlCommand(Sql, CON)
		COM.CommandType = CommandType.Text
		REA = COM.ExecuteReader
		PSELECT_RECORDSET = True
	Catch MYEX As MySqlException
		MENSAJE = "BiblioTABLAS - TDCMTOS_HDR - PSELECT_RECORDSET MyError#=" & MYEX.Number & " MyError=" & MYEX.ToString
	Catch EX As Exception
		MENSAJE = "BiblioTABLAS - TDCMTOS_HDR - PSELECT_RECORDSET Error=" & EX.ToString
	Finally
		If IsNothing(COM) = False Then
			COM.Dispose()
			COM = Nothing
		End If
	End Try
End Function

Public Function PSELECT(ByVal KHDOC_SIS_EMP as Integer, ByVal KHDOC_DOC_CAT as Integer, ByVal KHDOC_DOC_ANO as Integer, ByVal KHDOC_DOC_NUM as Integer) AS Boolean
	Dim READER As MySqlDataReader
	Dim COM As MySqlCommand
	Dim SQL as String

	Mensaje  = ""
	PSELECT = False
	If IsNothing(CON) = True Then
		MENSAJE = "BiblioTABLAS - TDCMTOS_HDR - PSELECT Conexi�n no definida"
		Exit Function
	End If
	If CON.State = ConnectionState.Closed Or CON.State = ConnectionState.Broken Then
		If CON.ConnectionString.Length <> 0 Then
			Try
				CON.Open()
			Catch MYEX As MySqlException
				MENSAJE = "BiblioTABLAS - TTDCMTOS_HDR - PSELECT Error#=" & MYEX.Number & " " & MYEX.ToString
				Exit Function
			Catch EX As Exception
				MENSAJE = "BiblioTABLAS - TTDCMTOS_HDR - PSELECT Error=" & EX.ToString
				Exit Function
			End Try
		Else
			MENSAJE = "BiblioTABLAS - TTDCMTOS_HDR - PSELECT String de Conexi�n no definido"
			Exit Function
		End If
	End If

	SQL = "SELECT * FROM Dcmtos_HDR WHERE HDOC_SIS_EMP = ?P1 AND HDOC_DOC_CAT = ?P2 AND HDOC_DOC_ANO = ?P3 AND HDOC_DOC_NUM = ?P4"
	READER = NOTHING
	COM = NOTHING
	TRY
		INIT()
		COM = New MySqlCommand(SQL,CON)
		COM.CommandType = CommandType.Text
		COM.Parameters.AddWithValue("?P1",KHDOC_SIS_EMP)
		COM.Parameters.AddWithValue("?P2",KHDOC_DOC_CAT)
		COM.Parameters.AddWithValue("?P3",KHDOC_DOC_ANO)
		COM.Parameters.AddWithValue("?P4",KHDOC_DOC_NUM)
		READER = COM.ExecuteReader(CommandBehavior.SingleRow)
		READER.READ()
		If READER.HasRows = True Then
			If READER.IsDBNull(READER.GetOrdinal("HDoc_Sis_Emp")) = False Then
				M_INT_HDOC_SIS_EMP = READER.GetInt32("HDoc_Sis_Emp")
			Else
				M_INT_HDOC_SIS_EMP = -1
			End If
			If READER.IsDBNull(READER.GetOrdinal("HDoc_Doc_Cat")) = False Then
				M_INT_HDOC_DOC_CAT = READER.GetInt32("HDoc_Doc_Cat")
			Else
				M_INT_HDOC_DOC_CAT = -1
			End If
			If READER.IsDBNull(READER.GetOrdinal("HDoc_Doc_Ano")) = False Then
				M_INT_HDOC_DOC_ANO = READER.GetInt32("HDoc_Doc_Ano")
			Else
				M_INT_HDOC_DOC_ANO = -1
			End If
			If READER.IsDBNull(READER.GetOrdinal("HDoc_Doc_Num")) = False Then
				M_INT_HDOC_DOC_NUM = READER.GetInt32("HDoc_Doc_Num")
			Else
				M_INT_HDOC_DOC_NUM = -1
			End If
			If READER.IsDBNull(READER.GetOrdinal("HDoc_Doc_Fec")) = False Then
				M_DT_HDOC_DOC_FEC = READER.GetMySQLDateTime("HDoc_Doc_Fec")
			End If
			If READER.IsDBNull(READER.GetOrdinal("HDoc_Emp_Cod")) = False Then
				M_INT_HDOC_EMP_COD = READER.GetInt32("HDoc_Emp_Cod")
			Else
				M_INT_HDOC_EMP_COD = -1
			End If
			If READER.IsDBNull(READER.GetOrdinal("HDoc_Emp_Nom")) = False Then
				M_STR_HDOC_EMP_NOM = READER.GetString("HDoc_Emp_Nom")
			Else
				M_STR_HDOC_EMP_NOM = "NULL"
			End If
			If READER.IsDBNull(READER.GetOrdinal("HDoc_Emp_Dir")) = False Then
				M_OBJ_HDOC_EMP_DIR = READER.GetString("HDoc_Emp_Dir")
			End If
			If READER.IsDBNull(READER.GetOrdinal("HDoc_Emp_Per")) = False Then
				M_STR_HDOC_EMP_PER = READER.GetString("HDoc_Emp_Per")
			Else
				M_STR_HDOC_EMP_PER = "NULL"
			End If
			If READER.IsDBNull(READER.GetOrdinal("HDoc_Emp_Tel")) = False Then
				M_STR_HDOC_EMP_TEL = READER.GetString("HDoc_Emp_Tel")
			Else
				M_STR_HDOC_EMP_TEL = "NULL"
			End If
			If READER.IsDBNull(READER.GetOrdinal("HDoc_Emp_NIT")) = False Then
				M_STR_HDOC_EMP_NIT = READER.GetString("HDoc_Emp_NIT")
			Else
				M_STR_HDOC_EMP_NIT = "NULL"
			End If
			If READER.IsDBNull(READER.GetOrdinal("HDoc_DR1_Cat")) = False Then
				M_INT_HDOC_DR1_CAT = READER.GetInt32("HDoc_DR1_Cat")
			Else
				M_INT_HDOC_DR1_CAT = -1
			End If
			If READER.IsDBNull(READER.GetOrdinal("HDoc_DR1_Num")) = False Then
				M_STR_HDOC_DR1_NUM = READER.GetString("HDoc_DR1_Num")
			Else
				M_STR_HDOC_DR1_NUM = "NULL"
			End If
			If READER.IsDBNull(READER.GetOrdinal("HDoc_DR1_Dbl")) = False Then
				M_DEC_HDOC_DR1_DBL = READER.GetDecimal("HDoc_DR1_Dbl")
			End If
			If READER.IsDBNull(READER.GetOrdinal("HDoc_DR1_Fec")) = False Then
				M_DT_HDOC_DR1_FEC = READER.GetMySQLDateTime("HDoc_DR1_Fec")
			End If
			If READER.IsDBNull(READER.GetOrdinal("HDoc_DR1_Emp")) = False Then
				M_INT_HDOC_DR1_EMP = READER.GetInt32("HDoc_DR1_Emp")
			Else
				M_INT_HDOC_DR1_EMP = -1
			End If
			If READER.IsDBNull(READER.GetOrdinal("HDoc_DR2_Cat")) = False Then
				M_INT_HDOC_DR2_CAT = READER.GetInt32("HDoc_DR2_Cat")
			Else
				M_INT_HDOC_DR2_CAT = -1
			End If
			If READER.IsDBNull(READER.GetOrdinal("HDoc_DR2_Num")) = False Then
				M_STR_HDOC_DR2_NUM = READER.GetString("HDoc_DR2_Num")
			Else
				M_STR_HDOC_DR2_NUM = "NULL"
			End If
			If READER.IsDBNull(READER.GetOrdinal("HDoc_DR2_Fec")) = False Then
				M_DT_HDOC_DR2_FEC = READER.GetMySQLDateTime("HDoc_DR2_Fec")
			End If
			If READER.IsDBNull(READER.GetOrdinal("HDoc_DR2_Emp")) = False Then
				M_INT_HDOC_DR2_EMP = READER.GetInt32("HDoc_DR2_Emp")
			Else
				M_INT_HDOC_DR2_EMP = -1
			End If
			If READER.IsDBNull(READER.GetOrdinal("HDoc_RF1_Num")) = False Then
				M_INT_HDOC_RF1_NUM = READER.GetInt32("HDoc_RF1_Num")
			Else
				M_INT_HDOC_RF1_NUM = -1
			End If
			If READER.IsDBNull(READER.GetOrdinal("HDoc_RF1_Cod")) = False Then
				M_STR_HDOC_RF1_COD = READER.GetString("HDoc_RF1_Cod")
			Else
				M_STR_HDOC_RF1_COD = "NULL"
			End If
			If READER.IsDBNull(READER.GetOrdinal("HDoc_RF1_Txt")) = False Then
				M_OBJ_HDOC_RF1_TXT = READER.GetString("HDoc_RF1_Txt")
			End If
			If READER.IsDBNull(READER.GetOrdinal("HDoc_RF2_Num")) = False Then
				M_INT_HDOC_RF2_NUM = READER.GetInt32("HDoc_RF2_Num")
			Else
				M_INT_HDOC_RF2_NUM = -1
			End If
			If READER.IsDBNull(READER.GetOrdinal("HDoc_RF2_Cod")) = False Then
				M_STR_HDOC_RF2_COD = READER.GetString("HDoc_RF2_Cod")
			Else
				M_STR_HDOC_RF2_COD = "NULL"
			End If
			If READER.IsDBNull(READER.GetOrdinal("HDoc_RF2_Txt")) = False Then
				M_OBJ_HDOC_RF2_TXT = READER.GetString("HDoc_RF2_Txt")
			End If
			If READER.IsDBNull(READER.GetOrdinal("HDoc_Usuario")) = False Then
				M_STR_HDOC_USUARIO = READER.GetString("HDoc_Usuario")
			Else
				M_STR_HDOC_USUARIO = "NULL"
			End If
			If READER.IsDBNull(READER.GetOrdinal("HDoc_Pro_Fec")) = False Then
				M_DT_HDOC_PRO_FEC = READER.GetMySQLDateTime("HDoc_Pro_Fec")
			End If
			If READER.IsDBNull(READER.GetOrdinal("HDoc_Pro_DCat")) = False Then
				M_INT_HDOC_PRO_DCAT = READER.GetInt32("HDoc_Pro_DCat")
			Else
				M_INT_HDOC_PRO_DCAT = -1
			End If
			If READER.IsDBNull(READER.GetOrdinal("HDoc_Pro_DAno")) = False Then
				M_INT_HDOC_PRO_DANO = READER.GetInt32("HDoc_Pro_DAno")
			Else
				M_INT_HDOC_PRO_DANO = -1
			End If
			If READER.IsDBNull(READER.GetOrdinal("HDoc_Pro_DNum")) = False Then
				M_INT_HDOC_PRO_DNUM = READER.GetInt32("HDoc_Pro_DNum")
			Else
				M_INT_HDOC_PRO_DNUM = -1
			End If
			If READER.IsDBNull(READER.GetOrdinal("HDoc_Doc_TC")) = False Then
				M_DEC_HDOC_DOC_TC = READER.GetDecimal("HDoc_Doc_TC")
			End If
			If READER.IsDBNull(READER.GetOrdinal("HDoc_Doc_Mon")) = False Then
				M_INT_HDOC_DOC_MON = READER.GetInt32("HDoc_Doc_Mon")
			Else
				M_INT_HDOC_DOC_MON = -1
			End If
			If READER.IsDBNull(READER.GetOrdinal("HDoc_RF1_Dbl")) = False Then
				M_DEC_HDOC_RF1_DBL = READER.GetDecimal("HDoc_RF1_Dbl")
			End If
			If READER.IsDBNull(READER.GetOrdinal("HDoc_RF2_Dbl")) = False Then
				M_DEC_HDOC_RF2_DBL = READER.GetDecimal("HDoc_RF2_Dbl")
			End If
			If READER.IsDBNull(READER.GetOrdinal("HDoc_RF3_Dbl")) = False Then
				M_DEC_HDOC_RF3_DBL = READER.GetDecimal("HDoc_RF3_Dbl")
			End If
			If READER.IsDBNull(READER.GetOrdinal("HDoc_Doc_Status")) = False Then
				M_INT_HDOC_DOC_STATUS = READER.GetInt32("HDoc_Doc_Status")
			Else
				M_INT_HDOC_DOC_STATUS = -1
			End If
		Else
			MENSAJE = ""
			Exit Function
		End IF
		READER.CLOSE()
		COM.DISPOSE()
		READER = NOTHING
		COM = NOTHING
		PSELECT = TRUE
	Catch MYEX As MySqlException
		MENSAJE = "BiblioTABLAS - TDCMTOS_HDR - PSELECT MyError#=" & MYEX.Number & " MyError=" & MYEX.ToString
	Catch EX As Exception
		MENSAJE = "BiblioTABLAS - TDCMTOS_HDR - PSELECT Error=" & EX.ToString
	Finally
		If IsNothing(READER) = False Then
			READER.Close()
			READER = Nothing
		End If
		If IsNothing(COM) = False Then
			COM.Dispose()
			COM = Nothing
		End If
	End Try
End Function

Public Function PSELECT_CONDICION(BYVAL CONDICION AS STRING) AS Boolean

	Dim READER As MySqlDataReader
	Dim COM As MySqlCommand
	Dim SQL as String

	Mensaje  = ""
	PSELECT_CONDICION = False
	If IsNothing(CON) = True Then
		MENSAJE = "BiblioTABLAS - TDCMTOS_HDR - PSELECT_CONDICION Conexi�n no definida"
		Exit Function
	End If
	If CON.State = ConnectionState.Closed Or CON.State = ConnectionState.Broken Then
		If CON.ConnectionString.Length <> 0 Then
			Try
				CON.Open()
			Catch MYEX As MySqlException
				MENSAJE = "BiblioTABLAS - TTDCMTOS_HDR - PSELECT_CONDICION Error#=" & MYEX.Number & " " & MYEX.ToString
				Exit Function
			Catch EX As Exception
				MENSAJE = "BiblioTABLAS - TTDCMTOS_HDR - PSELECT_CONDICION Error=" & EX.ToString
				Exit Function
			End Try
		Else
			MENSAJE = "BiblioTABLAS - TTDCMTOS_HDR - PSELECT_CONDICION String de Conexi�n no definido"
			Exit Function
		End If
	End If

	SQL = "SELECT * FROM Dcmtos_HDR WHERE " & CONDICION
	READER = NOTHING
	COM = NOTHING
	TRY
		INIT()
		COM = New MySqlCommand(SQL,CON)
		COM.CommandType = CommandType.Text
		READER = COM.ExecuteReader(CommandBehavior.SingleRow)
		READER.READ()
		If READER.HasRows = True Then
			If READER.IsDBNull(READER.GetOrdinal("HDoc_Sis_Emp")) = False Then
				M_INT_HDOC_SIS_EMP = READER.GetInt32("HDoc_Sis_Emp")
			Else
				M_INT_HDOC_SIS_EMP = -1
			End If
			If READER.IsDBNull(READER.GetOrdinal("HDoc_Doc_Cat")) = False Then
				M_INT_HDOC_DOC_CAT = READER.GetInt32("HDoc_Doc_Cat")
			Else
				M_INT_HDOC_DOC_CAT = -1
			End If
			If READER.IsDBNull(READER.GetOrdinal("HDoc_Doc_Ano")) = False Then
				M_INT_HDOC_DOC_ANO = READER.GetInt32("HDoc_Doc_Ano")
			Else
				M_INT_HDOC_DOC_ANO = -1
			End If
			If READER.IsDBNull(READER.GetOrdinal("HDoc_Doc_Num")) = False Then
				M_INT_HDOC_DOC_NUM = READER.GetInt32("HDoc_Doc_Num")
			Else
				M_INT_HDOC_DOC_NUM = -1
			End If
			If READER.IsDBNull(READER.GetOrdinal("HDoc_Doc_Fec")) = False Then
				M_DT_HDOC_DOC_FEC = READER.GetMySQLDateTime("HDoc_Doc_Fec")
			End If
			If READER.IsDBNull(READER.GetOrdinal("HDoc_Emp_Cod")) = False Then
				M_INT_HDOC_EMP_COD = READER.GetInt32("HDoc_Emp_Cod")
			Else
				M_INT_HDOC_EMP_COD = -1
			End If
			If READER.IsDBNull(READER.GetOrdinal("HDoc_Emp_Nom")) = False Then
				M_STR_HDOC_EMP_NOM = READER.GetString("HDoc_Emp_Nom")
			Else
				M_STR_HDOC_EMP_NOM = "NULL"
			End If
			If READER.IsDBNull(READER.GetOrdinal("HDoc_Emp_Dir")) = False Then
				M_OBJ_HDOC_EMP_DIR = READER.GetString("HDoc_Emp_Dir")
			End If
			If READER.IsDBNull(READER.GetOrdinal("HDoc_Emp_Per")) = False Then
				M_STR_HDOC_EMP_PER = READER.GetString("HDoc_Emp_Per")
			Else
				M_STR_HDOC_EMP_PER = "NULL"
			End If
			If READER.IsDBNull(READER.GetOrdinal("HDoc_Emp_Tel")) = False Then
				M_STR_HDOC_EMP_TEL = READER.GetString("HDoc_Emp_Tel")
			Else
				M_STR_HDOC_EMP_TEL = "NULL"
			End If
			If READER.IsDBNull(READER.GetOrdinal("HDoc_Emp_NIT")) = False Then
				M_STR_HDOC_EMP_NIT = READER.GetString("HDoc_Emp_NIT")
			Else
				M_STR_HDOC_EMP_NIT = "NULL"
			End If
			If READER.IsDBNull(READER.GetOrdinal("HDoc_DR1_Cat")) = False Then
				M_INT_HDOC_DR1_CAT = READER.GetInt32("HDoc_DR1_Cat")
			Else
				M_INT_HDOC_DR1_CAT = -1
			End If
			If READER.IsDBNull(READER.GetOrdinal("HDoc_DR1_Num")) = False Then
				M_STR_HDOC_DR1_NUM = READER.GetString("HDoc_DR1_Num")
			Else
				M_STR_HDOC_DR1_NUM = "NULL"
			End If
			If READER.IsDBNull(READER.GetOrdinal("HDoc_DR1_Dbl")) = False Then
				M_DEC_HDOC_DR1_DBL = READER.GetDecimal("HDoc_DR1_Dbl")
			End If
			If READER.IsDBNull(READER.GetOrdinal("HDoc_DR1_Fec")) = False Then
				M_DT_HDOC_DR1_FEC = READER.GetMySQLDateTime("HDoc_DR1_Fec")
			End If
			If READER.IsDBNull(READER.GetOrdinal("HDoc_DR1_Emp")) = False Then
				M_INT_HDOC_DR1_EMP = READER.GetInt32("HDoc_DR1_Emp")
			Else
				M_INT_HDOC_DR1_EMP = -1
			End If
			If READER.IsDBNull(READER.GetOrdinal("HDoc_DR2_Cat")) = False Then
				M_INT_HDOC_DR2_CAT = READER.GetInt32("HDoc_DR2_Cat")
			Else
				M_INT_HDOC_DR2_CAT = -1
			End If
			If READER.IsDBNull(READER.GetOrdinal("HDoc_DR2_Num")) = False Then
				M_STR_HDOC_DR2_NUM = READER.GetString("HDoc_DR2_Num")
			Else
				M_STR_HDOC_DR2_NUM = "NULL"
			End If
			If READER.IsDBNull(READER.GetOrdinal("HDoc_DR2_Fec")) = False Then
				M_DT_HDOC_DR2_FEC = READER.GetMySQLDateTime("HDoc_DR2_Fec")
			End If
			If READER.IsDBNull(READER.GetOrdinal("HDoc_DR2_Emp")) = False Then
				M_INT_HDOC_DR2_EMP = READER.GetInt32("HDoc_DR2_Emp")
			Else
				M_INT_HDOC_DR2_EMP = -1
			End If
			If READER.IsDBNull(READER.GetOrdinal("HDoc_RF1_Num")) = False Then
				M_INT_HDOC_RF1_NUM = READER.GetInt32("HDoc_RF1_Num")
			Else
				M_INT_HDOC_RF1_NUM = -1
			End If
			If READER.IsDBNull(READER.GetOrdinal("HDoc_RF1_Cod")) = False Then
				M_STR_HDOC_RF1_COD = READER.GetString("HDoc_RF1_Cod")
			Else
				M_STR_HDOC_RF1_COD = "NULL"
			End If
			If READER.IsDBNull(READER.GetOrdinal("HDoc_RF1_Txt")) = False Then
				M_OBJ_HDOC_RF1_TXT = READER.GetString("HDoc_RF1_Txt")
			End If
			If READER.IsDBNull(READER.GetOrdinal("HDoc_RF2_Num")) = False Then
				M_INT_HDOC_RF2_NUM = READER.GetInt32("HDoc_RF2_Num")
			Else
				M_INT_HDOC_RF2_NUM = -1
			End If
			If READER.IsDBNull(READER.GetOrdinal("HDoc_RF2_Cod")) = False Then
				M_STR_HDOC_RF2_COD = READER.GetString("HDoc_RF2_Cod")
			Else
				M_STR_HDOC_RF2_COD = "NULL"
			End If
			If READER.IsDBNull(READER.GetOrdinal("HDoc_RF2_Txt")) = False Then
				M_OBJ_HDOC_RF2_TXT = READER.GetString("HDoc_RF2_Txt")
			End If
			If READER.IsDBNull(READER.GetOrdinal("HDoc_Usuario")) = False Then
				M_STR_HDOC_USUARIO = READER.GetString("HDoc_Usuario")
			Else
				M_STR_HDOC_USUARIO = "NULL"
			End If
			If READER.IsDBNull(READER.GetOrdinal("HDoc_Pro_Fec")) = False Then
				M_DT_HDOC_PRO_FEC = READER.GetMySQLDateTime("HDoc_Pro_Fec")
			End If
			If READER.IsDBNull(READER.GetOrdinal("HDoc_Pro_DCat")) = False Then
				M_INT_HDOC_PRO_DCAT = READER.GetInt32("HDoc_Pro_DCat")
			Else
				M_INT_HDOC_PRO_DCAT = -1
			End If
			If READER.IsDBNull(READER.GetOrdinal("HDoc_Pro_DAno")) = False Then
				M_INT_HDOC_PRO_DANO = READER.GetInt32("HDoc_Pro_DAno")
			Else
				M_INT_HDOC_PRO_DANO = -1
			End If
			If READER.IsDBNull(READER.GetOrdinal("HDoc_Pro_DNum")) = False Then
				M_INT_HDOC_PRO_DNUM = READER.GetInt32("HDoc_Pro_DNum")
			Else
				M_INT_HDOC_PRO_DNUM = -1
			End If
			If READER.IsDBNull(READER.GetOrdinal("HDoc_Doc_TC")) = False Then
				M_DEC_HDOC_DOC_TC = READER.GetDecimal("HDoc_Doc_TC")
			End If
			If READER.IsDBNull(READER.GetOrdinal("HDoc_Doc_Mon")) = False Then
				M_INT_HDOC_DOC_MON = READER.GetInt32("HDoc_Doc_Mon")
			Else
				M_INT_HDOC_DOC_MON = -1
			End If
			If READER.IsDBNull(READER.GetOrdinal("HDoc_RF1_Dbl")) = False Then
				M_DEC_HDOC_RF1_DBL = READER.GetDecimal("HDoc_RF1_Dbl")
			End If
			If READER.IsDBNull(READER.GetOrdinal("HDoc_RF2_Dbl")) = False Then
				M_DEC_HDOC_RF2_DBL = READER.GetDecimal("HDoc_RF2_Dbl")
			End If
			If READER.IsDBNull(READER.GetOrdinal("HDoc_RF3_Dbl")) = False Then
				M_DEC_HDOC_RF3_DBL = READER.GetDecimal("HDoc_RF3_Dbl")
			End If
			If READER.IsDBNull(READER.GetOrdinal("HDoc_Doc_Status")) = False Then
				M_INT_HDOC_DOC_STATUS = READER.GetInt32("HDoc_Doc_Status")
			Else
				M_INT_HDOC_DOC_STATUS = -1
			End If
			PSelect_Condicion = True
		Else
			MENSAJE = ""
			Exit Function
		End IF
		READER.CLOSE()
		COM.DISPOSE()
		READER = NOTHING
		COM = NOTHING
		PSELECT_CONDICION = TRUE
	Catch MYEX As MySqlException
		MENSAJE = "BiblioTABLAS - TDCMTOS_HDR - PSELECT_CONDICION MyError#=" & MYEX.Number & " MyError=" & MYEX.ToString
	Catch EX As Exception
		MENSAJE = "BiblioTABLAS - TDCMTOS_HDR - PSELECT_CONDICION Error=" & EX.ToString
	Finally
		If IsNothing(READER) = False Then
			READER.Close()
			READER = Nothing
		End If
		If IsNothing(COM) = False Then
			COM.Dispose()
			COM = Nothing
		End If
	End Try
End Function

Public Function PSELECT_READER(ByRef READER As MySqlDataReader, _
				Optional ByVal CAMPOS As String = "", _
				Optional ByVal CONDICION As String = "", _
				Optional ByVal ORDENAMIENTO As String = "") AS Boolean

	Dim COM As MySqlCommand
	Dim SQL as String
	Dim SQL1 as String

	Mensaje  = ""
	PSELECT_READER = False
	If IsNothing(CON) = True Then
		MENSAJE = "BiblioTABLAS - TDCMTOS_HDR - PSELECT_READER Conexi�n no definida"
		Exit Function
	End If
	If CON.State = ConnectionState.Closed Or CON.State = ConnectionState.Broken Then
		If CON.ConnectionString.Length <> 0 Then
			Try
				CON.Open()
			Catch MYEX As MySqlException
				MENSAJE = "BiblioTABLAS - TTDCMTOS_HDR - PSELECT_READER Error#=" & MYEX.Number & " " & MYEX.ToString
				Exit Function
			Catch EX As Exception
				MENSAJE = "BiblioTABLAS - TTDCMTOS_HDR - PSELECT_READER Error=" & EX.ToString
				Exit Function
			End Try
		Else
			MENSAJE = "BiblioTABLAS - TTDCMTOS_HDR - PSELECT_READER String de Conexi�n no definido"
			Exit Function
		End If
	End If

	If CAMPOS.Length = 0 Then
		Sql = "Select * from Dcmtos_HDR"
	Else
		Sql = "SELECT " & CAMPOS & " FROM Dcmtos_HDR"
	End If
	If CONDICION.Length <> 0 Then
		Sql &= " Where " & CONDICION
	End If
	If ORDENAMIENTO.Length <> 0 Then
		Sql &= " Order By " & ORDENAMIENTO
	End If

		Sql1 = "Select Count(*) as Cuenta from Dcmtos_HDR"
	If CONDICION.Length <> 0 Then
		Sql1 &= " Where " & CONDICION
	End If

	READER = NOTHING
	COM = NOTHING
	TRY
		INIT()
		COM = New MySqlCommand(SQL1,CON)
		Cantidad_de_la_Clase = CInt(COM.ExecuteScalar())
		COM.Dispose()
		COM = Nothing

		COM = New MySqlCommand(SQL,CON)
		COM.CommandType = CommandType.Text
		READER = COM.ExecuteReader()
		COM.DISPOSE()
		COM = NOTHING
		PSELECT_READER = TRUE
	Catch MYEX As MySqlException
		MENSAJE = "BiblioTABLAS - TDCMTOS_HDR - PSELECT_READER MyError#=" & MYEX.Number & " MyError=" & MYEX.ToString
	Catch EX As Exception
		MENSAJE = "BiblioTABLAS - TDCMTOS_HDR - PSELECT_READER Error=" & EX.ToString
	Finally
		If IsNothing(COM) = False Then
			COM.Dispose()
			COM = Nothing
		End If
	End Try
End Function

Public Function PINSERT() AS Boolean
	Dim COM As MySqlCommand
	Dim SQL as String

	MENSAJE = ""
	PINSERT = False
	If IsNothing(CON) = True Then
		MENSAJE = "BiblioTABLAS - TDCMTOS_HDR - PINSERT Conexi�n no definida"
		Exit Function
	End If
	If CON.State = ConnectionState.Closed Or CON.State = ConnectionState.Broken Then
		If CON.ConnectionString.Length <> 0 Then
			Try
				CON.Open()
			Catch MYEX As MySqlException
				MENSAJE = "BiblioTABLAS - TTDCMTOS_HDR - PINSERT Error#=" & MYEX.Number & " " & MYEX.ToString
				Exit Function
			Catch EX As Exception
				MENSAJE = "BiblioTABLAS - TTDCMTOS_HDR - PINSERT Error=" & EX.ToString
				Exit Function
			End Try
		Else
			MENSAJE = "BiblioTABLAS - TTDCMTOS_HDR - PINSERT String de Conexi�n no definido"
			Exit Function
		End If
	End If

	COM = Nothing
	TRY
		SQL = "INSERT INTO Dcmtos_HDR (HDoc_Sis_Emp,HDoc_Doc_Cat,HDoc_Doc_Ano,HDoc_Doc_Num,HDoc_Doc_Fec,HDoc_Emp_Cod,HDoc_Emp_Nom,HDoc_Emp_Dir,HDoc_Emp_Per,HDoc_Emp_Tel,HDoc_Emp_NIT,HDoc_DR1_Cat,HDoc_DR1_Num,HDoc_DR1_Dbl,HDoc_DR1_Fec,HDoc_DR1_Emp,HDoc_DR2_Cat,HDoc_DR2_Num,HDoc_DR2_Fec,HDoc_DR2_Emp,HDoc_RF1_Num,HDoc_RF1_Cod,HDoc_RF1_Txt,HDoc_RF2_Num,HDoc_RF2_Cod,HDoc_RF2_Txt,HDoc_Usuario,HDoc_Pro_Fec,HDoc_Pro_DCat,HDoc_Pro_DAno,HDoc_Pro_DNum,HDoc_Doc_TC,HDoc_Doc_Mon,HDoc_RF1_Dbl,HDoc_RF2_Dbl,HDoc_RF3_Dbl,HDoc_Doc_Status) " & _
			"VALUES(?P1,?P2,?P3,?P4,?P5,?P6,?P7,?P8,?P9,?P10,?P11,?P12,?P13,?P14,?P15,?P16,?P17,?P18,?P19,?P20,?P21,?P22,?P23,?P24,?P25,?P26,?P27,?P28,?P29,?P30,?P31,?P32,?P33,?P34,?P35,?P36,?P37)"
		If IsNothing(TRA) = False Then
			COM = New MySqlCommand(Sql, tra.Connection, TRA)
		Else
			COM = New MySqlCommand(Sql, CON)
		End If
		COM.CommandType = CommandType.Text
		If m_int_HDoc_Sis_Emp = -1 then
			COM.Parameters.AddWithValue("?P1",DBNull.Value)
		Else
			COM.Parameters.AddWithValue("?P1",m_int_HDoc_Sis_Emp)
		End If
		If m_int_HDoc_Doc_Cat = -1 then
			COM.Parameters.AddWithValue("?P2",DBNull.Value)
		Else
			COM.Parameters.AddWithValue("?P2",m_int_HDoc_Doc_Cat)
		End If
		If m_int_HDoc_Doc_Ano = -1 then
			COM.Parameters.AddWithValue("?P3",DBNull.Value)
		Else
			COM.Parameters.AddWithValue("?P3",m_int_HDoc_Doc_Ano)
		End If
		If m_int_HDoc_Doc_Num = -1 then
			COM.Parameters.AddWithValue("?P4",DBNull.Value)
		Else
			COM.Parameters.AddWithValue("?P4",m_int_HDoc_Doc_Num)
		End If
		If m_dt_HDoc_Doc_Fec.IsValidDateTime = False then
			COM.Parameters.AddWithValue("?P5",DBNull.Value)
		Else
			COM.Parameters.AddWithValue("?P5",m_dt_HDoc_Doc_Fec.value)
		End If
		If m_int_HDoc_Emp_Cod = -1 then
			COM.Parameters.AddWithValue("?P6",DBNull.Value)
		Else
			COM.Parameters.AddWithValue("?P6",m_int_HDoc_Emp_Cod)
		End If
		If m_str_HDoc_Emp_Nom.ToUpper = "NULL" then
			COM.Parameters.AddWithValue("?P7",DBNull.Value)
		Else
			COM.Parameters.AddWithValue("?P7",m_str_HDoc_Emp_Nom)
		End If
		COM.Parameters.AddWithValue("?P8",m_obj_HDoc_Emp_Dir)
		If m_str_HDoc_Emp_Per.ToUpper = "NULL" then
			COM.Parameters.AddWithValue("?P9",DBNull.Value)
		Else
			COM.Parameters.AddWithValue("?P9",m_str_HDoc_Emp_Per)
		End If
		If m_str_HDoc_Emp_Tel.ToUpper = "NULL" then
			COM.Parameters.AddWithValue("?P10",DBNull.Value)
		Else
			COM.Parameters.AddWithValue("?P10",m_str_HDoc_Emp_Tel)
		End If
		If m_str_HDoc_Emp_NIT.ToUpper = "NULL" then
			COM.Parameters.AddWithValue("?P11",DBNull.Value)
		Else
			COM.Parameters.AddWithValue("?P11",m_str_HDoc_Emp_NIT)
		End If
		If m_int_HDoc_DR1_Cat = -1 then
			COM.Parameters.AddWithValue("?P12",DBNull.Value)
		Else
			COM.Parameters.AddWithValue("?P12",m_int_HDoc_DR1_Cat)
		End If
		If m_str_HDoc_DR1_Num.ToUpper = "NULL" then
			COM.Parameters.AddWithValue("?P13",DBNull.Value)
		Else
			COM.Parameters.AddWithValue("?P13",m_str_HDoc_DR1_Num)
		End If
		COM.Parameters.AddWithValue("?P14",m_dec_HDoc_DR1_Dbl)
		If m_dt_HDoc_DR1_Fec.IsValidDateTime = False then
			COM.Parameters.AddWithValue("?P15",DBNull.Value)
		Else
			COM.Parameters.AddWithValue("?P15",m_dt_HDoc_DR1_Fec.value)
		End If
		If m_int_HDoc_DR1_Emp = -1 then
			COM.Parameters.AddWithValue("?P16",DBNull.Value)
		Else
			COM.Parameters.AddWithValue("?P16",m_int_HDoc_DR1_Emp)
		End If
		If m_int_HDoc_DR2_Cat = -1 then
			COM.Parameters.AddWithValue("?P17",DBNull.Value)
		Else
			COM.Parameters.AddWithValue("?P17",m_int_HDoc_DR2_Cat)
		End If
		If m_str_HDoc_DR2_Num.ToUpper = "NULL" then
			COM.Parameters.AddWithValue("?P18",DBNull.Value)
		Else
			COM.Parameters.AddWithValue("?P18",m_str_HDoc_DR2_Num)
		End If
		If m_dt_HDoc_DR2_Fec.IsValidDateTime = False then
			COM.Parameters.AddWithValue("?P19",DBNull.Value)
		Else
			COM.Parameters.AddWithValue("?P19",m_dt_HDoc_DR2_Fec.value)
		End If
		If m_int_HDoc_DR2_Emp = -1 then
			COM.Parameters.AddWithValue("?P20",DBNull.Value)
		Else
			COM.Parameters.AddWithValue("?P20",m_int_HDoc_DR2_Emp)
		End If
		If m_int_HDoc_RF1_Num = -1 then
			COM.Parameters.AddWithValue("?P21",DBNull.Value)
		Else
			COM.Parameters.AddWithValue("?P21",m_int_HDoc_RF1_Num)
		End If
		If m_str_HDoc_RF1_Cod.ToUpper = "NULL" then
			COM.Parameters.AddWithValue("?P22",DBNull.Value)
		Else
			COM.Parameters.AddWithValue("?P22",m_str_HDoc_RF1_Cod)
		End If
		COM.Parameters.AddWithValue("?P23",m_obj_HDoc_RF1_Txt)
		If m_int_HDoc_RF2_Num = -1 then
			COM.Parameters.AddWithValue("?P24",DBNull.Value)
		Else
			COM.Parameters.AddWithValue("?P24",m_int_HDoc_RF2_Num)
		End If
		If m_str_HDoc_RF2_Cod.ToUpper = "NULL" then
			COM.Parameters.AddWithValue("?P25",DBNull.Value)
		Else
			COM.Parameters.AddWithValue("?P25",m_str_HDoc_RF2_Cod)
		End If
		COM.Parameters.AddWithValue("?P26",m_obj_HDoc_RF2_Txt)
		If m_str_HDoc_Usuario.ToUpper = "NULL" then
			COM.Parameters.AddWithValue("?P27",DBNull.Value)
		Else
			COM.Parameters.AddWithValue("?P27",m_str_HDoc_Usuario)
		End If
		If m_dt_HDoc_Pro_Fec.IsValidDateTime = False then
			COM.Parameters.AddWithValue("?P28",DBNull.Value)
		Else
			COM.Parameters.AddWithValue("?P28",m_dt_HDoc_Pro_Fec.value)
		End If
		If m_int_HDoc_Pro_DCat = -1 then
			COM.Parameters.AddWithValue("?P29",DBNull.Value)
		Else
			COM.Parameters.AddWithValue("?P29",m_int_HDoc_Pro_DCat)
		End If
		If m_int_HDoc_Pro_DAno = -1 then
			COM.Parameters.AddWithValue("?P30",DBNull.Value)
		Else
			COM.Parameters.AddWithValue("?P30",m_int_HDoc_Pro_DAno)
		End If
		If m_int_HDoc_Pro_DNum = -1 then
			COM.Parameters.AddWithValue("?P31",DBNull.Value)
		Else
			COM.Parameters.AddWithValue("?P31",m_int_HDoc_Pro_DNum)
		End If
		COM.Parameters.AddWithValue("?P32",m_dec_HDoc_Doc_TC)
		If m_int_HDoc_Doc_Mon = -1 then
			COM.Parameters.AddWithValue("?P33",DBNull.Value)
		Else
			COM.Parameters.AddWithValue("?P33",m_int_HDoc_Doc_Mon)
		End If
		COM.Parameters.AddWithValue("?P34",m_dec_HDoc_RF1_Dbl)
		COM.Parameters.AddWithValue("?P35",m_dec_HDoc_RF2_Dbl)
		COM.Parameters.AddWithValue("?P36",m_dec_HDoc_RF3_Dbl)
		If m_int_HDoc_Doc_Status = -1 then
			COM.Parameters.AddWithValue("?P37",DBNull.Value)
		Else
			COM.Parameters.AddWithValue("?P37",m_int_HDoc_Doc_Status)
		End If
		COM.ExecuteNonQuery()
		COM.Dispose()
		COM = Nothing
		PINSERT = True
	Catch MYEX As MySqlException
		MENSAJE = "BiblioTABLAS - TDCMTOS_HDR - PINSERT MyError#=" & MYEX.Number & " MyError=" & MYEX.ToString
	Catch ex As Exception
		MENSAJE = "BiblioTABLAS - TDCMTOS_HDR - PINSERT Error=" & ex.ToString
	Finally
		If IsNothing(COM) = False Then
			COM.Dispose()
			COM = Nothing
		End If
	End Try
End Function

Public Function PDELETE(Optional ByVal Condicion as String = "") AS Boolean

	Dim COM As MySqlCommand
	Dim SQL as String

	MENSAJE = ""
	PDELETE = False
	If IsNothing(CON) = True Then
		MENSAJE = "BiblioTABLAS - TDCMTOS_HDR - PDELETE Conexi�n no definida"
		Exit Function
	End If
	If CON.State = ConnectionState.Closed Or CON.State = ConnectionState.Broken Then
		If CON.ConnectionString.Length <> 0 Then
			Try
				CON.Open()
			Catch MYEX As MySqlException
				MENSAJE = "BiblioTABLAS - TTDCMTOS_HDR - PDELETE Error#=" & MYEX.Number & " " & MYEX.ToString
				Exit Function
			Catch EX As Exception
				MENSAJE = "BiblioTABLAS - TTDCMTOS_HDR - PDELETE Error=" & EX.ToString
				Exit Function
			End Try
		Else
			MENSAJE = "BiblioTABLAS - TTDCMTOS_HDR - PDELETE String de Conexi�n no definido"
			Exit Function
		End If
	End If

	COM = Nothing
	TRY
		If Condicion.Length <> 0 then
			SQL = "DELETE FROM Dcmtos_HDR WHERE " & Condicion
			If IsNothing(TRA) = False Then
				COM = New MySqlCommand(Sql, tra.Connection, TRA)
			Else
				COM = New MySqlCommand(Sql, CON)
			End If
			COM.CommandType = CommandType.Text
		Else
			SQL = "DELETE FROM Dcmtos_HDR WHERE HDoc_Sis_Emp = ?P1  AND HDoc_Doc_Cat = ?P2  AND HDoc_Doc_Ano = ?P3  AND HDoc_Doc_Num = ?P4 "
			If IsNothing(TRA) = False Then
				COM = New MySqlCommand(Sql, tra.Connection, TRA)
			Else
				COM = New MySqlCommand(Sql, CON)
			End If
			COM.CommandType = CommandType.Text
			COM.Parameters.AddWithValue("?P1", m_int_HDoc_Sis_Emp)
			COM.Parameters.AddWithValue("?P2", m_int_HDoc_Doc_Cat)
			COM.Parameters.AddWithValue("?P3", m_int_HDoc_Doc_Ano)
			COM.Parameters.AddWithValue("?P4", m_int_HDoc_Doc_Num)
		End If
		COM.ExecuteNonQuery()
		COM.Dispose()
		COM = Nothing
		PDELETE = True
	Catch MYEX As MySqlException
		MENSAJE = "BiblioTABLAS - TDCMTOS_HDR - PDELETE MyError#=" & MYEX.Number & " MyError=" & MYEX.ToString
	Catch ex As Exception
		MENSAJE = "BiblioTABLAS - TDCMTOS_HDR - PDELETE Error=" & ex.ToString
	Finally
		If IsNothing(COM) = False Then
			COM.Dispose()
			COM = Nothing
		End If
	End Try
End Function

Public Function PUPDATE() AS Boolean

	Dim COM As MySqlCommand
	Dim SQL as String

	MENSAJE = ""
	PUPDATE = False
	If IsNothing(CON) = True Then
		MENSAJE = "BiblioTABLAS - TDCMTOS_HDR - PUPDATE Conexi�n no definida"
		Exit Function
	End If
	If CON.State = ConnectionState.Closed Or CON.State = ConnectionState.Broken Then
		If CON.ConnectionString.Length <> 0 Then
			Try
				CON.Open()
			Catch MYEX As MySqlException
				MENSAJE = "BiblioTABLAS - TTDCMTOS_HDR - PUPDATE Error#=" & MYEX.Number & " " & MYEX.ToString
				Exit Function
			Catch EX As Exception
				MENSAJE = "BiblioTABLAS - TTDCMTOS_HDR - PUPDATE Error=" & EX.ToString
				Exit Function
			End Try
		Else
			MENSAJE = "BiblioTABLAS - TTDCMTOS_HDR - PUPDATE String de Conexi�n no definido"
			Exit Function
		End If
	End If

	COM = Nothing
	TRY
		SQL = "UPDATE Dcmtos_HDR SET HDoc_Doc_Fec = ?P5, HDoc_Emp_Cod = ?P6, HDoc_Emp_Nom = ?P7, HDoc_Emp_Dir = ?P8, HDoc_Emp_Per = ?P9, HDoc_Emp_Tel = ?P10, HDoc_Emp_NIT = ?P11, HDoc_DR1_Cat = ?P12, HDoc_DR1_Num = ?P13, HDoc_DR1_Dbl = ?P14, HDoc_DR1_Fec = ?P15, HDoc_DR1_Emp = ?P16, HDoc_DR2_Cat = ?P17, HDoc_DR2_Num = ?P18, HDoc_DR2_Fec = ?P19, HDoc_DR2_Emp = ?P20, HDoc_RF1_Num = ?P21, HDoc_RF1_Cod = ?P22, HDoc_RF1_Txt = ?P23, HDoc_RF2_Num = ?P24, HDoc_RF2_Cod = ?P25, HDoc_RF2_Txt = ?P26, HDoc_Usuario = ?P27, HDoc_Pro_Fec = ?P28, HDoc_Pro_DCat = ?P29, HDoc_Pro_DAno = ?P30, HDoc_Pro_DNum = ?P31, HDoc_Doc_TC = ?P32, HDoc_Doc_Mon = ?P33, HDoc_RF1_Dbl = ?P34, HDoc_RF2_Dbl = ?P35, HDoc_RF3_Dbl = ?P36, HDoc_Doc_Status = ?P37 WHERE HDoc_Sis_Emp = ?P1 AND HDoc_Doc_Cat = ?P2 AND HDoc_Doc_Ano = ?P3 AND HDoc_Doc_Num = ?P4"
		If IsNothing(TRA) = False Then
			COM = New MySqlCommand(Sql, tra.Connection, TRA)
		Else
			COM = New MySqlCommand(Sql, CON)
		End If
		COM.CommandType = CommandType.Text
		If m_dt_HDoc_Doc_Fec.IsValidDateTime = False then
			COM.Parameters.AddWithValue("?P5",DBNull.Value)
		Else
			COM.Parameters.AddWithValue("?P5",m_dt_HDoc_Doc_Fec.value)
		End If
		If m_int_HDoc_Emp_Cod = -1 then
			COM.Parameters.AddWithValue("?P6",DBNull.Value)
		Else
			COM.Parameters.AddWithValue("?P6",m_int_HDoc_Emp_Cod)
		End If
		If m_str_HDoc_Emp_Nom.ToUpper = "NULL" then
			COM.Parameters.AddWithValue("?P7",DBNull.Value)
		Else
			COM.Parameters.AddWithValue("?P7",m_str_HDoc_Emp_Nom)
		End If
		COM.Parameters.AddWithValue("?P8",m_obj_HDoc_Emp_Dir)
		If m_str_HDoc_Emp_Per.ToUpper = "NULL" then
			COM.Parameters.AddWithValue("?P9",DBNull.Value)
		Else
			COM.Parameters.AddWithValue("?P9",m_str_HDoc_Emp_Per)
		End If
		If m_str_HDoc_Emp_Tel.ToUpper = "NULL" then
			COM.Parameters.AddWithValue("?P10",DBNull.Value)
		Else
			COM.Parameters.AddWithValue("?P10",m_str_HDoc_Emp_Tel)
		End If
		If m_str_HDoc_Emp_NIT.ToUpper = "NULL" then
			COM.Parameters.AddWithValue("?P11",DBNull.Value)
		Else
			COM.Parameters.AddWithValue("?P11",m_str_HDoc_Emp_NIT)
		End If
		If m_int_HDoc_DR1_Cat = -1 then
			COM.Parameters.AddWithValue("?P12",DBNull.Value)
		Else
			COM.Parameters.AddWithValue("?P12",m_int_HDoc_DR1_Cat)
		End If
		If m_str_HDoc_DR1_Num.ToUpper = "NULL" then
			COM.Parameters.AddWithValue("?P13",DBNull.Value)
		Else
			COM.Parameters.AddWithValue("?P13",m_str_HDoc_DR1_Num)
		End If
		COM.Parameters.AddWithValue("?P14",m_dec_HDoc_DR1_Dbl)
		If m_dt_HDoc_DR1_Fec.IsValidDateTime = False then
			COM.Parameters.AddWithValue("?P15",DBNull.Value)
		Else
			COM.Parameters.AddWithValue("?P15",m_dt_HDoc_DR1_Fec.value)
		End If
		If m_int_HDoc_DR1_Emp = -1 then
			COM.Parameters.AddWithValue("?P16",DBNull.Value)
		Else
			COM.Parameters.AddWithValue("?P16",m_int_HDoc_DR1_Emp)
		End If
		If m_int_HDoc_DR2_Cat = -1 then
			COM.Parameters.AddWithValue("?P17",DBNull.Value)
		Else
			COM.Parameters.AddWithValue("?P17",m_int_HDoc_DR2_Cat)
		End If
		If m_str_HDoc_DR2_Num.ToUpper = "NULL" then
			COM.Parameters.AddWithValue("?P18",DBNull.Value)
		Else
			COM.Parameters.AddWithValue("?P18",m_str_HDoc_DR2_Num)
		End If
		If m_dt_HDoc_DR2_Fec.IsValidDateTime = False then
			COM.Parameters.AddWithValue("?P19",DBNull.Value)
		Else
			COM.Parameters.AddWithValue("?P19",m_dt_HDoc_DR2_Fec.value)
		End If
		If m_int_HDoc_DR2_Emp = -1 then
			COM.Parameters.AddWithValue("?P20",DBNull.Value)
		Else
			COM.Parameters.AddWithValue("?P20",m_int_HDoc_DR2_Emp)
		End If
		If m_int_HDoc_RF1_Num = -1 then
			COM.Parameters.AddWithValue("?P21",DBNull.Value)
		Else
			COM.Parameters.AddWithValue("?P21",m_int_HDoc_RF1_Num)
		End If
		If m_str_HDoc_RF1_Cod.ToUpper = "NULL" then
			COM.Parameters.AddWithValue("?P22",DBNull.Value)
		Else
			COM.Parameters.AddWithValue("?P22",m_str_HDoc_RF1_Cod)
		End If
		COM.Parameters.AddWithValue("?P23",m_obj_HDoc_RF1_Txt)
		If m_int_HDoc_RF2_Num = -1 then
			COM.Parameters.AddWithValue("?P24",DBNull.Value)
		Else
			COM.Parameters.AddWithValue("?P24",m_int_HDoc_RF2_Num)
		End If
		If m_str_HDoc_RF2_Cod.ToUpper = "NULL" then
			COM.Parameters.AddWithValue("?P25",DBNull.Value)
		Else
			COM.Parameters.AddWithValue("?P25",m_str_HDoc_RF2_Cod)
		End If
		COM.Parameters.AddWithValue("?P26",m_obj_HDoc_RF2_Txt)
		If m_str_HDoc_Usuario.ToUpper = "NULL" then
			COM.Parameters.AddWithValue("?P27",DBNull.Value)
		Else
			COM.Parameters.AddWithValue("?P27",m_str_HDoc_Usuario)
		End If
		If m_dt_HDoc_Pro_Fec.IsValidDateTime = False then
			COM.Parameters.AddWithValue("?P28",DBNull.Value)
		Else
			COM.Parameters.AddWithValue("?P28",m_dt_HDoc_Pro_Fec.value)
		End If
		If m_int_HDoc_Pro_DCat = -1 then
			COM.Parameters.AddWithValue("?P29",DBNull.Value)
		Else
			COM.Parameters.AddWithValue("?P29",m_int_HDoc_Pro_DCat)
		End If
		If m_int_HDoc_Pro_DAno = -1 then
			COM.Parameters.AddWithValue("?P30",DBNull.Value)
		Else
			COM.Parameters.AddWithValue("?P30",m_int_HDoc_Pro_DAno)
		End If
		If m_int_HDoc_Pro_DNum = -1 then
			COM.Parameters.AddWithValue("?P31",DBNull.Value)
		Else
			COM.Parameters.AddWithValue("?P31",m_int_HDoc_Pro_DNum)
		End If
		COM.Parameters.AddWithValue("?P32",m_dec_HDoc_Doc_TC)
		If m_int_HDoc_Doc_Mon = -1 then
			COM.Parameters.AddWithValue("?P33",DBNull.Value)
		Else
			COM.Parameters.AddWithValue("?P33",m_int_HDoc_Doc_Mon)
		End If
		COM.Parameters.AddWithValue("?P34",m_dec_HDoc_RF1_Dbl)
		COM.Parameters.AddWithValue("?P35",m_dec_HDoc_RF2_Dbl)
		COM.Parameters.AddWithValue("?P36",m_dec_HDoc_RF3_Dbl)
		If m_int_HDoc_Doc_Status = -1 then
			COM.Parameters.AddWithValue("?P37",DBNull.Value)
		Else
			COM.Parameters.AddWithValue("?P37",m_int_HDoc_Doc_Status)
		End If
		COM.Parameters.AddWithValue("?P1",m_int_HDoc_Sis_Emp)
		COM.Parameters.AddWithValue("?P2",m_int_HDoc_Doc_Cat)
		COM.Parameters.AddWithValue("?P3",m_int_HDoc_Doc_Ano)
		COM.Parameters.AddWithValue("?P4",m_int_HDoc_Doc_Num)
		COM.ExecuteNonQuery()
		COM.Dispose()
		COM = Nothing
		PUPDATE = True
	Catch MYEX As MySqlException
		MENSAJE = "BiblioTABLAS - TDCMTOS_HDR - PUPDATE MyError#=" & MYEX.Number & " MyError=" & MYEX.ToString
	Catch ex As Exception
		MENSAJE = "BiblioTABLAS - TDCMTOS_HDR - PUPDATE Error=" & ex.ToString
	Finally
		If IsNothing(COM) = False Then
			COM.Dispose()
			COM = Nothing
		End If
	End Try
End Function

Function PRECUPERA_REGISTRO() as DCMTOS_HDR
	Dim VAL as New DCMTOS_HDR
	VAL.HDOC_SIS_EMP = 0
	VAL.HDOC_DOC_CAT = 0
	VAL.HDOC_DOC_ANO = 0
	VAL.HDOC_DOC_NUM = 0
	Val.Simon_REGISTRO = False
	Val.MERROR = ""
	PRECUPERA_REGISTRO = VAL
	Try
			VAL.HDOC_SIS_EMP = HDOC_SIS_EMP
			VAL.HDOC_DOC_CAT = HDOC_DOC_CAT
			VAL.HDOC_DOC_ANO = HDOC_DOC_ANO
			VAL.HDOC_DOC_NUM = HDOC_DOC_NUM
			VAL.HDOC_DOC_FEC = HDOC_DOC_FEC
			VAL.HDOC_EMP_COD = HDOC_EMP_COD
			VAL.HDOC_EMP_NOM = HDOC_EMP_NOM
			VAL.HDOC_EMP_DIR = HDOC_EMP_DIR
			VAL.HDOC_EMP_PER = HDOC_EMP_PER
			VAL.HDOC_EMP_TEL = HDOC_EMP_TEL
			VAL.HDOC_EMP_NIT = HDOC_EMP_NIT
			VAL.HDOC_DR1_CAT = HDOC_DR1_CAT
			VAL.HDOC_DR1_NUM = HDOC_DR1_NUM
			VAL.HDOC_DR1_DBL = HDOC_DR1_DBL
			VAL.HDOC_DR1_FEC = HDOC_DR1_FEC
			VAL.HDOC_DR1_EMP = HDOC_DR1_EMP
			VAL.HDOC_DR2_CAT = HDOC_DR2_CAT
			VAL.HDOC_DR2_NUM = HDOC_DR2_NUM
			VAL.HDOC_DR2_FEC = HDOC_DR2_FEC
			VAL.HDOC_DR2_EMP = HDOC_DR2_EMP
			VAL.HDOC_RF1_NUM = HDOC_RF1_NUM
			VAL.HDOC_RF1_COD = HDOC_RF1_COD
			VAL.HDOC_RF1_TXT = HDOC_RF1_TXT
			VAL.HDOC_RF2_NUM = HDOC_RF2_NUM
			VAL.HDOC_RF2_COD = HDOC_RF2_COD
			VAL.HDOC_RF2_TXT = HDOC_RF2_TXT
			VAL.HDOC_USUARIO = HDOC_USUARIO
			VAL.HDOC_PRO_FEC = HDOC_PRO_FEC
			VAL.HDOC_PRO_DCAT = HDOC_PRO_DCAT
			VAL.HDOC_PRO_DANO = HDOC_PRO_DANO
			VAL.HDOC_PRO_DNUM = HDOC_PRO_DNUM
			VAL.HDOC_DOC_TC = HDOC_DOC_TC
			VAL.HDOC_DOC_MON = HDOC_DOC_MON
			VAL.HDOC_RF1_DBL = HDOC_RF1_DBL
			VAL.HDOC_RF2_DBL = HDOC_RF2_DBL
			VAL.HDOC_RF3_DBL = HDOC_RF3_DBL
			VAL.HDOC_DOC_STATUS = HDOC_DOC_STATUS
			VAL.Simon_REGISTRO = True
			PRECUPERA_REGISTRO = VAL
	Catch Ex as Exception
		MENSAJE = "BiblioTABLAS - TDCMTOS_HDR - PRECUPERA_REGISTRO Error=" & ex.ToString
	End Try
End Function

Function PPONE_REGISTRO(ByVal VAL As DCMTOS_HDR) as Boolean
	PPONE_REGISTRO = False
	Try
			HDOC_SIS_EMP = VAL.HDOC_SIS_EMP
			HDOC_DOC_CAT = VAL.HDOC_DOC_CAT
			HDOC_DOC_ANO = VAL.HDOC_DOC_ANO
			HDOC_DOC_NUM = VAL.HDOC_DOC_NUM
			HDOC_DOC_FEC = VAL.HDOC_DOC_FEC
			HDOC_EMP_COD = VAL.HDOC_EMP_COD
			HDOC_EMP_NOM = VAL.HDOC_EMP_NOM
			HDOC_EMP_DIR = VAL.HDOC_EMP_DIR
			HDOC_EMP_PER = VAL.HDOC_EMP_PER
			HDOC_EMP_TEL = VAL.HDOC_EMP_TEL
			HDOC_EMP_NIT = VAL.HDOC_EMP_NIT
			HDOC_DR1_CAT = VAL.HDOC_DR1_CAT
			HDOC_DR1_NUM = VAL.HDOC_DR1_NUM
			HDOC_DR1_DBL = VAL.HDOC_DR1_DBL
			HDOC_DR1_FEC = VAL.HDOC_DR1_FEC
			HDOC_DR1_EMP = VAL.HDOC_DR1_EMP
			HDOC_DR2_CAT = VAL.HDOC_DR2_CAT
			HDOC_DR2_NUM = VAL.HDOC_DR2_NUM
			HDOC_DR2_FEC = VAL.HDOC_DR2_FEC
			HDOC_DR2_EMP = VAL.HDOC_DR2_EMP
			HDOC_RF1_NUM = VAL.HDOC_RF1_NUM
			HDOC_RF1_COD = VAL.HDOC_RF1_COD
			HDOC_RF1_TXT = VAL.HDOC_RF1_TXT
			HDOC_RF2_NUM = VAL.HDOC_RF2_NUM
			HDOC_RF2_COD = VAL.HDOC_RF2_COD
			HDOC_RF2_TXT = VAL.HDOC_RF2_TXT
			HDOC_USUARIO = VAL.HDOC_USUARIO
			HDOC_PRO_FEC = VAL.HDOC_PRO_FEC
			HDOC_PRO_DCAT = VAL.HDOC_PRO_DCAT
			HDOC_PRO_DANO = VAL.HDOC_PRO_DANO
			HDOC_PRO_DNUM = VAL.HDOC_PRO_DNUM
			HDOC_DOC_TC = VAL.HDOC_DOC_TC
			HDOC_DOC_MON = VAL.HDOC_DOC_MON
			HDOC_RF1_DBL = VAL.HDOC_RF1_DBL
			HDOC_RF2_DBL = VAL.HDOC_RF2_DBL
			HDOC_RF3_DBL = VAL.HDOC_RF3_DBL
			HDOC_DOC_STATUS = VAL.HDOC_DOC_STATUS
			PPONE_REGISTRO = True
	Catch Ex as Exception
		MENSAJE = "BiblioTABLAS - TDCMTOS_HDR - PPONE_REGISTRO Error=" & ex.ToString
	End Try
End Function

Function PLLENA_COLECCION(ByRef COLECCION as Collection, ByVal CONDICION as String, Optional ByVal ORDENAMIENTO as String = "") as Boolean
	Dim CC as New Tablas.TDCMTOS_HDR
	Dim TEMPO as DCMTOS_HDR
	Dim Llave as String

	PLLENA_COLECCION = False
	Try
		If IsNothing(CON) = True Then
			Mensaje = "BiblioTABLAS - TDCMTOS_HDR - PLLENA_COLLECION Error = No se ha definido el String de Conexi�n a la base de datos."
			Exit Function
		End If

		CC.CONEXION = CONstr
		If CC.PSELECT_RECORDSET(CONDICION,ORDENAMIENTO) = False Then
			Mensaje = "BiblioTABLAS - TDCMTOS_HDR - PLLENA_COLLECION Error en Query = " & CC.MERROR
			Exit Function
		End If

		Do While CC.PMOVE_NEXT = True
			TEMPO = CC.PRECUPERA_REGISTRO
			Llave = TEMPO.HDoc_Sis_Emp.toString & "|" & TEMPO.HDoc_Doc_Cat.toString & "|" & TEMPO.HDoc_Doc_Ano.toString & "|" & TEMPO.HDoc_Doc_Num.toString
			COLECCION.Add(TEMPO,Llave)
		Loop
		PLLENA_COLECCION = True
	Catch EX as Exception
		MENSAJE="BiblioTABLAS - TDCMTOS_HDR - PLLENA_COLECCION Error=" & Ex.ToString
	Finally
		CC.Dispose()
		CC = Nothing
		Tempo = Nothing

		System.GC.Collect()
	End Try
End Function

Function POBTIENE_DEFAULT() as DCMTOS_HDR
	Dim VAL as New DCMTOS_HDR
	Val.Simon_REGISTRO = False
	Val.MERROR = ""
	POBTIENE_DEFAULT = VAL
	Try
			VAL.HDOC_SIS_EMP = 0
			VAL.HDOC_DOC_CAT = 0
			VAL.HDOC_DOC_ANO = 0
			VAL.HDOC_DOC_NUM = 0
			VAL.HDOC_DOC_FEC = New MySqlDateTime("2000-01-01")
			VAL.HDOC_EMP_COD = 0
			VAL.HDOC_EMP_NOM = "" 
			VAL.HDOC_EMP_DIR = "" 
			VAL.HDOC_EMP_PER = "" 
			VAL.HDOC_EMP_TEL = "" 
			VAL.HDOC_EMP_NIT = "" 
			VAL.HDOC_DR1_CAT = 0
			VAL.HDOC_DR1_NUM = "" 
			VAL.HDOC_DR1_DBL = 0D
			VAL.HDOC_DR1_FEC = new MysqlDateTime(0,0,0,0,0,0)
			VAL.HDOC_DR1_EMP = 0
			VAL.HDOC_DR2_CAT = 0
			VAL.HDOC_DR2_NUM = "" 
			VAL.HDOC_DR2_FEC = new MysqlDateTime(0,0,0,0,0,0)
			VAL.HDOC_DR2_EMP = 0
			VAL.HDOC_RF1_NUM = 0
			VAL.HDOC_RF1_COD = "" 
			VAL.HDOC_RF1_TXT = "" 
			VAL.HDOC_RF2_NUM = 0
			VAL.HDOC_RF2_COD = "" 
			VAL.HDOC_RF2_TXT = "" 
			VAL.HDOC_USUARIO = "" 
			VAL.HDOC_PRO_FEC = new MysqlDateTime(0,0,0,0,0,0)
			VAL.HDOC_PRO_DCAT = 0
			VAL.HDOC_PRO_DANO = 0
			VAL.HDOC_PRO_DNUM = 0
			VAL.HDOC_DOC_TC = 0D
			VAL.HDOC_DOC_MON = 0
			VAL.HDOC_RF1_DBL = 0D
			VAL.HDOC_RF2_DBL = 0D
			VAL.HDOC_RF3_DBL = 0D
			VAL.HDOC_DOC_STATUS = 0
			VAL.Simon_REGISTRO = True
			POBTIENE_DEFAULT = VAL
	Catch Ex as Exception
		MENSAJE = "BiblioTABLAS - TDCMTOS_HDR - POBTIENE_DEFAULT Error=" & ex.ToString
	End Try
End Function


#End REGION

End Class
End NameSpace
