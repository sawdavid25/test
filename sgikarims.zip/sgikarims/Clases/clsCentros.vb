Public Class clsCentros

#Region "Miembros"

    Public Enum TipoReset
        Full = 1
        Data = 2
    End Enum

    Public Structure CENTROS
        Dim Simon_REGISTRO As Boolean
        Dim MERROR As String
        Dim CEN_EMPRESA As Integer
        Dim CEN_CODIGO As Integer
        Dim CEN_DESCRIPCION As String
        Dim CEN_DIRECCION As String
        Dim CEN_MUNICIPIO As String
    End Structure

    Private m_int_cen_empresa As Integer
    Private m_int_cen_codigo As Integer
    Private m_str_cen_descripcion As String
    Private m_str_cen_direccion As String
    Private m_str_cen_municipio As String
    Private MENSAJE As String
    Private Cantidad_de_la_Clase As Integer = 0
    Private CON As MySqlConnection
    Private REA As MySqlDataReader
    Private CONstr As String
#End Region


#Region "Propiedades"

    Public Property CEN_EMPRESA() As Integer
        Get
            Return m_int_cen_empresa
        End Get
        Set(ByVal Value As Integer)
            m_int_cen_empresa = Value
        End Set
    End Property

    Public Property CEN_CODIGO() As Integer
        Get
            Return m_int_cen_codigo
        End Get
        Set(ByVal Value As Integer)
            m_int_cen_codigo = Value
        End Set
    End Property

    Public Property CEN_DESCRIPCION() As String
        Get
            Return m_str_cen_descripcion.Trim()
        End Get
        Set(ByVal Value As String)
            m_str_cen_descripcion = Value
        End Set
    End Property

    Public Property CEN_DIRECCION() As String
        Get
            Return m_str_cen_direccion.Trim()
        End Get
        Set(ByVal Value As String)
            m_str_cen_direccion = Value
        End Set
    End Property

    Public Property CEN_MUNICIPIO() As String
        Get
            Return m_str_cen_municipio.Trim()
        End Get
        Set(ByVal Value As String)
            m_str_cen_municipio = Value
        End Set
    End Property

    Public ReadOnly Property CantRecorSet() As Integer
        Get
            Return Cantidad_de_la_Clase
        End Get
    End Property

    Public Property CONEXION() As String
        Set(ByVal VALUE As String)
            CONstr = VALUE
            Try
                MENSAJE = ""
                If IsNothing(CON) = True Then
                    CON = New MySqlConnection
                End If
                If CON.State = ConnectionState.Open Then
                    CON.Close()
                End If
                CON.ConnectionString = CONstr
                CON.Open()
            Catch MyEX As MySqlException
                MENSAJE = "BiblioTABLAS - clsCentros - CONEXION MyError=" & MyEX.ToString
            Catch EX As Exception
                MENSAJE = "BiblioTABLAS - clsCentros - CONEXION Error=" & EX.ToString
            End Try
        End Set
        Get
            Return CONstr
        End Get
    End Property

    Public ReadOnly Property MERROR() As String
        Get
            Return MENSAJE
        End Get
    End Property

#End Region


#Region "Funciones Publicas"

    Public Sub New()
        CEN_EMPRESA = 0
        CEN_CODIGO = 0
        CEN_DESCRIPCION = ""
        CEN_DIRECCION = ""
        CEN_MUNICIPIO = ""
    End Sub

    Public Sub Reset(Optional ByVal Tipo As TipoReset = TipoReset.Data)
        Try
            INIT()
            If Tipo = clsCentros.TipoReset.Full Then
                Dispose()
            End If
        Catch Ex As Exception
            MENSAJE = "BiblioTABLAS - clsCentros - RESET No se podo hacer el Reset de la Clase" & Ex.ToString
        End Try
    End Sub

    Public Sub Dispose()
        Try
            If IsNothing(REA) = False Then
                REA.Close()
            End If
            If IsNothing(CON) = False Then
                If CON.State = ConnectionState.Open Then
                    CON.Close()
                End If
            End If
            CON = Nothing
            REA = Nothing
        Catch EX As Exception
        End Try
    End Sub

    Private Sub INIT()
        CEN_EMPRESA = 0
        CEN_CODIGO = 0
        CEN_DESCRIPCION = ""
        CEN_DIRECCION = ""
        CEN_MUNICIPIO = ""
        Cantidad_de_la_Clase = 0
    End Sub

    Public Function PMOVE_NEXT() As Boolean

        PMOVE_NEXT = False
        INIT()
        If IsNothing(REA) = True Then
            MENSAJE = "BiblioTABLAS - clsCentros - PMOVE_NEXT Conexi�n no definida"
            Exit Function
        End If
        Try
            If REA.Read = True Then
                If REA.IsDBNull(REA.GetOrdinal("cen_empresa")) = False Then
                    m_int_cen_empresa = REA.GetInt32("cen_empresa")
                Else
                    m_int_cen_empresa = -1
                End If
                If REA.IsDBNull(REA.GetOrdinal("cen_codigo")) = False Then
                    m_int_cen_codigo = REA.GetInt32("cen_codigo")
                Else
                    m_int_cen_codigo = -1
                End If
                If REA.IsDBNull(REA.GetOrdinal("cen_descripcion")) = False Then
                    m_str_cen_descripcion = REA.GetString("cen_descripcion")
                Else
                    m_str_cen_descripcion = "NULL"
                End If
                If REA.IsDBNull(REA.GetOrdinal("cen_direccion")) = False Then
                    m_str_cen_direccion = REA.GetString("cen_direccion")
                Else
                    m_str_cen_direccion = "NULL"
                End If
                If REA.IsDBNull(REA.GetOrdinal("cen_municipio")) = False Then
                    m_str_cen_municipio = REA.GetString("cen_municipio")
                Else
                    m_str_cen_municipio = "NULL"
                End If
                PMOVE_NEXT = True
            Else
                REA.Close()
                REA = Nothing
            End If
        Catch MYEX As MySqlException
            MENSAJE = "BiblioTABLAS - clsCentros - PMOVE_NEXT Error=" & MYEX.ToString
        Catch EX As Exception
            MENSAJE = "BiblioTABLAS - clsCentros - PMOVE_NEXT Error=" & EX.ToString
        End Try
    End Function

    Public Function PSELECT_RECORDSET(Optional ByVal CONDICION As String = "", Optional ByVal ORDENAMIENTO As String = "") As Boolean
        Dim COM As MySqlCommand
        Dim SQL As String
        Dim SQL1 As String

        PSELECT_RECORDSET = False
        If IsNothing(REA) = False Then
            REA.Close()
            REA = Nothing
        End If
        If IsNothing(CON) = True Then
            MENSAJE = "BiblioTABLAS - clsCentros - PSELECT_RECORDSET Conexi�n no definida"
            Exit Function
        End If
        If CON.State = ConnectionState.Closed Or CON.State = ConnectionState.Broken Then
            If CON.ConnectionString.Length <> 0 Then
                Try
                    CON.Open()
                Catch MYEX As MySqlException
                    MENSAJE = "BiblioTABLAS - TclsCentros - PSELECT_RECORDSET Error#=" & MYEX.Number & " " & MYEX.ToString
                    Exit Function
                Catch EX As Exception
                    MENSAJE = "BiblioTABLAS - TclsCentros - PSELECT_RECORDSET Error=" & EX.ToString
                    Exit Function
                End Try
            Else
                MENSAJE = "BiblioTABLAS - TclsCentros - PSELECT_RECORDSET String de Conexi�n no definido"
                Exit Function
            End If
        End If

        COM = Nothing
        SQL = "Select * from Centros"
        If CONDICION.Length <> 0 Then
            SQL &= " Where " & CONDICION
        End If
        If ORDENAMIENTO.Length <> 0 Then
            SQL &= " Order By " & ORDENAMIENTO
        End If

        SQL1 = "Select Count(*) as Cuenta from Centros"
        If CONDICION.Length <> 0 Then
            SQL1 &= " Where " & CONDICION
        End If
        Try
            INIT()
            COM = New MySqlCommand(SQL1, CON)
            Cantidad_de_la_Clase = CInt(COM.ExecuteScalar())
            COM.Dispose()
            COM = Nothing

            COM = New MySqlCommand(SQL, CON)
            COM.CommandType = CommandType.Text
            REA = COM.ExecuteReader
            PSELECT_RECORDSET = True
        Catch MYEX As MySqlException
            MENSAJE = "BiblioTABLAS - clsCentros - PSELECT_RECORDSET MyError#=" & MYEX.Number & " MyError=" & MYEX.ToString
        Catch EX As Exception
            MENSAJE = "BiblioTABLAS - clsCentros - PSELECT_RECORDSET Error=" & EX.ToString
        Finally
            If IsNothing(COM) = False Then
                COM.Dispose()
                COM = Nothing
            End If
        End Try
    End Function

    Public Function PSELECT_CONDICION(ByVal CONDICION As String) As Boolean

        Dim READER As MySqlDataReader
        Dim COM As MySqlCommand
        Dim SQL As String

        MENSAJE = ""
        PSELECT_CONDICION = False
        If IsNothing(CON) = True Then
            MENSAJE = "BiblioTABLAS - clsCentros - PSELECT_CONDICION Conexi�n no definida"
            Exit Function
        End If
        If CON.State = ConnectionState.Closed Or CON.State = ConnectionState.Broken Then
            If CON.ConnectionString.Length <> 0 Then
                Try
                    CON.Open()
                Catch MYEX As MySqlException
                    MENSAJE = "BiblioTABLAS - TclsCentros - PSELECT_CONDICION Error#=" & MYEX.Number & " " & MYEX.ToString
                    Exit Function
                Catch EX As Exception
                    MENSAJE = "BiblioTABLAS - TclsCentros - PSELECT_CONDICION Error=" & EX.ToString
                    Exit Function
                End Try
            Else
                MENSAJE = "BiblioTABLAS - TclsCentros - PSELECT_CONDICION String de Conexi�n no definido"
                Exit Function
            End If
        End If

        SQL = "SELECT * FROM Centros WHERE " & CONDICION
        READER = Nothing
        COM = Nothing
        Try
            INIT()
            COM = New MySqlCommand(SQL, CON)
            COM.CommandType = CommandType.Text
            READER = COM.ExecuteReader(CommandBehavior.SingleRow)
            READER.Read()
            If READER.HasRows = True Then
                If READER.IsDBNull(READER.GetOrdinal("cen_empresa")) = False Then
                    m_int_cen_empresa = READER.GetInt32("cen_empresa")
                Else
                    m_int_cen_empresa = -1
                End If
                If READER.IsDBNull(READER.GetOrdinal("cen_codigo")) = False Then
                    m_int_cen_codigo = READER.GetInt32("cen_codigo")
                Else
                    m_int_cen_codigo = -1
                End If
                If READER.IsDBNull(READER.GetOrdinal("cen_descripcion")) = False Then
                    m_str_cen_descripcion = READER.GetString("cen_descripcion")
                Else
                    m_str_cen_descripcion = "NULL"
                End If
                If READER.IsDBNull(READER.GetOrdinal("cen_direccion")) = False Then
                    m_str_cen_direccion = READER.GetString("cen_direccion")
                Else
                    m_str_cen_direccion = "NULL"
                End If
                If READER.IsDBNull(READER.GetOrdinal("cen_municipio")) = False Then
                    m_str_cen_municipio = READER.GetString("cen_municipio")
                Else
                    m_str_cen_municipio = "NULL"
                End If
                PSELECT_CONDICION = True
            Else
                MENSAJE = ""
                Exit Function
            End If
            READER.Close()
            COM.Dispose()
            READER = Nothing
            COM = Nothing
            PSELECT_CONDICION = True
        Catch MYEX As MySqlException
            MENSAJE = "BiblioTABLAS - clsCentros - PSELECT_CONDICION MyError#=" & MYEX.Number & " MyError=" & MYEX.ToString
        Catch EX As Exception
            MENSAJE = "BiblioTABLAS - clsCentros - PSELECT_CONDICION Error=" & EX.ToString
        Finally
            If IsNothing(READER) = False Then
                READER.Close()
                READER = Nothing
            End If
            If IsNothing(COM) = False Then
                COM.Dispose()
                COM = Nothing
            End If
        End Try
    End Function

    Public Function PSELECT_READER(ByRef READER As MySqlDataReader, _
                    Optional ByVal CAMPOS As String = "", _
                    Optional ByVal CONDICION As String = "", _
                    Optional ByVal ORDENAMIENTO As String = "") As Boolean

        Dim COM As MySqlCommand
        Dim SQL As String
        Dim SQL1 As String

        MENSAJE = ""
        PSELECT_READER = False
        If IsNothing(CON) = True Then
            MENSAJE = "BiblioTABLAS - clsCentros - PSELECT_READER Conexi�n no definida"
            Exit Function
        End If
        If CON.State = ConnectionState.Closed Or CON.State = ConnectionState.Broken Then
            If CON.ConnectionString.Length <> 0 Then
                Try
                    CON.Open()
                Catch MYEX As MySqlException
                    MENSAJE = "BiblioTABLAS - TclsCentros - PSELECT_READER Error#=" & MYEX.Number & " " & MYEX.ToString
                    Exit Function
                Catch EX As Exception
                    MENSAJE = "BiblioTABLAS - TclsCentros - PSELECT_READER Error=" & EX.ToString
                    Exit Function
                End Try
            Else
                MENSAJE = "BiblioTABLAS - TclsCentros - PSELECT_READER String de Conexi�n no definido"
                Exit Function
            End If
        End If

        If CAMPOS.Length = 0 Then
            SQL = "Select * from Centros"
        Else
            SQL = "SELECT " & CAMPOS & " FROM Centros"
        End If
        If CONDICION.Length <> 0 Then
            SQL &= " Where " & CONDICION
        End If
        If ORDENAMIENTO.Length <> 0 Then
            SQL &= " Order By " & ORDENAMIENTO
        End If

        SQL1 = "Select Count(*) as Cuenta from Centros"
        If CONDICION.Length <> 0 Then
            SQL1 &= " Where " & CONDICION
        End If

        READER = Nothing
        COM = Nothing
        Try
            INIT()
            COM = New MySqlCommand(SQL1, CON)
            Cantidad_de_la_Clase = CInt(COM.ExecuteScalar())
            COM.Dispose()
            COM = Nothing

            COM = New MySqlCommand(SQL, CON)
            COM.CommandType = CommandType.Text
            READER = COM.ExecuteReader()
            COM.Dispose()
            COM = Nothing
            PSELECT_READER = True
        Catch MYEX As MySqlException
            MENSAJE = "BiblioTABLAS - clsCentros - PSELECT_READER MyError#=" & MYEX.Number & " MyError=" & MYEX.ToString
        Catch EX As Exception
            MENSAJE = "BiblioTABLAS - clsCentros - PSELECT_READER Error=" & EX.ToString
        Finally
            If IsNothing(COM) = False Then
                COM.Dispose()
                COM = Nothing
            End If
        End Try
    End Function

    Function PRECUPERA_REGISTRO() As CENTROS
        Dim VAL As New CENTROS
        VAL.Simon_REGISTRO = False
        VAL.MERROR = ""
        PRECUPERA_REGISTRO = VAL
        Try
            VAL.CEN_EMPRESA = CEN_EMPRESA
            VAL.CEN_CODIGO = CEN_CODIGO
            VAL.CEN_DESCRIPCION = CEN_DESCRIPCION
            VAL.CEN_DIRECCION = CEN_DIRECCION
            VAL.CEN_MUNICIPIO = CEN_MUNICIPIO
            VAL.Simon_REGISTRO = True
            PRECUPERA_REGISTRO = VAL
        Catch Ex As Exception
            MENSAJE = "BiblioTABLAS - clsCentros - PRECUPERA_REGISTRO Error=" & Ex.ToString
        End Try
    End Function

    Function PPONE_REGISTRO(ByVal VAL As CENTROS) As Boolean
        PPONE_REGISTRO = False
        Try
            CEN_EMPRESA = VAL.CEN_EMPRESA
            CEN_CODIGO = VAL.CEN_CODIGO
            CEN_DESCRIPCION = VAL.CEN_DESCRIPCION
            CEN_DIRECCION = VAL.CEN_DIRECCION
            CEN_MUNICIPIO = VAL.CEN_MUNICIPIO
            PPONE_REGISTRO = True
        Catch Ex As Exception
            MENSAJE = "BiblioTABLAS - clsCentros - PPONE_REGISTRO Error=" & Ex.ToString
        End Try
    End Function

    Function PLLENA_COLECCION(ByRef COLECCION As Collection, ByVal CONDICION As String, Optional ByVal ORDENAMIENTO As String = "") As Boolean
        Dim CC As New clsCentros
        Dim TEMPO As CENTROS
        Dim Llave As String
        Dim Cuenta As Integer = 0

        PLLENA_COLECCION = False
        Try
            If IsNothing(CON) = True Then
                MENSAJE = "BiblioTABLAS - clsCentros - PLLENA_COLLECION Error = No se ha definido el String de Conexi�n a la base de datos."
                Exit Function
            End If

            CC.CONEXION = CONstr
            If CC.PSELECT_RECORDSET(CONDICION, ORDENAMIENTO) = False Then
                MENSAJE = "BiblioTABLAS - clsCentros - PLLENA_COLLECION Error en Query = " & CC.MERROR
                Exit Function
            End If

            Do While CC.PMOVE_NEXT = True
                TEMPO = CC.PRECUPERA_REGISTRO
                Cuenta += 1
                Llave = Cuenta.ToString

                COLECCION.Add(TEMPO, Llave)
            Loop
            PLLENA_COLECCION = True
        Catch EX As Exception
            MENSAJE = "BiblioTABLAS - clsCentros - PLLENA_COLECCION Error=" & EX.ToString
        Finally
            CC.Dispose()
            CC = Nothing
            TEMPO = Nothing

            System.GC.Collect()
        End Try
    End Function

    Function POBTIENE_DEFAULT() As CENTROS
        Dim VAL As New CENTROS
        VAL.Simon_REGISTRO = False
        VAL.MERROR = ""
        POBTIENE_DEFAULT = VAL
        Try
            VAL.CEN_EMPRESA = 0
            VAL.CEN_CODIGO = 0
            VAL.CEN_DESCRIPCION = ""
            VAL.CEN_DIRECCION = ""
            VAL.CEN_MUNICIPIO = ""
            VAL.Simon_REGISTRO = True
            POBTIENE_DEFAULT = VAL
        Catch Ex As Exception
            MENSAJE = "BiblioTABLAS - clsCentros - POBTIENE_DEFAULT Error=" & Ex.ToString
        End Try
    End Function


#End Region

End Class

