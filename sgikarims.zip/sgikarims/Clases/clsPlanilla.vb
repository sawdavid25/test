﻿Public Class clsPlanilla

#Region "Miembros"
    Dim Encabezado As New udtEncabezado
    Dim Detalle As New udtDetalle
    Dim DTLPro As New udtPro
    Dim intDsuspension As Integer
    Dim fecha_net_inicio As Date
    Dim fecha_net_fin As Date
    Dim intDlaborados As Integer
    Dim intIDContrato As Integer
    Dim dblBonificacion7879 As Double = 0.0
    Dim dblParqueo As Double = 0.0
    Dim intTMONEDA As Integer
    Dim strSuspendido As String
    Dim strDescripcion As String = STR_VACIO
#End Region

#Region "Estructuras"

    Private Structure udtEncabezado
        Const INT_CATALOGO As Integer = 882
        Dim intid As Integer
        Dim intAño As Integer
        Dim intEmpresa As Integer
        Dim ffecha As MySqlDateTime
        Dim fecha_net As Date
        Dim strCodigo As String
        Dim dblBonificacion As Double
        Dim dblTotal As Double
        Dim intMoneda As Integer
        Dim intTipo As Integer
        Dim strTipo As String
    End Structure

    Private Structure udtDetalle
        Dim intContrato As Integer
        Dim IntEmpleado As Integer
        Dim intPuesto As Integer
        Dim strEmpleado As String
        Dim strPuesto As String
        Dim dblSueldoBase As Double
        'Dim dblBonificacion As Double
        Dim dblBonificacion2 As Double
        Dim dblHorasExtra As Double
        Dim dblIGSS As Double
        Dim dblISR As Double
        Dim dblPrestamos As Double
        Dim dblAdelantos As Double
        Dim dblOtrosDescuentos As Double
        Dim dblSueldoLiquido As Double
    End Structure

    Private Structure udtPro
        Dim intIDContrato As Integer
        Const INT_CONTRATO As Integer = 436
        Dim intAñoContrato As Integer
    End Structure

#End Region

#Region "Propiedades "

    Public Property DSuspension As Integer
        Get
            Return intDsuspension
        End Get
        Set(value As Integer)
            intDsuspension = value
        End Set
    End Property

    Public Property Descripcion As String
        Get
            Return strDescripcion
        End Get
        Set(value As String)
            strDescripcion = value
        End Set
    End Property

    Public Property ParqueoP As Double
        Get
            Return dblParqueo
        End Get
        Set(value As Double)
            dblParqueo = value
        End Set
    End Property

    Public Property FechaInicioP As Date
        Get
            Return fecha_net_inicio
        End Get
        Set(value As Date)
            fecha_net_inicio = value
        End Set
    End Property

    Public Property FechaFinP As Date
        Get
            Return fecha_net_fin
        End Get
        Set(value As Date)
            fecha_net_fin = value
        End Set
    End Property

    Public Property DLaborados As Integer
        Get
            Return intDlaborados
        End Get
        Set(value As Integer)
            intDlaborados = value
        End Set
    End Property

    Public Property PIDContrato As Integer
        Get
            Return intIDContrato
        End Get
        Set(value As Integer)
            intIDContrato = value
        End Set
    End Property


    Public ReadOnly Property Catalogo As Integer
        Get
            Return udtEncabezado.INT_CATALOGO
        End Get
    End Property

    Public Property ID As Integer
        Get
            Return Encabezado.intid
        End Get
        Set(value As Integer)
            Encabezado.intid = value
        End Set
    End Property

    Public Property B7978 As Double
        Get
            Return dblBonificacion7879
        End Get
        Set(value As Double)
            dblBonificacion7879 = value
        End Set
    End Property

    Public Property Año As Integer
        Get
            Return Encabezado.intAño
        End Get
        Set(value As Integer)
            Encabezado.intAño = value
        End Set
    End Property

    Public Property Empresa As Integer
        Get
            Return Encabezado.intEmpresa
        End Get
        Set(value As Integer)
            Encabezado.intEmpresa = value
        End Set
    End Property

    Public Property Fecha As MySqlDateTime
        Get
            Return Encabezado.ffecha
        End Get
        Set(value As MySqlDateTime)
            Encabezado.ffecha = value
        End Set
    End Property

    Public Property Codigo As String
        Get
            Return Encabezado.strCodigo
        End Get
        Set(value As String)
            Encabezado.strCodigo = value
        End Set
    End Property

    Public Property TotalPlanilla As Double
        Get
            Return Encabezado.dblTotal
        End Get
        Set(value As Double)
            Encabezado.dblTotal = value
        End Set
    End Property

    Public Property MonedaPlanilla As Integer
        Get
            Return Encabezado.intMoneda
        End Get
        Set(value As Integer)
            Encabezado.intMoneda = value
        End Set
    End Property

    Public Property IDTipo As Integer
        Get
            Return Encabezado.intTipo
        End Get
        Set(value As Integer)
            Encabezado.intTipo = value
        End Set
    End Property

    Public Property TipoPlanilla As String
        Get
            Return Encabezado.strTipo
        End Get
        Set(value As String)
            Encabezado.strTipo = value
        End Set
    End Property

    ''**DETALLE...

    Public Property IDContrato As Integer
        Get
            Return Detalle.intContrato
        End Get
        Set(value As Integer)
            Detalle.intContrato = value
        End Set
    End Property

    Public Property IDEmpleado As Integer
        Get
            Return Detalle.IntEmpleado
        End Get
        Set(value As Integer)
            Detalle.IntEmpleado = value
        End Set
    End Property

    Public Property IDPuesto As Integer
        Get
            Return Detalle.intPuesto
        End Get
        Set(value As Integer)
            Detalle.intPuesto = value
        End Set
    End Property

    Public Property Empleado As String
        Get
            Return Detalle.strEmpleado
        End Get
        Set(value As String)
            Detalle.strEmpleado = value
        End Set
    End Property

    Public Property Puesto As String
        Get
            Return Detalle.strPuesto
        End Get
        Set(value As String)
            Detalle.strPuesto = value
        End Set
    End Property

    Public Property SueldoBase As Double
        Get
            Return Detalle.dblSueldoBase
        End Get
        Set(value As Double)
            Detalle.dblSueldoBase = value
        End Set
    End Property

    Public Property Bonificacion As Double
        Get
            Return Encabezado.dblBonificacion
        End Get
        Set(value As Double)
            Encabezado.dblBonificacion = value
        End Set
    End Property

    Public Property Bonificacion2 As Double
        Get
            Return Detalle.dblBonificacion2
        End Get
        Set(value As Double)
            Detalle.dblBonificacion2 = value
        End Set
    End Property

    Public Property HorasExtra As Double
        Get
            Return Detalle.dblHorasExtra
        End Get
        Set(value As Double)
            Detalle.dblHorasExtra = value
        End Set
    End Property

    Public Property IGSS As Double
        Get
            Return Detalle.dblIGSS
        End Get
        Set(value As Double)
            Detalle.dblIGSS = value
        End Set
    End Property

    Public Property ISR As Double
        Get
            Return Detalle.dblISR
        End Get
        Set(value As Double)
            Detalle.dblISR = value
        End Set
    End Property

    Public Property Prestamos As Double
        Get
            Return Detalle.dblPrestamos
        End Get
        Set(value As Double)
            Detalle.dblPrestamos = value
        End Set
    End Property

    Public Property Adelantos As Double
        Get
            Return Detalle.dblAdelantos
        End Get
        Set(value As Double)
            Detalle.dblAdelantos = value
        End Set
    End Property

    Public Property OtrosDescuentos As Double
        Get
            Return Detalle.dblOtrosDescuentos
        End Get
        Set(value As Double)
            Detalle.dblOtrosDescuentos = value
        End Set
    End Property

    Public Property SueldoLiquido As Double
        Get
            Return Detalle.dblSueldoLiquido
        End Get
        Set(value As Double)
            Detalle.dblSueldoLiquido = value
        End Set
    End Property

    ''PRO
    Public Property Suspendido As String
        Get
            Return strSuspendido
        End Get
        Set(value As String)
            strSuspendido = value
        End Set
    End Property


    Public Property ContratoID As Integer
        Get
            Return DTLPro.intIDContrato
        End Get
        Set(value As Integer)
            DTLPro.intIDContrato = value
        End Set
    End Property

    Public Property ContratoAño As Integer
        Get
            Return DTLPro.intAñoContrato
        End Get
        Set(value As Integer)
            DTLPro.intAñoContrato = value
        End Set
    End Property

    Public Property TMONEDA As Integer
        Get
            Return intTMONEDA
        End Get
        Set(value As Integer)
            intTMONEDA = value
        End Set
    End Property


#End Region

#Region "Funciones Públicas"

    Public Function CodigoPlanilla() As String
        CodigoPlanilla = STR_VACIO
        Dim strSQL As String
        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader
        Dim strCod As String = STR_VACIO
        Dim strAño As String = STR_VACIO
        Dim strMes As String = STR_VACIO
        strSQL = "Select Count(*)+1 as Cuenta from Dcmtos_HDR " & _
            " where HDoc_Doc_Cat = {cat} and month(HDoc_Doc_Fec) = month(now()) and HDoc_Doc_Ano= year(now())"
        strSQL = Replace(strSQL, "{cat}", udtEncabezado.INT_CATALOGO)
        Try
            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSQL, CON)
            ' REA = COM.ExecuteReader
            'REA.Read()
            'strCod = REA.GetInt32("Cuenta")
            strCod = COM.ExecuteScalar.ToString
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        strSQL = "select year(now()) ano, month(now()) mes"
        strSQL = Replace(strSQL, "{COD}", strCod)
        Try
            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSQL, CON)
            REA = COM.ExecuteReader
            REA.Read()
            strAño = REA.GetInt32("ano").ToString
            strMes = REA.GetInt32("mes").ToString
            If strMes.Length = 1 Then
                strMes = "0" & strMes
            End If
            If strCod.Length = 1 Then
                strCod = "0" & strCod
            End If
            CodigoPlanilla = strAño & strMes & strCod
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Function

    Public Sub New()
        Encabezado.ffecha = New MySqlDateTime(0, 0, 0, 0, 0, 0)
        Encabezado.intAño = NO_FILA
        Encabezado.intEmpresa = NO_FILA
        Encabezado.intid = NO_FILA
        Encabezado.strCodigo = STR_VACIO
        Encabezado.intTipo = NO_FILA
        Encabezado.strTipo = STR_VACIO
        Detalle.intContrato = NO_FILA
        Detalle.strEmpleado = STR_VACIO
        Detalle.strPuesto = STR_VACIO
        Detalle.dblSueldoBase = INT_CERO
        Encabezado.dblBonificacion = INT_CERO
        Detalle.dblBonificacion2 = INT_CERO
    End Sub

    Public Function GuardarEncabezado() As Boolean
        GuardarEncabezado = False
        Dim HDR As New clsDcmtos_HDR
        Try
            Encabezado.intEmpresa = Sesion.IdEmpresa
            Encabezado.intAño = cFunciones.AñoMySQL
            Encabezado.intid = cFunciones.NuevoId(udtEncabezado.INT_CATALOGO)
            Encabezado.fecha_net = cFunciones.HoyMySQL
            Encabezado.strCodigo = CodigoPlanilla()
            HDR.HDOC_SIS_EMP = Encabezado.intEmpresa
            HDR.HDOC_DOC_CAT = udtEncabezado.INT_CATALOGO
            HDR.HDOC_DOC_MON = intTMONEDA
            HDR.HDOC_DOC_ANO = Encabezado.intAño
            HDR.HDOC_DOC_NUM = Encabezado.intid
            HDR.HDoc_Doc_Fec_NET = Encabezado.fecha_net
            HDR.HDoc_DR2_Fec_NET = fecha_net_fin
            HDR.HDoc_DR1_Fec_NET = fecha_net_inicio
            HDR.HDOC_EMP_PER = Encabezado.strCodigo
            HDR.HDOC_EMP_NOM = strDescripcion
            HDR.HDOC_DR1_DBL = Encabezado.dblBonificacion
            HDR.HDOC_USUARIO = Sesion.Usuario
            HDR.HDOC_DR1_CAT = Encabezado.intTipo
            HDR.HDOC_DR1_NUM = Encabezado.strTipo
            HDR.HDOC_DOC_MON = Encabezado.intMoneda
            HDR.HDOC_RF1_DBL = Encabezado.dblTotal
            HDR.CONEXION = strConexion
            If HDR.Guardar = True Then
                GuardarEncabezado = True
            Else
                MsgBox(HDR.MERROR.ToString)
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Function


    Public Function GuardarDetalle(ByVal intLinea As Integer) As Boolean
        GuardarDetalle = False
        Dim DTL As New clsDcmtos_DTL
        Try
            DTL.CONEXION = strConexion
            DTL.DDOC_SIS_EMP = Sesion.IdEmpresa
            DTL.DDOC_DOC_CAT = udtEncabezado.INT_CATALOGO
            DTL.DDOC_DOC_ANO = cFunciones.AñoMySQL
            DTL.DDOC_DOC_NUM = Encabezado.intid
            DTL.DDOC_DOC_LIN = intLinea
            DTL.DDOC_PRD_PNR = "EMPLEADO"
            DTL.DDOC_PRD_DES = Detalle.strEmpleado
            DTL.DDOC_PRD_UM = Detalle.IntEmpleado
            DTL.DDOC_PRD_PUQ = Detalle.dblSueldoBase
            DTL.DDOC_PRD_DSP = dblParqueo
            DTL.DDOC_PRD_DSQ = Detalle.dblBonificacion2
            DTL.DDOC_PRD_NET = Detalle.dblHorasExtra
            DTL.DDOC_RF2_COD = strSuspendido
            DTL.DDOC_PRD_QTY = Detalle.dblIGSS
            DTL.DDOC_RF1_DBL = Detalle.dblISR
            DTL.DDOC_RF2_NUM = intDsuspension
            DTL.DDOC_RF3_NUM = intDlaborados
            DTL.DDOC_RF2_DBL = Detalle.dblPrestamos
            DTL.DDOC_RF3_DBL = Detalle.dblAdelantos
            DTL.DDOC_PRD_FOB = Detalle.dblOtrosDescuentos
            DTL.DDOC_RF1_NUM = Detalle.intPuesto
            DTL.DDOC_RF1_COD = Detalle.strPuesto
            DTL.DDOC_PRD_CIF = dblBonificacion7879
            DTL.DDOC_PRD_REF = Encabezado.strCodigo
            DTL.CONEXION = strConexion
            'Detalle.dblSueldoLiquido
            If DTL.Guardar = True Then
                If GuardarPro(intLinea) = True Then
                    GuardarDetalle = True
                End If
            Else
                MsgBox(DTL.MERROR.ToString)
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Function

    Public Function BorrarDetalle() As Boolean
        BorrarDetalle = False
        Dim cDetalle As New clsDcmtos_DTL
        Dim strCondicion As String = STR_VACIO
        strCondicion = "DDoc_Sis_Emp = {empresa} and DDoc_Doc_Cat = {catalogo} and DDoc_Doc_Num ={id}" & _
            " and DDoc_Doc_Ano = {año}"
        strCondicion = Replace(strCondicion, "{empresa}", Sesion.IdEmpresa)
        strCondicion = Replace(strCondicion, "{catalogo}", udtEncabezado.INT_CATALOGO)
        strCondicion = Replace(strCondicion, "{id}", Encabezado.intid)
        strCondicion = Replace(strCondicion, "{año}", Encabezado.intAño)
        Try
            cDetalle.CONEXION = strConexion
            If cDetalle.Borrar(strCondicion) = True Then
                BorrarDetalle = True
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Function

    Public Function BorrarEncabezado() As Boolean
        BorrarEncabezado = False
        Dim cEncabezado As New clsDcmtos_HDR
        Dim strCondicion As String = STR_VACIO
        strCondicion = "HDoc_Sis_Emp = {empresa} and HDoc_Doc_Cat = {catalogo} and HDoc_Doc_Num ={id}" & _
            " and HDoc_Doc_Ano = {año}"
        strCondicion = Replace(strCondicion, "{empresa}", Sesion.IdEmpresa)
        strCondicion = Replace(strCondicion, "{catalogo}", udtEncabezado.INT_CATALOGO)
        strCondicion = Replace(strCondicion, "{id}", Encabezado.intid)
        strCondicion = Replace(strCondicion, "{año}", Encabezado.intAño)
        Try
            cEncabezado.CONEXION = strConexion
            If cEncabezado.Borrar(strCondicion) = True Then
                BorrarEncabezado = True
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Function

    Private Function GuardarPro(ByVal intLinea As Integer) As Boolean
        GuardarPro = False
        Dim PRO As New clsDcmtos_DTL_Pro
        Try
            PRO.CONEXION = strConexion
            PRO.PDOC_SIS_EMP = Sesion.IdEmpresa
            PRO.PDOC_PAR_CAT = udtPro.INT_CONTRATO
            PRO.PDOC_PAR_ANO = DTLPro.intAñoContrato
            PRO.PDOC_PAR_LIN = intLinea
            PRO.PDOC_PAR_NUM = intIDContrato
            PRO.PDOC_CHI_ANO = Encabezado.intAño
            PRO.PDOC_CHI_CAT = udtEncabezado.INT_CATALOGO
            PRO.PDOC_CHI_NUM = Encabezado.intid
            PRO.PDOC_CHI_LIN = intLinea
            If PRO.Guardar = False Then
                MsgBox("Tabla Dcmtos_DTL_Pro -> Error al guardar relaciones" & PRO.MERROR.ToString, MsgBoxStyle.Critical)
            Else
                GuardarPro = True
            End If
        Catch ex As Exception
            MsgBox(ex, TotalPlanilla)
        End Try
    End Function

    Public Function BorrarPro() As Boolean
        BorrarPro = False
        Dim DTlPro As New clsDcmtos_DTL_Pro
        Dim strCondicion As String = STR_VACIO
        strCondicion = "PDoc_chi_Cat ={Planilla}  and PDoc_Chi_Ano={añoPlanilla} and " & _
            " PDoc_Chi_Num = {idPlanilla} and PDoc_Sis_Emp = {empresa} and Pdoc_par_Cat = {Contrato}"
        strCondicion = Replace(strCondicion, "{Planilla}", udtEncabezado.INT_CATALOGO)
        strCondicion = Replace(strCondicion, "{añoPlanilla}", Encabezado.intAño)
        strCondicion = Replace(strCondicion, "{idPlanilla}", Encabezado.intid)
        strCondicion = Replace(strCondicion, "{empresa}", Sesion.IdEmpresa)
        strCondicion = Replace(strCondicion, "{Contrato}", udtPro.INT_CONTRATO)

        Try
            DTlPro.CONEXION = strConexion
            If DTlPro.Borrar(strCondicion) = True Then
                BorrarPro = True
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Function

#End Region

End Class
