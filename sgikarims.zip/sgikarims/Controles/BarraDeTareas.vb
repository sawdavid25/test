﻿Public Class BarraDeTareas
    Public Event SelecionarPestaña(ByVal sender As System.Object, ByVal click As Boolean)

    Private Sub TabControl1_Selecting(sender As Object, e As TabControlCancelEventArgs) Handles TabControl1.Selecting
        RaiseEvent SelecionarPestaña(Me, True)
    End Sub

    Public Sub AgregarFormulario(ByVal key As String, ByVal Text As String)
        Try
            If ComprobarsiExite(key) = True Then
                TabControl1.TabPages.Add(key, Text)
                TabControl1.SelectedTab = TabControl1.TabPages(key)
                AddHandler TabControl1.TabPages(key).Click, AddressOf TabControl1_Selecting
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Public Sub QuitarFormulario(ByVal key As String)
        Dim tab As New TabPage
        Dim x As Integer = 0
        If Not key = STR_VACIO Then
            Try
                If ComprobarsiExite(key) = False Then
                    tab = TabControl1.TabPages(key)
                    TabControl1.TabPages.Remove(tab)
                End If
            Catch ex As Exception
                '  MsgBox(ex.ToString)
            End Try
            
        End If
    End Sub

    Private Function ComprobarsiExite(ByVal key As String) As Boolean
        ComprobarsiExite = False
        For i As Integer = 0 To TabControl1.TabCount - 1
            If TabControl1.TabPages(i).Name = key Then
                Exit Function
            End If
        Next
        ComprobarsiExite = True
    End Function

End Class
