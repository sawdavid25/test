﻿Public Class usrBancoDocumento
    'Modificado: 2019-09-22

    'Variables privadas
    Private intItem As Integer = INT_CERO
    Private intMonedaLocal As Integer = INT_CERO
    Private intMonedaExterna As Integer = INT_CERO
    Private logLocal As Boolean = False

    Private intEntidad As Integer = INT_CERO
    Private strOpciones As String = String.Empty
    Private strSimboloMoneda As String

    Private Base As New clsBancos
    Private Relacion As New clsBancos.DatoRelacion
    Private Presupuesto As New List(Of clsBancos.DatoLista)
    Private cfun As New clsFunciones

    'Constantes privadas
    Private Const ES_RESERVA As Integer = INT_CERO
    Private Const ES_PAGADO As Integer = 1
    Private Const Es_RECHAZADO As Integer = 2

    Private Const STR_RESERVA As String = STR_VACIO
    Private Const STR_PAGADO As String = "Cashed"
    Private Const STR_RECHAZADO As String = "Rejected"

    Private Const STR_NO_NEGOCIABLE As String = "-NO NEGOCIABLE-"

    Private Const STR_CHEQUE As String = "CHEQUE"
    Private Const STR_CAJA As String = "CAJA"
    Private Const STR_COMPRA As String = "COMPRA"
    Private Const STR_VENTA As String = "VENTA"
    Private Const STR_CUENTA As String = "CUENTA"
    Private Const STR_RETENCION As String = "RETENCION"
    Private Const STR_DEBITO As String = "NOTA DEBITO"

    'Datos del documento: tipo de documento, año, numero, tipo de subdocumento, grupo, id de cuenta y moneda
    Public Property Tipo As Integer = INT_CERO
    Public Property Ciclo As Integer = INT_CERO
    Public Property Numero As Integer = INT_CERO
    Public Property Documento As Integer = INT_CERO
    Public Property Grupo As Integer = INT_CERO
    Public Property Cuenta As Integer = INT_CERO
    Public Property Moneda As Integer = INT_CERO
    Public Property Nota_ As String = STR_VACIO

    Public ReadOnly Property EsNuevo As Boolean = True
    Public ReadOnly Property Modificado As Boolean = False

    Public Property Titulo As String = "Document"
    Private logInsertar As Boolean = False
    Private logConsultar As Boolean = False
    Private logEditar As Boolean = False
    Private logBorrar As Boolean = False


    'Cargar documento
    Public Sub CargarDocumento()
        _EsNuevo = True
        _Modificado = False
        If Not Numero.Equals(INT_CERO) Then
            _EsNuevo = False
        End If

        Cursor.Current = Cursors.AppStarting
        LimpiarDocumento()
        MostrarPaneles()
        If EsNuevo Then
            EtiquetaID.Text = "Nuevo"

            'Número para cheques nuevos
            If Tipo.Equals(Base.IdCheque) Then
                CeldaNumero.Text = NuevoCheque()
            End If
        Else
            Cursor.Current = Cursors.WaitCursor
            CargarDatos()
        End If
        _Titulo = Base.TextoDeGrupo(Grupo).ToUpper & Space(1) & Base.TextoDeTipo(Tipo).ToUpper

        ActualizarTotalLetras()
    End Sub

    'Recupera el numero de cheque de la tabla Catalogos y le suma 1
    Private Function NuevoCheque() As String
        Dim strSQL As String = "SELECT CAST(LPAD(ROUND(cc.cat_desc),8,0) AS CHAR) Cheque FROM Catalogos cc WHERE cc.cat_clase='Cheques' AND cc.cat_clave='Max_Num' AND cc.cat_sist=@cuenta LIMIT 1"
        Dim obj As Object
        Dim s As String = "00000000"

        'Recuperar el ultimo cheque de la chequera
        MyCnn.CONECTAR = strConexion

        Using cmd As New MySqlCommand(strSQL, CON)
            cmd.Parameters.AddWithValue("@cuenta", Cuenta)
            obj = cmd.ExecuteScalar
            If obj IsNot Nothing Then
                s = obj.ToString()
            End If
        End Using

        strSQL = "SELECT CAST(LPAD(COALESCE(MAX(CAST(HDoc_DR1_Num AS SIGNED)),0) + 1,8,'0') AS CHAR) Numero
                  FROM Dcmtos_HDR
                  WHERE HDoc_Sis_Emp=@empresa AND HDoc_Doc_Cat=@tipo AND HDoc_RF1_Num=@id"
        If Val(s) > INT_CERO Then
            strSQL &= " AND CAST(HDoc_DR1_Num AS SIGNED)<@maximo"
        End If
        MyCnn.CONECTAR = strConexion
        Using cmd As New MySqlCommand(strSQL, CON)
            cmd.Parameters.AddWithValue("@empresa", Sesion.IdEmpresa)
            cmd.Parameters.AddWithValue("@tipo", Base.IdCheque)
            cmd.Parameters.AddWithValue("@id", _Cuenta)
            cmd.Parameters.AddWithValue("@maximo", CLng(s))
            obj = cmd.ExecuteScalar
            If obj IsNot Nothing Then
                s = obj.ToString()
            End If
        End Using
        Return s
    End Function

    'Limpiar los datos del documento
    Private Sub LimpiarDocumento()
        Dim strSQL As String = String.Empty
        Dim strTemp As String = String.Empty

        Presupuesto = New List(Of clsBancos.DatoLista)
        If Base.IdDeposito.Equals(INT_CERO) Then
            Base.CargarTipos()
        End If

        'Ocultar paneles
        GrupoEmpresa.Enabled = True
        GrupoDeposito.Visible = False
        GrupoCuenta.Visible = False
        PanelCheques.Visible = False
        PanelCompras.Visible = False
        PanelVentas.Visible = False
        PanelCaja.Visible = False
        Grupo1.Visible = True
        Grupo2.Visible = True
        Grupo3.Visible = True
        'system.Windows.Forms.Application.DoEvents()

        'Limpiar controles de encabezado
        CeldaDocumento.Text = String.Empty
        CeldaNumero.Text = String.Empty
        CeldaConcepto.Text = String.Empty
        CeldaReferencia.Text = String.Empty
        CeldaNotas.Text = String.Empty
        Fecha.Value = Today.Date
        CeldaMonto.Text = INT_CERO.ToString("f")
        CeldaTasa.Text = INT_CERO.ToString("f")
        CeldaGastos.Text = INT_CERO.ToString("f")
        CasillaSecreto.Checked = False
        CasillaRevisado.Checked = False
        CasillaProveedores.Checked = False
        CasillaProveedores.Enabled = False
        CasillaProveedores.ForeColor = SystemColors.WindowText
        CasillaExterna.Checked = False
        CasillaExterna.Enabled = False

        'Por defecto la casilla de cobrado es verdadera 
        CasillaCobrado.Checked = True
        CasillaCobrado.Visible = False

        CasillaAnulado.Checked = False
        CasillaAnulado.Enabled = False
        CasillaAnulado.Text = "Rejected"

        CeldaReferencia.BackColor = SystemColors.Window
        CeldaReferencia.ForeColor = SystemColors.WindowText

        'Celdas de deposito y ventas
        CeldaEfectivo.Text = INT_CERO.ToString("f")
        CeldaCheques.Text = INT_CERO.ToString("f")
        CeldaOtrosBancos.Text = INT_CERO.ToString("f")
        CeldaTotalDeposito.Text = INT_CERO.ToString("f")
        CeldaTotalCompra.Text = INT_CERO.ToString("f")
        CeldaAnticipo.Text = INT_CERO.ToString("f")
        CeldaTotalVenta.Text = INT_CERO.ToString("f")
        CeldaDiferencia.Text = INT_CERO.ToString("f")
        CeldaTotalCaja.Text = INT_CERO.ToString("f")

        'Celdas de cuenta contable
        CeldaCuenta.Text = String.Empty
        CeldaCuentaNombre.Text = String.Empty

        'Deshabilitar botones
        BotonDocumento.Enabled = False
        BotonBuscar.Enabled = True
        BotonPresupuesto.Enabled = False
        BotonPoliza.Enabled = True

        'Recuperar ID de moneda local
        intMonedaLocal = Base.ObtenerIdMonedaLocal
        intMonedaExterna = Base.ObtenerIdMonedaExterna
        If Moneda.Equals(intMonedaLocal) Then
            strSQL = "SELECT cat_clave FROM Catalogos WHERE cat_clase='Monedas' AND cat_num={id} LIMIT 1".Replace("{id}", intMonedaExterna)
            MyCnn.CONECTAR = strConexion
            Using cmd As New MySqlCommand(strSQL, CON)
                strTemp = cmd.ExecuteScalar.ToString
            End Using
            EtiquetaTasa.Text = strTemp & " Ex. Rate"
            CeldaTasa.ForeColor = Color.DarkGreen
            logLocal = True
        Else
            EtiquetaTasa.Text = "Exchange Rate"
            CeldaTasa.ForeColor = SystemColors.WindowText
        End If

        'Limpiar variables de relacion
        intEntidad = INT_CERO
        With Relacion
            .Tipo = INT_CERO
            .Ciclo = INT_CERO
            .Numero = INT_CERO

        End With
        EtiquetaCajaFecha.Text = String.Empty

        'Limpiar controles de persona / empresa
        CeldaID.Text = INT_CERO.ToString
        CeldaEmpresa.Text = String.Empty
        CeldaPersona.Text = String.Empty
        Referencia.Text = String.Empty
        EtiquetaLetras.Text = String.Empty

        'Limpiar detalles
        Cheques.Rows.Clear()
        Compras.Rows.Clear()
        Ventas.Rows.Clear()
        Caja.Rows.Clear()

        'Actualizar titulo de total y columna total (ventas)
        strSQL = "SELECT cat_clave FROM Catalogos WHERE cat_num={id}".Replace("{id}", Moneda)
        MyCnn.CONECTAR = strConexion
        Using cmd As New MySqlCommand(strSQL, CON)
            strSimboloMoneda = Convert.ToString(cmd.ExecuteScalar)
        End Using

        EtiquetaMonto.Text = "Amount {s}".Replace("{s}", strSimboloMoneda)
        Ventas.Columns(venta_total.Index).HeaderText = "Amount in {s}".Replace("{s}", strSimboloMoneda)
        Compras.Columns(compra_monto.Index).HeaderText = "Amount in {s}".Replace("{s}", strSimboloMoneda)

        If EsNuevo Then
            If Documento.Equals(INT_CERO) Then
                BotonDocumento.Enabled = True
            Else
                strSQL = "SELECT cat_desc FROM Catalogos WHERE cat_num={id} LIMIT 1".Replace("{id}", Documento)
                MyCnn.CONECTAR = strConexion
                Using cmd As New MySqlCommand(strSQL, CON)
                    CeldaDocumento.Text = cmd.ExecuteScalar
                End Using
            End If

            CeldaTasa.Text = cFunciones.QueryTasa().ToString("f4")
            intItem = NO_FILA
        Else
            'Recuperar grupo e item
            strSQL = Base.SQLObtenerDocumentoGrupo(Tipo, Ciclo, Numero)
            MyCnn.CONECTAR = strConexion
            Using cmd As New MySqlCommand(strSQL, CON)
                Using sda As New MySqlDataAdapter(cmd)
                    Dim dt As New System.Data.DataTable
                    Dim dr As DataRow
                    sda.Fill(dt)
                    If dt.Rows.Count > 0 Then
                        dr = dt.Rows(0)
                        Grupo = CInt(dr("grupo"))
                        intItem = CInt(dr("item"))
                    End If
                End Using
            End Using
        End If

        'Documentos de Débito

        Select Case Tipo
            Case Base.IdCheque, Base.IdDebito
                'Habilitar presupuesto para Cheque y Débito
                BotonPresupuesto.Enabled = True

                CasillaCobrado.Checked = False
                CasillaCobrado.Visible = True

                'Sólo Cheques
                If Tipo.Equals(Base.IdCheque) Then
                    CeldaReferencia.BackColor = Color.AliceBlue
                    CeldaReferencia.ForeColor = Color.Blue
                    CeldaReferencia.Text = STR_NO_NEGOCIABLE

                    CasillaAnulado.Enabled = True
                    CasillaAnulado.Text = "Voided"
                End If
        End Select

        If Grupo.Equals(clsBancos.BancoGrupo.Impuestos) Then
            CeldaPersona.Text = "PAGO DE IMPUESTOS"
        End If

        'Transacciones disponibles para el grupo
        strOpciones = ListaDeItems(Grupo, intItem)

        'Formato de columnas
        FormatoDeColumnas()
        EtiquetaLetras.Text = String.Empty
    End Sub

    'Dar formato a columnas de detalles
    Private Sub FormatoDeColumnas()
        Cheques.SuspendLayout()
        Cheques.Rows.Clear()
        Cheques.Columns(cheque_fecha.Index).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter
        Cheques.Columns(cheque_numero.Index).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter
        Cheques.Columns(cheque_monto.Index).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight
        Cheques.Columns(cheque_estado.Index).DefaultCellStyle.BackColor = Color.LightBlue
        Cheques.ResumeLayout()

        Compras.SuspendLayout()
        Compras.Rows.Clear()
        Compras.Columns(compra_descripcion.Index).DefaultCellStyle.BackColor = Color.LightYellow
        Compras.Columns(compra_monto.Index).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight
        Compras.ResumeLayout()

        Ventas.SuspendLayout()
        Ventas.Rows.Clear()
        Ventas.Columns(venta_grupo.Index).DefaultCellStyle.BackColor = Color.SlateGray
        Ventas.Columns(venta_grupo.Index).DefaultCellStyle.ForeColor = Color.White
        Ventas.Columns(venta_grupo.Index).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter
        Ventas.Columns(venta_numero.Index).DefaultCellStyle.BackColor = Color.LightYellow
        Ventas.Columns(venta_numero.Index).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter
        Ventas.Columns(venta_fecha.Index).DefaultCellStyle.BackColor = Color.LightYellow
        Ventas.Columns(venta_fecha.Index).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter
        Ventas.Columns(venta_ref.Index).DefaultCellStyle.BackColor = Color.LightYellow
        Ventas.Columns(ventas_numero2.Index).DefaultCellStyle.BackColor = Color.LightYellow
        Ventas.Columns(venta_total.Index).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight
        Ventas.ResumeLayout()

        Caja.SuspendLayout()
        Caja.Rows.Clear()
        Caja.Columns(caja_documento.Index).DefaultCellStyle.BackColor = Color.SlateGray
        Caja.Columns(caja_documento.Index).DefaultCellStyle.ForeColor = Color.White
        Caja.Columns(caja_numero.Index).DefaultCellStyle.BackColor = Color.LightYellow
        Caja.Columns(caja_fecha.Index).DefaultCellStyle.BackColor = Color.LightYellow
        Caja.Columns(caja_fecha.Index).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter
        Caja.Columns(caja_total.Index).DefaultCellStyle.BackColor = Color.LightYellow
        Caja.Columns(caja_total.Index).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight
        Caja.Columns(caja_parcial.Index).DefaultCellStyle.BackColor = Color.LightYellow
        Caja.Columns(caja_parcial.Index).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight
        Caja.ResumeLayout()
    End Sub

    'Recupera los datos del documento
    Private Sub CargarDatos()
        Dim strSQL As String = " SELECT e.HDoc_DR1_Cat grupo, e.HDoc_DR2_Cat item, e.HDoc_Doc_Fec fecha, e.HDoc_RF2_Num id_documento, IFNULL(e.HDoc_DR1_Num,'') numero, e.HDoc_RF1_Cod concepto, e.HDoc_RF1_Dbl monto, " &
                               "        e.HDoc_Doc_TC tasa, IFNULL(e.HDoc_DR2_Num,'') referencia, IFNULL(e.HDoc_DR1_Dbl,0) gastos, e.HDoc_RF1_Txt notas, " &
                               "        e.HDoc_Emp_Cod id_empresa, e.HDoc_Emp_Nom empresa, e.HDoc_Emp_Per persona, IFNULL(e.HDoc_RF2_Cod,'') cc, " &
                               "        e.HDoc_RF2_Dbl efectivo, e.HDoc_RF3_Dbl cheques, IFNULL(e.HDoc_Ant_Com,0) anticipo, " &
                               "        e.HDoc_Doc_Status estado, IFNULL(e.HDoc_DR1_Emp,0) multiple, IFNULL(e.HDoc_DR2_Emp,0) secreto, " &
                               "        IFNULL((SELECT c1.cat_desc FROM Catalogos c1 WHERE c1.cat_num=e.HDoc_RF2_Num LIMIT 1),'') documento, " &
                               "        e.HDoc_Pro_DCat ref_tipo, e.HDoc_Pro_DAno ref_ciclo, e.HDoc_Pro_DNum ref_numero " &
                               " FROM Dcmtos_HDR e " &
                               " WHERE HDoc_Sis_Emp = @empresa AND HDoc_Doc_Cat = @tipo AND HDoc_Doc_Ano = @ciclo AND HDoc_Doc_Num = @numero " &
                               " LIMIT 1"
        Dim da As MySqlDataAdapter
        Dim dt As New System.Data.DataTable
        Dim dr As DataRow
        Dim obj As Object

        Dim intEstado As Integer = INT_CERO
        Dim dblSuma As Double = 0.0

        EtiquetaID.Text = String.Concat(Sesion.IdEmpresa, "-", Tipo, "-", Ciclo, "-", Numero)
        MyCnn.CONECTAR = strConexion
        Using cmd As New MySqlCommand(strSQL, CON)
            cmd.Parameters.AddWithValue("@empresa", Sesion.IdEmpresa)
            cmd.Parameters.AddWithValue("@tipo", Tipo)
            cmd.Parameters.AddWithValue("@ciclo", Ciclo)
            cmd.Parameters.AddWithValue("@numero", Numero)
            da = New MySqlDataAdapter(cmd)
            da.Fill(dt)
            da.Dispose()
        End Using
        If dt.Rows.Count > INT_CERO Then
            dr = dt.Rows(INT_CERO)

            Grupo = CInt(dr("grupo"))
            intItem = CInt(dr("item"))

            Fecha.Value = CDate(dr("fecha"))
            CeldaDocumento.Text = dr("documento")
            CeldaNumero.Text = dr("numero")
            CeldaConcepto.Text = dr("concepto")
            CeldaMonto.Text = CDbl(dr("monto")).ToString("f")
            CeldaTasa.Text = CDbl(dr("tasa")).ToString("f4")
            CeldaReferencia.Text = dr("referencia")
            CeldaGastos.Text = CDbl(dr("gastos")).ToString("f")
            CeldaNotas.Text = dr("notas")

            'Casillas
            intEstado = CInt(dr("estado"))
            CasillaAnulado.Checked = intEstado.Equals(clsBancos.ES_ANULADO)
            If intEstado.Equals(clsBancos.ES_ANULADO) Or intEstado.Equals(INT_CERO) Then
                CasillaCobrado.Checked = False
            Else : CasillaCobrado.Checked = True
            End If
            CasillaSecreto.Checked = CBool(dr("secreto"))
            CasillaProveedores.Checked = CBool(dr("multiple"))

            'Verificar si la poliza contable ya fue revisada
            If cFunciones.ContaActiva Then
                strSQL = "SELECT revisado FROM {conta}.polizas WHERE empresa = {empresa} AND ref_tipo = {tipo} AND ref_ciclo = {ciclo} AND ref_numero = {numero} LIMIT 1"
                strSQL = Replace(strSQL, "{conta}", Sesion.BaseConta)
                strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
                strSQL = Replace(strSQL, "{tipo}", Tipo)
                strSQL = Replace(strSQL, "{ciclo}", Ciclo)
                strSQL = Replace(strSQL, "{numero}", Numero)
                MyCnn.CONECTAR = strConexion
                Using cmd As New MySqlCommand(strSQL, CON)
                    obj = cmd.ExecuteScalar
                End Using
                If obj IsNot Nothing Then
                    CasillaRevisado.Checked = Not (CInt(obj).Equals(INT_CERO))
                End If
            Else : CasillaRevisado.Enabled = False
            End If

            'Grupo entidad (banco, empresa, persona, etc.)
            intEntidad = CInt(dr("id_empresa"))
            CeldaID.Text = intEntidad.ToString
            CeldaEmpresa.Text = Convert.ToString(dr("empresa"))
            CeldaPersona.Text = Convert.ToString(dr("persona"))

            'Documento relacionado
            With Relacion
                .Tipo = CInt(dr("ref_tipo"))
                .Ciclo = CInt(dr("ref_ciclo"))
                .Numero = CInt(dr("ref_numero"))
                .Nota = (dr("notas"))
            End With

            'Solo para depositos y cheques
            Select Case Tipo
                Case Base.IdDeposito
                    CeldaEfectivo.Text = CDbl(dr("efectivo")).ToString("f")
                    CeldaCheques.Text = CDbl(dr("cheques")).ToString("f")

                    CargarCheques()
                    dblSuma = SumarCheques()
                    CeldaOtrosBancos.Text = dblSuma.ToString("f")
                    SumarDeposito()
                Case Base.IdCheque

            End Select

            'De acuerdo al tipo de documento
            Select Case Tipo
                Case Base.IdDeposito, Base.IdCredito
                    If Grupo.Equals(clsBancos.BancoGrupo.Cliente) Then
                        CargarVentas()
                    End If
                Case Base.IdCheque, Base.IdDebito
                    'Recuperar detalle de presupuesto
                    CargarPresupuesto()

                    'Para proveedores y retenciones de ISR
                    If Grupo.Equals(clsBancos.BancoGrupo.Proveedor) Or (Grupo.Equals(clsBancos.BancoGrupo.Impuestos) And intItem.Equals(clsBancos.EnumImpuestos.ISRRetenciones) Or intItem.Equals(clsBancos.EnumImpuestos.IVARetenciones)) Then
                        CeldaAnticipo.Text = CDbl(dr("anticipo")).ToString("f")
                        CargarCompras()
                    ElseIf Grupo.Equals(clsBancos.BancoGrupo.Caja) And intItem.Equals(clsBancos.EnumCaja.Liquidacion) Then
                        CeldaDiferencia.Text = CDbl(dr("efectivo")).ToString("f")
                        CeldaCuenta.Text = dr("cc").ToString
                        CeldaCuentaNombre.Text = Base.ObtenerNombreCC(CeldaCuenta.Text)

                        'TODO mostrar info de liquidacion actual
                        InformacionDeCaja()

                        CargarLiquidacon()
                    End If
            End Select

            'Independiente del tipo
            If Grupo.Equals(clsBancos.BancoGrupo.Transferencia) Then
                CeldaCuenta.Text = dr("cc").ToString
                CeldaCuentaNombre.Text = Base.ObtenerNombreCC(CeldaCuenta.Text)
            End If
        End If
    End Sub

    'Recupera la informacion de la caja chica actual (numero, fecha y rango)
    Private Sub InformacionDeCaja()
        Dim strSQL As String = " SELECT c.BCta_Num ID, e.HDoc_Doc_Ano Año, e.HDoc_Doc_Num Numero, c.BCta_Nom_Cue Caja, e.HDoc_Doc_Mon Divisa, e.HDoc_Doc_TC Tasa, IFNULL(e.HDoc_DR1_Num,0) Documento, e.HDoc_Doc_Fec Fecha, cm.cat_ext Moneda, e.HDoc_RF2_Dbl Monto, e.HDoc_RF1_Dbl Bruto, " &
                               "    e.HDoc_DR1_Fec Inicio, e.HDoc_DR2_Fec Fin " &
                               " FROM Dcmtos_HDR e" &
                               "    LEFT JOIN CtasBcos c ON c.BCta_Sis_Emp=e.HDoc_Sis_Emp AND c.BCta_Num=e.HDoc_DR1_Cat" &
                               "    LEFT JOIN Catalogos cm ON cm.cat_clase='Monedas' AND cm.cat_num=e.HDoc_Doc_Mon" &
                               " WHERE e.HDoc_Sis_Emp={empresa} AND e.HDoc_Doc_Cat={tipo} AND e.HDoc_Doc_Ano={ciclo}  AND e.HDoc_Doc_Num={numero} " &
                               " LIMIT 1"

        EtiquetaCajaTitulo.Text = "Petty Cash Reconciliation"
        EtiquetaCajaFecha.Text = String.Empty
        If Relacion.Numero > INT_CERO Then
            strSQL = strSQL.Replace("{empresa}", Sesion.IdEmpresa)
            strSQL = strSQL.Replace("{tipo}", Relacion.Tipo)
            strSQL = strSQL.Replace("{ciclo}", Relacion.Ciclo)
            strSQL = strSQL.Replace("{numero}", Relacion.Numero)
            MyCnn.CONECTAR = strConexion
            Using cmd As New MySqlCommand(strSQL, CON)
                Using rd = cmd.ExecuteReader
                    If rd.Read() Then
                        EtiquetaCajaTitulo.Text = "Reconciliation N° " & rd.Item("documento").ToString & " from " & CDate(rd.Item("fecha")).ToString("dd/MM/yyyy")
                        EtiquetaCajaFecha.Text = "With documents between " & CDate(rd.Item("inicio")).ToString("dd/MM/yyyy") & " and " & CDate(rd.Item("fin")).ToString("dd/MM/yyyy")
                    End If
                End Using
            End Using
        End If
    End Sub

    'Muestra u oculta los paneles de acuerdo al grupo
    Private Sub MostrarPaneles()
        GrupoDeposito.Visible = False
        GrupoCuenta.Visible = False
        PanelCheques.Visible = False
        PanelCompras.Visible = False
        PanelVentas.Visible = False
        PanelCaja.Visible = False
        Grupo1.Visible = False
        Grupo2.Visible = False
        Grupo3.Visible = False

        CeldaAnticipo.ReadOnly = True
        CeldaAnticipo.BackColor = SystemColors.Info

        'Item actual
        EtiquetaTituloTransaccion.Text = Base.ItemsDeGrupo(Grupo)(intItem)

        'Mostrar paneles de acuerdo al grupo
        If Grupo.Equals(clsBancos.BancoGrupo.Proveedor) Then
            'GRUPO: Proveedores

            GrupoEmpresa.Text = "Provider"
            EtiquetaComprasTitulo.Text = "Purchase Invoices"
            BotonCompraCuenta.Visible = True
            BotonCompraGasto.Visible = True
            If Tipo.Equals(Base.IdDeposito) Then
                GrupoDeposito.Visible = True
                PanelCheques.Visible = True
            Else
                Grupo1.Visible = True
                PanelCompras.Visible = True
                If intItem.Equals(clsBancos.EnumProveedor.Pago) Or intItem.Equals(clsBancos.EnumProveedor.Impuesto) Then
                    CeldaAnticipo.ReadOnly = False
                    CeldaAnticipo.BackColor = SystemColors.Window
                End If
            End If
            If Tipo.Equals(Base.IdCheque) Or Tipo.Equals(Base.IdDebito) Then
                CasillaProveedores.Enabled = True
            End If
            Grupo3.Visible = True
        ElseIf Grupo.Equals(clsBancos.BancoGrupo.Caja) Then
            'GRUPO: Caja chica

            GrupoEmpresa.Text = "Petty Cash"
            EtiquetaCajaTitulo.Text = "Petty Cash Reconciliation"
            If Tipo.Equals(Base.IdCheque) Or Tipo.Equals(Base.IdDebito) Then
                GrupoCuenta.Text = "Petty Cash Difference"
                GrupoCuenta.Visible = True
                If intItem.Equals(clsBancos.EnumCaja.Liquidacion) Then
                    'Sólo habilitado para liquidación
                    GrupoCuenta.Enabled = True
                    PanelCaja.Visible = True
                Else
                    GrupoCuenta.Enabled = False
                    Grupo2.Visible = True
                    Grupo3.Visible = True
                End If
            Else
                GrupoCuenta.Text = "Petty Cash Difference"
                GrupoCuenta.Visible = True
                GrupoCuenta.Enabled = True
                ' Grupo1.Visible = True
                ' Grupo2.Visible = True
                ' Grupo3.Visible = True
            End If
        ElseIf Grupo.Equals(clsBancos.BancoGrupo.Cliente) Then
            'GRUPO: Clientes

            GrupoEmpresa.Text = "Customer"
            GrupoDeposito.Visible = True
            PanelCheques.Visible = True
            PanelVentas.Visible = True
            If (Sesion.IdEmpresa = 11) Or (Sesion.IdEmpresa = 16) Or Sesion.IdEmpresa = 14 Then
                Ventas.Columns(12).Visible = True
            End If
        ElseIf Grupo.Equals(clsBancos.BancoGrupo.Empleado) Then
            'GRUPO: Empleados

            GrupoEmpresa.Text = "Employee"
            If Tipo.Equals(Base.IdDeposito) Then
                GrupoDeposito.Visible = True
                PanelCheques.Visible = True
                Grupo3.Visible = True
            Else
                Grupo1.Visible = True
                Grupo2.Visible = True
                Grupo3.Visible = True
            End If
        ElseIf Grupo.Equals(clsBancos.BancoGrupo.Transferencia) Then
            'GRUPO: Transferencias

            GrupoEmpresa.Text = "Bank Account"
            GrupoCuenta.Text = "Accounting"
            GrupoCuenta.Visible = True
            Grupo2.Visible = True
            Grupo3.Visible = True
            EtiquetaComprasTitulo.Text = "Purchase Invoices"
            If intItem.Equals(clsBancos.EnumTransferencia.Depositos) Then
                'Transferencia desde otra cuenta
                GrupoEmpresa.Enabled = True
                GrupoCuenta.Enabled = False
                CasillaProveedores.Enabled = True
                CasillaExterna.Checked = False
            Else
                'Contra cuenta de gastos
                GrupoEmpresa.Enabled = True
                GrupoCuenta.Enabled = True
                CasillaExterna.Enabled = True
                CasillaExterna.Checked = True
                CasillaProveedores.Checked = False
            End If
            'TODO si es credito.transferencia mostrar documento de presentacion
        ElseIf Grupo.Equals(clsBancos.BancoGrupo.Impuestos) Then
            'GRUPO: Impuestos

            GrupoEmpresa.Text = "Reference"
            EtiquetaComprasTitulo.Text = "Income Tax Retentions"
            BotonCompraCuenta.Visible = True
            BotonCompraGasto.Visible = False

            Grupo1.Visible = True
            If intItem.Equals(clsBancos.EnumImpuestos.ISRRetenciones) Or intItem.Equals(clsBancos.EnumImpuestos.IVARetenciones) Then
                PanelCompras.Visible = True
                CeldaAnticipo.ReadOnly = False
                CeldaAnticipo.BackColor = SystemColors.Window
            Else : Grupo2.Visible = True
            End If
            Grupo3.Visible = True
        End If
    End Sub

    'Borrar el documento actual
    Public Function Borrar() As Boolean
        Dim logEx As Boolean = False
        Dim frm As New frmSeleccionar

        If _Numero > INT_CERO Then

            If cFunciones.SQLVerificarConciliacion(_Tipo, _Ciclo, _Numero) = 0 Then

                MsgBox("The document already exists in a reconciliation. You need authorization to modify.", vbInformation, "Notice")

                If cfun.AutorizarCambioDocumentosConciliados = True Then

                    frm.DialogResult = DialogResult.OK
                    If MsgBox("Are You sure " & vbCr & vbCr & "¿do you want to delete this document? ", vbQuestion + vbYesNo, "Aviso") = vbYes Then
                        If BorrarDocumento() Then
                            'Si la contabilidad esta activa
                            If cFunciones.ContaActiva Then
                                Using conta As New clsBPoliza
                                    'Eliminar poliza contable
                                    conta.BorrarPoliza(_Tipo, _Ciclo, _Numero, True)
                                End Using
                            End If

                            'Bitacora
                            MyCnn.CONECTAR = strConexion
                            cFunciones.EscribirRegistro("MvtosBcos", clsFunciones.AccEnum.acDelete,, _Tipo, _Ciclo, _Numero)
                            logEx = True
                        End If


                    End If

                Else
                    frm.DialogResult = DialogResult.Cancel
                    Exit Function
                End If

            Else
                If BorrarDocumento() Then
                    'Si la contabilidad esta activa
                    If cFunciones.ContaActiva Then
                        Using conta As New clsBPoliza
                            'Eliminar poliza contable
                            conta.BorrarPoliza(Sesion.BaseConta, _Tipo, _Ciclo, _Numero, True)
                            If Sesion.IdEmpresa = 18 Then
                                conta.BorrarPoliza("contapdm", _Tipo, _Ciclo, _Numero, True)
                            End If
                        End Using
                    End If

                    'Bitacora
                    MyCnn.CONECTAR = strConexion
                    cFunciones.EscribirRegistro("MvtosBcos", clsFunciones.AccEnum.acDelete,, _Tipo, _Ciclo, _Numero)
                    logEx = True
                End If


            End If


        End If
        Return logEx
    End Function

    'Borrar el registro de encabezado y detalles
    Private Function BorrarDocumento() As Boolean
        Dim logEx As Boolean = False
        Dim strSQL As String
        Dim strTemp As String

        'Recuperar el ID del tipo de documento si no ha sido asignado (anticipo)
        If Base.IdAnticipo.Equals(INT_CERO) Then
            Base.CargarTipos()
        End If

        'Borra anticipos generados
        strSQL = "DELETE  FROM Dcmtos_HDR, Dcmtos_DTL 
                  USING Dcmtos_HDR 
                  LEFT JOIN Dcmtos_DTL ON Dcmtos_DTL.DDoc_Sis_Emp = Dcmtos_HDR.HDoc_Sis_Emp AND Dcmtos_DTL.DDoc_Doc_Cat = Dcmtos_HDR.HDoc_Doc_Cat AND Dcmtos_DTL.DDoc_Doc_Ano = Dcmtos_HDR.HDoc_Doc_Ano AND Dcmtos_DTL.DDoc_Doc_Num = Dcmtos_HDR.HDoc_Doc_Num 
                  WHERE Dcmtos_HDR.HDoc_Sis_Emp = {empresa} AND Dcmtos_HDR.HDoc_Doc_Cat = {anticipos} AND Dcmtos_HDR.HDoc_Pro_DCat = {tipo}  AND Dcmtos_HDR.HDoc_Pro_DAno = {año} AND Dcmtos_HDR.HDoc_Pro_DNum = {numero} "
        If Sesion.IdEmpresa = 18 Then
            strSQL &= ";DELETE FROM PDM.Dcmtos_HDR, PDM.Dcmtos_DTL 
                  USING PDM.Dcmtos_HDR 
                  LEFT JOIN PDM.Dcmtos_DTL ON PDM.Dcmtos_DTL.DDoc_Sis_Emp = PDM.Dcmtos_HDR.HDoc_Sis_Emp AND PDM.Dcmtos_DTL.DDoc_Doc_Cat = PDM.Dcmtos_HDR.HDoc_Doc_Cat AND PDM.Dcmtos_DTL.DDoc_Doc_Ano = PDM.Dcmtos_HDR.HDoc_Doc_Ano AND PDM.Dcmtos_DTL.DDoc_Doc_Num = PDM.Dcmtos_HDR.HDoc_Doc_Num 
                  WHERE PDM.Dcmtos_HDR.HDoc_Sis_Emp = {empresa} AND PDM.Dcmtos_HDR.HDoc_Doc_Cat = {anticipos} AND PDM.Dcmtos_HDR.HDoc_Pro_DCat = {tipo}  AND PDM.Dcmtos_HDR.HDoc_Pro_DAno = {año} AND PDM.Dcmtos_HDR.HDoc_Pro_DNum = {numero} "
        End If
        strSQL = strSQL.Replace("{empresa}", Sesion.IdEmpresa)
        strSQL = strSQL.Replace("{anticipos}", Base.IdAnticipo)
        strSQL = strSQL.Replace("{tipo}", _Tipo)
        strSQL = strSQL.Replace("{año}", _Ciclo)
        strSQL = strSQL.Replace("{numero}", _Numero)
        MyCnn.CONECTAR = strConexion
        Using cmd As New MySqlCommand(strSQL, CON)
            cmd.ExecuteNonQuery()
        End Using

        'Borra los movimientos
        strSQL = "BMov_Sis_Emp = {empresa} AND BMov_Cta = {id} AND BMov_Doc_Cat = {tipo} AND BMov_Doc_Ano = {año} AND BMov_Doc_Num = {numero}"
        strSQL = strSQL.Replace("{empresa}", Sesion.IdEmpresa)
        strSQL = strSQL.Replace("{id}", _Cuenta)
        strSQL = strSQL.Replace("{tipo}", _Tipo)
        strSQL = strSQL.Replace("{año}", _Ciclo)
        strSQL = strSQL.Replace("{numero}", _Numero)
        Dim mvtosBcos As New Tablas.TMVTOSBCOS
        mvtosBcos.CONEXION = strConexion
        mvtosBcos.PDELETE(strSQL)

        'Borrar presupuesto
        If cFunciones.ContaActiva Then
            strSQL = "DELETE FROM {conta}.detalle_presupuesto WHERE empresa={empresa} AND categoria={categoria} AND ano={año} AND numero={numero} "
            If Sesion.IdEmpresa = 18 Then
                strSQL &= ";DELETE FROM contapdm.detalle_presupuesto WHERE empresa={empresa} AND categoria={categoria} AND ano={año} AND numero={numero} "
            End If
            strSQL = strSQL.Replace("{conta}", Sesion.BaseConta)
            strSQL = strSQL.Replace("{empresa}", Sesion.IdEmpresa)
            strSQL = strSQL.Replace("{categoria}", _Tipo)
            strSQL = strSQL.Replace("{año}", _Ciclo)
            strSQL = strSQL.Replace("{numero}", _Numero)
            Using cmd As New MySqlCommand(strSQL, CON)
                cmd.ExecuteNonQuery()
            End Using
        End If

        'Borra los créditos (abonos) a facturas de compras
        strSQL = "ECta_Sis_Emp = {empresa} AND ECta_Doc_Cat IN({tipo}) AND ECta_Doc_Ano = {año} AND ECta_Doc_Num = {numero}"
        strSQL = strSQL.Replace("{empresa}", Sesion.IdEmpresa)
        strSQL = strSQL.Replace("{tipo}", _Tipo & ", " & INT_CERO)
        strSQL = strSQL.Replace("{año}", _Ciclo)
        strSQL = strSQL.Replace("{numero}", _Numero)
        Dim ectacte As New Tablas.TECTACTE
        ectacte.CONEXION = strConexion
        ectacte.PDELETE(strSQL)

        'Borra el detalle del documento
        strSQL = "DDoc_Sis_Emp = {empresa} AND DDoc_Doc_Cat = {tipo} AND DDoc_Doc_Ano = {año} AND DDoc_Doc_Num = {numero}"
        strSQL = strSQL.Replace("{empresa}", Sesion.IdEmpresa)
        strSQL = strSQL.Replace("{tipo}", _Tipo)
        strSQL = strSQL.Replace("{año}", _Ciclo)
        strSQL = strSQL.Replace("{numero}", _Numero)
        Dim dtl As New clsDcmtos_DTL
        dtl.CONEXION = strSQL
        dtl.Borrar(strSQL)

        'Borra los descargos que se hayan hecho a otros documentos
        strSQL = "PDoc_Sis_Emp = {empresa} AND PDoc_Chi_Cat = {tipo} AND PDoc_Chi_Ano = {año} AND PDoc_Chi_Num = {numero}"
        strSQL = strSQL.Replace("{empresa}", Sesion.IdEmpresa)
        strSQL = strSQL.Replace("{tipo}", _Tipo)
        strSQL = strSQL.Replace("{año}", _Ciclo)
        strSQL = strSQL.Replace("{numero}", _Numero)
        Dim pro As New clsDcmtos_DTL_Pro
        pro.CONEXION = strSQL
        pro.Borrar(strSQL)

        'Borra referencia en documento relacionado
        If Relacion.Numero > INT_CERO Then
            strSQL = "UPDATE Dcmtos_HDR SET HDoc_Pro_DCat=0, HDoc_Pro_DAno=0, HDoc_Pro_DNum=0 WHERE HDoc_Sis_Emp = {empresa} AND HDoc_Doc_Cat = {tipo} AND HDoc_Doc_Ano = {año} AND HDoc_Doc_Num = {numero}"
            If Sesion.IdEmpresa = 18 Then
                strSQL = ";UPDATE PDM.Dcmtos_HDR SET HDoc_Pro_DCat=0, HDoc_Pro_DAno=0, HDoc_Pro_DNum=0 WHERE HDoc_Sis_Emp = {empresa} AND HDoc_Doc_Cat = {tipo} AND HDoc_Doc_Ano = {año} AND HDoc_Doc_Num = {numero}"
            End If
            strSQL = strSQL.Replace("{empresa}", Sesion.IdEmpresa)
            strSQL = strSQL.Replace("{tipo}", Relacion.Tipo)
            strSQL = strSQL.Replace("{año}", Relacion.Ciclo)
            strSQL = strSQL.Replace("{numero}", Relacion.Numero)
            MyCnn.CONECTAR = strConexion
            Using cmd As New MySqlCommand(strSQL, CON)
                cmd.ExecuteNonQuery()
            End Using
        End If

        'Borra el encabezado
        strSQL = "HDoc_Sis_Emp = {empresa} AND HDoc_Doc_Cat = {tipo} AND HDoc_Doc_Ano = {ciclo} AND HDoc_Doc_Num = {numero}"
        strSQL = strSQL.Replace("{empresa}", Sesion.IdEmpresa)
        strSQL = strSQL.Replace("{tipo}", _Tipo)
        strSQL = strSQL.Replace("{ciclo}", _Ciclo)
        strSQL = strSQL.Replace("{numero}", _Numero)
        Dim hdr As New clsDcmtos_HDR
        hdr.CONEXION = strConexion
        hdr.Borrar(strSQL)

        'Identificar recibos
        strSQL = " SELECT GROUP_CONCAT(TRIM(CONCAT(HDoc_Doc_Num,' ',HDoc_DR2_Num)) SEPARATOR ', ') Lista "
        strSQL = strSQL & " FROM Dcmtos_HDR "
        strSQL = strSQL & " WHERE HDoc_Sis_Emp = {empresa} AND HDoc_Doc_Cat = {recibo} AND HDoc_Pro_DCat = {tipo} AND HDoc_Pro_DAno = {ciclo} AND HDoc_Pro_DNum = {numero} "
        strSQL = strSQL.Replace("{empresa}", Sesion.IdEmpresa)
        strSQL = strSQL.Replace("{recibo}", Base.IdRecibo)
        strSQL = strSQL.Replace("{tipo}", _Tipo)
        strSQL = strSQL.Replace("{ciclo}", _Ciclo)
        strSQL = strSQL.Replace("{numero}", _Numero)
        MyCnn.CONECTAR = strConexion
        Using cmd As New MySqlCommand(strSQL, CON)
            strTemp = cmd.ExecuteScalar.ToString()
        End Using
        If Not (strTemp = String.Empty) Then
            MessageBox.Show("The following documents won't be affected" & vbCr & vbCr & "RECEIPT: " & strTemp & vbCr & vbCr & "Proceed with necessary tasks to complete the process", "Receipts", MessageBoxButtons.OK, MessageBoxIcon.Information)
        End If
        logEx = True

        Return logEx
    End Function

    'Guardar el documento actual
    Public Function Guardar(ByVal fechaDocumento As Date) As Boolean
        Dim logValidar As Boolean = False
        Dim dtFechaConta As Date
        Dim frm As New frmSeleccionar
        If EsNuevo Then
            If cFunciones.SQLVerificarFechaConciliacion(_Tipo, _Ciclo, _Numero, fechaDocumento, Cuenta) = 0 Then

                If GuardarDesdeBoton() Then

                    logValidar = True
                    cFunciones.EscribirRegistro("MvtosBcos", clsFunciones.AccEnum.acAdd, 0, _Tipo, _Ciclo, _Numero)

                End If
            Else

                Using conta As New clsBPoliza
                    MsgBox("The document already exists in a reconciliation. You need authorization to modify.", vbInformation, "Notice")
                    If cfun.AutorizarCambioDocumentosConciliados = True Then

                        frm.DialogResult = DialogResult.OK
                        If MsgBox("Are You sure " & vbCr & vbCr & "¿do you want to save this document? ", vbQuestion + vbYesNo, "Aviso") = vbYes Then

                            If GuardarDesdeBoton() Then

                                logValidar = True
                                conta.ProcesarDocumento(Tipo, Ciclo, Numero, Fecha.Value.ToString(FORMATO_MYSQL))
                                cFunciones.EscribirRegistro("MvtosBcos", clsFunciones.AccEnum.acUpdate, 0, _Tipo, _Ciclo, _Numero)

                            End If

                        End If

                    Else
                        frm.DialogResult = DialogResult.Cancel
                        Exit Function
                    End If
                End Using

            End If

        Else
            Using conta As New clsBPoliza
                'Captura la Fecha de la póliza o del documento, si este no tiene poliza
                dtFechaConta = cFunciones.SQLValidarFechaContable(_Tipo, _Ciclo, _Numero)
                If cFunciones.SQLVerificarCierre(_Tipo, _Ciclo, _Numero) = 0 Then

                    If cFunciones.SQLVerificarConciliacion(_Tipo, _Ciclo, _Numero) = 0 Then
                        MsgBox("The document already exists in a reconciliation. You need authorization to modify.", vbInformation, "Notice")
                        If cfun.AutorizarCambioDocumentosConciliados = True Then
                            frm.DialogResult = DialogResult.OK
                            If MsgBox("Are You sure " & vbCr & vbCr & "¿do you want to modify this document? ", vbQuestion + vbYesNo, "Aviso") = vbYes Then
                                If GuardarDesdeBoton() Then
                                    logValidar = True
                                    conta.ProcesarDocumento(Tipo, Ciclo, Numero, Fecha.Value.ToString(FORMATO_MYSQL))
                                    cFunciones.EscribirRegistro("MvtosBcos", clsFunciones.AccEnum.acUpdate, 0, _Tipo, _Ciclo, _Numero)
                                End If
                            End If
                        Else
                            frm.DialogResult = DialogResult.Cancel
                            Exit Function
                        End If
                    Else
                        If GuardarDesdeBoton() Then
                            logValidar = True
                            conta.ProcesarDocumento(Tipo, Ciclo, Numero, Fecha.Value.ToString(FORMATO_MYSQL))
                            cFunciones.EscribirRegistro("MvtosBcos", clsFunciones.AccEnum.acUpdate, 0, _Tipo, _Ciclo, _Numero)

                        End If

                    End If


                Else
                    MsgBox("There is already closure for this date. You need authorization to modify.", vbInformation, "Notice")
                    If cFunciones.AutorizarCambios = True Then
                        cFunciones.EscribirRegistro("MvtosBcos", clsFunciones.AccEnum.acConfirm, 0, _Tipo, _Ciclo, _Numero, "Autotizó el cambio")
                        If cFunciones.SQLVerificarConciliacion(_Tipo, _Ciclo, _Numero) = 0 Then
                            MsgBox("The document already exists in a reconciliation. You need authorization to modify.", vbInformation, "Notice")
                            If cfun.AutorizarCambioDocumentosConciliados = True Then
                                frm.DialogResult = DialogResult.OK
                                If MsgBox("Are You sure " & vbCr & vbCr & "¿do you want to modify this document? ", vbQuestion + vbYesNo, "Aviso") = vbYes Then

                                    If GuardarDesdeBoton() Then
                                        logValidar = True
                                        conta.ProcesarDocumento(Tipo, Ciclo, Numero, dtFechaConta.ToString(FORMATO_MYSQL))
                                    End If
                                Else
                                    frm.DialogResult = DialogResult.Cancel
                                    Exit Function
                                End If
                            Else
                                frm.DialogResult = DialogResult.Cancel
                                Exit Function
                            End If

                        Else

                            If GuardarDesdeBoton() Then
                                logValidar = True
                                conta.ProcesarDocumento(Tipo, Ciclo, Numero, dtFechaConta.ToString(FORMATO_MYSQL))
                            End If
                        End If
                    End If
                End If
            End Using
        End If
        Return logValidar
    End Function

    Public Function GuardarDesdeBoton() As Boolean
        Dim strMensaje As String = String.Empty
        Dim logEx As Boolean = False
        Dim ValidarNuevo As Boolean = False
        Dim dblDiferencial As Double = INT_CERO
        Accessos()
        If ComprobarDocumento() Then
            Cursor.Current = Cursors.AppStarting
            Nota_ = CeldaNotas.Text
            If EsNuevo Then
                Ciclo = Fecha.Value.Year
                Numero = Base.ObtenerNuevoDocumentoID(Tipo, Ciclo)
                ValidarNuevo = True
            End If
            If Numero > INT_CERO Then
                Cursor.Current = Cursors.WaitCursor
                If Sesion.IdEmpresa = 12 Then
                    If Cuenta = 1 Or Cuenta = 9 Then
                        If Tipo = Base.IdCheque Or Tipo = Base.IdDebito Then
                            MsgBox(" Verify that the document has its respective withholdings ", vbInformation)
                        End If
                    End If
                End If

                If GuardarDatos() Then
                    _Modificado = True

                    GuardarDetalle()

                    'Guardar datos del movimiento 
                    GuardarOperacion()

                    'Guardar recibo para deposito de cliente
                    If Not CasillaAnulado.Checked Then
                        If Grupo.Equals(clsBancos.BancoGrupo.Cliente) Then
                            GuardarRecibo(Tipo, Ciclo, Numero, strMensaje)
                        End If

                        Select Case Tipo
                            Case Base.IdCheque, Base.IdDebito
                                'Registra el crédito en la CxP
                                If Not (Grupo = clsBancos.BancoGrupo.Impuestos) Then
                                    RegistrarCompra()
                                End If
                            Case Base.IdDeposito, Base.IdCredito
                                'Registra el crédito en la CxC
                                RegistrarVenta()
                        End Select
                    End If

                    'Guarda si hay Diferencia Bancaria
                    If Tipo = Base.IdCheque Then
                        For Each row As DataGridViewRow In Compras.Rows
                            ' If Moneda = Divisa.Externa.id.ToString And CDbl(row.Cells(compra_moneda.Index).Value) = Divisa.Local.id.ToString Then
                            ' dblDiferencial = DiferenciaBancaria()
                            'If dblDiferencial <> INT_CERO Then
                            'GuardarDiferenciaCambiario(dblDiferencial)
                            'End If
                            'End If
                            Exit For
                        Next
                    End If

                    'Guardar asignacion de presupuesto
                    GuardarPresupuesto()

                    'Procesar poliza contable
                    If ValidarNuevo Then
                        Using conta As New clsBPoliza
                            If cFunciones.SQLVerificarCierre(Tipo, Ciclo, Numero) = 0 Then
                                conta.ProcesarDocumento(Tipo, Ciclo, Numero, Fecha.Value.ToString(FORMATO_MYSQL))
                            Else
                                conta.ProcesarDocumento(Tipo, Ciclo, Numero, cFunciones.HoyMySQL.ToString(FORMATO_MYSQL))
                            End If

                        End Using
                    End If

                    logEx = True
                End If
            End If
        End If
        Return logEx
    End Function

    'Guarda el detalle de compra en la tabla de estado de cuenta
    Private Sub RegistrarCompra()
        Dim strSQL As String = String.Empty
        Dim strSQLPDM As String = String.Empty
        Dim sql As clsQuery

        Dim intTipo As Integer '= Base.ObtenerIdDocumentoCompra
        Dim intCiclo As Integer
        Dim intNum As Integer
        Dim intMon As Integer
        Dim i As Integer = 0

        'Tasa de este documento y externa
        Dim dblTasa As Double = CDbl(CeldaTasa.Text)
        Dim dblTasaEx As Double = Base.ObtenerTasaDesdeCatalogos(Divisa.Externa.id)
        Dim dblCambio As Double = 0.0
        Dim dblTasaDoc As Double
        Dim dblMonto As Double
        Dim dblLocal As Double

        For Each row As DataGridViewRow In Compras.Rows
            intCiclo = CInt(row.Cells(compra_ciclo.Index).Value)
            intNum = CInt(row.Cells(compra_numero.Index).Value)
            intTipo = CInt(row.Cells(compra_tipo.Index).Value)
            If intNum > INT_CERO Then
                i += 1

                intMon = CInt(row.Cells(compra_moneda.Index).Value)
                dblTasaDoc = CDbl(row.Cells(compra_tasa.Index).Value)
                dblCambio = CDbl(row.Cells(compra_cambio.Index).Value)
                dblMonto = CDbl(row.Cells(compra_monto.Index).Value)

                If Moneda.Equals(intMonedaLocal) Then
                    'Cheque en moneda local
                    dblLocal = dblMonto
                    If intMon.Equals(intMonedaExterna) Then
                        'Factura en moneda externa
                        dblMonto = (dblMonto / dblTasaEx)
                        dblLocal = dblMonto * dblTasaDoc
                    Else
                        'Utilizar TC de factura
                        If dblTasaDoc.Equals(0) Then dblTasaDoc = dblTasa
                        dblMonto = (dblMonto / dblTasaDoc)
                    End If
                Else
                    'Debito en moneda externa
                    If Moneda.Equals(intMon) Then
                        'Misma moneda, utiliza la TC de la factura ($ -> Q)
                        dblLocal = (dblMonto * dblTasaDoc)
                    ElseIf dblCambio > 1 Then
                        'Utiliza la TC alternativa digitada por el usuario ($ -> Q)
                        dblLocal = (dblMonto * dblCambio)
                    Else
                        'Utiliza la TC del documento ($ -> Q)
                        dblLocal = (dblMonto * dblTasa)
                    End If
                End If
                dblLocal = Math.Round(dblLocal, 2)
                dblMonto = Math.Round(dblMonto, 2)

                sql = New clsQuery
                sql.Name = "{db}ECtaCte"
                sql.Kind = clsQuery.Mode.Insert

                'Id. del documento
                sql.Add("ECta_Sis_Emp", Sesion.IdEmpresa)
                sql.Add("ECta_Doc_Cat", Tipo)
                sql.Add("ECta_Doc_Ano", Ciclo)
                sql.Add("ECta_Doc_Num", Numero)
                sql.Add("ECta_Doc_Lin", i)

                'Empresa
                sql.Add("ECta_tipoemp", Base.Text("Proveedores"))
                sql.Add("ECta_codemp", intEntidad)

                'Cargo/abono
                sql.Add("ECta_Sini_Loc", INT_CERO)
                sql.Add("ECta_Crgo_Loc", INT_CERO)
                sql.Add("ECta_Abno_Loc", dblLocal)

                sql.Add("ECta_Sini_Ext", INT_CERO)
                sql.Add("ECta_Crgo_Ext", INT_CERO)
                sql.Add("ECta_Abno_Ext", dblMonto)

                'Concepto, vencimiento y moneda
                sql.Add("ECta_Concepto", Base.Text(CeldaConcepto.Text))
                sql.Add("ECta_FecDcmt", Base.Text(Fecha.Value.ToString(FORMATO_MYSQL)))
                sql.Add("ECta_FecVenc", Base.Text(Fecha.Value.ToString(FORMATO_MYSQL)))
                sql.Add("ECta_moneda", Moneda)
                sql.Add("ECta_TC", dblCambio)

                'Referencia
                sql.Add("ECta_Ref_Cat", intTipo)
                sql.Add("ECta_Ref_Ano", intCiclo)
                sql.Add("ECta_Ref_Num", intNum)
                strSQL = vbNullString

                strSQLPDM = sql.SQLString.Replace("{db}", "PDM.")
                strSQL = sql.SQLString.Replace("{db}", STR_VACIO)
                If Sesion.IdEmpresa = 18 Then
                    strSQL &= String.Concat(";", strSQLPDM)
                End If
                MyCnn.CONECTAR = strConexion
                Using cmd As New MySqlCommand(strSQL, CON)
                    cmd.ExecuteNonQuery()
                End Using
            End If
        Next
    End Sub

    'Validacion Diferencia Bancaria
    Private Function DiferenciaBancaria() As Double
        Dim strSQL As String = STR_VACIO
        Dim intDiferencia As Double
        Dim COM As MySqlCommand
        Dim conec As New MySqlConnection

        strSQL = "  SELECT IFNULL(ROUND(((l1.TotalFactura - l1.Retencion) - l1.Total),2),0) Diferencia "
        strSQL &= "     FROM ( "
        strSQL &= "         SELECT b.BCta_Cuenta Cuenta, ROUND(d.DDoc_RF2_Dbl, 5) Tasa, IF(h.HDoc_Doc_Mon=178, ROUND(d.DDoc_RF1_Dbl * d.DDoc_RF2_Dbl, 2), ROUND(d.DDoc_RF1_Dbl, 2)) Total, "
        strSQL &= "             IFNULL(h.HDoc_Emp_NIT, '') Presupuesto,ROUND(h44.HDoc_RF1_Dbl * h44.HDoc_Doc_TC,2) TotalFactura, IFNULL((h44.HDoc_Doc_TC * ROUND(SUM(cd.ECta_Abno_Loc),2)),0) Retencion  "
        strSQL &= "                 FROM Dcmtos_HDR h "
        strSQL &= "                     LEFT JOIN CtasBcos b ON b.BCta_Sis_Emp = h.HDoc_Sis_Emp AND b.BCta_Num = h.HDoc_RF1_Num "
        strSQL &= "                         LEFT JOIN Dcmtos_DTL d ON d.DDoc_Sis_Emp = h.HDoc_Sis_Emp AND d.DDoc_Doc_Cat = h.HDoc_Doc_Cat AND d.DDoc_Doc_Ano = h.HDoc_Doc_Ano AND d.DDoc_Doc_Num = h.HDoc_Doc_Num "
        strSQL &= "                             LEFT JOIN Dcmtos_HDR h44 ON h44.HDoc_Sis_Emp = d.DDoc_Sis_Emp AND h44.HDoc_Doc_Cat = d.DDoc_RF1_Num AND h44.HDoc_Doc_Ano = d.DDoc_RF2_Num AND h44.HDoc_Doc_Num = d.DDoc_RF3_Num "
        strSQL &= "                                 INNER JOIN ECtaCte cf ON cf.ECta_Sis_Emp = h44.HDoc_Sis_Emp AND cf.ECta_Doc_Cat = h44.HDoc_Doc_Cat AND cf.ECta_Doc_Ano = h44.HDoc_Doc_Ano AND cf.ECta_Doc_Num = h44.HDoc_Doc_Num "
        strSQL &= "                                     LEFT JOIN ECtaCte cd ON cd.ECta_Sis_Emp = h44.HDoc_Sis_Emp AND cd.ECta_Ref_Cat = h44.HDoc_Doc_Cat AND cd.ECta_Ref_Ano = h44.HDoc_Doc_Ano AND cd.ECta_Ref_Num = h44.HDoc_Doc_Num AND cd.ECta_Doc_Cat = 220 "
        strSQL &= "                                         WHERE h.HDoc_Sis_Emp = {empresa} AND h.HDoc_Doc_Cat = {catalogo} AND h.HDoc_Doc_Ano = {anio} AND h.HDoc_Doc_Num = {numero})l1 "
        strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
        strSQL = Replace(strSQL, "{catalogo}", Tipo)
        strSQL = Replace(strSQL, "{anio}", Ciclo)
        strSQL = Replace(strSQL, "{numero}", Numero)
        conec = New MySqlConnection(strConexion)
        conec.Open()
        COM = New MySqlCommand(strSQL, conec)
        intDiferencia = COM.ExecuteScalar
        conec.Close()
        conec.Dispose()
        conec = Nothing
        System.GC.Collect()
        Return intDiferencia

    End Function

    Private Sub GuardarDiferenciaCambiario(ByVal dblDiferencia As Double)
        Dim strSQL As String = String.Empty
        Dim strSQLPDM As String = String.Empty
        Dim sql As clsQuery

        Dim intTipo As Integer = Base.ObtenerIdDocumentoCompra
        Dim intCiclo As Integer
        Dim intNum As Integer
        Dim intMon As Integer
        Dim i As Integer = 0

        'Tasa de este documento y externa
        Dim dblTasa As Double = CDbl(CeldaTasa.Text)
        Dim dblTasaEx As Double = Base.ObtenerTasaDesdeCatalogos(Divisa.Externa.id)
        Dim dblCambio As Double = 0.0
        Dim dblTasaDoc As Double
        Dim dblMonto As Double
        Dim dblLocal As Double

        For Each row As DataGridViewRow In Compras.Rows
            intCiclo = CInt(row.Cells(compra_ciclo.Index).Value)
            intNum = CInt(row.Cells(compra_numero.Index).Value)
            If intNum > INT_CERO Then
                i += 1

                intMon = CInt(row.Cells(compra_moneda.Index).Value)
                dblTasaDoc = CDbl(row.Cells(compra_tasa.Index).Value)
                dblCambio = CDbl(row.Cells(compra_cambio.Index).Value)
                dblMonto = dblDiferencia

                sql = New clsQuery
                sql.Name = "{db}ECtaCte"
                sql.Kind = clsQuery.Mode.Insert

                'Id. del documento
                sql.Add("ECta_Sis_Emp", Sesion.IdEmpresa)
                sql.Add("ECta_Doc_Cat", 0)
                sql.Add("ECta_Doc_Ano", Ciclo)
                sql.Add("ECta_Doc_Num", Numero)
                sql.Add("ECta_Doc_Lin", i)

                'Empresa
                sql.Add("ECta_tipoemp", Base.Text("Proveedores"))
                sql.Add("ECta_codemp", intEntidad)

                'Cargo/abono
                sql.Add("ECta_Sini_Loc", INT_CERO)
                If dblMonto < 0 Then
                    sql.Add("ECta_Crgo_Loc", (dblMonto * -1))
                Else
                    sql.Add("ECta_Crgo_Loc", INT_CERO)
                End If
                If dblMonto > 0 Then
                    sql.Add("ECta_Abno_Loc", dblMonto)
                    sql.Add("ECta_Abno_Ext", INT_CERO)
                Else
                    sql.Add("ECta_Abno_Loc", INT_CERO)
                End If
                sql.Add("ECta_Sini_Ext", INT_CERO)
                sql.Add("ECta_Crgo_Ext", INT_CERO)


                'Concepto, vencimiento y moneda
                sql.Add("ECta_Concepto", Base.Text("Diferencial Cambiario"))
                sql.Add("ECta_FecDcmt", Base.Text(Fecha.Value.ToString(FORMATO_MYSQL)))
                sql.Add("ECta_FecVenc", Base.Text(Fecha.Value.ToString(FORMATO_MYSQL)))
                sql.Add("ECta_moneda", Moneda)
                sql.Add("ECta_TC", dblCambio)

                'Referencia
                sql.Add("ECta_Ref_Cat", intTipo)
                sql.Add("ECta_Ref_Ano", intCiclo)
                sql.Add("ECta_Ref_Num", intNum)
                strSQL = vbNullString

                strSQLPDM = sql.SQLString.Replace("{db}", "PDM.")
                strSQL = sql.SQLString.Replace("{db}", STR_VACIO)
                If Sesion.IdEmpresa = 18 Then
                    strSQL &= String.Concat(";", strSQLPDM)
                End If
                MyCnn.CONECTAR = strConexion
                Using cmd As New MySqlCommand(strSQL, CON)
                    cmd.ExecuteNonQuery()
                    sql = Nothing
                End Using
            End If
        Next

    End Sub

    'Guarda el detalle de venta en la tabla de estado de cuenta
    Private Sub RegistrarVenta()
        Dim strSQL As String = String.Empty
        Dim strSQLPDM As String = String.Empty
        Dim sql As clsQuery

        Dim intTipo As Integer
        Dim intCiclo As Integer
        Dim intNum As Integer
        Dim intMon As Integer
        Dim i As Integer = 0

        'Tasa de este documento y externa
        Dim dblTasa As Double = CDbl(CeldaTasa.Text)
        Dim dblTasaDoc As Double
        Dim dblMonto As Double
        Dim dblLocal As Double

        For Each row As DataGridViewRow In Ventas.Rows
            intTipo = CInt(row.Cells(venta_tipo.Index).Value)
            intCiclo = CInt(row.Cells(venta_ciclo.Index).Value)
            intNum = CInt(String.Concat("0", row.Cells(venta_numero.Index).Value))
            If intNum > INT_CERO Then
                i += 1

                intMon = CInt(row.Cells(venta_moneda.Index).Value)
                dblTasaDoc = CDbl(row.Cells(venta_tasa.Index).Value)
                dblMonto = CDbl(row.Cells(venta_total.Index).Value)

                If Moneda.Equals(intMonedaLocal) Then
                    'Cheque en moneda local
                    dblLocal = dblMonto
                    dblMonto = (dblMonto / dblTasa)
                Else
                    'Cheque en moneda exterior
                    dblLocal = (dblMonto * dblTasa)
                End If
                dblLocal = Math.Round(dblLocal, 2)
                dblMonto = Math.Round(dblMonto, 2)

                sql = New clsQuery
                sql.Name = "{db}ECtaCte"
                sql.Kind = clsQuery.Mode.Insert

                'Id. del documento
                sql.Add("ECta_Sis_Emp", Sesion.IdEmpresa)
                sql.Add("ECta_Doc_Cat", Tipo)
                sql.Add("ECta_Doc_Ano", Ciclo)
                sql.Add("ECta_Doc_Num", Numero)
                sql.Add("ECta_Doc_Lin", i)

                'Empresa
                sql.Add("ECta_tipoemp", Base.Text("Clientes"))
                sql.Add("ECta_codemp", CInt(row.Cells(venta_id.Index).Value))

                'Cargo/abono
                sql.Add("ECta_Sini_Loc", INT_CERO)
                sql.Add("ECta_Crgo_Loc", INT_CERO)
                sql.Add("ECta_Abno_Loc", dblLocal)

                sql.Add("ECta_Sini_Ext", INT_CERO)
                sql.Add("ECta_Crgo_Ext", INT_CERO)
                sql.Add("ECta_Abno_Ext", dblMonto)

                'Concepto, vencimiento y moneda
                sql.Add("ECta_Concepto", Base.Text(CeldaConcepto.Text))
                sql.Add("ECta_FecDcmt", Base.Text(Fecha.Value.ToString(FORMATO_MYSQL)))
                sql.Add("ECta_FecVenc", Base.Text(Fecha.Value.ToString(FORMATO_MYSQL)))
                sql.Add("ECta_moneda", Moneda)
                sql.Add("ECta_TC", dblTasa)

                'Referencia
                sql.Add("ECta_Ref_Cat", intTipo)
                sql.Add("ECta_Ref_Ano", intCiclo)
                sql.Add("ECta_Ref_Num", intNum)
                strSQL = vbNullString

                strSQLPDM = sql.SQLString.Replace("{db}", "PDM.")
                strSQL = sql.SQLString.Replace("{db}", STR_VACIO)
                If Sesion.IdEmpresa = 18 Then
                    strSQL &= String.Concat(";", strSQLPDM)
                End If
                MyCnn.CONECTAR = strConexion
                Using cmd As New MySqlCommand(strSQL, CON)
                    cmd.ExecuteNonQuery()
                End Using
            End If
        Next
    End Sub

    'Guarda el detalle de asignacion de presupuesto para documentos de débito
    Private Sub GuardarPresupuesto()
        Const STR_CARGO As String = "C"
        Dim dblTasa As Double = CDbl(CeldaTasa.Text)
        Dim SQL As clsQuery

        Dim strSQL As String = "DELETE FROM {conta}.detalle_presupuesto WHERE empresa={empresa} AND categoria={categoria} AND ano={año} AND numero={numero}"
        If Sesion.IdEmpresa = 18 Then
            strSQL &= ";DELETE FROM contapdm.detalle_presupuesto WHERE empresa={empresa} AND categoria={categoria} AND ano={año} AND numero={numero}"
        End If
        strSQL = strSQL.Replace("{conta}", Sesion.BaseConta)
        strSQL = strSQL.Replace("{empresa}", Sesion.IdEmpresa)
        strSQL = strSQL.Replace("{categoria}", Tipo)
        strSQL = strSQL.Replace("{año}", Ciclo)
        strSQL = strSQL.Replace("{numero}", Numero)

        'Borrar datos existentes
        MyCnn.CONECTAR = strConexion
        Dim cmd As New MySqlCommand(strSQL, CON)
        cmd.ExecuteNonQuery()

        For Each dato As clsBancos.DatoLista In Presupuesto
            SQL = New clsQuery()
            SQL.Name = "{conta}.detalle_presupuesto"
            SQL.Kind = clsQuery.Mode.Insert

            SQL.Add("empresa", Sesion.IdEmpresa)
            SQL.Add("categoria", Tipo)
            SQL.Add("ano", Ciclo)
            SQL.Add("numero", Numero)
            SQL.Add("moneda", Moneda)
            SQL.Add("tasa", CDbl(CeldaTasa.Text))
            SQL.Add("fecha", Base.Text(Fecha.Value.ToString(FORMATO_MYSQL)))
            SQL.Add("cuenta", Base.Text(dato.Codigo))
            If Moneda.Equals(intMonedaLocal) Then
                SQL.Add("importe_loc", dato.Monto)
                SQL.Add("importe_ext", Math.Round(dato.Monto / dblTasa, 5))
            Else
                SQL.Add("importe_loc", Math.Round(dato.Monto * dblTasa, 5))
                SQL.Add("importe_ext", dato.Monto)
            End If
            SQL.Add("operacion", Base.Text(STR_CARGO))
            Dim strSqlPdm As String = SQL.SQLString
            strSQL = Replace(SQL.SQLString, "{conta}", Sesion.BaseConta)
            If Sesion.IdEmpresa = 18 Then
                strSQL &= String.Concat(";", Replace(strSqlPdm, "{conta}", "contapdm"))
            End If

            'Insertar registro
            MyCnn.CONECTAR = strConexion
            cmd = New MySqlCommand(strSQL, CON)
            cmd.ExecuteNonQuery()
        Next
    End Sub

    'Guarda el registro de movimiento bancario
    Private Sub GuardarOperacion()
        Const STR_CLIENTES As String = "Clientes"
        Const STR_PROVEEDORES As String = "Proveedores"

        Dim strSQL As String = String.Empty
        Dim strSQLPDM As String = String.Empty
        Dim strGrupo As String = String.Empty
        Dim SQL As clsQuery

        Dim dblTasa As Double = 0.0
        Dim dblCargo As Double = 0.0
        Dim dblAbono As Double = 0.0
        Dim dblCargoEx As Double = 0.0
        Dim dblAbonoEx As Double = 0.0

        dblTasa = CDbl(CeldaTasa.Text)
        If Not CasillaAnulado.Checked Then
            Select Case Tipo
                Case Base.IdCheque, Base.IdDebito
                    'Debito
                    strGrupo = STR_PROVEEDORES
                    dblCargo = CDbl(CeldaMonto.Text)
                Case Base.IdDeposito, Base.IdCredito
                    'Credito
                    strGrupo = STR_CLIENTES
                    dblAbono = CDbl(CeldaMonto.Text)
            End Select

            If Moneda = intMonedaLocal Then
                'Documento actual en moneda local
                dblCargoEx = Math.Round(dblCargo / dblTasa, 5)
                dblAbonoEx = Math.Round(dblAbono / dblTasa, 5)
            Else
                'Documento actual en moneda exterior
                dblCargoEx = dblCargo
                dblAbonoEx = dblAbono
                dblCargo = Math.Round(dblCargoEx * dblTasa, 5)
                dblAbono = Math.Round(dblAbonoEx * dblTasa, 5)
            End If
        End If

        SQL = New clsQuery()
        SQL.Name = "{db}MvtosBcos"
        SQL.Kind = clsQuery.Mode.Insert

        'Asigna los datos a los campos
        SQL.Add("BMov_Sis_Emp", Sesion.IdEmpresa)
        SQL.Add("BMov_Cta", Cuenta)
        SQL.Add("BMov_Fec", Base.Text(Fecha.Value.ToString(FORMATO_MYSQL)))
        SQL.Add("BMov_Doc_Cat", Tipo)
        SQL.Add("BMov_Doc_Ano", Ciclo)
        SQL.Add("BMov_Doc_Num", Numero)
        SQL.Add("BMov_Beneficiario", Base.Text(CeldaPersona.Text))

        SQL.Add("BMov_Sini_Loc", INT_CERO)
        SQL.Add("BMov_Crgo_Loc", dblCargo)
        SQL.Add("BMov_Abno_Loc", dblAbono)
        SQL.Add("BMov_Sini_Ext", INT_CERO)
        SQL.Add("BMov_Crgo_Ext", dblCargoEx)
        SQL.Add("BMov_Abno_Ext", dblAbonoEx)

        SQL.Add("BMov_Cat_Doc", Documento)
        SQL.Add("BMov_Num_Doc", Base.Text(CeldaNumero.Text))
        SQL.Add("BMov_tipoemp", Base.Text(STR_CLIENTES))
        SQL.Add("BMov_codemp", intEntidad)
        SQL.Add("BMov_moneda", Moneda)
        SQL.Add("BMov_TC", dblTasa)
        SQL.Add("BMov_Concepto", Base.Text(CeldaConcepto.Text))
        SQL.Add("BMov_Saldo", INT_CERO)
        SQL.Add("BMov_Dias_Vcto", INT_CERO)

        strSQLPDM = SQL.SQLString.Replace("{db}", "PDM.")
        strSQL = SQL.SQLString.Replace("{db}", STR_VACIO)
        If Sesion.IdEmpresa = 18 Then
            strSQL &= String.Concat(";", strSQLPDM)
        End If
        MyCnn.CONECTAR = strConexion
        Using cmd As New MySqlCommand(strSQL, CON)
            cmd.ExecuteNonQuery()
        End Using
    End Sub

    'Genera un recibo para un deposito de cliente
    Private Sub GuardarRecibo(ByVal Tipo As Integer, ByVal Ciclo As Integer, ByVal Numero As Integer, ByRef Mensaje As String)
        Const DOC_RECIBO As String = "Doc_CRecibo"
        Const STR_NA As String = "N/A"

        Dim intTipo As Integer
        Dim intCiclo As Integer
        Dim intNumero As Integer = INT_CERO
        Dim intTemp As Integer
        Dim logEx As Boolean
        Dim logNuevo As Boolean = True
        Dim logLocal As Boolean

        Dim dblTotal As Double
        Dim dblOtros As Double

        Dim strSQL As String
        Dim strSQLPDM As String
        Dim strNombre As String = CeldaEmpresa.Text
        Dim strDir As String = String.Empty
        Dim strNit As String = String.Empty
        Dim strSerie As String = String.Empty
        Dim strTemp As String = String.Empty
        Dim strTotal As String
        Dim strLista As String

        Dim obj As Object
        Dim cmd As MySqlCommand
        Dim dt As System.Data.DataTable
        Dim dr As DataRow

        If intEntidad > INT_CERO Then
            If CDbl(CeldaTotalVenta.Text) > INT_CERO Then
                'Recuperar datos del cliente
                strSQL = "SELECT cli_cliente nombre, cli_direccion direccion, cli_nit nit FROM Clientes WHERE cli_sisemp={empresa} AND cli_codigo={id} LIMIT 1"
                strSQL = strSQL.Replace("{empresa}", Sesion.IdEmpresa)
                strSQL = strSQL.Replace("{id}", intEntidad)
                MyCnn.CONECTAR = strConexion
                Using cmr As New MySqlCommand(strSQL, CON)
                    Using sda As New MySqlDataAdapter(cmr)
                        dt = New System.Data.DataTable
                        sda.Fill(dt)
                        If dt.Rows.Count > 0 Then
                            dr = dt.Rows(0)
                            strNombre = Convert.ToString(dr("nombre"))
                            strDir = Convert.ToString(dr("direccion"))
                            strNit = Convert.ToString(dr("nit"))
                        End If
                    End Using
                End Using

                'Recuperar el ID del tipo de documento recibo
                intTipo = Base.ObtenerIdDeDocumento(DOC_RECIBO)

                'Determinar si ya existe un recibo para este documento
                strSQL = "SELECT HDoc_Doc_Ano Ciclo, HDoc_Doc_Num Numero FROM Dcmtos_HDR WHERE HDoc_Sis_Emp={empresa} AND HDoc_Pro_DCat={ref_tipo} AND HDoc_Pro_DAno={ref_ciclo} AND HDoc_Pro_DNum={ref_numero} AND HDoc_Doc_Cat={tipo}"
                strSQL = strSQL.Replace("{empresa}", Sesion.IdEmpresa)
                strSQL = strSQL.Replace("{ref_tipo}", Tipo)
                strSQL = strSQL.Replace("{ref_ciclo}", Ciclo)
                strSQL = strSQL.Replace("{ref_numero}", Numero)
                strSQL = strSQL.Replace("{tipo}", intTipo)
                MyCnn.CONECTAR = strConexion
                Using cmr As New MySqlCommand(strSQL, CON)
                    Using sda As New MySqlDataAdapter(cmr)
                        dt = New System.Data.DataTable
                        sda.Fill(dt)
                        If dt.Rows.Count > 0 Then
                            dr = dt.Rows(0)
                            intCiclo = CInt(dr("ciclo"))
                            intNumero = CInt(dr("numero"))
                            logNuevo = False
                        End If
                    End Using
                End Using

                'Si no existe obtener datos de nuevo documento
                If intNumero.Equals(INT_CERO) Then
                    'Obtener serie para recibos
                    strSQL = "SELECT cat_sist FROM Catalogos WHERE cat_sisemp={empresa} AND cat_clase='Serie' AND cat_clave={documento} AND cat_desc = 'AUTO'"
                    strSQL = strSQL.Replace("{empresa}", Sesion.IdEmpresa)
                    strSQL = strSQL.Replace("{documento}", Base.Text(DOC_RECIBO))
                    MyCnn.CONECTAR = strConexion
                    cmd = New MySqlCommand(strSQL, CON)
                    obj = cmd.ExecuteScalar
                    If obj IsNot Nothing Then
                        strSerie = obj.ToString
                    End If

                    'Año y número para el documento de recibo
                    intCiclo = Year(Fecha.Value)
                    strSQL = "SELECT (IFNULL(MAX(HDoc_Doc_Num),0)+1) Numero FROM Dcmtos_HDR WHERE HDoc_Sis_Emp={empresa} AND HDoc_Doc_Cat={tipo} AND HDoc_DR2_Num={serie}"
                    strSQL = strSQL.Replace("{empresa}", Sesion.IdEmpresa)
                    strSQL = strSQL.Replace("{tipo}", intTipo)
                    strSQL = strSQL.Replace("{serie}", Base.Text(strSerie))
                    MyCnn.CONECTAR = strConexion
                    cmd = New MySqlCommand(strSQL, CON)
                    intNumero = CInt(cmd.ExecuteScalar)

                    'Pedir confirmación de número de recibo
                    logEx = False
                    While Not logEx
                        strTemp = Base.PedirDato("Please confirm the receipt number" & Constants.vbCrLf & "If cancel is pressed no receipt is created", "Receipt Number", intNumero.ToString).Trim
                        If String.IsNullOrEmpty(strTemp) Then
                            'Cancelar
                            intNumero = NO_FILA
                            logEx = True
                        Else
                            strTemp = strTemp.TrimStart("0")
                            If strTemp.Length > 5 Then
                                strTemp = strTemp.Substring(0, 5)
                            End If
                            If Not Integer.TryParse(strTemp, intTemp) Then
                                MessageBox.Show(strTemp & " is not a valid number", "Receipt number", MessageBoxButtons.OK, MessageBoxIcon.Warning)
                            Else
                                strSQL = "SELECT HDoc_Doc_Num Numero FROM Dcmtos_HDR WHERE HDoc_Sis_Emp={empresa} AND HDoc_Doc_Cat={tipo} AND HDoc_DR2_Num={serie} AND HDoc_Doc_Num={numero} LIMIT 1"
                                strSQL = strSQL.Replace("{empresa}", Sesion.IdEmpresa)
                                strSQL = strSQL.Replace("{tipo}", intTipo)
                                strSQL = strSQL.Replace("{serie}", Base.Text(strSerie))
                                strSQL = strSQL.Replace("{numero}", intTemp)
                                MyCnn.CONECTAR = strConexion
                                cmd = New MySqlCommand(strSQL, CON)
                                obj = cmd.ExecuteScalar()
                                'No existe, por lo tanto crear
                                If obj Is Nothing Then
                                    intNumero = intTemp
                                    logEx = True
                                Else
                                    MessageBox.Show(" Receipt number " & strSerie & Space(1) & intTemp.ToString & " already exists", "Receipt number", MessageBoxButtons.OK, MessageBoxIcon.Warning)
                                End If
                            End If
                        End If
                    End While

                    If Not intNumero.Equals(NO_FILA) Then
                        Mensaje = "Receipt " & strSerie & Space(1) & intNumero & " was created"
                    End If
                End If

                strLista = String.Empty
                If Not intNumero.Equals(NO_FILA) Then
                    logLocal = Moneda.Equals(intMonedaLocal)
                    For Each row As DataGridViewRow In Ventas.Rows
                        If Not row.Cells(venta_numero.Index).Value.Equals(String.Empty) Then
                            If logLocal Then
                                logLocal = CInt(row.Cells(venta_numero.Index).Value).Equals(intMonedaLocal)
                            End If

                            'grupo + factura + serie + referencia
                            strTemp = row.Cells(venta_grupo.Index).Value & Space(1) &
                                      row.Cells(venta_numero.Index).Value & Space(1) &
                                      row.Cells(venta_serie.Index).Value
                            strTemp = strTemp.Trim & " (" & row.Cells(venta_ref.Index).Value & ")"
                            If Not strLista.Equals(String.Empty) Then
                                strLista &= ", "
                            End If
                            strLista &= strTemp
                        End If
                    Next
                End If

                'Guardar informacion del recibo
                Dim SQL As New clsQuery
                SQL.Name = "{db}Dcmtos_HDR"
                strSQL = String.Empty

                If logNuevo Then
                    SQL.Kind = clsQuery.Mode.Insert

                    'Datos del recibo
                    SQL.Add("HDoc_Sis_Emp", Sesion.IdEmpresa)
                    SQL.Add("HDoc_Doc_Cat", intTipo)
                    SQL.Add("HDoc_Doc_Ano", intCiclo)
                    SQL.Add("HDoc_Doc_Num", intNumero)
                    SQL.Add("HDoc_Usuario", Base.Text(Sesion.Usuario))

                    'Referencia al recibo generado
                    SQL.Add("HDoc_Pro_DCat", Tipo)
                    SQL.Add("HDoc_Pro_DAno", Ciclo)
                    SQL.Add("HDoc_Pro_DNum", Numero)

                    'Serie y fecha
                    SQL.Add("HDoc_DR2_Num", Base.Text(strSerie))
                    SQL.Add("HDoc_Doc_Fec", "CURRENT_DATE()")
                Else
                    'Actualizar recibo existente
                    SQL.Kind = clsQuery.Mode.Update

                    strSQL = "HDoc_Sis_Emp={empresa} AND HDoc_Doc_Cat={tipo} AND HDoc_Doc_Ano={ciclo} AND HDoc_Doc_Num={id}"
                    strSQL = strSQL.Replace("{empresa}", Sesion.IdEmpresa)
                    strSQL = strSQL.Replace("{tipo}", intTipo)
                    strSQL = strSQL.Replace("{ciclo}", intCiclo)
                    strSQL = strSQL.Replace("{id}", intNumero)
                End If

                SQL.Add("HDoc_Doc_Status", INT_UNO)

                'Empresa
                SQL.Add("HDoc_Emp_Cod", intEntidad)
                SQL.Add("HDoc_Emp_Nom", Base.Text(strNombre))
                SQL.Add("HDoc_Emp_Dir", Base.Text(strDir))
                SQL.Add("HDoc_Emp_Per", Base.Text(STR_NA))
                SQL.Add("HDoc_Emp_Tel", Base.Text(STR_NA))
                SQL.Add("HDoc_Emp_NIT", Base.Text(strNit))

                'Moneda y tasa de cambio
                SQL.Add("HDoc_Doc_Mon", Moneda)
                If logLocal Then
                    SQL.Add("HDoc_Doc_TC", INT_UNO)
                Else
                    SQL.Add("HDoc_Doc_TC", CDbl(CeldaTasa.Text).ToString("f4"))
                End If

                'Referencia(s)
                SQL.Add("HDoc_DR1_Cat", INT_CERO)
                strTemp = strLista
                If strTemp.Length > 100 Then
                    strTemp = strTemp.Substring(0, 100)
                End If
                SQL.Add("HDoc_DR1_Num", Base.Text(strTemp))

                'Forma de pago/cheque y banco
                SQL.Add("HDoc_RF1_Cod", Base.Text(ListaDeColumna(Cheques, cheque_numero.Index)))
                SQL.Add("HDoc_RF2_Cod", Base.Text(ListaDeColumna(Cheques, cheque_emisor.Index)))

                'Concepto y total en letras
                dblTotal = CDbl(CeldaMonto.Text)
                strTotal = cFunciones.ALetras(dblTotal).ToUpper

                SQL.Add("HDoc_RF1_Txt", Base.Text("PAGO: " & strLista))
                SQL.Add("HDoc_RF2_Txt", Base.Text(strTotal))

                'Monto en cheque y en efectivo
                dblOtros = SumarCheques()
                SQL.Add("HDoc_RF1_Dbl", dblOtros.ToString("f"))
                SQL.Add("HDoc_RF2_Dbl", Math.Round(dblTotal - dblOtros, 2).ToString)
                strSQLPDM = (SQL.SQLString & strSQL).Replace("{db}", "PDM.")
                strSQL = (SQL.SQLString & strSQL).Replace("{db}", STR_VACIO)
                If Sesion.IdEmpresa = 18 Then
                    strSQL &= String.Concat(";", strSQLPDM)
                End If
                MyCnn.CONECTAR = strConexion
                cmd = New MySqlCommand(strSQL, CON)
                cmd.ExecuteNonQuery()
            End If
        End If
    End Sub

    'Comprueba la validez de una fila de cheque
    Private Function ValidarFilaCheque(ByRef row As DataGridViewRow) As Boolean
        Dim logOk As Boolean = False
        Dim dblMonto As Double = 0.0

        'TODO validar las demas columnas
        If Double.TryParse(row.Cells(cheque_monto.Index).Value, dblMonto) Then
            row.Cells(cheque_monto.Index).Value = dblMonto.ToString("f")
            logOk = True
        End If
        Return logOk
    End Function

    'Comprueba la validez de una fila de compras (ref. proveedor)
    Private Function ValidarFilaCompra(ByRef row As DataGridViewRow) As Boolean
        Dim logOk As Boolean = False
        Dim strDesc As String
        Dim dblMonto As Double

        strDesc = row.Cells(compra_descripcion.Index).Value.ToString.Trim
        dblMonto = Math.Round(CDbl(row.Cells(compra_monto.Index).Value), 2)

        If strDesc.Equals(String.Empty) And dblMonto > INT_CERO Then
        Else : logOk = (dblMonto > INT_CERO)
        End If

        Return logOk
    End Function

    'Comprueba la validez de una fila de ventas (ref. cliente)
    Private Function ValidarFilaVenta(ByRef row As DataGridViewRow) As Boolean
        Dim logOk As Boolean = False
        Dim intMoneda As Integer = INT_CERO
        Dim dblMonto As Double = 0.0
        Dim dblTotal As Double = 0.0
        Dim dblTasa As Double = CDbl(CeldaTasa.Text)

        intMoneda = CInt(row.Cells(venta_moneda.Index).Value)
        dblMonto = Math.Round(CDbl(row.Cells(venta_monto.Index).Value), 2)
        dblTotal = Math.Round(CDbl(row.Cells(venta_total.Index).Value), 2)

        If intMoneda.Equals(INT_CERO) Then
            'Cargos manuales
            row.Cells(venta_moneda.Index).Value = Moneda.ToString
            row.Cells(venta_tasa.Index).Value = dblTasa.ToString
            row.Cells(venta_monto.Index).Value = dblTotal.ToString("f")
        ElseIf Not (dblMonto.Equals(dblTotal)) Then
            If intMoneda.Equals(Moneda) Then
                'Moneda de la fila igual a la cuenta
                dblMonto = dblTotal
            ElseIf Moneda.Equals(intMonedaLocal) Then
                'Moneda de la cuenta es local -> local a exterior
                dblMonto = Math.Round(dblTotal / dblTasa, 2)
            Else
                'De exterior a local
                dblMonto = Math.Round(dblTotal * dblTasa, 2)
            End If
            row.Cells(venta_monto.Index).Value = dblMonto.ToString("f")
        End If
        logOk = (CDbl(row.Cells(venta_total.Index).Value) > 0)

        Return logOk
    End Function

    'Devuelve un listado de valores de la columna de una cuadricula
    Private Function ListaDeColumna(ByRef Lista As DataGridView, ByVal Col As Integer) As String
        Dim strLista As String = String.Empty
        Dim strTemp As String
        For Each row As DataGridViewRow In Lista.Rows
            strTemp = row.Cells(Col).Value.ToString.Trim
            If Not strTemp.Equals(String.Empty) Then
                If Not strLista.Equals(String.Empty) Then
                    strLista &= ", "
                End If
                strLista &= strTemp
            End If
        Next
        Return strLista
    End Function

    'Guarda el detalle del documento 
    Private Sub GuardarDetalle()
        Const DOC_RETENCION As String = "Doc_RISR"

        Dim strSQL As String = String.Empty
        Dim strSQLPDM As String = String.Empty
        Dim strClase As String
        Dim strDato As String

        Dim dblNeto As Double
        Dim intLinea As Integer = INT_CERO
        Dim intEstado As Integer
        Dim intTipo As Integer
        Dim intIdRetencion As Integer
        Dim logPasa As Boolean = False

        Dim SQL As clsQuery
        Dim cmd As MySqlCommand

        'Borrar antes de guardar
        BorrarDetalles()

        'Sólo Depósitos
        If Tipo.Equals(Base.IdDeposito) Then
            'Guardar cheques
            For Each row As DataGridViewRow In Cheques.Rows
                logPasa = ValidarFilaCheque(row)
                If logPasa Then
                    intLinea += 1

                    SQL = New clsQuery() With {.Kind = clsQuery.Mode.Insert}
                    SQL.Name = "{db}Dcmtos_DTL"

                    SQL.Add("DDoc_Sis_Emp", Sesion.IdEmpresa)
                    SQL.Add("DDoc_Doc_Cat", Tipo)
                    SQL.Add("DDoc_Doc_Ano", Ciclo)
                    SQL.Add("DDoc_Doc_Num", Numero)
                    SQL.Add("DDoc_Doc_Lin", intLinea)

                    intEstado = INT_CERO
                    Select Case row.Cells(cheque_estado.Index).Value.ToString
                        Case STR_PAGADO : intEstado = ES_PAGADO
                        Case STR_RECHAZADO : intEstado = Es_RECHAZADO
                    End Select

                    SQL.Add("DDoc_RF1_Fec", Base.Text(CDate(row.Cells(cheque_fecha.Index).Value).ToString(FORMATO_MYSQL)))
                    SQL.Add("DDoc_RF1_Txt", Base.Text(row.Cells(cheque_emisor.Index).Value))
                    SQL.Add("DDoc_RF1_Cod", Base.Text(row.Cells(cheque_numero.Index).Value))
                    SQL.Add("DDoc_RF1_Dbl", CDbl(row.Cells(cheque_monto.Index).Value).ToString("f"))
                    SQL.Add("DDoc_RF1_Num", intEstado)
                    SQL.Add("DDoc_RF2_Cod", Base.Text(STR_CHEQUE))
                    strSQLPDM = SQL.SQLString.Replace("{db}", "PDM.")
                    strSQL = SQL.SQLString.Replace("{db}", STR_VACIO)
                    If Sesion.IdEmpresa = 18 Then
                        strSQL &= String.Concat(";", strSQLPDM)
                    End If
                    MyCnn.CONECTAR = strConexion
                    cmd = New MySqlCommand(strSQL, CON)
                    cmd.ExecuteNonQuery()
                End If
            Next
        End If

        'Guardar facturas de venta (ref. clientes)
        If Grupo.Equals(clsBancos.BancoGrupo.Cliente) Then
            For Each row As DataGridViewRow In Ventas.Rows
                'REVISAR: si tiene ID de moneda la fila no se evalua
                If CInt(row.Cells(venta_moneda.Index).Value).Equals(INT_CERO) Then
                    logPasa = ValidarFilaVenta(row)
                Else : logPasa = True
                End If

                If logPasa Then
                    intLinea += 1

                    SQL = New clsQuery() With {.Kind = clsQuery.Mode.Insert}
                    SQL.Name = "{db}Dcmtos_DTL"

                    SQL.Add("DDoc_Sis_Emp", Sesion.IdEmpresa)
                    SQL.Add("DDoc_Doc_Cat", Tipo)
                    SQL.Add("DDoc_Doc_Ano", Ciclo)
                    SQL.Add("DDoc_Doc_Num", Numero)
                    SQL.Add("DDoc_Doc_Lin", intLinea)

                    SQL.Add("DDoc_Prd_Cod", CInt(row.Cells(venta_id.Index).Value))
                    SQL.Add("DDoc_RF1_Cod", Base.Text(row.Cells(venta_serie.Index).Value))
                    strDato = row.Cells(venta_numero.Index).Value
                    If strDato.Equals(String.Empty) Then
                        strDato = INT_CERO.ToString
                    End If
                    SQL.Add("DDoc_RF3_Num", CInt(strDato))
                    If row.Cells(venta_fecha.Index).Value.ToString.Equals(String.Empty) Then
                        'No tiene fecha
                        SQL.Add("DDoc_RF1_Num", INT_CERO)
                        SQL.Add("DDoc_RF2_Num", Fecha.Value.Year)
                        SQL.Add("DDoc_RF1_Fec", Base.Text(CDate(Fecha.Value).ToString(FORMATO_MYSQL)))
                        SQL.Add("DDoc_RF2_Cod", Base.Text(STR_CUENTA))
                        SQL.Add("DDoc_RF3_Dbl", CDbl(CeldaTasa.Text))
                    Else
                        SQL.Add("DDoc_RF1_Num", row.Cells(venta_tipo.Index).Value)
                        SQL.Add("DDoc_RF2_Num", row.Cells(venta_ciclo.Index).Value)
                        SQL.Add("DDoc_RF1_Fec", Base.Text(CDate(row.Cells(venta_fecha.Index).Value).ToString(FORMATO_MYSQL)))
                        SQL.Add("DDoc_RF2_Cod", Base.Text(STR_VENTA))
                        SQL.Add("DDoc_RF3_Dbl", row.Cells(venta_tasa.Index).Value)
                    End If
                    SQL.Add("DDoc_RF1_Txt", Base.Text(row.Cells(venta_ref.Index).Value))

                    'Monto a mostrar en pantalla
                    SQL.Add("DDoc_RF1_Dbl", CDbl(row.Cells(venta_total.Index).Value))
                    'Monto en moneda original
                    SQL.Add("DDoc_RF2_Dbl", CDbl(row.Cells(venta_monto.Index).Value))
                    'Moneda y tasa de cambio del documento
                    SQL.Add("DDoc_Prd_UM", CInt(row.Cells(venta_total.Index).Value))

                    strSQLPDM = SQL.SQLString.Replace("{db}", "PDM.")
                    strSQL = SQL.SQLString.Replace("{db}", STR_VACIO)
                    If Sesion.IdEmpresa = 18 Then
                        strSQL &= String.Concat(";", strSQLPDM)
                    End If
                    MyCnn.CONECTAR = strConexion
                    cmd = New MySqlCommand(strSQL, CON)
                    cmd.ExecuteNonQuery()
                End If
            Next
        End If

        'Guardar caja chica 
        If Grupo.Equals(clsBancos.BancoGrupo.Caja) Then
            'Sólo si la transacción es Liquidación
            If intItem.Equals(clsBancos.EnumCaja.Liquidacion) Then
                For Each row As DataGridViewRow In Caja.Rows
                    intLinea += 1

                    SQL = New clsQuery() With {.Kind = clsQuery.Mode.Insert}
                    SQL.Name = "{db}Dcmtos_DTL"

                    SQL.Add("DDoc_Sis_Emp", Sesion.IdEmpresa)
                    SQL.Add("DDoc_Doc_Cat", Tipo)
                    SQL.Add("DDoc_Doc_Ano", Ciclo)
                    SQL.Add("DDoc_Doc_Num", Numero)
                    SQL.Add("DDoc_Doc_Lin", intLinea)

                    dblNeto = CDbl(row.Cells(caja_total.Index).Value)
                    strDato = row.Cells(caja_parcial.Index).Value.ToString
                    If Not strDato.Equals(String.Empty) Then
                        dblNeto = CDbl(strDato)
                    End If

                    'Detalle de liquidación (monto = neto, no bruto)
                    strDato = row.Cells(caja_numero.Index).Value
                    strDato &= " - "
                    strDato &= CDate(row.Cells(caja_fecha.Index).Value).ToString("dd/MM/yyyy")
                    SQL.Add("DDoc_RF1_Txt", Base.Text(strDato))
                    SQL.Add("DDoc_RF1_Dbl", Math.Round(dblNeto, 2).ToString("f"))
                    SQL.Add("DDoc_RF2_Cod", Base.Text(STR_CAJA))

                    strSQLPDM = SQL.SQLString.Replace("{db}", "PDM.")
                    strSQL = SQL.SQLString.Replace("{db}", STR_VACIO)
                    If Sesion.IdEmpresa = 18 Then
                        strSQL &= String.Concat(";", strSQLPDM)
                    End If
                    MyCnn.CONECTAR = strConexion
                    cmd = New MySqlCommand(strSQL, CON)
                    cmd.ExecuteNonQuery()
                Next
            End If
        End If

        'Sólo Cheques y Débitos
        If Tipo.Equals(Base.IdCheque) Or Tipo.Equals(Base.IdDebito) Then
            'Guardar facturas de compra (ref. proveedores) y retenciones (ref. impuestos)
            If Grupo.Equals(clsBancos.BancoGrupo.Proveedor) Or (Grupo.Equals(clsBancos.BancoGrupo.Impuestos) And intItem.Equals(clsBancos.EnumImpuestos.ISRRetenciones) Or intItem.Equals(clsBancos.EnumImpuestos.IVARetenciones)) Then
                'ID del tipo de documento retencion
                intIdRetencion = Base.ObtenerIdDeDocumento(DOC_RETENCION)

                For Each row As DataGridViewRow In Compras.Rows
                    logPasa = ValidarFilaCompra(row)
                    If logPasa Then
                        intLinea += 1

                        SQL = New clsQuery() With {.Kind = clsQuery.Mode.Insert}
                        SQL.Name = "{db}Dcmtos_DTL"

                        SQL.Add("DDoc_Sis_Emp", Sesion.IdEmpresa)
                        SQL.Add("DDoc_Doc_Cat", Tipo)
                        SQL.Add("DDoc_Doc_Ano", Ciclo)
                        SQL.Add("DDoc_Doc_Num", Numero)
                        SQL.Add("DDoc_Doc_Lin", intLinea)

                        strClase = STR_COMPRA
                        intTipo = row.Cells(compra_tipo.Index).Value
                        If intTipo.Equals(intIdRetencion) Then
                            'Retención ISR (proveedor)
                            strClase = STR_RETENCION

                            'Actualizar relación factura-retencion del proveedor (tipo, año y número)
                            strSQL = "UPDATE Dcmtos_HDR SET HDoc_Doc_Status = 1 WHERE HDoc_Sis_Emp = {empresa} AND HDoc_Doc_Cat = {tipo} AND HDoc_Doc_Ano = {ciclo} AND HDoc_Doc_Num = {numero}"
                            If Sesion.IdEmpresa = 18 Then
                                strSQL &= ";UPDATE PDM.Dcmtos_HDR SET HDoc_Doc_Status = 1 WHERE HDoc_Sis_Emp = {empresa} AND HDoc_Doc_Cat = {tipo} AND HDoc_Doc_Ano = {ciclo} AND HDoc_Doc_Num = {numero}"
                            End If
                            strSQL = strSQL.Replace("{empresa}", Sesion.IdEmpresa)
                            strSQL = strSQL.Replace("{tipo}", intIdRetencion)
                            strSQL = strSQL.Replace("{ciclo}", CInt(row.Cells(compra_ciclo.Index).Value))
                            strSQL = strSQL.Replace("{numero}", CInt(row.Cells(compra_numero.Index).Value))
                            MyCnn.CONECTAR = strConexion
                            cmd = New MySqlCommand(strSQL, CON)
                            cmd.ExecuteNonQuery()
                        ElseIf Not row.Cells(compra_cuenta.Index).Value.ToString.Equals(String.Empty) Then
                            'Cuenta contable
                            strClase = STR_CUENTA
                        End If

                        SQL.Add("DDoc_RF2_Cod", Base.Text(strClase))

                        SQL.Add("DDoc_RF1_Num", CInt(row.Cells(compra_tipo.Index).Value))
                        SQL.Add("DDoc_RF2_Num", CInt(row.Cells(compra_ciclo.Index).Value))
                        SQL.Add("DDoc_RF3_Num", CInt(row.Cells(compra_numero.Index).Value))

                        SQL.Add("DDoc_RF1_Txt", Base.Text(row.Cells(compra_descripcion.Index).Value))
                        If CDbl(row.Cells(compra_factura.Index).Value).ToString("f2") > 0 Then
                            SQL.Add("DDoc_Prd_NET", CDbl(row.Cells(compra_factura.Index).Value).ToString("f2"))
                        Else
                            SQL.Add("DDoc_Prd_NET", CDbl(row.Cells(compra_monto.Index).Value).ToString("f2"))
                        End If
                        SQL.Add("DDoc_RF1_Dbl", CDbl(row.Cells(compra_monto.Index).Value).ToString("f2"))
                        SQL.Add("DDoc_Prd_Ref", Base.Text(row.Cells(compra_cuenta.Index).Value))

                        'Guardar tasa de cambio alternativa (solo si es mayor que uno)
                        If CDbl(row.Cells(compra_cambio.Index).Value) > 1 Then
                            SQL.Add("DDoc_RF2_Dbl", CDbl(row.Cells(compra_cambio.Index).Value).ToString("f5"))
                        End If

                        'Retencion con factura para retencion
                        SQL.Add("DDoc_Prd_Fob", CInt(row.Cells(compra_ref_ciclo.Index).Value))
                        SQL.Add("DDoc_Prd_Cif", CInt(row.Cells(compra_ref_numero.Index).Value))

                        strSQLPDM = SQL.SQLString.Replace("{db}", "PDM.")
                        strSQL = SQL.SQLString.Replace("{db}", STR_VACIO)
                        If Sesion.IdEmpresa = 18 Then
                            strSQL &= String.Concat(";", strSQLPDM)
                        End If
                        MyCnn.CONECTAR = strConexion
                        cmd = New MySqlCommand(strSQL, CON)
                        cmd.ExecuteNonQuery()
                    End If
                Next
            End If
        End If

    End Sub

    'Limpia todos los detalles de los documentos
    Private Sub BorrarDetalles()
        Dim strSQL As String = String.Empty
        Dim cmd As MySqlCommand

        If CasillaAnulado.Checked Then
            'Borrar liquidaciones
            strSQL = "UPDATE Dcmtos_HDR SET HDoc_Pro_DCat={vacio}, HDoc_Pro_DAno={vacio}, HDoc_Pro_DNum={vacio} WHERE HDoc_Sis_Emp={empresa} AND HDoc_Doc_Cat={caja} AND HDoc_Pro_DCat={tipo} AND HDoc_Pro_DAno={ciclo} AND HDoc_Pro_DNum={numero}"
            If Sesion.IdEmpresa = 18 Then
                strSQL &= ";UPDATE PDM.Dcmtos_HDR SET HDoc_Pro_DCat={vacio}, HDoc_Pro_DAno={vacio}, HDoc_Pro_DNum={vacio} WHERE HDoc_Sis_Emp={empresa} AND HDoc_Doc_Cat={caja} AND HDoc_Pro_DCat={tipo} AND HDoc_Pro_DAno={ciclo} AND HDoc_Pro_DNum={numero}"
            End If
            strSQL = strSQL.Replace("{empresa}", Sesion.IdEmpresa)
            strSQL = strSQL.Replace("{vacio}", INT_CERO)
            strSQL = strSQL.Replace("{caja}", 246)
            strSQL = strSQL.Replace("{tipo}", Tipo)
            strSQL = strSQL.Replace("{ciclo}", Ciclo)
            strSQL = strSQL.Replace("{numero}", Numero)
            MyCnn.CONECTAR = strConexion
            cmd = New MySqlCommand(strSQL, CON)
            cmd.ExecuteNonQuery()

            'Recuperar el ID del tipo de documento si no ha sido asignado (anticipo)
            If Base.IdAnticipo.Equals(INT_CERO) Then
                Base.CargarTipos()
            End If

            'Borrar anticipos
            strSQL = " DELETE " &
                     " FROM Dcmtos_HDR, Dcmtos_DTL " &
                     " USING Dcmtos_HDR " &
                     "       LEFT JOIN Dcmtos_DTL ON Dcmtos_DTL.DDoc_Sis_Emp=Dcmtos_HDR.HDoc_Sis_Emp AND Dcmtos_DTL.DDoc_Doc_Cat=Dcmtos_HDR.HDoc_Doc_Cat AND Dcmtos_DTL.DDoc_Doc_Ano=Dcmtos_HDR.HDoc_Doc_Ano AND Dcmtos_DTL.DDoc_Doc_Num=Dcmtos_HDR.HDoc_Doc_Num " &
                     " WHERE Dcmtos_HDR.HDoc_Sis_Emp={empresa} AND Dcmtos_HDR.HDoc_Doc_Cat={anticipos} AND Dcmtos_HDR.HDoc_Pro_DCat={tipo} AND Dcmtos_HDR.HDoc_Pro_DAno={ciclo} AND Dcmtos_HDR.HDoc_Pro_DNum={numero} "
            If Sesion.IdEmpresa = 18 Then
                strSQL &= "; DELETE " &
                     " FROM PDM.Dcmtos_HDR, PDM.Dcmtos_DTL " &
                     " USING PDM.Dcmtos_HDR " &
                     "       LEFT JOIN PDM.Dcmtos_DTL ON PDM.Dcmtos_DTL.DDoc_Sis_Emp=PDM.Dcmtos_HDR.HDoc_Sis_Emp AND PDM.Dcmtos_DTL.DDoc_Doc_Cat=PDM.Dcmtos_HDR.HDoc_Doc_Cat AND PDM.Dcmtos_DTL.DDoc_Doc_Ano=PDM.Dcmtos_HDR.HDoc_Doc_Ano AND PDM.Dcmtos_DTL.DDoc_Doc_Num=PDM.Dcmtos_HDR.HDoc_Doc_Num " &
                     " WHERE PDM.Dcmtos_HDR.HDoc_Sis_Emp={empresa} AND PDM.Dcmtos_HDR.HDoc_Doc_Cat={anticipos} AND PDM.Dcmtos_HDR.HDoc_Pro_DCat={tipo} AND PDM.Dcmtos_HDR.HDoc_Pro_DAno={ciclo} AND PDM.Dcmtos_HDR.HDoc_Pro_DNum={numero} "
            End If
            strSQL = strSQL.Replace("{empresa}", Sesion.IdEmpresa)
            strSQL = strSQL.Replace("{anticipos}", Base.IdAnticipo)
            strSQL = strSQL.Replace("{tipo}", Tipo)
            strSQL = strSQL.Replace("{ciclo}", Ciclo)
            strSQL = strSQL.Replace("{numero}", Numero)
            MyCnn.CONECTAR = strConexion
            cmd = New MySqlCommand(strSQL, CON)
            cmd.ExecuteNonQuery()
        End If

        'Borrar ventas
        strSQL = "DDoc_Sis_Emp={empresa} AND DDoc_Doc_Cat={tipo} AND DDoc_Doc_Ano={ciclo} AND DDoc_Doc_Num={numero}"
        strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
        strSQL = Replace(strSQL, "{tipo}", Tipo)
        strSQL = Replace(strSQL, "{ciclo}", Ciclo)
        strSQL = Replace(strSQL, "{numero}", Numero)
        Dim dtl As New clsDcmtos_DTL
        dtl.CONEXION = strConexion
        dtl.Borrar(strSQL)

        'Borrar movimiento
        strSQL = "BMov_Sis_Emp={empresa} AND BMov_Cta={id} AND BMov_Doc_Cat={tipo} AND BMov_Doc_Ano={ciclo} AND BMov_Doc_Num={numero}"
        strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
        strSQL = Replace(strSQL, "{id}", Cuenta)
        strSQL = Replace(strSQL, "{tipo}", Tipo)
        strSQL = Replace(strSQL, "{ciclo}", Ciclo)
        strSQL = Replace(strSQL, "{numero}", Numero)
        Dim mvtosBcos As New Tablas.TMVTOSBCOS
        mvtosBcos.CONEXION = strConexion
        mvtosBcos.PDELETE(strSQL)

        'Borrar créditos en compras
        strSQL = "ECta_Sis_Emp={empresa} AND ECta_Doc_Cat IN({tipo}) AND ECta_Doc_Ano={ciclo} AND ECta_Doc_Num={numero}"
        strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
        strSQL = Replace(strSQL, "{tipo}", Tipo & "," & INT_CERO)
        strSQL = Replace(strSQL, "{ciclo}", Ciclo)
        strSQL = Replace(strSQL, "{numero}", Numero)
        Dim ectacte As New Tablas.TECTACTE
        ectacte.CONEXION = strConexion
        ectacte.PDELETE(strSQL)
    End Sub

    'Guarda los datos del encabezado
    Private Function GuardarDatos() As Boolean

        Dim strSQL As String = String.Empty
        Dim strSQLPDM As String = String.Empty
        Dim strCC As String = String.Empty
        Dim dblEfectivo As Double = CDbl(CeldaEfectivo.Text)
        Dim logEx As Boolean = False
        Dim SQL As New clsQuery
        Dim cmd As MySqlCommand

        SQL.Name = "{db}Dcmtos_HDR"
        If EsNuevo Then
            If logInsertar = True Then
                'Registro nuevo
                SQL.Kind = clsQuery.Mode.Insert
                SQL.Add("HDoc_Sis_Emp", Sesion.IdEmpresa)
                SQL.Add("HDoc_Doc_Cat", Tipo)
                SQL.Add("HDoc_Doc_Ano", Ciclo)
                SQL.Add("HDoc_Doc_Num", Numero)
            Else
                logEx = False
                MsgBox("You do not have permission for this action", vbInformation, "Notice")
                Exit Function
            End If
        Else
            If logEditar = True Then
                'Registro existente
                SQL.Kind = clsQuery.Mode.Update
                strSQL = "HDoc_Sis_Emp={empresa} AND HDoc_Doc_Cat={tipo} AND HDoc_Doc_Ano={ciclo} AND HDoc_Doc_Num={id}"
                strSQL = strSQL.Replace("{empresa}", Sesion.IdEmpresa)
                strSQL = strSQL.Replace("{tipo}", Tipo)
                strSQL = strSQL.Replace("{ciclo}", Ciclo)
                strSQL = strSQL.Replace("{id}", Numero)
            Else
                logEx = False
                MsgBox("You do not have permission for this action", vbInformation, "Notice")
                Exit Function
            End If
        End If

        'Datos de entidad
        SQL.Add("HDoc_Emp_Cod", intEntidad)
        SQL.Add("HDoc_Emp_Nom", Base.Text(CeldaEmpresa.Text))
        SQL.Add("HDoc_DR1_Emp", CInt(IIf(CasillaProveedores.Checked, INT_UNO, INT_CERO)))

        'Dependiendo del grupo
        Select Case Grupo
            Case clsBancos.BancoGrupo.Proveedor
                'Anticipo de compra
                SQL.Add("HDoc_Ant_Com", CDbl(CeldaAnticipo.Text))
            Case clsBancos.BancoGrupo.Caja
                If intItem.Equals(clsBancos.EnumCaja.Liquidacion) Then
                    'Asignar strCC cuenta contable de diferencia entre monto de documento y liquidacion
                    If CDbl(CeldaDiferencia.Text) <> 0.0 Then
                        strCC = CeldaCuenta.Text
                        If Not (strCC.Equals(String.Empty)) Then
                            'Si tiene cuenta asignar dblEfectivo es campo diferencia
                            dblEfectivo = CDbl(CeldaDiferencia.Text)
                        End If
                    End If
                End If
            Case clsBancos.BancoGrupo.Transferencia
                'Asignar strCC cuenta contable
                strCC = CeldaCuenta.Text
        End Select

        'Moneda
        SQL.Add("HDoc_Doc_Mon", Moneda)
        SQL.Add("HDoc_Doc_Tc", CDbl(CeldaTasa.Text))

        SQL.Add("HDoc_Doc_Fec", Base.Text(Fecha.Value.ToString(FORMATO_MYSQL)))
        SQL.Add("HDoc_DR1_Cat", Grupo)
        SQL.Add("HDoc_DR1_Num", Base.Text(CeldaNumero.Text))
        SQL.Add("HDoc_DR1_Dbl", CDbl(CeldaGastos.Text))
        SQL.Add("HDoc_DR2_Cat", intItem)
        SQL.Add("HDoc_DR2_Num", Base.Text(CeldaReferencia.Text))
        SQL.Add("HDoc_RF1_Num", Cuenta)
        SQL.Add("HDoc_RF1_Cod", Base.Text(CeldaConcepto.Text))
        SQL.Add("HDoc_RF1_Dbl", CDbl(CeldaMonto.Text))
        SQL.Add("HDoc_RF1_Txt", Base.Text(CeldaNotas.Text))
        SQL.Add("HDoc_Emp_Per", Base.Text(CeldaPersona.Text))
        SQL.Add("HDoc_RF2_Cod", Base.Text(strCC))
        SQL.Add("HDoc_RF2_Num", Documento)
        SQL.Add("HDoc_RF2_Dbl", dblEfectivo)
        SQL.Add("HDoc_RF2_Txt", Base.Text(EtiquetaLetras.Text))
        SQL.Add("HDoc_RF3_Dbl", CDbl(CeldaCheques.Text))

        'Documento relacionado
        SQL.Add("HDoc_Pro_DCat", Relacion.Tipo)
        SQL.Add("HDoc_Pro_DAno", Relacion.Ciclo)
        SQL.Add("HDoc_Pro_DNum", Relacion.Numero)

        'Documento confidencial
        SQL.Add("HDoc_DR2_Emp", CInt(IIf(CasillaSecreto.Checked, INT_UNO, INT_CERO)))

        'Estado del documento
        If CasillaAnulado.Checked Then
            SQL.Add("HDoc_Doc_Status", clsBancos.ES_ANULADO)
        Else
            SQL.Add("HDoc_Doc_Status", IIf(CasillaCobrado.Checked, INT_UNO, INT_CERO))
        End If
        SQL.Add("HDoc_Usuario", Base.Text(Sesion.Usuario))
        strSQLPDM = (SQL.SQLString & strSQL).Replace("{db}", "PDM.")
        strSQL = (SQL.SQLString & strSQL).Replace("{db}", STR_VACIO)
        If Sesion.IdEmpresa = 18 Then
            strSQL &= String.Concat(";", strSQLPDM)
        End If
        MyCnn.CONECTAR = strConexion
        cmd = New MySqlCommand(strSQL, CON)

        cmd.ExecuteNonQuery()

        'Guardar referencia si hay documento relacionado
        If Not (Relacion.Tipo.Equals(INT_CERO)) Then
            SQL = New clsQuery
            SQL.Name = "{db}Dcmtos_HDR"
            SQL.Kind = clsQuery.Mode.Update

            SQL.Add("HDoc_Pro_DCat", Tipo)
            SQL.Add("HDoc_Pro_DAno", Ciclo)
            SQL.Add("HDoc_Pro_DNum", Numero)

            strSQL = "HDoc_Sis_Emp={empresa} AND HDoc_Doc_Cat={tipo} AND HDoc_Doc_Ano={ciclo} AND HDoc_Doc_Num={id}"
            strSQL = strSQL.Replace("{empresa}", Sesion.IdEmpresa)
            strSQL = strSQL.Replace("{tipo}", Relacion.Tipo)
            strSQL = strSQL.Replace("{ciclo}", Relacion.Ciclo)
            strSQL = strSQL.Replace("{id}", Relacion.Numero)
            strSQLPDM = (SQL.SQLString & strSQL).Replace("{db}", "PDM.")
            strSQL = (SQL.SQLString & strSQL).Replace("{db}", STR_VACIO)
            If Sesion.IdEmpresa = 18 Then
                strSQL &= String.Concat(";", strSQLPDM)
            End If
            MyCnn.CONECTAR = strConexion
            cmd = New MySqlCommand(strSQL, CON)
            cmd.ExecuteNonQuery()
        End If

        _EsNuevo = False
        logEx = True

        Return logEx
    End Function

    'Comprobar los datos del documento antes de guardar
    Private Function ComprobarDocumento() As Boolean
        Dim logCancelar As Boolean = False
        Dim logOk As Boolean = False

        Dim dblMonto As Double = Math.Round(CDbl(CeldaMonto.Text), 2)
        Dim dblSuma As Double

        Select Case Grupo
            Case clsBancos.BancoGrupo.Transferencia
                CeldaEfectivo.Text = CeldaMonto.Text
        End Select

        SumarDeposito()
        SumarCompras(True)
        SumarVentas()

        'Total del deposito (sin gastos)
        dblSuma = Math.Round(CDbl(CeldaMonto.Text) + CDbl(CeldaCheques.Text) + CDbl(CeldaOtrosBancos.Text), 2)

        'Documento anulado en la sesion actual
        If CasillaAnulado.Checked And Not EsNuevo Then
            If Not (MessageBox.Show("This document was " & CasillaAnulado.Text & Constants.vbCrLf & Constants.vbCr & "¿Continue?", "Warning", MessageBoxButtons.YesNo, MessageBoxIcon.Question) = DialogResult.Yes) Then
                logCancelar = True
            End If
        End If

        If Not logCancelar Then
            Select Case Grupo
                Case clsBancos.BancoGrupo.Proveedor
                    If intItem.Equals(clsBancos.EnumProveedor.Pago) And intEntidad.Equals(INT_CERO) And CasillaProveedores.Checked = False Then
                        If Not CasillaAnulado.Checked Then
                            MessageBox.Show("You must select a provider for this document", "Provider", MessageBoxButtons.OK, MessageBoxIcon.Warning)
                            CeldaEmpresa.Focus()
                            logCancelar = True
                        End If
                    ElseIf intItem.Equals(clsBancos.EnumProveedor.Anticipo) Then
                        If intEntidad.Equals(INT_CERO) Then
                            MessageBox.Show("Provider is required for purchase advance", "Provider", MessageBoxButtons.OK, MessageBoxIcon.Warning)
                            CeldaEmpresa.Focus()
                            logCancelar = True
                        ElseIf CDbl(CeldaAnticipo.Text) <= 0.0 Then
                            MessageBox.Show("Enter a valid amount in advance payment field", "Advance payment", MessageBoxButtons.OK, MessageBoxIcon.Warning)
                            logCancelar = True
                        End If
                        'TODO verificar si tiene cuenta de anticipos en contabilidad
                    End If
                Case clsBancos.BancoGrupo.Cliente
                    If intEntidad.Equals(INT_CERO) Then
                        MessageBox.Show("You must select a customer for this document", "Customer", MessageBoxButtons.OK, MessageBoxIcon.Warning)
                        CeldaEmpresa.Focus()
                        logCancelar = True
                    ElseIf Not dblMonto.Equals(Math.Round(CDbl(CeldaTotalVenta.Text) - CDbl(CeldaGastos.Text), 2)) Then
                        'MR.191009 se redondea para evitar problemas de precision en conversion al comparar decimales
                        MessageBox.Show("Total amount of invoices and deposit amount do not match" & vbCr & vbCr & "Document amount: " & Math.Round(dblMonto, 2).ToString("f") & vbCr & "Invoices - expenses: " & Math.Round(CDbl(CeldaTotalVenta.Text) - CDbl(CeldaGastos.Text), 2).ToString("f"), "Customer", MessageBoxButtons.OK, MessageBoxIcon.Warning)
                        CeldaMonto.Focus()
                        logCancelar = True
                    End If
                Case clsBancos.BancoGrupo.Caja
                    If intEntidad.Equals(INT_CERO) Then
                        MessageBox.Show("You must select a petty cash for this document", "Petty Cash", MessageBoxButtons.OK, MessageBoxIcon.Warning)
                        CeldaEmpresa.Focus()
                        logCancelar = True
                    ElseIf intItem.Equals(clsBancos.EnumCaja.Liquidacion) Then
                        If Relacion.Tipo.Equals(INT_CERO) Then
                            MessageBox.Show("You must select a petty cash reconciliation", "Petty Cash", MessageBoxButtons.OK, MessageBoxIcon.Warning)
                            logCancelar = True
                        ElseIf Not CDbl(CeldaDiferencia.Text).Equals(0.0) And CeldaCuenta.Text.Trim.Equals(String.Empty) Then
                            MessageBox.Show("No journal account have been selected", "Reconciliation difference", MessageBoxButtons.OK, MessageBoxIcon.Warning)
                            logCancelar = True
                        End If
                    ElseIf intItem.Equals(clsBancos.EnumCaja.Apertura) Then
                        If CeldaEmpresa.Text.ToUpper.Contains("VIATICOS") Then
                            MessageBox.Show("Transaction not allowed for this petty cash type", "Petty Cash", MessageBoxButtons.OK, MessageBoxIcon.Warning)
                            logCancelar = True
                        End If
                    End If
                Case clsBancos.BancoGrupo.Transferencia
                    If intItem.Equals(clsBancos.EnumTransferencia.Depositos) And intEntidad.Equals(INT_CERO) Then
                        MessageBox.Show("You must select a bank account", "Bank Transfer", MessageBoxButtons.OK, MessageBoxIcon.Warning)
                        CeldaEmpresa.Focus()
                        logCancelar = True
                    ElseIf intItem.Equals(clsBancos.EnumTransferencia.Gasto) And CeldaCuenta.Text.Equals(String.Empty) Then
                        MessageBox.Show("You must select a ledger account", "Expenses", MessageBoxButtons.OK, MessageBoxIcon.Warning)
                        CeldaCuenta.Focus()
                        logCancelar = True
                    End If
            End Select

            If Not logCancelar Then
                If intItem.Equals(NO_FILA) Then
                    MessageBox.Show("You must select the transaction type", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning)
                    BotonTransaccion.Focus()
                ElseIf CeldaDocumento.Text.Trim.Equals(String.Empty) Then
                    MessageBox.Show("Document type is required", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning)
                    CeldaDocumento.Focus()
                ElseIf CeldaNumero.Text.Trim.Equals(String.Empty) Then
                    MessageBox.Show("Document number is a required field", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning)
                    CeldaNumero.Focus()
                ElseIf CDbl(CeldaTasa.Text) <= 0 Then
                    MessageBox.Show("Exchange rate must be greater than zero", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning)
                    CeldaTasa.Focus()
                ElseIf CDbl(CeldaMonto.Text) <= 0 And CasillaCobrado.Checked Then
                    MessageBox.Show("Zero amount document is not allowed", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning)
                    CeldaMonto.Focus()
                ElseIf Tipo.Equals(Base.IdDeposito) And Not dblMonto.Equals(dblSuma) Then
                    MessageBox.Show("Deposit amount and amount field do not match", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning)
                    CeldaMonto.Focus()
                Else
                    If Tipo.Equals(Base.IdCheque) Or Tipo.Equals(Base.IdDebito) Then
                        'Total de compras (ref. proveedores)
                        If Grupo.Equals(clsBancos.BancoGrupo.Proveedor) Then
                            If Not dblMonto.Equals(Math.Round(CDbl(CeldaTotalCompra.Text) - CDbl(CeldaAnticipo.Text), 2)) Then
                                'MR.191009 se redondea para evitar problemas de precision en conversion al comparar decimales
                                MessageBox.Show("Total amount - advance payment and amount field do not match" & vbCr & vbCr & "Document amount: " & Math.Round(dblMonto, 2).ToString("f") & vbCr & "Total - advance payment: " & Math.Round(CDbl(CeldaTotalCompra.Text) - CDbl(CeldaAnticipo.Text), 2).ToString("f"), "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning)
                                CeldaMonto.Focus()
                                logCancelar = True
                            End If
                        ElseIf (Grupo.Equals(clsBancos.BancoGrupo.Caja) And intItem.Equals(clsBancos.EnumCaja.Liquidacion)) Or Grupo.Equals(clsBancos.BancoGrupo.Planilla) Then
                            If Not CDbl(CeldaTotalCaja.Text).Equals(Math.Round(CDbl(CeldaMonto.Text) - CDbl(CeldaDiferencia.Text), 2)) Then
                                'MR.191009 se redondea para evitar problemas de precision en conversion al comparar decimales
                                MessageBox.Show("Total amount + difference and amount field do not match" & vbCr & vbCr & "Document amount: " & Math.Round(dblMonto, 2).ToString("f") & vbCr & "Total + difference: " & Math.Round(CDbl(CeldaTotalCaja.Text) + CDbl(CeldaDiferencia.Text), 2).ToString("f"), "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning)
                                logCancelar = True
                            End If
                        ElseIf Grupo.Equals(clsBancos.BancoGrupo.Impuestos) And intItem.Equals(clsBancos.EnumImpuestos.ISRRetenciones) Then
                            If Not dblMonto.Equals(Math.Round(CDbl(CeldaTotalCompra.Text), 2)) Then
                                'MR.191009 se redondea para evitar problemas de precision en conversion al comparar decimales
                                MessageBox.Show("Total amount of retention and amount field do not match" & vbCr & vbCr & "Document amount: " & Math.Round(dblMonto, 2).ToString("f") & vbCr & "Total amount: " & Math.Round(CDbl(CeldaTotalCompra.Text), 2).ToString("f"), "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning)
                                CeldaMonto.Focus()
                                logCancelar = True
                            End If
                        End If
                    End If

                    'Total de ventas (ref. clientes)
                    If Grupo.Equals(clsBancos.BancoGrupo.Cliente) Then
                        dblSuma = Math.Round(CDbl(CeldaTotalVenta.Text) - CDbl(CeldaGastos.Text), 2)
                        If dblSuma > INT_CERO Then
                            If Not dblMonto.Equals(dblSuma) Then
                                MessageBox.Show("The total amount of invoices do not match with the amount field" & Constants.vbCrLf & Constants.vbCrLf &
                                                "(Sales - Expenses) = " & dblSuma.ToString("f") & Constants.vbCrLf &
                                                "Amount = " & dblMonto.ToString("f"), "Warning", MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
                                logCancelar = True
                            End If
                        End If

                        If Not logCancelar Then
                            For Each row As DataGridViewRow In Ventas.Rows
                                If Not ComprobarVenta(row) Then
                                    logCancelar = True
                                End If
                            Next
                        End If
                    End If

                    logOk = Not (logCancelar)
                End If
            End If
        End If
        Return logOk
    End Function

    'Comprueba una fila del detalle de ventas
    Private Function ComprobarVenta(ByRef row As DataGridViewRow, Optional Aviso As Boolean = True) As Boolean
        Dim dblTasa As Double = CDbl(CeldaTasa.Text)
        Dim dblMonto As Double = CDbl(row.Cells(venta_monto.Index).Value)
        Dim dblTotal As Double = CDbl(row.Cells(venta_total.Index).Value)
        Dim intMon As Integer = CInt(row.Cells(venta_moneda.Index).Value)
        Dim logOk As Boolean = False

        If intMon.Equals(INT_CERO) Then
            'Cargos manuales
            row.Cells(venta_moneda.Index).Value = Moneda
            row.Cells(venta_tasa.Index).Value = dblTasa
            row.Cells(venta_monto.Index).Value = dblTotal
        ElseIf Not (dblMonto.Equals(dblTotal)) Then
            If intMon.Equals(Moneda) Then
                dblMonto = dblTotal
            ElseIf Moneda.Equals(intMonedaLocal) Then
                'Local -> Exterior
                dblMonto = Math.Round(dblTotal / dblTasa, 2)
            Else : dblMonto = Math.Round(dblTotal * dblTasa, 2)
            End If
            row.Cells(venta_monto.Index).Value = dblMonto
        End If

        If row.Cells(venta_ref.Index).Value.ToString.Trim.Equals(String.Empty) And dblTotal > INT_CERO Then
            If Aviso Then
                MessageBox.Show("Check data for row N° " & CInt(row.Index + 1).ToString("D2"), "Invoices and Debits", MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
                Ventas.Focus()
            End If
        ElseIf Aviso Then
            logOk = True
        Else
            logOk = (dblTotal > INT_CERO)
        End If

        Return logOk
    End Function

    'Carga los tipos de transacción de acuerdo al grupo
    Private Function ListaDeItems(ByVal Grupo As Integer, Optional Indice As Integer = NO_FILA) As String
        Dim strModo As String = String.Empty
        Dim strSQL As String = String.Empty
        Dim intDef As Integer = NO_FILA
        Dim logNada As Boolean = True
        Dim logActivo As Boolean = False
        Dim Items() As String
        Dim i As Integer

        'Items disponibles por cada grupo
        Select Case Grupo
            Case clsBancos.BancoGrupo.Proveedor
                Select Case Tipo
                    Case Base.IdDeposito : strModo = "0010"
                    Case Base.IdCheque : strModo = "1011"
                    Case Base.IdDebito : strModo = "1011"
                End Select
            Case clsBancos.BancoGrupo.Empleado
                Select Case Tipo
                    Case Base.IdCheque : strModo = "11110111111"
                    Case Base.IdDebito : strModo = "11110111111"
                    Case Base.IdDeposito : strModo = "00001000000"
                End Select
            Case clsBancos.BancoGrupo.Caja
                Select Case Tipo
                    Case Base.IdCheque : strModo = "1110"
                    Case Base.IdDeposito : strModo = "0011"
                    Case Base.IdDebito : strModo = "1010"
                End Select
            Case clsBancos.BancoGrupo.Impuestos
                Select Case Tipo
                    Case Base.IdDebito : strModo = "10111"
                End Select
        End Select
        logNada = strModo.Equals(String.Empty)

        'Construir la instruccion SQL para ser usado posteriormente en el formulario de seleccion
        Items = Base.ItemsDeGrupo(Grupo)
        For i = INT_CERO To Items.Length - 1
            If logNada Then
                logActivo = True
            Else : logActivo = strModo.Substring(i, 1).Equals("1")
            End If
            If logActivo Then
                If intDef.Equals(NO_FILA) Then intDef = i
                If Not (strSQL.Equals(String.Empty)) Then
                    strSQL &= " UNION "
                End If
                strSQL &= String.Format("(SELECT {0} ID, {1} Description)", i, Base.Text(Items(i)))
            End If
        Next
        If Not strSQL.Equals(String.Empty) Then
            strSQL = String.Format("({0}) x", strSQL)
        End If

        'Item predeterminado o actual
        EtiquetaTituloTransaccion.Text = Items(intDef)
        If EsNuevo Then
            intItem = intDef
        ElseIf Indice = NO_FILA Then
            intItem = intDef
        End If

        Return strSQL
    End Function

    'Devuelve la suma de cheques de otros bancos
    Private Function SumarCheques() As Double
        Dim dblSuma As Double = 0.0
        Dim row As DataGridViewRow
        For Each row In Cheques.Rows
            dblSuma += CDbl(row.Cells(cheque_monto.Index).Value)
        Next
        Return dblSuma
    End Function

    'Suma los totales de ventas
    Private Sub SumarVentas()
        Dim dblSuma As Double = 0.0
        Dim row As DataGridViewRow
        For Each row In Ventas.Rows
            dblSuma += CDbl(row.Cells(venta_total.Index).Value)
        Next
        CeldaTotalVenta.Text = dblSuma.ToString("f")
    End Sub

    'Suma los totales de compras
    Private Sub SumarCompras(Optional ParaGuardar As Boolean = False)
        Dim dblSuma As Double = 0.0
        Dim intCuenta As Integer = 0
        Dim row As DataGridViewRow
        For Each row In Compras.Rows
            dblSuma += CDbl(row.Cells(compra_monto.Index).Value)
            If Not row.Cells(compra_cuenta.Index).Value.Equals(String.Empty) Then
                intCuenta += 1
            End If
        Next
        CeldaTotalCompra.Text = dblSuma.ToString("f")

        If ParaGuardar Then
            'Si hay varias lineas de compras y una de ellas es una cuenta o varias cuentas contables habilitar activar casilla
            If Grupo.Equals(clsBancos.BancoGrupo.Proveedor) Then
                If (Compras.Rows.Count > 1 And intCuenta > 0) Or intCuenta > 1 Then
                    CasillaProveedores.Checked = True
                End If
            End If
        End If
    End Sub

    'Suma los totales de compras
    Private Sub SumarCaja()
        Dim dblSuma As Double = 0.0
        Dim row As DataGridViewRow
        For Each row In Caja.Rows
            dblSuma += CDbl(row.Cells(caja_total.Index).Value)
        Next
        CeldaTotalCaja.Text = dblSuma.ToString("f")
    End Sub

    'Carga el detalle de presupuesto para el documento actual (debito)
    Private Sub CargarPresupuesto()
        Dim strSQL As String = String.Empty
        Dim cmd As MySqlCommand
        Dim da As MySqlDataAdapter
        Dim dt As System.Data.DataTable
        Dim dato As clsBancos.DatoLista

        strSQL = " SELECT d.cuenta cuenta, IF(d.moneda={moneda},d.importe_loc, d.importe_ext) monto, c.nombre_loc nombre, c.nombre_ext nombre2 " &
                 " FROM {conta}.detalle_presupuesto d " &
                 "      LEFT JOIN {conta}.cuentas_presupuesto c On c.empresa=d.empresa And c.id_cuenta=d.cuenta " &
                 " WHERE d.empresa={empresa} And d.categoria={categoria} And d.ano={ciclo} And d.numero={numero} "
        strSQL = strSQL.Replace("{conta}", Sesion.BaseConta)
        strSQL = strSQL.Replace("{empresa}", Sesion.IdEmpresa)
        strSQL = strSQL.Replace("{categoria}", Tipo)
        strSQL = strSQL.Replace("{ciclo}", Ciclo)
        strSQL = strSQL.Replace("{numero}", Numero)
        strSQL = strSQL.Replace("{moneda}", intMonedaLocal)
        MyCnn.CONECTAR = strConexion
        cmd = New MySqlCommand(strSQL, CON)
        da = New MySqlDataAdapter(cmd)
        dt = New System.Data.DataTable
        da.Fill(dt)

        For Each dr As DataRow In dt.Rows
            dato = New clsBancos.DatoLista
            dato.Codigo = dr("cuenta").ToString
            dato.Texto = dr("nombre").ToString
            dato.Texto2 = dr("nombre2").ToString
            dato.Monto = CDbl(dr("monto"))
            Presupuesto.Add(dato)
        Next
    End Sub

    'Asigna el detalle de presupuesto para este documento
    Private Sub ModificarPresupuesto()
        Dim dato As clsBancos.DatoLista

        Using frm As New frmBPresupuesto
            CargarDetalleDePresupuesto(frm.Lista)
            frm.Sumar()
            frm.Monto = (CeldaMonto.Text)
            If frm.ShowDialog() = DialogResult.OK Then
                'Actualizar lista con los cambios efectuados
                Presupuesto = New List(Of clsBancos.DatoLista)
                For Each row As DataGridViewRow In frm.Lista.Rows
                    dato = New clsBancos.DatoLista
                    dato.Codigo = row.Cells(frm.Lista.Columns.Item("lista_cuenta").Index).Value
                    dato.Texto = row.Cells(frm.Lista.Columns.Item("lista_nombre").Index).Value
                    dato.Texto2 = row.Cells(frm.Lista.Columns.Item("lista_name").Index).Value
                    dato.Monto = CDbl(row.Cells(frm.Lista.Columns.Item("lista_monto").Index).Value)
                    Presupuesto.Add(dato)
                Next
                If EsNuevo = False Then
                    GuardarPresupuesto()
                End If
            End If
        End Using
    End Sub

    'Carga los documentos de venta con saldo pendiente de pago (ref. cliente)
    Private Sub CargarDetalleDePresupuesto(ByRef Lista As DataGridView)
        Dim row As DataGridViewRow

        Lista.Rows.Clear()
        Lista.SuspendLayout()
        Lista.AllowUserToAddRows = True

        If Presupuesto.Count > INT_CERO Then
            For Each dato As clsBancos.DatoLista In Presupuesto
                'Si no ha sido agregado aun
                row = Lista.Rows(Lista.NewRowIndex).Clone
                row.Cells(Lista.Columns.Item("lista_cuenta").Index).Value = dato.Codigo
                row.Cells(Lista.Columns.Item("lista_nombre").Index).Value = dato.Texto
                row.Cells(Lista.Columns.Item("lista_name").Index).Value = dato.Texto2
                row.Cells(Lista.Columns.Item("lista_monto").Index).Value = dato.Monto.ToString("f2")

                Lista.Rows.Add(row)
            Next
        End If
        Lista.AllowUserToAddRows = False
        Lista.ResumeLayout()
    End Sub

    'Carga el detalle de facturas para clientes
    Private Sub CargarVentas()
        Dim strSQL As String = String.Empty
        Dim strTemp As String = String.Empty
        Dim cmd As MySqlCommand
        Dim da As MySqlDataAdapter
        Dim dt As System.Data.DataTable
        Dim dr As DataRow
        Dim gr As DataGridViewRow

        'Informacion del recibo
        strSQL = " Select CAST(CONCAT(CAST(c.cat_desc As Char), ' N° ', a.HDoc_Doc_Num, ' dated ', DATE_FORMAT(a.HDoc_Doc_Fec, '%m/%d/%Y')) AS CHAR) Dato " &
                 " FROM Dcmtos_HDR a " &
                 "    LEFT JOIN Catalogos c ON c.cat_num = a.HDoc_Doc_Cat " &
                 " WHERE a.HDoc_Sis_Emp={empresa} AND a.HDoc_Doc_Cat={recibo} AND a.HDoc_Pro_DCat={tipo} AND a.HDoc_Pro_DAno={ciclo} AND a.HDoc_Pro_DNum={numero}"
        strSQL = strSQL.Replace("{empresa}", Sesion.IdEmpresa)
        strSQL = strSQL.Replace("{tipo}", Tipo)
        strSQL = strSQL.Replace("{ciclo}", Ciclo)
        strSQL = strSQL.Replace("{numero}", Numero)
        strSQL = strSQL.Replace("{recibo}", Base.IdRecibo)
        MyCnn.CONECTAR = strConexion
        cmd = New MySqlCommand(strSQL, CON)
        strTemp = Convert.ToString(cmd.ExecuteScalar).ToUpper
        Referencia.Text = "REF.: " & strTemp

        'Detalle de facturas
        strSQL = " SELECT h.HDoc_DR1_Dbl NumE,d.DDoc_RF1_Num tipo, d.DDoc_RF2_Num ciclo, IFNULL(o.cat_ext,'') grupo, IFNULL(d.DDoc_RF3_Num,0) numero, IFNULL(d.DDoc_RF1_Cod,'') serie, d.DDoc_RF1_Fec fecha,  " &
                 "        d.DDoc_Prd_UM moneda, d.DDoc_RF3_Dbl tasa, IFNULL(d.DDoc_RF1_Txt,'') referencia, d.DDoc_RF2_Dbl monto, d.DDoc_RF1_Dbl total, IFNULL(d.DDoc_Prd_Cod,0) id_cliente " &
                 " FROM Dcmtos_DTL d" &
                 "      LEFT JOIN Catalogos o ON o.cat_clase='Documentos' AND o.cat_num=d.DDoc_RF1_Num" &
                 " LEFT JOIN Dcmtos_HDR h ON h.HDoc_Sis_Emp = d.DDoc_Sis_Emp AND h.HDoc_Doc_Cat = d.DDoc_RF1_Num AND h.HDoc_Doc_Ano = d.DDoc_RF2_Num AND h.HDoc_Doc_Num = d.DDoc_RF3_Num " &
                 " WHERE d.DDoc_Sis_Emp={empresa} AND d.DDoc_Doc_Cat={tipo} AND d.DDoc_Doc_Ano={ciclo} AND d.DDoc_Doc_Num={numero} AND (d.DDoc_RF2_Cod={venta} OR d.DDoc_RF2_Cod={cuenta} OR d.DDoc_RF2_Cod={debito} ) " &
                 " ORDER BY d.DDoc_Doc_Lin"

        strSQL = strSQL.Replace("{empresa}", Sesion.IdEmpresa)
        strSQL = strSQL.Replace("{tipo}", Tipo)
        strSQL = strSQL.Replace("{ciclo}", Ciclo)
        strSQL = strSQL.Replace("{numero}", Numero)
        strSQL = strSQL.Replace("{venta}", Base.Text(STR_VENTA))
        strSQL = strSQL.Replace("{cuenta}", Base.Text(STR_CUENTA))
        strSQL = strSQL.Replace("{debito}", Base.Text(STR_DEBITO))
        MyCnn.CONECTAR = strConexion


        cmd = New MySqlCommand(strSQL, CON)
        da = New MySqlDataAdapter(cmd)
        dt = New System.Data.DataTable
        da.Fill(dt)

        'Limpiar
        Ventas.Rows.Clear()

        'Cargar detalle
        Ventas.SuspendLayout()
        Ventas.AllowUserToAddRows = True
        For Each dr In dt.Rows
            gr = Ventas.Rows(Ventas.NewRowIndex).Clone
            If CInt(dr("tipo")).Equals(INT_CERO) Then
                'Cargo agregado manualmente
                gr.Cells(venta_tipo.Index).Value = INT_CERO.ToString
                gr.Cells(venta_ciclo.Index).Value = INT_CERO.ToString
                gr.Cells(venta_grupo.Index).Value = String.Empty
                gr.Cells(venta_numero.Index).Value = String.Empty
                gr.Cells(venta_numero.Index).Style.BackColor = Color.LightSlateGray
                gr.Cells(venta_serie.Index).Value = dr("serie").ToString
                gr.Cells(venta_fecha.Index).Value = String.Empty
                gr.Cells(venta_fecha.Index).Style.BackColor = Color.LightSlateGray
                gr.Cells(venta_moneda.Index).Value = INT_CERO.ToString
                gr.Cells(venta_tasa.Index).Value = INT_CERO.ToString
                gr.Cells(venta_ref.Index).Value = dr("referencia").ToString
                gr.Cells(venta_monto.Index).Value = CDbl(dr("monto")).ToString("f")
                gr.Cells(venta_total.Index).Value = CDbl(dr("total")).ToString("f")
                gr.Cells(venta_id.Index).Value = INT_CERO.ToString
            Else
                'Factura de venta
                gr.Cells(venta_tipo.Index).Value = CInt(dr("tipo")).ToString
                gr.Cells(venta_ciclo.Index).Value = CInt(dr("ciclo")).ToString
                gr.Cells(venta_grupo.Index).Value = dr("grupo").ToString
                gr.Cells(venta_numero.Index).Value = CInt(dr("numero")).ToString
                gr.Cells(venta_serie.Index).Value = dr("serie").ToString
                gr.Cells(venta_fecha.Index).Value = CDate(dr("fecha")).ToString(FORMATO_MYSQL)
                gr.Cells(venta_moneda.Index).Value = CInt(dr("moneda")).ToString
                gr.Cells(venta_tasa.Index).Value = dr("tasa").ToString
                gr.Cells(venta_ref.Index).Value = dr("referencia").ToString
                gr.Cells(venta_monto.Index).Value = CDbl(dr("monto")).ToString("f")
                gr.Cells(venta_total.Index).Value = CDbl(dr("total")).ToString("f")
                gr.Cells(venta_id.Index).Value = CInt(dr("id_cliente")).ToString
                gr.Cells(ventas_numero2.Index).Value = CInt(dr("NumE")).ToString
            End If
            Ventas.Rows.Add(gr)
        Next
        Ventas.AllowUserToAddRows = False
        Ventas.ResumeLayout()

        SumarVentas()
    End Sub

    'Carga el detalle de facturas para clientes
    Private Sub CargarCompras()
        Dim strSQL As String = String.Empty
        Dim strTemp As String = String.Empty
        Dim intTipo As Integer
        Dim cmd As MySqlCommand
        Dim da As MySqlDataAdapter
        Dim dt As System.Data.DataTable
        Dim dr As DataRow
        Dim gr As DataGridViewRow

        'Facturas de compra, retenciones de ISR y otros cargos
        strSQL = " SELECT IFNULL(d.DDoc_RF1_Num,0) Tipo, IFNULL(d.DDoc_RF2_Num,0) Ciclo, IFNULL(d.DDoc_RF3_Num,0) Numero, " &
                 "        d.DDoc_RF1_Txt Descripcion, d.DDoc_RF1_Dbl Total, d.DDoc_Prd_Ref Cuenta, d.DDoc_Prd_Fob Ref_Ciclo, d.DDoc_Prd_Cif Ref_Numero, " &
                 "        COALESCE(e.HDoc_Doc_Mon,0) Moneda, d.DDoc_RF2_Dbl Ref_Tasa, COALESCE(e.HDoc_Doc_TC,0) Tasa, IFNULL(c.poliza,0) Poliza,IFNULL(d.DDoc_Prd_Net,0) Monto  " &
                 " FROM Dcmtos_DTL d " &
                 "      LEFT JOIN Dcmtos_HDR e ON e.HDoc_Sis_Emp = d.DDoc_Sis_Emp AND e.HDoc_Doc_Cat = d.DDoc_RF1_Num AND e.HDoc_Doc_Ano = d.DDoc_RF2_Num AND e.HDoc_Doc_Num = d.DDoc_RF3_Num" &
                 "      LEFT JOIN {conta}.polizas c ON c.empresa = e.HDoc_Sis_Emp AND c.ref_tipo = e.HDoc_Doc_Cat AND c.ref_ciclo = e.HDoc_Doc_Ano AND c.ref_numero = e.HDoc_Doc_Num " &
                 " WHERE d.DDoc_Sis_Emp={empresa} AND d.DDoc_Doc_Cat={tipo} AND d.DDoc_Doc_Ano={ciclo} AND d.DDoc_Doc_Num={numero} AND NOT(d.DDoc_RF2_Cod={grupo}) " &
                 " ORDER BY d.DDoc_Doc_Lin"
        strSQL = strSQL.Replace("{empresa}", Sesion.IdEmpresa)
        strSQL = strSQL.Replace("{tipo}", Tipo)
        strSQL = strSQL.Replace("{ciclo}", Ciclo)
        strSQL = strSQL.Replace("{numero}", Numero)
        strSQL = strSQL.Replace("{conta}", Sesion.BaseConta)
        If Grupo.Equals(clsBancos.BancoGrupo.Caja) Then
            strSQL = strSQL.Replace("{grupo}", Base.Text(STR_CAJA))
        Else
            strSQL = strSQL.Replace("{grupo}", Base.Text(STR_VENTA))
        End If
        MyCnn.CONECTAR = strConexion
        cmd = New MySqlCommand(strSQL, CON)
        da = New MySqlDataAdapter(cmd)
        dt = New System.Data.DataTable
        da.Fill(dt)

        'Limpiar
        Compras.Rows.Clear()

        'Cargar detalle
        Compras.SuspendLayout()
        Compras.AllowUserToAddRows = True
        For Each dr In dt.Rows
            gr = Compras.Rows(Compras.NewRowIndex).Clone
            intTipo = CInt(dr("tipo")).ToString
            gr.Cells(compra_tipo.Index).Value = intTipo
            gr.Cells(compra_ciclo.Index).Value = CInt(dr("ciclo")).ToString
            gr.Cells(compra_numero.Index).Value = CInt(dr("numero")).ToString
            gr.Cells(compra_moneda.Index).Value = CInt(dr("moneda")).ToString

            'Tasa del documento y tasa alterna almacenada en el detalle del documento bancario
            gr.Cells(compra_tasa.Index).Value = CDbl(dr("tasa")).ToString("f5")
            gr.Cells(compra_cambio.Index).Value = CDbl(dr("Ref_Tasa")).ToString("f5")
            'Marca X si se tiene una tasa de cambio alterna
            gr.Cells(compra_marca.Index).Value = If(CDbl(dr("Ref_Tasa")) > 0, "#", String.Empty)
            gr.Cells(compra_descripcion.Index).Value = dr("descripcion").ToString
            If intTipo.Equals(INT_CERO) Then
                gr.Cells(compra_descripcion.Index).Style.BackColor = Color.Orchid
            ElseIf CInt(dr("poliza")).Equals(INT_CERO) Then
                gr.Cells(compra_descripcion.Index).Style.BackColor = Color.Orange
            End If
            gr.Cells(compra_monto.Index).Value = CDbl(dr("total")).ToString("f")
            gr.Cells(compra_cuenta.Index).Value = dr("cuenta").ToString
            gr.Cells(compra_ref_ciclo.Index).Value = CInt(dr("ref_ciclo")).ToString
            gr.Cells(compra_ref_numero.Index).Value = CInt(dr("ref_numero")).ToString
            gr.Cells(compra_factura.Index).Value = CDbl(dr("Monto")).ToString
            If intTipo = 44 Or intTipo = 209 Then
                Compras.Columns("col_DocumentoTipo").Visible = True
                gr.Cells(col_DocumentoTipo.Index).Value = IIf(intTipo = 44, "FA", "RECIBO")
            Else
                Compras.Columns("col_DocumentoTipo").Visible = False
            End If
            Compras.Rows.Add(gr)
        Next
        Compras.AllowUserToAddRows = False
        Compras.ResumeLayout()

        SumarCompras()
    End Sub

    'Carga el detalle de la liquidacin actual
    Private Sub CargarLiquidacon()
        Dim strSQL As String = String.Empty
        Dim strDif As String
        Dim dblDif As Double
        Dim cmd As MySqlCommand
        Dim da As MySqlDataAdapter
        Dim dt As System.Data.DataTable
        Dim dr As DataRow
        Dim gr As DataGridViewRow

        'Detalle de liquidacion de caja chica
        With Relacion
            strSQL = Base.SQLDetalleDeLiquidacion(.Tipo, .Ciclo, .Numero)
        End With
        MyCnn.CONECTAR = strConexion
        cmd = New MySqlCommand(strSQL, CON)
        da = New MySqlDataAdapter(cmd)
        dt = New System.Data.DataTable
        da.Fill(dt)

        'Limpiar
        Caja.Rows.Clear()

        'Cargar detalle
        Caja.SuspendLayout()
        Caja.AllowUserToAddRows = True
        For Each dr In dt.Rows
            gr = Caja.Rows(Caja.NewRowIndex).Clone
            strDif = String.Empty
            dblDif = CDbl(dr("diferencia"))
            If Not dblDif.Equals(INT_CERO) Then
                strDif = dblDif.ToString("f")
            End If
            gr.Cells(caja_documento.Index).Value = dr("documento").ToString
            gr.Cells(caja_numero.Index).Value = dr("numero").ToString
            gr.Cells(caja_fecha.Index).Value = CDate(dr("fecha")).ToString("dd/MM/yyyy")
            gr.Cells(caja_nombre.Index).Value = dr("nombre").ToString
            gr.Cells(caja_moneda.Index).Value = dr("moneda").ToString
            gr.Cells(caja_total.Index).Value = CDbl(dr("total")).ToString("f")
            gr.Cells(caja_parcial.Index).Value = strDif
            gr.Cells(caja_concepto.Index).Value = dr("concepto").ToString
            Caja.Rows.Add(gr)
        Next
        Caja.AllowUserToAddRows = False
        Caja.ResumeLayout()

        SumarCaja()
    End Sub

    'Carga el detalle de cheques de otros bancos
    Private Sub CargarCheques()
        Dim strSQL As String = " SELECT DDoc_RF1_Fec fecha, DDoc_RF1_Txt emisor, DDoc_RF1_Cod numero, DDoc_RF1_Dbl monto, DDoc_RF1_Num estado " &
                               " FROM Dcmtos_DTL " &
                               " WHERE DDoc_Sis_Emp={empresa} AND DDoc_Doc_Cat={tipo} AND DDoc_Doc_Ano={ciclo} AND DDoc_Doc_Num={numero} AND (DDoc_RF2_Cod = 'CHEQUE') " &
                               " ORDER BY DDoc_Doc_Lin"
        strSQL = strSQL.Replace("{empresa}", Sesion.IdEmpresa)
        strSQL = strSQL.Replace("{tipo}", Tipo)
        strSQL = strSQL.Replace("{ciclo}", Ciclo)
        strSQL = strSQL.Replace("{numero}", Numero)

        Dim intEstado As Integer = INT_CERO
        Dim strEstado As String = String.Empty
        MyCnn.CONECTAR = strConexion
        Dim cmd As New MySqlCommand(strSQL, CON)
        Dim da As New MySqlDataAdapter(cmd)
        Dim dt As New System.Data.DataTable
        Dim dr As DataRow
        Dim gr As DataGridViewRow
        da.Fill(dt)

        'Formato de columnas
        Cheques.Rows.Clear()

        'Cargar detalle
        Cheques.SuspendLayout()
        Cheques.AllowUserToAddRows = True
        For Each dr In dt.Rows
            gr = Cheques.Rows(Cheques.NewRowIndex).Clone
            gr.Cells(cheque_fecha.Index).Value = CDate(dr("fecha")).ToString(FORMATO_MYSQL)
            gr.Cells(cheque_emisor.Index).Value = dr("emisor").ToString
            gr.Cells(cheque_numero.Index).Value = dr("numero").ToString
            gr.Cells(cheque_monto.Index).Value = CDbl(dr("monto")).ToString("f")
            intEstado = CInt(dr("estado"))
            Select Case intEstado
                Case ES_RESERVA : strEstado = STR_RESERVA
                Case ES_PAGADO : strEstado = STR_PAGADO
                Case Es_RECHAZADO : strEstado = STR_RECHAZADO
            End Select
            gr.Cells(cheque_estado.Index).Value = strEstado
            Cheques.Rows.Add(gr)
        Next
        Cheques.AllowUserToAddRows = False
        Cheques.ResumeLayout()
    End Sub

    'Suma casillas de efectivo, cheques y otros + gastos
    Private Sub SumarDeposito()
        Dim dblTemp As Double = 0.0
        Dim dblCheques As Double = 0.0

        dblTemp = CDbl(CeldaMonto.Text) + CDbl(CeldaCheques.Text) + CDbl(CeldaGastos.Text)
        dblCheques = SumarCheques()
        dblTemp = Math.Round(dblTemp + dblCheques, 2)
        CeldaTotalDeposito.Text = dblTemp.ToString("f")
    End Sub

    'Devuelve el proveedor para un ID
    Private Function BuscarProveedor(ByVal ID As Integer) As String
        Dim strSQL As String = "SELECT pro_proveedor ID FROM Proveedores WHERE pro_sisemp={empresa} AND pro_codigo={id} LIMIT 1"
        Dim strTemp As String

        strSQL = strSQL.Replace("{empresa}", Sesion.IdEmpresa)
        strSQL = strSQL.Replace("{id}", ID)
        MyCnn.CONECTAR = strConexion
        Using cmd As New MySqlCommand(strSQL, CON)
            strTemp = cmd.ExecuteScalar
        End Using
        Return strTemp
    End Function

    'Actualiza el total en letras
    Private Sub ActualizarTotalLetras(Optional Monto As Double = NO_FILA)
        Dim dblTemp As Double = 0.0
        Dim strTemp As String = String.Empty
        Dim num As New Numalet

        If Monto.Equals(NO_FILA) Then
            Double.TryParse(CeldaMonto.Text, dblTemp)
        End If
        If dblTemp > INT_CERO Then
            num.Decimales = 2
            num.SeparadorDecimalSalida = "con"
            num.MascaraSalidaDecimal = "00/100"
            strTemp = num.ToCustomCardinal(dblTemp).ToUpper.Replace("CON 00/100", "EXACTOS").Trim
        End If
        EtiquetaLetras.Text = strTemp
    End Sub

    'Para crear una columna de texto en una cuadricula
    Private Function CrearColumnaTexto(ByVal Nombre As String, Optional Texto As String = STR_VACIO, Optional EsVisible As Boolean = False, Optional Bloqueado As Boolean = True, Optional Ancho As Integer = 50) As DataGridViewTextBoxColumn
        Dim col As New DataGridViewTextBoxColumn
        col.Name = Nombre
        col.HeaderText = Texto
        col.Visible = EsVisible
        col.ReadOnly = Bloqueado
        col.Width = Ancho
        col.SortMode = DataGridViewColumnSortMode.NotSortable
        If Bloqueado Then
            col.DefaultCellStyle.BackColor = Color.LightYellow
        End If
        Return col
    End Function

    '----->>>>> RETENCIONES DE ISR 
    'Muestra las retenciones de ISR pendientes de proceso
    Private Sub MostrarRetenciones()
        Dim row As DataGridViewRow
        Dim gr As DataGridViewRow

        Dim dblTasa As Double = CDbl(CeldaTasa.Text)
        Dim dblTipo As Double
        Dim dblMonto As Double
        Dim intTipo As Integer
        Dim intCiclo As Integer
        Dim intNum As Integer
        Dim intMon As Integer
        Dim c As Integer

        Using frm As New frmSeleccionMultiple
            frm.strTipoVenta = 0
            ConfigurarDetalleExterno(frm.Lista)
            frm.AgregarColumnaSeleccion()
            CargarRetencionesPendientes(frm.Lista)

            frm.Text = "Select Income Tax Retentions"
            frm.Multiple = True
            If frm.ShowDialog = DialogResult.OK Then
                Compras.SuspendLayout()
                Compras.AllowUserToAddRows = True

                'Agregar documentos seleccionados a la lista
                c = frm.ColumnaSeleccion
                For Each row In frm.Lista.Rows
                    If CBool(row.Cells(c).Value) Then
                        intTipo = CInt(row.Cells(frm.Lista.Columns.Item("lista_tipo").Index).Value)
                        intCiclo = CInt(row.Cells(frm.Lista.Columns.Item("lista_ciclo").Index).Value)
                        intNum = CInt(row.Cells(frm.Lista.Columns.Item("lista_numero").Index).Value)

                        intMon = CInt(row.Cells(frm.Lista.Columns.Item("lista_moneda").Index).Value)
                        dblTipo = CDbl(row.Cells(frm.Lista.Columns.Item("lista_tasa").Index).Value)
                        dblMonto = CDbl(row.Cells(frm.Lista.Columns.Item("lista_saldo").Index).Value)

                        gr = Compras.Rows(Compras.NewRowIndex).Clone

                        gr.Cells(compra_tipo.Index).Value = intTipo
                        gr.Cells(compra_ciclo.Index).Value = intCiclo
                        gr.Cells(compra_numero.Index).Value = intNum
                        gr.Cells(compra_moneda.Index).Value = intMon
                        gr.Cells(compra_tasa.Index).Value = dblTipo
                        gr.Cells(compra_descripcion.Index).Value = "N° " & row.Cells(frm.Lista.Columns.Item("lista_referencia").Index).Value & " / " & CDate(row.Cells(frm.Lista.Columns.Item("lista_fecha").Index).Value).ToString(FORMATO_MYSQL)

                        If Not Moneda.Equals(intMon) Then
                            If intMon.Equals(intMonedaLocal) Then
                                'Local -> Exterior
                                dblMonto = Math.Round(dblMonto / dblTasa, 2)
                            Else
                                'Exterior -> Local
                                'REVISAR: por que se usa el tipo de cambio de la retencion
                                dblMonto = Math.Round(dblMonto * dblTipo, 2)
                            End If
                        End If
                        gr.Cells(compra_monto.Index).Value = dblMonto.ToString("f")

                        gr.Cells(compra_cuenta.Index).Value = String.Empty
                        gr.Cells(compra_ref_ciclo.Index).Value = CInt(row.Cells(frm.Lista.Columns.Item("lista_ref_ciclo").Index).Value)
                        gr.Cells(compra_ref_numero.Index).Value = CInt(row.Cells(frm.Lista.Columns.Item("lista_ref_numero").Index).Value)

                        Compras.Rows.Add(gr)
                        gr.Selected = True
                        gr.Cells(compra_monto.Index).Selected = True
                    End If
                Next

                Compras.AllowUserToAddRows = False
                Compras.ResumeLayout()
                SumarCompras()
            End If
        End Using
    End Sub

    'Carga los documentos de venta con saldo pendiente de pago (ref. cliente)
    Private Sub CargarRetencionesPendientes(ByRef Lista As DataGridView)
        Dim strSQL As String = Base.SQLRetencionesPendientes
        Dim dblSaldo As Double
        Dim intIdMoneda As Integer
        MyCnn.CONECTAR = strConexion
        Dim cmd As New MySqlCommand(strSQL, CON)
        Dim da As New MySqlDataAdapter(cmd)
        Dim dt As New System.Data.DataTable
        Dim dr As DataRow
        Dim row As DataGridViewRow
        da.Fill(dt)

        'Cargar filas en cuadricula para seleccion
        Lista.SuspendLayout()
        Lista.AllowUserToAddRows = True
        For Each dr In dt.Rows
            'Si no ha sido agregado aun
            If Not ExisteEnDetalle("compras", CInt(dr("tipo")), CInt(dr("ciclo")), CInt(dr("numero"))) Then
                intIdMoneda = CInt(dr("id_moneda"))
                dblSaldo = CDbl(dr("saldo"))
                If Not Moneda.Equals(intIdMoneda) Then
                    If intIdMoneda.Equals(intMonedaLocal) Then
                        'Local: Q -> $
                        dblSaldo = Math.Round(dblSaldo / CDbl(CeldaTasa.Text), 2)
                    ElseIf intIdMoneda.Equals(intMonedaExterna) Then
                        'Exterior: $ -> Q
                        dblSaldo = Math.Round(dblSaldo * CDbl(dr("tasa")), 2)
                    Else
                        MessageBox.Show("Currency not supported", "Unexpected error", MessageBoxButtons.OK, MessageBoxIcon.Stop)
                    End If
                End If

                row = Lista.Rows(Lista.NewRowIndex).Clone
                row.Cells(Lista.Columns.Item("lista_tipo").Index).Value = dr("tipo")
                row.Cells(Lista.Columns.Item("lista_ciclo").Index).Value = dr("ciclo")
                row.Cells(Lista.Columns.Item("lista_numero").Index).Value = dr("numero")

                row.Cells(Lista.Columns.Item("lista_grupo").Index).Value = dr("grupo")
                row.Cells(Lista.Columns.Item("lista_moneda").Index).Value = intIdMoneda.ToString
                row.Cells(Lista.Columns.Item("lista_tasa").Index).Value = CDbl(dr("tasa")).ToString("f5")
                row.Cells(Lista.Columns.Item("lista_fecha").Index).Value = CDate(dr("fecha")).ToString(FORMATO_MYSQL)
                row.Cells(Lista.Columns.Item("lista_referencia").Index).Value = dr("referencia")
                row.Cells(Lista.Columns.Item("lista_letra").Index).Value = dr("letra")
                row.Cells(Lista.Columns.Item("lista_saldo").Index).Value = CDbl(dr("saldo")).ToString("n2")
                row.Cells(Lista.Columns.Item("lista_notas").Index).Value = dr("notas")

                row.Cells(Lista.Columns.Item("lista_ref_ciclo").Index).Value = dr("ref_ciclo")
                row.Cells(Lista.Columns.Item("lista_ref_numero").Index).Value = dr("ref_numero")

                If CDbl(dr("saldo")) < INT_CERO Then
                    row.Cells(Lista.Columns.Item("lista_grupo").Index).Style.BackColor = Color.Red
                    row.Cells(Lista.Columns.Item("lista_grupo").Index).Style.ForeColor = Color.White
                End If

                Lista.Rows.Add(row)
            End If
        Next
        Lista.AllowUserToAddRows = False
        Lista.ResumeLayout()
    End Sub
    '<<<<<-----

    '----->>>>> COMPRAS PENDIENTES 
    'Muestra los documentos de compra con saldo pendientes para el proveedor indicado
    Private Sub MostrarCompras(ByVal ID As Integer)
        Dim strTemp As String = String.Empty

        Dim dblTasa As Double = CDbl(CeldaTasa.Text)
        Dim dblTipo As Double, dblCambio As Double = 0.0
        Dim dblMonto As Double

        Dim intTipo As Integer
        Dim intCiclo As Integer
        Dim intNum As Integer
        Dim intMon As Integer
        Dim c As Integer
        Dim logErr As Boolean = False

        Dim row As DataGridViewRow
        Dim gr As DataGridViewRow

        Using frm As New frmSeleccionMultiple
            frm.strTipoVenta = 0
            ConfigurarDetalleExterno(frm.Lista)
            frm.AgregarColumnaSeleccion()
            CargarComprasPendientes(frm.Lista, ID)

            frm.Text = "Select Pending Purchase Invoices"
            frm.Multiple = True
            If frm.ShowDialog = DialogResult.OK Then
                Compras.SuspendLayout()
                Compras.AllowUserToAddRows = True

                'Agregar documentos seleccionados a la lista
                c = frm.ColumnaSeleccion
                For Each row In frm.Lista.Rows
                    If CBool(row.Cells(c).Value) Then
                        intTipo = CInt(row.Cells(frm.Lista.Columns.Item("lista_tipo").Index).Value)
                        intCiclo = CInt(row.Cells(frm.Lista.Columns.Item("lista_ciclo").Index).Value)
                        intNum = CInt(row.Cells(frm.Lista.Columns.Item("lista_numero").Index).Value)

                        intMon = CInt(row.Cells(frm.Lista.Columns.Item("lista_moneda").Index).Value)
                        dblTipo = CDbl(row.Cells(frm.Lista.Columns.Item("lista_tasa").Index).Value)
                        dblMonto = CDbl(row.Cells(frm.Lista.Columns.Item("lista_saldo").Index).Value)

                        'Banco en moneda externa, documento en moneda local sin tasa de cambio
                        logErr = False
                        If _Moneda.Equals(intMonedaExterna) And intMon.Equals(intMonedaLocal) Then
                            If dblTipo <= 1 Then
                                strTemp = Base.PedirDato("The document " & row.Cells(frm.Lista.Columns.Item("lista_referencia").Index).Value & " in local currency has no exchange rate" & vbCr & vbCr & "Confirm if you want to use the following value", "Exchange Rate", dblTasa.ToString("f5"))
                                If strTemp.Equals(String.Empty) Then
                                    logErr = True
                                ElseIf Not IsNumeric(strTemp) Then
                                    MessageBox.Show(strTemp & " is not a valid exchange rate value" & vbCr & vbCr & "Document " & row.Cells(frm.Lista.Columns.Item("lista_referencia").Index).Value & " will not be added", "Exchange Rate", MessageBoxButtons.OK, MessageBoxIcon.Warning)
                                    logErr = True
                                Else
                                    'Este dato se guardara en el detalle del documento
                                    dblCambio = CDbl(strTemp)
                                End If
                            End If
                        End If

                        If Not logErr Then
                            gr = Compras.Rows(Compras.NewRowIndex).Clone

                            gr.Cells(compra_tipo.Index).Value = intTipo
                            gr.Cells(compra_ciclo.Index).Value = intCiclo
                            gr.Cells(compra_numero.Index).Value = intNum
                            gr.Cells(compra_moneda.Index).Value = intMon

                            'Tasa de cambio del documento, tasa de cambio alterna y marca
                            gr.Cells(compra_factura.Index).Value = Math.Round((dblTipo * dblMonto), 2)
                            gr.Cells(compra_tasa.Index).Value = dblTipo
                            gr.Cells(compra_cambio.Index).Value = dblCambio
                            gr.Cells(compra_marca.Index).Value = If(dblCambio > 0, "#", String.Empty)

                            gr.Cells(compra_descripcion.Index).Value = "N° " & row.Cells(frm.Lista.Columns.Item("lista_referencia").Index).Value & " / " & CDate(row.Cells(frm.Lista.Columns.Item("lista_fecha").Index).Value).ToString(FORMATO_MYSQL)

                            If Not Moneda.Equals(intMon) Then
                                If intMon.Equals(intMonedaLocal) Then
                                    'Local -> Exterior
                                    dblMonto = Math.Round(dblMonto / dblCambio, 2)
                                Else : dblMonto = Math.Round(dblMonto * CeldaTasa.Text, 2)
                                End If
                            End If
                            gr.Cells(compra_monto.Index).Value = dblMonto.ToString("f")

                            gr.Cells(compra_cuenta.Index).Value = String.Empty
                            gr.Cells(compra_ref_ciclo.Index).Value = INT_CERO.ToString
                            gr.Cells(compra_ref_numero.Index).Value = INT_CERO.ToString
                            If intTipo = 44 Then
                                gr.Cells(col_DocumentoTipo.Index).Value = "FA"
                            Else
                                gr.Cells(col_DocumentoTipo.Index).Value = "RECIBO"
                            End If

                            Compras.Rows.Add(gr)
                            gr.Selected = True
                            gr.Cells(compra_monto.Index).Selected = True
                        End If
                    End If
                Next

                Compras.AllowUserToAddRows = False
                Compras.ResumeLayout()
                SumarCompras()
            End If
        End Using
    End Sub

    'Carga los documentos de venta con saldo pendiente de pago (ref. cliente)
    Private Sub CargarComprasPendientes(ByRef Lista As DataGridView, ByVal ID As Integer)
        Dim strSQL As String = Base.SQLComprasPendientes(ID)
        Dim dblSaldo As Double
        Dim intIdMoneda As Integer
        MyCnn.CONECTAR = strConexion
        Dim cmd As New MySqlCommand(strSQL, CON)
        Dim da As New MySqlDataAdapter(cmd)
        Dim dt As New System.Data.DataTable
        Dim dr As DataRow
        Dim row As DataGridViewRow
        da.Fill(dt)

        'Cargar filas en cuadricula para seleccion
        Lista.SuspendLayout()
        Lista.AllowUserToAddRows = True
        For Each dr In dt.Rows
            'Si no ha sido agregado aun
            If Not ExisteEnDetalle("compras", CInt(dr("tipo")), CInt(dr("ciclo")), CInt(dr("numero"))) Then
                intIdMoneda = CInt(dr("id_moneda"))
                dblSaldo = CDbl(dr("saldo"))
                If Not Moneda.Equals(intIdMoneda) Then
                    If intIdMoneda.Equals(intMonedaLocal) Then
                        'Local: Q -> $
                        dblSaldo = Math.Round(dblSaldo / CDbl(CeldaTasa.Text), 2)
                    ElseIf intIdMoneda.Equals(intMonedaExterna) Then
                        'Exterior: $ -> Q
                        dblSaldo = Math.Round(dblSaldo * CDbl(dr("tasa")), 2)
                    Else
                        MessageBox.Show("Currency not supported", "Unexpected error", MessageBoxButtons.OK, MessageBoxIcon.Stop)
                    End If
                End If

                row = Lista.Rows(Lista.NewRowIndex).Clone
                row.Cells(Lista.Columns.Item("lista_tipo").Index).Value = dr("tipo")
                row.Cells(Lista.Columns.Item("lista_ciclo").Index).Value = dr("ciclo")
                row.Cells(Lista.Columns.Item("lista_numero").Index).Value = dr("numero")
                row.Cells(Lista.Columns.Item("lista_grupo").Index).Value = dr("grupo")
                row.Cells(Lista.Columns.Item("lista_moneda").Index).Value = intIdMoneda.ToString
                row.Cells(Lista.Columns.Item("lista_tasa").Index).Value = CDbl(dr("tasa")).ToString("f5")
                row.Cells(Lista.Columns.Item("lista_fecha").Index).Value = CDate(dr("fecha")).ToString(FORMATO_MYSQL)
                row.Cells(Lista.Columns.Item("lista_referencia").Index).Value = dr("referencia")
                row.Cells(Lista.Columns.Item("lista_letra").Index).Value = dr("letra")
                row.Cells(Lista.Columns.Item("lista_saldo").Index).Value = CDbl(dr("saldo")).ToString("n2")
                row.Cells(Lista.Columns.Item("lista_notas").Index).Value = dr("notas")
                If CDbl(dr("tasa")).Equals(0.0) Then
                    row.Cells(Lista.Columns.Item("lista_letra").Index).Style.BackColor = Color.Orange
                ElseIf CDbl(dr("tasa")).Equals(1) Then
                    row.Cells(Lista.Columns.Item("lista_letra").Index).Style.BackColor = Color.Yellow
                End If

                If CDbl(dr("saldo")) < INT_CERO Then
                    row.Cells(Lista.Columns.Item("lista_grupo").Index).Style.BackColor = Color.Red
                    row.Cells(Lista.Columns.Item("lista_grupo").Index).Style.ForeColor = Color.White
                End If

                Lista.Rows.Add(row)
            End If
        Next
        Lista.AllowUserToAddRows = False
        Lista.ResumeLayout()
    End Sub
    '<<<<<-----

    '----->>>>> VENTAS PENDIENTES 
    'Muestra los documentos de venta con saldo pendientes para el cliente indicado
    Private Sub MostrarVentasPendientes(ByVal ID As Integer)
        Dim row As DataGridViewRow
        Dim gr As DataGridViewRow

        Dim dblTasa As Double = CDbl(CeldaTasa.Text)
        Dim dblMonto As Double
        Dim intTipo As Integer
        Dim intCiclo As Integer
        Dim intNum As Integer
        Dim intMon As Integer
        Dim c As Integer

        Using frm As New frmSeleccionMultiple

            frm.strTipoVenta = 1
            ConfigurarDetalleExterno(frm.Lista, 1) 'Agrega las columnas
            frm.AgregarColumnaSeleccion()
            CargarVentasPendientes(frm.Lista, ID)

            frm.Text = "Select Pending Sales Invoices"
            frm.Multiple = True
            If frm.ShowDialog = DialogResult.OK Then
                Ventas.SuspendLayout()
                Ventas.AllowUserToAddRows = True

                'Agregar documentos seleccionados a la lista
                c = frm.ColumnaSeleccion
                For Each row In frm.Lista.Rows
                    If CBool(row.Cells(c).Value) Then
                        intTipo = CInt(row.Cells(frm.Lista.Columns.Item("lista_tipo").Index).Value)
                        intCiclo = CInt(row.Cells(frm.Lista.Columns.Item("lista_ciclo").Index).Value)
                        intNum = CInt(row.Cells(frm.Lista.Columns.Item("lista_numero").Index).Value)

                        If Not ExisteEnDetalle("ventas", intTipo, intCiclo, intNum) Then
                            intMon = CInt(row.Cells(frm.Lista.Columns.Item("lista_moneda").Index).Value)
                            dblMonto = CDbl(row.Cells(frm.Lista.Columns.Item("lista_saldo").Index).Value)

                            gr = Ventas.Rows(Ventas.NewRowIndex).Clone

                            gr.Cells(venta_tipo.Index).Value = intTipo
                            gr.Cells(venta_ciclo.Index).Value = intCiclo
                            gr.Cells(venta_numero.Index).Value = intNum
                            gr.Cells(venta_grupo.Index).Value = row.Cells(frm.Lista.Columns.Item("lista_grupo").Index).Value
                            gr.Cells(venta_serie.Index).Value = String.Empty
                            gr.Cells(venta_fecha.Index).Value = CDate(row.Cells(frm.Lista.Columns.Item("lista_fecha").Index).Value)
                            gr.Cells(venta_moneda.Index).Value = intMon
                            gr.Cells(venta_tasa.Index).Value = CDbl(row.Cells(frm.Lista.Columns.Item("lista_tasa").Index).Value)
                            gr.Cells(venta_ref.Index).Value = row.Cells(frm.Lista.Columns.Item("lista_referencia").Index).Value
                            gr.Cells(venta_monto.Index).Value = dblMonto


                            'REM el saldo ya viene en la moneda del banco

                            'If Not Moneda.Equals(intMon) Then
                            '    If Moneda.Equals(intMonedaLocal) Then
                            '        'Exterior -> Local
                            '        dblMonto = Math.Round(dblMonto * dblTasa, 2)
                            '    Else : dblMonto = Math.Round(dblMonto / dblTasa, 2)
                            '    End If
                            'End If

                            gr.Cells(venta_total.Index).Value = dblMonto.ToString("f")
                            gr.Cells(venta_id.Index).Value = CInt(row.Cells(frm.Lista.Columns.Item("lista_id").Index).Value)
                            gr.Cells(ventas_numero2.Index).Value = CInt(row.Cells(frm.Lista.Columns.Item("lista_ref_numero").Index).Value)


                            Ventas.Rows.Add(gr)
                            gr.Selected = True
                            gr.Cells(venta_total.Index).Selected = True
                        End If
                    End If
                Next

                Ventas.AllowUserToAddRows = False
                Ventas.ResumeLayout()
                SumarVentas()
            End If
        End Using
    End Sub

    'Configura las columnas para la cuadricula de ventas pendientes
    Private Sub ConfigurarDetalleExterno(ByRef Lista As DataGridView, Optional intVentas As Integer = 0)
        Dim col As DataGridViewTextBoxColumn

        'Configurar lista
        col = CrearColumnaTexto("lista_tipo")
        Lista.Columns.Add(col)
        col = CrearColumnaTexto("lista_ciclo")
        Lista.Columns.Add(col)
        col = CrearColumnaTexto("lista_grupo", String.Empty, True)
        col.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter
        col.DefaultCellStyle.BackColor = Color.SlateGray
        col.DefaultCellStyle.ForeColor = Color.White
        Lista.Columns.Add(col)
        col = CrearColumnaTexto("lista_numero", "Document", True, True, 70)
        col.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter
        Lista.Columns.Add(col)
        col = CrearColumnaTexto("lista_fecha", "Date", True, True, 70)
        col.ValueType = GetType(Date)
        col.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter
        Lista.Columns.Add(col)
        col = CrearColumnaTexto("lista_moneda")
        Lista.Columns.Add(col)
        col = CrearColumnaTexto("lista_tasa")
        Lista.Columns.Add(col)
        'Nueva Columna 
        If intVentas = 1 Then
            col = CrearColumnaTexto("lista_CxC", "Receivable", True, True, 180)
            Lista.Columns.Add(col)
            col.DefaultCellStyle.BackColor = Color.LightBlue
        End If

        col = CrearColumnaTexto("lista_referencia", "Reference", True, True, 180)
        Lista.Columns.Add(col)
        col = CrearColumnaTexto("lista_letra", String.Empty, True, True, 30)
        col.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter
        Lista.Columns.Add(col)
        'REM strSimboloMoneda
        col = CrearColumnaTexto("lista_saldo", "Balance", True, True, 70)
        col.ValueType = GetType(Decimal)
        col.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight
        Lista.Columns.Add(col)
        col = CrearColumnaTexto("lista_id")
        Lista.Columns.Add(col)
        col = CrearColumnaTexto("lista_secuencia")
        Lista.Columns.Add(col)
        If Sesion.IdEmpresa = 12 Or Sesion.IdEmpresa = 10 Then
            If (Tipo = 53) Or (Tipo = 54) Then
                col = CrearColumnaTexto("lista_notas", "FEL", True, True, 80)
                Lista.Columns.Add(col)
            Else
                col = CrearColumnaTexto("lista_notas")
                Lista.Columns.Add(col)
            End If
        Else
            col = CrearColumnaTexto("lista_notas")
            Lista.Columns.Add(col)
        End If
        col = CrearColumnaTexto("lista_ref_ciclo")
        Lista.Columns.Add(col)
        If Sesion.IdEmpresa = 16 Or Sesion.IdEmpresa = 14 Or Sesion.IdEmpresa = 11 Or Sesion.idGiro = 2 Then
            col = CrearColumnaTexto("lista_ref_numero", "Fact", True, True, 70)
            Lista.Columns.Add(col)
        Else
            col = CrearColumnaTexto("lista_ref_numero")
            Lista.Columns.Add(col)
        End If



    End Sub

    'Busca un documento en el listado de compras o ventas
    Private Function ExisteEnDetalle(ByVal Detalle As String, ByVal Tipo As Integer, ByVal Ciclo As Integer, ByVal Numero As Integer) As Integer
        Dim i As Integer = NO_FILA
        Dim intTipo As Integer = INT_CERO
        Dim intCiclo As Integer = INT_CERO
        Dim intNumero As Integer = INT_CERO
        Dim data As DataGridView = Nothing

        Select Case Detalle.ToLower.Trim
            Case "ventas"
                intTipo = venta_tipo.Index
                intCiclo = venta_ciclo.Index
                intNumero = venta_numero.Index
                data = Ventas
            Case "compras"
                intTipo = compra_tipo.Index
                intCiclo = compra_ciclo.Index
                intNumero = compra_numero.Index
                data = Compras
        End Select

        If data IsNot Nothing Then
            For Each row As DataGridViewRow In data.Rows
                If CInt(row.Cells(intTipo).Value).Equals(Tipo) And
                    CInt(row.Cells(intCiclo).Value).Equals(Ciclo) And
                    CInt(String.Concat("0", row.Cells(intNumero).Value)).Equals(Numero) Then
                    i = row.Index
                    Exit For
                End If
            Next
        End If
        Return Not i.Equals(NO_FILA)
    End Function

    'Carga los documentos de venta con saldo pendiente de pago (ref. cliente)
    Private Sub CargarVentasPendientes(ByRef Lista As DataGridView, ByVal ID As Integer)
        Dim strSQL As String = Base.SQLVentasPendientes(Tipo, Ciclo, Numero, ID, Moneda)
        MyCnn.CONECTAR = strConexion
        Dim cmd As New MySqlCommand(strSQL, CON)
        cmd.CommandTimeout = 300
        Dim da As New MySqlDataAdapter(cmd)
        Dim dt As New System.Data.DataTable
        Dim dr As DataRow
        Dim row As DataGridViewRow
        da.Fill(dt)

        'Cargar filas en cuadricula para seleccion
        Lista.SuspendLayout()
        Lista.AllowUserToAddRows = True
        For Each dr In dt.Rows
            If Not ExisteEnDetalle("ventas", CInt(dr("tipo")), CInt(dr("ciclo")), CInt(dr("numero"))) Then
                row = Lista.Rows(Lista.NewRowIndex).Clone
                row.Cells(Lista.Columns.Item("lista_tipo").Index).Value = dr("tipo")
                row.Cells(Lista.Columns.Item("lista_ciclo").Index).Value = dr("ciclo")
                row.Cells(Lista.Columns.Item("lista_numero").Index).Value = dr("numero")
                row.Cells(Lista.Columns.Item("lista_grupo").Index).Value = dr("grupo")
                row.Cells(Lista.Columns.Item("lista_secuencia").Index).Value = dr("secuencia")
                row.Cells(Lista.Columns.Item("lista_fecha").Index).Value = CDate(dr("fecha")).ToString(FORMATO_MYSQL)
                row.Cells(Lista.Columns.Item("lista_moneda").Index).Value = CInt(dr("moneda")).ToString
                row.Cells(Lista.Columns.Item("lista_tasa").Index).Value = CDbl(dr("tasa")).ToString("f5")
                row.Cells(Lista.Columns.Item("lista_CxC").Index).Value = dr("CxC") 'Nueva Columna
                row.Cells(Lista.Columns.Item("lista_referencia").Index).Value = dr("referencia")
                row.Cells(Lista.Columns.Item("lista_letra").Index).Value = dr("letra")
                row.Cells(Lista.Columns.Item("lista_saldo").Index).Value = CDbl(dr("saldo")).ToString("n2")
                row.Cells(Lista.Columns.Item("lista_id").Index).Value = ID.ToString
                If Sesion.IdEmpresa = 12 Or Sesion.IdEmpresa = 10 Then
                    row.Cells(Lista.Columns.Item("lista_notas").Index).Value = dr("NumeroAutorizacion")
                End If
                If Sesion.IdEmpresa = 16 Or Sesion.IdEmpresa = 14 Or Sesion.IdEmpresa = 11 Or Sesion.idGiro = 2 Then
                    row.Cells(Lista.Columns.Item("lista_ref_numero").Index).Value = CInt(dr("Numero2")).ToString
                End If
                Lista.Rows.Add(row)
            End If
        Next
        Lista.AllowUserToAddRows = False
        Lista.ResumeLayout()
    End Sub
    '<<<<<-----

    '----->>>>> LIQUIDACIONES PENDIENTES
    'Muestra los documentos de venta con saldo pendientes para el cliente indicado
    Private Sub MostrarLiquidacionesPendientes(ByVal ID As Integer)
        Dim row As DataGridViewRow

        Dim dblTasa As Double = INT_UNO
        Dim dblFactor As Double = INT_UNO
        Dim dblTotal As Double
        Dim logCambio As Boolean = False
        Dim intTipo As Integer
        Dim intCiclo As Integer
        Dim intNum As Integer
        Dim intMon As Integer

        Dim strDoc As String
        Dim datFecha As Date

        Using frm As New frmSeleccionMultiple
            frm.strTipoVenta = 0
            ConfigurarDetalleLiquidacion(frm.Lista)
            CargarLiquidacionesPendientes(frm.Lista, ID)

            frm.Text = "Select Pending Petty Cash Reconciliations"
            frm.Multiple = False
            If frm.ShowDialog = DialogResult.OK Then

                'Agregar documentos seleccionados a la lista
                row = frm.Lista.CurrentRow
                intTipo = CInt(row.Cells(frm.Lista.Columns.Item("lista_tipo").Index).Value)
                intCiclo = CInt(row.Cells(frm.Lista.Columns.Item("lista_ciclo").Index).Value)
                intNum = CInt(row.Cells(frm.Lista.Columns.Item("lista_numero").Index).Value)
                intMon = CInt(row.Cells(frm.Lista.Columns.Item("lista_divisa").Index).Value)
                strDoc = row.Cells(frm.Lista.Columns.Item("lista_documento").Index).Value
                datFecha = CDate(row.Cells(frm.Lista.Columns.Item("lista_fecha").Index).Value)
                dblTotal = CDbl(row.Cells(frm.Lista.Columns.Item("lista_monto").Index).Value)

                If Not intMon.Equals(Moneda) Then
                    dblTasa = CDbl(CeldaTasa.Text)
                    If MessageBox.Show("Amounts expressed in bank account currency" & vbCrLf & vbCrLf & "Exchange Rate: " & dblTasa.ToString("f5"), "Bank Account Currency " & strSimboloMoneda, MessageBoxButtons.OKCancel, MessageBoxIcon.Question) = DialogResult.OK Then
                        logCambio = True
                        If intMon.Equals(intMonedaLocal) Then
                            dblFactor = (1 / dblTasa)
                        Else : dblFactor = dblTasa
                        End If
                    Else : intTipo = INT_CERO
                    End If
                End If

                If Not intTipo.Equals(INT_CERO) Then
                    CeldaConcepto.Text = "LIQUIDACION N° " & strDoc & " DEL " & datFecha.ToString("dd/MM/yyyy")
                    If logCambio Then
                        CeldaNotas.Text = "CAMBIO DE MONEDA: T.C. " & dblTasa.ToString("f5")
                    End If

                    With Relacion
                        .Tipo = intTipo
                        .Ciclo = intCiclo
                        .Numero = intNum

                    End With
                    CargarLiquidacon()

                    If Not (CDbl(CeldaMonto.Text).Equals(INT_CERO) Or CDbl(CeldaMonto.Text).Equals(Math.Round(dblTotal * dblFactor, 2))) Then
                        MessageBox.Show("Document amount will be replaced" & vbCrLf & vbCrLf & "Current amount: " & CDbl(CeldaMonto.Text).ToString("f") & vbCrLf & "New amount: " & Math.Round(dblTotal * dblFactor, 2).ToString("f") & vbCrLf & vbCrLf & "OBSERVATION: You could assign the difference to a book account", "New Document Amount", MessageBoxButtons.OK, MessageBoxIcon.Information)
                    End If
                    CeldaMonto.Text = Math.Round(dblTotal * dblFactor, 2)

                    ActualizarTotalLetras()
                End If
            End If
        End Using
    End Sub

    'Carga las liquidaciones pendientes para la caja actual
    Private Sub CargarLiquidacionesPendientes(ByRef Lista As DataGridView, ByVal ID As Integer)
        Dim strSQL As String = Base.SQLLiquidacionesPendientes(ID)
        MyCnn.CONECTAR = strConexion
        Dim cmd As New MySqlCommand(strSQL, CON)
        Dim da As New MySqlDataAdapter(cmd)
        Dim dt As New System.Data.DataTable
        Dim dr As DataRow
        Dim row As DataGridViewRow
        da.Fill(dt)

        'Cargar filas en cuadricula para seleccion
        Lista.SuspendLayout()
        Lista.AllowUserToAddRows = True
        For Each dr In dt.Rows
            row = Lista.Rows(Lista.NewRowIndex).Clone
            row.Cells(Lista.Columns.Item("lista_tipo").Index).Value = CInt(dr("tipo")).ToString
            row.Cells(Lista.Columns.Item("lista_ciclo").Index).Value = CInt(dr("ciclo")).ToString
            row.Cells(Lista.Columns.Item("lista_numero").Index).Value = CInt(dr("numero")).ToString
            row.Cells(Lista.Columns.Item("lista_id").Index).Value = ID
            row.Cells(Lista.Columns.Item("lista_divisa").Index).Value = CInt(dr("divisa")).ToString
            row.Cells(Lista.Columns.Item("lista_tasa").Index).Value = CDbl(dr("tasa")).ToString("f5")
            row.Cells(Lista.Columns.Item("lista_bruto").Index).Value = CDbl(dr("bruto")).ToString("f")
            row.Cells(Lista.Columns.Item("lista_inicio").Index).Value = CDate(dr("inicio")).ToString(FORMATO_MYSQL)
            row.Cells(Lista.Columns.Item("lista_fin").Index).Value = CDate(dr("fin")).ToString(FORMATO_MYSQL)

            row.Cells(Lista.Columns.Item("lista_caja").Index).Value = dr("caja")
            row.Cells(Lista.Columns.Item("lista_documento").Index).Value = dr("documento")
            row.Cells(Lista.Columns.Item("lista_fecha").Index).Value = CDate(dr("fecha")).ToString(FORMATO_MYSQL)
            row.Cells(Lista.Columns.Item("lista_moneda").Index).Value = dr("moneda")
            row.Cells(Lista.Columns.Item("lista_monto").Index).Value = CDbl(dr("monto")).ToString("f")

            Lista.Rows.Add(row)
        Next
        Lista.AllowUserToAddRows = False
        Lista.ResumeLayout()
    End Sub

    'Configura las columnas para la cuadricula de ventas pendientes
    Private Sub ConfigurarDetalleLiquidacion(ByRef Lista As DataGridView)
        Dim col As DataGridViewTextBoxColumn

        'Columnas no visibles
        col = CrearColumnaTexto("lista_tipo")
        Lista.Columns.Add(col)
        col = CrearColumnaTexto("lista_ciclo")
        Lista.Columns.Add(col)
        col = CrearColumnaTexto("lista_numero")
        Lista.Columns.Add(col)
        col = CrearColumnaTexto("lista_id")
        Lista.Columns.Add(col)
        col = CrearColumnaTexto("lista_divisa")
        Lista.Columns.Add(col)
        col = CrearColumnaTexto("lista_tasa")
        Lista.Columns.Add(col)
        col = CrearColumnaTexto("lista_bruto")
        Lista.Columns.Add(col)
        col = CrearColumnaTexto("lista_inicio")
        Lista.Columns.Add(col)
        col = CrearColumnaTexto("lista_fin")
        Lista.Columns.Add(col)

        'Columnas visibles
        col = CrearColumnaTexto("lista_caja", "Petty Cash", True, True, 180)
        col.DefaultCellStyle.BackColor = Color.SlateGray
        col.DefaultCellStyle.ForeColor = Color.White
        Lista.Columns.Add(col)

        col = CrearColumnaTexto("lista_documento", "Document", True, True, 100)
        col.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter
        Lista.Columns.Add(col)

        col = CrearColumnaTexto("lista_fecha", "Date", True, True, 70)
        col.ValueType = GetType(Date)
        col.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter
        Lista.Columns.Add(col)

        col = CrearColumnaTexto("lista_moneda", "Currency", True, True, 60)
        col.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter
        Lista.Columns.Add(col)

        col = CrearColumnaTexto("lista_monto", "Amount", True, True, 70)
        col.ValueType = GetType(Decimal)
        col.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight
        Lista.Columns.Add(col)
    End Sub

    '<<<<<-----


    'Clic en el boton de persona / empresa
    Private Sub BotonEmpresa_Click(sender As Object, e As EventArgs) Handles BotonEmpresa.Click
        Dim strTitulo As String = String.Empty
        Dim strSQL As String = String.Empty

        'Para todos los grupos excepto Impuestos y Planilla
        If Not (Grupo.Equals(clsBancos.BancoGrupo.Planilla) Or Grupo.Equals(clsBancos.BancoGrupo.Impuestos)) Then

            Select Case Grupo
                Case clsBancos.BancoGrupo.Proveedor
                    strTitulo = " Provider"
                    strSQL = "(SELECT pro_codigo ID, pro_proveedor Description,'' type " &
                             " FROM Proveedores WHERE pro_sisemp={empresa} " &
                             " ORDER BY pro_proveedor) x"
                Case clsBancos.BancoGrupo.Cliente
                    strTitulo = " Customer"
                    strSQL = "(SELECT cli_codigo ID, cli_cliente Description,IF(cli_tipo  = 0, 'Invoice',IF(cli_tipo=1,'Destination','AR')) type " &
                             " FROM Clientes WHERE cli_sisemp={empresa} AND cli_status ='Activo' " &
                             " ORDER BY cli_cliente) x"
                Case clsBancos.BancoGrupo.Caja
                    strTitulo = " Petty Cash"
                    strSQL = "(SELECT BCta_Num ID, CAST(CONCAT(BCta_Nom_Cue, IF(BCta_Tipo=2,' (VIATICOS)',''),' - N° ', CAST(LPAD(BCta_Num_Cue,4,'0') AS CHAR)) AS CHAR) Description,''type " &
                             " FROM CtasBcos" &
                             " WHERE BCta_Sis_Emp={empresa} AND BCta_Tipo IN (1,2,3)" &
                             " ORDER BY BCta_Tipo, BCta_Nom_Cue) x"
                Case clsBancos.BancoGrupo.Empleado
                    strTitulo = " Employee"
                    strSQL = "(SELECT em_codigo ID, em_descripcion Description,'' type " &
                             " FROM Empleados WHERE em_empresa={empresa} " &
                             " ORDER BY em_descripcion) x"
                Case clsBancos.BancoGrupo.Transferencia
                    strTitulo = " Bank Account"
                    strSQL = "(SELECT BCta_Num ID, CONCAT(BCta_Des_Cue,' (',BCta_Num_Cue,')') Description, ''type " &
                             " FROM CtasBcos " &
                             " WHERE BCta_Sis_Emp={empresa} AND BCta_Tipo=0 " &
                             " ORDER BY BCta_Des_Cue) x"

            End Select
            strSQL = strSQL.Replace("{empresa}", Sesion.IdEmpresa)

            Using frm As New frmSeleccionar
                frm.Titulo = strTitulo
                frm.Tabla = strSQL
                frm.Campos = "x.ID, x.Description,x.type"
                frm.Condicion = "x.ID > 0"
                frm.FiltroText = "Select one item from the list"
                frm.Filtro = "x.Description"
                frm.Ordenamiento = String.Empty
                frm.TipoOrdenamiento = String.Empty
                If frm.ShowDialog(Me) = DialogResult.OK Then
                    intEntidad = CInt(frm.LLave)
                    CeldaID.Text = intEntidad
                    CeldaEmpresa.Text = frm.Dato
                    CeldaPersona.Text = frm.Dato
                    CeldaEmpresa.Focus()
                End If
            End Using
        End If
    End Sub

    'Doble clic en cheques
    Private Sub Cheques_DoubleClick(sender As Object, e As EventArgs) Handles Cheques.DoubleClick
        Dim i As Integer = INT_CERO
        Dim s As String = String.Empty

        If Cheques.CurrentRow IsNot Nothing Then
            If Cheques.CurrentCell.ColumnIndex.Equals(cheque_estado.Index) Then
                Using frm As New frmOption
                    frm.Titulo = " Change Check Status"
                    frm.Mensaje = " Select the New status For this check"
                    frm.Opciones = "Reserved|Cashed|Rejected"
                    If frm.ShowDialog(Me) = DialogResult.OK Then
                        Select Case frm.Seleccion
                            Case ES_PAGADO : s = STR_PAGADO
                            Case Es_RECHAZADO : s = STR_RECHAZADO
                            Case Else : s = STR_RESERVA
                        End Select
                        Cheques.CurrentCell.Value = s
                    End If
                End Using
            End If
        End If
    End Sub

    'Seleccionar o cambiar el tipo de transaccion
    Private Sub BotonTransaccion_Click(sender As Object, e As EventArgs) Handles BotonTransaccion.Click
        Dim strSQL As String = strOpciones
        Using frm As New frmSeleccionar
            frm.Titulo = " Transaction Type"
            frm.Tabla = strSQL
            frm.Campos = "x.ID, x.Description"
            frm.Condicion = "Not(x.Description ='')"
            frm.FiltroText = "Select the transaction type for this document"
            frm.Filtro = "x.Description"
            frm.Ordenamiento = String.Empty
            frm.TipoOrdenamiento = String.Empty
            frm.ShowDialog()
            If frm.DialogResult = DialogResult.OK Then
                intItem = frm.LLave
                EtiquetaTituloTransaccion.Text = Base.ItemsDeGrupo(Grupo)(intItem)
                If Grupo.Equals(clsBancos.BancoGrupo.Proveedor) Then
                    'GRUPO: Proveedores
                    If intItem.Equals(clsBancos.EnumProveedor.Pago) Then
                        CeldaAnticipo.ReadOnly = False
                        CeldaAnticipo.BackColor = SystemColors.Window
                    Else
                        'Bloquear anticipo
                        CeldaAnticipo.Text = INT_CERO.ToString("f2")
                        CeldaAnticipo.ReadOnly = True
                        CeldaAnticipo.BackColor = SystemColors.Info
                    End If
                ElseIf Grupo.Equals(clsBancos.BancoGrupo.Caja) Then
                    'GRUPO: Caja chica
                    MostrarPaneles()
                    If intItem.Equals(clsBancos.EnumCaja.Liquidacion) Then
                        'Liquidación
                        Grupo2.Visible = False
                        Grupo3.Visible = False
                        PanelCaja.Visible = True
                    Else
                        CeldaCuenta.Text = String.Empty
                        CeldaCuentaNombre.Text = String.Empty
                        Grupo2.Visible = True
                        Grupo3.Visible = True
                        PanelCaja.Visible = False
                    End If
                ElseIf Grupo.Equals(clsBancos.BancoGrupo.Transferencia) Then
                    'GRUPO: Transferencias
                    MostrarPaneles()
                    If intItem.Equals(clsBancos.EnumTransferencia.Depositos) Then
                        'Transferencia entre cuentas
                        CeldaCuenta.Text = String.Empty
                        CeldaCuentaNombre.Text = String.Empty
                        If intEntidad.Equals(INT_CERO) Then
                            CeldaPersona.Text = String.Empty
                        End If
                        CeldaEmpresa.Focus()
                    Else
                        'Cuenta de gasto
                        intEntidad = INT_CERO
                        CeldaID.Text = String.Empty
                        CeldaEmpresa.Text = String.Empty
                        CeldaPersona.Text = CeldaCuentaNombre.Text
                        CeldaCuenta.Focus()
                    End If
                ElseIf Grupo.Equals(clsBancos.BancoGrupo.Impuestos) Then
                    'GRUPO: Impuestos (débito)
                    MostrarPaneles()
                    If intItem.Equals(clsBancos.EnumImpuestos.ISRRetenciones) Or intItem.Equals(clsBancos.EnumImpuestos.IVARetenciones) Then
                        PanelCompras.Visible = True
                    Else
                        Compras.Rows.Clear()
                        Grupo2.Visible = True
                    End If
                    Grupo3.Visible = True
                End If
            End If
        End Using
    End Sub

    'Monto: validar
    Private Sub CeldaMonto_Validating(sender As Object, e As System.ComponentModel.CancelEventArgs) Handles CeldaMonto.Validating
        'Dim tx As TextBox = DirectCast(sender, TextBox)
        Dim dblTemp As Double = 0.0
        If Double.TryParse(CeldaMonto.Text, dblTemp) Then
            '    dblTemp = Math.Round(dblTemp, 2)
            '    tx.Text = dblTemp.ToString("f")

            '    'Si el grupo deposito es visible y efectivo, cheques y otros bancos es cero, asignar a efectivo el monto
            '    If GrupoDeposito.Visible Then
            '        '     If CDbl(CeldaEfectivo.Text).Equals(0.0) And CDbl(CeldaCheques.Text).Equals(0.0) And CDbl(CeldaOtrosBancos.Text).Equals(0.0) And _EsNuevo Then
            '        CeldaEfectivo.Text = dblTemp.ToString("f")
            '     '   End If
            '    End If

            '    ActualizarTotalLetras()
        Else
            MessageBox.Show("Please enter a valid number", "Numeric field", MessageBoxButtons.OK, MessageBoxIcon.Asterisk)
            CeldaMonto.SelectAll()
            CeldaMonto.Focus()
            e.Cancel = True
        End If
    End Sub

    'Cheque: fila nueva
    Private Sub BotonChequeMas_Click(sender As Object, e As EventArgs) Handles BotonChequeMas.Click
        Dim i As Integer = INT_CERO
        Cheques.Rows.Add(New String() {Today.ToString(FORMATO_MYSQL), String.Empty, String.Empty, "0.00", String.Empty})
        i = (Cheques.Rows.Count - 1)
        Cheques.CurrentCell = Cheques.Rows(i).Cells(cheque_fecha.Index)
        Cheques.Rows(Cheques.Rows.Count - 1).Selected = True
        Cheques.Focus()
        Cheques.BeginEdit(True)
    End Sub

    'Cheque: borrar fila actual
    Private Sub BotonChequeMenos_Click(sender As Object, e As EventArgs) Handles BotonChequeMenos.Click
        If Cheques.CurrentRow IsNot Nothing Then
            Cheques.Rows().Remove(Cheques.CurrentRow)
            If Cheques.Rows.Count > INT_CERO Then
                Cheques.Rows(Cheques.Rows.Count - 1).Selected = True
            End If
            Cheques.Focus()
            SumarDeposito()
        End If
    End Sub

    'Cheque: validar ingreso
    Private Sub Cheques_CellValidating(sender As Object, e As DataGridViewCellValidatingEventArgs) Handles Cheques.CellValidating
        Dim s As String = String.Empty
        If e.ColumnIndex.Equals(cheque_fecha.Index) Then
            If Not String.IsNullOrEmpty(e.FormattedValue) Then
                If Not IsDate(e.FormattedValue) Then
                    MessageBox.Show("Please enter a valid date", "Date", MessageBoxButtons.OK, MessageBoxIcon.Asterisk)
                    e.Cancel = True
                End If
            End If
        ElseIf e.ColumnIndex.Equals(cheque_monto.Index) Then
            If Not IsNumeric(e.FormattedValue) Then
                MessageBox.Show("Please enter a valid number", "Amount", MessageBoxButtons.OK, MessageBoxIcon.Asterisk)
                e.Cancel = True
            End If
        End If
    End Sub

    'Cheque: formato de celdas
    Private Sub Cheques_CellFormatting(sender As Object, e As DataGridViewCellFormattingEventArgs) Handles Cheques.CellFormatting
        If Not String.IsNullOrEmpty(e.Value) Then
            If e.ColumnIndex.Equals(cheque_fecha.Index) Then
                e.Value = CDate(e.Value).ToString(FORMATO_MYSQL)
            ElseIf e.ColumnIndex.Equals(cheque_monto.Index) Then
                e.Value = CDbl(e.Value).ToString("f")
            End If
        End If
    End Sub

    'Cheque: se ha modificado una celda
    Private Sub Cheques_CellValueChanged(sender As Object, e As DataGridViewCellEventArgs) Handles Cheques.CellValueChanged
        If e.ColumnIndex.Equals(cheque_monto.Index) Then
            CeldaOtrosBancos.Text = SumarCheques().ToString("f")
            SumarDeposito()
        End If
    End Sub

    'Texto: efectivo validado
    Private Sub CeldaEfectivo_Validated(sender As Object, e As EventArgs) Handles CeldaEfectivo.Validated
        If CeldaEfectivo.Text = STR_VACIO Then
            MessageBox.Show("Please enter a valid number", "Numeric field", MessageBoxButtons.OK, MessageBoxIcon.Asterisk)
            CeldaEfectivo.SelectAll()
            CeldaEfectivo.Focus()
        Else
            SumarDeposito()
        End If
    End Sub

    'Texto: cheques validado
    Private Sub CeldaCheques_Validated(sender As Object, e As EventArgs) Handles CeldaCheques.Validated
        If CeldaCheques.Text = STR_VACIO Then
            MessageBox.Show("Please enter a valid number", "Numeric field", MessageBoxButtons.OK, MessageBoxIcon.Asterisk)
            CeldaCheques.SelectAll()
            CeldaCheques.Focus()
        Else
            SumarDeposito()
        End If
    End Sub

    'Texto: recibe el foco
    Private Sub Texto_Enter(sender As Object, e As EventArgs)
        Dim tx As TextBox = DirectCast(sender, TextBox)
        tx.SelectAll()
    End Sub

    'Control: evento de carga
    Private Sub usrBancoDeposito_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        'Asignar manejador de evento Enter
        AddHandler CeldaNumero.Enter, AddressOf Texto_Enter
        AddHandler CeldaConcepto.Enter, AddressOf Texto_Enter
        AddHandler CeldaMonto.Enter, AddressOf Texto_Enter
        AddHandler CeldaTasa.Enter, AddressOf Texto_Enter
        AddHandler CeldaReferencia.Enter, AddressOf Texto_Enter
        AddHandler CeldaGastos.Enter, AddressOf Texto_Enter
        AddHandler CeldaNotas.Enter, AddressOf Texto_Enter

        AddHandler CeldaPersona.Enter, AddressOf Texto_Enter
        AddHandler CeldaEfectivo.Enter, AddressOf Texto_Enter
        AddHandler CeldaCheques.Enter, AddressOf Texto_Enter
        AddHandler CeldaAnticipo.Enter, AddressOf Texto_Enter
        AddHandler CeldaDiferencia.Enter, AddressOf Texto_Enter

        'Asignar manejador de evento Validating
        AddHandler CeldaGastos.Validating, AddressOf CeldaMonto_Validating
        AddHandler CeldaEfectivo.Validating, AddressOf CeldaMonto_Validating
        AddHandler CeldaCheques.Validating, AddressOf CeldaMonto_Validating
        AddHandler CeldaAnticipo.Validating, AddressOf CeldaMonto_Validating
        AddHandler CeldaDiferencia.Validating, AddressOf CeldaMonto_Validating

        'Informacion emergente
        InfoTexto.SetToolTip(BotonBuscar, "Add bank transfer related document to notes")
        InfoTexto.SetToolTip(BotonPresupuesto, "Budget allocation")
        InfoTexto.SetToolTip(BotonPoliza, "Show journal entry policy")

        InfoTexto.SetToolTip(BotonChequeMas, "Add new check empty row")
        InfoTexto.SetToolTip(BotonChequeMenos, "Remove current row")
        InfoTexto.SetToolTip(BotonCompraMas, "Show documents with pending balance")
        InfoTexto.SetToolTip(BotonCompraMenos, "Remove current row")
        InfoTexto.SetToolTip(BotonVentaMas, "Show documents with pending balance")
        InfoTexto.SetToolTip(BotonVentaMenos, "Remove current row")
        InfoTexto.SetToolTip(BotonCajaMas, "Select pending reconciliations")
        InfoTexto.SetToolTip(BotonCajaMenos, "Remove current row")

        'Posicionar paneles
        'Paneles al medio derecho
        Grupo1.Size = GrupoDeposito.Size
        Grupo1.Location = GrupoDeposito.Location
        GrupoCuenta.Size = GrupoDeposito.Size
        GrupoCuenta.Location = GrupoDeposito.Location
        'Panel inferior izquierdo
        Grupo2.Size = PanelCheques.Size
        Grupo2.Location = PanelCheques.Location
        PanelCompras.Size = PanelCheques.Size
        PanelCompras.Location = PanelCheques.Location
        'Panel inferior derecho
        Grupo3.Size = PanelVentas.Size
        Grupo3.Location = PanelVentas.Location

        'Detalle de liquidacion
        Dim sz As New Size With {.Height = PanelCheques.Height}
        sz.Width = (GrupoDeposito.Location.X + GrupoDeposito.Size.Width) - GrupoDocumento.Location.X
        PanelCaja.Location = PanelCheques.Location
        PanelCaja.Size = sz
    End Sub

    'Texto: validar tasa de cambio
    Private Sub CeldaTasa_Validating(sender As Object, e As System.ComponentModel.CancelEventArgs) Handles CeldaTasa.Validating
        Dim tx As TextBox = DirectCast(sender, TextBox)
        Dim dblTemp As Double = 0.0
        If Double.TryParse(tx.Text, dblTemp) Then
            dblTemp = Math.Round(dblTemp, 5)
            tx.Text = dblTemp.ToString("N5")
        Else
            MessageBox.Show("Please enter a valid number", "Exchange Rate", MessageBoxButtons.OK, MessageBoxIcon.Asterisk)
            tx.SelectAll()
            tx.Focus()
            e.Cancel = True
        End If
    End Sub

    'Agregar facturas al detalle de compras (ref. proveedor)
    Private Sub BotonCompraMas_Click(sender As Object, e As EventArgs) Handles BotonCompraMas.Click
        If Not intEntidad.Equals(INT_CERO) Then
            'Compras
            MostrarCompras(intEntidad)
            SumarCompras()
        ElseIf Grupo.Equals(clsBancos.BancoGrupo.Impuestos) Then
            'Retenciones de ISR
            MostrarRetenciones()
            SumarCompras()
        End If
    End Sub

    'Quitar una linea del detalle de compras
    Private Sub BotonCompraMenos_Click(sender As Object, e As EventArgs) Handles BotonCompraMenos.Click
        If Compras.CurrentRow IsNot Nothing Then
            Compras.Rows().Remove(Compras.CurrentRow)
            If Compras.Rows.Count > INT_CERO Then
                Compras.Rows(Compras.Rows.Count - 1).Selected = True
            End If
            Compras.Focus()
            SumarCompras()
        End If
    End Sub

    'Compras: formato de celdas
    Private Sub Compras_CellFormatting(sender As Object, e As DataGridViewCellFormattingEventArgs) Handles Compras.CellFormatting
        If Not String.IsNullOrEmpty(e.Value) Then
            If e.ColumnIndex.Equals(compra_monto.Index) Then
                e.Value = CDbl(e.Value).ToString("f")
            End If
        End If
    End Sub

    'Compras: se ha modifcado una celda
    Private Sub Compras_CellValueChanged(sender As Object, e As DataGridViewCellEventArgs) Handles Compras.CellValueChanged
        If e.ColumnIndex.Equals(compra_monto.Index) Then
            SumarCompras()
        End If
    End Sub

    'Compras: validar ingreso
    Private Sub Compras_CellValidating(sender As Object, e As DataGridViewCellValidatingEventArgs) Handles Compras.CellValidating
        Dim s As String = String.Empty
        If e.ColumnIndex.Equals(compra_monto.Index) Then
            If Not IsNumeric(e.FormattedValue) Then
                MessageBox.Show("Please enter a valid number", "Amount", MessageBoxButtons.OK, MessageBoxIcon.Asterisk)
                e.Cancel = True
            End If
        End If
    End Sub

    'Agregar facturas al detalle de ventas (ref. cliente)
    Private Sub BotonVentaMas_Click(sender As Object, e As EventArgs) Handles BotonVentaMas.Click
        Dim strSQL As String = "(SELECT cli_codigo ID, cli_cliente Description FROM Clientes WHERE cli_sisemp={empresa} ORDER BY cli_cliente) x".Replace("{empresa}", Sesion.IdEmpresa)
        Dim intId As Integer = INT_CERO

        'Preguntar si se usa el cliente del documento
        If Not intEntidad.Equals(INT_CERO) Then
            Using frm As New frmOption
                frm.Titulo = " Customer"
                frm.Mensaje = " Select a customer to show his pending documents"
                frm.Opciones = CeldaEmpresa.Text & "|Other (select from the list)"
                If frm.ShowDialog(Me) = DialogResult.OK Then
                    If Not frm.Seleccion.Equals(NO_FILA) Then
                        If Not frm.Seleccion.Equals(INT_CERO) Then
                            'Seleccionar otro cliente desde listado
                            Using lst As New frmSeleccionar
                                lst.Titulo = " another customer"
                                lst.Tabla = strSQL
                                lst.Campos = "x.ID, x.Description"
                                lst.Condicion = "x.ID > 0"
                                lst.FiltroText = "Select one item from the list"
                                lst.Filtro = "x.Description"
                                lst.Ordenamiento = String.Empty
                                lst.TipoOrdenamiento = String.Empty
                                If lst.ShowDialog(Me) = DialogResult.OK Then
                                    intId = lst.LLave
                                End If
                            End Using
                        Else : intId = intEntidad
                        End If
                    End If
                End If

                'Si se ha seleccionado un cliente
                If Not intId.Equals(INT_CERO) Then
                    MostrarVentasPendientes(intId)
                End If
            End Using
        End If
        SumarVentas()
    End Sub

    'Quitar una linea del detalle de ventas
    Private Sub BotonVentaMenos_Click(sender As Object, e As EventArgs) Handles BotonVentaMenos.Click
        If Ventas.CurrentRow IsNot Nothing Then
            Ventas.Rows().Remove(Ventas.CurrentRow)
            If Ventas.Rows.Count > INT_CERO Then
                Ventas.Rows(Ventas.Rows.Count - 1).Selected = True
            End If
            Ventas.Focus()
            SumarVentas()
        End If
    End Sub

    'Ventas: formato de celdas 
    Private Sub Ventas_CellFormatting(sender As Object, e As DataGridViewCellFormattingEventArgs) Handles Ventas.CellFormatting
        If Not String.IsNullOrEmpty(e.Value) Then
            If e.ColumnIndex.Equals(venta_total.Index) Then
                e.Value = CDbl(e.Value).ToString("f")
            End If
        End If
    End Sub

    'Ventas: se ha modificado una celda
    Private Sub Ventas_CellValueChanged(sender As Object, e As DataGridViewCellEventArgs) Handles Ventas.CellValueChanged
        If e.ColumnIndex.Equals(venta_total.Index) Then
            SumarVentas()
        End If
    End Sub

    'Ventas: validar ingreso
    Private Sub Ventas_CellValidating(sender As Object, e As DataGridViewCellValidatingEventArgs) Handles Ventas.CellValidating
        Dim s As String = String.Empty
        If e.ColumnIndex.Equals(venta_total.Index) Then
            If Not IsNumeric(e.FormattedValue) Then
                MessageBox.Show("Please enter a valid number", "Total", MessageBoxButtons.OK, MessageBoxIcon.Asterisk)
                e.Cancel = True
            End If
        End If
    End Sub

    'Gastos: validar
    Private Sub CeldaGastos_Validating(sender As Object, e As System.ComponentModel.CancelEventArgs) Handles CeldaGastos.Validating
        Dim tx As TextBox = DirectCast(sender, TextBox)
        Dim dblTemp As Double = 0.0
        If Double.TryParse(tx.Text, dblTemp) Then
            dblTemp = Math.Round(dblTemp, 2)
            tx.Text = dblTemp.ToString(FORMATO_MONEDA)
            CeldaEfectivo.Text = (dblTemp + CeldaMonto.Text).ToString(FORMATO_MONEDA)
            SumarDeposito()
        Else
            MessageBox.Show("Please enter a valid number", "Numeric field", MessageBoxButtons.OK, MessageBoxIcon.Asterisk)
            tx.SelectAll()
            tx.Focus()
            e.Cancel = True
        End If
    End Sub

    'Asociar documento bancario
    Private Sub BotonBuscar_Click(sender As Object, e As EventArgs) Handles BotonBuscar.Click
        Dim intID As Integer = INT_CERO
        Dim dblTasa As Double = CDbl(CeldaTasa.Text)
        Dim dblEx As Double = 0.0
        Dim strCuenta As String = String.Empty
        Dim strSQL As String = String.Empty

        Dim col As DataGridViewTextBoxColumn
        Dim sel As frmSeleccionMultiple
        Dim cmd As MySqlCommand
        Dim da As MySqlDataAdapter
        Dim dt As New System.Data.DataTable
        Dim gr As DataGridViewRow

        'Listado de cuentas
        strSQL = "(SELECT BCta_Num ID, BCta_Num_Cue Number, BCta_Nom_Cue Description FROM CtasBcos WHERE BCta_Sis_Emp={empresa} AND BCta_Tipo=0) x".Replace("{empresa}", Sesion.IdEmpresa)
        Using frm As New frmSeleccionar
            frm.Titulo = " Bank Account"
            frm.Tabla = strSQL
            frm.Campos = "x.ID, x.Description, x.Number"
            frm.Condicion = "x.ID > 0"
            frm.FiltroText = "Show documents to link from the following bank account"
            frm.Filtro = "x.Description"
            frm.Ordenamiento = "x.Description"
            frm.TipoOrdenamiento = String.Empty
            If frm.ShowDialog(Me) = DialogResult.OK Then
                intID = frm.LLave
                frm.Close()

                'Número de cuenta
                strSQL = "SELECT BCta_Num_Cue FROM CtasBcos WHERE BCta_Sis_Emp={empresa} AND BCta_Num={id} LIMIT 1"
                strSQL = strSQL.Replace("{empresa}", Sesion.IdEmpresa)
                strSQL = strSQL.Replace("{id}", intID)
                MyCnn.CONECTAR = strConexion
                cmd = New MySqlCommand(strSQL, CON)
                strCuenta = cmd.ExecuteScalar

                'Documentos de transferencia
                strSQL = "  SELECT h.HDoc_Doc_Cat Tipo, h.HDoc_Doc_Ano Ciclo, h.HDoc_Doc_Num Numero, h.HDoc_Doc_Fec Fecha, CONCAT(c.cat_desc, ' - ', h.HDoc_DR1_Num) Documento, c1.cat_desc Moneda, h.HDoc_RF1_Dbl Monto, h.HDoc_Doc_TC Tasa " &
                         "  FROM Dcmtos_HDR h " &
                         "       LEFT JOIN Catalogos c ON c.cat_num=h.HDoc_Doc_Cat " &
                         "       LEFT JOIN Catalogos c1 ON c1.cat_num=h.HDoc_Doc_Mon " &
                         "  WHERE h.HDoc_Sis_Emp={empresa} AND (h.HDoc_Doc_Cat={cheque} OR h.HDoc_Doc_Cat={debito} OR h.HDoc_Doc_Cat={credito} OR h.HDoc_Doc_Cat={deposito}) AND " &
                         "        h.HDoc_DR1_Cat={grupo} AND h.HDoc_DR2_Cat={item} AND h.HDoc_RF1_Num = {banco} AND ISNULL(h.HDoc_DR2_Emp)"

                strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
                strSQL = Replace(strSQL, "{cheque}", Base.IdCheque)
                strSQL = Replace(strSQL, "{credito}", Base.IdCredito)
                strSQL = Replace(strSQL, "{debito}", Base.IdDebito)
                strSQL = Replace(strSQL, "{deposito}", Base.IdDeposito)
                strSQL = Replace(strSQL, "{banco}", intID)
                strSQL = Replace(strSQL, "{grupo}", clsBancos.BancoGrupo.Transferencia)
                strSQL = Replace(strSQL, "{item}", clsBancos.EnumTransferencia.Depositos)
                MyCnn.CONECTAR = strConexion
                cmd = New MySqlCommand(strSQL, CON)
                da = New MySqlDataAdapter(cmd)
                da.Fill(dt)
                If dt.Rows.Count > INT_CERO Then
                    sel = New frmSeleccionMultiple
                    sel.strTipoVenta = 0
                    sel.Text = "Document to link"

                    'Configurar lista
                    col = CrearColumnaTexto("lista_tipo")
                    sel.Lista.Columns.Add(col)
                    col = CrearColumnaTexto("lista_ciclo")
                    sel.Lista.Columns.Add(col)
                    col = CrearColumnaTexto("lista_numero")
                    sel.Lista.Columns.Add(col)
                    col = CrearColumnaTexto("lista_fecha", "Date", True, True, 70)
                    col.ValueType = GetType(Date)
                    col.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter
                    sel.Lista.Columns.Add(col)
                    col = CrearColumnaTexto("lista_documento", "Document", True, True, 150)
                    col.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter
                    sel.Lista.Columns.Add(col)
                    col = CrearColumnaTexto("lista_moneda", "Currency", True, True, 60)
                    sel.Lista.Columns.Add(col)
                    col = CrearColumnaTexto("lista_monto", "Amount", True, True, 60)
                    col.ValueType = GetType(Decimal)
                    col.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight
                    sel.Lista.Columns.Add(col)
                    col = CrearColumnaTexto("lista_tasa", "Ex. Rate", True, True, 60)
                    sel.Lista.Columns.Add(col)

                    sel.Lista.SuspendLayout()
                    sel.Lista.AllowUserToAddRows = True
                    For Each dr As DataRow In dt.Rows
                        gr = sel.Lista.Rows(sel.Lista.NewRowIndex).Clone
                        gr.Cells(sel.Lista.Columns.Item("lista_tipo").Index).Value = dr("tipo").ToString
                        gr.Cells(sel.Lista.Columns.Item("lista_ciclo").Index).Value = dr("ciclo").ToString
                        gr.Cells(sel.Lista.Columns.Item("lista_numero").Index).Value = dr("numero").ToString
                        gr.Cells(sel.Lista.Columns.Item("lista_fecha").Index).Value = CDate(dr("fecha")).ToString(FORMATO_MYSQL)
                        gr.Cells(sel.Lista.Columns.Item("lista_documento").Index).Value = dr("documento").ToString
                        gr.Cells(sel.Lista.Columns.Item("lista_moneda").Index).Value = dr("moneda").ToString
                        gr.Cells(sel.Lista.Columns.Item("lista_monto").Index).Value = CDbl(dr("monto")).ToString("f")
                        gr.Cells(sel.Lista.Columns.Item("lista_tasa").Index).Value = CDbl(dr("tasa")).ToString("f5")
                        sel.Lista.Rows.Add(gr)
                    Next
                    sel.Lista.AllowUserToAddRows = False
                    sel.Lista.ResumeLayout()

                    If sel.ShowDialog(Me) = DialogResult.OK Then
                        gr = sel.Lista.CurrentRow
                        dblEx = Math.Round(CDbl(gr.Cells(sel.Lista.Columns.Item("lista_tasa").Index).Value), 5)
                        If Not dblEx.Equals(INT_CERO) Then
                            'Colocar el texto en las notas
                            CeldaNotas.Text = "Doc. Ref.: " &
                                              gr.Cells(sel.Lista.Columns.Item("lista_documento").Index).Value & " - " &
                                              gr.Cells(sel.Lista.Columns.Item("lista_fecha").Index).Value & Constants.vbCrLf &
                                              "Cta. Ref.: " & strCuenta
                            If Not dblTasa.Equals(dblEx) Then
                                'Remplazar la tasa de cambio por la de referencia
                                If MessageBox.Show("Replace current exchange rate?" & Constants.vbCrLf & Constants.vbCrLf &
                                                   "This document: " & dblTasa.ToString("f5") & Constants.vbCrLf &
                                                   "Doc. Ref.: " & dblEx.ToString("f5"), "Exchange Rate", MessageBoxButtons.YesNo, MessageBoxIcon.Exclamation) = DialogResult.Yes Then
                                    CeldaTasa.Text = dblEx.ToString("f4")
                                End If
                            End If
                        End If
                    End If
                    CeldaNotas.Focus()
                Else
                    MessageBox.Show("No documents found", "Bank Account", MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
                End If
            End If
        End Using

    End Sub

    'Seleccionar tipo de documento
    Private Sub BotonDocumento_Click(sender As Object, e As EventArgs) Handles BotonDocumento.Click
        Dim strSQL As String = "(SELECT cat_num ID, cat_desc Description FROM Catalogos WHERE cat_clase='DocsBcos' {filtro} ORDER BY cat_desc) x"
        If EsNuevo Or Documento.Equals(INT_CERO) Then
            strSQL = strSQL.Replace("{filtro}", "AND NOT(cat_sist={deposito} OR cat_sist ={cheque} OR cat_sist={documento})")
        Else : strSQL = strSQL.Replace("{filtro}", "AND cat_num={id}")
        End If
        strSQL = strSQL.Replace("{deposito}", Base.Text(clsBancos.BCO_DEPOSITO))
        strSQL = strSQL.Replace("{cheque}", Base.Text(clsBancos.BCO_CHEQUE))
        strSQL = strSQL.Replace("{id}", Documento)
        If Tipo.Equals(Base.IdCredito) Then
            strSQL = strSQL.Replace("{documento}", Base.Text(clsBancos.BCO_DEBITO))
        Else : strSQL = strSQL.Replace("{documento}", Base.Text(clsBancos.BCO_CREDITO))
        End If

        Using frm As New frmSeleccionar
            frm.Titulo = " Document Type"
            frm.Tabla = strSQL
            frm.Campos = "x.ID, x.Description"
            frm.Condicion = "x.ID > 0"
            frm.FiltroText = "Select one item from the list"
            frm.Filtro = "x.Description"
            frm.Ordenamiento = String.Empty
            frm.TipoOrdenamiento = String.Empty
            If frm.ShowDialog(Me) = DialogResult.OK Then
                Documento = CInt(frm.LLave)
                CeldaDocumento.Text = frm.Dato
                CeldaDocumento.Focus()
            End If
        End Using
    End Sub

    'Seleccionar cuenta contable
    Private Sub BotonCC_Click(sender As Object, e As EventArgs) Handles BotonCC.Click
        Dim strTemp As String = String.Empty
        If cFunciones.ContaActiva Then
            Dim strSQL As String = Base.SQLCuentasContables
            Using frm As New frmSeleccionar
                frm.Titulo = " Account"
                frm.Tabla = "({sql}) x".Replace("{sql}", strSQL)
                frm.Campos = "x.Account, x.Description"
                frm.Condicion = "NOT(x.Account='')"
                frm.FiltroText = "Select one item from the list"
                frm.Filtro = "x.Description"
                frm.Ordenamiento = String.Empty
                frm.TipoOrdenamiento = String.Empty
                If frm.ShowDialog() = DialogResult.OK Then
                    strTemp = frm.ListaClientes.CurrentRow.Cells(0).Value
                    If Not (strTemp.Equals(CeldaCuenta.Text)) Then
                        'TODO verificar que sea cuenta de ultimo nivel

                        CeldaCuenta.Text = strTemp
                        CeldaCuentaNombre.Text = frm.Dato
                        CeldaPersona.Text = CeldaCuentaNombre.Text.ToUpper
                    End If
                End If
            End Using
        End If
    End Sub

    'Devuelve el ID de modo de poliza contable para el documento
    Private Function ModoDePoliza() As Integer
        Const MODO_CHEQUE As Integer = 14
        Const MODO_DEBITO As Integer = 15
        Const MODO_CREDITO As Integer = 16
        Const MODO_DEPOSITO As Integer = 17

        Dim intModo As Integer = INT_CERO
        Select Case Tipo
            Case Base.IdCheque : intModo = MODO_CHEQUE
            Case Base.IdDebito : intModo = MODO_DEBITO
            Case Base.IdCredito : intModo = MODO_CREDITO
            Case Base.IdDeposito : intModo = MODO_DEPOSITO
        End Select
        Return intModo
    End Function

    'Mostrar la póliza contable asociada a este documento
    Private Sub BotonPoliza_Click(sender As Object, e As EventArgs) Handles BotonPoliza.Click
        Dim cp As clsPolizaContable
        If cFunciones.ContaActiva Then
            cp = New clsPolizaContable With {
                .intModo = ModoDePoliza(),
                .intTipo = Tipo,
                .intCiclo = Ciclo,
                .intNumero = Numero}
            cp.MostrarPolizaContable()
        End If
        CON.Close()
        CON.Open()
    End Sub

    'Agregar linea a ventas desde cuenta contable 
    Private Sub BotonVentaCuenta_Click(sender As Object, e As EventArgs) Handles BotonVentaCuenta.Click
        If cFunciones.ContaActiva Then
            SeleccionarCuentaParaVentas()
        End If
    End Sub

    'Agregar linea a ventas desde cuenta contable de gastos
    Private Sub BotonVentaGasto_Click(sender As Object, e As EventArgs) Handles BotonVentaGasto.Click
        If cFunciones.ContaActiva Then
            SeleccionarCuentaParaVentas(True)
        End If
    End Sub

    'Permite elegir una cuenta contable para agregar una linea a ventas
    Private Sub SeleccionarCuentaParaVentas(Optional EsDeGastos As Boolean = False)
        Dim strCuenta As String
        Dim strTexto As String
        Dim strTitulo As String = IIf(EsDeGastos, " Expenses", String.Empty) & " Account"

        Dim strSQL As String
        If EsDeGastos Then
            strSQL = Base.SQLCuentasContablesDeGastos()
        Else : strSQL = Base.SQLCuentasContables()
        End If

        Using frm As New frmSeleccionar
            frm.Titulo = strTitulo
            frm.Tabla = "({sql}) x".Replace("{sql}", strSQL)
            frm.Campos = "x.Account, x.Description"
            frm.Condicion = "NOT(x.Account='')"
            frm.FiltroText = "Select one item from the list"
            frm.Filtro = "x.Description"
            frm.Ordenamiento = String.Empty
            frm.TipoOrdenamiento = String.Empty
            If frm.ShowDialog() = DialogResult.OK Then
                strCuenta = frm.ListaClientes.CurrentRow.Cells(0).Value
                strTexto = frm.Dato
                AgregarVentaDesdeCuenta(strCuenta, strTexto)
            End If
        End Using
        SumarVentas()
    End Sub

    'Agrega una linea a ventas desde una cuenta de gastos
    Private Sub AgregarVentaDesdeCuenta(ByVal Cuenta As String, ByVal Texto As String)
        Dim gr As DataGridViewRow
        Ventas.SuspendLayout()
        Ventas.AllowUserToAddRows = True

        gr = Ventas.Rows(Ventas.NewRowIndex).Clone
        'Cargo agregado manualmente
        gr.Cells(venta_tipo.Index).Value = INT_CERO.ToString
        gr.Cells(venta_ciclo.Index).Value = INT_CERO.ToString
        gr.Cells(venta_grupo.Index).Value = String.Empty
        gr.Cells(venta_numero.Index).Value = String.Empty
        gr.Cells(venta_numero.Index).Style.BackColor = Color.LightSlateGray
        gr.Cells(venta_serie.Index).Value = Cuenta
        gr.Cells(venta_fecha.Index).Value = String.Empty
        gr.Cells(venta_fecha.Index).Style.BackColor = Color.LightSlateGray
        gr.Cells(venta_moneda.Index).Value = INT_CERO.ToString
        gr.Cells(venta_tasa.Index).Value = INT_CERO.ToString
        gr.Cells(venta_ref.Index).Value = Texto
        gr.Cells(venta_monto.Index).Value = CDbl(INT_CERO).ToString("f")
        gr.Cells(venta_total.Index).Value = CDbl(INT_CERO).ToString("f")
        gr.Cells(venta_id.Index).Value = INT_CERO.ToString
        Ventas.Rows.Add(gr)
        gr.Selected = True
        gr.Cells(venta_total.Index).Selected = True

        Ventas.AllowUserToAddRows = False
        Ventas.ResumeLayout()

        Ventas.BeginEdit(True)
    End Sub

    'Agregar linea a ventas desde cuenta contable 
    Private Sub BotonCompraCuenta_Click(sender As Object, e As EventArgs) Handles BotonCompraCuenta.Click
        If cFunciones.ContaActiva Then
            SeleccionarCuentaParaCompras()
        End If
    End Sub

    'Agregar linea a ventas desde cuenta contable  de gastos
    Private Sub BotonCompraGasto_Click(sender As Object, e As EventArgs) Handles BotonCompraGasto.Click
        If cFunciones.ContaActiva Then
            SeleccionarCuentaParaCompras(True)
        End If
    End Sub

    'Permite elegir una cuenta contable para agregar una linea a com
    Private Sub SeleccionarCuentaParaCompras(Optional EsDeGastos As Boolean = False)
        Dim strCuenta As String
        Dim strTexto As String
        Dim strTitulo As String = IIf(EsDeGastos, " Expenses", String.Empty) & " Account"
        Dim strTemp As String = String.Empty
        Dim dblTasa As Double = CDbl(CeldaTasa.Text)
        Dim dblCambio As Double = 0.0
        Dim logErr As Boolean = False
        Dim strSQL As String
        If EsDeGastos Then
            strSQL = Base.SQLCuentasContablesDeGastos()
        Else : strSQL = Base.SQLCuentasContables()
        End If

        Using frm As New frmSeleccionar
            frm.Titulo = strTitulo
            frm.Tabla = "({sql}) x".Replace("{sql}", strSQL)
            frm.Campos = "x.Account, x.Description"
            frm.Condicion = "NOT(x.Account='')"
            frm.FiltroText = "Select one item from the list"
            frm.Filtro = "x.Description"
            frm.Ordenamiento = String.Empty
            frm.TipoOrdenamiento = String.Empty
            If frm.ShowDialog() = DialogResult.OK Then
                strTemp = Base.PedirDato("The document in local currency has no exchange rate" & vbCr & vbCr & "Confirm if you want to use the following value", "Exchange Rate", dblTasa.ToString("f5"))
                If strTemp.Equals(String.Empty) Then
                    logErr = True
                ElseIf Not IsNumeric(strTemp) Then
                    MessageBox.Show(strTemp & " is not a valid exchange rate value" & vbCr & vbCr & "Document  will not be added", "Exchange Rate", MessageBoxButtons.OK, MessageBoxIcon.Warning)
                    logErr = True
                Else
                    'Este dato se guardara en el detalle del documento
                    dblCambio = CDbl(strTemp)
                End If
                strCuenta = frm.ListaClientes.CurrentRow.Cells(0).Value
                strTexto = frm.Dato
                AgregarCompraDesdeCuenta(strCuenta, strTexto, dblCambio)
            End If
        End Using
        SumarCompras()
    End Sub

    'Agrega una linea a compras desde una cuenta de gastos
    Private Sub AgregarCompraDesdeCuenta(ByVal Cuenta As String, ByVal Texto As String, ByVal dblCambio As Double)
        Dim gr As DataGridViewRow
        Compras.SuspendLayout()
        Compras.AllowUserToAddRows = True

        gr = Compras.Rows(Compras.NewRowIndex).Clone
        'Cargo agregado manualmente
        gr.Cells(compra_tipo.Index).Value = INT_CERO.ToString
        gr.Cells(compra_ciclo.Index).Value = INT_CERO.ToString
        gr.Cells(compra_numero.Index).Value = INT_CERO.ToString

        'Cuenta y descripción
        gr.Cells(compra_cuenta.Index).Value = Cuenta
        gr.Cells(compra_descripcion.Index).Value = Texto
        gr.Cells(compra_descripcion.Index).Style.BackColor = Color.LightSlateGray

        gr.Cells(compra_moneda.Index).Value = INT_CERO.ToString
        gr.Cells(compra_tasa.Index).Value = INT_CERO.ToString
        gr.Cells(compra_monto.Index).Value = CDbl(INT_CERO).ToString("f")

        gr.Cells(compra_ref_ciclo.Index).Value = INT_CERO.ToString
        gr.Cells(compra_ref_numero.Index).Value = INT_CERO.ToString

        gr.Cells(compra_cambio.Index).Value = dblCambio
        gr.Cells(compra_marca.Index).Value = If(dblCambio > 0, "#", String.Empty)

        Compras.Rows.Add(gr)
        gr.Selected = True
        gr.Cells(compra_monto.Index).Selected = True

        Compras.AllowUserToAddRows = False
        Compras.ResumeLayout()

        Compras.BeginEdit(True)
    End Sub

    'Limpiar liquidacion de caja chica actual
    Private Sub BotonCajaMenos_Click(sender As Object, e As EventArgs) Handles BotonCajaMenos.Click
        With Relacion
            .Tipo = INT_CERO
            .Ciclo = INT_CERO
            .Numero = INT_CERO
        End With
        EtiquetaCajaTitulo.Text = "Petty Cash Reconciliation"
        EtiquetaCajaFecha.Text = String.Empty
        CeldaTotalCaja.Text = INT_CERO.ToString("f")
        CeldaDiferencia.Text = INT_CERO.ToString("f")
        Caja.Rows.Clear()
    End Sub

    'Seleccionar liquidacion de caja chica actual
    Private Sub BotonCajaMas_Click(sender As Object, e As EventArgs) Handles BotonCajaMas.Click
        If intEntidad.Equals(INT_CERO) Then
            MessageBox.Show("No petty cash selected", "Petty Cash Reconciliation", MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
            CeldaEmpresa.Focus()
        Else
            MostrarLiquidacionesPendientes(intEntidad)
        End If
    End Sub

    'Asignar presupuesto para documento de débito
    Private Sub BotonPresupuesto_Click(sender As Object, e As EventArgs) Handles BotonPresupuesto.Click
        ModificarPresupuesto()
    End Sub

    Private Sub EtiquetaLetras_DoubleClick(sender As Object, e As EventArgs) Handles EtiquetaLetras.DoubleClick
        MessageBox.Show(String.Concat(Tipo, "-", Ciclo, "-", Numero), "ID de documento", MessageBoxButtons.OK, MessageBoxIcon.Information)
    End Sub

    Private Sub Compras_KeyDown(sender As Object, e As KeyEventArgs) Handles Compras.KeyDown
        Dim row As DataGridViewRow = Compras.CurrentRow
        If e.KeyCode = Keys.F1 Then
            e.SuppressKeyPress = True
            If row IsNot Nothing Then
                MessageBox.Show(String.Concat("Tipo: ", row.Cells(compra_tipo.Index).Value, vbCrLf, "Año: ", row.Cells(compra_ciclo.Index).Value, vbCrLf, "Numero: ", row.Cells(compra_numero.Index).Value, vbCrLf, "Moneda: ", row.Cells(compra_moneda.Index).Value, vbCrLf, "Numero: ", row.Cells(compra_tasa.Index).Value), "Document", MessageBoxButtons.OK, MessageBoxIcon.Information)
            End If
        End If
    End Sub

    Private Sub CasillaAnulado_CheckedChanged(sender As Object, e As EventArgs) Handles CasillaAnulado.CheckedChanged
        CasillaAnulado.ForeColor = SystemColors.ControlText
        If CasillaAnulado.Checked Then
            CasillaAnulado.Font = New System.Drawing.Font(CasillaAnulado.Font, FontStyle.Bold)
            If Tipo.Equals(Base.IdCheque) Then
                CasillaAnulado.ForeColor = Color.Red
            End If
        Else
            CasillaAnulado.Font = New System.Drawing.Font(CasillaAnulado.Font, FontStyle.Regular)
        End If
    End Sub

    Private Sub CasillaCobrado_CheckedChanged(sender As Object, e As EventArgs) Handles CasillaCobrado.CheckedChanged
        If CasillaCobrado.Checked Then
            CasillaCobrado.Font = New System.Drawing.Font(CasillaCobrado.Font, FontStyle.Bold)
        Else
            CasillaCobrado.Font = New System.Drawing.Font(CasillaCobrado.Font, FontStyle.Regular)
        End If
    End Sub

    'Actualizar la tasa de cambio alternativa para un documento en moneda local en una transaccion en moneda externa
    Private Sub Compras_CellDoubleClick(sender As Object, e As DataGridViewCellEventArgs) Handles Compras.CellDoubleClick
        Dim s As String = String.Concat(Compras.CurrentRow.Cells(e.ColumnIndex).Value)
        Dim strTemp As String
        If s.Equals("#") Then
            strTemp = Base.PedirDato("Change the alternate exchange rate for this document" & vbCr & vbCr & "Keep of modify the following value", "Exchange Rate", CDbl(Compras.CurrentRow.Cells(compra_cambio.Index).Value).ToString("f5"))
            If strTemp.Equals(String.Empty) Then
            ElseIf Not IsNumeric(strTemp) Then
                MessageBox.Show(strTemp & " is not a valid exchange rate value", "Exchange Rate", MessageBoxButtons.OK, MessageBoxIcon.Warning)
            Else
                Compras.CurrentRow.Cells(compra_cambio.Index).Value = CDbl(strTemp)
                Compras.CurrentRow.Cells(compra_monto.Index).Value = Compras.CurrentRow.Cells(compra_factura.Index).Value / CDbl(strTemp)
            End If
        End If
    End Sub
    Private Sub CeldaMonto_TextChanged(sender As Object, e As EventArgs) Handles CeldaMonto.TextChanged
        '  Dim tx As TextBox = DirectCast(sender, TextBox)
        Dim dblTemp As Double = 0.0
        '  If Double.TryParse(CeldaMonto.Text, dblTemp) Then


        'Si el grupo deposito es visible y efectivo, cheques y otros bancos es cero, asignar a efectivo el monto
        If GrupoDeposito.Visible Then
            '     If CDbl(CeldaEfectivo.Text).Equals(0.0) And CDbl(CeldaCheques.Text).Equals(0.0) And CDbl(CeldaOtrosBancos.Text).Equals(0.0) And _EsNuevo Then
            dblTemp = CeldaMonto.Text
            CeldaEfectivo.Text = dblTemp.ToString(FORMATO_MONEDA)
            '   End If
        End If

        ActualizarTotalLetras()
        ' Else
        'MessageBox.Show("Please enter a valid number", "Numeric field", MessageBoxButtons.OK, MessageBoxIcon.Asterisk)
        'CeldaMonto.SelectAll()
        'CeldaMonto.Focus()
        'End If
    End Sub

    Private Sub GrupoCuenta_Enter(sender As Object, e As EventArgs) Handles GrupoCuenta.Enter
    End Sub
    'Metodo de Acceso
    Private Sub Accessos()
        Dim cAccesos As New clsAccesos
        Try
            If cAccesos.Accesos("frmBCuenta") = True Then
                logInsertar = cAccesos.Insertar
                logConsultar = cAccesos.Consultar
                logEditar = cAccesos.Editar
                logBorrar = cAccesos.Borrar
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub Fecha_ValueChanged(sender As Object, e As EventArgs) Handles Fecha.ValueChanged
        CeldaTasa.Text = cFunciones.TasaSegunFecha(Fecha.Value.ToString(FORMATO_MYSQL))
    End Sub

End Class