﻿Public Class frmMensaje
    Dim strMensaje As String
    Public WriteOnly Property Mensaje As String
        Set(value As String)
            strMensaje = value
        End Set
    End Property

    Private Sub frmMensaje_Load(sender As Object, e As EventArgs) Handles Me.Load
        etiquetaMensaje.Text = strMensaje
    End Sub
End Class