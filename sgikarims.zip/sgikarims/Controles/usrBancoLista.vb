﻿Public Class usrBancoLista
    Public Event CuentaSeleccionada(ByVal ID As Integer)

    'Devuelve la ID de la cuenta correspondiente a la fila actual
    Public Function IDCuenta() As Integer
        Dim intID As Integer = vbEmpty
        If Not (Lista.SelectedRows.Count = vbEmpty) Then
            intID = Convert.ToInt32(Lista.SelectedCells(vbEmpty).Value)
        End If
        Return intID
    End Function

    'Carga los datos al listado de cuentas
    Public Sub MostrarLista(ByRef Clase As clsBancos)
        Dim cmd As MySqlCommand
        Dim da As MySqlDataAdapter
        Dim dt As System.Data.DataTable
        Dim row As DataGridViewRow

        'Limpiar conexion
        MyCnn.CONECTAR = strConexion
        Cursor = Cursors.AppStarting
        MyCnn.CONECTAR = strConexion
        cmd = New MySqlCommand(Clase.SQLListaCuentas, CON)
        da = New MySqlDataAdapter(cmd)
        dt = New System.Data.DataTable
        da.Fill(dt)

        Lista.Rows.Clear()
        Lista.SuspendLayout()
        Lista.AllowUserToAddRows = True

        Cursor = Cursors.WaitCursor

        For Each dr As DataRow In dt.Rows
            'Si no ha sido agregado aun
            row = Lista.Rows(Lista.NewRowIndex).Clone
            row.Cells(lista_no.Index).Value = dr("no")
            row.Cells(lista_banco.Index).Value = dr("bank")
            row.Cells(lista_numero.Index).Value = dr("account_number")
            row.Cells(lista_nombre.Index).Value = dr("account_name")
            row.Cells(lista_descripcion.Index).Value = dr("description")
            row.Cells(lista_moneda.Index).Value = dr("currency")
            Lista.Rows.Add(row)
        Next
        Lista.AllowUserToAddRows = False
        Lista.ResumeLayout()

        Cursor = Cursors.Default
    End Sub

    'Carga del formulario
    Private Sub usrBancoLista_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Lista.Visible = True
        Lista.Dock = DockStyle.Fill
    End Sub

    'Doble clic en una cuenta bancaria
    Private Sub Lista_DoubleClick(sender As Object, e As EventArgs) Handles Lista.DoubleClick
        Dim intID As Integer = vbEmpty
        If Not (Lista.SelectedRows.Count = vbEmpty) Then
            intID = Convert.ToInt32(Lista.SelectedCells(INT_CERO).Value)

            RaiseEvent CuentaSeleccionada(intID)
        End If
    End Sub
End Class
