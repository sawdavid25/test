﻿Public Class frmOption


#Region "Miembros"
    Dim strOpciones As String = STR_VACIO
    Dim intSeleccion As String = NO_FILA
    Dim strTitulo As String = STR_VACIO
    Dim strMensaje As String = STR_VACIO
    Dim strBase As String = STR_VACIO
#End Region

#Region "Propiedades"

    Public WriteOnly Property Opciones As String
        Set(value As String)
            strOpciones = value
        End Set
    End Property

    Public ReadOnly Property Seleccion As Integer
        Get
            Return intSeleccion
        End Get
    End Property

    Public WriteOnly Property Titulo As String
        Set(value As String)
            strTitulo = value
        End Set
    End Property

    Public WriteOnly Property Mensaje As String
        Set(value As String)
            strMensaje = value
        End Set
    End Property

    Public Property FilaBase As String
        Get
            Return strBase
        End Get
        Set(value As String)
            strBase = value
        End Set
    End Property

#End Region

#Region "Funciones"

    Private Sub CrearOpciones()
        Dim arrayOpciones() As String
        Dim intTop As Integer = 10
        Try
            Me.Text = strTitulo
            celdaMensaje.Text = strMensaje
            If strOpciones.Length > 0 Then
                arrayOpciones = strOpciones.Split("|".ToCharArray)
                For i As Integer = INT_CERO To arrayOpciones.Length - 1
                    Dim RB As New RadioButton
                    RB.Top = intTop + 26 * i
                    RB.Left = 50
                    RB.Name = i
                    RB.Width = arrayOpciones(i).Length + 300
                    RB.Text = arrayOpciones(i)

                    RB.Parent = Me.Panel1
                    If i = INT_CERO Then
                        RB.Checked = True
                    End If
                Next
            Else
                MsgBox("frmOpcion: No se indico ninguna opcion que cargar")
                Exit Sub
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

#End Region



    Private Sub frmOpcion_Load(sender As Object, e As EventArgs) Handles Me.Load
        CrearOpciones()
        botonAceptar.Focus()
        HorizontalScroll.Visible = False
        HorizontalScroll.Enabled = False
    End Sub

    Private Sub botonAceptar1_Click(sender As Object, e As EventArgs) Handles botonAceptar.Click
        For Each r As RadioButton In Me.Panel1.Controls
            If r.Checked = True Then
                intSeleccion = r.Name
                strBase = r.Text
                Me.DialogResult = System.Windows.Forms.DialogResult.OK
            End If
        Next
    End Sub

    Private Sub botonCancelar_Click(sender As Object, e As EventArgs) Handles botonCancelar.Click
        Me.DialogResult = System.Windows.Forms.DialogResult.Cancel
    End Sub

    Private Sub Panel1_Paint(sender As Object, e As PaintEventArgs) Handles Panel1.Paint

    End Sub
End Class