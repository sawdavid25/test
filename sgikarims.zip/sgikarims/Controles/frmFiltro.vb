﻿Public Class frmFiltro

#Region "Estructuras"

    Private Structure RFechas
        Dim strTituloFechas As String
        Dim fechaInicio As Date
        Dim fechaFin As Date
        Dim fechaCorte As Date
    End Structure

    Private Structure Opcion
        Dim strTituloOpciones As String
        Dim strOpciones As String
        Dim intSeleccion As Integer
    End Structure

    Private Structure Filtro
        Dim strTituloFiltro As String
        Dim strSql As String
        Dim intSeleccion As Integer
        Dim logVisible As Boolean
        Dim strTexto As String
        Dim tipoFiltro As Integer
    End Structure

    Private Structure Banderas
        Dim logFecha As Boolean
        Dim logOpcion As Boolean
        Dim logFiltro As Boolean
        Dim logCorte As Boolean
    End Structure

#End Region

#Region "Miembros"

    Dim strTitulo As String
    Dim sFechas As New RFechas
    Dim sFiltro As New Filtro
    Dim sFiltro2 As New Filtro
    Dim sFiltro3 As New Filtro
    Dim sOpcion As New Opcion
    Dim sBanderas As Banderas
    Dim strkey As String
    Dim intFilto As Integer = INT_CERO
    Dim strFechInicio As Date
    Dim strFechaFin As Date
    Dim strOpciones As String = STR_VACIO

#End Region

#Region "Propiedades"

    Public WriteOnly Property TipoFiltro As Integer

        Set(value As Integer)
            intFilto = value
        End Set

    End Property
    Public Property key As String
        Get
            Return strkey
        End Get
        Set(value As String)
            strkey = value
        End Set
    End Property

    Public WriteOnly Property Titulo As String
        Set(value As String)
            strTitulo = value
        End Set
    End Property

    Public WriteOnly Property TituloFechas As String
        Set(value As String)
            sFechas.strTituloFechas = value
        End Set
    End Property

    Public Property FechaInicio As Date
        Get
            Return sFechas.fechaInicio
        End Get
        Set(value As Date)
            sFechas.fechaInicio = value
        End Set
    End Property

    Public Property FechaFin As Date
        Get
            Return sFechas.fechaFin
        End Get
        Set(value As Date)
            sFechas.fechaFin = value
        End Set
    End Property
    Public ReadOnly Property FechaCorte As Date
        Get
            Return sFechas.fechaCorte
        End Get
    End Property

    Public WriteOnly Property TituloOpcion As String
        Set(value As String)
            sOpcion.strTituloOpciones = value
        End Set
    End Property

    Public WriteOnly Property Opciones As String
        Set(value As String)
            sOpcion.strOpciones = value
        End Set
    End Property

    Public ReadOnly Property SelOpcion As Integer
        Get
            Return sOpcion.intSeleccion
        End Get
    End Property
    'Flitros

    Public WriteOnly Property TituloFiltro As String
        Set(value As String)
            sFiltro.strTituloFiltro = value
        End Set
    End Property

    Public WriteOnly Property SqlFiltro As String
        Set(value As String)
            sFiltro.strSql = value
        End Set
    End Property

    Public ReadOnly Property SelFiltro As String
        Get
            Return sFiltro.intSeleccion
        End Get
    End Property

    Public ReadOnly Property SelFiltroText As String
        Get
            Return sFiltro.strTexto
        End Get
    End Property
    'filtro 2

    Public WriteOnly Property FiltroVisible2 As Boolean
        Set(value As Boolean)
            sFiltro2.logVisible = value
        End Set
    End Property

    Public WriteOnly Property TituloFiltro2 As String
        Set(value As String)
            sFiltro2.strTituloFiltro = value
        End Set
    End Property

    Public WriteOnly Property SqlFiltro2 As String
        Set(value As String)
            sFiltro2.strSql = value
        End Set
    End Property

    Public ReadOnly Property SelFiltro2 As String
        Get
            Return sFiltro2.intSeleccion
        End Get
    End Property

    Public ReadOnly Property SelFiltroText2 As String
        Get
            Return sFiltro2.strTexto
        End Get
    End Property

    Public WriteOnly Property TipoFiltro2 As Integer
        Set(value As Integer)
            sFiltro2.tipoFiltro = value
        End Set
    End Property

    'filtro 3

    Public WriteOnly Property FiltroVisible3 As Boolean
        Set(value As Boolean)
            sFiltro3.logVisible = value
        End Set
    End Property

    Public WriteOnly Property TituloFiltro3 As String
        Set(value As String)
            sFiltro3.strTituloFiltro = value
        End Set
    End Property

    Public WriteOnly Property SqlFiltro3 As String
        Set(value As String)
            sFiltro3.strSql = value
        End Set
    End Property

    Public ReadOnly Property SelFiltro3 As String
        Get
            Return sFiltro3.intSeleccion
        End Get
    End Property

    Public ReadOnly Property SelFiltroText3 As String
        Get
            Return sFiltro3.strTexto
        End Get
    End Property

    Public WriteOnly Property TipoFiltro3 As Integer
        Set(value As Integer)
            sFiltro3.tipoFiltro = value
        End Set
    End Property

    'Banderas

    Public WriteOnly Property BanderaFechas As Boolean
        Set(value As Boolean)
            sBanderas.logFecha = value
        End Set
    End Property

    Public WriteOnly Property BanderaOpcion As Boolean
        Set(value As Boolean)
            sBanderas.logOpcion = value
        End Set
    End Property

    Public WriteOnly Property BanderaFiltro As Boolean
        Set(value As Boolean)
            sBanderas.logFiltro = value
        End Set
    End Property

    Public WriteOnly Property BanderaCorte As Boolean
        Set(value As Boolean)
            sBanderas.logCorte = value
        End Set
    End Property

#End Region

#Region "Procedimientos"

    Public Sub reset()
        sFechas.strTituloFechas = "Select a date range"
        sOpcion.intSeleccion = NO_FILA
        sOpcion.strOpciones = STR_VACIO
        sOpcion.strTituloOpciones = "Select an option"
        sBanderas.logFecha = False
        ' sBanderas.logFiltro = False
        ' sBanderas.logOpcion = False

        sFiltro.strSql = STR_VACIO
        sFiltro.intSeleccion = NO_FILA
        sFiltro.strTituloFiltro = "Filter out"
        sFiltro.tipoFiltro = NO_FILA

        sFiltro2.logVisible = False
        sFiltro2.strSql = STR_VACIO
        sFiltro2.intSeleccion = NO_FILA
        sFiltro2.strTituloFiltro = "Filter out 2"
        sFiltro2.tipoFiltro = NO_FILA

        sFiltro3.logVisible = False
        sFiltro3.strSql = STR_VACIO
        sFiltro3.intSeleccion = NO_FILA
        sFiltro3.strTituloFiltro = "Filter out 3"
        sFiltro3.tipoFiltro = NO_FILA
    End Sub

    Private Sub CargarGrupos()
        Dim intCont As Integer = INT_CERO

        celdaTitulo.Text = strTitulo

        If sBanderas.logCorte = True Then
            If sBanderas.logOpcion = True Then
                grupoCorte.Visible = True
                grupoCorte.Dock = DockStyle.Left
                intCont = NO_FILA
                grupoOpcion.Visible = True
                grupoOpcion.Dock = DockStyle.Fill
            Else
                grupoCorte.Visible = True
                grupoCorte.Dock = DockStyle.Fill
                intCont = NO_FILA
            End If
        Else
            If sBanderas.logFecha = True Then
                grupoFechas.Visible = True
                grupoFechas.Dock = DockStyle.Left
                If sBanderas.logOpcion = True Then
                    grupoOpcion.Visible = True
                    grupoOpcion.Dock = DockStyle.Fill
                    If sBanderas.logFiltro = True Then
                        grupoFiltro.Visible = True
                        If sFiltro2.logVisible = True Then
                            celdaTitulo2.Visible = True
                            celdaTitulo2.Text = sFiltro2.strTituloFiltro
                            celdaFiltro2.Visible = True
                            botonFiltro2.Visible = True
                        Else
                            celdaTitulo2.Visible = False
                            celdaFiltro2.Visible = False
                            botonFiltro2.Visible = False
                        End If
                        If sFiltro3.logVisible = True Then
                            celdaTitulo3.Visible = True
                            celdaTitulo3.Text = sFiltro3.strTituloFiltro
                            celdaFiltro3.Visible = True
                            botonFiltro3.Visible = True
                        Else
                            celdaTitulo3.Visible = False
                            celdaFiltro3.Visible = False
                            botonFiltro3.Visible = False
                        End If
                        grupoFiltro.Dock = DockStyle.Right
                    End If
                ElseIf sBanderas.logFiltro = True Then
                    grupoFiltro.Visible = True
                    grupoFiltro.Dock = DockStyle.Fill
                End If
            ElseIf sBanderas.logOpcion = True Then
                grupoOpcion.Visible = True
                grupoOpcion.Dock = DockStyle.Left
                If sBanderas.logFiltro = True Then
                    grupoFiltro.Visible = True
                    grupoFiltro.Dock = DockStyle.Fill
                End If
            ElseIf sBanderas.logFiltro = True Then
                grupoFiltro.Visible = True
                grupoFiltro.Dock = DockStyle.Left
            Else
                grupoFiltro.Visible = False
                grupoOpcion.Visible = False
                grupoFechas.Visible = False
                grupoFechas.Dock = DockStyle.None
            End If

        End If

        If sBanderas.logFiltro = True Then
            If sBanderas.logFiltro = True Then
                grupoFiltro.Visible = True
                If sFiltro2.logVisible = True Then
                    celdaTitulo2.Visible = True
                    celdaTitulo2.Text = sFiltro2.strTituloFiltro
                    celdaFiltro2.Visible = True
                    botonFiltro2.Visible = True
                Else
                    celdaTitulo2.Visible = False
                    celdaFiltro2.Visible = False
                    botonFiltro2.Visible = False
                End If
                If sFiltro3.logVisible = True Then
                    celdaTitulo3.Visible = True
                    celdaTitulo3.Text = sFiltro3.strTituloFiltro
                    celdaFiltro3.Visible = True
                    botonFiltro3.Visible = True
                Else
                    celdaTitulo3.Visible = False
                    celdaFiltro3.Visible = False
                    botonFiltro3.Visible = False
                End If
                grupoFiltro.Dock = DockStyle.Right
            End If
            ' CargarFiltro(0)
            intCont = intCont + INT_UNO
        End If
        If sBanderas.logOpcion = True Then
            CargarOpciones()
            intCont = intCont + INT_UNO
        End If
        If sBanderas.logFecha = True Then
            intCont = intCont + INT_UNO
        End If
        If intCont = INT_UNO Then
            Me.Size = New System.Drawing.Point(281, 303)
        ElseIf intCont = 2 Then
            Me.Size = New System.Drawing.Point(510, 303)
        ElseIf intCont = 3 Then
            Me.Size = New System.Drawing.Point(707, 303)
        ElseIf intCont = NO_FILA Then
            Me.Size = New System.Drawing.Point(281, 200)
        End If
    End Sub

    Private Sub CargarOpciones()

        Dim arrayOpciones() As String
        Dim intTop As Integer = 10
        Try
            Me.Text = strTitulo
            If sOpcion.strOpciones.Length > 0 Then
                arrayOpciones = sOpcion.strOpciones.Split("|".ToCharArray)
                For i As Integer = INT_CERO To arrayOpciones.Length - 1
                    Dim RB As New RadioButton
                    RB.Top = intTop + 26 * i
                    RB.Left = 50
                    RB.Name = i
                    RB.Width = arrayOpciones(i).Length + 100
                    RB.Text = arrayOpciones(i)

                    RB.Parent = Me.Panel2
                    If i = INT_CERO Then
                        RB.Checked = True
                    End If
                Next
                'Else
                'MsgBox("frmOpcion: No se indico ninguna opcion que cargar")
                'Exit Sub
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try

    End Sub

    Private Function CargarFiltro(ByVal Opcion As Integer) As frmSeleccionar
        Dim frm As New frmSeleccionar
        Dim strTabla As String = STR_VACIO
        Try
            Select Case Opcion
                Case 1 'Filtrar por cliente'
                    strTabla = " (
                                    SELECT cli_codigo Code, cli_cliente Customer, IF(cli_tipo  = 0, 'Invoice',IF(cli_tipo=1,'Destination','AR')) type
                                    FROM Clientes
                                        WHERE cli_sisemp = " & Sesion.IdEmpresa & ") c"
                    frm.Campos = "c.Code,c.Customer,c.type "
                    frm.Tabla = strTabla
                    frm.Condicion = "c.Code>0"
                    frm.Limite = 20
                    frm.Titulo = "Select a customer"
                    frm.Filtro = "c.Customer"

                'Case 2 ' filtrar por centro de costos
                '    frm.Campos = "cost_num code ,cost_nombre Cost"
                '    frm.Tabla = cFunciones.ContaEmpresa & ".costos"
                '    frm.Condicion = "cost_num>0"
                '    frm.Titulo = "Select a cost center"
                '    frm.Filtro = "cost_nombre"
                Case 2 ' Filtrar Costos
                    frm.Campos = " cost_num code,cost_nombre Cost, pms_usuario,pms_id"
                    frm.Tabla = " " & cFunciones.ContaEmpresa & ".costos INNER JOIN Permisos p ON p.pms_id = cost_num AND p.pms_modulo = 505 AND p.pms_usuario = '" & Sesion.Usuario & "'"
                    frm.Condicion = " cost_num>-1"
                    frm.Titulo = " Select By Department"
                    frm.Filtro = "cost_nombre"


                Case 3 ' filtrar por proveedor
                    frm.Campos = "pro_codigo Code ,pro_proveedor Mill"
                    frm.Tabla = " Proveedores "
                    frm.Condicion = "pro_sisemp = " & Sesion.IdEmpresa & " and pro_fabricante= 'Si'"
                    frm.Titulo = "Select a mill"
                    frm.Filtro = "pro_proveedor"
                    frm.Limite = 20
                Case 4 ' filtrar por programa
                    frm.Campos = "cat_num Code,cat_clave Program"
                    frm.Tabla = "Catalogos"
                    frm.Condicion = "cat_clase = 'Programa'"
                    frm.Titulo = "Select a program"
                    frm.Filtro = "cat_clave"
                Case 5 'fitrar por pais
                    frm.Campos = " cat_num Code ,cat_desc Source "
                    frm.Tabla = " Catalogos "
                    frm.Condicion = " cat_clase = 'Paises' "
                    frm.Titulo = "Select Source"
                    frm.Filtro = " cat_desc "

                Case 6 ' filtrar por articulo
                    frm.Campos = "art_Codigo Code ,art_DCorta Yarn"
                    frm.Tabla = " Articulos "
                    frm.Condicion = "art_sisemp = " & Sesion.IdEmpresa
                    frm.Titulo = "Select a Yarn"
                    frm.Filtro = "art_DCorta"
                    frm.Limite = 30
                Case 7 ' filtrar por codigo generico
                    frm.Campos = "art_Codigo Code ,art_DCorta Yarn"
                    frm.Tabla = " Articulos "
                    frm.Condicion = "art_sisemp = " & Sesion.IdEmpresa
                    frm.Titulo = "Select a Yarn"
                    frm.Filtro = "art_DCorta"
                    frm.Limite = 30
                Case 8

                    frm.Campos = " cb.BCta_Num Id,cb.BCta_Nom_Cue Bank_Account, cb.BCta_Num_Cue Account_Number "
                    frm.Tabla = "  Permisos p  LEFT JOIN CtasBcos cb ON cb.BCta_Sis_Emp = p.pms_empresa AND cb.BCta_Num = p.pms_id "
                    frm.Condicion = " p.pms_empresa = " & Sesion.IdEmpresa & " AND p.pms_usuario = '" & Sesion.Usuario & "' AND p.pms_modulo = 94  AND p.pms_codigo = 'ALL' "
                    frm.Titulo = " Select a account"
                    frm.Filtro = "cb.BCta_Nom_Cue"
                    frm.Limite = 30

                Case 9 'Filtrar por Empleado 
                    Dim strRemplazo As String = STR_VACIO
                    strRemplazo = "per_sisemp = {empresa} AND per_estado = 1"
                    strRemplazo = Replace(strRemplazo, "{empresa}", Sesion.IdEmpresa)
                    frm.Titulo = "Select a Responsible"
                    frm.Campos = " per_codigo Id, CONCAT(per_nombre1,' ',per_nombre2,' ',per_apellido1,' ',per_apellido2) Descripcion"
                    frm.Tabla = " Personal  "
                    frm.FiltroText = " Enter The Name Of The responsible To Filter "
                    frm.Filtro = "per_nombre1  "
                    frm.Ordenamiento = "per_nombre1, per_nombre2, per_apellido1"
                    frm.TipoOrdenamiento = ""
                    frm.Condicion = strRemplazo
                    frm.Limite = 30
                Case 10
                    frm.Campos = " i.id_Inventario ID , i.Codigo_Equipo Code, CONCAT( i.Marca ,' - ' , i.Serie  ) Descripcion  "
                    frm.Tabla = "  InventarioIT i "
                    frm.Condicion = " i.id_Empresa = " & Sesion.IdEmpresa
                    frm.Titulo = " Select a Computer "
                    frm.Filtro = "i.Codigo_Equipo"
                    frm.Limite = 30
                Case 11     ' filtro para producto en consumibles, material de empaque, repuestos, inventario en custodia
                    frm.Campos = " i.inv_numero ID, a.art_DCorta Code, a.art_DCorta Descripcion "
                    frm.Tabla = " Articulos a JOIN Inventarios i ON a.art_sisemp=i.inv_sisemp AND a.art_codigo=i.inv_artcodigo JOIN Catalogos c ON a.art_clase=c.cat_num "
                    frm.Condicion = " a.art_sisemp = " & Sesion.IdEmpresa & " AND (c.cat_pid=5 OR (c.cat_pid=0 AND c.cat_ext='Inventario en Custodia') OR (c.cat_pid=0 AND c.cat_ext='Combustible') OR (c.cat_pid=2 AND c.cat_ext='Product in process')) "
                    frm.Titulo = " Select a Product "
                    frm.Filtro = "a.art_DCorta"
                    frm.Filtro2 = "i.inv_numero"
                    frm.Limite = 30
                Case 12   'Listado de PACAS
                    frm.Campos = "h.HDoc_Doc_Ano Anio, h.HDoc_Doc_Num Numero, h.HDoc_Doc_Cat Catalogo,   h.HDoc_Doc_Fec fecha, h.HDoc_DR1_Num Referencia, IFNULL(h980.HDoc_DR1_Num,'') PO, h.HDoc_Doc_Status estatus"
                    frm.Tabla = "Dcmtos_HDR h
                                    LEFT JOIN Dcmtos_DTL_Pro dp ON dp.PDoc_Sis_Emp = h.HDoc_Sis_Emp AND dp.PDoc_Par_Cat = h.HDoc_Doc_Cat AND dp.PDoc_Par_Ano = h.HDoc_Doc_Ano AND dp.PDoc_Par_Num = h.HDoc_Doc_Num AND dp.PDoc_Chi_Cat = 980 
                                    LEFT JOIN Dcmtos_HDR h980 ON h980.HDoc_Sis_Emp = dp.PDoc_Sis_Emp AND h980.HDoc_Doc_Cat = dp.PDoc_Chi_Cat AND h980.HDoc_Doc_Ano = dp.PDoc_Chi_Ano AND h980.HDoc_Doc_Num = dp.PDoc_Chi_Num"
                    frm.Condicion = "h.HDoc_Sis_Emp= " & Sesion.IdEmpresa & " AND h.HDoc_Doc_Cat = 952"
                    frm.Agrupar = " h.HDoc_Sis_Emp , h.HDoc_Doc_Cat, h.HDoc_Doc_Ano , h.HDoc_Doc_Num"
                    frm.Filtro = " h.HDoc_Doc_Num"
                    frm.Filtro2 = " h.HDoc_DR1_Num"
                    frm.Ordenamiento = "h.HDoc_Doc_Fec "
                    frm.TipoOrdenamiento = "DESC"
                    frm.Limite = 25
                    frm.Multiple = False
                Case 13
                    strTabla = " ( SELECT HDoc_Doc_Num id, HDoc_DR1_Num Lote, HDoc_Doc_Fec fecha, a.art_DCorta producto FROM Dcmtos_HDR h
                                   LEFT JOIN Inventarios i ON i.inv_sisemp = h.HDoc_Sis_Emp AND i.inv_numero = h.HDoc_Emp_Cod
                                   LEFT JOIN Articulos a ON a.art_sisemp = i.inv_sisemp AND a.art_codigo = i.inv_artcodigo 
                                   WHERE h.HDoc_Sis_Emp = " & Sesion.IdEmpresa & " AND h.HDoc_Doc_Cat = 776) l"
                    frm.Campos = "l.id, l.Lote, l.fecha, l.producto"
                    frm.Tabla = strTabla
                    frm.Condicion = "l.Lote IS NOT NULL"
                    frm.Limite = 25
                    frm.Titulo = "Select a Lote"
                    frm.Filtro = "l.Lote"
                Case 14     ' filtro para Producto Fibra
                    frm.Campos = " a.art_codigo  ID, a.art_DCorta Code, a.art_DCorta Descripcion "
                    frm.Tabla = " Articulos a INNER JOIN Catalogos c ON a.art_clase=c.cat_num "
                    frm.Condicion = " a.art_sisemp = " & Sesion.IdEmpresa & " AND cat_clase = 'ClaseArt' AND cat_sist = 'Art_Fibra' AND cat_ext = 'Fibra'  "
                    frm.Titulo = " Select a Product "
                    frm.Filtro = "a.art_DCorta"
                    frm.Filtro2 = "a.art_codigo"
                    frm.Limite = 25
                Case 15
                    strTabla = "Inventarios i 
                    LEFT JOIN Articulos a ON a.art_sisemp = i.inv_sisemp AND a.art_codigo = i.inv_artcodigo  
                    LEFT JOIN Catalogos c ON c.cat_num = a.art_clase
                    LEFT JOIN Catalogos ca ON ca.cat_num = inV_UMVenta"
                    frm.Campos = "i.inv_numero ID, a.art_desc Descripcion"
                    frm.Filtro = "a.art_desc"
                    frm.Tabla = strTabla
                    frm.Condicion = "i.inv_sisemp = " & Sesion.IdEmpresa & " AND i.inv_generico = 1 AND i.inv_status = 'Activo' 
                    AND  (c.cat_ext = 'Consumibles' OR c.cat_ext = 'Material de empaque' OR  c.cat_ext = 'Repuestos' 
                    OR c.cat_ext= 'Inventario en Custodia' OR c.cat_ext= 'Combustible' OR c.cat_ext= 'Maquinaria' OR c.cat_ext = 'Otros'
                    OR c.cat_ext='Product in process')"
                Case 16
                    frm.Campos = "pro_codigo Code ,pro_proveedor Nombre"
                    frm.Tabla = " Proveedores "
                    frm.Condicion = "pro_sisemp = " & Sesion.IdEmpresa
                    frm.Titulo = "Proveedor"
                    frm.Filtro = "pro_proveedor"
                    frm.Limite = 30
                Case 17
                    strTabla = "Inventarios i 
                    LEFT JOIN Articulos a ON a.art_sisemp = i.inv_sisemp AND a.art_codigo = i.inv_artcodigo  
                    LEFT JOIN Catalogos c ON c.cat_num = a.art_clase"
                    frm.Campos = "i.inv_numero ID, a.art_desc Descripcion"
                    frm.Filtro = "a.art_desc"
                    frm.Tabla = strTabla
                    frm.Condicion = "i.inv_sisemp = " & Sesion.IdEmpresa & " AND i.inv_status = 'Activo'"
            End Select
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try

        Return frm
    End Function

#End Region

    Private Sub frmFiltro_Load(sender As Object, e As EventArgs) Handles Me.Load
        Try
            dtpFechaInicio.Value = Today.AddMonths(NO_FILA)
            dtpFechaFin.Value = Today
            CargarGrupos()
            'CargarOpciones()

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try

    End Sub

    Private Sub botonCancelar_Click(sender As Object, e As EventArgs) Handles botonCancelar.Click
        Me.DialogResult = System.Windows.Forms.DialogResult.Cancel
    End Sub

    Private Sub botonAceptar_Click(sender As Object, e As EventArgs) Handles botonAceptar.Click
        Try
            sFechas.fechaInicio = dtpFechaInicio.Value
            sFechas.fechaFin = dtpFechaFin.Value
            sFiltro.intSeleccion = CInt(celdaSelctFiltro.Text)
            sFechas.fechaCorte = dtpFechaCorte.Value
            sFiltro.intSeleccion = CInt(celdaSelctFiltro.Text)
            sFiltro.strTexto = celdaFiltro.Text.Trim
            sFiltro2.intSeleccion = CInt(celdaSelctFiltro2.Text)
            sFiltro3.intSeleccion = CInt(celdaSelctFiltro3.Text)
            If grupoOpcion.Visible = True Then
                For Each r As RadioButton In Me.Panel2.Controls
                    If r.Checked = True Then
                        sOpcion.intSeleccion = r.Name
                        Me.DialogResult = System.Windows.Forms.DialogResult.OK
                    End If
                Next
            Else
                Me.DialogResult = System.Windows.Forms.DialogResult.OK
            End If

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub botonFiltro_Click(sender As Object, e As EventArgs) Handles botonFiltro.Click
        Dim frm As New frmSeleccionar
        frm = CargarFiltro(intFilto)
        Try
            frm.ShowDialog(frmSPrincipal)
            If frm.DialogResult = System.Windows.Forms.DialogResult.OK Then
                celdaSelctFiltro.Text = frm.LLave
                celdaFiltro.Text = frm.Dato

            End If

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub botonFiltro2_Click(sender As Object, e As EventArgs) Handles botonFiltro2.Click
        Dim frm As New frmSeleccionar
        frm = CargarFiltro(sFiltro2.tipoFiltro)
        Try
            frm.ShowDialog(frmSPrincipal)
            If frm.DialogResult = System.Windows.Forms.DialogResult.OK Then
                celdaSelctFiltro2.Text = frm.LLave
                celdaFiltro2.Text = frm.Dato

            End If

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub botonFiltro3_Click(sender As Object, e As EventArgs) Handles botonFiltro3.Click
        Dim frm As New frmSeleccionar
        frm = CargarFiltro(sFiltro3.tipoFiltro)
        Try
            frm.ShowDialog(frmSPrincipal)
            If frm.DialogResult = System.Windows.Forms.DialogResult.OK Then
                celdaSelctFiltro3.Text = frm.LLave
                celdaFiltro3.Text = frm.Dato
            End If

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub grupoFechas_Enter(sender As Object, e As EventArgs) Handles grupoFechas.Enter

    End Sub
End Class