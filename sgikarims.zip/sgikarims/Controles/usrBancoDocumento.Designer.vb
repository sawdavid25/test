﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class usrBancoDocumento
    Inherits System.Windows.Forms.UserControl

    'UserControl reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(usrBancoDocumento))
        Dim DataGridViewCellStyle1 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle2 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle3 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle4 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle5 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle6 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle7 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle9 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle10 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle11 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle12 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle13 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle8 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Me.GrupoDocumento = New System.Windows.Forms.GroupBox()
        Me.CasillaRevisado = New System.Windows.Forms.CheckBox()
        Me.BotonPoliza = New System.Windows.Forms.Button()
        Me.Imagenes = New System.Windows.Forms.ImageList(Me.components)
        Me.BotonPresupuesto = New System.Windows.Forms.Button()
        Me.BotonBuscar = New System.Windows.Forms.Button()
        Me.CeldaNotas = New System.Windows.Forms.TextBox()
        Me.EtiquetaNotas = New System.Windows.Forms.Label()
        Me.CeldaGastos = New System.Windows.Forms.TextBox()
        Me.EtiquetaGastos = New System.Windows.Forms.Label()
        Me.CeldaReferencia = New System.Windows.Forms.TextBox()
        Me.EtiquetaReferencia = New System.Windows.Forms.Label()
        Me.CeldaTasa = New System.Windows.Forms.TextBox()
        Me.EtiquetaTasa = New System.Windows.Forms.Label()
        Me.CeldaMonto = New System.Windows.Forms.TextBox()
        Me.EtiquetaMonto = New System.Windows.Forms.Label()
        Me.CasillaAnulado = New System.Windows.Forms.CheckBox()
        Me.CeldaConcepto = New System.Windows.Forms.TextBox()
        Me.EtiquetaConcepto = New System.Windows.Forms.Label()
        Me.CasillaCobrado = New System.Windows.Forms.CheckBox()
        Me.CeldaNumero = New System.Windows.Forms.TextBox()
        Me.EtiquetaNumero = New System.Windows.Forms.Label()
        Me.CasillaSecreto = New System.Windows.Forms.CheckBox()
        Me.Fecha = New System.Windows.Forms.DateTimePicker()
        Me.EtiquetaFecha = New System.Windows.Forms.Label()
        Me.BotonDocumento = New System.Windows.Forms.Button()
        Me.CeldaDocumento = New System.Windows.Forms.TextBox()
        Me.EtiquetaDocumento = New System.Windows.Forms.Label()
        Me.GrupoEmpresa = New System.Windows.Forms.GroupBox()
        Me.CeldaID = New System.Windows.Forms.TextBox()
        Me.Referencia = New System.Windows.Forms.Label()
        Me.CeldaPersona = New System.Windows.Forms.TextBox()
        Me.EtiquetaEmisor = New System.Windows.Forms.Label()
        Me.CasillaProveedores = New System.Windows.Forms.CheckBox()
        Me.BotonEmpresa = New System.Windows.Forms.Button()
        Me.CeldaEmpresa = New System.Windows.Forms.TextBox()
        Me.GrupoDeposito = New System.Windows.Forms.GroupBox()
        Me.CeldaTotalDeposito = New System.Windows.Forms.TextBox()
        Me.EtiquetaTotalDeposito = New System.Windows.Forms.Label()
        Me.CeldaOtrosBancos = New System.Windows.Forms.TextBox()
        Me.EtiquetaOtros = New System.Windows.Forms.Label()
        Me.CeldaCheques = New System.Windows.Forms.TextBox()
        Me.EtiquetaCheques = New System.Windows.Forms.Label()
        Me.CeldaEfectivo = New System.Windows.Forms.TextBox()
        Me.EtiquetaEfectivo = New System.Windows.Forms.Label()
        Me.PanelCheques = New System.Windows.Forms.Panel()
        Me.Cheques = New System.Windows.Forms.DataGridView()
        Me.cheque_fecha = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.cheque_emisor = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.cheque_numero = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.cheque_monto = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.cheque_estado = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.PanelChequesTitulo = New System.Windows.Forms.Panel()
        Me.BotonChequeMenos = New System.Windows.Forms.Button()
        Me.BotonChequeMas = New System.Windows.Forms.Button()
        Me.EtiquetaChequesTitulo = New System.Windows.Forms.Label()
        Me.PanelTransaccion = New System.Windows.Forms.Panel()
        Me.EtiquetaTransaccion = New System.Windows.Forms.Label()
        Me.BotonTransaccion = New System.Windows.Forms.Button()
        Me.EtiquetaTituloTransaccion = New System.Windows.Forms.Label()
        Me.PanelLetras = New System.Windows.Forms.Panel()
        Me.EtiquetaID = New System.Windows.Forms.Label()
        Me.EtiquetaLetras = New System.Windows.Forms.Label()
        Me.PanelVentas = New System.Windows.Forms.Panel()
        Me.CeldaTotalVenta = New System.Windows.Forms.TextBox()
        Me.EtiquetaVentaTotal = New System.Windows.Forms.Label()
        Me.Ventas = New System.Windows.Forms.DataGridView()
        Me.venta_tipo = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.venta_ciclo = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.venta_grupo = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.venta_numero = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.venta_serie = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.venta_fecha = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.venta_moneda = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.venta_tasa = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.venta_ref = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.venta_monto = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.venta_total = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.venta_id = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.ventas_numero2 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.PanelVentasTitulo = New System.Windows.Forms.Panel()
        Me.BotonVentaGasto = New System.Windows.Forms.Button()
        Me.BotonVentaCuenta = New System.Windows.Forms.Button()
        Me.BotonVentaMenos = New System.Windows.Forms.Button()
        Me.BotonVentaMas = New System.Windows.Forms.Button()
        Me.EtiquetaVentasTitulo = New System.Windows.Forms.Label()
        Me.InfoTexto = New System.Windows.Forms.ToolTip(Me.components)
        Me.Grupo1 = New System.Windows.Forms.GroupBox()
        Me.Grupo2 = New System.Windows.Forms.GroupBox()
        Me.Grupo3 = New System.Windows.Forms.GroupBox()
        Me.GrupoCuenta = New System.Windows.Forms.GroupBox()
        Me.EtiquetaCuentaNombre = New System.Windows.Forms.Label()
        Me.CeldaCuentaNombre = New System.Windows.Forms.TextBox()
        Me.CasillaExterna = New System.Windows.Forms.CheckBox()
        Me.EtiquetaCuenta = New System.Windows.Forms.Label()
        Me.BotonCC = New System.Windows.Forms.Button()
        Me.CeldaCuenta = New System.Windows.Forms.TextBox()
        Me.PanelCompras = New System.Windows.Forms.Panel()
        Me.CeldaAnticipo = New System.Windows.Forms.TextBox()
        Me.EtiquetaAnticipo = New System.Windows.Forms.Label()
        Me.CeldaTotalCompra = New System.Windows.Forms.TextBox()
        Me.EtiquetaCompraTotal = New System.Windows.Forms.Label()
        Me.Compras = New System.Windows.Forms.DataGridView()
        Me.PanelComprasTitulo = New System.Windows.Forms.Panel()
        Me.BotonCompraGasto = New System.Windows.Forms.Button()
        Me.BotonCompraCuenta = New System.Windows.Forms.Button()
        Me.BotonCompraMenos = New System.Windows.Forms.Button()
        Me.BotonCompraMas = New System.Windows.Forms.Button()
        Me.EtiquetaComprasTitulo = New System.Windows.Forms.Label()
        Me.PanelCaja = New System.Windows.Forms.Panel()
        Me.EtiquetaCajaFecha = New System.Windows.Forms.Label()
        Me.EtiquetaCajaDiferencia = New System.Windows.Forms.Label()
        Me.CeldaDiferencia = New System.Windows.Forms.TextBox()
        Me.CeldaTotalCaja = New System.Windows.Forms.TextBox()
        Me.EtiquetaCajaTotal = New System.Windows.Forms.Label()
        Me.Caja = New System.Windows.Forms.DataGridView()
        Me.caja_documento = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.caja_numero = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.caja_fecha = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.caja_nombre = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.caja_moneda = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.caja_total = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.caja_parcial = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.caja_concepto = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.PanelCajaTitulo = New System.Windows.Forms.Panel()
        Me.BotonCajaMenos = New System.Windows.Forms.Button()
        Me.BotonCajaMas = New System.Windows.Forms.Button()
        Me.EtiquetaCajaTitulo = New System.Windows.Forms.Label()
        Me.compra_tipo = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.compra_ciclo = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.compra_numero = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.compra_moneda = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.compra_tasa = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.compra_cambio = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.compra_marca = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.compra_descripcion = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.col_DocumentoTipo = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.compra_monto = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.compra_cuenta = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.compra_ref_ciclo = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.compra_ref_numero = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.compra_factura = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.GrupoDocumento.SuspendLayout()
        Me.GrupoEmpresa.SuspendLayout()
        Me.GrupoDeposito.SuspendLayout()
        Me.PanelCheques.SuspendLayout()
        CType(Me.Cheques, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.PanelChequesTitulo.SuspendLayout()
        Me.PanelTransaccion.SuspendLayout()
        Me.PanelLetras.SuspendLayout()
        Me.PanelVentas.SuspendLayout()
        CType(Me.Ventas, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.PanelVentasTitulo.SuspendLayout()
        Me.GrupoCuenta.SuspendLayout()
        Me.PanelCompras.SuspendLayout()
        CType(Me.Compras, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.PanelComprasTitulo.SuspendLayout()
        Me.PanelCaja.SuspendLayout()
        CType(Me.Caja, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.PanelCajaTitulo.SuspendLayout()
        Me.SuspendLayout()
        '
        'GrupoDocumento
        '
        Me.GrupoDocumento.Controls.Add(Me.CasillaRevisado)
        Me.GrupoDocumento.Controls.Add(Me.BotonPoliza)
        Me.GrupoDocumento.Controls.Add(Me.BotonPresupuesto)
        Me.GrupoDocumento.Controls.Add(Me.BotonBuscar)
        Me.GrupoDocumento.Controls.Add(Me.CeldaNotas)
        Me.GrupoDocumento.Controls.Add(Me.EtiquetaNotas)
        Me.GrupoDocumento.Controls.Add(Me.CeldaGastos)
        Me.GrupoDocumento.Controls.Add(Me.EtiquetaGastos)
        Me.GrupoDocumento.Controls.Add(Me.CeldaReferencia)
        Me.GrupoDocumento.Controls.Add(Me.EtiquetaReferencia)
        Me.GrupoDocumento.Controls.Add(Me.CeldaTasa)
        Me.GrupoDocumento.Controls.Add(Me.EtiquetaTasa)
        Me.GrupoDocumento.Controls.Add(Me.CeldaMonto)
        Me.GrupoDocumento.Controls.Add(Me.EtiquetaMonto)
        Me.GrupoDocumento.Controls.Add(Me.CasillaAnulado)
        Me.GrupoDocumento.Controls.Add(Me.CeldaConcepto)
        Me.GrupoDocumento.Controls.Add(Me.EtiquetaConcepto)
        Me.GrupoDocumento.Controls.Add(Me.CasillaCobrado)
        Me.GrupoDocumento.Controls.Add(Me.CeldaNumero)
        Me.GrupoDocumento.Controls.Add(Me.EtiquetaNumero)
        Me.GrupoDocumento.Controls.Add(Me.CasillaSecreto)
        Me.GrupoDocumento.Controls.Add(Me.Fecha)
        Me.GrupoDocumento.Controls.Add(Me.EtiquetaFecha)
        Me.GrupoDocumento.Controls.Add(Me.BotonDocumento)
        Me.GrupoDocumento.Controls.Add(Me.CeldaDocumento)
        Me.GrupoDocumento.Controls.Add(Me.EtiquetaDocumento)
        Me.GrupoDocumento.Location = New System.Drawing.Point(4, 0)
        Me.GrupoDocumento.Margin = New System.Windows.Forms.Padding(4)
        Me.GrupoDocumento.Name = "GrupoDocumento"
        Me.GrupoDocumento.Padding = New System.Windows.Forms.Padding(4)
        Me.GrupoDocumento.Size = New System.Drawing.Size(529, 315)
        Me.GrupoDocumento.TabIndex = 0
        Me.GrupoDocumento.TabStop = False
        Me.GrupoDocumento.Text = "Document Information"
        '
        'CasillaRevisado
        '
        Me.CasillaRevisado.AutoSize = True
        Me.CasillaRevisado.Location = New System.Drawing.Point(323, 274)
        Me.CasillaRevisado.Margin = New System.Windows.Forms.Padding(4)
        Me.CasillaRevisado.Name = "CasillaRevisado"
        Me.CasillaRevisado.Size = New System.Drawing.Size(91, 21)
        Me.CasillaRevisado.TabIndex = 25
        Me.CasillaRevisado.Text = "Reviewed"
        Me.CasillaRevisado.UseVisualStyleBackColor = True
        '
        'BotonPoliza
        '
        Me.BotonPoliza.Enabled = False
        Me.BotonPoliza.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.BotonPoliza.ImageKey = "book_open.ico"
        Me.BotonPoliza.ImageList = Me.Imagenes
        Me.BotonPoliza.Location = New System.Drawing.Point(196, 271)
        Me.BotonPoliza.Margin = New System.Windows.Forms.Padding(4)
        Me.BotonPoliza.Name = "BotonPoliza"
        Me.BotonPoliza.Size = New System.Drawing.Size(88, 31)
        Me.BotonPoliza.TabIndex = 24
        Me.BotonPoliza.Text = "Journal"
        Me.BotonPoliza.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.BotonPoliza.UseVisualStyleBackColor = True
        '
        'Imagenes
        '
        Me.Imagenes.ImageStream = CType(resources.GetObject("Imagenes.ImageStream"), System.Windows.Forms.ImageListStreamer)
        Me.Imagenes.TransparentColor = System.Drawing.Color.Transparent
        Me.Imagenes.Images.SetKeyName(0, "view.ico")
        Me.Imagenes.Images.SetKeyName(1, "money2.ico")
        Me.Imagenes.Images.SetKeyName(2, "align full-4.ico")
        Me.Imagenes.Images.SetKeyName(3, "star_blue.ico")
        Me.Imagenes.Images.SetKeyName(4, "book_open.ico")
        Me.Imagenes.Images.SetKeyName(5, "printer.ico")
        Me.Imagenes.Images.SetKeyName(6, "paste.ico")
        '
        'BotonPresupuesto
        '
        Me.BotonPresupuesto.Enabled = False
        Me.BotonPresupuesto.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.BotonPresupuesto.ImageKey = "star_blue.ico"
        Me.BotonPresupuesto.ImageList = Me.Imagenes
        Me.BotonPresupuesto.Location = New System.Drawing.Point(96, 271)
        Me.BotonPresupuesto.Margin = New System.Windows.Forms.Padding(4)
        Me.BotonPresupuesto.Name = "BotonPresupuesto"
        Me.BotonPresupuesto.Size = New System.Drawing.Size(85, 31)
        Me.BotonPresupuesto.TabIndex = 23
        Me.BotonPresupuesto.Text = "Budget"
        Me.BotonPresupuesto.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.BotonPresupuesto.UseVisualStyleBackColor = True
        '
        'BotonBuscar
        '
        Me.BotonBuscar.Enabled = False
        Me.BotonBuscar.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.BotonBuscar.ImageKey = "paste.ico"
        Me.BotonBuscar.ImageList = Me.Imagenes
        Me.BotonBuscar.Location = New System.Drawing.Point(11, 271)
        Me.BotonBuscar.Margin = New System.Windows.Forms.Padding(4)
        Me.BotonBuscar.Name = "BotonBuscar"
        Me.BotonBuscar.Size = New System.Drawing.Size(72, 31)
        Me.BotonBuscar.TabIndex = 21
        Me.BotonBuscar.Text = "Note"
        Me.BotonBuscar.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.BotonBuscar.UseVisualStyleBackColor = True
        '
        'CeldaNotas
        '
        Me.CeldaNotas.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.CeldaNotas.Location = New System.Drawing.Point(96, 214)
        Me.CeldaNotas.Margin = New System.Windows.Forms.Padding(4)
        Me.CeldaNotas.MaxLength = 1024
        Me.CeldaNotas.Multiline = True
        Me.CeldaNotas.Name = "CeldaNotas"
        Me.CeldaNotas.Size = New System.Drawing.Size(415, 42)
        Me.CeldaNotas.TabIndex = 20
        '
        'EtiquetaNotas
        '
        Me.EtiquetaNotas.AutoSize = True
        Me.EtiquetaNotas.Location = New System.Drawing.Point(7, 217)
        Me.EtiquetaNotas.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.EtiquetaNotas.Name = "EtiquetaNotas"
        Me.EtiquetaNotas.Size = New System.Drawing.Size(45, 17)
        Me.EtiquetaNotas.TabIndex = 19
        Me.EtiquetaNotas.Text = "Notes"
        '
        'CeldaGastos
        '
        Me.CeldaGastos.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.CeldaGastos.Location = New System.Drawing.Point(392, 181)
        Me.CeldaGastos.Margin = New System.Windows.Forms.Padding(4)
        Me.CeldaGastos.MaxLength = 10
        Me.CeldaGastos.Name = "CeldaGastos"
        Me.CeldaGastos.Size = New System.Drawing.Size(119, 24)
        Me.CeldaGastos.TabIndex = 18
        Me.CeldaGastos.Text = "0.00"
        Me.CeldaGastos.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'EtiquetaGastos
        '
        Me.EtiquetaGastos.AutoSize = True
        Me.EtiquetaGastos.Location = New System.Drawing.Point(263, 186)
        Me.EtiquetaGastos.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.EtiquetaGastos.Name = "EtiquetaGastos"
        Me.EtiquetaGastos.Size = New System.Drawing.Size(69, 17)
        Me.EtiquetaGastos.TabIndex = 17
        Me.EtiquetaGastos.Text = "Expenses"
        '
        'CeldaReferencia
        '
        Me.CeldaReferencia.BackColor = System.Drawing.SystemColors.GradientInactiveCaption
        Me.CeldaReferencia.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper
        Me.CeldaReferencia.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.CeldaReferencia.Location = New System.Drawing.Point(96, 181)
        Me.CeldaReferencia.Margin = New System.Windows.Forms.Padding(4)
        Me.CeldaReferencia.Name = "CeldaReferencia"
        Me.CeldaReferencia.Size = New System.Drawing.Size(153, 24)
        Me.CeldaReferencia.TabIndex = 16
        Me.CeldaReferencia.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'EtiquetaReferencia
        '
        Me.EtiquetaReferencia.AutoSize = True
        Me.EtiquetaReferencia.Location = New System.Drawing.Point(7, 186)
        Me.EtiquetaReferencia.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.EtiquetaReferencia.Name = "EtiquetaReferencia"
        Me.EtiquetaReferencia.Size = New System.Drawing.Size(74, 17)
        Me.EtiquetaReferencia.TabIndex = 15
        Me.EtiquetaReferencia.Text = "Reference"
        '
        'CeldaTasa
        '
        Me.CeldaTasa.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.CeldaTasa.Location = New System.Drawing.Point(392, 148)
        Me.CeldaTasa.Margin = New System.Windows.Forms.Padding(4)
        Me.CeldaTasa.MaxLength = 10
        Me.CeldaTasa.Name = "CeldaTasa"
        Me.CeldaTasa.Size = New System.Drawing.Size(119, 24)
        Me.CeldaTasa.TabIndex = 14
        Me.CeldaTasa.Text = "0.00"
        Me.CeldaTasa.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'EtiquetaTasa
        '
        Me.EtiquetaTasa.AutoSize = True
        Me.EtiquetaTasa.Location = New System.Drawing.Point(263, 153)
        Me.EtiquetaTasa.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.EtiquetaTasa.Name = "EtiquetaTasa"
        Me.EtiquetaTasa.Size = New System.Drawing.Size(104, 17)
        Me.EtiquetaTasa.TabIndex = 13
        Me.EtiquetaTasa.Text = "Exchange Rate"
        '
        'CeldaMonto
        '
        Me.CeldaMonto.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.CeldaMonto.Location = New System.Drawing.Point(96, 148)
        Me.CeldaMonto.Margin = New System.Windows.Forms.Padding(4)
        Me.CeldaMonto.MaxLength = 12
        Me.CeldaMonto.Name = "CeldaMonto"
        Me.CeldaMonto.Size = New System.Drawing.Size(112, 24)
        Me.CeldaMonto.TabIndex = 12
        Me.CeldaMonto.Text = "0.00"
        Me.CeldaMonto.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'EtiquetaMonto
        '
        Me.EtiquetaMonto.AutoSize = True
        Me.EtiquetaMonto.Location = New System.Drawing.Point(7, 153)
        Me.EtiquetaMonto.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.EtiquetaMonto.Name = "EtiquetaMonto"
        Me.EtiquetaMonto.Size = New System.Drawing.Size(56, 17)
        Me.EtiquetaMonto.TabIndex = 11
        Me.EtiquetaMonto.Text = "Amount"
        '
        'CasillaAnulado
        '
        Me.CasillaAnulado.AutoSize = True
        Me.CasillaAnulado.Location = New System.Drawing.Point(428, 274)
        Me.CasillaAnulado.Margin = New System.Windows.Forms.Padding(4)
        Me.CasillaAnulado.Name = "CasillaAnulado"
        Me.CasillaAnulado.Size = New System.Drawing.Size(86, 21)
        Me.CasillaAnulado.TabIndex = 26
        Me.CasillaAnulado.Text = "Rejected"
        Me.CasillaAnulado.UseVisualStyleBackColor = True
        '
        'CeldaConcepto
        '
        Me.CeldaConcepto.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.CeldaConcepto.Location = New System.Drawing.Point(96, 98)
        Me.CeldaConcepto.Margin = New System.Windows.Forms.Padding(4)
        Me.CeldaConcepto.MaxLength = 1024
        Me.CeldaConcepto.Multiline = True
        Me.CeldaConcepto.Name = "CeldaConcepto"
        Me.CeldaConcepto.Size = New System.Drawing.Size(415, 41)
        Me.CeldaConcepto.TabIndex = 10
        '
        'EtiquetaConcepto
        '
        Me.EtiquetaConcepto.AutoSize = True
        Me.EtiquetaConcepto.Location = New System.Drawing.Point(7, 101)
        Me.EtiquetaConcepto.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.EtiquetaConcepto.Name = "EtiquetaConcepto"
        Me.EtiquetaConcepto.Size = New System.Drawing.Size(60, 17)
        Me.EtiquetaConcepto.TabIndex = 9
        Me.EtiquetaConcepto.Text = "Concept"
        '
        'CasillaCobrado
        '
        Me.CasillaCobrado.AutoSize = True
        Me.CasillaCobrado.Location = New System.Drawing.Point(304, 65)
        Me.CasillaCobrado.Margin = New System.Windows.Forms.Padding(4)
        Me.CasillaCobrado.Name = "CasillaCobrado"
        Me.CasillaCobrado.Size = New System.Drawing.Size(88, 21)
        Me.CasillaCobrado.TabIndex = 7
        Me.CasillaCobrado.Text = "Collected"
        Me.CasillaCobrado.UseVisualStyleBackColor = True
        '
        'CeldaNumero
        '
        Me.CeldaNumero.BackColor = System.Drawing.SystemColors.Window
        Me.CeldaNumero.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper
        Me.CeldaNumero.Font = New System.Drawing.Font("Consolas", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.CeldaNumero.ForeColor = System.Drawing.Color.Blue
        Me.CeldaNumero.Location = New System.Drawing.Point(96, 60)
        Me.CeldaNumero.Margin = New System.Windows.Forms.Padding(4)
        Me.CeldaNumero.MaxLength = 20
        Me.CeldaNumero.Name = "CeldaNumero"
        Me.CeldaNumero.Size = New System.Drawing.Size(153, 29)
        Me.CeldaNumero.TabIndex = 6
        Me.CeldaNumero.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'EtiquetaNumero
        '
        Me.EtiquetaNumero.AutoSize = True
        Me.EtiquetaNumero.Location = New System.Drawing.Point(7, 68)
        Me.EtiquetaNumero.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.EtiquetaNumero.Name = "EtiquetaNumero"
        Me.EtiquetaNumero.Size = New System.Drawing.Size(58, 17)
        Me.EtiquetaNumero.TabIndex = 5
        Me.EtiquetaNumero.Text = "Number"
        '
        'CasillaSecreto
        '
        Me.CasillaSecreto.AutoSize = True
        Me.CasillaSecreto.Location = New System.Drawing.Point(413, 65)
        Me.CasillaSecreto.Margin = New System.Windows.Forms.Padding(4)
        Me.CasillaSecreto.Name = "CasillaSecreto"
        Me.CasillaSecreto.Size = New System.Drawing.Size(104, 21)
        Me.CasillaSecreto.TabIndex = 8
        Me.CasillaSecreto.Text = "Confidential"
        Me.CasillaSecreto.UseVisualStyleBackColor = True
        '
        'Fecha
        '
        Me.Fecha.CustomFormat = "dd/MM/yyyy"
        Me.Fecha.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Fecha.Format = System.Windows.Forms.DateTimePickerFormat.Custom
        Me.Fecha.Location = New System.Drawing.Point(304, 27)
        Me.Fecha.Margin = New System.Windows.Forms.Padding(4)
        Me.Fecha.MaxDate = New Date(2099, 12, 31, 0, 0, 0, 0)
        Me.Fecha.MinDate = New Date(1901, 1, 1, 0, 0, 0, 0)
        Me.Fecha.Name = "Fecha"
        Me.Fecha.Size = New System.Drawing.Size(125, 24)
        Me.Fecha.TabIndex = 4
        Me.Fecha.Value = New Date(2018, 7, 31, 12, 9, 39, 0)
        '
        'EtiquetaFecha
        '
        Me.EtiquetaFecha.AutoSize = True
        Me.EtiquetaFecha.Location = New System.Drawing.Point(260, 32)
        Me.EtiquetaFecha.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.EtiquetaFecha.Name = "EtiquetaFecha"
        Me.EtiquetaFecha.Size = New System.Drawing.Size(38, 17)
        Me.EtiquetaFecha.TabIndex = 3
        Me.EtiquetaFecha.Text = "Date"
        '
        'BotonDocumento
        '
        Me.BotonDocumento.Location = New System.Drawing.Point(217, 27)
        Me.BotonDocumento.Margin = New System.Windows.Forms.Padding(4)
        Me.BotonDocumento.Name = "BotonDocumento"
        Me.BotonDocumento.Size = New System.Drawing.Size(33, 25)
        Me.BotonDocumento.TabIndex = 2
        Me.BotonDocumento.Text = "..."
        Me.BotonDocumento.UseVisualStyleBackColor = True
        '
        'CeldaDocumento
        '
        Me.CeldaDocumento.BackColor = System.Drawing.SystemColors.Info
        Me.CeldaDocumento.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.CeldaDocumento.Location = New System.Drawing.Point(96, 27)
        Me.CeldaDocumento.Margin = New System.Windows.Forms.Padding(4)
        Me.CeldaDocumento.Name = "CeldaDocumento"
        Me.CeldaDocumento.ReadOnly = True
        Me.CeldaDocumento.Size = New System.Drawing.Size(112, 24)
        Me.CeldaDocumento.TabIndex = 1
        '
        'EtiquetaDocumento
        '
        Me.EtiquetaDocumento.AutoSize = True
        Me.EtiquetaDocumento.Location = New System.Drawing.Point(7, 32)
        Me.EtiquetaDocumento.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.EtiquetaDocumento.Name = "EtiquetaDocumento"
        Me.EtiquetaDocumento.Size = New System.Drawing.Size(72, 17)
        Me.EtiquetaDocumento.TabIndex = 0
        Me.EtiquetaDocumento.Text = "Document"
        '
        'GrupoEmpresa
        '
        Me.GrupoEmpresa.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.GrupoEmpresa.Controls.Add(Me.CeldaID)
        Me.GrupoEmpresa.Controls.Add(Me.Referencia)
        Me.GrupoEmpresa.Controls.Add(Me.CeldaPersona)
        Me.GrupoEmpresa.Controls.Add(Me.EtiquetaEmisor)
        Me.GrupoEmpresa.Controls.Add(Me.CasillaProveedores)
        Me.GrupoEmpresa.Controls.Add(Me.BotonEmpresa)
        Me.GrupoEmpresa.Controls.Add(Me.CeldaEmpresa)
        Me.GrupoEmpresa.Location = New System.Drawing.Point(541, 39)
        Me.GrupoEmpresa.Margin = New System.Windows.Forms.Padding(4)
        Me.GrupoEmpresa.Name = "GrupoEmpresa"
        Me.GrupoEmpresa.Padding = New System.Windows.Forms.Padding(4)
        Me.GrupoEmpresa.Size = New System.Drawing.Size(548, 139)
        Me.GrupoEmpresa.TabIndex = 2
        Me.GrupoEmpresa.TabStop = False
        Me.GrupoEmpresa.Text = "Entity"
        '
        'CeldaID
        '
        Me.CeldaID.BackColor = System.Drawing.SystemColors.ControlLight
        Me.CeldaID.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper
        Me.CeldaID.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.CeldaID.Location = New System.Drawing.Point(21, 25)
        Me.CeldaID.Margin = New System.Windows.Forms.Padding(4)
        Me.CeldaID.MaxLength = 5
        Me.CeldaID.Name = "CeldaID"
        Me.CeldaID.ReadOnly = True
        Me.CeldaID.Size = New System.Drawing.Size(52, 24)
        Me.CeldaID.TabIndex = 0
        Me.CeldaID.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Referencia
        '
        Me.Referencia.AutoSize = True
        Me.Referencia.Font = New System.Drawing.Font("Microsoft Sans Serif", 6.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Referencia.ForeColor = System.Drawing.Color.DarkGreen
        Me.Referencia.Location = New System.Drawing.Point(24, 116)
        Me.Referencia.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Referencia.Name = "Referencia"
        Me.Referencia.Size = New System.Drawing.Size(81, 15)
        Me.Referencia.TabIndex = 4
        Me.Referencia.Text = "REFERENCE"
        Me.Referencia.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'CeldaPersona
        '
        Me.CeldaPersona.BackColor = System.Drawing.SystemColors.Window
        Me.CeldaPersona.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.CeldaPersona.Location = New System.Drawing.Point(185, 87)
        Me.CeldaPersona.Margin = New System.Windows.Forms.Padding(4)
        Me.CeldaPersona.MaxLength = 100
        Me.CeldaPersona.Name = "CeldaPersona"
        Me.CeldaPersona.Size = New System.Drawing.Size(317, 24)
        Me.CeldaPersona.TabIndex = 6
        '
        'EtiquetaEmisor
        '
        Me.EtiquetaEmisor.AutoSize = True
        Me.EtiquetaEmisor.Location = New System.Drawing.Point(23, 91)
        Me.EtiquetaEmisor.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.EtiquetaEmisor.Name = "EtiquetaEmisor"
        Me.EtiquetaEmisor.Size = New System.Drawing.Size(150, 17)
        Me.EtiquetaEmisor.TabIndex = 5
        Me.EtiquetaEmisor.Text = "Name, Drawer / Payee"
        '
        'CasillaProveedores
        '
        Me.CasillaProveedores.AutoSize = True
        Me.CasillaProveedores.Location = New System.Drawing.Point(21, 59)
        Me.CasillaProveedores.Margin = New System.Windows.Forms.Padding(4)
        Me.CasillaProveedores.Name = "CasillaProveedores"
        Me.CasillaProveedores.Size = New System.Drawing.Size(214, 21)
        Me.CasillaProveedores.TabIndex = 3
        Me.CasillaProveedores.Text = "Multiple providers / Expenses"
        Me.CasillaProveedores.UseVisualStyleBackColor = True
        '
        'BotonEmpresa
        '
        Me.BotonEmpresa.Location = New System.Drawing.Point(471, 26)
        Me.BotonEmpresa.Margin = New System.Windows.Forms.Padding(4)
        Me.BotonEmpresa.Name = "BotonEmpresa"
        Me.BotonEmpresa.Size = New System.Drawing.Size(33, 25)
        Me.BotonEmpresa.TabIndex = 2
        Me.BotonEmpresa.Text = "..."
        Me.BotonEmpresa.UseVisualStyleBackColor = True
        '
        'CeldaEmpresa
        '
        Me.CeldaEmpresa.BackColor = System.Drawing.SystemColors.Info
        Me.CeldaEmpresa.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.CeldaEmpresa.Location = New System.Drawing.Point(83, 25)
        Me.CeldaEmpresa.Margin = New System.Windows.Forms.Padding(4)
        Me.CeldaEmpresa.MaxLength = 250
        Me.CeldaEmpresa.Name = "CeldaEmpresa"
        Me.CeldaEmpresa.ReadOnly = True
        Me.CeldaEmpresa.Size = New System.Drawing.Size(379, 24)
        Me.CeldaEmpresa.TabIndex = 1
        '
        'GrupoDeposito
        '
        Me.GrupoDeposito.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.GrupoDeposito.Controls.Add(Me.CeldaTotalDeposito)
        Me.GrupoDeposito.Controls.Add(Me.EtiquetaTotalDeposito)
        Me.GrupoDeposito.Controls.Add(Me.CeldaOtrosBancos)
        Me.GrupoDeposito.Controls.Add(Me.EtiquetaOtros)
        Me.GrupoDeposito.Controls.Add(Me.CeldaCheques)
        Me.GrupoDeposito.Controls.Add(Me.EtiquetaCheques)
        Me.GrupoDeposito.Controls.Add(Me.CeldaEfectivo)
        Me.GrupoDeposito.Controls.Add(Me.EtiquetaEfectivo)
        Me.GrupoDeposito.Location = New System.Drawing.Point(541, 183)
        Me.GrupoDeposito.Margin = New System.Windows.Forms.Padding(4)
        Me.GrupoDeposito.Name = "GrupoDeposito"
        Me.GrupoDeposito.Padding = New System.Windows.Forms.Padding(4)
        Me.GrupoDeposito.Size = New System.Drawing.Size(548, 130)
        Me.GrupoDeposito.TabIndex = 3
        Me.GrupoDeposito.TabStop = False
        Me.GrupoDeposito.Text = "Deposit"
        Me.GrupoDeposito.Visible = False
        '
        'CeldaTotalDeposito
        '
        Me.CeldaTotalDeposito.BackColor = System.Drawing.SystemColors.ControlLight
        Me.CeldaTotalDeposito.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.CeldaTotalDeposito.Location = New System.Drawing.Point(300, 91)
        Me.CeldaTotalDeposito.Margin = New System.Windows.Forms.Padding(4)
        Me.CeldaTotalDeposito.MaxLength = 10
        Me.CeldaTotalDeposito.Name = "CeldaTotalDeposito"
        Me.CeldaTotalDeposito.ReadOnly = True
        Me.CeldaTotalDeposito.Size = New System.Drawing.Size(119, 24)
        Me.CeldaTotalDeposito.TabIndex = 7
        Me.CeldaTotalDeposito.TabStop = False
        Me.CeldaTotalDeposito.Text = "0.00"
        Me.CeldaTotalDeposito.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'EtiquetaTotalDeposito
        '
        Me.EtiquetaTotalDeposito.AutoSize = True
        Me.EtiquetaTotalDeposito.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.EtiquetaTotalDeposito.Location = New System.Drawing.Point(301, 66)
        Me.EtiquetaTotalDeposito.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.EtiquetaTotalDeposito.Name = "EtiquetaTotalDeposito"
        Me.EtiquetaTotalDeposito.Size = New System.Drawing.Size(181, 17)
        Me.EtiquetaTotalDeposito.TabIndex = 6
        Me.EtiquetaTotalDeposito.Text = "Total + Expenses = Amount"
        '
        'CeldaOtrosBancos
        '
        Me.CeldaOtrosBancos.BackColor = System.Drawing.SystemColors.Info
        Me.CeldaOtrosBancos.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.CeldaOtrosBancos.Location = New System.Drawing.Point(163, 91)
        Me.CeldaOtrosBancos.Margin = New System.Windows.Forms.Padding(4)
        Me.CeldaOtrosBancos.MaxLength = 10
        Me.CeldaOtrosBancos.Name = "CeldaOtrosBancos"
        Me.CeldaOtrosBancos.ReadOnly = True
        Me.CeldaOtrosBancos.Size = New System.Drawing.Size(119, 24)
        Me.CeldaOtrosBancos.TabIndex = 5
        Me.CeldaOtrosBancos.Text = "0.00"
        Me.CeldaOtrosBancos.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'EtiquetaOtros
        '
        Me.EtiquetaOtros.AutoSize = True
        Me.EtiquetaOtros.Location = New System.Drawing.Point(17, 95)
        Me.EtiquetaOtros.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.EtiquetaOtros.Name = "EtiquetaOtros"
        Me.EtiquetaOtros.Size = New System.Drawing.Size(134, 17)
        Me.EtiquetaOtros.TabIndex = 4
        Me.EtiquetaOtros.Text = "Other banks checks"
        '
        'CeldaCheques
        '
        Me.CeldaCheques.BackColor = System.Drawing.SystemColors.Window
        Me.CeldaCheques.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.CeldaCheques.Location = New System.Drawing.Point(163, 58)
        Me.CeldaCheques.Margin = New System.Windows.Forms.Padding(4)
        Me.CeldaCheques.MaxLength = 10
        Me.CeldaCheques.Name = "CeldaCheques"
        Me.CeldaCheques.Size = New System.Drawing.Size(119, 24)
        Me.CeldaCheques.TabIndex = 3
        Me.CeldaCheques.Text = "0.00"
        Me.CeldaCheques.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'EtiquetaCheques
        '
        Me.EtiquetaCheques.AutoSize = True
        Me.EtiquetaCheques.Location = New System.Drawing.Point(17, 62)
        Me.EtiquetaCheques.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.EtiquetaCheques.Name = "EtiquetaCheques"
        Me.EtiquetaCheques.Size = New System.Drawing.Size(127, 17)
        Me.EtiquetaCheques.TabIndex = 2
        Me.EtiquetaCheques.Text = "Same bank checks"
        '
        'CeldaEfectivo
        '
        Me.CeldaEfectivo.BackColor = System.Drawing.SystemColors.Window
        Me.CeldaEfectivo.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.CeldaEfectivo.Location = New System.Drawing.Point(163, 25)
        Me.CeldaEfectivo.Margin = New System.Windows.Forms.Padding(4)
        Me.CeldaEfectivo.MaxLength = 10
        Me.CeldaEfectivo.Name = "CeldaEfectivo"
        Me.CeldaEfectivo.Size = New System.Drawing.Size(119, 24)
        Me.CeldaEfectivo.TabIndex = 1
        Me.CeldaEfectivo.Text = "0.00"
        Me.CeldaEfectivo.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'EtiquetaEfectivo
        '
        Me.EtiquetaEfectivo.AutoSize = True
        Me.EtiquetaEfectivo.Location = New System.Drawing.Point(17, 28)
        Me.EtiquetaEfectivo.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.EtiquetaEfectivo.Name = "EtiquetaEfectivo"
        Me.EtiquetaEfectivo.Size = New System.Drawing.Size(40, 17)
        Me.EtiquetaEfectivo.TabIndex = 0
        Me.EtiquetaEfectivo.Text = "Cash"
        '
        'PanelCheques
        '
        Me.PanelCheques.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.PanelCheques.Controls.Add(Me.Cheques)
        Me.PanelCheques.Controls.Add(Me.PanelChequesTitulo)
        Me.PanelCheques.Location = New System.Drawing.Point(4, 320)
        Me.PanelCheques.Margin = New System.Windows.Forms.Padding(4)
        Me.PanelCheques.Name = "PanelCheques"
        Me.PanelCheques.Size = New System.Drawing.Size(529, 178)
        Me.PanelCheques.TabIndex = 5
        Me.PanelCheques.Visible = False
        '
        'Cheques
        '
        Me.Cheques.AllowUserToAddRows = False
        Me.Cheques.AllowUserToDeleteRows = False
        Me.Cheques.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.Cheques.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells
        Me.Cheques.BackgroundColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle1.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.Cheques.ColumnHeadersDefaultCellStyle = DataGridViewCellStyle1
        Me.Cheques.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.Cheques.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.cheque_fecha, Me.cheque_emisor, Me.cheque_numero, Me.cheque_monto, Me.cheque_estado})
        DataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle2.BackColor = System.Drawing.SystemColors.Window
        DataGridViewCellStyle2.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.ControlText
        DataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.[False]
        Me.Cheques.DefaultCellStyle = DataGridViewCellStyle2
        Me.Cheques.Location = New System.Drawing.Point(0, 27)
        Me.Cheques.Margin = New System.Windows.Forms.Padding(4)
        Me.Cheques.MultiSelect = False
        Me.Cheques.Name = "Cheques"
        DataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle3.BackColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle3.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle3.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle3.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle3.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.Cheques.RowHeadersDefaultCellStyle = DataGridViewCellStyle3
        Me.Cheques.RowHeadersWidth = 31
        Me.Cheques.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.CellSelect
        Me.Cheques.Size = New System.Drawing.Size(529, 145)
        Me.Cheques.TabIndex = 0
        '
        'cheque_fecha
        '
        Me.cheque_fecha.HeaderText = "Date"
        Me.cheque_fecha.Name = "cheque_fecha"
        Me.cheque_fecha.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        Me.cheque_fecha.Width = 80
        '
        'cheque_emisor
        '
        Me.cheque_emisor.HeaderText = "Issuer"
        Me.cheque_emisor.Name = "cheque_emisor"
        Me.cheque_emisor.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        Me.cheque_emisor.Width = 95
        '
        'cheque_numero
        '
        Me.cheque_numero.HeaderText = "Number"
        Me.cheque_numero.Name = "cheque_numero"
        Me.cheque_numero.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        Me.cheque_numero.Width = 60
        '
        'cheque_monto
        '
        Me.cheque_monto.HeaderText = "Amount"
        Me.cheque_monto.Name = "cheque_monto"
        Me.cheque_monto.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        Me.cheque_monto.Width = 50
        '
        'cheque_estado
        '
        Me.cheque_estado.HeaderText = "Status"
        Me.cheque_estado.Name = "cheque_estado"
        Me.cheque_estado.ReadOnly = True
        Me.cheque_estado.Resizable = System.Windows.Forms.DataGridViewTriState.[True]
        Me.cheque_estado.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        Me.cheque_estado.Width = 50
        '
        'PanelChequesTitulo
        '
        Me.PanelChequesTitulo.BackColor = System.Drawing.SystemColors.ActiveCaption
        Me.PanelChequesTitulo.Controls.Add(Me.BotonChequeMenos)
        Me.PanelChequesTitulo.Controls.Add(Me.BotonChequeMas)
        Me.PanelChequesTitulo.Controls.Add(Me.EtiquetaChequesTitulo)
        Me.PanelChequesTitulo.Location = New System.Drawing.Point(0, 0)
        Me.PanelChequesTitulo.Margin = New System.Windows.Forms.Padding(4)
        Me.PanelChequesTitulo.Name = "PanelChequesTitulo"
        Me.PanelChequesTitulo.Size = New System.Drawing.Size(529, 30)
        Me.PanelChequesTitulo.TabIndex = 0
        '
        'BotonChequeMenos
        '
        Me.BotonChequeMenos.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.BotonChequeMenos.Location = New System.Drawing.Point(492, 1)
        Me.BotonChequeMenos.Margin = New System.Windows.Forms.Padding(4)
        Me.BotonChequeMenos.Name = "BotonChequeMenos"
        Me.BotonChequeMenos.Size = New System.Drawing.Size(33, 25)
        Me.BotonChequeMenos.TabIndex = 2
        Me.BotonChequeMenos.Text = "-"
        Me.BotonChequeMenos.UseVisualStyleBackColor = True
        '
        'BotonChequeMas
        '
        Me.BotonChequeMas.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.BotonChequeMas.Location = New System.Drawing.Point(456, 1)
        Me.BotonChequeMas.Margin = New System.Windows.Forms.Padding(4)
        Me.BotonChequeMas.Name = "BotonChequeMas"
        Me.BotonChequeMas.Size = New System.Drawing.Size(33, 25)
        Me.BotonChequeMas.TabIndex = 1
        Me.BotonChequeMas.Text = "+"
        Me.BotonChequeMas.UseVisualStyleBackColor = True
        '
        'EtiquetaChequesTitulo
        '
        Me.EtiquetaChequesTitulo.AutoSize = True
        Me.EtiquetaChequesTitulo.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.EtiquetaChequesTitulo.ForeColor = System.Drawing.SystemColors.HighlightText
        Me.EtiquetaChequesTitulo.Location = New System.Drawing.Point(8, 4)
        Me.EtiquetaChequesTitulo.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.EtiquetaChequesTitulo.Name = "EtiquetaChequesTitulo"
        Me.EtiquetaChequesTitulo.Size = New System.Drawing.Size(176, 20)
        Me.EtiquetaChequesTitulo.TabIndex = 0
        Me.EtiquetaChequesTitulo.Text = "Other banks checks"
        '
        'PanelTransaccion
        '
        Me.PanelTransaccion.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.PanelTransaccion.BackColor = System.Drawing.Color.DarkSeaGreen
        Me.PanelTransaccion.Controls.Add(Me.EtiquetaTransaccion)
        Me.PanelTransaccion.Controls.Add(Me.BotonTransaccion)
        Me.PanelTransaccion.Controls.Add(Me.EtiquetaTituloTransaccion)
        Me.PanelTransaccion.Location = New System.Drawing.Point(541, 6)
        Me.PanelTransaccion.Margin = New System.Windows.Forms.Padding(4)
        Me.PanelTransaccion.Name = "PanelTransaccion"
        Me.PanelTransaccion.Size = New System.Drawing.Size(548, 30)
        Me.PanelTransaccion.TabIndex = 1
        '
        'EtiquetaTransaccion
        '
        Me.EtiquetaTransaccion.AutoSize = True
        Me.EtiquetaTransaccion.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.EtiquetaTransaccion.ForeColor = System.Drawing.Color.Khaki
        Me.EtiquetaTransaccion.Location = New System.Drawing.Point(8, 5)
        Me.EtiquetaTransaccion.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.EtiquetaTransaccion.Name = "EtiquetaTransaccion"
        Me.EtiquetaTransaccion.Size = New System.Drawing.Size(114, 20)
        Me.EtiquetaTransaccion.TabIndex = 4
        Me.EtiquetaTransaccion.Text = "Transaction:"
        '
        'BotonTransaccion
        '
        Me.BotonTransaccion.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.BotonTransaccion.Location = New System.Drawing.Point(511, 1)
        Me.BotonTransaccion.Margin = New System.Windows.Forms.Padding(4)
        Me.BotonTransaccion.Name = "BotonTransaccion"
        Me.BotonTransaccion.Size = New System.Drawing.Size(33, 25)
        Me.BotonTransaccion.TabIndex = 3
        Me.BotonTransaccion.Text = "..."
        Me.BotonTransaccion.UseVisualStyleBackColor = True
        '
        'EtiquetaTituloTransaccion
        '
        Me.EtiquetaTituloTransaccion.AutoSize = True
        Me.EtiquetaTituloTransaccion.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.EtiquetaTituloTransaccion.ForeColor = System.Drawing.Color.White
        Me.EtiquetaTituloTransaccion.Location = New System.Drawing.Point(136, 5)
        Me.EtiquetaTituloTransaccion.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.EtiquetaTituloTransaccion.Name = "EtiquetaTituloTransaccion"
        Me.EtiquetaTituloTransaccion.Size = New System.Drawing.Size(138, 20)
        Me.EtiquetaTituloTransaccion.TabIndex = 2
        Me.EtiquetaTituloTransaccion.Text = "Transaction Type"
        '
        'PanelLetras
        '
        Me.PanelLetras.Anchor = CType(((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.PanelLetras.BackColor = System.Drawing.SystemColors.Info
        Me.PanelLetras.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.PanelLetras.Controls.Add(Me.EtiquetaID)
        Me.PanelLetras.Controls.Add(Me.EtiquetaLetras)
        Me.PanelLetras.Location = New System.Drawing.Point(3, 502)
        Me.PanelLetras.Margin = New System.Windows.Forms.Padding(4)
        Me.PanelLetras.Name = "PanelLetras"
        Me.PanelLetras.Size = New System.Drawing.Size(1087, 30)
        Me.PanelLetras.TabIndex = 9
        '
        'EtiquetaID
        '
        Me.EtiquetaID.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.EtiquetaID.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.EtiquetaID.ForeColor = System.Drawing.SystemColors.ControlDarkDark
        Me.EtiquetaID.Location = New System.Drawing.Point(941, 6)
        Me.EtiquetaID.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.EtiquetaID.Name = "EtiquetaID"
        Me.EtiquetaID.Size = New System.Drawing.Size(133, 16)
        Me.EtiquetaID.TabIndex = 20
        Me.EtiquetaID.Text = "ID"
        Me.EtiquetaID.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'EtiquetaLetras
        '
        Me.EtiquetaLetras.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.EtiquetaLetras.AutoSize = True
        Me.EtiquetaLetras.Font = New System.Drawing.Font("Georgia", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.EtiquetaLetras.ForeColor = System.Drawing.SystemColors.InfoText
        Me.EtiquetaLetras.Location = New System.Drawing.Point(4, 6)
        Me.EtiquetaLetras.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.EtiquetaLetras.Name = "EtiquetaLetras"
        Me.EtiquetaLetras.Size = New System.Drawing.Size(57, 18)
        Me.EtiquetaLetras.TabIndex = 2
        Me.EtiquetaLetras.Text = "TOTAL"
        Me.EtiquetaLetras.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'PanelVentas
        '
        Me.PanelVentas.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.PanelVentas.Controls.Add(Me.CeldaTotalVenta)
        Me.PanelVentas.Controls.Add(Me.EtiquetaVentaTotal)
        Me.PanelVentas.Controls.Add(Me.Ventas)
        Me.PanelVentas.Controls.Add(Me.PanelVentasTitulo)
        Me.PanelVentas.Location = New System.Drawing.Point(541, 320)
        Me.PanelVentas.Margin = New System.Windows.Forms.Padding(4)
        Me.PanelVentas.Name = "PanelVentas"
        Me.PanelVentas.Size = New System.Drawing.Size(548, 178)
        Me.PanelVentas.TabIndex = 7
        Me.PanelVentas.Visible = False
        '
        'CeldaTotalVenta
        '
        Me.CeldaTotalVenta.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.CeldaTotalVenta.BackColor = System.Drawing.SystemColors.ControlLight
        Me.CeldaTotalVenta.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.CeldaTotalVenta.Location = New System.Drawing.Point(427, 148)
        Me.CeldaTotalVenta.Margin = New System.Windows.Forms.Padding(4)
        Me.CeldaTotalVenta.MaxLength = 10
        Me.CeldaTotalVenta.Name = "CeldaTotalVenta"
        Me.CeldaTotalVenta.ReadOnly = True
        Me.CeldaTotalVenta.Size = New System.Drawing.Size(119, 24)
        Me.CeldaTotalVenta.TabIndex = 3
        Me.CeldaTotalVenta.TabStop = False
        Me.CeldaTotalVenta.Text = "0.00"
        Me.CeldaTotalVenta.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'EtiquetaVentaTotal
        '
        Me.EtiquetaVentaTotal.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.EtiquetaVentaTotal.AutoSize = True
        Me.EtiquetaVentaTotal.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.EtiquetaVentaTotal.Location = New System.Drawing.Point(325, 151)
        Me.EtiquetaVentaTotal.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.EtiquetaVentaTotal.Name = "EtiquetaVentaTotal"
        Me.EtiquetaVentaTotal.Size = New System.Drawing.Size(92, 17)
        Me.EtiquetaVentaTotal.TabIndex = 2
        Me.EtiquetaVentaTotal.Text = "Total Amount"
        Me.EtiquetaVentaTotal.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'Ventas
        '
        Me.Ventas.AllowUserToAddRows = False
        Me.Ventas.AllowUserToDeleteRows = False
        Me.Ventas.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Ventas.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells
        Me.Ventas.BackgroundColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle4.BackColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle4.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle4.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle4.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle4.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle4.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.Ventas.ColumnHeadersDefaultCellStyle = DataGridViewCellStyle4
        Me.Ventas.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.Ventas.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.venta_tipo, Me.venta_ciclo, Me.venta_grupo, Me.venta_numero, Me.venta_serie, Me.venta_fecha, Me.venta_moneda, Me.venta_tasa, Me.venta_ref, Me.venta_monto, Me.venta_total, Me.venta_id, Me.ventas_numero2})
        DataGridViewCellStyle5.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle5.BackColor = System.Drawing.SystemColors.Window
        DataGridViewCellStyle5.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle5.ForeColor = System.Drawing.SystemColors.ControlText
        DataGridViewCellStyle5.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle5.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle5.WrapMode = System.Windows.Forms.DataGridViewTriState.[False]
        Me.Ventas.DefaultCellStyle = DataGridViewCellStyle5
        Me.Ventas.Location = New System.Drawing.Point(0, 27)
        Me.Ventas.Margin = New System.Windows.Forms.Padding(4)
        Me.Ventas.MultiSelect = False
        Me.Ventas.Name = "Ventas"
        DataGridViewCellStyle6.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle6.BackColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle6.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle6.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle6.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle6.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle6.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.Ventas.RowHeadersDefaultCellStyle = DataGridViewCellStyle6
        Me.Ventas.RowHeadersWidth = 31
        Me.Ventas.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.CellSelect
        Me.Ventas.Size = New System.Drawing.Size(548, 111)
        Me.Ventas.TabIndex = 1
        '
        'venta_tipo
        '
        Me.venta_tipo.HeaderText = "Type"
        Me.venta_tipo.Name = "venta_tipo"
        Me.venta_tipo.ReadOnly = True
        Me.venta_tipo.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        Me.venta_tipo.Visible = False
        Me.venta_tipo.Width = 30
        '
        'venta_ciclo
        '
        Me.venta_ciclo.HeaderText = "Year"
        Me.venta_ciclo.Name = "venta_ciclo"
        Me.venta_ciclo.ReadOnly = True
        Me.venta_ciclo.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        Me.venta_ciclo.Visible = False
        Me.venta_ciclo.Width = 30
        '
        'venta_grupo
        '
        Me.venta_grupo.HeaderText = "Group"
        Me.venta_grupo.Name = "venta_grupo"
        Me.venta_grupo.ReadOnly = True
        Me.venta_grupo.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        Me.venta_grupo.Width = 40
        '
        'venta_numero
        '
        Me.venta_numero.HeaderText = "Number"
        Me.venta_numero.Name = "venta_numero"
        Me.venta_numero.ReadOnly = True
        Me.venta_numero.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        Me.venta_numero.Width = 60
        '
        'venta_serie
        '
        Me.venta_serie.HeaderText = "Serie"
        Me.venta_serie.Name = "venta_serie"
        Me.venta_serie.ReadOnly = True
        Me.venta_serie.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        Me.venta_serie.Visible = False
        Me.venta_serie.Width = 30
        '
        'venta_fecha
        '
        Me.venta_fecha.HeaderText = "Date"
        Me.venta_fecha.Name = "venta_fecha"
        Me.venta_fecha.ReadOnly = True
        Me.venta_fecha.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        Me.venta_fecha.Width = 75
        '
        'venta_moneda
        '
        Me.venta_moneda.HeaderText = "Currency"
        Me.venta_moneda.Name = "venta_moneda"
        Me.venta_moneda.ReadOnly = True
        Me.venta_moneda.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        Me.venta_moneda.Visible = False
        Me.venta_moneda.Width = 30
        '
        'venta_tasa
        '
        Me.venta_tasa.HeaderText = "Rate"
        Me.venta_tasa.Name = "venta_tasa"
        Me.venta_tasa.ReadOnly = True
        Me.venta_tasa.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        Me.venta_tasa.Visible = False
        Me.venta_tasa.Width = 30
        '
        'venta_ref
        '
        Me.venta_ref.HeaderText = "Reference"
        Me.venta_ref.Name = "venta_ref"
        Me.venta_ref.ReadOnly = True
        Me.venta_ref.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        Me.venta_ref.Width = 90
        '
        'venta_monto
        '
        Me.venta_monto.HeaderText = "Amount"
        Me.venta_monto.Name = "venta_monto"
        Me.venta_monto.ReadOnly = True
        Me.venta_monto.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        Me.venta_monto.Visible = False
        Me.venta_monto.Width = 30
        '
        'venta_total
        '
        Me.venta_total.HeaderText = "Total"
        Me.venta_total.MaxInputLength = 10
        Me.venta_total.Name = "venta_total"
        Me.venta_total.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        Me.venta_total.Width = 85
        '
        'venta_id
        '
        Me.venta_id.HeaderText = "Customer"
        Me.venta_id.Name = "venta_id"
        Me.venta_id.ReadOnly = True
        Me.venta_id.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        Me.venta_id.Visible = False
        Me.venta_id.Width = 30
        '
        'ventas_numero2
        '
        Me.ventas_numero2.HeaderText = "# Invoice"
        Me.ventas_numero2.Name = "ventas_numero2"
        Me.ventas_numero2.Visible = False
        '
        'PanelVentasTitulo
        '
        Me.PanelVentasTitulo.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.PanelVentasTitulo.BackColor = System.Drawing.SystemColors.ActiveCaption
        Me.PanelVentasTitulo.Controls.Add(Me.BotonVentaGasto)
        Me.PanelVentasTitulo.Controls.Add(Me.BotonVentaCuenta)
        Me.PanelVentasTitulo.Controls.Add(Me.BotonVentaMenos)
        Me.PanelVentasTitulo.Controls.Add(Me.BotonVentaMas)
        Me.PanelVentasTitulo.Controls.Add(Me.EtiquetaVentasTitulo)
        Me.PanelVentasTitulo.Location = New System.Drawing.Point(0, 0)
        Me.PanelVentasTitulo.Margin = New System.Windows.Forms.Padding(4)
        Me.PanelVentasTitulo.Name = "PanelVentasTitulo"
        Me.PanelVentasTitulo.Size = New System.Drawing.Size(548, 30)
        Me.PanelVentasTitulo.TabIndex = 0
        '
        'BotonVentaGasto
        '
        Me.BotonVentaGasto.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.BotonVentaGasto.Font = New System.Drawing.Font("Microsoft Sans Serif", 6.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BotonVentaGasto.Location = New System.Drawing.Point(292, 1)
        Me.BotonVentaGasto.Margin = New System.Windows.Forms.Padding(4)
        Me.BotonVentaGasto.Name = "BotonVentaGasto"
        Me.BotonVentaGasto.Size = New System.Drawing.Size(81, 25)
        Me.BotonVentaGasto.TabIndex = 1
        Me.BotonVentaGasto.Text = "Expenses"
        Me.BotonVentaGasto.UseVisualStyleBackColor = True
        '
        'BotonVentaCuenta
        '
        Me.BotonVentaCuenta.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.BotonVentaCuenta.Font = New System.Drawing.Font("Microsoft Sans Serif", 6.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BotonVentaCuenta.Location = New System.Drawing.Point(376, 1)
        Me.BotonVentaCuenta.Margin = New System.Windows.Forms.Padding(4)
        Me.BotonVentaCuenta.Name = "BotonVentaCuenta"
        Me.BotonVentaCuenta.Size = New System.Drawing.Size(81, 25)
        Me.BotonVentaCuenta.TabIndex = 2
        Me.BotonVentaCuenta.Text = "Account"
        Me.BotonVentaCuenta.UseVisualStyleBackColor = True
        '
        'BotonVentaMenos
        '
        Me.BotonVentaMenos.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.BotonVentaMenos.Location = New System.Drawing.Point(511, 1)
        Me.BotonVentaMenos.Margin = New System.Windows.Forms.Padding(4)
        Me.BotonVentaMenos.Name = "BotonVentaMenos"
        Me.BotonVentaMenos.Size = New System.Drawing.Size(33, 25)
        Me.BotonVentaMenos.TabIndex = 4
        Me.BotonVentaMenos.Text = "-"
        Me.BotonVentaMenos.UseVisualStyleBackColor = True
        '
        'BotonVentaMas
        '
        Me.BotonVentaMas.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.BotonVentaMas.Location = New System.Drawing.Point(477, 1)
        Me.BotonVentaMas.Margin = New System.Windows.Forms.Padding(4)
        Me.BotonVentaMas.Name = "BotonVentaMas"
        Me.BotonVentaMas.Size = New System.Drawing.Size(33, 25)
        Me.BotonVentaMas.TabIndex = 3
        Me.BotonVentaMas.Text = "+"
        Me.BotonVentaMas.UseVisualStyleBackColor = True
        '
        'EtiquetaVentasTitulo
        '
        Me.EtiquetaVentasTitulo.AutoSize = True
        Me.EtiquetaVentasTitulo.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.EtiquetaVentasTitulo.ForeColor = System.Drawing.SystemColors.HighlightText
        Me.EtiquetaVentasTitulo.Location = New System.Drawing.Point(8, 4)
        Me.EtiquetaVentasTitulo.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.EtiquetaVentasTitulo.Name = "EtiquetaVentasTitulo"
        Me.EtiquetaVentasTitulo.Size = New System.Drawing.Size(181, 20)
        Me.EtiquetaVentasTitulo.TabIndex = 0
        Me.EtiquetaVentasTitulo.Text = " Invoices and Debits"
        '
        'Grupo1
        '
        Me.Grupo1.Location = New System.Drawing.Point(541, 496)
        Me.Grupo1.Margin = New System.Windows.Forms.Padding(4)
        Me.Grupo1.Name = "Grupo1"
        Me.Grupo1.Padding = New System.Windows.Forms.Padding(4)
        Me.Grupo1.Size = New System.Drawing.Size(45, 32)
        Me.Grupo1.TabIndex = 10
        Me.Grupo1.TabStop = False
        Me.Grupo1.Visible = False
        '
        'Grupo2
        '
        Me.Grupo2.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.Grupo2.Location = New System.Drawing.Point(595, 496)
        Me.Grupo2.Margin = New System.Windows.Forms.Padding(4)
        Me.Grupo2.Name = "Grupo2"
        Me.Grupo2.Padding = New System.Windows.Forms.Padding(4)
        Me.Grupo2.Size = New System.Drawing.Size(45, 32)
        Me.Grupo2.TabIndex = 11
        Me.Grupo2.TabStop = False
        Me.Grupo2.Visible = False
        '
        'Grupo3
        '
        Me.Grupo3.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Grupo3.Location = New System.Drawing.Point(645, 496)
        Me.Grupo3.Margin = New System.Windows.Forms.Padding(4)
        Me.Grupo3.Name = "Grupo3"
        Me.Grupo3.Padding = New System.Windows.Forms.Padding(4)
        Me.Grupo3.Size = New System.Drawing.Size(45, 32)
        Me.Grupo3.TabIndex = 12
        Me.Grupo3.TabStop = False
        Me.Grupo3.Visible = False
        '
        'GrupoCuenta
        '
        Me.GrupoCuenta.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.GrupoCuenta.Controls.Add(Me.EtiquetaCuentaNombre)
        Me.GrupoCuenta.Controls.Add(Me.CeldaCuentaNombre)
        Me.GrupoCuenta.Controls.Add(Me.CasillaExterna)
        Me.GrupoCuenta.Controls.Add(Me.EtiquetaCuenta)
        Me.GrupoCuenta.Controls.Add(Me.BotonCC)
        Me.GrupoCuenta.Controls.Add(Me.CeldaCuenta)
        Me.GrupoCuenta.Location = New System.Drawing.Point(536, 202)
        Me.GrupoCuenta.Margin = New System.Windows.Forms.Padding(4)
        Me.GrupoCuenta.Name = "GrupoCuenta"
        Me.GrupoCuenta.Padding = New System.Windows.Forms.Padding(4)
        Me.GrupoCuenta.Size = New System.Drawing.Size(547, 130)
        Me.GrupoCuenta.TabIndex = 4
        Me.GrupoCuenta.TabStop = False
        Me.GrupoCuenta.Text = "Accounting"
        Me.GrupoCuenta.Visible = False
        '
        'EtiquetaCuentaNombre
        '
        Me.EtiquetaCuentaNombre.AutoSize = True
        Me.EtiquetaCuentaNombre.Location = New System.Drawing.Point(23, 68)
        Me.EtiquetaCuentaNombre.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.EtiquetaCuentaNombre.Name = "EtiquetaCuentaNombre"
        Me.EtiquetaCuentaNombre.Size = New System.Drawing.Size(134, 17)
        Me.EtiquetaCuentaNombre.TabIndex = 4
        Me.EtiquetaCuentaNombre.Text = "Account Description"
        '
        'CeldaCuentaNombre
        '
        Me.CeldaCuentaNombre.BackColor = System.Drawing.SystemColors.Info
        Me.CeldaCuentaNombre.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.CeldaCuentaNombre.Location = New System.Drawing.Point(27, 87)
        Me.CeldaCuentaNombre.Margin = New System.Windows.Forms.Padding(4)
        Me.CeldaCuentaNombre.MaxLength = 250
        Me.CeldaCuentaNombre.Name = "CeldaCuentaNombre"
        Me.CeldaCuentaNombre.ReadOnly = True
        Me.CeldaCuentaNombre.Size = New System.Drawing.Size(476, 24)
        Me.CeldaCuentaNombre.TabIndex = 5
        '
        'CasillaExterna
        '
        Me.CasillaExterna.AutoSize = True
        Me.CasillaExterna.Location = New System.Drawing.Point(419, 34)
        Me.CasillaExterna.Margin = New System.Windows.Forms.Padding(4)
        Me.CasillaExterna.Name = "CasillaExterna"
        Me.CasillaExterna.Size = New System.Drawing.Size(81, 21)
        Me.CasillaExterna.TabIndex = 3
        Me.CasillaExterna.Text = "External"
        Me.CasillaExterna.UseVisualStyleBackColor = True
        '
        'EtiquetaCuenta
        '
        Me.EtiquetaCuenta.AutoSize = True
        Me.EtiquetaCuenta.Location = New System.Drawing.Point(25, 34)
        Me.EtiquetaCuenta.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.EtiquetaCuenta.Name = "EtiquetaCuenta"
        Me.EtiquetaCuenta.Size = New System.Drawing.Size(95, 17)
        Me.EtiquetaCuenta.TabIndex = 0
        Me.EtiquetaCuenta.Text = "Book Account"
        '
        'BotonCC
        '
        Me.BotonCC.Location = New System.Drawing.Point(376, 30)
        Me.BotonCC.Margin = New System.Windows.Forms.Padding(4)
        Me.BotonCC.Name = "BotonCC"
        Me.BotonCC.Size = New System.Drawing.Size(33, 25)
        Me.BotonCC.TabIndex = 2
        Me.BotonCC.Text = "..."
        Me.BotonCC.UseVisualStyleBackColor = True
        '
        'CeldaCuenta
        '
        Me.CeldaCuenta.BackColor = System.Drawing.SystemColors.Info
        Me.CeldaCuenta.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.CeldaCuenta.Location = New System.Drawing.Point(133, 31)
        Me.CeldaCuenta.Margin = New System.Windows.Forms.Padding(4)
        Me.CeldaCuenta.MaxLength = 250
        Me.CeldaCuenta.Name = "CeldaCuenta"
        Me.CeldaCuenta.ReadOnly = True
        Me.CeldaCuenta.Size = New System.Drawing.Size(233, 24)
        Me.CeldaCuenta.TabIndex = 1
        '
        'PanelCompras
        '
        Me.PanelCompras.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.PanelCompras.Controls.Add(Me.CeldaAnticipo)
        Me.PanelCompras.Controls.Add(Me.EtiquetaAnticipo)
        Me.PanelCompras.Controls.Add(Me.CeldaTotalCompra)
        Me.PanelCompras.Controls.Add(Me.EtiquetaCompraTotal)
        Me.PanelCompras.Controls.Add(Me.Compras)
        Me.PanelCompras.Controls.Add(Me.PanelComprasTitulo)
        Me.PanelCompras.Location = New System.Drawing.Point(16, 316)
        Me.PanelCompras.Margin = New System.Windows.Forms.Padding(4)
        Me.PanelCompras.Name = "PanelCompras"
        Me.PanelCompras.Size = New System.Drawing.Size(509, 176)
        Me.PanelCompras.TabIndex = 6
        Me.PanelCompras.Visible = False
        '
        'CeldaAnticipo
        '
        Me.CeldaAnticipo.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.CeldaAnticipo.BackColor = System.Drawing.SystemColors.Window
        Me.CeldaAnticipo.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.CeldaAnticipo.Location = New System.Drawing.Point(172, 145)
        Me.CeldaAnticipo.Margin = New System.Windows.Forms.Padding(4)
        Me.CeldaAnticipo.MaxLength = 10
        Me.CeldaAnticipo.Name = "CeldaAnticipo"
        Me.CeldaAnticipo.Size = New System.Drawing.Size(105, 24)
        Me.CeldaAnticipo.TabIndex = 3
        Me.CeldaAnticipo.TabStop = False
        Me.CeldaAnticipo.Text = "0.00"
        Me.CeldaAnticipo.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'EtiquetaAnticipo
        '
        Me.EtiquetaAnticipo.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.EtiquetaAnticipo.AutoSize = True
        Me.EtiquetaAnticipo.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.EtiquetaAnticipo.Location = New System.Drawing.Point(40, 149)
        Me.EtiquetaAnticipo.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.EtiquetaAnticipo.Name = "EtiquetaAnticipo"
        Me.EtiquetaAnticipo.Size = New System.Drawing.Size(122, 17)
        Me.EtiquetaAnticipo.TabIndex = 2
        Me.EtiquetaAnticipo.Text = "Advance Payment"
        Me.EtiquetaAnticipo.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'CeldaTotalCompra
        '
        Me.CeldaTotalCompra.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.CeldaTotalCompra.BackColor = System.Drawing.SystemColors.ControlLight
        Me.CeldaTotalCompra.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.CeldaTotalCompra.Location = New System.Drawing.Point(388, 145)
        Me.CeldaTotalCompra.Margin = New System.Windows.Forms.Padding(4)
        Me.CeldaTotalCompra.MaxLength = 10
        Me.CeldaTotalCompra.Name = "CeldaTotalCompra"
        Me.CeldaTotalCompra.ReadOnly = True
        Me.CeldaTotalCompra.Size = New System.Drawing.Size(119, 24)
        Me.CeldaTotalCompra.TabIndex = 5
        Me.CeldaTotalCompra.TabStop = False
        Me.CeldaTotalCompra.Text = "0.00"
        Me.CeldaTotalCompra.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'EtiquetaCompraTotal
        '
        Me.EtiquetaCompraTotal.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.EtiquetaCompraTotal.AutoSize = True
        Me.EtiquetaCompraTotal.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.EtiquetaCompraTotal.Location = New System.Drawing.Point(287, 149)
        Me.EtiquetaCompraTotal.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.EtiquetaCompraTotal.Name = "EtiquetaCompraTotal"
        Me.EtiquetaCompraTotal.Size = New System.Drawing.Size(92, 17)
        Me.EtiquetaCompraTotal.TabIndex = 4
        Me.EtiquetaCompraTotal.Text = "Total Amount"
        Me.EtiquetaCompraTotal.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'Compras
        '
        Me.Compras.AllowUserToAddRows = False
        Me.Compras.AllowUserToDeleteRows = False
        Me.Compras.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Compras.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells
        Me.Compras.BackgroundColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle7.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle7.BackColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle7.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle7.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle7.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle7.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle7.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.Compras.ColumnHeadersDefaultCellStyle = DataGridViewCellStyle7
        Me.Compras.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.Compras.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.compra_tipo, Me.compra_ciclo, Me.compra_numero, Me.compra_moneda, Me.compra_tasa, Me.compra_cambio, Me.compra_marca, Me.compra_descripcion, Me.col_DocumentoTipo, Me.compra_monto, Me.compra_cuenta, Me.compra_ref_ciclo, Me.compra_ref_numero, Me.compra_factura})
        DataGridViewCellStyle9.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle9.BackColor = System.Drawing.SystemColors.Window
        DataGridViewCellStyle9.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle9.ForeColor = System.Drawing.SystemColors.ControlText
        DataGridViewCellStyle9.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle9.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle9.WrapMode = System.Windows.Forms.DataGridViewTriState.[False]
        Me.Compras.DefaultCellStyle = DataGridViewCellStyle9
        Me.Compras.Location = New System.Drawing.Point(0, 27)
        Me.Compras.Margin = New System.Windows.Forms.Padding(4)
        Me.Compras.MultiSelect = False
        Me.Compras.Name = "Compras"
        DataGridViewCellStyle10.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle10.BackColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle10.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle10.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle10.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle10.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle10.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.Compras.RowHeadersDefaultCellStyle = DataGridViewCellStyle10
        Me.Compras.RowHeadersWidth = 31
        Me.Compras.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.CellSelect
        Me.Compras.Size = New System.Drawing.Size(509, 112)
        Me.Compras.TabIndex = 1
        '
        'PanelComprasTitulo
        '
        Me.PanelComprasTitulo.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.PanelComprasTitulo.BackColor = System.Drawing.SystemColors.ActiveCaption
        Me.PanelComprasTitulo.Controls.Add(Me.BotonCompraGasto)
        Me.PanelComprasTitulo.Controls.Add(Me.BotonCompraCuenta)
        Me.PanelComprasTitulo.Controls.Add(Me.BotonCompraMenos)
        Me.PanelComprasTitulo.Controls.Add(Me.BotonCompraMas)
        Me.PanelComprasTitulo.Controls.Add(Me.EtiquetaComprasTitulo)
        Me.PanelComprasTitulo.Location = New System.Drawing.Point(0, 0)
        Me.PanelComprasTitulo.Margin = New System.Windows.Forms.Padding(4)
        Me.PanelComprasTitulo.Name = "PanelComprasTitulo"
        Me.PanelComprasTitulo.Size = New System.Drawing.Size(509, 30)
        Me.PanelComprasTitulo.TabIndex = 0
        '
        'BotonCompraGasto
        '
        Me.BotonCompraGasto.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.BotonCompraGasto.Font = New System.Drawing.Font("Microsoft Sans Serif", 6.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BotonCompraGasto.Location = New System.Drawing.Point(253, 1)
        Me.BotonCompraGasto.Margin = New System.Windows.Forms.Padding(4)
        Me.BotonCompraGasto.Name = "BotonCompraGasto"
        Me.BotonCompraGasto.Size = New System.Drawing.Size(81, 25)
        Me.BotonCompraGasto.TabIndex = 1
        Me.BotonCompraGasto.Text = "Expenses"
        Me.BotonCompraGasto.UseVisualStyleBackColor = True
        '
        'BotonCompraCuenta
        '
        Me.BotonCompraCuenta.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.BotonCompraCuenta.Font = New System.Drawing.Font("Microsoft Sans Serif", 6.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BotonCompraCuenta.Location = New System.Drawing.Point(337, 1)
        Me.BotonCompraCuenta.Margin = New System.Windows.Forms.Padding(4)
        Me.BotonCompraCuenta.Name = "BotonCompraCuenta"
        Me.BotonCompraCuenta.Size = New System.Drawing.Size(81, 25)
        Me.BotonCompraCuenta.TabIndex = 2
        Me.BotonCompraCuenta.Text = "Account"
        Me.BotonCompraCuenta.UseVisualStyleBackColor = True
        '
        'BotonCompraMenos
        '
        Me.BotonCompraMenos.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.BotonCompraMenos.Location = New System.Drawing.Point(472, 1)
        Me.BotonCompraMenos.Margin = New System.Windows.Forms.Padding(4)
        Me.BotonCompraMenos.Name = "BotonCompraMenos"
        Me.BotonCompraMenos.Size = New System.Drawing.Size(33, 25)
        Me.BotonCompraMenos.TabIndex = 4
        Me.BotonCompraMenos.Text = "-"
        Me.BotonCompraMenos.UseVisualStyleBackColor = True
        '
        'BotonCompraMas
        '
        Me.BotonCompraMas.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.BotonCompraMas.Location = New System.Drawing.Point(439, 1)
        Me.BotonCompraMas.Margin = New System.Windows.Forms.Padding(4)
        Me.BotonCompraMas.Name = "BotonCompraMas"
        Me.BotonCompraMas.Size = New System.Drawing.Size(33, 25)
        Me.BotonCompraMas.TabIndex = 3
        Me.BotonCompraMas.Text = "+"
        Me.BotonCompraMas.UseVisualStyleBackColor = True
        '
        'EtiquetaComprasTitulo
        '
        Me.EtiquetaComprasTitulo.AutoSize = True
        Me.EtiquetaComprasTitulo.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.EtiquetaComprasTitulo.ForeColor = System.Drawing.SystemColors.HighlightText
        Me.EtiquetaComprasTitulo.Location = New System.Drawing.Point(8, 4)
        Me.EtiquetaComprasTitulo.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.EtiquetaComprasTitulo.Name = "EtiquetaComprasTitulo"
        Me.EtiquetaComprasTitulo.Size = New System.Drawing.Size(163, 20)
        Me.EtiquetaComprasTitulo.TabIndex = 0
        Me.EtiquetaComprasTitulo.Text = "Purchase Invoices"
        '
        'PanelCaja
        '
        Me.PanelCaja.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.PanelCaja.Controls.Add(Me.EtiquetaCajaFecha)
        Me.PanelCaja.Controls.Add(Me.EtiquetaCajaDiferencia)
        Me.PanelCaja.Controls.Add(Me.CeldaDiferencia)
        Me.PanelCaja.Controls.Add(Me.CeldaTotalCaja)
        Me.PanelCaja.Controls.Add(Me.EtiquetaCajaTotal)
        Me.PanelCaja.Controls.Add(Me.Caja)
        Me.PanelCaja.Controls.Add(Me.PanelCajaTitulo)
        Me.PanelCaja.Location = New System.Drawing.Point(535, 309)
        Me.PanelCaja.Margin = New System.Windows.Forms.Padding(4)
        Me.PanelCaja.Name = "PanelCaja"
        Me.PanelCaja.Size = New System.Drawing.Size(548, 178)
        Me.PanelCaja.TabIndex = 8
        Me.PanelCaja.Visible = False
        '
        'EtiquetaCajaFecha
        '
        Me.EtiquetaCajaFecha.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.EtiquetaCajaFecha.AutoSize = True
        Me.EtiquetaCajaFecha.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.EtiquetaCajaFecha.Location = New System.Drawing.Point(3, 151)
        Me.EtiquetaCajaFecha.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.EtiquetaCajaFecha.Name = "EtiquetaCajaFecha"
        Me.EtiquetaCajaFecha.Size = New System.Drawing.Size(79, 17)
        Me.EtiquetaCajaFecha.TabIndex = 11
        Me.EtiquetaCajaFecha.Text = "Date range"
        Me.EtiquetaCajaFecha.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'EtiquetaCajaDiferencia
        '
        Me.EtiquetaCajaDiferencia.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.EtiquetaCajaDiferencia.AutoSize = True
        Me.EtiquetaCajaDiferencia.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.EtiquetaCajaDiferencia.Location = New System.Drawing.Point(128, 151)
        Me.EtiquetaCajaDiferencia.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.EtiquetaCajaDiferencia.Name = "EtiquetaCajaDiferencia"
        Me.EtiquetaCajaDiferencia.Size = New System.Drawing.Size(73, 17)
        Me.EtiquetaCajaDiferencia.TabIndex = 10
        Me.EtiquetaCajaDiferencia.Text = "Difference"
        Me.EtiquetaCajaDiferencia.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'CeldaDiferencia
        '
        Me.CeldaDiferencia.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.CeldaDiferencia.BackColor = System.Drawing.SystemColors.Window
        Me.CeldaDiferencia.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.CeldaDiferencia.Location = New System.Drawing.Point(211, 148)
        Me.CeldaDiferencia.Margin = New System.Windows.Forms.Padding(4)
        Me.CeldaDiferencia.MaxLength = 10
        Me.CeldaDiferencia.Name = "CeldaDiferencia"
        Me.CeldaDiferencia.Size = New System.Drawing.Size(105, 24)
        Me.CeldaDiferencia.TabIndex = 7
        Me.CeldaDiferencia.TabStop = False
        Me.CeldaDiferencia.Text = "0.00"
        Me.CeldaDiferencia.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'CeldaTotalCaja
        '
        Me.CeldaTotalCaja.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.CeldaTotalCaja.BackColor = System.Drawing.SystemColors.ControlLight
        Me.CeldaTotalCaja.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.CeldaTotalCaja.Location = New System.Drawing.Point(427, 148)
        Me.CeldaTotalCaja.Margin = New System.Windows.Forms.Padding(4)
        Me.CeldaTotalCaja.MaxLength = 10
        Me.CeldaTotalCaja.Name = "CeldaTotalCaja"
        Me.CeldaTotalCaja.ReadOnly = True
        Me.CeldaTotalCaja.Size = New System.Drawing.Size(119, 24)
        Me.CeldaTotalCaja.TabIndex = 3
        Me.CeldaTotalCaja.TabStop = False
        Me.CeldaTotalCaja.Text = "0.00"
        Me.CeldaTotalCaja.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'EtiquetaCajaTotal
        '
        Me.EtiquetaCajaTotal.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.EtiquetaCajaTotal.AutoSize = True
        Me.EtiquetaCajaTotal.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.EtiquetaCajaTotal.Location = New System.Drawing.Point(325, 151)
        Me.EtiquetaCajaTotal.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.EtiquetaCajaTotal.Name = "EtiquetaCajaTotal"
        Me.EtiquetaCajaTotal.Size = New System.Drawing.Size(92, 17)
        Me.EtiquetaCajaTotal.TabIndex = 2
        Me.EtiquetaCajaTotal.Text = "Total Amount"
        Me.EtiquetaCajaTotal.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'Caja
        '
        Me.Caja.AllowUserToAddRows = False
        Me.Caja.AllowUserToDeleteRows = False
        Me.Caja.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Caja.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells
        Me.Caja.BackgroundColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle11.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle11.BackColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle11.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle11.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle11.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle11.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle11.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.Caja.ColumnHeadersDefaultCellStyle = DataGridViewCellStyle11
        Me.Caja.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.Caja.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.caja_documento, Me.caja_numero, Me.caja_fecha, Me.caja_nombre, Me.caja_moneda, Me.caja_total, Me.caja_parcial, Me.caja_concepto})
        DataGridViewCellStyle12.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle12.BackColor = System.Drawing.SystemColors.Window
        DataGridViewCellStyle12.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle12.ForeColor = System.Drawing.SystemColors.ControlText
        DataGridViewCellStyle12.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle12.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle12.WrapMode = System.Windows.Forms.DataGridViewTriState.[False]
        Me.Caja.DefaultCellStyle = DataGridViewCellStyle12
        Me.Caja.Location = New System.Drawing.Point(0, 27)
        Me.Caja.Margin = New System.Windows.Forms.Padding(4)
        Me.Caja.MultiSelect = False
        Me.Caja.Name = "Caja"
        Me.Caja.ReadOnly = True
        DataGridViewCellStyle13.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle13.BackColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle13.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle13.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle13.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle13.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle13.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.Caja.RowHeadersDefaultCellStyle = DataGridViewCellStyle13
        Me.Caja.RowHeadersWidth = 31
        Me.Caja.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.CellSelect
        Me.Caja.Size = New System.Drawing.Size(548, 111)
        Me.Caja.TabIndex = 1
        '
        'caja_documento
        '
        Me.caja_documento.HeaderText = "Document"
        Me.caja_documento.Name = "caja_documento"
        Me.caja_documento.ReadOnly = True
        '
        'caja_numero
        '
        Me.caja_numero.HeaderText = "Number"
        Me.caja_numero.Name = "caja_numero"
        Me.caja_numero.ReadOnly = True
        '
        'caja_fecha
        '
        Me.caja_fecha.HeaderText = "Date"
        Me.caja_fecha.Name = "caja_fecha"
        Me.caja_fecha.ReadOnly = True
        Me.caja_fecha.Width = 75
        '
        'caja_nombre
        '
        Me.caja_nombre.HeaderText = "Name"
        Me.caja_nombre.Name = "caja_nombre"
        Me.caja_nombre.ReadOnly = True
        Me.caja_nombre.Width = 150
        '
        'caja_moneda
        '
        Me.caja_moneda.HeaderText = ""
        Me.caja_moneda.Name = "caja_moneda"
        Me.caja_moneda.ReadOnly = True
        Me.caja_moneda.Width = 25
        '
        'caja_total
        '
        Me.caja_total.HeaderText = "Amount"
        Me.caja_total.Name = "caja_total"
        Me.caja_total.ReadOnly = True
        Me.caja_total.Width = 70
        '
        'caja_parcial
        '
        Me.caja_parcial.HeaderText = "Partial"
        Me.caja_parcial.Name = "caja_parcial"
        Me.caja_parcial.ReadOnly = True
        Me.caja_parcial.Width = 70
        '
        'caja_concepto
        '
        Me.caja_concepto.HeaderText = "Concept"
        Me.caja_concepto.Name = "caja_concepto"
        Me.caja_concepto.ReadOnly = True
        Me.caja_concepto.Width = 350
        '
        'PanelCajaTitulo
        '
        Me.PanelCajaTitulo.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.PanelCajaTitulo.BackColor = System.Drawing.SystemColors.ActiveCaption
        Me.PanelCajaTitulo.Controls.Add(Me.BotonCajaMenos)
        Me.PanelCajaTitulo.Controls.Add(Me.BotonCajaMas)
        Me.PanelCajaTitulo.Controls.Add(Me.EtiquetaCajaTitulo)
        Me.PanelCajaTitulo.Location = New System.Drawing.Point(0, 0)
        Me.PanelCajaTitulo.Margin = New System.Windows.Forms.Padding(4)
        Me.PanelCajaTitulo.Name = "PanelCajaTitulo"
        Me.PanelCajaTitulo.Size = New System.Drawing.Size(548, 30)
        Me.PanelCajaTitulo.TabIndex = 0
        '
        'BotonCajaMenos
        '
        Me.BotonCajaMenos.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.BotonCajaMenos.Location = New System.Drawing.Point(511, 1)
        Me.BotonCajaMenos.Margin = New System.Windows.Forms.Padding(4)
        Me.BotonCajaMenos.Name = "BotonCajaMenos"
        Me.BotonCajaMenos.Size = New System.Drawing.Size(33, 25)
        Me.BotonCajaMenos.TabIndex = 4
        Me.BotonCajaMenos.Text = "-"
        Me.BotonCajaMenos.UseVisualStyleBackColor = True
        '
        'BotonCajaMas
        '
        Me.BotonCajaMas.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.BotonCajaMas.Location = New System.Drawing.Point(477, 1)
        Me.BotonCajaMas.Margin = New System.Windows.Forms.Padding(4)
        Me.BotonCajaMas.Name = "BotonCajaMas"
        Me.BotonCajaMas.Size = New System.Drawing.Size(33, 25)
        Me.BotonCajaMas.TabIndex = 3
        Me.BotonCajaMas.Text = "+"
        Me.BotonCajaMas.UseVisualStyleBackColor = True
        '
        'EtiquetaCajaTitulo
        '
        Me.EtiquetaCajaTitulo.AutoSize = True
        Me.EtiquetaCajaTitulo.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.EtiquetaCajaTitulo.ForeColor = System.Drawing.SystemColors.HighlightText
        Me.EtiquetaCajaTitulo.Location = New System.Drawing.Point(8, 4)
        Me.EtiquetaCajaTitulo.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.EtiquetaCajaTitulo.Name = "EtiquetaCajaTitulo"
        Me.EtiquetaCajaTitulo.Size = New System.Drawing.Size(226, 20)
        Me.EtiquetaCajaTitulo.TabIndex = 0
        Me.EtiquetaCajaTitulo.Text = "Petty Cash Reconciliation"
        '
        'compra_tipo
        '
        Me.compra_tipo.HeaderText = "Type"
        Me.compra_tipo.Name = "compra_tipo"
        Me.compra_tipo.ReadOnly = True
        Me.compra_tipo.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        Me.compra_tipo.Visible = False
        Me.compra_tipo.Width = 30
        '
        'compra_ciclo
        '
        Me.compra_ciclo.HeaderText = "Year"
        Me.compra_ciclo.Name = "compra_ciclo"
        Me.compra_ciclo.Visible = False
        '
        'compra_numero
        '
        Me.compra_numero.HeaderText = "Number"
        Me.compra_numero.Name = "compra_numero"
        Me.compra_numero.Visible = False
        '
        'compra_moneda
        '
        Me.compra_moneda.HeaderText = "Currency"
        Me.compra_moneda.Name = "compra_moneda"
        Me.compra_moneda.Visible = False
        '
        'compra_tasa
        '
        Me.compra_tasa.HeaderText = "Exchange Rate"
        Me.compra_tasa.Name = "compra_tasa"
        Me.compra_tasa.ReadOnly = True
        Me.compra_tasa.Visible = False
        Me.compra_tasa.Width = 65
        '
        'compra_cambio
        '
        Me.compra_cambio.HeaderText = "Alternate Exchange Rate"
        Me.compra_cambio.Name = "compra_cambio"
        Me.compra_cambio.ReadOnly = True
        Me.compra_cambio.Visible = False
        Me.compra_cambio.Width = 65
        '
        'compra_marca
        '
        DataGridViewCellStyle8.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        DataGridViewCellStyle8.BackColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle8.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.compra_marca.DefaultCellStyle = DataGridViewCellStyle8
        Me.compra_marca.HeaderText = ""
        Me.compra_marca.Name = "compra_marca"
        Me.compra_marca.ReadOnly = True
        Me.compra_marca.Width = 20
        '
        'compra_descripcion
        '
        Me.compra_descripcion.HeaderText = "Description"
        Me.compra_descripcion.Name = "compra_descripcion"
        Me.compra_descripcion.ReadOnly = True
        Me.compra_descripcion.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        Me.compra_descripcion.Width = 210
        '
        'col_DocumentoTipo
        '
        Me.col_DocumentoTipo.HeaderText = "Document"
        Me.col_DocumentoTipo.Name = "col_DocumentoTipo"
        Me.col_DocumentoTipo.ReadOnly = True
        Me.col_DocumentoTipo.Width = 77
        '
        'compra_monto
        '
        Me.compra_monto.HeaderText = "Amount"
        Me.compra_monto.Name = "compra_monto"
        Me.compra_monto.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        '
        'compra_cuenta
        '
        Me.compra_cuenta.HeaderText = "Account"
        Me.compra_cuenta.Name = "compra_cuenta"
        Me.compra_cuenta.Visible = False
        '
        'compra_ref_ciclo
        '
        Me.compra_ref_ciclo.HeaderText = "Year"
        Me.compra_ref_ciclo.Name = "compra_ref_ciclo"
        Me.compra_ref_ciclo.Visible = False
        '
        'compra_ref_numero
        '
        Me.compra_ref_numero.HeaderText = "Number"
        Me.compra_ref_numero.Name = "compra_ref_numero"
        Me.compra_ref_numero.Visible = False
        '
        'compra_factura
        '
        Me.compra_factura.HeaderText = "Amount Fact"
        Me.compra_factura.Name = "compra_factura"
        Me.compra_factura.Visible = False
        '
        'usrBancoDocumento
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.Controls.Add(Me.GrupoDeposito)
        Me.Controls.Add(Me.GrupoCuenta)
        Me.Controls.Add(Me.PanelVentas)
        Me.Controls.Add(Me.PanelCaja)
        Me.Controls.Add(Me.PanelCompras)
        Me.Controls.Add(Me.Grupo3)
        Me.Controls.Add(Me.Grupo2)
        Me.Controls.Add(Me.Grupo1)
        Me.Controls.Add(Me.PanelLetras)
        Me.Controls.Add(Me.PanelTransaccion)
        Me.Controls.Add(Me.GrupoEmpresa)
        Me.Controls.Add(Me.GrupoDocumento)
        Me.Controls.Add(Me.PanelCheques)
        Me.Margin = New System.Windows.Forms.Padding(4)
        Me.Name = "usrBancoDocumento"
        Me.Size = New System.Drawing.Size(1093, 535)
        Me.GrupoDocumento.ResumeLayout(False)
        Me.GrupoDocumento.PerformLayout()
        Me.GrupoEmpresa.ResumeLayout(False)
        Me.GrupoEmpresa.PerformLayout()
        Me.GrupoDeposito.ResumeLayout(False)
        Me.GrupoDeposito.PerformLayout()
        Me.PanelCheques.ResumeLayout(False)
        CType(Me.Cheques, System.ComponentModel.ISupportInitialize).EndInit()
        Me.PanelChequesTitulo.ResumeLayout(False)
        Me.PanelChequesTitulo.PerformLayout()
        Me.PanelTransaccion.ResumeLayout(False)
        Me.PanelTransaccion.PerformLayout()
        Me.PanelLetras.ResumeLayout(False)
        Me.PanelLetras.PerformLayout()
        Me.PanelVentas.ResumeLayout(False)
        Me.PanelVentas.PerformLayout()
        CType(Me.Ventas, System.ComponentModel.ISupportInitialize).EndInit()
        Me.PanelVentasTitulo.ResumeLayout(False)
        Me.PanelVentasTitulo.PerformLayout()
        Me.GrupoCuenta.ResumeLayout(False)
        Me.GrupoCuenta.PerformLayout()
        Me.PanelCompras.ResumeLayout(False)
        Me.PanelCompras.PerformLayout()
        CType(Me.Compras, System.ComponentModel.ISupportInitialize).EndInit()
        Me.PanelComprasTitulo.ResumeLayout(False)
        Me.PanelComprasTitulo.PerformLayout()
        Me.PanelCaja.ResumeLayout(False)
        Me.PanelCaja.PerformLayout()
        CType(Me.Caja, System.ComponentModel.ISupportInitialize).EndInit()
        Me.PanelCajaTitulo.ResumeLayout(False)
        Me.PanelCajaTitulo.PerformLayout()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents GrupoDocumento As GroupBox
    Friend WithEvents CeldaDocumento As TextBox
    Friend WithEvents EtiquetaDocumento As Label
    Friend WithEvents EtiquetaFecha As Label
    Friend WithEvents BotonDocumento As Button
    Friend WithEvents Fecha As DateTimePicker
    Friend WithEvents CasillaSecreto As System.Windows.Forms.CheckBox
    Friend WithEvents CeldaNumero As TextBox
    Friend WithEvents EtiquetaNumero As Label
    Friend WithEvents CeldaConcepto As TextBox
    Friend WithEvents EtiquetaConcepto As Label
    Friend WithEvents CasillaCobrado As System.Windows.Forms.CheckBox
    Friend WithEvents CasillaAnulado As System.Windows.Forms.CheckBox
    Friend WithEvents CeldaMonto As TextBox
    Friend WithEvents EtiquetaMonto As Label
    Friend WithEvents CeldaTasa As TextBox
    Friend WithEvents EtiquetaTasa As Label
    Friend WithEvents CeldaReferencia As TextBox
    Friend WithEvents EtiquetaReferencia As Label
    Friend WithEvents CeldaGastos As TextBox
    Friend WithEvents EtiquetaGastos As Label
    Friend WithEvents CeldaNotas As TextBox
    Friend WithEvents EtiquetaNotas As Label
    Friend WithEvents BotonBuscar As Button
    Friend WithEvents CasillaRevisado As System.Windows.Forms.CheckBox
    Friend WithEvents BotonPoliza As Button
    Friend WithEvents Imagenes As ImageList
    Friend WithEvents BotonPresupuesto As Button
    Friend WithEvents GrupoEmpresa As GroupBox
    Friend WithEvents BotonEmpresa As Button
    Friend WithEvents CeldaEmpresa As TextBox
    Friend WithEvents CasillaProveedores As System.Windows.Forms.CheckBox
    Friend WithEvents CeldaPersona As TextBox
    Friend WithEvents EtiquetaEmisor As Label
    Friend WithEvents Referencia As Label
    Friend WithEvents GrupoDeposito As GroupBox
    Friend WithEvents CeldaOtrosBancos As TextBox
    Friend WithEvents EtiquetaOtros As Label
    Friend WithEvents CeldaCheques As TextBox
    Friend WithEvents EtiquetaCheques As Label
    Friend WithEvents CeldaEfectivo As TextBox
    Friend WithEvents EtiquetaEfectivo As Label
    Friend WithEvents CeldaTotalDeposito As TextBox
    Friend WithEvents EtiquetaTotalDeposito As Label
    Friend WithEvents PanelCheques As Panel
    Friend WithEvents PanelChequesTitulo As Panel
    Friend WithEvents PanelTransaccion As Panel
    Friend WithEvents EtiquetaChequesTitulo As Label
    Friend WithEvents EtiquetaTituloTransaccion As Label
    Friend WithEvents BotonTransaccion As Button
    Friend WithEvents Cheques As DataGridView
    Friend WithEvents BotonChequeMenos As Button
    Friend WithEvents BotonChequeMas As Button
    Friend WithEvents PanelLetras As Panel
    Friend WithEvents EtiquetaLetras As Label
    Friend WithEvents PanelVentas As Panel
    Friend WithEvents Ventas As DataGridView
    Friend WithEvents PanelVentasTitulo As Panel
    Friend WithEvents BotonVentaMenos As Button
    Friend WithEvents BotonVentaMas As Button
    Friend WithEvents EtiquetaVentasTitulo As Label
    Friend WithEvents EtiquetaVentaTotal As Label
    Friend WithEvents CeldaTotalVenta As TextBox
    Friend WithEvents CeldaID As TextBox
    Friend WithEvents cheque_fecha As DataGridViewTextBoxColumn
    Friend WithEvents cheque_emisor As DataGridViewTextBoxColumn
    Friend WithEvents cheque_numero As DataGridViewTextBoxColumn
    Friend WithEvents cheque_monto As DataGridViewTextBoxColumn
    Friend WithEvents cheque_estado As DataGridViewTextBoxColumn
    Friend WithEvents InfoTexto As ToolTip
    Friend WithEvents Grupo1 As GroupBox
    Friend WithEvents Grupo2 As GroupBox
    Friend WithEvents Grupo3 As GroupBox
    Friend WithEvents EtiquetaTransaccion As Label
    Friend WithEvents GrupoCuenta As GroupBox
    Friend WithEvents EtiquetaCuentaNombre As Label
    Friend WithEvents CeldaCuentaNombre As TextBox
    Friend WithEvents CasillaExterna As System.Windows.Forms.CheckBox
    Friend WithEvents EtiquetaCuenta As Label
    Friend WithEvents BotonCC As Button
    Friend WithEvents CeldaCuenta As TextBox
    Friend WithEvents BotonVentaCuenta As Button
    Friend WithEvents BotonVentaGasto As Button
    Friend WithEvents PanelCompras As Panel
    Friend WithEvents CeldaTotalCompra As TextBox
    Friend WithEvents EtiquetaCompraTotal As Label
    Friend WithEvents Compras As DataGridView
    Friend WithEvents PanelComprasTitulo As Panel
    Friend WithEvents BotonCompraGasto As Button
    Friend WithEvents BotonCompraCuenta As Button
    Friend WithEvents BotonCompraMenos As Button
    Friend WithEvents BotonCompraMas As Button
    Friend WithEvents EtiquetaComprasTitulo As Label
    Friend WithEvents CeldaAnticipo As TextBox
    Friend WithEvents EtiquetaAnticipo As Label
    Friend WithEvents PanelCaja As Panel
    Friend WithEvents CeldaTotalCaja As TextBox
    Friend WithEvents EtiquetaCajaTotal As Label
    Friend WithEvents Caja As DataGridView
    Friend WithEvents PanelCajaTitulo As Panel
    Friend WithEvents BotonCajaMenos As Button
    Friend WithEvents BotonCajaMas As Button
    Friend WithEvents EtiquetaCajaTitulo As Label
    Friend WithEvents CeldaDiferencia As TextBox
    Friend WithEvents caja_documento As DataGridViewTextBoxColumn
    Friend WithEvents caja_numero As DataGridViewTextBoxColumn
    Friend WithEvents caja_fecha As DataGridViewTextBoxColumn
    Friend WithEvents caja_nombre As DataGridViewTextBoxColumn
    Friend WithEvents caja_moneda As DataGridViewTextBoxColumn
    Friend WithEvents caja_total As DataGridViewTextBoxColumn
    Friend WithEvents caja_parcial As DataGridViewTextBoxColumn
    Friend WithEvents caja_concepto As DataGridViewTextBoxColumn
    Friend WithEvents EtiquetaCajaDiferencia As Label
    Friend WithEvents EtiquetaCajaFecha As Label
    Friend WithEvents EtiquetaID As Label
    Friend WithEvents venta_tipo As DataGridViewTextBoxColumn
    Friend WithEvents venta_ciclo As DataGridViewTextBoxColumn
    Friend WithEvents venta_grupo As DataGridViewTextBoxColumn
    Friend WithEvents venta_numero As DataGridViewTextBoxColumn
    Friend WithEvents venta_serie As DataGridViewTextBoxColumn
    Friend WithEvents venta_fecha As DataGridViewTextBoxColumn
    Friend WithEvents venta_moneda As DataGridViewTextBoxColumn
    Friend WithEvents venta_tasa As DataGridViewTextBoxColumn
    Friend WithEvents venta_ref As DataGridViewTextBoxColumn
    Friend WithEvents venta_monto As DataGridViewTextBoxColumn
    Friend WithEvents venta_total As DataGridViewTextBoxColumn
    Friend WithEvents venta_id As DataGridViewTextBoxColumn
    Friend WithEvents ventas_numero2 As DataGridViewTextBoxColumn
    Friend WithEvents compra_tipo As DataGridViewTextBoxColumn
    Friend WithEvents compra_ciclo As DataGridViewTextBoxColumn
    Friend WithEvents compra_numero As DataGridViewTextBoxColumn
    Friend WithEvents compra_moneda As DataGridViewTextBoxColumn
    Friend WithEvents compra_tasa As DataGridViewTextBoxColumn
    Friend WithEvents compra_cambio As DataGridViewTextBoxColumn
    Friend WithEvents compra_marca As DataGridViewTextBoxColumn
    Friend WithEvents compra_descripcion As DataGridViewTextBoxColumn
    Friend WithEvents col_DocumentoTipo As DataGridViewTextBoxColumn
    Friend WithEvents compra_monto As DataGridViewTextBoxColumn
    Friend WithEvents compra_cuenta As DataGridViewTextBoxColumn
    Friend WithEvents compra_ref_ciclo As DataGridViewTextBoxColumn
    Friend WithEvents compra_ref_numero As DataGridViewTextBoxColumn
    Friend WithEvents compra_factura As DataGridViewTextBoxColumn
End Class
