﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class usrBancoCuenta
    Inherits System.Windows.Forms.UserControl

    'UserControl reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(usrBancoCuenta))
        Dim DataGridViewCellStyle1 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle2 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle3 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle4 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle5 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle6 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Me.GrupoDatos = New System.Windows.Forms.GroupBox()
        Me.EtiquetaSaldo = New System.Windows.Forms.Label()
        Me.CeldaSaldo = New System.Windows.Forms.TextBox()
        Me.EtiquetaCheque = New System.Windows.Forms.Label()
        Me.BotonUltimoCheque = New System.Windows.Forms.Button()
        Me.CeldaCheque = New System.Windows.Forms.TextBox()
        Me.BotonContable = New System.Windows.Forms.Button()
        Me.CeldaContable = New System.Windows.Forms.TextBox()
        Me.EtiquetaContable = New System.Windows.Forms.Label()
        Me.CeldaPlazo = New System.Windows.Forms.TextBox()
        Me.EtiquetaPlazo = New System.Windows.Forms.Label()
        Me.CeldaSobregiro = New System.Windows.Forms.TextBox()
        Me.EtiquetaSobregiro = New System.Windows.Forms.Label()
        Me.CeldaDivisa = New System.Windows.Forms.TextBox()
        Me.BotonMoneda = New System.Windows.Forms.Button()
        Me.CeldaMoneda = New System.Windows.Forms.TextBox()
        Me.EtiquetaMoneda = New System.Windows.Forms.Label()
        Me.CeldaContacto = New System.Windows.Forms.TextBox()
        Me.EtiquetaContacto = New System.Windows.Forms.Label()
        Me.CeldaDescripcion = New System.Windows.Forms.TextBox()
        Me.EtiquetaDescripcion = New System.Windows.Forms.Label()
        Me.CeldaNombre = New System.Windows.Forms.TextBox()
        Me.EtiquetaNombre = New System.Windows.Forms.Label()
        Me.BotonBanco = New System.Windows.Forms.Button()
        Me.CeldaBanco = New System.Windows.Forms.TextBox()
        Me.EtiquetaBanco = New System.Windows.Forms.Label()
        Me.BotonTipoCuenta = New System.Windows.Forms.Button()
        Me.CeldaTipo = New System.Windows.Forms.TextBox()
        Me.EtiquetaTipo = New System.Windows.Forms.Label()
        Me.CeldaNumero = New System.Windows.Forms.TextBox()
        Me.EtiquetaNumero = New System.Windows.Forms.Label()
        Me.CeldaCodigo = New System.Windows.Forms.TextBox()
        Me.EtiquetaCodigo = New System.Windows.Forms.Label()
        Me.BotonDeposito = New System.Windows.Forms.Button()
        Me.Imagenes = New System.Windows.Forms.ImageList(Me.components)
        Me.BotonCredito = New System.Windows.Forms.Button()
        Me.BotonCheque = New System.Windows.Forms.Button()
        Me.BotonDebito = New System.Windows.Forms.Button()
        Me.CuadroFiltro = New System.Windows.Forms.Panel()
        Me.BotonConfigurarCheque = New System.Windows.Forms.Button()
        Me.BotonFiltroImprimir = New System.Windows.Forms.Button()
        Me.BotonActualizar = New System.Windows.Forms.Button()
        Me.FiltroHasta = New System.Windows.Forms.DateTimePicker()
        Me.EtiquetaFiltroY = New System.Windows.Forms.Label()
        Me.FiltroDesde = New System.Windows.Forms.DateTimePicker()
        Me.EtiquetaFiltroEntre = New System.Windows.Forms.Label()
        Me.BotonFiltroTipo = New System.Windows.Forms.Button()
        Me.FiltroTipo = New System.Windows.Forms.TextBox()
        Me.PanelReserva = New System.Windows.Forms.Panel()
        Me.CeldaReserva = New System.Windows.Forms.TextBox()
        Me.EtiquetaReserva = New System.Windows.Forms.Label()
        Me.GrupoInformacion = New System.Windows.Forms.GroupBox()
        Me.BotonConciliacion = New System.Windows.Forms.Button()
        Me.EtiquetaColorCentro = New System.Windows.Forms.Label()
        Me.ColorCentro = New System.Windows.Forms.Label()
        Me.EtiquetaColorPresupuesto = New System.Windows.Forms.Label()
        Me.ColorPresupuesto = New System.Windows.Forms.Label()
        Me.EtiquetaColorAnulado = New System.Windows.Forms.Label()
        Me.ColorAnulado = New System.Windows.Forms.Label()
        Me.EtiquetaColorSinPoliza = New System.Windows.Forms.Label()
        Me.ColorSinPoliza = New System.Windows.Forms.Label()
        Me.Reserva = New System.Windows.Forms.DataGridView()
        Me.Movimiento = New System.Windows.Forms.DataGridView()
        Me.tipo = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.ciclo = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.numero = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.fecha = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.documento = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.referencia = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.dato = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.credito = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.debito = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.saldo = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.concepto = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.poliza = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.costos = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.presupuesto = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.estado = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.privado = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.GrupoDatos.SuspendLayout()
        Me.CuadroFiltro.SuspendLayout()
        Me.PanelReserva.SuspendLayout()
        Me.GrupoInformacion.SuspendLayout()
        CType(Me.Reserva, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Movimiento, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'GrupoDatos
        '
        Me.GrupoDatos.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.GrupoDatos.Controls.Add(Me.EtiquetaSaldo)
        Me.GrupoDatos.Controls.Add(Me.CeldaSaldo)
        Me.GrupoDatos.Controls.Add(Me.EtiquetaCheque)
        Me.GrupoDatos.Controls.Add(Me.BotonUltimoCheque)
        Me.GrupoDatos.Controls.Add(Me.CeldaCheque)
        Me.GrupoDatos.Controls.Add(Me.BotonContable)
        Me.GrupoDatos.Controls.Add(Me.CeldaContable)
        Me.GrupoDatos.Controls.Add(Me.EtiquetaContable)
        Me.GrupoDatos.Controls.Add(Me.CeldaPlazo)
        Me.GrupoDatos.Controls.Add(Me.EtiquetaPlazo)
        Me.GrupoDatos.Controls.Add(Me.CeldaSobregiro)
        Me.GrupoDatos.Controls.Add(Me.EtiquetaSobregiro)
        Me.GrupoDatos.Controls.Add(Me.CeldaDivisa)
        Me.GrupoDatos.Controls.Add(Me.BotonMoneda)
        Me.GrupoDatos.Controls.Add(Me.CeldaMoneda)
        Me.GrupoDatos.Controls.Add(Me.EtiquetaMoneda)
        Me.GrupoDatos.Controls.Add(Me.CeldaContacto)
        Me.GrupoDatos.Controls.Add(Me.EtiquetaContacto)
        Me.GrupoDatos.Controls.Add(Me.CeldaDescripcion)
        Me.GrupoDatos.Controls.Add(Me.EtiquetaDescripcion)
        Me.GrupoDatos.Controls.Add(Me.CeldaNombre)
        Me.GrupoDatos.Controls.Add(Me.EtiquetaNombre)
        Me.GrupoDatos.Controls.Add(Me.BotonBanco)
        Me.GrupoDatos.Controls.Add(Me.CeldaBanco)
        Me.GrupoDatos.Controls.Add(Me.EtiquetaBanco)
        Me.GrupoDatos.Controls.Add(Me.BotonTipoCuenta)
        Me.GrupoDatos.Controls.Add(Me.CeldaTipo)
        Me.GrupoDatos.Controls.Add(Me.EtiquetaTipo)
        Me.GrupoDatos.Controls.Add(Me.CeldaNumero)
        Me.GrupoDatos.Controls.Add(Me.EtiquetaNumero)
        Me.GrupoDatos.Controls.Add(Me.CeldaCodigo)
        Me.GrupoDatos.Controls.Add(Me.EtiquetaCodigo)
        Me.GrupoDatos.Location = New System.Drawing.Point(17, 7)
        Me.GrupoDatos.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.GrupoDatos.Name = "GrupoDatos"
        Me.GrupoDatos.Padding = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.GrupoDatos.Size = New System.Drawing.Size(1060, 234)
        Me.GrupoDatos.TabIndex = 0
        Me.GrupoDatos.TabStop = False
        Me.GrupoDatos.Text = "Bank Account"
        '
        'EtiquetaSaldo
        '
        Me.EtiquetaSaldo.AutoSize = True
        Me.EtiquetaSaldo.Font = New System.Drawing.Font("Microsoft Sans Serif", 6.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.EtiquetaSaldo.Location = New System.Drawing.Point(900, 169)
        Me.EtiquetaSaldo.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.EtiquetaSaldo.Name = "EtiquetaSaldo"
        Me.EtiquetaSaldo.Size = New System.Drawing.Size(128, 15)
        Me.EtiquetaSaldo.TabIndex = 30
        Me.EtiquetaSaldo.Text = "Bank account balance"
        '
        'CeldaSaldo
        '
        Me.CeldaSaldo.BackColor = System.Drawing.SystemColors.Info
        Me.CeldaSaldo.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.CeldaSaldo.Location = New System.Drawing.Point(903, 187)
        Me.CeldaSaldo.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.CeldaSaldo.MaxLength = 20
        Me.CeldaSaldo.Name = "CeldaSaldo"
        Me.CeldaSaldo.ReadOnly = True
        Me.CeldaSaldo.Size = New System.Drawing.Size(136, 24)
        Me.CeldaSaldo.TabIndex = 31
        Me.CeldaSaldo.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'EtiquetaCheque
        '
        Me.EtiquetaCheque.AutoSize = True
        Me.EtiquetaCheque.Font = New System.Drawing.Font("Microsoft Sans Serif", 6.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.EtiquetaCheque.Location = New System.Drawing.Point(677, 169)
        Me.EtiquetaCheque.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.EtiquetaCheque.Name = "EtiquetaCheque"
        Me.EtiquetaCheque.Size = New System.Drawing.Size(128, 15)
        Me.EtiquetaCheque.TabIndex = 27
        Me.EtiquetaCheque.Text = "Current check number"
        '
        'BotonUltimoCheque
        '
        Me.BotonUltimoCheque.Location = New System.Drawing.Point(813, 187)
        Me.BotonUltimoCheque.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.BotonUltimoCheque.Name = "BotonUltimoCheque"
        Me.BotonUltimoCheque.Size = New System.Drawing.Size(33, 25)
        Me.BotonUltimoCheque.TabIndex = 29
        Me.BotonUltimoCheque.Text = "..."
        Me.BotonUltimoCheque.UseVisualStyleBackColor = True
        '
        'CeldaCheque
        '
        Me.CeldaCheque.BackColor = System.Drawing.SystemColors.GradientInactiveCaption
        Me.CeldaCheque.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.CeldaCheque.Location = New System.Drawing.Point(680, 187)
        Me.CeldaCheque.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.CeldaCheque.MaxLength = 20
        Me.CeldaCheque.Name = "CeldaCheque"
        Me.CeldaCheque.ReadOnly = True
        Me.CeldaCheque.Size = New System.Drawing.Size(124, 24)
        Me.CeldaCheque.TabIndex = 28
        Me.CeldaCheque.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'BotonContable
        '
        Me.BotonContable.Location = New System.Drawing.Point(903, 122)
        Me.BotonContable.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.BotonContable.Name = "BotonContable"
        Me.BotonContable.Size = New System.Drawing.Size(33, 25)
        Me.BotonContable.TabIndex = 26
        Me.BotonContable.Text = "..."
        Me.BotonContable.UseVisualStyleBackColor = True
        '
        'CeldaContable
        '
        Me.CeldaContable.BackColor = System.Drawing.SystemColors.Info
        Me.CeldaContable.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.CeldaContable.Location = New System.Drawing.Point(680, 123)
        Me.CeldaContable.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.CeldaContable.MaxLength = 22
        Me.CeldaContable.Name = "CeldaContable"
        Me.CeldaContable.ReadOnly = True
        Me.CeldaContable.Size = New System.Drawing.Size(213, 24)
        Me.CeldaContable.TabIndex = 25
        Me.CeldaContable.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'EtiquetaContable
        '
        Me.EtiquetaContable.AutoSize = True
        Me.EtiquetaContable.Location = New System.Drawing.Point(572, 127)
        Me.EtiquetaContable.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.EtiquetaContable.Name = "EtiquetaContable"
        Me.EtiquetaContable.Size = New System.Drawing.Size(95, 17)
        Me.EtiquetaContable.TabIndex = 24
        Me.EtiquetaContable.Text = "Book Account"
        '
        'CeldaPlazo
        '
        Me.CeldaPlazo.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.CeldaPlazo.Location = New System.Drawing.Point(828, 91)
        Me.CeldaPlazo.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.CeldaPlazo.MaxLength = 2
        Me.CeldaPlazo.Name = "CeldaPlazo"
        Me.CeldaPlazo.Size = New System.Drawing.Size(65, 24)
        Me.CeldaPlazo.TabIndex = 23
        Me.CeldaPlazo.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'EtiquetaPlazo
        '
        Me.EtiquetaPlazo.AutoSize = True
        Me.EtiquetaPlazo.Location = New System.Drawing.Point(783, 95)
        Me.EtiquetaPlazo.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.EtiquetaPlazo.Name = "EtiquetaPlazo"
        Me.EtiquetaPlazo.Size = New System.Drawing.Size(41, 17)
        Me.EtiquetaPlazo.TabIndex = 22
        Me.EtiquetaPlazo.Text = "Term"
        '
        'CeldaSobregiro
        '
        Me.CeldaSobregiro.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.CeldaSobregiro.Location = New System.Drawing.Point(680, 91)
        Me.CeldaSobregiro.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.CeldaSobregiro.MaxLength = 12
        Me.CeldaSobregiro.Name = "CeldaSobregiro"
        Me.CeldaSobregiro.Size = New System.Drawing.Size(93, 24)
        Me.CeldaSobregiro.TabIndex = 21
        Me.CeldaSobregiro.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'EtiquetaSobregiro
        '
        Me.EtiquetaSobregiro.AutoSize = True
        Me.EtiquetaSobregiro.Location = New System.Drawing.Point(572, 95)
        Me.EtiquetaSobregiro.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.EtiquetaSobregiro.Name = "EtiquetaSobregiro"
        Me.EtiquetaSobregiro.Size = New System.Drawing.Size(68, 17)
        Me.EtiquetaSobregiro.TabIndex = 20
        Me.EtiquetaSobregiro.Text = "Overdraft"
        '
        'CeldaDivisa
        '
        Me.CeldaDivisa.BackColor = System.Drawing.Color.Honeydew
        Me.CeldaDivisa.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.CeldaDivisa.Location = New System.Drawing.Point(781, 59)
        Me.CeldaDivisa.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.CeldaDivisa.Name = "CeldaDivisa"
        Me.CeldaDivisa.ReadOnly = True
        Me.CeldaDivisa.Size = New System.Drawing.Size(257, 24)
        Me.CeldaDivisa.TabIndex = 19
        '
        'BotonMoneda
        '
        Me.BotonMoneda.Location = New System.Drawing.Point(741, 59)
        Me.BotonMoneda.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.BotonMoneda.Name = "BotonMoneda"
        Me.BotonMoneda.Size = New System.Drawing.Size(33, 25)
        Me.BotonMoneda.TabIndex = 18
        Me.BotonMoneda.Text = "..."
        Me.BotonMoneda.UseVisualStyleBackColor = True
        '
        'CeldaMoneda
        '
        Me.CeldaMoneda.BackColor = System.Drawing.SystemColors.Info
        Me.CeldaMoneda.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.CeldaMoneda.Location = New System.Drawing.Point(680, 59)
        Me.CeldaMoneda.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.CeldaMoneda.Name = "CeldaMoneda"
        Me.CeldaMoneda.ReadOnly = True
        Me.CeldaMoneda.Size = New System.Drawing.Size(52, 24)
        Me.CeldaMoneda.TabIndex = 17
        Me.CeldaMoneda.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'EtiquetaMoneda
        '
        Me.EtiquetaMoneda.AutoSize = True
        Me.EtiquetaMoneda.Location = New System.Drawing.Point(572, 63)
        Me.EtiquetaMoneda.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.EtiquetaMoneda.Name = "EtiquetaMoneda"
        Me.EtiquetaMoneda.Size = New System.Drawing.Size(65, 17)
        Me.EtiquetaMoneda.TabIndex = 16
        Me.EtiquetaMoneda.Text = "Currency"
        '
        'CeldaContacto
        '
        Me.CeldaContacto.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.CeldaContacto.Location = New System.Drawing.Point(680, 27)
        Me.CeldaContacto.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.CeldaContacto.MaxLength = 50
        Me.CeldaContacto.Name = "CeldaContacto"
        Me.CeldaContacto.Size = New System.Drawing.Size(359, 24)
        Me.CeldaContacto.TabIndex = 15
        '
        'EtiquetaContacto
        '
        Me.EtiquetaContacto.AutoSize = True
        Me.EtiquetaContacto.Location = New System.Drawing.Point(572, 31)
        Me.EtiquetaContacto.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.EtiquetaContacto.Name = "EtiquetaContacto"
        Me.EtiquetaContacto.Size = New System.Drawing.Size(105, 17)
        Me.EtiquetaContacto.TabIndex = 14
        Me.EtiquetaContacto.Text = "Contact Person"
        '
        'CeldaDescripcion
        '
        Me.CeldaDescripcion.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.CeldaDescripcion.Location = New System.Drawing.Point(137, 187)
        Me.CeldaDescripcion.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.CeldaDescripcion.MaxLength = 150
        Me.CeldaDescripcion.Name = "CeldaDescripcion"
        Me.CeldaDescripcion.Size = New System.Drawing.Size(399, 24)
        Me.CeldaDescripcion.TabIndex = 13
        '
        'EtiquetaDescripcion
        '
        Me.EtiquetaDescripcion.AutoSize = True
        Me.EtiquetaDescripcion.Location = New System.Drawing.Point(25, 191)
        Me.EtiquetaDescripcion.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.EtiquetaDescripcion.Name = "EtiquetaDescripcion"
        Me.EtiquetaDescripcion.Size = New System.Drawing.Size(79, 17)
        Me.EtiquetaDescripcion.TabIndex = 12
        Me.EtiquetaDescripcion.Text = "Description"
        '
        'CeldaNombre
        '
        Me.CeldaNombre.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.CeldaNombre.Location = New System.Drawing.Point(137, 155)
        Me.CeldaNombre.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.CeldaNombre.MaxLength = 100
        Me.CeldaNombre.Name = "CeldaNombre"
        Me.CeldaNombre.Size = New System.Drawing.Size(399, 24)
        Me.CeldaNombre.TabIndex = 11
        '
        'EtiquetaNombre
        '
        Me.EtiquetaNombre.AutoSize = True
        Me.EtiquetaNombre.Location = New System.Drawing.Point(25, 159)
        Me.EtiquetaNombre.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.EtiquetaNombre.Name = "EtiquetaNombre"
        Me.EtiquetaNombre.Size = New System.Drawing.Size(100, 17)
        Me.EtiquetaNombre.TabIndex = 10
        Me.EtiquetaNombre.Text = "Account Name"
        '
        'BotonBanco
        '
        Me.BotonBanco.Location = New System.Drawing.Point(412, 122)
        Me.BotonBanco.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.BotonBanco.Name = "BotonBanco"
        Me.BotonBanco.Size = New System.Drawing.Size(33, 25)
        Me.BotonBanco.TabIndex = 9
        Me.BotonBanco.Text = "..."
        Me.BotonBanco.UseVisualStyleBackColor = True
        '
        'CeldaBanco
        '
        Me.CeldaBanco.BackColor = System.Drawing.SystemColors.Info
        Me.CeldaBanco.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.CeldaBanco.Location = New System.Drawing.Point(137, 123)
        Me.CeldaBanco.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.CeldaBanco.Name = "CeldaBanco"
        Me.CeldaBanco.ReadOnly = True
        Me.CeldaBanco.Size = New System.Drawing.Size(265, 24)
        Me.CeldaBanco.TabIndex = 8
        Me.CeldaBanco.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'EtiquetaBanco
        '
        Me.EtiquetaBanco.AutoSize = True
        Me.EtiquetaBanco.Location = New System.Drawing.Point(25, 127)
        Me.EtiquetaBanco.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.EtiquetaBanco.Name = "EtiquetaBanco"
        Me.EtiquetaBanco.Size = New System.Drawing.Size(81, 17)
        Me.EtiquetaBanco.TabIndex = 7
        Me.EtiquetaBanco.Text = "Bank Name"
        '
        'BotonTipoCuenta
        '
        Me.BotonTipoCuenta.Location = New System.Drawing.Point(304, 91)
        Me.BotonTipoCuenta.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.BotonTipoCuenta.Name = "BotonTipoCuenta"
        Me.BotonTipoCuenta.Size = New System.Drawing.Size(33, 25)
        Me.BotonTipoCuenta.TabIndex = 6
        Me.BotonTipoCuenta.Text = "..."
        Me.BotonTipoCuenta.UseVisualStyleBackColor = True
        '
        'CeldaTipo
        '
        Me.CeldaTipo.BackColor = System.Drawing.SystemColors.Info
        Me.CeldaTipo.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.CeldaTipo.Location = New System.Drawing.Point(137, 91)
        Me.CeldaTipo.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.CeldaTipo.Name = "CeldaTipo"
        Me.CeldaTipo.ReadOnly = True
        Me.CeldaTipo.Size = New System.Drawing.Size(157, 24)
        Me.CeldaTipo.TabIndex = 5
        Me.CeldaTipo.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'EtiquetaTipo
        '
        Me.EtiquetaTipo.AutoSize = True
        Me.EtiquetaTipo.Location = New System.Drawing.Point(25, 95)
        Me.EtiquetaTipo.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.EtiquetaTipo.Name = "EtiquetaTipo"
        Me.EtiquetaTipo.Size = New System.Drawing.Size(95, 17)
        Me.EtiquetaTipo.TabIndex = 4
        Me.EtiquetaTipo.Text = "Account Type"
        '
        'CeldaNumero
        '
        Me.CeldaNumero.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.CeldaNumero.Location = New System.Drawing.Point(137, 59)
        Me.CeldaNumero.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.CeldaNumero.MaxLength = 50
        Me.CeldaNumero.Name = "CeldaNumero"
        Me.CeldaNumero.Size = New System.Drawing.Size(199, 24)
        Me.CeldaNumero.TabIndex = 3
        '
        'EtiquetaNumero
        '
        Me.EtiquetaNumero.AutoSize = True
        Me.EtiquetaNumero.Location = New System.Drawing.Point(25, 63)
        Me.EtiquetaNumero.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.EtiquetaNumero.Name = "EtiquetaNumero"
        Me.EtiquetaNumero.Size = New System.Drawing.Size(79, 17)
        Me.EtiquetaNumero.TabIndex = 2
        Me.EtiquetaNumero.Text = "Account N°"
        '
        'CeldaCodigo
        '
        Me.CeldaCodigo.BackColor = System.Drawing.SystemColors.Info
        Me.CeldaCodigo.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.CeldaCodigo.Location = New System.Drawing.Point(137, 27)
        Me.CeldaCodigo.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.CeldaCodigo.MaxLength = 10
        Me.CeldaCodigo.Name = "CeldaCodigo"
        Me.CeldaCodigo.ReadOnly = True
        Me.CeldaCodigo.Size = New System.Drawing.Size(79, 24)
        Me.CeldaCodigo.TabIndex = 1
        Me.CeldaCodigo.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'EtiquetaCodigo
        '
        Me.EtiquetaCodigo.AutoSize = True
        Me.EtiquetaCodigo.Location = New System.Drawing.Point(25, 31)
        Me.EtiquetaCodigo.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.EtiquetaCodigo.Name = "EtiquetaCodigo"
        Me.EtiquetaCodigo.Size = New System.Drawing.Size(41, 17)
        Me.EtiquetaCodigo.TabIndex = 0
        Me.EtiquetaCodigo.Text = "Code"
        '
        'BotonDeposito
        '
        Me.BotonDeposito.ImageAlign = System.Drawing.ContentAlignment.TopCenter
        Me.BotonDeposito.ImageIndex = 0
        Me.BotonDeposito.ImageList = Me.Imagenes
        Me.BotonDeposito.Location = New System.Drawing.Point(17, 249)
        Me.BotonDeposito.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.BotonDeposito.Name = "BotonDeposito"
        Me.BotonDeposito.Size = New System.Drawing.Size(77, 49)
        Me.BotonDeposito.TabIndex = 1
        Me.BotonDeposito.Text = "Deposit"
        Me.BotonDeposito.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.BotonDeposito.UseVisualStyleBackColor = True
        '
        'Imagenes
        '
        Me.Imagenes.ImageStream = CType(resources.GetObject("Imagenes.ImageStream"), System.Windows.Forms.ImageListStreamer)
        Me.Imagenes.TransparentColor = System.Drawing.Color.Transparent
        Me.Imagenes.Images.SetKeyName(0, "currency.ico")
        Me.Imagenes.Images.SetKeyName(1, "add2.ico")
        Me.Imagenes.Images.SetKeyName(2, "pencil tool.ico")
        Me.Imagenes.Images.SetKeyName(3, "minus.ico")
        Me.Imagenes.Images.SetKeyName(4, "recycle.ico")
        Me.Imagenes.Images.SetKeyName(5, "header and footer switch.ico")
        Me.Imagenes.Images.SetKeyName(6, "gear.ico")
        '
        'BotonCredito
        '
        Me.BotonCredito.ImageAlign = System.Drawing.ContentAlignment.TopCenter
        Me.BotonCredito.ImageIndex = 1
        Me.BotonCredito.ImageList = Me.Imagenes
        Me.BotonCredito.Location = New System.Drawing.Point(96, 249)
        Me.BotonCredito.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.BotonCredito.Name = "BotonCredito"
        Me.BotonCredito.Size = New System.Drawing.Size(67, 49)
        Me.BotonCredito.TabIndex = 2
        Me.BotonCredito.Text = "Credit"
        Me.BotonCredito.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.BotonCredito.UseVisualStyleBackColor = True
        '
        'BotonCheque
        '
        Me.BotonCheque.ImageAlign = System.Drawing.ContentAlignment.TopCenter
        Me.BotonCheque.ImageIndex = 2
        Me.BotonCheque.ImageList = Me.Imagenes
        Me.BotonCheque.Location = New System.Drawing.Point(171, 249)
        Me.BotonCheque.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.BotonCheque.Name = "BotonCheque"
        Me.BotonCheque.Size = New System.Drawing.Size(73, 49)
        Me.BotonCheque.TabIndex = 3
        Me.BotonCheque.Text = "Check"
        Me.BotonCheque.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.BotonCheque.UseVisualStyleBackColor = True
        '
        'BotonDebito
        '
        Me.BotonDebito.ImageAlign = System.Drawing.ContentAlignment.TopCenter
        Me.BotonDebito.ImageIndex = 3
        Me.BotonDebito.ImageList = Me.Imagenes
        Me.BotonDebito.Location = New System.Drawing.Point(245, 249)
        Me.BotonDebito.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.BotonDebito.Name = "BotonDebito"
        Me.BotonDebito.Size = New System.Drawing.Size(67, 49)
        Me.BotonDebito.TabIndex = 4
        Me.BotonDebito.Text = "Debit"
        Me.BotonDebito.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.BotonDebito.UseVisualStyleBackColor = True
        '
        'CuadroFiltro
        '
        Me.CuadroFiltro.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.CuadroFiltro.BackColor = System.Drawing.SystemColors.Info
        Me.CuadroFiltro.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.CuadroFiltro.Controls.Add(Me.BotonConfigurarCheque)
        Me.CuadroFiltro.Controls.Add(Me.BotonFiltroImprimir)
        Me.CuadroFiltro.Controls.Add(Me.BotonActualizar)
        Me.CuadroFiltro.Controls.Add(Me.FiltroHasta)
        Me.CuadroFiltro.Controls.Add(Me.EtiquetaFiltroY)
        Me.CuadroFiltro.Controls.Add(Me.FiltroDesde)
        Me.CuadroFiltro.Controls.Add(Me.EtiquetaFiltroEntre)
        Me.CuadroFiltro.Controls.Add(Me.BotonFiltroTipo)
        Me.CuadroFiltro.Controls.Add(Me.FiltroTipo)
        Me.CuadroFiltro.Location = New System.Drawing.Point(321, 249)
        Me.CuadroFiltro.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.CuadroFiltro.Name = "CuadroFiltro"
        Me.CuadroFiltro.Size = New System.Drawing.Size(755, 49)
        Me.CuadroFiltro.TabIndex = 5
        '
        'BotonConfigurarCheque
        '
        Me.BotonConfigurarCheque.ImageIndex = 6
        Me.BotonConfigurarCheque.ImageList = Me.Imagenes
        Me.BotonConfigurarCheque.Location = New System.Drawing.Point(707, 12)
        Me.BotonConfigurarCheque.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.BotonConfigurarCheque.Name = "BotonConfigurarCheque"
        Me.BotonConfigurarCheque.Size = New System.Drawing.Size(33, 27)
        Me.BotonConfigurarCheque.TabIndex = 8
        Me.BotonConfigurarCheque.UseVisualStyleBackColor = True
        '
        'BotonFiltroImprimir
        '
        Me.BotonFiltroImprimir.Location = New System.Drawing.Point(632, 12)
        Me.BotonFiltroImprimir.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.BotonFiltroImprimir.Name = "BotonFiltroImprimir"
        Me.BotonFiltroImprimir.Size = New System.Drawing.Size(67, 27)
        Me.BotonFiltroImprimir.TabIndex = 7
        Me.BotonFiltroImprimir.Text = "Print"
        Me.BotonFiltroImprimir.UseVisualStyleBackColor = True
        '
        'BotonActualizar
        '
        Me.BotonActualizar.Location = New System.Drawing.Point(544, 12)
        Me.BotonActualizar.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.BotonActualizar.Name = "BotonActualizar"
        Me.BotonActualizar.Size = New System.Drawing.Size(80, 27)
        Me.BotonActualizar.TabIndex = 6
        Me.BotonActualizar.Text = "Refresh"
        Me.BotonActualizar.UseVisualStyleBackColor = True
        '
        'FiltroHasta
        '
        Me.FiltroHasta.CustomFormat = "dd/MM/yyyy"
        Me.FiltroHasta.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.FiltroHasta.Format = System.Windows.Forms.DateTimePickerFormat.Custom
        Me.FiltroHasta.Location = New System.Drawing.Point(405, 12)
        Me.FiltroHasta.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.FiltroHasta.MaxDate = New Date(2099, 12, 31, 0, 0, 0, 0)
        Me.FiltroHasta.MinDate = New Date(1901, 1, 1, 0, 0, 0, 0)
        Me.FiltroHasta.Name = "FiltroHasta"
        Me.FiltroHasta.Size = New System.Drawing.Size(125, 24)
        Me.FiltroHasta.TabIndex = 5
        Me.FiltroHasta.Value = New Date(2018, 7, 31, 12, 9, 39, 0)
        '
        'EtiquetaFiltroY
        '
        Me.EtiquetaFiltroY.AutoSize = True
        Me.EtiquetaFiltroY.Location = New System.Drawing.Point(404, 16)
        Me.EtiquetaFiltroY.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.EtiquetaFiltroY.Name = "EtiquetaFiltroY"
        Me.EtiquetaFiltroY.Size = New System.Drawing.Size(15, 17)
        Me.EtiquetaFiltroY.TabIndex = 4
        Me.EtiquetaFiltroY.Text = "y"
        '
        'FiltroDesde
        '
        Me.FiltroDesde.CustomFormat = "dd/MM/yyyy"
        Me.FiltroDesde.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.FiltroDesde.Format = System.Windows.Forms.DateTimePickerFormat.Custom
        Me.FiltroDesde.Location = New System.Drawing.Point(264, 14)
        Me.FiltroDesde.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.FiltroDesde.MaxDate = New Date(2099, 12, 31, 0, 0, 0, 0)
        Me.FiltroDesde.MinDate = New Date(1901, 1, 1, 0, 0, 0, 0)
        Me.FiltroDesde.Name = "FiltroDesde"
        Me.FiltroDesde.Size = New System.Drawing.Size(125, 24)
        Me.FiltroDesde.TabIndex = 3
        Me.FiltroDesde.Value = New Date(2018, 7, 31, 12, 9, 39, 0)
        '
        'EtiquetaFiltroEntre
        '
        Me.EtiquetaFiltroEntre.AutoSize = True
        Me.EtiquetaFiltroEntre.Location = New System.Drawing.Point(191, 17)
        Me.EtiquetaFiltroEntre.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.EtiquetaFiltroEntre.Name = "EtiquetaFiltroEntre"
        Me.EtiquetaFiltroEntre.Size = New System.Drawing.Size(62, 17)
        Me.EtiquetaFiltroEntre.TabIndex = 2
        Me.EtiquetaFiltroEntre.Text = "Between"
        '
        'BotonFiltroTipo
        '
        Me.BotonFiltroTipo.Location = New System.Drawing.Point(145, 12)
        Me.BotonFiltroTipo.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.BotonFiltroTipo.Name = "BotonFiltroTipo"
        Me.BotonFiltroTipo.Size = New System.Drawing.Size(33, 27)
        Me.BotonFiltroTipo.TabIndex = 1
        Me.BotonFiltroTipo.Text = "..."
        Me.BotonFiltroTipo.UseVisualStyleBackColor = True
        '
        'FiltroTipo
        '
        Me.FiltroTipo.BackColor = System.Drawing.SystemColors.Info
        Me.FiltroTipo.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.FiltroTipo.Location = New System.Drawing.Point(13, 12)
        Me.FiltroTipo.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.FiltroTipo.Name = "FiltroTipo"
        Me.FiltroTipo.ReadOnly = True
        Me.FiltroTipo.Size = New System.Drawing.Size(123, 24)
        Me.FiltroTipo.TabIndex = 0
        Me.FiltroTipo.Text = "(Show all...)"
        Me.FiltroTipo.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'PanelReserva
        '
        Me.PanelReserva.Anchor = CType(((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.PanelReserva.BackColor = System.Drawing.Color.SteelBlue
        Me.PanelReserva.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.PanelReserva.Controls.Add(Me.CeldaReserva)
        Me.PanelReserva.Controls.Add(Me.EtiquetaReserva)
        Me.PanelReserva.Location = New System.Drawing.Point(17, 422)
        Me.PanelReserva.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.PanelReserva.Name = "PanelReserva"
        Me.PanelReserva.Size = New System.Drawing.Size(701, 34)
        Me.PanelReserva.TabIndex = 7
        '
        'CeldaReserva
        '
        Me.CeldaReserva.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.CeldaReserva.BackColor = System.Drawing.SystemColors.Info
        Me.CeldaReserva.Location = New System.Drawing.Point(569, 4)
        Me.CeldaReserva.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.CeldaReserva.MaxLength = 20
        Me.CeldaReserva.Name = "CeldaReserva"
        Me.CeldaReserva.ReadOnly = True
        Me.CeldaReserva.Size = New System.Drawing.Size(124, 22)
        Me.CeldaReserva.TabIndex = 1
        Me.CeldaReserva.Text = "0.00"
        Me.CeldaReserva.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'EtiquetaReserva
        '
        Me.EtiquetaReserva.AutoSize = True
        Me.EtiquetaReserva.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.EtiquetaReserva.ForeColor = System.Drawing.Color.White
        Me.EtiquetaReserva.Location = New System.Drawing.Point(7, 6)
        Me.EtiquetaReserva.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.EtiquetaReserva.Name = "EtiquetaReserva"
        Me.EtiquetaReserva.Size = New System.Drawing.Size(241, 20)
        Me.EtiquetaReserva.TabIndex = 0
        Me.EtiquetaReserva.Text = "Pending checks information"
        '
        'GrupoInformacion
        '
        Me.GrupoInformacion.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.GrupoInformacion.Controls.Add(Me.BotonConciliacion)
        Me.GrupoInformacion.Controls.Add(Me.EtiquetaColorCentro)
        Me.GrupoInformacion.Controls.Add(Me.ColorCentro)
        Me.GrupoInformacion.Controls.Add(Me.EtiquetaColorPresupuesto)
        Me.GrupoInformacion.Controls.Add(Me.ColorPresupuesto)
        Me.GrupoInformacion.Controls.Add(Me.EtiquetaColorAnulado)
        Me.GrupoInformacion.Controls.Add(Me.ColorAnulado)
        Me.GrupoInformacion.Controls.Add(Me.EtiquetaColorSinPoliza)
        Me.GrupoInformacion.Controls.Add(Me.ColorSinPoliza)
        Me.GrupoInformacion.Location = New System.Drawing.Point(731, 415)
        Me.GrupoInformacion.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.GrupoInformacion.Name = "GrupoInformacion"
        Me.GrupoInformacion.Padding = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.GrupoInformacion.Size = New System.Drawing.Size(347, 145)
        Me.GrupoInformacion.TabIndex = 9
        Me.GrupoInformacion.TabStop = False
        '
        'BotonConciliacion
        '
        Me.BotonConciliacion.ImageAlign = System.Drawing.ContentAlignment.TopCenter
        Me.BotonConciliacion.ImageIndex = 5
        Me.BotonConciliacion.ImageList = Me.Imagenes
        Me.BotonConciliacion.Location = New System.Drawing.Point(211, 25)
        Me.BotonConciliacion.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.BotonConciliacion.Name = "BotonConciliacion"
        Me.BotonConciliacion.Size = New System.Drawing.Size(96, 49)
        Me.BotonConciliacion.TabIndex = 0
        Me.BotonConciliacion.Text = "Conciliation"
        Me.BotonConciliacion.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.BotonConciliacion.UseVisualStyleBackColor = True
        '
        'EtiquetaColorCentro
        '
        Me.EtiquetaColorCentro.AutoSize = True
        Me.EtiquetaColorCentro.Location = New System.Drawing.Point(48, 110)
        Me.EtiquetaColorCentro.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.EtiquetaColorCentro.Name = "EtiquetaColorCentro"
        Me.EtiquetaColorCentro.Size = New System.Drawing.Size(104, 17)
        Me.EtiquetaColorCentro.TabIndex = 7
        Me.EtiquetaColorCentro.Text = "No Cost Center"
        '
        'ColorCentro
        '
        Me.ColorCentro.BackColor = System.Drawing.Color.Yellow
        Me.ColorCentro.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.ColorCentro.Location = New System.Drawing.Point(20, 108)
        Me.ColorCentro.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.ColorCentro.Name = "ColorCentro"
        Me.ColorCentro.Size = New System.Drawing.Size(19, 18)
        Me.ColorCentro.TabIndex = 6
        '
        'EtiquetaColorPresupuesto
        '
        Me.EtiquetaColorPresupuesto.AutoSize = True
        Me.EtiquetaColorPresupuesto.Location = New System.Drawing.Point(48, 81)
        Me.EtiquetaColorPresupuesto.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.EtiquetaColorPresupuesto.Name = "EtiquetaColorPresupuesto"
        Me.EtiquetaColorPresupuesto.Size = New System.Drawing.Size(69, 17)
        Me.EtiquetaColorPresupuesto.TabIndex = 5
        Me.EtiquetaColorPresupuesto.Text = "Budgeted"
        '
        'ColorPresupuesto
        '
        Me.ColorPresupuesto.BackColor = System.Drawing.Color.LightSteelBlue
        Me.ColorPresupuesto.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.ColorPresupuesto.Location = New System.Drawing.Point(20, 80)
        Me.ColorPresupuesto.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.ColorPresupuesto.Name = "ColorPresupuesto"
        Me.ColorPresupuesto.Size = New System.Drawing.Size(19, 18)
        Me.ColorPresupuesto.TabIndex = 4
        '
        'EtiquetaColorAnulado
        '
        Me.EtiquetaColorAnulado.AutoSize = True
        Me.EtiquetaColorAnulado.Location = New System.Drawing.Point(48, 54)
        Me.EtiquetaColorAnulado.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.EtiquetaColorAnulado.Name = "EtiquetaColorAnulado"
        Me.EtiquetaColorAnulado.Size = New System.Drawing.Size(52, 17)
        Me.EtiquetaColorAnulado.TabIndex = 3
        Me.EtiquetaColorAnulado.Text = "Voided"
        '
        'ColorAnulado
        '
        Me.ColorAnulado.BackColor = System.Drawing.Color.Red
        Me.ColorAnulado.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.ColorAnulado.Location = New System.Drawing.Point(20, 53)
        Me.ColorAnulado.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.ColorAnulado.Name = "ColorAnulado"
        Me.ColorAnulado.Size = New System.Drawing.Size(19, 18)
        Me.ColorAnulado.TabIndex = 2
        '
        'EtiquetaColorSinPoliza
        '
        Me.EtiquetaColorSinPoliza.AutoSize = True
        Me.EtiquetaColorSinPoliza.Location = New System.Drawing.Point(48, 26)
        Me.EtiquetaColorSinPoliza.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.EtiquetaColorSinPoliza.Name = "EtiquetaColorSinPoliza"
        Me.EtiquetaColorSinPoliza.Size = New System.Drawing.Size(114, 17)
        Me.EtiquetaColorSinPoliza.TabIndex = 1
        Me.EtiquetaColorSinPoliza.Text = "No Journal Entry"
        '
        'ColorSinPoliza
        '
        Me.ColorSinPoliza.BackColor = System.Drawing.Color.Orange
        Me.ColorSinPoliza.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.ColorSinPoliza.Location = New System.Drawing.Point(20, 25)
        Me.ColorSinPoliza.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.ColorSinPoliza.Name = "ColorSinPoliza"
        Me.ColorSinPoliza.Size = New System.Drawing.Size(19, 18)
        Me.ColorSinPoliza.TabIndex = 0
        '
        'Reserva
        '
        Me.Reserva.AllowUserToAddRows = False
        Me.Reserva.AllowUserToDeleteRows = False
        Me.Reserva.Anchor = CType(((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Reserva.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells
        Me.Reserva.BackgroundColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle1.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.Reserva.ColumnHeadersDefaultCellStyle = DataGridViewCellStyle1
        Me.Reserva.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        DataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle2.BackColor = System.Drawing.SystemColors.Window
        DataGridViewCellStyle2.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.ControlText
        DataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.[False]
        Me.Reserva.DefaultCellStyle = DataGridViewCellStyle2
        Me.Reserva.Location = New System.Drawing.Point(17, 457)
        Me.Reserva.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.Reserva.MultiSelect = False
        Me.Reserva.Name = "Reserva"
        Me.Reserva.ReadOnly = True
        DataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle3.BackColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle3.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle3.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle3.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle3.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.Reserva.RowHeadersDefaultCellStyle = DataGridViewCellStyle3
        Me.Reserva.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.Reserva.Size = New System.Drawing.Size(701, 103)
        Me.Reserva.TabIndex = 8
        '
        'Movimiento
        '
        Me.Movimiento.AllowUserToAddRows = False
        Me.Movimiento.AllowUserToDeleteRows = False
        Me.Movimiento.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Movimiento.BackgroundColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle4.BackColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle4.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle4.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle4.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle4.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle4.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.Movimiento.ColumnHeadersDefaultCellStyle = DataGridViewCellStyle4
        Me.Movimiento.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.Movimiento.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.tipo, Me.ciclo, Me.numero, Me.fecha, Me.documento, Me.referencia, Me.dato, Me.credito, Me.debito, Me.saldo, Me.concepto, Me.poliza, Me.costos, Me.presupuesto, Me.estado, Me.privado})
        DataGridViewCellStyle5.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle5.BackColor = System.Drawing.SystemColors.Window
        DataGridViewCellStyle5.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle5.ForeColor = System.Drawing.SystemColors.ControlText
        DataGridViewCellStyle5.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle5.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle5.WrapMode = System.Windows.Forms.DataGridViewTriState.[False]
        Me.Movimiento.DefaultCellStyle = DataGridViewCellStyle5
        Me.Movimiento.Location = New System.Drawing.Point(17, 305)
        Me.Movimiento.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Movimiento.MultiSelect = False
        Me.Movimiento.Name = "Movimiento"
        Me.Movimiento.ReadOnly = True
        DataGridViewCellStyle6.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle6.BackColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle6.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle6.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle6.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle6.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle6.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.Movimiento.RowHeadersDefaultCellStyle = DataGridViewCellStyle6
        Me.Movimiento.RowHeadersWidth = 31
        Me.Movimiento.RowTemplate.DefaultCellStyle.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Movimiento.RowTemplate.Height = 20
        Me.Movimiento.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.Movimiento.Size = New System.Drawing.Size(1060, 110)
        Me.Movimiento.TabIndex = 6
        '
        'tipo
        '
        Me.tipo.HeaderText = "Type"
        Me.tipo.Name = "tipo"
        Me.tipo.ReadOnly = True
        Me.tipo.Visible = False
        '
        'ciclo
        '
        Me.ciclo.HeaderText = "Year"
        Me.ciclo.Name = "ciclo"
        Me.ciclo.ReadOnly = True
        Me.ciclo.Visible = False
        '
        'numero
        '
        Me.numero.HeaderText = "Number"
        Me.numero.Name = "numero"
        Me.numero.ReadOnly = True
        Me.numero.Visible = False
        '
        'fecha
        '
        Me.fecha.HeaderText = "Date"
        Me.fecha.Name = "fecha"
        Me.fecha.ReadOnly = True
        Me.fecha.Width = 75
        '
        'documento
        '
        Me.documento.HeaderText = "Document"
        Me.documento.Name = "documento"
        Me.documento.ReadOnly = True
        '
        'referencia
        '
        Me.referencia.HeaderText = "Reference"
        Me.referencia.Name = "referencia"
        Me.referencia.ReadOnly = True
        Me.referencia.Width = 90
        '
        'dato
        '
        Me.dato.HeaderText = ""
        Me.dato.Name = "dato"
        Me.dato.ReadOnly = True
        Me.dato.Width = 275
        '
        'credito
        '
        Me.credito.HeaderText = "Credit"
        Me.credito.Name = "credito"
        Me.credito.ReadOnly = True
        Me.credito.Width = 80
        '
        'debito
        '
        Me.debito.HeaderText = "Debit"
        Me.debito.Name = "debito"
        Me.debito.ReadOnly = True
        Me.debito.Width = 80
        '
        'saldo
        '
        Me.saldo.HeaderText = "Balance"
        Me.saldo.Name = "saldo"
        Me.saldo.ReadOnly = True
        Me.saldo.Width = 95
        '
        'concepto
        '
        Me.concepto.HeaderText = "Memo"
        Me.concepto.Name = "concepto"
        Me.concepto.ReadOnly = True
        Me.concepto.Width = 200
        '
        'poliza
        '
        Me.poliza.HeaderText = "Ledger"
        Me.poliza.Name = "poliza"
        Me.poliza.ReadOnly = True
        Me.poliza.Visible = False
        '
        'costos
        '
        Me.costos.HeaderText = "Cost Center"
        Me.costos.Name = "costos"
        Me.costos.ReadOnly = True
        Me.costos.Visible = False
        '
        'presupuesto
        '
        Me.presupuesto.HeaderText = "Budget"
        Me.presupuesto.Name = "presupuesto"
        Me.presupuesto.ReadOnly = True
        Me.presupuesto.Visible = False
        '
        'estado
        '
        Me.estado.HeaderText = "Status"
        Me.estado.Name = "estado"
        Me.estado.ReadOnly = True
        Me.estado.Visible = False
        '
        'privado
        '
        Me.privado.HeaderText = "Confidential"
        Me.privado.MaxInputLength = 5
        Me.privado.Name = "privado"
        Me.privado.ReadOnly = True
        Me.privado.Resizable = System.Windows.Forms.DataGridViewTriState.[False]
        Me.privado.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        Me.privado.Visible = False
        '
        'usrBancoCuenta
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.Controls.Add(Me.Movimiento)
        Me.Controls.Add(Me.Reserva)
        Me.Controls.Add(Me.GrupoInformacion)
        Me.Controls.Add(Me.PanelReserva)
        Me.Controls.Add(Me.CuadroFiltro)
        Me.Controls.Add(Me.BotonDebito)
        Me.Controls.Add(Me.BotonCheque)
        Me.Controls.Add(Me.BotonCredito)
        Me.Controls.Add(Me.BotonDeposito)
        Me.Controls.Add(Me.GrupoDatos)
        Me.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.Name = "usrBancoCuenta"
        Me.Size = New System.Drawing.Size(1093, 571)
        Me.GrupoDatos.ResumeLayout(False)
        Me.GrupoDatos.PerformLayout()
        Me.CuadroFiltro.ResumeLayout(False)
        Me.CuadroFiltro.PerformLayout()
        Me.PanelReserva.ResumeLayout(False)
        Me.PanelReserva.PerformLayout()
        Me.GrupoInformacion.ResumeLayout(False)
        Me.GrupoInformacion.PerformLayout()
        CType(Me.Reserva, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Movimiento, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents GrupoDatos As GroupBox
    Friend WithEvents CeldaCodigo As TextBox
    Friend WithEvents EtiquetaCodigo As Label
    Friend WithEvents CeldaNumero As TextBox
    Friend WithEvents EtiquetaNumero As Label
    Friend WithEvents CeldaTipo As TextBox
    Friend WithEvents EtiquetaTipo As Label
    Friend WithEvents BotonTipoCuenta As Button
    Friend WithEvents CeldaDescripcion As TextBox
    Friend WithEvents EtiquetaDescripcion As Label
    Friend WithEvents CeldaNombre As TextBox
    Friend WithEvents EtiquetaNombre As Label
    Friend WithEvents BotonBanco As Button
    Friend WithEvents CeldaBanco As TextBox
    Friend WithEvents EtiquetaBanco As Label
    Friend WithEvents CeldaContacto As TextBox
    Friend WithEvents EtiquetaContacto As Label
    Friend WithEvents CeldaDivisa As TextBox
    Friend WithEvents BotonMoneda As Button
    Friend WithEvents CeldaMoneda As TextBox
    Friend WithEvents EtiquetaMoneda As Label
    Friend WithEvents CeldaSobregiro As TextBox
    Friend WithEvents EtiquetaSobregiro As Label
    Friend WithEvents CeldaPlazo As TextBox
    Friend WithEvents EtiquetaPlazo As Label
    Friend WithEvents CeldaContable As TextBox
    Friend WithEvents EtiquetaContable As Label
    Friend WithEvents BotonContable As Button
    Friend WithEvents BotonUltimoCheque As Button
    Friend WithEvents CeldaCheque As TextBox
    Friend WithEvents EtiquetaCheque As Label
    Friend WithEvents BotonDeposito As Button
    Friend WithEvents BotonCredito As Button
    Friend WithEvents BotonCheque As Button
    Friend WithEvents BotonDebito As Button
    Friend WithEvents Imagenes As ImageList
    Friend WithEvents EtiquetaSaldo As Label
    Friend WithEvents CeldaSaldo As TextBox
    Friend WithEvents CuadroFiltro As Panel
    Friend WithEvents BotonFiltroTipo As Button
    Friend WithEvents FiltroTipo As TextBox
    Friend WithEvents FiltroHasta As DateTimePicker
    Friend WithEvents EtiquetaFiltroY As Label
    Friend WithEvents FiltroDesde As DateTimePicker
    Friend WithEvents EtiquetaFiltroEntre As Label
    Friend WithEvents BotonFiltroImprimir As Button
    Friend WithEvents BotonActualizar As Button
    Friend WithEvents PanelReserva As Panel
    Friend WithEvents EtiquetaReserva As Label
    Friend WithEvents CeldaReserva As TextBox
    Friend WithEvents GrupoInformacion As GroupBox
    Friend WithEvents EtiquetaColorPresupuesto As Label
    Friend WithEvents ColorPresupuesto As Label
    Friend WithEvents EtiquetaColorAnulado As Label
    Friend WithEvents ColorAnulado As Label
    Friend WithEvents EtiquetaColorSinPoliza As Label
    Friend WithEvents ColorSinPoliza As Label
    Friend WithEvents EtiquetaColorCentro As Label
    Friend WithEvents ColorCentro As Label
    Friend WithEvents BotonConciliacion As Button
    Friend WithEvents Reserva As DataGridView
    Friend WithEvents Movimiento As DataGridView
    Friend WithEvents tipo As DataGridViewTextBoxColumn
    Friend WithEvents ciclo As DataGridViewTextBoxColumn
    Friend WithEvents numero As DataGridViewTextBoxColumn
    Friend WithEvents fecha As DataGridViewTextBoxColumn
    Friend WithEvents documento As DataGridViewTextBoxColumn
    Friend WithEvents referencia As DataGridViewTextBoxColumn
    Friend WithEvents dato As DataGridViewTextBoxColumn
    Friend WithEvents credito As DataGridViewTextBoxColumn
    Friend WithEvents debito As DataGridViewTextBoxColumn
    Friend WithEvents saldo As DataGridViewTextBoxColumn
    Friend WithEvents concepto As DataGridViewTextBoxColumn
    Friend WithEvents poliza As DataGridViewTextBoxColumn
    Friend WithEvents costos As DataGridViewTextBoxColumn
    Friend WithEvents presupuesto As DataGridViewTextBoxColumn
    Friend WithEvents estado As DataGridViewTextBoxColumn
    Friend WithEvents privado As DataGridViewTextBoxColumn
    Friend WithEvents BotonConfigurarCheque As Button
End Class
