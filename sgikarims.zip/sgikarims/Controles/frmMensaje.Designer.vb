﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class frmMensaje
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.etiquetaMensaje = New System.Windows.Forms.Label()
        Me.SuspendLayout()
        '
        'etiquetaMensaje
        '
        Me.etiquetaMensaje.Location = New System.Drawing.Point(-2, 32)
        Me.etiquetaMensaje.Name = "etiquetaMensaje"
        Me.etiquetaMensaje.Size = New System.Drawing.Size(315, 69)
        Me.etiquetaMensaje.TabIndex = 0
        Me.etiquetaMensaje.Text = "Exportando...."
        Me.etiquetaMensaje.TextAlign = System.Drawing.ContentAlignment.TopCenter
        '
        'frmMensaje
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.SystemColors.GradientInactiveCaption
        Me.ClientSize = New System.Drawing.Size(313, 134)
        Me.ControlBox = False
        Me.Controls.Add(Me.etiquetaMensaje)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow
        Me.Name = "frmMensaje"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "SGI Karims"
        Me.TopMost = True
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents etiquetaMensaje As System.Windows.Forms.Label
End Class
