﻿Public Class BarraTitulo

    Public Sub CambiarTitulo(ByVal strTitulo As String)
        CeldaTitulo.Text = strTitulo
    End Sub
    
    Private Sub BarraTitulo_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub
End Class
