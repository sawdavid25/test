﻿Public Class encabezado
    Public Event ClickNuevo(ByVal sender As System.Object, ByVal click As Boolean)
    Public Event ClickGuardar(ByVal sender As System.Object, ByVal click As Boolean)
    Public Event ClickBorrar(ByVal sender As System.Object, ByVal click As Boolean)
    Public Event ClickCerrar(ByVal sender As System.Object, ByVal click As Boolean)

    Private Sub botonNuevo_Click(sender As Object, e As EventArgs) Handles botonNuevo.Click
        RaiseEvent ClickNuevo(Me, True)
    End Sub

    Private Sub botonGuardar_Click(sender As Object, e As EventArgs) Handles botonGuardar.Click
        RaiseEvent ClickGuardar(Me, True)
    End Sub

    Private Sub botonBorrar_Click(sender As Object, e As EventArgs) Handles botonBorrar.Click
        RaiseEvent ClickBorrar(Me, True)
    End Sub

    Private Sub botonCerrar_Click(sender As Object, e As EventArgs) Handles botonCerrar.Click
        RaiseEvent ClickCerrar(Me, True)
    End Sub

End Class
