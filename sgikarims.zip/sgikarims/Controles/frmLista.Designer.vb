﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmLista
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.dtLista = New System.Windows.Forms.DataGridView()
        Me.panelBotones = New System.Windows.Forms.Panel()
        Me.botonCancelar = New System.Windows.Forms.Button()
        Me.BotonBorrar = New System.Windows.Forms.Button()
        Me.botonContinuar = New System.Windows.Forms.Button()
        Me.BarraTitulo1 = New KARIMs_SGI.BarraTitulo()
        CType(Me.dtLista, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.panelBotones.SuspendLayout()
        Me.SuspendLayout()
        '
        'dtLista
        '
        Me.dtLista.AllowUserToAddRows = False
        Me.dtLista.AllowUserToDeleteRows = False
        Me.dtLista.AllowUserToOrderColumns = True
        Me.dtLista.BackgroundColor = System.Drawing.SystemColors.Control
        Me.dtLista.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dtLista.Dock = System.Windows.Forms.DockStyle.Fill
        Me.dtLista.Location = New System.Drawing.Point(0, 86)
        Me.dtLista.Name = "dtLista"
        Me.dtLista.Size = New System.Drawing.Size(569, 233)
        Me.dtLista.TabIndex = 0
        '
        'panelBotones
        '
        Me.panelBotones.Controls.Add(Me.botonCancelar)
        Me.panelBotones.Controls.Add(Me.BotonBorrar)
        Me.panelBotones.Controls.Add(Me.botonContinuar)
        Me.panelBotones.Dock = System.Windows.Forms.DockStyle.Top
        Me.panelBotones.Location = New System.Drawing.Point(0, 0)
        Me.panelBotones.Name = "panelBotones"
        Me.panelBotones.Size = New System.Drawing.Size(569, 56)
        Me.panelBotones.TabIndex = 1
        '
        'botonCancelar
        '
        Me.botonCancelar.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.botonCancelar.Image = Global.KARIMs_SGI.My.Resources.Resources.db_cancel
        Me.botonCancelar.ImageAlign = System.Drawing.ContentAlignment.TopCenter
        Me.botonCancelar.Location = New System.Drawing.Point(482, 11)
        Me.botonCancelar.Name = "botonCancelar"
        Me.botonCancelar.Size = New System.Drawing.Size(75, 36)
        Me.botonCancelar.TabIndex = 2
        Me.botonCancelar.Text = "Cancelar"
        Me.botonCancelar.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.botonCancelar.UseVisualStyleBackColor = True
        '
        'BotonBorrar
        '
        Me.BotonBorrar.Image = Global.KARIMs_SGI.My.Resources.Resources.delete31
        Me.BotonBorrar.ImageAlign = System.Drawing.ContentAlignment.TopCenter
        Me.BotonBorrar.Location = New System.Drawing.Point(93, 9)
        Me.BotonBorrar.Name = "BotonBorrar"
        Me.BotonBorrar.Size = New System.Drawing.Size(75, 38)
        Me.BotonBorrar.TabIndex = 1
        Me.BotonBorrar.Text = "Borrar Datos"
        Me.BotonBorrar.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.BotonBorrar.UseVisualStyleBackColor = True
        '
        'botonContinuar
        '
        Me.botonContinuar.Image = Global.KARIMs_SGI.My.Resources.Resources.arrow_up_blue
        Me.botonContinuar.ImageAlign = System.Drawing.ContentAlignment.TopCenter
        Me.botonContinuar.Location = New System.Drawing.Point(12, 11)
        Me.botonContinuar.Name = "botonContinuar"
        Me.botonContinuar.Size = New System.Drawing.Size(75, 36)
        Me.botonContinuar.TabIndex = 0
        Me.botonContinuar.Text = "Continuar"
        Me.botonContinuar.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.botonContinuar.UseVisualStyleBackColor = True
        '
        'BarraTitulo1
        '
        Me.BarraTitulo1.BackColor = System.Drawing.Color.WhiteSmoke
        Me.BarraTitulo1.Dock = System.Windows.Forms.DockStyle.Top
        Me.BarraTitulo1.Location = New System.Drawing.Point(0, 56)
        Me.BarraTitulo1.Name = "BarraTitulo1"
        Me.BarraTitulo1.Size = New System.Drawing.Size(569, 30)
        Me.BarraTitulo1.TabIndex = 2
        '
        'frmLista
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(569, 319)
        Me.Controls.Add(Me.dtLista)
        Me.Controls.Add(Me.BarraTitulo1)
        Me.Controls.Add(Me.panelBotones)
        Me.Name = "frmLista"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent
        CType(Me.dtLista, System.ComponentModel.ISupportInitialize).EndInit()
        Me.panelBotones.ResumeLayout(False)
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents dtLista As System.Windows.Forms.DataGridView
    Friend WithEvents panelBotones As System.Windows.Forms.Panel
    Friend WithEvents botonCancelar As System.Windows.Forms.Button
    Friend WithEvents BotonBorrar As System.Windows.Forms.Button
    Friend WithEvents botonContinuar As System.Windows.Forms.Button
    Friend WithEvents BarraTitulo1 As KARIMs_SGI.BarraTitulo
End Class
