﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class usrBancoLista
    Inherits System.Windows.Forms.UserControl

    'UserControl reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim DataGridViewCellStyle1 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle4 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle5 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle2 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle3 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Me.Lista = New System.Windows.Forms.DataGridView()
        Me.lista_no = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.lista_banco = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.lista_numero = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.lista_nombre = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.lista_descripcion = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.lista_moneda = New System.Windows.Forms.DataGridViewTextBoxColumn()
        CType(Me.Lista, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'Lista
        '
        Me.Lista.AllowUserToAddRows = False
        Me.Lista.AllowUserToDeleteRows = False
        Me.Lista.BackgroundColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle1.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.Lista.ColumnHeadersDefaultCellStyle = DataGridViewCellStyle1
        Me.Lista.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.Lista.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.lista_no, Me.lista_banco, Me.lista_numero, Me.lista_nombre, Me.lista_descripcion, Me.lista_moneda})
        DataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle4.BackColor = System.Drawing.SystemColors.Window
        DataGridViewCellStyle4.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle4.ForeColor = System.Drawing.SystemColors.ControlText
        DataGridViewCellStyle4.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle4.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle4.WrapMode = System.Windows.Forms.DataGridViewTriState.[False]
        Me.Lista.DefaultCellStyle = DataGridViewCellStyle4
        Me.Lista.Location = New System.Drawing.Point(24, 247)
        Me.Lista.MultiSelect = False
        Me.Lista.Name = "Lista"
        Me.Lista.ReadOnly = True
        DataGridViewCellStyle5.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle5.BackColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle5.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle5.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle5.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle5.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle5.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.Lista.RowHeadersDefaultCellStyle = DataGridViewCellStyle5
        Me.Lista.RowHeadersWidth = 31
        Me.Lista.RowTemplate.Height = 21
        Me.Lista.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.Lista.Size = New System.Drawing.Size(613, 232)
        Me.Lista.TabIndex = 1
        Me.Lista.Visible = False
        '
        'lista_no
        '
        DataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        DataGridViewCellStyle2.BackColor = System.Drawing.SystemColors.Info
        DataGridViewCellStyle2.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lista_no.DefaultCellStyle = DataGridViewCellStyle2
        Me.lista_no.HeaderText = "N°"
        Me.lista_no.Name = "lista_no"
        Me.lista_no.ReadOnly = True
        Me.lista_no.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        Me.lista_no.Width = 50
        '
        'lista_banco
        '
        Me.lista_banco.HeaderText = "Bank Name"
        Me.lista_banco.Name = "lista_banco"
        Me.lista_banco.ReadOnly = True
        Me.lista_banco.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        Me.lista_banco.Width = 150
        '
        'lista_numero
        '
        Me.lista_numero.HeaderText = "Account Number"
        Me.lista_numero.Name = "lista_numero"
        Me.lista_numero.ReadOnly = True
        Me.lista_numero.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        Me.lista_numero.Width = 120
        '
        'lista_nombre
        '
        Me.lista_nombre.HeaderText = "Account Name"
        Me.lista_nombre.Name = "lista_nombre"
        Me.lista_nombre.ReadOnly = True
        Me.lista_nombre.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        Me.lista_nombre.Width = 175
        '
        'lista_descripcion
        '
        Me.lista_descripcion.HeaderText = "Description"
        Me.lista_descripcion.Name = "lista_descripcion"
        Me.lista_descripcion.ReadOnly = True
        Me.lista_descripcion.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        Me.lista_descripcion.Width = 200
        '
        'lista_moneda
        '
        DataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        Me.lista_moneda.DefaultCellStyle = DataGridViewCellStyle3
        Me.lista_moneda.HeaderText = "Currency"
        Me.lista_moneda.Name = "lista_moneda"
        Me.lista_moneda.ReadOnly = True
        Me.lista_moneda.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        Me.lista_moneda.Width = 80
        '
        'usrBancoLista
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.Controls.Add(Me.Lista)
        Me.Name = "usrBancoLista"
        Me.Size = New System.Drawing.Size(800, 500)
        CType(Me.Lista, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents Lista As DataGridView
    Friend WithEvents lista_no As DataGridViewTextBoxColumn
    Friend WithEvents lista_banco As DataGridViewTextBoxColumn
    Friend WithEvents lista_numero As DataGridViewTextBoxColumn
    Friend WithEvents lista_nombre As DataGridViewTextBoxColumn
    Friend WithEvents lista_descripcion As DataGridViewTextBoxColumn
    Friend WithEvents lista_moneda As DataGridViewTextBoxColumn
End Class
