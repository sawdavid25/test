﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmFiltro
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.grupoFechas = New System.Windows.Forms.GroupBox()
        Me.dtpFechaFin = New System.Windows.Forms.DateTimePicker()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.dtpFechaInicio = New System.Windows.Forms.DateTimePicker()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.panelTitulo = New System.Windows.Forms.Panel()
        Me.celdaTitulo = New System.Windows.Forms.Label()
        Me.panelAceptar = New System.Windows.Forms.Panel()
        Me.botonAceptar = New System.Windows.Forms.Button()
        Me.botonCancelar = New System.Windows.Forms.Button()
        Me.grupoOpcion = New System.Windows.Forms.GroupBox()
        Me.grupoFiltro = New System.Windows.Forms.GroupBox()
        Me.celdaTitulo3 = New System.Windows.Forms.Label()
        Me.celdaTitulo2 = New System.Windows.Forms.Label()
        Me.botonFiltro3 = New System.Windows.Forms.Button()
        Me.celdaFiltro3 = New System.Windows.Forms.TextBox()
        Me.celdaSelctFiltro3 = New System.Windows.Forms.Label()
        Me.botonFiltro2 = New System.Windows.Forms.Button()
        Me.celdaFiltro2 = New System.Windows.Forms.TextBox()
        Me.celdaSelctFiltro2 = New System.Windows.Forms.Label()
        Me.botonFiltro = New System.Windows.Forms.Button()
        Me.celdaFiltro = New System.Windows.Forms.TextBox()
        Me.celdaSelctFiltro = New System.Windows.Forms.Label()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.grupoCorte = New System.Windows.Forms.GroupBox()
        Me.dtpFechaCorte = New System.Windows.Forms.DateTimePicker()
        Me.Panel2 = New System.Windows.Forms.Panel()
        Me.grupoFechas.SuspendLayout()
        Me.panelTitulo.SuspendLayout()
        Me.panelAceptar.SuspendLayout()
        Me.grupoOpcion.SuspendLayout()
        Me.grupoFiltro.SuspendLayout()
        Me.Panel1.SuspendLayout()
        Me.grupoCorte.SuspendLayout()
        Me.SuspendLayout()
        '
        'grupoFechas
        '
        Me.grupoFechas.Controls.Add(Me.dtpFechaFin)
        Me.grupoFechas.Controls.Add(Me.Label2)
        Me.grupoFechas.Controls.Add(Me.dtpFechaInicio)
        Me.grupoFechas.Controls.Add(Me.Label1)
        Me.grupoFechas.Location = New System.Drawing.Point(17, 20)
        Me.grupoFechas.Margin = New System.Windows.Forms.Padding(4)
        Me.grupoFechas.Name = "grupoFechas"
        Me.grupoFechas.Padding = New System.Windows.Forms.Padding(4)
        Me.grupoFechas.Size = New System.Drawing.Size(309, 154)
        Me.grupoFechas.TabIndex = 1
        Me.grupoFechas.TabStop = False
        Me.grupoFechas.Text = "Filter by Date"
        Me.grupoFechas.Visible = False
        '
        'dtpFechaFin
        '
        Me.dtpFechaFin.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.dtpFechaFin.Location = New System.Drawing.Point(33, 105)
        Me.dtpFechaFin.Margin = New System.Windows.Forms.Padding(4)
        Me.dtpFechaFin.Name = "dtpFechaFin"
        Me.dtpFechaFin.Size = New System.Drawing.Size(145, 22)
        Me.dtpFechaFin.TabIndex = 3
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(29, 85)
        Me.Label2.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(70, 17)
        Me.Label2.TabIndex = 2
        Me.Label2.Text = "Final date"
        '
        'dtpFechaInicio
        '
        Me.dtpFechaInicio.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.dtpFechaInicio.Location = New System.Drawing.Point(33, 57)
        Me.dtpFechaInicio.Margin = New System.Windows.Forms.Padding(4)
        Me.dtpFechaInicio.Name = "dtpFechaInicio"
        Me.dtpFechaInicio.Size = New System.Drawing.Size(145, 22)
        Me.dtpFechaInicio.TabIndex = 1
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(29, 37)
        Me.Label1.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(72, 17)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "Initial date"
        '
        'panelTitulo
        '
        Me.panelTitulo.BackColor = System.Drawing.Color.WhiteSmoke
        Me.panelTitulo.Controls.Add(Me.celdaTitulo)
        Me.panelTitulo.Dock = System.Windows.Forms.DockStyle.Top
        Me.panelTitulo.Location = New System.Drawing.Point(0, 0)
        Me.panelTitulo.Margin = New System.Windows.Forms.Padding(4)
        Me.panelTitulo.Name = "panelTitulo"
        Me.panelTitulo.Size = New System.Drawing.Size(699, 46)
        Me.panelTitulo.TabIndex = 1
        '
        'celdaTitulo
        '
        Me.celdaTitulo.AutoSize = True
        Me.celdaTitulo.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.celdaTitulo.Location = New System.Drawing.Point(41, 11)
        Me.celdaTitulo.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.celdaTitulo.Name = "celdaTitulo"
        Me.celdaTitulo.Size = New System.Drawing.Size(77, 25)
        Me.celdaTitulo.TabIndex = 0
        Me.celdaTitulo.Text = "Label4"
        '
        'panelAceptar
        '
        Me.panelAceptar.Controls.Add(Me.botonAceptar)
        Me.panelAceptar.Controls.Add(Me.botonCancelar)
        Me.panelAceptar.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.panelAceptar.Location = New System.Drawing.Point(0, 331)
        Me.panelAceptar.Margin = New System.Windows.Forms.Padding(4)
        Me.panelAceptar.Name = "panelAceptar"
        Me.panelAceptar.Size = New System.Drawing.Size(699, 69)
        Me.panelAceptar.TabIndex = 2
        '
        'botonAceptar
        '
        Me.botonAceptar.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.botonAceptar.Image = Global.KARIMs_SGI.My.Resources.Resources.arrow_up_blue
        Me.botonAceptar.ImageAlign = System.Drawing.ContentAlignment.TopCenter
        Me.botonAceptar.Location = New System.Drawing.Point(500, 7)
        Me.botonAceptar.Margin = New System.Windows.Forms.Padding(4)
        Me.botonAceptar.Name = "botonAceptar"
        Me.botonAceptar.Size = New System.Drawing.Size(81, 42)
        Me.botonAceptar.TabIndex = 1
        Me.botonAceptar.Text = "&Aceptar"
        Me.botonAceptar.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.botonAceptar.UseVisualStyleBackColor = True
        '
        'botonCancelar
        '
        Me.botonCancelar.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.botonCancelar.Image = Global.KARIMs_SGI.My.Resources.Resources.db_cancel
        Me.botonCancelar.ImageAlign = System.Drawing.ContentAlignment.TopCenter
        Me.botonCancelar.Location = New System.Drawing.Point(601, 7)
        Me.botonCancelar.Margin = New System.Windows.Forms.Padding(4)
        Me.botonCancelar.Name = "botonCancelar"
        Me.botonCancelar.Size = New System.Drawing.Size(81, 42)
        Me.botonCancelar.TabIndex = 0
        Me.botonCancelar.Text = "&Cancelar"
        Me.botonCancelar.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.botonCancelar.UseVisualStyleBackColor = True
        '
        'grupoOpcion
        '
        Me.grupoOpcion.Controls.Add(Me.Panel2)
        Me.grupoOpcion.Location = New System.Drawing.Point(353, 10)
        Me.grupoOpcion.Margin = New System.Windows.Forms.Padding(4)
        Me.grupoOpcion.Name = "grupoOpcion"
        Me.grupoOpcion.Padding = New System.Windows.Forms.Padding(4)
        Me.grupoOpcion.Size = New System.Drawing.Size(295, 69)
        Me.grupoOpcion.TabIndex = 7
        Me.grupoOpcion.TabStop = False
        Me.grupoOpcion.Text = "Choose an Option"
        Me.grupoOpcion.Visible = False
        '
        'grupoFiltro
        '
        Me.grupoFiltro.Controls.Add(Me.celdaTitulo3)
        Me.grupoFiltro.Controls.Add(Me.celdaTitulo2)
        Me.grupoFiltro.Controls.Add(Me.botonFiltro3)
        Me.grupoFiltro.Controls.Add(Me.celdaFiltro3)
        Me.grupoFiltro.Controls.Add(Me.celdaSelctFiltro3)
        Me.grupoFiltro.Controls.Add(Me.botonFiltro2)
        Me.grupoFiltro.Controls.Add(Me.celdaFiltro2)
        Me.grupoFiltro.Controls.Add(Me.celdaSelctFiltro2)
        Me.grupoFiltro.Controls.Add(Me.botonFiltro)
        Me.grupoFiltro.Controls.Add(Me.celdaFiltro)
        Me.grupoFiltro.Controls.Add(Me.celdaSelctFiltro)
        Me.grupoFiltro.Location = New System.Drawing.Point(335, 80)
        Me.grupoFiltro.Margin = New System.Windows.Forms.Padding(4)
        Me.grupoFiltro.Name = "grupoFiltro"
        Me.grupoFiltro.Padding = New System.Windows.Forms.Padding(4)
        Me.grupoFiltro.Size = New System.Drawing.Size(364, 198)
        Me.grupoFiltro.TabIndex = 8
        Me.grupoFiltro.TabStop = False
        Me.grupoFiltro.Text = "Filter"
        Me.grupoFiltro.Visible = False
        '
        'celdaTitulo3
        '
        Me.celdaTitulo3.AutoSize = True
        Me.celdaTitulo3.Location = New System.Drawing.Point(15, 140)
        Me.celdaTitulo3.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.celdaTitulo3.Name = "celdaTitulo3"
        Me.celdaTitulo3.Size = New System.Drawing.Size(51, 17)
        Me.celdaTitulo3.TabIndex = 11
        Me.celdaTitulo3.Text = "Label4"
        Me.celdaTitulo3.Visible = False
        '
        'celdaTitulo2
        '
        Me.celdaTitulo2.AutoSize = True
        Me.celdaTitulo2.Location = New System.Drawing.Point(8, 78)
        Me.celdaTitulo2.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.celdaTitulo2.Name = "celdaTitulo2"
        Me.celdaTitulo2.Size = New System.Drawing.Size(51, 17)
        Me.celdaTitulo2.TabIndex = 10
        Me.celdaTitulo2.Text = "Label3"
        Me.celdaTitulo2.Visible = False
        '
        'botonFiltro3
        '
        Me.botonFiltro3.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.botonFiltro3.Location = New System.Drawing.Point(325, 156)
        Me.botonFiltro3.Margin = New System.Windows.Forms.Padding(4)
        Me.botonFiltro3.Name = "botonFiltro3"
        Me.botonFiltro3.Size = New System.Drawing.Size(35, 28)
        Me.botonFiltro3.TabIndex = 9
        Me.botonFiltro3.Text = "..."
        Me.botonFiltro3.UseVisualStyleBackColor = True
        Me.botonFiltro3.Visible = False
        '
        'celdaFiltro3
        '
        Me.celdaFiltro3.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.celdaFiltro3.Location = New System.Drawing.Point(8, 160)
        Me.celdaFiltro3.Margin = New System.Windows.Forms.Padding(4)
        Me.celdaFiltro3.Name = "celdaFiltro3"
        Me.celdaFiltro3.Size = New System.Drawing.Size(308, 22)
        Me.celdaFiltro3.TabIndex = 8
        Me.celdaFiltro3.Text = "TODOS"
        Me.celdaFiltro3.Visible = False
        '
        'celdaSelctFiltro3
        '
        Me.celdaSelctFiltro3.AutoSize = True
        Me.celdaSelctFiltro3.Location = New System.Drawing.Point(116, 143)
        Me.celdaSelctFiltro3.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.celdaSelctFiltro3.Name = "celdaSelctFiltro3"
        Me.celdaSelctFiltro3.Size = New System.Drawing.Size(21, 17)
        Me.celdaSelctFiltro3.TabIndex = 7
        Me.celdaSelctFiltro3.Text = "-1"
        Me.celdaSelctFiltro3.Visible = False
        '
        'botonFiltro2
        '
        Me.botonFiltro2.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.botonFiltro2.Location = New System.Drawing.Point(325, 100)
        Me.botonFiltro2.Margin = New System.Windows.Forms.Padding(4)
        Me.botonFiltro2.Name = "botonFiltro2"
        Me.botonFiltro2.Size = New System.Drawing.Size(35, 28)
        Me.botonFiltro2.TabIndex = 6
        Me.botonFiltro2.Text = "..."
        Me.botonFiltro2.UseVisualStyleBackColor = True
        Me.botonFiltro2.Visible = False
        '
        'celdaFiltro2
        '
        Me.celdaFiltro2.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.celdaFiltro2.Location = New System.Drawing.Point(8, 103)
        Me.celdaFiltro2.Margin = New System.Windows.Forms.Padding(4)
        Me.celdaFiltro2.Name = "celdaFiltro2"
        Me.celdaFiltro2.Size = New System.Drawing.Size(308, 22)
        Me.celdaFiltro2.TabIndex = 5
        Me.celdaFiltro2.Text = "TODOS"
        Me.celdaFiltro2.Visible = False
        '
        'celdaSelctFiltro2
        '
        Me.celdaSelctFiltro2.AutoSize = True
        Me.celdaSelctFiltro2.Location = New System.Drawing.Point(116, 84)
        Me.celdaSelctFiltro2.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.celdaSelctFiltro2.Name = "celdaSelctFiltro2"
        Me.celdaSelctFiltro2.Size = New System.Drawing.Size(21, 17)
        Me.celdaSelctFiltro2.TabIndex = 4
        Me.celdaSelctFiltro2.Text = "-1"
        Me.celdaSelctFiltro2.Visible = False
        '
        'botonFiltro
        '
        Me.botonFiltro.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.botonFiltro.Location = New System.Drawing.Point(325, 44)
        Me.botonFiltro.Margin = New System.Windows.Forms.Padding(4)
        Me.botonFiltro.Name = "botonFiltro"
        Me.botonFiltro.Size = New System.Drawing.Size(35, 28)
        Me.botonFiltro.TabIndex = 3
        Me.botonFiltro.Text = "..."
        Me.botonFiltro.UseVisualStyleBackColor = True
        '
        'celdaFiltro
        '
        Me.celdaFiltro.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.celdaFiltro.Location = New System.Drawing.Point(8, 48)
        Me.celdaFiltro.Margin = New System.Windows.Forms.Padding(4)
        Me.celdaFiltro.Name = "celdaFiltro"
        Me.celdaFiltro.Size = New System.Drawing.Size(308, 22)
        Me.celdaFiltro.TabIndex = 2
        Me.celdaFiltro.Text = "TODOS"
        '
        'celdaSelctFiltro
        '
        Me.celdaSelctFiltro.AutoSize = True
        Me.celdaSelctFiltro.Location = New System.Drawing.Point(116, 28)
        Me.celdaSelctFiltro.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.celdaSelctFiltro.Name = "celdaSelctFiltro"
        Me.celdaSelctFiltro.Size = New System.Drawing.Size(21, 17)
        Me.celdaSelctFiltro.TabIndex = 1
        Me.celdaSelctFiltro.Text = "-1"
        Me.celdaSelctFiltro.Visible = False
        '
        'Panel1
        '
        Me.Panel1.Controls.Add(Me.grupoFiltro)
        Me.Panel1.Controls.Add(Me.grupoOpcion)
        Me.Panel1.Controls.Add(Me.grupoFechas)
        Me.Panel1.Controls.Add(Me.grupoCorte)
        Me.Panel1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Panel1.Location = New System.Drawing.Point(0, 46)
        Me.Panel1.Margin = New System.Windows.Forms.Padding(4)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(699, 285)
        Me.Panel1.TabIndex = 9
        '
        'grupoCorte
        '
        Me.grupoCorte.Controls.Add(Me.dtpFechaCorte)
        Me.grupoCorte.Location = New System.Drawing.Point(29, 181)
        Me.grupoCorte.Margin = New System.Windows.Forms.Padding(4)
        Me.grupoCorte.Name = "grupoCorte"
        Me.grupoCorte.Padding = New System.Windows.Forms.Padding(4)
        Me.grupoCorte.Size = New System.Drawing.Size(297, 86)
        Me.grupoCorte.TabIndex = 9
        Me.grupoCorte.TabStop = False
        Me.grupoCorte.Text = "Cutoff date"
        Me.grupoCorte.Visible = False
        '
        'dtpFechaCorte
        '
        Me.dtpFechaCorte.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.dtpFechaCorte.Location = New System.Drawing.Point(21, 34)
        Me.dtpFechaCorte.Margin = New System.Windows.Forms.Padding(4)
        Me.dtpFechaCorte.Name = "dtpFechaCorte"
        Me.dtpFechaCorte.Size = New System.Drawing.Size(145, 22)
        Me.dtpFechaCorte.TabIndex = 0
        '
        'Panel2
        '
        Me.Panel2.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Panel2.Location = New System.Drawing.Point(4, 19)
        Me.Panel2.Name = "Panel2"
        Me.Panel2.Size = New System.Drawing.Size(287, 46)
        Me.Panel2.TabIndex = 0
        '
        'frmFiltro
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.AutoScroll = True
        Me.ClientSize = New System.Drawing.Size(699, 400)
        Me.Controls.Add(Me.Panel1)
        Me.Controls.Add(Me.panelAceptar)
        Me.Controls.Add(Me.panelTitulo)
        Me.Margin = New System.Windows.Forms.Padding(4)
        Me.Name = "frmFiltro"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "frmFiltro"
        Me.grupoFechas.ResumeLayout(False)
        Me.grupoFechas.PerformLayout()
        Me.panelTitulo.ResumeLayout(False)
        Me.panelTitulo.PerformLayout()
        Me.panelAceptar.ResumeLayout(False)
        Me.grupoOpcion.ResumeLayout(False)
        Me.grupoFiltro.ResumeLayout(False)
        Me.grupoFiltro.PerformLayout()
        Me.Panel1.ResumeLayout(False)
        Me.grupoCorte.ResumeLayout(False)
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents grupoFechas As System.Windows.Forms.GroupBox
    Friend WithEvents dtpFechaFin As System.Windows.Forms.DateTimePicker
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents dtpFechaInicio As System.Windows.Forms.DateTimePicker
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents panelTitulo As System.Windows.Forms.Panel
    Friend WithEvents celdaTitulo As System.Windows.Forms.Label
    Friend WithEvents panelAceptar As System.Windows.Forms.Panel
    Friend WithEvents botonAceptar As System.Windows.Forms.Button
    Friend WithEvents botonCancelar As System.Windows.Forms.Button
    Friend WithEvents grupoOpcion As System.Windows.Forms.GroupBox
    Friend WithEvents grupoFiltro As System.Windows.Forms.GroupBox
    Friend WithEvents celdaSelctFiltro As System.Windows.Forms.Label
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
    Friend WithEvents grupoCorte As System.Windows.Forms.GroupBox
    Friend WithEvents dtpFechaCorte As System.Windows.Forms.DateTimePicker
    Friend WithEvents botonFiltro As System.Windows.Forms.Button
    Friend WithEvents celdaFiltro As System.Windows.Forms.TextBox
    Friend WithEvents botonFiltro2 As System.Windows.Forms.Button
    Friend WithEvents celdaFiltro2 As System.Windows.Forms.TextBox
    Friend WithEvents celdaSelctFiltro2 As System.Windows.Forms.Label
    Friend WithEvents botonFiltro3 As System.Windows.Forms.Button
    Friend WithEvents celdaFiltro3 As System.Windows.Forms.TextBox
    Friend WithEvents celdaSelctFiltro3 As System.Windows.Forms.Label
    Friend WithEvents celdaTitulo3 As System.Windows.Forms.Label
    Friend WithEvents celdaTitulo2 As System.Windows.Forms.Label
    Friend WithEvents Panel2 As Panel
End Class
