﻿Public Class frmLista

    Dim strTitulo As String = STR_VACIO
    Dim strKey As String = STR_VACIO

    Public WriteOnly Property Key As String
        Set(value As String)
            strKey = value
        End Set
    End Property
  
    Public WriteOnly Property Titulo As String
        Set(value As String)
            strTitulo = value
        End Set
    End Property

    Private Sub frmLista_Load(sender As Object, e As EventArgs) Handles Me.Load
        BarraTitulo1.CambiarTitulo(strTitulo)
        Me.Text = strTitulo
    End Sub

    Private Sub botonCancelar_Click(sender As Object, e As EventArgs) Handles botonCancelar.Click
        Me.DialogResult = System.Windows.Forms.DialogResult.Cancel
    End Sub

    Private Sub ActuallizarPayment()
        Dim strSQL As String = STR_VACIO
        Dim strSQLF As String = STR_VACIO
        Dim COM As MySqlCommand
        Try
            strSQL = " UPDATE Clientes SET cli_observaciones = {Payment} WHERE cli_sisemp = {empresa} AND cli_codigo = {Cliente}"
            If Sesion.IdEmpresa = 18 Then
                strSQL &= "; UPDATE PDM.Clientes SET cli_observaciones = {Payment} WHERE cli_sisemp = {empresa} AND cli_codigo = {Cliente}"
            End If
            For i = INT_CERO To dtLista.RowCount - 1
                strSQLF = Replace(strSQL, "{Payment}", "'" & CStr(dtLista.Rows(i).Cells("2").Value) & " '")
                strSQLF = Replace(strSQLF, "{empresa}", Sesion.IdEmpresa)
                strSQLF = Replace(strSQLF, "{Cliente}", CStr(dtLista.Rows(i).Cells("0").Value))
                MyCnn.CONECTAR = strConexion
                COM = New MySqlCommand(strSQLF, CON)
                COM.ExecuteNonQuery()
            Next
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub botonContinuar_Click(sender As Object, e As EventArgs) Handles botonContinuar.Click

        Select Case strKey
            Case "Rpt_AccRecSch"
                ActuallizarPayment()
        End Select

        Me.DialogResult = System.Windows.Forms.DialogResult.OK
    End Sub
End Class