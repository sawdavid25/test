﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class encabezado
    Inherits System.Windows.Forms.UserControl

    'UserControl reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(encabezado))
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.CuadroLogo = New System.Windows.Forms.PictureBox()
        Me.botonCerrar = New System.Windows.Forms.Button()
        Me.botonBorrar = New System.Windows.Forms.Button()
        Me.botonGuardar = New System.Windows.Forms.Button()
        Me.botonNuevo = New System.Windows.Forms.Button()
        Me.Panel1.SuspendLayout()
        CType(Me.CuadroLogo, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'Panel1
        '
        Me.Panel1.BackColor = System.Drawing.SystemColors.Control
        Me.Panel1.Controls.Add(Me.CuadroLogo)
        Me.Panel1.Controls.Add(Me.botonCerrar)
        Me.Panel1.Controls.Add(Me.botonBorrar)
        Me.Panel1.Controls.Add(Me.botonGuardar)
        Me.Panel1.Controls.Add(Me.botonNuevo)
        Me.Panel1.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel1.Location = New System.Drawing.Point(0, 0)
        Me.Panel1.Margin = New System.Windows.Forms.Padding(4)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(803, 85)
        Me.Panel1.TabIndex = 1
        '
        'CuadroLogo
        '
        Me.CuadroLogo.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.CuadroLogo.BackColor = System.Drawing.SystemColors.ControlLightLight
        Me.CuadroLogo.Image = CType(resources.GetObject("CuadroLogo.Image"), System.Drawing.Image)
        Me.CuadroLogo.Location = New System.Drawing.Point(685, 4)
        Me.CuadroLogo.Margin = New System.Windows.Forms.Padding(4)
        Me.CuadroLogo.Name = "CuadroLogo"
        Me.CuadroLogo.Size = New System.Drawing.Size(113, 78)
        Me.CuadroLogo.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.CuadroLogo.TabIndex = 1
        Me.CuadroLogo.TabStop = False
        '
        'botonCerrar
        '
        Me.botonCerrar.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.botonCerrar.Image = Global.KARIMs_SGI.My.Resources.Resources.db_cancel
        Me.botonCerrar.Location = New System.Drawing.Point(602, 11)
        Me.botonCerrar.Margin = New System.Windows.Forms.Padding(4)
        Me.botonCerrar.Name = "botonCerrar"
        Me.botonCerrar.Size = New System.Drawing.Size(75, 55)
        Me.botonCerrar.TabIndex = 0
        Me.botonCerrar.Text = "&Close"
        Me.botonCerrar.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.botonCerrar.UseVisualStyleBackColor = True
        '
        'botonBorrar
        '
        Me.botonBorrar.Image = Global.KARIMs_SGI.My.Resources.Resources.delete31
        Me.botonBorrar.Location = New System.Drawing.Point(189, 11)
        Me.botonBorrar.Margin = New System.Windows.Forms.Padding(4)
        Me.botonBorrar.Name = "botonBorrar"
        Me.botonBorrar.Size = New System.Drawing.Size(75, 55)
        Me.botonBorrar.TabIndex = 0
        Me.botonBorrar.Text = "&Delete"
        Me.botonBorrar.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.botonBorrar.UseVisualStyleBackColor = True
        '
        'botonGuardar
        '
        Me.botonGuardar.Image = Global.KARIMs_SGI.My.Resources.Resources.save
        Me.botonGuardar.Location = New System.Drawing.Point(107, 11)
        Me.botonGuardar.Margin = New System.Windows.Forms.Padding(4)
        Me.botonGuardar.Name = "botonGuardar"
        Me.botonGuardar.Size = New System.Drawing.Size(75, 55)
        Me.botonGuardar.TabIndex = 0
        Me.botonGuardar.Text = "&Save"
        Me.botonGuardar.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.botonGuardar.UseVisualStyleBackColor = True
        '
        'botonNuevo
        '
        Me.botonNuevo.Image = Global.KARIMs_SGI.My.Resources.Resources.file_add
        Me.botonNuevo.Location = New System.Drawing.Point(24, 11)
        Me.botonNuevo.Margin = New System.Windows.Forms.Padding(4)
        Me.botonNuevo.Name = "botonNuevo"
        Me.botonNuevo.Size = New System.Drawing.Size(75, 55)
        Me.botonNuevo.TabIndex = 0
        Me.botonNuevo.Text = "&New"
        Me.botonNuevo.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.botonNuevo.UseVisualStyleBackColor = True
        '
        'encabezado
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.Controls.Add(Me.Panel1)
        Me.Margin = New System.Windows.Forms.Padding(4)
        Me.Name = "encabezado"
        Me.Size = New System.Drawing.Size(803, 89)
        Me.Panel1.ResumeLayout(False)
        CType(Me.CuadroLogo, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
    Friend WithEvents CuadroLogo As System.Windows.Forms.PictureBox
    Friend WithEvents botonCerrar As System.Windows.Forms.Button
    Friend WithEvents botonBorrar As System.Windows.Forms.Button
    Friend WithEvents botonGuardar As System.Windows.Forms.Button
    Friend WithEvents botonNuevo As System.Windows.Forms.Button

End Class
