﻿Public Class usrBancoCuenta
    'Modificado: 2019-08-28

    Private Const INT_BANCO As Integer = 0
    Private Const STR_MODULO As String = "frmBCuenta"

    'Tipo de documento bancario
    Private intFiltroTipo As Integer = 0

    Private intBanco As Integer = 0
    Private intMoneda As Integer = 0
    Private intModulo As Integer = 0

    Private logConfidencial As Boolean = False

    'Clase de cuenta: moneda local / exterior
    Private strClase As String = String.Empty
    Private strBuscar As String = String.Empty

    Private Base As New clsBancos

    'Propiedades públicas
    Public Property ID As Integer
    Public Property EsNuevo As Boolean

    Public ReadOnly Property Moneda() As Integer
        Get
            Moneda = intMoneda
        End Get
    End Property
    Public ReadOnly Property Titulo
        Get
            Titulo = (CeldaBanco.Text & " / " & CeldaNombre.Text).ToUpper.Trim
        End Get
    End Property

    'Eventos
    Public Event DocumentoSeleccionado(ByVal Tipo As Integer, ByVal Ciclo As Integer, ByVal Numero As Integer, ByVal Documento As Integer)

    'Limpia los controles para una cuenta nueva
    Public Sub NuevaCuenta()
        intFiltroTipo = INT_CERO
        intBanco = INT_CERO
        intMoneda = INT_CERO

        strBuscar = String.Empty

        logConfidencial = False
        strClase = String.Empty

        If Base.IdCheque.Equals(INT_CERO) Then
            Base.CargarTipos()
        End If

        'Limpiar celdas de encabezado
        CeldaCodigo.Text = INT_CERO.ToString("D3")
        CeldaNumero.Text = String.Empty
        CeldaTipo.Text = String.Empty
        CeldaBanco.Text = String.Empty
        CeldaNombre.Text = String.Empty
        CeldaDescripcion.Text = String.Empty
        CeldaContacto.Text = String.Empty
        CeldaMoneda.Text = String.Empty
        CeldaDivisa.Text = String.Empty
        CeldaSobregiro.Text = INT_CERO.ToString("f")
        CeldaPlazo.Text = INT_CERO.ToString
        CeldaContable.Text = String.Empty
        CeldaCheque.Text = INT_CERO.ToString("D8")

        'Controles del filtro
        BotonDeposito.Enabled = False
        BotonCredito.Enabled = False
        BotonCheque.Enabled = False
        BotonDebito.Enabled = False
        BotonActualizar.Enabled = False
        BotonConciliacion.Enabled = False

        FiltroTipo.Text = "(Show all...)"
        FiltroDesde.Value = Today.AddMonths(NO_FILA)
        'REM para depuracion 
        'FiltroDesde.Value = CDate("2018-09-01")
        FiltroHasta.Value = Today

        CeldaSaldo.Text = INT_CERO.ToString("f")
        CeldaReserva.Text = INT_CERO.ToString("f")

        'Limpiar detalles
        Movimiento.SuspendLayout()
        Reserva.SuspendLayout()

        Movimiento.Rows.Clear()
        Reserva.DataSource = Nothing
        Reserva.Rows.Clear()

        Movimiento.ResumeLayout()
        Reserva.ResumeLayout()

        EsNuevo = True
    End Sub

    'Carga los datos de la cuenta indicada
    Public Sub CargarCuenta(ByVal ID As Integer)
        Dim strSQL As String
        Dim cmd As MySqlCommand
        Dim da As MySqlDataAdapter
        Dim dt As System.Data.DataTable
        Dim row As DataRow
        Dim obj As Object

        NuevaCuenta()

        strSQL = Base.SQLCuenta(ID)
        Try
            MyCnn.CONECTAR = strConexion
            cmd = New MySqlCommand(strSQL, CON)
            da = New MySqlDataAdapter(cmd)
            dt = New System.Data.DataTable
            da.Fill(dt)
            If dt.Rows.Count > INT_CERO Then
                row = dt.Rows(INT_CERO)

                _ID = ID
                intBanco = CInt(row("id_banco"))
                intMoneda = CInt(row("id_moneda"))

                CeldaCodigo.Text = CInt(row("codigo")).ToString("D3")
                CeldaNumero.Text = row("numero").ToString.Trim
                CeldaTipo.Text = row("tipo").ToString.Trim
                CeldaBanco.Text = row("banco").ToString.Trim
                CeldaNombre.Text = row("nombre").ToString.Trim
                CeldaDescripcion.Text = row("descripcion").ToString.Trim
                CeldaContacto.Text = row("contacto").ToString.Trim
                CeldaMoneda.Text = row("moneda").ToString.Trim
                CeldaDivisa.Text = row("divisa").ToString.Trim
                CeldaSobregiro.Text = Format(Convert.ToDouble(row("sobregiro")), "0.00")
                CeldaPlazo.Text = CInt(row("plazo"))
                CeldaContable.Text = row("cuenta").ToString

                'Clase de cuenta: moneda local / externa
                strSQL = Base.SQLTipoDeMoneda(intMoneda)
                MyCnn.CONECTAR = strConexion
                cmd = New MySqlCommand(strSQL, CON)
                strClase = cmd.ExecuteScalar.ToString

                'Ultimo cheque de esta cuenta
                CeldaCheque.Text = CInt(row("cheque")).ToString("D8")

                'Habilitar botones de filtro
                BotonDeposito.Enabled = True
                BotonCredito.Enabled = True
                BotonCheque.Enabled = True
                BotonDebito.Enabled = True
                BotonActualizar.Enabled = True

                'Saldo de cuenta
                CeldaSaldo.Text = Base.SaldoActual(ID, FiltroDesde.Value, True).ToString(FMT_MSO_TOTAL)

                'Reserva
                MostrarReserva(ID)

                'Movimiento de cuenta
                MostrarMovimiento(ID)

                'Habilitar conciliacion
                BotonConciliacion.Enabled = True

                'Determinar si el usuario tiene permiso para visualizar documentos confidenciales en esta cuenta
                strSQL = "SELECT pms_registro FROM Permisos WHERE pms_codigo='SECRET' AND pms_usuario={usuario} AND pms_id={modulo} LIMIT 1"
                strSQL = strSQL.Replace("{usuario}", Base.Text(Sesion.Usuario))
                strSQL = strSQL.Replace("{modulo}", CeldaCodigo.Text)
                MyCnn.CONECTAR = strConexion
                cmd = New MySqlCommand(strSQL, CON)
                obj = cmd.ExecuteScalar()
                If obj IsNot Nothing Then
                    logConfidencial = CBool(CInt(obj) > INT_CERO)
                End If
            End If

            Movimiento.Focus()
        Catch ex As Exception
            MessageBox.Show(ex.Message, ex.Source + " error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try

        EsNuevo = False
    End Sub

    'Actualiza el saldo y el listado de movimientos
    Public Sub RecargarMovimientos()
        CeldaSaldo.Text = Base.SaldoActual(_ID, FiltroDesde.Value, True).ToString(FMT_MSO_TOTAL)
        MostrarMovimiento(_ID)
    End Sub

    'Comprueba los datos de la cuenta antes de guardar
    Private Function ComprobarCuenta() As Boolean
        Dim intDato As Integer, dblDato As Double
        Dim logAceptar As Boolean = False

        CeldaNumero.Text = CeldaNumero.Text.Trim.ToUpper
        CeldaTipo.Text = CeldaTipo.Text.Trim
        CeldaNombre.Text = CeldaNombre.Text.Trim.ToUpper
        CeldaDescripcion.Text = CeldaDescripcion.Text.Trim
        CeldaContable.Text = CeldaContable.Text.Trim

        If CeldaNumero.Text.Equals(String.Empty) Then
            'Número de cuenta
            MessageBox.Show("Required field cannot be left blank", "Account Number", MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
            CeldaNumero.Focus()
        ElseIf CeldaTipo.Text.Equals(String.Empty) Then
            'Tipo de cuenta
            MessageBox.Show("Please select an account type", "Account Type", MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
            CeldaTipo.Focus()
        ElseIf CeldaNombre.Text.Equals(String.Empty) Then
            'Nombre de la cuenta
            MessageBox.Show("Required field cannot be left blank", "Account Name", MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
            CeldaNombre.Focus()
        ElseIf CeldaDescripcion.Text.Equals(String.Empty) Then
            'Descripción
            MessageBox.Show("Required field cannot be left blank", "Account Name", MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
            CeldaDescripcion.Focus()
        ElseIf Not Double.TryParse(CeldaSobregiro.Text, dblDato) Then
            'Sobregiro
            MessageBox.Show("The field must be a number", "Overdraft", MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
            CeldaSobregiro.Focus()
        Else
            CeldaSobregiro.Text = dblDato.ToString("f")
            If Not Integer.TryParse(CeldaPlazo.Text, intDato) Then
                'Plazo
                MessageBox.Show("The field must be a number", "Term", MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
                CeldaPlazo.Focus()
            Else
                CeldaPlazo.Text = intDato.ToString
                logAceptar = True
            End If
        End If

        Return logAceptar
    End Function

    'Guarda los datos de la cuenta
    Private Function GuardarDatos() As Boolean
        Dim logEx As Boolean = False
        Dim strSQL As String

        'Obtener SQL de insercion o actualizacion
        If EsNuevo Then
            strSQL = Base.SQLCrearCuenta
        Else
            strSQL = Base.SQLActualizarCuenta
        End If

        Try
            MyCnn.CONECTAR = strConexion
            Dim cmd As New MySqlCommand(strSQL, CON)

            'Asignar valores y ejecutar
            cmd.Parameters.AddWithValue("@empresa", Sesion.IdEmpresa)
            cmd.Parameters.AddWithValue("@tipo", INT_BANCO)
            cmd.Parameters.AddWithValue("@id", CInt(CeldaCodigo.Text))
            cmd.Parameters.AddWithValue("@id_banco", intBanco)
            cmd.Parameters.AddWithValue("@contacto", CeldaContacto.Text)
            cmd.Parameters.AddWithValue("@numero", CeldaNumero.Text)
            cmd.Parameters.AddWithValue("@nombre", CeldaNombre.Text)
            cmd.Parameters.AddWithValue("@descripcion", CeldaDescripcion.Text)
            cmd.Parameters.AddWithValue("@tipo_cuenta", CeldaTipo.Text)
            cmd.Parameters.AddWithValue("@sobregiro", CDbl(CeldaSobregiro.Text))
            cmd.Parameters.AddWithValue("@plazo", CInt(CeldaPlazo.Text))
            cmd.Parameters.AddWithValue("@moneda", intMoneda)
            cmd.Parameters.AddWithValue("@contable", CeldaContable.Text)
            cmd.ExecuteNonQuery()

            If EsNuevo Then EsNuevo = False
            logEx = True
        Catch ex As Exception
            MessageBox.Show(ex.Message, ex.Source & " Error", MessageBoxButtons.OK, MessageBoxIcon.Stop)
        End Try

        Return logEx
    End Function

    'Guardar número de cheque
    Private Sub GuardarNumero()
        Dim strSQL As String = String.Empty
        Dim intNum As Integer
        Dim intCuenta As Integer = CInt(CeldaCodigo.Text)

        If Not intCuenta.Equals(INT_CERO) Then
            'Obtener ID actual si exite
            strSQL = "SELECT IFNULL(MAX(cat_num),0) ID FROM Catalogos WHERE cat_clase='Cheques' AND cat_clave='Max_Num' AND cat_sist={cuenta}"
            strSQL = strSQL.Replace("{cuenta}", Base.Text(intCuenta.ToString))
            MyCnn.CONECTAR = strConexion
            Dim cmd As New MySqlCommand(strSQL, CON)
            intNum = CInt(cmd.ExecuteScalar)
            If intNum.Equals(INT_CERO) Then
                'ID de nuevo registro
                strSQL = "SELECT (IFNULL(MAX(cat_num),0)+1) ID FROM Catalogos"
                MyCnn.CONECTAR = strConexion
                cmd = New MySqlCommand(strSQL, CON)
                intNum = CInt(cmd.ExecuteScalar)
            End If

            'Instruccion de remplazo
            strSQL = "REPLACE INTO Catalogos SET cat_num={numero}, cat_clase='Cheques', cat_clave='Max_Num', cat_desc={cheque}, cat_sist={cuenta}"
            strSQL = strSQL.Replace("{numero}", intNum)
            strSQL = strSQL.Replace("{cheque}", Base.Text(CeldaCheque.Text))
            strSQL = strSQL.Replace("{cuenta}", Base.Text(intCuenta.ToString))
            MyCnn.CONECTAR = strConexion
            cmd = New MySqlCommand(strSQL, CON)
            cmd.ExecuteNonQuery()
        End If
    End Sub

    'Guardar los datos de la cuenta
    Public Function GuardarCuenta() As Boolean
        Dim logEx As Boolean = False
        If ComprobarCuenta() Then
            If EsNuevo Then
                'Generar ID para cuenta nueva
                CeldaCodigo.Text = Base.ObtenerNuevaCuentaID.ToString
            End If
            If GuardarDatos() Then
                GuardarNumero()
                logEx = True
            ElseIf EsNuevo Then
                CeldaCodigo.Text = INT_CERO.ToString("D3")
            End If
        End If

        Return logEx
    End Function

    'Borrar la cuenta actual 
    Public Function BorrarCuenta() As Boolean
        Dim logEx As Boolean = False
        If MessageBox.Show("Are you sure you want to delete this bank account?", "Delete bank account", MessageBoxButtons.YesNo, MessageBoxIcon.Warning, MessageBoxDefaultButton.Button2) = DialogResult.Yes Then
            If TieneMovimiento(ID) Then
                MessageBox.Show("Cannot delete bank accounts with active transactions", "Bank account", MessageBoxButtons.OK, MessageBoxIcon.Information)
            Else
                Try
                    MyCnn.CONECTAR = strConexion
                    Using cmd As New MySqlCommand(Base.SQLBorrarCuenta(ID), CON)
                        cmd.ExecuteNonQuery()
                    End Using
                    logEx = True

                    'Bitacora
                    MyCnn.CONECTAR = strConexion
                    cFunciones.EscribirRegistro("CtasBcos", clsFunciones.AccEnum.acDelete, _ID)

                    MessageBox.Show("Bank account successfully deleted", "Bank accounts", MessageBoxButtons.OK, MessageBoxIcon.Information)
                Catch ex As Exception
                End Try
            End If
        End If
        Return logEx
    End Function

    'Deveulve verdadero si la cuenta bancaria tiene al menos un registro en movimientos
    Private Function TieneMovimiento(ByVal ID As Integer) As Boolean
        Dim logEx As Boolean = False
        Dim strSQL As String = Base.SQLCantidadMovimientos(ID)
        Dim obj As Object
        MyCnn.CONECTAR = strConexion
        Using cmd As New MySqlCommand(strSQL, CON)
            obj = cmd.ExecuteScalar
            If obj IsNot Nothing Then
                logEx = (CInt(obj) > INT_CERO)
            End If
        End Using
        Return logEx
    End Function

    'Muestra los datos de la reserva
    Private Sub MostrarReserva(ByVal ID As Integer)
        Dim strSQL As String = Base.SQLReserva(ID)
        Dim row As DataGridViewRow

        cFunciones.CargarLista(Reserva, strSQL)

        'Dar formato de fecha, color y total
        Reserva.SuspendLayout()
        Reserva.Columns(1).DefaultCellStyle.Format = "dd/MM/yyyy"
        Reserva.Columns(4).DefaultCellStyle.Format = "N2"
        Reserva.Columns(4).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight
        For Each row In Reserva.Rows
            row.Cells(3).Style.BackColor = Color.LightYellow
        Next
        Reserva.ResumeLayout()

        'Recuperar total de reservas
        CeldaReserva.Text = Base.TotalEnReserva(ID).ToString(FMT_MSO_TOTAL)
    End Sub

    Private Sub MostrarMovimiento(ByVal ID As Integer)
        Dim strSQL As String = String.Empty
        Dim logSecreto As Boolean
        Dim intFilas As Integer
        Dim dblSaldo As Double = 0.0
        Dim dblCredito As Double = 0.0
        Dim dblDebito As Double = 0.0

        Dim cmd As MySqlCommand
        Dim da As MySqlDataAdapter
        Dim dt As System.Data.DataTable
        Dim dr As DataRow

        Dim fila As DataGridViewRow

        Cursor.Current = Cursors.WaitCursor

        'Recupera el saldo a la fecha de inicio
        dblSaldo = Base.SaldoActual(ID, FiltroDesde.Value, False)

        Movimiento.SuspendLayout()
        Movimiento.Rows.Clear()
        Movimiento.Columns(fecha.Index).DefaultCellStyle.Format = "dd/MM/yyyy"
        Movimiento.Columns(fecha.Index).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter
        Movimiento.Columns(credito.Index).DefaultCellStyle.Format = "N2"
        Movimiento.Columns(credito.Index).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight
        Movimiento.Columns(debito.Index).DefaultCellStyle.Format = "N2"
        Movimiento.Columns(debito.Index).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight
        Movimiento.Columns(saldo.Index).DefaultCellStyle.Format = "N2"
        Movimiento.Columns(saldo.Index).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight

        'Recuperar lista de movimientos
        strSQL = Base.SQLMovimiento(ID, strClase, intFiltroTipo, FiltroDesde.Value, FiltroHasta.Value)
        MyCnn.CONECTAR = strConexion
        cmd = New MySqlCommand(strSQL, CON)
        da = New MySqlDataAdapter(cmd)
        dt = New System.Data.DataTable
        da.Fill(dt)

        'Recorrer para llenar
        For Each dr In dt.Rows
            Dim data As String() = New String() {dr("tipo"), dr("ciclo"), dr("numero"), Format(dr("fecha"), "dd/MM/yyyy"), dr("documento"), dr("referencia"), dr("dato"), dr("credito"), dr("debito"), INT_CERO, dr("concepto"), dr("poliza"), dr("costos"), dr("presupuesto"), dr("estado"), dr("secreto")}
            Movimiento.Rows.Add(data)
        Next
        'Recorrer para dar formato
        For Each fila In Movimiento.Rows
            logSecreto = CBool(fila.Cells(privado.Index).Value)
            dblCredito = CDbl(fila.Cells(credito.Index).Value)
            dblDebito = CDbl(fila.Cells(debito.Index).Value)
            dblSaldo = ((dblSaldo + dblCredito) - dblDebito)

            If logSecreto Then
                dblCredito = INT_CERO
                dblDebito = INT_CERO
                fila.Cells(debito.Index).Style.BackColor = Color.LightGray
                fila.Cells(credito.Index).Style.BackColor = Color.LightGray
            End If
            fila.Cells(credito.Index).Value = Format(dblCredito, FMT_MSO_TOTAL)
            fila.Cells(debito.Index).Value = Format(dblDebito, FMT_MSO_TOTAL)
            fila.Cells(saldo.Index).Value = Format(dblSaldo, FMT_MSO_TOTAL)

            '11 poliza, 12 costos, 13 presupuesto, 14 estado
            If fila.Cells(poliza.Index).Value.Equals(INT_CERO.ToString) Then
                'Si no tiene poliza fecha con fondo naranja
                fila.Cells(fecha.Index).Style.BackColor = Color.Orange
            ElseIf fila.Cells(costos.Index).Value.Equals(String.Empty) Or fila.Cells(costos.Index).Value.Equals(INT_CERO.ToString) Then
                'Si no tiene centro de costos descripcion con fondo amarillo
                fila.Cells(dato.Index).Style.BackColor = Color.Yellow
            End If

            If fila.Cells(presupuesto.Index).Value.Equals(INT_UNO.ToString) Then
                'Si presupuesto es 1, documento fondo celeste y texto azul
                fila.Cells(documento.Index).Style.BackColor = Color.LightBlue
                fila.Cells(documento.Index).Style.ForeColor = Color.Blue
            End If

            'Si el documento es cheque y esta ANULADO
            If fila.Cells(tipo.Index).Value.Equals(Base.IdCheque.ToString) Then
                If fila.Cells(estado.Index).Value.Equals(clsBancos.ES_ANULADO.ToString) Then
                    'Desde fecha hasta concepto
                    For i As Integer = fecha.Index To concepto.Index
                        If i = documento.Index Then
                            'Tipo de documento fondo rojo
                            fila.Cells(i).Style.BackColor = Color.Red
                            'Presupuesto texto amarillo sino blanco
                            If fila.Cells(presupuesto.Index).Value.Equals(INT_UNO.ToString) Then
                                fila.Cells(i).Style.ForeColor = Color.Yellow
                            Else : fila.Cells(i).Style.ForeColor = Color.White
                            End If
                        Else
                            'Texto rojo
                            fila.Cells(i).Style.ForeColor = Color.Red
                        End If
                    Next
                End If
            End If
        Next

        intFilas = Movimiento.Rows.Count
        If intFilas > INT_CERO Then
            Movimiento.FirstDisplayedScrollingRowIndex = (intFilas - 1)
            Movimiento.Rows(intFilas - 1).Selected = True
            Movimiento.CurrentCell = Movimiento.Rows(intFilas - 1).Cells(fecha.Index)
        End If
        Movimiento.ResumeLayout()

    End Sub

    'Seleccionar cuenta contable
    Private Sub BotonContable_Click(sender As Object, e As EventArgs) Handles BotonContable.Click
        Dim strWhere As String = "BCta_Sis_Emp = {empresa}".Replace("{empresa}", Sesion.IdEmpresa)

        Using frm As New frmSeleccionar
            frm.Titulo = " Account"
            frm.Tabla = cFunciones.ContaEmpresa & ".cuentas"
            frm.Campos = " DISTINCT(id_cuenta) Account, nombre Name "
            frm.Condicion = "id_cuenta>0"
            frm.FiltroText = " Enter part of the account name to apply the filter"
            frm.Filtro = "nombre"
            frm.Ordenamiento = "id_cuenta"
            frm.TipoOrdenamiento = String.Empty
            frm.ShowDialog(Me)
            If frm.DialogResult = DialogResult.OK Then
                CeldaContable.Text = frm.LLave.Trim
                CeldaContable.Focus()
            End If
        End Using
    End Sub

    'Seleccionar moneda
    Private Sub BotonMoneda_Click(sender As Object, e As EventArgs) Handles BotonMoneda.Click
        Using frm As New frmSeleccionar
            frm.Titulo = " Currency"
            frm.Tabla = "Catalogos"
            frm.Campos = "cat_num ID, cat_clave Symbol"
            frm.Condicion = "cat_clase='Monedas'"
            frm.FiltroText = "Enter the currency text to be filtered"
            frm.Filtro = "cat_clave"
            frm.Ordenamiento = "cat_num"
            frm.TipoOrdenamiento = String.Empty
            frm.Limite = 20
            frm.ShowDialog()
            If frm.DialogResult = DialogResult.OK Then
                'ID y abreviatura de moneda
                intMoneda = CInt(frm.LLave)
                CeldaMoneda.Text = frm.Dato

                'Recuperar nombre de la moneda
                Dim strSQL As String = "SELECT cat_desc FROM Catalogos WHERE cat_num={id}"
                MyCnn.CONECTAR = strConexion
                Dim cmd As New MySqlCommand(strSQL.Replace("{id}", intMoneda), CON)
                CeldaDivisa.Text = cmd.ExecuteScalar().ToString.Trim
                CeldaMoneda.Focus()
            End If
        End Using
    End Sub

    'Seleccionar banco
    Private Sub BotonBanco_Click(sender As Object, e As EventArgs) Handles BotonBanco.Click
        Using frm As New frmSeleccionar
            frm.Titulo = " Bank"
            frm.Tabla = "Catalogos"
            frm.Campos = "cat_num ID, cat_desc Bank"
            frm.Condicion = "cat_clase='Bancos'"
            frm.FiltroText = "Enter part of the bank name to apply the filter"
            frm.Filtro = "cat_desc"
            frm.Ordenamiento = "cat_desc"
            frm.TipoOrdenamiento = String.Empty
            frm.ShowDialog()
            If frm.DialogResult = DialogResult.OK Then
                'ID y nombre del banco
                intBanco = CInt(frm.LLave)
                CeldaBanco.Text = frm.Dato
                CeldaBanco.Focus()
            End If
        End Using
    End Sub

    'Tipo de cuenta bancaria
    Private Sub BotonTipoCuenta_Click(sender As Object, e As EventArgs) Handles BotonTipoCuenta.Click
        Using frm As New frmSeleccionar
            frm.Titulo = " Bank Account Type"
            frm.Tabla = "Catalogos"
            frm.Campos = "cat_num ID, cat_desc Type"
            frm.Condicion = "cat_clase='Tipo_Cuentas'"
            frm.FiltroText = "Enter part of the bank account type to apply the filter"
            frm.Filtro = "cat_desc"
            frm.Ordenamiento = "cat_desc"
            frm.TipoOrdenamiento = String.Empty
            frm.ShowDialog()
            If frm.DialogResult = DialogResult.OK Then
                CeldaTipo.Text = frm.Dato
                CeldaTipo.Focus()
            End If
        End Using
    End Sub

    'Ultimo cheque de esta cuenta
    Private Sub BotonUltimoCheque_Click(sender As Object, e As EventArgs) Handles BotonUltimoCheque.Click
        Dim intNum As Integer = INT_CERO
        Dim strDato As String = String.Empty

        strDato = InputBox("Enter the last check number of the current checkbook", "Current checkbook", CeldaCheque.Text)
        If Not String.IsNullOrEmpty(strDato) Then
            If Not strDato.Equals(CeldaCheque.Text) Then
                If Integer.TryParse(strDato, intNum) Then
                    If intNum > INT_CERO Then
                        CeldaCheque.Text = intNum.ToString("D8")
                        CeldaCheque.Focus()

                        GuardarNumero()
                    End If
                Else
                    MessageBox.Show("Check number must be a numeric value", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
                End If
            End If
        End If
    End Sub

    'FILTRO: Seleccion de tipo de cuenta
    Private Sub BotonFiltroTipo_Click(sender As Object, e As EventArgs) Handles BotonFiltroTipo.Click
        Dim strSQL As String = "((SELECT 0 ID, '(Show all...)' Document) UNION (SELECT DISTINCT m.BMov_Cat_Doc ID, c.cat_desc Document FROM MvtosBcos m LEFT JOIN Catalogos c ON c.cat_num = m.BMov_Cat_Doc WHERE m.BMov_Sis_Emp = {empresa} AND m.BMov_Cta = {cuenta} AND m.BMov_Cat_Doc)) x"
        strSQL = strSQL.Replace("{empresa}", Sesion.IdEmpresa)
        strSQL = strSQL.Replace("{cuenta}", CeldaCodigo.Text)
        Using frm As New frmSeleccionar
            frm.Titulo = " Bank Document Type"
            frm.Tabla = strSQL
            frm.Campos = "x.ID, x.Document"
            frm.Condicion = "NOT(x.Document ='')"
            frm.FiltroText = "Enter part of the bank document type to apply the filter"
            frm.Filtro = "x.Document"
            frm.Ordenamiento = String.Empty
            frm.TipoOrdenamiento = String.Empty
            frm.ShowDialog()
            If frm.DialogResult = DialogResult.OK Then
                intFiltroTipo = frm.LLave
                FiltroTipo.Text = frm.Dato
                FiltroTipo.Focus()
            End If
        End Using
    End Sub

    'Evento de carga del control
    Private Sub usrBancoCuenta_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        FiltroDesde.MaxDate = Today
        If Not Me.DesignMode Then
            IdentificarModulo()
        End If

        AsignarEventos
    End Sub

    'Asigna eventos a los controles
    Private Sub AsignarEventos()
        'Keypress para emular tabulador en casillas de texto
        AddHandler CeldaNumero.KeyPress, AddressOf CeldaCodigo_KeyPress
        AddHandler CeldaTipo.KeyPress, AddressOf CeldaCodigo_KeyPress
        AddHandler CeldaBanco.KeyPress, AddressOf CeldaCodigo_KeyPress
        AddHandler CeldaNombre.KeyPress, AddressOf CeldaCodigo_KeyPress
        AddHandler CeldaDescripcion.KeyPress, AddressOf CeldaCodigo_KeyPress
        AddHandler CeldaContacto.KeyPress, AddressOf CeldaCodigo_KeyPress
        AddHandler CeldaMoneda.KeyPress, AddressOf CeldaCodigo_KeyPress
        AddHandler CeldaDivisa.KeyPress, AddressOf CeldaCodigo_KeyPress
        AddHandler CeldaSobregiro.KeyPress, AddressOf CeldaCodigo_KeyPress
        AddHandler CeldaPlazo.KeyPress, AddressOf CeldaCodigo_KeyPress
        AddHandler CeldaContable.KeyPress, AddressOf CeldaCodigo_KeyPress
        AddHandler CeldaCheque.KeyPress, AddressOf CeldaCodigo_KeyPress
        AddHandler CeldaSaldo.KeyPress, AddressOf CeldaCodigo_KeyPress
        AddHandler CeldaReserva.KeyPress, AddressOf CeldaCodigo_KeyPress
    End Sub

    'Recupera el ID del modulo
    Private Sub IdentificarModulo()
        Dim strSQL As String = "SELECT pro_codigo ID FROM Programas WHERE pro_forma={modulo}".Replace("{modulo}", Base.Text(STR_MODULO))
        MyCnn.CONECTAR = strConexion
        Dim cmd As New MySqlCommand(strSQL, CON)
        Dim obj As Object

        'Obtener ID de modulo
        obj = cmd.ExecuteScalar
        If obj IsNot Nothing Then
            intModulo = CInt(obj)
        End If
    End Sub

    'Clic para actualizar filtro
    Private Sub BotonActualizar_Click(sender As Object, e As EventArgs) Handles BotonActualizar.Click
        If FiltroDesde.Value > FiltroHasta.Value Then
            MessageBox.Show("Please correct starting date", "Date Range", MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
        Else
            MostrarMovimiento(CInt(CeldaCodigo.Text))
            Movimiento.Focus()
        End If
    End Sub

    'Doble clic en un documento
    Private Sub Movimiento_DoubleClick(sender As Object, e As EventArgs) Handles Movimiento.DoubleClick
        Dim intTipo As Integer
        Dim intCiclo As Integer
        Dim intNumero As Integer
        Dim intDoc As Integer
        Dim logSecreto As Boolean

        'Identificar documento seleccionado
        If Not (Movimiento.SelectedRows.Count.Equals(INT_CERO)) Then
            'Tipo de documento de catalogo, año y numero
            intTipo = CInt(Movimiento.SelectedCells(tipo.Index).Value)
            intCiclo = CInt(Movimiento.SelectedCells(ciclo.Index).Value)
            intNumero = CInt(Movimiento.SelectedCells(numero.Index).Value)

            'Documento confidencial
            logSecreto = Base.EsConfidencial(intTipo, intCiclo, intNumero)
            'TODO quitar, solo para depuracion
            If Me.DesignMode Then
                logSecreto = False
            End If
            If logSecreto And Not logConfidencial Then
                MessageBox.Show("You do not have permission to open this document", "Confidential", MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
                Movimiento.Focus()
            Else
                'Recuperar el ID de documento bancario
                intDoc = Base.ObtenerIdBancoDocumento(intTipo)

                'Generar evento
                RaiseEvent DocumentoSeleccionado(intTipo, intCiclo, intNumero, intDoc)

            End If
        End If
    End Sub

    'Clic en el boton deposito
    Private Sub BotonDeposito_Click(sender As Object, e As EventArgs) Handles BotonDeposito.Click
        Dim intDoc As Integer = Base.ObtenerIdDeDocumento(clsBancos.BCO_DEPOSITO)

        'Generar evento
        RaiseEvent DocumentoSeleccionado(Base.IdDeposito, INT_CERO, INT_CERO, intDoc)
    End Sub

    'Clic en el boton credito
    Private Sub BotonCredito_Click(sender As Object, e As EventArgs) Handles BotonCredito.Click
        'Generar evento
        RaiseEvent DocumentoSeleccionado(Base.IdCredito, INT_CERO, INT_CERO, INT_CERO)
    End Sub

    'Clic en el boton cheque
    Private Sub BotonCheque_Click(sender As Object, e As EventArgs) Handles BotonCheque.Click
        Dim intDoc As Integer = Base.ObtenerIdDeDocumento(clsBancos.BCO_CHEQUE)

        'Generar evento
        RaiseEvent DocumentoSeleccionado(Base.IdCheque, INT_CERO, INT_CERO, intDoc)
    End Sub

    'Clic en el boton debito
    Private Sub BotonDebito_Click(sender As Object, e As EventArgs) Handles BotonDebito.Click
        'Generar evento
        RaiseEvent DocumentoSeleccionado(Base.IdDebito, INT_CERO, INT_CERO, INT_CERO)
    End Sub

    'Imprimir estado de cuenta
    Private Sub BotonFiltroImprimir_Click(sender As Object, e As EventArgs) Handles BotonFiltroImprimir.Click
        Dim intTipo As Integer = NO_FILA
        Using frm As New frmOption
            frm.Titulo = " Bank Account Balance"
            frm.Mensaje = " Type of Report"
            frm.Opciones = "Bank Account Statement|Summary|Bank Account Statement with budget"
            If frm.ShowDialog(Me) = DialogResult.OK Then
                intTipo = frm.Seleccion
                Select Case intTipo
                    Case INT_CERO
                        Base.ImprimirEstadoDeCuenta(ID, FiltroDesde.Value.Date, FiltroHasta.Value.Date, intFiltroTipo)
                    Case INT_UNO
                        Base.ImprimirEstadoDeCuentaResumen(ID, FiltroDesde.Value.Date, FiltroHasta.Value.Date)
                    Case 2
                        Base.ImprimirEstadoDeCuenta(ID, FiltroDesde.Value.Date, FiltroHasta.Value.Date, intFiltroTipo, 1)
                End Select
            End If
        End Using
    End Sub

    Private Sub BotonConfigurarCheque_Click(sender As Object, e As EventArgs) Handles BotonConfigurarCheque.Click
        Using frm As New frmBFormato
            frm.Cargar(_ID)
            If frm.ShowDialog() = DialogResult.OK Then

            End If
        End Using
    End Sub

    Private Sub CeldaCodigo_KeyPress(sender As Object, e As KeyPressEventArgs) Handles CeldaCodigo.KeyPress
        Dim texto As TextBox
        texto = CType(sender, TextBox)

        If Char.IsControl(e.KeyChar) Then
            If e.KeyChar.Equals(Chr(Keys.Return)) Then
                Me.SelectNextControl(texto, True, True, True, True)
                e.Handled = True
            End If
        End If
    End Sub

    Private Sub Movimiento_KeyDown(sender As Object, e As KeyEventArgs) Handles Movimiento.KeyDown
        If e.KeyCode = Keys.F3 Then
            e.SuppressKeyPress = True
            If Movimiento.Rows.Count > INT_CERO Then
                'Mostrar ventana de busqueda
                BuscarTexto
            End If
        ElseIf e.KeyCode = Keys.F7 Then
            Dim rpt As New clsReportes
            rpt.Historial(Movimiento.SelectedCells(2).Value, Movimiento.SelectedCells(1).Value, Movimiento.SelectedCells(0).Value)
        End If
    End Sub

    Private Sub BuscarTexto()
        Dim strTemp As String = String.Empty
        Dim strDato As String = String.Empty

        Dim intDesde As Integer = INT_CERO
        Dim intFilas As Integer = (Movimiento.Rows.Count - 1)
        Dim intCols As Integer = (Movimiento.Columns.Count - 1)

        Dim logEx As Boolean = False

        strTemp = InputBox(String.Empty, "Search" & IIf(strBuscar.Equals(String.Empty), String.Empty, " next"), strBuscar).Trim.ToUpper
        If strTemp.Equals(String.Empty) Then
            strBuscar = String.Empty
        Else
            'Si el texto es diferente buscar desde el inicio
            If strTemp.Equals(strBuscar) Then
                intDesde = (Movimiento.CurrentRow.Index + 1)
            End If
            strBuscar = strTemp

            'Recorrer las filas
            For i As Integer = intDesde To intFilas
                'Recorrer las columnas
                For j As Integer = INT_CERO To intCols
                    If Movimiento.Columns(j).Visible Then
                        strDato = If(Movimiento.Rows(i).Cells(j).Value, String.Empty).ToString().ToUpper.Trim
                        If strDato.Contains(strTemp) Then
                            'Seleccionar fila encontrada
                            Movimiento.ClearSelection()
                            Movimiento.CurrentCell = Movimiento.Rows(i).Cells(fecha.Index)
                            logEx = True
                            Exit For
                        End If
                    End If
                Next
                If logEx Then Exit For
            Next

            If Not logEx Then
                strBuscar = String.Empty
                MessageBox.Show("No search results for this text", "Search", MessageBoxButtons.OK, MessageBoxIcon.Information)
            End If
            Movimiento.Focus()
        End If
    End Sub

    Private Sub BotonConciliacion_Click(sender As Object, e As EventArgs) Handles BotonConciliacion.Click
        Dim frm As New frmConciliacionBancaria

        If Not Month(FiltroDesde.Value) = Month(FiltroHasta.Value) Then
            MsgBox("Check the date range", vbCritical, "Notice")
            Exit Sub
        End If

        frm.dtaFechaInicio = FiltroDesde.Value
        frm.dtaFechaFin = FiltroHasta.Value
        frm.intBanco = CeldaCodigo.Text
        frm.dblInicial = INT_CERO

        frm.ShowDialog(Me)
    End Sub
End Class
